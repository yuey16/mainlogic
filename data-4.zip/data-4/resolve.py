"""Link every LaTeX cite key in a paper to the Semantic Scholar record it cites.

The pipeline's training labels depend on knowing, for each `\\cite{key}` in a
paper, the full text of the work being cited. The cite keys live only in the
LaTeX; Semantic Scholar never sees the LaTeX and returns no keys. This script
bridges the two, taking `bibitems.json` (one record per `\\bibitem`) and S2's
parsed reference list for the same paper, and pairing them up.

Each cite key is tried against the S2 references in a cascade, most reliable
first, and the tier that fired is recorded so downstream code can filter:

    1. arxiv_id_in_bibitem   the bibitem names an arXiv id and an S2 reference
                             carries the same one               (confidence 1.0)
    2. doi_in_bibitem        same, with a DOI (case-insensitive) (confidence 1.0)
    3. title_fuzzy           normalised titles agree to at least
                             `--fuzzy-threshold` (rapidfuzz token_set_ratio),
                             the years agree when both are known, and the
                             author lists share a surname when both are known
                                                            (confidence score/100)
    4. title_search          the key is still unresolved, so S2's title-match
                             endpoint is asked for its single best hit for the
                             bibitem's title; the hit must then pass exactly
                             the tier-3 gates                (confidence score/100)

A wrong match is far worse than no match: a cite key silently pointing at the
wrong paper poisons every entailment label built from the sentences that cite
it, whereas an unresolved key just means those sentences are skipped. So the
fuzzy threshold defaults high (92), year and author agreement are second and
third gates, and matching is one-to-one — once an S2 reference is claimed by a
higher-confidence key it is off the table for everyone else.

Why three gates: any title scorer puts "Attention is all you need" against
"Attention is not all you need" over the threshold (token_sort_ratio: 92.6;
token_set_ratio: 100). Titles that differ by one small word are exactly the
near-twins we must not confuse, and the title score alone cannot tell them
apart; a different year or a disjoint author list can. The author gate is the
defence that actually carries that case — see `title_score` for the measured
comparison of scorers.

Keys with an arXiv id or DOI that S2 failed to list among the paper's
references are looked up directly (one batch request), because S2's reference
extraction is not exhaustive and the bibitem's own id is authoritative.

Tier 4 exists because S2's reference list carries "stubs": bibliography lines
it parsed but never linked to a record (no paperId), which tiers 1-3 cannot
use. The title-match endpoint reaches the record from the title alone. It is
one request per still-unresolved key, cached, and its hit goes through the
same three gates as tier 3 so it can never admit what tier 3 would refuse.

Finally, a matched record can carry no arXiv id, no DOI and no open-access
PDF, leaving downstream full-text fetching nothing to go on. Two repairs run
on those, filling only nulls:

  * the record is re-fetched by paperId in one batch request, in case the
    `/references` endpoint returned it with sparser fields than S2 holds;
  * if it is still bare but has a DBLP key, S2 is searched for a *sibling*
    record with the same DBLP key stem (`conf/nips/SukhbaatarSWF15` and
    `journals/corr/SukhbaatarSWF15` are the venue and arXiv versions of one
    work that S2 never merged) and the sibling's ids and PDF are copied over.
    The stem is the main evidence here, not the 92-point title gate: the
    arXiv v1 title often differs from the venue title. Only a weak title
    floor (60) is applied, enough to tell a retitled version of the same work
    from a different paper by the same group in the same year. A stem with
    more than one possible sibling is skipped, not guessed.

Output, next to the input:

    data/clean/arXiv-<paper>/refs.json

Every cite key appears there, matched or unresolved — downstream code skips
sentences citing unresolved keys, so an omitted key would be a silent bug.

Usage:
    python data/resolve.py data/papers.txt
    python data/resolve.py data/papers.txt --clean data/clean --fuzzy-threshold 92 -v
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys
import unicodedata
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from rapidfuzz import fuzz  # noqa: E402

from clean import read_id_list  # noqa: E402
from s2 import DEFAULT_CACHE_DIR, S2Client, S2Error, S2NotFound, strip_version  # noqa: E402

log = logging.getLogger("resolve")

# Path of the id-list file this run was given, so error messages can quote the
# exact command that fixes the problem instead of a generic "run X first".
args_ids_hint = "data/papers.txt"

METHOD_ARXIV = "arxiv_id_in_bibitem"
METHOD_DOI = "doi_in_bibitem"
METHOD_FUZZY = "title_fuzzy"
METHOD_SEARCH = "title_search"
METHOD_NONE = "none"
METHODS = (METHOD_ARXIV, METHOD_DOI, METHOD_FUZZY, METHOD_SEARCH)

# Default thresholds; see the module docstring for why they lean strict.
DEFAULT_FUZZY_THRESHOLD = 92
# arXiv preprints and their conference versions are routinely a year apart
# (Adam: arXiv 2014, ICLR 2015), and S2 may hold either date, so exact year
# agreement would reject correct matches. Two years apart is a different paper.
DEFAULT_YEAR_TOLERANCE = 1
# Scores below the threshold but above this are logged, so a near-miss is
# visible to a human rather than silently unresolved.
NEAR_MISS_FLOOR = 75

EXTERNAL_ID_KEYS = ("ArXiv", "DOI", "ACL", "PubMedCentral")

# Try at most this many of a record's authors when hunting for its DBLP
# sibling; a prolific coauthor's list can run to several pages.
MAX_SIBLING_AUTHORS = 2
# DBLP key stem: `conf/nips/SukhbaatarSWF15` -> `SukhbaatarSWF15`. Within one
# venue stream DBLP disambiguates same-stem works with a letter suffix
# (`...15a`), so the suffix is stripped to see the whole family at once.
DBLP_STEM_SUFFIX_RE = re.compile(r"(?<=\d{2})[a-z]$")
# Weak title gate for a DBLP sibling: "plausibly the same work under another
# name", not "the same title" — deliberately far below the 92 identity gate.
# A DBLP stem is only <first author><coauthor initials><year>, so two different
# papers by one group in one year can share it across venue streams; the
# retitled arXiv version of a work still keeps its distinctive noun phrase,
# an unrelated paper does not. Measured on the one observed pair, on the
# normalised titles this code compares: the true sibling ("End-To-End Memory
# Networks" vs "Weakly Supervised Memory Networks") scores 81 (73.2 on the raw
# strings), an unrelated paper by the same author about 30 (36.4 raw).
# Calibrated on a single pair, so provisional; when in doubt it rejects, and a
# wrong rejection only forfeits an arXiv id, whereas a wrong acceptance would
# label the wrong paper's full text as the cited work.
SIBLING_TITLE_FLOOR = 60


# --- title normalisation -----------------------------------------------------

# `\"{u}`, `\'e`, `\c{c}`, `\L`, `\em`, `\textbf` ... — drop the command, keep
# any argument text. Accented letters produced by TeX macros are handled by the
# unicode fold below once the backslash-command is gone.
LATEX_COMMAND_RE = re.compile(r"\\[a-zA-Z]+\s*|\\[\"'`^~=.uvHtcdbr]\s*")
# Everything that isn't a letter, digit or space becomes a space; brackets from
# clean.py's `{}` -> `()` rewrite go with it.
NON_ALNUM_RE = re.compile(r"[^0-9a-z\s]+")


def normalise_title(text: str | None) -> str:
    """Fold a title down to lowercase ASCII words so LaTeX noise can't sink a match."""
    if not text:
        return ""
    text = LATEX_COMMAND_RE.sub("", text)
    # Braces protect capitalisation and are glued to their word (`{GPU}s`,
    # `{LSTM}`), so they vanish without leaving a space that would split it.
    text = text.replace("{", "").replace("}", "")
    text = text.replace("~", " ")
    # NFKD splits `é` into `e` + combining accent; dropping the marks leaves ASCII.
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower()
    text = NON_ALNUM_RE.sub(" ", text)
    return " ".join(text.split())


# "A, B, and C", "A and B", "A & B", "A, B, et al." — anything that separates names.
AUTHOR_SPLIT_RE = re.compile(r"\s*(?:,|;|\band\b|&|\\&|\bet\s+al\b\.?)\s*", re.IGNORECASE)


def surnames(names: list[str] | str | None) -> set[str]:
    """Folded surnames from an author list, in either free text or S2's list form.

    The surname is taken to be the last word of each name, which holds for the
    formats both sides use ("Diederik Kingma", "I. Sutskever", "Vinyals"). It
    is only ever used to ask "do these two lists share *anyone*?", so a few
    misparsed names cost nothing as long as one surname survives.
    """
    if not names:
        return set()
    if isinstance(names, str):
        # `et~al.` uses a LaTeX tie, which the separator regex must see as a space.
        parts = AUTHOR_SPLIT_RE.split(names.replace("~", " "))
    else:
        parts = list(names)
    out: set[str] = set()
    for part in parts:
        words = normalise_title(part).split()
        if words and len(words[-1]) >= 2:
            out.add(words[-1])
    return out


# --- data shapes -------------------------------------------------------------


@dataclass
class BibItem:
    key: str
    title: str | None
    authors: str | None
    year: int | None
    arxiv_id: str | None
    doi: str | None
    norm_title: str = field(init=False)
    surnames: set[str] = field(init=False)

    def __post_init__(self) -> None:
        self.norm_title = normalise_title(self.title)
        self.surnames = surnames(self.authors)

    @classmethod
    def from_json(cls, key: str, entry: dict[str, Any]) -> BibItem:
        year = entry.get("year")
        arxiv_id = entry.get("arxiv_id")
        doi = entry.get("doi")
        return cls(
            key=key,
            title=entry.get("title") or None,
            authors=entry.get("authors") or None,
            year=int(year) if year not in (None, "") else None,
            arxiv_id=strip_version(str(arxiv_id)) if arxiv_id else None,
            doi=str(doi).strip().lower() if doi else None,
        )


@dataclass
class Candidate:
    """One S2 paper record, whether it came from the reference list or a direct lookup."""

    paper_id: str
    title: str | None
    year: int | None
    authors: list[str]
    external_ids: dict[str, str | None]
    open_access_pdf: str | None
    norm_title: str = field(init=False)
    surnames: set[str] = field(init=False)

    def __post_init__(self) -> None:
        self.norm_title = normalise_title(self.title)
        self.surnames = surnames(self.authors)

    @property
    def arxiv_id(self) -> str | None:
        return self.external_ids.get("ArXiv")

    @property
    def doi(self) -> str | None:
        doi = self.external_ids.get("DOI")
        return doi.lower() if doi else None

    @classmethod
    def from_paper(cls, paper: dict[str, Any]) -> Candidate | None:
        """Build from an S2 paper dict; None when S2 couldn't link it to a record.

        S2 keeps reference "stubs" it parsed from a bibliography but never
        resolved. They have a title but no paperId and no way to reach a full
        text, so matching a key to one would claim success while delivering
        nothing.
        """
        paper_id = paper.get("paperId")
        if not paper_id:
            return None
        ext = paper.get("externalIds") or {}
        pdf = paper.get("openAccessPdf") or {}
        return cls(
            paper_id=paper_id,
            title=paper.get("title"),
            year=paper.get("year"),
            authors=[a.get("name") or "" for a in paper.get("authors") or []],
            external_ids={k: ext.get(k) for k in EXTERNAL_ID_KEYS},
            open_access_pdf=pdf.get("url") or None,
        )


@dataclass
class Match:
    status: str  # matched | unresolved
    match_method: str
    confidence: float
    s2_paper_id: str | None
    title: str | None
    external_ids: dict[str, str | None]
    open_access_pdf: str | None

    @classmethod
    def unresolved(cls) -> Match:
        return cls(
            status="unresolved",
            match_method=METHOD_NONE,
            confidence=0.0,
            s2_paper_id=None,
            title=None,
            external_ids={k: None for k in EXTERNAL_ID_KEYS},
            open_access_pdf=None,
        )

    @classmethod
    def to_candidate(cls, cand: Candidate, method: str, confidence: float) -> Match:
        return cls(
            status="matched",
            match_method=method,
            confidence=round(confidence, 3),
            s2_paper_id=cand.paper_id,
            title=cand.title,
            external_ids=dict(cand.external_ids),
            open_access_pdf=cand.open_access_pdf,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "match_method": self.match_method,
            "confidence": self.confidence,
            "s2_paper_id": self.s2_paper_id,
            "title": self.title,
            "external_ids": self.external_ids,
            "open_access_pdf": self.open_access_pdf,
        }


# --- matching ----------------------------------------------------------------


def title_score(a: str, b: str) -> float:
    """Title similarity in [0, 100] for the fuzzy gates, shared by tiers 3 and 4.

    token_set_ratio, not token_sort_ratio, because bibliographies routinely
    truncate titles ("A decomposable attention model" for "A Decomposable
    Attention Model for Natural Language Inference": 66 under token_sort,
    100 under token_set). Measured over all 1560 (bibitem x candidate) pairs
    of 1706.03762v7 with the year and author gates applied, both scorers admit
    the same 39 correct matches and 0 wrong ones; token_set only adds the
    truncated cases. Near-twin titles ("...is all you need" vs "...is NOT all
    you need") pass *either* scorer at threshold 92 — it is the author-surname
    gate that rejects them, not this score. Don't "tighten" this back to
    token_sort_ratio without re-measuring; it buys nothing against near-twins
    and loses the truncated titles.
    """
    return fuzz.token_set_ratio(a, b)


def years_agree(a: int | None, b: int | None, tolerance: int) -> bool:
    """True when either year is unknown; otherwise within `tolerance`."""
    if a is None or b is None:
        return True
    return abs(a - b) <= tolerance


@dataclass
class Matcher:
    """Runs the cascade for one paper, tracking which S2 records are already spoken for."""

    fuzzy_threshold: float
    year_tolerance: int
    author_check: bool = True
    matches: dict[str, Match] = field(default_factory=dict)
    claimed: set[str] = field(default_factory=set)  # S2 paperIds already assigned

    def _claim(self, item: BibItem, cand: Candidate, method: str, confidence: float) -> None:
        self.matches[item.key] = Match.to_candidate(cand, method, confidence)
        self.claimed.add(cand.paper_id)

    def _passes_gates(self, item: BibItem, cand: Candidate, score: float) -> bool:
        """The three title-match gates, shared by tiers 3 and 4 so they cannot drift apart.

        A below-threshold score is refused silently (callers report near
        misses in their own way); the year and author refusals are logged
        because they are the cases a human should look at.
        """
        if score < self.fuzzy_threshold:
            return False
        if not years_agree(item.year, cand.year, self.year_tolerance):
            # High title similarity but the wrong decade is the classic
            # "same title, different paper" trap — worth a human's eye.
            log.warning(
                "%s: title scores %.0f against %r but years disagree (%s vs %s); rejected",
                item.key,
                score,
                cand.title,
                item.year,
                cand.year,
            )
            return False
        if self.author_check and item.surnames and cand.surnames and not (item.surnames & cand.surnames):
            # Same title, same year, nobody in common — a near-twin
            # title from a different group, or a misparsed bibitem.
            # Either way a human should look, not the matcher.
            log.warning(
                "%s: title scores %.0f against %r but no author in common (%s vs %s); rejected",
                item.key,
                score,
                cand.title,
                sorted(item.surnames),
                sorted(cand.surnames),
            )
            return False
        return True

    def match_by_id(self, items: list[BibItem], candidates: list[Candidate]) -> None:
        """Tiers 1 and 2: exact identifier agreement. Tier 1 runs to completion first."""
        by_arxiv = {c.arxiv_id: c for c in candidates if c.arxiv_id}
        by_doi = {c.doi: c for c in candidates if c.doi}

        for item in items:
            if item.key in self.matches or not item.arxiv_id:
                continue
            cand = by_arxiv.get(item.arxiv_id)
            if cand is None:
                continue
            if cand.paper_id in self.claimed:
                # Two bibitems naming the same arXiv id — a duplicated entry in
                # the paper's bibliography. Leave the second unresolved rather
                # than pretend two keys map to one work.
                log.warning("%s: arXiv:%s already claimed by another key", item.key, item.arxiv_id)
                continue
            self._claim(item, cand, METHOD_ARXIV, 1.0)

        for item in items:
            if item.key in self.matches or not item.doi:
                continue
            cand = by_doi.get(item.doi)
            if cand is None:
                continue
            if cand.paper_id in self.claimed:
                log.warning("%s: DOI %s already claimed by another key", item.key, item.doi)
                continue
            self._claim(item, cand, METHOD_DOI, 1.0)

    def match_by_title(self, items: list[BibItem], candidates: list[Candidate]) -> None:
        """Tier 3: fuzzy title agreement, assigned best-score-first across all pairs.

        Scoring every (key, reference) pair and then assigning greedily from the
        top means a key can't grab a mediocre match before a better-fitting key
        has had its turn at the same reference.
        """
        pending = [i for i in items if i.key not in self.matches]
        free = [c for c in candidates if c.paper_id not in self.claimed and c.norm_title]

        scored: list[tuple[float, BibItem, Candidate]] = []
        best_seen: dict[str, tuple[float, Candidate]] = {}
        for item in pending:
            if not item.norm_title:
                log.info("%s: no title in bibitem; cannot fuzzy-match", item.key)
                continue
            for cand in free:
                score = title_score(item.norm_title, cand.norm_title)
                if score > best_seen.get(item.key, (-1.0, cand))[0]:
                    best_seen[item.key] = (score, cand)
                if self._passes_gates(item, cand, score):
                    scored.append((score, item, cand))

        scored.sort(key=lambda t: -t[0])
        for score, item, cand in scored:
            if item.key in self.matches or cand.paper_id in self.claimed:
                continue
            self._claim(item, cand, METHOD_FUZZY, score / 100.0)
            log.info("%s: title_fuzzy %.0f  %r  ->  %r", item.key, score, item.title, cand.title)

        # Explain the misses: show what the closest reference was and why it lost.
        for item in pending:
            if item.key in self.matches or item.key not in best_seen:
                continue
            score, cand = best_seen[item.key]
            if score >= NEAR_MISS_FLOOR:
                log.info(
                    "%s: unresolved; best title score %.0f (< %s) against %r",
                    item.key,
                    score,
                    self.fuzzy_threshold,
                    cand.title,
                )
            else:
                log.debug("%s: unresolved; best title score %.0f against %r", item.key, score, cand.title)

    def match_by_search(self, items: list[BibItem], s2: S2Client) -> None:
        """Tier 4: ask S2 for its best title match, then judge it exactly as tier 3 would.

        One cached request per still-unresolved key with a title. S2 returns
        its single best hit or a 404; the hit is a full paper record, so a
        match here also carries the ids the reference list may have lacked.
        Keys are taken in bibliography order and claim as they go, so two keys
        that S2 answers with the same paper cannot both take it.
        """
        pending = [i for i in items if i.key not in self.matches and i.norm_title]
        for item in pending:
            try:
                # The normalised title, not the raw one: it is free of the
                # LaTeX macros and braces that would only confuse S2's search.
                hit = s2.search_match(item.norm_title)
            except S2NotFound:
                log.debug("%s: title_search: S2 has no close title match", item.key)
                continue
            cand = Candidate.from_paper(hit)
            if cand is None or not cand.norm_title:
                continue
            if cand.paper_id in self.claimed:
                log.warning(
                    "%s: title_search returned %r, already claimed by another key; rejected",
                    item.key,
                    cand.title,
                )
                continue
            score = title_score(item.norm_title, cand.norm_title)
            if not self._passes_gates(item, cand, score):
                if score < self.fuzzy_threshold:
                    # S2 thinks this is the paper; our title gate does not.
                    # Log it so a human can judge, since it is the only lead.
                    log.info(
                        "%s: title_search returned %r but title scores %.0f (< %s); rejected",
                        item.key,
                        cand.title,
                        score,
                        self.fuzzy_threshold,
                    )
                continue
            self._claim(item, cand, METHOD_SEARCH, score / 100.0)
            log.info("%s: title_search %.0f  %r  ->  %r", item.key, score, item.title, cand.title)


def is_bare(match: Match) -> bool:
    """True when a match carries nothing a full-text fetcher could use."""
    return match.open_access_pdf is None and not any(match.external_ids.values())


def fill_gaps(match: Match, cand: Candidate) -> bool:
    """Copy `cand`'s ids and PDF into `match` where `match` has none; True if anything landed."""
    gained = False
    for key, value in cand.external_ids.items():
        if match.external_ids.get(key) is None and value:
            match.external_ids[key] = value
            gained = True
    if match.open_access_pdf is None and cand.open_access_pdf:
        match.open_access_pdf = cand.open_access_pdf
        gained = True
    return gained


def dblp_stem(dblp_key: str | None) -> str | None:
    """`conf/nips/SukhbaatarSWF15a` -> `SukhbaatarSWF15`; None when there is no key."""
    if not dblp_key:
        return None
    return DBLP_STEM_SUFFIX_RE.sub("", dblp_key.rsplit("/", 1)[-1])


def merge_dblp_sibling(s2: S2Client, match: Match, record: dict[str, Any]) -> bool:
    """Borrow ids from the record S2 keeps for the *other* version of the same work.

    S2 sometimes holds a venue version and an arXiv version of one paper as
    two unmerged records, with the arXiv id only on the one we didn't match.
    DBLP keys expose the link: both carry the same stem under different venue
    prefixes. The sibling is found by scanning the record's own authors'
    paper lists (S2 has no lookup by DBLP key). No title gate is applied —
    the arXiv v1 title is frequently not the venue title, and the shared stem
    is the identity evidence. More than one candidate sibling means the stem
    is not unique for these authors and year, so nothing is merged. A weak
    title floor (`SIBLING_TITLE_FLOOR`) still guards against a stem shared by
    two genuinely different works.
    """
    stem = dblp_stem((record.get("externalIds") or {}).get("DBLP"))
    if stem is None:
        log.info("%r: no DBLP key, so no way to find a sibling record", match.title)
        return False
    author_ids = [a.get("authorId") for a in record.get("authors") or [] if a.get("authorId")]
    for author_id in author_ids[:MAX_SIBLING_AUTHORS]:
        papers = s2.author_papers(author_id)
        siblings = [
            p
            for p in papers
            if p.get("paperId") != match.s2_paper_id
            and dblp_stem((p.get("externalIds") or {}).get("DBLP")) == stem
        ]
        if not siblings:
            continue
        if len(siblings) > 1:
            log.warning(
                "%r: DBLP stem %s is shared by %d other record(s) (%s); ambiguous, not merged",
                match.title,
                stem,
                len(siblings),
                "; ".join(repr(p.get("title")) for p in siblings),
            )
            return False
        cand = Candidate.from_paper(siblings[0])
        if cand is None:
            continue
        score = title_score(normalise_title(match.title), cand.norm_title)
        if score < SIBLING_TITLE_FLOOR:
            log.warning(
                "%r: DBLP sibling %r (%s, stem %s) scores only %.0f (< %s) on title; not merged",
                match.title,
                cand.title,
                cand.paper_id,
                stem,
                score,
                SIBLING_TITLE_FLOOR,
            )
            return False
        gained = fill_gaps(match, cand)
        log.info(
            "%r: DBLP sibling %r (%s, stem %s, title score %.0f) %s",
            match.title,
            cand.title,
            cand.paper_id,
            stem,
            score,
            "supplied " + str({k: v for k, v in cand.external_ids.items() if v})
            + (" + open-access PDF" if cand.open_access_pdf else "")
            if gained
            else "has no external id or PDF either",
        )
        return gained
    log.info(
        "%r: no record sharing DBLP stem %s among the first %d author(s)' papers",
        match.title,
        stem,
        min(len(author_ids), MAX_SIBLING_AUTHORS),
    )
    return False


def enrich_sparse_matches(s2: S2Client, matches: dict[str, Match]) -> int:
    """Fill in ids and PDF links for matches that came back from S2 with none.

    Two repairs, both filling nulls only and never overwriting an id that is
    already there. First the bare records are re-fetched by paperId in one
    batch request, since `/references` can return sparser fields than a paper
    record. Anything still bare after that is tried against its DBLP sibling
    (see `merge_dblp_sibling`). Returns how many matches gained something.
    """
    sparse = {m.s2_paper_id: m for m in matches.values() if m.s2_paper_id and is_bare(m)}
    if not sparse:
        return 0
    log.info("re-fetching %d matched record(s) that carry no external id or PDF", len(sparse))
    found = s2.papers(list(sparse))
    enriched = 0
    for paper_id, match in sparse.items():
        record = found.get(paper_id) or {}
        cand = Candidate.from_paper(record)
        if cand is None:
            log.warning("%s: S2 batch lookup returned nothing for paperId %s", match.title, paper_id)
            continue
        gained = fill_gaps(match, cand)
        if not gained:
            log.info("%r: S2 holds no external id or PDF for paperId %s either", match.title, paper_id)
        if is_bare(match):
            gained = merge_dblp_sibling(s2, match, record) or gained
        if gained:
            enriched += 1
            log.info(
                "%r: now carries %s%s",
                match.title,
                {k: v for k, v in match.external_ids.items() if v},
                " + open-access PDF" if match.open_access_pdf else "",
            )
    return enriched


def lookup_missing_ids(s2: S2Client, items: list[BibItem], matched: set[str]) -> list[Candidate]:
    """Fetch S2 records for ids the bibitems name but S2's reference list lacks.

    The bibitem is the author's own statement of what they cited; if S2 didn't
    connect the dots in its reference parse, we can still resolve the key by
    asking for that id outright.
    """
    wanted: list[str] = []
    for item in items:
        if item.key in matched:
            continue
        if item.arxiv_id:
            wanted.append(f"ArXiv:{item.arxiv_id}")
        if item.doi:
            wanted.append(f"DOI:{item.doi}")
    if not wanted:
        return []

    log.info("looking up %d id(s) S2 did not list among the references", len(wanted))
    found = s2.papers(wanted)
    candidates: list[Candidate] = []
    for requested, paper in found.items():
        cand = Candidate.from_paper(paper or {})
        if cand is None:
            log.warning("%s: Semantic Scholar has no record for this id", requested)
            continue
        candidates.append(cand)
    return candidates


# --- per-paper driving -------------------------------------------------------


def load_bibitems(path: Path) -> tuple[dict[str, Any], list[BibItem]]:
    doc = json.loads(path.read_text(encoding="utf-8"))
    entries = doc.get("entries") or {}
    items = [BibItem.from_json(key, entry or {}) for key, entry in entries.items()]
    return doc, items


def resolve_paper(
    s2: S2Client,
    paper_id: str,
    paper_dir: Path,
    fuzzy_threshold: float,
    year_tolerance: int,
    author_check: bool = True,
) -> dict[str, Any] | None:
    bib_path = paper_dir / "bibitems.json"
    if not bib_path.is_file():
        log.error(
            "%s: no bibitems.json in %s — run: python data/clean.py %s",
            paper_id,
            paper_dir,
            args_ids_hint,
        )
        return None
    _, items = load_bibitems(bib_path)
    log.info("%s: %d cite key(s) in %s", paper_id, len(items), bib_path.name)

    try:
        raw_refs = s2.references(paper_id)
    except S2NotFound:
        log.error("%s: Semantic Scholar has no record of this paper; every key unresolved", paper_id)
        raw_refs = []
    candidates: list[Candidate] = []
    stubs = 0
    for ref in raw_refs:
        cand = Candidate.from_paper(ref.get("citedPaper") or {})
        if cand is None:
            stubs += 1
            continue
        candidates.append(cand)
    log.info("%s: S2 lists %d reference(s), %d linked to a record", paper_id, len(raw_refs), len(candidates))

    matcher = Matcher(
        fuzzy_threshold=fuzzy_threshold, year_tolerance=year_tolerance, author_check=author_check
    )
    matcher.match_by_id(items, candidates)

    # Ids the bibitems assert that S2's reference list didn't carry.
    extra = lookup_missing_ids(s2, items, set(matcher.matches))
    if extra:
        matcher.match_by_id(items, extra)
        candidates.extend(c for c in extra if c.paper_id not in {x.paper_id for x in candidates})

    matcher.match_by_title(items, candidates)
    matcher.match_by_search(items, s2)
    enrich_sparse_matches(s2, matcher.matches)

    # Assemble in bibitems order so every key is present, matched or not.
    entries = {item.key: (matcher.matches.get(item.key) or Match.unresolved()).to_dict() for item in items}
    by_method = {m: 0 for m in METHODS}
    for entry in entries.values():
        if entry["status"] == "matched":
            by_method[entry["match_method"]] += 1
    matched = sum(by_method.values())
    unresolved = [k for k, e in entries.items() if e["status"] != "matched"]

    result = {
        "paper": paper_id,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "fuzzy_threshold": fuzzy_threshold,
        "counts": {
            "total": len(items),
            "matched": matched,
            "unresolved": len(unresolved),
            "by_method": by_method,
        },
        "entries": entries,
    }
    out_path = paper_dir / "refs.json"
    out_path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    log.info(
        "%s: %d/%d matched (%s) → %s",
        paper_id,
        matched,
        len(items),
        ", ".join(f"{m}={n}" for m, n in by_method.items()),
        out_path,
    )
    if unresolved:
        log.info("%s: unresolved: %s", paper_id, ", ".join(unresolved))
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Match each paper's LaTeX cite keys to Semantic Scholar records.",
    )
    parser.add_argument("ids", type=Path, help="file listing the papers' arXiv ids")
    parser.add_argument("--clean", type=Path, default=Path("data/clean"), help="where bibitems.json lives")
    parser.add_argument(
        "--fuzzy-threshold",
        type=float,
        default=DEFAULT_FUZZY_THRESHOLD,
        help=f"minimum token_set_ratio (0-100) for a title match (default: {DEFAULT_FUZZY_THRESHOLD})",
    )
    parser.add_argument(
        "--year-tolerance",
        type=int,
        default=DEFAULT_YEAR_TOLERANCE,
        help=f"max |year difference| for a title match when both years are known (default: {DEFAULT_YEAR_TOLERANCE})",
    )
    parser.add_argument(
        "--no-author-check",
        action="store_true",
        help="don't require a shared author surname for a title match",
    )
    parser.add_argument("--cache", type=Path, default=DEFAULT_CACHE_DIR, help="S2 response cache")
    parser.add_argument("--refresh", action="store_true", help="ignore cached S2 responses")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)
    global args_ids_hint
    args_ids_hint = str(args.ids)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)-7s %(name)s: %(message)s",
    )
    # httpx logs every request at INFO; that's noise next to our own summary.
    logging.getLogger("httpx").setLevel(logging.WARNING)

    paper_ids = read_id_list(args.ids)
    if not paper_ids:
        log.error("no arXiv ids found in %s", args.ids)
        return 1

    failures = 0
    with S2Client(cache_dir=args.cache, refresh=args.refresh) as s2:
        for paper_id in paper_ids:
            paper_dir = args.clean / f"arXiv-{paper_id}"
            try:
                result = resolve_paper(
                    s2,
                    paper_id,
                    paper_dir,
                    args.fuzzy_threshold,
                    args.year_tolerance,
                    author_check=not args.no_author_check,
                )
            except S2Error as exc:
                log.error("%s: %s", paper_id, exc)
                failures += 1
                continue
            if result is None:
                failures += 1
        log.info("done: %d live S2 request(s), %d cache hit(s)", s2.live_requests, s2.cache_hits)
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
