"""A small Semantic Scholar Graph API client that caches on disk and tolerates 429s.

We run unauthenticated: S2's shared anonymous pool allows roughly one request
per second across *everyone* using it, so HTTP 429 is routine rather than
exceptional. Two things make working against it bearable, and both are
mandatory here rather than optional:

  * Every response is cached at `data/.cache/s2/<sha256-of-request>.json`, so
    re-running a script costs zero requests. Delete the file (or pass
    `refresh=True`) to fetch again.
  * Live requests are spaced `delay_s` apart, and a 429 or 5xx is retried
    with exponential backoff plus jitter, honouring `Retry-After` when S2
    sends one.

Only four endpoints are wrapped, because they are the four the pipeline needs:

    references(arxiv_id)   GET  /paper/arXiv:<id>/references   (paginated)
    papers(ids)            POST /paper/batch                   (<=500 ids/call)
    search_match(title)    GET  /paper/search/match            (one best hit or 404)
    author_papers(id)      GET  /author/<id>/papers            (paginated)

Set `S2_API_KEY` in the environment if you ever get a key; it is sent as
`x-api-key` and lifts the rate limit to a private pool.

Usage as a library:
    from s2 import S2Client
    with S2Client() as s2:
        refs = s2.references("1706.03762v7")
        found = s2.papers(["ArXiv:1409.0473", "DOI:10.1162/neco.1997.9.8.1735"])
        best = s2.search_match("End-to-end memory networks")

Usage as a smoke test:
    python data/s2.py 1706.03762v7
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import random
import re
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any

import httpx

log = logging.getLogger("s2")

API_BASE = "https://api.semanticscholar.org/graph/v1"
# Same identification style as ref.py: say who we are and why we're here.
USER_AGENT = "mainlogic-research/0.1 (FOLIO reference collection; contact via arXiv account)"
DEFAULT_CACHE_DIR = Path(__file__).resolve().parent / ".cache" / "s2"

# S2 documents ~1 req/s for anonymous callers; 1.1 s leaves a little slack.
DEFAULT_DELAY_S = 1.1
DEFAULT_TIMEOUT_S = 30.0
# Ten retries with a 2 s base and a 2 min cap adds up to ~10 minutes of
# patience, which is what an unauthenticated evening run actually needs.
DEFAULT_MAX_RETRIES = 10
BACKOFF_BASE_S = 2.0
BACKOFF_CAP_S = 120.0
RETRY_STATUSES = frozenset({429, 500, 502, 503, 504})

# Hard limits imposed by the API.
BATCH_LIMIT = 500
PAGE_LIMIT = 1000

# The fields the resolver needs to bridge a bibitem to a paper and its full text.
PAPER_FIELDS = "title,externalIds,openAccessPdf,year,authors"
# An author's whole output can run to a thousand records; leave the author
# lists out when all we want is to scan their ids.
AUTHOR_PAPER_FIELDS = "title,externalIds,openAccessPdf,year"

# `1705.03122v2` -> `1705.03122`. S2 stores arXiv ids without a version and its
# URL router rejects them with one.
ARXIV_VERSION_RE = re.compile(r"v\d+$")


def strip_version(arxiv_id: str) -> str:
    return ARXIV_VERSION_RE.sub("", arxiv_id.strip())


class S2Error(Exception):
    """Base class for anything that went wrong talking to Semantic Scholar."""


class S2NotFound(S2Error):
    """S2 has no record for this id (404). Cached, so the miss is free next time."""


class S2RetryExhausted(S2Error):
    """Gave up after `max_retries` 429/5xx responses."""


# --- cache -------------------------------------------------------------------


def cache_key(method: str, url: str, params: dict[str, Any] | None, body: Any) -> str:
    """A stable hash of the whole request, not just the URL.

    The batch endpoint is a POST whose meaning lives in the body, so hashing the
    URL alone would make every batch call collide.
    """
    canonical = json.dumps(
        {"method": method.upper(), "url": url, "params": params or {}, "body": body},
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


# --- client ------------------------------------------------------------------


@dataclass
class S2Client:
    cache_dir: Path = DEFAULT_CACHE_DIR
    delay_s: float = DEFAULT_DELAY_S
    max_retries: int = DEFAULT_MAX_RETRIES
    timeout_s: float = DEFAULT_TIMEOUT_S
    api_key: str | None = field(default_factory=lambda: os.environ.get("S2_API_KEY") or None)
    refresh: bool = False  # ignore the cache (still writes to it)

    # Counters so a run can report how much it actually cost.
    live_requests: int = field(default=0, init=False)
    cache_hits: int = field(default=0, init=False)

    _client: httpx.Client = field(init=False, repr=False)
    _last_request_at: float = field(default=0.0, init=False, repr=False)

    def __post_init__(self) -> None:
        self.cache_dir = Path(self.cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
        if self.api_key:
            headers["x-api-key"] = self.api_key
        self._client = httpx.Client(base_url=API_BASE, headers=headers, timeout=self.timeout_s)

    def __enter__(self) -> S2Client:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    # -- the single network path --------------------------------------------

    def request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        body: Any = None,
    ) -> Any:
        """Return the decoded JSON for a request, from cache when possible.

        404s are cached too and re-raised as `S2NotFound` on every call, since a
        paper S2 doesn't index today is unlikely to appear before the next run
        and asking again would burn a request from the shared pool.
        """
        key = cache_key(method, path, params, body)
        cache_file = self.cache_dir / f"{key}.json"

        if not self.refresh and cache_file.is_file():
            try:
                envelope = json.loads(cache_file.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                log.warning("unreadable cache file %s (%s); refetching", cache_file.name, exc)
            else:
                self.cache_hits += 1
                log.debug("cache hit %s %s", method, path)
                if envelope.get("status") == 404:
                    raise S2NotFound(f"{method} {path}: not found (cached)")
                return envelope["body"]

        status, payload = self._fetch(method, path, params, body)
        envelope = {
            "request": {"method": method.upper(), "path": path, "params": params, "body": body},
            "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "status": status,
            "body": payload,
        }
        # Write-then-rename so an interrupted run can't leave a half-written file
        # that the next run mistakes for a valid response.
        tmp = cache_file.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(envelope, ensure_ascii=False), encoding="utf-8")
        tmp.replace(cache_file)

        if status == 404:
            raise S2NotFound(f"{method} {path}: not found")
        return payload

    def _fetch(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None,
        body: Any,
    ) -> tuple[int, Any]:
        """Perform one live request with throttling and retries; returns (status, json)."""
        for attempt in range(self.max_retries + 1):
            self._throttle()
            self.live_requests += 1
            log.debug("live %s %s (attempt %d)", method, path, attempt + 1)
            try:
                response = self._client.request(method, path, params=params, json=body)
            except httpx.TransportError as exc:
                # Timeouts and connection resets are S2 being overloaded, not us
                # being wrong; treat them like a 503.
                wait = self._backoff(attempt, None)
                log.warning("%s %s: %s; retrying in %.1fs", method, path, type(exc).__name__, wait)
                time.sleep(wait)
                continue

            if response.status_code in RETRY_STATUSES:
                wait = self._backoff(attempt, response.headers.get("Retry-After"))
                log.warning(
                    "%s %s: HTTP %d; retrying in %.1fs (%d/%d)",
                    method,
                    path,
                    response.status_code,
                    wait,
                    attempt + 1,
                    self.max_retries,
                )
                time.sleep(wait)
                continue

            if response.status_code == 404:
                return 404, None
            if response.status_code >= 400:
                # A 400 means *we* sent something malformed; retrying won't help.
                raise S2Error(f"{method} {path}: HTTP {response.status_code}: {response.text[:200]}")
            return response.status_code, response.json()

        raise S2RetryExhausted(f"{method} {path}: gave up after {self.max_retries} retries")

    def _throttle(self) -> None:
        """Keep live requests at least `delay_s` apart."""
        elapsed = time.monotonic() - self._last_request_at
        if self.delay_s > 0 and elapsed < self.delay_s:
            time.sleep(self.delay_s - elapsed)
        self._last_request_at = time.monotonic()

    def _backoff(self, attempt: int, retry_after: str | None) -> float:
        """Seconds to wait before `attempt + 1`, preferring S2's own hint."""
        hinted = _parse_retry_after(retry_after)
        if hinted is not None:
            # Honour the server, plus a little jitter so many clients waking up
            # from the same 429 don't all hit it in the same second.
            return hinted + random.uniform(0.0, 1.0)
        base = min(BACKOFF_CAP_S, BACKOFF_BASE_S * (2**attempt))
        # Full jitter in [0.5x, 1.5x] — decorrelates clients without ever
        # collapsing the wait to zero.
        return base * random.uniform(0.5, 1.5)

    # -- endpoints ----------------------------------------------------------

    def references(self, arxiv_id: str, fields: str = PAPER_FIELDS) -> list[dict[str, Any]]:
        """Every reference S2 extracted from the paper, each as a `citedPaper` record.

        Returns the raw items (`{"citedPaper": {...}, ...}`) so callers can also
        see S2's reference "stubs" — entries it parsed from the bibliography but
        could not link to a known paper (their `paperId` is null).
        """
        path = f"/paper/arXiv:{strip_version(arxiv_id)}/references"
        items: list[dict[str, Any]] = []
        offset = 0
        while True:
            page = self.request(
                "GET", path, params={"fields": fields, "limit": PAGE_LIMIT, "offset": offset}
            )
            items.extend(page.get("data") or [])
            if page.get("next") is None:
                break
            offset = int(page["next"])
        return items

    def papers(self, ids: list[str], fields: str = PAPER_FIELDS) -> dict[str, dict[str, Any] | None]:
        """Look up many papers at once by id (`ArXiv:...`, `DOI:...`, `ACL:...`, or a paperId).

        One POST per 500 ids instead of one GET each. Ids S2 doesn't know map to
        None. Ids are deduplicated and sorted first so the same *set* of ids
        always hits the same cache file regardless of the order it arrived in.
        """
        unique = sorted(set(i.strip() for i in ids if i and i.strip()))
        found: dict[str, dict[str, Any] | None] = {}
        for start in range(0, len(unique), BATCH_LIMIT):
            chunk = unique[start : start + BATCH_LIMIT]
            result = self.request("POST", "/paper/batch", params={"fields": fields}, body={"ids": chunk})
            # S2 returns a list aligned with the ids it was given.
            for requested, paper in zip(chunk, result or []):
                found[requested] = paper
        return found

    def search_match(self, title: str, fields: str = PAPER_FIELDS) -> dict[str, Any]:
        """S2's single best title match for `title`; raises `S2NotFound` when nothing is close.

        Unlike the reference list, this returns a full paper record (external
        ids, open-access PDF), so it doubles as a way to reach a paper S2 only
        knew as an unlinked bibliography stub. S2 does its own similarity
        scoring and answers 404 rather than a poor match; whether the hit is
        *our* idea of a match is the caller's decision, not this method's.
        """
        result = self.request("GET", "/paper/search/match", params={"query": title, "fields": fields})
        data = (result or {}).get("data") or []
        if not data:
            raise S2NotFound(f"search/match {title!r}: empty result")
        return data[0]

    def author_papers(self, author_id: str, fields: str = AUTHOR_PAPER_FIELDS) -> list[dict[str, Any]]:
        """Every paper S2 attributes to an author id, as paper records.

        S2 offers no lookup by DBLP key, so this is how the resolver finds the
        sibling of a record S2 has split in two: the sibling shares an author,
        and the author's list is one (cached) request for most people.
        """
        path = f"/author/{author_id}/papers"
        items: list[dict[str, Any]] = []
        offset = 0
        while True:
            page = self.request(
                "GET", path, params={"fields": fields, "limit": PAGE_LIMIT, "offset": offset}
            )
            items.extend(page.get("data") or [])
            if page.get("next") is None:
                break
            offset = int(page["next"])
        return items


def _parse_retry_after(value: str | None) -> float | None:
    """`Retry-After` is either whole seconds or an HTTP date; support both."""
    if not value:
        return None
    value = value.strip()
    if value.isdigit():
        return float(value)
    try:
        when = parsedate_to_datetime(value)
    except (TypeError, ValueError):
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    return max(0.0, (when - datetime.now(timezone.utc)).total_seconds())


# --- smoke test --------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Fetch a paper's reference list from Semantic Scholar.")
    parser.add_argument("arxiv_id", help="e.g. 1706.03762v7")
    parser.add_argument("--cache", type=Path, default=DEFAULT_CACHE_DIR)
    parser.add_argument("--refresh", action="store_true", help="bypass the cache")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)-7s %(name)s: %(message)s",
    )

    with S2Client(cache_dir=args.cache, refresh=args.refresh) as s2:
        try:
            refs = s2.references(args.arxiv_id)
        except S2NotFound:
            log.error("%s: Semantic Scholar has no record of this paper", args.arxiv_id)
            return 1
        linked = [r for r in refs if (r.get("citedPaper") or {}).get("paperId")]
        log.info(
            "%s: %d reference(s), %d linked to an S2 paper (%d live request(s), %d cache hit(s))",
            args.arxiv_id,
            len(refs),
            len(linked),
            s2.live_requests,
            s2.cache_hits,
        )
        for ref in refs:
            paper = ref.get("citedPaper") or {}
            ext = paper.get("externalIds") or {}
            print(
                f"{paper.get('paperId') or '-':40}  {paper.get('year') or '----'}  "
                f"arXiv:{ext.get('ArXiv') or '-':<14} {paper.get('title')}"
            )
    return 0


if __name__ == "__main__":
    sys.exit(main())
