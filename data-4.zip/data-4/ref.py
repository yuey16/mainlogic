"""Fetch the arXiv sources a paper cites, flatten them, and file them alongside it.

For every paper already produced by `clean.py`, this reads its `refs.bib`, pulls
out the arXiv ids of the works it cites, downloads each one's LaTeX source,
flattens it with `clean.py`, and writes:

    data/clean/arXiv-<paper>/references/<ref-id>.tex
    data/clean/arXiv-<paper>/references/manifest.json

Downloaded tarballs are unpacked into `data/raw/arXiv-<ref-id>/` and reused, so
re-running costs nothing and arXiv is not asked twice for the same source.

arXiv asks automated clients to identify themselves and to leave a few seconds
between requests; this stays sequential and sleeps `--delay` seconds (default 3)
between downloads. Please don't crank it down.

Usage:
    python data/ref.py papers.txt
    python data/ref.py papers.txt --limit 10 --delay 3
"""

from __future__ import annotations

import argparse
import gzip
import io
import json
import logging
import sys
import tarfile
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import httpx  # noqa: E402

from clean import (  # noqa: E402
    ARXIV_MENTION_RE,
    clean_source,
    normalise_id,
    raw_dir_for,
    read_id_list,
)

log = logging.getLogger("ref")

EPRINT_URL = "https://arxiv.org/e-print/{id}"
USER_AGENT = "mainlogic-research/0.1 (FOLIO reference collection; contact via arXiv account)"
DEFAULT_DELAY_S = 3.0


# --- pulling reference ids out of a bibliography -----------------------------


def extract_reference_ids(bib_text: str, exclude: str = "") -> list[str]:
    """Every arXiv id cited in a .bib, in first-seen order, minus the paper itself."""
    base_exclude = exclude.split("v")[0] if exclude else ""
    ids: list[str] = []
    for match in ARXIV_MENTION_RE.finditer(bib_text):
        got = normalise_id(match.group(1))
        if not got or got in ids:
            continue
        if base_exclude and got.split("v")[0] == base_exclude:
            continue  # a paper citing itself
        ids.append(got)
    return ids


# --- downloading and unpacking ----------------------------------------------


class SourceUnavailable(Exception):
    """arXiv has no LaTeX source for this id (withdrawn, or PDF-only)."""


def unpack(payload: bytes, dest: Path) -> None:
    """Write an e-print payload into `dest`, whatever shape arXiv sent it in.

    It can be a gzipped tar, a single gzipped .tex, or a PDF when the author
    never uploaded source.
    """
    if payload[:4] == b"%PDF":
        raise SourceUnavailable("arXiv returned a PDF — no LaTeX source published")

    dest.mkdir(parents=True, exist_ok=True)
    try:
        with tarfile.open(fileobj=io.BytesIO(payload)) as tar:
            # filter="data" refuses absolute paths and traversal outside dest.
            tar.extractall(dest, filter="data")
        return
    except tarfile.ReadError:
        pass  # not a tarball — try a bare gzipped file

    try:
        text = gzip.decompress(payload)
    except (OSError, EOFError) as exc:
        raise SourceUnavailable(f"unrecognised payload ({len(payload)} bytes)") from exc
    if text[:4] == b"%PDF":
        raise SourceUnavailable("arXiv returned a PDF — no LaTeX source published")
    (dest / "main.tex").write_bytes(text)


def download_source(client: httpx.Client, arxiv_id: str, raw_root: Path) -> Path:
    """Return the unpacked source dir for `arxiv_id`, downloading if needed."""
    existing = raw_dir_for(raw_root, arxiv_id)
    if existing is not None and any(existing.rglob("*.tex")):
        log.debug("%s: already in %s", arxiv_id, existing)
        return existing

    url = EPRINT_URL.format(id=arxiv_id)
    log.info("downloading %s", url)
    response = client.get(url, follow_redirects=True)
    if response.status_code == 404:
        raise SourceUnavailable("404 from arXiv (withdrawn or bad id)")
    response.raise_for_status()

    dest = raw_root / f"arXiv-{arxiv_id}"
    try:
        unpack(response.content, dest)
    except SourceUnavailable:
        # Don't leave an empty shell behind to confuse the cache check.
        if dest.is_dir() and not any(dest.iterdir()):
            dest.rmdir()
        raise
    return dest


# --- per-paper driving -------------------------------------------------------


@dataclass
class RefOutcome:
    arxiv_id: str
    status: str  # written | cached | unavailable | failed
    path: str | None = None
    detail: str | None = None


@dataclass
class PaperOutcome:
    paper: str
    cited_arxiv_ids: int = 0
    written: int = 0
    skipped: int = 0
    references: list[RefOutcome] = field(default_factory=list)


def process_paper(
    client: httpx.Client,
    paper_id: str,
    clean_root: Path,
    raw_root: Path,
    delay_s: float,
    limit: int | None,
    refresh: bool,
) -> PaperOutcome:
    paper_dir = clean_root / f"arXiv-{paper_id}"
    bib = paper_dir / "refs.bib"
    outcome = PaperOutcome(paper=paper_id)

    if not bib.is_file():
        log.error("%s: no refs.bib in %s — run clean.py first", paper_id, paper_dir)
        return outcome

    ref_ids = extract_reference_ids(bib.read_text(encoding="utf-8"), exclude=paper_id)
    if limit is not None:
        ref_ids = ref_ids[:limit]
    outcome.cited_arxiv_ids = len(ref_ids)
    log.info("%s: %d cited arXiv id(s)", paper_id, len(ref_ids))

    refs_dir = paper_dir / "references"
    refs_dir.mkdir(parents=True, exist_ok=True)

    for index, ref_id in enumerate(ref_ids, start=1):
        target = refs_dir / f"arXiv-{ref_id}.tex"
        if target.is_file() and not refresh:
            log.debug("%s: already have %s", paper_id, target.name)
            outcome.references.append(RefOutcome(ref_id, "cached", str(target)))
            outcome.skipped += 1
            continue

        try:
            src = download_source(client, ref_id, raw_root)
        except SourceUnavailable as exc:
            log.warning("%s: %s", ref_id, exc)
            outcome.references.append(RefOutcome(ref_id, "unavailable", detail=str(exc)))
            outcome.skipped += 1
            _sleep(delay_s, index, len(ref_ids))
            continue
        except Exception as exc:
            log.error("%s: download failed: %s: %s", ref_id, type(exc).__name__, exc)
            outcome.references.append(
                RefOutcome(ref_id, "failed", detail=f"{type(exc).__name__}: {exc}")
            )
            outcome.skipped += 1
            _sleep(delay_s, index, len(ref_ids))
            continue

        # Flatten into a scratch dir, then keep just the .tex the caller asked for.
        try:
            staged = clean_source(src, refs_dir / f".staging-{ref_id}", ref_id)
            target.write_text(staged.main_tex.read_text(encoding="utf-8"), encoding="utf-8")
            _remove_tree(staged.out_dir)
        except Exception as exc:
            log.error("%s: clean failed: %s: %s", ref_id, type(exc).__name__, exc)
            outcome.references.append(
                RefOutcome(ref_id, "failed", detail=f"{type(exc).__name__}: {exc}")
            )
            outcome.skipped += 1
            _sleep(delay_s, index, len(ref_ids))
            continue

        log.info("%s → %s", ref_id, target)
        outcome.references.append(RefOutcome(ref_id, "written", str(target)))
        outcome.written += 1
        _sleep(delay_s, index, len(ref_ids))

    (refs_dir / "manifest.json").write_text(
        json.dumps(asdict(outcome), indent=2), encoding="utf-8"
    )
    return outcome


def _sleep(delay_s: float, index: int, total: int) -> None:
    """Be polite to arXiv, but don't wait after the final item."""
    if delay_s > 0 and index < total:
        time.sleep(delay_s)


def _remove_tree(path: Path) -> None:
    import shutil

    shutil.rmtree(path, ignore_errors=True)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Download, flatten, and file the arXiv sources a paper cites.",
    )
    parser.add_argument("ids", type=Path, help="file listing the papers' arXiv ids")
    parser.add_argument("--clean", type=Path, default=Path("data/clean"))
    parser.add_argument("--raw", type=Path, default=Path("data/raw"))
    parser.add_argument(
        "--delay",
        type=float,
        default=DEFAULT_DELAY_S,
        help=f"seconds between arXiv downloads (default: {DEFAULT_DELAY_S})",
    )
    parser.add_argument("--limit", type=int, help="only the first N references per paper")
    parser.add_argument("--refresh", action="store_true", help="re-fetch references already written")
    parser.add_argument("--timeout", type=float, default=60.0)
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)-7s %(name)s: %(message)s",
    )

    paper_ids = read_id_list(args.ids)
    if not paper_ids:
        log.error("no arXiv ids found in %s", args.ids)
        return 1

    totals = PaperOutcome(paper="ALL")
    with httpx.Client(headers={"User-Agent": USER_AGENT}, timeout=args.timeout) as client:
        for paper_id in paper_ids:
            outcome = process_paper(
                client,
                paper_id,
                args.clean,
                args.raw,
                args.delay,
                args.limit,
                args.refresh,
            )
            totals.cited_arxiv_ids += outcome.cited_arxiv_ids
            totals.written += outcome.written
            totals.skipped += outcome.skipped

    log.info(
        "done: %d reference(s) written, %d skipped, across %d paper(s)",
        totals.written,
        totals.skipped,
        len(paper_ids),
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
