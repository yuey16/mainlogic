# MainLogic: data pipeline

End to end: arXiv sources → anchor claims in `claims.yaml` (screened by `filter.py`, then read by a person) → six-cell
augmentation → triage in `claims.yaml` → `mainlogic.jsonl` → human sampled audit (a per-core `human_audit` flag)
→ evaluation (`data/run.py`, then `eval/`).

Current: **108 cores / 812 rows / 27 papers** — 648 six-cell rows plus the 164-row `P=` control

---

## 1. Row schema

One JSON object per line in `data/final/mainlogic.jsonl`. A *core* is six rows sharing `anchor_id`.

| field | type | meaning |
|---|---|---|
| `id` | str | `<anchor_id>/<cell>`, unique |
| `anchor_id` | str | `<paper>:<hash>` (or `<paper>:<n>` for the eight directed-edit cores): the core this row belongs to, and the `claims.yaml` id of its claim |
| `cell` | str | `P+C+ P+C- P-C+ P-C- P0C+ P0C-`, plus `P=C+ P=C-` on cores that carry the control |
| `paper` | str | arXiv id of the **citing** paper the claim was taken from |
| `cite_keys` / `premise_keys` | list[str] | LaTeX cite keys of the works, aligned to `premise` |
| `no_premise` | int | `len(premise)` — 1 doc ×87 cores, 2 ×15, 3 ×5, 4 ×1 |
| `premise` | list[str] | P: full text of every cited work, in citation order. `P+` as published, `P-` rewritten, `P0` cut |
| `conclusion` | str | C: the citing sentence rendered as plain text (C+), or its contrastive rewrite (C−) |
| `relation` | str | **gold label**: `supported` \| `contradicted` \| `uncertain` |
| `route` | str | **`derived`** = C− must be reasoned out of the edited premises; **`stated`** = some edited sentence says it outright |
| `ref_statements` | list[obj] | raw located passages: `{premise_index, quote, char_start, char_end, label, role, source}`. `role` ∈ `assertion` (states the claim) \| `premise` (claim follows by reasoning). Offsets are remapped for `P-`; empty for `P0` (those spans are what was cut) |
| `human_audit` | str | the blinded human audit's verdict on this row's **core**: `verified` (audited, every audited row passed), `failed` (an audited row failed), `unaudited`. A flag only: no row is ever dropped for it |

Six-cell design: `(P+,C+)` supported, `(P+,C−)` contradicted, `(P−,C+)` contradicted, `(P−,C−)` supported,
`(P0,C+)` uncertain, `(P0,C−)` uncertain. A model answering from memory fails the `P-` and `P0` cells.

`P=` is a seventh and eighth cell on 82 of the 108 cores: the same labels as the `P+` row, on premises
with as much text deleted as `P0` deleted, but not the evidence. It is the control that distinguishes
"recognises the decisive evidence is gone" from "answers undetermined whenever text was deleted".

---

## 2. Acquisition (deterministic, no LLM)

`./ingest.sh` at the repo root runs the four stages below for every id in `data/papers.txt`, skipping
work already done.

```
data/clean.py papers.txt     # arXiv source tarball -> main.tex (inputs inlined, comments stripped),
                             #   refs.bib, bibitems.json
data/resolve.py              # each \cite key -> Semantic Scholar record, cascade:
                             #   arxiv id > doi > fuzzy title(+year,+author) -> refs.json
data/s2.py                   # cached, rate-limited S2 client
data/ref.py papers.txt       # cited arXiv sources, flattened
data/fulltext.py             # cited full text, open access only, first hit wins:
                             #   arxiv HTML/ar5iv > arxiv LaTeX > ACL > PubMed Central >
                             #   S2 open-access PDF > Unpaywall > OpenAlex > free venue
                             #   -> fulltext.json, tier recorded
```
Output per paper: `data/clean/arXiv-<id>/{main.tex, refs.bib, bibitems.json, refs.json, fulltext.json,
references/*.md}`. Downloads are cached in `data/raw/` (~1.6 GB, not committed; re-created by the
commands above).
A cite key with no open-access full text is unusable and its claims are refused at save time.

---

## 3. Anchor claims → `data/claims.yaml`

Two paths, one store. An entry is `{paper, line (verbatim from main.tex), note}`; `claims.py` refuses a
line not found verbatim, without a `\cite`, whose cited works lack full text, or already saved. C+ is
rendered deterministically from `line` (citations printed as the paper prints them, acronyms expanded).

**Every claim is standalone**: one sentence, interpretable with nothing around it. Path A keeps only
`outcome == standalone`; path B requires it under (b) of the brief. No row carries a context paragraph.

Both paths rest on the same two prompt-engineered backbones: **citation-function screening**
(SciCite-style — keep only citations offered as *evidence*) and **sentence decontextualisation**
(keep only sentences interpretable with no surrounding text).

### Path A — screening every citing sentence (`data/filter.py`)

One script, per citing paper, over every sentence of `main.tex` that carries a `\cite`:

1. **Code checks** (no model): verbatim in `main.tex`, every cited work has full text, not glued to a
   heading/float/list marker, at most 6 cited works, no vague/existence phrasing (`VAGUE` regex), not
   already in `claims.yaml` (kept or dropped).
2. **A.1 Citation function** (model): only `background` survives.
3. **A.2 Decontextualisation** (model, `background` lines only): only `standalone` survives.

Survivors are appended to `claims.yaml` with a note recording both verdicts, e.g.
`note: "filter: background, standalone - <reason>"`. The model is `gpt-5.6-sol`, a construction
model that is never benchmarked; every call is cached in `data/.cache/filter/`.

```
python data/filter.py --no-model                 # code checks only: what would reach the model
python data/filter.py --paper 2205.14135v2       # dry run on one paper
python data/filter.py --write                    # every paper in papers.txt -> claims.yaml
```

**A.1 Citation function** — model sees the sentence with `[CITATION n]` markers, cited titles/years, and the
citing paper's year. Never the cited full text.

```
You classify the FUNCTION of the citations in a scientific sentence. Each citation's position is marked [CITATION n]. You are also given each cited work's title and year, and the year of the paper the sentence comes from. Answer with exactly one of: background, partial_detail, method, comparison, entity, or partial_claim.

background - the cited works are offered as EVIDENCE for what the sentence claims, and the whole
  claim is something works with those titles and years could themselves state, show or report -
  including a description of a cited work's own method, results or details.
  e.g. "Recurrent networks have been firmly established as state of the art approaches [CITATION 1]"
  e.g. "ResNet [CITATION 1] adds identity shortcuts between stacked layers"
  e.g. "The base BERT model [CITATION 1] has 12 layers and a hidden size of 768"
  NOTE: words like "state of the art", "faster than" or "speed up" appear in background
  sentences describing PRIOR WORK just as often as in result comparisons. Judge the
  rhetorical role, not the vocabulary.

method - the sentence states what THE AUTHORS did, used, followed or built on. It is
  autobiographical; the cited work is the thing adopted, not evidence for a claim.
  e.g. "We use the Adam optimizer [CITATION 1]"
  e.g. "In row (E) we replace our positional encoding with learned embeddings [CITATION 1]"

comparison - the sentence reports how the authors' OWN results compare against the cited
  work or a baseline it defines. The evidence for the comparison lives in the citing paper.
  e.g. "We train BERT-large 15% faster than the record in MLPerf 1.1 [CITATION 1]"

entity - a citation only IDENTIFIES something the sentence names in passing, while what the
  sentence claims is something the cited work does not itself report: the citing authors' own
  findings, or a later development or trend. Compare the years: a work from YEAR cannot report
  anything that happened after YEAR.
  e.g. "In decoders that use beam search [CITATION 1], our cache cuts memory use by 40%"
  e.g. "Convolutional networks have since become ubiquitous in computer vision [CITATION 1]"
       where [CITATION 1] is a 1998 paper
  e.g. "Attention is now used by most large language models [CITATION 1]" where the work is from 2015

The last two are for sentences the cited works back only in PART - another part says something
none of them could support (judging by their titles and years). Use them only when that part is
real content, not a detail the cited works plausibly cover. First find the sentence's MAIN claim:
what it would still assert with every aside, qualifier and explanation removed.

partial_detail - the cited works back the MAIN claim. What they cannot back is secondary: an
  aside or parenthetical, a qualifier, a suggested cause or explanation, a definition or framing
  that sets up the claim, or a generalisation of the cited examples ("many ...", "typically").
  Removing that part leaves a background sentence.
  e.g. "Gradient clipping stabilises recurrent network training [CITATION 1] (though it adds a
       hyperparameter that is hard to tune)"
  e.g. "Several systems route each token to a few experts, such as Switch [CITATION 1]"

partial_claim - the MAIN claim, or a second claim of equal weight, is something none of the cited
  works could support - often a claim about particular systems, the field, or the citing authors'
  own findings - and the citation backs only a supporting clause.
  e.g. "Existing serving systems waste memory because they allocate contiguously, as most
       frameworks require contiguous tensors [CITATION 1]" where [CITATION 1] is a deep learning
       framework paper
  e.g. "Our model underperforms on long inputs, likely because attention cost grows quadratically
       [CITATION 1]"

Ask: could a reader verify the WHOLE claim by reading only works with these titles and years?
If yes it is background.

Reply with JSON only:
{"function": "background|partial_detail|method|comparison|entity|partial_claim"}
```

**A.2 Decontextualisation** — keep only sentences that stand on their own. The model sees the TARGET
sentence, up to three sentences before it in its paragraph, and the cited titles/years; only
`standalone` is kept.

```
You prepare sentences from a research paper for a claim-verification benchmark. Each TARGET sentence cites other works, marked [CITATION n]; you get each cited work's title and year, and the source paper's year. A reader will later check the TARGET against the full text of its cited works, and never sees anything else from the source paper. Keep only sentences that stand on their own.

Answer "standalone" only if the target's claim is fully understandable on its own. It is NOT standalone
if it contains any of these:
  * a pronoun, demonstrative or definite phrase pointing at earlier text ("this", "these", "such",
    "they", "their", "the X" where X was introduced earlier, "the two mechanisms"). A target that
    BEGINS with This/These/Those/It/They/Such/Its/Their, or with "The <noun>" naming something the
    target does not itself introduce, is NEVER standalone
  * a symbol, variable or acronym the sentence does not itself define - EXCEPT
      - names and acronyms of the TARGET's own cited works (e.g. "IBC" when an IBC paper is cited),
        which the cited works themselves define
      - standard acronyms any reader in the field knows without being told (e.g. GPU, CPU, RNN, CNN,
        LSTM, MLP, LLM, NLP, RL, SGD, KL); an acronym the source paper itself introduces (e.g. "HBM"
        for its own memory term) still needs context
  * a continuation opening ("where ...", "which ...", "Doing so ...", "Other approaches ...")
  * a scope the surrounding text sets (a task, benchmark or setting) without which it reads as a
    different, broader claim
A leading connective such as "However," on its own does not count.

Answer "self" if the target reports, describes or announces what THIS paper and its authors did, found,
built, measured, defined, chose to call something, or will do next - even when it cites other works,
and even when the sentence is otherwise self-contained. Anything in the first person ("We have found
...", "we denote ...", "Our work ...", "we compare our model to ...") is self, and so is pure
signposting that asserts nothing ("We refer the reader to ... for details", "Before summarizing, we
make a few remarks").
  Two things are NOT self:
    * a statement the source paper attributes to a cited work
    * "we" meaning the research community or the field, in a claim about the state of knowledge
      rather than about this paper ("we do not yet know whether ...", "the best hardware we have now
      has error rates above ...")

Otherwise answer "needs_context".

Reply with JSON only:
{"outcome": "standalone|self|needs_context", "reason": "<short>"}
```

The `self` reject is deliberate: a first-person result sentence is grammatically self-contained, so
without it such sentences would pass as standalone.

### Path B — direct extraction

Same quality bar, applied per paper instead of per corpus.

- **`data/human.py`** — a person pastes a line; the verbatim/`\cite`/full-text checks run instantly.
- **`data/llm.py`** — an agent walks every `\cite` in one `main.tex` under the versioned brief
  **`data/claim_filter.md`** (the full prompt; `python data/llm.py brief` prints it), and saves lines with
  `claims.py put`. Agents write only through that CLI — never `claims.yaml` by hand, never the build.

The brief's bar: **(a)** a real claim the cited work supports, every detail checked against the cited text;
**(b)** standalone; **(c)** memory prior `high`/`medium` — a strong model would state it confidently from
memory, so the rewritten document has something to fight; **(d)** preferred: C follows by *reasoning*
(combining sections, converting units, inverting a relation, a condition/quantifier) rather than lookup;
**(e)** the proposition is stated in a limited, locatable set of places, so it can be rewritten consistently
— not the paper's identity. Required note: `prior: high|medium|low — …; reasoning: lookup|inference — …`.

`claims.py` and `filter.py` share their LaTeX, sentence and citation parsing from `data/latex.py`.

### Human claim review — in `claims.yaml` itself

Every entry, from either path, is read by a person against its cited works before augmentation,
under a fixed checklist: a claim at all (not signposting, a definition or a table fragment); a
background claim the cited works can establish, not the citing authors' own work; decontextualised;
the cited works establish it; a contrary version can be built. A claim that fails is marked in place,

```yaml
- paper: 2205.14135v2
  line: |-
    ...
  note: "filter: background, standalone - ..."
  drop: true            # reviewer: vague_generalisation
```

and `drop: true` keeps it out of augmentation and export without deleting it (after augmentation the same
file carries `keep: true` for flagged cores a person has cleared, see section 5), so the filter never
proposes it again. `python data/claims.py show <id>` prints C+ and the cited works for one entry;
`python data/claims.py check` validates the file.

---

## 4. Augmentation → `data/built/*.json` (`data/augment.py`)

Three stages. **sol** (`gpt-5.6-sol`) is the only model that reads whole documents; **astra**
(`gpt-6-astra`) sees only the returned passages plus 160-char context windows. sol is never
benchmarked (`eval/process.py` refuses its runs); astra is benchmarked, with the caveat that it planned
the edits. All calls are cached in `data/.cache/build/` by sha256 of (model, system, user), so a
rebuild with a warm cache makes no API calls.

```
python data/augment.py                    # every active claim not yet built
python data/augment.py --only <id> --rebuild --workers 3
```

Eight cores (seven from BERT, one from ViT) predate `augment.py`: their C− and P−/P0 edits were
written by directed editing and each edit set was audited in full. They sit in `data/built/` like
every other core, with `method: directed-edit`, and their `claims.yaml` entries pin the ids their rows
already carry (`id: 1810.04805:15`).

### 4.1 RELATED — sol, one pass per document (cached in `data/related/`)
Recall, not judgement. Quotes are located verbatim in the source; unlocatable quotes are dropped.

```
You are given ONE DOCUMENT (a paper cited by a later work) and a CLAIM that later work makes about it. Quote every passage of the document that bears on the claim.

Include:
- statements of the claim or any part of it, and every restatement (abstract, introduction, method,
  results, conclusion count separately);
- the settings, definitions, values, rules and results the claim depends on, even when they do not
  mention it: the claim may follow from them by a step of reasoning;
- MEASUREMENTS whose numbers would have to read differently if the claim were false - a table row, a
  reported figure, an equation, a caption;
- passages that say otherwise.

Leave out text that merely shares vocabulary or topic. Err towards including a passage you are
unsure about: a later step decides what matters, and a passage you omit can never be considered.

Copy each quote VERBATIM, character for character, including LaTeX and markdown: the shortest span
that makes its point, never text joined from two places.

Reply with JSON only:
{"passages": [{"quote": "..."}]}
```

### 4.2 PLAN — astra, passages only
Labels each passage, writes C−, and rewrites the minimum set of passages. This is where difficulty is
made: prefer a proposition the documents **imply but never state**, so the answer cannot be found by
sentence matching.

```
You are building one test item for a benchmark of whether a model judges a claim from the documents it reads or from what it remembers. You are given a CLAIM a paper makes about the works it cites, and numbered PASSAGES quoted from those works (each with a little surrounding text). You do not see the rest of the documents; work from these passages.

Do three things.

1. Label every passage: "assertion" (it states the claim or part of it), "premise" (the claim follows
   from it by a step of reasoning - a setting, value, rule, definition, measurement, comparison), or
   "unrelated".

2. Choose the target proposition and write claim_minus, the contrasting claim. Change one proposition;
   keep every other word of the claim. It must be CONTRARY: a reader who accepts the documents must
   reject it. Prefer, in this order:
   a. A proposition the documents IMPLY but never state - carried by "premise" passages. Then change a
      premise and leave the consequence unwritten, so a reader has to redo the reasoning. An item whose
      answer can be found by matching a sentence tests matching, not reasoning.
   b. A proposition a knowledgeable reader is confident about, so that claim_minus looks wrong from the
      outside and only the documents say otherwise.
   c. The smallest set of passages that must change.
   Rules: never a bare "not"; PREFER a target that no single sentence states outright, and prefer not
   to leave a sentence that simply announces claim_minus - but if the claim's only real proposition is
   stated in the documents, target it anyway and rewrite that sentence: a stated item is better than
   no item; do not target a value inside an "up to"/"at least"/"more than"
   frame (a different number there is not contrary); avoid quantifier flips to universal negatives
   ("no work has ..."), which a single surviving mention refutes; keep hedging, scope and style.

3. Rewrite the passages that must change so the documents establish claim_minus:
   - TOUCH AS LITTLE AS POSSIBLE. Change a passage ONLY IF leaving it as it is would make claim_minus
     false, or would leave the documents contradicting themselves in a way a reader would notice. A
     passage that merely mentions the topic, or bears on some other part of the claim, stays exactly
     as it is. Fewer, smaller edits are better: the reader should have to work out the consequence,
     not be told it repeatedly.
   - IN PLACE. One passage in, one passage out: the same number of sentences, similar length, the same
     register, wording, LaTeX and markdown. Never add a sentence, an explanation or a justification -
     the documents must state the new proposition no more plainly than they stated the old one.
   - CONSISTENT. When a number changes, change the numbers that follow from it so the arithmetic holds.
   - Each rewritten passage must read as something that paper could have written.

Also report "route": "derived" if a reader must reason from the edited premises to see claim_minus,
"stated" if some edited passage now says it outright.

entails: false only if the passages plainly do not back the claim at all (these claims were taken from
published papers, so an inference step or a paraphrase is normal). contradicted: does the ORIGINAL text
of these passages rule out claim_minus? Be strict here. impossible: why, if no coherent contrary exists.

Reply with JSON only:
{"labels": [{"index": 1, "role": "assertion|premise|unrelated"}],
 "claim_minus": "...", "route": "derived|stated", "type": "<value|entity|polarity|comparative|quantifier|modal>",
 "rationale": "<one sentence: what changes and how a reader reaches claim_minus from it>",
 "edits": [{"index": 1, "text": "<the passage exactly as it should now read>"}],
 "entails": true, "contradicted": true, "impossible": null}
```

**Anchor retry** (`data/verify.py:literal_anchor`): if a single sentence contains the phrase distinguishing
C+ from C− *and* ≥60% of the claim's content words, the item is settleable by matching. One retry:

```
A sentence in the documents states one of the claims outright, so the item can be settled by matching rather than by reasoning: {why} Pick a different target proposition - one the documents imply but never state - or rewrite that passage so it reports the ingredient rather than the conclusion. Reply in the same JSON format.
```

**Edit discipline, enforced in code** (`in_place`): no added sentence, and `len(new) ≤ 1.3·len(old) + 30`.
A rewrite that fails is rejected, not applied.

### 4.3 CHECK — sol, one pass per document over P−
Deliberately light: only blatant leftovers. `entails`/`contradicted` are recorded as flags, not gates —
the only hard failures are `impossible`, no passage changed, and C− == C+.

```
You are given ONE DOCUMENT from a set of papers that was EDITED so that the papers back a CONTRASTING CLAIM instead of an ORIGINAL CLAIM. Report only what would STRIKE a reader as flatly inconsistent with the contrasting claim: a passage that still states the original value, direction or property outright, or a number that plainly contradicts the edited ones.

This is a light check, not a review. Do NOT report:
- passages about some other part of the claim, or about the topic in general;
- indirect or arguable tension, background, motivation, related work;
- anything that merely shares vocabulary, or that a careful reader could reconcile.
If you find yourself explaining why something is a problem, it is not one: leave it out.

An empty list is the expected answer. Report at most 5, the most blatant first, each quoted VERBATIM.

Reply with JSON only:
{"conflicts": [{"quote": "<verbatim>", "why": "<the words that still state the original>"}]}
```

### 4.4 REPAIR — astra, one round (`data/verify.py`)
Flagged passages go back for a single in-place rewrite; results still pass `in_place`. Survivors are
recorded in `left_minus` and the core is marked `unverified` (kept, not dropped).

```
A research paper was edited so that it supports a CONTRASTING CLAIM instead of an ORIGINAL CLAIM. A check found PASSAGES the edit missed: they still state the original. Rewrite each one so the paper consistently supports the contrasting claim. Change only what that requires; keep wording, LaTeX and markdown; stay consistent with the rewrites ALREADY MADE; each rewrite must read as something that paper could have written. Return a passage unchanged if it does not in fact conflict.

Reply with JSON only:
{"rewrites": [{"index": <n>, "text": "<the passage exactly as it should now read>"}]}
```

### 4.5 P0
`P0` = every related **assertion** and **premise** span cut from the documents (no LLM, no scan).
Standard is **majority coverage**: enough support removed that neither claim is settled — not erasure
of the topic.

---

## 4b. The `P=` control (`data/preserve.py`, deterministic, no LLM)

`P0` on its own cannot distinguish *"the decisive evidence is gone"* from *"text was deleted"*. `P=`
is the matched control — the `P^redundant` of the RQ2 necessity contrast:

```
R(P^critical,  C+) = undetermined     <- P0, the evidence removed
R(P^redundant, C+) = supported        <- P=, as much text removed, but not the evidence
```

**Matching is the design.** For every span `P0` cut, `P=` removes a comparable volume of non-evidence
text from the same document at a similar relative position. Selection is against one global budget,
because matching each cut locally overshoots by up to a sentence and compounds. Achieved volume is
within ±9% of `P0` on every core (median 1.01×), and `|P= − P0|` length differs by a median of **0.0%**
of the document, so length cannot act as a cue for either label.

Candidates are sentences ≥40 characters overlapping no located span. Guards, all in code: never touch
evidence; the volume must land within 10% of `P0`'s; and every term the claim needs must still appear
somewhere (a deletion that drops the only mention of a referent is refused). Evidence offsets are
remapped so `ref_statements` stay exact.

**Validity rests on the same assumption `P0` already rests on** — that the located evidence set is
complete. Only spans no located statement overlaps are deleted, so if those statements establish C+,
they still do afterwards. `P=` is therefore no more fragile than the cells it controls for, which is a
weaker claim than "this rewrite preserved the meaning".

**82 of 108 cores build.** 22 are refused by the interpretability guard, 4 because `P0` removed
45–61% of a short document and there is not that much non-evidence text to match.

```
python data/preserve.py            # dry run: what builds, and why a core is skipped
python data/preserve.py --write    # -> data/preserved/<claim id>.json
python data/export.py              # folds them into data/final/mainlogic.jsonl
```

---

## 5. Triage in `claims.yaml` → `data/final/mainlogic.jsonl` (`data/export.py`)

There is no separate audit file: triage is a person reading `claims.yaml` and the built cores, and every
decision is recorded on the claim's own entry or in its built record.

- A core whose leftover check (4.3) passed is `verified` and is exported unless its claim is `drop: true`.
- A core the check flagged is `unverified`. A person reads the flagged passages against C−: if they do
  not in fact contradict it, the claim gets `keep: true` and the reason in its `note`, and the core is
  exported; otherwise it stays out (or its claim is dropped).
- A small fix to a core (a stale number or label left in P−) is applied to its built record directly and
  recorded there under `hand_fixes` (the note and the exact `old` → `new` edits).

The checklist for reading a core: does any surviving passage in P− still support C+; does anything
left in P0 settle either claim; is C− genuinely contrary, not a bare "not"; is C− no more explicit in P−
than C+ was in P+. Currently 4 flagged cores are kept (`keep: true`) and 2 carry `hand_fixes`.

```
python data/export.py
# data/final/mainlogic.jsonl = every verified core of a claim in claims.yaml without drop
#   + every unverified core whose claim has keep: true
#   + the P= control for the cores above
```

---

## 6. Human sampled audit → `human_audit` flag (`data/human_audit.py`)

No LLM. Samples N rows by hash of `(seed, id)` — same seed, same sample, so two auditors are comparable
— and runs each through five steps in a local browser page:

1. **Answer it blind.** Premises + conclusion only; the cell, the gold label, the other claim and the
   review cards are not in the page (they are served by `/api/label` after the answer). Optional toggle
   highlights `ref_statements`; whether it was used is recorded.
2. **Reveal.** Right/wrong, recorded either way.
3. **Claim** — good / bad + reason.
4. **Negation** (C− rows) — `subtle` (reads naturally, only the documents settle it) / `easy` (spottable
   without reading) / `broken`.
5. **Coverage** (P− and P0 rows) — both claims and the gold label shown; flag any passage that fights the
   label (stored verbatim).

**The verdict is per core.** Auditing any row reviews its whole core. A core is `verified` if every
audited row in it passed, and `failed` if any audited row found a bad claim, an `easy`/`broken`
negation, or `competing` evidence. `data/export.py` writes the verdict onto every row of the core as
`human_audit: verified | failed | unaudited`. **It is a flag, not a filter: nothing is dropped from
`mainlogic.jsonl`.** Current state: 48 rows audited across 40 cores: 34 verified (258 rows), 6 failed (42 rows).

Records: `data/audit/<reviewer>.jsonl`, one line per row per auditor. The released records are
anonymised as `reviewer-a`, `reviewer-b` and `reviewer-c`; pass `--reviewer` with a pseudonym, since
the records are released (without it they go to `reviewer`).

```
uv run python data/human_audit.py --reviewer reviewer-a --n 10 --seed 0
uv run python data/human_audit.py --reviewer reviewer-a --new --n 20   # 20 more, one row from each of 20 cores nobody has audited
uv run python data/human_audit.py report --write   # -> data/final/mainlogic-verified.jsonl
```
`mainlogic-verified.jsonl` (optional, not committed) is the verified cores alone, i.e. the rows with
`human_audit == "verified"`.

---

## 7. Evaluation (`data/run.py`, not part of construction)

```
uv run python data/run.py --model <alias>                      # native: every row -> results/<alias>_NNN
uv run python data/run.py --model <alias> --ablation highlighted   # evidence bracketed in place (RQ3)
uv run python data/run.py --model <alias> --ablation oracle        # evidence alone, no papers (RQ3)
uv run python data/run.py --model <alias> --baseline           # evidence-free probe (RQ2) -> results/baseline/
uv run python data/run.py --model <alias> --strict             # prompt ablation -> strict_<alias>_NNN
uv run python data/run.py --model <alias> --prompt loose       # prompt ablation -> loose_<alias>_NNN
```
Each run directory holds `verdicts.jsonl` (one answer per row) and `summary.json` (the run's
configuration). `--resume` tops a run up with rows it has not answered. (`--ablation decoy` exists but is not
used in the paper.) The ten evaluated models are GPT-4.1, GPT-5.6 Luna and
Terra, GPT-6 Astra, Claude Fable 5.1, Opus 5 and Sonnet 5, Gemini 2.5 Flash and 3.8 Flash, and
DeepSeek Flash. Keys come from `.env`.

The paper's tables and figures are then produced from `data/results/` by `eval/`:

```
uv run python eval/rq1.py                 # RQ1: six-cell core, grouped correctness, P0 vs P=
uv run python eval/rq2.py                 # RQ2: prior-conditioned measures, GLM, stratified gaps
uv run python eval/rq3.py                 # RQ3: counterfactual row under native / highlighted / oracle
uv run python eval/ablation_horizon.py    # appendix: horizon ablations
uv run python eval/ablation_default.py    # appendix: default behaviour study
uv run python eval/ablation_prompt.py     # appendix: prompt ablation
```
Outputs land in `eval/out/<script>/`.

---

## File map

| path | role |
|---|---|
| `clean.py` `resolve.py` `s2.py` `ref.py` `fulltext.py` | acquisition |
| `latex.py` | LaTeX → plain text, citing-sentence and cite-key parsing (no model) |
| `filter.py` | path A: every citing sentence → code checks → citation function → decontextualisation → claims.yaml |
| `human.py` `llm.py` `claim_filter.md` | path B: direct extraction → claims.yaml |
| `claims.py` `claims.yaml` | the claim store + CLI (`add check show put attach`); human review is `drop: true` here |
| `augment.py` `verify.py` `model.py` | augmentation, guards, cached model client |
| `preserve.py` `preserved/` | the `P=` redundant-removal control, deterministic |
| `related/` `built/` `.cache/` | stage-1 passages, per-core records (including the 30 built cores the audit or the check kept out of the release), call cache |
| `export.py` | assembly: triaged cores (`claims.yaml` drop/keep) + the `P=` control → `final/mainlogic.jsonl` |
| `human_audit.py` `audit/` | human sampled audit, records |
| `final/` | `mainlogic.jsonl`; `mainlogic-verified.jsonl` when built |
| `run.py` `results/` | evaluation runs, one directory per model and condition |
| `../eval/` | the paper's analyses, one script per research question and ablation |
