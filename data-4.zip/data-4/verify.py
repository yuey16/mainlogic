"""Shared checks for the augmentation pipeline.

Three kinds of guard live here, all used by data/augment.py:
  in_place          the edit discipline, checked in code: no added sentence, no runaway growth
  literal_anchor    is either claim simply STATED by a sentence? then the item tests matching
  scan / repair     a verifier reads the edited documents; what it flags goes back for one rewrite
"""

from __future__ import annotations

import difflib
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from model import Model, locate, normalise  # noqa: E402


REPAIR_PROMPT = """A research paper was edited so that it supports a CONTRASTING CLAIM instead of an \
ORIGINAL CLAIM. A check found PASSAGES the edit missed: they still state the original. Rewrite each one \
so the paper consistently supports the contrasting claim. Change only what that requires; keep wording, \
LaTeX and markdown; stay consistent with the rewrites ALREADY MADE; each rewrite must read as something \
that paper could have written. Return a passage unchanged if it does not in fact conflict.

Reply with JSON only:
{"rewrites": [{"index": <n>, "text": "<the passage exactly as it should now read>"}]}"""


SENTENCE_END = re.compile(r"[.!?](?:\s|$)")


def in_place(old: str, new: str) -> bool:
    """The strict discipline, checked in code: no added sentence, no more than 30% longer."""
    return (len(SENTENCE_END.findall(new)) <= len(SENTENCE_END.findall(old))
            and len(new) <= 1.3 * len(old) + 30)


def locate_loose(quote: str, text: str) -> tuple[int, int] | None:
    """A verifier sometimes appends its own words to a quote (a table row followed by why it
    conflicts). Fall back to the longest verbatim prefix, cut at a separator, of 30+ chars."""
    where = locate(quote, text)
    if where or len(quote) < 30:
        return where
    for sep in (" | For ", " — ", " - ", ". ", "; ", " | "):
        head = quote
        while sep in head:
            head = head[:head.rindex(sep) + (1 if sep == ". " else 0)].strip()
            if len(head) >= 30 and (where := locate(head, text)):
                return where
    return None


def scan(sol: Model, claim: str, claim_minus: str, texts: list[str], docs: list[dict], prompt: str) -> list[dict]:
    """sol reads each whole document. A document it could not read counts as flagged."""
    found = []
    for i, text in enumerate(texts):
        user = "\n".join([f"=== ORIGINAL CLAIM ===\n{claim}", "", f"=== CONTRASTING CLAIM ===\n{claim_minus}", "",
                          f"=== DOCUMENT ({docs[i]['title']}) ===\n{text}"])
        reply = sol.ask(prompt, user, valid_scan)
        if reply is None:
            found.append({"doc": i, "quote": "", "why": "scan failed: no usable reply", "failed": True})
            continue
        for c in reply["conflicts"]:
            if c["quote"].strip():
                found.append({"doc": i, "quote": normalise(c["quote"])[:400], "why": str(c.get("why", ""))[:200]})
    return found


def repair(astra: Model, claim: str, claim_minus: str, flags: list[dict], texts: list[str],
           changes: dict) -> dict[tuple[int, str], str]:
    """One round: rewrite what the scan found in text no edit had touched."""
    todo = []
    for flag in flags:
        if flag.get("failed"):
            continue
        where = locate_loose(flag["quote"], texts[flag["doc"]])
        if where:
            todo.append((flag["doc"], texts[flag["doc"]][where[0]:where[1]]))
    todo = list(dict.fromkeys(todo))
    if not todo:
        return {}
    already = [f"  - {old[:100]!r} -> {new[:100]!r}" for (_, old), new in list(changes.items())[:15]]
    listing = [f"[{n}] {old}" for n, (_, old) in enumerate(todo, 1)]
    user = "\n".join([f"=== ORIGINAL CLAIM ===\n{claim}", "", f"=== CONTRASTING CLAIM ===\n{claim_minus}", "",
                      "=== ALREADY MADE ===", *already, "", f"=== PASSAGES ({len(todo)}) ===", *listing])
    reply = astra.ask(REPAIR_PROMPT, user, lambda v: isinstance(v.get("rewrites"), list) and all(
        isinstance(r, dict) and isinstance(r.get("index"), int) and 1 <= r["index"] <= len(todo)
        and isinstance(r.get("text"), str) for r in v["rewrites"]))
    out = {}
    for r in (reply or {}).get("rewrites", []):
        doc, old = todo[r["index"] - 1]
        if r["text"] != old:
            out[(doc, old)] = r["text"]
    return out


# --- one claim ------------------------------------------------------------------------------


STOPWORDS = {"a", "an", "the", "of", "in", "on", "to", "is", "are", "was", "were", "be", "by", "as", "at",
             "and", "or", "it", "its", "that", "this", "with", "for", "from", "not", "no"}


def changed_phrases(before: str, after: str) -> list[str]:
    """The word runs that differ between two claims, as they read in `after`."""
    import difflib
    a, b = before.split(), after.split()
    out = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if op in ("replace", "insert") and j2 > j1:
            phrase = " ".join(b[j1:j2]).strip(" .,;:")
            if len(phrase) >= 2 and phrase.lower() not in STOPWORDS:
                out.append(phrase)
    return out


def literal_anchor(claim: str, other: str, texts: list[str]) -> str | None:
    """A sentence that states this claim: it carries the phrase distinguishing it from the other
    claim AND most of the claim's content words. The item can then be settled by matching rather
    than by reasoning. A distinguishing word appearing somewhere else in a long paper is not
    enough - "larger" or "improvements" occur everywhere."""
    words = lambda s: {w for w in re.findall(r"[a-z0-9]+", s.lower()) if w not in STOPWORDS and len(w) > 1}
    want = words(claim)
    if not want:
        return None
    for phrase in changed_phrases(normalise(other), normalise(claim)):
        needle = normalise(phrase).lower()
        for text in texts:
            for sentence in re.split(r"(?<=[.!?])\s+|\n", text):
                if needle in normalise(sentence).lower() and len(want & words(sentence)) / len(want) >= 0.6:
                    return f"{phrase} | {' '.join(sentence.split())[:120]}"
    return None
