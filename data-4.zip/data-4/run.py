"""Ask an LLM whether each conclusion follows from its premises.

Each row carries a gold label ("true", "uncertain", later "false"). Reported:
accuracy overall and per gold label, plus PAIR ACCURACY over decontextualization
minimal pairs — credit only when a model gets both the ill-posed original
(uncertain) and its standalone rewrite (true) right. A model that answers "true"
to everything scores 50% on a pair's rows and 0% on pairs.

Every verdict is saved, because a disagreement is only interpretable by reading it.

Premises are sent whole, exactly as stored. No truncation, no retrieval.

Usage:
    python data/run.py
    python data/run.py --model openai/gpt-5.6-luna --limit 10 --concurrency 4
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import logging
import os
import random
import re
import statistics
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console
from rich.progress import BarColumn, MofNCompleteColumn, Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

log = logging.getLogger("bench_logic")
ROOT = Path(__file__).resolve().parents[1]


def _rel(path) -> str:
    """A path as recorded in a run summary: relative to the repo, so it names no machine."""
    path = Path(path).resolve()
    return str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else path.name

LABELS = ("supported", "contradicted", "uncertain")
# The pipeline's screening labels are provisional: `slightly_true` means the
# cited works back the main claim while a detail goes further, which is still
# supported. It is not a fourth answer, and never maps to uncertain.
GOLD_ALIASES = {"true": "supported", "slightly_true": "supported", "false": "contradicted"}
UNSCORED_GOLD: tuple[str, ...] = ()

SYSTEM_PROMPT = """You are judging how a CONCLUSION follows, given premise documents

Answer with exactly one of:
  Supported     - the premises back the conclusion. They need not word every detail the same way:
                  if they establish what the conclusion asserts, it is supported.
  Contradicted  - the premises say otherwise: they state the opposite, or give a different value
                  for something the conclusion states.
  Uncertain     - the premises neither establish the conclusion nor contradict it. Use this when
                  they simply do not settle it, not when you merely feel unsure.

Respond with the answer and nothing else."""

# --strict adds one line, and nothing else changes: the default prompt above is the one every run
# so far has used, so old and new runs stay comparable. The strict view asks whether a model that
# is TOLD to ignore what it knows behaves differently from one that is merely given documents.
STRICT_LINE = ("\n\nUse the premise documents STRICTLY. Judge only from what they say: do not use "
               "world knowledge, prior familiarity with the work, or what you believe to be true "
               "outside these documents.")

# Prompt variants for A/B tests of the INSTRUCTION, holding the dataset fixed. "default" is the
# prompt above, byte for byte: every run so far used it, so it is the baseline arm and must never
# change. A variant states what it alters and why, and lands in its own run directory.
#  The evidence-free probe (RQ3) needs a prompt that does not name premises, because there are
#  none. Asked the default way, a model is told to judge "based only on the premise documents" and
#  then shown none, so "uncertain" is the only coherent answer and the run measures whether it
#  noticed the documents were missing — not what it believes. This wording leaves the source of the
#  evidence open, so memory counts, and "uncertain" means genuinely unsettled.
SYSTEM_PROMPT_EVIDENCE = """If the conclusion follows state Supported, if not state Contradicted, if you are
uncertain answer Uncertain. Answer with only one word."""

#  --baseline: the claim alone, asked as plainly as possible. No premises, no framing, no mention
#  of documents or evidence at all, so the only thing left to answer from is what the model knows.
#  This is the evidence-free probe RQ3 needs: b(C), the model's prior on the claim itself.
SYSTEM_PROMPT_BASELINE = """If the conclusion follows state Supported, if not state Contradicted, if you are
uncertain answer Uncertain. Answer with only one word."""

#  The loose arm of the instruction ablation. No definitions, no guidance on what counts as
#  evidence, no mention of premises: the documents are "some information" and the model is asked
#  the question. Paired with --strict, which adds a line forbidding world knowledge to the default
#  prompt, this brackets the default from both sides.
SYSTEM_PROMPT_LOOSE = """Here is some information, followed by a conclusion. Is the conclusion
supported, contradicted, or uncertain? Answer with one word: Supported, Contradicted, or
Uncertain."""

PROMPTS = {
    "default": SYSTEM_PROMPT,
    "evidence": SYSTEM_PROMPT_EVIDENCE,
    "baseline": SYSTEM_PROMPT_BASELINE,
    "loose": SYSTEM_PROMPT_LOOSE,
    # Does the closing clause of the Uncertain definition suppress the label? Every model but one
    # produces "uncertain" well below its 1-in-3 base rate, and the P0 cells are their weakest.
    # This arm removes the discouragement and changes nothing else.
    "neutral-uncertain": SYSTEM_PROMPT.replace(
        """  Uncertain     - the premises neither establish the conclusion nor contradict it. Use this when
                  they simply do not settle it, not when you merely feel unsure.""",
        """  Uncertain     - the premises neither establish the conclusion nor contradict it: they do not
                  settle it either way."""),
}


def one_per_claim(rows: list[dict]) -> list[dict]:
    """One row per distinct conclusion.

    The evidence-free probe asks about the CLAIM, so the premise state is irrelevant and the same
    claim appearing in three cells would be three calls with the same question. Keeping the first
    occurrence makes the probe 2 calls per anchor instead of 6, and the prior attaches downstream
    by conclusion text rather than by row id.
    """
    seen, out = set(), []
    for row in rows:
        key = row["conclusion"]
        if key not in seen:
            seen.add(key)
            out.append(row)
    return out


def sample_cores(rows: list[dict], n: int, seed: int) -> list[dict]:
    """N complete cores, drawn by hash of (seed, anchor).

    Whole cores, not rows, so every cell of a core is judged or none is; and hash order rather than
    a shuffle so two arms of an A/B, run separately, see exactly the same items.
    """
    anchors = sorted({r["anchor_id"] for r in rows if r.get("anchor_id")})
    anchors.sort(key=lambda a: hashlib.sha1(f"{seed}\x00{a}".encode()).hexdigest())
    keep = set(anchors[:n])
    return [r for r in rows if r.get("anchor_id") in keep]


DEFAULT_OUT = ROOT / "data" / "results"

WORD_RE = re.compile(r"[a-z]+")

# Temperature is a per-MODEL fact, not a per-provider one: Anthropic accepts it for Haiku 4.5 and
# rejects it for Sonnet 5 and Opus 5, in the same workspace on the same endpoint. Rather than keep a
# list that goes stale, the first 400 that names it records the model here and the call is retried
# without it. A run therefore costs one wasted request per new model, and none after that.
NO_TEMPERATURE: set[str] = set()

MAX_ATTEMPTS = 8
RETRY_BASE_S = 5.0
RETRY_CAP_S = 120.0


def parse_verdict(text: str | None) -> str | None:
    """First label-like word in the reply, or None if the model didn't answer."""
    if not text:
        return None
    spoken = {"true": "supported", "supports": "supported", "support": "supported",
              "false": "contradicted", "contradicts": "contradicted",
              "contradiction": "contradicted", "unknown": "uncertain",
              "undetermined": "uncertain", "insufficient": "uncertain"}
    for word in WORD_RE.findall(text.lower()):
        if word in LABELS:
            return word
        if word in spoken:
            return spoken[word]
    return None


#  Highlighting: the documents are kept whole and the located passages are bracketed in place, so
#  the reader no longer has to FIND the evidence but still has to weigh it against everything else.
#  Neither character occurs anywhere in the corpus, so a mark is unambiguous.
MARK_OPEN, MARK_CLOSE = "<start_important>", "<end_important>"
MARK_NOTE = (f"Passages that an earlier pass identified as potentially relevant to the conclusion "
             f"are denoted {MARK_OPEN}like this{MARK_CLOSE}. The marks say only that a passage was "
             f"judged relevant; they do not say whether it supports or contradicts anything, and "
             f"other parts of the documents may matter too.")


def mark_spans(text: str, spans: list[tuple[int, int]]) -> str:
    """Bracket each span, working backwards so earlier offsets stay valid."""
    out = text
    for start, end in sorted(set(spans), reverse=True):
        if 0 <= start < end <= len(out):
            out = out[:start] + MARK_OPEN + out[start:end] + MARK_CLOSE + out[end:]
    return out


def _relevant_but_insufficient(row: dict) -> list[list[tuple[int, int]]]:
    """Spans to mark in a P0 premise.

    P0 has no located evidence - that is what makes it P0 - so marking nothing would turn an absent
    highlight into the label cue. Instead we mark the passages the planner labelled `unrelated`:
    text the reader pass returned as bearing on the claim, which the planner then judged not to be
    evidence. They survive the cut, so they are relevant-but-insufficient by construction.
    """
    cid = row.get("anchor_id") or ""
    name = cid.replace(":", "_") + ".json"
    built, related = ROOT / "data" / "built" / name, ROOT / "data" / "related" / name
    if not built.is_file() or not related.is_file():
        return []
    roles = (json.loads(built.read_text(encoding="utf-8")).get("roles") or {})
    passages = json.loads(related.read_text(encoding="utf-8")).get("passages") or []
    out: list[list[tuple[int, int]]] = [[] for _ in row["premise"]]
    for index, role in roles.items():
        i = int(index) - 1
        if role != "unrelated" or not (0 <= i < len(passages)):
            continue
        passage = passages[i]
        doc = passage.get("premise_index", 0)
        if doc >= len(row["premise"]):
            continue
        at = row["premise"][doc].find(passage["quote"])
        if at >= 0:
            out[doc].append((at, at + len(passage["quote"])))
    return out


def decoy(row: dict) -> dict | None:
    """The row with the WRONG passages bracketed: the ones the planner judged not to be evidence.

    A control for the highlighted view. Highlighting does two things at once, it points at the
    evidence and it says "attend here". This marks passages of the same kind and similar length
    that the reader pass returned as topical and the planner labelled `unrelated`, and leaves the
    real evidence unmarked. If this recovers what highlighting recovers, the gain was the hint. If
    it does not, the gain was the pointer. Any decoy span that overlaps a located statement is
    dropped, so the marks never touch evidence. None when nothing can be marked.
    """
    spans = _relevant_but_insufficient(row)
    real: list[list[tuple[int, int]]] = [[] for _ in row["premise"]]
    for st in row.get("ref_statements") or []:
        if st.get("char_start") is not None and st["premise_index"] < len(real):
            real[st["premise_index"]].append((st["char_start"], st["char_end"]))
    clean = [[(a, b) for a, b in doc_spans
              if not any(a < e and s_ < b for s_, e in real[i])]
             for i, doc_spans in enumerate(spans)]
    if not any(clean):
        return None
    return {**row, "premise": [mark_spans(text, clean[i]) for i, text in enumerate(row["premise"])]}


def highlighted(row: dict) -> dict | None:
    """The row with its located passages bracketed in place. None when nothing can be marked."""
    spans: list[list[tuple[int, int]]] = [[] for _ in row["premise"]]
    for s in row.get("ref_statements") or []:
        if s.get("char_start") is not None and s["premise_index"] < len(spans):
            spans[s["premise_index"]].append((s["char_start"], s["char_end"]))
    if not any(spans):
        spans = _relevant_but_insufficient(row)
    if not any(spans):
        return None
    return {**row, "premise": [mark_spans(text, spans[i]) for i, text in enumerate(row["premise"])]}


def build_prompt(row: dict, bare: bool = False) -> str:
    """The user message. `bare` is the baseline probe: the conclusion and nothing else."""
    if bare:
        #  The claim and nothing else. A section header here reads as one field of a template and
        #  invites the model to fill in the others, which is how an early version of this probe
        #  produced fabricated "=== EVIDENCE ===" blocks instead of a one-word answer.
        return row["conclusion"]
    parts = []
    for i, premise in enumerate(row["premise"], start=1):
        parts.append(f"=== PREMISE DOCUMENT {i} of {row['no_premise']} ===\n{premise}")
    if any(MARK_OPEN in text for text in row["premise"]):
        parts.append(MARK_NOTE)
    parts.append(f"=== CONCLUSION ===\n{row['conclusion']}")
    #  With documents, the question is source-relative and the wording is unchanged from every run
    #  so far. With none, naming them would both announce their absence and forbid the only evidence
    #  the model has, which is the whole point of the evidence-free probe.
    parts.append("Based only on the premise documents, is the conclusion Supported, Contradicted, or Uncertain?"
                 if row["premise"] else
                 "Is the conclusion Supported, Contradicted, or Uncertain?")
    return "\n\n".join(parts)


def apply_ablation(rows: list[dict], ablation: str) -> list[dict]:
    """Rows as the chosen ablation presents them."""
    if ablation == "none":
        return rows
    if ablation == "oracle":
        #  P= differs from P+ only in the non-evidence text, and the oracle view discards exactly
        #  that, so an oracle P= row is byte-identical to its P+ sibling. Judging both would buy
        #  nothing but a second sample of the same question.
        rows = [r for r in rows if not str(r.get("cell", "")).startswith("P=")]
        # Just the statements, no surrounding paper: this separates "could not find
        # the evidence in 120k characters" from "found it and answered anyway".
        kept = [r for r in rows if r.get("ref_statements")]
        return [{**r, "premise": [s["quote"] for s in r["ref_statements"]],
                 "no_premise": len(r["ref_statements"])}
                for r in kept]
    if ablation == "highlighted":
        # A row whose evidence cannot be marked is DROPPED, never sent unmarked: an unmarked row in
        # a highlighted run would differ from its siblings in exactly the way the label does.
        out = [highlighted(r) for r in rows]
        kept = [r for r in out if r is not None]
        if len(kept) != len(rows):
            log.warning("highlighted: %d of %d row(s) had nothing to mark and were dropped",
                        len(rows) - len(kept), len(rows))
        return kept
    if ablation == "decoy":
        #  The P- row only. That is the row where highlighting bought anything, so it is the
        #  row on which the control has to be run. Paired against the highlighted run on the
        #  same rows.
        rows = [r for r in rows if str(r.get("cell", "")).startswith("P-")]
        out = [decoy(r) for r in rows]
        kept = [r for r in out if r is not None]
        if len(kept) != len(rows):
            log.warning("decoy: %d of %d P- row(s) had no unrelated passage to mark and were "
                        "dropped", len(rows) - len(kept), len(rows))
        return kept
    if ablation == "no-premise":
        # Nothing to judge against: every answer other than Uncertain comes from
        # what the model already knows (or guesses) about the claim.
        return [{**r, "premise": [], "no_premise": 0} for r in rows]
    raise ValueError(ablation)


def load_dotenv() -> None:
    env = ROOT / ".env"
    if not env.is_file():
        return
    for line in env.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, _, value = line.partition("=")
            os.environ.setdefault(key.strip(), value.strip().strip("'\""))


def estimate_cost(model: str, usage) -> float | None:
    price = PRICING.get(model)
    if not price or usage is None:
        return None
    return (usage.prompt_tokens or 0) * price[0] + (usage.completion_tokens or 0) * price[1]


def gold_label(row: dict) -> str:
    """The row's label as one of the three answers the model may give.

    Older datasets stored the label as the bool True; the pipeline's provisional
    `true` / `slightly_true` / `false` both map onto this three-way scheme.
    """
    # Augmented rows state the relation directly; anchors carry a screening label.
    label = row.get("relation") or row.get("label", True)
    label = "true" if label is True else str(label).lower()
    return GOLD_ALIASES.get(label, label)


def with_row_fields(result: dict, row: dict) -> dict:
    """Attach the row's CURRENT label and pairing, whatever the cache recorded.

    A verdict carries the model's answer, never the gold: labels move as the
    dataset is rebuilt, so gold is read from the row at scoring time.
    """
    return {**result, "id": row.get("id"), "paper": row.get("paper"), "gold": gold_label(row),
            "anchor_id": row.get("anchor_id"), "cell": row.get("cell"),
            "conclusion": row["conclusion"]}


def cached_tokens(usage) -> int:
    """Prompt tokens the provider served from its prefix cache, however it says so.

    Every vendor spells this differently: OpenAI and OpenRouter nest it under
    `prompt_tokens_details`, DeepSeek puts `prompt_cache_hit_tokens` at the top
    level, Gemini reports `cached_content_token_count`. A vendor that reports
    nothing reads as zero, which understates rather than invents a saving.
    """
    details = getattr(usage, "prompt_tokens_details", None)
    for owner, field in ((details, "cached_tokens"), (usage, "prompt_cache_hit_tokens"),
                         (usage, "cached_content_token_count")):
        value = getattr(owner, field, None) if owner is not None else None
        if isinstance(value, int):
            return value
    return 0


def premise_key(row: dict) -> str:
    """Rows that would send byte-identical premises share one key.

    C+ and C- for the same anchor differ only in the final conclusion line, so
    they share a ~25k-token prefix. Judging them back to back lets the provider
    serve the second from cache; judging them in parallel, as a flat gather does,
    guarantees two cache misses because neither call has returned yet.
    """
    premise = row["premise"] if isinstance(row["premise"], list) else [row["premise"]]
    return hashlib.sha1("\0".join(premise).encode("utf-8")).hexdigest()[:16]


async def judge(client, model: str, row: dict, semaphore, provider: str = "openai",
                system: str = SYSTEM_PROMPT, bare: bool = False) -> dict:
    """One row -> one verdict.

    Deliberately uncached: these models are non-deterministic (the OpenAI API
    rejects temperature 0 for them), so running a model twice is a second SAMPLE,
    not a repeat of the first. Each run is kept whole under data/results.
    """
    prompt = build_prompt(row, bare)
    async with semaphore:
        started = time.perf_counter()
        # These prompts are ~25k tokens each, so OpenRouter throttles on tokens
        # per minute, not just requests. Sustained 429s need real backoff — the
        # SDK's own retries give up long before the window resets.
        last_error = None
        for attempt in range(1, MAX_ATTEMPTS + 1):
            try:
                config = PROVIDERS[provider]
                optional = {}
                if config["temperature"] is not None and model not in NO_TEMPERATURE:
                    optional["temperature"] = config["temperature"]
                if config["extra_body"]:
                    optional["extra_body"] = config["extra_body"]
                response = await client.chat.completions.create(
                    model=model,
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user", "content": prompt},
                    ],
                    max_completion_tokens=4000,
                    **optional,
                )
                break
            except Exception as exc:
                last_error = exc
                if "temperature" in str(exc) and attempt < MAX_ATTEMPTS:
                    if model not in NO_TEMPERATURE:
                        log.warning("%s does not accept temperature; sending the default from now on", model)
                    NO_TEMPERATURE.add(model)
                    continue
                retryable = "429" in str(exc) or "rate" in str(exc).lower() or "timeout" in str(exc).lower()
                if not retryable or attempt == MAX_ATTEMPTS:
                    log.warning("%s: %s: %s", row.get("id"), type(exc).__name__, exc)
                    return with_row_fields({"id": row.get("id"), "verdict": None,
                            "error": f"{type(exc).__name__}: {exc}",
                            "latency_s": time.perf_counter() - started}, row)
                delay = min(RETRY_CAP_S, RETRY_BASE_S * 2 ** (attempt - 1)) * (0.5 + random.random())
                log.warning("%s: attempt %d/%d hit a rate limit, waiting %.0fs",
                            row.get("id"), attempt, MAX_ATTEMPTS, delay)
                await asyncio.sleep(delay)
        else:  # pragma: no cover - loop always breaks or returns
            return with_row_fields({"id": row.get("id"), "verdict": None, "error": str(last_error),
                    "latency_s": time.perf_counter() - started}, row)
        latency = time.perf_counter() - started

    text = (response.choices[0].message.content or "").strip()
    usage = response.usage
    result = {
        "id": row.get("id"),
        "paper": row.get("paper"),
        "conclusion": row["conclusion"],
        "no_premise": row["no_premise"],
        "verdict": parse_verdict(text),
        "raw": text[:200],
        "latency_s": round(latency, 2),
        "prompt_tokens": getattr(usage, "prompt_tokens", None),
        "cached_tokens": cached_tokens(usage),
        "completion_tokens": getattr(usage, "completion_tokens", None),
        "cost_usd": getattr(usage, "cost", None) or estimate_cost(model, usage),
        "cost_estimated": getattr(usage, "cost", None) is None,
        "provider": provider,
        "error": None,
    }
    return with_row_fields(result, row)


# The gpt-5.6 family differs only by suffix, so a bare name is expanded rather
# than typed out.
ALIASES = {
    "luna": "gpt-5.6-luna",
    "sol": "gpt-5.6-sol",
    "terra": "gpt-5.6-terra",
    "luna-pro": "gpt-5.6-luna-pro",
    "sol-pro": "gpt-5.6-sol-pro",
    "terra-pro": "gpt-5.6-terra-pro",
    "astra": "gpt-6-astra",
    # Non-OpenAI models keep their vendor prefix and are only reachable via OpenRouter.
    "sonnet-5": "anthropic/claude-sonnet-5",
}

# Every vendor below speaks the OpenAI chat-completions dialect, so one client
# serves them all; only the base URL, the key and the temperature differ.
PROVIDERS = {
    # The OpenAI API rejects temperature=0 for GPT-5.6 (only the default is
    # allowed) and has no usage.cost field, so neither is sent there.
    "openai": {"base_url": "https://api.openai.com/v1", "key_env": "OPENAI_API_KEY",
               "prefix": "", "temperature": None, "extra_body": None},
    "openrouter": {"base_url": "https://openrouter.ai/api/v1", "key_env": "OPENROUTER_API_KEY",
                   "prefix": "openai/", "temperature": 0, "extra_body": {"usage": {"include": True}}},
    "anthropic": {"base_url": "https://api.anthropic.com/v1/", "key_env": "ANTHROPIC_API_KEY",
                  "prefix": "", "temperature": 0, "extra_body": None},
    "gemini": {"base_url": "https://generativelanguage.googleapis.com/v1beta/openai/",
               "key_env": "GEMINI_API_KEY", "prefix": "", "temperature": 0, "extra_body": None},
    "deepseek": {"base_url": "https://api.deepseek.com/v1", "key_env": "DEEPSEEK_API_KEY",
                 "prefix": "", "temperature": 0, "extra_body": None},
    # api.moonshot.ai, not .cn: the .cn host rejects this key outright. Kimi
    # allows only its default temperature, like the GPT-5.6 family.
    "moonshot": {"base_url": "https://api.moonshot.ai/v1", "key_env": "MOONSHOT_API_KEY",
                 "prefix": "", "temperature": None, "extra_body": None},
}

# A short name picks both the model and the vendor that serves it, so `-m kimi`
# needs no --provider. Anything not listed falls back to --provider.
VENDOR_MODELS = {
    "anthropic": {"opus-5": "claude-opus-5", "sonnet-5": "claude-sonnet-5",
                  "haiku-4.5": "claude-haiku-4-5-20251001", "fable": "claude-fable-5-1",
                  "fable-5.1": "claude-fable-5-1"},
    "gemini": {"gemini-flash": "gemini-3.8-flash", "gemini-pro": "gemini-3.1-pro-preview",
               "gemini-2.5-flash": "gemini-2.5-flash", "gemini-3.8-flash": "gemini-3.8-flash"},
    "deepseek": {"deepseek-flash": "deepseek-flash", "deepseek-pro": "deepseek-v4-pro"},
    "moonshot": {"kimi": "kimi-k2.6", "kimi-k3": "kimi-k3"},
}
VENDOR_OF = {alias: vendor for vendor, models in VENDOR_MODELS.items() for alias in models}

# $/token per model, filled in once per run when the provider reports no cost.
PRICING: dict[str, tuple[float, float]] = {}


def provider_for(name: str, default: str) -> str:
    """The vendor that serves this short name, or the one asked for."""
    return VENDOR_OF.get(name.lower(), default)


def resolve_model(name: str, provider: str) -> str:
    """A short name or full id, in the form the chosen provider expects."""
    vendor_models = VENDOR_MODELS.get(provider, {})
    if name.lower() in vendor_models:
        return vendor_models[name.lower()]
    if provider not in ("openai", "openrouter"):
        return name  # a full vendor id, passed through untouched
    prefix = PROVIDERS[provider]["prefix"]
    bare = ALIASES.get(name.lower(), name)
    if bare.startswith("openai/"):
        bare = bare[len("openai/"):]
    if "/" in bare:  # some other vendor's id: only meaningful on OpenRouter
        if provider != "openrouter":
            raise SystemExit(f"{name!r} is not an OpenAI model; use --provider openrouter")
        return bare
    if not bare.startswith("gpt-") and name.lower() not in ALIASES:
        known = sorted(set(ALIASES) | set(VENDOR_OF))
        raise SystemExit(f"unknown model {name!r}; short names: {', '.join(known)}")
    return prefix + bare


def load_pricing(models: list[str]) -> None:
    """Published per-token prices, used to ESTIMATE spend when the API reports none."""
    import httpx

    try:
        data = httpx.get("https://openrouter.ai/api/v1/models", timeout=30).json()["data"]
    except Exception as exc:  # an estimate is a nicety; never block the run on it
        log.warning("could not load pricing (%s); cost will show as --", exc)
        return
    table = {m["id"]: m.get("pricing") or {} for m in data}
    for model in models:
        price = table.get(model) or table.get(f"openai/{model}") or {}
        try:
            PRICING[model] = (float(price["prompt"]), float(price["completion"]))
        except (KeyError, TypeError, ValueError):
            log.warning("no published price for %s; cost will show as --", model)


def score(scored: list[dict]) -> dict:
    """Accuracy overall, per gold label, and over complete pairs.

    A pair is every row sharing an `anchor_id`: the cells of one core. Pair accuracy asks whether the
    model got the WHOLE group right, which is what an evidence-dependence claim
    needs - one right answer and one lucky one is not evidence of anything.
    """
    def acc(rows):
        return sum(r["verdict"] == r["gold"] for r in rows) / len(rows) if rows else None

    unscored = [r for r in scored if r["gold"] in UNSCORED_GOLD]
    scored = [r for r in scored if r["gold"] not in UNSCORED_GOLD]
    by_gold = {lab: [r for r in scored if r["gold"] == lab] for lab in LABELS}
    pairs: dict[str, list[dict]] = {}
    for r in scored:
        core = r.get("anchor_id") or r.get("pair_id")      # verdicts written before the rename
        if core:
            pairs.setdefault(core, []).append(r)
    # Any family with more than one member counts: a four-cell core is the point,
    # and requiring exactly two silently dropped every complete one.
    complete = [rows for rows in pairs.values() if len(rows) > 1]
    return {
        "accuracy": acc(scored),
        "accuracy_by_gold": {lab: acc(rows) for lab, rows in by_gold.items() if rows},
        "n_by_gold": {lab: len(rows) for lab, rows in by_gold.items() if rows},
        "pair_accuracy": (sum(all(r["verdict"] == r["gold"] for r in rows) for rows in complete) / len(complete))
        if complete else None,
        "pairs": len(complete),
        "pair_sizes": dict(Counter(len(rows) for rows in complete)),
        "answers_on_unscored": {lab: dict(Counter(r["verdict"] for r in unscored if r["gold"] == lab))
                                for lab in UNSCORED_GOLD if any(r["gold"] == lab for r in unscored)},
    }


def condition_runs(root: Path, alias: str, model: str, ablation: str, strict: bool,
                   prompt: str) -> list[tuple[int, Path]]:
    """(answered rows, directory) for every run of exactly this condition, most complete first.

    Matched on what summary.json recorded, not on the directory name, and searched recursively so
    a probe under results/baseline/ is found too.
    """
    out = []
    for summary in sorted(root.rglob("summary.json")):
        if not (summary.parent / "verdicts.jsonl").is_file():
            continue
        meta = json.loads(summary.read_text(encoding="utf-8"))
        if (meta.get("ablation", "none") != ablation or bool(meta.get("strict")) != strict
                or meta.get("prompt", "default") != prompt):
            continue
        if alias not in (meta.get("alias"), meta.get("model")) and model != meta.get("model"):
            continue
        answered = sum(1 for v in load_rows(summary.parent / "verdicts.jsonl") if v.get("verdict"))
        out.append((answered, summary.parent))
    return sorted(out, reverse=True)


def load_rows(path: Path) -> list[dict]:
    """A JSONL file as a list; used for the dataset and for an existing run's verdicts."""
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def next_run_dir(root: Path, alias: str, ablation: str, strict: bool = False,
                 prompt: str = "default") -> Path:
    """data/results/terra_003 — the next free number for this model and view.

    Numbered, not timestamped: repeated runs of one model are the point, and
    `terra_001 .. terra_005` reads as a sample where timestamps read as noise.
    """
    # A vendor-prefixed id would otherwise make a directory inside a directory.
    safe = alias.replace("/", "_")
    stem = safe if ablation == "none" else f"{safe}_{ablation}"
    if strict:
        stem = f"strict_{stem}"
    if prompt != "default":
        stem = f"{prompt}_{stem}"
    used = {int(p.name.rsplit("_", 1)[1]) for p in root.glob(f"{stem}_[0-9][0-9][0-9]")
            if p.name.rsplit("_", 1)[1].isdigit()}
    return root / f"{stem}_{max(used, default=0) + 1:03d}"


async def run_one(client, args, model: str, alias: str, rows: list[dict], console: Console,
                  provider: str | None = None, fill: Path | None = None) -> dict:
    """Judge every row with one model and write that model's run directory."""
    semaphore = asyncio.Semaphore(args.concurrency)

    #  Every verdict is appended to a journal the moment it arrives. A pass that dies partway -
    #  a closed laptop, a killed process, a provider outage - therefore costs the rows it had not
    #  reached rather than all of them, and `--fill` picks the run up from whatever is on disk.
    journal_dir = Path(fill) if fill else next_run_dir(
        Path(args.out), alias, args.ablation, getattr(args, "strict", False),
        getattr(args, "prompt", "default"))
    journal_dir.mkdir(parents=True, exist_ok=True)
    journal = (journal_dir / "verdicts.jsonl").open("a", encoding="utf-8")

    results: list[dict] = []
    with Progress(
        SpinnerColumn(style="cyan"), TextColumn(f"[bold]{model:<24}"), BarColumn(bar_width=26),
        MofNCompleteColumn(), TextColumn("{task.fields[rate]}"), TimeElapsedColumn(), console=console,
    ) as progress:
        task = progress.add_task("", total=len(rows), rate="acc --")

        async def one(row):
            base = PROMPTS[getattr(args, "prompt", "default")]
            r = await judge(client, model, row, semaphore, provider or args.provider,
                            base + STRICT_LINE if getattr(args, "strict", False) else base,
                            bare=getattr(args, "baseline", False))
            results.append(r)
            journal.write(json.dumps(r, ensure_ascii=False) + "\n")
            journal.flush()
            done = [x for x in results if x.get("verdict")]
            acc = sum(x["verdict"] == x["gold"] for x in done) / len(done) if done else 0
            progress.update(task, advance=1, rate=f"acc {acc:5.1%}")
            # The live bar only draws on a terminal; when logging to a file, say
            # something every few rows so a long run is visibly alive.
            if not console.is_terminal and (len(results) % 5 == 0 or len(results) == len(rows)):
                print(f"{model}: {len(results)}/{len(rows)} done, acc so far {acc:.1%}", flush=True)

        if args.no_pair_order:
            await asyncio.gather(*(one(r) for r in rows))
        else:
            groups: dict[str, list[dict]] = {}
            for row in rows:
                groups.setdefault(premise_key(row), []).append(row)

            async def group(members: list[dict]) -> None:
                for row in members:      # in order: the first call fills the cache
                    await one(row)

            log.info("%s: %d row(s) in %d premise group(s)", model, len(rows), len(groups))
            await asyncio.gather(*(group(g) for g in groups.values()))

    journal.close()
    counts = Counter(r["verdict"] or "no answer" for r in results)
    scored = [r for r in results if r.get("verdict")]
    metrics = score(scored)
    lat = [r["latency_s"] for r in results if r.get("latency_s")]
    toks = [r["prompt_tokens"] for r in results if r.get("prompt_tokens")]
    cached = sum(r.get("cached_tokens") or 0 for r in results)
    costs = [r["cost_usd"] for r in results if r.get("cost_usd")]
    # Cached verdicts carry the cost of the call that produced them; only the rest
    # was spent now.
    spent = [r["cost_usd"] for r in results if r.get("cost_usd")]

    fill = fill or getattr(args, "fill", None)
    out_dir = journal_dir
    if fill:
        # Filling an existing run: keep the answers it already has and drop in the new ones, so a
        # rate limit or a bad request costs the failed rows rather than the whole pass. The journal
        # already holds this pass's rows, so read it back and keep the last answer per id.
        merged = {}
        for v in load_rows(out_dir / "verdicts.jsonl"):
            if v.get("verdict") or v["id"] not in merged:
                merged[v["id"]] = v
        results = list(merged.values())
        metrics = score([r for r in results if r.get("verdict")])
    out_dir.mkdir(parents=True, exist_ok=True)
    with (out_dir / "verdicts.jsonl").open("w", encoding="utf-8") as fh:
        for r in sorted(results, key=lambda r: str(r.get("id"))):
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
    summary = {
        "model": model, "alias": alias, "provider": provider or args.provider,
        "dataset": _rel(args.dataset), "rows": len(results), "ablation": args.ablation,
        "strict": bool(getattr(args, "strict", False)),
        "prompt": getattr(args, "prompt", "default"), "baseline": bool(getattr(args, "baseline", False)),
        "claims_probed": len({r["conclusion"] for r in rows}) if getattr(args, "baseline", False) else None,
        "sample": getattr(args, "sample", None), "sample_seed": getattr(args, "seed", 0),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "gold_counts": dict(Counter(r["gold"] for r in results)),
        **metrics, "counts": dict(counts),
        "unanswered": counts.get("no answer", 0),
        "prompt_tokens_total": sum(toks) if toks else None,
        "cached_tokens_total": cached,
        "cache_hit_rate": round(cached / sum(toks), 3) if toks and sum(toks) else None,
        "pair_ordered": not args.no_pair_order,
        "cost_usd_total": sum(costs) if costs else None,
        "cost_usd_this_run": sum(spent),
        "live_calls": sum(1 for r in results if r.get("verdict")),
        "latency_s_median": statistics.median(lat) if lat else None,
        "run_dir": _rel(out_dir),
    }
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    disagree = [r for r in scored if r["verdict"] != r["gold"]]
    console.print(f"[dim]{model}: {len(disagree)} disagreement(s) → {out_dir}[/]")
    return summary


async def run(args) -> int:
    from openai import AsyncOpenAI

    aliases = args.models or ["luna"]
    picked = [(a, provider_for(a, args.provider)) for a in aliases]
    models = [(a, p, resolve_model(a, p)) for a, p in picked]
    for _, provider in picked:
        env = PROVIDERS[provider]["key_env"]
        if not os.environ.get(env):
            log.error("%s is not set (put it in .env) — needed for --provider %s", env, provider)
            return 1
    if any(p == "openrouter" for _, p in picked):
        load_pricing([m for _, p, m in models if p == "openrouter"])
    if args.baseline:
        args.ablation, args.prompt = "no-premise", "baseline"
        #  A probe is not a benchmark pass: keep it out of the folder the eval scans for models.
        if args.out == DEFAULT_OUT:
            args.out = args.out / "baseline"
    rows = load_rows(args.dataset)
    if args.fill:
        # The fill must repeat the original run's view exactly, or the merged file would mix two.
        # Read it before the ablation is applied, since the view decides which ablation that is.
        meta = json.loads((args.fill / "summary.json").read_text(encoding="utf-8"))
        args.ablation = meta.get("ablation", "none")
        args.strict = bool(meta.get("strict"))
        args.prompt = meta.get("prompt", "default")
        args.baseline = bool(meta.get("baseline")) or args.prompt == "baseline"
    rows = apply_ablation(rows, args.ablation)
    if args.baseline:
        before = len(rows)
        rows = one_per_claim(rows)
        log.info("baseline: %d row(s) -> %d distinct claim(s)", before, len(rows))
    if args.fill:
        answered = {v["id"] for v in load_rows(args.fill / "verdicts.jsonl") if v.get("verdict")}
        rows = [r for r in rows if r["id"] not in answered]
        log.info("%s: %d row(s) still unanswered (%s view)", args.fill.name, len(rows), args.ablation)
        if not rows:
            print(f"{args.fill.name}: nothing to fill")
            return 0
    if args.sample:
        rows = sample_cores(rows, args.sample, args.seed)
    if args.limit:
        rows = rows[: args.limit]

    # Fall back to a wide fixed width when stdout is redirected, so the model
    # column is not crushed out of the comparison table.
    console = Console()
    if not console.is_terminal:
        console = Console(width=150)
    console.print(
        f"[dim]{len(rows)} rows · {len(models)} model(s) · premises sent whole[/]\n"
        + "\n".join(f"  [cyan]{m}[/] [dim]via {p}[/]" for _, p, m in models)
    )

    # One client per vendor in play: a run may mix them, so the client follows
    # the model rather than the --provider flag.
    clients = {p: AsyncOpenAI(base_url=PROVIDERS[p]["base_url"],
                              api_key=os.environ[PROVIDERS[p]["key_env"]],
                              timeout=args.timeout, max_retries=2)
               for p in {p for _, p in picked}}
    summaries = []
    # Sequential across models: these prompts are ~25k tokens, and running two
    # models at once just doubles the token rate into the same 429 ceiling.
    for alias, provider, model in models:
        #  --resume is per model: each one has its own run and its own set of unanswered rows.
        #  --fill journals straight back into the run it is topping up. Without this the pass
        #  would open a fresh directory and the filled rows would never reach the original.
        todo, fill = rows, args.fill
        if args.resume and not args.fill:
            found = condition_runs(Path(args.out), alias, model, args.ablation,
                                   bool(args.strict), args.prompt)
            if found:
                _, fill = found[0]
                answered = {v["id"] for v in load_rows(fill / "verdicts.jsonl") if v.get("verdict")}
                todo = [r for r in rows if r["id"] not in answered]
                console.print(f"[dim]{alias}: {len(todo)} of {len(rows)} row(s) unanswered in "
                              f"{fill.name}[/]")
                if not todo:
                    console.print(f"[dim]{alias}: nothing to do[/]")
                    continue
            else:
                console.print(f"[dim]{alias}: no existing run of this condition — full pass[/]")
        summaries.append(await run_one(clients[provider], args, model, alias, todo, console,
                                       provider, fill))
    for client in clients.values():
        await client.close()

    title = "supported / contradicted / uncertain against the premises"
    if args.ablation == "oracle":
        title += "  [ORACLE: the extracted statements only]"
    if args.ablation == "no-premise":
        title += "  [NO PREMISES: anything but uncertain comes from prior knowledge]"
    table = Table(title=title, header_style="bold cyan")
    table.add_column("model", style="bold")
    table.add_column("ACCURACY", justify="right")
    for lab in LABELS:
        n = summaries[0]["n_by_gold"].get(lab) if summaries else None
        if n:
            table.add_column(f"{lab} (n={n})", justify="right")
    unscored = [lab for lab in UNSCORED_GOLD if summaries and summaries[0]["answers_on_unscored"].get(lab)]
    for lab in unscored:
        n = sum(summaries[0]["answers_on_unscored"][lab].values())
        table.add_column(f"{lab} (n={n}) T/U/F", justify="right")
    table.add_column("PAIR ACC", justify="right")
    table.add_column("no answer", justify="right")
    table.add_column("median lat", justify="right")
    table.add_column("spent now / full pass", justify="right")
    fmt = lambda v: f"{v:.1%}" if v is not None else "--"  # noqa: E731
    for s in sorted(summaries, key=lambda s: s["accuracy"] or 0, reverse=True):
        acc = s["accuracy"] or 0
        style = "bold green" if acc >= 0.6 else ("yellow" if acc >= 0.4 else "red")
        per_label = [fmt(s["accuracy_by_gold"].get(lab)) for lab in LABELS if s["n_by_gold"].get(lab)]
        pair = f"{fmt(s['pair_accuracy'])} ({s['pairs']})" if s["pairs"] else "--"
        table.add_row(
            s["model"], f"[{style}]{fmt(s['accuracy'])}[/]", *per_label,
            *("/".join(str(s["answers_on_unscored"].get(lab, {}).get(a, 0)) for a in ("true", "uncertain", "false"))
              for lab in unscored),
            pair,
            f"[red]{s['unanswered']}[/]" if s["unanswered"] else "0",
            f"{s['latency_s_median']:.1f}s" if s["latency_s_median"] else "--",
            f"{'~' if s.get('provider') == 'openai' else ''}${s['cost_usd_this_run']:.2f} ({s['live_calls']} calls) / ${s['cost_usd_total'] or 0:.2f}",
        )
    console.print()
    console.print(table)
    if any(s["unanswered"] for s in summaries):
        console.print("[red]some rows have no verdict (rate limits) — re-run to fill them in[/]")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Ask LLMs whether each conclusion follows from its premises.",
        epilog="Models: a model id (gpt-5.6-sol) or a short name: "
               + ", ".join(sorted(ALIASES)),
    )
    parser.add_argument("-m", "--model", dest="models", action="append", metavar="NAME",
                        help="model to run; repeat for several (default: luna)")
    parser.add_argument("--provider", choices=tuple(PROVIDERS), default="openai",
                        help="API to call (default: openai, the OpenAI API directly)")
    parser.add_argument("--dataset", type=Path, default=ROOT / "data/final/mainlogic.jsonl")
    parser.add_argument("--limit", type=int, help="only the first N rows")
    parser.add_argument("--ablation",
                        choices=("none", "no-premise", "oracle", "highlighted", "decoy"),
                        default="none",
                        help="no-premise: the conclusion with no premise documents at all; "
                             "oracle: only the extracted statements, not the papers; decoy: the P- row "
                             "with the planner's `unrelated` passages bracketed and the evidence "
                             "left unmarked, a control for highlighted; highlighted: "
                             "the whole papers with the located passages bracketed in place")
    parser.add_argument("--no-premise", dest="ablation", action="store_const", const="no-premise",
                        help="shorthand for --ablation no-premise")
    parser.add_argument("--concurrency", type=int, default=2)
    parser.add_argument("--resume", action="store_true",
                        help="judge only the rows this model has not answered yet, and merge them "
                             "into its existing run. Rows added to the dataset since that run are "
                             "unanswered, so this tops a model up instead of re-running it")
    parser.add_argument("--baseline", action="store_true",
                        help="the evidence-free probe: the conclusion alone, judged with the "
                             "plainest possible instruction. Shorthand for --ablation no-premise "
                             "--prompt baseline, and the user message carries no premise section")
    parser.add_argument("--fill", type=Path, default=None, metavar="RUN_DIR",
                        help="re-judge only the rows an existing run left unanswered, and merge "
                             "them into it in place")
    parser.add_argument("--prompt", choices=sorted(PROMPTS), default="default",
                        help="which instruction to use; a non-default arm lands in <prompt>_<model>_NNN")
    parser.add_argument("--sample", type=int, default=None,
                        help="judge only N complete cores, drawn by hash so two arms see the same rows")
    parser.add_argument("--seed", type=int, default=0, help="sample seed")
    parser.add_argument("--strict", action="store_true",
                        help="add one line to the instruction: judge STRICTLY from the premises, no "
                             "world knowledge. Runs land in strict_<model>_NNN")
    parser.add_argument("--no-pair-order", action="store_true",
                        help="judge rows in file order instead of grouping rows that share a "
                             "premise, which forfeits the provider's prefix cache")
    parser.add_argument("--timeout", type=float, default=600.0)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.WARNING,
                        format="%(levelname)-7s %(name)s: %(message)s")
    load_dotenv()
    return asyncio.run(run(args))


if __name__ == "__main__":
    sys.exit(main())
