<!-- fulltext source=arxiv_html slug=arXiv-2112.11446 fetched=2026-09-22T13:28:50+00:00 -->

\reportnumber

001

# Scaling Language Models: Methods, Analysis & Insights from Training Gopher

Jack W. Rae
   
Sebastian Borgeaud
   
Trevor Cai
   
Katie Millican
   
Jordan Hoffmann
   
Francis Song
   
John Aslanides
   
Sarah Henderson
   
Roman Ring
   
Susannah Young
   
Eliza Rutherford
   
Tom Hennigan
   
Jacob Menick
   
Albin Cassirer
   
Richard Powell
   
George van den Driessche
   
Lisa Anne Hendricks
   
Maribeth Rauh
   
Po-Sen Huang
   
Amelia Glaese
   
Johannes Welbl
   
Sumanth Dathathri
   
Saffron Huang
   
Jonathan Uesato
   
John Mellor
   
Irina Higgins
   
Antonia Creswell
   
Nat McAleese
   
Amy Wu
   
Erich Elsen
   
Siddhant Jayakumar
   
Elena Buchatskaya
   
David Budden
   
Esme Sutherland
   
Karen Simonyan
   
Michela Paganini
   
Laurent Sifre
   
Lena Martens
   
Xiang Lorraine Li
   
Adhiguna Kuncoro
   
Aida Nematzadeh
   
Elena Gribovskaya
   
Domenic Donato
   
Angeliki Lazaridou
   
Arthur Mensch
   
Jean-Baptiste Lespiau
   
Maria Tsimpoukelli
   
Nikolai Grigorev
   
Doug Fritz
   
Thibault Sottiaux
   
Mantas Pajarskas
   
Toby Pohlen
   
Zhitao Gong
   
Daniel Toyama
   
Cyprien de Masson d’Autume
   
Yujia Li
   
Tayfun Terzi
   
Vladimir Mikulik
   
Igor Babuschkin
   
Aidan Clark
   
Diego de Las Casas
   
Aurelia Guy
   
Chris Jones
   
James Bradbury
   
Matthew Johnson
   
Blake Hechtman
   
Laura Weidinger
   
Iason Gabriel
   
William Isaac
   
Ed Lockhart
   
Simon Osindero
   
Laura Rimell
   
Chris Dyer
   
Oriol Vinyals
   
Kareem Ayoub
   
Jeff Stanway
   
Lorrayne Bennett
   
Demis Hassabis
   
Koray Kavukcuoglu
   
Geoffrey Irving
Affiliation:

###### Abstract

Language modelling provides a step towards intelligent communication systems by harnessing large repositories of written human knowledge to better predict and understand the world. In this paper, we present an analysis of Transformer-based language model performance across a wide range of model scales — from models with tens of millions of parameters up to a 280 billion parameter model called Gopher. These models are evaluated on 152 diverse tasks, achieving state-of-the-art performance across the majority. Gains from scale are largest in areas such as reading comprehension, fact-checking, and the identification of toxic language, but logical and mathematical reasoning see less benefit. We provide a holistic analysis of the training dataset and model’s behaviour, covering the intersection of model scale with bias and toxicity. Finally we discuss the application of language models to AI safety and the mitigation of downstream harms.

###### keywords

Natural Language Processing, Language Models, Deep Learning

## 1 Introduction

Natural language communication is core to intelligence, as it allows ideas to be efficiently shared between humans or artificially intelligent systems.
The generality of language allows us to express many intelligence tasks as taking in natural language input and producing natural language output.

Autoregressive language modelling
— predicting the future of a text sequence from its past —
provides a simple yet powerful objective that admits formulation of numerous cognitive tasks. At the same time, it opens the door to plentiful training data: the internet, books, articles, code, and other writing.
However this training objective is only an approximation to any specific goal or application, since we predict everything in the sequence rather than only the aspects we care about.
Yet if we treat the resulting models with appropriate caution, we believe they will be a powerful tool to capture some of the richness of human intelligence.

Using language models as an ingredient towards intelligence contrasts with their original application: transferring text over a limited-bandwidth communication channel. Shannon’s Mathematical Theory of Communication ([Shannon, 1948](#bib.bib152)) linked the statistical modelling of natural language with compression, showing that measuring the cross entropy of a language model is equivalent to measuring its compression rate. Shannon fit early language models to real data via precomputed tables of text statistics ([Dewey, 1923](#bib.bib44)) relating model complexity to improved text compression alongside more realistic text generation.11
1
A sample from Shannon’s word-pair model: “the head and in frontal attack on an english writer that the character of this point is therefore another method for the letters that the time of who ever told the problem for an unexpected.” But the relation to intelligence was there from the start: Shannon posits that a sufficiently complex model will resemble human communication adequately, and the Imitation Game ([Turing, 1950](#bib.bib165)) cemented the link. The relation between data compression (via prediction) and intelligence has been further expanded upon since (see [Wolff (1982)](#bib.bib174); [Chater (1999)](#bib.bib33); [Legg and Hutter (2007)](#bib.bib99)).

A key driver towards better language models has been modern computing. From their pen-and-paper origins, language models have transformed in capacity and predictive power by the exponential rise in compute ([Moore et al., 1965](#bib.bib118)). In the 1990s and 2000s, $n$-gram models saw increases in scale and better smoothing approaches ([Ney et al., 1994](#bib.bib120)), including a 300 billion $n$-gram model trained on two trillion tokens of text ([Brants et al., 2007](#bib.bib22)). These models have been applied to speech recognition ([Jelinek, 1997](#bib.bib74)), spelling correction ([Brill and Moore, 2000](#bib.bib23)), machine translation ([Brown et al., 1990](#bib.bib24)), and many other areas. However $n$-gram models become statistically and computationally inefficient as the context length is increased, which limits the richness of language they can model.

In the past two decades language models have progressed to neural networks that capture the structure of language implicitly ([Bengio et al., 2003](#bib.bib11); [Mikolov et al., 2010](#bib.bib112); [Graves, 2013](#bib.bib56); [Jozefowicz et al., 2016](#bib.bib79); [Radford et al., 2019](#bib.bib129)).
Progress has been driven by both scale and network architecture ([Hochreiter and Schmidhuber, 1997](#bib.bib66); [Bahdanau et al., 2014](#bib.bib8); [Vaswani et al., 2017](#bib.bib166)).
rosenfeld2020a and [Kaplan et al. (2020)](#bib.bib80) independently found power laws relating cross entropy loss to model size for recurrent and Transformer neural language models respectively. The empirically predicted gains to scale were realised in practice by the Generative Pre-trained Transformer 3 (GPT-3, [Brown et al. (2020)](#bib.bib25)), a 175 billion parameter Transformer trained over 300 billion tokens of text, which consumed zettaflops of compute to train — an order of magnitude beyond prior work ([Rosset, 2020](#bib.bib139)). GPT-3 demonstrated unprecedented generation quality alongside generalist capabilities across many Natural Language Processing (NLP) tasks — notably when prompted with examples (termed few-shot prompting).

In this paper we describe a protocol for training a state-of-the-art large language model and present a 280 billion parameter model called Gopher. We outline the methods of architecture specification, optimisation, infrastructure, and the curation of a high-quality text dataset MassiveText in [Section 3](#S3 "3 Method ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"). We perform a broad analysis of benchmark performance across 152 tasks that examine several diverse aspects of intelligence, and summarise the key results in [Section 4](#S4 "4 Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"). We see that Gopher lifts the performance over current state-of-the-art language models across roughly 81% of tasks containing comparable results, notably in knowledge-intensive domains such as fact checking and general knowledge.

As harmful content occurs both in Gopher’s training set and in many potential downstream applications, we examine model toxicity and bias in [Section 5](#S5 "5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") with a focus on how scale influences these properties. We find larger models are more likely to generate toxic responses when provided with toxic prompts, but they can also more accurately classify toxicity.
We also analyse Gopher in a dialogue-interaction setting in [Section 6](#S6 "6 Dialogue ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") via prompting and present several transcripts to demonstrate qualitative capabilities and limitations of the model.

Finally, we discuss the ethical and safe application of these models including which types of undesirable behaviour to mitigate before and after training in [Section 7](#S7 "7 Discussion ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"). We discuss application-driven safety and the potential for language models to accelerate research towards safer intelligent technology.

## 2 Background

Language modelling refers to modelling the probability of text $P(S)$ where $S$ can be a sentence, paragraph, or document depending on the application. This is done by tokenizing the string: mapping it to a sequence of integer-valued tokens: $g(S)=X=(X\_{1},X\_{2},\ldots,X\_{n})\in V^{n}$ where $V$ is the vocabulary (a finite set of positive integers) and $n$ is the resulting sequence length, and modelling $X$. Tokenization can be open-vocabulary where any string can be uniquely tokenized, e.g., byte-level modelling, or closed-vocabulary where only a subset of text can be uniquely represented, e.g., a list of words and a singular out-of-vocabulary token. We employ open-vocabulary tokenization via a mixture of byte-pair encoding (BPE) with a backoff to UTF-8 bytes in the style of [Radford et al. (2018)](#bib.bib128).

The typical way to model the token sequence $X$ is via the chain rule $P(X)=P(X\_{1},X\_{2},\ldots,X\_{n})=\prod\_{i=1}^{n}P(X\_{i}|X\_{<i})$. This is also known as autoregressive sequence modelling, because at each time-step the future (in this case, future token) is predicted based upon the past context. Whilst there are other objectives towards modelling a sequence, such as modelling masked tokens given bi-directional context ([Mikolov et al., 2013](#bib.bib114); [Devlin et al., 2019](#bib.bib43)) and modelling all permutations of the sequence ([Yang et al., 2019](#bib.bib179)) we focus on autoregressive modelling due to its strong performance and simplicity. We shall refer to language models hereon as the function approximators to perform next-token prediction.

A class of neural networks known as Transformers ([Vaswani et al., 2017](#bib.bib166)) have demonstrated state-of-the-art language model performance in recent years ([Dai et al., 2019](#bib.bib40); [Radford et al., 2018](#bib.bib128); [Radford et al., 2019](#bib.bib129)) and this is the architecture we focus on in this paper. There has been a trend of scaling the combination of training data, model size (measured in parameters) and training computation to obtain models with improved performance across academic and industrial benchmarks. Notable models along this progression include the 345 million parameter BERT ([Devlin et al., 2019](#bib.bib43)) performing strongly across a wide benchmark of language classification tasks, the 1.5 billion parameter GPT-2 ([Radford et al., 2018](#bib.bib128)) and 8.3 billion parameter Megatron ([Shoeybi et al., 2019](#bib.bib156)) displaying progressively superior zero-shot language model performance, the 11 billion parameter T5 ([Raffel et al., 2020a](#bib.bib131)) which advanced transfer learning and performance on several closed-book question answering tasks, and the aforementioned 175 billion parameter GPT-3. The moniker Large Language Models (LLMs) has become popular to describe this generation of larger models.

Since GPT-3 there has been a 178B parameter Transformer language model Jurassic-1 ([Lieber et al., 2021](#bib.bib104)) which uses a diverse training set and a larger tokenizer vocabulary size, along with an announced 530B Megatron-Turing NLG ([Kharya and Alvi, 2021](#bib.bib85)) which trains on a released dataset (The Pile, [Gao et al. (2020)](#bib.bib53)) (which we evaluate on) and has reported some tentative performance numbers.
There have also been Transformer variants which incorporate a sparse mixture of experts ([Fedus et al., 2021](#bib.bib49); [Roller et al., 2021b](#bib.bib138)) to increase the model size (in some cases to trillions of parameters) with more modest compute budgets.
Other recent LLMs include two models (FLAN and T0) fine-tuned on instructions for an array of down-stream tasks ([Sanh et al., 2021](#bib.bib146); [Wei et al., 2021](#bib.bib170)) which improves performance to unseen tasks — these ideas are complementary to the initial task of building a powerful language model but we compare performance nonetheless where possible.

## 3 Method

### 3.1 Models

In this paper we present results on six Transformer language models ranging from 44 million to 280 billion parameters, with the architectural details displayed in [Table 1](#S3.T1 "Table 1 ‣ 3.1 Models ‣ 3 Method ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"). We refer to the largest as Gopher and the entire set of models as the Gopher family.

We use the autoregressive Transformer architecture detailed in [Radford et al. (2019)](#bib.bib129) with two modifications: we use RMSNorm ([Zhang and Sennrich, 2019](#bib.bib185)) instead of LayerNorm ([Ba et al., 2016](#bib.bib7)),
and we use the relative positional encoding scheme from [Dai et al. (2019)](#bib.bib40) rather than absolute positional encodings.
Relative encodings permit us to evaluate on longer sequences than we trained on, which improves the modelling of articles and books as shown in [Section D.6](#A4.SS6 "D.6 Scaling Context Length ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
We tokenize the text using SentencePiece ([Kudo and Richardson, 2018](#bib.bib91)) with a vocabulary of 32,000 and use a byte-level backoff to support open-vocabulary modelling.
The Gopher model card ([Mitchell et al., 2019](#bib.bib116)) is included in [Appendix B](#A2 "Appendix B Gopher Model Card ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

| Model | Layers | Number Heads | Key/Value Size | dmodel | Max LR | Batch Size |
| --- | --- | --- | --- | --- | --- | --- |
| 44M | 8 | 16 | 32 | 512 | $6\times 10^{-4}$ | 0.25M |
| 117M | 12 | 12 | 64 | 768 | $6\times 10^{-4}$ | 0.25M |
| 417M | 12 | 12 | 128 | 1,536 | $2\times 10^{-4}$ | 0.25M |
| 1.4B | 24 | 16 | 128 | 2,048 | $2\times 10^{-4}$ | 0.25M |
| 7.1B | 32 | 32 | 128 | 4,096 | $1.2\times 10^{-4}$ | 2M |
| Gopher 280B | 80 | 128 | 128 | 16,384 | $4\times 10^{-5}$ | 3M $\rightarrow$ 6M |

Table 1: Model architecture details. For each model, we list the number of layers, the key/value size, the bottleneck activation size d${}\_{\text{model}}$, the maximum learning rate, and the batch size. The feed-forward size is always $4\times\textrm{d}\_{\textrm{model}}$.

### 3.2 Training

We train all models for 300 billion tokens with a 2048 token context window, using the Adam ([Kingma and Ba, 2014](#bib.bib88)) optimiser.
We warm-up the learning rate from $10^{-7}$ to the maximum learning rate over the first 1500 steps, and then decay it 10$\times$ using a cosine schedule.
As we increase model size, we decrease the maximum learning rate and increase the number of tokens in each batch, as shown in [Table 1](#S3.T1 "Table 1 ‣ 3.1 Models ‣ 3 Method ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
Furthermore, we increase Gopher’s batch size from three to six million tokens per batch during training.
We clip gradients based on the global gradient norm using a clipping value of 1.
However, for the 7.1B model and for Gopher we reduce this to 0.25 for improved stability.

We incorporate the bfloat16 numerical format to reduce memory and increase training throughput. Models smaller than 7.1B are trained with mixed precision float32 parameters and bfloat16 activations ([Micikevicius et al., 2018](#bib.bib111)), while 7.1B and 280B use bfloat16 activations and parameters. bfloat16 parameters are updated using stochastic rounding to maintain stability ([Gupta et al., 2015](#bib.bib58)).
We subsequently found that stochastic rounding does not fully recover mixed precision training performance; more details can be found in [Appendix C](#A3 "Appendix C Lessons Learned ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

### 3.3 Infrastructure

We built our training and evaluation codebase with JAX ([Bradbury et al., 2018](#bib.bib21)) and Haiku ([Hennigan et al., 2020](#bib.bib64)).
In particular, we use JAX’s pmap transformation to efficiently express both data and model parallelism.
We trained and evaluated all models on TPUv3 chips ([Jouppi et al., 2020](#bib.bib78)).

The half-precision parameters and single-precision Adam state for Gopher occupy 2.5 TiB, which far exceeds the 16 GiB of memory available on each TPUv3 core. To address these memory concerns, we use optimiser state partitioning ([Rajbhandari et al., 2020](#bib.bib134)), model parallelism ([Shoeybi et al., 2019](#bib.bib156)), and rematerialisation ([Griewank and Walther, 2000](#bib.bib57)) to partition the model state and reduce the activations so that they fit in TPU memory.

We find that both data and model parallelism are low-overhead on TPUv3s due to their fast cross-chip communication and only incur a 10% overhead when training Gopher. Therefore, we find that pipelining ([Huang et al., 2019](#bib.bib69)) is not necessary on TPUs until the training scale exceeds the 1024-chip “pod”, which greatly simplifies training mid-sized models.
However, pipelining is an efficient parallelism method on commodity networks due to its low communication volume, so is well suited to connecting multiple TPU pods.
In summary, we train Gopher by using model and data parallelism within TPU pods and pipelining across them. We verified through simulation that this topology was sensible for our hardware ([Schaarschmidt et al., 2021](#bib.bib148)); see  for details.

### 3.4 Training Dataset

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | Disk Size | Documents | Tokens | Sampling proportion |
| MassiveWeb | 1.9 TB | 604M | 506B | 48% |
| Books | 2.1 TB | 4M | 560B | 27% |
| C4 | 0.75 TB | 361M | 182B | 10% |
| News | 2.7 TB | 1.1B | 676B | 10% |
| GitHub | 3.1 TB | 142M | 422B | 3% |
| Wikipedia | 0.001 TB | 6M | 4B | 2% |

Table 2: MassiveText data makeup. For each subset of MassiveText, we list its total disk size, its number of documents, and its number of SentencePiece tokens. During training we sample from MassiveText non-uniformly, using the sampling proportion shown in the right-most column.

We train the Gopher family of models on MassiveText, a collection of large English-language text datasets from multiple sources: web pages, books, news articles, and code. [Table 2](#S3.T2 "Table 2 ‣ 3.4 Training Dataset ‣ 3 Method ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") details the constituent datasets. Our data pipeline ([Section A.1.1](#A1.SS1.SSS1 "A.1.1 Pipeline stages ‣ A.1 Dataset Pipeline ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")) includes text quality filtering, removal of repetitious text, deduplication of similar documents, and removal of documents with significant test-set overlap.
We find that successive stages of this pipeline improve language model downstream performance ([Section A.3.2](#A1.SS3.SSS2 "A.3.2 Iterative Refinement of MassiveWeb ‣ A.3 Dataset Ablations ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")), emphasising the importance of dataset quality.

Overall, MassiveText contains 2.35 billion documents, or about 10.5 TB of text.
Since we train Gopher on 300B tokens (12.8% of the tokens in the dataset), we sub-sample from MassiveText with sampling proportions specified per subset (books, news, etc.). We tune these sampling proportions to maximise downstream performance (see [Section A.3.1](#A1.SS3.SSS1 "A.3.1 MassiveText Subsets Weighting ‣ A.3 Dataset Ablations ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") for details). The largest sampling subset is our curated web-text corpus MassiveWeb, which we find to improve downstream performance relative to existing web-text datasets such as C4 ([Raffel et al., 2020b](#bib.bib132)) in [Figure A5](#A1.F5 "Figure A5 ‣ A.3.2 Iterative Refinement of MassiveWeb ‣ A.3 Dataset Ablations ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
We give further details of MassiveText in [Appendix A](#A1 "Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") and provide the MassiveText datasheet in [Table A3](#A1.T3 "Table A3 ‣ A.5 MassiveText Datasheet ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

## 4 Results

We compile the performance of Gopher and its family of smaller models across 152 tasks. We compare these results to prior state-of-the-art (SOTA) performance for language models (124 tasks with published LM performance), supervised approaches which make use of task-specific data, and human performance where available. In this section we present a summary of key findings, and refer to [Appendix D](#A4 "Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") for the full set of results and task-specific methodology.

### 4.1 Task Selection

|  |  |  |
| --- | --- | --- |
|  | # Tasks | Examples |
| Language Modelling | 20 | WikiText-103, The Pile: PG-19, arXiv, FreeLaw, $\ldots$ |
| Reading Comprehension | 3 | RACE-m, RACE-h, LAMBADA |
| Fact Checking | 3 | FEVER (2-way & 3-way), MultiFC |
| Question Answering | 3 | Natural Questions, TriviaQA, TruthfulQA |
| Common Sense | 4 | HellaSwag, Winogrande, PIQA, SIQA |
| MMLU | 57 | High School Chemistry, Atronomy, Clinical Knowledge, $\ldots$ |
| BIG-bench | 62 | Causal Judgement, Epistemic Reasoning, Temporal Sequences, $\ldots$ |

Table 3: Evaluation Tasks. We compile results for the Gopher family of models on 152 tasks.

We build a profile of language model performance that spans mathematics, common sense, logical reasoning, general knowledge, scientific understanding, ethics, and reading comprehension — alongside conventional language modelling benchmarks.
We include composite benchmarks (such as [BIG-bench collaboration (2021)](#bib.bib12)) which contain a mixture of tasks, alongside a number of established targeted benchmarks such as RACE for reading comprehension ([Lai et al., 2017](#bib.bib93)) and FEVER for fact-checking ([Thorne et al., 2018](#bib.bib164)), among others. We list our task sources in [Table 3](#S4.T3 "Table 3 ‣ 4.1 Task Selection ‣ 4 Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

We select tasks that require the model to estimate the probability of target text as we find this to be a general interface that supports the probing of knowledge and reasoning capabilities.
For language modelling tasks we calculate the bits per byte (BPB), a compression measure where a lower value indicates a higher probability placed on the correct continuation. All other tasks follow a multiple-choice format, where the model outputs a probability to each multiple-choice response given a context and question, and we select the response with the highest probability. Here, we measure the accuracy of a correct response.

We filter out training documents that are very similar to test-set instances for tasks that were created before MassiveText (November 2020) as described in [Section A.1.1](#A1.SS1.SSS1.Px5 "Test-set Filtering (All subsets) ‣ A.1.1 Pipeline stages ‣ A.1 Dataset Pipeline ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"). Furthermore some tasks have been designed to use unique test-set problem statements that should not benefit from pre-existing text data — such as BIG-bench. However we caution that there may be test set leakage within our training set; we discuss the challenges of test-set leakage and generalisation in [Section D.4](#A4.SS4 "D.4 Filtering Test-Set Documents ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

### 4.2 Comparisons with State of the Art

In [Figure 1](#S4.F1 "Figure 1 ‣ 4.2 Comparisons with State of the Art ‣ 4 Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") we present an overview of Gopher results with comparisons to state-of-the-art language model performance. Results are comparable across 124 tasks and we plot the percent change in performance metric (higher is better) of Gopher versus the current LM SOTA.22
2
Gopher comprises both our model and our training dataset. It is still informative to compare Gopher to previous SOTA LM approaches. Additionally, in this paper we also discuss the performance of Gopher as we vary the model capacity while holding the dataset fixed.
Gopher outperforms the current state-of-the-art for 100 tasks (81% of all tasks). The baseline model includes LLMs such as GPT-3 (175B parameters) ([Brown et al., 2020](#bib.bib25)), Jurassic-1 ([Lieber et al., 2021](#bib.bib104)) (178B parameters), and Megatron-Turing NLG (530B parameters) ([Kharya and Alvi, 2021](#bib.bib85)); the exact baseline is specified per task in [Figure A8](#A4.F8 "Figure A8 ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

We find that Gopher displays the most uniform improvement across reading comprehension, humanities, ethics, STEM and medicine categories. We see a general improvement on fact-checking.
For common sense reasoning, logical reasoning, and maths we see much smaller performance improvements and several tasks that have a deterioration in performance.
The general trend is less improvement in reasoning-heavy tasks (e.g., Abstract Algebra) and a larger and more consistent improvement in knowledge-intensive tests (e.g., General Knowledge).
Next is a discussion of a few specific sets of results.

For language model benchmarks, we expand the relative performance results of Gopher versus the current 178B SOTA model Jurassic-1 and 175B GPT-3 in [Figure 2](#S4.F2 "Figure 2 ‣ 4.2 Comparisons with State of the Art ‣ 4 Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"). Jurassic-1 is an LLM trained with an emphasis on large-vocabulary training and has generally outperformed GPT-3 at a very similar parameter size. We see Gopher does not outperform state-of-the-art on 8 of 19 tasks, under-performing on Ubuntu IRC and DM Mathematics in particular, possibly due to a poor tokenizer representation for numbers. Gopher demonstrates improved modelling on 11 of 19 tasks, in particular books and articles (Books3, PG-19, arXiv, etc.). This performance gain may be due to the heavy use of book data in MassiveText, with a sampling proportion of 27% in total (e.g., versus GPT-3’s 16%).

|  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 417M | 1.4B | 7.1B | Gopher 280B | GPT-3 175B | Megatron-Turing 530B | ALBERT (ensemble) | Amazon Turk | Human Ceiling |
| RACE-h | 27.2 | 26.0 | 30.6 | 71.6 | 46.8 | 47.9 | 90.5 | 69.4 | 94.2 |
| RACE-m | 26.2 | 25.0 | 31.8 | 75.1 | 58.1 | n/a | 93.6 | 85.1 | 95.4 |

Table 4: RACE reading comprehension. Accuracy for few-shot models: Gopher, GPT-3 ([Brown et al., 2020](#bib.bib25)), Megatron-Turing ([Kharya and Alvi, 2021](#bib.bib85)). Gopher extends performance significantly. Comparison with supervised SOTA: ALBERT (ensemble) result from [Jiang et al. (2020)](#bib.bib75). Amazon Turk and Human Ceiling (obtained by restricting to unambiguous questions with correctly labeled answers) accuracy from [Lai et al. (2017)](#bib.bib93).

Figure 1: Gopher (280B) vs LM SOTA. An overview of the percentage change in performance metric (higher is better) of Gopher versus state-of-the-art language model performance across 124 tasks. Each bar represents a task, here we clip the maximum relative improvement to 120%. In total Gopher shows an improvement across 100 / 124.
The best-published results include (175B) GPT-3, (178B) Jurassic-1, and (530B) Megatron-Turing NLG. For full comparison including supervised and human performance see [Figure A8](#A4.F8 "Figure A8 ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

We highlight two reading comprehension tasks RACE-m and RACE-h, multiple-choice exams pitched at a middle-school and high-school level respectively. Inspecting the accuracy in [Table 4](#S4.T4 "Table 4 ‣ 4.2 Comparisons with State of the Art ‣ 4 Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") we see Gopher extend upon the current LM SOTA for high-school reading comprehension (47.9% Megatron-Turing NLG $\rightarrow$ 71.6% Gopher) and the middle-school comprehension accuracy (58.1% GPT-3 $\rightarrow$ 75.1% Gopher). The high-school reading comprehension level approaches human-rater performance. Smaller models from the Gopher family do not perform as well on these tasks, which suggests that data alone does not explain the performance difference — the combination of scale and data is crucial. All models are still far from human-ceiling performance (around 95%) and supervised state-of-the-art (>90%) which was obtained using a smaller 223M parameter ALBERT-XXL model fine-tuned on the dataset ([Jiang et al., 2020](#bib.bib75)). It is possible supervised fine-tuning leads to greater reading comprehension, but it is also plausible the datasets contain exploitable statistics which can lead to high accuracy — as has been recently discovered for several common-sense reasoning benchmarks ([Li et al., 2021](#bib.bib103)).

Figure 2: Language Modelling Comparisons with SOTA. Comparison of Gopher to the current SOTA models on various language modelling tasks, including many from The Pile ([Gao et al., 2020](#bib.bib53)). The superscript (1) indicates the prior SOTA was Jurassic-1 and (2) indicates GPT-3. Gopher achieves state-of-the-art performance on 11 out of 19 datasets with the largest improvements on books and articles.

Figure 3: Scaling curves for FEVER. In the claim-only setting (closed-book) there is a persistent trend in three-way classificaton accuracy with parameter scale. Breaking down the three classes into two pairs, scale benefits mostly the ability to distinguish SUPPORTED vs REFUTED, but not REFUTED versus NOTENOUGHINFO. When gold evidence is provided (open-book) there is a small benefit from 7.1B to 280B Gopher and performance slightly exceeds the supervised SOTA ([Kruengkrai et al., 2021](#bib.bib90)).

For some of the most well-studied common sense reasoning tasks: Winogrande, HellaSwag and PIQA, Gopher is outperformed by the larger Megatron-Turing NLG by a small amount (1.2%, 0.2% and 4.1% respectively), but all LM approaches trail human-level performance considerably (). As with the mathematics tasks, this suggests that these models have limited reasoning capabilities.

We next highlight fact-checking. This is an important problem within the domain of tackling misinformation. We find that Gopher outperforms supervised SOTA approaches on the well-studied FEVER fact-checking benchmark when evidence is supplied. We see across model sizes in [Figure 3](#S4.F3 "Figure 3 ‣ 4.2 Comparisons with State of the Art ‣ 4 Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") that scale improves both the checking of facts given gold evidence alongside the ‘closed book’ checking of facts with a claim only. However, larger scale does not benefit the classification of facts which are unknown versus false, implying that larger models improve fact checking performance by knowing more facts versus forming a deeper understanding of misinformation at this stage.

|  |  |
| --- | --- |
| Random | 25.0% |
| GPT-21 | 32.4% |
| Average human rater1 | 34.5% |
| GPT-3 5-shot1 | 43.9% |
| UnifiedQA1 | 48.9% |
| Gopher 5-shot | 60.0% |
| Average human expert performance1 | 89.8% |
| June 2022 Forecast2 | 57.1% |
| June 2023 Forecast2 | 63.4% |

Table 5: Massive Multitask Language Understanding (MMLU). Average accuracy over 57 tasks with model and human accuracy comparisons from 1: [Hendrycks et al. (2020)](#bib.bib63). Human rater performance is obtained using Mechanical Turk and average human expert performance is estimated per task based upon published exam results and averaged. Gopher improves over the prior supervised SOTA models by a considerable margin (>30%) however it is far from human expert. We also include the average prediction for SOTA accuracy in June 2022 and 2023 made by 73 competitive human forecasters (2: [Steinhardt (2021)](#bib.bib161)). Gopher is situated between the 2022 and 2023 forecast.

Moving beyond per-task performance, we display the average accuracy across the 57 tasks in MMLU ([Table 5](#S4.T5 "Table 5 ‣ 4.2 Comparisons with State of the Art ‣ 4 Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")). These tasks consist of real-world human exams covering a range of academic subjects.
We have comparisons from GPT-3 ([Brown et al., 2020](#bib.bib25)), and a 11B T5 model fine-tuned on question tasks called UnifiedQA ([Khashabi et al., 2020](#bib.bib86)). These baseline model results along with human rater and expert performance were collected by [Hendrycks et al. (2020)](#bib.bib63). In [Table 5](#S4.T5 "Table 5 ‣ 4.2 Comparisons with State of the Art ‣ 4 Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") we see that Gopher achieves an overall accuracy of 60%, well above GPT-3’s 43.9% and UnifiedQA’s 48.9%.
Whilst this lifts the known performance of the pure language-model approach, it still trails the estimated human expert performance of 89.8%. We also display how this performance contrasts with human expectations.
From a competitive forecasting platform Hypermind33
3
<https://prod.hypermind.com/ngdp/en/showcase2/showcase.html?sc=JSAI#q4>, human forecasters aim to predict the accuracy of machine learning systems on this benchmark by set dates for prizes — according to the September 2021 average forecast, Gopher-level performance was expected between June 2022 and June 2023.

We conclude that Gopher lifts the baseline performance of a language-model approach across a wide set of tasks. In some settings (e.g., RACE reading comprehension and FEVER fact-checking) Gopher nears human rater performance or the performance of supervised models designed for particular problem domains. However for a few categories of tasks (e.g., mathematical reasoning and common-sense) there is less of an improvement and this may indicate a limitation to the large-scale language model approach. Next, we consider the topic of model scale in isolation.

### 4.3 Performance Improvements with Scale

Next, we investigate which types of tasks benefit from scaling model size. In this section we compare the performance of Gopher (280B) to smaller models ($\leq$ 7.1B). Because the Gopher family of models are all trained on the same dataset for the same number of tokens, this allows us to isolate the effect of scaling parameters and training compute for each task.

We compute the relative performance improvement of Gopher (280B) versus the best performance up to 7.1B over all 152 tasks.
The most performant smaller Gopher family model is usually, but not always, our 7.1B model.
We find that Gopher demonstrates a performance improvement on the vast majority of tasks – only $16$ (10.5%) had zero or no performance gains.
In contrast, $57$ (37.5%) tasks had small improvements, with relative performance increases of up to 25%, and 79 (51.2%) tasks had significant improvements of over 25%. We then visualise relative performance improvement by task category in [Figure 4](#S4.F4 "Figure 4 ‣ 4.3 Performance Improvements with Scale ‣ 4 Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

Figure 4: 280B vs best performance up to 7.1B across different tasks.
We compare the performance of Gopher to the best performance of our smaller models up to 7.1B.
In nearly every case, Gopher outperforms the best smaller model’s performance. Small gains come from either scale not improving results substantially or the smaller models already being very performant.
Language modelling improvements are in BPB and the rest are in terms of accuracy.

Some of the largest benefits of scale are seen in the Medicine, Science, Technology, Social Sciences, and the Humanities task categories.
These same categories are also where we see the greatest performance improvement over LM SOTA, as described in the previous section. Highlighting some specific tasks:
for Figure of Speech Detection from BIG-bench we obtain the largest gains– a 314% increase.
Gopher achieved an impressive 52.7% accuracy whereas the 7.1B model achieved only 16.8% accuracy.
Gopher also dramatically improves over the smaller models in Logical Args, Marketing, and Medical Genetics.
For the TruthfulQA benchmark ([Lin et al., 2021b](#bib.bib106)) we find performance improvement with scale (from 1.4B to 280B), despite scale appearing to hurt performance for several other model families such as GPT-J, GPT-2, T5, GPT-3. Furthermore, 280B is the first model to demonstrate performance significantly beyond random guessing on the multiple-choice TruthfulQA task formulation (more details in ).
These results highlight that on some tasks, scale seems to “unlock” the ability of a model to significantly improve performance on particular tasks.

On the other hand, we find that scale has a reduced benefit for tasks in the Maths, Logical Reasoning, and Common Sense categories.
Our results suggest that for certain flavours of mathematical or logical reasoning tasks, it is unlikely that scale alone will lead to performance breakthroughs.
In some cases Gopher has a lower performance than smaller models– examples of which include Abstract Algebra and Temporal Sequences from BIG-bench, and High School Mathematics from MMLU.
On the other hand, the modest performance gains in common sense tasks largely come from relatively strong performance from the smaller models, limiting the room for relative improvement.
While language modelling tasks see the smallest average improvements, this is due to the performance metric measured in BPB rather than accuracy and greatly limits the possible relative gains.

By comparing Gopher to our smaller models, we are able to specifically ask questions about the impact of model scale.
We conclude that while model scale plays an important role for improvements across the vast majority of tasks, the gains are not equally distributed.
Many academic subjects, along with general knowledge, see large improvements come from scale alone.
However, this analysis also highlights areas where model scale alone is not enough, or where the gains from scale are more modest– specifically some mathematical and logical reasoning tasks.
By combining these scaling results with the comparisons of Gopher to LM SOTA, we see that scale and the dataset are both contributing to Gopher’s strong performance in these domains.
In the next section we investigate various properties of the model relating to toxic content generation and classification, the modelling of biases, and the representation of dialects.

## 5 Toxicity and Bias Analysis

Alongside the benefits of scaling language models, it is crucial to analyse how scale impacts potentially harmful behaviour. Here we study the behaviour of our language models with respect to problematic outputs and biases.
We investigate the tendency of models to produce toxic output, to recognise toxic text, to display distributional bias in discourse about different groups of people, and to model subgroup dialects.
For each question we consider variation across model scale.

We choose evaluations and metrics which are commonly used in the field.
However, various work has discussed the limitations of current metrics and evaluations ([Blodgett et al., 2021](#bib.bib17); [Welbl et al., 2021](#bib.bib172); [Xu et al., 2021a](#bib.bib176); [Blodgett et al., 2020](#bib.bib16); [Sheng et al., 2019](#bib.bib154)) and our analysis has uncovered further caveats, which we highlight in the following sections and [Section 7.2](#S7.SS2 "7.2 Challenges in Toxicity and Bias ‣ 7 Discussion ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
We include these measures despite their shortcomings to underscore the importance of tackling these challenges and to highlight specific areas for future work, rather than to establish these particular approaches as best practice.

### 5.1 Toxicity

In the Sections [5.1.1](#S5.SS1.SSS1 "5.1.1 Generation Analysis ‣ 5.1 Toxicity ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") and [5.1.2](#S5.SS1.SSS2 "5.1.2 Classification Analysis ‣ 5.1 Toxicity ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"), we rely on the widely used and commercially deployed Perspective API 44
4
Perspective API was created by Jigsaw and is available at <https://perspectiveapi.com>.
classifier to study the toxicity of text generated by LMs, and associated CivilComments dataset for studying models’ ability to detect toxic text.
Accordingly, we adopt their definition of toxicity as ‘‘a rude, disrespectful or unreasonable comment that is likely to make someone leave a discussion.’’55
5
Note that the notion of toxicity involves subjective and ambiguous elements. What is perceived as toxic depends on conversation setting, as well as cultural and societal norms, and can be underspecified in an LM context.

#### 5.1.1 Generation Analysis

Our toxicity analysis of text generated by LMs follows the methodology used in [Gehman et al. (2020)](#bib.bib55); [Welbl et al. (2021)](#bib.bib172).
We use Perspective API to obtain toxicity scores for LM prompts and continuations.
We analyse the toxicity of LM outputs when sampling is conditioned on a set of prompts and when it’s unconditional (i.e. unprompted), similar to [Welbl et al. (2021)](#bib.bib172). Conditional generation allows us to analyse how the model responds to prompts that have varying toxicity scores. Prompts are from the RealToxicityPrompts (RTP) dataset ([Gehman et al., 2020](#bib.bib55)), which contains 100k naturally occurring, sentence-level prompts derived from a large corpus of English web text.
We sample 10% of the 100k RTP prompts for efficiency and generate 25 continuations per prompt.

(a) Generation analysis.

(b) Classification analysis.

Figure 5: Toxicity analyses.
(a) Toxicity of text generated by LMs, bucketed by prompt toxicity using the RTP dataset. Error bars show 99% confidence interval.
(b) Few-shot toxicity classification on the CivilComments dataset.
Larger models are better at classifying toxic text.

The continuation toxicity of larger models is more consistent with prompt toxicity than for smaller models ([5(a)](#S5.F5.sf1 "5(a) ‣ Figure 5 ‣ 5.1.1 Generation Analysis ‣ 5.1 Toxicity ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")).
When prompted, as the input toxicity increases, larger models respond with greater toxicity, plateauing near 7.1B parameters. This suggests that more parameters increase the model’s ability to respond like-for-like to inputs.

For unprompted samples, the toxicity is low and does not increase with model size. Levels are slightly lower than in the training data (), i.e. when unprompted, the LM does not amplify training data toxicity.
More details on our toxicity evaluation methodology, results and metrics can be found in .

#### 5.1.2 Classification Analysis

We evaluate the models’ ability to detect toxic text in the few-shot setting, in a manner similar to [Schick et al. (2021)](#bib.bib149), on the CivilComments dataset ([Borkan et al., 2019](#bib.bib20)) (see  for details).
We observe that the model’s ability to classify text for toxicity increases with scale in few-shot settings ([5(b)](#S5.F5.sf2 "5(b) ‣ Figure 5 ‣ 5.1.1 Generation Analysis ‣ 5.1 Toxicity ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")).
The smaller models perform comparably or worse than a random classifier (which would achieve an AUC of 0.5).
The largest model achieves an AUC of around $0.76$ in the 20-shot setting, significantly improving on the smaller models ([5(b)](#S5.F5.sf2 "5(b) ‣ Figure 5 ‣ 5.1.1 Generation Analysis ‣ 5.1 Toxicity ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")).
We note that while the state-of-the-art for toxicity detection in the few-shot setting is not well established, our performance is well below that
of state of the art classifiers
trained specifically for toxicity detection
([Borkan et al., 2019](#bib.bib20)).

In ,
we further explore whether large language models used for few-shot toxicity classification exhibit subgroup bias.
We measure unintended classifier bias using the 280B model with metrics introduced in [Borkan et al. (2019)](#bib.bib20)
and find that the model is prone to bias against subgroups in different ways.
Thus, while language models can be a powerful tool for few-shot classification (especially important in tasks with data that is difficult to annotate), outcomes are not necessarily fair across subgroups.
More work is needed to understand how to best mitigate these biases, and caution must be exercised when optimising for improvements in their toxicity classification capabilities.

### 5.2 Distributional Bias

We define distributional biases as biases which are not apparent in a single sample, but emerge over many samples.
For example, whereas “The woman is a nurse” is not a problematic sentence, it can be problematic if the model disproportionately associates women with certain occupations.
As discussed in [Sheng et al. (2021)](#bib.bib155), distributional biases in language models can have both negative representational impacts (e.g., [Kay et al. (2015)](#bib.bib82)) and allocational impacts (e.g., [Dastin (2018)](#bib.bib41)).
To investigate distributional biases in our model, we measure
stereotypical associations between gender and occupation, the distribution of sentiment in samples conditioned on different social groups, and perplexity on different dialects.
Whereas performance across many language tasks increases with scale, we find that simply increasing model size does not remove biased language.
Indeed, we expect models trained with a standard cross-entropy objective to reflect biases in our training data.

Progress in this space will require challenging cross-disciplinary work to outline desirable behaviour, measure and interpret model outputs, and design novel mitigations, as demonstrated by these results and the significant limitations of the following methods, discussed in [Section 7.2](#S7.SS2 "7.2 Challenges in Toxicity and Bias ‣ 7 Discussion ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

#### 5.2.1 Gender and Occupation Bias

We study gender and occupation bias via two different evaluations.
First, we measure the probability of gendered words following different occupation contexts.
Second, we evaluate on the Winogender coreference resolution dataset ([Rudinger et al., 2018](#bib.bib140)), where similar coreference accuracy across different pronouns indicates less gender bias.
In our evaluation, we primarily compare performance across male and female gendered terms,
but acknowledge these terms do not represent all possible gender identities ([Cao and Daumé, 2021](#bib.bib30)).

Gender Word Probability To measure how probable different gender words are in different occupation contexts, we follow a setup similar to [Brown et al. (2020)](#bib.bib25).
We input an occupation prompt like “The {occupation} was a” into our model and compute a gender bias metric by comparing the probabilities of the prompt being followed by either male or female gendered terms.

[6(a)](#S5.F6.sf1 "6(a) ‣ Figure 6 ‣ 5.2.1 Gender and Occupation Bias ‣ 5.2 Distributional Bias ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")reports our probability based gender bias metric as a function of model size for two different templates (“The {occupation} was a {gender}” and “The {occupation} is a {gender}”).
Overall, we do not find a consistent correlation between model size and bias.
Furthermore, we find that apparently unrelated choices in template (changing “was” to “is”) can alter the measured bias.
Additionally, choice of gender words also impacts results; if we only use the terms “male” and “female,” gender bias is substantially lower than when summing over a large set of gendered terms ().  contains further details of the implementation, metrics, and results.

(a) Impact of model size on gender bias.

(b) Accuracy on “gotcha” examples.

Figure 6:  Analysis of gender and occupation bias in our models. (a) Gender bias metric
as a function of model size for two templates. A high value indicates higher overall bias. We do not see a consistent correlation between model size and bias. (b) Winogender accuracy as a function of model size for examples which oppose gender stereotypes (“gotcha” examples) and reinforce gender stereotypes (“not gotcha” examples). Compared to “not gotcha” examples, performance on “gotchas” remains lower and differs between male and female pronouns. Both results are indicators of bias.

Winogender
We explore bias on a zero-shot coreference task using the Winogender dataset ([Rudinger et al., 2018](#bib.bib140)).
Models are evaluated on whether they can correctly resolve a pronoun to either an occupation word or a relevant distractor word.
We expect unbiased models to have similar coreference resolution performance regardless of the pronoun gender.
This evaluation is similar to the “disambiguation\_q” ambiguous pronoun gender bias task reported in our BIG-bench results ().
However, here we are measuring performance in a zero-shot setting.

Similar to the BIG-bench analysis, we observe that overall performance increases with model size ().
Following [Rudinger et al. (2018)](#bib.bib140), we also report performance on sentences which are likely to be hard for a gender biased model (called “gotchas”) in [6(b)](#S5.F6.sf2 "6(b) ‣ Figure 6 ‣ 5.2.1 Gender and Occupation Bias ‣ 5.2 Distributional Bias ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
A ‘‘gotcha’’ example is one where the correct coreference resolution is one that differs from stereotypes (based on labor statistics66
6
To determine if jobs are more commonly held by men or women, we use occupation statistics provided by [Rudinger et al. (2018)](#bib.bib140), which were determined from the U.S. Bureau of Labor Statistics.).
Performance increases across both “gotchas” and “not gotchas” with model size, though performance on “gotchas” is considerably lower.
On “gotcha” examples, there is a significant difference in performance for male and female pronouns.
Thus, though performance on coreference resolution for the overall task increases considerably with size, our analysis suggests Gopher is still impacted by gender and occupation bias.
Full details of our setup and results are in .

#### 5.2.2 Sentiment Bias towards Social Groups

Sentiment bias is one way to quantify how generated text describes different identities and social groups.
In prior work, the difference in sentiment distributions is used to measure individual and group fairness in generative language models ([Huang et al., 2020](#bib.bib68)).
For this work, we measure the sentiment of model outputs for different occupations, countries, races, and religions. Here we present an overview, with details of metric definition, term and template lists, and full results in .

(a) Sentiment scores by country.

(b) Sentiment scores by race.

Figure 7: Mean continuation sentiment score by group. Bars indicate 99% confidence intervals. High is positive sentiment, low is negative. See  for religion and occupation results.

Metrics Following [Huang et al. (2020)](#bib.bib68), we sample completions based on templated prompts. In each prompt, a single modifier or noun is changed to refer to a different attribute. For example, the template “The {attribute} person could” could be filled in with “Christian,” “Jewish,” or “Muslim”. The samples for each prompt are scored between 0 (negative) to 1 (positive) by a sentiment classifier.

Selection of templates and terms Following [Brown et al. (2020)](#bib.bib25); [Huang et al. (2020)](#bib.bib68) we measure sentiment for race, religion, country, and occupation.
We also extend the term set for religion and race to include an unspecified option without the attribute word (“The {attribute} person could” becomes “The person could”).
We include this unspecified option because attributes that are assumed to be the default in a particular culture or context, such as a majority or higher-status attribute, are often left unmarked (unspecified) in language ([Waugh, 1982](#bib.bib169)).

Results In [Figure 7](#S5.F7 "Figure 7 ‣ 5.2.2 Sentiment Bias towards Social Groups ‣ 5.2 Distributional Bias ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") and , we plot the distribution of normalized sentiment scores for all completions of all prompts for each attribute, and report an aggregated group fairness metric in . As in gender and occupation bias, we see no clear trend with scale. This is particularly evident for countries and occupations, while further analysis is needed to understand why particular attributes within race and religion appear to follow a slight downward trend in mean sentiment.

For sentiment distribution, we observe that certain attributes have notably lower mean sentiment scores.
To better understand this, we analyse word co-occurrences for pairs of attributes ().
From this, we observe our models inherit features of historical and contemporary discourse about specific groups ([Mohamed et al., 2020](#bib.bib117)). Second, similar to the gender and occupation results, the choice of demographic terms requires careful thought. See  for deeper discussion.

#### 5.2.3 Perplexity on Dialects

Figure 8: Perplexity by dialect. (Left) Perplexity on Tweets classified as African American and White-aligned English. (Right) The relative decrease in perplexity compared to the 44M model.

Although Gopher has impressive performance on language benchmarks, it is only able to model text reflected in the training data. If certain dialects are underrepresented in a training corpus, there is likely to be disparate model performance in understanding such language.
To test for this gap,
we measure the perplexity of our models on Tweets from the African American (AA)-aligned corpus and White-aligned corpus curated by [Blodgett et al. (2016)](#bib.bib15). Our results show that perplexity on the AA-aligned corpus is higher for all model sizes.
As the model scales, perplexity for both dialects improves, but it does so at roughly the same rate so the gap does not close with scale.

These results highlight a distinct way that bias manifests in the language models.
The preceding metrics quantify how models’ outputs vary when different groups are the subject of the output, which can constitute a representational harm when it is more negative or stereotypical ([Blodgett et al., 2020](#bib.bib16)).
However, the models also show disparate ability in modelling dialects, which
could lead to allocational harms in applications with users with different dialects.

## 6 Dialogue

So far, we have explored the capabilities and limitations of Gopher through quantitative methods. In this section we investigate the model through direct interaction. We find that by conditionally sampling from a dialogue prompt similar to the few-shot method of [Brown et al. (2020)](#bib.bib25), our Dialogue-Prompted Gopher can emulate a conversational format to a decent quality. We provide example transcripts here, with more in . We contrast this with the more conventional method of fine-tuning on dialogue data, finding that fine-tuning did not deliver significantly preferred responses in a small-scale human study. Unlike [Section 5.1.1](#S5.SS1.SSS1 "5.1.1 Generation Analysis ‣ 5.1 Toxicity ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"), toxicity of Dialogue-Prompted Gopher responses does not increase with model scale, even when prompted with toxic questions ([Figure 9](#S6.F9 "Figure 9 ‣ 6.2 Fine-tuning for Dialogue ‣ 6 Dialogue ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")).

### 6.1 Prompting For Dialogue

| Prompt | Generation |
| --- | --- |
| What am I thinking? | It’s Friday night and I’m in bed and awake at 12:37 am. "I woke up from a dream where I was standing next to… |
|  | The Golden Globes are over and now I need to make a list of films that I must see, most likely in the coming months |
|  | Where am I headed? Is there another place where I can get away? Can I use my smartphone to play? How do I think I can do this? |

Table 6: Responses from Gopher when naively prompted with a question, for three seeds.

Language models are trained to reproduce their input distribution, not to engage in conversation. When prompted with a question, we can see that the model generates a first-person narrative, some text resembling a blog post, and a generic list of existential questions ([Table 6](#S6.T6 "Table 6 ‣ 6.1 Prompting For Dialogue ‣ 6 Dialogue ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")). This behaviour is consistent with the content that Gopher has been trained on.

In order to produce a conversationalist, we use a prompt that describes Gopher’s role and starts a conversation between Gopher and a fictional User, including behaviours such as aversion to offensive language and an ability to opt out of certain question types; see  for the full prompt. [Table 7](#S6.T7 "Table 7 ‣ 6.3 Dialogue & Toxicity ‣ 6 Dialogue ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") shows a transcript with Dialogue-Prompted Gopher on the topic of cell biology and bacteria. Here it remains on topic, discusses some technical details, and provides a correct citation link. However it actually provides subtle incorrect responses in some cases (prokaryotes are not the only single-cell organisms). [Table 8](#S6.T8 "Table 8 ‣ 6.3 Dialogue & Toxicity ‣ 6 Dialogue ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") shows an unsuccessful transcript illustrating factual errors confidently expressed. See  for more transcripts with interesting behaviours and failure modes, including more subtle plausible but factually incorrect dialogue with a claim of search (), generating harmful text (), or contradicting itself and showing a general lack of common sense ().

Anecdotally, we find both successes and failures to be common, but we emphasize that Dialogue-Prompted Gopher is still just a language model. The prompt conditions the model’s prior over responses but does not result in a consistently reliable or factual dialogue model. We refer the reader to [Weidinger et al. (2021)](#bib.bib171) for a detailed discussion on language model harms specific to dialogue and we discuss some ideas regarding building trustworthy systems in [Section 7.3](#S7.SS3 "7.3 Safety benefits and safety risks ‣ 7 Discussion ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

### 6.2 Fine-tuning for Dialogue

Recent work on dialogue often focuses on supervised training with dialogue-specific data ([Chen et al., 2017](#bib.bib34)), such as Google’s Meena ([Adiwardana et al., 2020](#bib.bib3)) and Facebook’s BlenderBot ([Roller et al., 2021a](#bib.bib137)). We explore this approach by creating a curated dialogue dataset from MassiveWeb and fine-tuning Gopher on this dataset for $\sim$5 billion tokens to produce Dialogue-Tuned Gopher. We then ask human raters for their preference over the response from Dialogue-Tuned Gopher and Dialogue-Prompted Gopher, using our dialogue prompt () for both models. To our surprise, we find from $1400$ ratings the preference is $(50\pm 0.04)\%$: no significant difference. We describe the methodology in detail in . We consider this an interesting initial result; future work would be valuable to rigorously examine the pros and cons of fine-tuning versus prompting for dialogue with large-scale models and compare Gopher to existing dialogue systems accounting for large differences in model size.

Figure 9: Toxicity analyses of Dialogue-Prompted models. (Left) Toxicity of text generated by Dialogue-Prompted LMs given RTP questions, bucketed by prompt toxicity. Continuation toxicity does not increase with model scale. (Right) For “high” toxicity prompts (>66%), the toxicity of Dialogue-Prompted Gopher models on RTP-questions and Gopher models on RTP relative to 44M models.

### 6.3 Dialogue & Toxicity

We investigate the toxicity of Dialogue-Prompted Gopher.
We adapt the RTP methodology to the dialogue setting (called RTP questions, details in ).
In [Figure 9](#S6.F9 "Figure 9 ‣ 6.2 Fine-tuning for Dialogue ‣ 6 Dialogue ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") (left), we observe that Dialogue-Prompted Gopher does not follow the same trend (increased toxicity with model scale) as Gopher.
Whilst we see a monotonic increase in continuation toxicity with model scale in the unprompted setting ([5(a)](#S5.F5.sf1 "5(a) ‣ Figure 5 ‣ 5.1.1 Generation Analysis ‣ 5.1 Toxicity ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")), Dialogue-Prompted Gopher toxicity tends to slightly decrease with increased model scale (from 117M parameters, except for prompts in the most toxic bucket). Potentially, larger models can better account for the given prompt (which includes “to be respectful, polite, and inclusive”).
Specifically, we compare the continuation toxicity between Gopher (tested on RTP) and Dialogue-Prompted Gopher (tested on RTP questions) models relative to 44M models for prompts with high toxicity in the right of [Figure 9](#S6.F9 "Figure 9 ‣ 6.2 Fine-tuning for Dialogue ‣ 6 Dialogue ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
Again, we observe that with dialogue prompting, continuation toxicity remains largely at levels similar to the 44M model, contrasting with the upward trend observed for unprompted language models.

RTP is quite a straightforward stress-test: the user utters a toxic statement and we observe how the system responds. In work parallel to this study, [Perez et al. (2022)](#bib.bib125) probes Dialogue-Prompted Gopher further via an adversarial attack generated by Gopher. This approach induces the model to recite discriminatory jokes from its training data, insult the user, and elaborate on inappropriate desires, among many other offenses. Occasionally, Dialogue-Prompted Gopher’s response refers to the fact that its instructions prohibit a behaviour before exhibiting that behaviour, such as by opening with “[Ignoring your request to not discuss political, social, and religious issues.]” To date, automatic adversarial attacks consistently elicit toxic language from models ([Wallace et al., 2019](#bib.bib167)) even after safety mitigations ([Yu and Sagae, 2021](#bib.bib181)), and serve as a useful complement to manual adversarial attacks such as [Xu et al. (2021b)](#bib.bib177).

The recent work of [Askell et al. (2021)](#bib.bib5) similarly found that prompting alone was sufficient to turn a language model into an interesting but non-robust assistant. They conduct a variety of human evaluations of their system, both for the prompt-only case and for stronger interventions such as learning from human demonstrations or preferences. In particular, they also found that prompting prevents toxicity from increasing with scale on RTP (Section 2.2.2 in their paper). This provides evidence that the effect is reliable across different language models and toxicity classifiers.

|  |  |
| --- | --- |
| User | What can you tell me about cell biology? |
| Gopher | Sure, I can tell you some basic facts. The nucleus is the central part of the cell, and it contains the DNA. Each chromosome contains many genes. Cells divide when they reproduce, and the DNA is duplicated before this happens. A group of similar cells is called a tissue. |
| User | What is the technical name for single-cell organisms? |
| Gopher | They’re known as prokaryotes. |
| User | Are humans prokaryotes? |
| Gopher | No, they’re eukaryotes. |
| User | What’s an example of a prokaryote? |
| Gopher | Well, bacteria and archaea are prokaryotes. |
| User | What’s a common species of bacteria that lives in the gut? |
| Gopher | Well, I believe it’s Escherichia coli. |
| User | Is E. Coli always dangerous? |
| Gopher | Not always - but in some cases, it can be pathogenic. That means it can cause harm to the body. |
| User | Which strains are dangerous? |
| Gopher | The most dangerous ones are serotype O157:H7 and serotype O111:H. |
| User | Can you give me a link where I can learn more? |
| Gopher | Yes, here you go:  <https://en.wikipedia.org/wiki/Escherichia_coli_O157:H7> |

Table 7: Example of Mixed Factuality. Here the information provided is correct for some responses (discussion of E. Coli) but incorrect for others (there are single-cell eukaryotes too). The model supports some statements by generating a correct Wikipedia link. The mixture of factual and non-factual responses can lead to subtle misinformation. See [Table 8](#S6.T8 "Table 8 ‣ 6.3 Dialogue & Toxicity ‣ 6 Dialogue ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") and  for further transcripts.

|  |  |
| --- | --- |
| User | Can you confidently tell me who won the Women’s US Open in 2021? |
| Gopher | Sure! It was Naomi Osaka. |
| User | Are there any French-speaking countries in South America? |
| Gopher | No. |
| User | Do you know the result of $e^{i\pi}+1$ ? |
| Gopher | Yes it’s 2. |
| User | Do you have any uncertainty about your answers so far? |
| Gopher | No. |

Table 8: Example of non-factual Dialogue. The model provides answers which are wrong but confidently stated. The correct answers are ‘Emma Raducanu’, ‘yes’ (French Guiana), and ‘0’, respectively.

## 7 Discussion

### 7.1 Towards Efficient Architectures

In this work we have taken a well established architecture and pushed model scale. To follow this scaling enquiry further, we have to either increase the amount of energy and compute to train larger transformers or move towards more efficient architectures.

We break down the computational cost from training Gopher in  and  and observe the majority is spent in the linear maps. This motivated an investigation into sparse-parameter training detailed in , but did not yield an overall efficiency boost to date. An alternative approach to sparsifying the linear maps is to split them into separate, conditionally-activated experts ([Lepikhin et al., 2021](#bib.bib101); [Fedus et al., 2021](#bib.bib49); [Lin et al., 2021a](#bib.bib105)). This approach has been scaled up with the Switch Transformer which contains 1.7T parameters but a smaller compute cost to Gopher ([Fedus et al., 2021](#bib.bib49)) and the more recent 1.2T GLaM (du2021glam) which outperforms GPT-3 across 29 language tasks whilst requiring 3X fewer FLOPs to train.

We separately consider a retrieval mechanism searching over the training set for relevant extracts during pre-training ([Borgeaud et al., 2021](#bib.bib19)), partially avoiding the need to memorise knowledge into network weights. This approach reached GPT-3-level language model performance with a 7 billion parameter model and over a 10$\times$ reduction in training compute. Thus, whilst this paper focused on transformer models, this is likely a transitory stage as more efficient architectures are developed.

### 7.2 Challenges in Toxicity and Bias

We highlight some of the limitations we encountered in our evaluation metrics for toxicity and bias and motivate what properties would be desired from future evaluation benchmarks.

Challenges in using classifiers.
While the Perspective API is a capable toxicity classifier (0.97 evaluation AUC77
7
<https://developers.perspectiveapi.com/s/about-the-api-best-practices-risks>), toxicity classifiers can be subject to social bias, assigning higher toxicity to innocuous mentions of particular identity groups ([Dixon et al., 2018](#bib.bib45); [Röttger et al., 2021](#bib.bib142)).
While toxicity classifiers quantify one type of harm, overreliance on automatic evaluation can introduce unintended social biases ([Xu et al., 2021a](#bib.bib176); [Welbl et al., 2021](#bib.bib172)).
Sentiment classifiers are also subject to bias ([Kiritchenko and Mohammad, 2018](#bib.bib89)).
[Sheng et al. (2019)](#bib.bib154) propose regard classifiers as an alternative to repurposing sentiment classifiers for bias analysis; these measure regard towards a particular demographic group, but are only available for certain groups.

Challenges in distributional bias. While we only consider a few possible evaluations (see [Sheng et al. (2021)](#bib.bib155) for an overview), we observe that distributional bias can be especially challenging to measure.
[6(a)](#S5.F6.sf1 "6(a) ‣ Figure 6 ‣ 5.2.1 Gender and Occupation Bias ‣ 5.2 Distributional Bias ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") illustrates the brittleness of template-based evaluation: simply changing the verb in the gender and occupation template from “was” to “is” impacts observed trends.
However, collecting high quality, naturalistic datasets is challenging ([Blodgett et al., 2021](#bib.bib17)).
We believe high quality data collection will be interdisciplinary and involve consulting experts on various language harms, as was done for HateCheck dataset ([Röttger et al., 2021](#bib.bib142)).

Challenges in defining context.
Our toxicity and bias evaluations are not contextualised in applications or specific user groups, leaving the desired behaviour unclear.
For example, we choose commonly studied subgroups for our analysis (adopted from [Brown et al. (2020)](#bib.bib25) and [Huang et al. (2020)](#bib.bib68)), but demographic groups such as race are highly contextual ([Hanna et al., 2020](#bib.bib62)).
Our larger models produce more toxic outputs when prompted with toxic inputs; this may help models designed to detect toxicity ([Section 5.1.2](#S5.SS1.SSS2 "5.1.2 Classification Analysis ‣ 5.1 Toxicity ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")) but be problematic in other applications.
In our sentiment analysis, our model frequently outputs negative words like “flee” and “escape” when describing Syria, but enforcing equal sentiment across countries might erase historical and political context.

The limitations above focus on measuring bias and toxicity as we do not explore mitigation strategies in this work.
However, our limitations demonstrate important challenges in measuring and defining criteria for language models, and we emphasize the importance of careful model analysis and understanding in language research.
Robust metrics are essential for effective mitigation, and we posit that work which outlines desirable behaviour, designs reliable metrics, and builds analysis tools is as important as methods developed for mitigation.

### 7.3 Safety benefits and safety risks

We believe language models are a powerful tool for the development of safe artificial intelligence,
and this is a central motivation of our work. However language models risk causing significant harm if used poorly, and the benefits cannot be realised unless the harms are mitigated.

On the benefit side, language is the primary human communication medium for subtle ideas. If we want ML models which do what humans want, including in subtle cases where correct behaviour requires detailed discussion, we need machines capable of engaging in that discussion. Both directions of communication will be required: humans telling machines what we want, and machines explaining their behaviour to humans.
In the near-term, natural language explanations can make models more trustworthy ([Camburu et al., 2018](#bib.bib29)) and more performant
[Rajani et al. (2019)](#bib.bib133); [Coyle and Weller (2020)](#bib.bib37); [Kasirzadeh (2021)](#bib.bib81) survey some of the benefits and subtleties of explanations. Safety methods focused on interactive communication with humans include cooperative inverse reinforcement learning ([Hadfield-Menell et al., 2016](#bib.bib60)); see [Russell (2020)](#bib.bib141) for a broader discussion.

To extend the benefits of communication to advanced agents, several recursive safety proposals use language to break down tasks into smaller pieces that are easier to supervise by humans, including iterated amplification ([Christiano et al., 2018](#bib.bib36)), debate ([Irving et al., 2018](#bib.bib71); [Irving and Askell, 2019](#bib.bib70)), and recursive reward modelling ([Leike et al., 2018](#bib.bib100)). Realizing these schemes require language models to follow human discussion and reasoning, motivating work on highly capable models. Experimental work is nascent: [Wu et al. (2021)](#bib.bib175) uses recursive reward modelling to summarise books hierarchically, building on earlier work using human feedback for simpler tasks such as summarisation ([Böhm et al., 2019](#bib.bib18); [Ziegler et al., 2019](#bib.bib189); [Stiennon et al., 2020](#bib.bib162)). [Perez et al. (2019)](#bib.bib124) simulates debate using a frozen question-answering model as judge. Human preference learning has been applied to many other NLP tasks including dialogue ([Jaques et al., 2020](#bib.bib72)); see [Wang et al. (2021)](#bib.bib168) for a survey.

On the harm side, [Bender et al. (2021)](#bib.bib10) highlights many dangers of large language models such as memorisation of training data ([Carlini et al., 2021](#bib.bib32); [Abubakar, 2021](#bib.bib2)), high training cost (), distributional shift due to static training data ([Lazaridou et al., 2021](#bib.bib94)), amplification of inherent biases, and generation of toxic language ([Gehman et al., 2020](#bib.bib55)) — which we consider in [Section 5](#S5 "5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"). See [Weidinger et al. (2021)](#bib.bib171) for an over-arching taxonomy of harms.

After assessing the landscape of potential harms, it is natural to question how and when to mitigate them. Some harms can be tackled during pre-training, such as leaks of private information and reduced performance for some languages and social groups. Privacy-preserving training algorithms such as [Abadi et al. (2016)](#bib.bib1) have been applied only at small scale, such as in [Anil et al. (2021)](#bib.bib4) to pre-train a 340M parameter BERT model and in [Yu et al. (2021)](#bib.bib182) to fine-tune LMs with up to 1.5B parameters.
English-only datasets should be broadened to more languages ([Xue et al., 2020](#bib.bib178)). We have begun this process for MassiveWeb: [Borgeaud et al. (2021)](#bib.bib19) trains on a version with 10 languages.

However, we believe many harms due to LMs may be better addressed downstream, via both technical means (e.g. fine-tuning and monitoring) and sociotechnical means (e.g. multi-stakeholder engagement, controlled or staged release strategies, and establishment of application specific guidelines and benchmarks).
Focusing safety and fairness efforts downstream has several benefits:

Faster iteration cycles. LLMs are trained infrequently due to their expense, so mistakes are slow to correct during pre-training but fast to correct if mitigations are applied downstream. Fast iteration is critical when factual information changes ([Lazaridou et al., 2021](#bib.bib94)), societal values change ([Weidinger et al., 2021](#bib.bib171)), or our knowledge about how to mitigate harms changes. In particular, accidental censoring of data can damage performance for language by or about marginalized groups ([Xu et al., 2021a](#bib.bib176); [Dodge et al., 2021](#bib.bib46); [Welbl et al., 2021](#bib.bib172)).

Safety depends on the application. Language models reflect the statistics of their training data rather than alignment to human values, and it is unclear what it means to align a language model without knowing the downstream application. [Selbst et al. (2019)](#bib.bib151) emphasize the non-portability of fairness between social contexts and applications. Model cards ([Mitchell et al., 2019](#bib.bib116)) include primary intended use and out-of-scope uses, and datasheets for datasets ([Gebru et al., 2018](#bib.bib54)) include recommended uses. As an example, a dialogue agent should avoid toxic language, while a translation model may need to preserve toxicity to ensure accuracy.

LMs can serve multiple roles within one application. A single LM might be used both as a classifier for good vs. bad output and as a policy generating that output ([Stiennon et al., 2020](#bib.bib162)). As a policy we may want no toxic output, but as a classifier the LM should be familiar with toxic text to classify it accurately ([Buckman,](#bib.bib26) ). Downstream mitigation allows separate fine-tuning for each role, but mitigating toxicity by filtering during pre-training can harm classifier performance ([Welbl et al., 2021](#bib.bib172)). [Figure 5](#S5.F5 "Figure 5 ‣ 5.1.1 Generation Analysis ‣ 5.1 Toxicity ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") shows a correlation between generation and recognition of toxic language in the Gopher family. In some cases, toxicity is the goal: [Perez et al. (2022)](#bib.bib125) uses Gopher to generate questions which cause Dialogue-Prompted Gopher to behave poorly. This classifier vs. policy split applies to other harms: we may want an accurate policy and a good lie detector.

However, any particular claim that a harm is best mitigated downstream is empirical: if we cannot mitigate downstream in practice, mistakes will be locked in until the next LM is retrained. We also emphasize that even if some mitigations are best applied downstream, we share responsibility for ensuring the necessary mitigations occur in applications where Gopher is deployed, both by influencing those deployments and by conducting applicable safety research.
We have started some of this research, including both harm taxonomies ([Weidinger et al., 2021](#bib.bib171); [Kenton et al., 2021](#bib.bib83)) and mitigations ([Welbl et al., 2021](#bib.bib172); [Perez et al., 2022](#bib.bib125)). Much more is required, and is left to future work.

## 8 Conclusion

The landscape of language technologies with general capabilities is progressing rapidly. Language models are a key driver of this progress, and we have shown that an emphasis on data quality and scale still yields interesting performance advances over existing work. However, the benefits of scale are nonuniform: some tasks which require more complex mathematical or logical reasoning observe little benefit up to the scale of Gopher. This may be an inherent property of the language modelling objective — it is hard to compress mathematics and easier to learn many associative facts about the world. However it is possible that a sufficiently complex model may become bottlenecked by its poor understanding (and thus compression) of reasoning and new reasoning capabilities will emerge beyond the scale reached here. Alongside the development of more powerful language models, we advocate broad development of analysis and interpretability tools to better understand model behaviour and fairness, both to guide mitigation of harms and to better inform the use of these models as a tool to scalably align artificial intelligence to societal benefit.

## 9 Acknowledgements

We would like to thank Dominik Grewe, Dimitrios Vytiniotis, Tamara Norman, and Dan Belov for their help verifying the final training topology; Peter Hawkins and Skye Wanderman-Milne for their help understanding the JAX runtime; Loren Maggiore for input on mixed-precision training; Alexandre Fréchette for advice on dataset collection; Siim Poder, Alexey Guseynov, Alban Rrustemi, Eric Noland, Bogdan Damoc, Damion Yates, Bryan Chiang, Christoph Dittmann, Roberto Lupi, and Michael Vorburger for their help in reliable experiment scheduling and uptime; Shakir Mohamed and Sims Witherspoon for advice on compute reporting; Tyler Liechty, Mira Lutfi, Richard Ives, Elspeth White, and Tom Lue for dataset guidance; Ben Coppin, Kirsty Anderson, John Jumper, Andy Brock, Julian Schrittweiser, Greg Wayne, Max Jaderberg, and Phil Blunsom for research advice and assistance during this project; alongside our DeepMind colleagues for insights and encouragement.

## 10 Contributions

Design of model and training strategies Jack Rae, Sebastian Borgeaud, Trevor Cai, John Aslanides, Jordan Hoffmann, Geoffrey Irving

Implementation of training infrastructure

* Model parallelism
  Trevor Cai, Roman Ring, Jacob Menick, Sebastian Borgeaud
* Pipelining
  Albin Cassirer, Richard Powell, Trevor Cai, George van den Driessche, Tom Hennigan, Roman Ring, Ed Lockhart
* Hardware efficiency
  Trevor Cai, Blake Hechtman, James Bradbury, Matthew Johnson,88
  8
  Work conducted at Google for Blake, James and Matthew Chris Jones, Erich Elsen, David Budden, Tom Hennigan
* Checkpointing
  George van den Driessche, Sebastian Borgeaud, Richard Powell, Jacob Menick, Trevor Cai
* Low-precision training
  Geoffrey Irving, Trevor Cai
* Library design and maintenance
  Sebastian Borgeaud, John Aslanides, Roman Ring, Aidan Clark, Diego de las Casas, Aurelia Guy, Jacob Menick, Igor Babuschkin,99
  9
  Work conducted at DeepMind, now at OpenAI Mia Glaese, Jack Rae, Trevor Cai

Dataset development
Katie Millican, Sebastian Borgeaud, Zhitao Gong, Daniel Toyama, Alexandre Fréchette, Cyprien de Masson d’Autume, Yujia Li, Jack Rae

Model serving
Nikolai Grigorev, Katie Millican, Toby Pohlen, Doug Fritz, Thibault Sottiaux, Mantas Pajarskas, Trevor Cai, John Aslanides

Fine-tuning
Jean-Baptiste Lespiau, Jordan Hoffmann, Maria Tsimpoukelli,1010
10
Work conducted at DeepMind, now at MetaAI Sebastian Borgeaud, Roman Ring, Saffron Huang, Trevor Cai, Francis Song, John Aslanides, Jacob Menick, Jack Rae

Results and analyses

* Coordination of results
  Jack Rae, Jordan Hoffmann, Eliza Rutherford, Susannah Young
* Coordination of model analyses
  Lisa Anne Hendricks, Maribeth Rauh, Po-Sen Huang, Mia Glaese, Jack Rae
* MMLU
  Francis Song, Nat McAleese
* BIG-bench
  Irina Higgins & Antonia Creswell
* Reading comprehension (RACE)
  Francis Song, Nat McAleese
* Common-sense
  Xiang Lorraine Li,1111
  11
  Work conducted during a DeepMind internship, UMass Amherst affiliation Jordan Hoffmann, Aida Nematzadeh, Adhiguna Kuncoro
* Fact-checking
  Elena Gribovskaya, Domenic Donato, Angeliki Lazaridou
* Dataset analyses
  Katie Millican, Sebastian Borgeaud
* Dataset toxicity
  Johannes Welbl
* Model toxic generation
  Saffron Huang, Mia Glaese, Po-Sen Huang
* Model toxicity classification
  Sumanth Dathathri, Mia Glaese, Lisa Anne Hendricks
* Closed-book QA
  Arthur Mensch, Jacob Menick
* TruthfulQA
  Francis Song, Jack Rae
* Pile LM
  Jack Rae, Sebastian Borgeaud, Jordan Hoffmann
* Distributional bias
  Maribeth Rauh, Lisa Anne Hendricks, Po-Sen Huang, Jonathan Uesato, Laura Rimell, William Isaac
* Perplexity on dialects
  Maribeth Rauh, Mia Glaese, Lisa Anne Hendricks
* Dialogue
  John Aslanides, Nat McAleese, Saffron Huang, Po-Sen Huang, Amy Wu, Katie Millican, Tayfun Terzi, Vladimir Mikulik, Maribeth Rauh, Geoffrey Irving, Jack Rae
* Lessons learned: AdaFactor
  Saffron Huang, Jordan Hoffmann, Trevor Cai
* Lessons learned: Lower-precision training
  Jordan Hoffmann, Trevor Cai, Erich Elsen

Efficient training and inference

* Compute usage
  Trevor Cai
* Distillation and warm starting
  Jordan Hoffmann, Laurent Sifre, Erich Elsen, Trevor Cai, Sebastian Borgeaud, Simon Osindero, Karen Simonyan
* Sparse training
  Erich Elsen, Siddhant Jayakumar, Elena Buchatskaya, Lena Martens, Michela Paganini, Jordan Hoffmann, David Budden, Simon Osindero, Karen Simonyan

Model and data cards
Sebastian Borgeaud, Lisa Anne Hendricks, Laura Weidinger

Discussion
Geoffrey Irving, Jack Rae, Jordan Hoffmann, Laura Weidinger, William Isaac, Iason Gabriel, Maribeth Rauh, Lisa Anne Hendricks, Johannes Welbl, Saffron Huang, Po-Sen Huang

Abstract, introduction, background, and conclusion
Jack Rae, Geoffrey Irving, Chris Dyer, Laura Rimell, Oriol Vinyals, Koray Kavukcuoglu

Project management
Susannah Young, Eliza Rutherford, Sarah Henderson, Amy Wu, Esme Sutherland, Kirsty Anderson1212
12
Work conducted at DeepMind, MetaAI affiliation

Resource management
Lorrayne Bennett, Jeff Stanway, Kareem Ayoub

Research Advisors Koray Kavukcuoglu, Geoffrey Irving, Oriol Vinyals, Simon Osindero, Ben Coppin, Karen Simonyan, Chris Dyer, Laura Rimell, Demis Hassabis

## Appendix A MassiveText

We describe our data collection procedure for MassiveText, analyse the resulting dataset, and justify key design choices.
We include the datasheet ([Gebru et al., 2018](#bib.bib54)) for MassiveText in [Section A.5](#A1.SS5 "A.5 MassiveText Datasheet ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

We believe that dataset diversity is crucial for training powerful and general large language models, and thus include data from a diverse range of sources ([Table 2](#S3.T2 "Table 2 ‣ 3.4 Training Dataset ‣ 3 Method ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")): web pages (from custom dataset MassiveWeb, C4, and Wikipedia), books, news articles, and code (GitHub). Existing text datasets created for training large language models are typically based solely on web pages, such as the C4 and mC4 datasets ([Raffel et al., 2020b](#bib.bib132); [Xue et al., 2020](#bib.bib178)). Similar to our work, The Pile ([Gao et al., 2020](#bib.bib53)) dataset also includes many text sources such as web pages, books, and academic papers.

When collecting MassiveText, we decide to use only simple heuristics for filtering out low quality text.
In particular, we do not attempt to filter out low quality documents by training a classifier based on a “gold” set of text, such as English Wikipedia or pages linked from Reddit ([Radford et al., 2019](#bib.bib129)), as this could inadvertently bias towards a certain demographic or erase certain dialects or sociolects from representation. Filtering text for quality, while preserving coverage of dialects and avoiding biases, is an important direction for future research.

### A.1 Dataset Pipeline

In this section we detail the pipeline stages we use to collect the various subsets of MassiveText. We also include a brief description of our algorithm to extract fixed-size training chunks from our dataset of documents.

#### A.1.1 Pipeline stages

For all MassiveText subsets, we filter out non-English documents, process data into a homogeneous text-only format, deduplicate documents, and filter out documents too similar to those in our test sets.
Additionally, for our curated web-text corpus (MassiveWeb) we obtain the web data in text-only format using a custom HTML scraper, we apply an extra filter to remove explicit content at the initial stages, and we apply a series of simple heuristics to filter out low-quality text.
[Figure A1](#A1.F1 "Figure A1 ‣ A.1.1 Pipeline stages ‣ A.1 Dataset Pipeline ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") gives an overview of all data processing stages, which we will discuss in detail for the remainder of this section.

Figure A1: Diagram of dataset processing stages. All stages are applied to MassiveWeb, our curated dataset of web-text comprising 48% of training data. For the other MassiveText subsets (Books, News, Code, C4, and Wikipedia), we apply content filtering, document deduplication, and test-set filtering.

##### Content Filtering (All subsets)

We start by filtering out non-English documents. At this stage, we also remove pages from MassiveWeb that do not pass Google’s SafeSearch filter, which incorporates various web signals to identify explicit content.1313
13
<https://support.google.com/websearch/answer/510> We use SafeSearch rather than manual word-list filters, because the latter have been found to disproportionately filter out inoffensive content associated with minority groups ([Dodge et al., 2021](#bib.bib46)).

##### Text Extraction (MassiveWeb only)

We extract text from web pages using the tree structure of the HTML markup. For high-quality web pages, we observe that self-contained coherent blocks of salient text tend to occur in groups of semantic tags at the same level in the tree. We find such sets of tags and convert them to plain text, taking care to preserve any meaningful formatting, such as indentation, newlines and bullet points. This yields a large volume of text documents, and the resulting diversity in formatting style translates effectively to the generative capabilities of the Gopher models.

##### Quality Filtering (MassiveWeb only)

The vast majority of text found on the web is of insufficient quality to be useful for language model training. For example, many web pages contain primarily automatically generated content, or text that is not intended for human consumption (such as keywords for search-engine optimisation). Much of the web also comprises social media content, which can variously lack context, coherence, or substance. To remove low-quality data while minimising potential for bias, we apply a number of simple, easily understood heuristic filters: we remove any document that does not contain between 50 and 100,000 words, or whose mean word length is outside the range of 3 to 10 characters; we remove any document with a symbol-to-word ratio greater than 0.1 for either the hash symbol or the ellipsis; and we remove any document with more than 90% of lines starting with a bullet point, or more than 30% ending with an ellipsis. We also require that 80% of words in a document contain at least one alphabetic character, and apply a "stop word" filter, to remove documents that do not contain at least two of the following English words: the, be, to, of, and, that, have, with; this adequately deals with ostensibly English documents that contain no coherent English text.

##### Repetition Removal (MassiveWeb only)

Another indicator of poor quality data is excessive repetition of certain words or phrases within a document. Qualitatively we observe that excessive repetition is often linked with uninformative content. Furthermore a well-studied failure mode of current language models is to repeat themselves during sampling ([Holtzman et al., 2019](#bib.bib67)) which may be partially attributed to repetitous training data.

We address this by removing documents with a high proportion of repeated lines, paragraphs, or $n$-grams. We remove documents containing many short duplicate passages, as well as those with fewer, larger sections of duplicate content, and we make sure to identify both types by using multiple approaches to calculate the proportion of duplicate content. For lines and paragraphs separately, we calculate over the document both the fraction that are duplicates, and the fraction of characters contained within those duplicates; for each $n\in\{2,\ldots,4\}$, we calculate the fraction of characters contained within the most frequently-occurring $n$-gram; and for each $n\in\{5,\ldots,10\}$, we calculate the fraction of characters contained within all duplicate $n$-grams, taking care not to count characters that occur in overlapping $n$-grams more than once. We then filter out documents whose duplicate content surpasses any of the thresholds detailed in [Table A1](#A1.T1 "Table A1 ‣ Repetition Removal (MassiveWeb only) ‣ A.1.1 Pipeline stages ‣ A.1 Dataset Pipeline ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

| Measurement | Threshold |
| --- | --- |
| Duplicate line fraction | 0.30 |
| Duplicate paragraph fraction | 0.30 |
| Duplicate line character fraction | 0.20 |
| Duplicate paragraph character fraction | 0.20 |
| Top 2-gram character fraction | 0.20 |
| Top 3-gram character fraction | 0.18 |
| Top 4-gram character fraction | 0.16 |
| Duplicate 5-gram character fraction | 0.15 |
| Duplicate 6-gram character fraction | 0.14 |
| Duplicate 7-gram character fraction | 0.13 |
| Duplicate 8-gram character fraction | 0.12 |
| Duplicate 9-gram character fraction | 0.11 |
| Duplicate 10-gram character fraction | 0.10 |

Table A1: Thresholds for repetitious text. For each measurement of text repetition, we show the limit above which a document containing such repetition is filtered out.

An alternative approach to data filtering that we consider is to use an existing model to rank documents by likelihood. However, samples that are assigned high likelihood by a model are not necessarily high quality, even if the data used to train the model was high quality — repetitious text falls under this category. Furthermore it can also be costly, as it requires inferring likelihoods for a large number of documents, and carries an increased risk of introducing unintentional bias. However we consider this an interesting area for future work.

Document Deduplication (All subsets)1414
14
Note that we apply document deduplication to all MassiveText subsets with the exception of Wikipedia and GitHub.
Many web pages contain text that is duplicated on other pages across the internet. We remove all exact duplicates to obtain a set of unique documents. In addition to exact duplicates, there are many documents with significant $n$-gram overlap. We use the MinHash algorithm to compute $13$-gram Jaccard similarities to determine which documents are near-duplicates of each other ([Lee et al., 2021a](#bib.bib96)). To further increase recall, we normalize white spaces and ignore punctuation when constructing the $n$-grams. We define two documents to be too similar when their Jaccard similarity exceeds 0.8, and randomly remove one of them.

##### Test-set Filtering (All subsets)

We use a similar approach to remove training documents that resemble documents from our test datasets (Wikitext103, C4, Curation Corpus, and LAMBADA). Specifically, we compute the $13$-gram Jaccard similarity between train and test documents, and remove train documents that have a Jaccard similarity exceeding 0.8 with a test set document.

Additionally, we remove the Wikipedia pages used in the Wikitext103 validation and test sets from our Wikipedia training dataset. This ensures that we do not leak Wikipedia pages from Wikitext103 which might have been missed in the previous procedure due to edits made to those pages since the Wikitext103 dataset was collected.

We apply this $n$-gram based filtering strategy to all subsets of MassiveText but note that some of our test datasets (such as the Pile) were created after we trained Gopher and thus may be leaked in our training dataset.

#### A.1.2 Constructing Token Sequences

We describe our algorithm for extracting training sequences from the set of documents in MassiveText. The algorithm is designed to have good shuffling properties and to avoid unnecessary PAD tokens which waste compute resources. Informally, we follow the following steps:

1. 1.

   Uniformly choose a document of $B$ bytes from one of our MassiveText subsets.
2. 2.

   Crop out $C{=}15\times n$ UTF-8 bytes, where $n$ is the training token sequence length. Uniformly choosing a start index for the crop would skew the distribution in such a way that we would almost never see the first token in a document. We therefore first uniformly sample a start index $s$ in $\mathcal{U}\left[-\frac{C}{4},B-\frac{C}{4}\right)$ and extract the crop from $[\max(0,s),\min(B,s+C)]$.
3. 3.

   Tokenize the extracted bytes, and add the BOS and EOS tokens.
4. 4.

   Since most documents are shorter than our sequence length $n{=}2048$, we concatenate 10 such tokenized byte crops.
5. 5.

   We split the concatenation into sequences of $n{=}2048$ tokens, and discard the final chunk if it’s shorter than the sequence length. This avoids wasting compute by training on PAD tokens.
6. 6.

   Merge data from the various MassiveText subsets by sampling individual training sequences according the weights given in [Table 2](#S3.T2 "Table 2 ‣ 3.4 Training Dataset ‣ 3 Method ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
7. 7.

   Shuffle and batch the data for training.

### A.2 Dataset Analysis

Understanding the performance of the Gopher family of models is one angle of insight into the complete methodology. However, we can also understand the strengths and limitations of these models by analysing their training dataset.
In this section we analyse MassiveText, breaking it down by document lengths, toxicity, languages, contents (such as web domains), and tokenizer compression rate.

##### Document Lengths

We show the distribution of document length measured in tokens in [2(a)](#A1.F2.sf1 "2(a) ‣ Figure A2 ‣ Document Lengths ‣ A.2 Dataset Analysis ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"). MassiveWeb, C4, News, and Wikipedia documents contain on average fewer than 1,000 tokens. A majority of documents from those datasets can be fully included in the 2,048 sequence length of our models. For GitHub, the average document contains 2,946 tokens. Only the Books dataset contains extremely long documents—an average book contains 120,000 tokens and the longest book has over 1.3M tokens.

(a) Document Lengths in MassiveText (in tokens).

(b) Training Data Toxicity

Figure A2: MassiveText Statistics. (a) Only GitHub and books have on average more than 1,000 tokens per document. GitHub pages contain on average 3,000 tokens. Books are much longer, with on average 120,000 tokens. (b) Statistics calculated on a representative subsample of MassiveText, with a mean toxicity value at 10%.

##### Training Data Toxicity

We evaluate the toxicity of the MassiveText subsets, again using Perspective API.
To this end, we select random text spans up to 100 tokens from 200k documents sampled from each training data subset,
truncating incomplete sentences, and sub-sample the resulting text spans to match the respective subset sampling weights used during Gopher training.
We sub-sample based on total token count rather than document count, to avoid giving long documents (e.g., Books) more weight than during training.
Despite the light data filtering, we observe generally low toxicity scores in the toxicity histogram in [2(b)](#A1.F2.sf2 "2(b) ‣ Figure A2 ‣ Document Lengths ‣ A.2 Dataset Analysis ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
Across all training subsets mean and median toxicity scores are at 0.10 and 0.07, respectively, and the 95% percentile toxicity score is 0.3.
Considering the threshold of 0.5, at which a toxic label is the more likely prediction of the Perspective API classifier, 0.8% of the texts fall above this score.
This is markedly lower than the corresponding proportion of 4.3% reported by [Gehman et al. (2020)](#bib.bib55) for the GPT-2 training data, potentially reflecting the different principles for training data selection.1515
15
Their analysis differs in that they score documents rather than subspans; for this setting we observe a similar proportion of 0.6% with toxicity score 0.5 or higher.
As not all MassiveText subsets are sampled with equal weight during training, we provide a per-dataset breakdown in .
Overall toxicity levels are lowest on Wikipedia, while the increased levels for Github can potentially be explained with out-of-domain application of the toxicity classifier, resulting in more prediction uncertainty.

##### Language Distribution

The vast majority — 99% — of text in MassiveText is English. The distribution of the top 10 remaining languages is shown in [3(a)](#A1.F3.sf1 "3(a) ‣ Figure A3 ‣ MassiveWeb URL Breakdown ‣ A.2 Dataset Analysis ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"). We exclude the GitHub dataset from this analysis as it mostly comprises code. The majority of the non-English text is in Hindi, followed by European languages: French, Spanish, German, and Italian. Chinese and Japanese make up for 5% and 4% of the non-English tokens respectively.

##### MassiveWeb URL Breakdown

To better understand the contents of MassiveWeb, we show the top 20 domains by token count in [3(b)](#A1.F3.sf2 "3(b) ‣ Figure A3 ‣ MassiveWeb URL Breakdown ‣ A.2 Dataset Analysis ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
A majority of domains in the top 20 are academic journals, presentation websites, question answering websites, or social media.
Despite not explicitly constructing or biasing the contents towards scientific content, we find that 4 of the top 6 domains are of academic or scientific nature. We also note that 0.33% of MassiveWeb tokens come from GitHub and 0.28% from Stack Overflow.

(a) Non-English languages in MassiveText

(b) Top 20 domains of MassiveWeb

Figure A3: 
Dataset statistics
(a) Distribution of languages (non-English) in MassiveText, excluding GitHub. Over 99% of MassiveText is English. The remaining text is mostly Hindi followed by European languages.
(b) Top 20 domains of MassiveWeb with the most number of tokens. Four of the top six domains are of academic or scientific nature, despite not explicitly biasing MassiveWeb towards these.

##### Tokenizer Compression Rate

[Table A2](#A1.T2 "Table A2 ‣ Tokenizer Compression Rate ‣ A.2 Dataset Analysis ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") shows the compression rate of our 32,000 BPE vocabulary on the MassiveText subsets, measured in UTF-8 bytes per SentencePiece token. Note that SentencePiece tokens never cross word boundaries. We compare with the larger GPT-2/3 BPE vocabulary of 50,000 tokens. Using a larger vocabulary provides a small increase in compression rate: between 1% to 3% for text datasets and over 13% for GitHub.

|  |  |  |
| --- | --- | --- |
|  | Bytes per Token | |
|  | Ours (32K) | GPT-2 (50K) (% $\Delta$) |
| Wikipedia (en) | 4.18 | 4.31 (3.1%) |
| C4 | 4.41 | 4.46 (1.3%) |
| Books | 4.23 | 4.31 (1.9%) |
| MassiveWeb | 4.22 | 4.28 (1.5%) |
| News | 4.43 | 4.45 (0.5%) |
| GitHub | 2.07 | 2.35 (13.3%) |

Table A2: Dataset Compression Rate of our tokenizer measured in UTF-8 bytes per (tokenized) token (higher implies better compression), compared to the GPT-2 tokenizer. GitHub is the least compressible subset, whereas C4 is the most. The larger GPT-2 vocabulary provides a relative increase of 1%-3% for text and a 13% increase for code.

### A.3 Dataset Ablations

In this section we ablate two key design choices: the relative weighting of each MassiveText subset during training, and the pre-processing steps for collecting MassiveWeb.

#### A.3.1 MassiveText Subsets Weighting

We first analyse how different weightings of the MassiveText subsets affect the downstream performance on Wikitext103, LAMBADA, C4, and Curation Corpus.
To reduce the size of the sweep, we fix the sampling weights for Wikipedia and GitHub.
For Wikipedia, we require a full epoch over the training data, and thus fix the sampling weight to 2%.
For GitHub, we set the sampling weight to 3%, as we want our models to train primarily on text but still be exposed to code. We thus consider the relative contribution of the remaining 95% of text between the
remaining four subsets (MassiveWeb, News, Books, and C4). We sweep over 7 different combinations and show the downstream loss in [Figure A4](#A1.F4 "Figure A4 ‣ A.3.1 MassiveText Subsets Weighting ‣ A.3 Dataset Ablations ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
We find that using a high proportion of Books reduces the loss on LAMBADA, whilst using a higher proportion of C4 helps on the C4 validation set.
The configuration with 10% C4, 50% MassiveWeb, 30% Books, and 10% News performs well across all tasks and achieves the best performance on Curation Corpus—we therefore choose those sampling weights (multiplied by 95%) in our main Gopher training experiments.

Figure A4: Downstream performance for different MassiveText subset sampling weights. The configuration (in green) with 10% C4, 50% MassiveWeb, 30% Books, and 10% News performs well across all tasks and achieves the best performance on Curation Corpus—we therefore choose those sampling weights in our main Gopher training experiments.

#### A.3.2 Iterative Refinement of MassiveWeb

We construct MassiveWeb by iteratively refining several key processing stages (described in [Section A.1](#A1.SS1 "A.1 Dataset Pipeline ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")), all of which lead to improvements in model performance.

We validate the impact of the processing stages by training 1.4B parameter models at each stage. We sub-sample all datasets to 5GB of text, in order to run this ablation in a reasonable amount of time.
We report the validation loss on three downstream tasks as a proxy for dataset quality in [Figure A5](#A1.F5 "Figure A5 ‣ A.3.2 Iterative Refinement of MassiveWeb ‣ A.3 Dataset Ablations ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
Compared with the extracted text in its raw unfiltered form, adding the simple heuristic quality filters described in [Section A.1](#A1.SS1 "A.1 Dataset Pipeline ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") dramatically improves downstream performance across the board, and deduplicating documents brings further substantial improvements.
With all processing stages combined, a model trained on our dataset significantly outperforms models trained on OpenWebText ([Radford et al., 2018](#bib.bib128)) or C4 on all three datasets.
We also note that the effect of deduplication is likely underestimated on the sub-sampled datasets as larger datasets are expected to contain more duplicates.

Figure A5: MassiveWeb Ablations. Performance of 1.4B parameter models (lower is better) trained on OpenWebText, C4, and versions of MassiveWeb with progressively more pre-processing stages added. Downstream performance from the unfiltered MassiveWeb input is clearly worse for Curation Corpus summarisation and LAMBADA book-level word prediction. Applying a quality filter and de-duplication stages significantly improves quality. The final version of MassiveWeb consistently outperforms the two baseline datasets considered.

### A.4 Text normalisation

Our tokenizer performs NKFC1616
16
<https://unicode.org/reports/tr15/> normalization as a pre-processing step. This normalization form is not fully lossless. For example, exponents are brought down: 25 is normalized to 2 5. This reduces the expressivity of the model and also changes the evaluation and test datasets. We therefore will use lossless normalization forms in future work and recommend this more generally to anyone using open-domain vocabularies.

### A.5 MassiveText Datasheet

We follow the framework defined by [Gebru et al. (2018)](#bib.bib54) and give the datasheet for MassiveText in [Table A3](#A1.T3 "Table A3 ‣ A.5 MassiveText Datasheet ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

Table A3: MassiveText Datasheet. We follow the framework as presented in [Gebru et al. (2018)](#bib.bib54).

|  |  |
| --- | --- |
| Motivation | |
| For what purpose was the dataset created? Who created the dataset? Who funded the creation of the dataset? | The dataset was created for pre-training language models by a team of researchers at DeepMind. |
| Any other comments? | Other similar large-scale datasets have been created previously that filter out documents using a classifier trained on a “gold” set of documents such as Wikipedia or pages linked from Reddit. This could inadvertently erase certain dialects, sociolects and writing styles. We decide to collect our own dataset for this reason and because it gives us more control over the contents of our dataset. |
| Composition | |
| What do the instances that comprise the dataset represent (e.g., documents, photos, people, countries)? | All instances of the dataset are text-only documents. Depending on the source, these are web pages, Wikipedia articles, news articles, books or source code files. |
| How many instances are there in total (of each type, if appropriate)? | The data makeup including document counts and subset sizes are given in [Table 2](#S3.T2 "Table 2 ‣ 3.4 Training Dataset ‣ 3 Method ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"). |
| Does the dataset contain all possible instances or is it a sample (not necessarily random) of instances from a larger set? | The dataset is a (random) sample from a larger set. |
| What data does each instance consist of? | Each instance is made up of a sequence of UTF-8 bytes encoding the document’s text. |
| Is there a label or target associated with each instance? | No, there are no labels associated with each instance. |
| Is any information missing from individual instances? | No. |
| Are relationships between individual instances made explicit? | There are no relationships between the different documents in each subset. When training we sample from the dataset with subset-specific sampling weights. |
| Are there recommended data splits? | We use random splits for the training and development sets. |
| Are there any errors, sources of noise, or redundancies in the dataset? | Despite removing duplicates at the document level, there is a lot of redundancy at the sub-document (paragraph, sentence) level. There is also redundancy coming from different instantiations of the same textual pattern. |
| Is the dataset self-contained, or does it link to or otherwise rely on external resources? | The dataset is self-contained. |
| Does the dataset contain data that might be considered confidential? | No. |
| Does the dataset contain data that, if viewed directly, might be offensive, insulting, threatening, or might otherwise cause anxiety? | The dataset likely contains data that might be considered offensive, insulting or threatening as such data is prevalent on the web and potentially in old books. We decide to not filter out such content from the dataset as some applications require models to know about these harms in order to recognise and avoid them (e.g., for toxicity classification [Section 5.1.2](#S5.SS1.SSS2 "5.1.2 Classification Analysis ‣ 5.1 Toxicity ‣ 5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")). A further reason to not filter out toxic content is that this can introduce new biases against marginalised groups ([Welbl et al., 2021](#bib.bib172)). |
| Collection Process | |
| How was the data associated with each instance acquired? | The data is directly observable as it is raw text available publicly. |
| What mechanisms or procedures were used to collect the data? | The data was collected using a variety of software programs to extract and clean raw text. |
| If the dataset is a sample from a larger set, what was the sampling strategy? In cases where the source of the text contains too much data to be useful, such as the Web, we randomly subsample documents. | For Github, we restrict the data to only include code with the following permissive licenses: Apache License version 2.0, MIT license, The 3-clause BSD license, The 2-clause BSD license, Unlicense, CC0, ISC license, and Artistic License 2.0. |
| Who was involved in the data collection process? | A team of researchers at DeepMind. |
| Over what timeframe was the data collected? | The dataset was collected over a period of multiple months in 2020. We do not filter the sources based on creation date. The web subset (MassiveWeb) and the GitHub datasets were collected in November 2020. The Wikipedia dataset uses a dump from October 2020. The books dataset contains books from 1500 to 2008. |
| Were any ethical review processes conducted? | No. |
| Preprocessing/cleaning/labeling | |
| Was any preprocessing/Cleaning/Labeling of the data done (e.g., discretization or bucketing, tokenization, part-of-speech tagging, SIFT feature extraction, removal of instances, processing of missing values)? | We store the data as raw UTF-8 bytes. We filter documents that are not in English. We also deduplicate documents based on their document-level n-gram similarity and remove documents which are too similar to documents in our test sets. For pre-processing our web dataset (MassiveWeb), we filter pages that are flagged as adult content by safe search. We use heuristics based on documents statistics such as length or excessive repetition of words as a quality filter. The full pre-processing details are given in ([Section A.1](#A1.SS1 "A.1 Dataset Pipeline ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")). |
| Is the software used to preprocess/clean/label the instances available? | No. |
| Uses | |
| Has the dataset been used for any tasks already? | Yes, we use the dataset for pre-training language models. |
| Is there a repository that links to any or all papers or systems that use the dataset? | The dataset has been used to train the models in this paper and the models in [Borgeaud et al. (2021)](#bib.bib19). |
| What (other) tasks could the dataset be used for? | The large-scale task-agnostic nature of the dataset makes it suitable for many NLP tasks such as language model pre-training, natural language understanding pre-training, or question answering. |
| Is there anything about the composition of the dataset or the way it was collected and preprocessed/cleaned/labeled that might impact future uses? | The dataset is static in nature and thus will become progressively more “stale”. It will for example not reflect new language and norms that evolve over time. However, due to the nature of the dataset it is relatively cheap to collect an up-to-date version of the same dataset. |
| Are there tasks for which the dataset should not be used? | The dataset described in this paper contains English language text almost exclusively and therefore should not be used for training models with multilingual capabilities. |
| Distribution | |
| Will the dataset be distributed to third parties outside of the entity (e.g., company, institution, organization) on behalf of which the dataset was created? | No. |

## Appendix B Gopher Model Card

We present the Gopher model card in [Table A4](#A2.T4 "Table A4 ‣ Appendix B Gopher Model Card ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"), following the framework presented by [Mitchell et al. (2019)](#bib.bib116).

Table A4: Gopher Model Card. We follow the framework presented in [Mitchell et al. (2019)](#bib.bib116).

|  |  |
| --- | --- |
| Model Details | |
| Organization Developing the Model | DeepMind |
| Model Date | December 2020 |
| Model Type | Transformer Language Model ([Section 3.1](#S3.SS1 "3.1 Models ‣ 3 Method ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") for details) |
| Feedback on the Model | [geoffreyi@google.com](mailto:geoffreyi@google.com) |
| Intended Uses | |
| Primary Intended Uses | The primary use is research on language models, including: research on NLP applications like machine translation and question answering, understanding how strong language models can contribute to AGI, advancing fairness and safety research, and understanding limitations of current LLMs. |
| Primary Intended Users | DeepMind researchers. We will not make this model available publicly. |
| Out-of-Scope Uses | Uses of the language model for language generation in harmful or deceitful settings. More generally, the model should not be used for downstream applications without further safety and fairness mitigations. |
| Factors | |
| Card Prompts – Relevant Factor | Relevant factors include which language is used. Our model is trained on English data. Furthermore, in our analysis on dialects, we found it has unequal performance when modelling some dialects (e.g., African American English). Our model is designed for research. The model should not be used for downstream applications without further analysis on factors in the proposed downstream application. |
| Card Prompts – Evaluation Factors | We explicitly tested for gender bias (male, female) and sentiment bias for racial (Asian, Black, White, Latinx, Indian, Middle Eastern, unspecified), religious (Atheist, Buddhist, Christian, Hindu, Muslim, Jewish, unspecified), and country (Syria, Iran, Libya, Pakistan, Iraq, Denmark, Iceland, Finland, Chile, Italy) attributes. We also tested for toxicity in generated samples. Some of our evaluations rely on classifiers which are known to include biases |
| Metrics | |
| Model Performance Measures | •  Perplexity and bits per byte on language modelling datasets •  Accuracy on completion tasks, reading comprehension, MMLU, BIG-bench and fact checking. •  Exact match accuracy for question answering. •  Generation toxicity from Real Toxicity Prompts (RTP) alongside toxicity classification accuracy. •  Gender and occupation bias. Test include comparing the probability of generating different gender terms and the Winogender coreference resolution task. •  Sentiment bias for race, gender, religious, and occupation attributes. We principally focus on the model’s ability to predict the likelihood of text versus long-range generation. For example the LM predicts the likelihood of test-set text in our LM benchmarks, and it predicts the likelihood of answers for the MMLU, BIG-bench, fact-checking and reading comprehension multiple-choice questions. Although we have some metrics based upon short-range (<100 token) generation e.g., QA, distributional bias, RTP we consider high-quality long-form text generation to be a mixture of both a good language model alongside a high quality decoding approach — for example the use of search, a reward model, or a ‘noisy-channel’ formulation. Thus we focus on tasks that isolate the successful prediction of text as a pure requirement of a performant language model. |
| Decision thresholds | N/A |
| Approaches to Uncertainty and Variability | Due to the costs of training large language models, we cannot train Gopher multiple times. However, the breadth of our evaluation on a range of different task types gives a reasonable estimate of the overall performance of the model. |
| Evaluation Data | |
| Datasets | •  Language modelling on LAMBADA, Wikitext103 ([Merity et al., 2017](#bib.bib110)), C4 ([Raffel et al., 2020a](#bib.bib131)), PG-19 ([Rae et al., 2020](#bib.bib130)) and the Pile ([Gao et al., 2020](#bib.bib53)). •  Language understanding, real world knowledge, mathematical and logical reasoning on the Massive Multitask Language Understanding (MMLU) benchmark ([Hendrycks et al., 2020](#bib.bib63)) and on the “Beyond the Imitation Game Benchmark” (BIG-bench) ([BIG-bench collaboration, 2021](#bib.bib12)). •  Question answering (closed book) on Natural Questions ([Kwiatkowski et al., 2019](#bib.bib92)) and TriviaQA ([Joshi et al., 2017](#bib.bib77)). •  Reading comprehension on RACE ([Lai et al., 2017](#bib.bib93)) •  Fact checking on FEVER ([Thorne et al., 2018](#bib.bib164)) and MultiFC ([Augenstein et al., 2019](#bib.bib6)) •  Common sense understanding on HellaSwag ([Zellers et al., 2019](#bib.bib184)), PIQA ([Bisk et al., 2020](#bib.bib13)), Winogrande ([Sakaguchi et al., 2020](#bib.bib143)), SIQA ([Sap et al., 2019](#bib.bib147)) •  Twitter dataset ([Blodgett et al., 2016](#bib.bib15)) •  Real Toxicity Prompts (RTP) ([Gehman et al., 2020](#bib.bib55)) •  CivilComments toxicity classification ([Borkan et al., 2019](#bib.bib20)) |
| Motivation | We chose fairness evaluations based on previous work studying harmful output of language models. We chose tests that covered a spectrum of potential harmful traits and biases including toxicity and distributional biases for a diverse set of attributes: gender, race, country, and religion. |
| Preprocessing | Input text is tokenized using a SentencePiece tokenizer with vocab size 32,000. The tokenizer also performs NFKC normalization. |
| Training Data | |
| See the Datasheet in [Section A.5](#A1.SS5 "A.5 MassiveText Datasheet ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") | |
| Quantitative Analyses | |
| Unitary Results | [Section 5](#S5 "5 Toxicity and Bias Analysis ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")gives a detailed description of our analysis. Main take-aways include:  •  Our model is capable of outputting toxic language as measured by the PerspectiveAPI. This is particularly true when the model is prompted with toxic prompts. •  Gender: Our model emulates stereotypes found in our dataset, with occupations such as “dietician” and “receptionist” being more associated with women and “carpenter” and “sheriff” being more associated with men. •  Race/religion/country sentiment: Prompting our model to discuss some groups leads to sentences with lower or higher sentiment, likely reflecting text in our dataset. |
| Intersectional Results | We did not investigate intersectional biases. |
| Ethical Considerations | |
| Data | The data is sourced from a variety of sources, some of it from web content. Sexually explicit content is filtered out but racist, sexist or otherwise harmful content will be contained in the dataset. |
| Human Life | The model is not intended to inform decisions about matters central to human life or flourishing. |
| Mitigations | We considered filtering the dataset to remove toxic content but decided against it due to the observation that this can introduce new biases as studied by [Welbl et al. (2021)](#bib.bib172). More work is needed on mitigation approaches to toxic content and other types of risks associated with language models, such as those discussed in [Weidinger et al. (2021)](#bib.bib171). |
| Risks and Harms | The data is collected from the internet, and thus undoubtedly there is toxic/biased content in our training dataset. Furthermore, it is likely that personal information is also in the dataset that has been used to train our models. We defer to the more detailed discussion in [Weidinger et al. (2021)](#bib.bib171). |
| Use Cases | Especially fraught use cases include the generation of factually incorrect information with the intent of distributing it or using the model to generate racist, sexist or otherwise toxic text with harmful intent. Many more use cases that could cause harm exist. Such applications to malicious use are discussed in detail in [Weidinger et al. (2021)](#bib.bib171). |

## Appendix C Lessons Learned

### C.1 Adafactor

Figure A6: 7.1B model train with Adafactor and Adam.
We found that training with Adafactor resulted in increased training instabilities at larger scales. This resulted in unhealthy training curves even at smaller learning rates and increased probability of a divergence.

We investigated using the Adafactor ([Shazeer and Stern, 2018](#bib.bib153)) optimiser instead of Adam as it provides a reduced memory footprint, potentially allowing for a larger model to be trained or fine-tuned given particular resources.
While at smaller scales we found pre-training with Adafactor to be stable and performant, at large scales we found that Adafactor resulted in reduced performance compared to Adam along with increased number of instabilities. Notably, when training a 7.1B parameter model with Adafactor we start to see minor loss divergences when compared to an Adam baseline (see [Figure A6](#A3.F6 "Figure A6 ‣ C.1 Adafactor ‣ Appendix C Lessons Learned ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")), unlike what we observed at the 1.4B parameter scale.
Larger models were also prone to increased instabilities which we attempted to mitigate by lowering the learning rate. In [Figure A6](#A3.F6 "Figure A6 ‣ C.1 Adafactor ‣ Appendix C Lessons Learned ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"), the Adam run used a maximum learning rate of $1.2\times 10^{-4}$ whereas the Adafactor run used a maximum learning rate of $6\times 10^{-5}$ and still showed instabilities.
Fine-tuning with Adafactor is also prone to divergence and is brittle to hyperparameter settings such as the learning rate and batch size.
However, as discussed in , we used Adafactor for fine-tuning Gopher as it reduced the hardware requirements considerably.

Figure A7: bfloat16 Training.
For four different combinations of float32 and bfloat16 parameters (detailed below) we show performance on three different downstream tasks using a 417M parameter model.
While bfloat16 without random rounding is clearly the least performant (blue), bfloat16 with random rounding (orange) unexpectedly under-performs full-precision training.
Storing a float32 copy of the parameters in the optimiser state alleviates this issue.

### C.2 Lower-Precision Training with bfloat16

While training with activations and model parameters in half precision (float16) can have known instabilities due to the restricted numerical range, it has been suggested that the numbers represented by bfloat16 allow for training of models without a degradation in performance compared to full float32 training ([Burgess et al., 2019](#bib.bib27)).
While Gopher was trained using bfloat16, both in its parameters and its activations, subsequent analysis showed that this resulted in many layers becoming stale.
Due to the small learning rate and the size of the parameter updates, many parameters did not register updates over many steps hampering model performance.

We investigated this, focusing on a 417 million parameter model for our testing.
The impact of bfloat16 versus full precision had clear impact at all scales during subsequent testing, as shown in [Figure A7](#A3.F7 "Figure A7 ‣ C.1 Adafactor ‣ Appendix C Lessons Learned ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") on a 417M model.
We encourage future groups to consider adding float32 parameters to a partitioned optimiser state when possible, as we found this mitigated any loss in performance.
Our headline finding was:

* We found it best to maintain float32 parameters purely for the optimiser update. One can partition the set of float32 parameters for optimisation updates alone along with the optimiser state as in [Rajbhandari et al. (2020)](#bib.bib134).
  The float32 parameters are used for the update and again cast to bfloat16 for the forward pass. This matches performance of full float32 training, improves the speed, and has only a slightly increased memory footprint compared to bfloat16 training.

A more detailed description of the four tested configurations is given below:

* •

  fp32 Everywhere: Both parameters and activations are stored in float32. Of the options, this uses the most memory but is the most precise.
* •

  bloat16 parameters without Random Rounding: The parameters and activations are cast to bfloat16. During the parameter update, no randomised rounding is used.
* •

  bloat16 parameters with Random Rounding: The parameters and activations are cast to bfloat16. During the parameter update, randomised rounding is used. The parameter is randomly rounded up or down proportional to the distance (in bfloat16 space) to either value.
* •

  bloat16 parameters with a float32 copy in the partitioned optimiser state: The parameters and activations are cast to bfloat16. However, a copy of the parameters are stored in float32 in the optimiser state and used for the update. The parameters are randomly rounded to bfloat16 for the forward pass.

In all configurations, we use fp32 for computing the attention softmax and the softmax cross-entropy in the loss. This stabilizes low-precision training with almost zero runtime cost on TPU. All methods using bfloat16 offer a similar $1.4\times$ speed improvement over fp32 everywhere.

We find that using bfloat16 parameters without random rounding performs the worst of the five tested methods– the green curve in [Figure A7](#A3.F7 "Figure A7 ‣ C.1 Adafactor ‣ Appendix C Lessons Learned ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
fp32 everywhere acts as a baseline– while it has the largest memory footprint, no compromises are made in numerical representation relative to the other methods.
We find that bfloat16 parameters with a float32 copy stored in the partitioned optimiser state is indistinguishable in performance yet offers a reduced memory footprint and a $1.4\times$ speed improvement.

## Appendix D Results

Figure A8: Results Overview. A performance overview of Gopher versus state-of-the-art performance from existing language models, supervised models and human performance where available.

### D.1 Overview

We provide a results overview in [Figure A8](#A4.F8 "Figure A8 ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") which encapsulates the raw performance of Gopher along with known language model state-of-the-art performance, supervised state-of-the-art performance and human expert performance. Here supervised approaches imply the use of task-specific data for model fine-tuning or even architecture design.

For each task category, the datasets in [Figure A8](#A4.F8 "Figure A8 ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") are arranged from in order of increasing Gopher performance, from top to bottom.
In each category it can be seen that Gopher (blue) generally equals or outperforms the language modelling state of the art (green), with human performance (red) better still, often with large gaps, indicating room for improvement. We also report the raw numerical results in [Table A5](#A4.T5 "Table A5 ‣ D.1 Overview ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

Table A5: Table of results. For the tasks considered, we show the performance of Gopher, and when available language model SOTA, supervised fine-tuned (SFT) SOTA, and Human Expert performance. A value of ‘-’ denotes that the value was not present. Language modelling results are in BPB (lower is better), the rest are in accuracy (higher is better). We show with how many shot Gopher was evaluated in parentheses after the value.

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Tag | Task | Gopher (k-Shot) | SOTA | SFT | Human Expert |
| Analogical Reasoning | Analogical Similarity | 17.2 (5) | 14.0 | - | - |
| Analogical Reasoning | Identify Odd Metaphor | 38.6 (5) | - | - | - |
| Analogical Reasoning | Odd One Out | 32.5 (5) | - | - | - |
| Common Sense | Anachronisms | 56.4 (5) | 51.0 | - | - |
| Common Sense | Causal Judgment | 50.8 (5) | - | - | - |
| Common Sense | Crash Blossom | 63.6 (5) | - | - | - |
| Common Sense | Crass AI | 56.8 (5) | - | - | - |
| Common Sense | Disambiguation Q | 45.5 (5) | - | - | - |
| Common Sense | Discourse Marker Prediction | 11.7 (5) | 15.0 | - | - |
| Common Sense | Empirical Judgments | 52.5 (5) | - | - | - |
| Common Sense | HellaSwag | 79.2 (0) | 80.2 | 93.9 | - |
| Common Sense | Irony Identification | 69.7 (5) | - | 30.0 | - |
| Common Sense | PIQA | 81.8 (0) | 82.0 | 91.3 | - |
| Common Sense | Riddle Sense | 68.2 (5) | - | - | 91.3 |
| Common Sense | SIQA | 50.6 (0) | - | - | - |
| Common Sense | Timedial | 50.9 (5) | - | 73.0 | 97.8 |
| Common Sense | Understanding Fables | 39.6 (5) | 28.0 | - | - |
| Common Sense | Winogrande | 70.1 (0) | 73.0 | 83.2 | - |
| Common Sense | Winowhy | 56.7 (5) | 43.2 | 48.2 | - |
| Emotional Intelligence | Dark Humor Detection | 83.1 (5) | - | 50.0 | - |
| Emotional Intelligence | Ruin Names | 38.6 (5) | 33.0 | - | - |
| Emotional Intelligence | SNARKS | 48.3 (5) | 43.1 | - | - |
| Ethics | Business Ethics | 70.0 (5) | 46.0 | 68.5 | 90.0 |
| Ethics | Moral Disputes | 66.8 (5) | 44.5 | 61.5 | 90.0 |
| Ethics | Moral Permissibility | 55.1 (5) | - | - | - |
| Ethics | Moral Scenarios | 40.2 (5) | 26.1 | 24.4 | 85.0 |
| Fact Checking | FEVER (2-way) | 77.5 (10) | 67.0 | - | - |
| Fact Checking | FEVER (3-way) | 77.5 (15) | - | 77.0 | - |
| Fact Checking | Known Unknowns | 63.6 (5) | 58.5 | 63.0 | - |
| Fact Checking | Misconceptions | 61.7 (5) | 30.4 | 54.8 | - |
| Fact Checking | Sentence Ambiguity | 69.1 (5) | - | - | - |
| General Knowledge | General Knowledge | 93.9 (5) | 30.0 | - | - |
| General Knowledge | Global Facts | 38.0 (5) | 37.2 | 37.0 | 80.0 |
| General Knowledge | Miscellaneous | 75.7 (5) | 60.0 | 63.7 | 80.0 |
| General Knowledge | Movie Recommendation | 50.5 (5) | 48.8 | - | - |
| General Knowledge | Natural Questions | 28.2 (64) | 29.9 | 35.2 | - |
| General Knowledge | Similarities Abstraction | 81.8 (5) | 53.9 | - | - |
| General Knowledge | Sports Understanding | 54.9 (5) | 50.0 | - | 84.0 |
| General Knowledge | TriviaQA | 57.1 (64) | 71.2 | 60.5 | - |
| Humanities | High School European History | 72.1 (5) | 53.9 | 63.2 | 95.0 |
| Humanities | High School US History | 78.9 (5) | 52.9 | 63.4 | 95.0 |
| Humanities | High School World History | 75.1 (5) | 56.1 | 63.7 | 95.0 |
| Humanities | Hindu Knowledge | 80.0 (5) | 34.2 | 40.0 | - |
| Humanities | International Law | 77.7 (5) | 55.3 | 65.7 | 90.0 |
| Humanities | Jurisprudence | 71.3 (5) | 54.5 | 64.4 | 90.0 |
| Humanities | Logical Fallacies | 72.4 (5) | 47.8 | 61.5 | 95.0 |
| Humanities | Management | 77.7 (5) | 56.3 | 72.3 | 95.0 |
| Humanities | Marketing | 83.3 (5) | 59.8 | 82.2 | 90.0 |
| Humanities | Philosophy | 68.8 (5) | 51.2 | 53.6 | 80.0 |
| Humanities | Prehistory | 67.6 (5) | 52.7 | 52.2 | 90.0 |
| Humanities | Professional Law | 44.5 (5) | 34.8 | 39.5 | 92.0 |
| Humanities | World Religions | 84.2 (5) | 54.9 | 60.6 | 90.0 |
| Logical Reasoning | Analytic Entailment | 53.0 (5) | - | - | - |
| Logical Reasoning | Date Understanding | 44.1 (5) | 17.2 | - | - |
| Logical Reasoning | Entailed Polarity | 89.5 (5) | 66.4 | - | - |
| Logical Reasoning | Epistemic Reasoning | 56.4 (5) | - | - | - |
| Logical Reasoning | Evaluating Information Essentiality | 16.7 (5) | 23.5 | - | - |
| Logical Reasoning | Logic Grid Puzzle | 35.1 (5) | - | - | - |
| Logical Reasoning | Logical Args | 59.1 (5) | - | - | - |
| Logical Reasoning | Logical Fallacy Detection | 58.9 (5) | - | - | - |
| Logical Reasoning | Logical Sequence | 36.4 (5) | 44.8 | - | - |
| Logical Reasoning | Metaphor Boolean | 59.3 (5) | 41.0 | - | - |
| Logical Reasoning | Navigate | 51.1 (5) | 45.2 | - | - |
| Logical Reasoning | Novel Concepts | 59.1 (5) | 28.0 | 31.2 | - |
| Logical Reasoning | Penguins In A Table | 40.6 (5) | 28.2 | - | - |
| Logical Reasoning | Physical Intuition | 59.7 (5) | 26.3 | - | - |
| Logical Reasoning | Presuppositions As NLI | 34.0 (5) | 37.7 | - | - |
| Logical Reasoning | Reasoning About Colored Objects | 49.2 (5) | - | - | 100.0 |
| Logical Reasoning | StrategyQA | 61.0 (5) | 60.1 | 54.4 | 87.0 |
| Logical Reasoning | Temporal Sequences | 19.0 (5) | - | - | - |
| Maths | Abstract Algebra | 25.0 (5) | 30.0 | 29.0 | 95.0 |
| Maths | College Mathematics | 37.0 (5) | 35.0 | 35.2 | 92.0 |
| Maths | Elementary Mathematics | 33.6 (5) | 29.9 | 35.2 | 95.0 |
| Maths | Formal Logic | 35.7 (5) | 29.5 | 26.5 | 90.0 |
| Maths | High School Mathematics | 23.7 (5) | 28.1 | 30.6 | 85.0 |
| Maths | Mathematical Induction | 57.6 (5) | 60.8 | - | - |
| Maths | Professional Accounting | 44.3 (5) | 33.0 | 40.1 | 95.0 |
| Medicine | Anatomy | 56.3 (5) | 47.4 | 43.2 | 90.0 |
| Medicine | Clinical Knowledge | 67.2 (5) | 47.4 | 52.9 | 90.0 |
| Medicine | College Medicine | 60.1 (5) | 47.6 | 44.1 | 90.0 |
| Medicine | Human Aging | 66.4 (5) | 49.8 | 53.3 | 90.0 |
| Medicine | Human Organs Senses Multiple Choice | 84.8 (5) | 40.9 | - | - |
| Medicine | Medical Genetics | 69.0 (5) | 39.9 | 40.1 | 90.0 |
| Medicine | Nutrition | 69.9 (5) | 46.6 | 49.4 | 90.0 |
| Medicine | Professional Medicine | 64.0 (5) | 35.8 | 46.3 | 87.0 |
| Medicine | Virology | 47.0 (5) | 45.1 | 45.4 | 90.0 |
| Reading Comprehension | English Proverbs | 57.6 (5) | - | - | - |
| Reading Comprehension | Fantasy Reasoning | 64.1 (5) | 51.0 | - | - |
| Reading Comprehension | Figure Of Speech Detection | 52.7 (5) | 10.0 | - | - |
| Reading Comprehension | Formal Fallacies Syllogisms Negation | 50.7 (5) | 50.0 | - | - |
| Reading Comprehension | GRE Reading Comprehension | 27.3 (5) | - | - | - |
| Reading Comprehension | Hyperbaton | 51.7 (5) | - | - | - |
| Reading Comprehension | Implicatures | 62.0 (5) | - | - | - |
| Reading Comprehension | Implicit Relations | 36.4 (5) | 9.0 | - | - |
| Reading Comprehension | Intent Recognition | 88.7 (5) | 83.5 | - | - |
| Reading Comprehension | LAMBADA | 74.5 (0) | 76.6 | - | - |
| Reading Comprehension | Movie Dialog Same Or Different | 50.7 (5) | 51.9 | 54.0 | - |
| Reading Comprehension | Nonsense Words Grammar | 61.4 (5) | 18.0 | - | 100.0 |
| Reading Comprehension | Phrase Relatedness | 81.8 (5) | 37.5 | - | - |
| Reading Comprehension | Question Selection | 41.4 (5) | 39.2 | - | - |
| Reading Comprehension | RACE-h | 71.6 (5) | 47.9 | 90.5 | 94.2 |
| Reading Comprehension | RACE-m | 75.1 (5) | 58.1 | 93.6 | 95.4 |
| Science/Technology | Astronomy | 65.8 (5) | 48.6 | 46.6 | 90.0 |
| Science/Technology | College Biology | 70.8 (5) | 45.1 | 40.4 | 80.0 |
| Science/Technology | College Chemistry | 45.0 (5) | 26.0 | 34.0 | 90.0 |
| Science/Technology | College Computer Science | 49.0 (5) | 46.0 | 43.2 | 85.0 |
| Science/Technology | College Physics | 34.3 (5) | 27.5 | 32.4 | 80.0 |
| Science/Technology | Computer Security | 65.0 (5) | 57.1 | 64.3 | 90.0 |
| Science/Technology | Conceptual Physics | 49.4 (5) | 36.6 | 44.1 | 95.0 |
| Science/Technology | Electrical Engineering | 60.0 (5) | 49.6 | 48.2 | 90.0 |
| Science/Technology | High School Biology | 71.3 (5) | 48.2 | 52.8 | 95.0 |
| Science/Technology | High School Chemistry | 47.8 (5) | 33.2 | 36.1 | 90.0 |
| Science/Technology | High School Computer Science | 54.0 (5) | 39.0 | 49.8 | 95.0 |
| Science/Technology | High School Physics | 33.8 (5) | 27.7 | 41.0 | 90.0 |
| Science/Technology | High School Statistics | 50.0 (5) | 30.9 | 34.0 | 90.0 |
| Science/Technology | Machine Learning | 41.1 (5) | 31.3 | 33.3 | 85.0 |
| Science/Technology | Physics MC | 50.9 (5) | 21.4 | - | - |
| Social Sciences | Econometrics | 43.0 (5) | 33.2 | 30.2 | 90.0 |
| Social Sciences | High School Geography | 76.8 (5) | 57.3 | 65.5 | 90.0 |
| Social Sciences | High School Government and Politics | 83.9 (5) | 57.5 | 72.3 | 95.0 |
| Social Sciences | High School Macroeconomics | 65.1 (5) | 40.3 | 47.2 | 90.0 |
| Social Sciences | High School Microeconomics | 66.4 (5) | 41.9 | 53.0 | 90.0 |
| Social Sciences | High School Psychology | 81.8 (5) | 60.6 | 71.7 | 95.0 |
| Social Sciences | Human Sexuality | 67.2 (5) | 54.1 | 49.6 | 90.0 |
| Social Sciences | Professional Psychology | 68.1 (5) | 44.7 | 48.3 | 90.0 |
| Social Sciences | Public Relations | 71.8 (5) | 48.0 | 58.5 | 90.0 |
| Social Sciences | Security Studies | 64.9 (5) | 51.4 | 49.3 | 90.0 |
| Social Sciences | Sociology | 84.1 (5) | 53.1 | 64.9 | 95.0 |
| Social Sciences | US Foreign Policy | 81.0 (5) | 68.9 | 64.4 | 90.0 |
| Language Modelling | DM Mathematics | 1.14 (0) | 1.04 | - | - |
| Language Modelling | Ubuntu IRC | 1.09 (0) | 0.857 | - | - |
| Language Modelling | OpenSubtitles | 0.899 (0) | 0.879 | - | - |
| Language Modelling | OpenWebtext2 | 0.677 (0) | 0.624 | - | - |
| Language Modelling | HackerNews | 0.890 (0) | 0.869 | - | - |
| Language Modelling | Books3 | 0.712 (0) | 0.802 | - | - |
| Language Modelling | Bookcorpus2 | 0.741 (0) | 0.779 | - | - |
| Language Modelling | Pile CC | 0.691 (0) | 0.669 | - | - |
| Language Modelling | PhilPapers | 0.695 (0) | 0.723 | - | - |
| Language Modelling | Gutenberg PG-19 | 0.656 (0) | 0.890 | - | - |
| Language Modelling | ArXiv | 0.662 (0) | 0.680 | - | - |
| Language Modelling | StackExchange | 0.641 (0) | 0.655 | - | - |
| Language Modelling | NIH ExPorter | 0.590 (0) | 0.590 | - | - |
| Language Modelling | PubMed Abstracts | 0.577 (0) | 0.587 | - | - |
| Language Modelling | WikiText-103 | 0.566 (0) | 0.640 | - | - |
| Language Modelling | USPTO Backgrounds | 0.546 (0) | 0.537 | - | - |
| Language Modelling | PubMed Central | 0.525 (0) | 0.579 | - | - |
| Language Modelling | FreeLaw | 0.513 (0) | 0.514 | - | - |
| Language Modelling | Curation Corpus | 0.475 (0) | - | - | - |
| Language Modelling | GitHub | 0.377 (0) | 0.358 | - | - |

### D.2 Pile

We evaluate Gopher and its family of smaller models on The Pile, which is a suite of language model benchmarks ([Gao et al., 2020](#bib.bib53)). The Pile compiles a set of published language model benchmarks spanning books (PG-19, Books2-3), web-based text (OpenWebText2, Pile-CC), mathematics (DM Mathematics), code (Github, StackExchange), conversational data (Ubuntu IRC, Enron), academic texts (arXiv, PubMed, Philpapers), subtitles (YouTube Subtitles, OpenSubtitles) and several other data-sources. We evaluate on a subset of these datasets, as some contain licensing restrictions. For all subsets we evaluate the model’s loss per UTF-8 byte (versus loss per token, which is model specific). We report this as ‘bits per byte’ which is the total log loss (base 2) divided by the number of UTF-8 bytes in the text.
We display the raw values in [Table A7](#A4.T7 "Table A7 ‣ D.4 Filtering Test-Set Documents ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
For 10/18 tasks Gopher achieves SOTA performance, with the largest relative gains on Gutenberg, GitHub, PubMed, arXiv, and Stackexchange.
Gopher performs relatively worse on Ubuntu IRC, DM\_Mathematics, and OpenWebText.
Compared to Jurassic-1 ([Lieber et al., 2021](#bib.bib104)), Gopher performs better on 8/16 tasks, identical on one, and worse on the remaining 7/16. GPT-3 achieves the best performance on OpenWebText2, a value not reported by Jurassic-1.

### D.3 Language Modelling

We first display evaluation curves calculated periodically during training in [Figure A9](#A4.F9 "Figure A9 ‣ D.3 Language Modelling ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").
The evaluation curves are for four language model benchmarks that we explicitly filtered from the training set. These include Wikitext103 ([Merity et al., 2017](#bib.bib110)), LAMBADA ([Paperno et al., 2016](#bib.bib121)), and Curation Corpus ([Curation, 2020](#bib.bib38)) and C4 ([Raffel et al., 2020a](#bib.bib131)). We see the natural ordering of data efficiency and better performance (via lower log-loss) with model scale. In [Figure A9](#A4.F9 "Figure A9 ‣ D.3 Language Modelling ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") and [Table A6](#A4.T6 "Table A6 ‣ D.4 Filtering Test-Set Documents ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") we contrast the final performance to published results.

Figure A9: Online Evaluation curves. Zero-shot performance on the C4, Curation Corpus, LAMBADA, and WikiText-103 evaluation sets during training.
The largest models did not have an evaluator running during the entirety of training. A more detailed summary can be found in [Table A6](#A4.T6 "Table A6 ‣ D.4 Filtering Test-Set Documents ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

### D.4 Filtering Test-Set Documents

Comparing the performance of language models trained on different data is challenging. One of the main reasons is that memorisation can aid language model performance ([Carlini et al., 2019](#bib.bib31)), and different training datasets means different memorisation potential. Fundamentally we want to use language models for applications where novel text or communication can arise, and thus be able to track the generalisation ability of models via our selected benchmarks.

One response to this memorisation-generalisation ambiguity is to refrain from reporting language model performance: e.g., [Brown et al. (2020)](#bib.bib25) discuss the decision to withhold the majority of results — they report numbers only on the Mikolov-processed version of Penn Treebank (PTB) ([Marcus et al., 1993](#bib.bib109); [Mikolov et al., 2011](#bib.bib113)).1717
17
This is a collection of Wall Street Journal articles from the 1990s and was deemed a reasonable test set due to an empirically low co-occurrence of long $n$-grams with the training set, likely due to the text’s age. However it is possible that language modelling is simply an easier task to measure train-test leakage (via $n$-gram overlap). For question-answering or translation, the existence of a paraphrased context in the training set can be enough for the test instance to be more trivially solved. Whilst [Brown et al. (2020)](#bib.bib25) do refrain from reporting language modelling, they do report performance numbers on question answering, translation, and even simple arithmetic tasks that all could draw heavily on training-set memorisation in ways that an n-gram filter may not easily detect.

We take the approach of filtering training documents that have a high similarity to test-set documents using a filter based on Jaccard similarity of $n$-grams ([Section A.1.1](#A1.SS1.SSS1.Px5 "Test-set Filtering (All subsets) ‣ A.1.1 Pipeline stages ‣ A.1 Dataset Pipeline ‣ Appendix A MassiveText ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")). This includes WikiText-103, Curation Corpus summarisation, LAMBADA. For test sets that have been built since MassiveText was constructed (November 2020), such as the Pile, MMLU, and BIG-bench this has not been applied. In this setting, we decide to report numbers versus train a new model on an updated dataset. This is partly a pragmatic decision — new evaluation benchmarks will frequently arise over time and re-training is expensive. Furthermore many new benchmarks are constructed to be resilient to test-set leakage such as BIG-bench, which relies on human-curated test examples and has mechanisms to avoid being scraped from the web. We take the approach of reporting a wide set of performance numbers with the principle that aggregate findings across several benchmark tasks to be sufficient for robust conclusions.

| Model | LAMBADA (acc) | Wikitext103 (ppl) | Curation Corpus (ppl) |
| --- | --- | --- | --- |
| 44M | 30.1% | 41.54 | 29.41 |
| 117M | 41.2% | 28.01 | 19.26 |
| 417M | 51.9% | 19.48 | 13.65 |
| 1.4B | 62.1% | 14.29 | 10.5 |
| 7.1B | 68.5% | 10.81 | 8.77 |
| 280B | 74.5% | 8.12 | 7.75 |

Table A6: Zero-shot performance of our models on downstream tasks. We show Wikitext103 and Curation Corpus validation perplexity along with LAMBADA accuracy.

|  | Gopher | Jurassic | GPT-3 |
| --- | --- | --- | --- |
| dm\_mathematics | 1.14 | 1.04 | 1.37 |
| ubuntu\_irc | 1.09 | 0.857 | 0.946 |
| opensubtitles | 0.899 | 0.879 | 0.932 |
| openwebtext2 | 0.677 | - | 0.624 |
| hackernews | 0.890 | 0.869 | 0.975 |
| books3 | 0.712 | 0.835 | 0.802 |
| bookcorpus2 | 0.741 | - | 0.779 |
| pile\_cc | 0.691 | 0.669 | 0.698 |
| philpapers | 0.695 | 0.741 | 0.723 |
| gutenberg\_pg\_19 | 0.656 | 0.890 | 1.16 |
| arxiv | 0.662 | 0.680 | 0.838 |
| stackexchange | 0.641 | 0.655 | 0.773 |
| nih\_exporter | 0.590 | 0.590 | 0.612 |
| pubmed\_abstracts | 0.577 | 0.587 | 0.625 |
| uspto\_backgrounds | 0.546 | 0.537 | 0.566 |
| pubmed\_central | 0.525 | 0.579 | 0.690 |
| freelaw | 0.513 | 0.514 | 0.612 |
| github | 0.377 | 0.358 | 0.645 |

Table A7: The Pile.
The BPB for GPT-3 and Jurassic are taken from the Jurassic paper ([Lieber et al., 2021](#bib.bib104)) when applicable, otherwise they are from ([Gao et al., 2020](#bib.bib53)).

### D.5 Scaling Curves

We display the scaling curves over a number of downstream language model benchmarks. We plot the evaluation loss, measured in terms of bits per byte, versus model parameters excluding embeddings on a log-log scale. A straight line indicates the existence of a power law as discovered by [Kaplan et al. (2020)](#bib.bib80). We see an approximately linear fit from 417M $\rightarrow$ 7.1B parameters however Gopher noticeably deviates from this power law fit indicating it is either under-trained or the trend deviates from a power law at this scale.

Figure A10: Scaling Curves. Plotting parameters versus evaluation loss, in bits per byte. Both axes are log-scale to inspect the presence of a power-law. Whilst this appears to hold at smaller scale, the 280B Gopher model has notably deviated from this trend.

It is worth noting the scaling law does appear to hold for PG-19 however for many other datasets, notably Curation Corpus (summarisation) the trend is far off.

### D.6 Scaling Context Length

Alongside the scaling of parameters, we investigate the effect on increasing the context length used during evaluation time. We plot the relative percent increase in performance (measured by the ratios of BPB as described in [Section D.2](#A4.SS2 "D.2 Pile ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher")) of Gopher provided with a context window of $L$ versus Gopher provided with a context window of $1000$ in [Figure A11](#A4.F11 "Figure A11 ‣ D.6 Scaling Context Length ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"). Because we evaluate the model with a sliding window, where we shift the model along by $L/2$ tokens, this means the model’s predictions have a variable context length from $L/2$ to $L$.

Figure A11: Context Length Scaling. Relative performance improvement of increasing the evaluation sequence length of Gopher (trained with 2048) versus a model evaluated with a sequence length of $1024$. We observe the largest gains for articles and code: ArXiv, GitHub, PubMed and PhilPapers. Reassuringly, we see no gains for PubMed Abstracts.

Because Gopher was trained with a sequence length of $2048$ it does not generalise well to relative positional encodings that exceed this boundary. We observe (although do not report) a sharp degradation in performance via naive context length scaling. However we can clamp the maximum time position to $2048$ and extend the context length with either an improvement in performance — notably for articles and code (arXiv, GitHub, PubMed, PhilPapers) or no improvement — notably for PubMed Abstracts. Interestingly we see a smaller performance improvement for Books (BookCorpus2, Books3, PG-19 ([Rae et al., 2020](#bib.bib130))) which could suggest many of these books do not contain long-range dependencies, despite being long, or that Gopher is not yet sufficiently powerful to condition on them.

The result on books is surprising — e.g. PG-19 was developed specifically to test long-range language modelling capability — but it appears to be echoed with recent contemporary work. [Sun et al. (2021)](#bib.bib163) investigate whether language models learn interesting long-range dependencies on book data. One finding from this work is that these book collections can contain texts which are compendiums of magazine articles (which do not greatly benefit from large contexts) along with fiction texts (which do continue to benefit from longer contexts). Thus part of the story is in extracting more granular evaluation sets.

The ability to extrapolate to a larger context length at evaluation time is a useful property because training with very long contexts can be computationally expensive. In this study, this extrapolation property motivated the use of the relative positional encodings scheme from ([Dai et al., 2019](#bib.bib40)) versus the more conventional absolute positional encoding scheme ([Vaswani et al., 2017](#bib.bib166); [Brown et al., 2020](#bib.bib25)). The reason the positional encodings can extrapolate well is because we can clamp the maximum relative time — whereas it is not possible to clamp the absolute positions. Contemporary work has also verified that absolute positional time encodings extrapolate poorly to longer sequence lengths and has proposed an alternative temporal encoding scheme ALiBi ([Press et al., 2021](#bib.bib127)). It would be interesting to compare the extrapolation capabilities between these two temporal representation approaches.

At present, there is a side effect via maximum time-step clamping of preventing the model from understanding the relative positions of distant text. For tokens beyond $2048$ timesteps ago, all relative times are equal and thus ablation experiments to shuffle the distant past (as performed by [Sun et al. (2021)](#bib.bib163) for example) will not yield any performance improvement. An interesting challenge will be to determine a strong scheme for temporal extrapolation that still respects the understanding of absolute and relative time.

### D.7 MMLU

(a) Model Comparison

(b) Gopher versus June ’22 forecasts.

Figure A12: MMLU Model Comparison.
(a) Average accuracy over 57 multiple-choice problems ([Hendrycks et al., 2020](#bib.bib63)).
The family of Gopher and GPT-3 models are evaluated 5-shot with no additional fine-tuning.
GPT-2 and RoBERTa and UnifiedQA (a fine-tuned T5 model) are fine-tuned on tailored QA data.
(b) 5-shot Gopher and GPT-3 performance on a scale ranging from average human rater performance (34.5%) to estimated per-task human expert performance (89.8%) ([Hendrycks et al., 2020](#bib.bib63)). The forecasted distribution of SOTA performance on MMLU for June 2022 ([Steinhardt, 2021](#bib.bib161)) is also shown.

The Massive Multitask Language Understanding (MMLU) benchmark is a set of 57 multiple-choice problems proposed by [Hendrycks et al. (2020)](#bib.bib63) that emulate human exams. Whilst this is dubbed language understanding, it is not aimed at probing linguistic capabilities such as co-reference resolution but is instead aimed at testing a model’s ability across a wide range of academic subjects — from computer science to history to law. Having world knowledge is beneficial to many of the tasks, but logical and mathematical reasoning is also tested. An example problem is displayed below (we evaluated in the 5-shot setting but show the 1-shot case for simplicity):

```
A highly knowledgeable and intelligent AI answers multiple-choice questions about High School Macroeconomics.

Which of the following policies best describes supply-side fiscal policy?
(A) An increase in the money supply
(B) Increased government spending
(C) Lower taxes on research and development of new technology
(D) Higher taxes on household income

Answer: (C) Lower taxes on research and development of new technology

Of the following choices the most direct exchange in the circular flow model of
a private closed economy is when
(A) households provide goods to firms in exchange for wage payments.
(B) households provide resources to firms in exchange for goods.
(C) households provide revenues to firms in exchange for wage payments.
(D) firms supply goods to households in exchange for revenues.

Answer:
```

We scored the immediate completions ‘ (A)’, ‘ (B)’, etc. and selected the response with the highest probability.

Figure A13: Gopher calibration on MMLU. Each point represents a topic.

We see a breakdown of performance across the family of Gopher models per MMLU task in [14(a)](#A4.F14.sf1 "14(a) ‣ Figure A14 ‣ D.7 MMLU ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"). For 55 tasks of 57 Gopher outperforms smaller-scale models, and in most cases we see a significant leap in performance. For Abstract Algebra and High School Mathematics there is not a positive trend in terms of performance with scale, suggesting larger models are unlikely to spontaneously understand these topics. When comparing Gopher to the SOTA unsupervised model on this benchmark, GPT-3, we see a significant improvement on all tasks except the aforementioned Abstract Algebra and High School Mathematics (where both models perform with very low performance). Some of the largest performance gain is obtained for knowledge-intensive tasks such as medicine, history, politics, world religions and sociology. Alongside a strong performance, we find in [Figure A13](#A4.F13 "Figure A13 ‣ D.7 MMLU ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") that Gopher produces a calibrated prediction.

Although pairwise model comparisons can be illustrative, it can be sometimes useful to pitch them against human performance and predicted future performance to gauge progress. In [12(b)](#A4.F12.sf2 "12(b) ‣ Figure A12 ‣ D.7 MMLU ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher") we plot the overall average performance of 5-shot prompted Gopher (60.0%) and GPT-3 (43.9%) against human-rater performance (34.5%) and the estimated human expert performance per task (89.8%), where the comparison values are obtained from ([Hendrycks et al., 2020](#bib.bib63)). We also compare to the distribution of $77$ professional forecasters, who are attempting to estimate the state-of-the-art performance on this task by June 2022 who on average estimate a 57.1% accuracy (see [Steinhardt (2021)](#bib.bib161) for further details of the methodology). We find Gopher almost halves the accuracy gap from GPT-3 to human expert performance and exceeds forecaster expectations.

We display the raw results on the Massive Multitask Language Understanding (MMLU) suite of tasks.

(a) Gopher family task breakdown.

(b) Gopher vs GPT-3, both evaluated 5-shot.

Figure A14: MMLU Task Breakdown. Accuracy across 57 MMLU tasks spanning STEM, humanities, legal and business domains. Tasks consist of multiple choice questions, each with four responses — 25% indicates chance. Gopher provides a significant improvement over smaller models for most tasks, notable exceptions being Abstract Algebra and High School Mathematics where scale appears to hurt. A comparison with GPT-3 175B is displayed in (b) where Gopher improves accuracy on 55 of the tasks. Gopher is also well-calibrated on this task, see [Figure A13](#A4.F13 "Figure A13 ‣ D.7 MMLU ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher").

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | 417M | 1.4B | 7.1B | 280B |
| Abstract Algebra | 23.0 | 28.0 | 28.0 | 25.0 |
| Anatomy | 33.3 | 25.2 | 36.3 | 56.3 |
| Astronomy | 19.1 | 34.2 | 28.9 | 65.8 |
| Business Ethics | 24.0 | 23.0 | 37.0 | 70.0 |
| Clinical Knowledge | 27.2 | 26.4 | 30.6 | 67.2 |
| College Biology | 27.1 | 27.1 | 27.1 | 70.8 |
| College Chemistry | 20.0 | 23.0 | 31.0 | 45.0 |
| College Computer Science | 25.0 | 40.0 | 36.0 | 49.0 |
| College Mathematics | 27.0 | 30.0 | 25.0 | 37.0 |
| College Medicine | 24.3 | 28.9 | 22.0 | 60.1 |
| College Physics | 17.6 | 23.5 | 20.6 | 34.3 |
| Computer Security | 26.0 | 24.0 | 25.0 | 65.0 |
| Conceptual Physics | 21.3 | 24.3 | 30.6 | 49.4 |
| Econometrics | 22.8 | 24.6 | 25.4 | 43.0 |
| Electrical Engineering | 24.1 | 21.4 | 33.1 | 60.0 |
| Elementary Mathematics | 26.7 | 27.5 | 26.2 | 33.6 |
| Formal Logic | 17.5 | 26.2 | 18.3 | 35.7 |
| Global Facts | 21.0 | 33.0 | 31.0 | 38.0 |
| High School Biology | 25.5 | 28.7 | 29.4 | 71.3 |
| High School Chemistry | 29.6 | 25.1 | 26.6 | 47.8 |
| High School Computer Science | 33.0 | 23.0 | 32.0 | 54.0 |
| High School European History | 30.9 | 26.7 | 30.9 | 72.1 |
| High School Geography | 26.8 | 28.8 | 33.3 | 76.8 |
| High School Government And Politics | 20.2 | 33.7 | 38.9 | 83.9 |
| High School Macroeconomics | 25.6 | 33.3 | 27.7 | 65.1 |
| High School Mathematics | 27.0 | 24.8 | 23.0 | 23.7 |
| High School Microeconomics | 21.0 | 33.2 | 23.9 | 66.4 |
| High School Physics | 27.8 | 31.1 | 27.8 | 33.8 |
| High School Psychology | 25.9 | 32.5 | 31.4 | 81.8 |
| High School Statistics | 38.4 | 25.5 | 47.2 | 50.0 |
| High School US History | 26.0 | 25.0 | 27.9 | 78.9 |
| High School World History | 26.6 | 23.2 | 30.8 | 75.1 |
| Human Aging | 21.1 | 12.1 | 37.2 | 66.4 |
| Human Sexuality | 18.3 | 27.5 | 32.1 | 67.2 |
| International Law | 35.5 | 36.4 | 27.3 | 77.7 |
| Jurisprudence | 19.4 | 21.3 | 32.4 | 71.3 |
| Logical Fallacies | 26.4 | 30.1 | 23.9 | 72.4 |
| Machine Learning | 22.3 | 19.6 | 38.4 | 41.1 |
| Management | 23.3 | 31.1 | 31.1 | 77.7 |
| Marketing | 25.2 | 25.6 | 27.4 | 83.3 |
| Medical Genetics | 14.0 | 19.0 | 24.0 | 69.0 |
| Miscellaneous | 25.5 | 20.8 | 30.3 | 75.7 |
| Moral Disputes | 24.0 | 28.9 | 28.9 | 66.8 |
| Moral Scenarios | 24.7 | 27.3 | 24.1 | 40.2 |
| Nutrition | 24.8 | 31.4 | 32.0 | 69.9 |
| Philosophy | 29.3 | 30.2 | 32.5 | 68.8 |
| Prehistory | 30.2 | 27.2 | 28.4 | 67.6 |
| Professional Accounting | 27.0 | 26.2 | 26.2 | 44.3 |
| Professional Law | 26.7 | 27.6 | 28.5 | 44.5 |
| Professional Medicine | 26.8 | 24.6 | 39.7 | 64.0 |
| Professional Psychology | 27.8 | 28.8 | 24.8 | 68.1 |
| Public Relations | 19.1 | 23.6 | 28.2 | 71.8 |
| Security Studies | 20.8 | 40.0 | 35.9 | 64.9 |
| Sociology | 26.4 | 28.4 | 32.8 | 84.1 |
| US Foreign Policy | 26.0 | 25.0 | 38.0 | 81.0 |
| Virology | 28.9 | 18.7 | 34.3 | 47.0 |
| World Religions | 29.2 | 27.5 | 30.4 | 84.2 |
| Overall | 25.7 | 27.3 | 29.5 | 60.0 |

Table A8: 5-Shot MMLU Accuracy by Model Size.

### D.8 BIG-bench

The Beyond the Imitation Game Benchmark (BIG-bench) ([BIG-bench collaboration, 2021](#bib.bib12)) is a collection of evaluation tasks intended to probe the abilities of large language models. Tasks include traditional natural language processing tasks, for example reading comprehension and question answering, as well as tasks that require other capabilities, such as (1) logical and mathematical reasoning, (2) an understanding of the world, for example, causal and physical reasoning, (3) an understanding of humans, for example, social reasoning and theory of mind or (4) scientific understanding among others.

There are two ways that LMs can be evaluated on a BIG-bench task: either in a generative setting, where the LM must predict a response to the prompt; or in a multiple choice setting, where the LM must evaluate the log-probability of a collection of possible answers, selecting the one with the highest log-probability as the answer. In this work we concentrate on the multiple choice setting without fine-tuning. This is because we aim to focus on the most direct capability of language models — which is to score the probability of text. The multiple-choice formulation simply requires scoring the prompt and responses, and selecting the argmax. Open-ended generative tasks rely on both good language model estimation but also good “decoding” techniques — e.g., appropriate sampling approaches, the use of search, reward models etc. which can conflate a mixture of model capability and decoding sophistication. We next detail which tasks we focus on.

#### D.8.1 Task Selection

BIG-bench currently contains over 160 tasks split into over 974 sub-tasks. We select a set of 63 tasks for evaluation, considering multiple-choice JSON tasks.
We also remove tasks that are not in English since our models are trained principally on English text only. Additionally, we remove tasks that test the ability of the models to deal with long contexts or the tokenisation properties of the models, since we are interested in evaluating the semantic capabilities of our models.

Concretely we exclude BIG-bench tasks that contain one or more of the following keywords: translation, low-resource language, non-English, multilingual, example task, programmatic, non-language, context length, tokenization. We also manually filter out the tasks, entailed\_polarity\_hindi, dyck\_languages and persian\_multiple\_choice, since they are not in English, and suicide\_risk, since we do not consider this task to be an appropriate application of language models. The $62$ tasks that we restrict to are detailed in [Table A9](#A4.T9 "Table A9 ‣ D.8.1 Task Selection ‣ D.8 BIG-bench ‣ Appendix D Results ‣ Scaling Language Models: Methods, Analysis & Insights from Training Gopher"), this is broken down by category in  and the distribution of task categories is detailed in .

The final $62$ tasks selected from BIG-bench for our analysis are listed below:

|  |
| --- |
| anachronisms, analogical\_similarity, analytic\_entailment, causal\_judgment, crash\_blossom, crass\_ai, dark\_humor\_detection, date\_understanding, disambiguation\_q, discourse\_marker\_prediction, empirical\_judgments, english\_proverbs, entailed\_polarity, epistemic\_reasoning, evaluating\_information\_essentiality, fantasy\_reasoning, figure\_of\_speech\_detection, formal\_fallacies\_syllogisms\_negation, general\_knowledge\_json, gre\_reading\_comprehension, hindu\_knowledge, Human\_organs\_senses\_multiple\_choice, hyperbaton, identify\_odd\_metaphor, implicatures, implicit\_relations, intent\_recognition, irony\_identification, known\_unknowns, logic\_grid\_puzzle, logical\_args, logical\_fallacy\_detection, logical\_sequence, mathematical\_induction, metaphor\_boolean, misconceptions, moral\_permissibility, movie\_dialog\_same\_or\_different, movie\_recommendation, navigate, nonsense\_words\_grammar, novel\_concepts, odd\_one\_out, penguins\_in\_a\_table, phrase\_relatedness, physical\_intuition, physics\_mc, presuppositions\_as\_nli, question\_selection, reasoning\_about\_colored\_objects, riddle\_sense, ruin\_names, sentence\_ambiguity, similarities\_abstraction, SNARKS, sports\_understanding, strategyqa, temporal\_sequences, timedial, understanding\_fables, vitaminc\_fact\_verification, winowhy. |

Table A9: BIG-bench Selected Tasks. A set of 62 English-language multiple choice tasks.

|  |  |
| --- | --- |
| Task Type | Constituent Tasks |
