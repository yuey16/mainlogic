<!-- fulltext source=arxiv_html slug=arXiv-2007.00644 fetched=2026-09-22T13:23:45+00:00 -->

# Measuring Robustness to Natural Distribution Shifts in Image Classification

Rohan Taori     
Achal Dave     
Vaishaal Shankar

UC Berkeley     
CMU     
UC Berkeley

Nicholas Carlini     
Benjamin Recht     
Ludwig Schmidt

Google Brain     
UC Berkeley     
UC Berkeley

###### Abstract

We study how robust current ImageNet models are to distribution shifts arising from natural variations in datasets.
Most research on robustness focuses on synthetic image perturbations (noise, simulated weather artifacts, adversarial examples, etc.), which leaves open how robustness on synthetic distribution shift relates to distribution shift arising in real data.
Informed by an evaluation of 204 ImageNet models in 213 different test conditions, we find that there is often little to no transfer of robustness from current synthetic to natural distribution shift.
Moreover, most current techniques provide no robustness to the natural distribution shifts in our testbed.
The main exception is training on larger and more diverse datasets, which in multiple cases increases robustness, but is still far from closing the performance gaps.
Our results indicate that distribution shifts arising in real data are currently an open research problem.
We provide our testbed and data as a resource for future work at <https://modestyachts.github.io/imagenet-testbed/>.

## 1 Introduction

Reliable classification under distribution shift is still out of reach for current machine learning [[65](#bib.bib65), [91](#bib.bib91), [68](#bib.bib68)].
As a result, the research community has proposed a wide range of evaluation protocols that go beyond a single, static test set.
Common examples include noise corruptions [[33](#bib.bib33), [38](#bib.bib38)], spatial transformations [[29](#bib.bib29), [28](#bib.bib28)], and adversarial examples [[84](#bib.bib84), [5](#bib.bib5)].
Encouragingly, the past few years have seen substantial progress in robustness to these distribution shifts, e.g., see [[55](#bib.bib55), [114](#bib.bib114), [34](#bib.bib34), [115](#bib.bib115), [28](#bib.bib28), [105](#bib.bib105), [93](#bib.bib93), [96](#bib.bib96), [57](#bib.bib57), [13](#bib.bib13), [66](#bib.bib66)] among many others.
However, this progress comes with an important limitation: all of the aforementioned distribution shifts are *synthetic*: the test examples are derived from well-characterized image modifications at the pixel level.

Synthetic distribution shifts are a good starting point for experiments since they are precisely defined and easy to apply to arbitrary images.
However, classifiers ultimately must be robust to distribution shifts arising naturally in the real world.
These distribution shifts may include subtle changes in scene compositions, object types, lighting conditions, and many others.
Importantly, these variations are *not* precisely defined because they have not been created artificially.
The hope is that an ideal robust classifier is still robust to such natural distribution shifts.

In this paper, we investigate how robust current machine learning techniques are to distribution shift arising naturally from real image data without synthetic modifications.
To this end, we conduct a comprehensive experimental study in the context of ImageNet [[18](#bib.bib18), [70](#bib.bib70)].
ImageNet is a natural starting point since it has been the focus of intense research efforts over the past decade and a large number of pre-trained classification models, some with robustness interventions, are available for this task.
The core of our experimental study is a testbed of 204 pre-trained ImageNet models that we evaluate in 213 different settings, covering both the most popular models and distribution shifts.
Our testbed consists of $10^{9}$ model predictions and is 100 times larger than prior work [[47](#bib.bib47), [68](#bib.bib68), [27](#bib.bib27), [33](#bib.bib33)].
This allows us to draw several new conclusions about current robustness interventions:

Robustness measurements should control for accuracy.
Existing work typically argues that an intervention improves robustness by showing that the accuracy on a robustness test set has improved (e.g., see [[115](#bib.bib115), [34](#bib.bib34), [102](#bib.bib102), [63](#bib.bib63), [40](#bib.bib40)]).
We find that in many cases, this improved robustness can be explained by the model performing better on the standard, unperturbed test set.
For instance, using different model architectures does not substantially improve the robustness of a model beyond what would be expected from having a higher standard accuracy.
While training more accurate models is clearly useful, it is important to separate accuracy improvements from robustness improvements when interpreting the results.

Current synthetic robustness measures do not imply natural robustness.
Prior work often evaluates on synthetic distribution shifts to measure robustness [[38](#bib.bib38), [9](#bib.bib9), [32](#bib.bib32)].
We find that current robustness measures for synthetic distribution shift are at most weakly predictive for robustness on the natural distribution shifts presently available. While there are good reasons to study synthetic forms of robustness – for instance, adversarial examples are interesting from a security perspective – synthetic distribution shifts alone do not provide a comprehensive measure of robustness at this time.
Moreover, as the right plot in Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") exemplifies, current robustness interventions are often (but not always) ineffective on the natural distribution shifts in our testbed.

Training on more diverse data improves robustness.
Across all of our experiments, the only intervention that improves robustness to multiple natural distribution shifts is training with a more diverse dataset.
This overarching trend has not previously been identified and stands out only through our large testbed.
Quantifying when and why training with more data helps is an interesting open question: while more data is generally helpful, we find some models that are trained on 100 times more data than the standard ImageNet training set but do not provide any robustness.

The goal of our paper is specifically *not* to introduce a new classification method or image dataset.
Instead, our paper is a meta-study of current robustness research to identify overarching trends that span multiple evaluation settings.
This is particularly important if the ultimate goal of a research direction is to produce models that function reliably in a wide variety of contexts.
Our findings highlight robustness on real data as a clear challenge for future work.
Due to the diminishing returns of larger training datasets, addressing this robustness challenge will likely require new algorithmic ideas and more evaluations on natural distribution shifts.

Figure 1: 
(Left)
We plot 78 standard models trained on ImageNet without any robustness interventions, showing both their accuracy on the standard test set (ImageNet, x-axis) and on a test set with distribution shift (ImageNetV2, y-axis).
All models lie below the $y=x$ line: their accuracy under this distribution shift is lower than on the standard test set.
Nevertheless, improvements in accuracy on the standard test set almost perfectly predict a consistent improvement under distribution shift, as shown by the linear fit (red line).
A hypothetical robustness intervention, shown in green, should provide *effective robustness*, i.e., the intervention should improve the accuracy under distribution shift beyond what is predicted by the linear fit.
  
                                       
(Right)
We plot most of the 204 models in our testbed, highlighting those with the highest effective robustness using square markers.
These models are still far from closing the accuracy gap induced by the distribution shift (ideally a robust model would fall on the $y=x$ line).
Figure [2](#S4.F2 "Figure 2 ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") shows a more detailed version of this plot with error bars for all points.

## 2 Measuring robustness

We first discuss how to measure robustness as a quantity distinct from accuracy.
In our experiments, we always have two evaluation settings: the “standard” test set, and the test set with distribution shift.
For a model $f$, we denote the two accuracies with $\text{acc}\_{1}(f)$ and $\text{acc}\_{2}(f)$, respectively.

When comparing the robustness of two models $f\_{a}$ and $f\_{b}$, one approach would be to rank the models by their accuracy under distribution shift.
However, this approach does not disentangle the robustness of a model from its accuracy on the standard test set.
As an example, consider a pair of models with accuracy $\text{acc}\_{1}(f\_{a})=0.8$, $\text{acc}\_{2}(f\_{a})=0.75$ (i.e., a 5% drop in accuracy from the distribution shift), and $\text{acc}\_{1}(f\_{b})=0.9$, $\text{acc}\_{2}(f\_{b})=0.76$ (a 14% drop).
Model $f\_{b}$ has higher accuracy on the second test set, but overall sees a drop of 14% from the standard to the shifted test set.
In contrast, the first model sees only a 5% drop.
Hence we would like to refer to the first model as more robust, even though it achieves lower accuracy on the shifted test set.

Effective robustness. The core issue in the preceding example is that standard accuracy ($\text{acc}\_{1}$) acts as a confounder.
Instead of directly comparing accuracies under distribution shift, we would like to understand if a model $f\_{b}$ offers higher accuracy on the shifted test set *beyond what is expected from having higher accuracy on the original test set*.
We call this notion of robustness beyond a baseline *effective robustness*.
Graphically, effective robustness corresponds to a model being above the linear trend (red line) given by our testbed of standard models in Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") (left).

To precisely define effective robustness, we introduce $\beta(x)$, the baseline accuracy on the shifted test set for a given accuracy $x$ on the standard test set.
On the distribution shifts in our testbed, we instantiate $\beta$ by computing the parameters of a log-linear fit for the models without a robustness intervention (the red line in Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification")).
Empirically, this approach yields a good fit to the data.
For other distribution shifts, the baseline accuracy may follow different trends and may also depend on properties beyond the standard accuracy, e.g., model architecture.
 contains detailed information on how to compute $\beta$.

Given the accuracy baseline $\beta$, we define the effective robustness of a model as

|  |  |  |
| --- | --- | --- |
|  | $\rho(f)=\text{acc}\_{2}(f)-\beta(\text{acc}\_{1}(f))\;.$ |  |

A model without special robustness properties falls on the linear fit and hence has $\rho(f)$ = 0.
The main goal of a robustness intervention is to increase $\rho$.
Models with large $\rho$ offer robustness beyond what we can currently achieve with standard models.

Relative robustness.
Effective robustness alone does not imply that a robustness intervention is useful.
In particular, a robustness intervention could increase $\rho$ for a model it is applied to, but at the same time *decrease* both $\text{acc}\_{1}$ and $\text{acc}\_{2}$.
Such a robustness intervention would offer no benefits.
So to complement effective robustness, we also introduce *relative robustness* to directly quantify the effect of an intervention on the accuracy under distribution shift.
For a model $f^{\prime}$ with robustness intervention, derived from a model $f$ without the intervention, the relative robustness is $\tau(f^{\prime})=\text{acc}\_{2}(f^{\prime})-\text{acc}\_{2}(f)$.
We graphically illustrate this notion of robustness in Appendix [B.1](#A2.SS1 "B.1 Relative and effective robustness graphical sketch ‣ Appendix B Relative and effective robustness ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification").

Overall, a useful robustness intervention should obtain *both* positive effective and relative robustness.
As we will see, only few classification models currently achieve this goal, and no models achieve both large effective and relative robustness.

## 3 Experimental setup

We now describe our experimental setup.
A model $f$ is first trained on a fixed training set.
We then evaluate this model on two test sets: the “standard” test set (denoted $S\_{1}$) and the test set with a distribution shift (denoted $S\_{2}$).

A crucial question in this setup is what accuracy the model $f$ can possibly achieve on the test set with distribution shift.
In order to ensure that the accuracy on the two test sets are comparable, we focus on natural distribution shifts where humans have thoroughly reviewed the test sets to include only correctly labeled images [[76](#bib.bib76), [68](#bib.bib68), [39](#bib.bib39), [2](#bib.bib2), [18](#bib.bib18)].11
1
For ObjectNet [[2](#bib.bib2)], [Borji 2020](#bib.bib7) has pointed out potential label quality issues, but also found that a substantial accuracy drop remains when taking these issues into account.
This implies that an ideal robust classifier does not have a substantial accuracy gap between the two test sets.
Indeed, recent work experimentally confirms that humans achieve similar classification accuracy on the original ImageNet test set and the ImageNetV2 replication study (one of the distribution shifts in our testbed) [[77](#bib.bib77)].

### 3.1 Types of distribution shifts

At a high level, we distinguish between two main types of distribution shift.
We use the term *natural* distribution shift for datasets that rely only on unmodified images.
In contrast, we refer to distribution shifts as *synthetic* if they involve modifications of existing images specifically to test robustness.
To be concrete, we next provide an overview of the distribution shifts in our robustness evaluation, with further details in Appendix [E](#A5 "Appendix E Evaluation settings in the testbed ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") and visual overviews in Appendices [A](#A1 "Appendix A Testbed overview ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") and .

#### 3.1.1 Natural distribution shifts

We evaluate on seven natural distribution shifts that we classify into three categories.

Consistency shifts.
To evaluate a notion of robustness similar to $\ell\_{p}$-adversarial examples but without synthetic perturbations, we measure robustness to small changes across video frames as introduced by [Gu et al. 2019](#bib.bib35) and [Shankar et al. 2019](#bib.bib76).
The authors assembled sets of contiguous video frames that appear perceptually similar to humans,
but produce inconsistent predictions for classifiers.
We define $S\_{1}$ to be the set of “anchor” frames in each video, and evaluate the accuracy under distribution shift by choosing the worst frame from each frame set for a classifier.
This is the “pm-k” metric introduced by [Shankar et al. 2019](#bib.bib76).

Dataset shifts.
Next, we consider datasets $S\_{2}$ that are collected in a different manner
from $S\_{1}$ but still evaluate a classification task with a compatible set of classes.
These distribution shifts test to what extent current robustness interventions help with natural variations between datasets that are hard to model explicitly.
We consider four datasets of this variety:
(i) ImageNetV2, a reproduction of the ImageNet test set collected by [Recht et al. 2019](#bib.bib68);
(ii) ObjectNet, a test set of objects in a variety of scenes with 113 classes that overlap with ImageNet [[2](#bib.bib2)];
and, (iii) ImageNetVid-Robust-anchor and YTBB-Robust-anchor [[76](#bib.bib76)], which are the datasets constructed from only the anchor frames in the consistency datasets described above.
These two datasets contain 30 and 24 super-classes of the ImageNet class hierarchy, respectively.
For each of these distribution shifts, we define $S\_{1}$ to be a subset of the ImageNet test set with the same label set as $S\_{2}$ so that the accuracies are comparable.

Adversarially filtered shifts.
Finally, we consider an adversarially collected dataset, ImageNet-A [[39](#bib.bib39)].
[Hendrycks et al. 2019](#bib.bib39) assembled the dataset by downloading a large number of labeled images from Flickr, DuckDuckGo, iNaturalist, and other sites,
and then selected the subset that was misclassified by a ResNet-50 model.
We include ImageNet-A in our testbed to investigate whether the adversarial filtering process leads to qualitatively different results.
Since ImageNet-A contains only 200 classes, the standard test set $S\_{1}$ here is again a subset of the ImageNet test set that has the same 200 classes as ImageNet-A.

#### 3.1.2 Synthetic distribution shifts

The research community has developed a wide range of synthetic robustness notions for image classification over the past five years.
In our study, we consider the following classes of synthetic distribution shifts, which cover the most common types of image perturbations.

Image corruptions.
We include all corruptions from [[38](#bib.bib38)], as well as some corruptions from [[33](#bib.bib33)].
These include common examples of image noise (Gaussian, shot noise), various blurs (Gaussian, motion), simulated weather conditions (fog, snow), and “digital” corruptions such as various JPEG compression levels.
We refer the reader to Appendix [E.2](#A5.SS2 "E.2 Corruptions ‣ Appendix E Evaluation settings in the testbed ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") for a full list of the 38 corruptions.

Style transfer. We use a stylized version of the ImageNet test set [[44](#bib.bib44), [34](#bib.bib34)].

Adversarial examples.
We include untargeted adversarial perturbations bounded in $\ell\_{\infty}$- or $\ell\_{2}$-norm by running projected gradient descent as described in [[55](#bib.bib55)].
We use $\varepsilon=\{\frac{0.5}{255},\frac{2}{255}\}$ for $\ell\_{\infty}$ and $\varepsilon=\{0.1,0.5\}$ for $\ell\_{2}$ (further details in Appendix [E.3](#A5.SS3 "E.3 Adversarial attacks ‣ Appendix E Evaluation settings in the testbed ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification")).

### 3.2 Classification models

Our model testbed includes 204 ImageNet models covering a variety of different architectures and training methods.
The models can be divided into the following three categories (see Appendix [F](#A6 "Appendix F Models in the testbed ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") for a full list of all models and their categories).

Standard models. We refer to models trained on the ILSVRC 2012 training set without a specific robustness focus as *standard* models.
This category includes 78 models with architectures ranging from AlexNet to EfficietNet, e.g., [[50](#bib.bib50), [78](#bib.bib78), [37](#bib.bib37), [85](#bib.bib85), [88](#bib.bib88)].

Robust models. This category includes 86 models with an explicit robustness intervention such as adversarially robust models [[101](#bib.bib101), [74](#bib.bib74), [13](#bib.bib13), [72](#bib.bib72), [27](#bib.bib27)], models with special data augmentation [[34](#bib.bib34), [108](#bib.bib108), [100](#bib.bib100), [41](#bib.bib41), [28](#bib.bib28), [20](#bib.bib20), [113](#bib.bib113)], and models with architecture modifications [[115](#bib.bib115)].

Models trained on more data. Finally, our testbed contains 30 models that utilize substantially more training data than the standard ImageNet training set.
This subset includes models trained on (i) Facebook’s collection of 1 billion Instagram images [[56](#bib.bib56), [104](#bib.bib104)], (ii) the YFCC 100 million dataset [[104](#bib.bib104)], (iii) Google’s JFT 300 million dataset [[82](#bib.bib82), [102](#bib.bib102)], (iv) a subset of OpenImages [[98](#bib.bib98)], or (v) a subset of the full ImageNet dataset of 21,841 classes [[99](#bib.bib99), [11](#bib.bib11), [49](#bib.bib49)].

## 4 Main results

Figure 2: 
Model accuracies on the four natural dataset shifts: ImageNetV2 (top left), ObjectNet (top right), ImageNet-Vid-Robust-anchor (bottom left), and YTBB-Robust-anchor (bottom right).
These plots demonstrate that the standard test accuracy (x-axis) is a reliable predictor for the test accuracy under distribution shift (y-axis), especially for models trained without a robustness intervention.
The notable outliers to this trend are some models trained on substantially more data.
For ObjectNet, ImageNet-Vid-Robust-anchor, and YTBB-Robust-anchor, we show the accuracy on a subset of the ImageNet classes on the x-axis to match the label space of the target task (y-axis).
Each data point corresponds to one model in our testbed and is shown with 99.5% Clopper-Pearson confidence intervals.
The axes were adjusted using logit scaling and the linear fit was computed in the scaled space on only the standard models.
The red shaded region is a 95% confidence region for the linear fit from 1,000 bootstrap samples.

Figure 3: 
Model accuracies on the two consistency shifts: ImageNet-Vid-Robust (left), and YTBB-Robust (right).
Both plots are shown with evaluation on pm-0 (anchor frames) on the x-axis and pm-10 (worst case prediction in a 20-frame neighborhood) on the y-axis.
This plot shows that most current robustness interventions do not provide robustness to consistency distribution shifts.
The notable outliers to this trend are $\ell\_{p}$-adversarially robust models and EfficientNet-L2 (NoisyStudent). We color the adversarially robust models separately in this figure to illustrate this phenomenon.
Confidence intervals, axis scaling, and the linear fit are computed similarly to Figure [2](#S4.F2 "Figure 2 ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification").

We now present our main experiments.
First, we measure how much effective and relative robustness models achieve on the natural distribution shifts in our testbed.
Then we investigate to what extent robustness on synthetic distribution shift is predictive of robustness on natural distribution shift.

### 4.1 Results on natural distribution shifts

Following the categorization in Section [3](#S3 "3 Experimental setup ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification"), we measure the robustness of classification models on three types of natural distribution shift.
Appendix  contains variations of the figures referenced in this section.
For further detail, we have made interactive plots available at <http://robustness.imagenetv2.org/>.

Dataset shifts. Figure [2](#S4.F2 "Figure 2 ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") shows the effective robustness of models on the four dataset shifts in our testbed.
In each case, we find that the standard test accuracy (x-axis) is a good predictor for the test accuracy under distribution shift (y-axis).
The linear fit is best for ImageNetV2, ObjectNet, and ImageNet-Vid-Robust with respective $r^{2}$ scores of 1.00, 0.95, and 0.95, but is more noisy for YTBB-Robust ($r^{2}=0.83$).
The noisy fit on YTBB-Robust is likely due to the fact that the categories in YTBB-Robust are not well aligned with those of ImageNet, where the models were trained [[76](#bib.bib76)].
Another potential reason is that the video test sets are significantly smaller (2,530 images in YTBB and 1,109 images in ImageNet-Vid-Robust).

In the high accuracy regime (above the 76% achieved by a ResNet-50), the main outliers in terms of positive effective robustness are models trained on substantially more data than the standard ImageNet training set.
This includes a ResNet152 model trained on 11,000 ImageNet classes ($\rho=2.1$%) [[99](#bib.bib99)], several ResNeXt models trained on 1 billion images from Instagram ($\rho=1.5$%) [[56](#bib.bib56)], and the EfficientNet-L2 (NoisyStudent) model trained on a Google-internal JFT-300M dataset of 300 million images ($\rho=1.1$%) [[102](#bib.bib102)].
However, not all models trained on more data display positive effective robustness.
For instance, a ResNet101 trained on the same JFT-300M dataset has an effective robustness of $\rho=-0.23$% [[82](#bib.bib82)].
We conduct additional experiments to investigate the effect of training data in [Section 5](#S5 "5 How does the amount of training data impact robustness? ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification").
Appendix [G](#A7 "Appendix G Model accuracies ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") contains a full list of models with their effective robustness numbers.
On YTBB-Robust, a few data augmentation strategies and $\ell\_{p}$-robust models display positive effective robustness; we investigate this further in Appendix [B.2](#A2.SS2 "B.2 Relative and effective robustness for ResNet50 models ‣ Appendix B Relative and effective robustness ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification").

Consistency shifts. We plot the effective robustness of models on consistency shifts in  [Figure 3](#S4.F3 "In 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification").
Interestingly, we observe that $\ell\_{p}$-adversarially robust models display substantial effective robustness to ImageNet-Vid-Robust (average $\rho=6.7$%) and YTBB-Robust (average $\rho=4.9$%).
This suggests that these models are not only more robust to synthetic perturbations, but also offer robustness for the perceptually small variations between consecutive video frames.

However, these gains in effective robustness do not necessarily lead to relative robustness.
On average, relative robustness on both datasets is negative (average $\tau=-8.5$% on ImageNet-Vid-Robust and average $\tau=-0.7$% on YTBB-Robust for ResNet50 models).
See Appendix [B.2](#A2.SS2 "B.2 Relative and effective robustness for ResNet50 models ‣ Appendix B Relative and effective robustness ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") ([Figure 10](#A2.F10 "In B.2 Relative and effective robustness for ResNet50 models ‣ Appendix B Relative and effective robustness ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification")) for a visual comparison.
Among the models trained on more data, only one achieves both high accuracy and substantial effective robustness: EfficientNet-L2 (NoisyStudent) [[102](#bib.bib102)] has $\rho=2.4$% and $\rho=7.4$% on ImageNet-Vid-Robust and YTBB-Robust, respectively.

Figure 4: 
Model accuracies on ImageNet-A, a dataset adversarially filtered to contain only images incorrectly classified by a ResNet50 trained on ImageNet.
This filtering results in a ‘knee’ curve: models with lower ImageNet accuracy than ResNet-50 have near-chance performance on ImageNet-A, while models with higher ImageNet accuracy improve drastically on ImageNet-A.
ImageNet classes were subsampled to match the class distribution of ImageNet-A.
Confidence intervals and axis scaling are computed similarly to Figure [2](#S4.F2 "Figure 2 ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification").
The linear fit is computed piecewise around the ResNet50 model accuracy.

Adversarially filtered shifts. ImageNet-A [[39](#bib.bib39)] was created by classifying a set of images with a ResNet50 and only keeping the misclassified images.
Interestingly, this approach creates a “knee” in the resulting scatter plot (see Figure [4](#S4.F4 "Figure 4 ‣ 4.1 Results on natural distribution shifts ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification")): models below a ResNet50’s standard accuracy have close to chance performance on ImageNet-A,22
2
Chance performance is 0.5% as ImageNet-A contains 200 classes. and models above a ResNet50’s standard accuracy quickly close the accuracy gap.
In the high accuracy regime, every percentage point improvement on ImageNet brings at least an 8% improvement on ImageNet-A.
This is in contrast to datasets that are not constructed adversarially, where the initial accuracy drops are smaller, but later models make slow progress on closing the gap.
These results demonstrate that adversarial filtering does not necessarily lead to harder distribution shifts.

### 4.2 Results on synthetic distribution shifts

Given the difficulty of collecting real world data to measure a model’s robustness to natural distribution shifts, an important question is whether there are synthetic proxies.
We now study to what extent robustness to the above synthetic distribution shifts predicts robustness on these natural distribution shifts.

Figure 5: 
Model accuracies under image corruptions (top row) and $\ell\_{p}$-attacks (bottom row).
Similar to Figure [2](#S4.F2 "Figure 2 ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification"), the left plots show the effective robustness for each synthetic distribution shift.
Multiple non-standard models achieve substantial effective robustness, corroborating recent research progress on creating models robust to synthetic shift. The right plots show the correlation between the effective robustness for each synthetic shift and the ImageNetV2 distribution shift (top left in Figure [2](#S4.F2 "Figure 2 ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification")) for the non-standard models.
Both image corruptions and $\ell\_{p}$-attacks are very weakly predictive of effective robustness on ImageNetV2: there are several models that achieve high effective robustness under the synthetic measures but little to no effective
robustness on ImageNetV2.

In Figure [5](#S4.F5 "Figure 5 ‣ 4.2 Results on synthetic distribution shifts ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification"), we analyze the predictiveness of two commonly studied synthetic robustness metrics: average accuracy on image corruptions [[38](#bib.bib38)], and average accuracy drop under a range of PGD adversarial attacks [[55](#bib.bib55)].
We compare these metrics with effective robustness on ImageNetV2.
While effective robustness is only one aspect (c.f. Section [2](#S2 "2 Measuring robustness ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification")), it is a necessary prerequisite for a model to have helpful robustness properties.

The plots show that robustness under either of these synthetic distribution shifts does not imply that the
corresponding model has effective robustness on ImageNetV2 (the Pearson correlation coefficients are $r=0.24$ and $r=-0.05$ for image corruptions and $\ell\_{p}$-adversarial attacks, respectively).
Appendix [C](#A3 "Appendix C Effective robustness scatterplots ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") further extends the experiment by comparing both synthetic distribution shift measures with the remaining natural distribution shifts in our testbed and reaches similiar conclusions.

Our analysis of the aggregate measures proposed in prior work does not preclude that specific synthetic distribution shifts do predict behavior on natural distribution shifts.
Instead, our results show that averaging a large number of synthetic corruptions does not yield a comprehensive robustness measure that also predicts robustness on natural distribution shift.

To extend on this analysis, in Appendix  we find that no individual synthetic measure in our testbed is a consistent predictor of natural distribution shift, but some synthetic shifts are substantially more predictive than others.
For instance, $\ell\_{p}$-robustness has the highest correlation with consistency shifts,
and some image corruptions such as brightness or Gaussian blur have higher correlation with dataset shifts.
However, our testbed indicates that these synthetic measures are not necessarily causal, i.e., models trained with brightness or Gaussian blur do not have substantial effective robustness on dataset shifts.
Further analyzing relationships between individual synthetic and natural distribution shifts is an interesting avenue for future work.

### 4.3 Takeaways and discussion

To recap our results, we now discuss two of the central questions in our paper:
Do current robustness interventions help on real data? And is synthetic robustness correlated with natural robustness?

Across our study, current robustness interventions offer little to no improvement on the natural distribution shifts presently available.

For dataset shifts, we find that models trained with substantially more data yield a small improvement.
However, the amount of extra data needed is orders of magnitude larger than the standard ImageNet training set, and the models show only small gains (in the best case improving the accuracy drop from 8.6% to 7.5% on ImageNetV2 for EfficientNet-L2 NoisyStudent).
These results suggest that current robustness interventions methods do not provide benefits on the dataset shifts in our study.

For consistency shifts, adversarially trained models generally have effective robustness, but usually little or no relative robustness.
On ImageNet-Vid-Robust, the baseline models without adversarial training still achieve higher accuracy under distribution shift.
A notable outlier is EfficietNet-L2 (NoisyStudent) [[102](#bib.bib102)], which utilizes self-training and exhibits high effective robustness in the high accuracy regime.
Self-training has recently been shown to help adversarial robustness as well [[10](#bib.bib10), [94](#bib.bib94), [61](#bib.bib61)].
Investigating the effect of self-training on robustness is an interesting direction for future work.

Moreover, we find that current aggregate metrics for synthetic robustness are at most weakly correlated with natural robustness.
Effective robustness under non-adversarial image corruptions or $\ell\_{p}$-attacks does not imply effective robustness to natural distribution shifts.
While much progress has been made on creating models robust to synthetic distribution shift, new methods may be needed to handle natural shifts.

## 5 How does the amount of training data impact robustness?

As discussed in Section [4.1](#S4.SS1 "4.1 Results on natural distribution shifts ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification"), multiple models trained on more data achieve positive effective robustness on dataset shifts.
However, this effect is not uniform.
Among others, the ResNet101 model trained on JFT-300M has negligible effective robustness ($\rho=-0.23$%) despite being trained on $300\times$ more data than standard ImageNet models.
A possible explanation is that differences in label diversity or quality play a role in promoting robustness.
We investigate the role of data in more detail with two experiments.

Varying the number of images per class.
We start by subsampling the ILSVRC-2012 training set by factors of {2, 4, 8, 16, 32} and show the impact on accuracy and robustness on ImageNetV2 in [Figure 6](#S5.F6 "In 5 How does the amount of training data impact robustness? ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification").
While larger training subsets yield higher accuracies, they do not improve effective robustness, at least for ImageNetV2.

Varying the number of classes.
Next, we subsample ImageNet in a more biased way by varying the set of classes.
First, we create three subsets of the ILSVRC training set with 500, 250, and 125 classes and train models on these subsets.
We then evaluate all models on the 125 class subset and show the results in [Figure 6](#S5.F6 "In 5 How does the amount of training data impact robustness? ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification").
Varying the number of classes again affects accuracies, but does not impact effective robustness.

Figure 6: To investigate the impact of training data on robustness, we vary the training data along two axes: the number of images per class (left), and the number of classes (right).
Although models trained on more data provide improvements in effective robustness, we find that subsampling the training set has no impact on effective robustness.
Confidence intervals, axis scaling, and the linear fit are computed similarly to Figure [2](#S4.F2 "Figure 2 ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification").

Our experiments suggest that neither growing the number of images nor classes in an i.i.d. fashion are effective robustness interventions.
Nevertheless, [Figure 2](#S4.F2 "In 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") shows that larger datasets can provide meaningful robustness improvements.
This disparity may be due to limitations of emulating dataset growth by subsampling ILSVRC.
For one, our experiments consider only i.i.d. subsets of the training images or classes.
Another possibility is that increases in dataset size may only improve robustness after the dataset is large enough so that the accuracy on the original distribution is nearly saturated.
Our experiments only observe dataset sizes smaller than ILSVRC, which may fall below this inflection point.
Studying the effect of data on robustness is an important direction for future work.

## 6 Related work

Our work is best seen as a unification of two independent lines of
research—synthetic and natural distribution shift—not
previously studied together.
Synthetic distribution shifts have been studied extensively in the literature
[[33](#bib.bib33), [28](#bib.bib28), [38](#bib.bib38), [48](#bib.bib48), [93](#bib.bib93), [57](#bib.bib57)].
We incorporate as many prior synthetic measures of robustness as possible.
Our dataset largely confirms the high-level results from these papers (see Appendix [D](#A4 "Appendix D Corruption robustness ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") for additional discussion).
For example, [Ford et al. 2019](#bib.bib31) provide evidence for the relationship between adversarial robustness
and robustness to Gaussian noise.
The study of natural distribution shifts has been an equally extensive
research direction [[68](#bib.bib68), [76](#bib.bib76), [91](#bib.bib91), [2](#bib.bib2)].
When examining each natural distribution shift individually, we
confirm the findings of earlier work that there is a consistent
drop with a linear trend going from ImageNet to each of the other test sets [[76](#bib.bib76), [68](#bib.bib68), [2](#bib.bib2)].

We study the relationship between these two previously independent lines of work.
By creating a testbed $100\times$ larger
than prior work [[47](#bib.bib47), [68](#bib.bib68), [27](#bib.bib27), [33](#bib.bib33)], we are able to make several new
observations.
For instance, we show that robustness to synthetic distribution shift often behaves differently from robustness to natural distribution shift.
We argue that it is important to control for accuracy when measuring
the efficacy of a robustness intervention.
Viewed in this light, most interventions do not provide effective robustness.
The main exception is training with
more data, which improves robustness across natural distribution shifts.
In some situations, $\ell\_{p}$-adversarial robustness helps with natural distribution shift that asks for consistency across similar looking images.

contains additional discussion of specific related work in more detail.
For instance,  revisits consistency shifts and explains why, in contrast to previous work [[35](#bib.bib35)], we find consistency robustness is only weakly correlated with color corruption robustness.

##### Concurrent and subsequent work.

An early version of this paper with results on ImageNetV2 and ImageNet-Vid-Robust appeared on OpenReview in late 2019 [[90](#bib.bib90)].
Since then, two closely related papers have been published concurrently with the updated version of this paper.

[Djolonga et al. 2020](#bib.bib21) evaluate 40 models on the same natural distribution shifts as our paper.
Our testbed is larger and contains 200 models with more robustness interventions.
Overall both papers reach similar conclusions.
Their focus is more on the connections to transfer learning while we focus more on comparisons between synthetic and natural distribution shifts.
[Djolonga et al. 2020](#bib.bib21) also explore the performance of various models with a synthetic image dataset.

[Hendrycks et al. 2020a](#bib.bib40) also study the connections between synthetic robustness and robustness to natural distribution shifts.
This paper introduces a new dataset, ImageNet-R, that contains various renditions (sculptures, paintings, etc.) of 200 ImageNet classes as a new example of natural distribution shift.
The paper then introduces DeepAugment, a new data augmentation technique based on synthetic image transformations, and find that this robustness intervention is effective on ImageNet-R.
In , we analyze the ImageNet-R test set and DeepAugment models, as well as the closely related ImageNet-Sketch test set [[95](#bib.bib95)], in more detail.

At a high-level, ImageNet-R and ImageNet-Sketch follow the trends of the other dataset shifts in our testbed, with models trained on extra data providing the most robustness (up to $\rho=29.1$% on ImageNet-R, though the effect is not uniform, similar to the other dataset shifts).
After the models trained on more data, we find that DeepAugment (in combination with AugMix [[41](#bib.bib41)]) achieves substantial effective robustness ($\rho=11.2$%).
Interestingly, adversarial robustness also leads to effective robustness on ImageNet-R.
An AdvProp model [[100](#bib.bib100)] achieves the highest absolute accuracy on ImageNet-R for a model trained without extra data ($57.8$%) and has effective robustness $\rho=7.5$%.
A model with feature denoising and trained with PGD-style robust optimization [[101](#bib.bib101), [55](#bib.bib55)] achieves the highest effective robustness on ImageNet-R ($\rho=22.7$%) and also positive relative robustness ($\tau=5.7$%).

##### Domain adaptation / transfer learning.

Our work is focused on generalizing to out-of-distribution data *without* fine-tuning on the target distribution.
A complementary approach uses data from the target domain in order to improve generalization on that particular domain [[64](#bib.bib64)].
Depending on the scenario, robustness (without fine-tuning) or domain adaptation may be more appropriate.
For instance, it may be challenging to record data from the distribution shift, which would prevent fine-tuning before deployment.
In some scenarios, we also expect our model to generalize without extra data (e.g., because humans can do so [[77](#bib.bib77)]).
Concurrent work by [Djolonga et al. 2020](#bib.bib21) studies connections between robustness to distribution shifts and transfer learning.
Investigating our testbed from the perspective of transfer learning is an interesting direction for future research.

##### Domain generalization.

Out-of-distribution generalization as measured in our robustness testbed is closely related to domain generalization [[6](#bib.bib6), [60](#bib.bib60)].
In domain generalization, the training algorithm has access to samples drawn from multiple different distributions (domains).
At test time, the model is evaluated on samples from a new domain that was not present in training.
The idea is that having explicit knowledge of multiple domains at training time may help generalization to a new domain at test time.

Several papers have proposed algorithms for domain generalization; we refer to [Gulrajani & Lopez-Paz 2020](#bib.bib36) for a comprehensive survey.
Our testbed currently does not contain any algorithms explicitly following the domain generalization paradigm (though pre-training on a different distribution and then fine-tuning on ImageNet has similarities to domain generalization).
A recent meta-study of domain generalization found that standard empirical risk minimization performs as well or better than the eight domain generalization algorithms they compared to [[36](#bib.bib36)].
This result of [Gulrajani & Lopez-Paz 2020](#bib.bib36) has similarities to our finding that robustness interventions currently rarely improve over the trend given by standard (ERM) models trained without a robustness intervention.
Evaluating domain generalization approaches on the distribution shifts in our testbed may yield new insights into the performance characteristics of these algorithms.

##### Distributionally robust optimization.

Distributionally robust optimization (DRO) is another recently proposed technique to increase robustness to distribution shift [[22](#bib.bib22), [23](#bib.bib23)].
The DRO objective minimizes the worst case risk over all distributions close to the data distribution (or in the group DRO setting, the worst case risk over all defined groups).
DRO has been used to train adversarially robust models [[79](#bib.bib79)], vision models with higher worst-group accuracies [[71](#bib.bib71)], models less reliant on spurious correlations [[81](#bib.bib81)], and many others [[62](#bib.bib62), [24](#bib.bib24)].
For a more thorough discussion on DRO and related work, we refer the reader to [[22](#bib.bib22)].
We are currently unable to include DRO models as we are not aware of any pre-trained DRO models for ImageNet.
We will add DRO models to our testbed as they become available.

##### Adversarial filtering.

One of the distribution shifts in our testbed was obtained via adversarial filtering (ImageNet-A, [[39](#bib.bib39)]).
Architectures introduced after the model used to filter ImageNet-A made quick progress in closing the accuracy gap (see Section [4.1](#S4.SS1 "4.1 Results on natural distribution shifts ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification")).
A similar phenomenon occurred in natural language processing.
[Zellers et al. 2018](#bib.bib111) introduced Swag, an adversarially filtered test for grounded commonsense inference, a combination of natural language inference and commonsense reasoning.
At the time of publication, the best model achieved 59% accuracy, while a human expert achieved 85%.
Two months later, [Devlin et al. 2019](#bib.bib19) introduced the BERT model which achieves 86% accuracy on Swag.
This provides further evidence that adversarial filtering can create test sets that are only hard for a specific (existing) class of models.

In the context of training sets, adversarial filtering is similar to hard negative mining, which is often used to generate training data for detection models [[30](#bib.bib30), [17](#bib.bib17), [83](#bib.bib83), [69](#bib.bib69)].
[Bras et al. 2020](#bib.bib8) propose AFLite, an adversarial filtering algorithm for both refining training sets and creating harder test sets.
They evaluate AFLite on natural language inference tasks and ImageNet classification.
An interesting question is whether combining their algorithm with a ResNet-50 and evaluating later models leads to similar phenomena as on ImageNet-A [[39](#bib.bib39)] and Swag [[111](#bib.bib111)].

##### Fairness in machine learning.

[Mitchell et al. 2019](#bib.bib59) proposed model cards to document the performance of machine learning models in a variety of conditions.
Their focus is on human-centered models and distribution shifts arising from demographic groups (race, gender, etc.).
Our focus here is on ImageNet due to the large number of available models and distribution shifts, but the underlying problem is similar: machine learning models are often brittle under distribution shift.
We remark that ImageNet is known to have geo-diversity deficiencies [[75](#bib.bib75)], among other issues [[14](#bib.bib14), [25](#bib.bib25)].
In the context of OpenImages [[51](#bib.bib51)], researchers have proposed the Inclusive Image dataset [[1](#bib.bib1)].
Adding OpenImages and Inclusive Images to our testbed and comparing these distribution shifts to our existing examples is an interesting direction for future work.

##### Further domains.

Our work is focused on the domain of image classification.
There is a long line of work considering robustness (either natural or synthetic) on other domains [[26](#bib.bib26), [80](#bib.bib80), [106](#bib.bib106), [52](#bib.bib52), [58](#bib.bib58)]. In the context of natural language processing, [Belinkov & Bisk 2018](#bib.bib4) explore language model robustness to synthetic versus natural one-word substitutions and reach similar high-level results, finding there is limited robustness transfer between the two distributions.

## 7 Conclusion

The goal of robust machine learning is to develop methods that function reliably in a wide variety of settings.
So far, this research direction has focused mainly on synthetic perturbations of existing test sets, highlighting important failure cases and initiating progress towards more robust models.
Ultimately, the hope is that the resulting techniques also provide benefits on real data.
Our paper takes a step in this direction and complements the current synthetic robustness tests with comprehensive experiments on distribution shifts arising from real data.

We find that current image classification models still suffer from substantial accuracy drops on natural distribution shifts.
Moreover, current robustness interventions – while effective against synthetic perturbations – yield little to no consistent improvements on real data. The only approach providing broad benefits is training on larger datasets, but the gains are small and inconsistent.

Overall, our results show a clear challenge for future research.
Even training on 1,000 times more data is far from closing the accuracy gaps, so robustness on real data will likely require new algorithmic ideas and better understanding of how training data affects robustness.
Our results indicate two immediate steps for work in this area: robustness metrics should control for baseline accuracy, and robust models should additionally be evaluated on natural distribution shifts.
We hope that our comprehensive testbed with nuanced robustness metrics and multiple types of distribution shift will provide a clear indicator of progress on the path towards reliable machine learning on real data.

## Broader Impact

Robustness is one of the key problems that prevents deploying machine learning in the real world and harnessing the associated benefits.
A canonical example is image classification for medical diagnosis. As was found when researchers attempted to deploy a neural network to detect diabetes from retina images, “an accuracy assessment from a lab goes only so far. It says nothing of how the AI will perform in the chaos of a real-world environment” [[3](#bib.bib3)].
Similarly, researcher also found that current methods for chest X-ray classification are brittle even in the absence of recognized confounders [[110](#bib.bib110)].
If models were robust, then this transfer to the real world would be straightforward.
Unfortunately, achieving robustness on real data is still a substantial challenge for machine learning.

Our work studies how robust current image classification methods are to distribution shifts arising in real data.
We hope that our paper will have a positive effect on the study of distribution shifts and allow researchers to more accurately evaluate to what extent a proposed technique increases the robustness to particular forms of distribution shift.
This will allow researchers to better understand how a deployed system will work in practice, without actually having to deploy it first and users potentially suffering negative consequences.

However, there are several potential ways in which our study could cause unintended harm.
It is possible that our paper might be used as an argument to stop performing research on some synthetic forms of robustness, e.g., adversarial examples or common corruptions.
This is not our intention.
These forms of corruption are interesting independent of any correlation to existing natural distribution shift (e.g., adversarial examples are a genuine security problem).

We only capture a small number of natural distribution shifts among all the possible distribution shifts.
We selected these shifts because they have been used extensively in the literature and are concrete examples of the types of distribution shift we would like models to be robust to.
It is likely that there are shifts that we do not capture, and so even if the shifts we define were to be completely solved, other shifts would remain a concern.

One significant form of distribution shift we do not evaluate is dataset bias in representing different demographic groups.
For example, the Inclusive Images dataset [[75](#bib.bib75)] attempts to correct for the geographical bias introduced in the Open Images dataset [[51](#bib.bib51)] by including a more balanced representation of images from Africa, Asia, and South America.
Neglecting such implicit biases in the data distribution can harm underrepresented demographic groups.
Ultimately, evaluating on fixed datasets may not be enough, and validating the fairness and safety of deployable machine learning requires careful analysis in the application domain.

Finally, more reliable machine learning can also enable negative uses cases, e.g., widespread surveillance or autonomous weapon systems.
As with many technologies, these risks require careful regulation and awareness of unintended consequences arising from technological advances.

## Acknowledgements

We would like to thank
Logan Engstrom,
Justin Gilmer,
Moritz Hardt,
Daniel Kang,
Jerry Li,
Percy Liang,
Nelson Liu,
John Miller,
Preetum Nakkiran,
Rebecca Roelofs,
Aman Sinha,
Jacob Steinhardt, and
Dimitris Tsipras
for helpful conversations while working on this paper.

This research was generously supported in part by ONR awards N00014-17-1-2191, N00014-17-1-2401, and N00014-18-1-2833, the DARPA Assured Autonomy (FA8750-18-C-0101) and Lagrange (W911NF-16-1-0552) programs, a Siemens Futuremakers Fellowship, an Amazon AWS AI Research Award.

## Appendix A Testbed overview

Figure 7: 
An overview of our testbed.
Each row is a model, and each column is an evaluation setting.
For the corruptions, we display each of the five severities defined in [[38](#bib.bib38)].
We also plot in-memory and on-disk versions of each corruption as jpeg compression was found to be a confounding factor in [[31](#bib.bib31)].
A few cells are empty due to resource constraints.
Testbed code and data is provided at <https://modestyachts.github.io/imagenet-testbed/>.

## Appendix B Relative and effective robustness

### B.1 Relative and effective robustness graphical sketch

A central question we address in our paper is whether current methodologies provide meaningful robustness to natural distribution shifts. We discuss how both relative robustness and effective robustness are needed to disentangle the confounding effect of original model accuracy. In Figure [8](#A2.F8.fig1 "Figure 8 ‣ B.1 Relative and effective robustness graphical sketch ‣ Appendix B Relative and effective robustness ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification"), we graphically illustrate this notion of relative robustness.

Figure 8: 
While a hypothetical intervention (green), applied to a baseline model (blue), leads to effective robustness (it is above the red line), it reduces the model’s accuracy under distribution shift.
Hence it fails to provide relative robustness.
An ideal intervention would place the model in the white quadrant - positive effective and relative robustness.

### B.2 Relative and effective robustness for ResNet50 models

We provide additional plots depicting a subset of the models in our testbed.
In order to make an equal comparison, we only plot ResNeet50 variants, models which slightly modify the training data or architecture of a base ResNet50.
The plots in this section thus describe what the relative and effective robustness properties of various robustness interventions look like on a standard ResNet50.
The models can be directly compared with each other since the base model before intervention is the same.

For natural dataset shifts, the plots in Figure [9](#A2.F9 "Figure 9 ‣ B.2 Relative and effective robustness for ResNet50 models ‣ Appendix B Relative and effective robustness ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") demonstrate that the only models that have consistently positive relative and positive effective robustness are models that are trained on more data.
However, the effect is small, and not all models trained on more data are more robust.
On YTBB-Robust specifically, a few data augmentation strategies from ImageNet-C provide significant both effective and relative robustness:
training on greyscale ($\rho=6.9$%, $\tau=1.8$%);
training on pixelate ($\rho=5.4$%, $\tau=2.0$%);
training on jpeg compression ($\rho=5.4$%, $\tau=6.3$%);
training on gaussian noise, contrast, motion blur, and jpeg compression ($\rho=4.8$%, $\tau=5.0$%);
and training on gaussian noise ($\rho=3.6$%, $\tau=4.0$%).
However, this performance is not consistent across the natural distribution shifts.
Exploring why these data augmentation strategies are helpful on YTBB-Robust is an interesting direction for future work.
Additionally, while some $\ell\_{p}$-adversarially robust models display significant effective robustness on YTBB-Robust -
$\ell\_{2}$ robust ResNet50 ($\rho=6.4$%),
$\ell\_{\inf}$ robust ResNet50 ($\rho=6.4$%),
and ResNet50 smoothed with 0.25 gaussian noise and adversarially 1-step PGD trained ($\rho=5.0$)
- in most cases, they fail to provide positive relative robustness.

For natural consistency shifts, the plots in Figure [10](#A2.F10 "Figure 10 ‣ B.2 Relative and effective robustness for ResNet50 models ‣ Appendix B Relative and effective robustness ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") demonstrate that while adversarially robust models provide effective robustness (average $\rho=4.3$% on ImageNet-Vid-Robust and average $\rho=3.9$% on YTBB-Robust), they only sometimes provide relative robustness on YTBB-Robust.

For the adversarially filtered shift, the plot in Figure [11](#A2.F11 "Figure 11 ‣ B.2 Relative and effective robustness for ResNet50 models ‣ Appendix B Relative and effective robustness ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") demonstrates that robustness interventions have little impact on ImageNet-A accuracy. Most of the "knee"-like response curve can be explained as an artifact of the adversarial filtering, with the knee occuring at the ResNet50 model accuracy.

Figure 9: 
Relative and effective robustness for models that are variants of a ResNet50.
Model accuracies are displayed on the four natural dataset shifts: ImageNetV2 (top left), ObjectNet (top right), ImageNet-Vid-Robust-anchor (bottom left), and YTBB-Robust-anchor (bottom right).
These plots demonstrate that the only models that have consistently positive relative and positive effective robustness are models that are trained on more data.
However, the effect is small, and not all models trained on more data are more robust.
Confidence intervals, axis scaling, and the linear fit are computed similarly to Figure [2](#S4.F2 "Figure 2 ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification").

Figure 10: 
Relative and effective robustness for models that are variants of a ResNet50.
Model accuracies are displayed the two consistency shifts: ImageNet-Vid-Robust (left), and YTBB-Robust (right).
These plots demonstrate that while adversarially robust models provide effective robustness, they do not necessarily provide relative robustness.
Confidence intervals, axis scaling, and the linear fit are computed similarly to Figure [2](#S4.F2 "Figure 2 ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification").

Figure 11: 
Relative and effective robustness for models that are variants of a ResNet50.
Model accuracies are displayed on ImageNet-A, a dataset adversarially filtered to contain only images incorrectly classified by a ResNet50 trained on ImageNet.
Due to the "knee"-like response curve, an artifact of the adversarial filtering, effective robustness is defined piecewise around the ResNet50 model accuracy point.
The plot demonstrates that robustness interventions have little impact on ImageNet-A accuracy.
However, the effect is small, and not all models trained on more data are more robust.
Confidence intervals, axis scaling, and the linear fit are computed similarly to Figure [2](#S4.F2 "Figure 2 ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification").

## Appendix C Effective robustness scatterplots

In this section, we further explore to what extent robustness to synthetic distribution shifts predicts robustness on natural distribution shift.
We extend the analysis in
Figure [5](#S4.F5 "Figure 5 ‣ 4.2 Results on synthetic distribution shifts ‣ 4 Main results ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification")
by computing effective robustness on all natural distribution shifts and comparingn them against effective robustness on synthetic distribution shifts.

For natural dataset shifts, the scatter plots in Figure [12](#A3.F12 "Figure 12 ‣ Appendix C Effective robustness scatterplots ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") are weakly correlated (the Pearson correlation coefficients are $r=0.24,-0.05,-0.01,-0.26,0.61,0.30,0.52,0.36$ in reading order),
indicating that improved robustness to corruptions or adversarial attacks in general does not improve effective robustness under natural dataset shifts.
Of the group, the two strongest correlations are effective robustness between ImageNet-Vid-Robust and image corruptions ($r=0.61$) and between YTBB-Robust and image corruptions ($r=0.52$).
While not very strong, the correlations are significant, and exploring this phenomenon between image corruptions and video anchor frames is an interesting direction for future work.

For natural consistency shifts, the plots in Figure [13](#A3.F13 "Figure 13 ‣ Appendix C Effective robustness scatterplots ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") are largely uncorrelated, with the exception that accuracy on adversarial attacks is correlated with effective robustness on consistency shifts for lp adversarially models. However, as explored in Appendix [B.2](#A2.SS2 "B.2 Relative and effective robustness for ResNet50 models ‣ Appendix B Relative and effective robustness ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification"), effective robustness on these shifts does not always imply relative robustness.

For the adversarially filtered shift, as seen in Figure [14](#A3.F14 "Figure 14 ‣ Appendix C Effective robustness scatterplots ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification"), after computing effective robustness piecewise around the ResNet50 accuracy, there is no observed correlation between the synthetic and natural robustness measures on ImageNet-A.

Figure 12: 
We compare the effective robustness of models with their accuracy drop due to corruptions (left column) and adversarial attacks (right column).
The effective robustness is computed with respect to linear fits on the four natural dataset shifts: ImageNetV2 (first row), ObjectNet (second row), ImageNet-Vid-Robust-anchor (third row), and YTBB-Robust-anchor (fourth row).
The measures are largely uncorrelated, indicating that improved robustness to corruptions or adversarial attacks does not improve effective robustness under natural dataset shifts.

Figure 13: 
We compare the effective robustness of models with their accuracy drop due to corruptions (left column) and adversarial attacks (right column).
The effective robustness is computed with respect to linear fits on the two consistency shifts: ImageNet-Vid-Robust (first row), and YTBB-Robust (second row).
The measures are largely uncorrelated, with the exception that accuracy on adversarial attacks is correlated with effective robustness on consistency shifts for lp adversarially models.

Figure 14: 
We compare the effective robustness of models with their accuracy drop due to corruptions (left column) and adversarial attacks (right column).
The effective robustness is computed with respect to a linear fit on ImageNet-A, the adversarially filtered shift.
After computing effective robustness piecewise around the ResNet50 accuracy, there is no observed correlation between the synthetic and natural robustness measures.

## Appendix D Corruption robustness

Figure 15: 
A detailed view of corruption robustness, with cells sampled from the main grid in Figure [7](#A1.F7 "Figure 7 ‣ Appendix A Testbed overview ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification").
Here we present ResNet50s trained on some of the corruptions from the ImageNet-C benchmark, as well as the best model trained on more data, FixResNeXt101\_32x48d\_v2, and the best model trained on just the standard training set, efficientnet-b8-advprop-autoaug.

We have already seen that corruption robustness does not promote effective robustness, or robustness to real distribution shift. Here, we analyze whether robustness to some corruptions transfers to others, and what may contribute to corruption robustness.
Figure [15](#A4.F15 "Figure 15 ‣ Appendix D Corruption robustness ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") shows the result of training various ResNet50s33
3
Each ResNet50 was trained with a batch size of 256 for 120 epochs, starting with a learning rate of 0.1 and decaying by a factor of 10 every 30 epochs. For the ResNet50s trained on corruptions, we randomly sample a corruption and severity for each image. Refer to [E.2](#A5.SS2 "E.2 Corruptions ‣ Appendix E Evaluation settings in the testbed ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification") for details on corruptions and severities. We use our custom fast gpu implementations of these corruptions for training. on a few corruptions from ImageNet-C.

In line with prior work, this plot here tells us that training against one type of synthetic corruption or one set of synthetic corruption does not transfer well to other corruptions. There are cases where transfer does happen, but overall the models are only robust to the corruption they are trained on.

It is also interesting to note (from [Figure 7](#A1.F7 "In Appendix A Testbed overview ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification")) that PGD models actually see a drop in robustness to low frequency corruptions such as contrast, a phenomenon also observed in [[107](#bib.bib107)].

## Appendix E Evaluation settings in the testbed

### E.1 Natural distribution shifts

For ImageNetV2, we evaluate on the following datasets: imagenetv2-matched-frequency, imagenetv2-matched-frequency-format-val, imagenetv2-threshold-0.7, imagenetv2-threshold-0.7-format-val, imagenetv2-top-images, imagenetv2-top-images-format-val. The format-val versions are variants of the original dataset encoded with jpeg settings similar to the original one. Unless otherwise stated, results in our paper referring to imagenetv2 are for imagenetv2-matched-frequency-format-val.

For ObjectNet, we obtained a beta version of the dataset through personal correspondance. Each image in the dataset was then cropped by 2px on each side following the authors’ instructions. Predictions were taken over only the classes that also appeared in the 1000 classes for the ImageNet validation set.

For ImageNet-Vid-Robust and YTBB-Robust, we look at the anchor frames in the dataset and evaluate the benign accuracy for pm0. For pm10, we look at up to 20 nearest frames marked “similar” to the anchor frame in the dataset and count it as a misclassification if any one of the predictions is wrong.

For ImageNet-A, predictions were taken over only the classes that also appeared in the 1000 classes for the ImageNet validation set.

### E.2 Corruptions

We include 38 different corruption types: greyscale (in memory), gaussian noise (in memory and on disk), shot noise (in memory and on disk), impulse noise (in memory and on disk), speckle noise (in memory and on disk), gaussian blur (in memory and on disk), defocus blur (in memory and on disk), glass blur (on disk), motion blur (in memory and on disk), zoom blur (in memory and on disk), snow (in memory and on disk), frost (in memory and on disk), fog (in memory and on disk), spatter (in memory and on disk), brightness (in memory and on disk), contrast (in memory and on disk), saturate (in memory and on disk), pixelate (in memory and on disk), jpeg compression (in memory and on disk), elastic transform (in memory and on disk).

For each corruption, we average over the five severities.

We make sure to make the distinction between in memory corruptions, for which we provide custom fast gpu implementations, and on disk corruptions, for which we use the publicly available ImageNet-C dataset, since it was reported in [[31](#bib.bib31)] that jpeg compression can have a significant impact on model accuracies (indeed, as evidenced by Figure [15](#A4.F15 "Figure 15 ‣ Appendix D Corruption robustness ‣ Measuring Robustness to Natural Distribution Shiftsin Image Classification")).

### E.3 Adversarial attacks

We run the following 4 pgd attacks one each model with these settings:

pgd.linf.eps0.5 Norm: 0.5/255, Step size: 5.88e-5, Num steps: 100

pgd.linf.eps2 Norm: 2/255, Step size: 2.35e-4, Num steps: 100

pgd.l2.eps0.1 Norm: 0.1, Step size: 0.01, Num steps: 100

pgd.l2.eps0.5 Norm: 0.5, Step size: 0.05, Num steps: 100

Most of the models were attacked with only 10% of the dataset (in a class-balanced manner) due to computational constraints. These models are displayed with larger error bars in the plots.

### E.4 Stylized Imagenet

We use the stylized imagenet dataset used by [[34](#bib.bib34)] as another evaluation dataset.

### E.5 125 class evaluation

For the 125 subsampled class evaluation, we evaluate on the following classes from ILSVRC:

n01494475 n01630670 n01644373 n01644900 n01669191 n01677366 n01697457 n01742172 n01796340 n01829413 n01871265 n01924916 n01944390 n01978287 n01980166 n02007558 n02009229 n02017213 n02033041 n02037110 n02056570 n02071294 n02085936 n02086079 n02093428 n02093991 n02095314 n02095570 n02096294 n02096437 n02097474 n02100236 n02100583 n02102318 n02105056 n02107574 n02112706 n02113023 n02114855 n02128925 n02134418 n02138441 n02165105 n02219486 n02226429 n02264363 n02280649 n02441942 n02483708 n02486261 n02488291 n02492035 n02641379 n02730930 n02777292 n02790996 n02795169 n02808440 n02814533 n02814860 n02837789 n02859443 n02892201 n02895154 n02948072 n02951585 n02977058 n03000247 n03110669 n03201208 n03208938 n03216828 n03240683 n03250847 n03272562 n03297495 n03337140 n03376595 n03379051 n03447721 n03492542 n03527444 n03535780 n03642806 n03670208 n03673027 n03692522 n03710193 n03775071 n03832673 n03838899 n03840681 n03868242 n03873416 n03877845 n03884397 n03908714 n03920288 n03933933 n04004767 n04009552 n04037443 n04041544 n04067472 n04074963 n04099969 n04125021 n04141975 n04149813 n04204238 n04208210 n04229816 n04266014 n04310018 n04330267 n04335435 n04336792 n04355338 n04417672 n04479046 n04505470 n07715103 n07875152 n09256479 n12620546

## Appendix F Models in the testbed

The following list contains all models we evaluated on ImageNet with references and links to the corresponding source code.
Also noted is the model type used to color the plots in the paper.

1. 1.

   BiT-M-R50x1-ILSVRC2012 [[49](#bib.bib49)]. Trained with more data model. <https://github.com/google-research/big_transfer>
2. 2.

   BiT-M-R50x3-ILSVRC2012 [[49](#bib.bib49)]. Trained with more data model. <https://github.com/google-research/big_transfer>
3. 3.

   BiT-M-R101x1-ILSVRC2012 [[49](#bib.bib49)]. Trained with more data model. <https://github.com/google-research/big_transfer>
4. 4.

   BiT-M-R101x3-ILSVRC2012 [[49](#bib.bib49)]. Trained with more data model. <https://github.com/google-research/big_transfer>
5. 5.

   BiT-M-R152x4-ILSVRC2012 [[49](#bib.bib49)]. Trained with more data model. <https://github.com/google-research/big_transfer>
6. 6.

   FixPNASNet [[92](#bib.bib92)]. Standard training model. <https://github.com/facebookresearch/FixRes>
7. 7.

   FixResNeXt101\_32x48d [[92](#bib.bib92)]. Trained with more data model. <https://github.com/facebookresearch/FixRes>
8. 8.

   FixResNeXt101\_32x48d\_v2 [[92](#bib.bib92)]. Trained with more data model. <https://github.com/facebookresearch/FixRes>
9. 9.

   FixResNet50 [[92](#bib.bib92)]. Standard training model. <https://github.com/facebookresearch/FixRes>
10. 10.

    FixResNet50CutMix [[92](#bib.bib92)]. Robustness intervention model. <https://github.com/facebookresearch/FixRes>
11. 11.

    FixResNet50CutMix\_v2 [[92](#bib.bib92)]. Robustness intervention model. <https://github.com/facebookresearch/FixRes>
12. 12.

    FixResNet50\_no\_adaptation [[92](#bib.bib92)]. Standard training model. <https://github.com/facebookresearch/FixRes>
13. 13.

    FixResNet50\_v2 [[92](#bib.bib92)]. Standard training model. <https://github.com/facebookresearch/FixRes>
14. 14.

    alexnet [[50](#bib.bib50)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
15. 15.

    alexnet\_lpf2 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
16. 16.

    alexnet\_lpf3 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
17. 17.

    alexnet\_lpf5 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
18. 18.

    bninception [[46](#bib.bib46)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
19. 19.

    bninception-imagenet21k [[46](#bib.bib46)]. Trained with more data model. <https://github.com/dmlc/mxnet-model-gallery/blob/master/imagenet-21k-inception.md>
20. 20.

    cafferesnet101 [[37](#bib.bib37)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
21. 21.

    densenet121 [[43](#bib.bib43)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
22. 22.

    densenet121\_lpf2 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
23. 23.

    densenet121\_lpf3 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
24. 24.

    densenet121\_lpf5 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
25. 25.

    densenet161 [[43](#bib.bib43)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
26. 26.

    densenet169 [[43](#bib.bib43)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
27. 27.

    densenet201 [[43](#bib.bib43)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
28. 28.

    dpn107 [[11](#bib.bib11)]. Trained with more data model. <https://github.com/Cadene/pretrained-models.pytorch>
29. 29.

    dpn131 [[11](#bib.bib11)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
30. 30.

    dpn68 [[11](#bib.bib11)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
31. 31.

    dpn68b [[11](#bib.bib11)]. Trained with more data model. <https://github.com/Cadene/pretrained-models.pytorch>
32. 32.

    dpn92 [[11](#bib.bib11)]. Trained with more data model. <https://github.com/Cadene/pretrained-models.pytorch>
33. 33.

    dpn98 [[11](#bib.bib11)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
34. 34.

    efficientnet-b0 [[88](#bib.bib88)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
35. 35.

    efficientnet-b0-advprop-autoaug [[100](#bib.bib100)]. Robustness intervention model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
36. 36.

    efficientnet-b0-autoaug [[15](#bib.bib15)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
37. 37.

    efficientnet-b1 [[88](#bib.bib88)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
38. 38.

    efficientnet-b1-advprop-autoaug [[100](#bib.bib100)]. Robustness intervention model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
39. 39.

    efficientnet-b1-autoaug [[15](#bib.bib15)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
40. 40.

    efficientnet-b2 [[88](#bib.bib88)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
41. 41.

    efficientnet-b2-advprop-autoaug [[100](#bib.bib100)]. Robustness intervention model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
42. 42.

    efficientnet-b2-autoaug [[15](#bib.bib15)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
43. 43.

    efficientnet-b3 [[88](#bib.bib88)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
44. 44.

    efficientnet-b3-advprop-autoaug [[100](#bib.bib100)]. Robustness intervention model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
45. 45.

    efficientnet-b3-autoaug [[15](#bib.bib15)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
46. 46.

    efficientnet-b4 [[88](#bib.bib88)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
47. 47.

    efficientnet-b4-advprop-autoaug [[100](#bib.bib100)]. Robustness intervention model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
48. 48.

    efficientnet-b4-autoaug [[15](#bib.bib15)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
49. 49.

    efficientnet-b5 [[88](#bib.bib88)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
50. 50.

    efficientnet-b5-advprop-autoaug [[100](#bib.bib100)]. Robustness intervention model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
51. 51.

    efficientnet-b5-autoaug [[15](#bib.bib15)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
52. 52.

    efficientnet-b5-randaug [[16](#bib.bib16)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
53. 53.

    efficientnet-b6-advprop-autoaug [[100](#bib.bib100)]. Robustness intervention model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
54. 54.

    efficientnet-b6-autoaug [[15](#bib.bib15)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
55. 55.

    efficientnet-b7-advprop-autoaug [[100](#bib.bib100)]. Robustness intervention model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
56. 56.

    efficientnet-b7-autoaug [[15](#bib.bib15)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
57. 57.

    efficientnet-b7-randaug [[16](#bib.bib16)]. Standard training model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
58. 58.

    efficientnet-b8-advprop-autoaug [[100](#bib.bib100)]. Robustness intervention model. <https://github.com/tensorflow/tpu/tree/master/models/official/efficientnet>
59. 59.

    efficientnet-l2-noisystudent [[102](#bib.bib102)]. Trained with more data model. <https://github.com/rwightman/pytorch-image-models>
60. 60.

    facebook\_adv\_trained\_resnet152\_baseline [[101](#bib.bib101)]. Robustness intervention model. <https://github.com/facebookresearch/ImageNet-Adversarial-Training>
61. 61.

    facebook\_adv\_trained\_resnet152\_denoise [[101](#bib.bib101)]. Robustness intervention model. <https://github.com/facebookresearch/ImageNet-Adversarial-Training>
62. 62.

    facebook\_adv\_trained\_resnext101\_denoiseAll [[101](#bib.bib101)]. Robustness intervention model. <https://github.com/facebookresearch/ImageNet-Adversarial-Training>
63. 63.

    fbresnet152 [[37](#bib.bib37)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
64. 64.

    google\_resnet101\_jft-300M [[82](#bib.bib82)]. Trained with more data model.
65. 65.

    googlenet/inceptionv1 [[85](#bib.bib85)]. Standard training model. <https://github.com/pytorch/vision/tree/master/torchvision/models>
66. 66.

    inceptionresnetv2 [[37](#bib.bib37)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
67. 67.

    inceptionv3 [[86](#bib.bib86)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
68. 68.

    inceptionv4 [[87](#bib.bib87)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
69. 69.

    instagram-resnext101\_32x16d [[56](#bib.bib56)]. Trained with more data model. <https://github.com/facebookresearch/WSL-Images>
70. 70.

    instagram-resnext101\_32x32d [[56](#bib.bib56)]. Trained with more data model. <https://github.com/facebookresearch/WSL-Images>
71. 71.

    instagram-resnext101\_32x48d [[56](#bib.bib56)]. Trained with more data model. <https://github.com/facebookresearch/WSL-Images>
72. 72.

    instagram-resnext101\_32x8d [[56](#bib.bib56)]. Trained with more data model. <https://github.com/facebookresearch/WSL-Images>
73. 73.

    mnasnet0\_5 [[89](#bib.bib89)]. Standard training model. <https://github.com/pytorch/vision/tree/master/torchvision/models>
74. 74.

    mnasnet1\_0 [[89](#bib.bib89)]. Standard training model. <https://github.com/pytorch/vision/tree/master/torchvision/models>
75. 75.

    mobilenet\_v2 [[73](#bib.bib73)]. Standard training model. <https://github.com/pytorch/vision/tree/master/torchvision/models>
76. 76.

    mobilenet\_v2\_lpf2 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
77. 77.

    mobilenet\_v2\_lpf3 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
78. 78.

    mobilenet\_v2\_lpf5 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
79. 79.

    nasnetalarge [[117](#bib.bib117)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
80. 80.

    nasnetamobile [[117](#bib.bib117)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
81. 81.

    pnasnet5large [[53](#bib.bib53)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
82. 82.

    polynet [[116](#bib.bib116)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
83. 83.

    resnet101 [[37](#bib.bib37)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
84. 84.

    resnet101-tencent-ml-images [[97](#bib.bib97)]. Trained with more data model. <https://github.com/Tencent/tencent-ml-images>
85. 85.

    resnet101\_cutmix [[108](#bib.bib108)]. Robustness intervention model. <https://github.com/clovaai/CutMix-PyTorch>
86. 86.

    resnet101\_lpf2 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
87. 87.

    resnet101\_lpf3 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
88. 88.

    resnet101\_lpf5 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
89. 89.

    resnet152 [[37](#bib.bib37)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
90. 90.

    resnet152-imagenet11k [[99](#bib.bib99)]. Trained with more data model. <https://github.com/tornadomeet/ResNet>
91. 91.

    resnet18 [[37](#bib.bib37)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
92. 92.

    resnet18-rotation-nocrop\_40 [[28](#bib.bib28)]. Robustness intervention model. <https://github.com/MadryLab/spatial-pytorch>
93. 93.

    resnet18-rotation-random\_30 [[28](#bib.bib28)]. Robustness intervention model. <https://github.com/MadryLab/spatial-pytorch>
94. 94.

    resnet18-rotation-random\_40 [[28](#bib.bib28)]. Robustness intervention model. <https://github.com/MadryLab/spatial-pytorch>
95. 95.

    resnet18-rotation-standard\_40 [[28](#bib.bib28)]. Robustness intervention model. <https://github.com/MadryLab/spatial-pytorch>
96. 96.

    resnet18-rotation-worst10\_30 [[28](#bib.bib28)]. Robustness intervention model. <https://github.com/MadryLab/spatial-pytorch>
97. 97.

    resnet18-rotation-worst10\_40 [[28](#bib.bib28)]. Robustness intervention model. <https://github.com/MadryLab/spatial-pytorch>
98. 98.

    resnet18\_lpf2 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
99. 99.

    resnet18\_lpf3 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
100. 100.

     resnet18\_lpf5 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
101. 101.

     resnet18\_ssl [[104](#bib.bib104)]. Trained with more data model. <https://github.com/facebookresearch/semi-supervised-ImageNet1K-models>
102. 102.

     resnet18\_swsl [[104](#bib.bib104)]. Trained with more data model. <https://github.com/facebookresearch/semi-supervised-ImageNet1K-models>
103. 103.

     resnet34 [[37](#bib.bib37)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
104. 104.

     resnet34\_lpf2 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
105. 105.

     resnet34\_lpf3 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
106. 106.

     resnet34\_lpf5 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
107. 107.

     resnet50 [[37](#bib.bib37)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
108. 108.

     resnet50-randomized\_smoothing\_noise\_0.00 [[13](#bib.bib13)]. Standard training model. <https://github.com/locuslab/smoothing>
109. 109.

     resnet50-randomized\_smoothing\_noise\_0.25 [[13](#bib.bib13)]. Robustness intervention model. <https://github.com/locuslab/smoothing>
110. 110.

     resnet50-randomized\_smoothing\_noise\_0.50 [[13](#bib.bib13)]. Robustness intervention model. <https://github.com/locuslab/smoothing>
111. 111.

     resnet50-randomized\_smoothing\_noise\_1.00 [[13](#bib.bib13)]. Robustness intervention model. <https://github.com/locuslab/smoothing>
112. 112.

     resnet50-smoothing\_adversarial\_DNN\_2steps\_eps\_512\_noise\_0.25 [[72](#bib.bib72)]. Robustness intervention model. <https://github.com/Hadisalman/smoothing-adversarial>
113. 113.

     resnet50-smoothing\_adversarial\_DNN\_2steps\_eps\_512\_noise\_0.50 [[72](#bib.bib72)]. Robustness intervention model. <https://github.com/Hadisalman/smoothing-adversarial>
114. 114.

     resnet50-smoothing\_adversarial\_DNN\_2steps\_eps\_512\_noise\_1.00 [[72](#bib.bib72)]. Robustness intervention model. <https://github.com/Hadisalman/smoothing-adversarial>
115. 115.

     resnet50-smoothing\_adversarial\_PGD\_1step\_eps\_512\_noise\_0.25 [[72](#bib.bib72)]. Robustness intervention model. <https://github.com/Hadisalman/smoothing-adversarial>
116. 116.

     resnet50-smoothing\_adversarial\_PGD\_1step\_eps\_512\_noise\_0.50 [[72](#bib.bib72)]. Robustness intervention model. <https://github.com/Hadisalman/smoothing-adversarial>
117. 117.

     resnet50-smoothing\_adversarial\_PGD\_1step\_eps\_512\_noise\_1.00 [[72](#bib.bib72)]. Robustness intervention model. <https://github.com/Hadisalman/smoothing-adversarial>
118. 118.

     resnet50-vtab [[112](#bib.bib112)]. Standard training model. <https://tfhub.dev/s?publisher=vtab>
119. 119.

     resnet50-vtab-exemplar [[112](#bib.bib112)]. Standard training model. <https://tfhub.dev/s?publisher=vtab>
120. 120.

     resnet50-vtab-rotation [[112](#bib.bib112)]. Standard training model. <https://tfhub.dev/s?publisher=vtab>
121. 121.

     resnet50-vtab-semi-exemplar [[112](#bib.bib112)]. Standard training model. <https://tfhub.dev/s?publisher=vtab>
122. 122.

     resnet50-vtab-semi-rotation [[112](#bib.bib112)]. Standard training model. <https://tfhub.dev/s?publisher=vtab>
123. 123.

     resnet50\_adv-train-free [[74](#bib.bib74)]. Robustness intervention model. <https://github.com/mahyarnajibi/FreeAdversarialTraining>
124. 124.

     resnet50\_augmix [[41](#bib.bib41)]. Robustness intervention model. <https://github.com/google-research/augmix>
125. 125.

     resnet50\_aws\_baseline. Standard training model.
126. 126.

     resnet50\_cutmix [[108](#bib.bib108)]. Robustness intervention model. <https://github.com/clovaai/CutMix-PyTorch>
127. 127.

     resnet50\_cutout [[20](#bib.bib20)]. Robustness intervention model. <https://github.com/clovaai/CutMix-PyTorch>
128. 128.

     resnet50\_deepaugment [[40](#bib.bib40)]. Robustness intervention model. <https://github.com/hendrycks/imagenet-r>
129. 129.

     resnet50\_deepaugment\_augmix [[40](#bib.bib40)]. Robustness intervention model. <https://github.com/hendrycks/imagenet-r>
130. 130.

     resnet50\_feature\_cutmix [[108](#bib.bib108)]. Robustness intervention model. <https://github.com/clovaai/CutMix-PyTorch>
131. 131.

     resnet50\_imagenet\_100percent\_batch64\_original\_images. Standard training model.
132. 132.

     resnet50\_imagenet\_subsample\_125\_classes\_batch64\_original\_images. Standard training model.
133. 133.

     resnet50\_imagenet\_subsample\_1\_of\_16\_batch64\_original\_images. Standard training model.
134. 134.

     resnet50\_imagenet\_subsample\_1\_of\_2\_batch64\_original\_images. Standard training model.
135. 135.

     resnet50\_imagenet\_subsample\_1\_of\_32\_batch64\_original\_images. Standard training model.
136. 136.

     resnet50\_imagenet\_subsample\_1\_of\_4\_batch64\_original\_images. Standard training model.
137. 137.

     resnet50\_imagenet\_subsample\_1\_of\_8\_batch64\_original\_images. Standard training model.
138. 138.

     resnet50\_imagenet\_subsample\_250\_classes\_batch64\_original\_images. Standard training model.
139. 139.

     resnet50\_imagenet\_subsample\_500\_classes\_batch64\_original\_images. Standard training model.
140. 140.

     resnet50\_l2\_eps3\_robust [[27](#bib.bib27)]. Robustness intervention model. <https://github.com/MadryLab/robustness>
141. 141.

     resnet50\_linf\_eps4\_robust [[27](#bib.bib27)]. Robustness intervention model. <https://github.com/MadryLab/robustness>
142. 142.

     resnet50\_linf\_eps8\_robust [[27](#bib.bib27)]. Robustness intervention model. <https://github.com/MadryLab/robustness>
143. 143.

     resnet50\_lpf2 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
144. 144.

     resnet50\_lpf3 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
145. 145.

     resnet50\_lpf5 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
146. 146.

     resnet50\_mixup [[113](#bib.bib113)]. Robustness intervention model. <https://github.com/clovaai/CutMix-PyTorch>
147. 147.

     resnet50\_ssl [[104](#bib.bib104)]. Trained with more data model. <https://github.com/facebookresearch/semi-supervised-ImageNet1K-models>
148. 148.

     resnet50\_swsl [[104](#bib.bib104)]. Trained with more data model. <https://github.com/facebookresearch/semi-supervised-ImageNet1K-models>
149. 149.

     resnet50\_trained\_on\_SIN [[34](#bib.bib34)]. Robustness intervention model. <https://github.com/rgeirhos/texture-vs-shape>
150. 150.

     resnet50\_trained\_on\_SIN\_and\_IN [[34](#bib.bib34)]. Robustness intervention model. <https://github.com/rgeirhos/texture-vs-shape>
151. 151.

     resnet50\_trained\_on\_SIN\_and\_IN\_then\_finetuned\_on\_IN [[34](#bib.bib34)]. Robustness intervention model. <https://github.com/rgeirhos/texture-vs-shape>
152. 152.

     resnet50\_with\_brightness\_aws. Robustness intervention model.
153. 153.

     resnet50\_with\_contrast\_aws. Robustness intervention model.
154. 154.

     resnet50\_with\_defocus\_blur\_aws. Robustness intervention model.
155. 155.

     resnet50\_with\_fog\_aws. Robustness intervention model.
156. 156.

     resnet50\_with\_frost\_aws. Robustness intervention model.
157. 157.

     resnet50\_with\_gaussian\_noise\_aws. Robustness intervention model.
158. 158.

     resnet50\_with\_gaussian\_noise\_contrast\_motion\_blur\_jpeg\_compression\_aws. Robustness intervention model.
159. 159.

     resnet50\_with\_greyscale\_aws. Robustness intervention model.
160. 160.

     resnet50\_with\_jpeg\_compression\_aws. Robustness intervention model.
161. 161.

     resnet50\_with\_motion\_blur\_aws. Robustness intervention model.
162. 162.

     resnet50\_with\_pixelate\_aws. Robustness intervention model.
163. 163.

     resnet50\_with\_saturate\_aws. Robustness intervention model.
164. 164.

     resnet50\_with\_spatter\_aws. Robustness intervention model.
165. 165.

     resnet50\_with\_zoom\_blur\_aws. Robustness intervention model.
166. 166.

     resnext101\_32x16d\_ssl [[104](#bib.bib104)]. Trained with more data model. <https://github.com/facebookresearch/semi-supervised-ImageNet1K-models>
167. 167.

     resnext101\_32x4d [[103](#bib.bib103)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
168. 168.

     resnext101\_32x4d\_ssl [[104](#bib.bib104)]. Trained with more data model. <https://github.com/facebookresearch/semi-supervised-ImageNet1K-models>
169. 169.

     resnext101\_32x4d\_swsl [[104](#bib.bib104)]. Trained with more data model. <https://github.com/facebookresearch/semi-supervised-ImageNet1K-models>
170. 170.

     resnext101\_32x8d [[103](#bib.bib103)]. Standard training model. <https://github.com/pytorch/vision/tree/master/torchvision/models>
171. 171.

     resnext101\_32x8d\_deepaugment\_augmix [[40](#bib.bib40)]. Robustness intervention model. <https://github.com/hendrycks/imagenet-r>
172. 172.

     resnext101\_32x8d\_ssl [[104](#bib.bib104)]. Trained with more data model. <https://github.com/facebookresearch/semi-supervised-ImageNet1K-models>
173. 173.

     resnext101\_32x8d\_swsl [[104](#bib.bib104)]. Trained with more data model. <https://github.com/facebookresearch/semi-supervised-ImageNet1K-models>
174. 174.

     resnext101\_64x4d [[103](#bib.bib103)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
175. 175.

     resnext50\_32x4d [[103](#bib.bib103)]. Standard training model. <https://github.com/pytorch/vision/tree/master/torchvision/models>
176. 176.

     resnext50\_32x4d\_ssl [[104](#bib.bib104)]. Trained with more data model. <https://github.com/facebookresearch/semi-supervised-ImageNet1K-models>
177. 177.

     resnext50\_32x4d\_swsl [[104](#bib.bib104)]. Trained with more data model. <https://github.com/facebookresearch/semi-supervised-ImageNet1K-models>
178. 178.

     se\_resnet101 [[42](#bib.bib42)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
179. 179.

     se\_resnet152 [[42](#bib.bib42)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
180. 180.

     se\_resnet50 [[42](#bib.bib42)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
181. 181.

     se\_resnext101\_32x4d [[42](#bib.bib42)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
182. 182.

     se\_resnext50\_32x4d [[42](#bib.bib42)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
183. 183.

     senet154 [[42](#bib.bib42)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
184. 184.

     shufflenet\_v2\_x0\_5 [[54](#bib.bib54)]. Standard training model. <https://github.com/pytorch/vision/tree/master/torchvision/models>
185. 185.

     shufflenet\_v2\_x1\_0 [[54](#bib.bib54)]. Standard training model. <https://github.com/pytorch/vision/tree/master/torchvision/models>
186. 186.

     squeezenet1\_0 [[45](#bib.bib45)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
187. 187.

     squeezenet1\_1 [[45](#bib.bib45)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
188. 188.

     vgg11 [[78](#bib.bib78)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
189. 189.

     vgg11\_bn [[78](#bib.bib78)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
190. 190.

     vgg13 [[78](#bib.bib78)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
191. 191.

     vgg13\_bn [[78](#bib.bib78)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
192. 192.

     vgg16 [[78](#bib.bib78)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
193. 193.

     vgg16\_bn [[78](#bib.bib78)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
194. 194.

     vgg16\_bn\_lpf2 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
195. 195.

     vgg16\_bn\_lpf3 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
196. 196.

     vgg16\_bn\_lpf5 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
197. 197.

     vgg16\_lpf2 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
198. 198.

     vgg16\_lpf3 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
199. 199.

     vgg16\_lpf5 [[115](#bib.bib115)]. Robustness intervention model. <https://github.com/adobe/antialiased-cnns>
200. 200.

     vgg19 [[78](#bib.bib78)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
201. 201.

     vgg19\_bn [[78](#bib.bib78)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>
202. 202.

     wide\_resnet101\_2 [[109](#bib.bib109)]. Standard training model. <https://github.com/pytorch/vision/tree/master/torchvision/models>
203. 203.

     wide\_resnet50\_2 [[109](#bib.bib109)]. Standard training model. <https://github.com/pytorch/vision/tree/master/torchvision/models>
204. 204.

     xception [[12](#bib.bib12)]. Standard training model. <https://github.com/Cadene/pretrained-models.pytorch>

## Appendix G Model accuracies
