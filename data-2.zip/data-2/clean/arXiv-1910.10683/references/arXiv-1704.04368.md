<!-- fulltext source=arxiv_html slug=arXiv-1704.04368 fetched=2026-09-22T13:31:22+00:00 -->

# Get To The Point: Summarization with Pointer-Generator Networks

Abigail See
Affiliation: Stanford University
Email: [abisee@stanford.edu](mailto:)
  
Peter J. Liu
Affiliation: Google Brain
Email: [peterjliu@google.com](mailto:)
  
Christopher D. Manning
Affiliation: Stanford University
Email: [manning@stanford.edu](mailto:)

###### Abstract

Neural sequence-to-sequence models have provided a viable new approach
for abstractive text summarization (meaning they are not restricted to simply selecting and rearranging passages from the original text).
However, these models have two shortcomings: they are liable to reproduce factual details inaccurately, and they tend to repeat themselves.
In this work we propose a novel architecture that augments the standard sequence-to-sequence attentional model in two orthogonal ways.
First, we use a hybrid pointer-generator network that can copy words from the source text via pointing, which aids accurate reproduction of information, while retaining the ability to produce novel words through the generator.
Second, we use coverage to keep track of what has been summarized, which discourages repetition.
We apply our model to the CNN / Daily Mail summarization
task, outperforming the current abstractive state-of-the-art
by at least 2 ROUGE points.

Original Text (truncated):
lagos, nigeria (cnn) a day after winning nigeria’s presidency, muhammadu buhari told cnn’s christiane amanpour that he plans to aggressively fight corruption that has long plagued nigeria and go after the root of the nation’s unrest. buhari said he’ll “rapidly give attention” to curbing violence in the northeast part of nigeria, where the terrorist group boko haram operates. by cooperating with neighboring nations chad, cameroon and niger, he said his administration is confident it will be able to thwart criminals and others contributing to nigeria’s instability. for the first time in nigeria’s history, the opposition defeated the ruling party in democratic elections. buhari defeated incumbent goodluck jonathan by about 2 million votes, according to nigeria’s independent national electoral commission. the win comes after a long history of military rule, coups and botched attempts at democracy in africa’s most populous nation.
  
 
Baseline Seq2Seq + Attention:
UNK UNK says his administration is confident it will be able to destabilize nigeria’s economy. UNK says his administration is confident it will be able to thwart criminals and other nigerians. he says the country has long nigeria and nigeria’s economy.
  
 
Pointer-Gen:
muhammadu buhari says he plans to aggressively fight corruption in the northeast part of nigeria. he says he’ll “rapidly give attention” to curbing violence in the northeast part of nigeria.
he says his administration is confident it will be able to thwart criminals.
  
 
Pointer-Gen + Coverage:
muhammadu buhari says he plans to aggressively fight corruption that has long plagued nigeria. he says his administration is confident it will be able to thwart criminals. the win comes after a long history of military rule, coups and botched attempts at democracy in africa’s most populous nation.

Figure 1: 
Comparison of output of 3 abstractive summarization models on a news article.
The baseline model makes factual errors, a nonsensical sentence and struggles with OOV words muhammadu buhari.
The pointer-generator model is accurate but repeats itself.
Coverage eliminates repetition.
The final summary is composed from several fragments.

Figure 2: Baseline sequence-to-sequence model with attention. The model may attend to relevant words in the source text to generate novel words, e.g., to produce the novel word beat in the abstractive summary Germany beat Argentina 2-0 the model may attend to the words victorious and win in the source text.

## 1 Introduction

Summarization is the task of condensing a piece of text to a shorter version that contains the main information from the original.
There are two broad approaches to summarization: *extractive* and *abstractive*.
Extractive methods assemble summaries exclusively from
passages (usually whole sentences) taken directly from the source
text, while abstractive methods may generate novel words and
phrases not featured in the source text – as a human-written
abstract usually does.
The extractive approach is easier, because copying large chunks of text from the source document ensures baseline levels of grammaticality and accuracy.
On the other hand, sophisticated abilities that are crucial to high-quality summarization, such as paraphrasing, generalization, or the incorporation of real-world knowledge, are possible only in an abstractive framework (see Figure [5](#S7.F5 "Figure 5 ‣ 7 Discussion ‣ Get To The Point: Summarization with Pointer-Generator Networks")).

Due to the difficulty of abstractive summarization, the great majority of past work has been extractive [Kupiec et al. (1995)](#bib.bib12); [Paice (1990)](#bib.bib20); [Saggion and Poibeau (2013)](#bib.bib23).
However, the recent success of sequence-to-sequence models [Sutskever et al. (2014)](#bib.bib25), in which recurrent neural networks (RNNs) both read and freely generate text, has made abstractive summarization viable [Chopra et al. (2016)](#bib.bib4); [Nallapati et al. (2016)](#bib.bib19); [Rush et al. (2015)](#bib.bib22); [Zeng et al. (2016)](#bib.bib31).
Though these systems are promising, they exhibit undesirable behavior such as inaccurately reproducing factual details, an inability to deal with out-of-vocabulary (OOV) words, and repeating themselves (see Figure [1](#S0.F1 "Figure 1 ‣ Get To The Point: Summarization with Pointer-Generator Networks")).

In this paper we present an architecture that addresses these three
issues in the context of multi-sentence summaries.
While most recent abstractive work has focused on headline generation
tasks (reducing one or two sentences to a single headline), we believe
that longer-text summarization is both more challenging (requiring
higher levels of abstraction while avoiding repetition) and ultimately more useful.
Therefore we apply our model to the recently-introduced
CNN/Daily Mail dataset [Hermann et al. (2015)](#bib.bib9); [Nallapati et al. (2016)](#bib.bib19), which contains news articles (39 sentences on average) paired with multi-sentence summaries, and show that we outperform the state-of-the-art abstractive system by at least 2 ROUGE points.

Our hybrid pointer-generator network facilitates copying
words from the source text via pointing [Vinyals et al. (2015)](#bib.bib29), which improves accuracy and handling of OOV words, while retaining the ability to generate new words.
The network, which can be viewed as a balance between extractive and abstractive approaches, is similar to [Gu et al.](#bib.bib7)’s [Gu et al. (2016)](#bib.bib7) CopyNet and [Miao and Blunsom](#bib.bib17)’s [Miao and Blunsom (2016)](#bib.bib17) Forced-Attention Sentence Compression, that were applied to short-text summarization.
We propose a novel variant of the coverage vector [Tu et al. (2016)](#bib.bib28) from Neural Machine Translation, which we use to track and control coverage of the source document.
We show that coverage is remarkably effective for eliminating repetition.

## 2 Our Models

In this section we describe (1) our baseline sequence-to-sequence model, (2) our pointer-generator model, and (3) our coverage mechanism that can be added to either of the first two models. The code for our models is available online.11
1
[www.github.com/abisee/pointer-generator](https://www.github.com/abisee/pointer-generator)

Figure 3: Pointer-generator model.
For each decoder timestep a generation probability $p\_{\text{gen}}\in[0,1]$ is calculated, which weights the probability of generating words from the vocabulary, versus copying words from the source text.
The vocabulary distribution and the attention distribution are weighted and summed to obtain the final distribution, from which we make our prediction.
Note that out-of-vocabulary article words such as 2-0 are included in the final distribution.
Best viewed in color.

### 2.1 Sequence-to-sequence attentional model

Our baseline model is similar to that of [Nallapati et al.](#bib.bib19) [Nallapati et al. (2016)](#bib.bib19), and is depicted in Figure [2](#S0.F2 "Figure 2 ‣ Get To The Point: Summarization with Pointer-Generator Networks").
The tokens of the article $w\_{i}$ are fed one-by-one into the encoder (a single-layer bidirectional LSTM),
producing a sequence of encoder hidden states $h\_{i}$.
On each step $t$, the decoder (a single-layer unidirectional LSTM) receives the word embedding of the previous word (while training, this is the previous word of the reference summary; at test time it is the previous word emitted by the decoder), and has decoder state $s\_{t}$.
The attention distribution $a^{t}$ is calculated as in [Bahdanau et al.](#bib.bib1) [Bahdanau et al. (2015)](#bib.bib1):

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle e\_{i}^{t}$ | $\displaystyle=v^{T}\tanh(W\_{h}h\_{i}+W\_{s}s\_{t}+b\_{\text{attn}})$ |  | (1) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle a^{t}$ | $\displaystyle=\text{softmax}(e^{t})$ |  | (2) |

where $v$, $W\_{h}$, $W\_{s}$ and $b\_{\text{attn}}$ are learnable parameters.
The attention distribution can be viewed as a probability distribution over the source words, that tells the decoder where to look to produce the next word.
Next, the attention distribution is used to produce a weighted sum of the encoder hidden states, known as the context vector $h^{\*}\_{t}$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $h^{\*}\_{t}=\sum\nolimits\_{i}a\_{i}^{t}h\_{i}$ |  | (3) |

The context vector, which can be seen as a fixed-size representation of what has been read from the source for this step, is concatenated with the decoder state $s\_{t}$ and fed through two linear layers to produce the vocabulary distribution $P\_{\text{vocab}}$:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle P\_{\text{vocab}}$ | $\displaystyle=\text{softmax}(V^{\prime}(V[s\_{t},h^{\*}\_{t}]+b)+b^{\prime})$ |  | (4) |

where $V$, $V^{\prime}$, $b$ and $b^{\prime}$ are learnable parameters.
$P\_{\text{vocab}}$ is a probability distribution over all words in the vocabulary, and provides us with our final distribution from which to predict words $w$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P(w)=P\_{\text{vocab}}(w)$ |  | (5) |

During training, the loss for timestep $t$ is the negative log likelihood of the target word $w^{\*}\_{t}$ for that timestep:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\text{loss}\_{t}=-\log P(w^{\*}\_{t})$ |  | (6) |

and the overall loss for the whole sequence is:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\text{loss}=\frac{1}{T}\sum\nolimits\_{t=0}^{T}\text{loss}\_{t}$ |  | (7) |

### 2.2 Pointer-generator network

Our pointer-generator network is a hybrid between our baseline and a pointer network [Vinyals et al. (2015)](#bib.bib29), as it allows both copying words via pointing, and generating words from a fixed vocabulary.
In the pointer-generator model (depicted in Figure [3](#S2.F3 "Figure 3 ‣ 2 Our Models ‣ Get To The Point: Summarization with Pointer-Generator Networks")) the attention distribution $a^{t}$ and context vector $h^{\*}\_{t}$ are calculated as in section [2.1](#S2.SS1 "2.1 Sequence-to-sequence attentional model ‣ 2 Our Models ‣ Get To The Point: Summarization with Pointer-Generator Networks").
In addition, the generation probability $p\_{\text{gen}}\in[0,1]$ for timestep $t$ is calculated from the context vector $h^{\*}\_{t}$, the decoder state $s\_{t}$ and the decoder input $x\_{t}$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $p\_{\text{gen}}=\sigma(w\_{h^{\*}}^{T}h^{\*}\_{t}+w\_{s}^{T}s\_{t}+w\_{x}^{T}x\_{t}+b\_{\text{ptr}})$ |  | (8) |

where vectors $w\_{h^{\*}}$, $w\_{s}$, $w\_{x}$ and scalar $b\_{\text{ptr}}$ are learnable parameters and $\sigma$ is the sigmoid function.
Next, $p\_{\text{gen}}$ is used as a soft switch to choose between generating a word from the vocabulary by sampling from $P\_{\text{vocab}}$, or copying a word from the input sequence by sampling from the attention distribution $a^{t}$.
For each document let the extended vocabulary denote the union of the vocabulary, and all words appearing in the source document.
We obtain the following probability distribution over the extended vocabulary:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P(w)=p\_{\text{gen}}P\_{\text{vocab}}(w)+(1-p\_{\text{gen}})\sum\nolimits\_{i:w\_{i}=w}a^{t}\_{i}$ |  | (9) |

Note that if $w$ is an out-of-vocabulary (OOV) word, then $P\_{\text{vocab}}(w)$ is zero;
similarly if $w$ does not appear in the source document, then $\sum\_{i:w\_{i}=w}a^{t}\_{i}$ is zero.
The ability to produce OOV words is one of the primary advantages of pointer-generator models; by contrast models such as our baseline are restricted to their pre-set vocabulary.

The loss function is as described in equations ([6](#S2.E6 "In 2.1 Sequence-to-sequence attentional model ‣ 2 Our Models ‣ Get To The Point: Summarization with Pointer-Generator Networks")) and ([7](#S2.E7 "In 2.1 Sequence-to-sequence attentional model ‣ 2 Our Models ‣ Get To The Point: Summarization with Pointer-Generator Networks")), but with respect to our modified probability distribution $P(w)$ given in equation ([9](#S2.E9 "In 2.2 Pointer-generator network ‣ 2 Our Models ‣ Get To The Point: Summarization with Pointer-Generator Networks")).

### 2.3 Coverage mechanism

Repetition is a common problem for sequence-to-sequence models [Tu et al. (2016)](#bib.bib28); [Mi et al. (2016)](#bib.bib16); [Sankaran et al. (2016)](#bib.bib24); [Suzuki and Nagata (2016)](#bib.bib26), and is especially pronounced when generating multi-sentence text (see Figure [1](#S0.F1 "Figure 1 ‣ Get To The Point: Summarization with Pointer-Generator Networks")).
We adapt the coverage model of [Tu et al.](#bib.bib28) [Tu et al. (2016)](#bib.bib28) to solve the problem.
In our coverage model, we maintain a coverage vector $c^{t}$, which is the sum of attention distributions over all previous decoder timesteps:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $c^{t}=\sum\nolimits\_{t^{\prime}=0}^{t-1}a^{t^{\prime}}$ |  | (10) |

Intuitively, $c^{t}$ is a (unnormalized) distribution over the source document words that represents the degree of coverage that those words have received from the attention mechanism so far.
Note that $c^{0}$ is a zero vector, because on the first timestep, none of the source document has been covered.

The coverage vector is used as extra input to the attention mechanism, changing equation ([1](#S2.E1 "In 2.1 Sequence-to-sequence attentional model ‣ 2 Our Models ‣ Get To The Point: Summarization with Pointer-Generator Networks")) to:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $e\_{i}^{t}=v^{T}\tanh(W\_{h}h\_{i}+W\_{s}s\_{t}+w\_{c}c^{t}\_{i}+b\_{\text{attn}})$ |  | (11) |

where $w\_{c}$ is a learnable parameter vector of same length as $v$.
This ensures that the attention mechanism’s current decision (choosing where to attend next) is informed by a reminder of its previous decisions (summarized in $c^{t}$).
This should make it easier for the attention mechanism to avoid repeatedly attending to the same locations, and thus avoid generating repetitive text.

We find it necessary (see section [5](#S5 "5 Experiments ‣ Get To The Point: Summarization with Pointer-Generator Networks")) to additionally define a coverage loss to penalize repeatedly attending to the same locations:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\text{covloss}\_{t}=\sum\nolimits\_{i}\min(a\_{i}^{t},c\_{i}^{t})$ |  | (12) |

Note that the coverage loss is bounded; in particular $\text{covloss}\_{t}\leq\sum\_{i}a\_{i}^{t}=1$.
Equation ([12](#S2.E12 "In 2.3 Coverage mechanism ‣ 2 Our Models ‣ Get To The Point: Summarization with Pointer-Generator Networks")) differs from the coverage loss used in Machine Translation.
In MT, we assume that there should be a roughly one-to-one translation ratio; accordingly the final coverage vector is penalized if it is more or less than 1.
Our loss function is more flexible: because summarization should not require uniform coverage, we only penalize the overlap between each attention distribution and the coverage so far – preventing repeated attention.
Finally, the coverage loss, reweighted by some hyperparameter $\lambda$, is added to the primary loss function to yield a new composite loss function:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\text{loss}\_{t}=-\log P(w^{\*}\_{t})+\lambda\sum\nolimits\_{i}\min(a\_{i}^{t},c\_{i}^{t})$ |  | (13) |

## 3 Related Work

Neural abstractive summarization.
[Rush et al.](#bib.bib22) [Rush et al. (2015)](#bib.bib22) were the first to apply modern neural networks to abstractive text summarization, achieving state-of-the-art performance on DUC-2004 and Gigaword, two sentence-level summarization datasets.
Their approach, which is centered on the attention mechanism, has been augmented with recurrent decoders [Chopra et al. (2016)](#bib.bib4), Abstract Meaning Representations [Takase et al. (2016)](#bib.bib27), hierarchical networks [Nallapati et al. (2016)](#bib.bib19), variational autoencoders [Miao and Blunsom (2016)](#bib.bib17), and direct optimization of the performance metric [Ranzato et al. (2016)](#bib.bib21), further improving performance on those datasets.

However, large-scale datasets for summarization of longer text are rare.
[Nallapati et al.](#bib.bib19) [Nallapati et al. (2016)](#bib.bib19) adapted the DeepMind question-answering dataset [Hermann et al. (2015)](#bib.bib9) for summarization, resulting in the CNN/Daily Mail dataset, and provided the first abstractive baselines.
The same authors then published a neural *extractive* approach [Nallapati et al. (2017)](#bib.bib18), which uses hierarchical RNNs to select sentences, and found that it significantly outperformed their abstractive result with respect to the ROUGE metric.
To our knowledge, these are the only two published results on the full dataset.

Prior to modern neural methods, abstractive summarization received less attention than extractive summarization, but [Jing](#bib.bib10) [Jing (2000)](#bib.bib10) explored cutting unimportant parts of sentences to create summaries, and [Cheung and Penn](#bib.bib3) [Cheung and Penn (2014)](#bib.bib3) explore sentence fusion using dependency trees.

Pointer-generator networks.
The pointer network [Vinyals et al. (2015)](#bib.bib29) is a sequence-to-sequence model that uses the soft attention distribution of [Bahdanau et al.](#bib.bib1) [Bahdanau et al. (2015)](#bib.bib1) to produce an output sequence consisting of elements from the input sequence.
The pointer network has been used to create hybrid approaches for NMT [Gulcehre et al. (2016)](#bib.bib8), language modeling [Merity et al. (2016)](#bib.bib15), and summarization [Gu et al. (2016)](#bib.bib7); [Gulcehre et al. (2016)](#bib.bib8); [Miao and Blunsom (2016)](#bib.bib17); [Nallapati et al. (2016)](#bib.bib19); [Zeng et al. (2016)](#bib.bib31).

Our approach is close to the Forced-Attention Sentence Compression model of [Miao and Blunsom](#bib.bib17) [Miao and Blunsom (2016)](#bib.bib17) and the CopyNet model of [Gu et al.](#bib.bib7) [Gu et al. (2016)](#bib.bib7), with some small differences:
(i) We calculate an explicit switch probability $p\_{\text{gen}}$, whereas Gu et al. induce competition through a shared softmax function.
(ii) We recycle the attention distribution to serve as the copy distribution, but Gu et al. use two separate distributions.
(iii) When a word appears multiple times in the source text, we sum probability mass from all corresponding parts of the attention distribution, whereas Miao and Blunsom do not.
Our reasoning is that (i) calculating an explicit $p\_{\text{gen}}$ usefully enables us to raise or lower the probability of all generated words or all copy words at once, rather than individually, (ii) the two distributions serve such similar purposes that we find our simpler approach suffices, and (iii) we observe that the pointer mechanism often copies a word while attending to multiple occurrences of it in the source text.

Our approach is considerably different from that of
[Gulcehre et al. (2016)](#bib.bib8) and [Nallapati et al. (2016)](#bib.bib19).
Those works train their pointer components to activate only for out-of-vocabulary words or named entities (whereas we allow our model to freely learn when to use the pointer), and they do not mix the probabilities from the copy distribution and the vocabulary distribution.
We believe the mixture approach described here is better for abstractive summarization – in section [6](#S6 "6 Results ‣ Get To The Point: Summarization with Pointer-Generator Networks") we show that the copy mechanism is vital for accurately reproducing rare but in-vocabulary words, and in section [7.2](#S7.SS2 "7.2 How abstractive is our model? ‣ 7 Discussion ‣ Get To The Point: Summarization with Pointer-Generator Networks") we observe that the mixture model enables the language model and copy mechanism to work together to perform abstractive copying.

Coverage.
Originating from Statistical Machine Translation [Koehn (2009)](#bib.bib11), coverage was adapted for NMT by [Tu et al.](#bib.bib28) [Tu et al. (2016)](#bib.bib28) and [Mi et al.](#bib.bib16) [Mi et al. (2016)](#bib.bib16), who both use a GRU to update the coverage vector each step.
We find that a simpler approach – summing the attention distributions to obtain the coverage vector – suffices.
In this respect our approach is similar to [Xu et al.](#bib.bib30) [Xu et al. (2015)](#bib.bib30), who apply a coverage-like method to image captioning,
and [Chen et al.](#bib.bib2) [Chen et al. (2016)](#bib.bib2), who also incorporate a coverage mechanism (which they call ‘distraction’) as described in equation ([11](#S2.E11 "In 2.3 Coverage mechanism ‣ 2 Our Models ‣ Get To The Point: Summarization with Pointer-Generator Networks")) into neural summarization of longer text.

Temporal attention is a related technique that has been applied to NMT [Sankaran et al. (2016)](#bib.bib24) and summarization [Nallapati et al. (2016)](#bib.bib19).
In this approach, each attention distribution is divided by the sum of the previous, which effectively dampens repeated attention.
We tried this method but found it too destructive, distorting the signal from the attention mechanism and reducing performance.
We hypothesize that an early intervention method such as coverage is preferable to a post hoc method such as temporal attention – it is better to inform the attention mechanism to help it make better decisions, than to override its decisions altogether.
This theory is supported by the large boost that coverage gives our ROUGE scores (see Table [1](#S4.T1 "Table 1 ‣ 4 Dataset ‣ Get To The Point: Summarization with Pointer-Generator Networks")), compared to the smaller boost given by temporal attention for the same task [Nallapati et al. (2016)](#bib.bib19).

## 4 Dataset

We use the CNN/Daily Mail dataset [Hermann et al. (2015)](#bib.bib9); [Nallapati et al. (2016)](#bib.bib19), which contains online news articles (781 tokens on average) paired with multi-sentence summaries (3.75 sentences or 56 tokens on average).
We used scripts supplied by [Nallapati et al. (2016)](#bib.bib19) to obtain the same version of the the data, which has 287,226 training pairs, 13,368 validation pairs and 11,490 test pairs.
Both the dataset’s published results [Nallapati et al. (2016)](#bib.bib19); [Nallapati et al. (2017)](#bib.bib18) use the anonymized version of the data, which has been pre-processed to replace each named entity, e.g., The United Nations, with its own unique identifier for the example pair, e.g., @entity5.
By contrast, we operate directly on the original text (or non-anonymized version of the data),22
2
at [www.github.com/abisee/pointer-generator](https://www.github.com/abisee/pointer-generator) which we believe is the favorable problem to solve because it requires no pre-processing.

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | ROUGE | | | METEOR | |
|  | 1 | 2 | L | exact match | + stem/syn/para |
| abstractive model [Nallapati et al. (2016)](#bib.bib19)\* | 35.46 | 13.30 | 32.65 | - | - |
| seq-to-seq + attn baseline (150k vocab) | 30.49 | 11.17 | 28.08 | 11.65 | 12.86 |
| seq-to-seq + attn baseline (50k vocab) | 31.33 | 11.81 | 28.83 | 12.03 | 13.20 |
| pointer-generator | 36.44 | 15.66 | 33.42 | 15.35 | 16.65 |
| pointer-generator + coverage | 39.53 | 17.28 | 36.38 | 17.32 | 18.72 |
| lead-3 baseline (ours) | 40.34 | 17.70 | 36.57 | 20.48 | 22.21 |
| lead-3 baseline [Nallapati et al. (2017)](#bib.bib18)\* | 39.2 | 15.7 | 35.5 | - | - |
| extractive model [Nallapati et al. (2017)](#bib.bib18)\* | 39.6 | 16.2 | 35.3 | - | - |

Table 1: ROUGE F1 and METEOR scores on the test set.
Models and baselines in the top half are abstractive, while those in the bottom half are extractive.
Those marked with \* were trained and evaluated on the anonymized dataset, and so are not strictly comparable to our results on the original text.
All our ROUGE scores have a 95% confidence interval of at most $\pm 0.25$ as reported by the official ROUGE script.
The METEOR improvement from the 50k baseline to the pointer-generator model, and from the pointer-generator to the pointer-generator+coverage model, were both found to be statistically significant using an approximate randomization test with $p<0.01$.

## 5 Experiments

For all experiments, our model has 256-dimensional hidden states and 128-dimensional word embeddings.
For the pointer-generator models, we use a vocabulary of 50k words for both source and target – note that due to the pointer network’s ability to handle OOV words, we can use a smaller vocabulary size than [Nallapati et al.](#bib.bib19)’s [Nallapati et al. (2016)](#bib.bib19) 150k source and 60k target vocabularies.
For the baseline model, we also try a larger vocabulary size of 150k.

Note that the pointer and the coverage mechanism introduce very few additional parameters to the network: for the models with vocabulary size 50k, the baseline model has 21,499,600 parameters, the pointer-generator adds 1153 extra parameters ($w\_{h^{\*}}$, $w\_{s}$, $w\_{x}$ and $b\_{\text{ptr}}$ in equation [8](#S2.E8 "In 2.2 Pointer-generator network ‣ 2 Our Models ‣ Get To The Point: Summarization with Pointer-Generator Networks")), and coverage adds 512 extra parameters ($w\_{c}$ in equation [11](#S2.E11 "In 2.3 Coverage mechanism ‣ 2 Our Models ‣ Get To The Point: Summarization with Pointer-Generator Networks")).

Unlike [Nallapati et al. (2016)](#bib.bib19), we do not pre-train the word embeddings – they are learned from scratch during training.
We train using Adagrad [Duchi et al. (2011)](#bib.bib6) with learning rate 0.15 and an initial accumulator value of 0.1.
(This was found to work best of Stochastic Gradient Descent, Adadelta, Momentum, Adam and RMSProp).
We use gradient clipping with a maximum gradient norm of 2, but do not use any form of regularization.
We use loss on the validation set to implement early stopping.

During training and at test time we truncate the article to 400 tokens and limit the length of the summary to 100 tokens for training and 120 tokens at test time.33
3
The upper limit of 120 is mostly invisible: the beam search algorithm is self-stopping and almost never reaches the 120th step.
This is done to expedite training and testing, but we also found that truncating the article can raise the performance of the model (see section [7.1](#S7.SS1 "7.1 Comparison with extractive systems ‣ 7 Discussion ‣ Get To The Point: Summarization with Pointer-Generator Networks") for more details).
For training, we found it efficient to start with highly-truncated sequences, then raise the maximum length once converged.
We train on a single Tesla K40m GPU with a batch size of 16.
At test time our summaries are produced using beam search with beam size 4.

We trained both our baseline models for about 600,000 iterations (33 epochs) – this is similar to the 35 epochs required by [Nallapati et al.](#bib.bib19)’s [Nallapati et al. (2016)](#bib.bib19) best model.
Training took 4 days and 14 hours for the 50k vocabulary model, and 8 days 21 hours for the 150k vocabulary model.
We found the pointer-generator model quicker to train, requiring less than 230,000 training iterations (12.8 epochs); a total of 3 days and 4 hours.
In particular, the pointer-generator model makes much quicker progress in the early phases of training.
To obtain our final coverage model, we added the coverage mechanism with coverage loss weighted to $\lambda=1$ (as described in equation [13](#S2.E13 "In 2.3 Coverage mechanism ‣ 2 Our Models ‣ Get To The Point: Summarization with Pointer-Generator Networks")), and trained for a further 3000 iterations (about 2 hours).
In this time the coverage loss converged to about 0.2, down from an initial value of about 0.5.
We also tried a more aggressive value of $\lambda=2$; this reduced coverage loss but increased the primary loss function, thus we did not use it.

We tried training the coverage model without the loss function, hoping that the attention mechanism may learn by itself not to attend repeatedly to the same locations, but we found this to be ineffective, with no discernible reduction in repetition.
We also tried training with coverage from the first iteration rather than as a separate training phase, but found that in the early phase of training, the coverage objective interfered with the main objective, reducing overall performance.

## 6 Results

### 6.1 Preliminaries

Our results are given in Table [1](#S4.T1 "Table 1 ‣ 4 Dataset ‣ Get To The Point: Summarization with Pointer-Generator Networks").
We evaluate our models with the standard ROUGE metric [Lin (2004b)](#bib.bib14), reporting the F1 scores for ROUGE-1, ROUGE-2 and ROUGE-L (which respectively measure the word-overlap, bigram-overlap, and longest common sequence between the reference summary and the summary to be evaluated).
We obtain our ROUGE scores using the pyrouge package.44
4
[pypi.python.org/pypi/pyrouge/0.1.3](https://pypi.python.org/pypi/pyrouge/0.1.3)
We also evaluate with the METEOR metric [Denkowski and Lavie (2014)](#bib.bib5), both in exact match mode (rewarding only exact matches between words) and full mode (which additionally rewards matching stems, synonyms and paraphrases).55
5
[www.cs.cmu.edu/~alavie/METEOR](https://www.cs.cmu.edu/~alavie/METEOR)

In addition to our own models, we also report the lead-3 baseline (which uses the first three
sentences of the article as a summary), and compare to the only existing
abstractive [Nallapati et al. (2016)](#bib.bib19) and extractive [Nallapati et al. (2017)](#bib.bib18) models on the full dataset.
The output of our models is available online.66
6
[www.github.com/abisee/pointer-generator](https://www.github.com/abisee/pointer-generator)

Given that we generate plain-text summaries but Nallapati et
al. [Nallapati et al. (2016)](#bib.bib19); [Nallapati et al. (2017)](#bib.bib18)
generate anonymized summaries (see Section [4](#S4 "4 Dataset ‣ Get To The Point: Summarization with Pointer-Generator Networks")), our ROUGE scores are not strictly comparable.
There is evidence to suggest that the original-text dataset may result in higher ROUGE scores in general than the anonymized dataset – the lead-3 baseline is higher on the former than the latter.
One possible explanation is that multi-word named entities lead to a higher rate of $n$-gram overlap.
Unfortunately, ROUGE is the only available means of comparison with Nallapati et al.’s work.
Nevertheless, given that the disparity in the lead-3 scores is (+1.1 ROUGE-1, +2.0 ROUGE-2, +1.1 ROUGE-L) points respectively, and our best model scores exceed [Nallapati et al.](#bib.bib19) [Nallapati et al. (2016)](#bib.bib19) by (+4.07 ROUGE-1, +3.98 ROUGE-2, +3.73 ROUGE-L) points, we may estimate that we outperform the only previous abstractive system by at least 2 ROUGE points all-round.

1-grams2-grams3-grams4-gramssentences$0$$10$$20$$30$% that are duplicatespointer-generator, no coveragepointer-generator + coveragereference summaries

Figure 4: Coverage eliminates undesirable repetition.
Summaries from our non-coverage model contain many duplicated $n$-grams while our coverage model produces a similar number as the reference summaries.

### 6.2 Observations

We find that both our baseline models perform poorly with respect to ROUGE and METEOR, and in fact the larger vocabulary size (150k) does not seem to help.
Even the better-performing baseline (with 50k vocabulary) produces summaries with several common problems.
Factual details are frequently reproduced incorrectly, often replacing an uncommon (but in-vocabulary) word with a more-common alternative.
For example in Figure [1](#S0.F1 "Figure 1 ‣ Get To The Point: Summarization with Pointer-Generator Networks"), the baseline model appears to struggle with the rare word thwart, producing destabilize instead, which leads to the fabricated phrase destabilize nigeria’s economy.
Even more catastrophically, the summaries sometimes devolve into repetitive nonsense, such as the third sentence produced by the baseline model in Figure [1](#S0.F1 "Figure 1 ‣ Get To The Point: Summarization with Pointer-Generator Networks").
In addition, the baseline model can’t reproduce out-of-vocabulary words (such as muhammadu buhari in Figure [1](#S0.F1 "Figure 1 ‣ Get To The Point: Summarization with Pointer-Generator Networks")).
Further examples of all these problems are provided in the supplementary material.

Our pointer-generator model achieves much better ROUGE and METEOR scores than the baseline, despite many fewer training epochs.
The difference in the summaries is also marked: out-of-vocabulary words are handled easily, factual details are almost always copied correctly, and there are no fabrications (see Figure [1](#S0.F1 "Figure 1 ‣ Get To The Point: Summarization with Pointer-Generator Networks")).
However, repetition is still very common.

Our pointer-generator model with coverage improves the ROUGE and METEOR scores further, convincingly surpassing the best abstractive model of [Nallapati et al.](#bib.bib19) [Nallapati et al. (2016)](#bib.bib19) by several ROUGE points.
Despite the brevity of the coverage training phase (about 1% of the total training time), the repetition problem is almost completely eliminated, which can be seen both qualitatively (Figure [1](#S0.F1 "Figure 1 ‣ Get To The Point: Summarization with Pointer-Generator Networks")) and quantitatively (Figure [4](#S6.F4 "Figure 4 ‣ 6.1 Preliminaries ‣ 6 Results ‣ Get To The Point: Summarization with Pointer-Generator Networks")).
However, our best model does not quite surpass the ROUGE scores of the
lead-3 baseline, nor the current best extractive model [Nallapati et al. (2017)](#bib.bib18).
We discuss this issue in section [7.1](#S7.SS1 "7.1 Comparison with extractive systems ‣ 7 Discussion ‣ Get To The Point: Summarization with Pointer-Generator Networks").

## 7 Discussion

Article: smugglers lure arab and african migrants by offering discounts to get onto overcrowded ships if people bring more potential passengers, a cnn investigation has revealed. (…)
  
Summary: cnn investigation uncovers the business inside a human smuggling ring.
  
 
Article: eyewitness video showing white north charleston police officer michael slager shooting to death an unarmed black man has exposed discrepancies in the reports of the first officers on the scene. (…)
  
Summary: more questions than answers emerge in controversial s.c. police shooting.

Figure 5: Examples of highly abstractive reference summaries (bold denotes novel words).

### 7.1 Comparison with extractive systems

It is clear from Table [1](#S4.T1 "Table 1 ‣ 4 Dataset ‣ Get To The Point: Summarization with Pointer-Generator Networks") that extractive systems tend to achieve higher ROUGE scores than abstractive, and that the extractive lead-3 baseline is extremely strong (even the best extractive system beats it by only a small margin).
We offer two possible explanations for these observations.

Firstly, news articles tend to be structured with the most important information at the start; this partially explains the strength of the lead-3 baseline.
Indeed, we found that using only the first 400 tokens (about 20 sentences) of the article yielded significantly higher ROUGE scores than using the first 800 tokens.

Secondly, the nature of the task and the ROUGE metric make extractive approaches and the lead-3 baseline difficult to beat.
The choice of content for the reference summaries is quite subjective – sometimes the sentences form a self-contained summary; other times they simply showcase a few interesting details from the article.
Given that the articles contain 39 sentences on average, there are many equally valid ways to choose 3 or 4 highlights in this style.
Abstraction introduces even more options (choice of phrasing), further decreasing the likelihood of matching the reference summary.
For example, smugglers profit from desperate migrants is a valid alternative abstractive summary for the first example in Figure [5](#S7.F5 "Figure 5 ‣ 7 Discussion ‣ Get To The Point: Summarization with Pointer-Generator Networks"), but it scores 0 ROUGE with respect to the reference summary.
This inflexibility of ROUGE is exacerbated by only having one reference summary, which has been shown to lower ROUGE’s reliability compared to multiple reference summaries [Lin (2004a)](#bib.bib13).

Due to the subjectivity of the task and thus the diversity of valid summaries, it seems that ROUGE rewards safe strategies such as selecting the first-appearing content, or preserving original phrasing.
While the reference summaries do sometimes deviate from these techniques, those deviations are unpredictable enough that the safer strategy obtains higher ROUGE scores on average.
This may explain why extractive systems tend to obtain higher ROUGE scores than abstractive, and even extractive systems do not significantly exceed the lead-3 baseline.

To explore this issue further, we evaluated our systems with the METEOR metric, which rewards not only exact word matches, but also matching stems, synonyms and paraphrases (from a pre-defined list).
We observe that all our models receive over 1 METEOR point boost by the inclusion of stem, synonym and paraphrase matching, indicating that they may be performing some abstraction.
However, we again observe that the lead-3 baseline is not surpassed by our models.
It may be that news article style makes the lead-3 baseline very strong with respect to any metric.
We believe that investigating this issue further is an important direction for future work.

1-grams2-grams3-grams4-gramssentences$0$$20$$40$$60$$80$$100$% that are novelpointer-generator + coveragesequence-to-sequence + attention baselinereference summaries

Figure 6: Although our best model is abstractive, it does not produce novel $n$-grams (i.e., $n$-grams that don’t appear in the source text) as often as the reference summaries. The baseline model produces more novel $n$-grams, but many of these are erroneous (see section [7.2](#S7.SS2 "7.2 How abstractive is our model? ‣ 7 Discussion ‣ Get To The Point: Summarization with Pointer-Generator Networks")).

Article: andy murray (…) is into the semi-finals of the miami open , but not before getting a scare from 21 year-old austrian dominic thiem, who pushed him to 4-4 in the second set before going down 3-6 6-4, 6-1 in an hour and three quarters. (…)
  
Summary: andy murray defeated dominic thiem 3-6 6-4, 6-1 in an hour and three quarters.
  
 
Article: (…) wayne rooney smashes home during manchester united ’s 3-1 win over aston villa on saturday. (…)
  
Summary: manchester united beat aston villa 3-1 at old trafford on saturday.

Figure 7: Examples of abstractive summaries produced by our model (bold denotes novel words).

### 7.2 How abstractive is our model?

We have shown that our pointer mechanism makes our abstractive system more reliable, copying factual details correctly more often.
But does the ease of copying make our system any less abstractive?

Figure [6](#S7.F6 "Figure 6 ‣ 7.1 Comparison with extractive systems ‣ 7 Discussion ‣ Get To The Point: Summarization with Pointer-Generator Networks") shows that our final model’s summaries contain a much lower rate of novel $n$-grams (i.e., those that don’t appear in the article) than the reference summaries, indicating a lower degree of abstraction.
Note that the baseline model produces novel $n$-grams more frequently – however, this statistic includes all the incorrectly copied words, UNK tokens and fabrications alongside the good instances of abstraction.

In particular, Figure [6](#S7.F6 "Figure 6 ‣ 7.1 Comparison with extractive systems ‣ 7 Discussion ‣ Get To The Point: Summarization with Pointer-Generator Networks") shows that our final model copies whole article sentences 35% of the time; by comparison the reference summaries do so only 1.3% of the time.
This is a main area for improvement, as we would like our model to move beyond simple sentence extraction.
However, we observe that the other 65% encompasses a range of abstractive techniques.
Article sentences are truncated to form grammatically-correct shorter versions, and new sentences are composed by stitching together fragments.
Unnecessary interjections, clauses and parenthesized phrases are sometimes omitted from copied passages.
Some of these abilities are demonstrated in Figure [1](#S0.F1 "Figure 1 ‣ Get To The Point: Summarization with Pointer-Generator Networks"), and the supplementary material contains more examples.

Figure [7](#S7.F7 "Figure 7 ‣ 7.1 Comparison with extractive systems ‣ 7 Discussion ‣ Get To The Point: Summarization with Pointer-Generator Networks") shows two examples of more impressive abstraction – both with similar structure.
The dataset contains many sports stories whose summaries follow the X beat Y $\langle$score$\rangle$ on $\langle$day$\rangle$ template, which may explain why our model is most confidently abstractive on these examples.
In general however, our model does not routinely produce summaries like those in Figure [7](#S7.F7 "Figure 7 ‣ 7.1 Comparison with extractive systems ‣ 7 Discussion ‣ Get To The Point: Summarization with Pointer-Generator Networks"), and is not close to producing summaries like in Figure [5](#S7.F5 "Figure 5 ‣ 7 Discussion ‣ Get To The Point: Summarization with Pointer-Generator Networks").

The value of the generation probability $p\_{\text{gen}}$ also gives a measure of the abstractiveness of our model.
During training, $p\_{\text{gen}}$ starts with a value of about 0.30 then increases, converging to about 0.53 by the end of training.
This indicates that the model first learns to mostly copy, then learns to generate about half the time.
However at test time, $p\_{\text{gen}}$ is heavily skewed towards copying, with a mean value of 0.17.
The disparity is likely due to the fact that during training, the model receives word-by-word supervision in the form of the reference summary, but at test time it does not.
Nonetheless, the generator module is useful even when the model is copying.
We find that $p\_{\text{gen}}$ is highest at times of uncertainty such as the beginning of sentences, the join between stitched-together fragments, and when producing periods that truncate a copied sentence.
Our mixture model allows the network to copy while simultaneously consulting the language model – enabling operations like stitching and truncation to be performed with grammaticality.
In any case, encouraging the pointer-generator model to write more abstractively, while retaining the accuracy advantages of the pointer module, is an exciting direction for future work.

## 8 Conclusion

In this work we presented a hybrid pointer-generator architecture with coverage, and showed that it reduces inaccuracies and repetition.
We applied our model to a new and challenging long-text dataset, and significantly outperformed the abstractive state-of-the-art result.
Our model exhibits many abstractive abilities, but attaining higher levels of abstraction remains an open research question.

## 9 Acknowledgment

We thank the ACL reviewers for their helpful comments.
This work was begun while the first author was an intern at Google Brain and continued at Stanford. Stanford University gratefully acknowledges the support of the DARPA DEFT Program AFRL contract no. FA8750-13-2-0040. Any opinions in this material are those of the authors alone.

## Supplementary Material

This appendix provides examples from the test set, with side-by-side comparisons of the reference summaries and the summaries produced by our models.
In each example:

* •

  italics denote out-of-vocabulary words
* •

  red denotes factual errors in the summaries
* •

  green shadingintensity represents the value of the generation probability $p\_{\text{gen}}$
* •

  yellow shadingintensity represents final value of the coverage vector at the end of final model’s summarization process.

Article (truncated): andy murray came close to giving himself some extra preparation time for his wedding next week before ensuring that he still has unfinished tennis business to attend to . the world no 4 is into the semi-finals of the miami open , but not before getting a scare from 21 year-old austrian dominic thiem , who pushed him to 4-4 in the second set before going down 3-6 6-4 , 6-1 in an hour and three quarters . murray was awaiting the winner from the last eight match between tomas berdych and argentina ’s juan monaco . prior to this tournament thiem lost in the second round of a challenger event to soon-to-be new brit aljaz bedene . andy murray pumps his first after defeating dominic thiem to reach the miami open semi finals . muray throws his sweatband into the crowd after completing a 3-6 , 6-4 , 6-1 victory in florida . murray shakes hands with thiem who he described as a ’ strong guy ’ after the game . and murray has a fairly simple message for any of his fellow british tennis players who might be agitated about his imminent arrival into the home ranks : do n’t complain . instead the british no 1 believes his colleagues should use the assimilation of the world number 83 , originally from slovenia , as motivation to better themselves .
  
 
Reference Summary:
  
british no 1 defeated dominic thiem in miami open quarter finals .
  
andy murray celebrated his 500th career win in the previous round .
  
third seed will play the winner of tomas berdych and juan monaco in the semi finals of the atp masters 1000 event in key biscayne .
  
 
Baseline:
  
andy murray beat UNK bedene 6-3 , 6-4 , 6-1 in an hour and three quarters .
  
british no 1 believes his colleagues should use the maze of the world number 83 , originally from slovenia , as motivation to better themselves .
  
 
Pointer-Generator, No Coverage:
  
andy murray came close to giving himself some extra preparation for his wedding next week before getting a scare from 21 year-old austrian dominic thiem .
  
the world no 4 is into the semi-finals of the miami open , but not before getting a scare from 21 year-old austrian dominic thiem .
  
 
Pointer-Generator, With Coverage:
  
andy murray defeated dominic thiem 3-6 6-4 , 6-1 in an hour and three quarters .
  
murray was awaiting the winner from the last eight match between tomas berdych and argentina ’s juan monaco .
  
prior to this tournament thiem lost in the second round of a challenger event to soon-to-be new brit aljaz bedene .

Figure 8: 
The baseline model reports the wrong score 6-3, substitutes bedene for thiem and struggles with the uncommon word assimilation.
The pointer-network models accurately reproduce the out-of-vocabulary words thiem and aljaz.
Note that the final model produces the novel word defeated to incorporate several fragments into a single sentence.

Article (truncated): munster have signed new zealand international francis saili on a two-year deal . utility back saili , who made his all blacks debut against argentina in 2013 , will move to the province later this year after the completion of his 2015 contractual commitments . the 24-year-old currently plays for auckland-based super rugby side the blues and was part of the new zealand under-20 side that won the junior world championship in italy in 2011 . saili ’s signature is something of a coup for munster and head coach anthony foley believes he will be a great addition to their backline . francis saili has signed a two-year deal to join munster and will link up with them later this year . ’ we are really pleased that francis has committed his future to the province , ’ foley told munster ’s official website . ’ he is a talented centre with an impressive skill-set and he possesses the physical attributes to excel in the northern hemisphere . ’ i believe he will be a great addition to our backline and we look forward to welcoming him to munster . ’ saili has been capped twice by new zealand and was part of the under 20 side that won the junior championship in 2011 .
  
 
Reference Summary:
  
utility back francis saili will join up with munster later this year .
  
the new zealand international has signed a two-year contract .
  
saili made his debut for the all blacks against argentina in 2013 .
  
 
Baseline:
  
dutch international francis UNK has signed a two-year deal to join irish UNK super rugby side the blues .
  
UNK ’s signature is something of a coup for munster and his head coach anthony foley believes he will be a great addition to their respective prospects .
  
UNK has been capped twice by new zealand .
  
 
Pointer-Generator, No Coverage:
  
new zealand international francis saili will move to the province later this year .
  
utility back saili made his all blacks debut against argentina in 2013 .
  
utility back saili will move to the province later this year .
  
 
Pointer-Generator, With Coverage:
  
francis saili has signed a two-year deal to join munster later this year .
  
the 24-year-old was part of the new zealand under-20 side that won the junior world championship in italy in 2011 .
  
saili ’s signature is something of a coup for munster and head coach anthony foley .

Figure 9: The baseline model incorrectly substitutes dutch for new zealand (perhaps reflecting the European bias of the dataset), fabricates irish, and struggles with out-of-vocabulary words saili and auckland-based.
Though it is not clear why, the phrase addition to our backline is changed to the nonsensical addition to their respective prospects.
The pointer-generator model fixes these accuracy problems, and the addition of coverage fixes the repetition problem.
Note that the final model skips over large passages of text to produce shorter sentences.

Article (truncated): right from the moment he breezed through the doors at old trafford , louis van gaal was a man with a plan . the first season , he stated , would see him deliver manchester united back into their rightful place in the champions league . he would restore them to the premier league top four but loftier aims of silverware would have to wait . his three-year vision would allow for such thoughts but , first things first , united needed to be dining from european football ’s top table again . louis van gaal is close to delivering his first-season aim of returning man united into champions league . wayne rooney smashes home during manchester united ’s 3-1 win over aston villa on saturday . united ’s win over aston villa took them third , eight points ahead of fifth-placed liverpool in the table . april 12 manchester city ( h ) . april 18 chelsea ( a ) . april 26 everton ( a ) . may 2 west bromwich albion ( h ) . may 9 crystal palace ( a ) . may 17 arsenal ( h ) . may 24 hull city ( a ) . one season out of the champions league was far from ideal , but two seasons would be an absolute disaster and something , he understood , that would not be tolerated . in november , even that was looking optimistic . a 1-0 defeat to manchester city meant that united had taken just 13 points from their opening 10 matches - it was their worst start to a league campaign since 1986 , when ron atkinson only lasted until november .
  
 
Reference Summary:
  
man united have an eight-point cushion from fifth-place liverpool .
  
van gaal looks likely to deliver on his promise of top four finish .
  
but the dutchman has a three-year vision mapped out .
  
next season will have to see united mount sustained challenge for title .
  
they must also reach the later stages of the champions league .
  
 
Baseline:
  
manchester united beat aston villa 3-1 at old trafford on saturday .
  
louis van gaal is close to delivering his UNK aim of returning man united into the premier league top four .
  
louis van gaal is close to delivering his UNK aim of returning man united into champions league .
  
 
Pointer-Generator, No Coverage:
  
louis van gaal is close to delivering his first-season aim of returning man united into champions league.
  
united ’s win over aston villa took them third , eight points ahead of fifth-placed liverpool in the table .
  
louis van gaal is close to delivering his first-season aim of returning man united into champions league.
  
 
Pointer-Generator, With Coverage:
  
manchester united beat aston villa 3-1 at old trafford on saturday .
  
louis van gaal is close to delivering his first-season aim of returning man united into champions league .
  
united needed to be dining from european football ’s top table again .

Figure 10: In this example, both our baseline model and final model produce a completely abstractive first sentence, using a novel word beat.

Article (truncated): having been on the receiving end of a 6-1 thumping , a defeat like that could be justifiably met with a backlash by angry supporters . watching a 3-1 first leg aggregate advantage turn into a 7-4 deficit come the end of the reverse encounter too could send many fans apoplectic at the capitulation of their side . however that does n’t appear the case for those devoted to porto . porto supporters gave their team a hero ’s welcome following their 6-1 defeat at bayern munich on tuesday . porto star striker jackson martinez was one of many players to look perplexed by their warm reception . porto boss julen lopetegui ( left ) was hugged by fans congratulating him on their champions league run . police escorts were needed to keep the delirious supporters at bay as the porto team bus drove past . the team bus was met with a cacophony of noise from porto supporters proudly chanting about their club . on their return from a humiliating champions league quarter-final loss at the hands of bayern munich on tuesday night , the squad were given a heroes reception as they arrived back in portugal . in the early hours of wednesday morning , fans mobbed the squad congratulating them on their run in the tournament . star striker jackson martinez and ricardo quaresma were one of many porto players who looked perplexed as they were hugged by fans before they making their way on to the team bus - set upon a cacophony of fiercely-proud chanting . it was the first time that porto , who had been unbeaten in this season ’s tournament up until tuesday night , had reached the quarter-finals of the champions league since the 2008-09 season .
  
 
Reference Summary:
  
bayern munich beat porto 6-1 in their champions league tie on tuesday .
  
result saw bayern win quarter-final encounter 7-4 on aggregate .
  
it was the first-time porto had reached that stage since the 2008-09 season .
  
 
Baseline:
  
porto beat bayern munich 2-0 in the champions league on tuesday night .
  
porto star james UNK was one of many players involved in the match .
  
the squad were given a trophy as they arrived back in portugal .
  
 
Pointer-Generator, No Coverage:
  
porto star striker jackson martinez was one of many players to look perplexed by their warm reception.
  
porto star striker jackson martinez was one of many players to look perplexed by their warm reception.
  
porto star striker jackson martinez was one of many players to look perplexed by their warm reception.
  
 
Pointer-Generator, With Coverage:
  
porto star striker jackson martinez was one of many players to look perplexed by their warm reception .
  
porto boss julen lopetegui was hugged by fans congratulating him on their champions league run .
  
however that does n’t appear the case for those devoted to porto .
  
police escorts were needed to keep the delirious supporters at bay .

Figure 11: The baseline model makes several factual inaccuracies: it claims porto beat bayern munich not vice versa, the score is changed from 7-4 to 2-0, jackson is changed to james and a heroes reception is replaced with a trophy.
Our final model produces sentences that are individually accurate, but they do not make sense as a whole.
Note that the final model omits the parenthesized phrase ( left ) from its second sentence.

Article: ( cnn ) ” it ’s showtime ! ” michael keaton paid homage – ever so slightly – to his roles in “ beetlejuice ” and “ batman ” in his third turn hosting “ saturday night live ” this weekend . keaton acknowledged in his opening monologue that a lot has changed since he first hosted the comedy sketch show in 1982 . “ i had a baby – he ’s 31 . i also have a new girlfriend – she ’s 28 , ” he said . fans who were hoping for a full-blown revival of keaton ’s most memorable characters might have been a little disappointed . snl cast members taran killam and bobby moynihan begged the actor with a song to “ play ” batman and beetlejuice with them . all they got in response were a couple of one-liners . overall , keaton ’s performance drew high marks from viewers and critics for its “ deadpan ” manner and “ unpredictable weirdness , ” in the words of a.v . club ’s dennis perkins . fans also delighted in a cameo from “ walking dead ” star norman reedus during weekend update . keaton scored some laughs from the audience as an ad executive who ’s not very good at his job , a confused grandfather and a high school teacher who gets asked to the prom in a riff on the romantic comedy “ she ’s all that . ” other crowd-pleasing spots included a scientology parody music video and a news conference spoofing the ncaa student-athlete debate . the show also poked fun at cnn with cast member cecily strong playing anchor brooke baldwin . baldwin said on twitter that she ’s taking it as a “ crazy compliment ” and shared a clip from the skit .
  
 
Reference Summary:
  
michael keaton hosted “ saturday night live ” for the first time in 1982 .
  
in 2015 , his nods to starring roles in “ beetlejuice ” and “ batman ” are brief .
  
 
Baseline:
  
“ snl ” wins “ saturday night live ” .
  
keaton acknowledged in his opening “ saturday night live ” .
  
keaton acknowledged in his opening night ’s “ UNK ” .
  
the show also pokes fun at cnn with cast member mariah carey .
  
 
Pointer-Generator, No Coverage:
  
“ beetlejuice ” michael keaton paid homage to his roles in “ beetlejuice ” and “ batman ” in his third turn hosting “ saturday night live ” this weekend .
  
keaton acknowledged in his opening monologue that a lot has changed since he first hosted the comedy sketch show in 1982 .
  
 
Pointer-Generator, With Coverage:
  
michael keaton paid homage to his roles in “ beetlejuice ” and “ batman ” in his third turn hosting “ saturday night live ” .
  
keaton acknowledged in his opening monologue that a lot has changed since he first hosted the comedy sketch show in 1982 .

Figure 12: Baseline model replaces cecily strong with mariah carey, and produces generally nonsensical output.
The baseline model may be struggling with the out-of-vocabulary word beetlejuice, or perhaps the unusual non-news format of the article.
Note that the final model omits – ever so slightly – from its first sentence.

Article (truncated): they are supposed to be the dream team who can solve the conundrum of how to win the election . but david cameron and boris johnson were left scratching their heads today as they struggled with a children ’s jigsaw teaching toddlers about the seasons . as the london mayor tried to hammer ill-fitting pieces together with his hands , the prime minister tried out what could be a new election slogan , telling him : ’ if in doubt , wedge it in . ’ after being put right by a four-year-old who spotted their errors , the pair had more fun finger painting with tory blue paint . david cameron and boris johnson were left stumped by the puzzle at advantage children ’s day nursery in surbiton , as three-year-old stephanie looked on . when they tried to put the puzzle back together , they hit trouble after it proved to be more difficult than expected . the conservative duo made their first appearance together on the campaign trail with a visit to advantage day nursery in surbiton , south west london . they were supposed to be highlighting tory plans to double free childcare for 600,000 children aged three and four . they sat at a table with joshua and stephanie , both aged three , and four-year-olds hamish and leo where they broke up a puzzle which depicted the four seasons . when they tried to put it back together , they hit trouble after it proved to be more difficult than expected .
  
 
Reference Summary:
  
david cameron and boris johnson visit nursery to promote childcare .
  
duo left flummoxed by jigsaw aimed at teaching children about seasons .
  
london mayor resorted to brute force to hammer wrong pieces together .
  
prime minister gave his approval , telling boris : ’ if in doubt , wedge it in ’ .
  
 
Baseline:
  
david cameron and boris johnson were left mystified by the puzzle .
  
they were at the nursery in UNK to promote a tory pledge to double free childcare for 25 children aged three and four .
  
the pair were at the nursery in UNK to promote a tory pledge to double free childcare for children aged three and four .
  
 
Pointer-Generator, No Coverage:
  
london mayor tried to hammer ill-fitting pieces together with his hands .
  
they were supposed to be highlighting tory plans to double free childcare .
  
they were supposed to be highlighting tory plans to double free childcare .
  
they were supposed to be highlighting tory plans to double free childcare .
  
 
Pointer-Generator, With Coverage:
  
london mayor tried to hammer ill-fitting pieces together with his hands .
  
prime minister tried out what could be a new election slogan .
  
but they hit trouble after it proved to be more difficult than expected .

Figure 13: The baseline model appropriately replaces stumped with novel word mystified.
However, the reference summary chooses flummoxed (also novel) so the choice of mystified is not rewarded by the ROUGE metric.
The baseline model also incorrectly substitutes 600,000 for 25.
In the final model’s output we observe that the generation probability is largest at the beginning of sentences (especially the first verb) and on periods.

Article (truncated): lagos , nigeria ( cnn ) a day after winning nigeria ’s presidency , muhammadu buhari told cnn ’s christiane amanpour that he plans to aggressively fight corruption that has long plagued nigeria and go after the root of the nation ’s unrest . buhari said he ’ll “ rapidly give attention ” to curbing violence in the northeast part of nigeria , where the terrorist group boko haram operates . by cooperating with neighboring nations chad , cameroon and niger , he said his administration is confident it will be able to thwart criminals and others contributing to nigeria ’s instability . for the first time in nigeria ’s history , the opposition defeated the ruling party in democratic elections . buhari defeated incumbent goodluck jonathan by about 2 million votes , according to nigeria ’s independent national electoral commission . the win comes after a long history of military rule , coups and botched attempts at democracy in africa ’s most populous nation .
  
 
Reference Summary:
  
muhammadu buhari tells cnn ’s christiane amanpour that he will fight corruption in nigeria .
  
nigeria is the most populous country in africa and is grappling with violent boko haram extremists .
  
nigeria is also africa ’s biggest economy , but up to 70 % of nigerians live on less than a dollar a day .
  
 
Baseline:
  
UNK UNK says his administration is confident it will be able to destabilize nigeria ’s economy .
  
UNK says his administration is confident it will be able to thwart criminals and other nigerians .
  
he says the country has long nigeria and nigeria ’s economy .
  
 
Pointer-Generator, No Coverage:
  
muhammadu buhari says he plans to aggressively fight corruption in the northeast part of nigeria .
  
he says he ’ll “ rapidly give attention ” to curbing violence in the northeast part of nigeria .
  
he says his administration is confident it will be able to thwart criminals .
  
 
Pointer-Generator, With Coverage:
  
muhammadu buhari says he plans to aggressively fight corruption that has long plagued nigeria .
  
he says his administration is confident it will be able to thwart criminals .
  
the win comes after a long history of military rule , coups and botched attempts at democracy in africa ’s most populous nation .

Figure 14: The baseline model incorrectly changes thwart criminals and others contributing to nigeria’s instability to destabilize nigeria’s economy – which has a mostly opposite meaning. It also produces a nonsensical sentence.
Note that our final model produces the novel word says to paraphrase told cnn ‘s christiane amanpour.

Article: cairo ( cnn ) at least 12 people were killed sunday , and more injured , in separate attacks on a police station , a checkpoint and along a highway in egypt ’s northern sinai , authorities said . six people , including one civilian , were killed when a car bomb exploded near the police station in al-arish , capital of north sinai , health ministry spokesman hossam abdel-ghafar told ahram online . he said 40 people were injured . ansar beit al-maqdis , an isis affiliate , claimed responsibility for the attack , which came hours after another operation that the group also claimed . in that earlier attack , a first lieutenant , a sergeant and four conscripts were killed when their armored vehicle was attacked on the highway from al-arish to sheikh zuweid in northern sinai , the military said . two other soldiers were injured and taken to a military hospital . ansar beit al-maqdis has claimed many attacks against the army and police in sinai . a third attack sunday on a checkpoint in rafah left three security personnel injured , after unknown assailants opened fire at them , according to state media . the attacks come as the military announced a reshuffle of several senior military positions , state media reported . among those being replaced are the generals in charge of military intelligence and egypt ’s second field army , which is spearheading the battle against the insurgents in the northern sinai . egypt ’s army has been fighting a decade-long militant islamist insurgency , which has spiked since the ouster of muslim brotherhood president mohamed morsy in the summer of 2013 . hundreds of police and soldiers , as well as civilians , have been killed in militant attacks in the past months . ian lee reported from cairo . anas hamdan reported from atlanta .
  
  Reference Summary:
  
six people , including one civilian , are killed when a car bomb explodes near a police station .
  
six others are killed when their armored vehicle is attacked on a highway in northern sinai .
  
ansar beit al-maqdis , an isis affiliate , claims responsibility .
  
  Baseline:
  
he says the attacks come after another operation that killed 12 .
  
the attacks come as military announced a u.n. peacekeeping force in northern sinai .
  
 
Pointer-Generator, No Coverage:
  
ansar beit al-maqdis , an isis affiliate , claimed responsibility for the attack .
  
ansar beit al-maqdis , an isis affiliate , claimed responsibility for the attack .
  
the attacks come as the military announced a reshuffle of several senior military positions .
  
 
Pointer-Generator, With Coverage:
  
six people , including one civilian , were killed when a car bomb explodes near the police station .
  
ansar beit al-maqdis , an isis affiliate , claimed responsibility for the attack .
  
egypt ’s army has been fighting a decade-long militant islamist insurgency .

Figure 15: The baseline model fabricates a completely false detail about a u.n. peacekeeping force that is not mentioned in the article.
This is most likely inspired by a connection between U.N. peacekeeping forces and northern sinai in the training data.
The pointer-generator model is more accurate, correctly reporting the reshuffle of several senior military positions.
