<!-- fulltext source=arxiv_html slug=arXiv-1712.05384 fetched=2026-09-18T05:32:40+00:00 -->

# Simulation of low-depth quantum circuits as complex undirected graphical models

Sergio Boixo
Affiliation: Google Inc., Venice, CA 90291, USA
  
Sergei V. Isakov
Affiliation: Google Inc., Venice, CA 90291, USA
  
Vadim N. Smelyanskiy
Affiliation: Google Inc., Venice, CA 90291, USA
  
Hartmut Neven
Affiliation: Google Inc., Venice, CA 90291, USA

August 24, 2026

###### Abstract

Near term quantum computers with a high quantity (around 50) and
quality (around 0.995 fidelity for two-qubit gates) of
qubits will approximately sample from certain probability
distributions beyond the capabilities of known classical algorithms
on state-of-the-art computers, achieving the first milestone of
so-called quantum supremacy. This has stimulated recent progress in
classical algorithms to simulate quantum circuits. Classical
simulations are also necessary to approximate the fidelity of
multiqubit quantum computers using cross entropy benchmarking. Here
we present numerical results of a novel classical simulation algorithm to
calculate output probabilities of universal random circuits with more qubits and depth than
previously reported. For example, circuits with $5\times 9$ qubits of depth 40, $7\times 8$ qubits of depth 30, and
$10\times(\kappa>10)$) qubits of depth 19 are all easy to sample
by calculating around one thousand measurements in a single workstation. Cross entropy benchmarking with around
one million measurements for these circuits is now also possible in
a computer cluster. The algorithm is related to the “Feynman
path” method to simulate quantum circuits. For low-depth circuits, the algorithm scales
exponentially in the depth times the smaller lateral
dimension, or the treewidth, as explained in
Boixo et. al. [[1](#bib.bib1)], and therefore confirms the
bounds in that paper. In particular, circuits with $7\times 7$
qubits and depth 40 remain currently out of reach. Follow up work on
a supercomputer environment will tighten this bound.

## I Introduction

Quantum computers offer the promise to perform a number of
computational tasks believed to be impossible for classical
computers. Prominent examples are quantum
simulations [[2](#bib.bib2), [3](#bib.bib3), [4](#bib.bib4), [5](#bib.bib5), [6](#bib.bib6), [7](#bib.bib7), [8](#bib.bib8), [9](#bib.bib9)]
and factoring large numbers [[10](#bib.bib10)]. Given the progress in classical
computation, surpassing the capabilities of state-of-the-art
algorithms and computers is no small feat. Therefore, in the path to
more practical “quantum supremacy” breakthroughs, it is reasonable
to focus first on more specific milestones better suited for near-term
quantum computers with a high quantity (around 50) and quality (around
0.995 two qubit gate fidelity) of qubits. Sampling from the output
distribution of certain families of quantum circuits has been
identified as a promising venue for a first milestone of quantum
supremacy [[11](#bib.bib11), [12](#bib.bib12), [13](#bib.bib13), [14](#bib.bib14), [15](#bib.bib15), [16](#bib.bib16)]. Universal random circuits [[1](#bib.bib1)] (or more general
chaotic quantum evolutions [[17](#bib.bib17)]) are particularly well-suited for
near term devices. On the one hand, we note that an important
characteristic of these types of sampling problems is that they are
hypersensitive to perturbations [[18](#bib.bib18), [19](#bib.bib19)] and, therefore, approximate
classical algorithms are unlikely to work. On the other hand, this
also implies that an experimental implementation will not be
successful unless the qubits being used are very coherent and all
operations have high fidelity (and very fine-tuned
control). Nevertheless, the same hypersensitivity to perturbations
makes this type of demonstration of quantum supremacy a good benchmark
for multiqubit fidelity of universal computers using cross entropy
benchmarking [[1](#bib.bib1), [17](#bib.bib17)]. A successful implementation of a first milestone
of quantum supremacy would demonstrate the basic building blocks for a
large-scale quantum computer within the operational range of the
surface code [[20](#bib.bib20), [21](#bib.bib21)].

The prospect of a near-term demonstration of quantum supremacy has
also stimulated recent progress in classical algorithms to simulate
quantum circuits [[22](#bib.bib22), [1](#bib.bib1), [23](#bib.bib23), [24](#bib.bib24), [25](#bib.bib25)]. The most efficient algorithms previously
reported to simulate generic circuits (without symmetries that allow
for faster compressions [[26](#bib.bib26), [23](#bib.bib23)] or “emulations”) apply gates to a
vector state, implemented as highly optimized matrix-vector
multiplications [[22](#bib.bib22), [1](#bib.bib1), [24](#bib.bib24), [25](#bib.bib25)].
Benchmarking results for a highly optimized algorithm of
this type were reported in Ref. [[1](#bib.bib1)] for
$6\times 7$ qubits and depth 27 taking 989 seconds and performed in
the Edison supercomputer. More recently, Ref. [[24](#bib.bib24)]
reported a simulation using 8192 nodes and 0.5 petabytes of memory for
a quantum circuit (in the same ensemble) with $5\times 9$ qubits and
depth 25 on the new Cori II supercomputer in 552 seconds (and $6\times 7$ qubits in 80 seconds). Finally, Ref. [[25](#bib.bib25)] recently reported simulations of
a circuit with $7\times 7$ qubits and depth 27 and another circuit of
$7\times 8$ qubits and depth 23, along two days in the IBM Blue Gene/Q
supercomputer.
Computing time in a supercomputer at that scale is scarce and
expensive.

We generalize the simulation of a quantum circuit by mapping it onto
an undirected graphical model, which we compute using the variable
elimination algorithm, developed in the context
of exact inference [[27](#bib.bib27), [28](#bib.bib28), [28](#bib.bib28)]. In some cases a circuit amplitude can be mapped directly
to the partition function of an Ising
model with imaginary temperature [[1](#bib.bib1)], which
can be computed exactly with the same method. This is related to the
Feynman path method [[29](#bib.bib29)], the tensor network method [[30](#bib.bib30)], and similar
approaches [[31](#bib.bib31)]. The algorithm is explained
in Sec. [IV](#S4 "IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"), and we provide pseudocode in App. [A](#A1 "Appendix A Pseudocode ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"). We are mostly interested in sampling output
probabilities, but the same method can be used to calculate many
amplitudes at once or calculating observables exactly. The
quantum circuits implemented with superconducting qubits, which is our
main focus, use controlled-phase gates (and controlled-Z gates in
particular) as the predominant two-qubit
gate [[32](#bib.bib32), [20](#bib.bib20)]. We
exploit the fact that controlled-phase gates are diagonal in the
computational basis (this is also used in the algorithms referred
above). The cost of this algorithm is exponential in
$\min(O(d\ell),O(n))$ for depth $d$, minimum lateral dimension
$\ell$ and total number of qubits $n$. More optimally, the cost is
exponential in the treewidth, which is upper bounded by
$\min(O(d\ell),O(n))$, and was estimated in
Ref. [[1](#bib.bib1)] (see also
Sec. [IV.2](#S4.SS2 "IV.2 Numerical estimation of the treewidth for some quantum circuits ‣ IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")).

## II Numerical results

In the simplest implementation, we compute one-by-one the exact probabilities assigned by a
quantum circuit ${\mathcal{U}}$ to a chosen
set of outputs. One use case is cross entropy
benchmarking [[1](#bib.bib1), [17](#bib.bib17)], where we need to
compute the probabilities assigned by ${\mathcal{U}}$ to the bit-strings measured in an
experiment, see App. [B](#A2 "Appendix B Cross entropy benchmarking ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"). In other use cases, such as estimating the value of an observable, or simulating
sampling from the output distribution, the error scales as $t^{-1/2}$,
where $t$ is the number of output probabilities computed (see
App. [C](#A3 "Appendix C Random circuit sampling with a set of probabilities ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")). If the time per
amplitude is small enough (for instance, around 100 seconds or less), then we
can obtain enough probabilities in a single workstation in a
reasonable time (for instance, 1000 probabilities in around one
day). The sampling is also trivially parallelizable across
machines. The algorithm can
be modified to sample sets of probabilities in a single run, see Eq. ([6](#S3.E6 "In III.2 Undirected graphical model ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")). It can also be modified to calculate an
observable exactly, but the computational cost might change. This
algorithm is not useful in all cases. For instance,
Ref. [[1](#bib.bib1)] numerically verified that the
output distribution of low-depth universal random circuits approaches
the entropy of the Porter-Thomas (or exponential) distribution to
within its standard deviation of order $2^{-n/2}$. It would require
to compute a number of output probabilities of order $2^{n}$ to verify
this property. We also note that
for enough depth a direct evolution of the wave vector is likely to
become more efficient, as it is easier to optimize.

In what follows we report the time per probability (or amplitude) in a single
workstation. We use as a reference a machine with 2$\times$ 14-core
Intel E5-2690 V4 processors @ 2.6GHz, 35MB Cache and 128GB DDR4
2400MHz RAM. We use single precision complex numbers, as the relative error per
probability is negligible for the sizes computed (less then
$10^{-5}$). The computation of a single probability can also be
distributed among several machines as the size of the computation
grows. We leave this and other optimizations (such as reusing part of
the computation when calculating many probabilities) for follow up
work.

We are interested in circuits in a 2D lattice, as they are available
experimentally [[32](#bib.bib32), [20](#bib.bib20)]. We will
use the following set of gates:

1. 1.

   We use controlled-phase (CZ) gates as two-qubit gates.
2. 2.

   For a concrete example we use single qubit gates in the set
   $\{{\rm H},{\rm X}^{1/2},{\rm Y}^{1/2},{\rm T}\}$. The gate ${\rm H}$ is a Hadamard, ${\rm X}^{1/2}$ (${\rm Y}^{1/2}$) is a $\pi/2$ rotation around the ${\rm X}$ (${\rm Y}$) axis of the Bloch sphere, and the non-Clifford T gate is the diagonal matrix $\{1,e^{i\pi/4}\}$.

We use the rules for the layout of gates described
in [[1](#bib.bib1)]. We are also particularly interested
in superconducting qubits, and it is currently not possible to perform two CZ gates simultaneously in two neighboring qubits [[20](#bib.bib20), [33](#bib.bib33), [34](#bib.bib34), [35](#bib.bib35)]. This restriction was used for the circuits.

Figure 1: Time per output probability for a typical instance as
a function of depth on a single workstation, using
TensorFlow as the engine for the computation and a vertical
elimination ordering (see Sec. [IV.1](#S4.SS1 "IV.1 Vertical variable elimination ordering for low-depth circuits ‣ IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")). Different colors
corresponds to different circuit sizes, from $5\times 5$ (and $5\times 9$) qubits, to $10\times 10$ ($10\times 11$). The green circle
marker corresponds to the circuits simulated in
Ref. [[1](#bib.bib1)], black circles to
Ref. [[24](#bib.bib24)], and blue circles to
Ref. [[25](#bib.bib25)]. The yellow circle is the circuit
used in Fig. [3](#S2.F3 "Figure 3 ‣ II Numerical results ‣ Simulation of low-depth quantum circuits as complex undirected graphical models").

Figure [1](#S2.F1 "Figure 1 ‣ II Numerical results ‣ Simulation of low-depth quantum circuits as complex undirected graphical models") shows the time per output probability for typical instances of different circuit sizes as
a function of depth on a single workstation.11
1
To be
precise, at depth 1 we apply the first layer of Hadamards for
the circuits defined in Ref. [[1](#bib.bib1)]. Different colors
correspond to different circuit sizes, from $5\times 5$ (and $5\times 9$) qubits, to $10\times 10$ ($10\times 11$). Here we use a
vertical variable elimination ordering, which in essence processes
the “Feynman path” or worldline of each qubit in sequence (see
Sec. [IV.1](#S4.SS1 "IV.1 Vertical variable elimination ordering for low-depth circuits ‣ IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")). The processing time (and required memory)
of each computation grows exponentially with depth. The exponential
growth is also faster for larger circuits. More specifically, we
process the worldline of the qubits ordered first along the
smaller lateral dimension $\ell$. The cost of
computing probabilities for circuits with $5\times 9$ qubits,
with $\ell=5$, is similar to the cost of circuits with $5\times 5$ qubits. The same is true for circuits of sizes $7\times 7$ and $7\times 8$ with $\ell=7$, and also sizes $10\times 10$ and $10\times 11$
(or larger) with $\ell=10$. In this implementation the
computational graph of the algorithm was constructed in python
and processed with TensorFlow version 1.3.0 [[36](#bib.bib36)]. For each size
depicted, the computation becomes memory limited (128 GB RAM) after the highest
depth shown (depths around $31$ to $33$ for $7\times 7$ qubits depending
on the instance).

Figure 2: Timings per output probability for typical instances at
different depths using different implementations of the graphical
model variable elimination algorithm. We compare a TensorFlow
implementation and a C++ implementation using the vertical variable
elimination ordering (see Sec. [IV.1](#S4.SS1 "IV.1 Vertical variable elimination ordering for low-depth circuits ‣ IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")), and an implementation using the Dask python
package using a variable ordering obtained by running QuickBB [[37](#bib.bib37)] for a day to
find a treewidth decomposition at each depth (see Sec. [IV.2](#S4.SS2 "IV.2 Numerical estimation of the treewidth for some quantum circuits ‣ IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")).

Figure [2](#S2.F2 "Figure 2 ‣ II Numerical results ‣ Simulation of low-depth quantum circuits as complex undirected graphical models") compares the run times per output
probability as a function of depth for three different
implementations. One is the implementation with a TensorFlow [[36](#bib.bib36)] backend
using the same vertical variable elimination ordering as in
Fig. [1](#S2.F1 "Figure 1 ‣ II Numerical results ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"). This implementation is efficient and
portable to the different architectures in which TensorFlow is
available, including distributed environments. A second implementation
is a native C++ implementation. The C++ implementation is faster,
although the run times are similar, and is probably less portable and harder to
distribute across machines. Finally we also show an implementation using a variable
ordering obtained by running QuickBB [[37](#bib.bib37)] for a day to
find a treewidth decomposition at each depth. The tensors
obtained by this variable elimination ordering are worse aligned
than in the vertical ordering, and can not be processed by the
off-the-shelf TensorFlow binary. Therefore we used the python module
Dask [[38](#bib.bib38)] in this case (Dask was slower than TensorFlow in the vertical
ordering for our current implementation). Not taking into account
the time required to find a better variable elimination ordering,
the treewidth ordering is faster. In all three cases further
optimizations are possible, and the run times reported are merely
indicative. All three implementations are memory (RAM) limited after
the last depth shown in the figure.

Figure 3: Histogram (blue) of the output probabilities for a circuit with $7\times 8$ qubits and depth 30. We calculated 200 thousand
exact probabilities. Error bars were obtained by bootstrapping. We see that the probabilities obey the exponential or
Porter-Thomas distribution (red) [[1](#bib.bib1)].

As an illustration, we calculated 200 thousand output probabilities of
a universal random circuit with $7\times 8$ qubits and depth 30. We
show in Fig. [3](#S2.F3 "Figure 3 ‣ II Numerical results ‣ Simulation of low-depth quantum circuits as complex undirected graphical models") that the distribution obeys the exponential
or Porter-Thomas distribution. We also used these probabilities to
estimate the entropy of the output distribution of this circuit. We
obtain an entropy of $\log(2^{7\times 8})-0.422\pm 0.007$, while the analytical value
for a Porter-Thomas distribution is $\log(2^{7\times 8})-0.4228$ [[1](#bib.bib1)].

## III Circuit simulation as an undirected graphical model

The basic principle of the algorithm can be seen as a mapping of a
quantum circuit to an undirected graphical model with complex
factors. This is equivalent to the interaction graph of the Ising
model detailed in Ref. [[1](#bib.bib1)]. The evaluation
is carried out using an algorithm developed in the context of exact
inference for undirected graphical
models [[27](#bib.bib27), [28](#bib.bib28), [39](#bib.bib39)], but in the present
case the factors are complex. A
similar algorithm was used to find an exact ground state of a
classical Ising model in [[40](#bib.bib40)]. We now explain in detail how the
undirected graphical model is constructed.

### III.1 Feynman path method

We represent a quantum circuit by a product of unitary matrices $U^{(t)}$ corresponding to different clock cycles $t$. We introduce the following notation for the amplitude of a particular bit-string after the final cycle of the circuit,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\langle x|{\mathcal{U}}|0\ldots 0\rangle=\sum\_{\{b^{t}\}}\prod\_{t=0}^{d-1}\mathinner{\langle{b^{t+1}}|}U^{(t)}\mathinner{|{b^{t}}\rangle},\quad\mathinner{|{b^{d}}\rangle}=\mathinner{|{x}\rangle}.$ |  | (1) |

Here $\mathinner{|{b^{t}}\rangle}=\otimes\_{j=1}^{n}\mathinner{|{b^{t}\_{j}}\rangle}$ and $\mathinner{|{b^{t}\_{j}}\rangle}$
corresponds to the states $\mathinner{|{0}\rangle}$ or $\mathinner{|{1}\rangle}$ of the $j$-th
qubit. The expression ([1](#S3.E1 "In III.1 Feynman path method ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) can be viewed as a Feynman path integral with individual paths $\{b^{0},\ldots,b^{d}\}$
formed by a sequence of the computational basis states of the $n$-qubit system. The initial condition for each path corresponds to $b^{0}\_{j}=0$ for all qubits and the final point corresponds to
$\mathinner{|{b^{d}}\rangle}=\mathinner{|{x}\rangle}$.

Assuming that a ${\rm T}$ gate is applied to qubit $j$ at the cycle $t$, the indices of the matrix $\mathinner{\langle{b^{t+1}}|}U^{(t)}\mathinner{|{b^{t}}\rangle}$ will be equal to each other, i.e. $b\_{j}^{t+1}=b^{t}\_{j}$.
A similar property applies to the ${\rm CZ}$ gate as well. The state of a qubit can only flip under the action of the gates ${\rm H}$, ${\rm X}^{1/2}$ or ${\rm Y}^{1/2}$.
We refer to these as non-diagonal gates as they contain two nonzero
elements in each row and column (unlike ${\rm T}$ and ${\rm CZ}$). This
observation allows us to rewrite the path integral representation in a
more economic fashion.

Through the circuit, a sequence of non-diagonal gates are applied to qubit $j$. We denote the length of this sequence as $d\_{j}$.
In a given path the qubit $j$ goes through the sequence of Boolean
states $\{b\_{j}^{k}\}\_{k=0}^{d\_{j}},$ where, as before, we have $b\_{j}^{k}\in\{0,1\}$. The value of $b\_{j}^{k}$ in the sequence determines the state of the qubit immediately after the action of the $k$-th non-diagonal gate. The last element in the sequence is fixed
by the assignment of bits in the bit-string $x$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $b\_{j}^{d\_{j}}=x\_{j}\;,\quad j\in[1,n]\;.$ |  | (2) |

Therefore, an individual path in the path integral can be encoded by
the set of $\sum\_{j=1}^{n}d\_{j}$ binary variables $\{b\_{j}^{k}\}$ with
$j\in[1,n]$ and $k\in[0,d\_{j}]$ for a given $j$.

### III.2 Undirected graphical model

Equation ([1](#S3.E1 "In III.1 Feynman path method ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) is a sum of products of factors defined by the gates of the quantum circuit. A quantum circuit ${\mathcal{U}}$ is given as a sequence of gates ${\mathcal{U}}=U\_{g}\cdots U\_{1}$. In expression ([1](#S3.E1 "In III.1 Feynman path method ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")), each gate $U$ will contribute
factors defined by a complex pseudo-Boolean function
$\psi\_{U}$. A diagonal one-qubit gate is expressed as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle U=\sum\_{b\in\{0,1\}}\psi\_{U}(b)\mathinner{|{b}\rangle}\mathinner{\langle{b}|}\quad\quad\textrm{(diagonal)}\;,$ |  | (3) |

where $\psi\_{U}(b)$ is a complex function of one Boolean variable.
Next consider a non-diagonal one-qubit gate,
for example ${\rm H}$, ${\rm X}^{1/2}$, ${\rm Y}^{1/2}$, and so on,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle U=\sum\_{b,b^{\prime}\in\{0,1\}}\psi\_{U}(b^{\prime},b)\mathinner{|{b^{\prime}}\rangle}\mathinner{\langle{b}|}\quad\quad\textrm{(non-diagonal)}\;,$ |  | (4) |

where $\psi\_{U}(b,b^{\prime})$ is a complex function of two Boolean
variables. For example, for a Hadamard gate $\psi\_{\rm H}(1,1)=-1/\sqrt{2}$, while all other entries are $1/\sqrt{2}$. A
diagonal two-qubit gate, such as ${\rm CZ}$, can be written as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle U={\rm CZ}=\sum\_{b,b^{\prime}\in\{0,1\}}\psi\_{\rm CZ}(b,b^{\prime})\mathinner{|{b,b^{\prime}}\rangle}\mathinner{\langle{b,b^{\prime}}|}\;,$ |  | (5) |

where $\psi\_{\rm CZ}(b\_{1},b\_{2})$ is also a function of two Boolean
variables, with $\psi\_{\rm CZ}(1,1)=-1$ and all the other
entries equal $1$.

For circuits where the only two-qubit gate is a
${\rm CZ}$, the expression ([1](#S3.E1 "In III.1 Feynman path method ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) is a sum of products of factors
defined by complex functions of one or two Boolean variables

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\langle x|{\mathcal{U}}|0\ldots 0\rangle=\sum\_{\{b\_{j}^{k}\}}\delta(b\_{n}^{d\_{n}},x\_{n})\cdots\psi\_{\nu}(b\_{\nu\_{1}}^{\nu^{\prime}\_{1}},b\_{\nu\_{2}}^{\nu^{\prime}\_{2}})\cdots\\ \cdots\psi\_{\mu}(b\_{\mu}^{\mu^{\prime}})\cdots\psi\_{1}(b\_{1}^{1},b\_{1}^{0})\cdots\delta(b\_{2}^{0},0)\delta(b\_{1}^{0},0)$ |  | (6) |

where $\{b\_{j}^{k}\}$ are the classical Boolean variables introduced
above. The delta functions set the values of the Boolean variables
corresponding to the initial and final bit-strings. If we omit some
or all the
delta functions, we would compute sets of amplitudes at once. We show below how the method is extended to more general
gates or gates acting on more qubits.

In order to compute expression ([6](#S3.E6 "In III.2 Undirected graphical model ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")), it is convenient
to interpret it as an undirected
graphical model by defining the graph $G$ where each variable $b\_{j}^{k}$
corresponds exactly to one vertex in $G$ and each function $\psi$ results in a
clique between the vertices corresponding to the variables of
$\psi$. As explained above, the subscript $j\in[1,n]$ enumerates the
qubits, and the superscript $k$ enumerates new variables introduced
along each qubit worldline, one new variable for each qubit acted upon
by a non-diagonal gate. After the vertices of the graph $G$ have been
defined in this way, gates do not introduce any further vertices,
rather they (might) introduce edges between vertices. Multiple
gates might be represented by the same edge or edges, and act upon the
same vertex or vertices. Explicit rules on how gates are represented
are given below.

A quantum circuit representation of a diagonal one-qubit gate and the corresponding graphical model are

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\lx@xy@svg{\hbox{\raise 2.5pt\hbox{\kern 0.0pt\hbox{\ignorespaces\ignorespaces\ignorespaces\hbox{\vtop{\halign{\entry@#!@&&\entry@@#!@\cr&&&&\crcr}}}\ignorespaces{\hbox{\kern 0.0pt\raise 0.0pt\hbox{\hbox{\kern-3.0pt\raise 1.25pt\hbox{\hbox{\kern 3.0pt\raise-2.5pt\hbox{$\textstyle{}$}}}}}}}{\hbox{\kern 10.00002pt\raise 0.0pt\hbox{\hbox{\kern-2.14583pt\raise 5.0pt\hbox{$\textstyle{b}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 20.00003pt\raise 0.0pt\hbox{\hbox{\kern 3.00003pt\raise-3.41666pt\hbox{$\textstyle{U}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 43.91814pt\raise 0.0pt\hbox{\hbox{\kern-2.14583pt\raise 5.0pt\hbox{$\textstyle{b}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 53.91815pt\raise 0.0pt\hbox{\hbox{\kern-3.0pt\raise 1.25pt\hbox{\hbox{\kern 3.0pt\raise-2.5pt\hbox{$\textstyle{\ignorespaces\ignorespaces\ignorespaces\ignorespaces}$}}}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}\ignorespaces}}}}\ignorespaces\quad\quad\Longrightarrow\quad\quad\hbox to10.96pt{\vbox to23.64pt{\pgfpicture\makeatletter\hbox{\hskip 5.47884pt\lower-4.91386pt\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@begingroup@{stroke=#000000} \lxSVG@begingroup@{fill=#000000} \lxSVG@setlinewidth{\the\pgflinewidth}\lxSVG@begingroup@{stroke-width=0.4pt} \lx@inpgf@ignorespaces\nullfont\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} {{}} {{\lx@inpgf@ignorespaces{}{}{{}}{}}}{{{}}}{{{{}}{{}}\lx@inpgf@ignorespaces}}{{}}{{{ }}}\lx@inpgf@ignorespaces\hbox{\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.52 0 C 6.52 3.6 3.6 6.52 0 6.52 C -3.6 6.52 -6.52 3.6 -6.52 0 C -6.52 -3.6 -3.6 -6.52 0 -6.52 C 3.6 -6.52 6.52 -3.6 6.52 0 Z M 0 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{0.0pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 0 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}}\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{}{{ {}{}}}{ {}{}} {{}{{\lx@inpgf@ignorespaces}}}{{}{\lx@inpgf@ignorespaces}}{}{{}{\lx@inpgf@ignorespaces}} {\lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{-2.14583pt}{8.44687pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 -2.97 11.69)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} \lxSVG@closescope {\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}\hss}\lxSVG@discardpath\lxSVG@closescope \hss}}\lxSVG@closescope\endpgfpicture}}\;.$ |  |

The quantum circuit and graphical model of a non-diagonal one-qubit gate
are

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\lx@xy@svg{\hbox{\raise 2.5pt\hbox{\kern 0.0pt\hbox{\ignorespaces\ignorespaces\ignorespaces\hbox{\vtop{\halign{\entry@#!@&&\entry@@#!@\cr&&&&\crcr}}}\ignorespaces{\hbox{\kern 0.0pt\raise 0.0pt\hbox{\hbox{\kern-3.0pt\raise 1.25pt\hbox{\hbox{\kern 3.0pt\raise-2.5pt\hbox{$\textstyle{}$}}}}}}}{\hbox{\kern 10.00002pt\raise 0.0pt\hbox{\hbox{\kern-2.14583pt\raise 5.0pt\hbox{$\textstyle{b}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 20.00003pt\raise 0.0pt\hbox{\hbox{\kern 3.00003pt\raise-3.41666pt\hbox{$\textstyle{U}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 43.91814pt\raise 0.0pt\hbox{\hbox{\kern-3.5486pt\raise 5.0pt\hbox{$\textstyle{b^{\prime}}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 53.91815pt\raise 0.0pt\hbox{\hbox{\kern-3.0pt\raise 1.25pt\hbox{\hbox{\kern 3.0pt\raise-2.5pt\hbox{$\textstyle{\ignorespaces\ignorespaces\ignorespaces\ignorespaces}$}}}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}\ignorespaces}}}}\ignorespaces\quad\quad\Longrightarrow\quad\quad\hbox to40.81pt{\vbox to24.21pt{\pgfpicture\makeatletter\hbox{\hskip 5.47884pt\lower-4.91386pt\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@begingroup@{stroke=#000000} \lxSVG@begingroup@{fill=#000000} \lxSVG@setlinewidth{\the\pgflinewidth}\lxSVG@begingroup@{stroke-width=0.4pt} \lx@inpgf@ignorespaces\nullfont\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} {{}} {{\lx@inpgf@ignorespaces{}{}{{}}{}}}{{{}}}{{{{}}{{}}\lx@inpgf@ignorespaces}}{{}}{{{ }}}\lx@inpgf@ignorespaces\hbox{\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.52 0 C 6.52 3.6 3.6 6.52 0 6.52 C -3.6 6.52 -6.52 3.6 -6.52 0 C -6.52 -3.6 -3.6 -6.52 0 -6.52 C 3.6 -6.52 6.52 -3.6 6.52 0 Z M 0 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{0.0pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 0 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}}\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{}{{ {}{}}}{ {}{}} {{}{{\lx@inpgf@ignorespaces}}}{{}{\lx@inpgf@ignorespaces}}{}{{}{\lx@inpgf@ignorespaces}} {\lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{-2.14583pt}{8.44687pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 -2.97 11.69)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}} {{\lx@inpgf@ignorespaces{}{}{{}}{}}}{{{}}}{{{{}}{{}}\lx@inpgf@ignorespaces}}{{}}{{{ }}}\lx@inpgf@ignorespaces\hbox{\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 45.89 0 C 45.89 3.6 42.97 6.52 39.37 6.52 C 35.77 6.52 32.85 3.6 32.85 0 C 32.85 -3.6 35.77 -6.52 39.37 -6.52 C 42.97 -6.52 45.89 -3.6 45.89 0 Z M 39.37 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{28.45276pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 39.37 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}}\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{}{{ {}{}}}{ {}{}} {{}{{\lx@inpgf@ignorespaces}}}{{}{\lx@inpgf@ignorespaces}}{}{{}{\lx@inpgf@ignorespaces}} {\lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{24.90416pt}{8.44687pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 34.46 11.69)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.8 0 L 32.57 0}{fill:none} \lx@inpgf@ignorespaces \lxSVG@closescope {\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}\hss}\lxSVG@discardpath\lxSVG@closescope \hss}}\lxSVG@closescope\endpgfpicture}}\;.$ |  |

The circuit and graphical model for a two-qubit diagonal gate are

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\begin{aligned} \lx@xy@svg{\hbox{\raise 2.5pt\hbox{\kern 0.0pt\hbox{\ignorespaces\ignorespaces\ignorespaces\hbox{\vtop{\halign{\entry@#!@&&\entry@@#!@\cr&&&&\cr&&&&\cr}}}\ignorespaces{\hbox{\kern 0.0pt\raise 0.0pt\hbox{\hbox{\kern-3.0pt\raise 1.25pt\hbox{\hbox{\kern 3.0pt\raise-2.5pt\hbox{$\textstyle{}$}}}}}}}{\hbox{\kern 10.00002pt\raise 0.0pt\hbox{\hbox{\kern-2.14583pt\raise 5.0pt\hbox{$\textstyle{b}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 20.00003pt\raise 0.0pt\hbox{\hbox{\kern 5.0pt\raise 0.0pt\hbox{$\textstyle{\hphantom{U}}$}}}}}\ignorespaces\ignorespaces{\hbox{\kern 25.00003pt\raise-12.25pt\hbox{\hbox{\kern 0.0pt\raise-3.41666pt\hbox{$\textstyle{U}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 47.91808pt\raise 0.0pt\hbox{\hbox{\kern-2.14583pt\raise 5.0pt\hbox{$\textstyle{b}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 57.91809pt\raise 0.0pt\hbox{\hbox{\kern-3.0pt\raise 1.25pt\hbox{\hbox{\kern 3.0pt\raise-2.5pt\hbox{$\textstyle{\ignorespaces\ignorespaces\ignorespaces\ignorespaces}$}}}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 0.0pt\raise-24.5pt\hbox{\hbox{\kern-3.0pt\raise 1.25pt\hbox{\hbox{\kern 3.0pt\raise-2.5pt\hbox{$\textstyle{}$}}}}}}}{\hbox{\kern 10.00002pt\raise-24.5pt\hbox{\hbox{\kern-3.5486pt\raise 5.0pt\hbox{$\textstyle{b^{\prime}}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 20.00003pt\raise-24.5pt\hbox{\hbox{\kern 5.0pt\raise 0.0pt\hbox{$\textstyle{\hphantom{U}}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 47.91808pt\raise-24.5pt\hbox{\hbox{\kern-3.5486pt\raise 5.0pt\hbox{$\textstyle{b^{\prime}}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 57.91809pt\raise-24.5pt\hbox{\hbox{\kern-3.0pt\raise 1.25pt\hbox{\hbox{\kern 3.0pt\raise-2.5pt\hbox{$\textstyle{\ignorespaces\ignorespaces\ignorespaces\ignorespaces}$}}}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}\ignorespaces}}}}\ignorespaces\end{aligned}\quad\quad\Longrightarrow\quad\quad\begin{aligned} \hbox to23.79pt{\vbox to42.35pt{\pgfpicture\makeatletter\hbox{\hskip 18.87708pt\lower-21.3183pt\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@begingroup@{stroke=#000000} \lxSVG@begingroup@{fill=#000000} \lxSVG@setlinewidth{\the\pgflinewidth}\lxSVG@begingroup@{stroke-width=0.4pt} \lx@inpgf@ignorespaces\nullfont\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} {{}} {{{}}}{{{}}}{{{{}}{{}}\lx@inpgf@ignorespaces}}{{}}{{{ }}}\lx@inpgf@ignorespaces\hbox{\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.52 19.69 C 6.52 23.29 3.6 26.21 0 26.21 C -3.6 26.21 -6.52 23.29 -6.52 19.69 C -6.52 16.08 -3.6 13.16 0 13.16 C 3.6 13.16 6.52 16.08 6.52 19.69 Z M 0 19.69}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{0.0pt}{14.22638pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 0 19.69)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}}\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{}{{{}{}}}{{}{}} {{}{{\lx@inpgf@ignorespaces}}}{{}{\lx@inpgf@ignorespaces}}{}{{}{\lx@inpgf@ignorespaces}} {\lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{-12.73853pt}{10.75417pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 -17.63 14.88)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}} {{{}}}{{{}}}{{{{}}{{}}\lx@inpgf@ignorespaces}}{{}}{{{ }}}\lx@inpgf@ignorespaces\hbox{\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.52 -19.69 C 6.52 -16.08 3.6 -13.16 0 -13.16 C -3.6 -13.16 -6.52 -16.08 -6.52 -19.69 C -6.52 -23.29 -3.6 -26.21 0 -26.21 C 3.6 -26.21 6.52 -23.29 6.52 -19.69 Z M 0 -19.69}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{0.0pt}{-14.22638pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 0 -19.69)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}}\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{}{{{}{}}}{{}{}} {{}{{\lx@inpgf@ignorespaces}}}{{}{\lx@inpgf@ignorespaces}}{}{{}{\lx@inpgf@ignorespaces}} {\lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{-15.54407pt}{-17.98529pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 -21.51 -24.89)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 0 12.89 L 0 -12.89}{fill:none} \lx@inpgf@ignorespaces \lxSVG@closescope {\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}\hss}\lxSVG@discardpath\lxSVG@closescope \hss}}\lxSVG@closescope\endpgfpicture}}\;.\end{aligned}$ |  | (11) |

Finally, the corresponding quantum circle and graphical model for a two-qubit non-diagonal gate are

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\begin{aligned} \lx@xy@svg{\hbox{\raise 2.5pt\hbox{\kern 0.0pt\hbox{\ignorespaces\ignorespaces\ignorespaces\hbox{\vtop{\halign{\entry@#!@&&\entry@@#!@\cr&&&&\cr&&&&\cr}}}\ignorespaces{\hbox{\kern 0.0pt\raise 0.0pt\hbox{\hbox{\kern-3.0pt\raise 1.25pt\hbox{\hbox{\kern 3.0pt\raise-2.5pt\hbox{$\textstyle{}$}}}}}}}{\hbox{\kern 10.00002pt\raise 0.0pt\hbox{\hbox{\kern-4.38889pt\raise 6.5pt\hbox{$\textstyle{b\_{0}}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 20.00003pt\raise 0.0pt\hbox{\hbox{\kern 5.0pt\raise 0.0pt\hbox{$\textstyle{\hphantom{U}}$}}}}}\ignorespaces\ignorespaces{\hbox{\kern 25.00003pt\raise-12.25pt\hbox{\hbox{\kern 0.0pt\raise-3.41666pt\hbox{$\textstyle{U}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 47.91808pt\raise 0.0pt\hbox{\hbox{\kern-7.1666pt\raise 6.5pt\hbox{$\textstyle{\;\;b\_{0}^{\prime}}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 57.91809pt\raise 0.0pt\hbox{\hbox{\kern-3.0pt\raise 1.25pt\hbox{\hbox{\kern 3.0pt\raise-2.5pt\hbox{$\textstyle{\ignorespaces\ignorespaces\ignorespaces\ignorespaces}$}}}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 0.0pt\raise-24.5pt\hbox{\hbox{\kern-3.0pt\raise 1.25pt\hbox{\hbox{\kern 3.0pt\raise-2.5pt\hbox{$\textstyle{}$}}}}}}}{\hbox{\kern 10.00002pt\raise-24.5pt\hbox{\hbox{\kern-4.38889pt\raise 6.5pt\hbox{$\textstyle{b\_{1}}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 20.00003pt\raise-24.5pt\hbox{\hbox{\kern 5.0pt\raise 0.0pt\hbox{$\textstyle{\hphantom{U}}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 47.91808pt\raise-24.5pt\hbox{\hbox{\kern-7.1666pt\raise 6.5pt\hbox{$\textstyle{\;\;b\_{1}^{\prime}}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 57.91809pt\raise-24.5pt\hbox{\hbox{\kern-3.0pt\raise 1.25pt\hbox{\hbox{\kern 3.0pt\raise-2.5pt\hbox{$\textstyle{\ignorespaces\ignorespaces\ignorespaces\ignorespaces}$}}}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}\ignorespaces}}}}\ignorespaces\end{aligned}\quad\quad\Longrightarrow\quad\quad\begin{aligned} \hbox to69.57pt{\vbox to44.14pt{\pgfpicture\makeatletter\hbox{\hskip 20.55765pt\lower-22.0683pt\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@begingroup@{stroke=#000000} \lxSVG@begingroup@{fill=#000000} \lxSVG@setlinewidth{\the\pgflinewidth}\lxSVG@begingroup@{stroke-width=0.4pt} \lx@inpgf@ignorespaces\nullfont\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} {{}} {{{}}}{{{}}}{{{{}}{{}}\lx@inpgf@ignorespaces}}{{}}{{{ }}}\lx@inpgf@ignorespaces\hbox{\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.52 19.69 C 6.52 23.29 3.6 26.21 0 26.21 C -3.6 26.21 -6.52 23.29 -6.52 19.69 C -6.52 16.08 -3.6 13.16 0 13.16 C 3.6 13.16 6.52 16.08 6.52 19.69 Z M 0 19.69}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{0.0pt}{14.22638pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 0 19.69)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}}\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{}{{{}{}}}{{}{}} {{}{{\lx@inpgf@ignorespaces}}}{{}{\lx@inpgf@ignorespaces}}{}{{}{\lx@inpgf@ignorespaces}} {\lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{-17.22464pt}{11.50417pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 -23.83 15.92)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}} {{{}}}{{{}}}{{{{}}{{}}\lx@inpgf@ignorespaces}}{{}}{{{ }}}\lx@inpgf@ignorespaces\hbox{\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.52 -19.69 C 6.52 -16.08 3.6 -13.16 0 -13.16 C -3.6 -13.16 -6.52 -16.08 -6.52 -19.69 C -6.52 -23.29 -3.6 -26.21 0 -26.21 C 3.6 -26.21 6.52 -23.29 6.52 -19.69 Z M 0 -19.69}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{0.0pt}{-14.22638pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 0 -19.69)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}}\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{}{{{}{}}}{{}{}} {{}{{\lx@inpgf@ignorespaces}}}{{}{\lx@inpgf@ignorespaces}}{}{{}{\lx@inpgf@ignorespaces}} {\lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{-17.22464pt}{-16.9486pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 -23.83 -23.45)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}} {{{}}}{{{}}}{{{{}}{{}}\lx@inpgf@ignorespaces}}{{}}{{{ }}}\lx@inpgf@ignorespaces\hbox{\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 45.89 19.69 C 45.89 23.29 42.97 26.21 39.37 26.21 C 35.77 26.21 32.85 23.29 32.85 19.69 C 32.85 16.08 35.77 13.16 39.37 13.16 C 42.97 13.16 45.89 16.08 45.89 19.69 Z M 39.37 19.69}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{28.45276pt}{14.22638pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 39.37 19.69)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}}\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{}{{ {}{}}}{ {}{}} {{}{{\lx@inpgf@ignorespaces}}}{{}{\lx@inpgf@ignorespaces}}{}{{}{\lx@inpgf@ignorespaces}} {\lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{36.89963pt}{11.21747pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 51.06 15.52)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}} {{{}}}{{{}}}{{{{}}{{}}\lx@inpgf@ignorespaces}}{{}}{{{ }}}\lx@inpgf@ignorespaces\hbox{\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 45.89 -19.69 C 45.89 -16.08 42.97 -13.16 39.37 -13.16 C 35.77 -13.16 32.85 -16.08 32.85 -19.69 C 32.85 -23.29 35.77 -26.21 39.37 -26.21 C 42.97 -26.21 45.89 -23.29 45.89 -19.69 Z M 39.37 -19.69}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{28.45276pt}{-14.22638pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 39.37 -19.69)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}}\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{}{{ {}{}}}{ {}{}} {{}{{\lx@inpgf@ignorespaces}}}{{}{\lx@inpgf@ignorespaces}}{}{{}{\lx@inpgf@ignorespaces}} {\lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{36.89963pt}{-17.23529pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 51.06 -23.85)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 0 12.89 L 0 -12.89 M 6.8 -19.69 L 32.57 -19.69 M 39.37 -12.89 L 39.37 12.89 M 32.57 19.69 L 6.8 19.69 M 4.81 14.88 L 34.56 -14.88}{fill:none} \lx@inpgf@ignorespaces {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 4.81 -14.88 L 34.56 14.88}{fill:none} \lx@inpgf@ignorespaces \lxSVG@closescope {\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}\hss}\lxSVG@discardpath\lxSVG@closescope \hss}}\lxSVG@closescope\endpgfpicture}}\;.\end{aligned}$ |  |

As an example, consider a quantum circuit with two qubits such as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\begin{aligned} \lx@xy@svg{\hbox{\raise 2.5pt\hbox{\kern 0.0pt\hbox{\ignorespaces\ignorespaces\ignorespaces\hbox{\vtop{\halign{\entry@#!@&&\entry@@#!@\cr&&&&\cr&&&&\cr}}}\ignorespaces{\hbox{\kern 0.0pt\raise 0.0pt\hbox{\hbox{\kern-16.6667pt\raise-2.5pt\hbox{$\textstyle{\mathinner{|{0}\rangle}}$}}}}}{\hbox{\kern 2.4375pt\raise 0.0pt\hbox{\hbox{\kern 3.00003pt\raise-3.41666pt\hbox{$\textstyle{H}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 27.73682pt\raise 0.0pt\hbox{\hbox{\kern-1.27777pt\raise-2.47217pt\hbox{$\textstyle{\bullet}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 40.35556pt\raise 0.0pt\hbox{\hbox{\kern 3.00003pt\raise-3.41666pt\hbox{$\textstyle{H}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 48.91808pt\raise 0.0pt\hbox{\hbox{\kern 9.00002pt\raise-1.25pt\hbox{$\textstyle{\lx@xy@svgnested{\hbox{\raise 2.5pt\hbox{\kern 22.0pt\hbox{\ignorespaces\ignorespaces\ignorespaces\ignorespaces\hbox{\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\ignorespaces}\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\ignorespaces\ignorespaces}\ignorespaces\ignorespaces\ignorespaces{}{}\ignorespaces\ignorespaces\ignorespaces{}\ignorespaces\hbox{\hbox{\kern 0.0pt\raise 0.0pt\hbox{{{}{}{{{}{}{}{}{{{{{}}}{{{}}{{{}}{{{}}{{{}}{{{}}{{{}}{{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}}}}}}}}}}}}}{{}{}{}{}\lx@xy@spline@}{}}}}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@drawline@}}\ignorespaces{}\ignorespaces{}}}}}}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\kern 0.0pt\raise-14.49998pt\hbox{\hbox{\kern-16.6667pt\raise-2.5pt\hbox{$\textstyle{\mathinner{|{0}\rangle}}$}}}}}{\hbox{\kern 2.4375pt\raise-14.49998pt\hbox{\hbox{\kern 3.00003pt\raise-3.41666pt\hbox{$\textstyle{H}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 27.73682pt\raise-14.49998pt\hbox{\hbox{\kern-1.27777pt\raise-2.47217pt\hbox{$\textstyle{\bullet}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 40.35556pt\raise-14.49998pt\hbox{\hbox{\kern 3.00003pt\raise-3.41666pt\hbox{$\textstyle{H}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 48.91808pt\raise-14.49998pt\hbox{\hbox{\kern 9.00002pt\raise-1.25pt\hbox{$\textstyle{\lx@xy@svgnested{\hbox{\raise 2.5pt\hbox{\kern 22.0pt\hbox{\ignorespaces\ignorespaces\ignorespaces\ignorespaces\hbox{\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\ignorespaces}\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\ignorespaces\ignorespaces}\ignorespaces\ignorespaces\ignorespaces{}{}\ignorespaces\ignorespaces\ignorespaces{}\ignorespaces\hbox{\hbox{\kern 0.0pt\raise 0.0pt\hbox{{{}{}{{{}{}{}{}{{{{{}}}{{{}}{{{}}{{{}}{{{}}{{{}}{{{}}{{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}}}}}}}}}}}}}{{}{}{}{}\lx@xy@spline@}{}}}}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@drawline@}}\ignorespaces{}\ignorespaces{}}}}}}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces}}}}\ignorespaces\end{aligned}$ |  | (12) |

where the vertical line symbolizes a controlled-Z gate (which is
diagonal) and the final boxes represent a measurement.
The undirected graphical model corresponding to this circuit is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\begin{aligned} \hbox to66.73pt{\vbox to38.28pt{\pgfpicture\makeatletter\hbox{\enskip\lower-4.91386pt\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@begingroup@{stroke=#000000} \lxSVG@begingroup@{fill=#000000} \lxSVG@setlinewidth{\the\pgflinewidth}\lxSVG@begingroup@{stroke-width=0.4pt} \lx@inpgf@ignorespaces\nullfont\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.52 39.37 C 6.52 42.97 3.6 45.89 0 45.89 C -3.6 45.89 -6.52 42.97 -6.52 39.37 C -6.52 35.77 -3.6 32.85 0 32.85 C 3.6 32.85 6.52 35.77 6.52 39.37 Z M 0 39.37}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{0.0pt}{28.45276pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 0 39.37)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 45.89 39.37 C 45.89 42.97 42.97 45.89 39.37 45.89 C 35.77 45.89 32.85 42.97 32.85 39.37 C 32.85 35.77 35.77 32.85 39.37 32.85 C 42.97 32.85 45.89 35.77 45.89 39.37 Z M 39.37 39.37}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{28.45276pt}{28.45276pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 39.37 39.37)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 85.26 39.37 C 85.26 42.97 82.34 45.89 78.74 45.89 C 75.14 45.89 72.22 42.97 72.22 39.37 C 72.22 35.77 75.14 32.85 78.74 32.85 C 82.34 32.85 85.26 35.77 85.26 39.37 Z M 78.74 39.37}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{56.90552pt}{28.45276pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 78.74 39.37)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.52 0 C 6.52 3.6 3.6 6.52 0 6.52 C -3.6 6.52 -6.52 3.6 -6.52 0 C -6.52 -3.6 -3.6 -6.52 0 -6.52 C 3.6 -6.52 6.52 -3.6 6.52 0 Z M 0 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{0.0pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 0 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 45.89 0 C 45.89 3.6 42.97 6.52 39.37 6.52 C 35.77 6.52 32.85 3.6 32.85 0 C 32.85 -3.6 35.77 -6.52 39.37 -6.52 C 42.97 -6.52 45.89 -3.6 45.89 0 Z M 39.37 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{28.45276pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 39.37 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 85.26 0 C 85.26 3.6 82.34 6.52 78.74 6.52 C 75.14 6.52 72.22 3.6 72.22 0 C 72.22 -3.6 75.14 -6.52 78.74 -6.52 C 82.34 -6.52 85.26 -3.6 85.26 0 Z M 78.74 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{56.90552pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 78.74 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.8 39.37 L 32.57 39.37 M 46.17 39.37 L 71.94 39.37}{fill:none} \lx@inpgf@ignorespaces {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.8 0 L 32.57 0 M 46.17 0 L 71.94 0}{fill:none} \lx@inpgf@ignorespaces {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 39.37 6.8 L 39.37 32.57}{fill:none} \lx@inpgf@ignorespaces \lxSVG@closescope {\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}\hss}\lxSVG@discardpath\lxSVG@closescope \hss}}\lxSVG@closescope\endpgfpicture}}\;.\end{aligned}$ |  | (13) |

This example is worked out explicitly in App. [D](#A4 "Appendix D Simulation example ‣ Simulation of low-depth quantum circuits as complex undirected graphical models").

The same method can be applied to calculate the expectation value of
an operator $O$ given by $\mathinner{\langle{0}|}{\mathcal{U}}^{\dagger}O{\mathcal{U}}\mathinner{|{0}\rangle}$. For a local
operator we simplify this expression by writing the circuit unitary
${\mathcal{U}}$ in terms of gates ${\mathcal{U}}\_{\alpha}$, and canceling terms
${\mathcal{U}}\_{\alpha}^{\dagger}{\mathcal{U}}\_{\alpha}=1$ whenever possible. The operator
results in factors in an expression equivalent to
Eq. ([6](#S3.E6 "In III.2 Undirected graphical model ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")), following exactly the same
procedure. Alternatively, the expectation value of an observable can
be estimated by sampling output probabilities and using Monte Carlo
integration, see App. [C](#A3 "Appendix C Random circuit sampling with a set of probabilities ‣ Simulation of low-depth quantum circuits as complex undirected graphical models").

## IV Variable elimination algorithm

The evaluation of a sum of products of factors such as expression
([6](#S3.E6 "In III.2 Undirected graphical model ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) can be done directly by an algorithm developed in
the context of exact inference for undirected graphical models, known as the bucket elimination algorithm [[27](#bib.bib27), [41](#bib.bib41)] or the variable elimination algorithm [[28](#bib.bib28)]. In our
case, though, the factors have complex values, and it does not
correspond to a probabilistic model. The
graphical model of some circuits can also be interpreted directly as
an Ising model at imaginary
temperature [[1](#bib.bib1)], see App. [F](#A6 "Appendix F The partition function for random circuits ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"),
similar to the relation between undirected graphical models or random Markov fields and Ising models at real temperature.

The variable elimination algorithm is usually explained by first considering the case where the graphical model is one dimensional. This would correspond to the worldline of a quantum circuit with a single qubit. In this case we would have to evaluate expressions of the form

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\sum\_{b^{d\_{0}},\cdots,b^{0}}\psi\_{d\_{0}}(b^{{d\_{0}}},b^{{d\_{0}}-1})\cdots\psi\_{2}(b^{2},b^{1})\psi\_{1}(b^{1},b^{0})$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{b^{d\_{0}},b^{{d\_{0}}-1}}\psi(b^{{d\_{0}}},b^{{d\_{0}}-1})\cdots\sum\_{b^{1}}\psi\_{2}(b^{2},b^{1})\sum\_{b^{0}}\psi\_{1}(b^{1},b^{0})$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{b^{d\_{0}},b^{{d\_{0}}-1}}\psi(b^{{d\_{0}}},b^{{d\_{0}}-1})\cdots\sum\_{b^{1}}\psi\_{2}(b^{2},b^{1})\tau\_{1}(b^{1})$ |  | (14) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{b^{d\_{0}},b^{{d\_{0}}-1}}\psi(b^{{d\_{0}}},b^{{d\_{0}}-1})\cdots\sum\_{b^{2}}\psi\_{2}(b^{3},b^{2})\tau\_{2}(b^{2})$ |  | (15) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{b^{d\_{0}}}\tau\_{d\_{0}}(b^{d\_{0}})\;.$ |  |

That is, we evaluate a one dimensional undirected graphical model by
using the distributive property and eliminating variables from left to
right (or right to left). A variable is eliminated by performing the
corresponding sum and storing the corresponding factor in memory, as
in the step from Eq. ([14](#S4.E14 "In IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) to Eq. ([15](#S4.E15 "In IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")). The
same algorithm applies to trees, and is known as belief propagation in
the context of graphical models [[42](#bib.bib42)]. It is also
closely related to the Bethe Peierls iterative
method [[43](#bib.bib43)] or the cavity method in physics [[44](#bib.bib44)]. The cost of this algorithm is linear.

In more general cases we obtain factors that grow in size after eliminating a variable. For example

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\sum\_{b\_{j}}\psi(b\_{i},b\_{j})\psi(b\_{j},b\_{k})\tau(b\_{j},b\_{l})=\tau(b\_{i},b\_{k},b\_{l})\;.$ |  | (16) |

The size of a factor or tensor stored in memory is exponential in the
number of variables or indexes. The size of the factors obtained through variable elimination depends on the order of elimination. Consequently, the cost of this algorithm can vary exponentially for different variable elimination orders.

### IV.1 Vertical variable elimination ordering for low-depth circuits

For circuits with low depth and low dimension a simple strategy for
the order of variable elimination is to process one qubit at a time,
eliminating all variables in one
worldline sequentially before moving to a neighboring qubit. As an example, we consider again the
circuits of Ref. [[1](#bib.bib1)], which are defined in
a two dimensional lattice of qubits. As explained in
Sec. [III](#S3 "III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"), the mapping of a circuit output amplitude to an undirected
graphical model results in a graph defined on vertices corresponding
to Boolean classical
variables $b\_{j}^{k}$, where the index $j$
enumerates the qubits, and the superscript $k$ enumerates new
variables along the so-called worldline of a qubit $j$ in the time
direction. We assume that the qubit index $j$ is ordered so that
sequential values correspond to neighboring qubits in the underlying
two dimensional lattice. Processing the variables first along the
worldline direction, which we call the vertical ordering of variable
elimination, corresponds to eliminating variables in the
lexicographical order of the pairs $(j,k)$. That is, we eliminate all
$b\_{j}^{k}$ variables corresponding to qubit $j$ sequentially along the $k$
index before moving to the variables corresponding to qubit $j+1$.

Figure 4: Treewidth for circuits from
Ref. [[1](#bib.bib1)] with $6\times 6$, $7\times 6$, and $7\times 7$ qubits as a function of the circuit depth
using a vertical elimination ordering, one circuit instance in each case. There are small variations
between instances of the same size.

Figure [4](#S4.F4 "Figure 4 ‣ IV.1 Vertical variable elimination ordering for low-depth circuits ‣ IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models") shows the size of the maximun
tensor rank as a function of the circuit depth for an instance of each
size $6\times 6$, $6\times 7$, and $7\times 7$ using a vertical
elimination ordering. More exactly, we plot the size of the tensor
minus 1, to make it directly comparable to the standard definition of
treewidth used in Fig. [5](#S4.F5 "Figure 5 ‣ IV.2 Numerical estimation of the treewidth for some quantum circuits ‣ IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models").
There are small variations between instances of
the same size, which explains that in this particular case the
instance of size $6\times 7$ has a larger tensor size for some depths in this
ordering than the instance of size $7\times 7$.

### IV.2 Numerical estimation of the treewidth for some quantum circuits

The size of the factors obtained by variable elimination from a given ordering can be analyzed graphically. We start with the undirected graph corresponding to the original expression, where each variable corresponds to a vertex. To simulate the elimination of a variable, we add an edge between all vertices connected to the vertex (variable) being eliminated. The cliques obtained in this process correspond to factors obtained through variable elimination. The size of the largest clique is called the induced width. Note that different orderings in the vertex elimination process, which correspond to different orderings of variable elimination, can result in different cliques. The treewidth is defined as the minimum width over all variable orderings. Determining the treewidth is in general NP-complete, but heuristic algorithms, such as QuickBB [[37](#bib.bib37)], can be used to obtain an approximation.

Figure 5: Numerical upper bound for the treewidth of the undirected graphical model corresponding to circuits from Ref. [[1](#bib.bib1)] with $6\times 6$, $6\times 7$, and $7\times 7$ qubits as a function of the circuit depth.

For a circuit in a 2D lattice of qubits with two-qubit gates
restricted to nearest neighbors, as in
Ref. [[1](#bib.bib1)], the treewidth of the
corresponding undirected graphical model is proportional to
$\min(O(d\ell),O(n))$, where $\ell$ is the minimum lateral
dimension. Figure [5](#S4.F5 "Figure 5 ‣ IV.2 Numerical estimation of the treewidth for some quantum circuits ‣ IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models") shows numerical upper bounds for
the treewidth as a function of depth (see also
Ref. [[1](#bib.bib1)]). The upper bounds were obtained
by running the *QuickBB*
algorithm [[37](#bib.bib37)]. This algorithm also returns the
corresponding variable elimination order, which was used in
Fig. [2](#S2.F2 "Figure 2 ‣ II Numerical results ‣ Simulation of low-depth quantum circuits as complex undirected graphical models") and also to calculate the probabilities plotted
in Fig. [3](#S2.F3 "Figure 3 ‣ II Numerical results ‣ Simulation of low-depth quantum circuits as complex undirected graphical models").

## V Conclusion

We generalize the simulation of a quantum circuit by mapping it onto
an undirected graphical model, which we compute using the variable
elimination algorithm, developed in the context of exact
inference [[27](#bib.bib27), [39](#bib.bib39), [28](#bib.bib28)]. This is particularly convenient for circuits of
low depth [[30](#bib.bib30), [1](#bib.bib1), [31](#bib.bib31)], and with predominantly diagonal two-qubit
gates. We are able to sample the output distribution of quantum
circuits in a single workstation for cases that previously required a
supercomputer. We also show how to perform cross entropy benchmarking and
how to estimate the value of an
observable. The computation of many amplitudes is embarrassingly
parallelizable across machines. The cost of this algorithm is
exponential in $\min(O(d\ell),O(n))$ for depth $d$, minimun lateral
dimension $\ell$ and total number of qubits $n$. More optimally, the
cost is exponential in the treewidth of the graph, as estimated in
Ref. [[1](#bib.bib1)]. Follow up work will study
potential improvements to this algorithm, such as implementation in a
supercomputer and code optimization, and possible space-time
tradeoffs [[31](#bib.bib31)].

###### Acknowledgements.

We acknowledge Stephan Hoyer for conversations and suggesting the use of Dask.

## Appendix A Pseudocode

In this section we give pseudocode for the quantum circuit simulation
algorithm presented in the main text [[28](#bib.bib28)]. As seen
in Eq. ([6](#S3.E6 "In III.2 Undirected graphical model ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")), an output amplitude of a quantum circuit is expressed as a
sum of products of factors. Each factor is a complex valued function
or tensor defined in one or two Boolean
variables or indexes. The variable elimination algorithm performs the sum of
Eq. ([6](#S3.E6 "In III.2 Undirected graphical model ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) eliminating one variable at a time, see
Eq. ([16](#S4.E16 "In IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")). Larger tensors are created in the process. In
what follows we assume that all Boolean variables have been given an
appropriate order for variable elimination, see
Secs. [IV.1](#S4.SS1 "IV.1 Vertical variable elimination ordering for low-depth circuits ‣ IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models") and [IV.2](#S4.SS2 "IV.2 Numerical estimation of the treewidth for some quantum circuits ‣ IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models").

The basic objects of the computation are
tensors. Tensors are complex functions defined
on Boolean variables. Variables are associated with
vertices in the undirected graphical model as explained in
Sec. [III.2](#S3.SS2 "III.2 Undirected graphical model ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"). Tensors implement two
operations. One is a multiplication across tensors, tensor1 \* tensor2, implemented with broadcasting semantics, as in the NumPy
python library. This means that the product of tensors is done
elementwise. If an index or variable in tensor\_a is
missing in tensor\_b then, in effect, this index is added
to tensor\_b with dimension 1
(the value of tensor\_b is determined by the pre-existing indexes). The other operation,
tensor.reduce\_sum(), computes the sum of elements across the
first dimension of the tensor. For simplicity, we assume
that the indexes of all tensors are initially ordered from low to
high. This will also be an invariant of the algorithm.

The bucket elimination
algorithm [[27](#bib.bib27), [41](#bib.bib41)] keeps track of the
order of the operations involved. More explicitly, we use the bucket
elimination algorithm to build a computational graph that will be
processed by TensorFlow or Dask. A bucket is
a list of tensors. The ordered list buckets
has one bucket per variable. In this way each bucket is associated to a
variable. An invariant of the algorithm is that each tensor in a
bucket acts upon the variable associated with the
bucket, and all other variables have higher order.

First we initialize each bucket with the
tensors in Eq. ([6](#S3.E6 "In III.2 Undirected graphical model ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")), corresponding to the
gates, initialization and measurement of a circuit output amplitude:

```
for tensor in initial_factors:
  buckets[tensor.indexes[0]].append(tensor)
```

Note that this obeys the invariant given above, because of the
assumption that the variables or indexes in
each tensor are ordered from low to high.

Each bucket in the buckets list is processed
in order. Processing a bucket implements the elimination of the
variable associated with that bucket, as in Eq. ([16](#S4.E16 "In IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")). As
noted above, we assume that variables have initially been ordered with
the chosen variable elimination order. Processing the
buckets list one by one then implements the correct
order. Processing a bucket can return a tensor
without indexes, corresponding to a scalar, when all tensors in the
bucket had only one variable (this has to be the variable
associated with the bucket). Typically this only happens in the last
bucket, and this scalar corresponds to the amplitude that
we want to calculate. In some cases, for circuits of very small depth,
the circuit can be decomposed into disjoint tensors, and the
corresponding scalars are multiplied together.

```
result = None
for bucket in buckets:
  if not empty(bucket):
    tensor = bucket.process_bucket()
    if rank(tensor) > 0:
      first_index = tensor.indexes[0]
      to_bucket = buckets[first_index]
      to_bucket.append(tensor)
    else:
      if result:
        result *= tensor
      else:
        result = tensor
return result
```

The processing of a bucket consists on
two steps: first all tensors in the bucket are broadcasted together, and then the
first variable is summed over, as in Eq. ([16](#S4.E16 "In IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")). By the invariants of the algorithm, the
variable summed over is the one associated to the
bucket.

```
def process_bucket(bucket):
  result = bucket.tensors[0]
  for tensor in bucket.tensors[1:]:
    result *= tensor
  # reduce
  return result.reduce_sum()
```

## Appendix B Cross entropy benchmarking

We now review cross entropy benchmarking, a technique to estimate the fidelity of
an experimental quantum circuit
implementation using the exact probabilities amplitudes calculated by
a quantum circuit simulation algorithm [[1](#bib.bib1), [17](#bib.bib17)].

The cross-entropy between a probability distribution $p\_{A}$ and the ideal output probability $p\_{\mathcal{U}}$ is defined as
$S(p\_{A},p\_{\mathcal{U}})=-\sum\_{x}p\_{A}(x)\log p\_{\mathcal{U}}(x)$. As explained
in Ref. [[1](#bib.bib1)], the cross-entropy with an
uncorrelated distribution $p\_{\rm unc}$ averaged over quantum
circuits is almost constant, ${\rm H}\_{0}={\mathbb{E}}\_{\mathcal{U}}[S(p\_{\rm unc},p\_{U})]$. In the
following we make the averaging over circuits ${\mathcal{U}}$ implicitly.

We write the output of an experimental quantum circuit
implementation with fidelity $\alpha$ as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\rho=\alpha\,{\mathcal{U}}\mathinner{|{0}\rangle}\!\mathinner{\langle{0}|}{\mathcal{U}}^{\dagger}+(1-\alpha)\sigma\_{\mathcal{U}}\;.$ |  | (17) |

The state ${\mathcal{U}}\mathinner{|{0}\rangle}$ corresponds to the ideal output of circuit ${\mathcal{U}}$, without
any errors, while $\sigma\_{\mathcal{U}}$
represents the output of the implementation of ${\mathcal{U}}$ after any
experimental errors. The experimental output probability for a bit-string $x$ is
$p\_{\rm exp}(x)=\mathinner{\langle{x}|}\rho\mathinner{|{x}\rangle}=\alpha\,p\_{\mathcal{U}}(x)+(1-\alpha)\mathinner{\langle{x}|}\sigma\_{\mathcal{U}}\mathinner{|{x}\rangle}$. From the arguments
presented in Ref. [[1](#bib.bib1)], almost any error in a
random universal circuit of sufficient depth results in an output probability
which is uncorrelated with the ideal probability distribution, and
therefore we assume that $\mathinner{\langle{x}|}\sigma\_{\mathcal{U}}\mathinner{|{x}\rangle}$ is uncorrelated with $p\_{\mathcal{U}}(x)$.
We have

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle{\rm H}\_{0}-S(p\_{\rm exp},p\_{\mathcal{U}})$ |  | (18) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle={\rm H}\_{0}+\sum\_{j}\big(\alpha p\_{\mathcal{U}}(x\_{j})$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\quad\quad+(1-\alpha)\mathinner{\langle{x\_{j}}|}\sigma\_{\mathcal{U}}\mathinner{|{x\_{j}}\rangle}\big)\log p\_{\mathcal{U}}(x\_{j})$ |  | (19) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle={\rm H}\_{0}-\alpha{\rm H}(p\_{\mathcal{U}})-(1-\alpha){\rm H}\_{0}$ |  | (20) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\alpha({\rm H}\_{0}-{\rm H}(p\_{\mathcal{U}}))\;.$ |  | (21) |

Therefore

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\alpha={{\rm H}\_{0}-S(p\_{\rm exp},p\_{\mathcal{U}})\over{\rm H}\_{0}-{\rm H}(p\_{\mathcal{U}})}$ |  | (22) |

is an estimate of the experimental fidelity. Note that ${\rm H}\_{0}$ and
${\rm H}(p\_{\mathcal{U}})$ can be calculated numerically, see Sec. [II](#S2 "II Numerical results ‣ Simulation of low-depth quantum circuits as complex undirected graphical models") and
App. [C](#A3 "Appendix C Random circuit sampling with a set of probabilities ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"). Furthermore, for universal random circuits
in the Porter-Thomas regime we have ${\rm H}\_{0}=\log(2^{n})+\gamma$ and
${\rm H}(p\_{\mathcal{U}})=\log(2^{n})-1+\gamma$, where $\gamma$ is Euler’s
constant [[1](#bib.bib1)].

In order to estimate the fidelity $\alpha$ of an experimental
implementation, we take a large sample
$S\_{\rm exp}=\{x\_{1}^{\rm exp},\ldots,x\_{m}^{\rm exp}\}$ of bit-strings $x$ in the
computational basis ($m\sim 10^{3}-10^{6}$). From the central limit
theory we have (see App. [C](#A3 "Appendix C Random circuit sampling with a set of probabilities ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"))

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle-\frac{1}{m}\sum\_{j=1}^{m}\log p\_{U}(x\_{j}^{\rm exp})$ |  | (23) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=-\sum\_{x}p\_{\rm exp}(x)\log p\_{\mathcal{U}}(x)+O(1/\sqrt{m})$ |  | (24) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=S(p\_{\rm exp},p\_{\mathcal{U}})+O(1/\sqrt{m})\;.$ |  | (25) |

In conclusion, using the algorithm presented in the main text to
calculate the $m$ ideal output probabilities $\{p\_{\mathcal{U}}(x^{\rm exp})\}$, we can use
Eqs. ([23](#A2.E23 "In Appendix B Cross entropy benchmarking ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) and ([22](#A2.E22 "In Appendix B Cross entropy benchmarking ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) to obtain an estimate of
$\alpha$.

## Appendix C Random circuit sampling with a set of probabilities

Assume that we are asked to perform the following computational task:
sample a set of bit-strings $S$ from the output distribution
$\{p\_{\mathcal{U}}(x)\}$ defined by a quantum circuit ${\mathcal{U}}$.
In order to simulate sampling from the output distribution $\{p\_{\mathcal{U}}(x)\}$ using the
algorithm above, we start with a set $T=\{x\_{j}\}$ of bit-strings
selected uniformly at random. We denote the size of $T$ as $t$. We then calculate the probabilities $\{p\_{\mathcal{U}}(x\_{j})\}$ corresponding
to the circuit ${\mathcal{U}}$ and sample from the set $T$ according to the normalized probabilities $\tilde{p}\_{\mathcal{U}}(x\_{j})$

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\tilde{p}\_{\mathcal{U}}(x\_{j})$ | $\displaystyle={p\_{\mathcal{U}}(x\_{j})\over\sum\_{j\in T}p\_{\mathcal{U}}(x\_{j})}=\frac{2^{n}}{t}\left(1+O\left({1\over\sqrt{t}}\right)\right)p\_{\mathcal{U}}(x\_{j})\;.$ |  | (26) |

Note that by standard arguments in Monte Carlo integration, and given
that the variance of the relevant distribution for random circuits is a constant $\sim 1$ [[1](#bib.bib1)], we can approximate any function
defined over the output probabilities of the circuit using the set
$T$ up to an error $\sim 1/\sqrt{t}$.

In particular, if we take a sample $S$ of size $m$ from $T$ according
to the probabilities $\{\tilde{p}\_{\mathcal{U}}(x\_{j})\}$ we would get an estimate of
the cross entropy of this sample

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle-\frac{1}{m}\sum\_{j\in S}\log p\_{\mathcal{U}}(x\_{j})$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=-\sum\_{j\in T}\tilde{p}\_{\mathcal{U}}(x\_{j})\log p\_{\mathcal{U}}(x\_{j})+O\left(\frac{1}{\sqrt{m}}\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=-\frac{2^{n}}{t}\left(1+O\left({1\over\sqrt{t}}\right)\right)\sum\_{j\in T}p\_{\mathcal{U}}(x\_{j})\log p\_{\mathcal{U}}(x\_{j})+O\left(\frac{1}{\sqrt{m}}\right)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=H({\mathcal{U}})+O\left({1\over\sqrt{t}}\right)H({\mathcal{U}})+O\left(\frac{1}{\sqrt{m}}\right)\;,$ |  | (27) |

where $H({\mathcal{U}})$ is the entropy of the output distribution defined by
circuit ${\mathcal{U}}$.
That is, according to the cross entropy difference (see
Eq. ([22](#A2.E22 "In Appendix B Cross entropy benchmarking ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) and Ref. [[1](#bib.bib1)]), our simulation is
sampling from the ideal circuit with high fidelity, because we obtain
the correct entropy.

A more detailed calculation shows that the cross entropy obtained this
way is distributed according to

|  |  |  |  |
| --- | --- | --- | --- |
|  | $H({\mathcal{U}})-\xi\sqrt{2/t}\,H({\mathcal{U}})+\zeta\sqrt{(\pi^{2}/6-1)/m}\\ +\xi\zeta\frac{n^{2}}{\sqrt{2tm(\pi^{2}/6-1)}}\;,$ |  | (28) |

where $\xi$ and $\zeta$ and independent random variables that obey
the normal distribution $N(0,1)$.

Note that the error or order $1/\sqrt{m}$ comes
from simulating a sample of size $S$ out of the set $T$ of output
probabilities that have been calculated. This error is avoided if we
estimate an observable directly from $T$.

## Appendix D Simulation example

In this appendix we consider the specific example of the quantum
circuit

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\begin{aligned} \lx@xy@svg{\hbox{\raise 2.5pt\hbox{\kern 0.0pt\hbox{\ignorespaces\ignorespaces\ignorespaces\hbox{\vtop{\halign{\entry@#!@&&\entry@@#!@\cr&&&&\cr&&&&\cr}}}\ignorespaces{\hbox{\kern 0.0pt\raise 0.0pt\hbox{\hbox{\kern-16.6667pt\raise-2.5pt\hbox{$\textstyle{\mathinner{|{0}\rangle}}$}}}}}{\hbox{\kern 2.4375pt\raise 0.0pt\hbox{\hbox{\kern 3.00003pt\raise-3.41666pt\hbox{$\textstyle{H}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 27.73682pt\raise 0.0pt\hbox{\hbox{\kern-1.27777pt\raise-2.47217pt\hbox{$\textstyle{\bullet}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 40.35556pt\raise 0.0pt\hbox{\hbox{\kern 3.00003pt\raise-3.41666pt\hbox{$\textstyle{H}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 48.91808pt\raise 0.0pt\hbox{\hbox{\kern 9.00002pt\raise-1.25pt\hbox{$\textstyle{\lx@xy@svgnested{\hbox{\raise 2.5pt\hbox{\kern 22.0pt\hbox{\ignorespaces\ignorespaces\ignorespaces\ignorespaces\hbox{\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\ignorespaces}\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\ignorespaces\ignorespaces}\ignorespaces\ignorespaces\ignorespaces{}{}\ignorespaces\ignorespaces\ignorespaces{}\ignorespaces\hbox{\hbox{\kern 0.0pt\raise 0.0pt\hbox{{{}{}{{{}{}{}{}{{{{{}}}{{{}}{{{}}{{{}}{{{}}{{{}}{{{}}{{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}}}}}}}}}}}}}{{}{}{}{}\lx@xy@spline@}{}}}}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@drawline@}}\ignorespaces{}\ignorespaces{}}}}}}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\kern 0.0pt\raise-14.49998pt\hbox{\hbox{\kern-16.6667pt\raise-2.5pt\hbox{$\textstyle{\mathinner{|{0}\rangle}}$}}}}}{\hbox{\kern 2.4375pt\raise-14.49998pt\hbox{\hbox{\kern 3.00003pt\raise-3.41666pt\hbox{$\textstyle{H}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 27.73682pt\raise-14.49998pt\hbox{\hbox{\kern-1.27777pt\raise-2.47217pt\hbox{$\textstyle{\bullet}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 40.35556pt\raise-14.49998pt\hbox{\hbox{\kern 3.00003pt\raise-3.41666pt\hbox{$\textstyle{H}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}{\hbox{\lx@xy@droprule}}{\hbox{\kern 48.91808pt\raise-14.49998pt\hbox{\hbox{\kern 9.00002pt\raise-1.25pt\hbox{$\textstyle{\lx@xy@svgnested{\hbox{\raise 2.5pt\hbox{\kern 22.0pt\hbox{\ignorespaces\ignorespaces\ignorespaces\ignorespaces\hbox{\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\ignorespaces}\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\ignorespaces\ignorespaces}\ignorespaces\ignorespaces\ignorespaces{}{}\ignorespaces\ignorespaces\ignorespaces{}\ignorespaces\hbox{\hbox{\kern 0.0pt\raise 0.0pt\hbox{{{}{}{{{}{}{}{}{{{{{}}}{{{}}{{{}}{{{}}{{{}}{{{}}{{{}}{{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}{{}}{{}}{{{}}}}}}}}}}}}}}}{{}{}{}{}\lx@xy@spline@}{}}}}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@drawline@}}\ignorespaces{}\ignorespaces{}}}}}}$}}}}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces{\hbox{\lx@xy@droprule}}\ignorespaces\ignorespaces\ignorespaces\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces{}{\hbox{\lx@xy@droprule}}\ignorespaces}}}}\ignorespaces\end{aligned}$ |  | (29) |

We calculate the output amplitude for input $\mathinner{|{00}\rangle}$ and output
$\mathinner{|{00}\rangle}$. The corresponding graphical model is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\begin{aligned} \hbox to108.2pt{\vbox to65.52pt{\pgfpicture\makeatletter\hbox{\hskip 11.42119pt\lower-11.42119pt\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@begingroup@{stroke=#000000} \lxSVG@begingroup@{fill=#000000} \lxSVG@setlinewidth{\the\pgflinewidth}\lxSVG@begingroup@{stroke-width=0.4pt} \lx@inpgf@ignorespaces\nullfont\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 15.53 59.06 C 15.53 67.63 8.58 74.58 0 74.58 C -8.58 74.58 -15.53 67.63 -15.53 59.06 C -15.53 50.48 -8.58 43.53 0 43.53 C 8.58 43.53 15.53 50.48 15.53 59.06 Z M 0 59.06}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{-4.38889pt}{39.35913pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 -6.07 54.46)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 74.58 59.06 C 74.58 67.63 67.63 74.58 59.06 74.58 C 50.48 74.58 43.53 67.63 43.53 59.06 C 43.53 50.48 50.48 43.53 59.06 43.53 C 67.63 43.53 74.58 50.48 74.58 59.06 Z M 59.06 59.06}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{38.29025pt}{39.35913pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 52.98 54.46)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 133.64 59.06 C 133.64 67.63 126.69 74.58 118.11 74.58 C 109.53 74.58 102.58 67.63 102.58 59.06 C 102.58 50.48 109.53 43.53 118.11 43.53 C 126.69 43.53 133.64 50.48 133.64 59.06 Z M 118.11 59.06}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{80.96939pt}{39.35913pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 112.04 54.46)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 15.53 0 C 15.53 8.58 8.58 15.53 0 15.53 C -8.58 15.53 -15.53 8.58 -15.53 0 C -15.53 -8.58 -8.58 -15.53 0 -15.53 C 8.58 -15.53 15.53 -8.58 15.53 0 Z M 0 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{-4.38889pt}{-3.32pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 -6.07 -4.59)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 74.58 0 C 74.58 8.58 67.63 15.53 59.06 15.53 C 50.48 15.53 43.53 8.58 43.53 0 C 43.53 -8.58 50.48 -15.53 59.06 -15.53 C 67.63 -15.53 74.58 -8.58 74.58 0 Z M 59.06 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{38.29025pt}{-3.32pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 52.98 -4.59)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 133.64 0 C 133.64 8.58 126.69 15.53 118.11 15.53 C 109.53 15.53 102.58 8.58 102.58 0 C 102.58 -8.58 109.53 -15.53 118.11 -15.53 C 126.69 -15.53 133.64 -8.58 133.64 0 Z M 118.11 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{80.96939pt}{-3.32pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 112.04 -4.59)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 15.8 59.06 L 43.25 59.06 M 74.86 59.06 L 102.31 59.06}{fill:none} \lx@inpgf@ignorespaces {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 15.8 0 L 43.25 0 M 74.86 0 L 102.31 0}{fill:none} \lx@inpgf@ignorespaces {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 59.06 15.8 L 59.06 43.25}{fill:none} \lx@inpgf@ignorespaces \lxSVG@closescope {\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}\hss}\lxSVG@discardpath\lxSVG@closescope \hss}}\lxSVG@closescope\endpgfpicture}}\;.\end{aligned}$ |  | (30) |

Because the input and output is specified, we have $b\_{0}^{0}$ $=$ $b\_{0}^{2}$
$=$ $b\_{1}^{0}$ $=$ $b\_{1}^{2}$ $=$ 0. Then the graph can be simplified to

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\begin{aligned} \hbox to22.84pt{\vbox to65.52pt{\pgfpicture\makeatletter\hbox{\hskip-31.25795pt\lower-11.42119pt\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@begingroup@{stroke=#000000} \lxSVG@begingroup@{fill=#000000} \lxSVG@setlinewidth{\the\pgflinewidth}\lxSVG@begingroup@{stroke-width=0.4pt} \lx@inpgf@ignorespaces\nullfont\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 74.58 59.06 C 74.58 67.63 67.63 74.58 59.06 74.58 C 50.48 74.58 43.53 67.63 43.53 59.06 C 43.53 50.48 50.48 43.53 59.06 43.53 C 67.63 43.53 74.58 50.48 74.58 59.06 Z M 59.06 59.06}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{38.29025pt}{39.35913pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 52.98 54.46)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 74.58 0 C 74.58 8.58 67.63 15.53 59.06 15.53 C 50.48 15.53 43.53 8.58 43.53 0 C 43.53 -8.58 50.48 -15.53 59.06 -15.53 C 67.63 -15.53 74.58 -8.58 74.58 0 Z M 59.06 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{38.29025pt}{-3.32pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 52.98 -4.59)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 59.06 15.8 L 59.06 43.25}{fill:none} \lx@inpgf@ignorespaces \lxSVG@closescope {\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}\hss}\lxSVG@discardpath\lxSVG@closescope \hss}}\lxSVG@closescope\endpgfpicture}}\;.\end{aligned}$ |  | (31) |

The treewidth of this graph is 2, because it is a clique with two vertices.22
2
This is the same as the
treewidth of the graph in Fig. ([30](#A4.E30 "In Appendix D Simulation example ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) when first
eliminating the variables $b\_{0}^{0}$, $b\_{0}^{2}$, $b\_{1}^{0}$ and
$b\_{1}^{2}$. In the next step we can eliminate the variables $b\_{0}^{1}$
and $b\_{1}^{1}$ in any order.

More explicitly, the amplitude $\mathinner{\langle{00}|}C\mathinner{|{00}\rangle}$, where $C$ is the
circuit in Fig. ([29](#A4.E29 "In Appendix D Simulation example ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")), is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathinner{\langle{00}|}C\mathinner{|{00}\rangle}=\sum\_{b\_{0}^{1},b\_{1}^{1}}\psi\_{\rm H}(0,b\_{0}^{1})\psi\_{\rm CZ}(b\_{0}^{1},b\_{1}^{1})\psi\_{\rm H}(b\_{0}^{1},0)\\ \psi\_{\rm H}(0,b\_{1}^{1})\psi\_{\rm H}(b\_{1}^{1},0)\;.$ |  | (32) |

The function $\psi\_{\rm H}$ corresponds to a Hadamard gate and is given by
the table

|  |  |  |
| --- | --- | --- |
| 0 | 0 | $1/\sqrt{2}$ |
| 0 | 1 | $1/\sqrt{2}$ |
| 1 | 0 | $1/\sqrt{2}$ |
| 1 | 1 | $-1/\sqrt{2}$ |

The function $\psi\_{\rm CZ}$ corresponds to a controlled-Z gate and is given by
the table

|  |  |  |
| --- | --- | --- |
| 0 | 0 | $1$ |
| 0 | 1 | $1$ |
| 1 | 0 | $1$ |
| 1 | 1 | $-1$ |

We can rewrite Eq. ([32](#A4.E32 "In Appendix D Simulation example ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathinner{\langle{00}|}C\mathinner{|{00}\rangle}=\sum\_{b\_{0}^{1},b\_{1}^{1}}\tau\_{1}(b\_{0}^{1},b\_{1}^{1})$ |  | (33) |

where the table for the function $\tau\_{1}$ is

|  |  |  |
| --- | --- | --- |
| 0 | 0 | $1/4$ |
| 0 | 1 | $1/4$ |
| 1 | 0 | $1/4$ |
| 1 | 1 | $-1/4$ |

If we now sum over the variable $b\_{1}^{1}$ we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathinner{\langle{00}|}C\mathinner{|{00}\rangle}=\sum\_{b\_{0}^{1}}\tau\_{2}(b\_{0}^{1})$ |  | (34) |

where the function $\tau\_{2}$ is

|  |  |
| --- | --- |
| 0 | $1/2$ |
| 1 | 0 |

Finally, summing $b\_{0}^{1}$ we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathinner{\langle{00}|}C\mathinner{|{00}\rangle}=1/2\;.$ |  | (35) |

## Appendix E Relation to tensor network contraction

Variable elimination on the undirected graph representing a quantum circuit is related to the simulation of a quantum circuit by contracting tensor networks [[30](#bib.bib30)].
In a tensor network graphical representation, gates correspond to vertices (tensors) and qubits connecting gates (indexes in the tensors) are represented by edges. Therefore, a two-qubit gate is represented as a node with four edges, two for input and two for output. For instance, the tensor network corresponding to the example of Eq. ([12](#S3.E12 "In III.2 Undirected graphical model ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\hbox to123.64pt{\vbox to38.28pt{\pgfpicture\makeatletter\hbox{\enskip\lower-4.91386pt\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@begingroup@{stroke=#000000} \lxSVG@begingroup@{fill=#000000} \lxSVG@setlinewidth{\the\pgflinewidth}\lxSVG@begingroup@{stroke-width=0.4pt} \lx@inpgf@ignorespaces\nullfont\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.52 39.37 C 6.52 42.97 3.6 45.89 0 45.89 C -3.6 45.89 -6.52 42.97 -6.52 39.37 C -6.52 35.77 -3.6 32.85 0 32.85 C 3.6 32.85 6.52 35.77 6.52 39.37 Z M 0 39.37}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{0.0pt}{28.45276pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 0 39.37)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 45.89 39.37 C 45.89 42.97 42.97 45.89 39.37 45.89 C 35.77 45.89 32.85 42.97 32.85 39.37 C 32.85 35.77 35.77 32.85 39.37 32.85 C 42.97 32.85 45.89 35.77 45.89 39.37 Z M 39.37 39.37}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{28.45276pt}{28.45276pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 39.37 39.37)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.52 0 C 6.52 3.6 3.6 6.52 0 6.52 C -3.6 6.52 -6.52 3.6 -6.52 0 C -6.52 -3.6 -3.6 -6.52 0 -6.52 C 3.6 -6.52 6.52 -3.6 6.52 0 Z M 0 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{0.0pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 0 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 45.89 0 C 45.89 3.6 42.97 6.52 39.37 6.52 C 35.77 6.52 32.85 3.6 32.85 0 C 32.85 -3.6 35.77 -6.52 39.37 -6.52 C 42.97 -6.52 45.89 -3.6 45.89 0 Z M 39.37 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{28.45276pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 39.37 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 85.26 19.69 C 85.26 23.29 82.34 26.21 78.74 26.21 C 75.14 26.21 72.22 23.29 72.22 19.69 C 72.22 16.08 75.14 13.16 78.74 13.16 C 82.34 13.16 85.26 16.08 85.26 19.69 Z M 78.74 19.69}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{56.90552pt}{14.22638pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 78.74 19.69)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 124.63 39.37 C 124.63 42.97 121.71 45.89 118.11 45.89 C 114.51 45.89 111.59 42.97 111.59 39.37 C 111.59 35.77 114.51 32.85 118.11 32.85 C 121.71 32.85 124.63 35.77 124.63 39.37 Z M 118.11 39.37}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{85.35828pt}{28.45276pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 118.11 39.37)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 124.63 0 C 124.63 3.6 121.71 6.52 118.11 6.52 C 114.51 6.52 111.59 3.6 111.59 0 C 111.59 -3.6 114.51 -6.52 118.11 -6.52 C 121.71 -6.52 124.63 -3.6 124.63 0 Z M 118.11 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{85.35828pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 118.11 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 164 39.37 C 164 42.97 161.08 45.89 157.48 45.89 C 153.88 45.89 150.96 42.97 150.96 39.37 C 150.96 35.77 153.88 32.85 157.48 32.85 C 161.08 32.85 164 35.77 164 39.37 Z M 157.48 39.37}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{113.81104pt}{28.45276pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 157.48 39.37)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 164 0 C 164 3.6 161.08 6.52 157.48 6.52 C 153.88 6.52 150.96 3.6 150.96 0 C 150.96 -3.6 153.88 -6.52 157.48 -6.52 C 161.08 -6.52 164 -3.6 164 0 Z M 157.48 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{113.81104pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 157.48 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.8 39.37 L 32.57 39.37}{fill:none} \lx@inpgf@ignorespaces {{}}{} {\lx@inpgf@ignorespaces{}{}{{}}{}}{\lx@inpgf@ignorespaces{}{}{{}}{}}{{}{}\lx@inpgf@ignorespaces}{{}} {\lx@inpgf@ignorespaces{}{}{{}}{}}{{{}}{{}}}{{}}{\lx@inpgf@ignorespaces{}{}{{}}{}}{{{}}{{}}}{{}}{}{{}}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{{{{{{}}{}{}{}{}{{}}}}}{}{}{}{}}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 75.34 13.8 C 69.04 2.88 58.77 0 46.17 0}{fill:none} \lx@inpgf@ignorespaces {{}}{} {\lx@inpgf@ignorespaces{}{}{{}}{}}{\lx@inpgf@ignorespaces{}{}{{}}{}}{{}{}\lx@inpgf@ignorespaces}{{}} {\lx@inpgf@ignorespaces{}{}{{}}{}}{{{}}{{}}}{{}}{\lx@inpgf@ignorespaces{}{}{{}}{}}{{{}}{{}}}{{}}{}{{}}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{{{{{{}}{}{}{}{}{{}}}}}{}{}{}{}}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 74.84 25.25 C 67.67 35.49 58.66 39.37 46.17 39.37}{fill:none} \lx@inpgf@ignorespaces {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.8 0 L 32.57 0}{fill:none} \lx@inpgf@ignorespaces {{}}{} {\lx@inpgf@ignorespaces{}{}{{}}{}}{\lx@inpgf@ignorespaces{}{}{{}}{}}{{}{}\lx@inpgf@ignorespaces}{{}} {\lx@inpgf@ignorespaces{}{}{{}}{}}{{{}}{{}}}{{}}{\lx@inpgf@ignorespaces{}{}{{}}{}}{{{}}{{}}}{{}}{}{{}}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{{{{{{}}{}{}{}{}{{}}}}}{}{}{}{}}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 83.11 24.89 C 91.08 34.39 98.91 39.37 111.31 39.37}{fill:none} \lx@inpgf@ignorespaces {{}}{} {\lx@inpgf@ignorespaces{}{}{{}}{}}{\lx@inpgf@ignorespaces{}{}{{}}{}}{{}{}\lx@inpgf@ignorespaces}{{}} {\lx@inpgf@ignorespaces{}{}{{}}{}}{{{}}{{}}}{{}}{\lx@inpgf@ignorespaces{}{}{{}}{}}{{{}}{{}}}{{}}{}{{}}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{{{{{{}}{}{}{}{}{{}}}}}{}{}{}{}}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 83.55 14.88 C 92.25 6.17 99 0 111.31 0}{fill:none} \lx@inpgf@ignorespaces {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 124.91 39.37 L 150.68 39.37}{fill:none} \lx@inpgf@ignorespaces {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 124.91 0 L 150.68 0}{fill:none} \lx@inpgf@ignorespaces \lxSVG@closescope {\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}\hss}\lxSVG@discardpath\lxSVG@closescope \hss}}\lxSVG@closescope\endpgfpicture}}\;.$ |  | (36) |

The operation of contracting a network of tensors is analogous to the variable elimination in Sec. [IV](#S4 "IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"). The indexes in common are summed over or contracted, and the size of the resulting tensor in memory is exponential in the number of remaining indices. Graphically, the contraction of two tensors is represented by eliminating the edges (indexes) that the corresponding two vertices (tensors) have in common, and replacing both vertices with a single vertex with the remaining edges (indexes). As in variable elimination, the cost also depends in the order in which indexes are eliminated.

Reference [[30](#bib.bib30)] relates the minimum cost of the tensor contraction to the treewidth of the corresponding line graph. The line graph $G^{\prime}$ corresponding to the graph $G$ representing the tensor network is defined with a vertex for every edge in $G$. If two edges are incident in the same vertex (tensor) in $G$, then we add an edge in $G^{\prime}$ between the corresponding two vertices of $G^{\prime}$. In this way a two-qubit gate (a tensor with four indexes) results in a clique between four vertices in the line graph. For instance, the line graph corresponding to the tensor network in ([36](#A5.E36 "In Appendix E Relation to tensor network contraction ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\hbox to95.19pt{\vbox to38.28pt{\pgfpicture\makeatletter\hbox{\enskip\lower-4.91386pt\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@begingroup@{stroke=#000000} \lxSVG@begingroup@{fill=#000000} \lxSVG@setlinewidth{\the\pgflinewidth}\lxSVG@begingroup@{stroke-width=0.4pt} \lx@inpgf@ignorespaces\nullfont\hbox to0.0pt{\lxSVG@begingroup@{\_scopebegin=1} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.52 39.37 C 6.52 42.97 3.6 45.89 0 45.89 C -3.6 45.89 -6.52 42.97 -6.52 39.37 C -6.52 35.77 -3.6 32.85 0 32.85 C 3.6 32.85 6.52 35.77 6.52 39.37 Z M 0 39.37}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{0.0pt}{28.45276pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 0 39.37)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 124.63 0 C 124.63 3.6 121.71 6.52 118.11 6.52 C 114.51 6.52 111.59 3.6 111.59 0 C 111.59 -3.6 114.51 -6.52 118.11 -6.52 C 121.71 -6.52 124.63 -3.6 124.63 0 Z M 118.11 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{85.35828pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 118.11 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.52 0 C 6.52 3.6 3.6 6.52 0 6.52 C -3.6 6.52 -6.52 3.6 -6.52 0 C -6.52 -3.6 -3.6 -6.52 0 -6.52 C 3.6 -6.52 6.52 -3.6 6.52 0 Z M 0 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{0.0pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 0 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 45.89 0 C 45.89 3.6 42.97 6.52 39.37 6.52 C 35.77 6.52 32.85 3.6 32.85 0 C 32.85 -3.6 35.77 -6.52 39.37 -6.52 C 42.97 -6.52 45.89 -3.6 45.89 0 Z M 39.37 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{28.45276pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 39.37 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 45.89 39.37 C 45.89 42.97 42.97 45.89 39.37 45.89 C 35.77 45.89 32.85 42.97 32.85 39.37 C 32.85 35.77 35.77 32.85 39.37 32.85 C 42.97 32.85 45.89 35.77 45.89 39.37 Z M 39.37 39.37}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{28.45276pt}{28.45276pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 39.37 39.37)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 85.26 39.37 C 85.26 42.97 82.34 45.89 78.74 45.89 C 75.14 45.89 72.22 42.97 72.22 39.37 C 72.22 35.77 75.14 32.85 78.74 32.85 C 82.34 32.85 85.26 35.77 85.26 39.37 Z M 78.74 39.37}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{56.90552pt}{28.45276pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 78.74 39.37)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 85.26 0 C 85.26 3.6 82.34 6.52 78.74 6.52 C 75.14 6.52 72.22 3.6 72.22 0 C 72.22 -3.6 75.14 -6.52 78.74 -6.52 C 82.34 -6.52 85.26 -3.6 85.26 0 Z M 78.74 0}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{56.90552pt}{0.0pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 78.74 0)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}\lx@inpgf@ignorespaces\hbox{\hbox{{\lxSVG@begingroup@{\_scopebegin=1} {{}{{{}}}{{}}{}{}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{}{}{}{}{}{{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 124.63 39.37 C 124.63 42.97 121.71 45.89 118.11 45.89 C 114.51 45.89 111.59 42.97 111.59 39.37 C 111.59 35.77 114.51 32.85 118.11 32.85 C 121.71 32.85 124.63 35.77 124.63 39.37 Z M 118.11 39.37}{fill:none} \lx@inpgf@ignorespaces }{{{{\lx@inpgf@ignorespaces}}\lxSVG@begingroup@{\_scopebegin=1} \lxSVG@transformcm{1.0}{0.0}{0.0}{1.0}{85.35828pt}{28.45276pt}\lxSVG@begingroup@{transform=matrix(1.0 0.0 0.0 1.0 118.11 39.37)} \pgfsys@hbox{68}\lxSVG@closescope }}} \lxSVG@closescope }}} {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.8 0 L 32.57 0 M 46.17 0 L 71.94 0}{fill:none} \lx@inpgf@ignorespaces {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 39.37 6.8 L 39.37 32.57 M 46.17 39.37 L 71.94 39.37 M 85.54 39.37 L 111.31 39.37}{fill:none} \lx@inpgf@ignorespaces {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 78.74 6.8 L 78.74 32.57 M 73.93 34.56 L 44.18 4.81}{fill:none} \lx@inpgf@ignorespaces {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 73.93 4.81 L 44.18 34.56}{fill:none} \lx@inpgf@ignorespaces {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 6.8 39.37 L 32.57 39.37}{fill:none} \lx@inpgf@ignorespaces {{}}{}{{}} {{{{{}}{}{}{}{}{{}}}}}{}{{{{{}}{}{}{}{}{{}}}}}{{}}{}{}{}{}\lxSVG@stroke\lxSVG@drawpath@unclipped{M 85.54 0 L 111.31 0}{fill:none} \lx@inpgf@ignorespaces \lxSVG@closescope {\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}{\lx@inpgf@ignorespaces}\hss}\lxSVG@discardpath\lxSVG@closescope \hss}}\lxSVG@closescope\endpgfpicture}}\;.$ |  | (37) |

It follows that the line graph of the tensor network for a quantum
circuit is analogous to the undirected graphical model detailed
above. The main difference is that diagonal two-qubit (and
single-qubit) gates are treated more efficiently in the undirected
graphical model obtained directly from the quantum circuit factor
representation. In the line graph obtained from a tensor network a
diagonal gate results in a clique with four vertices, but in the
original graphical model is represented only by an edge and does not
introduce new vertices. This can be seen comparing the examples in Fig. [30](#A4.E30 "In Appendix D Simulation example ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"), with treewidth 2, and ([37](#A5.E37 "In Appendix E Relation to tensor network contraction ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")), which has treewidth 4. Because the cost is exponential in the treewidth, this optimization results in a smaller exponent for the computation.

Figure 6: Numerical upper bound for the treewidth of the line graph which gives the tensor contraction complexity [[30](#bib.bib30)] of circuits from Ref. [[1](#bib.bib1)] with $6\times 6$, $6\times 7$, and $7\times 7$ qubits as a function of the circuit depth.

Figure [6](#A5.F6 "Figure 6 ‣ Appendix E Relation to tensor network contraction ‣ Simulation of low-depth quantum circuits as complex undirected graphical models") shows numerical upper bounds for the treewidth of the line graph as a function of depth for the circuits in Ref. [[1](#bib.bib1)]. The upper bounds were also obtained by running the *QuickBB* algorithm [[37](#bib.bib37)]. Now that the treewidth has been reduced by almost a factor of two in the undirected graphical model which is drawn directly from the quantum circuit, Fig. [5](#S4.F5 "Figure 5 ‣ IV.2 Numerical estimation of the treewidth for some quantum circuits ‣ IV Variable elimination algorithm ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"), instead of using the line graph of the tensor network, Fig. [6](#A5.F6 "Figure 6 ‣ Appendix E Relation to tensor network contraction ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"). This is due to the fact that in these circuits all two-qubit gates are controlled-Z gates.

## Appendix F The partition function for random circuits

We review the direct mapping of random circuits to a partition
function of an Ising model at imaginary temperature from
Ref. [[1](#bib.bib1)]. Previous algorithms for mapping
universal quantum circuits to partition functions of complex Ising
models use polynomial reductions to a universal gate
set [[45](#bib.bib45), [46](#bib.bib46), [47](#bib.bib47)],
which make them less efficient.

We encode each individual Feynman path by the set of $L$ binary
variables or spins $s=\{s\_{j}^{k}\}$ with $j\in[1\mathrel{{.}\,{.}}\penalty n]$, $k\in[0\mathrel{{.}\,{.}}\penalty d\_{j}]$ and $s\_{j}^{k}\in\{1,-1\}$. One can easily see from the explicit form of the
non-diagonal gates in our example that the absolute values of the probability amplitudes associated with different paths are all the same and equal to $2^{-L/2}$. Using this fact we write the path integral ([1](#S3.E1 "In III.1 Feynman path method ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) in the following form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\langle x|{\mathcal{U}}|0\ldots 0\rangle=2^{-L/2}\sum\_{s}{\rm exp}\left(\frac{i\pi}{4}H\_{s}(x)\right)\;.$ |  | (38) |

Here ${\rm exp}(i\pi H\_{s}(x)/4)$ is a phase factor associated with each path that depends explicitly on the end-point condition ([2](#S3.E2 "In III.1 Feynman path method ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")).

The value of the phase $\pi H\_{s}/4$ is accumulated as a sum of discrete phase changes that are associated with individual gates. For the $k$-th non-diagonal gate applied to qubit $j$ we introduce the coefficient $\alpha\_{j}^{k}$ such that $\alpha\_{j}^{k}=1$ if the gate is ${\rm X}^{1/2}$ and $\alpha\_{j}^{k}=0$ if the gate is ${\rm Y}^{1/2}$.
Thus, the total phase change accumulated from the application of ${\rm X}^{1/2}$ and ${\rm Y}^{1/2}$ gates equals

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\hskip-7.22743pt\frac{i\pi}{4}H\_{s}^{{\rm X}^{1/2}}(x)$ | $\displaystyle=\frac{i\pi}{2}\sum\_{j=1}^{n}\sum\_{k=0}^{d\_{j}}\alpha\_{j}^{k}\frac{1+s\_{j}^{k-1}s\_{j}^{k}}{2}\;,$ |  | (39) |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\frac{i\pi}{4}H\_{s}^{{\rm Y}^{1/2}}(x)$ | $\displaystyle=i\pi\sum\_{j=1}^{n}\sum\_{k=0}^{d\_{j}}(1-\alpha\_{j}^{k})\frac{1-s\_{j}^{k-1}}{2}\frac{1+s\_{j}^{k}}{2}\;\;.$ |  |

As mentioned above, the dependence on $x$ arises due to the boundary condition ([2](#S3.E2 "In III.1 Feynman path method ‣ III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")). Note that we have omitted constant phase terms that do not depend on the path $s$.

We now describe the phase change from the action of gates ${\rm T}$ and ${\rm CZ}$. We introduce coefficients $d(j,t)$ equal to the number of non-diagonal gates applied to qubit $j$ over the first $t$ cycles (including the $0$-th cycle of Hadamard gates). We also introduce coefficients $\tau\_{j}^{t}$ such that $\tau\_{j}^{t}=1$ if a ${\rm T}$ gate is applied at cycle $t$ to qubit $j$ and $\tau\_{j}^{t}=0$ otherwise.
Then the total phase accumulated from the action of the ${\rm T}$ gates equals

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\frac{i\pi}{4}H\_{s}^{T}(x)=\frac{i\pi}{4}\sum\_{j=1}^{n}\sum\_{t=0}^{d}\tau\_{j}^{t}\frac{1-s\_{j}^{d(j,t)}}{2}\;.$ |  | (40) |

For a given pair of qubits $(i,j)$, we introduce coefficients $z\_{ij}^{t}$ such that $z\_{ij}^{t}=1$ if a ${\rm CZ}$ gate is applied to the qubit pair during cycle $t$ and $z\_{ij}^{t}=0$ otherwise.
The total phase accumulated from the action of the ${\rm CZ}$ gates equals

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{i\pi}{4}H\_{s}^{{\rm CZ}}(x)\\ =i\pi\sum\_{i=1}^{n}\sum\_{j=1}^{i-1}\sum\_{t=0}^{d}z\_{ij}^{t}\frac{1-s\_{i}^{d(i,t)}}{2}\frac{1-s\_{j}^{d(j,t)}}{2}.$ |  | (41) |

One can see from comparing ([38](#A6.E38 "In Appendix F The partition function for random circuits ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) with ([39](#A6.E39 "In Appendix F The partition function for random circuits ‣ Simulation of low-depth quantum circuits as complex undirected graphical models"))-([41](#A6.E41 "In Appendix F The partition function for random circuits ‣ Simulation of low-depth quantum circuits as complex undirected graphical models")) that the wavefunction amplitudes $\langle x|U|0\ldots 0\rangle$ take the form of a partition function of a classical Ising model
with energy $H\_{s}$ for a state $s$ and purely imaginary inverse
temperature $i\pi/4$. The total phase for each path takes 8 distinct
values (mod 2$\pi$) equal to $[0,\pi/4\mathrel{{.}\,{.}}\penalty 7\pi/4]$. The
interaction graph of this Ising model is the undirected graphical
model introduced in Sec. [III](#S3 "III Circuit simulation as an undirected graphical model ‣ Simulation of low-depth quantum circuits as complex undirected graphical models").

Note that if a quantum circuit uses only Clifford gates (not ${\rm T}$ gates), the total phase for each spin configuration in the partition function (mod 2$\pi$) is restricted to $[0,\pi/2,\pi,3\pi/2]$. In these case, the corresponding partition function can be calculated efficiently in polynomial time [[48](#bib.bib48), [49](#bib.bib49), [50](#bib.bib50)].
