<!-- fulltext source=arxiv_html slug=arXiv-1603.05579 fetched=2026-09-18T06:54:59+00:00 -->

# Convergence of a Newton algorithm for semi-discrete optimal transport

Jun Kitagawa
Address: Department of Mathematics, Michigan State University
Email address: [kitagawa@math.msu.edu](mailto:kitagawa@math.msu.edu)
, 
Quentin Mérigot
Address: Laboratoire de Mathématiques d’Orsay, Univ. Paris-Sud, CNRS,
Université Paris-Saclay, 91405 Orsay, France
Email address: [quentin.merigot@math.u-psud.fr](mailto:quentin.merigot@math.u-psud.fr)
 and 
Boris Thibert
Address: Laboratoire Jean Kuntzmann, Université Grenoble-Alpes
Email address: [boris.thibert@univ-grenoble-alpes.fr](mailto:boris.thibert@univ-grenoble-alpes.fr)

###### Abstract.

A popular way to solve optimal transport problems numerically
is to assume that the source probability measure is absolutely
continuous while the target measure is finitely supported. We
introduce a damped Newton’s algorithm in this setting, which is
experimentally efficient, and we establish its global linear
convergence for cost functions satisfying an assumption that appears
in the regularity theory for optimal transport.

## 1. Introduction

Some problems in geometric optics or convex geometry can be recast as
optimal transport problems between probability measures: this includes
the far-field reflector antenna problem, Alexandrov’s Gaussian
curvature prescription problem, etc. A popular way to solve these
problems numerically is to assume that the source probability measure
is absolutely continuous while the target measure is finitely
supported. We refer to this setting as semi-discrete optimal
transport. Among the several algorithms proposed to solve
semi-discrete optimal transport problems, one currently needs to
choose between algorithms that are slow but come with a convergence
speed analysis
[[29](#bib.bib29), [8](#bib.bib8), [21](#bib.bib21)]
or algorithms that are much faster in practice but which come with no
convergence guarantees
[[5](#bib.bib5), [27](#bib.bib27), [11](#bib.bib11), [22](#bib.bib22), [10](#bib.bib10)].
Algorithms of the first kind rely on coordinate-wise increments and
the number of iterations required to reach the solution up to an error
of $\varepsilon$ is of order $N^{3}/\varepsilon$, where $N$ is the number of Dirac
masses in the target measure. On the other hand, algorithms of the
second kind typically rely on the formulation of the semi-discrete
optimal transport problem as an unconstrained convex optimization
problem which is solved using a Newton or quasi-Newton method.

The purpose of this article is to bridge this gap between theory and
practice by introducing a damped Newton’s algorithm which is
experimentally efficient and by proving the global convergence of this
algorithm with optimal rates. The main assumptions is that the cost
function satisfies a condition that appears in the regularity theory
for optimal transport (the Ma-Trudinger-Wang condition) and that
the support of the source density is connected in a quantitative way
(it must satisfy a weighted Poincaré-Wirtinger inequality). In
§[1.7](#S1.SS7 "1.7. Convergence result ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), we compare this algorithm and the
convergence theorem to previous computational approaches to optimal
transport.

### 1.1. Semi-discrete optimal transport

The source space is an open domain $\Omega$ of a $d$-dimensional
Riemannian manifold, which we endow with the measure $\mathcal{H}\_{g}^{d}$ induced
by the Riemannian metric $g$ on the manifold. The target space is
an (abstract) finite set $Y$. We are given a cost function $c$ on the
product space $\Omega\times Y$, or equivalently a collection
$(c(\cdot,y))\_{y\in Y}$ of functions on $\Omega$. We assume that the
functions $c(\cdot,y)$ are of class $\mathcal{C}^{1,1}$ on $\Omega$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\forall y\in Y,~~c(\cdot,y)\in\mathcal{C}^{1,1}(\Omega).$ |  | (Reg) |

Here $\mathcal{C}^{n,\alpha}(\Omega)$ denotes the class of functions which are $n$-times differentiable and whose $n$-th derivatives are $\alpha$-Hölder continuous. In particular, $\mathcal{C}^{0,\alpha}$ is the space of $\alpha$-Hölder continuous functions.
We consider a compact subset $X$ of $\Omega$ and $\rho$ a probability
density on $X$, i.e. such that $\rho\mathrm{d}\mathcal{H}^{d}$ is a probability
measure. By an abuse of notation, we will often conflate the density $\rho$ with the measure $\rho\mathrm{d}\mathcal{H}^{d}$ itself.
Note that the support of $\rho$ is contained in $X$, but we
do not assume that it is actually equal to $X$. The push-forward of
$\rho$ by a measurable map $T:X\to Y$ is the finitely supported
measure $T\_{\#}\rho=\sum\_{y\in Y}\rho(T^{-1}(y))\delta\_{y}$. The map
$T$ is called a *transport map* between $\rho$ and a probability
measure $\mu$ on $Y$ if $T\_{\#}\rho=\mu$. The *semi-discrete
optimal transport problem* consists in minimizing the transport cost
over all transport maps between $\rho$ and $\mu$, that is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\min\left\{\int\_{X}c(x,T(x))\rho(x)\mathrm{d}\mathcal{H}\_{g}^{d}(x)\mid T:X\to Y\hbox{ s.t. }T\_{\#}\rho=\mu\right\}.$ |  | (M) |

This problem is an instance of Monge’s optimal transport problem,
where the target measure is finitely supported.
Kantorovich proposed a relaxed version of the problem ([M](#S1.Ex2 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) as
an infinite dimensional linear programming problem over the space of
probability measures with marginals $\rho$ and $\mu$.

### 1.2. Laguerre tessellation and economic interpretation

Figure 1. (Left) The domain $X$ (with boundary in blue) is
endowed with a probability density pictured in grayscale
representing the density of population in a city. The set $Y$
(in red) represents the location of bakeries. Here,
$X,Y\subseteq\mathbb{R}^{2}$ and $c(x,y)=|x-y|^{2}$ (Middle) The
Voronoi tessellation induced by the bakeries (Right) The
Laguerre tessellation: the price of bread the bakery near the
center of $X$ is higher than at the other bakeries,
effectively shrinking its Laguerre cell.

In the semi-discrete setting, the dual of Kantorovich’s relaxation can
be conveniently phrased using the notion of Laguerre tessellation. We
start with an economic metaphor. Assume that the probability density
$\rho$ describes the population distribution over a large city $X$, and that the
finite set $Y$ describes the location of bakeries in the
city. Customers living at a location $x$ in $X$ try to minimize the
walking cost $c(x,y)$, resulting in a decomposition of the space called a
Voronoi tessellation. The number of customers received by a bakery $y\in Y$
is equal to the integral of $\rho$ over its Voronoi cell, namely

|  |  |  |
| --- | --- | --- |
|  | $\Vor\_{y}:=\{x\in\Omega\mid\forall z\in Y,c(x,y)\leqslant c(x,z)\}.$ |  |

If the price of bread is given by a function
$\psi:Y\to\mathbb{R}$, customers living at location $x$ in $X$ make a
compromise between walking cost and price by minimizing the sum
$c(x,y)+\psi(y)$. This leads to the notion of Laguerre tessellation,
whose cells are given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Lag\_{y}(\psi):=\{x\in\Omega\mid\forall z\in Y,c(x,y)+\psi(y)\leqslant c(x,z)+\psi(z)\}.$ |  | (1.1) |

When the sets $X$ and $Y$ are contained in $\mathbb{R}^{d}$ and the cost is the squared
Euclidean distance, the computation of the Laguerre tessellation is a
classical problem of computational geometry, for which there exists
very efficient softwares, such as CGAL [[1](#bib.bib1)] or Geogram [[2](#bib.bib2)]. For other cost functions, one has to adapt the algorithms, as was done for the reflector cost on the sphere in [[10](#bib.bib10)]. The shape of the Voronoi and Laguerre tessellations
is depicted in Figure [1](#S1.F1 "Figure 1 ‣ 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

We want the Laguerre cells to form a partition of $\Omega$ up to a
negligible set. By the implicit function theorem, this will be the
case if the following *twist condition* holds,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\forall x\in X,~~y\in Y\mapsto D\_{x}c(x,y)\in T^{\*}\_{x}\Omega\hbox{ is injective,}$ |  | (Twist) |

where $D\_{x}$ denotes differentiation with respect to the first variable. The twist condition implies that for any prices
$\psi$ on $Y$, the transport map induced by the Laguerre tessellation

|  |  |  |  |
| --- | --- | --- | --- |
|  | $T\_{\psi}(x):=\arg\min\_{y\in Y}(c(x,y)+\psi(y)),$ |  | (1.2) |

is uniquely defined almost everywhere. It is easy to see (see
Proposition [2.2](#S2.Thmtheorem2 "Proposition 2.2. ‣ 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), that for any function $\psi$ on $Y$, the
map $T\_{\psi}$ is an optimal transport map between $\rho$ and the
pushforward measure $T\_{\psi\#}\rho=\sum\_{y\in Y}\rho(\Lag\_{y}(\psi))\delta\_{y}.$

### 1.3. Kantorovich’s functional

The map $T\_{\psi}$ is an optimal transport map
between $\rho$ and $T\_{\psi\#}\rho$. Conversely, Theorem [1.1](#S1.Thmtheorem1 "Theorem 1.1. ‣ 1.3. Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") below ensures that any
semi-discrete optimal transport problem admits such a solution. In
other words, for any probability density $\rho$ on $X$ and any probability measures $\mu$ on $Y$ there exists a
function (price) $\psi$ on $Y$ such that $T\_{\psi\#}\rho=\nu$. The
proof of this theorem is an easy generalization of the proof given in
[[5](#bib.bib5)] for the quadratic cost, but it is
nonetheless included in Section [2](#S2 "2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") for the sake of
completeness.

Here and after, we denote $(\mathbbold{1}\_{y})\_{y\in Y}$ the canonical basis of
$\mathbb{R}^{Y}$, and $\left\|\cdot\right\|$ the Euclidean norm induced by this basis, while $\left\|\cdot\right\|\_{g}$ will denote the norm induced by the Riemannian metric $g$ on either $T\_{x}\Omega$ or $T^{\*}\_{x}\Omega$ (which will be clear from context). We
will, slightly abusively, consider the space of probability measures
$\mathcal{P}(Y)$ as a subset of $\mathbb{R}^{Y}$.

###### Theorem 1.1.

Assume ([Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), let $\rho$ be a bounded probability
density on $X$ and $\nu=\sum\_{y\in Y}\nu\_{y}\mathbbold{1}\_{y}$ in
$\mathcal{P}(Y)$. Then, the functional $\Phi$

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Phi(\psi)$ | $\displaystyle:=\int\_{X}(\min\_{y\in Y}c(x,y)+\psi(y))\rho(x)\mathrm{d}\mathcal{H}\_{g}^{d}(x)-\sum\_{y\in Y}\psi(y)\nu\_{y}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{y\in Y}\int\_{\Lag\_{y}(\psi)}(c(x,y)+\psi(y))\rho(x)\mathrm{d}\mathcal{H}\_{g}^{d}(x)-\sum\_{y\in Y}\psi(y)\nu\_{y}$ |  | (1.3) |

is concave, $\mathcal{C}^{1}$-smooth, and its gradient is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\nabla\Phi(\psi)=\sum\_{y\in Y}(\rho(\Lag\_{y}(\psi))-\nu\_{y})\mathbbold{1}\_{y}.$ |  | (1.4) |

###### Corollary 1.2.

The following statements are equivalent:

* (i)

  $\psi:Y\to\mathbb{R}$ is a global maximizer of $\Phi$ ;
* (ii)

  $T\_{\psi}$ is an optimal transport map between $\rho$ and
  $\nu$ ;
* (iii)

  $T\_{\psi\#}\rho=\nu$, or equivalently,

  |  |  |  |  |
  | --- | --- | --- | --- |
  |  | $\forall y\in Y,~\rho(\Lag\_{y}(\psi))=\nu\_{y}$ |  | (MA) |

We call *Kantorovich’s functional* the function $\Phi$ introduced
in ([1.3](#S1.E3 "In Theorem 1.1. ‣ 1.3. Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Note that both this functional and its gradient are
invariant by addition of a constant. The non-linear equation
([MA](#S1.Ex6 "In item (iii) ‣ Corollary 1.2. ‣ 1.3. Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) can be considered as a discrete version of the
generalized Monge-Ampère equation that characterizes the solutions to
optimal transport problems (see for instance Chapter 12 in
[[34](#bib.bib34)]).

### 1.4. Damped Newton algorithm

We consider a simple damped Newton’s algorithm to solve semi-discrete
optimal transport problem. This algorithm is very close to the one
used by Mirebeau in [[28](#bib.bib28)]. To phrase this algorithm in a more general way, we
introduce a notation for the measure of Laguerre cells: for $\psi\in\mathbb{R}^{Y}$ we set

|  |  |  |  |
| --- | --- | --- | --- |
|  | $G(\psi):=\sum\_{y\in Y}G\_{y}(\psi)\mathbbold{1}\_{y}\hbox{ where }G\_{y}(\psi)=\rho(\Lag\_{y}(\psi)),$ |  | (1.5) |

so that $\nabla\Phi(\psi)=G(\psi)-\nu$. In the algorithm (Algorithm [1](#alg1 "In 1.4. Damped Newton algorithm ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), we denote by $A^{+}$ the
*pseudo-inverse* of the matrix $A$.

```
Input: 

A tolerance η>0\eta>0 and an initial ψ0∈ℝY\psi_{0}\in\mathbb{R}^{Y} such that

ε0:=12​min⁡[miny∈Y⁡Gy​(ψ0),miny∈Y⁡μy]>0.\varepsilon_{0}:=\frac{1}{2}\min\left[\min_{y\in Y}G_{y}(\psi_{0}),~\min_{y\in Y}\mu_{y}\right]>0.

(1.6)

While: 

‖Gy​(ψk)−μy‖⩾η\left\|G_{y}(\psi_{k})-\mu_{y}\right\|\geqslant\eta

Step 1: 

Compute dk=−D​G​(ψk)+​(G⁡(ψk)−μ)d_{k}=-\mathrm{D}G(\psi_{k})^{+}(G(\psi_{k})-\mu)

Step 2: 

Determine the minimum ℓ∈ℕ\ell\in\mathbb{N} such that ψkℓ:=ψk+2−ℓ​dk\psi_{k}^{\ell}:=\psi_{k}+2^{-\ell}d_{k} satisfies

{miny∈Y⁡Gy​(ψkℓ)⩾ε0‖G⁡(ψkℓ)−μ‖⩽(1−2−(ℓ+1))​‖G⁡(ψk)−μ‖\left\{\begin{aligned} &\min_{y\in Y}G_{y}(\psi_{k}^{\ell})\geqslant\varepsilon_{0}\\
&\left\|G(\psi_{k}^{\ell})-\mu\right\|\leqslant(1-2^{-(\ell+1)})\left\|G(\psi_{k})-\mu\right\|\end{aligned}\right.

Step 3: 

Set ψk+1=ψk+2−ℓ​dk\psi_{k+1}=\psi_{k}+2^{-\ell}d_{k} and k←k+1k\leftarrow k+1.
```

Algorithm 1 Simple damped Newton’s algorithm

The goal of this article is to prove the global convergence of this
damped Newton algorithm and to establish estimates on the speed of
convergence. As shown in Proposition [6.1](#S6.Thmtheorem1 "Proposition 6.1. ‣ 6.1. General damped Newton algorithm ‣ 6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), the
convergence of Algorithm [1](#alg1 "In 1.4. Damped Newton algorithm ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") depends on the regularity
and strong monotonicity of the map $G=\nabla\Phi$. As we will see,
the regularity of $G$ will depend mostly on the geometry of the cost
function and the regularity of the density. On the other hand, the
strong monotonicity of $G$ will require a strong connectedness
assumption on the support of $\rho$, in the form of a weighted
Poincaré-Wirtinger inequality. Before stating our main theorem we give
some indication about these intermediate regularity and monotonicity
results and their assumptions.

### 1.5. Regularity of Kantorovich’s functional and MTW condition

In order to establish the convergence of a damped Newton algorithm for
([MA](#S1.Ex6 "In item (iii) ‣ Corollary 1.2. ‣ 1.3. Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), we need to study the $\mathcal{C}^{2,\alpha}$ regularity of
Kantorovich’s functional $\Phi$. However, while $\mathcal{C}^{1}$ regularity
of $\Phi$ follows rather easily from the ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) hypothesis (or
even from weaker hypothesis, see Theorem [2.1](#S2.Thmtheorem1 "Theorem 2.1. ‣ 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")),
higher order regularity seems to depend on the geometry of the cost
function in a more subtle manner. We found that a sufficient condition
for the regularity of $\Phi$ is the Ma-Trudinger-Wang condition
[[26](#bib.bib26)], which appeared naturally in the study of the
regularity of optimal transport maps. We use a discretization
of Loeper’s geometric reformulation of the Ma-Trundinger-Wang
condition [[23](#bib.bib23)].

###### Definition 1.1 (Loeper’s condition).

The cost $c$ satisfies Loeper’s condition if for every $y$ in $Y$
there exists a convex open subset $\Omega\_{y}$ of $\mathbb{R}^{d}$ and a $\mathcal{C}^{1,1}$
diffeomorphism $\exp^{c}\_{y}:\Omega\_{y}\to\Omega$ such that the functions

|  |  |  |  |
| --- | --- | --- | --- |
|  | $p\in\Omega\_{y}\mapsto c(\exp^{c}\_{y}p,y)-c(\exp^{c}\_{y}p,z)$ |  | (QC) |

are quasi-convex for all $z$ in $Y$. The map $\exp^{c}\_{y}$ is called the
*$c$-exponential* with respect to $y$, and the domain $\Omega\_{y}$
is an *exponential chart*.

We comment here, that when $Y$ is a finite subset of a continuous space and $c$ satisfies conditions ([Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), and ([A3w](#S4.Ex117 "In 6th item ‣ Remark 4.4. ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) (which can be found on pages [Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), [Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), and [A3w](#S4.Ex117 "In 6th item ‣ Remark 4.4. ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") respectively), the $c$-exponential map defined in the usual sense in optimal transport theory (see Remarks [1.1](#S1.Thmremark1 "Remark 1.1. ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") and [4.4](#S4.Thmremark4 "Remark 4.4. ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) will satisfy what we call Loeper’s condition above. However, it will become apparent that for our purposes what is essential is the above quasi-convexity property and not the actual definition of $\exp^{c}\_{y}$. Thus we will elect to use the notation $\exp^{c}\_{y}$ even in cases when $Y$ is not a finite subset of a continuous space.

###### Definition 1.2 ($c$-Convexity).

Assuming Loeper’s condition,
a subset $X$ of $\Omega$ is *$c$-convex with respect to
a point $y$ of $Y$* if its inverse image $(\exp\_{y}^{c})^{-1}(X)$
is convex. The subset $X$ is said to be *$c$-convex* if it is
*$c$-convex* with respect to every point $y$ in $Y$.

Note that by assumption, the domain $\Omega$ itself is $c$-convex.
The connection between this discrete version of Loeper’s condition and
the conditions used in the regularity theory for optimal transport is
detailed in Remark [1.1](#S1.Thmremark1 "Remark 1.1. ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"). The ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) condition
implies the convexity of each Laguerre cell in its own exponential
charts, namely $(\exp\_{y}^{c})^{-1}(\Lag\_{y}(\psi))$ is convex for
every $y$ in $Y$. This plays a crucial role in the regularity of
Kantorovich’s functional.

###### Theorem 1.3.

Assume ([Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), and ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Let $X$ be a
compact, $c$-convex subset of $\Omega$ and let $\rho$ in
$\mathcal{P}^{\mathrm{ac}}(X)\cap\mathcal{C}^{0,\alpha}(X)$ for $\alpha$ in $(0,1]$. Then,
Kantorovich’s functional is of class $\mathcal{C}^{2,\alpha}\_{\text{loc}}$ on the
set

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{K}^{+}:=\{\psi:Y\to\mathbb{R}\mid\forall y\in Y,~\rho(\Lag\_{y}(\psi))>0\},$ |  | (1.7) |

and its Hessian is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle(z\neq y)\qquad$ | $\displaystyle\frac{\partial^{2}\Phi}{\partial\mathbbold{1}\_{y}\partial\mathbbold{1}\_{z}}(\psi)=\int\_{\Lag\_{y}(\psi)\cap\Lag\_{z}(\psi)}\frac{\rho(x)}{\left\|D\_{x}c(x,y)-D\_{x}c(x,z)\right\|\_{g}}\mathrm{d}\mathcal{H}\_{g}^{d-1}(x),$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\frac{\partial^{2}\Phi}{\partial\mathbbold{1}\_{y}^{2}}(\psi)=-\sum\_{z\in Y\setminus\{y\}}\frac{\partial^{2}\Phi}{\partial\mathbbold{1}\_{y}\partial\mathbbold{1}\_{z}}.$ |  | (1.8) |

The proof of this theorem and a more precise statement are given in
Section [4](#S4 "4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") (Theorem [4.1](#S4.Thmtheorem1 "Theorem 4.1. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")),
showing that the $\mathcal{C}^{2,\alpha}$ estimate can be made uniform
when the mass of the Laguerre cells is bounded from below by a
positive constant.

###### Remark 1.1.

We remark that under certain assumptions on the cost $c$, our
([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) condition is implied by classical conditions introduced
in a smooth setting by X.-N. Ma, N. Trudinger, and X.-J. Wang
[[26](#bib.bib26)], which include the well known (MTW) or (A3)
condition. See Remark [4.4](#S4.Thmremark4 "Remark 4.4. ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") for more specifics.

There are a wide variety of known examples satisfying these
conditions. Aside from the canonical example of the inner product on
$\mathbb{R}^{n}\times\mathbb{R}^{n}$, and other costs on Euclidean spaces mentioned
in [[26](#bib.bib26), [33](#bib.bib33)], there are the nonflat
examples of Riemannian distance squared and
$-\log\left\|x-y\right\|\_{\mathbb{R}^{n+1}}$ on (a subset of) $\mathbb{S}^{n}\times\mathbb{S}^{n}$ (see [[24](#bib.bib24)]). The last cost is associated to
the *far-field reflector antenna problem*. We refer the reader to
[[19](#bib.bib19), p. 1331] for a (more) comprehensive list of such
costs.

### 1.6. Strong concavity of Kantorovich’s functional

As noted earlier, Kantorovich’s functional $\Phi$ cannot be strictly
concave, since it is invariant under addition of a constant. This
implies that the Hessian $\mathrm{D}^{2}\Phi$ has a zero eigenvalue
corresponding to the constants. A more serious obstruction to the
strict concavity of $\Phi$ at a point $\psi$ arises when the discrete
graph induced by the Hessian (where two points are connected iff
$\partial^{2}\Phi/\partial\mathbbold{1}\_{y}\partial\mathbbold{1}\_{z}(\psi)\neq 0$) is not
connected. This can happen either because one of the Laguerre cells is
empty (hence not connected to any neighbor) or if the support of the
probability density $\rho$ is itself disconnected. In order to avoid
the latter phenomena, we will require that $(X,\rho)$ satisfies a
weighted $\mathrm{L}^{1}$ Poincaré-Wirtinger inequality.

###### Definition 1.3 (weighted Poincaré-Wirtinger).

A continuous probability density $\rho$ on a compact set $X\subseteq\Omega$ satisfies a weighted Poincaré-Wirtinger inequality with
constant $C\_{\mathrm{pw}}>0$ if for every $\mathcal{C}^{1}$ function $f$ on $X$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left\|f-\mathbb{E}\_{\rho}(f)\right\|\_{L^{1}(\rho)}\leqslant C\_{\mathrm{pw}}\left\|\nabla f\right\|\_{L^{1}(\rho)},$ |  | (PW) |

where $\left\|h\right\|\_{L^{1}(\rho)}:=\int\_{X}|h(x)|\rho(x)\mathrm{d}\mathcal{H}\_{g}^{d}(x)$ and
$\mathbb{E}\_{\rho}(f):=\int\_{X}f(x)\rho(x)\mathrm{d}\mathcal{H}\_{g}^{d}(x)$.

We denote $E\_{Y}$ the orthogonal complement (in $\mathbb{R}^{Y}$) of the space
of constant functions on $Y$, that is $E\_{Y}:=\{\psi\in\mathbb{R}^{Y}\mid\sum\_{y}\psi(y)=0\}.$ As before, $\mathcal{K}^{+}$ is the set of functions
$\psi$ whose Laguerre cells all have positive mass.

###### Theorem 1.4.

Assume ([Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), and ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Let $X$ be a
compact, $c$-convex subset of $\Omega$, and $\rho$ be a continuous
probability density on $X$ satisfying ([PW](#S1.Ex10 "In Definition 1.3 (weighted Poincaré-Wirtinger). ‣ 1.6. Strong concavity of Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Then,
Kantorovich’s functional $\Phi$ is strictly concave on $E\_{Y}\cap\mathcal{K}^{+}$.

As before, a more quantitative statement is proven in
Section [5](#S5 "5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") (Theorem [5.1](#S5.Thmtheorem1 "Theorem 5.1. ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")),
establishing strong concavity of $\Phi$ assuming that the mass of the Laguerre cells is bounded from below by a positive
constant.

### 1.7. Convergence result

Putting Proposition [6.1](#S6.Thmtheorem1 "Proposition 6.1. ‣ 6.1. General damped Newton algorithm ‣ 6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), Theorem [1.3](#S1.Thmtheorem3 "Theorem 1.3. ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") and
Theorem [1.4](#S1.Thmtheorem4 "Theorem 1.4. ‣ 1.6. Strong concavity of Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") together, we can prove the global
convergence of the damped Newton algorithm for semi-discrete
optimal transport (Algorithm 1) together with optimal convergence
rates.

###### Theorem 1.5.

Assume ([Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and also that

* (i)

  The support of the probability density $\rho$ is included
  in a compact, $c$-convex subset $X$ of $\Omega$, and $\rho\in\mathcal{C}^{0,\alpha}(X)$ for $\alpha$ in $(0,1]$.
* (ii)

  $\rho$ has positive Poincaré-Wirtinger
  ([PW](#S1.Ex10 "In Definition 1.3 (weighted Poincaré-Wirtinger). ‣ 1.6. Strong concavity of Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) constant.

Then the damped Newton algorithm for semi-discrete optimal transport
(Algorithm 1) converges globally with linear rate and locally with
rate $1+\alpha$.

###### Remark 1.2.

This theorem makes no assumption about the convexity (or
$c$-convexity) of the support of the source density $\rho$. Such
cases are not handled by other numerical methods for Monge-Ampère
equations [[6](#bib.bib6), [24](#bib.bib24)]. For completeness,
we provide in Appendix [A](#A1 "Appendix A A weighted Poincaré-Wirtinger inequality ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") an explicit example of a
radial measure on $\mathbb{R}^{d}$ whose support is an annulus but whose
Poincaré-Wirtinger constant is nonetheless positive.

###### Remark 1.3.

The positive lower bound on the damping parameter
($\tau\_{k}=2^{-\ell}$ in Algorithm [1](#alg1 "In 1.4. Damped Newton algorithm ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) established in
this theorem degrades as $N$ grows to infinity. It is plausible (but
far from direct) that one could control this quantity when $N$ is
large by a comparison to the continuous Monge-Ampère equation. The
strong concavity estimate (Theorem [1.4](#S1.Thmtheorem4 "Theorem 1.4. ‣ 1.6. Strong concavity of Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) would
then need to be replaced by uniform ellipticity estimates for the
linearized Monge-Ampère equation, while the regularity estimate
(Theorem [1.3](#S1.Thmtheorem3 "Theorem 1.3. ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) would be replaced by regularity
estimates for solutions to the Monge-Ampère equation. We refer to
Loeper and Rapetti [[25](#bib.bib25)] for an implementation
of this ideas in a continuous setting. The space-discretization of
their approach is open.

### Comparison to previous work.

There exist a few other numerical methods relying on Newton’s
algorithm for the resolution of the standard Monge-Ampère equation or
for the quadratic optimal transport problem. Here, we highlight some
of the differences between Algorithm [1](#alg1 "In 1.4. Damped Newton algorithm ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") and
Theorem [1.5](#S1.Thmtheorem5 "Theorem 1.5. ‣ 1.7. Convergence result ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") and these existing results. First, we note that
many authors have reported the good behavior in practice of Newton’s or
quasi-Newton’s methods for solving discretized Monge-Ampère equations
or optimal transport problems
[[27](#bib.bib27), [11](#bib.bib11), [6](#bib.bib6)]. Note
however that none of these works contain convergence proofs for the
Newton’s algorithm.

Loeper and Rapetti [[25](#bib.bib25)] (refined by Saumier,
Agueh, and Khouider [[31](#bib.bib31)]) establish the global
convergence of a damped Newton’s method for solving quadratic optimal
transport on the torus, relying heavily on Caffarelli’s regularity
theory. In particular, the convergence of the algorithm requires a
positive lower bound on the probability densities, while this
condition is not necessary for Theorem [1.5](#S1.Thmtheorem5 "Theorem 1.5. ‣ 1.7. Convergence result ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") (see
Section [5](#S5 "5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") and Appendix [A](#A1 "Appendix A A weighted Poincaré-Wirtinger inequality ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") where we
construct explicitly probability densities with non-convex support
that still satisfy the hypothesis of Theorem [1.5](#S1.Thmtheorem5 "Theorem 1.5. ‣ 1.7. Convergence result ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). A second
drawback on relying on the regularity theory for optimal transport is
that the damping parameter, which is an input parameter of the
algorithm used in [[25](#bib.bib25)], cannot be determined
explicitly from the data. Third, the convergence proof is for
continuous densities, and it seems difficult to adapt it to the
space-discretized problem. On the positive side, it seems likely that
the convergence proof of
[[25](#bib.bib25)][[31](#bib.bib31)] can be adapted
to cost functions satisfying the Ma-Trudinger-Wang condition (which is
equivalent to Loeper’s condition ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) that we also require).

Oliker and Prussner prove the *local* convergence of Newton’s
method for finding Alexandrov’s solutions to the Monge-Ampère equation
$\det\mathrm{D}^{2}u=\nu$ with Dirichlet boundary conditions, where $\nu$ is
a finitely supported measure [[29](#bib.bib29)]. Global
convergence for a damped Newton’s algorithm is established by Mirebeau
[[28](#bib.bib28)] for a variant of Oliker and
Prussner’s discretization, but without convergence
rates. Theorem [1.5](#S1.Thmtheorem5 "Theorem 1.5. ‣ 1.7. Convergence result ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") can be seen as an extension of the
strategy used by Mirebeau to optimal transport problems, which amounts
to (a) replacing the Dirichlet boundary conditions with the second
boundary value conditions from optimal transport (b) replacing the
Lebesgue measure by more general probability densities and (c)
changing the Monge-Ampère equation itself in order to deal with more
general cost functions.

We also comment here that our result Theorem [5.1](#S5.Thmtheorem1 "Theorem 5.1. ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")
answers a conjecture first raised by Gangbo and McCann, in the case
when the cost function satisfies the Ma-Trudinger-Wang condition. In
[[15](#bib.bib15), Example 1.6], a numerical approach to the
semi-discrete optimal transport problem is suggested by taking what is
equivalent to the negative gradient flow of the Kantorovich function
defined in ([1.3](#S1.E3 "In Theorem 1.1. ‣ 1.3. Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) above. There, Gangbo and McCann conjecture
that this gradient flow should converge, and our result of uniform
concavity of the Kantorovich functional provides a positive answer to
a quantitative strengthening of this conjecture, at least for costs,
measures, and domains satisfying the assumptions of
Theorem [5.1](#S5.Thmtheorem1 "Theorem 5.1. ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

Finally, we note that the overall strategy for proving the
convergence of Algorithm 1 (proving regularity then strict concavity
of $\Phi$) shares features to the one used in
[[9](#bib.bib9)] to study the relationship between highly
anisotropic semi-discrete quadratic optimal transport and Knothe
rearrangement.

### Outline

In Section [2](#S2 "2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), we establish the differentiability
of Kantorovich’s functional $\Phi$, adapting arguments from
[[5](#bib.bib5)]. In
Sections [3](#S3 "3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") and [4](#S4 "4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), we
prove the (uniform) second-differentiability of Kantorovich’s
functional when the cost function satisfies Loeper’s ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))
condition. Section [5](#S5 "5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") is devoted to the proof of
uniform concavity of Kantorovich’s functional, when the probability
density satisfies a Poincaré-Wirtinger inequality
([PW](#S1.Ex10 "In Definition 1.3 (weighted Poincaré-Wirtinger). ‣ 1.6. Strong concavity of Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). In Section [6](#S6 "6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), we combine these
intermediate results to prove the convergence of the damped Newton’s
algorithm (Theorem [1.5](#S1.Thmtheorem5 "Theorem 1.5. ‣ 1.7. Convergence result ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), and we present a numerical
illustration. Appendix [A](#A1 "Appendix A A weighted Poincaré-Wirtinger inequality ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") presents an explicit
construction of a probability density with non-convex support over
$\mathbb{R}^{d}$ which satisfies the assumptions of
Theorem [1.5](#S1.Thmtheorem5 "Theorem 1.5. ‣ 1.7. Convergence result ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"). Appendix [B](#A2 "Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") contains the
details of the proof of the main theorem of
Section [4](#S4 "4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

#### Acknowledgements

QM and BT would like to acknowledge the support of the French ANR
through the grant ANR-16-CE40-0014 (MAGA). BT is also partially
supported by LabEx PERSYVAL-Lab (ANR-11-LABX-0025-01).

## 2. Kantorovich’s functional

The purpose of this section is to present the variational formulation
introduced in [[5](#bib.bib5)] for the semi-discrete
optimal transport problem, adapting the arguments presented for the
squared Euclidean cost in [[5](#bib.bib5)] to cost
functions satisfying ([Reg’](#S2.Ex11 "In 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([Twist’](#S2.Ex12 "In 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), which
are weaker than the conditions ([Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))
presented in the introduction:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\forall y\in Y,~~c(\cdot,y)\in\mathcal{C}^{0}(\Omega)$ |  | (Reg’) |

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\forall y\neq z\in Y,\ \forall t\in\mathbb{R},~~\mathcal{H}\_{g}^{d}((c(\cdot,y)-c(\cdot,z))^{-1}(t))=0$ |  | (Twist’) |

Note that under ([Twist’](#S2.Ex12 "In 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), the map $T\_{\varphi}:X\to Y$ defined
by ([1.2](#S1.E2 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) is uniquely-defined $\mathcal{H}\_{g}^{d}$–almost everywhere. Most of the results presented here are well known in the optimal transport literature, we include proofs for completeness.

###### Theorem 2.1.

Assume ([Reg’](#S2.Ex11 "In 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([Twist’](#S2.Ex12 "In 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), and let $\rho$ be
a bounded probability density on $X$ and $\nu=\sum\_{y\in Y}\nu\_{y}\delta\_{y}$ be a probability measure over $Y$. Then, the
functional $\Phi$ defined by ([1.3](#S1.E3 "In Theorem 1.1. ‣ 1.3. Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) is concave,
$\mathcal{C}^{1}$-smooth, and its gradient is given by ([1.4](#S1.E4 "In Theorem 1.1. ‣ 1.3. Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")).

The proof of Theorem [2.1](#S2.Thmtheorem1 "Theorem 2.1. ‣ 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") relies on
Propositions [2.2](#S2.Thmtheorem2 "Proposition 2.2. ‣ 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") and [2.3](#S2.Thmtheorem3 "Proposition 2.3. ‣ 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

###### Proposition 2.2.

For any $\psi:Y\to\mathbb{R}$, the map $T\_{\psi}$ is
an optimal transport map for the cost $c$ between any probability
density $\rho$ on $\Omega$ and the pushforward measure $\nu:=T\_{\psi\#}\rho$.

###### Proof.

Assume that $\nu=S\_{\#}\rho$ where $S$ is a
measurable map between $X$ and $Y$. Then, by definition of $T\_{\psi}$
one has

|  |  |  |
| --- | --- | --- |
|  | $\forall x\in X,~~c(x,T\_{\psi}(x))+\psi(T\_{\psi}(x))\leqslant c(x,S(x))+\psi(S(x)).$ |  |

Multiplying this inequality by $\rho$ and
integrating it over $X$ gives

|  |  |  |
| --- | --- | --- |
|  | $\int\_{X}(c(x,T\_{\psi}(x))+\psi(T\_{\psi}(x)))\rho(x)\mathrm{d}\mathcal{H}\_{g}^{d}(x)\leqslant\int\_{X}(c(x,S(x))+\psi(S(x)))\rho(x)\mathrm{d}\mathcal{H}\_{g}^{d}(x)$ |  |

Since
$\nu=S\_{\#}\rho=T\_{\psi\#}\rho$, the change of variable formula
gives

|  |  |  |
| --- | --- | --- |
|  | $\int\_{X}\psi(S(x))\rho(x)\mathrm{d}\mathcal{H}\_{g}^{d}(x)=\int\_{Y}\varphi(y)\mathrm{d}\nu=\int\_{X}\psi(T\_{\psi}(x))\rho(x)\mathrm{d}\mathcal{H}\_{g}^{d}(x)$ |  |

Substracting this
equality from the inequality above shows that $T\_{\psi}$ is optimal:

|  |  |  |
| --- | --- | --- |
|  | $\int\_{X}c(x,T\_{\psi}(x))\rho(x)\mathrm{d}\mathcal{H}\_{g}^{d}(x)\leqslant\int\_{X}c(x,S(x))\rho(x)\mathrm{d}\mathcal{H}\_{g}^{d}(x)\qed$ |  |

###### Proposition 2.3.

Assume ([Twist’](#S2.Ex12 "In 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([Reg’](#S2.Ex11 "In 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Let $\rho$ be a
probability density over a compact subset $X$ of $\Omega$. Then, the
map $G:\mathbb{R}^{Y}\to\mathbb{R}^{Y}$ is continuous:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $G(\psi)=\left(\rho(\Lag\_{y}(\psi))\right)\_{y\in Y}$ |  | (2.9) |

###### Lemma 2.4.

Let $\rho$ be a probability density over a compact subset $X$ of $\Omega$, and let
$f$ in $\mathcal{C}^{0}(X)$ be such that $\rho(f^{-1}(t))=0$ for all $t\in\mathbb{R}$. Then, the function $g:t\mapsto\rho(f^{-1}((-\infty,t]))$ is continuous.

###### Proof.

We consider the function $h(t)=\rho(f^{-1}((-\infty,t)))$. By hypothesis, $g(t)-h(t)=\rho(f^{-1}(t))=0$. Moreover, using Lebesgue’s monotone convergence theorem one easily sees that $g$ (resp. $h$) is right-continuous (resp. left-continuous). This concludes the proof
∎

###### Proof of Proposition [2.3](#S2.Thmtheorem3 "Proposition 2.3. ‣ 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

Proving the continuity of $G$ amounts to proving the
continuity of the functions $G\_{y}(\psi):=\rho(\Lag\_{y}(\psi))$ for
any $y$ in $Y$. Fix $y$ in $Y$ and remark that by definition,
$\Lag\_{y}(\psi)=\bigcap\_{z\neq y\in Y}H\_{z}(\psi)$
where

|  |  |  |
| --- | --- | --- |
|  | $H\_{z}(\psi):=\{x\in X\mid c(x,y)+\psi(y)\leqslant c(x,z)+\psi(z)\}.$ |  |

Denoting $A\Delta B$ the symmetric difference of two
sets, we have the following inequalities

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left|G\_{y}(\psi)-G\_{y}(\varphi)\right|\leqslant\rho(\Lag\_{y}(\psi)\Delta\Lag\_{y}(\varphi))\leqslant\sum\_{z\in Y\setminus\{y\}}\rho(H\_{z}(\psi)\Delta H\_{z}(\varphi)).$ |  | (2.10) |

Fix $z\neq y\in Y$, and denote $f=c(\cdot,y)-c(\cdot,z)$. Then,

|  |  |  |
| --- | --- | --- |
|  | $H\_{z}(\psi)\Delta H\_{z}(\varphi)\subseteq f^{-1}([\psi(z)-\psi(y),\varphi(z)-\varphi(y)]).$ |  |

Here and after, we use the convention that $[a,b]=[\min\{a,b\},\max\{a,b\}]$.
By ([Twist’](#S2.Ex12 "In 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and
Lemma [2.4](#S2.Thmtheorem4 "Lemma 2.4. ‣ 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") we know that
$\lim\_{\varphi\to\psi}\rho(H\_{z}(\psi)\Delta H\_{z}(\varphi))=0,$ which
with ([2.10](#S2.E10 "In Proof of Proposition . ‣ 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) concludes the proof.
∎

### 2.1. Proof of Theorem [1.1](#S1.Thmtheorem1 "Theorem 1.1. ‣ 1.3. Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")

We simultaneously show that
the functional is concave and compute its gradient. For any
function $\psi$ on $Y$ and any measurable map $T:X\to Y$, one has
$\min\_{y\in Y}(c(x,y)+\psi(y))\leqslant c(y,T(y))+\psi(T(y))$, which
by integration gives

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Phi(\psi)\leqslant\int\_{X}(c(x,T(x))+\psi(T(x)))\rho(x)\mathrm{d}\mathcal{H}\_{g}^{d}(x)-\sum\_{y\in Y}\psi(y)\nu\_{y}.$ |  | (2.11) |

Moreover, equality holds when $T=T\_{\psi}$. Taking another function
$\varphi$ on $Y$ and setting $T=T\_{\varphi}$ in Equation ([2.11](#S2.E11 "In 2.1. Proof of Theorem ‣ 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))
gives

|  |  |  |
| --- | --- | --- |
|  | $\Phi(\psi)\leqslant\Phi(\varphi)+\langle G(\varphi)-\nu\mid\psi-\varphi\rangle,$ |  |

where $G$ is defined as in the statement of
Proposition [2.3](#S2.Thmtheorem3 "Proposition 2.3. ‣ 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"). This proves that the
superdifferential $\partial^{+}\Phi(\varphi)$ contains $G(\varphi)-\nu$, thus establishing the
concavity of $\Phi$ and its differentiability almost everywhere. It is known that the
supergradient $\partial^{+}\Phi(\varphi)$ is characterized by [[30](#bib.bib30), Theorem 25.6]

|  |  |  |
| --- | --- | --- |
|  | $\partial^{+}\Phi(\varphi)=\mathrm{conv}\left\{\lim\_{n\to\infty}\nabla\Phi(\varphi\_{n})\mid(\varphi\_{n})\in S\right\},$ |  |

where $\mathrm{conv}$ denotes the convex envelope and $S$ the set of sequences $(\varphi\_{n})$ converging to $\varphi$ such that $\Phi$ is differentiable at $\varphi\_{n}$.
By Proposition [2.3](#S2.Thmtheorem3 "Proposition 2.3. ‣ 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), the map $G$ is continuous,
meaning that we have constructed a continuous selection of a
supergradient in the superdifferential of the concave function
$\Phi$

|  |  |  |
| --- | --- | --- |
|  | $\partial^{+}\Phi(\varphi)=\mathrm{conv}\left\{\lim\_{n\to\infty}\nabla\Phi(\varphi\_{n})\right\}=\mathrm{conv}\left\{\lim\_{n\to\infty}G(\varphi\_{n})-\nu\right\}=\{G(\varphi)-\nu\}.$ |  |

This proves that $\Phi$ is $\mathcal{C}^{1}$, and that $\nabla\Phi(\varphi)=G(\varphi)-\nu$.

## 3. Local regularity in a $c$-exponential chart

The results presented in this section constitute an intermediate step
in the proof of $\mathcal{C}^{2,\alpha}$ regularity of Kantorovich’s
functional. Let $\hat{X}$ be a compact, convex subset of $\mathbb{R}^{d}$ and
$f\_{1},\ldots,f\_{N}$ be $\mathcal{C}^{1,1}$ functions on $\hat{X}$ which are
quasi-convex, meaning that for any scalar $\lambda\in\mathbb{R}$ the closed
sublevel sets $K\_{i}(\lambda):=f\_{i}^{-1}([-\infty,\lambda])$ are convex.
Let $\hat{\rho}$ be a continuous probability density over $\hat{X}$. The
purpose of this section is to give sufficient conditions to ensure
the regularity of the following function $\hat{G}$ near the origin of $\mathbb{R}^{N}$:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\hat{G}:\bm{\lambda}\in\mathbb{R}^{N}\mapsto\int\_{K(\bm{\lambda})}\hat{\rho}(x)\mathrm{d}\mathcal{H}^{d}(x),$ |  | (3.12) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\hbox{where }K(\bm{\lambda}):=\bigcap\_{i=1}^{N}K\_{i}(\lambda\_{i})=\{x\in\hat{X}\mid\forall i\in\{1,\ldots,N\},~f\_{i}(x)\leqslant\lambda\_{i}\}.$ |  |

### 3.1. Assumptions and statement of the theorem.

We will impose
two conditions on the functions $(f\_{i})\_{1\leqslant i\leqslant N}$. As we will
see in Section [4](#S4 "4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), both conditions are satisfied
when these functions $(f\_{i})$ are constructed from a semi-discrete
optimal transport transport problem whose cost function satisfy
Loeper’s condition (see Definition [1.1](#S1.Thmdefinition1 "Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")).

#### Non-degeneracy

The functions $(f\_{i})$
satisfy the *nondegeneracy condition* if the norm of their
gradients is bounded from below:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\varepsilon\_{nd}:=\min\_{1\leqslant i\leqslant N}\min\_{\hat{X}}\left\|\nabla f\_{i}\right\|>0.$ |  | (ND) |

This condition is necessary for the continuity of the map $\hat{G}$ even
when $N=1$.

#### Transversality

The boundary of the convex set $K(\bm{\lambda})$ can be decomposed
into $N+1$ *facets*, namely $(K(\bm{\lambda})\cap\partial K\_{i}(\lambda\_{i}))\_{1\leqslant i\leqslant N}$ and $K(\bm{\lambda})\cap\partial\hat{X}$. The purpose of the transversality condition we consider is to
ensure that the angle between adjacent facets is bounded from below
when $\bm{\lambda}$ remains close to some fixed vector $\bm{\lambda}\_{0}$.

###### Definition 3.1 (Normal cone).

Let $K$ be a convex compact set of $\mathbb{R}^{d}$. The *normal cone*
to $K$ at a point $x$ in $K$ is the set

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{N}\_{x}K=\{v\in\mathbb{R}^{d}\mid\forall y\in K,~\langle y-x\mid v\rangle\leqslant 0\},$ |  | (3.13) |

and its elements are said to be *normal to $K$ at $x$*.

###### Definition 3.2 (Transversality).

The family of functions $(f\_{i})$ satisfy the
*transversality condition near $\bm{\lambda}\_{0}$* if there exists
positive constants $\varepsilon\_{tr}$ and $T\_{tr}\leqslant 1$ such that for every
$\bm{\lambda}$ in $\mathbb{R}^{N}$ satisfying $\left\|\bm{\lambda}-\bm{\lambda\_{0}}\right\|\_{\infty}\leqslant T\_{tr}$ for the usual $\ell^{\infty}$
norm on $\mathbb{R}^{N}$ and every point $x$ in $\partial K(\bm{\lambda})$ one
has,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\hbox{ if }\exists i\neq j\in\{1,\ldots,N\}\hbox{ s.t. }f\_{i}(x)=\lambda\_{i}\hbox{ and }f\_{j}(x)=\lambda\_{j},$ |  | (T) |
|  |  | $\displaystyle\hbox{ then, }\left(\frac{\langle\nabla f\_{i}(x)\mid\nabla f\_{j}(x)\rangle}{\left\|\nabla f\_{i}(x)\right\|\left\|\nabla f\_{j}(x)\right\|}\right)^{2}\leqslant 1-\varepsilon^{2}\_{tr}$ |  |
|  |  | $\displaystyle\hbox{ if }\exists i\in\{1,\ldots,N\}\hbox{ s.t. }f\_{i}(x)=\lambda\_{i}\hbox{ and }x\in\partial\hat{X},$ |  |
|  |  | $\displaystyle\hbox{ then, }\forall u\in\mathcal{N}\_{x}\hat{X},~\left(\frac{\langle u\mid\nabla f\_{j}(x)\rangle}{\left\|u\right\|\left\|\nabla f\_{j}(x)\right\|}\right)^{2}\leqslant 1-\varepsilon^{2}\_{tr},$ |  |

Note that $\partial\hat{X}$ is smooth at $x$, $\mathcal{N}\_{x}\hat{X}$ is the
ray spanned by the exterior normal to $\hat{X}$ at $x$.

###### Theorem 3.1.

Assume that the functions satisfy the non-degeneracy condition
([ND](#S3.Ex23 "In Non-degeneracy ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and the transversality condition ([T](#S3.Ex24 "In Definition 3.2 (Transversality). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) near
$\bm{\lambda\_{0}}$. Let $\hat{\rho}$ be a $\mathcal{C}^{0,\alpha}$ probability
density on $\hat{X}$. Then, the map $\hat{G}$ defined in ([3.12](#S3.E12 "In 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))
is of class $\mathcal{C}^{1,\alpha}$ on the cube $Q:=\bm{\lambda\_{0}}+[-T\_{tr},T\_{tr}]^{N}$ and has partial derivatives given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{\partial\hat{G}}{\partial\lambda\_{i}}(\bm{\lambda})=\int\_{K({\bm{\lambda}})\cap\partial K\_{i}({\bm{\lambda}})}\frac{\hat{\rho}(x)}{\left\|\nabla f\_{i}(x)\right\|}\mathrm{d}\mathcal{H}^{d-1}(x).$ |  | (3.14) |

In addition, the norm $\left\|\hat{G}\right\|\_{\mathcal{C}^{1,\alpha}(Q)}$ is bounded
by a constant depending only on $\varepsilon\_{tr},\varepsilon\_{nd},\left\|\hat{\rho}\right\|\_{\mathcal{C}^{0,\alpha}(\hat{X})}$, on the diameter of $\hat{X}$ and on

|  |  |  |
| --- | --- | --- |
|  | $C\_{M}:=\max\_{1\leqslant i\leqslant N}\left\|\nabla f\_{i}\right\|\_{\infty}\qquad C\_{L}:=\max\_{1\leqslant i\leqslant N}\left\|\nabla f\_{i}\right\|\_{\Lip(\hat{X})}.$ |  |

Note that the $\mathcal{C}^{1,\alpha}$ constant of $\hat{G}$ depends on the
transversality constant $\varepsilon\_{tr}$ but that it does not depend on
$T\_{tr}$.

### 3.2. Sketch of proof

The correct expression for the partial derivatives of $\hat{G}$, given
by equation ([3.14](#S3.E14 "In Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), can easily be guessed by applying the
co-area formula. The non-degeneracy condition then ensures that the
denominator in this expression does not vanish. What is more delicate
is to prove that these partial derivatives are $\alpha$-Hölder, with
a uniform estimate on the $\alpha$-Hölder norm. A second application
of the co-area formula on the manifold $f\_{i}^{-1}(\lambda\_{i})$
suggests that for $j\neq i$ one should have,

|  |  |  |
| --- | --- | --- |
|  | $\left|\frac{\partial}{\partial\lambda\_{j}}\int\_{K({\bm{\lambda}})\cap\partial K\_{i}({\bm{\lambda}})}\frac{\hat{\rho}(x)}{\left\|\nabla f\_{i}(x)\right\|}\mathrm{d}\mathcal{H}^{d-1}(x)\right|\leqslant C\mathcal{H}^{d-2}(K({\bm{\lambda}})\cap\partial K\_{i}({\bm{\lambda}})\cap\partial K\_{j}({\bm{\lambda}})),$ |  |

under the assumption that the
density $\hat{\rho}$ is $\mathcal{C}^{1}$ and the facet $K({\bm{\lambda}})\cap\partial K\_{i}({\bm{\lambda}})$ does not intersect $\partial\hat{X}$. It will turn out that, thanks to the transversality hypothesis, the
$\mathcal{H}^{d-2}$-measure of the union $\Sigma(\bm{\lambda})$ of these facets can be bounded
uniformly:

|  |  |  |
| --- | --- | --- |
|  | $\Sigma(\bm{\lambda})=\bigcup\_{1\leqslant i\leqslant N}(K(\bm{\lambda})\cap\partial\hat{X}\cap\partial K\_{i}(\lambda\_{i}))\cup\bigcup\_{1\leqslant i<j\leqslant N}(K(\bm{\lambda})\cap\partial K\_{i}(\lambda\_{i})\cap\partial K\_{j}(\lambda\_{j})).$ |  |

Note also that equivalently, a point $x$ belongs to the singular set
$\Sigma(\bm{\lambda})$ if and only if it satisfies one of the
assumptions in ([T](#S3.Ex24 "In Definition 3.2 (Transversality). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). In the next subsection, we prove an upper
bound on $\mathcal{H}^{d-2}(\Sigma(\bm{\lambda}))$ (see
Proposition [3.2](#S3.Thmtheorem2 "Proposition 3.2. ‣ 3.3. A control on the (𝑑-2)–Hausdorff measure of singular points ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). The proof of Theorem [3.1](#S3.Thmtheorem1 "Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")
follows from this upper bound and from several applications of the
co-area formula. Since it is elementary but quite long, we have
postponed the proof of the theorem itself to Appendix [B](#A2 "Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

### 3.3. A control on the $(d-2)$–Hausdorff measure of singular points

In this section, we prove that the transversality condition
([T](#S3.Ex24 "In Definition 3.2 (Transversality). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and the quasi-convexity of the functions $(f\_{i})$ imply a
uniform upper bound on the $(d-2)$–Hausdorff measure of
$\Sigma(\bm{\lambda})$.

###### Proposition 3.2.

Assuming the transversality condition ([T](#S3.Ex24 "In Definition 3.2 (Transversality). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), there exists a
constant depending only on $d$ and $\diam(\hat{X})$ such that for
every $\left\|\bm{\lambda}\right\|\_{\infty}\leqslant T\_{tr}$,

|  |  |  |
| --- | --- | --- |
|  | $\mathcal{H}^{d-2}(\Sigma(\bm{\lambda}))\leqslant C(d,\diam(\hat{X}))\cdot\frac{1}{\varepsilon\_{tr}}.$ |  |

We will deduce this proposition from a general upper bound on the
$(d-2)$–Hausdorff measure of the set of $\tau$–singular points of a
compact convex body. A more general and quantitative version of this
bound can be found in [[18](#bib.bib18)]. We provide below a
straightforward and easy proof based on the notions of packing and
covering numbers.

###### Proposition 3.3.

Let $K$ be a convex, compact set of $\mathbb{R}^{d}$ and $\tau>0$. Then,

|  |  |  |
| --- | --- | --- |
|  | $\mathcal{H}^{d-2}(\mathrm{Sing}(K,\tau))\leqslant C(d,\diam(K))\ \frac{1}{\tau},$ |  |

where $\mathrm{Sing}(K,\tau):=\{x\in\partial K\mid\exists u,v\in\mathcal{N}\_{x}(K)\cap\mathbb{S}^{d-1},~~\langle u\mid v\rangle^{2}\leqslant 1-\tau^{2}\}.$

Recall that the covering number $\mathrm{Cov}(K,\eta)$ of a subset $K\subseteq\mathbb{R}^{d}$ is the minimum number of Euclidean balls of radius $\eta$
required to cover $K$. The packing number of a subset $K$ is given by

|  |  |  |
| --- | --- | --- |
|  | $\mathrm{Pack}(K,\eta):=\max\{\mathrm{Card}(X)\mid X\subseteq K\hbox{ and }\forall x\neq y\in X,\left\|x-y\right\|\geqslant\eta\}.$ |  |

We will use the following comparisons between covering and packing numbers:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathrm{Cov}(K,\eta)\leqslant\mathrm{Pack}(K,\eta)\leqslant\mathrm{Cov}(K,\frac{\eta}{2}).$ |  | (3.15) |

###### Proof of Proposition [3.3](#S3.Thmtheorem3 "Proposition 3.3. ‣ 3.3. A control on the (𝑑-2)–Hausdorff measure of singular points ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

The proof consists in comparing a lower bound and an upper bound of
the packing number of the set

|  |  |  |
| --- | --- | --- |
|  | $U:=\{(x,n)\in\mathbb{R}^{d}\times\mathbb{S}^{d-1}\mid x\in\mathrm{Sing}(K,\tau)\mbox{ and }n\in\mathcal{N}\_{x}(K)\}.$ |  |

Step 1. We first calculate an upper bound on the
covering number of the unit bundle $\mathcal{U}K:=\{(x,n)\in\partial K\times\mathbb{S}^{d-1}\mid n\in\mathcal{N}\_{x}K\}$. Given a positive radius
$r$, we denote by $K^{r}$ the set of points that are within distance $r$ of
$K$. By convexity, the projection map $\mathrm{p}\_{K}:\mathbb{R}^{d}\to K$, mapping a
point to its orthogonal projection on $K$, is well defined and
$1$-Lipschitz. We consider

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\pi:\partial K^{r}$ | $\displaystyle\to\mathcal{U}(K)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle x$ | $\displaystyle\mapsto\left(\mathrm{p}\_{K}(x),\frac{x-\mathrm{p}\_{K}(x)}{\left\|x-\mathrm{p}\_{K}(x)\right\|}\right)$ |  |

The map $\pi$ is surjective and has Lipschitz constant
$L:=\sqrt{1+4/r^{2}}$. We deduce an upper bound on covering number of
$\mathcal{U}K$ from the covering number of the level set $\partial K^{r}$:

|  |  |  |
| --- | --- | --- |
|  | $\mathrm{Cov}(\mathcal{U}(K),\varepsilon)\leqslant\mathrm{Cov}\left(\partial K^{r},\frac{\varepsilon}{L}\right).$ |  |

Now, consider a sphere $S$ with diameter $2\diam(K)$ that encloses
the tubular neighborhood $K^{r}$ with $r:=\diam(K)$. The projection map
$\mathrm{p}\_{K^{r}}$ is $1$-Lipschitz, and $\mathrm{p}\_{K^{r}}(S)=\partial K^{r}$. Using
the same argument as above, we have:

|  |  |  |
| --- | --- | --- |
|  | $\mathrm{Cov}\left(\partial K^{r},\eta\right)\leqslant\mathrm{Cov}(S,\eta)\leqslant C(d)\cdot(\diam(K)/\eta)^{d-1}.$ |  |

Combining these bounds with the inclusion $U\subseteq\mathcal{U}(K)$ gives us

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathrm{Cov}(U,\varepsilon)\leqslant\frac{C(d,\diam(K))}{\varepsilon^{d-1}}.$ |  | (3.16) |

Step 2. We now establish a lower bound for
$\mathrm{Pack}(U,2\varepsilon)$. Let $x$ be a $\tau$-singular point and $u,v$ be
two unit vectors such that $\langle u\mid v\rangle^{2}\leqslant 1-\tau^{2}$. This
implies that $\mathcal{N}\_{x}K\cap\mathbb{S}^{d-1}$ contains a spherical geodesic
segment of length at least $C\cdot\tau$, giving us a lower bound on
the packing number of $\mathcal{N}\_{x}K\cap\mathbb{S}^{d-1}$, namely $\mathrm{Pack}(\mathcal{N}\_{x}K\cap\mathbb{S}^{d-1},\eta)\geqslant C\cdot\tau/\eta$. Now, let $X$ be a maximal set in the
definition of the packing number $\mathrm{Pack}(\mathrm{Sing}(K,\tau),2\varepsilon)$
and for every $x\in X$, let $Y\_{x}$ be a maximal set in the definition
of the packing number $\mathrm{Pack}(\mathcal{N}\_{x}(K)\cap\mathbb{S}^{d-1},2\varepsilon)$, so that $\Card(Y\_{x})\geqslant C\cdot\tau/\varepsilon$. Then, the set $Z:=\{(x,y)\mid x\in X,~y\in Y\_{x}\}$
is a $2\varepsilon$ packing of $U$, and the cardinality of this set is
bounded from below by $C\cdot\Card(X)\cdot\tau/\varepsilon$. This
gives

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathrm{Pack}(U,2\varepsilon)\geqslant C\cdot\mathrm{Pack}(\mathrm{Sing}(K,\tau),2\varepsilon)\cdot\tau/\varepsilon.$ |  | (3.17) |

Step 3.
Combining Equations ([3.16](#S3.E16 "In Proof of Proposition . ‣ 3.3. A control on the (𝑑-2)–Hausdorff measure of singular points ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), ([3.17](#S3.E17 "In Proof of Proposition . ‣ 3.3. A control on the (𝑑-2)–Hausdorff measure of singular points ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and the
comparison between packing and covering numbers
([3.15](#S3.E15 "In 3.3. A control on the (𝑑-2)–Hausdorff measure of singular points ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), we get

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathrm{Pack}(\mathrm{Sing}(K,\tau),2\varepsilon)$ | $\displaystyle\leqslant\frac{C(d,\diam(K))}{\tau\varepsilon^{d-2}}.$ |  |

Using the comparison between packing and covering numbers, this means
that we can cover $\mathrm{Sing}(K,\tau)$ with $N\_{\varepsilon}$ balls of radius
$\varepsilon$, such that $N\_{\varepsilon}\leqslant C(d,\diam(K))/(\tau\varepsilon^{d-2})$. By definition of the Hausdorff measure, we have

|  |  |  |
| --- | --- | --- |
|  | $\mathcal{H}^{d-2}(\mathrm{Sing}(K,\tau))\leqslant\liminf\_{\varepsilon\to 0}N\_{\varepsilon}\varepsilon^{d-2}\leqslant C(d,\diam(K))\frac{1}{\tau}.\qed$ |  |

###### Proof of Proposition [3.2](#S3.Thmtheorem2 "Proposition 3.2. ‣ 3.3. A control on the (𝑑-2)–Hausdorff measure of singular points ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

Given $\left\|\bm{\lambda}\right\|\_{\infty}\leqslant T\_{tr}$, the transversality condition ([T](#S3.Ex24 "In Definition 3.2 (Transversality). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) implies

|  |  |  |
| --- | --- | --- |
|  | $\forall x\in\Sigma(\bm{\lambda}),~~\exists u,v\in\mathcal{N}\_{x}K(\bm{\lambda}),~~\left(\frac{\langle u\mid v\rangle}{\left\|u\right\|\left\|v\right\|}\right)^{2}\leqslant 1-\varepsilon\_{tr}^{2},$ |  |

where $\mathcal{N}\_{x}K(\bm{\lambda})$ is the
normal cone to the convex set $K(\bm{\lambda})$ at $x$ (see
([3.13](#S3.E13 "In Definition 3.1 (Normal cone). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))). This implies that $\Sigma(\bm{\lambda})$ is
included in the set $\mathrm{Sing}(K(\bm{\lambda}),\varepsilon\_{tr})$ of
$\tau$-singular points
with $\tau=\varepsilon\_{tr}$. The conclusion then follows from
Proposition [3.3](#S3.Thmtheorem3 "Proposition 3.3. ‣ 3.3. A control on the (𝑑-2)–Hausdorff measure of singular points ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").
∎

## 4. $\mathcal{C}^{2,\alpha}$ regularity of Kantorovich’s functional

This section is devoted to the proof of the following regularity result. Recall that the conditions ([Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), and ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) are defined in the introduction, respectively on pages [Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), [Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), and [QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

###### Theorem 4.1.

Assume ([Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), and ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Let $X$ be
a compact, $c$-convex subset of $\Omega$ and $\rho$ in
$\mathcal{P}^{\mathrm{ac}}(X)\cap\mathcal{C}^{0,\alpha}(X)$ for $\alpha$ in $(0,1]$. Then,
the Kantorovich’s functional $\Phi$ is uniformly $\mathcal{C}^{2,\alpha}$ on the
set

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{K}^{\varepsilon}:=\{\psi:Y\to\mathbb{R}\mid\forall y\in Y,~\rho(\Lag\_{y}(\psi))>\varepsilon\}$ |  | (4.18) |

and its Hessian is given by ([1.8](#S1.E8 "In Theorem 1.3. ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). In addition,
the $\mathcal{C}^{2,\alpha}$ norm of the restriction of $\Phi$ to
$\mathcal{K}^{\varepsilon}$ depends only on $\left\|\rho\right\|\_{\infty}$, $\varepsilon$, $\diam(X)$,
and the constants defined in Remark [4.1](#S4.Thmremark1 "Remark 4.1 (Constants). ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") below.

For the remainder of the section, for any point $y$ in $Y$, we will
denote $X\_{y}=(\exp\_{y}^{c})^{-1}(X)\subseteq\mathbb{R}^{d}$ the inverse image of
the domain $X$ in the exponential chart at $y$. The set $X\_{y}$ is
convex by $c$-concavity of $X$. We consider the functions

|  |  |  |
| --- | --- | --- |
|  | $f\_{z,y}:p\in X\_{y}\mapsto c(\exp\_{y}^{c}(p),y)-c(\exp\_{y}^{c}(p),z),$ |  |

which are quasi-concave by ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). The main difficulty in deducing Theorem [4.1](#S4.Thmtheorem1 "Theorem 4.1. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") from
Theorem [3.1](#S3.Thmtheorem1 "Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") is in establishing the quantitative
transversality condition ([T](#S3.Ex24 "In Definition 3.2 (Transversality). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) introduced on p. [T](#S3.Ex24 "In Definition 3.2 (Transversality). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") for the family of functions
$(f\_{z,y})\_{z\in Y\setminus\{y\}}$.

###### Remark 4.1 (Constants).

The $\mathcal{C}^{2,\alpha}$
norm of the restriction of $\Phi$ to $\mathcal{K}^{\varepsilon}$ explicitely
depends on the following constants, whose finiteness (or positivity)
follows from the compactness of the domain $X$, from the finiteness
of the set $Y$ and from the conditions ([Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")),
([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), and ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\varepsilon\_{tw}$ | $\displaystyle:=\min\_{x\in X}\min\_{y,z\in Y\atop{y\neq z}}\left\|D\_{x}c(x,y)-D\_{c}(x,z)\right\|\_{g}>0$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle C\_{\nabla}$ | $\displaystyle:=\max\_{(x,y)\in X\times Y}\left\|D\_{x}c(x,y)\right\|\_{g}<+\infty$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle C\_{\mathrm{exp}}$ | $\displaystyle:=\max\_{y\in Y}\max\left\{\left\|\exp\_{y}^{c}\right\|\_{\Lip(X\_{y})},\left\|(\exp\_{y}^{c})^{-1}\right\|\_{\Lip(X)}\right\}<+\infty,$ |  | (4.19) |

where we recall that $X\_{y}:=\exp\_{y}^{-1}(X)$.
Our estimates will also rely on the following constants involving the
differential of the exponential maps. As before, the tangent spaces
$\mathrm{T}\_{x}\Omega$ are endowed with the Riemannian metric $g$ from
$\Omega$. We set:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle C\_{\mathrm{cond}}$ | $\displaystyle:=\max\_{y\in Y}\max\_{p\in X\_{y}}\cond(\left.\mathrm{D}\exp\_{y}^{c}\right|\_{p}),$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle C\_{\mathrm{det}}$ | $\displaystyle:=\max\_{y\in Y}\left\|\det(\mathrm{D}\exp\_{y}^{c})\right\|\_{\Lip(X\_{y})},$ |  |

where $\cond(A)$ is the condition number of a linear transform
$A$ between finite dimensional normed spaces and $\det(A)$ is the determinant of $A$ with
respect to orthornormal bases. The quantitative transversality
estimates involve all the above constants in an explicit way, see ([4.31](#S4.E31 "In 4.3. Proof of Theorem ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")).

###### Remark 4.2.

Even in the Euclidean case, one needs a lower bound on the volume of
Laguerre cells in order to establish the second-differentiability of
the functional $\Phi$. Indeed, let $y\_{\pm}=\pm 1$, let $y\_{0}=0$,
$Y=\{y\_{-},y\_{0},y\_{+}\}\subseteq\mathbb{R}$. Consider the cost
$c(x,y)=-xy$, and the density $\rho=1$ on
$X=[-\frac{1}{2},\frac{1}{2}]$. Let $\varphi\_{\tau}\in\mathbb{R}^{Y}$ be
defined by $\varphi(y\_{\pm})=1/2$ and $\varphi(y\_{0})=\tau$. A simple
calculation gives, for $\tau\geqslant 0$,

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\frac{\partial\Phi}{\partial\mathbbold{1}\_{y\_{0}}}(\psi\_{\tau})=\max(1-2\tau,0),$ |  |

which is not differentiable at $\tau=1/2$, even though ([Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")),
([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), and ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) are all satisfied.

Outline. In Section [4.1](#S4.SS1 "4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), we
establish a part of the transversality condition using elementary
properties of convex sets
(Proposition [4.2](#S4.Thmtheorem2 "Proposition 4.2. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). We establish
in Section [4.2](#S4.SS2 "4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") a second transversality condition
using additional assumptions and proceed in
Section [4.3](#S4.SS3 "4.3. Proof of Theorem ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") to the proof of Theorem
[4.1](#S4.Thmtheorem1 "Theorem 4.1. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"). In Section
[4.4](#S4.SS4 "4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), we propose an alternative
transversality estimate when $Y$ is a sample subset of a target domain
$\Omega^{\prime}$ (Proposition [4.8](#S4.Thmtheorem8 "Proposition 4.8. ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")).

### 4.1. Lower transversality estimates

Next, we undertake a series of proofs to obtain explicit constants in
the transversality estimate ([T](#S3.Ex24 "In Definition 3.2 (Transversality). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), which depend on the choices
of cost, domains, and dimension. Consider the Laguerre cell of a point
$y$ in $Y$ in its own exponential chart, that is

|  |  |  |
| --- | --- | --- |
|  | $L\_{y}(\psi):=(\exp\_{y}^{c})^{-1}(\Lag\_{y}(\psi))=\{p\in X\_{y}\mid f\_{z,y}(p)\leqslant\psi(z)-\psi(y)\}.$ |  |

The set $L\_{y}(\psi)$ is the
intersection of sublevel sets of the functions $f\_{z,y}$, and is
therefore a convex subset of $X\_{y}$ by condition ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")).
The first proposition establishes that two unit outer normals to $L\_{y}$
with the same basepoint cannot be near-opposite. Recall the definition
of the normal cone from ([3.13](#S3.E13 "In Definition 3.1 (Normal cone). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")).

###### Proposition 4.2.

Assume that $\psi$ lies in $\mathcal{K}^{\varepsilon/2}$ (see
([4.18](#S4.E18 "In Theorem 4.1. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))). For any $y$ in $Y$, any point $p$ in $\partial L\_{y}(\psi)$ and any unit normal vectors $v,w\in\mathcal{N}\_{p}L\_{y}(\psi)$
one has

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\langle v\mid w\rangle\geqslant-1+\delta\_{0}^{2},$ |  | (4.20) |

where $\delta\_{0}:=\varepsilon/(2^{d-1}\left\|\rho\right\|\_{\infty}{C\_{\mathrm{exp}}}^{2d}\diam{(X)}^{d})\leqslant 1$.

The proof of this proposition follows from a general lemma about
convex sets. By convexity ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), the set $L\_{y}(\psi)$ is
contained in an intersection of two half-spaces with outward normals
$v$ and $w$ at $p$, giving an upper bound on its volume in term of its
diameter and the angle between $v$ and $w$ (see
Figure [2](#S4.F2 "Figure 2 ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). On the other hand, we know that the volume of
$L\_{y}(\psi)$ is bounded from below by a constant depending on $\varepsilon$. Comparing
these bounds will give us the one-sided estimate
([4.20](#S4.E20 "In Proposition 4.2. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")).

###### Lemma 4.3.

Let $K$ be a bounded convex set of $\mathbb{R}^{d}$, let $p$ be a boundary
point of $K$ and $v,w$ be two unit (outward) normal vectors to $K$
at $p$. Then,

|  |  |  |
| --- | --- | --- |
|  | $-1+\delta^{2}\_{K}\leqslant\langle v\mid w\rangle\hbox{ where }\delta\_{K}=\frac{\mathcal{H}^{d}(K)}{2^{d-2}\diam(K)^{d}}\leqslant 1.$ |  |

Figure 2.  Bound on the volume of a convex set $K$ as
a function of the angle between two normal vectors $v,w$ at the
same point and its diameter (see Lemma [4.3](#S4.Thmtheorem3 "Lemma 4.3. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")).

###### Proof.

The left-hand side of the inequality is non-positive, so the
inequality needs only to be proven when $\langle v\mid w\rangle\leqslant 0$, which we
assume from now on. Making a rotation of axes and a translation if
necessary, we assume that $p$ lies at the orign and that the unit
vectors span the first two coordinates of $\mathbb{R}^{d}$. Then, letting
$H:=\{p\mid\langle p\mid v\rangle\leqslant 0\}$, $H^{\prime}:=\{p\mid\langle p\mid w\rangle\leqslant 0\}$
and $D$ be the two-dimensional disc centered at $0$ of radius
$\diam(K)$, one has

|  |  |  |
| --- | --- | --- |
|  | $K\subseteq H\cap H^{\prime}\cap(D\times[-\diam(K),\diam(K)]^{d-2}).$ |  |

The intersection $H\cap H^{\prime}\cap D$ is an angular sector of the disc
$D$, whose angle is equal to $\theta:=\pi-\arccos(\langle v\mid w\rangle)$ (see Figure [2](#S4.F2 "Figure 2 ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Therefore, we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{H}^{d}(K)$ | $\displaystyle\leqslant\mathcal{H}^{d}(H\cap H^{\prime}\cap(D\times[-\diam(K),\diam(K)]^{d-2}))$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant 2^{d-2}\diam(K)^{d}\tan(\theta/2).$ |  | (4.21) |

Using the expression of $\cos(\theta)$ in term of $\tan(\theta/2)$ and
recalling $\langle v\mid w\rangle\leqslant 0$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\tan(\theta/2)=\sqrt{\frac{1+\langle v\mid w\rangle}{1-\langle v\mid w\rangle}}\leqslant\sqrt{1+\langle v\mid w\rangle}$ |  | (4.22) |

The lemma follows directly from Equations
([4.21](#S4.E21 "In Proof. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))–([4.22](#S4.E22 "In Proof. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")).
∎

###### Proof of Proposition [4.2](#S4.Thmtheorem2 "Proposition 4.2. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

By definition of the bi-Lipschitz constant $C\_{\mathrm{exp}}$,

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\mathcal{H}^{d}(L\_{y}(\psi))\geqslant\varepsilon/(2C\_{\mathrm{exp}}^{d}\left\|\rho\right\|\_{\infty})\hbox{ and }\diam(L\_{y}(\psi))\leqslant C\_{\mathrm{exp}}\diam(X).$ |  |

Applying the above lemma to the two outward normals $v,w$ at $p$, we get

|  |  |  |
| --- | --- | --- |
|  | $\langle v\mid w\rangle+1\geqslant\frac{\mathcal{H}^{d}(L\_{y}(\psi))^{2}}{4^{d-2}\diam(L\_{y}(\psi))^{2d}}\geqslant\frac{\varepsilon^{2}}{4^{d-1}C\_{\mathrm{exp}}^{4d}\left\|\rho\right\|\_{\infty}^{2}\diam(X)^{2d}}.\qed$ |  |

We also record the following lemma for later use.

###### Lemma 4.4.

Let $y$ in $Y$ and let $p$ in be a point of $L\_{y}(\psi)$ such that
for some $z\neq y$,  $f\_{z,y}(p)=\psi(z)-\psi(y)$. Then, the
point $p^{\prime}:=(\exp\_{z}^{c})^{-1}(\exp\_{y}^{c}(p))$ belongs to $L\_{z}(\psi)$ and the vector
$\nabla f\_{y,z}(p)$ lies in the normal cone $\mathcal{N}\_{p^{\prime}}L\_{z}(\psi)$.

###### Proof.

We introduce the point $x=\exp\_{y}^{c}(p)$. The hypothesis is
equivalent to $c(x,y)+\psi(y)=c(x,z)+\psi(z).$ Since $p$
belongs to $L\_{y}(\psi)$, the point $x$ belongs to $\Lag\_{y}(\psi)$. Then, for any $z^{\prime}\in Y$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle c(x,z)+\psi(z)$ | $\displaystyle=c(x,y)+\psi(y)\leqslant c(x,z^{\prime})+\psi(z^{\prime})$ |  |

thus establishing that $x$ belongs to $\Lag\_{z}(\psi)$ or equivalently $p^{\prime}\in L\_{z}(\psi)$.
∎

### 4.2. Upper transversality estimates.

We now turn to the proof of the quantitative transversality
estimates. We begin with a bound which involves the condition
number of differential of exponential maps, see
Remark [4.1](#S4.Thmremark1 "Remark 4.1 (Constants). ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"). The advantage of this first bound is that
we do not have to assume that the points in $Y$ are sampled from a
continuous domain. A second transversality estimate is presented in
§[4.4](#S4.SS4 "4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

#### Notation.

We introduce notation that will be used in throughout this section. We
fix a point $y\_{0}$ in $Y$ and also fix an arbitrary ordering of the
remaining points, so that $Y=\{y\_{0},y\_{1},\ldots,y\_{N}\}$. We
define $\hat{X}:=X\_{y\_{0}}$ and for every index $i\in\{1,\ldots,N\}$ we put

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle f\_{i}:=f\_{y\_{i},y\_{0}}:p\in\hat{X}$ | $\displaystyle\mapsto c(\exp\_{y\_{0}}^{c}(p),y\_{0})-c(\exp\_{y\_{0}}^{c}(p),y\_{i}).$ |  |

By the ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) condition, these functions $f\_{1},\ldots,f\_{N}$
satisfy the non-degeneracy condition ([ND](#S3.Ex23 "In Non-degeneracy ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), and we have the
following inequalities:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\varepsilon\_{nd}:=\min\_{i,j\neq 0}\min\_{p\in X\_{y\_{0}}}\left\|\nabla f\_{i}(p)-\nabla f\_{j}(p)\right\|\geqslant C\_{\mathrm{exp}}^{-1}\varepsilon\_{tw}>0,$ |  | (4.23) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\sup\_{i\neq 0}\sup\_{p\in X\_{y\_{0}}}\left\|\nabla f\_{i}(p)\right\|\leqslant C\_{\mathrm{exp}}C\_{\nabla}.$ |  | (4.24) |

To any function $\psi:Y\to\mathbb{R}$ we associate the vector

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\bm{\lambda}\_{\psi}:$ | $\displaystyle=(\psi(y\_{1})-\psi(y\_{0}),\ldots,\psi(y\_{N})-\psi(y\_{0}))\in\mathbb{R}^{N}.$ |  | (4.25) |

We also consider the same family of convex set as in
Section [3](#S3 "3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"):

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle K(\bm{\lambda})=\{p\in\hat{X}\mid\forall 1\leqslant i\leqslant N,f\_{i}(p)\leqslant\lambda\_{i}\},$ |  |

so that $K(\bm{\lambda}\_{\psi})=(\exp\_{y\_{0}}^{c})^{-1}(\Lag\_{y\_{0}}(\psi))$.

###### Proposition 4.5.

Assume that $\bm{\lambda}:=\bm{\lambda}\_{\psi}$ where $\psi$ belongs
to $\mathcal{K}^{\varepsilon/2}$ and let $p$ be a point in $K(\bm{\lambda})$. Then,

Case I:
:   If $f\_{i}(p)=\lambda\_{i}$ and $f\_{j}(p)=\lambda\_{j}$ for $i\neq j$ in $\{1,\ldots,N\}$, then

    |  |  |  |  |
    | --- | --- | --- | --- |
    |  | $\left(\frac{\langle\nabla f\_{i}(p)\mid\nabla f\_{j}(p)\rangle}{\left\|\nabla f\_{i}(p)\right\|\left\|\nabla f\_{j}(p)\right\|}\right)^{2}\leqslant 1-\delta\_{1}^{2}.$ |  | (4.26) |

Case II:
:   If $p\in\partial\hat{X}$ and if
    $f\_{i}(p)=\lambda\_{i}$ for some $i$ in $\{1,\ldots,N\}$, then

    |  |  |  |  |
    | --- | --- | --- | --- |
    |  | $\forall w\in\mathcal{N}\_{p}\hat{X},~~\left(\frac{\langle\nabla f\_{i}(p)\mid w\rangle}{\left\|\nabla f\_{i}(p)\right\|\left\|w\right\|}\right)^{2}\leqslant 1-\delta\_{1}^{2}.$ |  | (4.27) |

In the above inequalities,

|  |  |  |
| --- | --- | --- |
|  | $\delta\_{1}:=\frac{\varepsilon\_{nd}\delta\_{0}}{2C\_{\mathrm{exp}}C\_{\nabla}C\_{\mathrm{cond}}^{2}}.$ |  |

By assumption, all the Laguerre cells associated to $\psi$ contain a
mass of at least $\varepsilon/2$. This allows us to apply
Proposition [4.2](#S4.Thmtheorem2 "Proposition 4.2. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), ensuring that normal
vectors cannot be near-opposite, to all the Laguerre cells in their
exponential charts. We denote $L\_{i}:=L\_{y\_{i}}(\psi)=(\exp\_{y\_{i}}^{c})^{-1}(\Lag\_{y\_{i}}(\psi))$ for brevity.

The proposition also relies on two simple lemmas. The first lemma
shows the effect of a diffeomorphism on the normal cone to a convex
set, when its image is also convex.

###### Lemma 4.6.

Let $K\subset\mathbb{R}^{d}$ be a compact, convex set, $F$ be a $\mathcal{C}^{1}$
diffeomorphism from an open neighborhood of $K$ to an open subset of
$\mathbb{R}^{d}$, and assume that $F(K)$ is also a convex set. Then, for
any point $x$ in $\partial K$ one has

|  |  |  |
| --- | --- | --- |
|  | $\mathcal{N}\_{F(x)}(F(K))=[\mathrm{D}F^{-1}\_{F(x)}]^{\*}(\mathcal{N}\_{x}K),$ |  |

where $A^{\*}$ denotes the adjoint of $A$.

###### Proof.

Consider $x$ in $\partial K$, $v\in\mathcal{N}\_{x}K$, and define
$\varphi(z):=\langle F^{-1}(z)-x\mid v\rangle$. Since $v$ is an outer normal to $K$
at $x$, the restriction of $\varphi$ to the set $F(K)$ is
non-positive. Since $F(K)$ is convex, for any point $y\in K$, $F(K)$
contains the segment $[F(x),F(y)]$. We therefore have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle 0$ | $\displaystyle\geqslant\varphi((1-t)F(x)+tF(y))$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\geqslant\varphi(F(x))+t\langle\nabla\varphi(F(x))\mid F(y)-F(x)\rangle-o(t)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=t\langle[\mathrm{D}F^{-1}\_{F(x)}]^{\*}(v)\mid F(y)-F(x)\rangle-o(t).$ |  |

where we have used $\varphi(F(x))=0$ and $\nabla\varphi(F(x))=[\mathrm{D}F^{-1}\_{F(x)}]^{\*}(v)$ to obtain the equality at the end. Dividing by $t$ and
taking the limit as $t$ goes to zero, we see that

|  |  |  |
| --- | --- | --- |
|  | $\forall y\in K,~~\langle[\mathrm{D}F^{-1}\_{F(x)}]^{\*}(v)\mid F(y)-F(x)\rangle\leqslant 0,$ |  |

thus
showing that $[\mathrm{D}F^{-1}\_{F(x)}]^{\*}(v)$ belongs to the normal
cone to $F(K)$ at $F(x)$. The converse inclusion follows from
the symmetry of the problem.
∎

The second lemma compares the angle between two vectors and the angle
between their image under a linear map, using the generalized
Wiedlandt inequality (see [[17](#bib.bib17), Section 3.4]). We
identify $\mathbb{R}^{d}$ with its tangent and cotangent spaces through the
Euclidean structure. We denote the adjoint of the derivative of the
exponential map $\exp^{c}\_{y}$ at a point $p$ in $X\_{y}$ by

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle(\mathrm{D}\exp^{c}\_{y\_{i}})^{\*}|\_{p}:\mathrm{T}^{\*}\_{\exp^{c}\_{y\_{i}}(p)}\Omega\to\mathrm{T}^{\*}\_{p}\mathbb{R}^{d}\cong\mathbb{R}^{d},$ |  |

###### Lemma 4.7.

Let $y\_{k}\neq y\_{\ell}\in Y$, let $x$ be a point in $X$ and set $p\_{k}:=(\exp\_{y\_{k}}^{c})^{-1}(x)$ and $p\_{\ell}:=(\exp\_{y\_{\ell}}^{c})^{-1}(x)$ and

|  |  |  |
| --- | --- | --- |
|  | $A=(\mathrm{D}\exp^{c}\_{y\_{k}}|\_{p\_{k}})^{\*}\circ[(\mathrm{D}\exp^{c}\_{y\_{l}}|\_{p\_{l}})^{\*}]^{-1}:\mathrm{T}\_{p\_{\ell}}^{\*}\mathbb{R}^{d}\to\mathrm{T}\_{p\_{k}}^{\*}\mathbb{R}^{d}.$ |  |

Then, the following inequalities hold for all $v$, $w$ in $\mathbb{R}^{d}$:

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle C\_{\mathrm{cond}}^{-4}\left(1+\frac{\langle v\mid w\rangle}{\left\|v\right\|\left\|w\right\|}\right)\leqslant 1+\frac{\langle Av\mid Aw\rangle}{\left\|Av\right\|\left\|Aw\right\|}\leqslant C\_{\mathrm{cond}}^{4}\left(1+\frac{\langle v\mid w\rangle}{\left\|v\right\|\left\|w\right\|}\right).$ |  |

###### Proof.

Indeed, let $\theta$ be the angle between $v$ and $w$ and $\theta^{\prime}$ be
the angle between $Av$ and $Aw$, both in the interval $(0,\pi)$. Let
$t:=\tan(\theta/2)$, $t^{\prime}:=\tan(\theta^{\prime}/2)$. The generalized Wiedlandt
inequality in [[17](#bib.bib17), Section 3.4] asserts $(1/\cond(A))t\leqslant t^{\prime}\leqslant\cond(A)t$. Expressing $\cos(\theta)$ in term of $t=\tan(\theta/2)$,

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle 1+\cos(\theta^{\prime})=1+\frac{1-t^{\prime 2}}{1+t^{\prime 2}}=\frac{2}{1+t^{\prime 2}}\leqslant\cond(A)^{2}(1+\cos(\theta))$ |  |

We conclude the second inequality above by using $\cond(A\_{2}^{\*}[A\_{1}^{\*}]^{-1})\leqslant\cond(A\_{1})\cond(A\_{2})$ and the definition of the constant
$C\_{\mathrm{cond}}$. For the first inequality, simply note that $\cond(A^{-1})=\cond(A)$.
∎

###### Proof of Proposition [4.5](#S4.Thmtheorem5 "Proposition 4.5. ‣ Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), case I.

We let

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle V:$ | $\displaystyle=\nabla f\_{i}(p)=\nabla f\_{y\_{i},y\_{0}}(p),$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle W:$ | $\displaystyle=\nabla f\_{j}(p)=\nabla f\_{y\_{j},y\_{0}}(p),$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle v:$ | $\displaystyle=\frac{V}{\left\|V\right\|},\quad w:=\frac{W}{\left\|W\right\|}.$ |  |

Switching the indices $i$ and $j$ if necessary, we
assume that $\left\|V\right\|\leqslant\left\|W\right\|$. The proof depends on the sign of
$\langle W-V\mid V\rangle$ (see Remark [4.3](#S4.Thmremark3 "Remark 4.3. ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") below for the significance of the sign of this expression). Assume first $\langle W-V\mid V\rangle\leqslant 0$, and
let $\alpha\_{v}:=1/\left\|V\right\|,\alpha\_{w}:=1/\left\|W\right\|$. Then,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle 1-\langle v\mid w\rangle$ | $\displaystyle=\frac{1}{2}\left\|v-w\right\|^{2}=\frac{1}{2}\left\|\alpha\_{w}(W-V)-(\alpha\_{v}-\alpha\_{w})V\right\|^{2}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\frac{1}{2}\alpha\_{w}^{2}\left\|W-V\right\|^{2}+\frac{1}{2}(\alpha\_{v}-\alpha\_{w})^{2}\left\|V\right\|^{2}-\alpha\_{w}(\alpha\_{v}-\alpha\_{w})\langle W-V\mid V\rangle$ |  |

Using $\alpha\_{w}\leqslant\alpha\_{v}$, and $\left\|W-V\right\|\geqslant\varepsilon\_{nd}$ we
end up with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle 1-\langle v\mid w\rangle^{2}$ | $\displaystyle\geqslant 1-\langle v\mid w\rangle\geqslant\frac{1}{2}\alpha\_{w}^{2}\left\|W-V\right\|^{2}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\geqslant\frac{1}{2}\frac{\varepsilon\_{nd}^{2}}{C\_{\mathrm{exp}}^{2}C\_{\nabla}^{2}}\geqslant\frac{\varepsilon\_{nd}^{2}\delta\_{0}^{2}}{4C\_{\mathrm{exp}}^{2}C\_{\nabla}^{2}C\_{\mathrm{cond}}^{4}}=\delta\_{1}^{2}$ |  |

where we have used ([4.23](#S4.E23 "In Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and
([4.24](#S4.E24 "In Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), $\delta\_{0}\leqslant 1$ and $C\_{\mathrm{cond}}\geqslant 1$. This
establishes the desired bound when $\langle v\mid w\rangle\in[0,1]$. In the
case $\langle v\mid w\rangle\in[-1,0]$, we can apply
Proposition [4.2](#S4.Thmtheorem2 "Proposition 4.2. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") to show that
$1-\langle v\mid w\rangle^{2}\geqslant 1+\langle v\mid w\rangle\geqslant\delta\_{0}^{2}\geqslant\delta\_{1}^{2},$
thus establishing the desired bound.

Now suppose $\langle W-V\mid V\rangle\geqslant 0$. A slightly tedious computation
gives

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\langle v\mid w\rangle^{2}$ | $\displaystyle=1-\frac{\left\|W-V\right\|^{2}}{\left\|W\right\|^{2}}+\frac{\langle W-V\mid v\rangle^{2}}{\left\|W\right\|^{2}}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=1-\frac{\left\|W-V\right\|^{2}}{\left\|W\right\|^{2}}\left(1-\frac{\langle W-V\mid v\rangle^{2}}{\left\|W-V\right\|^{2}}\right)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant 1-\frac{\varepsilon\_{nd}^{2}}{C\_{\mathrm{exp}}^{2}C\_{\nabla}^{2}}\left(1-\langle\frac{W-V}{\left\|W-V\right\|}\mid v\rangle\right),$ |  | (4.28) |

where we have used $\langle W-V\mid V\rangle\geqslant 0$ with ([4.23](#S4.E23 "In Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([4.24](#S4.E24 "In Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) to get the last inequality. We will now apply Proposition
[4.2](#S4.Thmtheorem2 "Proposition 4.2. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") to the Laguerre cell $L\_{i}$. By
Lemma [4.4](#S4.Thmtheorem4 "Lemma 4.4. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), the point $p\_{i}:=(\exp\_{y\_{i}}^{c})^{-1}(\exp\_{y\_{0}}^{c}(p))\in X\_{y\_{i}}$ belong to
$L\_{i}$ and the vectors $V\_{i}:=\nabla f\_{y\_{0},y\_{i}}(p\_{i})$ and $W\_{i}:=\nabla f\_{y\_{j},y\_{i}}(p\_{i})$ are both normals to $L\_{i}$ at
$p\_{i}$. Proposition [4.2](#S4.Thmtheorem2 "Proposition 4.2. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") then shows that the
vectors $V\_{i}$ and $W\_{i}$ satisfy

|  |  |  |  |
| --- | --- | --- | --- |
|  | $-1+\delta\_{0}^{2}\leqslant\frac{\langle V\_{i}\mid W\_{i}\rangle}{\left\|V\_{i}\right\|\left\|W\_{i}\right\|}.$ |  | (4.29) |

We transfer this inequality to the exponential chart of the original
point $y\_{0}$ using the linear map

|  |  |  |
| --- | --- | --- |
|  | $A:=(\left.\mathrm{D}\exp\_{y\_{0}}^{c}\right|\_{p})^{\*}\circ[(\left.\mathrm{D}\exp\_{y\_{i}}^{c}\right|\_{p\_{i}})^{\*}]^{-1}.$ |  |

First, note that $W-V=AW\_{i}$ and
$V=-AV\_{i}.$ Applying the generalized Wiedlandt inequality
(Lemma [4.7](#S4.Thmtheorem7 "Lemma 4.7. ‣ Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([4.29](#S4.E29 "In Proof of Proposition , case I. ‣ Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle 1-\frac{\langle W-V\mid v\rangle}{\left\|W-V\right\|}=1+\frac{\langle AW\_{i}\mid AV\_{i}\rangle}{\left\|AW\_{i}\right\|{\left\|AV\_{i}\right\|}}$ | $\displaystyle\geqslant C\_{\mathrm{cond}}^{-4}\left(1+\frac{\langle V\_{i}\mid W\_{i}\rangle}{\left\|V\_{i}\right\|\left\|W\_{i}\right\|}\right)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\geqslant C\_{\mathrm{cond}}^{-4}\delta\_{0}^{2}\geqslant\delta\_{1}^{2}.$ |  | (4.30) |

Combining this inequality with ([4.28](#S4.E28 "In Proof of Proposition , case I. ‣ Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) we obtain
([4.26](#S4.E26 "In item Case I ‣ Proposition 4.5. ‣ Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) in this case as well.
∎

###### Proof of Proposition [4.5](#S4.Thmtheorem5 "Proposition 4.5. ‣ Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), case II.

Consider $V:=\nabla f\_{i}(p)$ and let $W$ be any vector in the
normal cone $\mathcal{N}\_{p}\hat{X}$. When $\langle V\mid W\rangle\leqslant 0$, the
inequality directly follows from
Proposition [4.2](#S4.Thmtheorem2 "Proposition 4.2. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), ensuring that normal
vectors cannot be near-opposite. We now assume $\langle V\mid W\rangle\geqslant 0$
and we will apply Proposition [4.2](#S4.Thmtheorem2 "Proposition 4.2. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") to the
Laguerre cell of $y\_{i}$ and transfer the result to the exponential
chart of the point $y\_{0}$. Let $p\_{i}=(\exp\_{y\_{i}}^{c})^{-1}(\exp\_{y}^{c}(p))$. Then, by
Lemma [4.4](#S4.Thmtheorem4 "Lemma 4.4. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), $p\_{i}$ belongs to $L\_{i}$ and $V\_{i}:=\nabla f\_{y\_{0},y\_{i}}(p\_{i})$ is a normal vector to $L\_{i}$ at $p\_{i}$. We
define a second normal vector by considering

|  |  |  |
| --- | --- | --- |
|  | $A:=(\left.\mathrm{D}\exp\_{y\_{0}}^{c}\right|\_{p\_{0}})^{\*}\circ[(\left.\mathrm{D}\exp\_{y\_{i}}^{c}\right|\_{p\_{i}})^{\*}]^{-1}$ |  |

and by setting $W\_{i}:=A^{-1}W\in\mathrm{T}^{\*}\_{p\_{i}}\mathbb{R}^{d}$. By
Lemma [4.6](#S4.Thmtheorem6 "Lemma 4.6. ‣ Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), the vector $W\_{i}$ belongs to
the normal cone to $X\_{y\_{i}}$ at $p\_{i}$. Moreover, since $L\_{i}$ is
contained in $X\_{y\_{i}}$ and both sets contain $p\_{i}$, we have $\mathcal{N}\_{p\_{i}}X\_{y\_{i}}\subseteq\mathcal{N}\_{p\_{i}}L\_{i}$, thus ensuring that $W\_{i}$ also belongs
to the normal cone to $L\_{i}$ at $p\_{i}$. Then, by
Proposition [4.2](#S4.Thmtheorem2 "Proposition 4.2. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") again,

|  |  |  |
| --- | --- | --- |
|  | $\frac{\langle V\_{i}\mid W\_{i}\rangle}{\left\|V\_{i}\right\|\left\|W\_{i}\right\|}\geqslant-1+\delta\_{0}^{2}.$ |  |

As
before, we transfer this inequality to the exponential chart of
the original point $y$ using the linear map $A$. We have $V=\nabla f\_{i}(p)=-AV\_{i}$, and by construction $W=AW\_{i}$. We get the
desired inequality by applying Lemma [4.7](#S4.Thmtheorem7 "Lemma 4.7. ‣ Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle 1-\frac{\langle V\mid W\rangle}{\left\|V\right\|\left\|W\right\|}=1+\frac{\langle AV\_{i}\mid AW\_{i}\rangle}{\left\|AV\_{i}\right\|\left\|AW\_{i}\right\|}$ | $\displaystyle\geqslant C\_{\mathrm{cond}}^{-4}\left(1+\frac{\langle V\_{i}\mid W\_{i}\rangle}{\left\|V\_{i}\right\|\left\|W\_{i}\right\|}\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\geqslant C\_{\mathrm{cond}}^{-4}\delta\_{0}^{2}\geqslant\delta\_{1}^{2},$ |  |

and by recalling that $\langle V\mid W\rangle\geqslant 0$.
∎

### 4.3. Proof of Theorem [4.1](#S4.Thmtheorem1 "Theorem 4.1. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")

By Theorem [1.1](#S1.Thmtheorem1 "Theorem 1.1. ‣ 1.3. Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), the second-differentiability of
Kantorovich’s functional $\Phi$ will follow from the differentiability
of the function

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle G\_{y\_{0}}(\psi):=\int\_{\Lag\_{y\_{0}}(\psi)}\rho(x)\mathrm{d}\mathcal{H}^{d}\_{g}(x)=\int\_{L\_{y}(\psi)}\hat{\rho}(p)\mathrm{d}p$ |  |

where we have used the change-of-variable formula with $x=\exp\_{y\_{0}}^{c}(p)$, so that $\hat{\rho}$ is the density of the pushforward
measure $(\exp^{c}\_{y\_{0}})^{-1}\_{\#}(\rho\mathcal{H}^{d}\_{g})$ with respect to the
Lebesgue measure. We recall that

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle K(\bm{\lambda}\_{\psi})=(\exp\_{y\_{0}}^{c})^{-1}(\Lag\_{y\_{0}}(\psi)),$ |  |

so that $G\_{y\_{0}}(\psi)=\hat{G}(\bm{\lambda}\_{\psi})$ (as defined in ([3.12](#S3.E12 "In 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))).
The differentiability
of $\hat{G}$ will be proven using Theorem [3.1](#S3.Thmtheorem1 "Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") from the
previous section.

Let us fix a function $\psi\_{0}$ in $\mathcal{K}^{\varepsilon}$ and recall that
$\bm{\lambda}\_{0}:=\bm{\lambda}\_{\psi\_{0}}$. By
Proposition [2.3](#S2.Thmtheorem3 "Proposition 2.3. ‣ 2. Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") there exists a positive constant $T\_{tr}$
such that every function $\psi$ on $Y$ satisfying $\left\|\psi-\psi\_{0}\right\|\_{\infty}\leqslant T\_{tr}$ belongs to
$\mathcal{K}^{\varepsilon/2}$. Then, by
Proposition [4.5](#S4.Thmtheorem5 "Proposition 4.5. ‣ Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), we see that the functions
$f\_{i}$ satisfy the transversality condition ([T](#S3.Ex24 "In Definition 3.2 (Transversality). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) on the cube
$\bm{\lambda\_{0}}+[-T\_{tr},T\_{tr}]^{N}$ with constant

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\varepsilon\_{tr}=\delta\_{1}=\frac{\varepsilon\_{nd}\delta\_{0}}{2C\_{\mathrm{exp}}C\_{\nabla}C\_{\mathrm{cond}}^{2}},$ |  | (4.31) |

where we recall that $\delta\_{0}=\varepsilon/(2^{d}\left\|\rho\right\|\_{\infty}{C\_{\mathrm{exp}}}^{2d}\diam{(X)}^{d})$. Note also
that since $\rho$ is $\alpha$-Hölder and since the exponential map
is $\mathcal{C}^{1,1}$, the probability density $\hat{\rho}$ is also
$\alpha$-Hölder with constant

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left\|\hat{\rho}\right\|\_{\mathcal{C}^{0,\alpha}(\hat{X})}\leqslant C(\left\|\rho\right\|\_{\mathcal{C}^{0,\alpha}},C\_{\mathrm{det}}).$ |  | (4.32) |

We can now apply Theorem [3.1](#S3.Thmtheorem1 "Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"). This ensures that the
function $\hat{G}$ is of class $\mathcal{C}^{1,\alpha}$ on the cube
$\bm{\lambda\_{0}}+[-T\_{tr},T\_{tr}]^{N}$, so that
$\partial\Phi/\partial\mathbbold{1}\_{y\_{0}}$ is $\mathcal{C}^{1,\alpha}$ on a
neighborhood of $\psi\_{0}$. Since this holds for any point $y\_{0}\in Y$ and
any function $\psi\_{0}$ in $\mathcal{K}^{\varepsilon}$, we have established the
$\mathcal{C}^{2,\alpha}$-regularity of $\Phi$ on $\mathcal{K}^{\varepsilon}$. The
claimed dependency of $\left\|\Phi\right\|\_{\mathcal{C}^{2,\alpha}(\mathcal{K}^{\varepsilon})}$ follows from equations
([4.31](#S4.E31 "In 4.3. Proof of Theorem ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))–([4.32](#S4.E32 "In 4.3. Proof of Theorem ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and from
Theorem [3.1](#S3.Thmtheorem1 "Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

Our goal is now to deduce the formula for the gradient of $G$ given in
Theorem [4.1](#S4.Thmtheorem1 "Theorem 4.1. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") (Equation ([1.8](#S1.E8 "In Theorem 1.3. ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))), from the
formula for the gradient of $\hat{G}$ given in Theorem [3.1](#S3.Thmtheorem1 "Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")
(Equation ([3.14](#S3.E14 "In Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))). This is done by looking more closely at the
change of variable induced by the exponential map $F:=\exp^{c}\_{y\_{0}}:\Omega\to\mathbb{R}^{d}$. For ease of notation we let $h:=c(\cdot,y\_{0})-c(\cdot,y\_{i})\lambda=f\_{i}\circ F^{-1}$. By definition of the push-forward, we have for any
bounded measurable function $\chi$ on $\Omega$,

|  |  |  |
| --- | --- | --- |
|  | $\int\_{\hat{\Omega}}\chi(F(p))\rho(p)\mathrm{d}\mathcal{H}^{d}(p)=\int\_{\Omega}\chi(x)\hat{\rho}(x)\mathrm{d}\mathcal{H}^{d}\_{g}(x).$ |  |

Multiplying $\chi$ by the characteristic function of $h^{-1}([t,s])$, this gives

|  |  |  |
| --- | --- | --- |
|  | $\int\_{f\_{i}^{-1}([t,s])}\chi(F(p))\hat{\rho}(p)\mathrm{d}\mathcal{H}^{d}(p)=\int\_{h^{-1}([t,s])}\chi(x)\rho(x)\mathrm{d}\mathcal{H}^{d}\_{g}(x).$ |  |

Applying the coarea formula on both sides, we get

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\int\_{t}^{s}\int\_{f\_{i}^{-1}(r)}\frac{\chi(F(p))\hat{\rho}(p)}{\left\|\nabla f\_{i}(p)\right\|}\mathrm{d}\mathcal{H}^{d-1}(p)\mathrm{d}r=\int\_{t}^{s}\int\_{h^{-1}(r)}\frac{\chi(x)\rho(x)}{\left\|\nabla h(x)\right\|\_{g}}\mathrm{d}\mathcal{H}^{d-1}\_{g}(x)\mathrm{d}r.$ |  | (4.33) |

Using the
$\mathcal{C}^{1,1}$ smoothness of the functions $f\_{i}$ and the ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))
condition, we can see that for any $\chi$ in $\mathcal{C}^{0}\_{c}(\Omega)$, the
two inner integrals

|  |  |  |
| --- | --- | --- |
|  | $r\mapsto\int\_{f\_{i}^{-1}(r)}\frac{\chi(F(p))\hat{\rho}(p)}{\left\|\nabla f\_{i}(p)\right\|}\mathrm{d}\mathcal{H}^{d-1}(p)\hbox{ and }r\mapsto\int\_{h^{-1}(r)}\frac{\chi(x)\rho(x)}{\left\|\nabla h(x)\right\|\_{g}}\mathrm{d}\mathcal{H}^{d-1}\_{g}(x)$ |  |

depend continuously on $r$. Using the continuity of these functions
in $r$, equation ([4.33](#S4.E33 "In 4.3. Proof of Theorem ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and the Fundamental Theorem of
Calculus, we get that for any function $\chi$ in $\mathcal{C}^{0}\_{c}(\Omega)$
and any $r$ in $\mathbb{R}$,

|  |  |  |
| --- | --- | --- |
|  | $\int\_{f\_{i}^{-1}(r)}\frac{\chi(F(p))\hat{\rho}(p)}{\left\|\nabla f\_{i}(p)\right\|}\mathrm{d}\mathcal{H}^{d-1}(p)=\int\_{h^{-1}(r)}\frac{\chi(x)\rho(x)}{\left\|\nabla h(x)\right\|\_{g}}\mathrm{d}\mathcal{H}^{d-1}\_{g}(x).$ |  |

By
Tietze’s extension theorem, ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), the level set $S:=h^{-1}(r)$ is a $\mathcal{C}^{1,1}$ hypersurface of $\Omega$. Thus
every function in $\mathcal{C}^{0}\_{c}(S)$ can be extended to a function in
$\mathcal{C}^{0}\_{c}(\Omega)$. The previous equality therefore holds for any
$\chi$ in $\mathcal{C}^{0}\_{c}(S)$, and by density, it also holds for any
function $\chi$ in $\mathrm{L}^{1}(S)$. Applying this with $\chi$ equal to the
indicator function of the interface between the Laguerre cell of $y\_{0}$
and the cell of $y\_{i}$, we get the desired formula for the partial
derivatives:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\frac{\partial G\_{i}}{\partial\psi\_{i}}(\psi)=\frac{\partial\hat{G}}{\partial\lambda\_{i}}(\bm{\lambda}\_{\psi})$ | $\displaystyle=\int\_{L\_{y\_{0}}(\psi)\cap f\_{i}^{-1}(\psi(y\_{i})-\psi(y\_{0}))}\frac{\hat{\rho}(p)}{\left\|\nabla f\_{i}(p)\right\|}\mathrm{d}\mathcal{H}^{d-1}(p)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\int\_{\Lag\_{y\_{0}}(\psi)\cap\Lag\_{y\_{i}}(\psi)}\frac{\rho(x)}{\left\|Dc\_{y\_{0}}(x)-Dc\_{y\_{i}}(x)\right\|\_{g}}\mathrm{d}\mathcal{H}\_{g}^{d-1}(x).$ |  |

### 4.4. Alternative upper transversality estimates

Finally, we state an alternate upper transversality estimate, under the assumption that the points in $Y$ are sampled from some *target domain* $\Lambda$, along with some convexity conditions. Specifically, let $\Lambda$ be a bounded, open subset in some Riemannian manifold, with $Y\subset\Lambda$. We then assume that for any $x^{\prime}\in\Omega^{{\rm{cl}}}$, the mapping

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle y$ | $\displaystyle\mapsto-D\_{x}c(x^{\prime},y)$ |  |

is a diffeomorphism onto its range, and we denote the inverse by $\exp^{c}\_{x^{\prime}}$. We will also assume that
$(\exp^{c}\_{x})^{-1}(\Lambda)$ is convex for all $x\in\Omega$, and finally that the following inequality holds: for any $x$, $x^{\prime}\in\Omega$, $q\_{0}$, $q\_{1}\in(\exp^{c}\_{x^{\prime}})^{-1}(\Lambda)$, and $t\in[0,1]$,

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle-c(x,\exp\_{x^{\prime}}^{c}((1-t)q\_{0}+tq\_{1}))+c(x^{\prime},\exp\_{x^{\prime}}^{c}((1-t)q\_{0}+tq\_{1})))$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant\max\{-c(x,\exp\_{x^{\prime}}^{c}(q\_{0}))+c(x^{\prime},\exp\_{x^{\prime}}^{c}(q\_{0})),-c(x,\exp\_{x^{\prime}}^{c}(q\_{1}))+c(x^{\prime},\exp\_{x^{\prime}}^{c}(q\_{1}))\}$ |  | (4.34) |

Note that this last inequality is nothing but quasi-concavity of $c(x^{\prime},\cdot)-c(x,\cdot)$ in the global coordinate chart of $\Lambda$ defined by $\exp\_{x^{\prime}}^{c}$.
For more on these conditions, see Remark [4.4](#S4.Thmremark4 "Remark 4.4. ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") below.

Proposition [4.8](#S4.Thmtheorem8 "Proposition 4.8. ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") can be applied to provide an alternative bound in the transversality condition ([T](#S3.Ex24 "In Definition 3.2 (Transversality). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) when the point $p\_{0}\in\partial K(\bm{\lambda})$ is in the interior of $X$ (so in particular, when dealing with Laguerre cells that do not intersect $\partial X$). The advantage of this bound is that it does not require knowledge of the condition number $C\_{\mathrm{cond}}$.

Recall that we have fixed some point $y\_{0}\in Y=\{y\_{1},\ldots,y\_{N}\}$ and for any index $i\in\{1,\ldots,N\}$ we use the notation,

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle f\_{i}(p)=f\_{y\_{i},y\_{0}}(p)=c(\exp^{c}\_{y\_{0}}{p},y\_{0})-c(\exp^{c}\_{y\_{0}}{p},y\_{i}).$ |  |

We also re-define the constants $C\_{\nabla}$ and $C\_{\mathrm{exp}}$ so that in their definitions, the maximum of $y$ ranges over the domain $\Lambda$ instead of just $Y$.

###### Proposition 4.8.

Suppose $\left\|\bm{\lambda}\right\|<T\_{tr}<\frac{\varepsilon}{8C\_{\mathrm{exp}}^{2d-2}\left\|\rho\right\|\_{\infty}\mathcal{H}^{d-1}\_{g}(\partial X)}$, and $p\_{0}\in K(\bm{\lambda})$ with $f\_{i}(p\_{0})=\lambda\_{i}$ and $f\_{j}(p\_{0})=\lambda\_{j}$ for $i\neq j$ in $\{1,\ldots,N\}$. Then we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left(\frac{\langle\nabla f\_{i}(p\_{0})\mid\nabla f\_{j}(p\_{0})\rangle}{\left\|\nabla f\_{i}(p\_{0})\right\|\left\|\nabla f\_{j}(p\_{0})\right\|}\right)^{2}\leqslant 1-\delta\_{2}^{2}$ |  | (4.35) |

where

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\delta\_{2}:=\frac{\varepsilon\varepsilon\_{nd}}{4\sqrt{2}C\_{\nabla}^{2}C\_{\mathrm{exp}}^{2d+4}\left\|\rho\right\|\_{\infty}\left(\mathcal{H}^{d-1}\_{g}(\partial X)\right)}.$ |  |

###### Remark 4.3.

Before embarking on the proof of this “continuous” upper transversality estimate, we compare some key features of its proof with that of the “discrete” upper transversality estimate Proposition [4.5](#S4.Thmtheorem5 "Proposition 4.5. ‣ Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"). By considering the case when the two vectors $\nabla f\_{i}(p\_{0})$ and $\nabla f\_{j}(p\_{0})$ are collinear, we can see that both proofs rely on the same core idea. In this case, $\nabla f\_{i}(p\_{0})$ and $\nabla f\_{j}(p\_{0})$ are outward normal vectors (in coordinates induced by $\exp^{c}\_{y\_{0}}$, see Remark [4.4](#S4.Thmremark4 "Remark 4.4. ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) to the sublevel sets $\{-c(\cdot,y\_{0})+\psi(y\_{0})\leqslant-c(\cdot,y\_{i})+\psi(y\_{i})\}$ and $\{-c(\cdot,y\_{0})+\psi(y\_{0})\leqslant-c(\cdot,y\_{j})+\psi(y\_{j})\}$ respectively, at $p\_{0}$ which lies on the intersection of their boundaries. Since these sets are convex in the associated coordinates, this will cause the Laguerre cell associated to $y\_{i}$ to be trapped in a lower dimensional set, giving it zero mass which is a contradiction. The difference between the two proofs lies in quantifying this estimate. In the discrete version of the estimate we do one of two things depending on the sign of the inner product $\langle W-V\mid V\rangle$ (see proof of Proposition [4.5](#S4.Thmtheorem5 "Proposition 4.5. ‣ Notation. ‣ 4.2. Upper transversality estimates. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). When this inner product is negative, using that $\left\|W\right\|\geqslant\left\|V\right\|$ and the lower bound on $\left\|W-V\right\|$ from the non-degeneracy condition ([ND](#S3.Ex23 "In Non-degeneracy ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) yields that $W$ must lie outside of a cone of a certain size opening with axis along $V$. In the other case we note $W-V$ and $-V$ are, respectively, outward normal vectors to the sublevel sets $\{-c(\cdot,y\_{i})+\psi(y\_{i})\leqslant-c(\cdot,y\_{j})+\psi(y\_{j})\}$ and $\{-c(\cdot,y\_{i})+\psi(y\_{i})\leqslant-c(\cdot,y\_{0})+\psi(y\_{0})\}$, viewed in coordinates given by $\exp\_{y\_{i}}^{c}$. Thus the lower transversality estimate Proposition [4.2](#S4.Thmtheorem2 "Proposition 4.2. ‣ 4.1. Lower transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") can be applied to obtain a quantitative bound, but at the price of involving the condition number since we have made a change of coordinates. In the continuous version, there is no change of coordinates, instead we make a rotation to align $\nabla f\_{j}(p\_{0})$ and $\nabla f\_{i}(p\_{0})$, then estimate the error induced by this rotation using ([4.34](#S4.E34 "In 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), in a vein similar to calculations from [[16](#bib.bib16), Remark 2.5, Proof of Lemma 4.7].

###### Proof of Proposition [4.8](#S4.Thmtheorem8 "Proposition 4.8. ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

Let us again write

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle V:$ | $\displaystyle=\nabla f\_{i}(p\_{0}),\quad W:=\nabla f\_{j}(p\_{0}),$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle v:$ | $\displaystyle=\frac{V}{\left\|V\right\|},\quad w:=\frac{W}{\left\|W\right\|},$ |  |

and assume $\varepsilon\_{nd}<\left\|V\right\|\leqslant\left\|W\right\|$ and $\langle v\mid w\rangle>0$. Let us also define

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle x\_{0}:$ | $\displaystyle=\exp^{c}\_{y\_{0}}(p\_{0}),\quad q\_{0}:=-D\_{x}c(x\_{0},y\_{0}),\quad q\_{1}:=-D\_{x}c(x\_{0},y\_{j}).$ |  |

A quick calculation yields

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle q\_{0}$ | $\displaystyle=[(\mathrm{D}\exp^{c}\_{y\_{0}}|\_{p\_{0}})^{\*}]^{-1}(-\nabla\_{p}c(\exp^{c}\_{y\_{0}}(p),y\_{0})|\_{p=p\_{0}}),$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle q\_{1}$ | $\displaystyle=[(\mathrm{D}\exp^{c}\_{y\_{0}}|\_{p\_{0}})^{\*}]^{-1}(W)+q\_{0},$ |  |

Now we define the point

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle q^{\prime}:=[(\mathrm{D}\exp^{c}\_{y\_{0}}|\_{p\_{0}})^{\*}]^{-1}(\left\|V\right\|w)+q\_{0},$ |  |

since $\left\|V\right\|\leqslant\left\|W\right\|$, the above calculation yields that $q^{\prime}$ lies on the line segment between $q\_{0}$ and $q\_{1}$; since $(\exp^{c}\_{x\_{0}})^{-1}(\Lambda)$ is convex we have that $q^{\prime}\in(\exp^{c}\_{x\_{0}})^{-1}(\Lambda)$ as well.

Thus we can define

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle y^{\prime}\_{i}:$ | $\displaystyle=\exp^{c}\_{x\_{0}}(q^{\prime}),$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\tilde{f}\_{i}(p):$ | $\displaystyle=-c(\exp^{c}\_{y\_{0}}(p),y^{\prime}\_{i})+c(\exp^{c}\_{y\_{0}}(p),y\_{0})+c(x\_{0},y^{\prime}\_{i})-c(x\_{0},y\_{0})+\lambda\_{i},$ |  |

and by ([4.34](#S4.E34 "In 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) applied with the choices $x:=\exp^{c}\_{y\_{0}}(p)$, $x^{\prime}:=x\_{0}$, $t:=\frac{\left\|V\right\|}{\left\|W\right\|}$, and $q\_{0}$, $q\_{1}$ as defined above.
we will obtain for all $p\in(\exp^{c}\_{y\_{0}})^{-1}(\Omega)$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\tilde{f}\_{i}(p)-\lambda\_{i}\leqslant\max\{0,f\_{j}(p)-\lambda\_{j}\},$ |  | (4.36) |

while another quick calculation yields

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle y\_{i}$ | $\displaystyle=\exp^{c}\_{x\_{0}}([(\left.\mathrm{D}\exp^{c}\_{y\_{0}}\right|\_{p\_{0}})^{\*}]^{-1}(V)+q\_{0}).$ |  |

Now note that

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\lvert-c(\exp^{c}\_{y\_{0}}(p),y^{\prime}\_{i})+c(\exp^{c}\_{y\_{0}}(p),y\_{i})\rvert$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant\sup\_{(x,q)\in\Omega\times(\exp^{c}\_{x\_{0}})^{-1}(\Lambda)}\left\|(\left.\mathrm{D}\exp^{c}\_{x\_{0}}\right|\_{q})^{\*}(-D\_{y}c(x,\exp^{c}\_{x\_{0}}(q)))\right\|\left\|[(\left.\mathrm{D}\exp^{c}\_{y\_{0}}\right|\_{p\_{0}})^{\*}]^{-1}(\left\|V\right\|w-V)\right\|$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant C\_{\nabla}C\_{\mathrm{exp}}^{2}\left\|\left\|V\right\|w-V\right\|,$ |  |

where we have used that if $y=\exp^{c}\_{x\_{0}}(q)$, then $(\left.\mathrm{D}\exp^{c}\_{x\_{0}}\right|\_{q})^{\*}=\left.\mathrm{D}\exp^{c}\_{y}\right|\_{-D\_{x}c(x\_{0},y)}$. As a result we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\lvert\tilde{f}\_{i}(p)-f\_{i}(p)\rvert^{2}=\lvert-c(\exp^{c}\_{y\_{0}}(p),y^{\prime}\_{i})+c(\exp^{c}\_{y\_{0}}(p),y\_{i})\rvert^{2}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant(C\_{\nabla}C\_{\mathrm{exp}}^{2})^{2}\left\|V-\left\|V\right\|w\right\|^{2}=2(C\_{\nabla}C\_{\mathrm{exp}}^{2})^{2}\left\|V\right\|^{2}(1-\langle v\mid w\rangle)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant 2(C\_{\nabla}C\_{\mathrm{exp}}^{2})^{2}(C\_{\mathrm{exp}}C\_{\nabla})^{2}(1-\langle v\mid w\rangle).$ |  |

Combining with ([4.36](#S4.E36 "In Proof of Proposition . ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) we then have for any $p\in(\exp^{c}\_{y\_{0}})^{-1}(\Omega)$,

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle f\_{i}(p)-\lambda\_{i}\leqslant\max\{0,\ f\_{j}(p)-\lambda\_{j}\}+\sqrt{2}C\_{\mathrm{exp}}^{3}C\_{\nabla}^{2}\sqrt{1-\langle v\mid w\rangle}$ |  |

or re-arranging and using that $\left\|\bm{\lambda}\right\|<T\_{tr}$,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle 1-\langle v\mid w\rangle$ | $\displaystyle\geqslant\sup\_{p\in(\exp^{c}\_{y\_{0}})^{-1}(\Omega)}\frac{(f\_{i}(p)-\max\{0,f\_{j}(p)\}-2T\_{tr})^{2}}{2(C\_{\mathrm{exp}}^{3}C\_{\nabla}^{2})^{2}}.$ |  | (4.37) |

We now make the following observation. Let us write $X\_{i}:=(\exp^{c}\_{y\_{i}})^{-1}(X)$. Then for any $t$, $s>0$, we can estimate the volume of $X\_{i}\cap\{f\_{y\_{0},y\_{i}}\leqslant-t\}\cap\{f\_{y\_{j},y\_{i}}\leqslant-s\}$ by

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\mathcal{H}^{d}\left(X\_{i}\cap\{f\_{y\_{0},y\_{i}}\leqslant-t\}\cap\{f\_{y\_{j},y\_{i}}\leqslant-s\}\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\geqslant\mathcal{H}^{d}\left(X\_{i}\cap\{f\_{y\_{0},y\_{i}}\leqslant 0\}\cap\{f\_{y\_{j},y\_{i}}\leqslant 0\}\right)-\mathcal{H}^{d}\left(X\_{i}\cap\{-t<f\_{y\_{0},y\_{i}}\leqslant 0\}\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\quad-\mathcal{H}^{d}\left(X\_{i}\cap\{-s<f\_{y\_{j},y\_{i}}\leqslant 0\}\right).$ |  |

Using that $L\_{i}\subset\{f\_{y\_{0},y\_{i}}\leqslant 0\}\cap\{f\_{y\_{j},y\_{i}}\leqslant 0\}$, we can bound the first term from below as

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\mathcal{H}^{d}\left(X\_{i}\cap\{f\_{y\_{0},y\_{i}}\leqslant 0\}\cap\{f\_{y\_{j},y\_{i}}\leqslant 0\}\right)\geqslant\frac{\varepsilon}{C\_{\mathrm{exp}}^{d}\left\|\rho\right\|\_{\infty}}.$ |  |

For the second term, by the coarea formula, we can write

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{H}^{d}\left(X\_{i}\cap\{-t<f\_{y\_{0},y\_{i}}\leqslant 0\}\right)$ | $\displaystyle\leqslant\int\_{-t}^{0}\int\_{X\_{i}\cap\{f\_{y\_{0},y\_{i}}=z\}}\frac{1}{\left\|\nabla f\_{y\_{0},y\_{i}}(p)\right\|}d\mathcal{H}^{d-1}(p)dz$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant\frac{t\mathcal{H}^{d-1}(\partial X\_{i})}{\varepsilon\_{nd}}\leqslant\frac{tC\_{\mathrm{exp}}^{d-1}\mathcal{H}^{d-1}\_{g}(\partial X)}{\varepsilon\_{nd}},$ |  |

where to obtain the second line we have again used the fact that for every $z\in\mathbb{R}$, the set $X\_{i}\cap\{f\_{y\_{0},y\_{i}}=z\}$ is contained in the boundary of a convex subset of $X\_{i}$ in conjunction with [[21](#bib.bib21), Remark 5.2]. By a similar bound on the third term, we see that as long as

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\max\{t,\ s\}<\frac{\varepsilon\varepsilon\_{nd}}{2C\_{\mathrm{exp}}^{2d-2}\left\|\rho\right\|\_{\infty}\mathcal{H}^{d-1}\_{g}(\partial X)}$ |  |

we have

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\mathcal{H}^{d}\left(X\_{i}\cap\{f\_{y\_{0},y\_{i}}\leqslant-t\}\cap\{f\_{y\_{j},y\_{i}}\leqslant-s\}\right)>0,$ |  |

thus in particular, (by continuity of $f\_{y\_{0},y\_{i}}$ and $f\_{y\_{j},y\_{i}}$) there must exist a point $p^{\prime}\_{c}\in X\_{i}$ for which $\max\{f\_{y\_{0},y\_{i}}(p^{\prime}\_{c}),\ f\_{y\_{j},y\_{i}}(p^{\prime}\_{c})\}\leqslant-\frac{\varepsilon\varepsilon\_{nd}}{2C\_{\mathrm{exp}}^{2d-2}\left\|\rho\right\|\_{\infty}\mathcal{H}^{d-1}\_{g}(\partial X)}$. Translating this back into coordinates in $(\exp^{c}\_{0})^{-1}(X)$ and in terms of $f\_{i}$, $f\_{j}$, we see there exists a point $p\_{c}\in(\exp^{c}\_{0})^{-1}(X)$ for which

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle f\_{i}(p\_{c})-\max\{0,\ f\_{j}(p\_{c})\}\geqslant\frac{\varepsilon\varepsilon\_{nd}}{2C\_{\mathrm{exp}}^{2d-2}\left\|\rho\right\|\_{\infty}\mathcal{H}^{d-1}\_{g}(\partial X)}.$ |  |

Thus if we have $T\_{tr}\leqslant\frac{\varepsilon\varepsilon\_{nd}}{8C\_{\mathrm{exp}}^{2d-2}\left\|\rho\right\|\_{\infty}\mathcal{H}^{d-1}\_{g}(\partial X)}$, combining with ([4.37](#S4.E37 "In Proof of Proposition . ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) we will obtain the bound ([4.35](#S4.E35 "In Proposition 4.8. ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) as desired.
∎

###### Remark 4.4.

Under a set of standard conditions, we can obtain both ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([4.34](#S4.E34 "In 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")).

Let $\Omega$ and $\Lambda$ be bounded and smooth domains in $d$ dimensional Riemannian manifolds and take a cost $c\in C^{4}(\overline{\Omega}\times\overline{\Lambda})$. Also assume

* •

  $c$ satisfies the ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) condition: for every $x\in\Omega$, the map $y\in\Lambda\mapsto-D\_{x}c(x,y)$ is a diffeomorphism onto its image $\Lambda\_{x}:=-D\_{x}c(x,\Lambda)\subset T^{\*}\_{x}\Omega$ and we define the $c$-exponential map $\exp^{c}\_{x}:\Lambda\_{x}\to\Lambda$ by $\exp^{c}\_{x}=(-D\_{x}c(x,\cdot))^{-1}$.
* •

  the cost $c^{\*}(x,y):=c(y,x)$ satisfies the ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) condition: for every $y\in\Lambda$, we can define the $c^{\*}$-exponential map $\exp^{c}\_{y}:\Omega\_{y}\to\Omega$ on the set $\Omega\_{y}:=-D\_{y}c(\Omega,y)\subset T^{\*}\_{y}\Lambda$ by $\exp^{c}\_{y}=(-D\_{y}c(\cdot,y))^{-1}$.
* •

  $(\exp^{c}\_{x})^{-1}(\Lambda)$ is convex for each $x\in\Omega$.
* •

  $(\exp^{c^{\*}}\_{y})^{-1}(\Omega)$ is convex for each $y\in\Lambda$.
* •

  $\det D^{2}\_{xy}c(x,y)\neq 0$ for all $(x,y)\in\overline{\Omega}\times\overline{\Lambda}$.
* •

  For any $(x,y)\in\overline{\Omega}\times\overline{\Lambda}$ and $\eta\in T^{\*}\_{x}\Omega$, $V\in T\_{x}\Omega$ with $\eta(V)=0$,

  |  |  |  |  |
  | --- | --- | --- | --- |
  |  | $\displaystyle-(c\_{ij,pq}-c\_{ij,r}c^{r,s}c\_{s,pq})c^{p,k}c^{q,l}V^{i}V^{j}\eta\_{k}\eta\_{l}\geqslant 0,$ |  | (A3w) |

here indices before a comma are derivatives on $\Omega$ and after a comma on $\Lambda$, for fixed coordinate systems, and a pair of raised indices denotes the inverse of a matrix. This last condition ([A3w](#S4.Ex117 "In 6th item ‣ Remark 4.4. ‣ 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) originates (in a stronger version) in [[26](#bib.bib26)] related to regularity of optimal transport. [[23](#bib.bib23), Theorem 3.2] in the Euclidean case and [[20](#bib.bib20), Theorem 4.10] in the general manifold case show the above conditions imply ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([4.34](#S4.E34 "In 4.4. Alternative upper transversality estimates ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). In fact, they are equivalent as seen in [[23](#bib.bib23)]. This geometric interpretation is a key ingredient in showing regularity in the optimal transport problem in the vein of Caffarelli’s classical work [[7](#bib.bib7)], see [[13](#bib.bib13), [16](#bib.bib16)].

## 5. Strong concavity of Kantorovich’s functional

We establish in this section the strong concavity of Kantorovich’s
functional $\Phi$ over some suitable domain of $\mathbb{R}^{Y}$. As explained
in the introduction, $\Phi$ is invariant under addition of a constant,
so that we must restrict ourselves to the orthogonal complement $E\_{Y}$
of the space of constant functions. Moreover, we will consider the set
$\mathcal{K}^{\varepsilon}$ defined by ([4.18](#S4.E18 "In Theorem 4.1. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), which can be thought of as the
space of strictly $c$-concave functions. Recall that the conditions ([Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), and ([PW](#S1.Ex10 "In Definition 1.3 (weighted Poincaré-Wirtinger). ‣ 1.6. Strong concavity of Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) are defined in the introduction, on pages [Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), [Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), [QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), and [PW](#S1.Ex10 "In Definition 1.3 (weighted Poincaré-Wirtinger). ‣ 1.6. Strong concavity of Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") respectively.

###### Theorem 5.1.

Assume ([Reg](#S1.Ex1 "In 1.1. Semi-discrete optimal transport ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), ([Twist](#S1.Ex4 "In 1.2. Laguerre tessellation and economic interpretation ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Let $X$ be a
compact, $c$-convex subset of $\Omega$, and $\rho$ be a continuous
probability density on $X$ satisfying ([PW](#S1.Ex10 "In Definition 1.3 (weighted Poincaré-Wirtinger). ‣ 1.6. Strong concavity of Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Then,
there exists a positive constant $C$, such that

|  |  |  |
| --- | --- | --- |
|  | $\forall\psi\in\mathcal{K}^{\varepsilon},~\forall v\in E\_{Y},~~\langle\mathrm{D}^{2}\Phi(\psi)v\mid v\rangle\leqslant-C\cdot\varepsilon^{3}\left\|v\right\|^{2},$ |  |

where $C$ is defined in ([5.46](#S5.E46 "In Step 3 ‣ 5.3. Proof of Theorem ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), and depends on $\left\|\rho\right\|\_{\infty}$, $\mathcal{H}^{d-1}\_{g}(\partial X)$, and $C\_{\mathrm{exp}}$, $C\_{\nabla}$, and $\varepsilon\_{tw}$ from Remark [4.1](#S4.Thmremark1 "Remark 4.1 (Constants). ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

###### Remark 5.1.

Note that the upper bound on the largest non-zero
eigenvalue of $\mathrm{D}^{2}\Phi(\psi)$ degrades as $N$ grows to infinity,
since $\varepsilon$ is of the order of $1/N$. A possible place for
improvement is the reverse isoperimetric inequality stated in
equation ([5.43](#S5.E43 "In Step 1 ‣ 5.3. Proof of Theorem ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Currently, we are vastly overestimating the size of the boundary of a Laguerre cell by bounding it with the area of the boundary of the whole domain, additionally we are bounding the density $\rho$ by its supremum, and paying in terms of the constant $C\_{\mathrm{exp}}$. Note that ([5.43](#S5.E43 "In Step 1 ‣ 5.3. Proof of Theorem ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) in its current form can *never* achieve equality, even for constant density $\rho$ and the quadratic cost function where $C\_{\mathrm{exp}}=1$, as equality would only happen for a Laguerre cell that occupied the whole domain $X$, which can not happen as *all* Laguerre cells have nonzero mass.
To improve the inequality, one
could try to control the anisotropy of Laguerre cells and bound the area of the boundary of a cell by some fraction of the area of $\partial X$, however this would require
assumptions on the distribution of the points $Y$ and on
$\nu\in\mathcal{P}(Y)$. We believe that such an upper bound on the
anisotropy of Laguerre cells would be interesting in itself, and
heuristically seems feasible to view as a discrete analogue of the regularity results
for optimal transport (interpreting the Laguerre cells associated
to $\psi:Y\to\mathbb{R}$ as the $c^{\*}$-subdifferentials of $\psi$).

###### Remark 5.2.

Note that unlike the domain $X$, the support of the density $\rho$
does not need be $c$-convex. We provide in
Appendix [A](#A1 "Appendix A A weighted Poincaré-Wirtinger inequality ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") an example of a radial measure on
$\mathbb{R}^{d}$ whose support is an annulus (hence is not simply connected)
but whose Poincaré-Wirtinger constant ([PW](#S1.Ex10 "In Definition 1.3 (weighted Poincaré-Wirtinger). ‣ 1.6. Strong concavity of Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) is
nonetheless positive.

The end of the section is devoted to the proof of Theorem
[5.1](#S5.Thmtheorem1 "Theorem 5.1. ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"). It relies on the fact that
$-\mathrm{D}^{2}\Phi(\psi)$ can be regarded as the Laplacian matrix of a
weighted graph on $Y$, whose first nonzero eigenvalue can be
controlled from below using the Cheeger constant of the weighted
graph. In turn, this weighted Cheeger constant can be controlled using
the Poincaré-Wirtinger inequality.

### 5.1. Poincaré inequality and continuous Cheeger constant

We start by proving that the finiteness of the Poincaré-Wirtinger
constant of the weighted domain $(X,\rho)$ implies the positivity of
the weighted Cheeger constant, defined in ([5.38](#S5.E38 "In Lemma 5.3. ‣ 5.1. Poincaré inequality and continuous Cheeger constant ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). In the following, a *Lipschitz domain* denotes the closure of an open set with Lipschitz
boundary.

###### Lemma 5.2.

Assume ([QC](#S1.Ex8 "In Definition 1.1 (Loeper’s condition). ‣ 1.5. Regularity of Kantorovich’s functional and MTW condition ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and that $X$ is compact and $c$-convex. Then

* (i)

  $X$ is a Lipschitz domain,
* (ii)

  for any $\psi\in\mathcal{K}^{+}$ and $y$ in $Y$, $\Lag\_{y}(\psi)\cap X$
  is a Lipschitz domain.

###### Proof.

By assumption, for any $y\in Y$ one can write $X=\exp\_{y}^{c}(X\_{y})$
where $X\_{y}$ is a bounded convex subset of $\mathbb{R}^{d}$ which must have
nonempty interior since it supports an absolutely continuous
probability measure. Moreover, the map $\exp\_{y}^{c}$ is a
diffeomorphism, hence bi-Lipschitz. This implies (i), while (ii)
follows from the exact same arguments, remembering that
$\rho(\Lag\_{y}(\psi))>0$.
∎

Given a Lipschitz domain $A$ of $X$ we write, slightly abusing notations,

|  |  |  |
| --- | --- | --- |
|  | $\left|\partial A\right|\_{\rho}:=\int\_{\partial A\cap\mathrm{int}(X)}\rho(x)\mathrm{d}\mathcal{H}^{d-1}\_{g}(x)~\hbox{ and }~\left|A\right|\_{\rho}:=\int\_{A}\rho(x)\mathrm{d}\mathcal{H}^{d}\_{g}(x).$ |  |

###### Lemma 5.3.

Let $X$ be a compact domain of $\Omega$ and $\rho$ in $\mathcal{C}^{0}(X)$ be
a probability density with finite Poincaré-Wirtinger constant
([PW](#S1.Ex10 "In Definition 1.3 (weighted Poincaré-Wirtinger). ‣ 1.6. Strong concavity of Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Then the weighted Cheeger constant of
$(X,\rho)$ is positive, that is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathrm{h}(\rho):=\inf\_{A\subseteq X}\frac{\left|\partial A\right|\_{\rho}}{\min(\left|A\right|\_{\rho},\left|X\setminus A\right|\_{\rho})}\geqslant\frac{2}{C\_{\mathrm{pw}}},$ |  | (5.38) |

where the infimum is taken over Lipschitz domains $A\subseteq\mathrm{int}(X)$ whose boundary has finite $\mathcal{H}^{d-1}\_{g}$–measure.

The proof is based on properties of functions with bounded
variation. For more details on this topic, we refer the reader to
[[4](#bib.bib4)]. Although the discussion in the reference is on Euclidean spaces, the relevant results easily extend to the Riemannian case, as $\exp^{c}\_{y}$ serves as a global coordinate system on all of $\Omega$.

###### Proof.

Let $A$ be a Lipschitz domain $A$ of $\mathrm{int}(X)$.
Since $A$ has a Lipschitz boundary with finite
area, its indicator function $\chi\_{A}$ has bounded variation in
$\mathrm{int}(X)$. By the density theorem [[4](#bib.bib4), Theorem
10.1.2], there exists a sequence of
$\mathcal{C}^{1}$-functions $f\_{n}$ on $\mathrm{int}(X)$ that converges to
$\chi\_{A}$ in the sense of intermediate convergence (whose definition is not important here). By
([PW](#S1.Ex10 "In Definition 1.3 (weighted Poincaré-Wirtinger). ‣ 1.6. Strong concavity of Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")),

|  |  |  |
| --- | --- | --- |
|  | $\left\|f\_{n}-\mathbb{E}\_{\rho}(f\_{n})\right\|\_{L^{1}(\rho)}\leqslant C\_{\mathrm{pw}}\ \left\|\nabla f\_{n}\right\|\_{L^{1}(\rho)}.$ |  |

Since intermediate convergence is stronger than $L^{1}$
convergence, the continuity of $\rho$ implies

|  |  |  |
| --- | --- | --- |
|  | $\lim\_{n\to\infty}\left\|f\_{n}-\mathbb{E}\_{\rho}(f\_{n})\right\|\_{L^{1}(\rho)}=\left\|\chi\_{A}-\mathbb{E}\_{\rho}(\chi\_{A})\right\|\_{L^{1}(\rho)}=2\left|A\right|\_{\rho}\ \left|X\setminus A\right|\_{\rho}.$ |  |

Note that we used the fact that $\rho$ is a probability measure,
i.e. $\rho(X)=1$. Proposition 10.1.2 of
[[4](#bib.bib4)] implies that the total variation measure
$|Df\_{n}|$ narrowly converges to $|D\chi\_{A}|$, which with the continuity of
$\rho$ implies that $\int\_{\Omega}|Df\_{n}|\rho\mathrm{d}\mathcal{H}^{d}\_{g}$ converges to
$\int\_{\Omega}|D\chi\_{A}|\rho\mathrm{d}\mathcal{H}^{d}\_{g}=\left|\partial A\right|\_{\rho}$. The relation
$|Df\_{n}|=\left\|\nabla f\_{n}\right\|\_{g}\mathrm{d}\mathcal{H}^{d}\_{g}$ then gives

|  |  |  |
| --- | --- | --- |
|  | $\lim\_{n\to\infty}\left\|\nabla f\_{n}\right\|\_{L^{1}(\rho)}\leqslant\left|\partial A\right|\_{\rho}.$ |  |

Combining the previous equations together leads to the desired
inequality.
∎

### 5.2. Cheeger constant of a graph

The goal of this section is to give a lower bound of the second
eigenvalue of $-\mathrm{D}^{2}\Phi(\psi)$ in terms of the Cheeger constant of
the weighted graph induced by this matrix. An unoriented weighted
graph can always be represented by its adjacency matrix
$(w\_{yz})\_{(y,z)\in Y^{2}}$, a symmetric matrix with zero diagonal
entries. We introduce a few definitions from graph theory, following
the conventions of [[14](#bib.bib14)].

###### Definition 5.1.

Let $(w\_{yz})\_{(y,z)\in Y^{2}}$ be a weighted graph over $Y$.
The (weighted) *degree* of a vertex $y$ is $d\_{y}:=\sum\_{z\neq y}w\_{yz}$. The (weighted) *Laplacian* is the matrix
$(L\_{yz})\_{(y,z)\in Y^{2}}$ whose entries are $L\_{yz}=-w\_{yz}$ for
$y\neq z$ and $L\_{yy}=d\_{y}$.

###### Definition 5.2.

The *Cheeger constant*
of a weighted graph $(w\_{yz})\_{(y,z)\in Y^{2}}$ over a point set $Y$
is given by

|  |  |  |
| --- | --- | --- |
|  | $\mathrm{h}(w):=\min\_{S\subseteq Y}\frac{\left|\partial S\right|\_{w}}{\min(\left|S\right|\_{w},\left|Y\setminus S\right|\_{w})},$ |  |

|  |  |  |
| --- | --- | --- |
|  | $\hbox{where }\left|\partial S\right|\_{w}:=\sum\_{y\in S,z\not\in S}w\_{yz}\quad\hbox{ and }\quad\left|S\right|\_{w}:=\sum\_{y\in S}d\_{y}.$ |  |

The (weighted) Cheeger inequality bounds from below the first nonzero
eigenvalue of the Laplacian of a weighted graph, denoted $\lambda(w)$,
from its Cheeger constant and its minimal degree. The formulation we
use can be deduced from Corollary 2.2 of [[14](#bib.bib14)]
and from the inequality $1-\sqrt{1-x^{2}}\geqslant x^{2}/2.$

###### Theorem 5.4 (Cheeger inequality).

$\lambda(w)\geqslant\frac{1}{2}\ \mathrm{h}^{2}(w)\cdot\min\_{y\in Y}d\_{y}.$

We now proceed to the proof of the main theorem of this section.

### 5.3. Proof of Theorem [5.1](#S5.Thmtheorem1 "Theorem 5.1. ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")

Let $\psi$ be a function in $\mathcal{K}^{\varepsilon}$ and consider the
weighted graph $(w\_{yz})\_{(y,z)\in Y^{2}}$ given by

|  |  |  |
| --- | --- | --- |
|  | $w\_{yz}:=-\frac{\partial^{2}\Phi}{\partial\mathbbold{1}\_{y}\partial\mathbbold{1}\_{z}}(\psi)=\int\_{\Lag\_{y,z}(\psi)}\frac{\rho(x)}{\left\|D\_{x}c(x,y)-D\_{x}c(x,z)\right\|\_{g}}\mathrm{d}\mathcal{H}^{d-1}\_{g}(x)$ |  |

for $y\neq z$ in $Y$, and with zero diagonal entries ($w\_{yy}=0$). In the formula above, we used the notation
$\Lag\_{y,z}(\psi)=\Lag\_{y}(\psi)\cap\Lag\_{z}(\psi)$ for the facet
between two Laguerre cells. By construction, the Laplacian matrix of
this weighted graph is the Hessian matrix $-\mathrm{D}^{2}\Phi(\psi)$, so that
Theorem [5.4](#S5.Thmtheorem4 "Theorem 5.4 (Cheeger inequality). ‣ 5.2. Cheeger constant of a graph ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") directly gives us a lower bound on the first
nonzero eigenvalue of $-\mathrm{D}^{2}\Phi(\psi)$. To complete the proof, we
need to bound the Cheeger constant and the minimum degree of the graph
$w$ from below.

#### Step 1

The goal here is to bound from below the discrete Cheeger constant
$\mathrm{h}(w)$ in terms of the continuous weighted Cheeger constant
$\mathrm{h}(\rho)$ and the constants introduced in ([4.19](#S4.E19 "In Remark 4.1 (Constants). ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). By
definition of the constants $\varepsilon\_{tw}$ and $C\_{\nabla}$, for every
$y\neq z$ in $Y$, one has

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\varepsilon\_{tw}\ w\_{yz}\leqslant|\Lag\_{y,z}(\psi)|\_{\rho}\leqslant 2C\_{\nabla}w\_{yz}.$ |  | (5.39) |

Consider a subset $S$ of $Y$, and let $A=\cup\_{y\in S}\Lag\_{y}(\psi)$. Then, the intersection of the boundary of $A$ with $X$
is contained an union of facets of Laguerre cells, namely

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\partial A\cap\mathrm{int}(X)\subseteq\bigcup\_{y\in S,z\not\in S}\Lag\_{y,z}(\psi).$ |  | (5.40) |

The two inequalities ([5.39](#S5.E39 "In Step 1 ‣ 5.3. Proof of Theorem ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([5.40](#S5.E40 "In Step 1 ‣ 5.3. Proof of Theorem ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) imply a
lower bound on the numerator of the Cheeger constant:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left|\partial A\right|\_{\rho}\leqslant\sum\_{y\in S,z\not\in S}\left|\Lag\_{y,z}(\psi)\right|\_{\rho}\leqslant 2C\_{\nabla}\,\left|\partial S\right|\_{w}.$ |  | (5.41) |

We now need to bound the denominator of the Cheeger constant from
above, which requires us to control the weighted degrees
$\mathrm{d}\_{y}$. Note that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathrm{d}\_{y}=\sum\_{z\neq y}w\_{yz}\leqslant\frac{1}{\varepsilon\_{tw}}\sum\_{z\neq y}|\Lag\_{y,z}(\psi)|\_{\rho}\leqslant\frac{1}{\varepsilon\_{tw}}|\partial\Lag\_{y}(\psi)|\_{\rho},$ |  | (5.42) |

where the second inequality comes from the fact that the facets
$\Lag\_{y,z}(\psi)$ form a partition of the boundary $\partial\Lag\_{y}(\psi)\cap\mathrm{int}(X)$ up to a $\mathcal{H}^{d-1}\_{g}$–negligible
set. To see that this is the case, it suffices to remark that in the
exponential chart of $y$, the intersection of two distinct facets
adjacent to $y$ has a finite $\mathcal{H}^{d-2}\_{g}$–measure, as implied by
Proposition [3.2](#S3.Thmtheorem2 "Proposition 3.2. ‣ 3.3. A control on the (𝑑-2)–Hausdorff measure of singular points ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

In order to apply the (continuous) Cheeger inequality, we need to
replace the weighted area of the boundaries of Laguerre cells in ([5.42](#S5.E42 "In Step 1 ‣ 5.3. Proof of Theorem ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) by the
weighted volume of the cells. We have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{H}^{d-1}\_{g}(\partial\Lag\_{y}(\psi))$ | $\displaystyle\leqslant C\_{\mathrm{exp}}^{d-1}\mathcal{H}^{d-1}((\exp\_{y}^{c})^{-1}\partial\Lag\_{y}(\psi))$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant C\_{\mathrm{exp}}^{d-1}\mathcal{H}^{d-1}(\partial X\_{y})$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant C\_{\mathrm{exp}}^{2(d-1)}\mathcal{H}^{d-1}\_{g}(\partial X).$ |  |

The first and third inequalities use the definition of the
bi-Lipschitz constant $C\_{\mathrm{exp}}$ of the exponential map, while the second
inequality uses the monotonicity of the $\mathcal{H}^{d-1}$–measure of the
boundary of a convex set with respect to inclusion (see [[32](#bib.bib32), p.211]). Using the
assumption $\left|\Lag\_{y}(\psi)\right|\_{\rho}\geqslant\varepsilon$, this gives us a (rather
crude) reverse isoperimetric inequality

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\left|\partial\Lag\_{y}(\psi)\right|\_{\rho}$ | $\displaystyle\leqslant\left\|\rho\right\|\_{\infty}\mathcal{H}^{d-1}\_{g}(\partial\Lag\_{y}(\psi))$ |  | (5.43) |
|  |  | $\displaystyle\leqslant\frac{\left\|\rho\right\|\_{\infty}}{\varepsilon}C\_{\mathrm{exp}}^{2(d-1)}\mathcal{H}^{d-1}\_{g}(\partial X)\left|\Lag\_{y}(\psi)\right|\_{\rho}$ |  |

We remark here that the above inequality is never sharp, see also Remark [5.1](#S5.Thmremark1 "Remark 5.1. ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").
Combining
([5.42](#S5.E42 "In Step 1 ‣ 5.3. Proof of Theorem ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), ([5.43](#S5.E43 "In Step 1 ‣ 5.3. Proof of Theorem ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and $\left|A\right|\_{\rho}=\sum\_{y\in S}\left|\Lag\_{y}(\psi)\right|\_{\rho}$ we obtain

|  |  |  |
| --- | --- | --- |
|  | $\left|S\right|\_{w}=\sum\_{y\in S}\mathrm{d}\_{y}\leqslant\frac{1}{\varepsilon}\frac{\left\|\rho\right\|\_{\infty}C\_{\mathrm{exp}}^{2(d-1)}\mathcal{H}^{d-1}\_{g}(\partial X)}{\varepsilon\_{tw}}\left|A\right|\_{\rho}.$ |  |

The same inequality holds for the complement $\left|X\setminus S\right|$. We combine the previous inequality with Equation
([5.41](#S5.E41 "In Step 1 ‣ 5.3. Proof of Theorem ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and with Lemma [5.3](#S5.Thmtheorem3 "Lemma 5.3. ‣ 5.1. Poincaré inequality and continuous Cheeger constant ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") to
get a lower bound on the Cheeger constant

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathrm{h}(w)\geqslant\frac{\varepsilon\_{tw}\varepsilon}{C\_{\mathrm{exp}}^{2(d-1)}C\_{\nabla}\mathcal{H}^{d-1}\_{g}(\partial X)\left\|\rho\right\|\_{\infty}C\_{\mathrm{pw}}}.$ |  | (5.44) |

Note that, in order to apply Lemma [5.3](#S5.Thmtheorem3 "Lemma 5.3. ‣ 5.1. Poincaré inequality and continuous Cheeger constant ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") we
implicitly used the fact that $A$ is a Lipschitz domain (as a finite
union of Lipschitz domains, see Lemma [5.2](#S5.Thmtheorem2 "Lemma 5.2. ‣ 5.1. Poincaré inequality and continuous Cheeger constant ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) whose
boundary has finite $\mathcal{H}^{d-1}\_{g}$–measure (by
Equation ([5.43](#S5.E43 "In Step 1 ‣ 5.3. Proof of Theorem ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))).

#### Step 2

In order to apply the Cheeger inequality, we still need to bound from below the weighted degree $d\_{y}$. By ([5.39](#S5.E39 "In Step 1 ‣ 5.3. Proof of Theorem ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) one has, using the crucial fact that $\left|\partial\Lag\_{y}(\psi)\right|\_{\rho}$ is the measure of $\partial\Lag\_{y}(\psi)\cap\mathrm{int}(X)$,

|  |  |  |
| --- | --- | --- |
|  | $d\_{y}=\sum\_{z\neq y}w\_{yz}\geqslant\frac{1}{2C\_{\nabla}}\sum\_{z\neq y}\left|\Lag\_{y,z}(\psi)\right|\_{\rho}\geqslant\frac{1}{2C\_{\nabla}}\left|\partial\Lag\_{y}(\psi)\right|\_{\rho}.$ |  |

Taking $A=\Lag\_{y}(\psi)$ in the definition of the weighted Cheeger constant $\mathrm{h}(\rho)$ defined in Lemma [5.3](#S5.Thmtheorem3 "Lemma 5.3. ‣ 5.1. Poincaré inequality and continuous Cheeger constant ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), one gets

|  |  |  |
| --- | --- | --- |
|  | $\left|\partial\Lag\_{y}(\psi)\right|\_{\rho}\geqslant\mathrm{h}(\rho)\ \min(\left|\Lag\_{y}(\psi)\right|\_{\rho},\left|X\setminus\Lag\_{y}(\psi)\right|\_{\rho})\geqslant\mathrm{h}(\rho)\varepsilon.$ |  |

The last inequality comes from the assumption that each Laguerre
cell has a mass greater than $\varepsilon$ and that $X\setminus\Lag\_{y}(\psi)$ also contains a Laguerre cell (except for the trivial
case where $Y$ is a singleton). We deduce

|  |  |  |  |
| --- | --- | --- | --- |
|  | $d\_{y}\geqslant\frac{\varepsilon}{C\_{\nabla}C\_{\mathrm{pw}}}.$ |  | (5.45) |

#### Step 3

Combining the Cheeger inequality
with Equation ([5.44](#S5.E44 "In Step 1 ‣ 5.3. Proof of Theorem ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and
([5.45](#S5.E45 "In Step 2 ‣ 5.3. Proof of Theorem ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) we have $\lambda(w)\geqslant C\varepsilon^{3}$ where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C:=\frac{\varepsilon\_{tw}^{2}}{2C\_{\mathrm{exp}}^{4(d-1)}C\_{\nabla}^{3}\left(\mathcal{H}^{d-1}\_{g}(\partial X)\right)^{2}\left\|\rho\right\|^{2}\_{\infty}C\_{\mathrm{pw}}^{3}}.$ |  | (5.46) |

Since the graph induced by the Hessian is connected, the kernel of
$-\mathrm{D}^{2}\Phi(\psi)$ is equal to the space of constant functions over
$Y$, implying that $\Ker(-\mathrm{D}^{2}\Phi(\psi))^{\perp}=E\_{Y}$. Then, using
the variational characterization of the first nonzero eigenvalue of
the Laplacian matrix we get:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\varepsilon^{3}\leqslant\lambda(w)=\min\_{v\in E\_{Y}}\frac{\langle-D^{2}\Phi(\psi)\mid v\rangle}{\left\|v\right\|^{2}}.$ |  | ∎ |

## 6. Convergence of the damped Newton algorithm

The goal of this section is to show the convergence of the Damped
Newton algorithm for semi-discrete optimal transport. This follows in
fact from a more general result. We establish in Section
[6.1](#S6.SS1 "6.1. General damped Newton algorithm ‣ 6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") the convergence of the damped
Newton algorithm (Algorithm [1](#alg1 "In 1.4. Damped Newton algorithm ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) under general
assumptions on the functional. We finally apply this algorithm to the
semi-discrete optimal transport problem, using the intermediate
results (regularity and strict concavity of the Kantorovich
functional) proven in
Section [4](#S4 "4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") and [5](#S5 "5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

### 6.1. General damped Newton algorithm

Let $Y$ be a finite set and denote $\mathbb{R}^{Y}$ the space of functions on
$Y$. We consider $\mathcal{P}(Y)$, the space of probability measures on $Y$,
as a subset of $\mathbb{R}^{Y}$. Finally, we denote by $E\_{Y}$ the space of
functions on $Y$ who sum to zero. In this section, we show that
Algorithm [1](#alg1 "In 1.4. Damped Newton algorithm ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") can be used to solve non-linear equations
$G(\psi)=\mu$ where $\mu\in\mathcal{P}(Y)$ and the map $G:\mathbb{R}^{Y}\to\mathcal{P}(Y)$ satisfies some regularity and monotonicity assumptions.

###### Proposition 6.1.

Let $G$ be a functional from $\mathbb{R}^{Y}$ to $\mathcal{P}(Y)$ which is
invariant under addition of a constant. Let $G(\psi)=\sum\_{y\in Y}G\_{y}(\psi)\mathbbold{1}\_{y}$ and

|  |  |  |
| --- | --- | --- |
|  | $\mathcal{K}^{\varepsilon}=\{\psi\in\mathbb{R}^{Y}\mid\forall y\in Y,~G\_{y}(\psi)\geqslant\varepsilon\},$ |  |

and assume
that $G$ has the following properties:

* (i)

  (Regularity) For every positive $\varepsilon$, $G$ is
  $\mathcal{C}^{1,\alpha}$ on $\mathcal{K}^{\varepsilon}$. We let $L\_{\varepsilon}$ be the smallest
  constant such that

  |  |  |  |
  | --- | --- | --- |
  |  | $\forall\varphi\neq\psi\in\mathcal{K}^{\varepsilon},~~\frac{\left\|G(\varphi)-G(\psi)\right\|}{\left\|\varphi-\psi\right\|}+\frac{\left\|\mathrm{D}G(\varphi)-\mathrm{D}G(\psi)\right\|}{\left\|\varphi-\psi\right\|^{\alpha}}\leqslant L\_{\varepsilon}.$ |  |
* (ii)

  (Uniform monotonicity) For every $\varepsilon>0$, there exists a positive constant $\kappa\_{\varepsilon}$ such that $G$ is $\kappa\_{\varepsilon}$–uniformly monotone on
  $\mathcal{K}^{\varepsilon}\cap E\_{Y}$:

  |  |  |  |
  | --- | --- | --- |
  |  | $\forall\psi\in\mathcal{K}^{\varepsilon},\forall v\in E\_{Y},~~\langle v\mid\mathrm{D}G(\psi)v\rangle\geqslant\kappa\_{\varepsilon}\left\|v\right\|^{2}.$ |  |

Now, let $\mu\in\mathcal{P}(Y)$ and let $\psi\_{0}$ be a function on $Y$
such that the constant $\varepsilon\_{0}$ defined in ([1.6](#S1.E6 "In item Input ‣ 1 ‣ 1.4. Damped Newton algorithm ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))
is positive. Set $\kappa:=\min(\kappa\_{\frac{1}{2}\varepsilon\_{0}},1)$ and $L:=\max(L\_{\frac{1}{2}\varepsilon\_{0}},1)$. Then, the iterates $(\psi\_{k})$ of
Algorithm [1](#alg1 "In 1.4. Damped Newton algorithm ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") satisfy

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\left\|G(\psi\_{k+1})-\mu\right\|\leqslant(1-\overline{\tau}\_{k}/2)\left\|G(\psi\_{k})-\mu\right\|$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\hbox{ where }\overline{\tau}\_{k}:=\min\left(\frac{\kappa^{1+\frac{1}{\alpha}}\varepsilon}{d^{\frac{1}{\alpha}}L^{\frac{1}{\alpha}}\left\|G(\psi\_{k})-\mu\right\|},1\right).$ |  | (6.47) |

In addition, as soon as $\overline{\tau}\_{k}=1$ one has

|  |  |  |
| --- | --- | --- |
|  | $\left\|G(\psi\_{k+1})-\mu\right\|\leqslant\frac{L\left\|G(\psi\_{k})-\mu\right\|^{1+\alpha}}{\kappa^{1+\alpha}}.$ |  |

In particular, the
damped Newton’s algorithm converges globally with linear speed and
locally with superlinear speed (quadratic speed if $\alpha=1$).

###### Proof.

We set $\varepsilon:=\varepsilon\_{0}$, $L:=\max(L\_{\varepsilon/2},1)$ and $\kappa:=\min(\kappa\_{\varepsilon/2},1)$. First, we remark that for every $\psi\in\mathcal{K}^{\frac{\varepsilon}{2}}$, the pseudo-inverse $\mathrm{D}G^{+}(\psi)$ maps the
subspace $E\_{Y}$ to itself. The uniform monotonicity of $G$ therefore
implies that $\left\|\mathrm{D}G^{+}(\psi)\right\|\leqslant 1/\kappa$, where $\left\|\cdot\right\|$
is the operator norm on $\mathbb{R}^{Y}$.

We start by the analysis of a single iteration of the algorithm. We
let $\psi:=\psi\_{k}\in\mathcal{K}^{\varepsilon}$, define $v:=\mathrm{D}G(\psi)^{+}(G(\psi)-\mu)$ and $\psi\_{\tau}:=\psi-\tau v$. Since the pseudo-inverse $\mathrm{D}G^{+}(\psi)$ is $1/\kappa$-Lipschitz, one has $\left\|v\right\|\leqslant\left\|G(\psi)-\mu\right\|/\kappa$. Now let $\tau\_{1}$ be the largest time before the curve
$\psi\_{\sigma}$ leaves $\mathcal{K}^{\varepsilon/2}$. In particular, $\psi\_{\tau\_{1}}$
lies at the boundary of $\mathcal{K}^{\varepsilon/2}$, meaning that there must exist a
point $y$ in $Y$ such that $G\_{y}(\psi\_{\tau\_{1}})=\varepsilon/2$. This implies
that $\left\|G(\psi\_{\tau\_{1}})-G(\psi)\right\|\geqslant\varepsilon/2$, and using the
Lipschitz bound on $G$ we obtain a lower bound on $\tau\_{1}$

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\frac{\varepsilon}{2}\leqslant\left\|G(\psi\_{\tau\_{1}})-G(\psi)\right\|\leqslant L\tau\_{1}\left\|v\right\|\leqslant\frac{L\tau\_{1}}{\kappa}\left\|G(\psi)-\mu\right\|.$ |  |

This implies that $\tau\_{1}$ is necessarily larger than $\kappa\varepsilon/(2L\left\|G(\psi)-\mu\right\|)$. We now established that the curve $\tau\mapsto\psi\_{\tau}$ remains in $\mathcal{K}^{\varepsilon/2}$ before time $\tau\_{1}$,
implying that the function $\tau\in[0,\tau\_{1}]\mapsto G(\psi\_{\tau})$
is uniformly $\mathcal{C}^{1,\alpha}$. Applying Taylor’s formula we get

|  |  |  |  |
| --- | --- | --- | --- |
|  | $G(\psi\_{\tau})=G(\psi-\tau\mathrm{D}G(\psi)^{+}(G(\psi)-\mu))=(1-\tau)G(\psi)+\tau\mu+R(\tau)$ |  | (6.48) |

where, using $v=\mathrm{D}G(\psi)^{+}(G(\psi)-\mu)$, and the $\alpha$-Hölder property for $\mathrm{D}G$

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\left\|R(\tau)\right\|$ | $\displaystyle=\left\|\int\_{0}^{\tau}(\mathrm{D}G(\psi\_{\sigma})-\mathrm{D}G(\psi))v\mathrm{d}\sigma\right\|$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant\frac{L}{\alpha+1}\tau^{\alpha+1}\left\|v\right\|^{\alpha+1}\leqslant\frac{L\left\|G(\psi)-\mu\right\|^{(1+\alpha)}}{\kappa^{(1+\alpha)}}\tau^{(1+\alpha)}$ |  | (6.49) |

For every $y\in Y$, using that $\mu\_{y}\geqslant 2\varepsilon$ (by ([1.6](#S1.E6 "In item Input ‣ 1 ‣ 1.4. Damped Newton algorithm ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))) and $G\_{y}(\psi)\geqslant\varepsilon$, one gets

|  |  |  |
| --- | --- | --- |
|  | $G\_{y}(\psi\_{\tau})\geqslant(1-\tau)G\_{y}(\psi)+\tau\mu\_{y}+R\_{y}(\tau)\geqslant(1+\tau)\varepsilon-\left\|R(\tau)\right\|.$ |  |

If $\tau$ is chosen such that such
that $\left\|R(\tau)\right\|\leqslant\tau\varepsilon$ we will have $G\_{y}(\psi\_{\tau})\geqslant\varepsilon$ for all points $y$ in $Y$ and therefore $\psi\_{\tau}$ will belong
to $\mathcal{K}^{\varepsilon}$. Thanks to our estimate on $R(\tau)$ this will be true
provided that

|  |  |  |
| --- | --- | --- |
|  | $\tau\leqslant\tau\_{2}:=\min\left(\tau\_{1},\frac{\kappa^{1+\frac{1}{\alpha}}\varepsilon^{\frac{1}{\alpha}}}{L^{\frac{1}{\alpha}}\|G(\psi)-\mu\|^{1+\frac{1}{\alpha}}}\right).$ |  |

Finally we establish the second inequality required by Step 2 of the
Algorithm. To do that, we subtract $\mu$ from both sides in
([6.48](#S6.E48 "In Proof. ‣ 6.1. General damped Newton algorithm ‣ 6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) to obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $G(\psi\_{\tau})-\mu=(1-\tau)(G(\psi)-\mu)+R(\tau).$ |  | (6.50) |

In order to get $\left\|G(\psi\_{\tau})-\mu\right\|\leqslant(1-\frac{\tau}{2})\left\|G(\psi)-\mu\right\|$, it is sufficient to establish
that $\left\|R(\tau)\right\|\leqslant\frac{\tau}{2}\left\|G(\psi)-\mu\right\|$. Using the
estimation on $\left\|R(\tau)\right\|$ again, we see that it suffices to take

|  |  |  |
| --- | --- | --- |
|  | $\tau\leqslant\tau\_{3}:=\min\left(\tau\_{2},\frac{\kappa^{1+\frac{1}{\alpha}}}{L^{\frac{1}{\alpha}}\|G(\psi)-\mu\|2^{\frac{1}{\alpha}}},1\right).$ |  |

Finally, using $L\geqslant 1$, $\kappa\leqslant 1$ and $\left\|G(\psi)-\mu\right\|\leqslant d$ (since $G(\psi)$ and $\mu$ are probability measures), we can
establish that $\tau\_{3}\geqslant\overline{\tau}\_{k}$ where the value of
$\overline{\tau}\_{k}$ is defined in ([6.47](#S6.E47 "In Proposition 6.1. ‣ 6.1. General damped Newton algorithm ‣ 6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). This ensures the
first estimate on the improvement of the error between two successive
steps.

By this first estimate, we see that there exists $k\_{0}$ such that
$\overline{\tau}\_{k}=1$ for $k\geqslant k\_{0}$. When this happens, one can use
([6.50](#S6.E50 "In Proof. ‣ 6.1. General damped Newton algorithm ‣ 6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) to get $\left\|G(\psi\_{k+1})-\mu\right\|\leqslant\left\|R(\tau)\right\|$. We obtain the second estimate of the theorem by
plugging in ([6.49](#S6.E49 "In Proof. ‣ 6.1. General damped Newton algorithm ‣ 6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")).∎

### 6.2. Proof of Theorem [1.5](#S1.Thmtheorem5 "Theorem 1.5. ‣ 1.7. Convergence result ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")

Proposition [6.1](#S6.Thmtheorem1 "Proposition 6.1. ‣ 6.1. General damped Newton algorithm ‣ 6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") can be directly applied to the gradient
of the Kantorovich functional, or more precisely to

|  |  |  |
| --- | --- | --- |
|  | $G(\psi):=\sum\_{y\in Y}\rho(\Lag\_{y}(\psi))\mathbbold{1}\_{y}=\nabla\Phi(\psi)+\mu$ |  |

In that case, the set $K^{\varepsilon}$ is given by

|  |  |  |
| --- | --- | --- |
|  | $K^{\varepsilon}=\{\psi\in\mathbb{R}^{Y}\mid\forall y\in Y,~\rho(\Lag\_{y}(\psi))\geqslant\varepsilon\}.$ |  |

We have assumed that the
probability density $\rho$ is $\mathcal{C}^{0,\alpha}(X)$ where $X$ is a
$c$-convex, compact subset of $\Omega$. Then, by
Theorem [4.1](#S4.Thmtheorem1 "Theorem 4.1. ‣ 4. 𝒞^{2,𝛼} regularity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), for any $\varepsilon>0$, the map $G$ is
uniformly $\mathcal{C}^{1,\alpha}$ over $\mathcal{K}^{\varepsilon}$. This ensures that the
(Regularity) condition of Proposition [6.1](#S6.Thmtheorem1 "Proposition 6.1. ‣ 6.1. General damped Newton algorithm ‣ 6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") is
satisfied. Furthermore, since we also assumed that $\rho$ satisfies a
weighted Poincaré-Wirtinger inequality, we can apply Theorem
[5.1](#S5.Thmtheorem1 "Theorem 5.1. ‣ 5. Strong concavity of Kantorovich’s functional ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") to see that the (Uniform monotonicity)
hypothesis of Proposition [6.1](#S6.Thmtheorem1 "Proposition 6.1. ‣ 6.1. General damped Newton algorithm ‣ 6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") is also
satisfied. Applying Proposition [6.1](#S6.Thmtheorem1 "Proposition 6.1. ‣ 6.1. General damped Newton algorithm ‣ 6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), we deduce the
desired convergence rates for Algorithm [1](#alg1 "In 1.4. Damped Newton algorithm ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

### 6.3. Numerical results

We conclude the article with a numerical illustration of this
algorithm, for the cost $c(x,y)=\left\|x-y\right\|^{2}$ and for a
piecewise-linear density. The source density is piecewise-linear over
a triangulation of $[0,3]$ with $18$ triangles (displayed in
Figure [3](#S6.F3 "Figure 3 ‣ 6.3. Numerical results ‣ 6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). It takes value $1$ on the boundary
$\partial[0,3]^{2}$ and vanishes on the square $[1,2]^{2}$. In
particular, the support of this density is not simply connected and
not convex. The target measure is uniform over a uniform grid
$\frac{1}{n-1}\{0,\ldots,n-1\}^{2}$. Figure [3](#S6.F3 "Figure 3 ‣ 6.3. Numerical results ‣ 6. Convergence of the damped Newton algorithm ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")
displays the iterates of the Newton algorithm, which in this case
takes 25 iterations to solve the optimal transport problem with an
error equal to the numerical precision of the machine. The source code
of this algorithm is publicly
available11
1
https://github.com/mrgt/PyMongeAmpere.

We finally note that recent progress in computational geometry would
allow one to implement Algorithm [1](#alg1 "In 1.4. Damped Newton algorithm ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") for the quadratic
cost on $\mathbb{R}^{3}$, refining [[22](#bib.bib22)] or
[[12](#bib.bib12)]. It should also be possible to deal with optimal
transport problems arising from geometric optics, such as the
far-field reflector problem [[10](#bib.bib10)], whose
associated cost satisfies the Ma-Trudinger-Wang condition
[[24](#bib.bib24)].

|  |  |  |
| --- | --- | --- |
|  |  |  |
|  |  |  |
|  |  |  |

Figure 3. Evolution of the Laguerre cells during the execution of the
damped Newton algorithm for semi-discrete optimal transport. (Top)
The source density $\rho$ is piecewise linear over the domain
$X=[0,3]^{3}$ over the displayed triangulation: it takes value $1$
on the boundary of the square $[0,3]^{2}$ and $0$ on the boundary of
$[1,2]^{2}$. The target measure is uniform over a $30^{2}$ uniform
grid in $[0,1]^{2}$. (Bottom) Laguerre cells at steps
$k=0,2,6,9,12,15,18,21$ and $25$.

## Appendix A A weighted Poincaré-Wirtinger inequality

In this section, we provide an (almost) explicit example of a
probability density on $\mathbb{R}^{d}$ whose support is an annulus, therefore
not simply connected, but which still satisfies a weighted
Poincaré-Wirtinger inequality.

###### Proposition A.1.

Let $0<r<R$ and assume that $\overline{\rho}\in\mathcal{C}^{0}([0,R])$ is a
probability density with $\overline{\rho}=0$ on $[0,r]$ and $\overline{\rho}$
concave on $[r,R]$. Consider

|  |  |  |
| --- | --- | --- |
|  | $\rho(x)=\frac{1}{\left\|x\right\|^{d-1}\omega\_{d-1}}\overline{\rho}(\left\|x\right\|)\qquad\hbox{over}\qquad X:=\mathrm{B}(0,R)\subseteq\mathbb{R}^{d},$ |  |

where
$\omega\_{d-1}$ is the volume of the unit sphere $\mathbb{S}^{d-1}$. Then,
$\rho$ satisfies the weighted Poincaré-Wirtinger inequality
([PW](#S1.Ex10 "In Definition 1.3 (weighted Poincaré-Wirtinger). ‣ 1.6. Strong concavity of Kantorovich’s functional ‣ 1. Introduction ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) for some positive constant.

The proof relies on two $L^{1}$-Poincaré-Wirtinger inequalities. The
first inequality is the usual Poincaré-Wirtinger inequality on the
sphere: given a $\mathcal{C}^{1}$ function $f$ on $\mathbb{S}^{d-1}$, and $F\_{d-1}:=(1/\omega\_{d-1})\int\_{\mathbb{S}^{d-1}}f(z)\mathrm{d}z$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\int\_{\mathbb{S}^{d-1}}\left|f(z)-F\_{d-1}\right|\mathrm{d}\mathcal{H}^{d-1}(z)\leqslant c\_{d}\int\_{\mathbb{S}^{d-1}}\left\|\nabla f(z)\right\|\mathrm{d}\mathcal{H}^{d-1}(z)$ |  | (A.51) |

for some positive constant $c\_{d}$. The second inequality is a
Poincaré-Wirtinger inequality on the segment $[0,R]$ weighted by
$\overline{\rho}$. Given a function in $\mathcal{C}^{1}([0,R])$, and letting $F\_{1}:=\int\_{0}^{R}f(r)\overline{\rho}(r)\mathrm{d}r/\int\_{0}^{R}\overline{\rho}(r)\mathrm{d}r$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\int\_{0}^{R}\left|\overline{f}(r)-F\_{1}\right|\overline{\rho}(r)\mathrm{d}r\leqslant c\_{\overline{\rho}}\int\_{0}^{R}\left|\overline{f}^{\prime}(r)\right|\overline{\rho}(r)\mathrm{d}r$ |  | (A.52) |

for some positive constant $c\_{\overline{\rho}}$ depending only on
$\overline{\rho}$. The inequality ([A.52](#A1.E52 "In Appendix A A weighted Poincaré-Wirtinger inequality ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) can be
deduced from Theorem 2.1 in [[3](#bib.bib3)] and from the
concavity of $\overline{\rho}$ on $[r,R]$.

###### Proof.

We now proceed to the proof of the Poincaré-Wirtinger inequality for
$(X,\rho)$. Let $f:\mathrm{B}(0,R)\to\mathbb{R}$ be a function of class
$\mathcal{C}^{1}$. By polar coordinates and the definition of $\rho$, one
has

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle F$ | $\displaystyle:=\int\_{\mathrm{B}(0,R)}f(x)\rho(x)\mathrm{d}\mathcal{H}^{d}(x)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\int\_{0}^{R}\frac{1}{\omega\_{d-1}r^{d-1}}\int\_{\mathbb{S}^{d-1}(r)}f(z)\overline{\rho}(r)\mathrm{d}\mathcal{H}^{d-1}(z)\mathrm{d}r=\int\_{0}^{R}\overline{f}(r)\overline{\rho}(r)\mathrm{d}r,$ |  |

where the function $\overline{f}(r)$ is the mean value of $f$ over the
sphere $\mathbb{S}^{d-1}(r)$,

|  |  |  |
| --- | --- | --- |
|  | $\overline{f}(r)=\frac{1}{\omega\_{d-1}r^{d-1}}\int\_{\mathbb{S}^{d-1}(r)}f(z)\mathrm{d}\mathcal{H}^{d-1}(z)=\frac{1}{\omega\_{d-1}}\int\_{\mathbb{S}^{d-1}}f(rz)\mathrm{d}\mathcal{H}^{d-1}(z).$ |  |

Using the triangle inequality and the relation between $\overline{\rho}$ and $\rho$ we get

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\int\_{\mathrm{B}(0,R)}\left|f(x)-F\right|\rho(x)\mathrm{d}\mathcal{H}^{d}(x)=\int\_{0}^{R}\int\_{\mathbb{S}^{d-1}(r)}\left|f(z)-F\right|\rho(z)\mathrm{d}\mathcal{H}^{d-1}(z)\mathrm{d}r$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\quad\leqslant\int\_{0}^{R}\overline{\rho}(r)\left|\overline{f}(r)-F\right|\mathrm{d}r+\int\_{0}^{R}\frac{\overline{\rho}(r)}{r^{d-1}\omega\_{d-1}}\int\_{\mathbb{S}^{d-1}(r)}\left|f(z)-\overline{f}(r)\right|\mathrm{d}\mathcal{H}^{d-1}(z)\mathrm{d}r$ |  | (A.53) |

We first deal with the second term of the sum. Using the
Poincaré-Wirtinger inequality on the sphere
([A.51](#A1.E51 "In Appendix A A weighted Poincaré-Wirtinger inequality ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), we have

|  |  |  |
| --- | --- | --- |
|  | $\int\_{\mathbb{S}^{d-1}(r)}\left|f(z)-\overline{f}(r)\right|\mathrm{d}\mathcal{H}^{d-1}(z)\leqslant c\_{d}\int\_{\mathbb{S}^{d-1}(r)}\left\|\left.\nabla f(z)\right|\_{z^{\perp}}\right\|\mathrm{d}\mathcal{H}^{d-1}(z),$ |  |

where $\left.\nabla f(z)\right|\_{z^{\perp}}$ is the orthogonal
projection of the gradient on the tangent plane $\{z\}^{\perp}$, so
that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\int\_{0}^{R}\frac{\overline{\rho}(r)}{r^{d-1}\omega\_{d-1}}\int\_{\mathbb{S}^{d-1}(r)}\left|f(z)-\overline{f}(r)\right|\mathrm{d}\mathcal{H}^{d-1}(z)\leqslant c\_{d}\int\_{B(0,r)}\left\|\left.\nabla f(x)\right|\_{x^{\perp}}\right\|\rho(x)\mathrm{d}\mathcal{H}^{d}(x).$ |  | (A.54) |

By the calculation of $F$ above, we see $F$ is also the mean value of
$\overline{f}$ weighted by $\overline{\rho}$. We can therefore control the first
term of the upper bound of ([A.53](#A1.E53 "In Proof. ‣ Appendix A A weighted Poincaré-Wirtinger inequality ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) using the
Poincaré-Wirtinger inequality on the segment
([A.52](#A1.E52 "In Appendix A A weighted Poincaré-Wirtinger inequality ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")):

|  |  |  |
| --- | --- | --- |
|  | $\int\_{0}^{R}\overline{\rho}(r)\left|\overline{f}(r)-F\right|\mathrm{d}r\leqslant c\_{\overline{\rho}}\int\_{0}^{R}\left|\overline{f}^{\prime}(r)\right|\overline{\rho}(r)\mathrm{d}r.$ |  |

Now, notice that:

|  |  |  |
| --- | --- | --- |
|  | $\overline{f}^{\prime}(r)=\lim\_{h\to 0}\frac{\overline{f}(r+h)-\overline{f}(r)}{h}=\lim\_{h\to 0}\frac{1}{\omega\_{d-1}}\int\_{\mathbb{S}^{d-1}}\frac{f((r+h)z)-f(rz)}{h}\mathrm{d}\mathcal{H}^{d-1}(z),$ |  |

from which we deduce

|  |  |  |
| --- | --- | --- |
|  | $\left|\overline{f}^{\prime}(r)\right|\leqslant\frac{1}{\omega\_{d-1}}\int\_{\mathbb{S}^{d-1}}\left|\frac{\partial f}{\partial r}(rz)\right|\mathrm{d}\mathcal{H}^{d-1}(z)=\frac{1}{\omega\_{d-1}r^{d-1}}\int\_{\mathbb{S}^{d-1}(r)}\left|\langle\nabla f(z)\mid\frac{z}{r}\rangle\right|\mathrm{d}\mathcal{H}^{d-1}(z)$ |  |

Integrating this inequality shows that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\int\_{0}^{R}\overline{\rho}(r)\left|\overline{f}(r)-F\right|\mathrm{d}r$ | $\displaystyle\leqslant c\_{\overline{\rho}}\int\_{0}^{R}\frac{\overline{\rho}(r)}{\omega\_{d-1}r^{d-1}}\int\_{\mathbb{S}^{d-1}(r)}\left|\langle\nabla f(z)\mid\frac{z}{r}\rangle\right|\mathrm{d}\mathcal{H}^{d-1}(z)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=c\_{\overline{\rho}}\int\_{\mathrm{B}(0,R)}\left|\langle\nabla f(x)\mid\frac{x}{\left\|x\right\|}\rangle\right|\rho(x)\mathrm{d}\mathcal{H}^{d}(x).$ |  | (A.55) |

From the simple inequality $(a+b)^{2}\leqslant 2(a^{2}+b^{2})$, we get

|  |  |  |
| --- | --- | --- |
|  | $\left|\langle\nabla f(x)\mid\frac{x}{\left\|x\right\|}\rangle\right|+\left\|\left.\nabla f(x)\right|\_{x^{\perp}}\right\|\leqslant\sqrt{2}\left\|\nabla f(x)\right\|.$ |  |

Using the bounds ([A.54](#A1.E54 "In Proof. ‣ Appendix A A weighted Poincaré-Wirtinger inequality ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([A.55](#A1.E55 "In Proof. ‣ Appendix A A weighted Poincaré-Wirtinger inequality ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) in Equation ([A.53](#A1.E53 "In Proof. ‣ Appendix A A weighted Poincaré-Wirtinger inequality ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), we get the desired inequality:

|  |  |  |
| --- | --- | --- |
|  | $\int\_{\mathrm{B}(0,R)}\left|f(x)-F\right|\rho(x)\mathrm{d}\mathcal{H}^{d}(x)\leqslant\sqrt{2}(c\_{d}+c\_{\overline{\rho}})\int\_{\mathrm{B}(0,R)}\left\|\nabla f(x)\right\|\rho(x)\mathrm{d}\mathcal{H}^{d}(x).\qed$ |  |

## Appendix B Proof of Theorem [3.1](#S3.Thmtheorem1 "Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")

### B.1. Existence of partial derivatives

Without loss of generality, we assume that $\bm{\lambda}\_{0}=\bm{0}$.
We start the proof of Theorem [3.1](#S3.Thmtheorem1 "Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") by showing the existence
of partial derivatives for the map $\hat{G}$. In this section, we denote
$e\_{1},\ldots,e\_{N}$ the canonical basis of $\mathbb{R}^{N}$. We start by
rewriting the finite difference defining the partial derivative of
$\hat{G}$ in direction $e\_{i}$ using the coarea formula. Fix $\left\|\bm{\lambda}\right\|<T\_{tr}$. For $t>0$, one
has:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\frac{1}{t}(\hat{G}(\bm{\lambda}+t\bm{e}\_{i})-\hat{G}(\bm{\lambda}))$ | $\displaystyle=\frac{1}{t}\int\_{K(\bm{\lambda}+t\bm{e}\_{i})\setminus K(\bm{\lambda})}\hat{\rho}(x)\mathrm{d}\mathcal{H}^{d}(x)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\frac{1}{t}\int\_{\lambda\_{i}}^{\lambda\_{i}+t}\hat{g}(s)\mathrm{d}s,$ |  | (B.56) |

where the function $\hat{g}$ is defined by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{g}(s):=\int\_{\cap\_{j\neq i}K\_{j}(\lambda\_{j})\cap f\_{i}^{-1}(s)}\frac{\hat{\rho}(x)}{\left\|\nabla f\_{i}(x)\right\|}\mathrm{d}\mathcal{H}^{d-1}(x).$ |  | (B.57) |

The same reasoning also holds for $t<0$. We now claim that $\hat{g}$ is
continuous on some interval
around $\lambda\_{i}$, which by ([B.56](#A2.E56 "In B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and the Fundamental
Theorem of Calculus will imply that the limit as $t\to 0$ in
([B.56](#A2.E56 "In B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) exists and is equal to $\hat{g}(\bm{\lambda})$, thus
establishing the formula ([3.14](#S3.E14 "In Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). The continuity of $\hat{g}$ follows from the next proposition, which
is formulated in a slightly more general way.

###### Proposition B.1.

Let $\sigma$ be a continuous non-negative function on $\hat{X}$ and let
$\omega$ be the modulus of continuity of $\sigma$. Given any vector
$\bm{\lambda}$ in $\mathbb{R}^{N}$ with $\left\|\bm{\lambda}\right\|\_{\infty}\leqslant T\_{tr}$,
consider the function

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle h:s\in\mathbb{R}\mapsto\int\_{L\cap S\_{s}}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x),$ |  |

where $L:=\bigcap\_{j\neq i}K\_{j}(\lambda\_{j})$ and $S\_{s}:=f\_{i}^{-1}(s)$. Then $h$ is uniformly continuous on
$[-T\_{tr},T\_{tr}]$ and has modulus of continuity

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\omega\_{h}(\delta)=C\_{1}\cdot(\omega(C\_{2}\delta)+\left|\delta\right|),$ |  | (B.58) |

where the constants
only depend on $\left\|f\_{i}\right\|\_{\mathcal{C}^{1,1}}$, $\diam(\hat{X})$, $\varepsilon\_{nd}$,
$\varepsilon\_{tr}$ and $\left\|\sigma\right\|\_{\infty}$.

Taking $\sigma=\hat{\rho}/\left\|\nabla f\_{i}\right\|$ in the previous proposition,
which is continuous using the non-degeneracy condition ([ND](#S3.Ex23 "In Non-degeneracy ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))
and the assumption $f\_{i}\in\mathcal{C}^{1,1}(\hat{X})$, we see that the function
$\hat{g}$ defined by ([B.57](#A2.E57 "In B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) is continuous. This implies the
existence of partial derivatives and establishes formula
([3.14](#S3.E14 "In Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). The proof of Proposition [B.1](#A2.Thmtheorem1 "Proposition B.1. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") requires the following lemma.

###### Lemma B.2.

Assume that the functions $f\_{i}:\hat{X}\to\mathbb{R}$
satisfy ([ND](#S3.Ex23 "In Non-degeneracy ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Then, for every $i\in\{1,\ldots,N\},$
there exists a map $\Phi\_{i}:\hat{X}\times\mathbb{R}\to\mathbb{R}^{d}$ such that:

1. (i)

   For any $(x,t)$ in $\hat{X}\times\mathbb{R}$ such that the curve $\Phi\_{i}(x,[0,t])$ remains in $\hat{X}$, one has $f\_{i}(\Phi\_{i}(x,t))=f\_{i}(x)+t$.
2. (ii)

   The map $\Phi\_{i}$ satisfies the following inequalities for every $x,y\in\hat{X}$, $t\in\mathbb{R}$:

   |  |  |  |  |  |
   | --- | --- | --- | --- | --- |
   |  |  | $\displaystyle\left\|\Phi\_{i}(x,t)-\Phi\_{i}(x,s)\right\|\leqslant\frac{\left|t-s\right|}{\varepsilon\_{nd}}$ |  | (B.59) |
   |  |  |  |  |  |
   | --- | --- | --- | --- | --- |
   |  |  | $\displaystyle\left\|\Phi\_{i}(x,t)-\Phi\_{i}(y,t)\right\|\leqslant\exp(C\_{\Phi}\left|t\right|)\left\|x-y\right\|,$ |  | (B.60) |

   where $C\_{\Phi}:=3C\_{L}/\varepsilon\_{nd}^{2}$.

###### Proof.

We consider the vector field $V\_{i}^{0}(x)=\nabla f\_{i}(x)/\left\|\nabla f\_{i}(x)\right\|^{2}$ on $\hat{X}$, which satisfies
$\left\|V\_{i}^{0}\right\|\_{\infty}\leqslant 1/\varepsilon\_{nd}$ and whose Lipschitz constant
is bounded by $C\_{\Phi}$.
This vector field is extended
to $\mathbb{R}^{d}$ using the orthogonal projection on $\hat{X}$, denoted $p\_{\hat{X}}$,

|  |  |  |
| --- | --- | --- |
|  | $\forall x\in\mathbb{R}^{d},~V\_{i}(x):=V^{0}\_{i}(p\_{\hat{X}}(x)).$ |  |

By
convexity of $\hat{X}$, the map $p\_{\hat{X}}$ is $1$-Lipschitz. This
implies that the Lipschitz constant of $V\_{i}$ is also bounded by
$C\_{\Phi}$. We let $\Phi\_{i}$ be the flow induced by this vector
field, which exists and is for all time since $V\_{i}$ is bounded and uniformly Lipschitz on all of $\mathbb{R}^{d}$. The inequality ([B.59](#A2.E59 "In item ii ‣ Lemma B.2. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) follows from the
definition of integral curves and the bound on $\left\|V\_{i}\right\|$. Any
integral curve $\gamma:[0,T]\to\mathbb{R}^{d}$ of $V\_{i}$ which remains in
$\hat{X}$ satisfies

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle f\_{i}(\gamma(t))$ | $\displaystyle=f\_{i}(\gamma(0))+\int\_{0}^{t}\langle\gamma^{\prime}(s)\mid\nabla f\_{i}(\gamma(s))\rangle\mathrm{d}s$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=f\_{i}(\gamma(0))+\int\_{0}^{t}\langle V\_{i}(\gamma(s))\mid\nabla f\_{i}(\gamma(s))\rangle\mathrm{d}s=f\_{i}(\gamma(0))+t,$ |  |

thus establishing (i). The inequality ([B.60](#A2.E60 "In item ii ‣ Lemma B.2. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) follows from the bound on
the Lipschitz constant of $V\_{i}$ and from Gronwall’s lemma.
∎

Figure 4. Illustration of the proof of Proposition [B.1](#A2.Thmtheorem1 "Proposition B.1. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

###### Proof of Proposition [B.1](#A2.Thmtheorem1 "Proposition B.1. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").

Let $t,s$ be small enough so that the transversality condition
([T](#S3.Ex24 "In Definition 3.2 (Transversality). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) holds (that is $t,s\in[-T\_{tr},T\_{tr}]$). We assume
that $t<s$ so as to fix the signs of some expressions. We consider
the following partition of the facet $S\_{t}\cap L$, whose geometric
meaning is illustrated in Figure [4](#A2.F4 "Figure 4 ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"):

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle A\_{t}=\{x\in S\_{t}\cap L\mid\Phi\_{i}(x,[0,s-t])\subseteq L\}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle B\_{t}=\{x\in S\_{t}\cap L\mid\exists u\in[0,s-t),~\Phi\_{i}(x,u)\in\partial L\}.$ |  |

Similarly, we define

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle A\_{s}=\{x\in S\_{s}\cap L\mid\Phi\_{i}(x,[t-s,0])\subseteq L\}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle B\_{s}=\{x\in S\_{s}\cap L\mid\exists u\in(t-s,0],~\Phi\_{i}(x,u)\in\partial L\}.$ |  |

Recall that by definition,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $h(t)=\int\_{A\_{t}}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)+\int\_{B\_{t}}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x),$ |  | (B.61) |

where the integral is with respect to the $(d-1)$-dimensional
Hausdorff measure. Our strategy to show the continuity of $h$ is to
prove that the first term in the sums defining $h(t)$ and $h(s)$ in
([B.61](#A2.E61 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) are close, namely

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left|\int\_{A\_{t}}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)-\int\_{A\_{s}}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)\right|\leqslant C\_{3}\cdot(\left|s-t\right|+\omega(C\left|s-t\right|))$ |  | (B.62) |

and then that the terms involving $B\_{t},B\_{s}$ are small (recall
that both sets depend on $t$ *and* $s$):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\int\_{B\_{t}}\left|\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)\right|+\int\_{B\_{s}}\left|\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)\right|\leqslant C\_{4}\cdot\left|s-t\right|$ |  | (B.63) |

The combination of the estimates ([B.62](#A2.E62 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([B.63](#A2.E63 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))
implies the desired inequality ([B.58](#A2.E58 "In Proposition B.1. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). We now turn to the
proof of these estimates, and that the constants $C\_{3}$ and $C\_{4}$ in
these estimates depend on $\left\|f\_{i}\right\|\_{\mathcal{C}^{1,1}}$, $\diam(\hat{X})$,
$\varepsilon\_{nd}$, $\varepsilon\_{tr}$ and $\left\|\sigma\right\|\_{\infty}$.

Proof of Estimate ([B.62](#A2.E62 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). By
Lemma [B.2](#A2.Thmtheorem2 "Lemma B.2. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").(i), for any point $x$ in $A\_{t}$ one has
$f\_{i}(\Phi\_{i}(x,s-t))=s$, so that the map $F(x):=\Phi\_{i}(x,s-t)$
induces a bijection between the sets $A\_{t}$ and $A\_{s}$. As a
consequence of ([B.60](#A2.E60 "In item ii ‣ Lemma B.2. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), the restriction of $F$ to
$A\_{t}$ is a bi-Lipschitz bijection between the sets $A\_{t}$ and $A\_{s}$,
with Lipschitz constant

|  |  |  |
| --- | --- | --- |
|  | $\max\{\left\|F^{-1}\right\|\_{\Lip(A\_{s})},\ \left\|F\right\|\_{\Lip(A\_{t})}\}\leqslant\exp(C\_{\Phi}\left|s-t\right|).$ |  |

Using a Lipschitz change of variable formula, we get

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\int\_{A\_{t}}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)$ | $\displaystyle=\int\_{F^{-1}(A\_{s})}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant\left\|F^{-1}\right\|\_{\Lip(A\_{s})}^{d-1}\int\_{A\_{s}}\sigma(F^{-1}(x))\mathrm{d}\mathcal{H}^{d-1}(x)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant\exp(C\_{\Phi}(d-1)\left|s-t\right|)\int\_{A\_{s}}\sigma(F^{-1}(x))\mathrm{d}\mathcal{H}^{d-1}(x).$ |  | (B.64) |

By definition of the modulus of continuity and thanks to ([B.59](#A2.E59 "In item ii ‣ Lemma B.2. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")),

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\left|\sigma(F^{-1}(x))-\sigma(x)\right|$ | $\displaystyle\leqslant\omega(\left\|F^{-1}(x)-x\right\|)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\omega(\left\|\Phi(x,s-t)-x\right\|)\leqslant\omega(\left|s-t\right|/\varepsilon\_{nd})$ |  |

Integrating this inequality, we get

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\int\_{A\_{s}}\sigma(F^{-1}(x))\mathrm{d}\mathcal{H}^{d-1}(x)$ | $\displaystyle\leqslant\int\_{A\_{s}}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)+\mathcal{H}^{d-1}(A\_{s})\omega(\left|s-t\right|/\varepsilon\_{nd})$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant\int\_{A\_{s}}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)+\mathcal{H}^{d-1}(\hat{X})\omega(\left|s-t\right|/\varepsilon\_{nd})$ |  | (B.65) |

where the second inequality uses the monotonicity of the
$(d-1)$-dimensional Hausdorff measure of the boundary of a convex set
with respect to inclusion, see [[32](#bib.bib32), p.211]. Combining
([B.64](#A2.E64 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([B.65](#A2.E65 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) we get

|  |  |  |
| --- | --- | --- |
|  | $\int\_{A\_{t}}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)\leqslant\exp(C\_{\Phi}(d-1)\left|s-t\right|)\left(\int\_{A\_{s}}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)+\mathcal{H}^{d-1}(\hat{X})\omega(\left|s-t\right|/\varepsilon\_{nd})\right)$ |  |

so that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\int\_{A\_{t}}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)-\int\_{A\_{s}}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)$ | $\displaystyle\leqslant(\exp(C\_{\Phi}(d-1)\left|s-t\right|)-1)\left\|\sigma\right\|\_{\infty}\mathcal{H}^{d-1}(\hat{X})+$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\qquad\exp(C\_{\Phi}(d-1)\left|s-t\right|)\mathcal{H}^{d-1}(\hat{X})\omega(\left|s-t\right|/\varepsilon\_{nd})$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant C\_{3}\cdot(\left|s-t\right|+\omega(\left|s-t\right|/\varepsilon\_{nd})),$ |  |

where the constant $C\_{3}$ depends on $C\_{L}$, $\varepsilon\_{nd}$, $\varepsilon\_{tr}$,
$\left\|\sigma\right\|\_{\infty}$ and $\diam(\hat{X})$. Exchanging the role of $s$
and $t$ completes the proof of ([B.62](#A2.E62 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")).

Proof of ([B.63](#A2.E63 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). By definition, for every
point $x$ in the set $B\_{t}$, the curve $\Phi\_{i}(x,[0,s-t])$ must cross the
boundary of $L$ at some point, so that

|  |  |  |
| --- | --- | --- |
|  | $u(x):=\min\{v\in[0,s-t]\mid\Phi\_{i}(x,v)\in\partial L\}$ |  |

is well defined. We write $P(x):=\Phi\_{i}(x,u(x))$ for the corresponding
point on the boundary of $L$. By definition of $u(x)$, the curve
$\Phi(x,[0,u(x)])$ is included in $L$, so that by
Lemma [B.2](#A2.Thmtheorem2 "Lemma B.2. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport").(i) we have $f\_{i}(P(x))=t+u(x)$. This shows

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle P(B\_{t})\subseteq\Lambda:=\partial L\cap f\_{i}^{-1}([t,s]).$ |  | (B.66) |

We now prove that the map $P$ satisfies a reverse-Lipschitz
inequality. Note that for any point $x$ in $B\_{t}$,

|  |  |  |
| --- | --- | --- |
|  | $x=\Phi\_{i}(P(x),-u(x))=\Phi\_{i}(P(x),t-f\_{i}(P(x))),$ |  |

Using the
bounds ([B.60](#A2.E60 "In item ii ‣ Lemma B.2. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([B.59](#A2.E59 "In item ii ‣ Lemma B.2. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), we get that for
any $x,y$ in $B\_{t}$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\left\|x-y\right\|$ | $\displaystyle\leqslant\left\|\Phi\_{i}(P(x),t-f\_{i}(P(x)))-\Phi\_{i}(P(y),t-f\_{i}(P(y)))\right\|$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant\left\|\Phi\_{i}(P(x),t-f\_{i}(P(x)))-\Phi\_{i}(P(y),t-f\_{i}(P(x)))\right\|$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\qquad\qquad+\left\|\Phi\_{i}(P(y),t-f\_{i}(P(x)))-\Phi\_{i}(P(y),t-f\_{i}(P(y)))\right\|$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant\exp(C\_{\Phi}T\_{tr})\left\|P(x)-P(y)\right\|+\left|f\_{i}(P(x))-f\_{i}(P(y))\right|/\varepsilon\_{nd}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant C^{\prime}\left\|P(x)-P(y)\right\|$ |  |

where $C^{\prime}:=\exp(C\_{\Phi})+C\_{L}/\varepsilon\_{nd}$; we have used that $T\_{tr}\leqslant 1$.
We can now bound the $(d-1)$–Hausdorff measure of $B\_{t}$ from that of
$\Lambda$ using this Lipschitz bound and the inclusion ([B.66](#A2.E66 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{H}^{d-1}(B\_{t})\leqslant\mathcal{H}^{d-1}(P^{-1}(P(B\_{t})))\leqslant C^{\prime d-1}\mathcal{H}^{d-1}(\Lambda).$ |  | (B.67) |

What remains to be done is to prove that the $(d-1)$–Hausdorff measure of
$\Lambda$ behaves like $\BigO(\left|s-t\right|)$, and this is where the transversality
condition will enter.

Let us write

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle F\_{j}:=\begin{cases}f\_{j}^{-1}(\lambda\_{j}),&j\neq 0,i,\\ \partial\hat{X}\cap\partial L,&j=0.\end{cases}$ |  |

Then $\partial L$ can be
partitioned (up to a $\mathcal{H}^{d-1}$–negligible set) into faces
$\partial L=\cup\_{j\neq i}(F\_{j}\cap L)$ and using the
coarea formula on each of the facets we get (writing $B:=f\_{i}^{-1}([t,s])$)

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{H}^{d-1}(\Lambda)$ | $\displaystyle=\sum\_{j\neq i}\mathcal{H}^{d-1}(B\cap(F\_{j}\cap L))$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{j\neq i}\int\_{B\cap(F\_{j}\cap L)}\mathrm{d}\mathcal{H}^{d-1}(x)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{j\neq i}\int\_{t}^{s}\int\_{S\_{u}\cap(F\_{j}\cap L)}\frac{1}{J\_{ij}(x)}\mathrm{d}\mathcal{H}^{d-2}(x)\mathrm{d}u,$ |  | (B.68) |

where and $J\_{ij}(x)$ is the Jacobian of the restriction of the function
$f\_{i}$ to the hypersurface $F\_{j}$. More
precisely,

|  |  |  |
| --- | --- | --- |
|  | $J\_{ij}(x)=\left\|\nabla f\_{i}(x)-\langle\nabla f\_{i}(x)\mid\nabla f\_{j}(x)\rangle\frac{\nabla f\_{j}(x)}{\left\|\nabla f\_{j}(x)\right\|^{2}}\right\|$ |  |

if $j\neq 0$, $i$, and

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle J\_{i0}(x)=\left\|\nabla f\_{i}(x)-\langle\nabla f\_{i}(x)\mid v\_{0}(x)\rangle v\_{0}(x)\right\|$ |  |

where $v\_{0}(x)\in\mathcal{N}\_{x}\hat{X}$ is a unit vector. Since $\hat{X}$ is convex, for $\mathcal{H}^{d-1}$ a.e. $x\in\partial\hat{X}$, the normal cone $\mathcal{N}\_{x}\hat{X}$ consists of only one direction, thus for such $x$ there is a unique choice of $v\_{0}(x)$.
Let us write $v\_{i}=\nabla f\_{i}(x)/\left\|\nabla f\_{i}(x)\right\|$ and $v\_{j}$ for either $\nabla f\_{j}(x)/\left\|\nabla f\_{j}(x)\right\|$ or $v\_{0}(x)$, we then have using ([T](#S3.Ex24 "In Definition 3.2 (Transversality). ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle J\_{ij}(x)^{2}$ | $\displaystyle=\left\|\nabla f\_{i}(x)\right\|^{2}\left\|v\_{i}-\langle v\_{i}\mid v\_{j}\rangle v\_{j}\right\|^{2}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\geqslant\left\|\nabla f\_{i}(x)\right\|^{2}(1-\langle v\_{i}\mid v\_{j}\rangle^{2})$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\geqslant\varepsilon^{2}\_{nd}\varepsilon^{2}\_{tr}.$ |  | (B.69) |

Combining ([B.68](#A2.E68 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([B.69](#A2.E69 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) gives us

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{H}^{d-1}(\Lambda)$ | $\displaystyle\leqslant\frac{1}{\varepsilon\_{nd}\varepsilon\_{tr}}\sum\_{j\neq i}\int\_{t}^{s}\mathcal{H}^{d-2}(S\_{u}\cap(F\_{j}\cap L))\mathrm{d}u$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\frac{1}{\varepsilon\_{nd}\varepsilon\_{tr}}\int\_{t}^{s}\mathcal{H}^{d-2}(S\_{u}\cap\partial L)\mathrm{d}u.$ |  | (B.70) |

By definition, a point belongs to the intersection $S\_{u}\cap\partial L$ if it
lies in the singularity set $\Sigma(\bm{\lambda}(u))$ where
$\bm{\lambda}(u)=(\lambda\_{1},\ldots,\lambda\_{i-1},u,\lambda\_{i+1},\ldots,\lambda\_{N})$. By
Lemma [3.2](#S3.Thmtheorem2 "Proposition 3.2. ‣ 3.3. A control on the (𝑑-2)–Hausdorff measure of singular points ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"),

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{H}^{d-2}(S\_{u}\cap\partial L)\leqslant\mathcal{H}^{d-2}(\Sigma(\bm{\lambda}(u)))\leqslant C(d,\diam(\hat{X}))\cdot\frac{1}{\varepsilon\_{tr}}.$ |  | (B.71) |

Combining ([B.67](#A2.E67 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")), ([B.70](#A2.E70 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([B.71](#A2.E71 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"))
we obtain $\mathcal{H}^{d}(B\_{t})\leqslant C\cdot\left|t-s\right|$, which implies
([B.63](#A2.E63 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) using the boundedness of $\sigma$.
∎

### B.2. Continuity of partial derivatives

We prove that the function $\hat{G}$ defined in ([3.12](#S3.E12 "In 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) is continuously
differentiable by controlling the modulus of continuity of its partial
derivatives given in ([3.14](#S3.E14 "In Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Again, we start with a slightly more
general proposition.

###### Proposition B.3.

Let $\sigma$ be a
continuous function on $\hat{X}$ with modulus of continuity
$\omega$ and $i\in\{1,\cdots,N\}$. Consider the following function on the cube
$Q:=[-T\_{tr},T\_{tr}]^{N}$:

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle H(\bm{\lambda}):=\int\_{K(\bm{\lambda})\cap f\_{i}^{-1}(\lambda\_{i})}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x).$ |  |

Then $H$ is uniformly continuous on $Q$ with modulus of continuity

|  |  |  |
| --- | --- | --- |
|  | $\omega\_{H}(\delta)=C\_{1}\cdot(\omega(C\_{2}\delta)+\left|\delta\right|),$ |  |

where the constants
only depend on $\left\|f\_{i}\right\|\_{\mathcal{C}^{1,1}(\hat{X})}$, $\diam(\hat{X})$, $\varepsilon\_{nd}$,
$\varepsilon\_{tr}$, and $\left\|\sigma\right\|\_{\infty}$.

###### Proof.

Proposition [B.1](#A2.Thmtheorem1 "Proposition B.1. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") yields that
the function $H$ is uniformly continuous with respect to changes of
the $i$th variable. Let us now consider variations with respect to
the $j$th variable, with $j\neq i$ by introducing

|  |  |  |
| --- | --- | --- |
|  | $h:s\in[-T\_{tr},T\_{tr}]\mapsto\int\_{K(\lambda\_{1},\ldots,\lambda\_{j-1},s,\lambda\_{j+1},\ldots,\lambda\_{N})\cap f\_{i}^{-1}(\lambda\_{i})}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x).$ |  |

for some fixed $\bm{\lambda}\in[-T\_{tr},T\_{tr}]^{N}$. We can
rewrite the difference between two values of $h$ using the coarea
formula. As before, we assume $s>t$ to fix the signs and introduce $L^{\prime}:=\hat{X}\cap\bigcap\_{k\not\in\{i,j\}}K\_{k}(\lambda\_{k})$ and $S:=f\_{i}^{-1}(\lambda\_{i})$. We have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle h(s)-h(t)$ | $\displaystyle=\int\_{L^{\prime}\cap K\_{j}(s)\cap S}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)-\int\_{L^{\prime}\cap K\_{j}(t)\cap S}\sigma(x)\mathrm{d}\mathcal{H}^{d-1}(x)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\int\_{t}^{s}\int\_{L^{\prime}\cap S\cap f\_{j}^{-1}(u)}\frac{\sigma(x)}{J\_{ij}(x)}\mathrm{d}\mathcal{H}^{d-2}(x)\mathrm{d}u,$ |  |

where the Jacobian factor $J\_{ij}\geqslant\varepsilon\_{nd}\varepsilon\_{tr}$ from
([B.69](#A2.E69 "In Proof of Proposition . ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Therefore,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $h(s)\leqslant h(t)+\frac{\left\|\sigma\right\|\_{\infty}}{\varepsilon\_{nd}\varepsilon\_{tr}}\int\_{t}^{s}\mathcal{H}^{d-2}(L\cap S\cap f^{-1}(u))\mathrm{d}u.$ |  | (B.72) |

Just as in the proof of
Proposition [B.1](#A2.Thmtheorem1 "Proposition B.1. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"), the set $L\cap S\cap f^{-1}(u)$ is
included in the set
$\Sigma(\lambda\_{1},\ldots,\lambda\_{j-1},u,\lambda\_{j},\ldots,\lambda\_{N})$. Thus,
by Lemma [3.2](#S3.Thmtheorem2 "Proposition 3.2. ‣ 3.3. A control on the (𝑑-2)–Hausdorff measure of singular points ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"),

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{H}^{d-2}(L\cap S\cap f^{-1}(u))\leqslant\frac{C(d,\hat{X})}{\varepsilon\_{tr}}.$ |  | (B.73) |

Combining ([B.72](#A2.E72 "In Proof. ‣ B.2. Continuity of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) and ([B.73](#A2.E73 "In Proof. ‣ B.2. Continuity of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")) we can see that the function $h$ is Lipschitz with constant

|  |  |  |
| --- | --- | --- |
|  | $C\_{h}:=C(d,\hat{X})\frac{\left\|\sigma\right\|\_{\infty}}{\varepsilon\_{nd}\varepsilon\_{tr}^{2}}.$ |  |

Finally,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\left|H(\bm{\mu})-H(\bm{\lambda})\right|$ | $\displaystyle\leqslant\sum\_{j=1}^{N}\left|H(\lambda\_{1},\ldots,\lambda\_{k-1},\mu\_{j},\ldots,\mu\_{N})-H(\lambda\_{1},\ldots,\lambda\_{j},\mu\_{j+1},\ldots,\mu\_{N})\right|$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant\omega\_{h}(\left|\mu\_{i}-\lambda\_{i}\right|)+\sum\_{j\neq i}C\_{h}\left|\mu\_{j}-\lambda\_{j}\right|$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leqslant\omega\_{h}(\left\|\mu-\lambda\right\|\_{\infty})+(N-1)C\_{h}\left\|\mu-\lambda\right\|\_{\infty},$ |  |

where $\omega\_{h}$ is the modulus of continuity defined in
Proposition [B.1](#A2.Thmtheorem1 "Proposition B.1. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport"). This establishes the uniform continuity
of the function $H$, with the desired modulus of continuity.
∎

### B.3. Proof of Theorem [3.1](#S3.Thmtheorem1 "Theorem 3.1. ‣ Transversality ‣ 3.1. Assumptions and statement of the theorem. ‣ 3. Local regularity in a 𝑐-exponential chart ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")

Proposition [B.1](#A2.Thmtheorem1 "Proposition B.1. ‣ B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") shows that the partial derivative $\hat{G}$ with
respect to the variable $\lambda\_{i}$ exists and that its expression is given
by ([B.57](#A2.E57 "In B.1. Existence of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport")). Applying Proposition [B.3](#A2.Thmtheorem3 "Proposition B.3. ‣ B.2. Continuity of partial derivatives ‣ Appendix B Proof of Theorem ‣ Convergence of a Newton algorithm for semi-discrete optimal transport") with $\sigma(x)=\hat{\rho}(x)/\left\|\nabla f\_{i}(x)\right\|$, we obtain $\mathcal{C}^{0,\alpha}$ regularity for
each of the partial derivatives of $\hat{G}$ on the cube $Q:=[-T\_{tr},T\_{tr}]^{N}$ from the $\mathcal{C}^{0,\alpha}$ regularity of $\hat{\rho}$. Moreover, the $\mathcal{C}^{0,\alpha}$ constant of each partial derivative over $Q$
is controlled by

|  |  |  |
| --- | --- | --- |
|  | $C(\diam(\hat{X}),\varepsilon\_{nd},\varepsilon\_{tr},\left\|\nabla f\_{i}\right\|\_{\mathcal{C}^{1,1}(X)},\left\|\hat{\rho}\right\|\_{\mathcal{C}^{0,\alpha}(X)}).$ |  |
