<!-- fulltext source=arxiv_html slug=arXiv-1503.00947 fetched=2026-09-18T06:57:17+00:00 -->

# Discretization of the 3D Monge-Ampere operator, between Wide Stencils and Power Diagrams

Jean-Marie Mirebeau
Note: 
CNRS, University Paris Dauphine, UMR 7534, Laboratory CEREMADE, Paris, France.
  
ANR grant NS-LBR ANR-13-JS01-0003-01

###### Abstract

We introduce a monotone (degenerate elliptic) discretization of the Monge-Ampere operator, on domains discretized on cartesian grids. The scheme is consistent provided the solution hessian condition number is uniformly bounded.
Our approach enjoys the simplicity of the Wide Stencil method [[FO11](#bib.bibx8)], but significantly improves its accuracy using ideas from discretizations of optimal transport based on power diagrams [[AHA98](#bib.bibx1)].
We establish the global convergence of a damped Newton solver for the discrete system of equations.
Numerical experiments, in three dimensions, illustrate the scheme efficiency.

## 1 Introduction

We introduce a discretization of the Monge-Ampere operator, on three dimensional cartesian grids, which is simultaneously monotone and consistent.
Existing consistent schemes, based e.g. on Finite Elements [[BN12](#bib.bibx4), [Nei12](#bib.bibx14)] or Finite Differences [[LR05](#bib.bibx12)], are not monotone, and thus require the PDE solution to be sufficiently smooth, and the numerical solver to be well initialized.
Existing monotone schemes, based on Wide Stencil discretizations [[FO11](#bib.bibx8), [Obe06](#bib.bibx15)], suffer from a consistency error depending on the discretization stencil angular resolution.
Filtered schemes [[FO13](#bib.bibx9)] combine a monotone and a consistent scheme, and attempt to cumulate their robustness and accuracy; improving either of the constituting schemes will benefit to the filtered combination.
A monotone and consistent scheme is introduced in [[BCM14](#bib.bibx2)], but it is limited to two dimensions. Geometric approaches [[OP89](#bib.bibx16)] are discussed in the third paragraph.

The proposed numerical scheme belongs to the Wide-Stencil category [[Obe06](#bib.bibx15)], in the sense that we actually define a family of schemes parameterized by a user chosen stencil. Larger stencils provide consistency for strongly anisotropic problems (i.e. for which the solution hessian is almost degenerate), but at the cost of an increased computation time.
The choice of stencil is left to the user; let us mention that in the special case of [[BCM14](#bib.bibx2)] an automatic (solution adaptive, local, anisotropic, and parameter free) stencil construction could be designed.
Our numerical experiments show that small stencils, of radius $\sqrt{3}$ or $\sqrt{6}$, see the table page [1](#S3.T1 "Table 1 ‣ 3 Numerical experiments ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), already yield convincing results. The scheme is dimension independent, but we emphasize its application to three dimensional domains, which is tractable and tested.

Our approach is also inspired by [[OP89](#bib.bibx16)] and the discretizations of optimal transport [[AHA98](#bib.bibx1), [Mer11](#bib.bibx13), [Lév14](#bib.bibx11)] based on global geometric structures, up to two differences.
The first modification, a *symmetrization* see Remark [1.9](#S1.Thmtheorem9 "Remark 1.9 (Symmetrization). ‣ Outline: ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), is required to operate our method with the Dirichlet boundary conditions of the standard Monge-Ampere problem ([1](#S1.E1 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), instead of the second boundary conditions implicit in optimal transportation.
The second modification *localizes* these methods by limiting interactions to close discretization points, see Remark [1.10](#S1.Thmtheorem10 "Remark 1.10 (Localization). ‣ Outline: ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), which considerably simplifies their numerical implementation.
The methods [[OP89](#bib.bibx16), [AHA98](#bib.bibx1), [Mer11](#bib.bibx13), [Lév14](#bib.bibx11)] indeed rely on global geometric structures named power diagrams, which generalize Voronoï diagrams.
Their construction requires state of the art methods of discrete geometry, which especially in 3D are still an active subject of research. For instance [[Lév14](#bib.bibx11)] mentions arbitrary precision arithmetic, arithmetic filtering, expansion arithmetics and symbolic perturbation, merely for the consistent evaluation of geometric predicates. Our approach is in contrast local and requires none of these subtleties.
We show that this simplification preserves consistency in the setting of viscosity solutions, see §[2.3](#S2.SS3 "2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), but at the following price: the solution hessian condition number must be uniformly bounded, and the weak Alexandroff solutions cannot be recovered.

We fix throughout this paper an open, convex and bounded domain $\Omega\subseteq{\mathbb{R}}^{d}$, $d\geq 2$ ($d=3$ in the numerical section §[3](#S3 "3 Numerical experiments ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")).
Given a positive density $\rho\in C^{0}(\overline{\Omega},{\mathbb{R}}\_{+}^{\*})$, and some Dirichlet data $\sigma\in C^{0}(\partial\Omega,{\mathbb{R}})$, we set the goal of approximating numerically the unique viscosity solution [[CIL92](#bib.bibx5), [Gut01](#bib.bibx10)] of

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{cases}\det(\nabla^{2}u)=\rho&\text{on }\Omega,\\ u=\sigma&\text{on }\partial\Omega,\\ u\text{ convex,}\end{cases}$ |  | (1) |

where $\nabla^{2}u$ denotes the hessian matrix of $u$.
The PDE domain $\Omega$ is discretized on a cartesian grid $X$. Up to a linear change of coordinates, encoding scaling, rotation and offset, we may assume that

|  |  |  |
| --- | --- | --- |
|  | $X\subseteq\Omega\cap{\mathbb{Z}}^{d}.$ |  |

The discussion of the discretization of the boundary $\partial\Omega$ is postponed to Remark [2.4](#S2.Thmtheorem4 "Remark 2.4 (Boundary discretization). ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams").

###### Definition 1.1.

We denote by ${\mathbb{U}}$ the collection of maps $u:X\cup\partial\Omega\to{\mathbb{R}}$.

###### Definition 1.2.

A discrete operator ${\cal D}$ associates to each $u\in{\mathbb{U}}$ a discrete map ${\cal D}u:X\to{\mathbb{R}}$.

Given some discretization ${\cal D}$ of the Monge-Ampere operator, the counterpart of ([1](#S1.E1 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) takes the form: find $u\in{\mathbb{U}}$ such that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{cases}{\cal D}u=\rho&\text{on }X,\\ u=\sigma&\text{on }\partial\Omega.\end{cases}$ |  | (2) |

The constraint “$u$ convex” is not spelled explicitly in ([2](#S1.E2 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), contrary to ([1](#S1.E1 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), but some discrete counterpart of it often follows from the identity ${\cal D}u=\rho$ [[BCM14](#bib.bibx2)].
Before discretizing the Monge-Ampere operator, we need to introduce a more basic operator $\Delta\_{e}$, $e\in{\mathbb{Z}}^{d}$, aimed at approximating the second order difference $\langle e,(\nabla^{2}u(x))e\rangle$. If $x\in X$, $x+e\in X$ and $x-e\in X$, then we set classically

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta\_{e}u(x):=u(x+e)-2u(x)+u(x-e).$ |  | (3) |

In general, one may not have $x+e\in X$, for instance if $x+e$ lies outside $\Omega$. Hence we introduce

|  |  |  |  |
| --- | --- | --- | --- |
|  | $h\_{x}^{e}:=\min\{h>0;\,x+he\in X\cup\partial\Omega\}.$ |  | (4) |

Let $h^{+}:=h\_{x}^{e}$ and $h^{-}:=h\_{x}^{-e}$. Only one linear combination of $u(x)$, $u(x+h^{+}e)$ and $u(x-h^{-}e)$ is consistent with $\langle e,(\nabla^{2}u(x))e\rangle$, namely

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta\_{e}u(x):=\frac{2}{h^{+}+h^{-}}\left(\frac{u(x+h^{+}e)-u(x)}{h^{+}}+\frac{u(x-h^{-}e)-u(x)}{h^{-}}\right).$ |  | (5) |

We next illustrate the notions of consistency and monotonicity (degenerate ellipticity) using two now classical discretizations of the Monge-Ampere operator.
The Finite Differences (FD) [[LR05](#bib.bibx12)] approximation of the Monge-Ampere operator is defined as the determinant of a naive but consistent approximation of the hessian matrix of $u$ by finite differences: denoting by $(e\_{i})\_{1\leq i\leq d}$ the canonical basis of ${\mathbb{R}}^{d}$

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal D}^{\text{\tiny FD}}u(x):=\det(\delta\_{ij})\_{1\leq i,j\leq 3},\quad\text{ with }\delta\_{ij}=\begin{cases}\Delta\_{e\_{i}}u(x)&\text{ if }i=j,\\ \frac{1}{4}\left(\Delta\_{e\_{i}+e\_{j}}u(x)-\Delta\_{e\_{i}-e\_{j}}u(x)\right)&\text{ if }i\neq j.\end{cases}$ |  | (6) |

The Wide Stencil (WS) [[FO11](#bib.bibx8)] approximation of the Monge-Ampere operator is defined as follows: denoting by ${\cal B}\subseteq({\mathbb{Z}}^{d})^{d}$ a finite collection of $d$-plets of pairwise orthogonal vectors

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal D}^{\text{\tiny WS}}\_{\cal B}u(x):=\min\_{B\in{\cal B}}\prod\_{e\in B}\frac{\max\{\Delta\_{e}u(x),0\}}{\|e\|^{2}}.$ |  | (7) |

###### Definition 1.3.

An operator ${\cal D}$ is said Degenerate Elliptic of second order (DE2), with stencil $V$, iff for all $x\in X$, ${\cal D}u(x)$ is a non-decreasing function of the second order differences $(\Delta\_{e}u(x))\_{e\in V}$.

By construction, scheme WS is DE2, with stencil $\{e\in{\mathbb{Z}}^{d};\,\exists B\in{\cal B},\,e\in B\}$. Scheme FD in contrast is *not* DE2. Degenerate Ellipticity comes with strong guarantees including a maximum principle for the discrete solutions of ([2](#S1.E2 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), and guaranteed convergence of Euler iterative solvers for this discrete system [[Obe06](#bib.bibx15)]. It allows to recover non-smooth viscosity solutions of ([1](#S1.E1 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), see §[2.3](#S2.SS3 "2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), and plays a crucial role in the proof §[2.2](#S2.SS2 "2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") of the global convergence of a damped Newton solver for ([2](#S1.E2 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")).

Let $S\_{d}$ denote the set of symmetric $d\times d$ matrices, and let $S\_{d}^{+}\subseteq S\_{d}$ be the subset of positive definite matrices.
In order to analyze the consistency of these schemes, we introduce for each $M\in S\_{d}^{+}$ the norm $\|\cdot\|\_{M}$ and the map $u\_{M}\in{\mathbb{U}}$ defined by

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\|x\|\_{M}$ | $\displaystyle:=\sqrt{\langle x,Mx\rangle},$ | $\displaystyle u\_{M}(x):=\frac{1}{2}\|x\|\_{M}^{2}.$ |  | (8) |

###### Definition 1.4.

The consistency set of an operator ${\cal D}$ is the collection of all $M\in S\_{d}^{+}$ such that
${\cal D}u\_{M}=\det(M)$, identically on $X$.

The consistency set of scheme FD is the whole $S\_{d}^{+}$; in fact, the identity ${\cal D}u\_{M}(x)=\det(M)$ also holds for non-positive matrices, although they are irrelevant for our application. The consistency set of scheme WS is in contrast of *empty interior*; precisely, it consists of matrices $M\in S\_{d}^{+}$ for which some $B\in{\cal B}$ is an eigenbasis [[Obe06](#bib.bibx15)]. Stated otherwise, the consistency of scheme WS is an asymptotic property, obtained by growing the stencil size to infinity.

A combination
${\cal D}u(x)=w(u,x){\cal D}^{\text{\tiny WS}}\_{\cal B}u(x)+(1-w(u,x)){\cal D}^{\text{\tiny FD}}u(x)$
of schemes FD and WS is considered in [[FO13](#bib.bibx9)]. The weight $w(u,x)\in[0,1]$ depends on the local behavior of $u$ close to $x$, as well as on the discretization scale and the angular resolution of the stencil ${\cal B}$. Strictly speaking, the weighted scheme loses both the degenerate ellipticity of ${\cal D}^{\text{\tiny WS}}\_{\cal B}$, and the consistency of ${\cal D}^{\text{\tiny FD}}$.
Nevertheless [[FO13](#bib.bibx9)] establishes convergence in the setting of viscosity solutions, and illustrates numerically (in two space dimensions) that the weight $w(u,x)$ favors the consistent scheme ${\cal D}^{\text{\tiny FD}}$ except close to the most singular features of the solution. Second order accuracy may in principle be achieved even on a degenerate equation, contrary to the method proposed below. The filtered scheme construction proposed in [[FO13](#bib.bibx9)] is quite flexible, and could be improved by replacing the monotone scheme WS with the more accurate, and still monotone, scheme proposed in this paper.

We propose an alternative solution to the apparent conflict between
between degenerate ellipticity and consistency. The coordinates of a vector $e=(a\_{1},\cdots,a\_{d})\in{\mathbb{Z}}^{d}$ are said co-prime iff $\gcd(a\_{1},\cdots,a\_{d})=1$.

###### Definition 1.5.

We limit our attentions to stencils $V\subseteq{\mathbb{Z}}^{d}\setminus\{0\}$ which are finite, symmetric w.r.t the origin, span ${\mathbb{R}}^{d}$, and which elements have co-prime coordinates. The proposed operator is

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal D}\_{V}u(x):=\Leb\{g\in{\mathbb{R}}^{d};\,\forall e\in V,\,2\langle g,e\rangle\leq\Delta\_{e}u(x)\},$ |  | (9) |

where $\Leb$ denotes $d$-dimensional Lebesgue measure.

The Degenerate Ellipticity of ${\cal D}\_{V}$ is clear: if any second order difference $\Delta\_{e}u(x)$ increases, then the convex polytope appearing in ([9](#S1.E9 "In Definition 1.5. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) increases for inclusion, hence also in volume. Refining slightly this argument we obtain the derivative of ${\cal D}\_{V}u(x)$ with respect to $\Delta\_{e}u(x)$: namely the $(d-1)$-dimensional measure of the facets of ([9](#S1.E9 "In Definition 1.5. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) defined by the equality constraint $2|\langle g,e\rangle|=\Delta\_{e}u(x)$, divided by $\|e\|$ (as a result, ${\cal D}\_{V}u(x)$ is continuously differentiable in $u$, in contrast with ([7](#S1.E7 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"))).
Computing polytopes defined by linear inequalities like ([9](#S1.E9 "In Definition 1.5. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) is, by convex duality, equivalent to computing the convex envelope of a set of points [[PS12](#bib.bibx17)]. Numerous computer libraries are available for that purpose, such as TetGen®or CGAL®(the author made his own routine which takes advantage of the symmetry of the polytope ([9](#S1.E9 "In Definition 1.5. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"))).

The expression ([9](#S1.E9 "In Definition 1.5. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) seems more complex to evaluate than ([6](#S1.E6 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) or ([7](#S1.E7 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")). Yet in our numerical experiments §[3](#S3 "3 Numerical experiments ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), the cost of evaluating the operator ${\cal D}\_{V}$ was dominated by the cost of solving linear systems (when solving ([2](#S1.E2 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) with a damped Newton solver), for which the MUMPS®library was used.
The applicability of Newton’s method to the Monge-Ampere problem is also investigated in [[LR05](#bib.bibx12)], for the continuous problem, and in [[FO11](#bib.bibx8)] and [[Nei12](#bib.bibx14)], for some discretizations. Its super-linear rate of convergence, in the neighborhood of the problem solution, makes it appealing for applications. In contrast, gradient descent [[AHA98](#bib.bibx1)] or first order Euler [[Obe06](#bib.bibx15)] schemes converge slower but benefit from global convergence guarantees with monotone discretizations (iterates converge to the unique solution of the discrete problem, independently of initialization).
For the discretization of interest, we prove §[2.2](#S2.SS2 "2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") that a damped Newton method benefits from *both* a super-exponential rate of convergence close to the discrete problem solution, and a global convergence guarantee.

The following results, established §[2.1](#S2.SS1 "2.1 Consistency ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), show that the consistency set of the proposed scheme is of non-empty interior, in contrast with scheme WS. By Corollary [1.8](#S1.Thmtheorem8 "Corollary 1.8 (Finite stencils are enough). ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), a finite stencil is sufficient to guarantee consistency for all matrices $M\in S\_{d}^{+}$ with condition number below a given bound.

###### Definition 1.6.

For each matrix $M\in S\_{d}^{+}$, we introduce the Voronoi cell and facet

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Vor(M)$ | $\displaystyle:=\{g\in{\mathbb{R}}^{d};\,\forall e\in{\mathbb{Z}}^{d},\,\|g\|\_{M}\leq\|g-e\|\_{M}\},$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Vor(M;e)$ | $\displaystyle:=\{g\in\Vor(M);\,\|g\|\_{M}=\|g-e\|\_{M}\}.$ |  |

An $M$-Voronoi vector is an element $e\in{\mathbb{Z}}^{d}\setminus\{0\}$ such that $\Vor(M;e)\neq\emptyset$; it is said *strict* iff the facet $\Vor(M;e)$ is $(d-1)$-dimensional.

Figure 1: Voronoi cell $\Vor(M)$, Voronoi vectors $e$, and ellipse $\{x\in{\mathbb{R}}^{d};\,\langle x,Mx\rangle\leq 1\}$. Left: 2D, Right: 3D. Note that $e$ traverses the facet $\Vor(M;e)$ at the point $e/2$.

###### Proposition 1.7 (Consistency).

A matrix $M$ is in the consistency set of ${\cal D}\_{V}$ iff $V$ contains all strict $M$-Voronoi vectors.

###### Corollary 1.8 (Finite stencils are enough).

Let $\kappa\geq 1$ and let $V$ collect all elements $e\in{\mathbb{Z}}^{d}$ with norm $\|e\|\leq\kappa\sqrt{d}$ and co-prime coordinates. Then
the consistency set of ${\cal D}\_{V}$ contains all $M\in S\_{d}^{+}$ such that $\kappa\geq\sqrt{\|M\|\|M^{-1}\|}$.

#### Outline:

The results on consistency are established §[2.3](#S2.SS3 "2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), and the global convergence of the damped Newton solver in §[2.2](#S2.SS2 "2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"). We also study in §[2.3](#S2.SS3 "2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") convergence as the grid scale tends to zero, in the setting of viscosity solutions. Numerical experiments §[3](#S3 "3 Numerical experiments ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") illustrate the method’s efficiency.

###### Remark 1.9 (Symmetrization).

A non-symmetrical variant of our Monge-Ampere operator discretization ([9](#S1.E9 "In Definition 1.5. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) can be defined as follows:
for $x\in X$ such that $x+e\in X$ for all $e\in V$

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal D}^{\prime}\_{V}u(x):=\Leb\{g\in{\mathbb{R}}^{d};\,\forall e\in V,\,\langle g,e\rangle\leq u(x+e)-u(x)\}.$ |  | (10) |

In the case of a quadratic function $u\_{M}$, $M\in S\_{d}^{+}$, the polytope appearing in ([10](#S1.E10 "In Remark 1.9 (Symmetrization). ‣ Outline: ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) is merely a translation of ([9](#S1.E9 "In Definition 1.5. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) by the vector $Mx$, so that ${\cal D}^{\prime}\_{V}u\_{M}={\cal D}\_{V}u\_{M}$.
In the case of a general $u$, the polytope ([10](#S1.E10 "In Remark 1.9 (Symmetrization). ‣ Outline: ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) can be non-symmetric, in contrast with ([9](#S1.E9 "In Definition 1.5. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")). This asymmetry can actually help extract weak Alexandroff solutions of ([1](#S1.E1 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) with non-symmetric subgradient sets, such as the two Diracs test case in [[BF14](#bib.bibx3)].

The drawback of the expression ([10](#S1.E10 "In Remark 1.9 (Symmetrization). ‣ Outline: ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) is that it is only correctly defined sufficiently far from the boundary $\partial\Omega$. There is no simple way, to the knowledge of the author, to incorporate in ([10](#S1.E10 "In Remark 1.9 (Symmetrization). ‣ Outline: ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) the values of $u$ on $\partial\Omega$, and remain consistent with the Monge-Ampere operator $\det(\nabla^{2}u)$ in the strong sense of Definition [1.4](#S1.Thmtheorem4 "Definition 1.4. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"). Hence our choice of ([9](#S1.E9 "In Definition 1.5. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), defined in terms of the symmetric second order differences $\Delta\_{e}u(x)$, $e\in V$.

###### Remark 1.10 (Localization).

Consider the point dependent, largest possible stencil $V(x)=\{e\in{\mathbb{Z}}^{d};\ x+e\in X\}$. Then ${\cal D}^{\prime}\_{V(x)}u(x)$, see ([10](#S1.E10 "In Remark 1.9 (Symmetrization). ‣ Outline: ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), is the measure of the power cell associated to $x$ in the power diagram based discretization [[OP89](#bib.bibx16), [AHA98](#bib.bibx1), [Mer11](#bib.bibx13), [Lév14](#bib.bibx11)] of optimal transport. Since the stencils $(V(x))\_{x\in X}$ are typically huge, it is not reasonable to evaluate ${\cal D}^{\prime}\_{V(x)}u(x)$ independently for each $x$. Instead a global power diagram needs to be constructed, using complex geometric procedures which validity requires extremely careful evaluations of geometric predicates [[Lév14](#bib.bibx11)].

## 2 Proofs of the main results

We establish in §[2.1](#S2.SS1 "2.1 Consistency ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") the numerical scheme consistency, show in §[2.2](#S2.SS2 "2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") the global convergence of a damped Newton solver for the discrete system, and prove in §[2.3](#S2.SS3 "2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") a convergence result in the setting of viscosity solutions as the discretization grid scale tends to zero.

### 2.1 Consistency

Our consistency analysis relies on elementary properties of Voronoi cells of lattices, see Definition [1.6](#S1.Thmtheorem6 "Definition 1.6. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), and [[CS92](#bib.bibx6)] for more on this topic. Our first step is to bound their diameter.
Let $\kappa(M)^{2}$ denote the condition number of a matrix $M\in S\_{d}^{+}$, i.e. $\kappa(M):=\sqrt{\|M\|\|M^{-1}\|}$.

###### Lemma 2.1.

Let $M\in S\_{d}^{+}$. Any point $g\in\Vor(M)$ satisfies $\|g\|\leq\frac{1}{2}\kappa(M)\sqrt{d}$. Any $M$-Voronoi vector $e$ satisfies $\|e\|\leq\kappa(M)\sqrt{d}$, and has co-prime coordinates.

###### Proof.

*Bound on the norm.* Let $g\in\Vor(M)$, and let $e\_{g}$ be obtained by rounding the coordinates of $g$ to the nearest integer, so that $\|g-e\_{g}\|\leq\frac{1}{2}\sqrt{d}$. One has $\lambda^{-}\|g\|\leq\|g\|\_{M}\leq\|g-e\_{g}\|\_{M}\leq\lambda^{+}\|g-e\_{g}\|$, where $\lambda^{-},\lambda^{+}$ are respectively the smallest and largest eigenvalues of $M^{\frac{1}{2}}$. Thus $\|g\|\leq(\lambda^{+}/\lambda^{-})\frac{1}{2}\sqrt{d}$ as announced.
If $e$ is an $M$-Voronoi vector, then there exists $g\in\Vor(M)$ such that $\|g\|=\|e-g\|$, hence $\|e\|\leq 2\|g\|\leq\kappa(M)\sqrt{d}$.

*Coordinates are co-prime.* Consider a vector which coordinates are not co-prime: $ke$, with $k\geq 2$ and $e\in{\mathbb{Z}}^{d}\setminus\{0\}$. Then for any $g\in{\mathbb{R}}^{d}$ one has $\|ke-g\|\_{M}^{2}+(k-1)\|g\|\_{M}^{2}=k\|e-g\|\_{M}^{2}+(k^{2}-k)\|e\|\_{M}^{2}$. Hence $\|e-g\|\_{M}<\max\{\|ke-g\|\_{M},\|g\|\_{M}\}$ and therefore $ke$ cannot be an $M$-Voronoi vector.
∎

###### Corollary 2.2.

Let $M\in S\_{d}^{+}$, and let $E$ be the collection of strict $M$-Voronoi vectors. For any set $V\subseteq{\mathbb{Z}}^{d}$ one has $\Vor(M)\subseteq\{g\in{\mathbb{R}}^{d};\,\forall e\in V,\,2\langle g,Me\rangle\leq\|e\|\_{M}^{2}\}$, with equality iff $E\subseteq V$.

###### Proof.

For any $g,e\in{\mathbb{R}}^{d}$, we have the equivalence $\|g\|\_{M}\leq\|g-e\|\_{M}\Leftrightarrow 2\langle g,Me\rangle\leq\|e\|\_{M}^{2}$, obtained by squaring both sides of the first inequality.
Hence $\Vor(M)$ is a convex polytope, defined by a family of linear inequalities indexed by $e\in{\mathbb{Z}}^{d}$. By Lemma [2.1](#S2.Thmtheorem1 "Lemma 2.1. ‣ 2.1 Consistency ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") one can eliminate all inequalities but a finite number. Among these inequalities, only those corresponding to strict $M$-Voronoi vectors are active, in the sense that they define a facet of $\Vor(M)$. The result follows.
∎

We next identify the volume of a Voronoi cell, and use it to establish our scheme consistency.

###### Lemma 2.3.

For any $M\in S\_{d}^{+}$ one has $\Leb(\Vor(M))=1$.

###### Proof.

The set $\Vor(M)$ collects elements $g\in{\mathbb{R}}^{d}$ which are closer to the origin than to any other point $e\in{\mathbb{Z}}^{d}$. As a result the translates of $\Vor(M)$, by all offsets $e\in{\mathbb{Z}}^{d}$, tile the space ${\mathbb{R}}^{d}$ up to a negligible set. Thus $\Leb(\Vor(M))$ is the co-volume of the lattice ${\mathbb{Z}}^{d}$, namely $1$ as announced.
∎

###### Proof of Proposition [1.7](#S1.Thmtheorem7 "Proposition 1.7 (Consistency). ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") (Consistency).

Let $M\in S\_{d}^{+}$, let $x\in X$, and let $u\_{M}$ be the quadratic map ([8](#S1.E8 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")).
By construction $\Delta\_{e}u\_{M}(x)=\|e\|\_{M}^{2}$, for any $e\in{\mathbb{Z}}^{d}$. Hence ${\cal D}\_{V}u\_{M}(x)$ is the volume of:

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\{g\in{\mathbb{R}}^{d};\,\forall e\in V,\,2\langle g,e\rangle\leq\|e\|\_{M}^{2}\}=M\{g\in{\mathbb{R}}^{d};\,\forall e\in V,\,2\langle g,Me\rangle\leq\|e\|\_{M}^{2}\}\supseteq M\Vor(M).$ |  |

where we used Corollary [2.2](#S2.Thmtheorem2 "Corollary 2.2. ‣ 2.1 Consistency ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") and abusively denoted by $ME:=\{Me;\,e\in E\}$ the image of a set $E$ by the linear map $M$.
Therefore ${\cal D}\_{V}u\_{M}(x)\geq\det(M)\Leb(\Vor(M))=\det(M)$ by Lemma [2.3](#S2.Thmtheorem3 "Lemma 2.3. ‣ 2.1 Consistency ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"). Equality holds iff the above inclusion of polytopes is an equality, equivalently iff $V$ contains all strict $M$-Voronoi vectors by Corollary [2.2](#S2.Thmtheorem2 "Corollary 2.2. ‣ 2.1 Consistency ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams").
∎

###### Proof of Corollary [1.8](#S1.Thmtheorem8 "Corollary 1.8 (Finite stencils are enough). ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") (Finite stencils are enough).

Combine Proposition [1.7](#S1.Thmtheorem7 "Proposition 1.7 (Consistency). ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") and Lemma [2.1](#S2.Thmtheorem1 "Lemma 2.1. ‣ 2.1 Consistency ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams").
∎

### 2.2 Global convergence of a damped Newton solver

We establish the convergence of a damped Newton solver for the discrete system ([2](#S1.E2 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")). Before doing so, we need to clarify the implementation of boundary conditions.
The stencil $V$ is fixed in the following, and obeys the properties of Definition [1.5](#S1.Thmtheorem5 "Definition 1.5. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams").

###### Remark 2.4 (Boundary discretization).

Maps $u\in{\mathbb{U}}$ are in principle, see Definition [1.1](#S1.Thmtheorem1 "Definition 1.1. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), defined both on the discrete sampling $X$ of $\Omega$, and on the whole uncountable boundary $\partial\Omega$.
Fortunately, only finitely many values of $u$ on $\partial\Omega$ play an active role in the system of equations ([2](#S1.E2 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")): those on

|  |  |  |
| --- | --- | --- |
|  | $\partial X:=\{x+h\_{x}^{e}e;\,x\in X,\,e\in V\}\cap\partial\Omega.$ |  |

This discretization, with $\#(X\cup\partial X)$ unkowns,
is used in our experiments, and in the proof of the damped Newton solver global convergence below.

Alternatively one may (i) not introduce any unknown for the boundary values, but use the given Dirichlet data $\sigma$ as in [[BCM14](#bib.bibx2)], or (ii) introduce some unknowns on an arbitrary boundary sampling $\partial X^{\prime}$, extended to $\partial\Omega\setminus\partial X^{\prime}$ by some interpolation procedure. Unfortunately (i) leads to initialization difficulties for the iterative solver, since one needs to find a strictly convex seed $u\_{0}$ with prescribed boundary values on $\partial\Omega$, and (ii) may limit the accuracy of the scheme if first order interpolation is used, or violate its degenerate ellipticity in the case of high order interpolation.

Our first step is to establish, in Corollary [2.6](#S2.Thmtheorem6 "Corollary 2.6. ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), that the Jacobian matrix associated to the discrete Monge-Ampere system ([2](#S1.E2 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) is invertible. This follows from the invertibility of diagonally dominant matrices, recalled in the next lemma, and from the degenerate ellipticity of the proposed operator ${\cal D}\_{V}$.

###### Lemma 2.5.

Let $A$ be an $n\times n$ matrix
such that for each $1\leq i\leq n$

|  |  |  |  |
| --- | --- | --- | --- |
|  | $|A\_{ii}|\geq\sum\_{j\neq i}|A\_{ij}|.$ |  | (11) |

Assume that for each index $1\leq i\_{0}\leq n$ there exists a chain $i\_{0},\cdots,i\_{k}$ such that $i\_{k}$ satisfies *strictly* inequality ([11](#S2.E11 "In Lemma 2.5. ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), and $A\_{i\_{r},i\_{r+1}}\neq 0$ for all $0\leq r<k$. Then $A$ is invertible.

###### Proof.

For each index $1\leq i\leq n$, let $k(i)$ denote the length of the smallest chain of indices as above.
Let $x\in{\mathbb{R}}^{d}$ be such that $Ax=0$. Among the indices $1\leq i\leq n$ such that the vector component $|x\_{i}|$ is maximal, choose one which minimizes $k(i)$.
From $(Ax)\_{i}=0$ we obtain

|  |  |  |
| --- | --- | --- |
|  | $|A\_{ii}||x\_{i}|\leq\sum\_{j\neq i}|A\_{ij}||x\_{j}|,\quad\text{ thus }(|A\_{ii}|-\sum\_{j\neq i}|A\_{ij}|)|x\_{i}|+\sum\_{j\neq i}|A\_{ij}|(|x\_{i}|-|x\_{j}|)=U+V\leq 0.$ |  |

Both terms $U$ and $V$ are non-negative by construction, hence $U=V=0$. If $k(i)=0$, then from $U=0$ we obtain $|x\_{i}|=0$, hence $x=0$. If $k(i)\neq 0$, then from $V=0$ we obtain $|x\_{j}|=|x\_{i}|$ for all indices $1\leq j\leq n$ such that $A\_{ij}\neq 0$. One of these indices satisfies $k(j)=k(i)-1$, which contradicts our choice of $i$. This concludes the proof.
∎

Let ${\mathbb{U}}\_{0}$ be the collection of maps $u:X\cup\partial X\to{\mathbb{R}}$ such that:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\forall x\in X,\ {\cal D}\_{V}u(x)>0.\qquad\text{ (Equivalently: }\forall x\in X,\ \forall e\in V,\ \Delta\_{e}u(x)>0.)$ |  | (12) |

Let $f:{\mathbb{U}}\_{0}\to{\mathbb{R}}^{X\cup\partial X}$ be defined by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f(u)(x):=\begin{cases}\ln{\cal D}\_{V}u(x)&\text{ if }x\in X,\\ u(x)&\text{ if }x\in\partial X.\end{cases}$ |  | (13) |

###### Corollary 2.6.

For each $u\in{\mathbb{U}}\_{0}$, the Jacobian matrix $df(u)$ is invertible.

###### Proof.

Let $u\in{\mathbb{U}}\_{0}$ and let $A:=df(u)$, which formally is a matrix associating a coefficient to each index pair $(x,y)$, $x,y\in X\cup\partial X$. The line of $A$ corresponding to each $x\in\partial X$ has a single non-zero coefficient, namely $1$ at index $(x,x)$, hence this line satisfies ([11](#S2.E11 "In Lemma 2.5. ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) strictly. By degenerate ellipticity of ${\cal D}\_{V}$, the line corresponding to any $x\in X$ satisfies ([11](#S2.E11 "In Lemma 2.5. ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")).
We prove in the following the chain property of Lemma [2.5](#S2.Thmtheorem5 "Lemma 2.5. ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), which implies the announced invertibility.

Let $x\in X$, and let $K\_{x}$ be the polytope appearing in ([9](#S1.E9 "In Definition 1.5. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), which by construction is convex, compact and symmetric w.r.t the origin.
For each $e\in V$ let $F\_{e}$ denote the facet of $K\_{x}$ defined by the equality constraint $2\langle g,e\rangle=\Delta\_{e}u(x)$. Let $V\_{x}:=\{e\in V;\,\Lambda\_{e}>0\}$ where $\Lambda\_{e}$ denotes the $(d-1)$-dimensional measure of $F\_{e}$. Since the polytope is symmetric, one has $\Lambda\_{e}=\Lambda\_{-e}$ for all $e\in V$, hence $V\_{x}$ is symmetric. Since the polytope is compact, and since the exterior normal to $F\_{e}$ is $e/\|e\|$, the set $V\_{x}$ spans ${\mathbb{R}}^{d}$. The coefficient of the Jacobian matrix $A$ at index $(x,x+h\_{x}^{e}e)$ is $4\Lambda\_{e}/(h\_{x}^{e}(h\_{x}^{e}+h\_{x}^{-e})\|e\|\Leb(K\_{x}))$, using ([5](#S1.E5 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) and the geometric argument that the polytope volume variation is at first order given by the facets areas $\Lambda\_{e}+\Lambda\_{-e}$ times their normal displacement. This coefficient is hence positive if $e\in V\_{x}$.

Among the points $x+h\_{x}^{e}e$, $e\in V\_{x}$ one at least is strictly closer to $\partial\Omega$ than $x$. By induction we can thus build a finite chain $x=x\_{0},\cdots,x\_{k-1}\in X$ such that $x\_{k}\in\partial X$ and the coefficient of $A$ at index $(x\_{r},x\_{r+1})$ is non-zero for each $0\leq r<k$. The announced result then follows from Lemma [2.5](#S2.Thmtheorem5 "Lemma 2.5. ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams").
∎

Our second step is to show that ([13](#S2.E13 "In 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) is a proper map: the preimage of any compact set is a compact set, a property which is tightly linked with the well-posedness of the PDE ([1](#S1.E1 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")).
Let

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\partial\_{x}U:=\{g\in{\mathbb{R}}^{d};\,\forall y\in\overline{\Omega},\,\langle g,y-x\rangle\leq U(y)-U(x)\}$ |  | (14) |

denote the subgradient of a convex map $U\in C^{0}(\overline{\Omega},{\mathbb{R}})$ at a point $x\in\Omega$.
We connect in Lemma [2.7](#S2.Thmtheorem7 "Lemma 2.7. ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") the proposed operator ${\cal D}\_{V}u(x)$ with the Lebesgue measure of $\partial\_{x}U$, where $U$ is the lower convex envelope of $u$. The properness of ([13](#S2.E13 "In 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) then follows in Corollary [2.9](#S2.Thmtheorem9 "Corollary 2.9. ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") from the maximum principle of Alexandroff-Bakelman-Pucci.

###### Lemma 2.7.

Let $u\in{\mathbb{U}}\_{0}$, and let $U:\Hull(X\cup\partial X)\to{\mathbb{R}}$ be the maximal convex map bounded above by $u$. Then $\Leb(\partial\_{x}U)\leq h\_{\*}^{d}{\cal D}\_{V}u(x)$ for all $x\in X$, with
$h\_{\*}:=\max\{h\_{x}^{e};\,x\in X,e\in V\}$.

###### Proof.

By construction $U\leq u$, and for any $x\in X$ such that $U(x)<u(x)$ one has $\Leb(\partial\_{x}U)=0$, so that the announced inequality holds.
Assume that $U(x)=u(x)$, and let $g^{+},g^{-}\in\partial\_{x}U$. Let $e\in V$ and let $h^{+}:=h\_{x}^{e}$, $h^{-}:=h\_{x}^{-e}$ as in ([5](#S1.E5 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")). One has
$\langle g^{+},h^{+}e\rangle\leq u(x+h^{+}e)-u(x)$, and $\langle g^{-},-h^{-}e\rangle\leq u(x-h^{-}e)-u(x)$ by ([14](#S2.E14 "In 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), thus

|  |  |  |
| --- | --- | --- |
|  | $\langle g^{+}-g^{-},e\rangle\leq\frac{u(x+h^{+}e)-u(x)}{h^{+}}+\frac{u(x-h^{-}e)-u(x)}{h^{-}}=\frac{h^{+}+h^{-}}{2}\Delta\_{e}u(x)\leq h\_{\*}\Delta\_{e}u(x).$ |  |

Therefore $\frac{1}{2}(\partial\_{x}U-\partial\_{x}U)\subseteq h\_{\*}K\_{x}$, where the left hand side is a Minkowski sum of sets, and $K\_{x}$ is the polytope appearing in ([9](#S1.E9 "In Definition 1.5. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")). The announced estimate then follows from this inclusion and Brunn-Minkowski’s inequality.
∎

###### Theorem 2.8 (Alexandroff-Bakelman-Pucci’s maximum principle [[Gut01](#bib.bibx10)]).

Let $u\in C^{0}(\overline{\Omega})$, and let $U$ be the maximal convex map bounded above by $u$. Then

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\min\_{\partial\Omega}u-\min\_{\overline{\Omega}}u\leq(\Leb(G)/\omega\_{d})^{\frac{1}{d}}\diam(\Omega),\qquad\text{ with }G:=\bigcup\_{\begin{subarray}{c}x\in\Omega\\ u(x)=U(x)\end{subarray}}\partial\_{x}U,$ |  | (15) |

where $\diam(\Omega):=\max\{\|x-y\|;x,y\in\Omega\}$,
and $\omega\_{d}$ is the volume of the $d$-dimensional unit ball.

###### Corollary 2.9.

The map $f:{\mathbb{U}}\_{0}\to{\mathbb{R}}^{X\cup\partial X}$ is proper.

###### Proof.

Since $f$ is continuous, it suffices to bound by above and below the values of an arbitrary $u\in{\mathbb{U}}\_{0}$ in terms of those of $f(u)$. We have the obvious estimate $f(u)(x)=u(x)$ for values at $x\in\partial X$.

*Lower bound on $X$.*
Let $\Omega^{\prime}$ be the interior of $\Hull(X\cup\partial X)$, and let $u^{\prime}\in C^{0}(\overline{\Omega}^{\prime},{\mathbb{R}})$ be defined by $u^{\prime}(z)=\min\_{x\in X\cup\partial X}u(x)+\lambda\|x-z\|$, where $\lambda>0$. Let $U\in C^{0}(\overline{\Omega}^{\prime},{\mathbb{R}})$ be the maximal convex function bounded above by $u^{\prime}$. If the constant $\lambda$ is sufficiently large, then $U$ also is the maximal convex function bounded above by $u$. In addition for all $x\in\Omega^{\prime}$, one has $U(x)=u^{\prime}(x)\Leftrightarrow x\in X\cup\partial X$.
We obtain applying Theorem [2.8](#S2.Thmtheorem8 "Theorem 2.8 (Alexandroff-Bakelman-Pucci’s maximum principle []). ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") the desired lower bound on $\min\{u(x);\,x\in X\}$, since

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\min\_{\overline{\Omega^{\prime}}}u^{\prime}$ | $\displaystyle=\min\_{X\cup\partial X}u,$ | $\displaystyle\min\_{\partial\Omega^{\prime}}u^{\prime}$ | $\displaystyle=\min\_{\partial X}u,$ | $\displaystyle\Leb(G)$ | $\displaystyle=\sum\_{x\in X}\Leb(\partial\_{x}U)\leq h\_{\*}^{d}\sum\_{x\in X}{\cal D}\_{V}u(x)=h\_{\*}^{d}\sum\_{x\in X}e^{f(u)(x)}.$ |  |

*Upper bound on $X$.* Let $x\in X\cup\partial X$ be such that $u(x)$ is maximal, and let us assume for contradiction that $x\notin\partial X$.
Since $\Delta\_{e}u(x)>0$, for any $e\in V$, one has either $u(x+h^{+}e)>u(x)$, or $u(x-h^{-}e)>u(x)$, with the notations of ([5](#S1.E5 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")). This contradicts the maximality of $u(x)$, and concludes the proof.
∎

Numerous variants of the Newton method exist [[EW94](#bib.bibx7)]; an elementary one is presented below for completeness, which guarantees global convergence for the system ([2](#S1.E2 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) of interest.
This damped Newton algorithm is an iterative equation solver, which recursion rule ([16](#S2.E16 "In Proposition 2.10 (Global convergence of the damped Newton algorithm). ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) involves an adaptively chosen “damping” parameter $\delta$. In practice $\delta$ is typically small in the first iterations, and equal to $1$ in the last ones, which coincide with the classical Newton method and enjoy quadratic convergence. Convergence is guaranteed for maps which, like ([5](#S1.E5 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), are shown to be proper and at each point a local diffeomorphism.
Note that these assumptions, plus the connectedness of the source domain and the simple connectedness of the target domain (here both satisfied), imply by Hadamard-Levy’s theorem that $f$ is a global diffeomorphism.

###### Proposition 2.10 (Global convergence of the damped Newton algorithm).

Let $N>0$, let ${\mathbb{U}}\_{0}\subseteq{\mathbb{R}}^{N}$ be an open set, and let $f\in C^{1}({\mathbb{U}}\_{0},{\mathbb{R}}^{N})$. Assume that $f$ is proper and that the Jacobian matrix $F(x):=df(x)$ is invertible for each $x\in{\mathbb{U}}\_{0}$.
Consider $y\in{\mathbb{R}}^{N}$, and for each $x\in{\mathbb{U}}\_{0}$, $\delta\in[0,1]$, the Newton update

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Newton(x,\delta):=x+\delta F(x)^{-1}(y-f(x)).$ |  | (16) |

Let $x\_{0}\in{\mathbb{U}}\_{0}$, and for each $n\geq 0$ let $x\_{n+1}:=\Newton(x\_{n},\delta\_{n})$, where $\delta\_{n}=2^{-k\_{n}}$ and $k\_{n}$ is the smallest non-negative integer such that $\|y-f(x\_{n+1})\|\leq(1-\delta\_{n}/2)\|y-f(x\_{n})\|$.
Then $f(x\_{n})\to y$ as $n\to\infty$.

###### Proof.

Introduce the set $K:=\{x\in{\mathbb{U}}\_{0};\,\|y-f(x)\|\leq\|y-f(x\_{0})\|\}$, which is compact since $f$ is proper. For any $x\in{\mathbb{U}}\_{0}$ one has the Taylor expansion: for small $\delta$

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle f(\Newton(x,\delta))$ | $\displaystyle=f(x)+\delta F(x)F(x)^{-1}(y-f(x))+o(\delta\|F(x)^{-1}(y-f(x))\|)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=y-(1-\delta)(y-f(x))+o(\delta\|y-f(x)\|).$ |  | (17) |

Hence
$\|y-f(\Newton(x,\delta))\|=(1-\delta+o(\delta))\|y-f(x)\|$ using ([17](#S2.E17 "In Proof. ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), which is smaller than $(1-\delta/2)\|y-f(x)\|$ for an open range of $\delta\in]0,\lambda(x)[$. By compactness, this property holds for all $x\in K$ with an uniform open range $]0,\lambda[$.

Thus $\delta\_{0}$ is well defined, bounded below by $\lambda/2$, and by construction $\|y-f(x\_{1})\|\leq(1-\lambda/2)\|y-f(x\_{0})\|$ so that $x\_{1}\in K$. The result follows from an immediate induction argument.
∎

### 2.3 Convergence in the setting of viscosity solutions

In this section, we let the discretization grid scale tend to zero, and study the convergence of the minimizers to the discrete problems ([2](#S1.E2 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")).
For all integers $n\geq 1$, let $X\_{n}:=\Omega\cap n^{-1}{\mathbb{Z}}^{d}$.
Let ${\mathbb{U}}\_{n}$ be the collection of (semi-)discrete maps $u:X\_{n}\cup\partial\Omega\to{\mathbb{R}}$.
The stencil $V$ is fixed and obeys the assumptions of Definition [1.5](#S1.Thmtheorem5 "Definition 1.5. ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams").
For any $u\in{\mathbb{U}}\_{n}$, $x\in X\_{n}$, and $M\in S\_{d}$ let

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle{\cal D}\_{n}(u)$ | $\displaystyle:=\Leb\{g\in{\mathbb{R}}^{d};\,\forall e\in V,\ 2\langle g,e\rangle\leq\Delta\_{e/n}u(x)\},$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle D(M)$ | $\displaystyle:=\Leb\{g\in{\mathbb{R}}^{d};\,\forall e\in V,\ 2\langle g,e\rangle\leq\langle e,Me\rangle\}.$ |  | (18) |

We denoted by $\Delta\_{e/n}u(x):=n^{2}(u(x+e/n)-2u(x)+u(x-e/n))$ the standard approximation of $\langle e,(\nabla^{2}u(x))e\rangle$ on the grid $X\_{n}$ (This expression assumes that $x\pm e/n\in X\_{n}$, and should be modified as in ([5](#S1.E5 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) otherwise).
Given a density $\rho\in C^{0}(\overline{\Omega},{\mathbb{R}}\_{+}^{\*})$, and some Dirichlet data $\sigma\in C^{0}(\partial\Omega,{\mathbb{R}})$, we study the problems

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\begin{cases}u\in{\mathbb{U}}\_{n},\\ {\cal D}\_{n}(u)=\rho&\text{ on }\Omega,\\ u=\sigma&\text{ on }\partial\Omega.\end{cases}$ |  | $\displaystyle\begin{cases}u:\overline{\Omega}\to{\mathbb{R}},\\ D(\nabla^{2}u)=\rho&\text{ on }\Omega,\\ u=\sigma&\text{ on }\partial\Omega.\end{cases}$ |  | (19) |

By §[2.2](#S2.SS2 "2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), the discretized problem ([19](#S2.E19 "In 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), left) has a unique solution $u\_{n}\in{\mathbb{U}}\_{n}$. We show in Corollary [2.15](#S2.Thmtheorem15 "Corollary 2.15. ‣ 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") that ([19](#S2.E19 "In 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), right) also admits a unique solution $u\_{\infty}$. Importantly, if $\nabla^{2}u\_{\infty}$ exists at each $x\in\Omega$ and belongs to the consistency set of ${\cal D}\_{V}$, then $u\_{\infty}$ is also the unique solution to the Monge-Ampere equation ([1](#S1.E1 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")).
The study of ([19](#S2.E19 "In 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), right) relies on the concept of viscosity solutions [[CIL92](#bib.bibx5)].

###### Definition 2.11.

A sub-solution (resp. super-solution) of ([19](#S2.E19 "In 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), right) is an upper-semi-continuous (resp. lower-semi-continuous) map $u:\overline{\Omega}\to{\mathbb{R}}$ such that (I) $u\leq\sigma$ (resp. $u\geq\sigma$) on $\partial\Omega$ and (II)
for any $x\in\Omega$ and any $\varphi\in C^{2}(\Omega)$ such that $u-\varphi$ has a local maximum (resp. minimum) at $x$, one has $D(\nabla^{2}\varphi(x))\geq\rho(x)$ (resp. $\leq\rho(x)$).

A solution to ([19](#S2.E19 "In 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), right) is a map $u:\overline{\Omega}\to{\mathbb{R}}$ which is both a super-solution and a sub-solution.

Replacing “local maximum” with “strict global maximum” (resp. minimum) in Definition [2.11](#S2.Thmtheorem11 "Definition 2.11. ‣ 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") yields an equivalent notion of sub- and super-solutions [[CIL92](#bib.bibx5)].
Super- and sub-solutions of ([19](#S2.E19 "In 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), right) obey a comparison principle, proved Proposition [2.13](#S2.Thmtheorem13 "Proposition 2.13. ‣ 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams").
Given symmetric matrices $M,M^{\prime}\in S\_{d}$, we write $M\preceq M^{\prime}$ iff the difference $M^{\prime}-M$ is positive semi-definite.

###### Lemma 2.12.

For any $M,M^{\prime}\in S\_{d}$, one has: $M\preceq M^{\prime}\Rightarrow D(M)\leq D(M^{\prime})$. More quantitatively, if $M,H\in S\_{d}$ are such that $D(M)>0$ and $D(H)>0$ then

|  |  |  |
| --- | --- | --- |
|  | $D(M+H)^{\frac{1}{d}}\geq D(M)^{\frac{1}{d}}+D(H)^{\frac{1}{d}}.$ |  |

###### Proof.

Let $K(M)\subseteq{\mathbb{R}}^{d}$ be the polytope appearing in ([18](#S2.E18 "In 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), so that $D(M)=\Leb K(M)$. Then

|  |  |  |
| --- | --- | --- |
|  | $M\preceq M^{\prime}\ \Rightarrow\ \forall e\in V,\|e\|^{2}\_{M}\preceq\|e\|^{2}\_{M^{\prime}}\ \Rightarrow\ K(M)\subseteq K(M^{\prime})\ \Rightarrow\ D(M)\leq D(M^{\prime}).$ |  |

Second point: since $\langle e,(M+H)e\rangle=\langle e,Me\rangle+\langle e,He\rangle$, the set $K(M+H)$ contains the Minkowski sum $K(M)+K(H)$. The announced result follows from Brunn-Minkowski’s inequality.
∎

###### Proposition 2.13.

If $u\_{\*}$ is a sub-solution of ([19](#S2.E19 "In 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), right), and $u^{\*}$ a super-solution, then $u\_{\*}\leq u^{\*}$.

###### Proof.

The result does not immediately follow from [[CIL92](#bib.bibx5)] because the operator
$-D(\nabla^{2}u)$
is only degenerate elliptic. The following operator is in contrast strictly elliptic when $\varepsilon>0$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $F\_{\varepsilon}(u):=-D(\nabla^{2}u)^{\frac{1}{d}}+\varepsilon u.$ |  | (20) |

Let $M:=\sup\_{\overline{\Omega}}u\_{\*}-u^{\*}$, which is finite by upper-semi-continuity. For contradiction, we assume $M>0$. Let also $r:=\max\{\|x\|;x\in\overline{\Omega}\}$ and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $u\_{\varepsilon}(x):=u\_{\*}(x)+\frac{\varepsilon M}{2}(\|x\|^{2}-r^{2}).$ |  | (21) |

One has $u\_{\varepsilon}\leq u\_{\*}\leq u^{\*}$ on $\partial\omega$, and by Lemma [2.12](#S2.Thmtheorem12 "Lemma 2.12. ‣ 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle F\_{\varepsilon}(u^{\*})-F\_{\varepsilon}(u\_{\varepsilon})\geq\varepsilon M-\varepsilon(u\_{\*}-u^{\*})\geq 0.$ |  | (22) |

Applying the standard comparison principle [[CIL92](#bib.bibx5)] to the strictly elliptic $F\_{\varepsilon}$ we obtain $u^{\*}\geq u\_{\varepsilon}$, hence $u^{\*}-u\_{\*}\geq-\varepsilon Mr^{2}/2$. Letting $\varepsilon\to 0$ yields $u^{\*}\geq u\_{\*}$ as announced.
∎

Weal solutions can be extracted from sequences of discrete solutions:
for each $n\geq 1$, extend $u\_{n}$ by bilinear interpolation (or any other local interpolation procedure) on $\Omega\_{n}:=\{x\in\Omega;\,d(x,\partial\Omega)\geq n^{-1}\sqrt{d}\}$, and define $u\_{\*},u^{\*}:\overline{\Omega}\to{\mathbb{R}}$ by

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | $\displaystyle u\_{\*}(x)$ | $\displaystyle:=\limsup\_{n\to\infty}u\_{n}(x),$ | $\displaystyle u^{\*}(x)$ | $\displaystyle:=\liminf\_{n\to\infty}u\_{n}(x).$ |  | (23) |

###### Lemma 2.14.

$u\_{\*}$ and $u^{\*}$ are respectively a sub-solution and a super-solution of ([19](#S2.E19 "In 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), right).

###### Proof.

Inspection of the proof of Corollary [2.9](#S2.Thmtheorem9 "Corollary 2.9. ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") yields the quantitive estimate

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\min\_{\partial\Omega}\sigma-\left(\frac{1}{n^{d}}\sum\_{x\in X\_{n}}\frac{\rho(x)}{\omega\_{d}}\right)^{\frac{1}{d}}\diam(\Omega)\leq u\_{n}\leq\max\_{\partial\Omega}\sigma.$ |  | (24) |

Note that $n^{-d}\sum\_{x\in X\_{n}}\rho(x)\to\int\_{\Omega}\rho$ as $n\to\infty$. (Also, the multiplicative term $h\_{\*}$ appearing in Corollary [2.9](#S2.Thmtheorem9 "Corollary 2.9. ‣ 2.2 Global convergence of a damped Newton solver ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") equals $1$ with our choice of discrete domain $X\_{n}=\Omega\cap n^{-1}{\mathbb{Z}}^{d}$, since $]x,x+e/n]\cap(X\_{n}\cup\partial\Omega)$ is non-empty for all $x\in X\_{n}$, $e\in{\mathbb{Z}}^{d}$.)

The maps $u\_{n}\in{\mathbb{U}}\_{n}$ are therefore bounded independently of $n$, hence $u\_{\*}$ and $u^{\*}$ are well defined. From this point, the announced result follows by a standard argument: let $x\in\Omega$ and $\varphi\in C^{2}(\Omega)$ be such that $u^{\*}-\varphi$ attains a strict global maximum at $x\in\Omega$. For each $n\geq 1$, let $x\_{n}$ be the element of $X\_{n}$ which maximizes $u\_{n}-\varphi$. By monotonicity ${\cal D}\_{n}\varphi(x\_{n})\geq{\cal D}\_{n}u\_{n}(x\_{n})=\rho(x\_{n})$. Observing that $x\_{n}\to x$ as $n\to\infty$, we obtain $D(\nabla^{2}\varphi(x))\geq\rho(x)$ in the limit. This establishes that $u^{\*}$ is a super-solution, and likewise $u\_{\*}$ is a sub-solution.
∎

###### Corollary 2.15.

One has $u\_{\*}=u^{\*}$, and this map is the unique solution $u\_{\infty}$ of ([19](#S2.E19 "In 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), right). As a result, $u\_{n}$ converges pointwise to $u\_{\infty}$ as $n\to\infty$.

###### Proof.

By construction $u\_{\*}\leq u^{\*}$, but by the comparison principle $u\_{\*}\geq u^{\*}$, see Proposition [2.13](#S2.Thmtheorem13 "Proposition 2.13. ‣ 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams").
Therefore ([19](#S2.E19 "In 2.3 Convergence in the setting of viscosity solutions ‣ 2 Proofs of the main results ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"), right) admits the solution $u\_{\infty}:=u\_{\*}=u^{\*}$ which, again by the comparison principle, is its unique solution. Finally, for any $x\in\Omega$ on has as $n\to\infty$: $\limsup u\_{n}(x)=u^{\*}(x)=u\_{\*}(x)=\liminf u\_{n}(x)$, hence $u\_{\infty}(x)=\lim u\_{n}(x)$.
∎

## 3 Numerical experiments

We implemented the three11
1
The filtered method [[FO13](#bib.bibx9)], which accuracy may be competitive, was not implemented due to lack of time.
Monge Ampere discretizations described in the introduction: the Finite Differences (FD) scheme ${\cal D}^{\text{\tiny FD}}$, the Wide Stencil (WS) scheme ${\cal D}^{\text{\tiny WS}}\_{\cal B}$, and the proposed scheme ${\cal D}\_{V}$. All presented experiments are three dimensional. The latter two schemes require choosing a collection ${\cal B}$ of triplets of orthogonal vectors, or a stencil $V$, see Table [1](#S3.T1 "Table 1 ‣ 3 Numerical experiments ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams").
We recall that scheme FD is consistent but not monotone (or degenerate elliptic). Scheme WS is monotone and thus benefits from the associated convergence guarantees, but suffers from significant consistency errors, see Figure [2](#S3.F2 "Figure 2 ‣ 3 Numerical experiments ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams").
The proposed scheme is simultaneously monotone and consistent, provided the PDE solution hessian condition number is bounded, and the scheme stencil $V$ is sufficiently large, see Proposition [1.7](#S1.Thmtheorem7 "Proposition 1.7 (Consistency). ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") and Corollary [1.8](#S1.Thmtheorem8 "Corollary 1.8 (Finite stencils are enough). ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"). A consistency error arises when these conditions are not satisfied, see Figure [2](#S3.F2 "Figure 2 ‣ 3 Numerical experiments ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams").

We limit our attention to synthetic test cases, posed on the unit cube $\Omega:=]0,1[^{3}$. A known convex function $U:\overline{\Omega}\to{\mathbb{R}}$ is numerically recovered from its hessian determinant $\rho:=\det(\nabla^{2}U)$, and its boundary values $\sigma:=U\_{|\partial\Omega}$.
Three test cases are considered.

* •

  (Quadratic) $U(x):=\frac{1}{2}\langle x,Mx\rangle$, where $M$ was chosen randomly, with $\sqrt{\|M\|\|M^{-1}\|}\approx 8.5$.
* •

  (Smoothed cone) $U(x):=\sqrt{\delta^{2}+\|x-x\_{0}\|^{2}}$, with $\delta:=0.1$ and $x\_{0}:=(1/2,1/2,1/2)$.
* •

  (Singular, [[FO13](#bib.bibx9)]) $U(x):=-\sqrt{3-\|x\|^{2}}$.

A Damped Newton solver is applied to the discrete system ([2](#S1.E2 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")), starting from the trivial seed $u(x):=\|x\|^{2}$.

Quadratic test case. The chosen matrix $M$ does not belong to the consistency set of schemes ${\cal D}\_{V}$ and ${\cal D}^{\text{\tiny WS}}\_{\cal B}$, with the chosen $V$ and ${\cal B}$; hence the numerical error reflects their consistency error, and is resolution independent. On the topic of consistency, it was determined using Proposition [1.7](#S1.Thmtheorem7 "Proposition 1.7 (Consistency). ‣ 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams") and some semi-definite programming that the consistency set of the proposed scheme ${\cal D}\_{V}$ contains all $M\in S\_{3}^{+}$ such that $\Tr(M)/(\det M)^{\frac{1}{3}}$ is less than $7.8$ with the small stencil $V$, and less than $11.9$ with the large $V$, see Table [1](#S3.T1 "Table 1 ‣ 3 Numerical experiments ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams"). The always consistent but non-monotone scheme ${\cal D}^{\text{\tiny FD}}$ finds the exact solution for a range of resolutions, up to machine precision, but switches to a completely erroneous solution at other resolutions.

Smoothed Cone test case. The test function $U$ is smooth, but the test is not as simple as it looks since (i) $\nabla U$ varies quickly close to the center $x\_{0}$, but (ii) $\nabla^{2}U$ is almost degenerate far from $x\_{0}$. Point (i) favors small stencils, while point (ii) requires a good angular resolution. Scheme WS is most efficient with a small triplets collection ${\cal B}$ at low resolutions, but with a medium or large one at high resolutions. Picking a stencil $V$ is easier with the proposed scheme: the larger one here always yields a smaller error, albeit at a higher computational cost. The non-monotone scheme FD passes this test as well.
We give some computation times for this test, which are typical of our experience. On a 2.7 Ghz Laptop using a single core, using a $50\times 50\times 50$ discretization grid $X$, computations took (in minutes): $4.7$ and $9.7$ with the proposed scheme, small and large $V$ respectively; $6.4$, $24$ and $65$ with scheme WS, small medium and large ${\cal B}$ respectively; $6.5$ with scheme FD.

Singular test case. The function $U$ is not smooth at the point $(1,1,1)$, where its gradient is formally $(+\infty,+\infty,+\infty)$. The non-monotone scheme FD completely fails this test: numerical error does not decrease as resolution increases, and initializing the Newton solver with the exact solution $U$ does not even help, as observed in [[FO13](#bib.bibx9)]. Scheme WS will recover the solution, if the bases collection ${\cal B}$ is large enough, but numerical error decays quite slowly. The proposed scheme works flawlessly: it has the same convergence guarantees as scheme WS, but yields an $L^{\infty}$ error about $20$ times smaller on a $50^{3}$ grid. Curiously, numerical error is identical with the small and the large stencil $V$.

| Proposed | Stencil vectors | $\#(V)$ |
| --- | --- | --- |
| Small | $(1,0,0),(1,1,0),(1,1,1)$ | 13 |
| Large | Same and $(2,1,0),(2,1,1)$ | 37 |

| Scheme WS | Orthogonal triplets | $\#({\cal B})$ |
| --- | --- | --- |
| Small | All within $\{-1,0,1\}^{3}$ | 6 |
| Medium | All within $\{-2,\cdots,2\}^{3}$ | 43 |
| Large | All within $\{-3,\cdots,3\}^{3}$ | 82 |

Table 1: *Left:* Stencil $V$ used with the proposed scheme ${\cal D}\_{V}$. In addition to those indicated $(\alpha\_{1},\alpha\_{2},\alpha\_{3})$, the stencil contains all vectors $(\varepsilon\_{1}\alpha\_{\sigma(1)},\varepsilon\_{2}\alpha\_{\sigma(2)},\varepsilon\_{3}\alpha\_{\sigma(3)})$ obtained by permuting and changing the sign of their coordinates. Opposite vectors are identified when evaluating $\#(V)$.
  
*Right:* Collection ${\cal B}$ of orthogonal triplets used with the Wide-Stencil scheme ${\cal D}^{\text{\tiny WS}}\_{\cal B}$. Triplets are counted up to reordering their components, and changing their sign: $(e\_{0},e\_{1},e\_{2})\sim(\varepsilon\_{1}e\_{\sigma(1)},\varepsilon\_{2}e\_{\sigma(2)},\varepsilon\_{3}e\_{\sigma(3)})$. Vectors with non-coprime coordinates, such as $(2,2,0)$, are rejected.

| Proposed, Small | Proposed, Large | WS, Small | WS, Medium | WS, Large |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |

Figure 2: 
Relative consistency error $({\cal D}u\_{M}-\det(M))/{\cal D}u\_{M}$ ($\text{blue}=0$, $\text{red}=1$) for a quadratic ([8](#S1.E8 "In 1 Introduction ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams")) map $u\_{M}$ associated to a matrix $M=M(v)$, with $v$ in the unit sphere (hence the spherical plot).
First line: $M(v)$ has eigenvalues $6^{2},1,1$, the former with eigenvector $v$. Second line likewise with eigenvalues $6^{-2},1,1$. Third line $M(v)=R(v)DR(v)$ where $R(v)$ is the rotation of axis $v$ and angle $\pi$, and $D$ is diagonal of entries $6,1,1/6$.

Figure 3: 
Log-Log plot of the $L^{\infty}$ error, as a function of resolution $n$, for the three test cases.
Discretization set $X\subseteq\Omega$ has $n^{3}$ points.
Scheme stencils on Figure [1](#S3.T1 "Table 1 ‣ 3 Numerical experiments ‣ Discretization of the 3D Monge-Ampere operator,between Wide Stencils and Power Diagrams").
