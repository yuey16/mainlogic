<!-- fulltext source=oa_pdf slug=arXiv-astro-ph_0109483 fetched=2026-09-18T06:45:12+00:00 -->

A reconstruction of the initial conditions of the Universe by optimal mass transportation 

refinement, the second-order Lagrangian perturbation method,<sup>13–16</sup> also known to be potential. 

# Uriel Frisch<sup>∗</sup> , Sabino Matarrese<sup>†</sup> , Roya Mohayaee<sup>‡∗</sup> & Andrei Sobolevski<sup>§∗</sup> 

> ∗ CNRS, UMR 6529, Observatoire de la Cˆote d’Azur, BP 4229, 06304 Nice Cedex 4, France 

> † Dipartimento di Fisica “G. Galilei” and INFN, Sezione di Padova, via Marzolo 8, 35131-Padova, Italy 

> ‡ Dipartimento di Fisica, Universit´a Degli Studi di Roma “La Sapienza”, P.le A. Moro 5, 00185-Roma, Italy 

> § Department of Physics, M.V. Lomonossov University 119899-Moscow, Russia 

Nature| VOL 417| 16 MAY 2002 

Reconstructing the density fluctuations in the early Universe that evolved into the distribution of galaxies we see today is a challenge of modern cosmology.<sup>1</sup> An accurate reconstruction would allow us to test cosmological models by simulating the evolution starting from the reconstructed state and comparing it to the observations. Several reconstruction techniques have been proposed,<sup>2–9</sup> but they all suffer from lack of uniqueness because the velocities of galaxies are usually not known. Here we show that reconstruction can be reduced to a well-determined problem of optimisation, and present a specific algorithm that provides excellent agreement when tested against data from N-body simulations. By applying our algorithm to the new redshift surveys now under way,<sup>10</sup> we will be able to recover reliably the properties of the primeval fluctuation field of the local Universe and to determine accurately the peculiar velocities (deviations from the Hubble expansion) and the true positions of many more galaxies than is feasible by any other method. 

Starting from the available data on the galaxy distribution, can we trace back in time and map to its initial locations the highly structured distribution of mass in the Universe (Fig. 1)? Here we show that, with a suitable hypothesis, the knowledge of both the present non-uniform distribution of mass and of its primordial quasi-uniform distribution uniquely determines the inverse Lagrangian map, defined as the transformation from present (Eulerian) positions x to the respective initial (Lagrangian) positions q. 

We first consider the direct Lagrangian map q �→ x, which can be approximately written in terms of a potential as x = ∇qΦ(q) at those scales where nonlinearity stays moderate.<sup>11</sup> This is supported by numerical N-body simulations showing good agreement with a very simple potential approximation, due to Zel’dovich,<sup>12</sup> which assumes that the particles move on straight trajectories. Even better agreement is obtained with a 



FIG. 1. N -body simulation output (present epoch) used for testing our reconstruction method. In the standard model of structure formation, the distribution of matter in the Universe is believed to have emerged from a very smooth initial state: tiny irregularities of the gravitational potential, which we can still observe as temperature fluctuations of the cosmic microwave background, gave rise to density fluctuations, which grew under their self-gravity, developing a rich and coherent pattern of structures. Most of the mass is in the form of cold dark matter; the luminous matter (galaxies) can be assumed to trace – up to some form of bias – the underlying dark matter. Shown here is a projection onto the x-y plane of a 10% slice of the simulation box of size 200h<sup>−1</sup> Mpc. The model, ΛCDM, uses cold dark matter with cosmological constant and the following parameters: Hubble constant h = 0.65, density parameters ΩΛ = 0.7 and Ωm = 0.3, normalization factor σ8 = 0.99. Points are highlighted in yellow when reconstruction fails by more than 6 h<sup>−1</sup> Mpc, which happens mostly in high-density regions. 

In our “reconstruction hypothesis”, we furthermore assume the convexity of the potential Φ(q), a consequence of which is the absence of multi-streaming: for almost any Eulerian position, there is a single Lagrangian antecedent. As is well-known, the Zel’dovich approximation leads to caustics and to multi-streaming. This can be overcome in various ways, for example by a modification known as the adhesion model, an equation of viscous pressureless gas dynamics.<sup>17, 18</sup> The latter, which 

1 

leads to shocks rather than caustics, is known to have a convex potential<sup>19</sup> and to be in better agreement with N-body simulations. Suppression or reduction of multistreaming requires a mechanism of momentum exchange, such as viscosity, between neighbouring streams having different velocities. This is a common phenomenon in ordinary fluids, such as the flow of air or water in our natural environment. Dark matter is however essentially collisionless and the usual mechanism for generating viscosity (discovered by Maxwell) does not operate, so that a non-collisional mechanism involving a small-scale gravitational instability must be invoked. 

Our reconstruction hypothesis implies that the initial positions can be obtained from the present ones by another gradient map: q = ∇xΘ(x), where Θ is a convex potential related to Φ by a Legendre–Fenchel transform (see Methods). We denote by ρ0 the initial mass density (which can be treated as uniform) and by ρ(x) the final one. Mass conservation implies ρ0d<sup>3</sup> q = ρ(x)d<sup>3</sup> x. Thus, the ratio of final to initial density is the Jacobian of the inverse Lagrangian map. This can be written as the following Monge–Amp`ere equation<sup>20</sup> for the unknown potential Θ 



where ‘det’ stands for determinant. 

We emphasize that no information about the dynamics of matter other than the reconstruction hypothesis is needed for our method, whose degree of success depends crucially on how well this hypothesis is satisfied. Exact reconstruction is obtained, for example, for the Zel’dovich approximation (before particle trajectories cross) and for adhesion-model dynamics (at arbitrary times). 

We note that our Monge–Amp`ere equation for selfgravitating matter may be viewed as a nonlinear generalisation of a Poisson equation (used for reconstruction in ref. 4), to which it reduces if particles have moved very little from their initial positions. 

It has been discovered recently that the map generated by the solution to the Monge-Amp`ere equation (1) is the (unique) solution to an optimisation problem<sup>21</sup> (see also refs 22 and 23). This is the ‘mass transportation’ problem of Monge and Kantorovich<sup>24, 25</sup> in which one seeks the map x �→ q that minimises the quadratic ‘cost’ function 



Note that x = q is forbidden: as the initial and final density fields ρ0 and ρ(x) are prescribed there is a constraint on Jacobian of the map (see Methods). 

Next, we take into account that information on the mass distribution is provided in the form of N discrete particles both in simulations and when handling observational data from galaxy surveys. The cost minimisation then becomes what is known in optimisation theory as the assignment problem: find the unique one-to-one pairing of a set of N initial points qj’s and N final points xi’s 

that minimises Idiscr =<sup>�N</sup> i=1<sup>|xi −qj(i)|2.Animmediate</sup> consequence is that, for any subset of k pairs of initial and final points (2 ≤ k ≤ N ), the contribution of these points to the cost function should not decrease under arbitrary permutations of initial points. This property is known to be equivalent to having a Lagrangian map that is the gradient of a convex function.<sup>26</sup> 

If we restrict ourselves to interchanging just pairs (k = 2), the map is said to be monotonic, a condition not equivalent to minimisation of the cost function (except in one dimension). In ref. 5, a method of reconstruction called the Path Interchange Zel’dovich Approximation (PIZA) is introduced which uses the same quadratic cost function (obtained by applying a minimum-action argument within the framework of the Zel’dovich approximation). In PIZA, a randomly chosen tentative correspondence between initial and final points is successively improved by swapping pairs of initial particles whenever this decreases the cost function. Eventually, a monotonic map is obtained which usually does not minimise the cost. This explains the non-uniqueness of PIZA reconstruction (also noticed in ref. 8). 



FIG. 2. Tests of MAK reconstructions of the Lagrangian positions, using the data shown in Fig. 1. The dots near the diagonal are a scatter plot of reconstructed initial points vs. simulation initial points for the coarsest 6.25 h<sup>−1</sup> Mpc grid with 17,178 points. The scatter diagram uses a ‘quasi-periodic projection’ coordinate q˜ ≡ (q1 + q2√2+ q3√3)/(1+ √2+ √3), which guarantees a one-to-one correspondence between q˜-values and points on the regular Lagrangian grid. The upper left inset is a histogram (by percentage) of distances in reconstruction mesh units between such points; the first slightly darker bin (whose width was taken to be slightly less than one mesh) corresponds to perfect reconstruction (thereby allowing a good determination of the peculiar velocities of galaxies); the lower right inset is a similar histogram for reconstruction on a finer 3.12 h<sup>−1</sup> Mpc grid using 19,187 points. With the 6.25h<sup>−1</sup> Mpc grid, 62% of the 17,178 points are assigned perfectly and about 75% are within not more than one mesh. With the 3.12h<sup>−1</sup> Mpc grid, we have 34% of exact reconstruction out of 19,187 points. On further refinement of the mesh by a factor two, this degrades to 14%. 

2 

There are, however, known deterministic strategies for the assignment problem which give the correct unique solution; their complexity (dependence on N of the number of operations needed) is close to N<sup>3</sup> for arbitrary cost functions, but can be sharply reduced when the cost function is quadratic. Combining the organisation of data taken from H´enon’s mechanical analogue machine<sup>27</sup> for solving the assignment problem with the dual simplex method of Balinski,<sup>28</sup> we have designed an algorithm which gives the optimal assignement for about 20,000 particles in a few hours of CPU on a fast Alpha machine. For historical reasons we call our approach Monge–Amp`ere–Kantorovich or MAK (see Methods). Details of the algorithms will be given elsewhere; we merely note that, when working with catalogues of several hundred thousands of galaxies expected within a few years, a direct application of the assignment algorithm in its present state could require unreasonable computational resources. A mixed strategy can however be used, in which the assignment problem is solved on a coarse grid while, on smaller scales, the Monge–Amp`ere equation (1) is solved by a relaxation technique (adapted from ref. 23). 

We tested the MAK reconstruction on data obtained by a cosmological N -body simulation with 128<sup>3</sup> particles, using the HYDRA code<sup>29</sup> (Fig. 1). Reconstruction was performed on three 32<sup>3</sup> grids with (comoving) meshes given by ∆x = 6.25 h<sup>−1</sup> Mpc, ∆x/2 and ∆x/4, where h is the Hubble constant in units of 100 km s<sup>−1</sup> Mpc<sup>−1</sup> . In comoving coordinates, the typical displacement of our mass elements over one Hubble time is about ten h<sup>−1</sup> Mpc. We discarded those points that, at the end of the simulation (present epoch), were not within a sphere containing about 20,000 points, a number comparable to that of currently available all-sky galaxy redshift catalogues. As the simulation assumes periodic boundary conditions, we also took into account periodicity when calculating the distance between pairs of points. The MAK reconstructions were used to generate a scatter diagram and various histograms allowing comparisons of simulation and reconstructed Lagrangian points (Fig. 2). The results demonstrate the essentially potential character of the Lagrangian map above ∼ 6 h<sup>−1</sup> Mpc (within the given cosmological model). 

We also performed PIZA reconstructions on the coarsest grid and obtained typically 30–40% exactly reconstructed points, but severe non-uniqueness: for two different seeds of the random generator only about half of the exactly reconstructed points were the same. 

When reconstructing from observational data, in redshift space (Fig. 3), the galaxies appear displaced radially (as seen by the observer) by an amount proportional to the radial component of the peculiar velocity. We thus performed another reconstruction, with an accordingly modified cost function, that led to somewhat degraded results (Fig. 3) but at the same time provided an approximate determination of peculiar velocities. More accurate determination of peculiar velocities can be done using second-order Lagrangian perturbation theory. The 

effect of the catalogue selection function can be handled by standard techniques; for instance one can assign each galaxy a ‘mass’ inversely proportional to the catalog selection function.<sup>8, 9</sup> 

What is the smallest length scale at which an optimisation algorithm such as MAK can be expected to give a unique and reliable reconstruction? The key ingredient here is the simultaneous knowledge of the initial and present mass density fields. MAK-type reconstruction (with a suitable cost based on the equation of a self-gravitating fluid) should therefore be possible down to scales comparable to the thickness of collapsed structures, below which the hydrodynamical description ceases to be meaningful. 



FIG. 3. Reconstruction test in redshift space with the same data as for the real-space reconstruction tested in the upper left histogram of Fig. 2. The circular redshift map (violet points) corresponds to the same real-space slice as displayed in Fig. 1. The observer is taken to be at the center of the simulation box. Points used for reconstruction within the displayed slice are highlighted in red. Reconstruction is performed by the MAK algorithm with a different cost function, obtained (as in ref. 8) by assuming that the peculiar velocities v can be estimated by the Zel’dovich approximation: v = f (x − q), where f ≈ Ω<sup>0</sup> m<sup>.6≈0.49.Note that we now have</sup> 43% of exactly reconstructed points, included among the 60% which are within not more than 6.25 h<sup>−1</sup> Mpc from their correct positions. 

The fact that MAK guarantees a unique solution and that our present reconstruction hypothesis proved to be very faithful down to 6.5 h<sup>−1</sup> Mpc makes our method very promising for the analysis of galaxy redshift surveys.<sup>10</sup> Reconstruction of the primordial positions and velocities of matter will allow us to test the Gaussian nature of the primordial perturbations and the self-consistency of cosmological hypotheses, such as the choice of the global cosmological parameters and the assumed biasing scheme. 

3 

By obtaining a point-by-point reconstruction of the specific realisation that describes the observed patch of our Universe, we can distinguish between universal properties and the influence of the large-scale environment on the galaxy formation process. Moreover, reconstruction will open a new window not only onto the past but also into the present Universe: it would enable us to make a first-time determination of the peculiar velocities of a very large number of galaxies, using their positions in redshift catalogues. 

### Methods 

### Monge–Amp`ere equation 

The Lagrangian map q �→ x is taken to be the gradient of a convex potential Φ(q); therefore its inverse x �→ q also has a potential representation q = ∇xΘ(x), where Θ(x) is again a convex function; the two potentials are Legendre–Fenchel transforms of each other (see ref. 30, pp. 61–65): 



The potential Θ satisfies the Monge–Amp`ere equation (1), written for the first time by Amp`ere<sup>20</sup> by exploiting the property of the Legendre transformation. Note that within the more restricted framework of the Zel’dovich approximation, Θ differs just by a quadratic additive term from the Eulerian velocity potential.<sup>19</sup> 

### Quadratic cost function 

To show that the quadratic cost minimisation leads to the Monge– Amp`ere equation, we define the displacement field ξ(x) ≡ x − q(x) and perform a variation δξ(x) to obtain, to lowest order, the variation of the cost function δI =<sup>�</sup> x<sup>2 ξ(x)·(ρ(x) δξ) d3x.</sup> The condition that the Eulerian density remains unchanged, which constrains the variation, is expressed as ∇x · (ρ(x)δξ(x)) = 0. By a simple Lagrange multiplier argument, this implies that ξ must be a gradient of some function of x; thus, q = x−ξ = ∇xΘ(x). Furthermore, should Θ be non-convex and thus lead to multi-streaming, this would prevent the Lagrangian map from being optimal. 

### History of mass transportation 

Monge<sup>24</sup> posed the following problem: how to optimally move material from one place to another, knowing only its initial and final spatial distributions, the cost being a prescribed function of the distance travelled by ‘molecules’ of material (a linear function in Monge’s original work). Kantorovich<sup>25</sup> showed that Monge’s query was an instance of the linear programming problem and developed for it a theory which found numerous applications in economics and applied mathematics. 

9. Branchini, E., Eldar, A., Nusser, A. Peculiar velocity reconstruction with fast action method: tests on mock redshift surveys. Mon. Not. R. Astron. Soc., submitted. Preprint astroph/0110618 (2001). 

10. Frieman, J.A. & Szalay, A.S. Large-scale structure: entering the precision era. Phys. Reports 333–334, 215–232 (2000). 

11. Bertschinger, E. & Dekel, A., Recovering the full velocity and density fields from large-scale redshift-distance samples. Astrophys. J. 336, L5–L8 (1989). 

12. Zel’dovich, Ya.B. Gravitational instability: an approximate theory for large density perturbations. Astron.& Astrophys. 5, 84–89 (1970). 

13. Moutarde, F., Alimi, J.-M., Bouchet, F.R., Pellat, R. & Ramani, A. Precollapse scale invariance in gravitational instability. Astrophys. J. 382, 377–381 (1991). 

14. Buchert, T. Lagrangian theory of gravitational instability of Friedman-Lemaitre cosmologies and the Zel’dovich approximation. Mon. Not. R. Astron. Soc. 254, 729–737 (1992). 

15. Munshi, D., Sahni, V. & Starobinsky, A. Nonlinear approximations to gravitational instability: a comparison in the quasi-linear regime. Astrophys. J. 436, 517–527 (1994). 

16. Catelan, P. Lagrangian dynamics in non-flat universes and nonlinear gravitational evolution. Mon. Not. R. Astron. Soc. 276, 115–124 (1995). 

17. Gurbatov, S. & Saichev, A.I. Probability distribution and spectra of potential hydrodynamic turbulence. Radiophys. Quant. Electr. 27, 303–313 (1984). 

18. Shandarin, S.F. & Zel’dovich, Ya.B. The large-scale structure of the universe: turbulence, intermittency, structures in a selfgravitating medium Rev. Mod. Phys. 61, 185–220 (1989). 

19. Vergassola, M., Dubrulle, B., Frisch, U. & Noullez, A. Burgers’ equation, Devil’s staircases and the mass distribution for largescale structures Astron.& Astrophys. 289, 325–356 (1994). 

20. Amp`ere, A.-M. M´emoire concernant . . . l’int´egration des ´equations aux diff´erentielles partielles du premier et du second ordre. Journal de L’Ecole<sup>´</sup> Royale Polytechnique 11, 1–188 (1820). 

21. Brenier, Y. D´ecomposition polaire et r´earrangement monotone des champs de vecteurs. C. R. Acad. Sci. Paris 305, 805–808 (1987). 

22. Gangbo, W. & McCann, R.J. The geometry of optimal transportation. Acta Mathematica 177, 113–161 (1996). 

23. Benamou, J.-D. & Brenier, Y. The optimal time-continuous mass transport problem and its augmented Lagrangian numerical resolution. Numer. Math., 84, 375–393 (2000). (www.inria.fr/rrrt/rr-3356.html). 

24. Monge, G. M´emoire sur la th´eorie des d´eblais et des remblais. Histoire de l’Acad´emie Royale des Science de Paris, 666–704 (1781). 

25. Kantorovich, L. On the translocation of masses. C.R. (Doklady) Acad. Sci. URSS (N.S.) 37, 199–201 (1942). 

26. Rockafellar, R.T. Convex Analysis (Princeton University Press, 1970). 

27. H´enon, M. A mechanical model for the transportation problem. C. R. Acad. Sci. Paris. 321, 741–745 (1995). A more detailed version, including optimisation algorithms, is available at www.obs-nice.fr/etc7/henon.pdf 

28. Balinski, M.L. A competitive (dual) simplex method for the assignment problem. Mathematical Programming 34, 125–141 (1986). 

29. Couchman, H.M.P., Thomas, P.A. & Pearce, F.R. Hydra: an Adaptive-Mesh Implementation of P<sup>3</sup> M-SPH. Astrophys. J. 452, 797–813 (1995). 

30. Arnold, V.I. Mathematical Methods of Classical Mechanics (Springer, Berlin, 1978). 

## Acknowledgements 

1. Narayanan, V.K. & Croft, R.A. Recovering the primordial density fluctuations: a comparison of methods. Astrophys. J. 515, 471– 486 (1999). 

2. Peebles, P.J.E. Tracing galaxy orbits back in time. Astrophys. J. 344, L53–L56 (1989). 

3. Weinberg, D.H. Reconstructing primordial density fluctuations-I. Method. Mon. Not. R. Astron. Soc. 254, 315–342 (1992). 

4. Nusser, A. & Dekel, A. Tracing large-scale fluctuations back in time. Astrophys. J. 391, 443–452 (1992). 

5. Croft, R.A. & Gazta˜naga, E. Reconstruction of cosmological density and velocity fields in the Lagrangian Zel’dovich approximation. Mon. Not. R. Astron. Soc. 285, 793–805 (1997). 

6. Nusser, A. & Branchini, E. On the least action principle in cosmology. Mon. Not. R. Astron. Soc. 313, 587–595 (2000). 

7. Goldberg, D.M. & Spergel, D.N. Using perturbative least action to recover cosmological initial conditions. Astrophys. J. 544, 21–29 (2000). 

8. Valentine, H., Saunders, W. & Taylor, A. Reconstructing the IRAS point source catalog redshift survey with a generalized PIZA. Mon. Not. R. Astron. Soc. 319, L13–L17 (2000). 

Special thanks are due to E. Branchini (observational and conceptual aspects), to Y. Brenier (mathematical aspects) and to M. H´enon (algorithmic aspects and the handling of spatial periodicity and of scatter plots). We also thank J. Bec, H. Frisch, B. Gladman, L. Moscardini, A. Noullez, C. Porciani, M. Rees, E. Spiegel, A. Starobinsky and P. Thomas for comments. This work was supported by the BQR program of Observatoire de la Cˆote d’Azur, by the TMR program of the European Union (UF, RM), by MIUR (SM), by the French Ministry of Education, the McDonnel Foundation, the Russian RFBR and INTAS (AS). 

4
