<!-- fulltext source=oa_pdf slug=doi-10.1109_ecmr.2013.6698835 fetched=2026-09-21T06:20:21+00:00 -->

# **Consistent Sparsification for Graph Optimization** 

Guoquan Huang, Michael Kaess, and John J. Leonard 

**_Abstract_ — In a standard pose-graph formulation of simultaneous localization and mapping (SLAM), due to the continuously increasing numbers of nodes (states) and edges (measurements), the graph may grow prohibitively too large for long-term navigation. This motivates us to systematically reduce the pose graph amenable to available processing and memory resources. In particular, in this paper we introduce a** **_consistent_ graph sparsification scheme: i) sparsifying nodes via marginalization of old nodes, while retaining all the information (consistent relative constraints) – which is conveyed in the discarded measurements – about the remaining nodes after marginalization; and ii) sparsifying edges by formulating and solving a consistent** ℓ1 **-regularized minimization problem, which automatically promotes the sparsity of the graph. The proposed approach is validated on both synthetic and real data.** 

## I. INTRODUCTION 

Recently, most popular solutions to the simultaneous localization and mapping (SLAM) problem, either in batch or incremental fashion, are based on graph optimization (i.e., all robot poses and/or landmark positions comprise the nodes of the graph, while each edge encodes a measurement constraint) [1]–[4]. However, a standard graph formulation may suffer from unbounded complexity of both processing and memory, which can grow continuously over time. This is due to the fact that new robot poses (and new landmarks in the case of feature-based SLAM) are constantly being added into the graph, resulting in the number of nodes increasing constantly in time; and moreover, if frequent loop-closing events occur in SLAM, loop-closure constraints (edges) can significantly increase the density of the graph. This, for example, can be the case where a service robot is operating inside an office building for an extended period of time. 

Even though the issue of reducing the complexity of graph optimization, in particular, for SLAM, has recently been addressed [5]–[9], to the best of our knowledge, little work has yet explicitly taken into account estimation consistency (i.e., unbiased estimates, and the estimated covariance larger than or equal to the true covariance [10]) in the design of graph reduction (sparsification) scheme. This is a significant limitation, since if an estimator is inconsistent, then the accuracy of the computed state estimates is unknown, which in turn makes the estimator unreliable. 

To address the aforementioned issue, in this paper we study in-depth _consistent_ graph sparsification for SLAM, and explicitly enforce consistency during sparsifying _both_ nodes 

This work was partially supported by ONR grants N00014-12-1-0093, N00014-10-1-0936, N00014-11-1-0688, and N00014-12-10020. The authors are with the Computer Science and Artificial Intelligence Laboratory, Massachusetts Institute of Technology, Cambridge, MA 02139, USA. Email: { `gqhuang` | `kaess` | `jleonard` } `@mit.edu` 

and edges of the graph. In particular, the main contributions of this work are the following: 

- We sparsify the nodes of the graph by marginalization of old, matured (accurately estimated) nodes when loop closure occurs, and derive _consistent_ relative constraints for (a subset of) the remaining nodes, which encapsulate _all_ the information – conveyed in the discarded measurements at the time of marginalization – about the remaining nodes. As a result, the problem size (i.e., the number of optimization variables) is bounded _only_ by the explored area, and independent of the exploration time. Although marginalization (Schur complement) is commonly used to reduce the size of the state vector in batch estimation [11], when applied to graph-based incremental estimation, to the best of our knowledge, little work has been shown to optimally (and thus consistently) extract all the information about the remaining nodes from the discarded measurements and then propagate it to subsequent optimization. In contrast, we explicitly derive from the discarded measurements the consistent (i.e., without reuse or loss of information) relative constraints for the remaining nodes that are also involved in the discarded measurements. These induced constraints, in general, are _correlated_ , instead of independent as assumed in most prior work, and are used as new measurements in subsequent estimation. 

- Furthermore, we sparsify the edges of the graph by formulating and solving a _consistent_ ℓ1-regularized minimization problem. In particular, due to marginalization of old nodes as well as frequent loop closures, it may become necessary to systematically remove some edges so as to reduce the processing and memory requirements. Towards this end, we formulate the sparsification of graph edges as a novel consistency-constrained ℓ1-regularized minimization problem, which implicitly imposes the sparsity of the solution due to ℓ1 norm. As a result, its solution renders the sparsified graph which consistently approximates the original dense graph (i.e., by definition, the covariance of the resulting sparsified graph is larger than or equal to that of the original one). It is interesting to point out that, while ℓ1minimization has been extensively studied in compressive sensing [12], the application to graph sparsification treated in this paper is expected to promote its widespread adoption in robotics. 

## II. RELATED WORK 

The SLAM problem has received considerable attention over the past two decades and many different estimators were 

1 

employed for solving it. In particular, filtering methods such as the extended Kalman filter (EKF) recursively estimate a state vector consisting of the current robot pose and the observed landmarks [13]–[16]. One appealing property of such a filtering algorithm is its bounded runtime with respect to the size of the explored environment, while the quadratic computational complexity limits its applications to large areas. Moreover, due to the fact that any linearization-based filter marginalizes out the previous robot poses, it cannot relinearize the nonlinear system and measurement models at the past states, which may result in large linearization errors and degrade the performance. 

## _A. Graph optimization_ 

Graph-based batch optimization methods for SLAM recently have prevailed (e.g., [1], [3], [4], [17]–[23]). These methods follow the paradigm of bundle-adjustment (BA) algorithms originally developed in photogrammetry and computer vision [11], and formulate and solve a batch leastsquares problem for the entire robot trajectory (and all landmarks), with no marginalization. These BA-based approaches exploit the sparsity of the measurement graph so as to speed up computation. However, for large-scale problems, an optimal batch solution may still be too computationally expensive to obtain in real time [24]. 

Therefore, different approximate methods for graph optimization have been developed, which either use a subset of the data to optimize over only a subset of variables, or solve the BA problem intermittently. Specifically, sliding-window filters (SWFs) [25], [26] compute a solution for a constantsize, sliding window of states (robot poses and landmark positions) using only the measurements corresponding to that time interval. Similarly, keyframe-based approaches [27]– [29] perform batch optimization over only a (heuristically) selected subset of views or keyframes. On the other hand, incremental approaches to BA, such as the incremental smoothing and mapping (iSAM) algorithm [2], greatly reduce computation by employing factorization-updating methods that allow reusing the information-matrix factorization available from previous time steps. Computationally demanding procedures, such as relinearization and batch factorization, are only performed periodically. Nevertheless, the incremental methods still suffer from increased computational cost. For instance, due to the increased robot trajectory over time as well as the accumulation of fill-in between periodic batch steps, iSAM’s efficiency degrades with the increasingly dense graph (e.g., if the number of constraints is more than five times the number of poses as reported in [24]). It becomes necessary to sparsify both the nodes and the edges of the graph in order to fully take advantage of the efficiency offered by the incremental estimation algorithms in large environments. 

## _B. Graph reduction_ 

The keyframe-based approximate approaches for graph optimization [28], [29] are among the first attempt to reduce the pose graph for visual SLAM. As mentioned earlier, 

these approaches create a sparse skeleton graph of views (poses) and then perform batch optimization only on these keyframes. In particular, in order to keep the density of poses constant in a given region, old poses are marginalized out from the skeleton graph. However, it is unclear that if applying these methods to an incremental setting, how the information (which is conveyed in the discarded measurements after marginalization) about the remaining poses is utilized in future optimization. In this work, we explicitly derive the _consistent_ relative constraints for (a subset of) the remaining poses that are involved in the discarded measurements. These induced constraints describe _all_ the information for the remaining states available in the discarded measurements, and are used as new constraints in future estimation. 

Similarly, in [5] marginalization is employed to reduce graph complexity. However, since it composes the relativepose constraints for the remaining states directly from the discarded measurements by geometry, during this process, the same measurement information may be used multiple times, which results in _inconsistent_ constraints. In addition, it heuristically removes edges based on the degrees of their nodes; when the degree of a node exceeds an ad-hoc, prechosen threshold, the associated edge with the least residual error is pruned out. We also notice that the recent work of [8] bounds the size of the pose graph with respect to the explored area, instead of the exploration time. To this end, this approach does not add new nodes at loop closures (without marginalization), while retaining new relative-pose constraints between the existing nodes involved in the loop closures, which are inferred directly from the discarded measurements in a similar way as in [5]. 

Recently, compact pose SLAM [6] uses an informationtheoretic method to determine which poses should be added into the state vector of the information filter [30] and which measurements should be utilized in the estimation. In particular, only nonredundant poses are included in the graph if no other poses are nearby, and only highly informative loop-closure edges (computed based on the mutual information gain) are added into the graph, while other poses and measurements are simply discarded. This clearly results in loss of information. Interestingly, the proposed sparsification scheme presented in Section IV can combine the node reduction idea of [6] to determine which nodes to marginalize out, while retaining all the information about the remaining nodes from the discarded measurements. 

More recently, an information-theoretic approach is proposed to compress the pose graph, _only_ for laser-based SLAM [7]. Specifically, this method selects only the most informative laser scans (nodes) with respect to the built map of the environment; and moreover, it employs the _approximate_ marginalization based on Chow-Liu tree to keep the sparsity of the pose graph. However, it remains unclear that, during this approximate marginalization, how the information conveyed in the discarded laser scans about the remaining nodes, is extracted and utilized in an incremental framework. Moreover, the Chow-Liu tree approximation employed in the marginalization in theory does not guarantee consistency. In 

2 

contrast, both issues are explicitly addressed in our proposed approach (see Section IV). 

We also notice that the most recent publication [9] addresses the same problem of pose-graph sparsification. In [9], a marginalization process similar to Section IV-A is used to sparsify the nodes; and a better Chow-Liu tree-based approximation than that of [7] is proposed to sparsify the edges. However, the Chow-Liu tree-based sparsification yet does not guarantee consistent estimates, which is addressed in this paper by formulating and solving a consistent ℓ1regularized sparsification problem. 

On the other hand, conservative (consistent) sparsification of information matrix is introduced in [31] for sparse extended information filter (SEIF)-based SLAM [32], [33]. While this approach is closely related to the proposed sparsification of graph edges (see Section IV-B), we formulate such consistent sparsification as an ℓ1-regularized minimization problem which implicitly promotes the sparsity by ℓ1 norm and whose solution automatically renders the sparsified information matrix (graph). As a result, the proposed approach does not need to know which edges to eliminate beforehand, which, however, is assumed in [31]. 

## III. PROBLEM FORMULATION 

While many problems in robotics and computer vision can be formulated as graph (network) optimization, in this section we focus on SLAM to illustrate the graph-based formulation. In particular, graph-based SLAM [3] consists of a front-end and a back-end. The former aims to extract all the relative-pose constraints from the raw sensor measurements (e.g., [34]), while the latter is to compute the most likely configuration of the poses, which is the focus of this paper. 

Specifically, in the graph built during the front-end, the robot poses are described by the nodes of the graph, and the edges represent the spatial constraints between the connecting nodes, which are constructed either from proprioceptive (e.g., odometry) or exteroceptive measurements (e.g., images). Let x = �x1T<sup>, . . . , xT</sup> n �T be the robot poses (nodes), and zij = h(xi, xj) + nij be the measurement constraint (edge) between the nodes i and j, where noise is commonly assumed to be zero-mean white Gaussian, i.e., nij ∼N (0, Wij ). The objective of the back-end is to compute the maximum likelihood estimate (MLE) of all the robot poses (nodes) using all the measurement constraints (edges). By assuming independent measurements, we have the following factorization of the measurement likelihood function: 



where Z = {zij} denotes all the measurements (edges). By using the Gaussian-noise assumption and taking the negative logarithm of (1), we can easily show that maximizing the likelihood (1) is equivalent to minimizing the following leastsquares cost function: 



where we have used the notation ||r||<sup>2</sup> W<sup>= rT W−1r, i.e., the</sup> squared Mahalanobis distance of residual r with covariance W. This is a _nonlinear_ least-squares problem because of the nonlinearity of the constraints h(·). 

A standard iterative Gauss-Newton approach is often used for solving (2). In particular, at the k-th Gauss-Newton iteration, a correction, δx<sup>(k)</sup> , to the current estimate, ˆx<sup>(k)</sup> , is computed by minimizing the second-order Taylor-series approximation of (2), which can be written as: 



where we linearize the measurement constraints at the current state estimate with Jacobians, H<sup>(</sup> ij<sup>k)=∂h(</sup> ∂<sup>x</sup> x<sup>i,xj)</sup> ���x=ˆx<sup>(k). Note</sup> that hereafter we drop the iteration index (k) for simplicity of notation. We now have a _linear_ least-squares problem with respect to δx (3), where J is the full Jacobian matrix obtained by stacking and weighting all the measurement Jacobians, and r is the corresponding stacked residual vector: 



We employ QR factorization to solve (3), i.e., 





Once δx is found by back substitution (5), the new state estimate is updated as: ˆx<sup>(k+1)</sup> = ˆx<sup>(k)</sup> + δx<sup>(k)</sup> . 

## _A. Incremental smoothing and mapping_ 

When a new measurement, zmn, sequentially becomes available, ideally we need to recompute the full Jacobian J and solve the batch problem from scratch. However, this is an expensive operator, even by exploiting the sparsity of the Hessian matrix [1], [4], [20]. To save computations, we focus on incremental smoothing and mapping (iSAM) [2], which reuses the previously-computed Jacobian and _incrementally_ updates the QR factorization directly. 

In particular, we augment J (without recomputing it) with the new measurement Jacobian Hmn [see (6)]: 



We now aim to decompose Ja into triangular form (i.e., square-root information matrix). Since J was already factorized into the triangular R, we only need to zero out 

3 

the new block row, i.e., the new measurement Jacobian Hmn, in order to obtain the updated square-root information matrix Ra. This can be achieved efficiently, for example, by using Givens QR [35]. Similarly, the corresponding new vector, da, can be obtained by applying the same Givens rotations to the augmented residual vector, da := 



It is important to note that, although relinearization is not needed at each time step when a new measurement becomes available, in order to reduce the linearization errors, we relinearize the system at the latest, and thus the best, state estimates periodically [2] or as needed when the linearization point significantly deviates from the current state estimate [24]. In addition, we can combine variable reordering [2] with this batch factorization to reduce fill-in of the resulting triangular system [see (5)], which can further speed up the subsequent incremental estimation. 

## IV. CONSISTENT GRAPH SPARSIFICATION 

Even though different algorithms, such as the iSAM presented in the preceding section (also see [2]), are available to improve the efficiency of batch least-squares solutions, their performance degrades with the growing size of the graph as the robot continuously navigates in its environments. In order to make the processing and memory requirements amenable for long-term operation, in this section we introduce consistent sparsification of both the nodes and edges of the graph within the incremental estimation framework. 

## _A. Consistent node sparsification via marginalization_ 

First of all, we sparsify the nodes of the graph by marginalizing out the selected old poses, while consistently retaining all the information that discarded measurements convey about the remaining nodes, so as to bound the size of the graph (state vector) only with respect to the explored area, instead of the exploration time. Note that this temporally-scalable idea has been explored in [8], which, however, follows an approximate composition of discarded measurements. In particular, we partition the nodes (states), x = , where xM denote the nodes to marginalize �xxMR � out, and xR are those remaining in the graph. In this work we choose xM to be the old poses when loop closure occurs. This, however, is not a necessary assumption; instead, one can selectively discard the most matured (accurately estimated) or the least informative nodes as compared to the rest of the graph [6], [7]. We should repeat that in this work we focus more on how to optimally (and thus consistently) retrieve all the information from the discarded measurements about the remaining nodes, instead of on studying which nodes are the best to marginalize. 

The marginalization process is carried out with Schur complement, and yields the following reduced-Hessian matrix for the remaining state xR: 



where the matrices appearing in the above equation are defined as partitions of the full-Hessian matrix [see (3) and (4)]: 



Note that the estimates of the remaining nodes, ˆxR, remain the same before and after this marginalization process [30], due to the fact that the marginal distribution of a joint Gaussian distribution is also Gaussian. After marginalization, all the states in xM, as well as all the measurements that involve these states, denoted by ZM, are discarded, and no longer participate in the future optimization. 

It is important to note that, the discarded measurements ZM typically involve, and thus convey information about, a subset of the remaining states xR. In order for consistent (i.e., without loss or reuse of information) estimation in an incremental fashion, we need to retain all such information and propagate it to subsequent optimization. Therefore, we now focus on deriving such consistent constraints from the discarded measurements, which will be used whenever the batch relinearization occurs in the incremental estimation. 

_1) Derive consistent relative constraints from_ ZM _:_ We further partition the remaining states into two subsets, xR1 which together with xM are involved in the discarded measurements and xR2 which are not involved, i.e., xR = . In order to optimally retrieve all the information �xxRR21 � conveyed in the discarded measurements about the subset of the remaining states, ideally we should solve the MLE (least-squares) problem of minimizing cm(xM, xR1 ), for xR1 [see (2)]. However, in most cases, ZM contains only _relative_ pose-to-pose measurement constraints, and does not include any _global_ information about the involved states. This implies that the corresponding system is _unobservable_ and we cannot find the optimal estimates of xM and xR1 in the global frame of reference without ambiguity [10]. Instead, we can _locally_ find MLE for the remaining nodes xR1 , by transforming the involved states into a local frame of reference of one remaining state (e.g., of the first node in xR1 ). The computed MLE of the relative-state estimates essentially are the relative-pose constraints that encapsulate all the information contained in the discarded measurements for the remaining states, and will be used for computing the Jacobians and Hessians in the future optimization. 

Specifically, we now solve the following least-squares (MLE) problem using _only_ the discarded measurements ZM, with respect to the _relative_ states,<sup>L</sup> xM and<sup>L</sup> ¯xR1 , [see (2)]. Here the symbol “ ¯ ” denotes that the remaining nodes exclude the node used to define the local frame {L}. 



Similarly, a Gauss-Newton approach is employed to solve the above problem. The information (Hessian) matrix of the estimates of the relative remaining states (i.e., the relativepose constraints), is again obtained using Schur complement 

4 

by marginalizing out<sup>L</sup> xM [see (9) and (8)]: 





where the symbol “ ¯ ” denotes that all the involved Jacobians and Hessians are computed with respect to the _relative_ states, LxM and L¯xR1 , which are different from (8) and (9). 

Close inspection reveals that the information matrix A<sup>¯</sup> m encapsulates all the information contained in the discarded measurements ZM; and thus A<sup>¯</sup> p, the Schur complement of A<sup>¯</sup> MM in A<sup>¯</sup> m, describes _all_ the information that the discarded measurements provide us about the relative remaining states, L¯xR1 . Therefore, the relative constraints for the remaining states induced from the discarded measurements,<sup>L</sup> ¯xR1 ∼N �Lˆ¯xR1 , ¯A−p 1�, are consistent (i.e., without loss/reuse of information). Note that these essentially are the relative-frame generic linear constraints (GLC) as derived in [9]. Note also that, due to marginalization (12), in general, the information matrix A<sup>¯</sup> p, and thus the corresponding covariance matrix A<sup>¯−</sup> p<sup>1,isfull.Thisindicatesthat</sup> the induced relative constraints for the remaining states are _correlated_ , instead of independent. 

At this point, we stress that although marginalization of old nodes is often used to reduce the pose graph (e.g., [5], [7]), prior to [9] that was developed in parallel to this work, to the best of our knowledge, little work has yet explicitly derived optimal (consistent) relative constraints for the remaining nodes from the discarded edges, for the use in future estimation. In particular, in [5] the authors compose a new _independent_ edge (relative constraint) – induced by marginalization – directly from the connected discarded edges by geometry. However, since same discarded edges may be used multiple times in composing new edges, these new edges should be _correlated_ . As a result of this reuse of information of same measurements, inconsistent relative constraints for the remaining nodes are inferred, which will negatively impact subsequent estimation. In contrast, in the proposed approach we infer the optimal relative constraints by solving a batch MLE (least-squares) problem followed by marginalization, and hence capture all the correlations between the induced constraints. 

## _B. Consistent edge sparsification via_ ℓ1 _-minimization_ 

Due to marginalization as well as loop closures, the information (Hessian) matrix, and thus the graph, inevitably becomes dense, which can significantly increase the computational burden for the graph optimizer (or batch leastsquares solver). To address this issue, we now aim to sparsify the edges of the graph in a _consistent_ manner – the covariance of the sparsified graph is larger than or equal to that of the original one. 

Mathematically, suppose the original dense graph representing a Gaussian distribution, N (ˆx, Σ). We aim to find a sparse graph to consistently approximate the original one, with the mean unchanged, i.e., the corresponding Gaussian distribution, N (ˆx, X<sup>−1</sup> ), where X is the resulting sparse 

information matrix. To this end, as in [31] we choose to minimize the Kullback-Leibler Divergence (KLD) between the two Gaussians, while enforcing the consistency constraint on the covariance matrix, i.e., 



By noting that the original covariance matrix Σ as well as the dimension of the state x is known, this is a _convex_ problem, and hence the global minimum can be guaranteed [36]. In [31] an optimal solution is constructed by assuming that the edges of the graph to remove are known before sparsification, which clearly is not always the case in practice. 

In contrast, we notice that ℓ1-minimization, which is convex and ensures a sparse solution, has been extensively studied in compressive sensing [12]. By exploiting this idea, we reformulate the problem (13) and (14) as the following convex consistency-constrained ℓ1-regularized minimization problem, whose solution automatically renders a consistent sparse information matrix: 





where ||·||1 denotes the ℓ1 norm, and λ is a design parameter to control the level of sparsity of the solution, which can be selected heuristically as [37]. Note that the equivalence between the constraints (14) and (16) is established based on Corollary 7.7.4 in [38]. While many different convex optimization algorithms [36], such as interior point methods, are available to solve the above problem (15) and (16), we adapt the alternating direction method of multipliers (ADMM) [39] to solve it more efficiently. 

In particular, ADMM is often used to solve problems of the following form: 



where the optimization variable X is n-dimensional symmetric positive definite, i.e., X ∈S++<sup>n.Bydefiningf(X):=</sup> − ln (det X) + tr (XΣ), and g(Y) := λ||Y||1, we have the same problem as in (15), but _without_ consistency constraint (16). To solve the above ℓ1-regularized problem (17), the ADMM algorithm iterates as follows [39]: 



where ρ > 0 is a penalty parameter used in the augmented Lagrangian and || · ||F denotes the Frobenius norm. 

In order to find the desired _consistent_ sparse information matrix, X, we now include the consistency constraint (16) into the ADMM step (18). In particular, the optimality 

5 

condition of (18) is given by: 



where we have employed the eigen-decomposition in the second equality with D = Diag(di). By inspection, the solution has the following form, X<sup>(k+1)</sup> := VΓV<sup>T</sup> , where Γ = Diag(γi), γi > 0. To find Γ and thus X, substitution of the above form of X<sup>(k+1)</sup> into (22) yields: 





In order to satisfy the consistency constraint (16), we need to ensure γi (24) is smaller than the minimum eigenvalue of Σ<sup>−1</sup> , denoted by λmin(Σ<sup>−1</sup> ). Therefore, we compute γi as: 



On the other hand, (19) is a well-known lasso problem and its optimal solution is given by [40]: 



where the shrinkage operator, shrink(Ξ, ξ), updates each element Ξij as: shrink(Ξ, ξ)ij = sgn(Ξij) max (|Ξij| − ξ, 0). Since no closed-form solution can be found to ensure its consistency, i.e., Y<sup>(k)</sup> < Σ<sup>−1</sup> [see (16)], we relax this consistency constraint in this step. This can be justified by the fact that, although Y<sup>(k)</sup> may not satisfy (16) or even not be positive definite, X<sup>(k+1)</sup> , which is what we are ultimately seeking, always remains so by construction. 

## V. EXPERIMENTAL RESULTS 

To validate the proposed consistent graph sparsification, we have preliminarily tested the algorithm on both synthetic and real-world data: i) Manhattan3500 (3500 nodes, 5598 edges), ii) City4000 (2815 nodes, 20687 edges), iii) Intel research lab (909 nodes, 4453 edges), and iv) MIT Killian court (1940 nodes, 2190 edges). The first two datasets are synthetic, while the last two are real. For the results presented in this section, we integrate the proposed graph sparsification scheme into the iSAM algorithm [2] performing incremental estimation, termed S-iSAM,<sup>1</sup> which is compared with the ground truth for the simulated data and with the batch leastsquares (BLS) – that is the best result can be obtained in practice – for the real data. We marginalize out the old poses when loop closures occur, and sparsify the graph when the number of non-zeros of the information (Hessian) matrix exceeds a pre-chosen threshold (for instance, 10% of the total matrix entries). 

In particular, Fig. 1 shows, as an example, the information (Hessian) matrices before and after the proposed sparsification of edges in the case of Manhattan3500. It is clear that the sparsified information (Hessian) matrix 

> 1It is important to point out that the proposed sparsification scheme can be integrated into the SEIF as in [31], besides the iSAM as considered here. 



<!-- Start of picture text -->
original information matrix sparsified informaiton matrix<br>0 0<br>5 5<br>10 10<br>15 15<br>20 20<br>25 25<br>0 5 10 15 20 25 0 5 10 15 20 25<br>nz = 408 nz = 94<br><!-- End of picture text -->

Fig. 1. Illustration of the proposed consistent sparsification of edges for the Manhattan3500 graph occurring at a particular time step. 

significantly reduces the non-zeros, by 77% in this particular case, while preserving consistency (which can be easily verified numerically). Note also that, in practice it is not necessary to perform the proposed edge sparsification, i.e., to solve the ℓ1-regularized minimization, every time step, thus saving substantial computational cost, particularly when the graph becomes large. This is due to the fact that the graph becomes dense only when marginalization or loop closure occurs, which, in general, is an occasional event (i.e., not as frequent as adding an edge/node). 

Moreover, Figs. 2 and 3 show the estimates and their errors, respectively, as compared to the benchmarks (i.e., ground truth for simulated data, and BLS for the real data). As evident, the proposed S-iSAM achieves results close to the benchmarks, while keeping significantly fewer nodes, i.e., 1971 nodes for Manhattan3500 (56%), 2098 nodes for City4000 (75%), 507 nodes for Intel (56%), and 1718 nodes for MIT (89%). We would like to point out that the proposed node sparsification provides a consistent way of retrieving the information about the remaining nodes from the discarded measurements, rather than intends to find the minimum number of nodes to represent the original graph. It should be also stressed that, when a node is marginalized out, all the measurements (edges) connected to it – including the future measurements of this kind – are discarded, and hence cannot be used for the subsequent estimation in order to obtain causal estimates (without using discarded information). This implies that the proposed approach may utilize significantly fewer measurements (depending on the particular graphs) than the BLS that uses all available measurements, while achieving comparable performance. This result is attributed to the fact that _all_ the information, conveyed in the discarded measurements, about the remaining states, is retained during the proposed consistent node sparsification. 

## VI. CONCLUSIONS AND FUTURE WORK 

In this paper, we have proposed a consistent sparsification scheme for graph optimization with applications to SLAM. In particular, we first sparsify the nodes of the graph by marginalizing out old poses at the times of loop closures, while retaining all the information for the remaining nodes conveyed in the discarded measurements. To this end, we formulate a batch MLE (least-squares) problem using only the discarded measurements, with respect to the relative, instead 

6 



<!-- Start of picture text -->
10 DR DR<br>S−iSAM 40 S−iSAM<br>Ground truth Groud truth<br>0<br>−10 20<br>−20<br>0<br>−30<br>−20<br>−40<br>−50 −40<br>−60<br>−60<br>−70<br>−50 −40 −30 −20 −10 0 10 20 30 40 50 −80 −60 −40 −20 0 20 40 60<br>(a) Manhattan3500 (b) City4000<br>DR DR<br>S−iSAM 120 S − iSA M<br>BLS BL S<br>0 100<br>80<br>−5 60<br>40<br>−10<br>20<br>0<br>−15<br>−20<br>−40<br>−20<br>−60<br>−10 −5 0 5 10 15 20 −200 −150 −100 −50 0<br>(c) Intel Research Lab (d) MIT Killian Court<br><!-- End of picture text -->

Fig. 2. Experimental results on the synthetic (a and b) and real (d and c) data: In these plots, the dots correspond to the dead-reckoning (DR), the crosses to the benchmark which is either the ground truth or the batch least-squares (BLS), the squares to the iSAM with the proposed sparsification scheme (S-iSAM). It is clear that the proposed method achieves results close to the benchmarks, even though it utilizes less information from the available measurements as some measurements are discarded for the future usage due to marginalization. Note also that in the two real-world datasets (c and d), the compared approaches produce very similar results (see Fig. 3), which makes the corresponding lines difficult to distinguish. 



<!-- Start of picture text -->
6 1.4 3.5 x 10−5 2 x 10−3<br>543 1.20.80.61 2.51.532 1.51<br>2 0.4 1 0.5<br>1 0.2 0.5<br>00 200 400 600 800 1000 1200 1400 1600 1800 2000 00 500 1000 1500 2000 2500 00 100 200 300 400 500 600 00 200 400 600 800 1000 1200 1400 1600 1800<br>0.2 0.07 1 x 10−5 1.4 x 10−5<br>0.15 0.060.05 0.8 1.21<br>0.1 0.040.03 0.60.4 0.80.6<br>0.05 0.020.01 0.2 0.40.2<br>00 200 400 600 800 node no. 1000 1200 1400 1600 1800 2000 00 500 1000 node no. 1500 2000 2500 00 100 200 node no. 300 400 500 600 00 200 400 600 node no. 800 1000 1200 1400 1600 1800<br>(a) Manhattan3500 (b) City4000 (c) Intel Research Lab (d) MIT Killian Court<br>position error (m) position error (m) position error (m) position error (m)<br>orientation error (rad) orientation error (rad) orientation error (rad) orientation error (rad)<br><!-- End of picture text -->

Fig. 3. Estimation errors of the proposed S-iSAM as compared to the benchmarks (ground truth or BLS) in the synthetic and real data. In these plots, the upper subplots are the estimation errors of the positions and the bottom ones are the orientation estimation errors. It becomes evident that the iSAM with the proposed graph sparsification scheme attains comparable performance as that of the benchmarks. 

of global, states (i.e., in the local frame of reference of one remaining node involved in the discarded measurements). Furthermore, we sparsify the edges of the graph based on a consistent ℓ1-regularized convex minimization problem which promotes the sparsity of the solution imposed by ℓ1 norm and is solved by adapting the ADMM algorithm [39]. The solution to this convex problem automatically renders a 

sparsified graph that consistently approximates the original one. The proposed graph sparsification scheme has been integrated in the iSAM algorithm [2] and validated on both synthetic and real data. 

It should be pointed out that, although the ADMM method is efficient to solve a relatively small problem of consistent edge sparsification [see (15) and (16)] (e.g., when the number 

7 

of nodes of the graph is in the order of thousands), it may not be satisfactory when the graph becomes even larger. For this reason, in the future we will investigate different ways to speed up the solution to the ℓ1-regularized minimization problem, for example, by selecting only a dense subgraph to sparsify via the ADMM approach, instead of the whole graph as we currently do. Moreover, since, by no means, it would be optimal to marginalize out the old nodes at loop closures, we will study in depth the problem of which nodes should be marginalized out and when, in order to maximize the information retained in the sparsified graph while achieving a minimal representation of the original graph. In addition, we will conduct more thorough evaluations on various largescale real-world experiments. 

## REFERENCES 

- [1] F. Dellaert and M. Kaess, “Square root SAM: Simultaneous localization and mapping via square root information smoothing,” _International Journal of Robotics Research_ , vol. 25, no. 12, pp. 1181–1203, Dec. 2006. 

- [2] M. Kaess, A. Ranganathan, and F. Dellaert, “iSAM: Incremental smoothing and mapping,” _IEEE Transactions on Robotics_ , vol. 24, no. 6, pp. 1365–1378, Dec. 2008. 

- [3] G. Grisetti, R. Kummerle, C. Stachniss, and W. Burgard, “A tutorial on graph-based SLAM,” _IEEE Intelligent Transportation Systems Magazine_ , vol. 2, no. 4, pp. 31–43, 2010. 

- [4] R. Kummerle, G. Grisetti, H. Strasdat, K. Konolige, and W. Burgard, “g2o: A general framework for graph optimization,” in _Proc. of the IEEE Intl. Conf. on Robotics and Automation_ , Shanghai, China, May 9–13, 2011, pp. 3607–3613. 

- [5] E. Eade, P. Fong, and M. Munich, “Monocular graph SLAM with complexity reduction,” in _Proc. of the IEEE/RSJ Intl. Conf. on Intelligent Robots and Systems_ , Taipei, Taiwan, Oct. 18–22, 2010, pp. 3017–3024. 

- [6] V. Ila, J. Porta, and J. Andrade-Cetto, “Information-based compact pose SLAM,” _IEEE Transactions on Robotics_ , vol. 26, no. 1, pp. 78– 93, Feb. 2010. 

- [7] H. Kretzschmar and C. Stachniss, “Information-theoretic compression of pose graphs for laser-based SLAM,” _International Journal of Robotics Research_ , vol. 31, no. 11, pp. 1219–1230, Sep. 2012. 

- [8] H. Johannsson, M. Kaess, M. Fallon, and J. Leonard, “Temporally scalable visual SLAM using a reduced pose graph,” in _Proc. of the IEEE Intl. Conf. on Robotics and Automation_ , Karlsruhe,Germany, May 6–10, 2013, pp. 54–61. 

- [9] N. Carlevaris-Bianco and R. M. Eustice, “Generic factor-based node marginalization and edge sparsification for pose-graph SLAM,” in _Proc. of the IEEE Intl. Conf. on Robotics and Automation_ , Karlsruhe, Germany, May 6–10, 2013, pp. 5728–5735. 

- [10] Y. Bar-Shalom, X. R. Li, and T. Kirubarajan, _Estimation with applications to tracking and navigation_ . New York: Wiley, 2001. 

- [11] B. Triggs, P. F. McLauchlan, R. I. Hartley, and A. W. Fitzgibbon, “Bundle adjustment – a modern synthesis,” _Lecture Notes in Computer Science_ , vol. 1883, pp. 298–375, Jan. 2000. 

- [12] D. Donoho, “Compressed sensing,” _IEEE Transactions on Signal Processing_ , vol. 52, no. 4, pp. 1289–1306, Apr. 2006. 

- [13] S. Thrun, “Robotic mapping: A survey,” in _Exploring artificial intelligence in the new millennium_ , G. Lakemeyer and B. Nebel, Eds. San Francisco, CA: Morgan Kaufmann Inc., 2003, pp. 1–35. 

- [14] S. Thrun, W. Burgard, and D. Fox, _Probabilistic robotics_ . Cambridge, MA: The MIT Press, 2005. 

- [15] H. Durrant-Whyte and T. Bailey, “Simultaneous localization and mapping: Part I,” _IEEE Robotics Automation Magazine_ , vol. 13, no. 2, pp. 99–110, Jun. 2006. 

- [16] T. Bailey and H. Durrant-Whyte, “Simultaneous localization and mapping (SLAM): Part II,” _IEEE Robotics Automation Magazine_ , vol. 13, no. 3, pp. 108–117, 2006. 

- [17] F. Lu and E. Milios, “Globally consistent range scan alignment for environment mapping,” _Autonomous Robots_ , vol. 4, no. 4, pp. 333– 349, Oct. 1997. 

- [18] J. Folkesson and H. Christensen, “Graphical SLAM - a self-correcting map,” in _Proc. of the IEEE Intl. Conf. on Robotics and Automation_ , vol. 1, Apr. 26– May 1, 2004, pp. 383–390. 

- [19] E. Olson, J. Leonard, and S. Teller, “Fast iterative alignment of pose graphs with poor initial estimates,” in _Proc. of the IEEE Intl. Conf. on Robotics and Automation_ , Orlando, FL, May 15–19, 2006, pp. 2262– 2269. 

- [20] K. Konolige, G. Grisetti, R. Kummerle, W. Burgard, B. Limketkai, and R. Vincent, “Efficient sparse pose adjustment for 2D mapping,” in _Proc. of the IEEE/RSJ Intl. Conf. on Intelligent Robots and Systems_ , Taipei, Taiwan, Oct. 18–22, 2010, pp. 22–29. 

- [21] G. Grisetti, C. Stachniss, and W. Burgard, “Nonlinear constraint network optimization for efficient map learning,” _IEEE Transactions on Intelligent Transportation Systems_ , vol. 10, no. 3, pp. 428–439, Sep. 2009. 

- [22] G. Grisetti, R. Kummerle, C. Stachniss, U. Frese, and C. Hertzberg, “Hierarchical optimization on manifolds for online 2D and 3D mapping,” in _Proc. of the IEEE Intl. Conf. on Robotics and Automation_ , Anchorage, AK, May3–8, 2010, pp. 273–278. 

- [23] H. Strasdat, J. M. M. Montiel, and A. J. Davison, “Visual SLAM: Why filter?” _Image and Vision Computing_ , vol. 30, no. 2, pp. 65–77, Feb. 2012. 

- [24] M. Kaess, H. Johannsson, R. Roberts, V. Ila, J. Leonard, and F. Dellaert, “iSAM2: Incremental smoothing and mapping using the Bayes tree,” _International Journal of Robotics Research_ , vol. 31, pp. 217– 236, Feb. 2012. 

- [25] G. Sibley, L. Matthies, and G. Sukhatme, “Sliding window filter with application to planetary landing,” _Journal of Field Robotics_ , vol. 27, no. 5, pp. 587–608, 2010. 

- [26] G. P. Huang, A. I. Mourikis, and S. I. Roumeliotis, “An observability constrained sliding window filter for SLAM,” in _Proc. of the IEEE/RSJ Intl. Conf. on Intelligent Robots and Systems_ , San Francisco, CA, Sep. 25–30, 2011, pp. 65–72. 

- [27] G. Klein and D. Murray, “Parallel tracking and mapping for small AR workspaces,” in _Proc. of the IEEE and ACM International Symposium on Mixed and Augmented Reality_ , Nara, Japan, Nov. 13–16, 2007. 

- [28] K. Konolige and M. Agrawal, “FrameSLAM: From bundle adjustment to real-time visual mapping,” _IEEE Transactions on Robotics_ , vol. 24, no. 5, pp. 1066–1077, Oct. 2008. 

- [29] K. Konolige, J. Bowman, J. D. Chen, P. Mihelich, M. Calonder, V. Lepetit, and P. Fua, “View-based maps,” _International Journal of Robotics Research_ , vol. 29, no. 8, pp. 941–957, Jul. 2010. 

- [30] R. M. Eustice, H. Singh, and J. J. Leonard, “Exactly sparse delayedstate filters for view-based SLAM,” _IEEE Transactions on Robotics_ , vol. 22, no. 6, pp. 1100–1114, Dec. 2006. 

- [31] J. Vial, H. Durrant-Whyte, and T. Bailey, “Conservative sparsification for efficient and consistent approximate estimation,” in _Proc. of the IEEE/RSJ Intl. Conf. on Intelligent Robots and Systems_ , San Francisco, CA, Sep. 25–30, 2011, pp. 886 –893. 

- [32] S. Thrun, Y. Liu, D. Koller, A. Ng, Z. Ghahramani, and H. DurrantWhyte, “Simultaneous localization and mapping with sparse extended information filters,” _International Journal of Robotics Research_ , vol. 23, no. 7-8, pp. 693–716, Aug. 2004. 

- [33] M. R. Walter, R. M. Eustice, and J. J. Leonard, “Exactly sparse extended information filters for feature-based SLAM,” _International Journal of Robotics Research_ , vol. 26, no. 4, pp. 335–359, 2007. 

- [34] E. Olson, “Robust and efficient robotic mapping,” Ph.D. dissertation, MIT, Cambridge, MA, USA, 2008. 

- [35] G. H. Golub and C. F. V. Loan, _Matrix Computations_ . The Johns Hopkins University Press, 1996. 

- [36] S. Boyd and L. Vandenberghe, _Convex Optimization_ . Cambridge University Press, 2004. 

- [37] O. Banerjee, L. E. Ghaoui, A. d’Aspremont, and G. Natsoulis, “Convex optimization techniques for fitting sparse Gaussian graphical models,” in _Proc. of the International Conference on Machine Learning_ , New York, NY, Jun. 25–29, 2006, pp. 89–96. 

- [38] R. A. Horn and C. R. Johnson, _Matrix Analysis_ . Cambridge University Press, 1990. 

- [39] S. Boyd, N. Parikh, E. Chu, B. Peleato, and J. Eckstein, “Distributed optimization and statistical learning via the alternating direction method of multipliers,” _Foundations and Trends in Machine Learning_ , vol. 3, no. 1, pp. 1–122, 2011. 

- [40] R. Tibshirani, “Regression shrinkage and selection via the lasso,” _Journal of the Royal Statistical Society (Series B)_ , vol. 58, no. 1, pp. 267–288, 1996. 

8
