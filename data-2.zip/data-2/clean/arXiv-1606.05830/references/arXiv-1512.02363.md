<!-- fulltext source=arxiv_html slug=arXiv-1512.02363 fetched=2026-09-21T06:17:25+00:00 -->

This paper has been accepted for publication in *IEEE Transactions on Robotics*.

DOI: [10.1109/TRO.2016.2597321](http://dx.doi.org/10.1109/TRO.2016.2597321)

IEEE Explore: <http://ieeexplore.ieee.org/document/7557075/>

Please cite the paper as:

Christian Forster, Luca Carlone, Frank Dellaert, Davide Scaramuzza,

“On-Manifold Preintegration for Real-Time Visual-Inertial Odometry”,

in *IEEE Transactions on Robotics*, 2016.

# On-Manifold Preintegration for Real-Time Visual-Inertial Odometry

Christian Forster
  
Luca Carlone
  
Frank Dellaert
  
Davide Scaramuzza
††thanks: 
C. Forster is with the Robotics and Perception Group, University of Zurich, Switzerland.
E-mail: forster@ifi.uzh.ch
L. Carlone is with the Laboratory for Information & Decision Systems, Massachusetts Institute of Technology, USA.
E-mail: lcarlone@mit.edu
F. Dellaert is with the College of Computing, Georgia Institute of Technology, USA.
E-mail: dellaert@cc.gatech.edu
D. Scaramuzza is with the Robotics and Perception Group, University of Zurich, Switzerland.
E-mail: sdavide@ifi.uzh.ch
This research was partially funded by the Swiss National Foundation (project number 200021-143607, “Swarm of Flying Cameras”), the National Center of Competence in Research Robotics (NCCR), the UZH Forschungskredit, the NSF Award 11115678, and the USDA NIFA Award GEOW-2014-09160.

###### Abstract

Current approaches for visual-inertial odometry (VIO) are able to attain highly accurate
state estimation via nonlinear optimization.
However, real-time optimization quickly becomes infeasible as the trajectory grows over time;
this problem is further emphasized by the fact that inertial measurements come at high rate,
hence leading to fast growth of the number of variables in the optimization.
In this paper, we address this issue by preintegrating inertial measurements between selected keyframes into single relative motion constraints.
Our first contribution is a *preintegration theory* that properly addresses the manifold structure of the rotation group.
We formally discuss the generative measurement model as well as the nature of the rotation noise and derive the expression
for the *maximum a posteriori* state estimator.
Our theoretical development enables the computation of all necessary Jacobians for the optimization and a-posteriori bias correction in analytic form.
The second contribution is to show that the preintegrated IMU model can be seamlessly integrated into a visual-inertial pipeline under the unifying framework of factor graphs.
This enables the application of incremental-smoothing algorithms and the use of a *structureless* model for visual measurements,
which avoids optimizing over the 3D points, further accelerating the computation.
We perform an extensive evaluation of our monocular VIO pipeline on real and simulated datasets.
The results confirm that our modelling effort leads to accurate state estimation in
real-time, outperforming state-of-the-art approaches.

## Supplementary Material

* •

  Video of the experiments: <https://youtu.be/CsJkci5lfco>
* •

  Source-code for preintegrated IMU and structureless vision factors <https://bitbucket.org/gtborg/gtsam>.

## I Introduction

The use of cameras and inertial sensors for three-dimensional structure and motion estimation has
received considerable attention from the robotics community.
Both sensor types are cheap, ubiquitous, and complementary.
A single moving camera is an exteroceptive sensor that allows us to measure appearance and geometry of a three-dimensional scene, up to an unknown metric scale; an inertial measurement unit (IMU) is a proprioceptive sensor that renders metric scale of monocular vision and gravity observable [[1](#bib.bib1)] and provides robust and accurate inter-frame motion estimates.
Applications of VIO range from autonomous navigation in GPS-denied environments, to 3D reconstruction, and augmented reality.

The existing literature on VIO imposes a trade-off between accuracy and computational efficiency
(a detailed review is given in Section [II](#S2 "II Related Work ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
On the one hand, filtering approaches enable fast inference, but their accuracy is deteriorated by
the accumulation of linearization errors.
On the other hand, full smoothing approaches, based on nonlinear optimization, are accurate, but computationally demanding.
Fixed-lag smoothing offers a compromise between accuracy for efficiency; however,
it is not clear how to set the length of the estimation window so to
guarantee a given level of performance.

In this work we show that it is possible to overcome this trade-off. We design a VIO system that
enables fast incremental smoothing and computes the optimal *maximum a posteriori* (MAP) estimate in real time.
An overview of our approach is given in Section [IV](#S4 "IV Maximum a Posteriori Visual-Inertial State Estimation ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").

The first step towards this goal is the development of a novel preintegration theory.
The use of *preintegrated IMU measurements* was first proposed in [[2](#bib.bib2)] and consists of combining many inertial measurements between two keyframes into a single relative motion constraint.
We build upon this work and present a preintegration theory that properly addresses the manifold structure of the rotation group $\mathrm{SO}(3)$.
Our preintegration theory is presented in Sections [V](#S5 "V IMU Model and Motion Integration ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")-[VI](#S6 "VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").
Compared with [[2](#bib.bib2)], our theory offers a more formal treatment of the rotation noise, and avoids singularities in the representation of rotations.
Furthermore, we are able to derive all necessary Jacobians in analytic form: specifically, we report the analytic Jacobians of the residuals, the noise propagation, and the a-posteriori bias correction in the appendix of this paper.

Our second contribution is to frame the IMU preintegration theory into a factor graph model.
This enables the application of incremental smoothing algorithms, as iSAM2 [[3](#bib.bib3)], which avoid the accumulation of linearization errors and offer an elegant way to trade-off accuracy with efficiency.
Inspired by [[4](#bib.bib4), [5](#bib.bib5)], we also adopt a *structureless* model for visual measurements, which allows eliminating a large number of variables (*i.e.*, all 3D points) during incremental smoothing, further accelerating the computation (Section [VII](#S7 "VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
In contrast to [[5](#bib.bib5)], we use the structureless model in an incremental smoothing framework.
This has two main advantages: we do not need to delay the processing of visual measurements, and we can relinearize the visual measurements multiple times.

In order to demonstrate the effectiveness of our model, we integrated the proposed IMU preintegration in a state-of-the-art VIO pipeline and tested it on real and simulated datasets (Sections [VIII](#S8 "VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
Our theoretical development leads to tangible practical advantages: an implementation of the approach proposed in this paper performs full-smoothing at a rate of 100 Hz and achieves superior accuracy with respect to competitive state-of-the-art filtering and optimization approaches.

Besides the technical contribution, the paper also provides a tutorial contribution for practitioners.
In Section [III](#S3 "III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") and across the paper, we provide a short but concise summary of uncertainty representation on manifolds and exemplary derivations for uncertainty propagation and Jacobian computation.
The complete derivation of all equations and Jacobians – necessary to implement
our model – are given in the appendix.

This paper is an extension of our previous work [[6](#bib.bib6)] with additional experiments, an in-depth discussion of related work, and comprehensive technical derivations.
The results of the new experiments highlight the accuracy of bias estimation, demonstrate the consistency of our approach, and provide comparisons against full batch estimation.
We release our implementation of the preintegrated IMU and structureless vision factors in the GTSAM 4.0 optimization toolbox [[7](#bib.bib7)].

## II Related Work

Related work on visual-inertial odometry can be sectioned along three main dimensions.
The first dimension is the number of camera-poses involved in the estimation. While *full smoothers* (or *batch
nonlinear least-squares* algorithms) estimate the complete history of poses,
*fixed-lag smoothers* (or *sliding window estimators*) consider a window of the latest poses,
and *filtering* approaches only estimate the latest state.
Both fixed-lag smoothers and filters marginalize older states and absorb the corresponding information in a Gaussian prior.

The second dimension regards the representation of the uncertainty for the measurements and the Gaussian priors:
the *Extended Kalman Filter* (EKF) represents the uncertainty using a covariance matrix; instead, *information filters* and smoothers resort to the information matrix (the inverse of the covariance) or the square-root of the information matrix [[3](#bib.bib3), [8](#bib.bib8)].

Finally, the third dimension distinguishes existing approaches by looking at the
number of times in which the measurement model is linearized. While a standard EKF (in contrast to the *iterated* EKF) processes a measurement only once, a smoothing approach allows linearizing multiple times.

While the terminology is vast, the underlying algorithms are tightly related. For instance, it can be shown that the iterated Extended Kalman filter equations are equivalent to the Gauss-Newton algorithm, commonly used for smoothing [[9](#bib.bib9)].

### II-A Filtering

Filtering algorithms enable efficient estimation by restricting the inference process to the latest state of the system.
The complexity of the EKF grows quadratically in the number of estimated landmarks, therefore,
a small number of landmarks (in the order of 20) are typically tracked to allow real-time operation [[10](#bib.bib10), [11](#bib.bib11), [12](#bib.bib12)].
An alternative is to adopt a “structureless” approach where landmark positions are marginalized out of the state vector.
An elegant example of this strategy is the *Multi-State Constraint Kalman filter* (MSC-KF) [[5](#bib.bib5)].
The structureless approach requires to keep previous poses in the state vector,
by means of *stochastic cloning* [[13](#bib.bib13)].

A drawback of using a structureless approach for filtering,
is that the processing of landmark measurements needs to be delayed until all measurements of a landmark are obtained [[5](#bib.bib5)].
This hinders accuracy as the filter cannot use all current visual information.
Marginalization is also a source of errors as it locks in linearization errors and erroneous outlier measurements.
Therefore, it is particularly important to filter out spurious measurements as a single
outlier can irreversibly corrupt the filter [[14](#bib.bib14)].
Further, linearization errors introduce drift in the estimate and render the filter *inconsistent*.
An effect of inconsistency is that the estimator becomes over-confident, resulting in non-optimal information fusion.
Generally, the VIO problem has four unobservable directions: the global position and the orientation around the gravity direction (yaw) [[15](#bib.bib15), [16](#bib.bib16)].
In [[16](#bib.bib16)] it is shown that linearization at the wrong estimate results in only three unobservable directions (the global position); hence, erroneous linearization adds spurious information in yaw direction to the Gaussian prior, which renders the filter inconsistent.
This problem was addressed with the *first-estimates jacobian* approach [[17](#bib.bib17)], which ensures that a state is not updated with different linearization points — a source of inconsistency.
In the *observability-constrained* EKF (OC-EKF) an estimate of the unobservable directions is maintained which allows to update the filter only in directions that are observable [[16](#bib.bib16), [18](#bib.bib18)].
A thorough analysis of VIO observability properties is given in [[1](#bib.bib1), [15](#bib.bib15), [19](#bib.bib19)].

### II-B Fixed-lag Smoothing

Fixed-lag smoothers estimate the states that fall within a given time
window, while marginalizing out older states [[20](#bib.bib20), [21](#bib.bib21), [22](#bib.bib22), [23](#bib.bib23), [24](#bib.bib24)].
In a maximum likelihood estimation setup, fixed-lag smoothers lead to an optimization problem over a set of recent states.
For nonlinear problems, smoothing approaches are generally more accurate than filtering, since they relinearize past measurements [[25](#bib.bib25)].
Moreover, these approaches are more resilient to outliers, which can be discarded a posteriori
(i.e., after the optimization), or can be alleviated by using robust cost functions.
On the downside, the marginalization of the states outside the estimation window
leads to dense Gaussian priors
which hinder efficient inference.
For this reason, it has been proposed to drop certain measurements in the interest of sparsity [[24](#bib.bib24)].
Furthermore, due to marginalization,
fixed-lag smoothers share part of the issues of filtering (consistency, build-up of linearization errors) [[26](#bib.bib26), [22](#bib.bib22), [18](#bib.bib18)].

### II-C Full Smoothing

Full smoothing methods estimate the entire history of the states (camera trajectory and 3D landmarks), by solving a large nonlinear optimization problem
[[27](#bib.bib27), [28](#bib.bib28), [29](#bib.bib29), [30](#bib.bib30), [31](#bib.bib31)].
Full smoothing guarantees the highest accuracy;
however, real-time operation quickly becomes infeasible as the trajectory and the map grow over time.
Therefore, it has been proposed to discard frames except selected *keyframes* [[32](#bib.bib32), [33](#bib.bib33), [34](#bib.bib34), [24](#bib.bib24)] or to run the optimization in a parallel thread, using a tracking and mapping dual architecture [[35](#bib.bib35), [20](#bib.bib20)].
A breakthrough has been the development of *incremental smoothing techniques* (iSAM [[36](#bib.bib36)], iSAM2 [[3](#bib.bib3)]),
which leverage the expressiveness of *factor graphs* to maintain sparsity and to identify and update only the typically small subset of variables affected by a new measurement.

Nevertheless, the high rate of inertial measurements (usually 100 Hz to 1 kHz) still constitutes a challenge for smoothing approaches. A naive implementation would require adding a new state at every IMU measurement, which quickly becomes impractically slow [[37](#bib.bib37)].
Therefore, inertial measurements are typically integrated between frames to form relative motion constraints [[38](#bib.bib38), [30](#bib.bib30), [39](#bib.bib39), [40](#bib.bib40), [24](#bib.bib24)].
For standard IMU integration between two frames, the initial condition is given by the state estimate at the first frame.
However, at every iteration of the optimization, the state estimate changes, which requires to repeat the IMU integration between all frames [[24](#bib.bib24)].
Lupton and Sukkarieh [[2](#bib.bib2)] show that this repeated integration can be
avoided by a reparametrization of the relative motion constraints. Such reparametrization is called *IMU preintegration*.

In the present work, we build upon the seminal work [[2](#bib.bib2)] and bring the theory of IMU preintegration to maturity by properly addressing the manifold structure of the rotation group $\mathrm{SO}(3)$.
The work [[2](#bib.bib2)] adopted Euler angles as global parametrization for rotations.
Using Euler angles and applying the usual averaging and smoothing techniques of Euclidean spaces for state propagation and covariance estimation is not properly invariant under the action of rigid transformations [[41](#bib.bib41), [42](#bib.bib42)].
Moreover, Euler angles are known to have singularities.
Our work, on the other hand, provides a formal treatment of the rotation measurements
(and the corresponding noise), and provides a complete derivation of the maximum a posteriori
estimator.
We also derive analytic expressions for the Jacobians (needed for the optimization), which, to the best of our knowledge,
have not been previously reported in the literature.
In the experimental section, we show that a proper representation of the rotation manifold results in higher
accuracy and robustness, leading to tangible advantages over the original proposal [[2](#bib.bib2)].

## III Preliminaries

In this paper we formulate VIO in terms of MAP estimation.
In our model, MAP estimation leads to a nonlinear optimization problem that involves quantities living on smooth manifolds (e.g., rotations, poses).
Therefore, before delving into details, we conveniently review some useful geometric concepts.
This section can be skipped by the expert reader.

We structure this section as follows:
Section [III-A](#S3.SS1 "III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") provides useful notions related to two main Riemannian manifolds: the Special Orthogonal Group $\mathrm{SO}(3)$ and the Special Euclidean Group $\mathrm{SE}(3)$.
Our presentation is based on [[43](#bib.bib43), [44](#bib.bib44)].
Section [III-B](#S3.SS2 "III-B Uncertainty Description in SO(3) ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") describes a suitable model to describe uncertain rotations in $\mathrm{SO}(3)$.
Section [III-C](#S3.SS3 "III-C Gauss-Newton Method on Manifold ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") reviews optimization on manifolds, following standard references [[45](#bib.bib45)].

### III-A Notions of Riemannian geometry

##### Special Orthogonal Group

$\mathrm{SO}(3)$ describes the group of 3D rotation matrices and it is formally defined as
$\mathrm{SO}(3)\doteq\{\mathtt{R}\in\mathbb{R}^{3\times 3}\;{:}\;\mathtt{R}^{\mathsf{T}}\mathtt{R}={\mathbf{I}},\det(\mathtt{R})=1\}$.
The group operation is the usual matrix multiplication, and the inverse is the matrix transpose.
The group $\mathrm{SO}(3)$ also forms a smooth manifold.
The tangent space to the manifold (at the identity) is denoted as $\mathfrak{so}(3)$, which is also called the *Lie algebra* and coincides with the space of $3\times 3$ skew symmetric matrices.
We can identify every skew symmetric matrix with a vector in $\mathbb{R}^{3}$ using the *hat* operator:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\boldsymbol{\omega}^{\wedge}=\begin{bmatrix}\omega\_{1}\\ \omega\_{2}\\ \omega\_{3}\end{bmatrix}^{\wedge}=\begin{bmatrix}0&-\omega\_{3}&\omega\_{2}\\ \omega\_{3}&0&-\omega\_{1}\\ -\omega\_{2}&\omega\_{1}&0\end{bmatrix}\in\mathfrak{so}(3).$ |  | (1) |

Similarly, we can map a skew symmetric matrix to a vector in $\mathbb{R}^{3}$ using the *vee* operator $(\cdot)^{\vee}$:
for a skew symmetric matrix $\mathtt{S}=\boldsymbol{\omega}^{\wedge}$, the vee operator is such that $\mathtt{S}^{\vee}=\boldsymbol{\omega}$.
A property of skew symmetric matrices that will be useful later on is:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{a}^{\wedge}\;\mathbf{b}=-\mathbf{b}^{\wedge}\;\mathbf{a},\quad\forall\;\mathbf{a},\mathbf{b}\in\mathbb{R}^{3}.$ |  | (2) |

The *exponential map* (at the identity) $\exp:\mathfrak{so}(3)\rightarrow\mathrm{SO}(3)$ associates an element of the Lie Algebra to a rotation and coincides with standard matrix exponential (Rodrigues’ formula):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textstyle\exp(\boldsymbol{\phi}^{\wedge})={\mathbf{I}}+\frac{\sin(\|\boldsymbol{\phi}\|)}{\|\boldsymbol{\phi}\|}\boldsymbol{\phi}^{\wedge}+\frac{1-\cos(\|\boldsymbol{\phi}\|)}{\|\boldsymbol{\phi}\|^{2}}\left(\boldsymbol{\phi}^{\wedge}\right)^{2}.$ |  | (3) |

A first-order approximation of the exponential map that we will use later on is:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textstyle\exp(\boldsymbol{\phi}^{\wedge})\approx\mathbf{I}+\boldsymbol{\phi}^{\wedge}\;.$ |  | (4) |

Fig. 1: The right Jacobian $\mathtt{J}\_{r}$ relates an additive perturbation $\delta\boldsymbol{\phi}$ in the tangent space to a multiplicative perturbation on the manifold $\mathrm{SO}(3)$, as per Eq. ([7](#S3.E7 "In Special Orthogonal Group ‣ III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).

The *logarithm map* (at the identity) associates a matrix $\mathtt{R}\neq\mathbf{I}$ in $\mathrm{SO}(3)$ to a skew symmetric matrix:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\log(\mathtt{R})=\frac{\varphi\cdot(\mathtt{R}-\mathtt{R}^{\mathsf{T}})}{2\sin(\varphi)}\text{ with }\varphi=\cos^{-1}\left(\frac{\mathrm{tr}\left(\mathtt{R}\right)-1}{2}\right).$ |  | (5) |

Note that $\log(\mathtt{R})^{\vee}=\mathbf{a}\varphi$, where $\mathbf{a}$ and $\varphi$ are the rotation axis and the rotation angle of $\mathtt{R}$, respectively.
If $\mathtt{R}=\mathbf{I}$, then $\varphi=0$ and $\mathbf{a}$ is undetermined and can therefore be chosen arbitrarily.

The exponential map is a bijection if restricted to the open ball $\|\boldsymbol{\phi}\|<\pi$, and the corresponding inverse is the logarithm map.
However, if we do not restrict the domain, the exponential map becomes surjective as every vector $\boldsymbol{\phi}=(\varphi+2k\pi)\mathbf{a}$, $k\in\mathbb{Z}$ would be an admissible logarithm of $\mathtt{R}$.

For notational convenience, we adopt “vectorized” versions of the exponential and logarithm map:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{array}[]{cccccccc}\mathrm{Exp}:&\mathbb{R}^{3}&\rightarrow&\mathrm{SO}(3)&;&\boldsymbol{\phi}&\mapsto&\exp(\boldsymbol{\phi}^{\wedge})\\ \mathrm{Log}:&\mathrm{SO}(3)&\rightarrow&\mathbb{R}^{3}&;&\mathtt{R}&\mapsto&\log(\mathtt{R})^{\vee},\end{array}$ |  | (6) |

which operate directly on vectors, rather than on skew symmetric matrices in $\mathfrak{so}(3)$.

Later, we will use the following first-order approximation:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathrm{Exp}(\boldsymbol{\phi}+\delta\boldsymbol{\phi})\approx\mathrm{Exp}(\boldsymbol{\phi})\;\mathrm{Exp}(\mathtt{J}\_{r}(\boldsymbol{\phi})\delta\boldsymbol{\phi}).$ |  | (7) |

The term $\mathtt{J}\_{r}(\boldsymbol{\phi})$ is the *right Jacobian* of $\mathrm{SO}(3)$ [[43](#bib.bib43), p.40] and relates additive increments in the tangent space to multiplicative increments applied on the right-hand-side (Fig.  [1](#S3.F1 "Fig. 1 ‣ Special Orthogonal Group ‣ III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textstyle\mathtt{J}\_{r}(\boldsymbol{\phi})=\mathbf{I}-\frac{1-\cos(\|\boldsymbol{\phi}\|)}{\|\boldsymbol{\phi}\|^{2}}\boldsymbol{\phi}^{\wedge}+\frac{\|\boldsymbol{\phi}\|-\sin(\|\boldsymbol{\phi}\|)}{\|\boldsymbol{\phi}^{3}\|}(\boldsymbol{\phi}^{\wedge})^{2}.\;$ |  | (8) |

A similar first-order approximation holds for the logarithm:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathrm{Log}\big(\;\mathrm{Exp}(\boldsymbol{\phi})\;\mathrm{Exp}(\delta\boldsymbol{\phi})\;\big)\approx\boldsymbol{\phi}+\mathtt{J}\_{r}^{-1}(\boldsymbol{\phi})\delta\boldsymbol{\phi}.$ |  | (9) |

Where the inverse of the right Jacobian is

|  |  |  |
| --- | --- | --- |
|  | $\mathtt{J}\_{r}^{-1}(\boldsymbol{\phi})=\mathbf{I}+\frac{1}{2}\boldsymbol{\phi}^{\wedge}+\left(\frac{1}{\|\boldsymbol{\phi}\|^{2}}+\frac{1+\cos(\|\boldsymbol{\phi}\|)}{2\|\boldsymbol{\phi}\|\sin(\|\boldsymbol{\phi}\|)}\right)(\boldsymbol{\phi}^{\wedge})^{2}.\;$ |  |

The right Jacobian $\mathtt{J}\_{r}(\boldsymbol{\phi})$ and its inverse $\mathtt{J}\_{r}^{-1}(\boldsymbol{\phi})$ reduce to the identity matrix for $\|\boldsymbol{\phi}\|\!=\!0$.

Another useful property of the exponential map is:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathtt{R}\ \mathrm{Exp}(\boldsymbol{\phi})\ \mathtt{R}^{\mathsf{T}}$ | $\displaystyle=\exp(\mathtt{R}\boldsymbol{\phi}^{\wedge}\mathtt{R}^{\mathsf{T}})=\mathrm{Exp}(\mathtt{R}\boldsymbol{\phi})$ |  | (10) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Leftrightarrow\quad\mathrm{Exp}(\boldsymbol{\phi})\ \mathtt{R}$ | $\displaystyle=\mathtt{R}\ \mathrm{Exp}(\mathtt{R}^{\mathsf{T}}\boldsymbol{\phi}).$ |  | (11) |

##### Special Euclidean Group

$\mathrm{SE}(3)$ describes the group of rigid motion in 3D, which is the semi-direct product of $\mathrm{SO}(3)$ and $\mathbb{R}^{3}$, and it is defined as $\mathrm{SE}(3)\doteq\{(\mathtt{R},\mathbf{p})\;{:}\;\mathtt{R}\in\mathrm{SO}(3),\mathbf{p}\in\mathbb{R}^{3}\}$.
Given $\mathtt{T}\_{1},\mathtt{T}\_{2}\in\mathrm{SE}(3)$, the group operation is
$\mathtt{T}\_{1}\cdot\mathtt{T}\_{2}=(\mathtt{R}\_{1}\mathtt{R}\_{2}\;,\;\mathbf{p}\_{1}+\mathtt{R}\_{1}\mathbf{p}\_{2})$,
and the inverse is
$\mathtt{T}\_{1}^{-1}=(\mathtt{R}\_{1}^{\mathsf{T}}\;,\;-\mathtt{R}\_{1}^{\mathsf{T}}\mathbf{p}\_{1})$.
The *exponential map* and the *logarithm map* for $\mathrm{SE}(3)$ are defined in [[44](#bib.bib44)].
However, these are not needed in this paper for reasons that will be clear in Section [III-C](#S3.SS3 "III-C Gauss-Newton Method on Manifold ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").

### III-B Uncertainty Description in $\mathrm{SO}(3)$

A natural definition of uncertainty in $\mathrm{SO}(3)$ is to define a distribution in the tangent space, and then map it to $\mathrm{SO}(3)$ via the exponential map ([6](#S3.E6 "In Special Orthogonal Group ‣ III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) [[46](#bib.bib46), [47](#bib.bib47), [44](#bib.bib44)]:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\tilde{\mathtt{R}}=\mathtt{R}\;\mathrm{Exp}(\epsilon),\qquad\epsilon\sim{\cal N}(0,\Sigma),$ |  | (12) |

where $\mathtt{R}$ is a given noise-free rotation (the *mean*) and $\epsilon$ is a small normally distributed perturbation with zero mean and covariance $\Sigma$.

To obtain an explicit expression for the distribution of $\tilde{\mathtt{R}}$, we start from the integral of the Gaussian distribution in $\mathbb{R}^{3}$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\int\_{\mathbb{R}^{3}}p(\epsilon)d\epsilon=\int\_{\mathbb{R}^{3}}\alpha e^{-\frac{1}{2}\left\|\epsilon\right\|^{2}\_{\Sigma}}\text{d}\epsilon=1,$ |  | (13) |

where $\alpha=1/\sqrt{(2\pi)^{3}\det(\Sigma)}$ and $\left\|\epsilon\right\|^{2}\_{\Sigma}\doteq\epsilon^{\mathsf{T}}\Sigma^{-1}\epsilon$ is the squared Mahalanobis distance with covariance $\Sigma$.
Then, applying the change of coordinates $\epsilon=\mathrm{Log}(\mathtt{R}^{-1}\tilde{\mathtt{R}})$ (this is the inverse of ([12](#S3.E12 "In III-B Uncertainty Description in SO(3) ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) when $\|\epsilon\|<\pi$), the integral ([13](#S3.E13 "In III-B Uncertainty Description in SO(3) ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) becomes:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\int\_{\mathrm{SO}(3)}\beta(\tilde{\mathtt{R}})\;e^{-\frac{1}{2}\left\|\mathrm{Log}(\mathtt{R}^{-1}\tilde{\mathtt{R}})\right\|^{2}\_{\Sigma}}\;\text{d}\tilde{\mathtt{R}}=1,$ |  | (14) |

where $\beta(\tilde{\mathtt{R}})$ is a normalization factor.
The normalization factor assumes the form $\beta(\tilde{\mathtt{R}})=\alpha/|\det({\cal J}(\tilde{\mathtt{R}})|$, where ${\cal J}(\tilde{\mathtt{R}})\doteq\mathtt{J}\_{r}(\mathrm{Log}(\mathtt{R}^{-1}\tilde{\mathtt{R}}))$ and $\mathtt{J}\_{r}(\cdot)$ is the right Jacobian ([8](#S3.E8 "In Special Orthogonal Group ‣ III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")); ${\cal J}(\tilde{\mathtt{R}})$ is a by-product of the change of variables, see [[46](#bib.bib46)] for a derivation.

From the argument of ([14](#S3.E14 "In III-B Uncertainty Description in SO(3) ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) we can directly read our “Gaussian” distribution in $\mathrm{SO}(3)$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $p(\tilde{\mathtt{R}})=\beta(\tilde{\mathtt{R}})\;e^{-\frac{1}{2}\left\|\mathrm{Log}(\mathtt{R}^{-1}\tilde{\mathtt{R}})\right\|^{2}\_{\Sigma}}.$ |  | (15) |

For small covariances we can approximate $\beta\simeq\alpha$, as $\mathtt{J}\_{r}(\mathrm{Log}(\mathtt{R}^{-1}\tilde{\mathtt{R}}))$ is well approximated by the identity matrix when $\tilde{\mathtt{R}}$ is close to $\mathtt{R}$. Note that ([14](#S3.E14 "In III-B Uncertainty Description in SO(3) ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) already assumes relatively a small covariance $\Sigma$, since it “clips” the probability tails outside the open ball of radius $\pi$ (this is due to the re-parametrization $\epsilon=\mathrm{Log}(\mathtt{R}^{-1}\tilde{\mathtt{R}})$, which restricts $\epsilon$
to $\|\epsilon\|<\pi$).
Approximating $\beta$ as a constant, the negative log-likelihood of a rotation $\mathtt{R}$, given a measurement $\tilde{\mathtt{R}}$ distributed as in ([15](#S3.E15 "In III-B Uncertainty Description in SO(3) ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), is:

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal L}(\mathtt{R})=\frac{1}{2}\left\|\mathrm{Log}(\mathtt{R}^{-1}\tilde{\mathtt{R}})\right\|^{2}\_{\Sigma}+\text{const}=\frac{1}{2}\left\|\mathrm{Log}(\tilde{\mathtt{R}}^{-1}\mathtt{R})\right\|^{2}\_{\Sigma}+\text{const},$ |  | (16) |

which geometrically can be interpreted as the squared angle (geodesic distance in $\mathrm{SO}(3)$) between $\tilde{\mathtt{R}}$ and $\mathtt{R}$ weighted by the inverse uncertainty $\Sigma^{-1}$.

### III-C Gauss-Newton Method on Manifold

A standard Gauss-Newton method in Euclidean space works by repeatedly optimizing a quadratic approximation of the (generally non-convex) objective function.
Solving the quadratic approximation reduces to solving a set of linear equations (*normal equations*), and the solution of this local approximation is used to update the current estimate.
Here we recall how to extend this approach to (unconstrained) optimization problems whose variables belong to some manifold ${\cal M}$.

Let us consider the following optimization problem:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\min\_{x\in{\cal M}}f(x),$ |  | (17) |

where the variable $x$ belongs to a manifold ${\cal M}$; for the sake of simplicity we consider a single variable in ([17](#S3.E17 "In III-C Gauss-Newton Method on Manifold ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), while the description easily generalizes to multiple variables.

Contrarily to the Euclidean case, one cannot directly approximate ([17](#S3.E17 "In III-C Gauss-Newton Method on Manifold ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) as a quadratic function of $x$. This is due to two main reasons.
First, working directly on $x$ leads to an over-parametrization of the problem (e.g., we parametrize a rotation matrix with 9 elements, while a 3D rotation is completely defined by a vector in $\mathbb{R}^{3}$)
and this can make the *normal equations* under-determined.
Second, the solution of the resulting approximation does not belong to ${\cal M}$ in general.

A standard approach for optimization on manifold [[45](#bib.bib45), [48](#bib.bib48)], consists of defining a *retraction* ${\cal R}\_{x}$, which is a bijective map between an element $\delta x$ of the tangent space (at $x$) and a neighborhood of $x\in{\cal M}$.
Using the retraction, we can re-parametrize our problem as follows:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\min\_{x\in{\cal M}}f(x)\quad\Rightarrow\quad\min\_{\delta x\in\mathbb{R}^{n}}f({\cal R}\_{x}(\delta x)).$ |  | (18) |

The re-parametrization is usually called *lifting* [[45](#bib.bib45)].
Roughly speaking, we work in the tangent space defined at the current estimate, which locally behaves as an Euclidean space.
The use of the retraction allows framing the optimization problem over an Euclidean space
of suitable dimension (e.g., $\delta x\in\mathbb{R}^{3}$ when we work in $\mathrm{SO}(3)$).
We can now apply standard optimization techniques to the problem on the right-hand side of ([18](#S3.E18 "In III-C Gauss-Newton Method on Manifold ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
In the Gauss-Newton framework, we square the cost around the current estimate.
Then we solve the quadratic approximation to get a vector $\delta x^{\star}$ in the tangent space.
Finally, the current guess on the manifold is updated as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{x}\leftarrow{\cal R}\_{\hat{x}}(\delta x^{\star}).$ |  | (19) |

This “lift-solve-retract” scheme can be generalized to any trust-region method [[45](#bib.bib45)].
Moreover, it provides a grounded and unifying generalization of the *error state model*, commonly used in aerospace literature for filtering [[49](#bib.bib49)] and recently adopted in robotics for optimization [[23](#bib.bib23), [34](#bib.bib34)].

We conclude this section by discussing the choice of the retraction ${\cal R}\_{x}$.
A possible retraction is the exponential map.
It is known that, computationally, this may not be the most convenient choice, see [[50](#bib.bib50)].

In this work, we use the following retraction for $\mathrm{SO}(3)$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal R}\_{\mathtt{R}}(\boldsymbol{\phi})=\mathtt{R}\;\mathrm{Exp}(\delta\boldsymbol{\phi}),\qquad\delta\boldsymbol{\phi}\in\mathbb{R}^{3},$ |  | (20) |

and for $\mathrm{SE}(3)$, we use the retraction at $\mathtt{T}\doteq(\mathtt{R},\mathbf{p})$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal R}\_{\mathtt{T}}(\delta\boldsymbol{\phi},\delta\mathbf{p})=(\mathtt{R}\;\mathrm{Exp}(\delta\boldsymbol{\phi}),\ \mathbf{p}+\mathtt{R}\;\delta\mathbf{p}),\qquad\left[\delta\boldsymbol{\phi}\ \ \delta\mathbf{p}\right]\in\mathbb{R}^{6},$ |  | (21) |

which explains why in Section [III-A](#S3.SS1 "III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") we only defined the exponential map for $\mathrm{SO}(3)$:
with this choice of retraction we never need to compute the exponential map for $\mathrm{SE}(3)$.

## IV Maximum a Posteriori Visual-Inertial State Estimation

We consider a VIO problem in which we want to track the state of a *sensing system* (e.g., a mobile robot, a UAV, or a hand-held device),
equipped with an IMU and a monocular camera.
We assume that the IMU frame “B” coincides with the body frame we want to track, and that the transformation between the camera and the IMU is fixed and known from prior calibration (Fig. [2](#S4.F2 "Fig. 2 ‣ IV Maximum a Posteriori Visual-Inertial State Estimation ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
Furthermore, we assume that a *front-end* provides image measurements of 3D landmarks at unknown position.
The front-end also selects a subset of images, called *keyframes* [[32](#bib.bib32)], for which we want to compute a pose estimate. Section [VIII-B1](#S8.SS2.SSS1 "VIII-B1 Implementation ‣ VIII-B Real Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") discusses implementation aspects, including the choice of the front-end in our experiments.

Fig. 2: 
$\mathtt{T}\_{\text{\tiny{W}}\text{\tiny{B}}}\doteq(\mathtt{R}\_{\text{\tiny{W}}\text{\tiny{B}}},{}\_{\text{\tiny{W}}}\mathbf{p})$ is the pose of the
body frame B w.r.t. the world frame W. We assume that the body frame coincides with the
IMU frame. $\mathtt{T}\_{\text{\tiny{B}}\text{\tiny{C}}}$ is the pose of the camera in the body frame, known from prior calibration.

### IV-A The State

The state of the system at time $i$ is described by the IMU orientation, position, velocity and biases:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{x}\_{i}\doteq[\mathtt{R}\_{i},\mathbf{p}\_{i},\mathbf{v}\_{i},\mathbf{b}\_{i}].$ |  | (22) |

The pose $(\mathtt{R}\_{i},\mathbf{p}\_{i})$ belongs to $\mathrm{SE}(3)$, while velocities live in a vector space, i.e., $\mathbf{v}\_{i}\in\mathbb{R}^{3}$.
IMU biases can be written as $\mathbf{b}\_{i}=[\mathbf{b}^{g}\_{i}\;\;\mathbf{b}^{a}\_{i}]\in\mathbb{R}^{6}$, where $\mathbf{b}^{g}\_{i},\mathbf{b}^{a}\_{i}\in\mathbb{R}^{3}$ are the gyroscope and accelerometer bias, respectively.

Let $\mathcal{K}\_{k}$ denote the set of all keyframes up to time $k$.
In our approach we estimate the state of all keyframes:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{X}\_{k}\doteq\{\mathbf{x}\_{i}\}\_{i\in\mathcal{K}\_{k}}.$ |  | (23) |

In our implementation, we adopt a structureless approach (*cf.*, Section [VII](#S7 "VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), hence the 3D landmarks are not part of the variables to be estimated.
However, the proposed approach generalizes in a straightforward manner to also estimating the landmarks and the camera intrinsic and extrinsic calibration parameters.

### IV-B The Measurements

The input to our estimation problem are the measurements from the camera and the IMU.
We denote with $\mathcal{C}\_{i}$ the image measurements at keyframe $i$.
At time $i$, the camera can observe multiple landmarks $l$, hence $\mathcal{C}\_{i}$ contains multiple image measurements $\mathbf{z}\_{il}$.
With slight abuse of notation we write $l\in\mathcal{C}\_{i}$ when a landmark $l$ is seen at time $i$.

We denote with $\mathcal{I}\_{ij}$ the set of IMU measurements acquired between two consecutive keyframes $i$ and $j$.
Depending on the IMU measurement rate and the frequency of selected keyframes, each set $\mathcal{I}\_{ij}$ can contain from a small number to hundreds of IMU measurements.
The set of measurements collected up to time $k$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{Z}\_{k}\doteq\{\mathcal{C}\_{i},\mathcal{I}\_{ij}\}\_{(i,j)\in\mathcal{K}\_{k}}.$ |  | (24) |

### IV-C Factor Graphs and MAP Estimation

The posterior probability of the variables $\mathcal{X}\_{k}$, given the available visual and inertial measurements $\mathcal{Z}\_{k}$ and priors $p(\mathcal{X}\_{0})$ is:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle p(\mathcal{X}\_{k}|$ | $\displaystyle\mathcal{Z}\_{k})\propto\ p(\mathcal{X}\_{0})p(\mathcal{Z}\_{k}|\mathcal{X}\_{k})\overset{(a)}{=}p(\mathcal{X}\_{0})\!\!\!\prod\_{(i,j)\in\mathcal{K}\_{k}}\!\!\!p(\mathcal{C}\_{i},\mathcal{I}\_{ij}|\mathcal{X}\_{k})$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\overset{(b)}{=}$ | $\displaystyle\ p(\mathcal{X}\_{0})\!\!\!\!\prod\_{(i,j)\in\mathcal{K}\_{k}}\!\!\!\!p(\mathcal{I}\_{ij}|\mathbf{x}\_{i},\mathbf{x}\_{j})\;\prod\_{i\in\mathcal{K}\_{k}}\prod\_{l\in\mathcal{C}\_{i}}p(\mathbf{z}\_{il}|\mathbf{x}\_{i}).$ |  | (25) |

The factorizations (a) and (b) follow from a standard independence assumption among the measurements. Furthermore, the Markovian property is applied in (b) (e.g., an image measurement at time $i$ only depends on the state at time $i$).

As the measurements $\mathcal{Z}\_{k}$ are known, we are free to eliminate them as variables and consider them as parameters of the joint probability factors over the actual unknowns.
This naturally leads to the well known factor graph representation, a class of bipartite graphical models that can be used to represent such factored densities [[51](#bib.bib51), [52](#bib.bib52)].
A schematic representation of the connectivity of the factor graph underlying the VIO problem is given in Fig.  [3](#S4.F3 "Fig. 3 ‣ IV-C Factor Graphs and MAP Estimation ‣ IV Maximum a Posteriori Visual-Inertial State Estimation ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") (the connectivity of the structureless vision factors will be clarified in Section [VII](#S7 "VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
The factor graph is composed of nodes for unknowns and nodes for the probability factors defined on them, and the graph structure expresses which unknowns are involved in each factor.

The MAP estimate $\mathcal{X}\_{k}^{\star}$ corresponds to the maximum of ([25](#S4.Ex2 "In IV-C Factor Graphs and MAP Estimation ‣ IV Maximum a Posteriori Visual-Inertial State Estimation ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), or equivalently, the minimum of the negative log-posterior.
Under the assumption of zero-mean Gaussian noise, the negative log-posterior can be written as a sum of squared residual errors:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\mathcal{X}\_{k}^{\star}\doteq\arg\min\_{\mathcal{X}\_{k}}\;-\log\_{e}\;p(\mathcal{X}\_{k}|\mathcal{Z}\_{k})$ |  | (26) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\arg\min\_{\mathcal{X}\_{k}}\;\|\mathbf{r}\_{0}\|^{2}\_{\mathbf{\Sigma}\_{0}}\!\!\!+\sum\_{(i,j)\in\mathcal{K}\_{k}}\|\mathbf{r}\_{\mathcal{I}\_{ij}}\|^{2}\_{\mathbf{\Sigma}\_{ij}}+\sum\_{i\in\mathcal{K}\_{k}}\sum\_{l\in\mathcal{C}\_{i}}\|\mathbf{r}\_{\mathcal{C}\_{il}}\|^{2}\_{\mathbf{\Sigma}\_{\mathcal{C}}}$ |  |

where $\mathbf{r}\_{0}$, $\mathbf{r}\_{\mathcal{I}\_{ij}}$, $\mathbf{r}\_{\mathcal{C}\_{il}}$ are the residual errors associated to the measurements, and
$\mathbf{\Sigma}\_{0}$, $\mathbf{\Sigma}\_{ij}$, and $\mathbf{\Sigma}\_{\mathcal{C}}$ are the corresponding covariance matrices.
Roughly speaking, the residual error is a function of $\mathcal{X}\_{k}$ that quantifies the mismatch between a measured quantity and the predicted value of this quantity given the state $\mathcal{X}\_{k}$ and the priors.
The goal of the following sections is to provide expressions for the residual errors and the covariances.

Fig. 3: Left: visual and inertial measurements in VIO. Right: factor graph
in which several IMU measurements are summarized in a single preintegrated
IMU factor and a structureless vision factor constraints keyframes observing the same landmark.

## V IMU Model and Motion Integration

An IMU commonly includes a 3-axis accelerometer and a 3-axis gyroscope and allows measuring the rotation rate and the acceleration of the sensor with respect to an inertial frame.
The measurements, namely ${}\_{\text{\tiny{B}}}\tilde{\mathbf{a}}(t)$, and ${}\_{\text{\tiny{B}}}\tilde{\boldsymbol{\omega}}\_{\text{\tiny{W}}\text{\tiny{B}}}(t)$, are affected by additive white noise $\boldsymbol{\eta}$ and a slowly varying sensor bias $\mathbf{b}$:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle{}\_{\text{\tiny{B}}}\tilde{\boldsymbol{\omega}}\_{\text{\tiny{W}}\text{\tiny{B}}}(t)$ | $\displaystyle={}\_{\text{\tiny{B}}}\boldsymbol{\omega}\_{\text{\tiny{W}}\text{\tiny{B}}}(t)+\mathbf{b}^{g}(t)+\boldsymbol{\eta}^{g}(t)$ |  | (27) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle{}\_{\text{\tiny{B}}}\tilde{\mathbf{a}}(t)$ | $\displaystyle=\mathtt{R}\_{\text{\tiny{W}}\text{\tiny{B}}}^{\mathsf{T}}(t)\left({}\_{\text{\tiny{W}}}\mathbf{a}(t)-{}\_{\text{\tiny{W}}}\mathbf{g}\right)+\mathbf{b}^{a}(t)+\boldsymbol{\eta}^{a}(t),$ |  | (28) |

In our notation, the prefix B denotes that the corresponding quantity is expressed in the frame B (*c.f.,* Fig. [2](#S4.F2 "Fig. 2 ‣ IV Maximum a Posteriori Visual-Inertial State Estimation ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
The pose of the IMU is described by the transformation $\{\mathtt{R}\_{\text{\tiny{W}}\text{\tiny{B}}},{}\_{\text{\tiny{W}}}\mathbf{p}\}$, which maps a point from sensor frame B to W.
The vector ${}\_{\text{\tiny{B}}}\boldsymbol{\omega}\_{\text{\tiny{W}}\text{\tiny{B}}}(t)\!\in\!\mathbb{R}^{3}$ is the instantaneous angular velocity of B relative to W expressed in coordinate frame B, while ${}\_{\text{\tiny{W}}}\mathbf{a}(t)\!\in\!\mathbb{R}^{3}$ is the acceleration of the sensor; ${}\_{\text{\tiny{W}}}\mathbf{g}$ is the gravity vector in world coordinates. We neglect effects due to earth’s rotation, which amounts
to assuming that W is an inertial frame.

The goal now is to infer the motion of the system from IMU measurements.
For this purpose we introduce the following kinematic model [[53](#bib.bib53), [49](#bib.bib49)]:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\dot{\mathtt{R}}\_{\text{\tiny{W}}\text{\tiny{B}}}=\mathtt{R}\_{\text{\tiny{W}}\text{\tiny{B}}}\ {}\_{\text{\tiny{B}}}\boldsymbol{\omega}\_{\text{\tiny{W}}\text{\tiny{B}}}^{\wedge},\qquad{}\_{\text{\tiny{W}}}\dot{\mathbf{v}}={}\_{\text{\tiny{W}}}\mathbf{a},\qquad{}\_{\text{\tiny{W}}}\dot{\mathbf{p}}={}\_{\text{\tiny{W}}}\mathbf{v},$ |  | (29) |

which describes the evolution of the pose and velocity of B.

The state at time $t+\Delta t$ is obtained by integrating Eq. ([29](#S5.E29 "In V IMU Model and Motion Integration ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathtt{R}\_{\text{\tiny{W}}\text{\tiny{B}}}(t+\Delta t)$ | $\displaystyle=\mathtt{R}\_{\text{\tiny{W}}\text{\tiny{B}}}(t)\;\mathrm{Exp}\left(\int\_{t}^{t+\Delta t}\!\!\!\!{}\_{\text{\tiny{B}}}\boldsymbol{\omega}\_{\text{\tiny{W}}\text{\tiny{B}}}(\tau)d\tau\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle{}\_{\text{\tiny{W}}}\mathbf{v}(t+\Delta t)$ | $\displaystyle={}\_{\text{\tiny{W}}}\mathbf{v}(t)+\int\_{t}^{t+\Delta t}\!\!\!\!{}\_{\text{\tiny{W}}}\mathbf{a}(\tau)d\tau$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle{}\_{\text{\tiny{W}}}\mathbf{p}(t+\Delta t)$ | $\displaystyle={}\_{\text{\tiny{W}}}\mathbf{p}(t)+\int\_{t}^{t+\Delta t}\!\!\!\!{}\_{\text{\tiny{W}}}\mathbf{v}(\tau)d\tau+\iint\_{t}^{t+\Delta t}{}\_{\text{\tiny{W}}}\mathbf{a}(\tau)d\tau^{2}.$ |  |

Assuming that ${}\_{\text{\tiny{W}}}\mathbf{a}$ and ${}\_{\text{\tiny{B}}}\boldsymbol{\omega}\_{\text{\tiny{W}}\text{\tiny{B}}}$ remain constant in the time interval $[t,t+\Delta t]$, we can write:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathtt{R}\_{\text{\tiny{W}}\text{\tiny{B}}}(t+\Delta t)$ | $\displaystyle=\mathtt{R}\_{\text{\tiny{W}}\text{\tiny{B}}}(t)\;\mathrm{Exp}\left({}\_{\text{\tiny{B}}}\boldsymbol{\omega}\_{\text{\tiny{W}}\text{\tiny{B}}}(t)\Delta t\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle{}\_{\text{\tiny{W}}}\mathbf{v}(t+\Delta t)$ | $\displaystyle={}\_{\text{\tiny{W}}}\mathbf{v}(t)+{}\_{\text{\tiny{W}}}\mathbf{a}(t)\Delta t$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle{}\_{\text{\tiny{W}}}\mathbf{p}(t+\Delta t)$ | $\displaystyle={}\_{\text{\tiny{W}}}\mathbf{p}(t)+{}\_{\text{\tiny{W}}}\mathbf{v}(t)\Delta t+\frac{1}{2}{}\_{\text{\tiny{W}}}\mathbf{a}(t)\Delta t^{2}.$ |  | (30) |

Using Eqs. ([27](#S5.E27 "In V IMU Model and Motion Integration ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"))–([28](#S5.E28 "In V IMU Model and Motion Integration ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), we can write ${}\_{\text{\tiny{W}}}\mathbf{a}$ and ${}\_{\text{\tiny{B}}}\boldsymbol{\omega}\_{\text{\tiny{W}}\text{\tiny{B}}}$ as a function of the IMU measurements, hence ([30](#S5.Ex7 "In V IMU Model and Motion Integration ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) becomes

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathtt{R}(t+\Delta t)$ | $\displaystyle=\ \mathtt{R}(t)\ \mathrm{Exp}\left(\left(\tilde{\boldsymbol{\omega}}(t)-\mathbf{b}^{g}(t)-\boldsymbol{\eta}^{gd}(t)\right)\Delta t\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{v}(t+\Delta t)$ | $\displaystyle=\ \mathbf{v}(t)+\mathbf{g}\Delta t+\mathtt{R}(t)\left(\tilde{\mathbf{a}}(t)\!-\!\mathbf{b}^{a}(t)\!-\!\boldsymbol{\eta}^{ad}(t)\right)\Delta t$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{p}(t+\Delta t)$ | $\displaystyle=\ \mathbf{p}(t)+\mathbf{v}(t)\Delta t+\frac{1}{2}\mathbf{g}\Delta t^{2}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle+\frac{1}{2}\mathtt{R}(t)\left(\tilde{\mathbf{a}}(t)\!-\!\mathbf{b}^{a}(t)\!-\!\boldsymbol{\eta}^{ad}(t)\right)\Delta t^{2},$ |  | (31) |

where we dropped the coordinate frame subscripts for readability (the notation should be unambiguous from now on).
This numeric integration of the velocity and position assumes a constant orientation $\mathtt{R}(t)$ for the time of integration between two measurements, which is not an exact solution of the differential equation ([29](#S5.E29 "In V IMU Model and Motion Integration ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) for measurements with non-zero rotation rate. In practice,
the use of a high-rate IMU mitigates the effects of this approximation.
We adopt the integration scheme ([31](#S5.Ex9 "In V IMU Model and Motion Integration ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) as it is simple and amenable for modeling and uncertainty propagation.
While we show that this integration scheme performs very well in practice, we remark that for slower IMU measurement rates one may consider using
higher-order numerical integration methods [[54](#bib.bib54), [55](#bib.bib55), [56](#bib.bib56), [57](#bib.bib57)].

The covariance of the discrete-time noise $\boldsymbol{\eta}^{gd}$ is a function of the sampling rate and relates to the continuous-time spectral noise $\boldsymbol{\eta}^{g}$ via
$\text{Cov}(\boldsymbol{\eta}^{gd}(t))=\frac{1}{\Delta t}\text{Cov}(\boldsymbol{\eta}^{g}(t))$.
The same relation holds for $\boldsymbol{\eta}^{ad}$ (*cf.*, [[58](#bib.bib58), Appendix]).

## VI IMU Preintegration on Manifold

Fig. 4: Different rates for IMU and camera.

While Eq. ([31](#S5.Ex9 "In V IMU Model and Motion Integration ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) could be readily seen as a probabilistic constraint in a factor graph, it would require to include states in the factor graph at high rate.
Intuitively, Eq. ([31](#S5.Ex9 "In V IMU Model and Motion Integration ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) relates states at time $t$ and $t+\Delta t$, where $\Delta t$
is the sampling period of the IMU, hence we would have to add new states in the estimation at every new IMU measurement [[37](#bib.bib37)].

Here we show that all measurements between two keyframes at times $k=i$ and $k=j$ (see Fig.  [4](#S6.F4 "Fig. 4 ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) can be summarized in a single compound measurement, named *preintegrated IMU measurement*, which constrains the motion between consecutive keyframes.
This concept was first proposed in [[2](#bib.bib2)] using Euler angles and we extend it, by developing a suitable theory for preintegration on the manifold $\mathrm{SO}(3)$.

We assume that the IMU is synchronized with the camera and provides measurements at discrete times $k$ (*cf.*, Fig.  [4](#S6.F4 "Fig. 4 ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).11
1
We calibrate the IMU-camera delay using the *Kalibr* toolbox [[59](#bib.bib59)]. An alternative is to add the delay as a state in the estimation process [[60](#bib.bib60)].
Iterating the IMU integration ([31](#S5.Ex9 "In V IMU Model and Motion Integration ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) for all $\Delta t$ intervals between two consecutive keyframes at times $k=i$ and $k=j$ (*c.f.*, Fig. [4](#S6.F4 "Fig. 4 ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), we find:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathtt{R}\_{j}=$ | $\displaystyle\ \mathtt{R}\_{i}\prod\_{k=i}^{j-1}\mathrm{Exp}\left(\left(\tilde{\boldsymbol{\omega}}\_{k}-\mathbf{b}^{g}\_{k}-\boldsymbol{\eta}^{gd}\_{k}\right)\Delta t\right),$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbf{v}\_{j}=$ | $\displaystyle\ \!\mathbf{v}\_{i}\!+\mathbf{g}\Delta t\_{ij}+\sum\_{k=i}^{j-1}\mathtt{R}\_{k}\Big(\tilde{\mathbf{a}}\_{k}-\mathbf{b}^{a}\_{k}-\boldsymbol{\eta}^{ad}\_{k}\Big)\Delta t$ |  | (32) |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{p}\_{j}=$ | $\displaystyle\ \!\mathbf{p}\_{i}\!+\sum\_{k=i}^{j-1}\Big[\mathbf{v}\_{k}\Delta t+\frac{1}{2}\mathbf{g}\Delta t^{2}+\frac{1}{2}\mathtt{R}\_{k}\Big(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{k}\!-\!\boldsymbol{\eta}^{ad}\_{k}\Big)\Delta t^{2}\Big]$ |  |

where we introduced the shorthands $\Delta t\_{ij}\doteq\sum\_{k=i}^{j-1}\Delta t$ and $(\cdot)\_{i}\doteq(\cdot)(t\_{i})$ for readability.
While Eq. ([32](#S6.Ex12 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) already provides an estimate of the motion between time $t\_{i}$ and $t\_{j}$, it has the drawback that the integration in ([32](#S6.Ex12 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) has to be repeated whenever the linearization point at time $t\_{i}$ changes [[24](#bib.bib24)] (intuitively, a change in the rotation $\mathtt{R}\_{i}$ implies a change in all future rotations $\mathtt{R}\_{k}$, $k=i,\ldots,j-1$, and makes necessary to re-evaluate summations and products in ([32](#S6.Ex12 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"))).

We want to avoid to recompute the above integration whenever the linearization point at time $t\_{i}$ changes.
Therefore, we follow [[2](#bib.bib2)] and *define* the following relative motion increments that are independent of the pose and velocity at $t\_{i}$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta\mathtt{R}\_{ij}$ | $\displaystyle\doteq\mathtt{R}\_{i}^{\mathsf{T}}\mathtt{R}\_{j}=\prod\_{k=i}^{j-1}\mathrm{Exp}\left(\left(\tilde{\boldsymbol{\omega}}\_{k}-\mathbf{b}^{g}\_{k}-\boldsymbol{\eta}^{gd}\_{k}\right)\Delta t\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta\mathbf{v}\_{ij}$ | $\displaystyle\doteq\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{v}\_{j}\!-\!\mathbf{v}\_{i}\!-\!\mathbf{g}\Delta t\_{ij}\right)\!=\!\sum\_{k=i}^{j-1}\Delta\mathtt{R}\_{ik}\!\left(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{k}\!-\!\boldsymbol{\eta}^{ad}\_{k}\right)\!\Delta t$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta\mathbf{p}\_{ij}$ | $\displaystyle\doteq\textstyle\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{p}\_{j}-\mathbf{p}\_{i}-\mathbf{v}\_{i}\Delta t\_{ij}-\frac{1}{2}\mathbf{g}\Delta t\_{ij}^{2}\right)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{k=i}^{j-1}\left[\Delta\mathbf{v}\_{ik}\Delta t+\frac{1}{2}\Delta\mathtt{R}\_{ik}\left(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{k}\!-\!\boldsymbol{\eta}^{ad}\_{k}\right)\Delta t^{2}\right]$ |  | (33) |

where $\Delta\mathtt{R}\_{ik}\doteq\mathtt{R}\_{i}^{\mathsf{T}}\mathtt{R}\_{k}$ and $\Delta\mathbf{v}\_{ik}\doteq\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{v}\_{k}\!-\!\mathbf{v}\_{i}\!-\!\mathbf{g}\Delta t\_{ik}\right)$.
We highlight that, in contrast to the “delta” rotation $\Delta\mathtt{R}\_{ij}$, neither
$\Delta\mathbf{v}\_{ij}$ nor $\Delta\mathbf{p}\_{ij}$ correspond to the true *physical* change in velocity and position but are defined in a way that make the right-hand side of ([33](#S6.Ex14 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) independent from the state at time $i$ as well as gravitational effects.
Indeed, we will be able to compute the right-hand side of ([33](#S6.Ex14 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) directly from the inertial measurements between the two keyframes.

Unfortunately, summations and products in ([33](#S6.Ex14 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) are still function of the bias estimate.
We tackle this problem in two steps.
In Section [VI-A](#S6.SS1 "VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"), we assume $\mathbf{b}\_{i}$ is known; then, in Section [VI-C](#S6.SS3 "VI-C Incorporating Bias Updates ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") we show how to avoid repeating the integration when the bias estimate changes.

In the rest of the paper, we assume that the bias remains constant between two keyframes:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{b}^{g}\_{i}=\mathbf{b}^{g}\_{i+1}=\ldots=\mathbf{b}^{g}\_{j-1},\quad\mathbf{b}^{a}\_{i}=\mathbf{b}^{a}\_{i+1}=\ldots=\mathbf{b}^{a}\_{j-1}.$ |  | (34) |

### VI-A Preintegrated IMU Measurements

Equation ([33](#S6.Ex14 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) relates the states of keyframes $i$ and $j$ (left-hand side) to the measurements (right-hand side).
In this sense, it can be already understood as a measurement model.
Unfortunately, it has a fairly intricate dependence on the measurement noise and this complicates a direct application of MAP estimation; intuitively, the MAP estimator requires to clearly define the densities (and their log-likelihood) of the measurements.
In this section we manipulate ([33](#S6.Ex14 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) so to make easier the derivation of the measurement log-likelihood.
In practice, we isolate the noise terms of the individual inertial measurements in ([33](#S6.Ex14 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
As discussed above, across this section assume that the bias at time $t\_{i}$ is known.

Let us start with the rotation increment $\Delta\mathtt{R}\_{ij}$ in ([33](#S6.Ex14 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
We use the first-order approximation ([7](#S3.E7 "In Special Orthogonal Group ‣ III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) (rotation noise is “small”) and rearrange the terms, by “moving” the noise to the end, using the relation ([11](#S3.E11 "In Special Orthogonal Group ‣ III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta\mathtt{R}\_{ij}$ | $\displaystyle\stackrel{{\scriptstyle\text{eq.}\eqref{eq:expExpansion}}}{{\simeq}}\prod\_{k=i}^{j-1}\left[\mathrm{Exp}\left(\left(\tilde{\boldsymbol{\omega}}\_{k}-\mathbf{b}^{g}\_{i}\right)\Delta t\right)\mathrm{Exp}\left(-\mathtt{J}^{k}\_{r}\;\boldsymbol{\eta}^{gd}\_{k}\;\Delta t\right)\right]$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\!\stackrel{{\scriptstyle\text{eq.}\eqref{eq:adjointProperty2}}}{{=}}\Delta\tilde{\mathtt{R}}\_{ij}\prod\_{k=i}^{j-1}\mathrm{Exp}\left(-\Delta\tilde{\mathtt{R}}\_{k+1j}^{\mathsf{T}}\;\mathtt{J}^{k}\_{r}\;\boldsymbol{\eta}^{gd}\_{k}\;\Delta t\right)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\ \doteq\Delta\tilde{\mathtt{R}}\_{ij}\mathrm{Exp}\left(-\delta\boldsymbol{\phi}\_{ij}\right)$ |  | (35) |

with $\mathtt{J}^{k}\_{r}\doteq\mathtt{J}^{k}\_{r}((\tilde{\boldsymbol{\omega}}\_{k}-\mathbf{b}^{g}\_{i})\Delta t)$.
In the last line of ([35](#S6.E35 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), we defined the *preintegrated rotation measurement* $\Delta\tilde{\mathtt{R}}\_{ij}\doteq\prod\_{k=i}^{j-1}\mathrm{Exp}\left(\left(\tilde{\boldsymbol{\omega}}\_{k}-\mathbf{b}^{g}\_{i}\right)\Delta t\right)$, and its noise $\delta\boldsymbol{\phi}\_{ij}$, which will be further analysed in the next section.

Substituting ([35](#S6.E35 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) back into the expression of $\Delta\mathbf{v}\_{ij}$ in ([33](#S6.Ex14 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), using the first-order approximation ([4](#S3.E4 "In Special Orthogonal Group ‣ III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) for $\mathrm{Exp}\left(-\delta\boldsymbol{\phi}\_{ij}\right)$, and dropping higher-order noise terms, we obtain:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta\mathbf{v}\_{ij}$ | $\displaystyle\stackrel{{\scriptstyle\text{eq.}\eqref{eq:expFirstOrder}}}{{\simeq}}\sum\_{k=i}^{j-1}\Delta\tilde{\mathtt{R}}\_{ik}({\mathbf{I}}-\delta\boldsymbol{\phi}\_{ik}^{\wedge})\left(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{i}\right)\Delta t\!-\!\Delta\tilde{\mathtt{R}}\_{ik}\boldsymbol{\eta}^{ad}\_{k}\Delta t$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\overset{\text{eq.}\eqref{eq:skewProperty}}{=}\Delta\tilde{\mathbf{v}}\_{ij}\!+\!\sum\_{k=i}^{j-1}\left[\Delta\tilde{\mathtt{R}}\_{ik}\left(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{i}\right)^{\wedge}\delta\boldsymbol{\phi}\_{ik}\Delta t-\Delta\tilde{\mathtt{R}}\_{ik}\boldsymbol{\eta}^{ad}\_{k}\Delta t\right]$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\;\;\doteq\Delta\tilde{\mathbf{v}}\_{ij}-\delta\mathbf{v}\_{ij}$ |  | (36) |

where we defined the *preintegrated velocity measurement* $\Delta\tilde{\mathbf{v}}\_{ij}\doteq\sum\_{k=i}^{j-1}\!\Delta\tilde{\mathtt{R}}\_{ik}\!\left(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{i}\right)\Delta t$ and its noise $\delta\mathbf{v}\_{ij}$.

Similarly, substituting ([35](#S6.E35 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) and ([36](#S6.Ex19 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) in the expression of $\Delta\mathbf{p}\_{ij}$ in ([33](#S6.Ex14 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), and using the first-order approximation ([4](#S3.E4 "In Special Orthogonal Group ‣ III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), we obtain:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\!\!\!\!\!\!\!\Delta\mathbf{p}\_{ij}$ | $\displaystyle\!\!\stackrel{{\scriptstyle\text{eq.}\eqref{eq:expFirstOrder}}}{{\simeq}}\!\sum\_{k=i}^{j-1}\Big[(\Delta\tilde{\mathbf{v}}\_{ik}\!-\!\delta\mathbf{v}\_{ik})\Delta t\!+\!\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{ik}({\mathbf{I}}\!-\!\delta\boldsymbol{\phi}\_{ik}^{\wedge})\left(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{i}\right)\Delta t^{2}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\hskip 9.24994pt\hskip 9.24994pt\hskip 9.24994pt\hskip 9.24994pt\!-\!\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{ik}\boldsymbol{\eta}^{ad}\_{k}\Delta t^{2}\Big]$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\!\!\overset{\text{eq.}\eqref{eq:skewProperty}}{\!\!=\!\!}\Delta\tilde{\mathbf{p}}\_{ij}\!+\!\sum\_{k=i}^{j-1}\Big[-\delta\mathbf{v}\_{ik}\Delta t+\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{ik}\left(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{i}\right)^{\wedge}\delta\boldsymbol{\phi}\_{ik}\Delta t^{2}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\hskip 9.24994pt\hskip 9.24994pt\hskip 9.24994pt\hskip 9.24994pt\hskip 9.24994pt\hskip 9.24994pt\hskip 9.24994pt-\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{ik}\boldsymbol{\eta}^{ad}\_{k}\Delta t^{2}\Big]$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\doteq\Delta\tilde{\mathbf{p}}\_{ij}-\delta\mathbf{p}\_{ij},$ |  | (37) |

where we defined the *preintegrated position measurement* $\Delta\tilde{\mathbf{p}}\_{ij}$ and its noise $\delta\mathbf{p}\_{ij}$.

Substituting the expressions ([35](#S6.E35 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), ([36](#S6.Ex19 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), ([37](#S6.Ex21 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) back in the original definition of $\Delta\mathtt{R}\_{ij},\Delta\mathbf{v}\_{ij},\Delta\mathbf{p}\_{ij}$ in ([33](#S6.Ex14 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), we finally get our *preintegrated measurement model*
(remember $\mathrm{Exp}\left(-\delta\boldsymbol{\phi}\_{ij}\right)^{\mathsf{T}}=\mathrm{Exp}\left(\delta\boldsymbol{\phi}\_{ij}\right)$):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta\tilde{\mathtt{R}}\_{ij}$ | $\displaystyle=\mathtt{R}\_{i}^{\mathsf{T}}\mathtt{R}\_{j}\mathrm{Exp}\left(\delta\boldsymbol{\phi}\_{ij}\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta\tilde{\mathbf{v}}\_{ij}$ | $\displaystyle=\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{v}\_{j}\!-\!\mathbf{v}\_{i}\!-\!\mathbf{g}\Delta t\_{ij}\right)+\delta\mathbf{v}\_{ij}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\tilde{\mathbf{p}}\_{ij}$ | $\displaystyle=\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{p}\_{j}-\mathbf{p}\_{i}-\mathbf{v}\_{i}\Delta t\_{ij}-\frac{1}{2}\mathbf{g}\Delta t\_{ij}^{2}\right)+\delta\mathbf{p}\_{ij}$ |  | (38) |

where our compound measurements are written as a function of the (to-be-estimated) state “plus” a random noise, described by the random vector $[\delta\boldsymbol{\phi}\_{ij}^{\mathsf{T}},\delta\mathbf{v}\_{ij}^{\mathsf{T}},\delta\mathbf{p}\_{ij}^{\mathsf{T}}]^{\mathsf{T}}$.

To wrap-up the discussion in this section, we manipulated the measurement model ([33](#S6.Ex14 "In VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"))
and rewrote it as ([38](#S6.Ex25 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")). The advantage of Eq.  ([38](#S6.Ex25 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"))
is that, for a suitable distribution of the noise, it makes the definition of the log-likelihood straightforward.
For instance the (negative) log-likelihood of measurements with zero-mean additive Gaussian noise (last two lines in ([38](#S6.Ex25 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"))) is a quadratic function. Similarly, if $\delta\boldsymbol{\phi}\_{ij}$ is a zero-mean Gaussian noise, we compute the (negative) log-likelihood
associated with $\Delta\tilde{\mathtt{R}}\_{ij}$.
The nature of the noise terms is discussed in the following section.

### VI-B Noise Propagation

In this section we derive the statistics of the noise vector $[\delta\boldsymbol{\phi}\_{ij}^{\mathsf{T}},\delta\mathbf{v}\_{ij}^{\mathsf{T}},\delta\mathbf{p}\_{ij}^{\mathsf{T}}]^{\mathsf{T}}$.
While we already observed that it is convenient to approximate the noise vector to be
zero-mean Normally distributed, it is of paramount importance to accurately model the noise covariance.
Indeed, the noise covariance has a strong influence on
the MAP estimator (the inverse noise covariance is used to weight the terms in the optimization ([26](#S4.E26 "In IV-C Factor Graphs and MAP Estimation ‣ IV Maximum a Posteriori Visual-Inertial State Estimation ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"))).
In this section, we therefore provide a derivation of the covariance $\mathbf{\Sigma}\_{ij}$ of the preintegrated measurements:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\boldsymbol{\eta}^{\Delta}\_{ij}\doteq[\delta\boldsymbol{\phi}\_{ij}^{\mathsf{T}},\delta\mathbf{v}\_{ij}^{\mathsf{T}},\delta\mathbf{p}\_{ij}^{\mathsf{T}}]^{\mathsf{T}}\sim{\cal N}(\mathbf{0}\_{9\times 1},\mathbf{\Sigma}\_{ij}).$ |  | (39) |

We first consider the preintegrated rotation noise $\delta\boldsymbol{\phi}\_{ij}$.
Recall from ([35](#S6.E35 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textstyle\mathrm{Exp}\left(-\delta\boldsymbol{\phi}\_{ij}\right)\doteq\prod\_{k=i}^{j-1}\mathrm{Exp}\left(-\Delta\tilde{\mathtt{R}}\_{k+1j}^{\mathsf{T}}\mathtt{J}^{k}\_{r}\;\boldsymbol{\eta}^{gd}\_{k}\;\Delta t\right).$ |  | (40) |

Taking the $\mathrm{Log}$ on both sides and changing signs, we get:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textstyle\delta\boldsymbol{\phi}\_{ij}=-\mathrm{Log}\left(\prod\_{k=i}^{j-1}\mathrm{Exp}\left(-\Delta\tilde{\mathtt{R}}\_{k+1j}^{\mathsf{T}}\mathtt{J}^{k}\_{r}\;\boldsymbol{\eta}^{gd}\_{k}\;\Delta t\right)\right).$ |  | (41) |

Repeated application of the first-order approximation ([9](#S3.E9 "In Special Orthogonal Group ‣ III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) (recall that $\boldsymbol{\eta}^{gd}\_{k}$ as well as $\delta\boldsymbol{\phi}\_{ij}$ are small rotation noises, hence the right Jacobians are close to the identity) produces:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textstyle\delta\boldsymbol{\phi}\_{ij}\simeq\sum\_{k=i}^{j-1}\Delta\tilde{\mathtt{R}}\_{k+1j}^{\mathsf{T}}\;\mathtt{J}^{k}\_{r}\;\boldsymbol{\eta}^{gd}\_{k}\;\Delta t$ |  | (42) |

Up to first order, the noise $\delta\boldsymbol{\phi}\_{ij}$ is zero-mean and Gaussian, as it is a linear combination of zero-mean noise terms $\boldsymbol{\eta}^{gd}\_{k}$. This is desirable, since it brings the rotation measurement model ([38](#S6.Ex25 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) exactly in the form ([12](#S3.E12 "In III-B Uncertainty Description in SO(3) ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).

Dealing with the noise terms $\delta\mathbf{v}\_{ij}$ and $\delta\mathbf{p}\_{ij}$ is now easy: these are linear combinations of the acceleration noise $\boldsymbol{\eta}^{ad}\_{k}$ and the preintegrated rotation noise $\delta\boldsymbol{\phi}\_{ij}$, hence they are also zero-mean and Gaussian.
Simple manipulation leads to:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\delta\mathbf{v}\_{ij}$ | $\displaystyle\simeq\!\sum\_{k=i}^{j-1}\left[-\Delta\tilde{\mathtt{R}}\_{ik}\left(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{i}\right)^{\wedge}\!\delta\boldsymbol{\phi}\_{ik}\Delta t+\Delta\tilde{\mathtt{R}}\_{ik}\boldsymbol{\eta}^{ad}\_{k}\Delta t\right]$ |  | (43) |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\delta\mathbf{p}\_{ij}$ | $\displaystyle\simeq\!\sum\_{k=i}^{j-1}\Big[\delta\mathbf{v}\_{ik}\Delta t\!-\!\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{ik}\left(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{i}\right)^{\wedge}\!\delta\boldsymbol{\phi}\_{ik}\Delta t^{2}\!+\!\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{ik}\boldsymbol{\eta}^{ad}\_{k}\Delta t^{2}\Big]$ |  |

where the relations are valid up to the first order.

Eqs. ([42](#S6.E42 "In VI-B Noise Propagation ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"))-([43](#S6.E43 "In VI-B Noise Propagation ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) express the preintegrated noise $\boldsymbol{\eta}^{\Delta}\_{ij}$
as a linear function of the IMU measurement noise $\boldsymbol{\eta}^{d}\_{k}\doteq[\boldsymbol{\eta}^{gd}\_{k},\boldsymbol{\eta}^{ad}\_{k}]$, $k=1,\ldots,j-1$.
Therefore, from the knowledge of the covariance of $\boldsymbol{\eta}^{d}\_{k}$ (given in the IMU specifications), we can compute the
covariance of $\boldsymbol{\eta}^{\Delta}\_{ij}$, namely $\mathbf{\Sigma}\_{ij}$, by a simple linear propagation.

In Appendix [IX-A](#Sx2.SS1 "IX-A Iterative Noise Propagation ‣ Appendix ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"), we provide a more clever way to compute
$\mathbf{\Sigma}\_{ij}$. In particular, we show that $\mathbf{\Sigma}\_{ij}$ can be conveniently computed in iterative form:
as a new IMU measurement arrive we only update $\mathbf{\Sigma}\_{ij}$, rather
than recomputing it from scratch. The iterative computation leads to
simpler expressions and is more amenable for online inference.

### VI-C Incorporating Bias Updates

In the previous section, we assumed that the bias $\{\bar{\mathbf{b}}^{a}\_{i},\bar{\mathbf{b}}^{g}\_{i}\}$ that is used during preintegration between $k=i$ and $k=j$ is correct and does not change.
However, more likely, the bias estimate changes by a small amount $\delta\mathbf{b}$ during optimization.
One solution would be to recompute the delta measurements when the bias changes; however, that is computationally expensive.
Instead, given a bias update $\mathbf{b}\leftarrow\bar{\mathbf{b}}+\delta\mathbf{b}$, we can update the delta measurements using a first-order expansion:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\tilde{\mathtt{R}}\_{ij}(\mathbf{b}^{g}\_{i})$ | $\displaystyle\textstyle\simeq\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}^{g}\_{i})\;\mathrm{Exp}\Big(\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}}\delta\mathbf{b}^{g}\Big)$ |  | (44) |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta\tilde{\mathbf{v}}\_{ij}(\mathbf{b}^{g}\_{i},\mathbf{b}^{a}\_{i})$ | $\displaystyle\textstyle\simeq\Delta\tilde{\mathbf{v}}\_{ij}(\bar{\mathbf{b}}^{g}\_{i},\bar{\mathbf{b}}^{a}\_{i})+\frac{\partial\Delta\bar{\mathbf{v}}\_{ij}}{\partial\mathbf{b}^{g}}\delta\mathbf{b}^{g}\_{i}+\frac{\partial\Delta\bar{\mathbf{v}}\_{ij}}{\partial\mathbf{b}^{a}}\delta\mathbf{b}^{a}\_{i}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta\tilde{\mathbf{p}}\_{ij}(\mathbf{b}^{g}\_{i},\mathbf{b}^{a}\_{i})$ | $\displaystyle\textstyle\simeq\Delta\tilde{\mathbf{p}}\_{ij}(\bar{\mathbf{b}}^{g}\_{i},\bar{\mathbf{b}}^{a}\_{i})+\frac{\partial\Delta\bar{\mathbf{p}}\_{ij}}{\partial\mathbf{b}^{g}}\delta\mathbf{b}^{g}\_{i}+\frac{\partial\Delta\bar{\mathbf{p}}\_{ij}}{\partial\mathbf{b}^{a}}\delta\mathbf{b}^{a}\_{i}$ |  |

This is similar to the bias correction in [[2](#bib.bib2)] but operates directly on $\mathrm{SO}(3)$.
The Jacobians $\{\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}},\frac{\partial\Delta\bar{\mathbf{v}}\_{ij}}{\partial\mathbf{b}^{g}},\ldots\}$
(computed at $\bar{\mathbf{b}}\_{i}$, the bias estimate at integration time) describe how the measurements change due to a change in the bias estimate.
The Jacobians remain constant and can be precomputed during the preintegration.
The derivation of the Jacobians is very similar to the one we used in Section [VI-A](#S6.SS1 "VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") to express the measurements as a large value *plus* a small perturbation and is given in Appendix [IX-B](#Sx2.SS2 "IX-B Bias Correction via First-Order Updates ‣ Appendix ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").

### VI-D Preintegrated IMU Factors

Given the preintegrated measurement model in ([38](#S6.Ex25 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) and since measurement noise is zero-mean and Gaussian (with covariance $\mathbf{\Sigma}\_{ij}$) up to first order ([39](#S6.E39 "In VI-B Noise Propagation ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), it is now easy to write the residual errors
$\mathbf{r}\_{\mathcal{I}\_{ij}}\doteq[\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}^{\mathsf{T}},\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}^{\mathsf{T}},\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}^{\mathsf{T}}]^{\mathsf{T}}\in\mathbb{R}^{9}$,
where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}\doteq$ | $\displaystyle\ \textstyle\mathrm{Log}\left(\left(\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}^{g}\_{i})\mathrm{Exp}\left(\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}}\delta\mathbf{b}^{g}\right)\right)^{\mathsf{T}}\mathtt{R}\_{i}^{\mathsf{T}}\mathtt{R}\_{j}\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}\doteq$ | $\displaystyle\ \textstyle\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{v}\_{j}-\mathbf{v}\_{i}-\mathbf{g}\Delta t\_{ij}\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle-$ | $\displaystyle\textstyle\left[\Delta\tilde{\mathbf{v}}\_{ij}(\bar{\mathbf{b}}^{g}\_{i},\bar{\mathbf{b}}^{a}\_{i})+\frac{\partial\Delta\bar{\mathbf{v}}\_{ij}}{\partial\mathbf{b}^{g}}\delta\mathbf{b}^{g}+\frac{\partial\Delta\bar{\mathbf{v}}\_{ij}}{\partial\mathbf{b}^{a}}\delta\mathbf{b}^{a}\right]$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}\doteq$ | $\displaystyle\ \textstyle\mathtt{R}\_{i}^{\mathsf{T}}\big(\mathbf{p}\_{j}-\mathbf{p}\_{i}-\mathbf{v}\_{i}\Delta t\_{ij}-\frac{1}{2}\mathbf{g}\Delta t\_{ij}^{2}\big)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle-$ | $\displaystyle\textstyle\left[\Delta\tilde{\mathbf{p}}\_{ij}(\bar{\mathbf{b}}^{g}\_{i},\bar{\mathbf{b}}^{a}\_{i})+\frac{\partial\Delta\bar{\mathbf{p}}\_{ij}}{\partial\mathbf{b}^{g}}\delta\mathbf{b}^{g}+\frac{\partial\Delta\bar{\mathbf{p}}\_{ij}}{\partial\mathbf{b}\_{a}}\delta\mathbf{b}^{a}\right],$ |  | (45) |

in which we also included the bias updates of Eq. ([44](#S6.E44 "In VI-C Incorporating Bias Updates ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).

According to the “lift-solve-retract” method (Section [III-C](#S3.SS3 "III-C Gauss-Newton Method on Manifold ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), at each Gauss-Newton iteration we need to re-parametrize ([45](#S6.Ex33 "In VI-D Preintegrated IMU Factors ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) using the retraction ([21](#S3.E21 "In III-C Gauss-Newton Method on Manifold ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
Then, the “solve” step requires to linearize the resulting cost around the current estimate.
For the purpose of linearization, it is convenient to compute analytic expressions of the Jacobians of the residual errors, which we derive in the Appendix [IX-C](#Sx2.SS3 "IX-C Jacobians of Residual Errors ‣ Appendix ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").

### VI-E Bias Model

When presenting the IMU model ([27](#S5.E27 "In V IMU Model and Motion Integration ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), we said that biases are slowly time-varying quantities.
Hence, we model them with a “Brownian motion”, *i.e.*, integrated white noise:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\dot{\mathbf{b}}^{g}(t)=\boldsymbol{\eta}^{bg},\qquad\dot{\mathbf{b}}^{a}(t)=\boldsymbol{\eta}^{ba}.$ |  | (46) |

Integrating ([46](#S6.E46 "In VI-E Bias Model ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) over the time interval $[t\_{i},t\_{j}]$ between two consecutive keyframes $i$ and $j$ we get:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{b}^{g}\_{j}=\mathbf{b}^{g}\_{i}+\boldsymbol{\eta}^{bgd},\qquad\mathbf{b}^{a}\_{j}=\mathbf{b}^{a}\_{i}+\boldsymbol{\eta}^{bad},$ |  | (47) |

where, as done before, we use the shorthand $\mathbf{b}^{g}\_{i}\doteq\mathbf{b}^{g}(t\_{i})$, and we define the discrete noises $\boldsymbol{\eta}^{bgd}$ and $\boldsymbol{\eta}^{bad}$, which have zero mean and covariance $\mathbf{\Sigma}^{bgd}\doteq\Delta t\_{ij}\text{Cov}(\boldsymbol{\eta}^{bg})$ and $\mathbf{\Sigma}^{bad}\doteq\Delta t\_{ij}\text{Cov}(\boldsymbol{\eta}^{ba})$, respectively (*cf.* [[58](#bib.bib58), Appendix]).

The model ([47](#S6.E47 "In VI-E Bias Model ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) can be readily included in our factor graph, as a further additive term in ([26](#S4.E26 "In IV-C Factor Graphs and MAP Estimation ‣ IV Maximum a Posteriori Visual-Inertial State Estimation ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) for all consecutive keyframes:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textstyle\|\mathbf{r}\_{\mathbf{b}\_{ij}}\|^{2}\doteq\|\mathbf{b}^{g}\_{j}-\mathbf{b}^{g}\_{i}\|^{2}\_{\mathbf{\Sigma}^{bgd}}+\|\mathbf{b}^{a}\_{j}-\mathbf{b}^{a}\_{i}\|^{2}\_{\mathbf{\Sigma}^{bad}}$ |  | (48) |

## VII Structureless Vision Factors

In this section we introduce our structureless model for vision measurements.
The key feature of our approach is the linear elimination of landmarks.
Note that the elimination is repeated at each Gauss-Newton iteration, hence we are still guaranteed to obtain the optimal MAP estimate.

Visual measurements contribute to the cost ([26](#S4.E26 "In IV-C Factor Graphs and MAP Estimation ‣ IV Maximum a Posteriori Visual-Inertial State Estimation ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) via the sum:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textstyle\sum\_{i\in\mathcal{K}\_{k}}\sum\_{l\in\mathcal{C}\_{i}}\|\mathbf{r}\_{\mathcal{C}\_{il}}\|^{2}\_{\mathbf{\Sigma}\_{\mathcal{C}}}=\sum\_{l=1}^{L}\sum\_{i\in\mathcal{X}(l)}\|\mathbf{r}\_{\mathcal{C}\_{il}}\|^{2}\_{\mathbf{\Sigma}\_{\mathcal{C}}}$ |  | (49) |

which, on the right-hand-side, we rewrote as a sum of contributions of each landmark $l=1,\ldots,L$.
In ([49](#S7.E49 "In VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), $\mathcal{X}(l)$ denotes the subset of keyframes in which $l$ is seen.

A fairly standard model for the residual error of a single image measurement $\mathbf{z}\_{il}$ is the reprojection error:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textstyle\mathbf{r}\_{\mathcal{C}\_{il}}=\mathbf{z}\_{il}-\pi(\mathtt{R}\_{i},\mathbf{p}\_{i},\mathbf{\rho}\_{l}),$ |  | (50) |

where $\mathbf{\rho}\_{l}\in\mathbb{R}^{3}$ denotes the position of the $l$-th landmark, and $\pi(\cdot)$ is a standard perspective projection, which also encodes the (known) IMU-camera transformation $\mathtt{T}\_{\text{\tiny{B}}\text{\tiny{C}}}$.

Direct use of ([50](#S7.E50 "In VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) would require to include the landmark positions $\mathbf{\rho}\_{l}$, $l=1,\ldots,L$ in the optimization, and this impacts negatively on computation.
Therefore, in the following we adopt a *structureless* approach that avoids optimization over the landmarks, thus ensuring to retrieve the MAP estimate.

As recalled in Section [III-C](#S3.SS3 "III-C Gauss-Newton Method on Manifold ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"), at each GN iteration, we *lift* the cost function, using the retraction ([21](#S3.E21 "In III-C Gauss-Newton Method on Manifold ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
For the vision factors this means that the original residuals ([49](#S7.E49 "In VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) become:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textstyle\sum\_{l=1}^{L}\sum\_{i\in\mathcal{X}(l)}\|\mathbf{z}\_{il}-\check{\pi}(\delta\boldsymbol{\phi}\_{i},\delta\mathbf{p}\_{i},\delta\mathbf{\rho}\_{l})\|^{2}\_{\mathbf{\Sigma}\_{\mathcal{C}}}$ |  | (51) |

where $\delta\boldsymbol{\phi}\_{i},\delta\mathbf{p}\_{i},\delta\mathbf{\rho}\_{l}$ are now Euclidean corrections, and $\check{\pi}(\cdot)$ is the lifted cost function.
The “solve” step in the GN method is based on linearization of the residuals:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textstyle\sum\_{l=1}^{L}\sum\_{i\in\mathcal{X}(l)}\|\mathbf{F}\_{il}\delta\mathbf{T}\_{i}+\mathbf{E}\_{il}\delta\mathbf{\rho}\_{l}-\mathbf{b}\_{il}\|^{2},$ |  | (52) |

where $\delta\mathbf{T}\_{i}\doteq[\delta\boldsymbol{\phi}\_{i}\;\delta\mathbf{p}\_{i}]^{\mathsf{T}}$; the Jacobians $\mathbf{F}\_{il},\mathbf{E}\_{il}$, and the vector $\mathbf{b}\_{il}$ (both normalized by $\mathbf{\Sigma}\_{\mathcal{C}}^{1/2}$) result from the linearization.
The vector $\mathbf{b}\_{il}$ is the residual error at the linearization point.

Writing the second sum in ([52](#S7.E52 "In VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) in matrix form we get:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textstyle\sum\_{l=1}^{L}\|\mathbf{F}\_{l}\;\delta\mathbf{T}\_{\mathcal{X}(l)}+\mathbf{E}\_{l}\;\delta\mathbf{\rho}\_{l}-\mathbf{b}\_{l}\|^{2}$ |  | (53) |

where $\mathbf{F}\_{l},\mathbf{E}\_{l},\mathbf{b}\_{l}$ are obtained by stacking $\mathbf{F}\_{il},\mathbf{E}\_{il},\mathbf{b}\_{il}$, respectively, for all $i\in\mathcal{X}(l)$.

Since a landmark $l$ appears in a single term of the sum ([53](#S7.E53 "In VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), for any given choice of the pose perturbation $\delta\mathbf{T}\_{\mathcal{X}(l)}$,
the landmark perturbation $\delta\mathbf{\rho}\_{l}$ that minimizes the quadratic cost
$\|\mathbf{F}\_{l}\;\delta\mathbf{T}\_{\mathcal{X}(l)}+\mathbf{E}\_{l}\;\delta\mathbf{\rho}\_{l}-\mathbf{b}\_{l}\|^{2}$ is:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\delta\mathbf{\rho}\_{l}=-(\mathbf{E}\_{l}^{\mathsf{T}}\mathbf{E}\_{l})^{-1}\mathbf{E}\_{l}^{\mathsf{T}}(\mathbf{F}\_{l}\;\delta\mathbf{T}\_{\mathcal{X}(l)}-\mathbf{b}\_{l})$ |  | (54) |

Substituting ([54](#S7.E54 "In VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) back into ([53](#S7.E53 "In VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"))
we can *eliminate* the variable $\delta\mathbf{\rho}\_{l}$ from the optimization problem:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sum\_{l=1}^{L}\|({\mathbf{I}}-\mathbf{E}\_{l}(\mathbf{E}\_{l}^{\mathsf{T}}\mathbf{E}\_{l})^{-1}\mathbf{E}\_{l}^{\mathsf{T}})\left(\mathbf{F}\_{l}\;\delta\mathbf{T}\_{\mathcal{X}(l)}-\mathbf{b}\_{l}\right)\|^{2},$ |  | (55) |

where ${\mathbf{I}}-\mathbf{E}\_{l}(\mathbf{E}\_{l}^{\mathsf{T}}\mathbf{E}\_{l})^{-1}\mathbf{E}\_{l}^{\mathsf{T}}$ is an orthogonal projector of $\mathbf{E}\_{l}$.
In Appendix [IX-D](#Sx2.SS4 "IX-D Structureless Vision Factors: Null Space Projection ‣ Appendix ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") we show that the cost ([55](#S7.E55 "In VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) can be further manipulated, leading to a more efficient implementation.

This approach is well known in the bundle adjustment literature as the *Schur complement trick*, where a standard practice is to update the linearization point of $\mathbf{\rho}\_{l}$ via *back-substitution* [[61](#bib.bib61)].
In contrast, we obtain the updated landmark positions from the linearization point of the poses using a fast linear triangulation.
Using this approach, we reduced a large set of factors ([51](#S7.E51 "In VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) which involve poses and landmarks into a smaller set of $L$ factors ([55](#S7.E55 "In VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), which only involve poses.
In particular, the factor corresponding to landmark $l$ only involves the states $\mathcal{X}(l)$ observing $l$, creating the connectivity pattern of Fig.  [3](#S4.F3 "Fig. 3 ‣ IV-C Factor Graphs and MAP Estimation ‣ IV Maximum a Posteriori Visual-Inertial State Estimation ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").
The same approach is also used in MSC-KF [[5](#bib.bib5)] to avoid the inclusion of landmarks in the state vector.
However, since MSC-KF can only linearize and absorb a measurement once, the processing of measurements needs to be delayed until all measurements of the same landmark are observed.
This does not apply to the proposed optimization-based approach, which allows for multiple relinearizations and the incremental inclusion of new measurements.

## VIII Experimental Analysis

We tested the proposed approach on both simulated and real data.
Section [VIII-A](#S8.SS1 "VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") reports simulation results, showing that our
approach is accurate, fast, and consistent.
Section [VIII-B](#S8.SS2 "VIII-B Real Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") compares our approach against the state-of-the-art,
confirming its superior accuracy in real indoor and outdoor experiments.

### VIII-A Simulation Experiments

Fig. 5: Simulation setup: The camera moves along a circular trajectory while observing features (green lines) on the walls of a square environment.

We simulated a camera following a circular trajectory of three meter radius with a sinusoidal vertical motion.
The total length of the trajectory is 120 meters.
While moving, the camera observes landmarks as depicted in Fig. [5](#S8.F5 "Fig. 5 ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").
The number of landmark observations per frame is limited to 50.
To simulate a realistic feature-tracker, we corrupt the landmark measurements with isotropic
Gaussian noise with standard deviation $\sigma\_{\text{px}}=1$ pixel.
The camera has a focal length of $315$ pixels and runs at a rate of 2.5 Hz (simulating keyframes).
The simulated acceleration and gyroscope measurements are computed from the analytic derivatives of the parametric trajectory and additionally corrupted by white noise and a slowly time-varying bias terms, according to the IMU model in Eq. ([27](#S5.E27 "In V IMU Model and Motion Integration ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).22
2
We used the following IMU parameters:
Gyroscope and accelerometer continuous-time noise density: $\sigma^{g}=0.0007\ [\text{rad}/(\text{s}\sqrt{\text{Hz}})]$, $\sigma^{a}=0.019\ [\text{m}/(\text{s}^{2}\sqrt{\text{Hz}})]$. Gyroscope and accelerometer *bias* continous-time noise density:
$\sigma^{bg}=0.0004\ [\text{rad}/(\text{s}^{2}\sqrt{\text{Hz}})]$,
$\sigma^{ba}=0.012\ [\text{m}/(\text{s}^{3}\sqrt{\text{Hz}})]$.
To evaluate our approach, we performed a Monte Carlo analysis with 50 simulation runs, each with different realizations of process and measurement noise.
In each run we compute the MAP estimate using the IMU and the vision models presented in this paper.
The optimization (whose solution is the MAP estimate) is solved using
the incremental smoothing algorithm iSAM2 [[3](#bib.bib3)].
iSAM2 uses the Bayes tree [[62](#bib.bib62)] data structure to obtain efficient variable ordering that minimizes fill-in in the square-root information matrix and, thus, minimizes computation time.
Further, iSAM2 exploits the fact that new measurements often have only local effect on the MAP estimate, hence applies incremental updates directly to the square-root information matrix, only re-solving for the variables affected by a new measurement.

In the following we present the results of our experiments, organized in four subsections:
1) pose estimation accuracy and timing,
2) consistency,
3) bias estimation accuracy, and
4) first-order bias correction. Then, in Section [VIII-A5](#S8.SS1.SSS5 "VIII-A5 Advantages over the Euler-angle-based formulation ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") we compare
our approach against the original proposal of [[2](#bib.bib2)].

#### VIII-A1 Pose Estimation Accuracy and Timing

The optimal
MAP estimate is given by the *batch* nonlinear optimization of the least-squares objective in Eq. ([26](#S4.E26 "In IV-C Factor Graphs and MAP Estimation ‣ IV Maximum a Posteriori Visual-Inertial State Estimation ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
However, as shown on the left in Fig. [6](#S8.F6 "Fig. 6 ‣ VIII-A1 Pose Estimation Accuracy and Timing ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"), the computational cost of batch optimization
quickly increases as the trajectory length grows.
A key ingredient that makes our approach extremely efficient is the use of the incremental smoothing algorithm iSAM2 [[3](#bib.bib3)], which performs close-to-optimal inference, while preserving real-time capability. Fig. [8](#S8.F8 "Fig. 8 ‣ VIII-A1 Pose Estimation Accuracy and Timing ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") shows that the accuracy of iSAM2 is
practically the same as the batch estimate.
In odometry problems, the iSAM2 algorithm results in approximately constant update time per frame (Fig. [6](#S8.F6 "Fig. 6 ‣ VIII-A1 Pose Estimation Accuracy and Timing ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"), left), which in our experiment is approximately 10 milliseconds per update (Fig. [6](#S8.F6 "Fig. 6 ‣ VIII-A1 Pose Estimation Accuracy and Timing ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"), right).

Fig. 6: 
Left: CPU time required for inference, comparing
batch estimation against iSAM2. Right: histogram plot
of CPU time for the proposed approach.

Fig. 7: Root Mean Squared Error (RMSE) averaged over 50 Monte Carlo experiments, comparing
batch nonlinear optimization and iSAM2.

Fig. 8: Orientation and position errors with 3$\sigma$ bounds (single simulation).

#### VIII-A2 Consistency

For generic motion, the VIO problem has four unobservable degrees of freedom, three corresponding to the global translation and one to the global orientation around the gravity direction (yaw), see [[16](#bib.bib16)].
A VIO algorithm must preserve these observability properties and avoid inclusion of spurious information along the unobservable directions, which would result in inconsistency [[16](#bib.bib16)].
Fig. [8](#S8.F8 "Fig. 8 ‣ VIII-A1 Pose Estimation Accuracy and Timing ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") reports orientation and position errors with the corresponding $3\sigma$ bounds, confirming that our approach is consistent.
In the VIO problem, the gravity direction is observable, hence the uncertainty on
roll and pitch remains bounded.
In contrast, global yaw and position cannot be measured and the uncertainty slowly grows over time.

To present more substantial evidence of the fact that our estimator is consistent, we
recall a standard measure of consistency, the *average* Normalized Estimation Error Squared (NEES) [[63](#bib.bib63)].
The NEES is the squared estimation error $\boldsymbol{\epsilon}\_{k}$ normalized by the estimator-calculated covariance ${\boldsymbol{\Sigma}}\_{k}$:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\eta\_{k}$ | $\displaystyle\doteq\boldsymbol{\epsilon}\_{k}^{\mathsf{T}}\hat{\boldsymbol{\Sigma}}\_{k}^{-1}\boldsymbol{\epsilon}\_{k}\qquad\quad\text{(NEES)}$ |  | (56) |

The error in estimating the current pose is computed as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\boldsymbol{\epsilon}\_{k}\doteq\big[\mathrm{Log}(\hat{\mathtt{R}}\_{k}^{\mathsf{T}}\mathtt{R}\_{k}^{\text{gt}}),\ \hat{\mathtt{R}}\_{k}^{\mathsf{T}}(\hat{\mathbf{p}}\_{k}-\mathbf{p}\_{k}^{\text{gt}})\big]^{\mathsf{T}}$ |  | (57) |

where the exponent “gt” denotes ground-truth states and $(\hat{\mathtt{R}}\_{k},\hat{\mathbf{p}}\_{k})$ denotes the estimated pose at time $k$.
Note that the error ([57](#S8.E57 "In VIII-A2 Consistency ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) is expressed in the body frame and it is consistent with our choice of the retraction in
Eq. ([21](#S3.E21 "In III-C Gauss-Newton Method on Manifold ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) (intuitively, the retraction applies the perturbation in the body frame).

The *average* NEES over $N$ independent Monte Carlo runs, can be computed
by averaging the NEES values:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textstyle\bar{\eta}\_{k}=\frac{1}{N}\sum\_{i=1}^{N}\eta^{(i)}\_{k}\qquad\quad\text{(average NEES)}$ |  | (58) |

where $\eta^{(i)}\_{k}$ is the NEES computed at the $i$-th Monte Carlo run.
If the estimator is consistent, then $N\textstyle\bar{\eta}\_{k}$ is $\chi^{2}\_{n}$ chi-square distributed with
$n=\text{dim}(\boldsymbol{\epsilon}\_{k})\cdot N$ degrees of freedom [[63](#bib.bib63), pp. 234].
We evaluate this hypothesis with a $\chi^{2}\_{n}$ acceptance test [[63](#bib.bib63), pp. 235].
For a significance level $\alpha=2.5\%$ and $n=\text{dim}(\boldsymbol{\epsilon}\_{k})\cdot N=6\cdot 50$,
the acceptance region of the test is given by the two-sided probability concentration region $\bar{\eta}\_{k}\in[5.0,7.0]$.
If $\bar{\eta}\_{k}$ rises significantly higher than the upper bound, the estimator is overconfident,
if it tends below the lower bound, it is conservative. In VIO one usually wants to avoid
overconfident estimators: the fact that $\bar{\eta}\_{k}$ exceeds the upper bound is an indicator of the fact that
the estimator is including spurious information in the inference process.

In Fig. [11](#S8.F11 "Fig. 11 ‣ VIII-A2 Consistency ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") we report the average NEES of the proposed approach.
The average NEES approaches the lower bound but, more importantly, it remains below the upper bound at 7.0 (black dots), which assures that the estimator is not overconfident.
We also report the average rotational and translational NEES to allow a comparison with the observability-constrained EKF in [[16](#bib.bib16), [18](#bib.bib18)], which obtains similar results by enforcing explicitly the observability properties in EKF.

Fig. 9: Normalized Estimation Error Squared (NEES) averaged over 50 Monte Carlo runs.
The average NEES is reported for the current pose (top), current position (middle), and current rotation (bottom).

Fig. 10: 
Comparison between ground truth bias (red line) and estimated bias (blue lines) in a Monte Carlo run.

Fig. 11: Error committed
when using the first-order approximation ([44](#S6.E44 "In VI-C Incorporating Bias Updates ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) instead
of repeating the integration, for different bias perturbations.
Left: $\Delta\tilde{\mathbf{p}}\_{ij}(\bar{\mathbf{b}}\_{i}+\delta\mathbf{b}\_{i})$ error;
Center: $\Delta\tilde{\mathbf{v}}\_{ij}(\bar{\mathbf{b}}\_{i}+\delta\mathbf{b}\_{i})$ error;
Right: $\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}\_{i}+\delta\mathbf{b}\_{i})$ error.
Statistics are computed over 1000 Monte Carlo runs.

#### VIII-A3 Bias Estimation Accuracy

Our simulations allow us to compare the estimated gyroscope and accelerometer bias with the true biases that were used to corrupt the simulated inertial measurements.
Fig. [11](#S8.F11 "Fig. 11 ‣ VIII-A2 Consistency ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") shows that biases estimated by our approach (in blue) correctly track the ground truth biases (in red).
Note that, since we use a smoothing approach, at each step, we potentially change the entire history of the bias estimates, hence
we visualize the bias estimates using multiple curves.
Each curve represents the history of the estimated biases from time zero (left-most extreme of the blue curve) to the current time (right-most extreme of the blue curve).

#### VIII-A4 First-Order Bias Correction

We performed an additional Monte-Carlo analysis to evaluate the a-posteriori bias correction proposed in Section [VI-C](#S6.SS3 "VI-C Incorporating Bias Updates ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").
The preintegrated measurements are computed with the bias estimate at the time of integration.
However, as seen in Fig. [11](#S8.F11 "Fig. 11 ‣ VIII-A2 Consistency ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"), the bias estimate for an older preintegrated measurement may change when more information becomes available.
To avoid repeating the integration when the bias estimate changes, we perform a first-order correction of the preintegrated measurement according to Eq. ([44](#S6.E44 "In VI-C Incorporating Bias Updates ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
The accuracy of this first order bias correction is reported in Fig. [11](#S8.F11 "Fig. 11 ‣ VIII-A2 Consistency ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").
To compute the statistics, we integrated 100 random IMU measurements with a given bias estimate $\bar{\mathbf{b}}\_{i}$ which results in the preintegrated measurements $\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}\_{i}),\Delta\tilde{\mathbf{v}}\_{ij}(\bar{\mathbf{b}}\_{i})$ and $\Delta\tilde{\mathbf{p}}\_{ij}(\bar{\mathbf{b}}\_{i})$.
Subsequently, a random perturbation $\delta\mathbf{b}\_{i}$ with magnitude between $0.04$ and $0.2$ was applied to both the gyroscope and accelerometer bias.
We repeated the integration at $\bar{\mathbf{b}}\_{i}+\delta\mathbf{b}\_{i}$ to obtain $\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}\_{i}+\delta\mathbf{b}\_{i}),\Delta\tilde{\mathbf{v}}\_{ij}(\bar{\mathbf{b}}\_{i}+\delta\mathbf{b}\_{i})$ and $\Delta\tilde{\mathbf{p}}\_{ij}(\bar{\mathbf{b}}\_{i}+\delta\mathbf{b}\_{i})$.
This ground-truth result was then compared against the first-order correction in ([44](#S6.E44 "In VI-C Incorporating Bias Updates ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) to compute the error of the approximation. The errors resulting from the first-order approximation are negligible, even for relatively large
bias perturbations.

#### VIII-A5 Advantages over the Euler-angle-based formulation

In this section we compare the proposed IMU preintegration with the original formulation of [[2](#bib.bib2)], based
on Euler angles.
We observe three main problems with the preintegration using Euler angles, which are avoided in our formulation.

The first drawback is that, in contrast to the integration using the exponential map in Eq. ([30](#S5.Ex7 "In V IMU Model and Motion Integration ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")),
the rotation integration based on Euler angles is only exact up to the first order. For the interested reader, we
recall the rotation rate integration using Euler angles in Appendix [IX-E](#Sx2.SS5 "IX-E Rotation Rate Integration Using Euler Angles ‣ Appendix ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").
On the left of Fig. [13](#S8.F13 "Fig. 13 ‣ VIII-A5 Advantages over the Euler-angle-based formulation ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"), we report the integration errors commited by the Euler angle parametrization
when integrating angular rates with randomly selected rotation axes and magnitude in the range from 1 to 3 rad/s.
Integration error in Euler angles accumulates quickly when
the sampling time $\Delta t$ or the angular rate $\tilde{\boldsymbol{\omega}}$ are large. On the other hand, the proposed
approach, which performs integration directly on the rotation manifold, is exact, regardless the values of $\Delta t$ and $\tilde{\boldsymbol{\omega}}$.

The second drawback is that the Euler parametrization is not *fair* [[64](#bib.bib64)], which means that, given the preintegrated Euler angles $\tilde{\boldsymbol{\theta}}$, the negative log-likelihood
${\cal L}(\boldsymbol{\theta})=\frac{1}{2}\|\tilde{\boldsymbol{\theta}}-\boldsymbol{\theta}\|^{2}\_{\Sigma}$ is not invariant under the action of rigid body transformations.
On the right of Fig. [13](#S8.F13 "Fig. 13 ‣ VIII-A5 Advantages over the Euler-angle-based formulation ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") we show experimentally how the log-likelihood changes when the frame of reference is rotated around randomly selected rotation axes.
This essentially means that an estimator using Euler angles may give different results for different choices of the
world frame (*cf.*with Fig. [2](#S4.F2 "Fig. 2 ‣ IV Maximum a Posteriori Visual-Inertial State Estimation ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")). On the other hand, the
$\mathrm{SO}(3)$ parametrization can be easily seen to be fair (the negative likelihood ([16](#S3.E16 "In III-B Uncertainty Description in SO(3) ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"))
can be promptly seen to be left invariant), and this is confirmed by Fig. [13](#S8.F13 "Fig. 13 ‣ VIII-A5 Advantages over the Euler-angle-based formulation ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") (right).

The third drawback is the existence of so-called *gimball lock* singularities.
For a $zyx$ Euler angle parametrization, the singularity is reached at pitch values of $\theta=\frac{\pi}{2}+n\pi$, for $n\in\mathbb{Z}$.
To evaluate the effect of the singularity and how it affects the computation of preintegrated measurement noise, we performed
the following Monte Carlo analysis.
We simulated a set of trajectories that reach maximum pitch values $\theta\_{\text{max}}$ of increasing magnitude.
For each trajectory, we integrate the rotation uncertainty using the Euler parametrization and the proposed on-manifold approach.
The ground-truth covariance is instead obtained through sampling. We use the Kullback-Leibler (KL) divergence to quantify the mismatch between the estimated covariances and the ground-truth one.
The results of this experiment are shown in Fig. [13](#S8.F13 "Fig. 13 ‣ VIII-A5 Advantages over the Euler-angle-based formulation ‣ VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"), where we observe that the closer we get to the singularity, the worse is the noise propagation using Euler angles.
On the other hand, the proposed approach can accurately estimate the measurement covariance,
independently on the motion of the platform.

Fig. 12: (a) Integration errors committed with the Euler angle parametrization for angular velocities $\boldsymbol{\omega}$ of increasing magnitude [rad/s]. (b) Negative log-likelihood of a rotation measurement under the action of random rigid body transformations.

Fig. 13: Kullback-Leibler divergence between the preintegrated rotation covariance –computed using Euler angles (red) and the proposed approach (blue)– and the ground-truth covariance. The Euler angle parametrization degrades close to the singularity at $\theta\_{\text{max}}=90$ deg while the proposed on-manifold approach is accurate regardless of the motion.

### VIII-B Real Experiments

We integrated the proposed inertial factors in a monocular VIO pipeline to benchmark its performance against the state of the art.
In the following, we first discuss our implementation, and then present results from an indoor experiment with motion-capture ground-truth.
Finally, we show results from longer trajectories in outdoor experiments.
The results confirm that our approach is more accurate than state-of-the-art filtering and fixed-lag smoothing algorithms, and enables fast inference in real-world problems.

#### VIII-B1 Implementation

Our implementation consists of a high frame rate tracking front-end based on SVO33
3
<http://github.com/uzh-rpg/rpg_svo> [[65](#bib.bib65)] and an optimization back-end based on iSAM2 [[3](#bib.bib3)]44
4
<http://borg.cc.gatech.edu>.
The front-end tracks salient features in the image at camera rate while the back-end optimizes in parallel the state of selected *keyframes* as described in this paper.

SVO [[65](#bib.bib65)] is a precise and robust monocular visual odometry system that employs *sparse image alignment* to estimate incremental motion and tracks features by minimizing the photometric error between subsequent frames.
The difference to tracking features individually, as in standard Lucas-Kanade tracking, is that we exploit the known depth of features from previous triangulations.
This allows us to track all features as a bundle in a single optimization that satisfies epipolar constraints; hence, outliers only originate from erroneous triangulations.
In the visual-inertial setting, we further exploit the availability of accurate rotation increments, obtained by integrating angular velocity measurements from the gyroscope.
These increments are used as rotation priors in the sparse-image-alignment algorithm, and this increases the overall robustness of the system.
The motion estimation is combined with an outlier resistant probabilistic triangulation method that is implemented with a recursive Bayesian filter. The high frame-rate motion estimation combined with the robust depth estimation results in increased robustness in scenes with repetitive and high frequency texture (*e.g.*, asphalt).
The output of SVO are selected keyframes with feature-tracks corresponding to triangulated landmarks.
This data is passed to the back-end that computes the visual-inertial MAP estimate in Eq. ([26](#S4.E26 "In IV-C Factor Graphs and MAP Estimation ‣ IV Maximum a Posteriori Visual-Inertial State Estimation ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) using iSAM2 [[3](#bib.bib3)].

We remark that our approach does not marginalize out past states. Therefore, while the approach is designed for fast visual-inertial
odometry, if desired, it could be readily extended to incorporate loop closures.

#### VIII-B2 Indoor Experiments

The indoor experiment shows that the proposed approach is more accurate than two competitive state-of-the-art approaches, namely
OKVIS55
5
<https://github.com/ethz-asl/okvis> [[24](#bib.bib24)], and MSCKF [[5](#bib.bib5)].
The experiment is performed on the 430m-long indoor trajectory of Fig. [16](#S8.F16 "Fig. 16 ‣ VIII-B2 Indoor Experiments ‣ VIII-B Real Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").
The dataset was recorded with a forward-looking VI-Sensor [[66](#bib.bib66)] that consists of an ADIS16448 MEMS IMU and two embedded WVGA monochrome cameras (we only use the left camera).
Intrinsic and extrinsic calibration was obtained using [[59](#bib.bib59)].
The camera runs at 20Hz and the IMU at 800Hz.
Ground truth poses are provided by a Vicon system mounted in the room; the *hand-eye* calibration between the Vicon markers and the camera is computed using a least-squares method [[67](#bib.bib67)].

Fig. 14: Left: two images from the indoor trajectory dataset with tracked features in green.
Right: top view of the trajectory estimate produced by our approach (blue) and 3D landmarks triangulated from the
trajectory (green).

Fig. 15: Comparison of the proposed approach
versus the OKVIS algorithm [[24](#bib.bib24)] and an implementation of the MSCKF filter [[5](#bib.bib5)].
Relative errors are measured over different segments of the trajectory, of length $\{10,40,90,160,250,360\}$m, according to the
odometric error metric in [[68](#bib.bib68)].

Fig. 16: Processing-time per keyframe for the proposed VIO approach.

Fig.  [16](#S8.F16 "Fig. 16 ‣ VIII-B2 Indoor Experiments ‣ VIII-B Real Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") compares the proposed system against the OKVIS algorithm [[24](#bib.bib24)], and an implementation of the MSCKF filter [[5](#bib.bib5)].
Both these algorithms currently represent the state-of-the-art in VIO, OKVIS for optimization-based approaches, and MSCKF for filtering methods.
We obtained the datasets as well as the trajectories computed with OKVIS and MSCKF from the authors of [[24](#bib.bib24)].
We use the relative error metrics proposed in [[68](#bib.bib68)] to obtain error statistics.
The metric evaluates the relative error by averaging the drift over trajectory segments of different length ($\{10,40,90,160,250,360\}$m in Fig.  [16](#S8.F16 "Fig. 16 ‣ VIII-B2 Indoor Experiments ‣ VIII-B Real Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
Our approach exhibits less drift than the state-of-the-art, achieving $0.3$m drift on average over 360m traveled distance; OKVIS and MSCKF accumulate an average error of $0.7$m.
We observe significantly less drift in yaw direction in the proposed approach while the error in pitch and and roll direction is constant for all methods due to the observability of the gravity direction.

Fig. 17: Orientation and position errors with 3$\sigma$ bounds for the real indoor experiment in Fig. [16](#S8.F16 "Fig. 16 ‣ VIII-B2 Indoor Experiments ‣ VIII-B Real Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").

We highlight that these three algorithms use different front-end feature tracking systems, which influence the overall performance of the approach. Therefore, while in Section [VIII-A](#S8.SS1 "VIII-A Simulation Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")
we discussed only aspects related to the preintegration theory, in this section we evaluate the proposed system as a whole
(SVO, preintegration, structureless vision factors, iSAM2).

Evaluating consistency in real experiments by means of analysing the average NEES is difficult as one would have to evalate and average the results of multiple runs of the same trajectory with different realizations of sensor noise.
In Figure [17](#S8.F17 "Fig. 17 ‣ VIII-B2 Indoor Experiments ‣ VIII-B Real Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") we show the error plots with the 3-sigma bounds for a single run.
The result is consistent as the estimation errors remain within the bounds of the estimated uncertainty.
In this experiment, we aligned only the first frame of the trajectory with the vicon trajectory. Therefore, analyzing the drift over 400 meters is very prone to errors in the initial pose from the ground-truth or errors in the hand-eye calibration of the system.

Figure [16](#S8.F16 "Fig. 16 ‣ VIII-B2 Indoor Experiments ‣ VIII-B Real Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") illustrates the time required by the back-end to compute the full MAP estimate, by running iSAM2 with 10 optimization iterations.
The experiment was performed on a standard laptop (Intel i7, 2.4 GHz).
The average update time for iSAM2 is $10$ms.
The peak corresponds to the start of the experiment in which the camera was not moving.
In this case the number of tracked features becomes very large making the back-end slightly slower.
The SVO front-end requires approximately $3$ms to process a frame on the laptop while the back-end runs in a parallel thread and optimizes only keyframes.
Although the processing times of OKVIS were not reported, the approach is described as computationally demanding [[24](#bib.bib24)].
OKVIS needs to repeat IMU integration at every change of the linearization point, which we avoid by using the preintegrated IMU measurements.

Fig. 18: Outdoor trajectory (length: $300\rm{m}$) around a building with identical start and end point at coordinates $(0,0,0)$. The end-to-end error of the proposed approach is $1.0\rm{m}$. Google Tango accumulated $2.2\rm{m}$ drift. The green dots are the 3D points triangulated from our trajectory estimate.

Fig. 19: 
Real test comparing the proposed VIO approach against Google Tango.
The $160$m-long trajectory starts at $(0,0,0)$ (ground floor), goes up till the 3rd floor of a building, and
returns to the initial point. The figure shows a side view (left) and a top view (right)
of the trajectory estimates for our approach (blue) and Tango (red).
Google Tango accumulates $1.4$m error, while the proposed approach only
has $0.5$m drift. 3D points triangulated from our trajectory estimate are shown in green for
visualization purposes.

#### VIII-B3 Outdoor Experiments

The second experiment is performed on an outdoor trajectory, and compares the proposed approach against the *Google* Tango *Peanut* sensor (mapper version 3.15), which is an *engineered* VIO system.
We rigidly attached the VI-Sensor to a Tango device and walked around an office building.
Fig. [18](#S8.F18 "Fig. 18 ‣ VIII-B2 Indoor Experiments ‣ VIII-B Real Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") depicts the trajectory estimates for our approach and Google Tango.
The trajectory starts and ends at the same location, hence we can report the end-to-end error which is 1.5m for the proposed approach and 2.2m for the Google Tango sensor.

In Fig. [18](#S8.F18 "Fig. 18 ‣ VIII-B2 Indoor Experiments ‣ VIII-B Real Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry") we also show the estimated landmark positions (in green).
3D points are not estimated by our approach (which uses a structureless vision model), but are triangulated from our trajectory estimate for visualization purposes.

The third experiment is the one in Fig.  [19](#S8.F19 "Fig. 19 ‣ VIII-B2 Indoor Experiments ‣ VIII-B Real Experiments ‣ VIII Experimental Analysis ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").
The trajectory goes across three floors of an office building and eventually returns to the initial location on the ground floor.
Also in this case the proposed approach guarantees a very small end-to-end error ($0.5$m), while Tango accumulates $1.4$m error.

We remark that Tango and our system use different sensors, hence the reported end-to-end errors only allow for a qualitative comparison.
However, the IMUs of both sensors exhibit similar noise characteristics [[69](#bib.bib69), [70](#bib.bib70)] and the Tango camera has a significantly larger field-of-view and better shutter speed control than our sensor.
Therefore, the comparison is still valuable to assess the accuracy of the proposed approach.

A video demonstrating the execution of our approach for the real experiments discussed in this section can be viewed at <https://youtu.be/CsJkci5lfco>

## IX Conclusion

This paper proposes a novel preintegration theory, which provides a grounded way to model a large number of IMU measurements as a single motion constraint.
Our proposal improves over related works that perform integration in a global frame, e.g., [[23](#bib.bib23), [5](#bib.bib5)], as we do not commit to a linearization point during integration.
Moreover, it leverages the seminal work on preintegration [[2](#bib.bib2)], bringing to maturity the preintegration and uncertainty propagation in $\mathrm{SO}(3)$.

As a second contribution, we discuss how to use the preintegrated IMU model in a VIO pipeline; we adopt a structureless model for visual measurements which avoids optimizing over 3D landmarks.
Our VIO approach uses iSAM2 to perform constant-time incremental smoothing.

An efficient implementation of our approach requires $10$ms to perform inference (back-end), and $3$ms for feature tracking (front-end). Experimental results also confirm that our approach is more accurate than state-of-the-art alternatives, including filtering and optimization-based techniques.

We release the source-code of the IMU preintegration and the structurless vision factors in the GTSAM 4.0 optimization toolbox [[7](#bib.bib7)] and provide additional theoretical derivations and implementation details in the Appendix of this paper.

Acknowledgments
The authors gratefully acknowledge Stephen Williams and Richard Roberts
for helping with an early implementation in GTSAM, and Simon Lynen and Stefan Leutenegger for providing datasets and results of their algorithms.
Furthermore, we are thankful to Mingyu Chen for the detailed comments and suggestions on the previous version of this paper.

## Appendix

### IX-A Iterative Noise Propagation

In this section we show that the computation of the preintegrated noise
covariance, discussed in
Section [VI-B](#S6.SS2 "VI-B Noise Propagation ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"), can be carried out in iterative form,
which leads to simpler expressions and is more amenable for online inference.

Let us start from the preintegrated rotation noise in ([42](#S6.E42 "In VI-B Noise Propagation ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
To write $\delta\boldsymbol{\phi}\_{ij}$ in iterative form, we simply take the last term ($k=j-1$) out of the sum and rearrange the terms:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\delta\boldsymbol{\phi}\_{ij}$ | $\displaystyle\simeq\sum\_{k=i}^{j-1}\Delta\tilde{\mathtt{R}}\_{k+1j}^{\mathsf{T}}\mathtt{J}^{k}\_{r}\boldsymbol{\eta}^{gd}\_{k}\Delta t$ |  | (59) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{k=i}^{j-2}\Delta\tilde{\mathtt{R}}\_{k+1j}^{\mathsf{T}}\mathtt{J}^{k}\_{r}\boldsymbol{\eta}^{gd}\_{k}\Delta t+\overbrace{\Delta\tilde{\mathtt{R}}\_{jj}^{\mathsf{T}}}^{={\mathbf{I}}\_{3\times 3}}\mathtt{J}\_{r}^{j-1}\boldsymbol{\eta}^{gd}\_{j-1}\Delta t$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{k=i}^{j-2}(\overbrace{\Delta\tilde{\mathtt{R}}\_{k+1j-1}\Delta\tilde{\mathtt{R}}\_{j-1j}}^{=\Delta\tilde{\mathtt{R}}\_{k+1j}})^{\mathsf{T}}\mathtt{J}^{k}\_{r}\boldsymbol{\eta}^{gd}\_{k}\Delta t+\mathtt{J}\_{r}^{j-1}\boldsymbol{\eta}^{gd}\_{j-1}\Delta t$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\Delta\tilde{\mathtt{R}}\_{j-1j}^{\mathsf{T}}\sum\_{k=i}^{j-2}\Delta\tilde{\mathtt{R}}\_{k+1j-1}^{\mathsf{T}}\mathtt{J}^{k}\_{r}\boldsymbol{\eta}^{gd}\_{k}\Delta t+\mathtt{J}\_{r}^{j-1}\boldsymbol{\eta}^{gd}\_{j-1}\Delta t$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\Delta\tilde{\mathtt{R}}\_{j-1j}^{\mathsf{T}}\delta\boldsymbol{\phi}\_{ij-1}+\mathtt{J}\_{r}^{j-1}\boldsymbol{\eta}^{gd}\_{j-1}\Delta t.$ |  |

Repeating the same process for $\delta\mathbf{v}\_{ij}$ in ([43](#S6.E43 "In VI-B Noise Propagation ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")):

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\delta\mathbf{v}\_{ij}$ | $\displaystyle=\sum\_{k=i}^{j-1}\left[-\Delta\tilde{\mathtt{R}}\_{ik}\left(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{i}\right)^{\wedge}\delta\boldsymbol{\phi}\_{ik}\Delta t+\Delta\tilde{\mathtt{R}}\_{ik}\boldsymbol{\eta}^{ad}\_{k}\Delta t\right]$ |  | (60) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{k=i}^{j-2}\left[-\Delta\tilde{\mathtt{R}}\_{ik}\left(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{i}\right)^{\wedge}\delta\boldsymbol{\phi}\_{ik}\Delta t+\Delta\tilde{\mathtt{R}}\_{ik}\boldsymbol{\eta}^{ad}\_{k}\Delta t\right]$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\hskip 9.24994pt\ -\!\Delta\tilde{\mathtt{R}}\_{ij-1}\left(\tilde{\mathbf{a}}\_{j-1}\!-\!\mathbf{b}^{a}\_{i}\right)^{\wedge}\delta\boldsymbol{\phi}\_{i{j-1}}\Delta t+\Delta\tilde{\mathtt{R}}\_{i{j-1}}\boldsymbol{\eta}^{ad}\_{j-1}\Delta t$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\!\!\!\!\!\!=\delta\mathbf{v}\_{ij-1}\!-\!\Delta\tilde{\mathtt{R}}\_{ij-1}\left(\tilde{\mathbf{a}}\_{j-1}\!-\!\mathbf{b}^{a}\_{i}\right)^{\wedge}\delta\boldsymbol{\phi}\_{i{j-1}}\Delta t\!+\!\Delta\tilde{\mathtt{R}}\_{i{j-1}}\boldsymbol{\eta}^{ad}\_{j-1}\Delta t$ |  |

Doing the same for $\delta\mathbf{p}\_{ij}$ in ([43](#S6.E43 "In VI-B Noise Propagation ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")),
and noting that $\delta\mathbf{p}\_{ij}$ can be written as a function of $\delta\mathbf{v}\_{ij}$
(*cf.*with the expression of $\delta\mathbf{v}\_{ij}$ in ([43](#S6.E43 "In VI-B Noise Propagation ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"))):

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\delta\mathbf{p}\_{ij}\!=\!\sum\_{k=i}^{j-1}\!\left[\delta\mathbf{v}\_{ik}\Delta t\!-\!\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{ik}\left(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{i}\right)^{\wedge}\delta\boldsymbol{\phi}\_{ik}\Delta t^{2}\!+\!\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{ik}\boldsymbol{\eta}^{ad}\_{k}\Delta t^{2}\!\right]$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{k=i}^{j-2}\left[\delta\mathbf{v}\_{ik}\Delta t-\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{ik}\left(\tilde{\mathbf{a}}\_{k}\!-\!\mathbf{b}^{a}\_{i}\right)^{\wedge}\delta\boldsymbol{\phi}\_{ik}\Delta t^{2}+\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{ik}\boldsymbol{\eta}^{ad}\_{k}\Delta t^{2}\right]$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle+\!\delta\mathbf{v}\_{ij-1}\Delta t\!-\!\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{ij-1}\!\left(\tilde{\mathbf{a}}\_{j-1}\!-\!\mathbf{b}^{a}\_{i}\right)^{\wedge}\!\delta\boldsymbol{\phi}\_{ij-1}\Delta t^{2}\!+\!\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{i{j-1}}\boldsymbol{\eta}^{ad}\_{j-1}\Delta t^{2}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\delta\mathbf{p}\_{ij-1}+\delta\mathbf{v}\_{ij-1}\Delta t-\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{ij-1}\left(\tilde{\mathbf{a}}\_{j-1}\!-\!\mathbf{b}^{a}\_{i}\right)^{\wedge}\delta\boldsymbol{\phi}\_{ij-1}\Delta t^{2}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\hskip 9.24994pt\hskip 9.24994pt\hskip 9.24994pt\hskip 9.24994pt\ +\frac{1}{2}\Delta\tilde{\mathtt{R}}\_{i{j-1}}\boldsymbol{\eta}^{ad}\_{j-1}\Delta t^{2}$ |  | (61) |

Recalling that $\boldsymbol{\eta}^{\Delta}\_{ik}\doteq[\delta\boldsymbol{\phi}\_{ik},\delta\mathbf{v}\_{ik},\delta\mathbf{p}\_{ik}]$,
and defining the IMU measurement noise $\boldsymbol{\eta}^{d}\_{k}\doteq[\boldsymbol{\eta}^{gd}\_{k}\;\;\boldsymbol{\eta}^{ad}\_{k}]$,66
6
Both
$\boldsymbol{\eta}^{\Delta}\_{ij}$ and $\boldsymbol{\eta}^{d}\_{k}$ are column vectors: we omit the transpose in the definition
to keep notation simple.
we can finally write Eqs. ([59](#Sx2.E59 "In IX-A Iterative Noise Propagation ‣ Appendix ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry"))-([61](#Sx2.Ex41 "In IX-A Iterative Noise Propagation ‣ Appendix ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) in compact matrix form as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\boldsymbol{\eta}^{\Delta}\_{ij}=\mathbf{A}\_{j-1}\boldsymbol{\eta}^{\Delta}\_{ij-1}+\mathbf{B}\_{j-1}\boldsymbol{\eta}^{d}\_{j-1},$ |  | (62) |

From the linear model ([62](#Sx2.E62 "In IX-A Iterative Noise Propagation ‣ Appendix ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) and given the covariance $\mathbf{\Sigma}\_{\boldsymbol{\eta}}\in\mathbb{R}^{6\times 6}$ of
the raw IMU measurements noise $\boldsymbol{\eta}^{d}\_{k}$,
it is now possible to compute the preintegrated measurement covariance iteratively:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{\Sigma}\_{ij}=\mathbf{A}\_{j-1}\mathbf{\Sigma}\_{ij-1}\mathbf{A}\_{j-1}^{\mathsf{T}}+\mathbf{B}\_{j-1}\mathbf{\Sigma}\_{\boldsymbol{\eta}}\mathbf{B}\_{j-1}^{\mathsf{T}}$ |  | (63) |

starting from initial conditions $\mathbf{\Sigma}\_{ii}=\mathbf{0}\_{9\times 9}$.

### IX-B Bias Correction via First-Order Updates

In this section we provide a complete derivation of the first-order bias correction
proposed in Section [VI-C](#S6.SS3 "VI-C Incorporating Bias Updates ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").

Let us assume that we have computed the preintegrated variables
at a given bias estimate $\bar{\mathbf{b}}\_{i}\doteq[\bar{\mathbf{b}}^{g}\_{i}\;\;\bar{\mathbf{b}}^{a}\_{i}]$,
and let us denote the corresponding preintegrated measurements as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta\bar{\mathtt{R}}\_{ij}\doteq\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}\_{i}),\ \Delta\bar{\mathbf{v}}\_{ij}\doteq\Delta\tilde{\mathbf{v}}\_{ij}(\bar{\mathbf{b}}\_{i}),\ \Delta\bar{\mathbf{p}}\_{ij}\doteq\Delta\tilde{\mathbf{p}}\_{ij}(\bar{\mathbf{b}}\_{i}).$ |  | (64) |

In this section we want to devise an expression to “update” $\Delta\bar{\mathtt{R}}\_{ij}$, $\Delta\bar{\mathbf{v}}\_{ij}$, $\Delta\bar{\mathbf{p}}\_{ij}$ when our bias estimate changes.

Consider the case in which we get a new estimate $\hat{\mathbf{b}}\_{i}\leftarrow\bar{\mathbf{b}}\_{i}+\delta\mathbf{b}\_{i}$,
where $\delta\mathbf{b}\_{i}$ is a *small* correction w.r.t. the previous estimate $\bar{\mathbf{b}}\_{i}$.

We start with the bias correction for the preintegrated rotation measurement.
The key idea here is to write $\Delta\tilde{\mathtt{R}}\_{ij}(\hat{\mathbf{b}}\_{i})$ (the preintegrated measurement
at the new bias estimate) as a function of $\Delta\bar{\mathtt{R}}\_{ij}$ (the preintegrated
measurement at the old bias estimate), “plus” a first-order correction.
Recalling Eq. ([35](#S6.E35 "In VI-A Preintegrated IMU Measurements ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")),
we write $\Delta\tilde{\mathtt{R}}\_{ij}(\hat{\mathbf{b}}\_{i})$ as:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\tilde{\mathtt{R}}\_{ij}(\hat{\mathbf{b}}\_{i})$ | $\displaystyle=\prod\_{k=i}^{j-1}\mathrm{Exp}\left(\left(\tilde{\boldsymbol{\omega}}\_{k}-\hat{\mathbf{b}}^{g}\_{i}\right)\Delta t\right)$ |  | (65) |

Substituting $\hat{\mathbf{b}}\_{i}=\bar{\mathbf{b}}\_{i}+\delta\mathbf{b}\_{i}$ in the previous expression and using
the first-order approximation ([4](#S3.E4 "In Special Orthogonal Group ‣ III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) in each factor
(we assumed small $\delta\mathbf{b}\_{i}$):

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\tilde{\mathtt{R}}\_{ij}(\hat{\mathbf{b}}\_{i})$ | $\displaystyle=\prod\_{k=i}^{j-1}\mathrm{Exp}\left(\left(\tilde{\boldsymbol{\omega}}\_{k}-(\bar{\mathbf{b}}^{g}\_{i}+\delta\mathbf{b}^{g}\_{i})\right)\Delta t\right)$ |  | (66) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\simeq\prod\_{k=i}^{j-1}\mathrm{Exp}\left(\left(\tilde{\boldsymbol{\omega}}\_{k}-\bar{\mathbf{b}}^{g}\_{i}\right)\Delta t\right)\mathrm{Exp}\left(-\mathtt{J}^{k}\_{r}\;\delta\mathbf{b}^{g}\_{i}\;\Delta t\right).$ |  |

Now, we rearrange the terms in the product, by “moving” the terms including $\delta\mathbf{b}^{gd}\_{i}$ to the end, using the relation ([11](#S3.E11 "In Special Orthogonal Group ‣ III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta\tilde{\mathtt{R}}\_{ij}(\hat{\mathbf{b}}\_{i})\!=\!\Delta\bar{\mathtt{R}}\_{ij}\prod\_{k=i}^{j-1}\mathrm{Exp}\left(\ -\Delta\tilde{\mathtt{R}}\_{k+1j}(\bar{\mathbf{b}}\_{i})^{\mathsf{T}}\mathtt{J}^{k}\_{r}\;\delta\mathbf{b}^{g}\_{i}\;\Delta t\right),$ |  | (67) |

where we used the fact that by definition it holds that
$\Delta\bar{\mathtt{R}}\_{ij}=\prod\_{k=i}^{j-1}\mathrm{Exp}\left(\left(\tilde{\boldsymbol{\omega}}\_{k}-\bar{\mathbf{b}}^{g}\_{i}\right)\Delta t\right)$.
Repeated application of the first-order approximation ([7](#S3.E7 "In Special Orthogonal Group ‣ III-A Notions of Riemannian geometry ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) (recall that $\delta\mathbf{b}^{g}\_{i}$ is small, hence the right Jacobians are close to the identity) produces:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta\tilde{\mathtt{R}}\_{ij}(\hat{\mathbf{b}}\_{i})$ | $\displaystyle\simeq\Delta\bar{\mathtt{R}}\_{ij}\mathrm{Exp}\left(\sum\_{k=i}^{j-1}-\Delta\tilde{\mathtt{R}}\_{k+1j}(\bar{\mathbf{b}}\_{i})^{\mathsf{T}}\mathtt{J}^{k}\_{r}\delta\mathbf{b}^{g}\_{i}\Delta t\right)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\Delta\bar{\mathtt{R}}\_{ij}\mathrm{Exp}\Big(\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}}\delta\mathbf{b}^{g}\_{i}\Big)$ |  | (68) |

Using ([68](#Sx2.Ex46 "In IX-B Bias Correction via First-Order Updates ‣ Appendix ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) we can now update the preintegrated rotation measurement
$\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}\_{i})$ to get $\Delta\tilde{\mathtt{R}}\_{ij}(\hat{\mathbf{b}}\_{i})$ without repeating the integration.

Let us now focus on the bias correction of the preintegrated velocity $\Delta\tilde{\mathbf{v}}\_{ij}(\hat{\mathbf{b}}\_{i})$:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\Delta\tilde{\mathbf{v}}\_{ij}(\hat{\mathbf{b}}\_{i})=\sum\_{k=i}^{j-1}\Delta\tilde{\mathtt{R}}\_{ik}(\hat{\mathbf{b}}\_{i})\left(\tilde{\mathbf{a}}\_{k}-\bar{\mathbf{b}}^{a}\_{i}-\delta\mathbf{b}^{a}\_{i}\right)\Delta t$ |  | (69) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\!\!\stackrel{{\scriptstyle\eqref{eq:updateR}}}{{\simeq}}\sum\limits\_{k=i}^{j-1}\Delta\bar{\mathtt{R}}\_{ik}\mathrm{Exp}\Big(\frac{\partial\Delta\bar{\mathtt{R}}\_{ik}}{\partial\mathbf{b}^{g}}\delta\mathbf{b}^{g}\_{i}\Big)\left(\tilde{\mathbf{a}}\_{k}-\bar{\mathbf{b}}^{a}\_{i}-\delta\mathbf{b}^{a}\_{i}\right)\Delta t$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\!\!\stackrel{{\scriptstyle\eqref{eq:expFirstOrder}}}{{\simeq}}\sum\limits\_{k=i}^{j-1}\Delta\bar{\mathtt{R}}\_{ik}\left({\mathbf{I}}+\Big(\frac{\partial\Delta\bar{\mathtt{R}}\_{ik}}{\partial\mathbf{b}^{g}}\delta\mathbf{b}^{g}\_{i}\Big)^{\wedge}\right)\left(\tilde{\mathbf{a}}\_{k}-\bar{\mathbf{b}}^{a}\_{i}-\delta\mathbf{b}^{a}\_{i}\right)\Delta t$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\!\!\stackrel{{\scriptstyle(a)}}{{\simeq}}\Delta\bar{\mathbf{v}}\_{ij}-\sum\_{k=i}^{j-1}\Delta\bar{\mathtt{R}}\_{ik}\Delta t\delta\mathbf{b}^{a}\_{i}+\sum\_{k=i}^{j-1}\Delta\bar{\mathtt{R}}\_{ik}\Big(\frac{\partial\Delta\bar{\mathtt{R}}\_{ik}}{\partial\mathbf{b}^{g}}\delta\mathbf{b}^{g}\_{i}\Big)^{\wedge}\left(\tilde{\mathbf{a}}\_{k}-\bar{\mathbf{b}}^{a}\_{i}\right)\Delta t$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\!\!\stackrel{{\scriptstyle\eqref{eq:skewProperty}}}{{=}}\Delta\bar{\mathbf{v}}\_{ij}-\sum\_{k=i}^{j-1}\Delta\bar{\mathtt{R}}\_{ik}\Delta t\delta\mathbf{b}^{a}\_{i}-\sum\_{k=i}^{j-1}\Delta\bar{\mathtt{R}}\_{ik}\left(\tilde{\mathbf{a}}\_{k}-\bar{\mathbf{b}}^{a}\_{i}\right)^{\wedge}\frac{\partial\Delta\bar{\mathtt{R}}\_{ik}}{\partial\mathbf{b}^{g}}\Delta t\;\delta\mathbf{b}^{g}\_{i}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\!\!=\Delta\bar{\mathbf{v}}\_{ij}+\frac{\partial\Delta\bar{\mathbf{v}}\_{ij}}{\partial\mathbf{b}^{a}}\delta\mathbf{b}^{a}\_{i}+\frac{\partial\Delta\bar{\mathbf{v}}\_{ij}}{\partial\mathbf{b}^{g}}\delta\mathbf{b}^{g}\_{i}$ |  |

Where for $(a)$, we used $\Delta\bar{\mathbf{v}}\_{ij}=\sum\_{k=i}^{j-1}\Delta\bar{\mathtt{R}}\_{ik}\left(\tilde{\mathbf{a}}\_{k}-\bar{\mathbf{b}}^{a}\_{i}\right)\Delta t$.
Exactly the same derivation can be repeated for $\Delta\tilde{\mathbf{p}}\_{ij}(\hat{\mathbf{b}}\_{i})$.
Summarizing, the Jacobians used for the a posteriori bias update in Eq.  ([44](#S6.E44 "In VI-C Incorporating Bias Updates ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) are:

|  |  |  |
| --- | --- | --- |
|  | $\begin{array}[]{ccl}\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}}&=&-\sum\_{k=i}^{j-1}\left[\Delta\tilde{\mathtt{R}}\_{k+1j}(\bar{\mathbf{b}}\_{i})^{\mathsf{T}}\;\mathtt{J}^{k}\_{r}\;\Delta t\right]\\ \frac{\partial\Delta\bar{\mathbf{v}}\_{ij}}{\partial\mathbf{b}^{a}}&=&-\sum\_{k=i}^{j-1}\Delta\bar{\mathtt{R}}\_{ik}\Delta t\\ \frac{\partial\Delta\bar{\mathbf{v}}\_{ij}}{\partial\mathbf{b}^{g}}&=&-\sum\_{k=i}^{j-1}\Delta\bar{\mathtt{R}}\_{ik}\left(\tilde{\mathbf{a}}\_{k}-\bar{\mathbf{b}}^{a}\_{i}\right)^{\wedge}\frac{\partial\Delta\bar{\mathtt{R}}\_{ik}}{\partial\mathbf{b}^{g}}\Delta t\\ \frac{\partial\Delta\bar{\mathbf{p}}\_{ij}}{\partial\mathbf{b}^{a}}&=&\sum\_{k=i}^{j-1}\frac{\partial\Delta\bar{\mathbf{v}}\_{ik}}{\partial\mathbf{b}^{a}}\Delta t-\frac{1}{2}\Delta\bar{\mathtt{R}}\_{ik}\Delta t^{2}\\ \frac{\partial\Delta\bar{\mathbf{p}}\_{ij}}{\partial\mathbf{b}^{g}}&=&\sum\_{k=i}^{j-1}\frac{\partial\Delta\bar{\mathbf{v}}\_{ik}}{\partial\mathbf{b}^{g}}\Delta t-\frac{1}{2}\Delta\bar{\mathtt{R}}\_{ik}\left(\tilde{\mathbf{a}}\_{k}-\bar{\mathbf{b}}^{a}\_{i}\right)^{\wedge}\frac{\partial\Delta\bar{\mathtt{R}}\_{ik}}{\partial\mathbf{b}^{g}}\Delta t^{2}\end{array}$ |  |

Note that the Jacobians can be computed incrementally, as new measurements arrive.

### IX-C Jacobians of Residual Errors

In this section we provide analytic expressions for the Jacobian matrices of the
residual errors in Eq.  ([45](#S6.Ex33 "In VI-D Preintegrated IMU Factors ‣ VI IMU Preintegration on Manifold ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
These Jacobians are crucial when using iterative optimization techniques (e.g.,
the Gauss-Newton method of Section [III-C](#S3.SS3 "III-C Gauss-Newton Method on Manifold ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) to minimize the cost in Eq. ([26](#S4.E26 "In IV-C Factor Graphs and MAP Estimation ‣ IV Maximum a Posteriori Visual-Inertial State Estimation ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).

“Lifting” the cost function (see Section [III-C](#S3.SS3 "III-C Gauss-Newton Method on Manifold ‣ III Preliminaries ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) consists in substituting the following retractions:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{array}[]{rclrcl}\mathtt{R}\_{i}&\leftarrow&\mathtt{R}\_{i}\ \mathrm{Exp}(\delta\boldsymbol{\phi}\_{i}),&\mathtt{R}\_{j}&\leftarrow&\mathtt{R}\_{j}\ \mathrm{Exp}(\delta\boldsymbol{\phi}\_{j}),\\ \mathbf{p}\_{i}&\leftarrow&\mathbf{p}\_{i}+\mathtt{R}\_{i}\delta\mathbf{p}\_{i},&\mathbf{p}\_{j}&\leftarrow&\mathbf{p}\_{j}+\mathtt{R}\_{j}\delta\mathbf{p}\_{j},\\ \mathbf{v}\_{i}&\leftarrow&\mathbf{v}\_{i}+\delta\mathbf{v}\_{i},&\mathbf{v}\_{j}&\leftarrow&\mathbf{v}\_{j}+\delta\mathbf{v}\_{i},\\ \delta\mathbf{b}^{g}\_{i}&\leftarrow&\delta\mathbf{b}^{g}\_{i}+\tilde{\delta}{\mathbf{b}^{g}\_{i}},&\delta\mathbf{b}^{a}\_{i}&\leftarrow&\delta\mathbf{b}^{a}\_{i}+\tilde{\delta}{\mathbf{b}^{a}\_{i}},\\ \end{array}$ |  | (70) |

The process of lifting makes the residual errors a function defined on a vector space, on which it is easy to compute Jacobians.
Therefore, in the following sections we derive the Jacobians w.r.t. the vectors $\delta\boldsymbol{\phi}\_{i},\delta\mathbf{p}\_{i},\delta\mathbf{v}\_{i},\delta\boldsymbol{\phi}\_{j},\delta\mathbf{p}\_{j},\delta\mathbf{v}\_{j},\tilde{\delta}{\mathbf{b}^{g}\_{i}},\tilde{\delta}{\mathbf{b}^{a}\_{i}}$.

#### IX-C1 Jacobians of $\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}$

Since $\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}$ is linear in $\delta\mathbf{b}^{g}\_{i}$ and $\delta\mathbf{b}^{a}\_{i}$,
and the retraction is simply a vector sum, the Jacobians of $\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}$ w.r.t. $\tilde{\delta}{\mathbf{b}^{g}\_{i}},\tilde{\delta}{\mathbf{b}^{a}\_{i}}$ are simply the matrix coefficients of $\delta\mathbf{b}^{g}\_{i}$ and $\delta\mathbf{b}^{a}\_{i}$.
Moreover, $\mathtt{R}\_{j}$ and $\mathbf{v}\_{j}$ do not appear in $\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}$, hence the Jacobians w.r.t. $\delta\boldsymbol{\phi}\_{j},\delta\mathbf{v}\_{j}$ are zero.
Let us focus on the remaining Jacobians:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}(\mathbf{p}\_{i}\!+\!\mathtt{R}\_{i}\delta\mathbf{p}\_{i})$ | $\displaystyle=\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{p}\_{j}\!-\!\mathbf{p}\_{i}\!-\!\mathtt{R}\_{i}\delta\mathbf{p}\_{i}\!-\!\mathbf{v}\_{i}\Delta t\_{ij}\!-\!\frac{1}{2}\mathbf{g}\Delta t\_{ij}^{2}\right)\!-\!C$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}(\mathbf{p}\_{i})+(-{\mathbf{I}}\_{3\times 1})\delta\mathbf{p}\_{i}$ |  | (71) |

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}(\mathbf{p}\_{j}\!+\!\mathtt{R}\_{j}\delta\mathbf{p}\_{j})$ | $\displaystyle=\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{p}\_{j}\!+\!\mathtt{R}\_{j}\delta\mathbf{p}\_{j}\!-\!\mathbf{p}\_{i}\!-\!\mathbf{v}\_{i}\Delta t\_{ij}\!-\!\frac{1}{2}\mathbf{g}\Delta t\_{ij}^{2}\right)\!-\!C$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}(\mathbf{p}\_{j})+(\mathtt{R}\_{i}^{\mathsf{T}}\mathtt{R}\_{j})\delta\mathbf{p}\_{j}$ |  | (72) |

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}(\mathbf{v}\_{i}\!+\!\delta\mathbf{v}\_{i})$ | $\displaystyle=\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{p}\_{j}\!-\!\mathbf{p}\_{i}\!-\!\mathbf{v}\_{i}\Delta t\_{ij}\!-\!\delta\mathbf{v}\_{i}\Delta t\_{ij}\!-\!\frac{1}{2}\mathbf{g}\Delta t\_{ij}^{2}\right)\!-\!C$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}(\mathbf{v}\_{i})+(-\mathtt{R}\_{i}^{\mathsf{T}}\Delta t\_{ij})\delta\mathbf{v}\_{i}$ |  | (73) |

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}$ | $\displaystyle(\mathtt{R}\_{i}\;\mathrm{Exp}(\delta\boldsymbol{\phi}\_{i}))$ |  | (74) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=(\mathtt{R}\_{i}\mathrm{Exp}(\delta\boldsymbol{\phi}\_{i}))^{\mathsf{T}}\left(\mathbf{p}\_{j}-\mathbf{p}\_{i}-\mathbf{v}\_{i}\Delta t\_{ij}-\frac{1}{2}\mathbf{g}\Delta t\_{ij}^{2}\right)-C$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\stackrel{{\scriptstyle\eqref{eq:expFirstOrder}}}{{\simeq}}({\mathbf{I}}-\delta\boldsymbol{\phi}\_{i}^{\wedge})\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{p}\_{j}-\mathbf{p}\_{i}-\mathbf{v}\_{i}\Delta t\_{ij}-\frac{1}{2}\mathbf{g}\Delta t\_{ij}^{2}\right)-C$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\stackrel{{\scriptstyle\eqref{eq:skewProperty}}}{{=}}\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}(\mathtt{R}\_{i})+\left(\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{p}\_{j}-\mathbf{p}\_{i}-\mathbf{v}\_{i}\Delta t\_{ij}-\frac{1}{2}\mathbf{g}\Delta t\_{ij}^{2}\right)\right)^{\wedge}\delta\boldsymbol{\phi}\_{i}.$ |  |

Where we used the shorthand
$C\doteq\Delta\tilde{\mathbf{p}}\_{ij}+\frac{\partial\Delta\bar{\mathbf{p}}\_{ij}}{\partial\mathbf{b}^{g}\_{i}}\delta\mathbf{b}^{g}\_{i}+\frac{\partial\Delta\bar{\mathbf{p}}\_{ij}}{\partial\mathbf{b}^{a}\_{i}}\delta\mathbf{b}^{a}\_{i}$.
Summarizing, the Jacobians of $\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}$ are:

|  |  |  |
| --- | --- | --- |
|  | $\begin{array}[]{ll}\frac{\partial\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}}{\partial\delta\boldsymbol{\phi}\_{i}}=(\mathtt{R}\_{i}^{\mathsf{T}}\!(\mathbf{p}\_{j}\!-\!\mathbf{p}\_{i}\!-\!\mathbf{v}\_{i}\Delta t\_{ij}\!-\!\frac{1}{2}\mathbf{g}\Delta t\_{ij}^{2}))^{\wedge}&\frac{\partial\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}}{\partial\delta\boldsymbol{\phi}\_{j}}=\mathbf{0}\\ \frac{\partial\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}}{\partial\delta\mathbf{p}\_{i}}=-{\mathbf{I}}\_{3\times 1}&\frac{\partial\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}}{\partial\delta\mathbf{p}\_{j}}=\mathtt{R}\_{i}^{\mathsf{T}}\mathtt{R}\_{j}\\ \frac{\partial\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}}{\partial\delta\mathbf{v}\_{i}}=-\mathtt{R}\_{i}^{\mathsf{T}}\Delta t\_{ij}&\frac{\partial\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}}{\partial\delta\mathbf{v}\_{j}}=\mathbf{0}\\ \frac{\partial\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}}{\partial\tilde{\delta}{\mathbf{b}^{a}\_{i}}}=-\frac{\partial\Delta\bar{\mathbf{p}}\_{ij}}{\partial\mathbf{b}^{a}\_{i}}&\frac{\partial\mathbf{r}\_{\Delta\mathbf{p}\_{ij}}}{\partial\tilde{\delta}{\mathbf{b}^{g}\_{i}}}=-\frac{\partial\Delta\bar{\mathbf{p}}\_{ij}}{\partial\mathbf{b}^{g}\_{i}}\end{array}$ |  |

#### IX-C2 Jacobians of $\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}$

As in the previous section, $\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}$ is linear in $\delta\mathbf{b}^{g}\_{i}$ and $\delta\mathbf{b}^{a}\_{i}$,
hence the Jacobians of $\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}$ w.r.t. $\tilde{\delta}{\mathbf{b}^{g}\_{i}},\tilde{\delta}{\mathbf{b}^{a}\_{i}}$ are simply the matrix coefficients of
$\delta\mathbf{b}^{g}\_{i}$ and $\delta\mathbf{b}^{a}\_{i}$.
Moreover, $\mathtt{R}\_{j}$, $\mathbf{p}\_{i}$, and $\mathbf{p}\_{j}$ do not appear in $\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}$,
hence the Jacobians w.r.t. $\delta\boldsymbol{\phi}\_{j},\delta\mathbf{p}\_{i},\delta\mathbf{p}\_{j}$ are zero. The
remaining Jacobias are computed as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}(\mathbf{v}\_{i}+\delta\mathbf{v}\_{i})$ | $\displaystyle=\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{v}\_{j}-\mathbf{v}\_{i}-\delta\mathbf{v}\_{i}-\mathbf{g}\Delta t\_{ij}\right)-D$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\mathbf{r}\_{\Delta\mathbf{v}}(\mathbf{v}\_{i})-\mathtt{R}\_{i}^{\mathsf{T}}\delta\mathbf{v}\_{i}$ |  | (75) |

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}(\mathbf{v}\_{j}+\delta\mathbf{v}\_{j})$ | $\displaystyle=\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{v}\_{j}+\delta\mathbf{v}\_{j}-\mathbf{v}\_{i}-\mathbf{g}\Delta t\_{ij}\right)-D$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\mathbf{r}\_{\Delta\mathbf{v}}(\mathbf{v}\_{j})+\mathtt{R}\_{i}^{\mathsf{T}}\delta\mathbf{v}\_{j}$ |  | (76) |

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}$ | $\displaystyle(\mathtt{R}\_{i}\;\mathrm{Exp}(\delta\boldsymbol{\phi}\_{i}))=\left(\mathtt{R}\_{i}\;\mathrm{Exp}(\delta\boldsymbol{\phi}\_{i})\right)^{\mathsf{T}}\left(\mathbf{v}\_{j}-\mathbf{v}\_{i}-\mathbf{g}\Delta t\_{ij}\right)-D$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\stackrel{{\scriptstyle\eqref{eq:expFirstOrder}}}{{\simeq}}({\mathbf{I}}-\delta\boldsymbol{\phi}\_{i}^{\wedge})\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{v}\_{j}-\mathbf{v}\_{i}-\mathbf{g}\Delta t\_{ij}\right)-D$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\stackrel{{\scriptstyle\eqref{eq:skewProperty}}}{{=}}\mathbf{r}\_{\Delta\mathbf{v}}(\mathtt{R}\_{i})+\left(\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{v}\_{j}-\mathbf{v}\_{i}-\mathbf{g}\Delta t\_{ij}\right)\right)^{\wedge}\delta\boldsymbol{\phi}\_{i},$ |  | (77) |

with $D\doteq\left[\Delta\tilde{\mathbf{v}}\_{ij}+\frac{\partial\Delta\bar{\mathbf{v}}\_{ij}}{\partial\mathbf{b}^{g}\_{i}}\delta\mathbf{b}^{g}\_{i}+\frac{\partial\Delta\bar{\mathbf{v}}\_{ij}}{\partial\mathbf{b}^{a}\_{i}}\delta\mathbf{b}^{a}\_{i}\right]$. Summarizing, the Jacobians of $\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}$ are:

|  |  |  |
| --- | --- | --- |
|  | $\begin{array}[]{ll}\frac{\partial\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}}{\partial\delta\boldsymbol{\phi}\_{i}}=\left(\mathtt{R}\_{i}^{\mathsf{T}}\left(\mathbf{v}\_{j}-\mathbf{v}\_{i}-\mathbf{g}\Delta t\_{ij}\right)\right)^{\wedge}&\frac{\partial\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}}{\partial\delta\boldsymbol{\phi}\_{j}}=\mathbf{0}\\ \frac{\partial\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}}{\partial\delta\mathbf{p}\_{i}}=\mathbf{0}&\frac{\partial\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}}{\partial\delta\mathbf{p}\_{j}}=\mathbf{0}\\ \frac{\partial\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}}{\partial\delta\mathbf{v}\_{i}}=-\mathtt{R}\_{i}^{\mathsf{T}}&\frac{\partial\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}}{\partial\delta\mathbf{v}\_{j}}=\mathtt{R}\_{i}^{\mathsf{T}}\\ \frac{\partial\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}}{\partial\tilde{\delta}{\mathbf{b}^{a}\_{i}}}=-\frac{\partial\Delta\bar{\mathbf{v}}\_{ij}}{\partial\mathbf{b}^{a}\_{i}}&\frac{\partial\mathbf{r}\_{\Delta\mathbf{v}\_{ij}}}{\partial\tilde{\delta}{\mathbf{b}^{g}\_{i}}}=-\frac{\partial\Delta\bar{\mathbf{v}}\_{ij}}{\partial\mathbf{b}^{g}\_{i}}\end{array}$ |  |

#### IX-C3 Jacobians of $\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}$

The derivation of the Jacobians of $\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}$ is slightly more involved.
We first note that $\mathbf{p}\_{i},\mathbf{p}\_{j},\mathbf{v}\_{i},\mathbf{v}\_{j},\delta\mathbf{b}^{a}\_{i}$ do not appear in the
expression of $\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}$, hence the corresponding Jacobians are zero.
The remaining Jacobians can be computed as follows:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}(\mathtt{R}\_{i}\;\mathrm{Exp}(\delta\boldsymbol{\phi}\_{i}))$ | $\displaystyle=\mathrm{Log}\left(\left(\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}^{g}\_{i})E\right)^{\mathsf{T}}\left(\mathtt{R}\_{i}\;\mathrm{Exp}(\delta\boldsymbol{\phi}\_{i})\right)^{\mathsf{T}}\mathtt{R}\_{j}\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\mathrm{Log}\left(\left(\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}^{g}\_{i})E\right)^{\mathsf{T}}\mathrm{Exp}(-\delta\boldsymbol{\phi}\_{i})\mathtt{R}\_{i}^{\mathsf{T}}\mathtt{R}\_{j}\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\overset{\eqref{eq:adjointProperty2}}{=}\mathrm{Log}\left(\left(\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}^{g}\_{i})E\right)^{\mathsf{T}}\mathtt{R}\_{i}^{\mathsf{T}}\mathtt{R}\_{j}\mathrm{Exp}(-\mathtt{R}\_{j}^{\mathsf{T}}\mathtt{R}\_{i}\delta\boldsymbol{\phi}\_{i})\right)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\overset{\eqref{eq:logExpansion}}{\simeq}\mathbf{r}\_{\Delta\mathtt{R}}(\mathtt{R}\_{i})-\mathtt{J}\_{r}^{-1}(\mathbf{r}\_{\Delta\mathtt{R}}(\mathtt{R}\_{i}))\mathtt{R}\_{j}^{\mathsf{T}}\mathtt{R}\_{i}\delta\boldsymbol{\phi}\_{i}$ |  | (78) |

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}(\mathtt{R}\_{j}\;\mathrm{Exp}(\delta\boldsymbol{\phi}\_{j}))$ | $\displaystyle=\mathrm{Log}\left(\left(\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}^{g}\_{i})E\right)^{\mathsf{T}}\mathtt{R}\_{i}^{\mathsf{T}}(\mathtt{R}\_{j}\;\mathrm{Exp}(\delta\boldsymbol{\phi}\_{j}))\right)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\overset{\eqref{eq:logExpansion}}{\simeq}\mathbf{r}\_{\Delta\mathtt{R}}(\mathtt{R}\_{j})+\mathtt{J}\_{r}^{-1}(\mathbf{r}\_{\Delta\mathtt{R}}(\mathtt{R}\_{j}))\delta\boldsymbol{\phi}\_{j}$ |  | (79) |

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\textstyle\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}$ | $\displaystyle(\delta\mathbf{b}^{g}\_{i}+\tilde{\delta}{\mathbf{b}^{g}\_{i}})$ |  | (80) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\mathrm{Log}\Big(\Big(\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}^{g}\_{i})\mathrm{Exp}\big(\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}}(\delta\mathbf{b}^{g}\_{i}+\tilde{\delta}{\mathbf{b}^{g}\_{i}})\big)\Big)^{\mathsf{T}}\mathtt{R}\_{i}^{\mathsf{T}}\mathtt{R}\_{j}\Big)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\overset{\eqref{eq:expExpansion}}{\simeq}\mathrm{Log}\Big(\Big(\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}^{g}\_{i})\ E\ \mathrm{Exp}\big(\mathtt{J}\_{r}^{b}\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}}\tilde{\delta}{\mathbf{b}^{g}\_{i}}\big)\Big)^{\mathsf{T}}\mathtt{R}\_{i}^{\mathsf{T}}\mathtt{R}\_{j}\Big)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\mathrm{Log}\Big(\mathrm{Exp}\Big(-\mathtt{J}\_{r}^{b}\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}}\tilde{\delta}{\mathbf{b}^{g}\_{i}}\Big)\left(\Delta\tilde{\mathtt{R}}\_{ij}(\bar{\mathbf{b}}^{g}\_{i})\ E\right)^{\mathsf{T}}\mathtt{R}\_{i}^{\mathsf{T}}\mathtt{R}\_{j}\Big)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\mathrm{Log}\Big(\mathrm{Exp}\Big(-\mathtt{J}\_{r}^{b}\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}}\tilde{\delta}{\mathbf{b}^{g}\_{i}}\Big)\mathrm{Exp}\left(\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}(\delta\mathbf{b}^{g}\_{i})\right)\Big)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\overset{\eqref{eq:adjointProperty2}}{=}\mathrm{Log}\Big(\mathrm{Exp}\big(\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}(\delta\mathbf{b}^{g}\_{i})\big)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\hskip 9.24994pt\hskip 9.24994pt\cdot\mathrm{Exp}\big(-\mathrm{Exp}\left(\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}(\delta\mathbf{b}^{g}\_{i})\right)^{\mathsf{T}}\mathtt{J}\_{r}^{b}\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}}\tilde{\delta}{\mathbf{b}^{g}\_{i}}\big)\Big)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\overset{\eqref{eq:logExpansion}}{\simeq}\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}(\delta\mathbf{b}^{g}\_{i})$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\hskip 9.24994pt\hskip 9.24994pt-\mathtt{J}\_{r}^{-1}\left(\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}(\delta\mathbf{b}^{g}\_{i})\right)\mathrm{Exp}\left(\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}(\delta\mathbf{b}^{g}\_{i})\right)^{\mathsf{T}}\mathtt{J}\_{r}^{b}\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}}\ \tilde{\delta}{\mathbf{b}^{g}\_{i}},$ |  |

where we used the shorthands $E\doteq\mathrm{Exp}\left(\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}}\delta\mathbf{b}^{g}\right)$ and $\mathtt{J}\_{r}^{b}\doteq\mathtt{J}\_{r}\left(\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}}\delta\mathbf{b}^{g}\_{i}\right)$.
In summary, the Jacobians of $\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}$ are:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{array}[]{ll}\frac{\partial\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}}{\partial\delta\boldsymbol{\phi}\_{i}}=-\mathtt{J}\_{r}^{-1}(\mathbf{r}\_{\Delta\mathtt{R}}(\mathtt{R}\_{i}))\mathtt{R}\_{j}^{\mathsf{T}}\mathtt{R}\_{i}&\frac{\partial\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}}{\partial\delta\mathbf{p}\_{i}}=\mathbf{0}\\ \frac{\partial\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}}{\partial\delta\mathbf{v}\_{i}}=\mathbf{0}&\frac{\partial\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}}{\partial\delta\boldsymbol{\phi}\_{j}}=\mathtt{J}\_{r}^{-1}(\mathbf{r}\_{\Delta\mathtt{R}}(\mathtt{R}\_{j}))\\ \frac{\partial\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}}{\partial\delta\mathbf{p}\_{j}}=\mathbf{0}&\frac{\partial\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}}{\partial\delta\mathbf{v}\_{j}}=\mathbf{0}\\ \frac{\partial\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}}{\partial\tilde{\delta}{\mathbf{b}^{a}\_{i}}}=\mathbf{0}&\frac{\partial\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}}{\partial\tilde{\delta}{\mathbf{b}^{g}\_{i}}}=\alpha\end{array}$ |  | (81) |

with $\alpha=-\mathtt{J}\_{r}^{-1}\left(\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}(\delta\mathbf{b}^{g}\_{i})\right)\mathrm{Exp}\left(\mathbf{r}\_{\Delta\mathtt{R}\_{ij}}(\delta\mathbf{b}^{g}\_{i})\right)^{\mathsf{T}}\mathtt{J}\_{r}^{b}\frac{\partial\Delta\bar{\mathtt{R}}\_{ij}}{\partial\mathbf{b}^{g}}$.

### IX-D Structureless Vision Factors: Null Space Projection

In this section we provide a more efficient implementation of the structureless
vision factors, described in Section [VII](#S7 "VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry").

Let us consider Eq. ([55](#S7.E55 "In VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
Recall that
$\mathbf{Q}\doteq({\mathbf{I}}-\mathbf{E}\_{l}(\mathbf{E}\_{l}^{\mathsf{T}}\mathbf{E}\_{l})^{-1}\mathbf{E}\_{l}^{\mathsf{T}})\in\mathbb{R}^{2n\_{l}\times 2n\_{l}}$
is an *orthogonal projector* of $\mathbf{E}\_{l}$, where $n\_{l}$ is the number of cameras observing landmark $l$.
Roughly speaking, $\mathbf{Q}$ projects any vector in $\mathbb{R}^{2n\_{l}}$ to the null space of the matrix $\mathbf{E}\_{l}$.
Since $\mathbf{E}\_{l}\in\mathbb{R}^{2n\_{l}\times 3}$ has rank 3, the dimension of its null space is $2n\_{l}-3$.
Any basis $\mathbf{E}^{\perp}\_{l}\in\mathbb{R}^{2n\_{l}\times 2n\_{l}-3}$ of the null space of $\mathbf{E}\_{l}$ satisfies the following relation [[71](#bib.bib71)]:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{E}^{\perp}\_{l}\left((\mathbf{E}^{\perp}\_{l})^{\mathsf{T}}\mathbf{E}^{\perp}\_{l}\right)^{-1}(\mathbf{E}^{\perp}\_{l})^{\mathsf{T}}={\mathbf{I}}-\mathbf{E}\_{l}(\mathbf{E}\_{l}^{\mathsf{T}}\mathbf{E}\_{l})^{-1}\mathbf{E}\_{l}^{\mathsf{T}}.$ |  | (82) |

A basis for the null space can be easily computed from $\mathbf{E}\_{l}$ using SVD.
Such basis is *unitary*, i.e., satisfies $(\mathbf{E}^{\perp}\_{l})^{\mathsf{T}}\mathbf{E}^{\perp}\_{l}={\mathbf{I}}$.
Substituting ([82](#Sx2.E82 "In IX-D Structureless Vision Factors: Null Space Projection ‣ Appendix ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")) into ([55](#S7.E55 "In VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")), and recalling that
$\mathbf{E}^{\perp}\_{l}$ is a unitary matrix, we obtain:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\sum\_{l=1}^{L}\|\mathbf{E}^{\perp}\_{l}(\mathbf{E}^{\perp}\_{l})^{\mathsf{T}}\left(\mathbf{F}\_{l}\;\delta\mathbf{T}\_{\mathcal{X}(l)}-\mathbf{b}\_{l}\right)\|^{2}$ |  | (83) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{l=1}^{L}\big(\mathbf{E}^{\perp}\_{l}(\mathbf{E}^{\perp}\_{l})^{\mathsf{T}}\!(\mathbf{F}\_{l}\;\delta\mathbf{T}\_{\mathcal{X}(l)}-\mathbf{b}\_{l})\big)^{\mathsf{T}}\!\big(\mathbf{E}^{\perp}\_{l}(\mathbf{E}^{\perp}\_{l})^{\mathsf{T}}(\mathbf{F}\_{l}\;\delta\mathbf{T}\_{\mathcal{X}(l)}-\mathbf{b}\_{l})\big)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{l=1}^{L}\left(\mathbf{F}\_{l}\;\delta\mathbf{T}\_{\mathcal{X}(l)}-\mathbf{b}\_{l}\right)^{\mathsf{T}}\mathbf{E}^{\perp}\_{l}\overbrace{(\mathbf{E}^{\perp}\_{l})^{\mathsf{T}}\mathbf{E}^{\perp}\_{l}}^{={\mathbf{I}}\_{3\times 3}}(\mathbf{E}^{\perp}\_{l})^{\mathsf{T}}\left(\mathbf{F}\_{l}\;\delta\mathbf{T}\_{\mathcal{X}(l)}-\mathbf{b}\_{l}\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\sum\_{l=1}^{L}\|(\mathbf{E}^{\perp}\_{l})^{\mathsf{T}}\left(\mathbf{F}\_{l}\;\delta\mathbf{T}\_{\mathcal{X}(l)}-\mathbf{b}\_{l}\right)\|^{2}$ |  |

which is an alternative representation of the cost function ([55](#S7.E55 "In VII Structureless Vision Factors ‣ On-Manifold Preintegration for Real-Time Visual-Inertial Odometry")).
This representation is usually preferable from a computational standpoint, as it does not include matrix inversion and can be computed using a smaller number of matrix multiplications.

### IX-E Rotation Rate Integration Using Euler Angles

In this section, we recall how to integrate rotation rate measurements using the Euler angle parametrization.
Let $\tilde{\boldsymbol{\omega}}\_{k}$ be the rotation rate measurement at time $k$ and $\boldsymbol{\eta}^{g}\_{k}$ be the corresponding noise.
Then, given the vector of Euler angles at time $k$, namely $\boldsymbol{\theta}\_{k}\in\mathbb{R}^{3}$,
we can integrate the rotation rate measurement $\tilde{\boldsymbol{\omega}}\_{k}$ and get $\boldsymbol{\theta}\_{k+1}$ as follows:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\boldsymbol{\theta}\_{k+1}=\boldsymbol{\theta}\_{k}+[E^{\prime}(\boldsymbol{\theta}\_{k})]^{-1}(\tilde{\boldsymbol{\omega}}\_{k}-\boldsymbol{\eta}^{g}\_{k})\Delta t,$ |  | (84) |

where the matrix $E^{\prime}(\boldsymbol{\theta}\_{k})$ is the *conjugate Euler angle rate matrix* [[72](#bib.bib72)].
The covariance of $\boldsymbol{\theta}\_{k+1}$ can be approximated by a
first-order propagation as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{\Sigma}^{\text{Euler}}\_{k+1}=\mathbf{A}\_{k}\mathbf{\Sigma}^{\text{Euler}}\_{k}\mathbf{A}\_{k}^{\mathsf{T}}+\mathbf{B}\_{k}\mathbf{\Sigma}\_{\boldsymbol{\eta}}\mathbf{B}\_{k}^{\mathsf{T}}$ |  | (85) |

where $\mathbf{A}\_{k}\doteq{\mathbf{I}}\_{3\times 3}+\frac{\partial[E^{\prime}(\boldsymbol{\theta}\_{k})]^{-1}}{\partial\boldsymbol{\theta}\_{k}}\Delta t$, $\mathbf{B}\_{k}=-[E^{\prime}(\boldsymbol{\theta}\_{k})]^{-1}\Delta t$, and $\mathbf{\Sigma}\_{\boldsymbol{\eta}}$ is the covariance of the measurement noise $\boldsymbol{\eta}^{gd}\_{k}$.

|  |  |
| --- | --- |
|  | Christian Forster (1986, Swiss) obtained his Ph.D. in Computer Science (2016) at the University of Zurich under the supervision of Davide Scaramuzza. Previously, he received a B.Sc. degree in Mechanical Engineering (2009) and a M.Sc. degree in Robotics, Systems and Control (2012) at ETH Zurich, Switzerland. In 2011, he was a visiting researcher at CSIR (South Africa), and in 2014 at Georgia Tech in the group of Frank Dellaert. He is broadly interested in developing real-time computer vision algorithms that enable robots to perceive the three dimensional environment. |

|  |  |
| --- | --- |
|  | Luca Carlone is a research scientist in the Laboratory for Information and Decision Systems at the Massachusetts Institute of Technology. Before joining MIT, he was a postdoctoral fellow at Georgia Tech (2013-2015), a visiting researcher at the University of California Santa Barbara (2011), and a visiting researcher at the University of Zaragoza (2010). He got his Ph.D. from Politecnico di Torino, Italy, in 2012. His research interests include nonlinear estimation, optimization, and control applied to robotics, with special focus on localization, mapping, and decision making for navigation in single and multi robot systems. |

|  |  |
| --- | --- |
|  | Frank Dellaert is Professor in the School of Interactive Computing at Georgia Tech. He graduated from Carnegie Mellon in 2001 with a Ph.D. in Computer Science, after obtaining degrees from Case Western Reserve University and K.U. Leuven before that. Professor Dellaert’s research focuses on large-scale inference for autonomous robot systems, on land, air, and in water. He pioneered the use of several probabilistic methods in both computer vision and robotics. With Dieter Fox and Sebastian Thrun, he has introduced the Monte Carlo localization method for estimating and tracking the pose of robots, which is now a standard and popular tool in mobile robotics. Most recently, he has investigated 3D reconstruction in large-scale environments by taking a graph-theoretic view, and pioneered the use of sparse factor graphs as a representation in robot navigation and mapping. He and his group released an open-source large-scale optimization toolbox, GTSAM. |

|  |  |
| --- | --- |
|  | Davide Scaramuzza (1980, Italian) is Professor of Robotics at the University of Zurich, where he does research at the intersection of robotics, computer vision, and neuroscience. He did his PhD in robotics and computer Vision at ETH Zurich and a postdoc at the University of Pennsylvania. From 2009 to 2012, he led the European project sFly, which introduced the world’s first autonomous navigation of micro drones in GPS-denied environments using visual-inertial sensors as the only sensor modality. For his research contributions, he was awarded an SNSF-ERC Starting Grant, the IEEE Robotics and Automation Early Career Award, and a Google Research Award. He coauthored the book Introduction to Autonomous Mobile Robots (published by MIT Press). |
