<!-- fulltext source=oa_pdf slug=doi-10.15607_rss.2015.xi.023 fetched=2026-09-21T06:21:43+00:00 -->

# Exploiting the Separable Structure of SLAM 

Kasra Khosoussi, Shoudong Huang, Gamini Dissanyake Centre for Autonomous Systems, University of Technology Sydney 

_{_ kasra.khosoussi, shoudong.huang, gamini.dissanayake _}_ @uts.edu.au 

**_Abstract_ —In this paper we point out an overlooked structure of SLAM that distinguishes it from a generic nonlinear least squares problem. The measurement function in most common forms of SLAM is linear with respect to robot and features’ positions. Therefore, given an estimate for robot orientation, the conditionally optimal estimate for the rest of state variables can be easily obtained by solving a sparse linear-Gaussian estimation problem. We propose an algorithm to exploit this intrinsic property of SLAM by stripping the problem down to its nonlinear core, while maintaining its natural sparsity. Our algorithm can be used together with any Newton-based iterative solver and is applicable to 2D/3D pose-graph and feature-based problems. Our results suggest that iteratively solving the nonlinear core of SLAM leads to a fast and reliable convergence as compared to the state-of-the-art back-ends.** 

## I. INTRODUCTION 

Simultaneous Localization and Mapping (SLAM) has been investigated for more than two decades [11]. Mathematically, SLAM is modeled as a high-dimensional nonlinear estimation problem whose goal is to find the “optimal” estimate for robot poses and map using noisy measurements and uncertain priors. The first successful solutions, posed SLAM as a _filtering_ problem [8]. It was revealed later that the _smoothing_ formulation brings not only accuracy, but also scalability, through exploiting the sparse structure of SLAM. Perhaps the most distinctive property of modern SLAM algorithms is the exploitation of this natural sparsity [7]. 

Under the assumption of Gaussian noise and Gaussian prior, finding the maximum likelihood (ML) and maximum _a posteriori_ (MAP) estimate in the smoothing form of SLAM requires solving a nonlinear least squares (NLS) problem. Given a sufficiently “good” initial guess, this problem can be solved by employing iterative schemes such as Gauss-Newton (GN). In each iteration of GN, the measurement function is approximated by its first-order Taylor expansion around the current estimate, followed by solving the resulting linear least squares problem. GN and many other iterative solvers treat the measurement function as a generic smooth nonlinear function of states. However, the widely-used measurement model associated to range-bearing sensors in 2D/3D feature-based/posegraph SLAM has a significant structure. This measurement function is linear in robot and landmarks’ positions. Therefore given the robot orientation **_θ_** , the optimal choice in ML or MAP sense for positions **p** can be obtained by solving a sparse _linear_ least squares problem. 

In the least squares literature, NLS problems with partially linear residuals are called _separable_ [2, 13]. In statistical terms, such problems are sometimes called _conditionally_ 

_linear-Gaussian_ state space models [9] since estimating the linear variables, given the nonlinear ones and measurements corrupted by Gaussian noise, corresponds to a linear-Gaussian system. 

Golub and Pereyra developed the original _Variable Projection_ (VP) algorithm to solve general separable NLS problems [12]. The main idea behind VP is to explicitly eliminate the linear variables and solve the reduced NLS problem. This technique has been applied to a wide range of applications. Both theoretically [24] and empirically it has been shown that compared to solving the full NLS problem, variable projection techniques exhibit faster or equal convergence rate (see [13] and references therein). 

In this paper we show how different variable projection algorithms can be applied to various forms of SLAM without any restrictive assumption. Unfortunately these algorithms, in their existing forms, are incapable of maintaining the sparse structure of SLAM, and therefore lead to solutions with cubic time complexity. To address this issue we propose an equivalent variable projection algorithm that is capable of exploiting both structures (i.e., separability and sparsity) at the same time. 

## _Notation_ 

Throughout this paper bold lower-case and upper-case letters are reserved for vectors and matrices, respectively. Sets are shown by upper-case letters. _|X|_ denotes the cardinality of set _X_ . **I** and **0** denote the identity and zero matrices with appropriate sizes, respectively. Let vec( **q** 1 _, . . . ,_ **q** _n_ ) denote the column vector obtained by stacking **q** _i_ ’s. **S** 1 _≻_ **S** 2 means **S** 1 _−_ **S** 2 is positive-definite. Kronecker product is denoted by _⊗_ . Euclidean norm is denoted by _∥· ∥_ . The weighted Euclidean norm of vector **e** with matrix **W** _≻_ **0** is denoted by _∥_ **e** _∥_ **W** ≜ _√_ **e**<sup>_⊤_</sup> **W e** . Finally diag( **W** 1 _, . . . ,_ **W** _k_ ) is the blockdiagonal matrix with matrices **W** 1 _, . . . ,_ **W** _k_ as blocks on its main diagonal. 

## II. PROBLEM FORMULATION AND PRELIMINARIES 

## _A. Graphical Representation of SLAM_ 

SLAM can naturally be represented by a simple directed graph _G_ = ( _V,E_ ). Each state variable is mapped into a vertex **x** _i ∈V_ , and each relative measurement is represented by an edge _ek_ ≜ ( _ik,jk_ ) _∈E_ . Here ( _i,j_ ) _∈E_ corresponds to the relative measurement from **x** _i_ to **x** _j_ . Suppose _|V|_ = _n_ + 1 and _|E|_ = _m_ . For pose-graphs we have _n_ = _np −_ 1 in which _np_ denotes the number of poses. Similarly, in feature-based SLAM with _nf_ features we have _n_ = _nf_ + _np −_ 1. Due to 

**Remark 1.** Note that (2) admits both pose-graph and feature-based SLAM problems as special cases. In pose-graph SLAM _Sf_ = ∅, while in feature-based SLAM relative pose measurements are limited to odometry measurements. 

the relative nature of measurements in SLAM and without an informative prior, we must define a global coordinates system and anchor one of the nodes to it. Without loss of generality we can assume **x** 0 is the origin of our global coordinates system. The _reduced_ incidence matrix of _G_ after anchoring **x** 0 to the origin (i.e., deleting the corresponding row from the original incidence matrix) is denoted by **A** _∈{−_ 1 _,_ 0 _,_ 1 _}_<sup>_n×m_</sup> . For the _k_ th edge _ek_ = ( _ik,jk_ ) _∈E_ we have **A** _ik,k_ = _−_ 1 and **A** _jk,k_ = 1. The remaining elements of **A** are all zero. Similarly, **A** _◦ ∈{−_ 1 _,_ 0 _,_ 1 _}_<sup>_n×n_</sup> is the reduced incidence matrix of the subgraph of _G_ consisting only of robot poses and odometry measurements. Note that **A** _◦_ has a fixed structure and it is uniquely determined by the number of poses _np_ . Finally we define **A** _ℓ_ ≜ **A** _⊗_ **I** _ℓ_ for _ℓ ∈_ Z _≥_ 2. 

According to (2), the stacked measurement function of planar SLAM is given by 



Here we assume the correct regularization terms are applied to the measurements [4]. In order to avoid redundancy in our formulas we use this unified measurement function (6) in the rest of the paper. Note that (6) can be rewritten as **h** ( **x** ) = **H** 1( **_θ_** ) **p** + **H** 2 **_θ_** in which, 

## _B. Measurement Model_ 

The conventional state vector is usually defined as vec( **x** 1 _, . . . ,_ **x** _n_ ). For reasons that will become clear shortly, we permute the standard state vector and define our state vector as **x** ≜ vec( **p** _,_ **_θ_** ). In 2D SLAM, **p** _∈_ R<sup>2</sup><sup>_n_</sup> is the vector of _x_ and _y_ coordinates of robot poses and landmark positions, and **_θ_** _∈_ [ _−π, π_ )<sup>_np−_1</sup> is the vector of robot orientations. Each observation **z** _ij_ (from node _i_ to node _j_ ) is corrupted by an independently drawn additive Gaussian noise **_ϵ_** _ij ∼N_ ( **0** _,_ **Σ** _ij_ ), 



It is important to note that unlike **H** 2, **H** 1( **_θ_** ) depends on **_θ_** . Nevertheless, we drop the argument of **H** 1 for the sake of simplicity of our notation. 

**Remark 2.** For the purpose of this paper, the measurement model in 3D SLAM wtih SE(3)<sup>3</sup> measurements is fairly similar to that of planar SLAM. With a little abuse of notation, the measurement function for 3D SLAM can be expressed as **h**<sup>_◦_</sup> ( **x** ) = **H**<sup>_◦_</sup> 1<sup>(</sup><sup>**_θ_**)</sup><sup>**p**+</sup><sup>**h**</sup><sup>_◦_</sup> 2<sup>(</sup><sup>**_θ_**)inwhich</sup> 



The measurement function **h** _ij_ ( _·,·_ ) for any ( _i,j_ ) _∈E_ has the following form, 



Similar to our formulation of 2D SLAM, here **p** is the stacked vector of robot positions, **_θ_** is the vector of robot orientation (parametrised by quaternions or Euler angles), **R** _θ_ is a block-diagonal matrix composed of **R** ( **_θ_** _i_ ) _∈_ SO(3) and **_ψ_** ( **_θ_** ) denotes relative robot orientations. The measurement function and the corresponding error term (see e.g., [14]) are therefore linear in **p** . Without loosing any generality, for simplicity of notation and due to space limitation here we mainly focus on 2D SLAM. 



where **R** ( _θi_ ) _∈_ SO(2)<sup>1</sup> is the rotation matrix corresponding to _θi_ , wrap : R _→_ [ _−π,π_ ) maps its argument to the equivalent angle in [ _−π,π_ ) and _Sp_ and _Sf_ are the disjoint sets of indices of robot poses and features, respectively. Let us define 



**Remark 3.** This paper investigates SLAM problems with standard SE(2) and SE(3) measurements for pose-graphs and pose-point measurements in 2D and 3D for featurebased problems. Such measurements can be obtained from range-bearing sensors after a reparameterization of original measurements (e.g., after performing scan-matching). These models have become standard choices in the past few years. However, such reparameterizations often involve nonlinear transformation of original data which could introduce some error in computing covariance matrices and even affect the validity of the assumption of additive Gaussian noise. In the context of our work, such transformations can be thought as reparameterization performed to introduce separability. Note 

Here _ki_ is the index of robot pose making the _i_ th observation. **z** _p_ and **z** _θ_ denote the stacked vector of _δxij_ and _δyij_ , and _δθij_ measurements, respectively. We permute the measurement vector accordingly to obtain **z** ≜ vec( **z** _p,_ **z** _θ_ ). Similarly, the stacked vector of noise variables and its covariance matrix are denoted by **_ϵ_** ≜ vec( **_ϵ_** _p,_ **_ϵ_** _θ_ ) and **Σ** , respectively. Therefore the measurement model can be expressed in a compact form by 





> 1Special orthogonal group. 

> 2To simplify our notaions we denote random variables (e.g., **z** ) and their realisation in the same way. 

> 3Special Euclidean group. 

that directly using range-bearing measurements does not lead to a separable NLS. Although here we do not consider a specific choice of sensors, the use of inertial sensors in 3D SLAM is common [19]. Therefore it is worth noting that inertial measurements does not violate the separable structure of SLAM as such measurements are linear in **p** (see e.g., [19]). 

## _C. Point Estimation Criterion_ 

In the Bayesian approach to SLAM **x** is modeled as a random vector with prior _p_ ( **x** ) = _N_ ( **x** ; **_µ_ x** _,_ **Σx** ). The MAP estimate is the maximizer of the posterior density (or the minimizer of its negative log), 



Therefore the MAP estimate **x** ˆ MAP is given by: 



In the absence of an informative prior over **x** ,<sup>4</sup> one may seek the maximizer of the likelihood function _p_ ( **z** _|_ **x** ) in order to obtain the ML estimate **x** ˆ ML. Dropping the prior in (10) gives **x** ˆ ML, 



In the following sections we mainly focus on **x** ˆ ML as it is fairly rare to have an informative prior over **x** in real applications. Nevertheless, our approach can be straightforwardly generalized to the Bayesian formulation (10) as well. To simplify our notation we denote the optimal estimate for any variable like _c_ with _c_<sup>_⋆_</sup> . Here _c_<sup>_⋆_</sup> is either _c_ ˆML or _c_ ˆMAP. 

## III. EXPLOITING SEPARABILITY IN SLAM 

In the previous section we formulated the MAP and ML estimation problems in SLAM as _nonlinear_ least squares problems. By further inspection of (7) one can see that the nonlinearity is caused by the rotation matrices. Hence given the robot orientations **_θ_** , measurements are linear in robot and features’ positions **p** . Therefore given **_θ_** , the ML and MAP estimates for **p** are obtained by solving _linear_ least squares problems. Such problems are often called _separable_ NLS [13]. This special structure distinguishes SLAM from the general NLS. Our main goal in this paper is to exploit this structure in order to improve the performance of the current SLAM algorithms. 

## _A. Variable Projection_ 

Variable projection (VP) is an algorithm proposed by Golub and Pereyra to exploit this structure [12]. They proved that under some regularity conditions, the solution of the original problem (10) or (11) (for general separable NLS problems) can be obtained using the following procedure (see [12, Theorem 2.1]). Here we explain how their approach can be applied to SLAM. 

> 4In this case, **x** is treated as the vector of unknown deterministic parameters in the measurement model. 

- I. Find **p**<sup>_⋆_</sup> ( **_θ_** ), the closed-form expression for **p** as a function of **_θ_** that minimizes the original cost function in **p** . 

- II. Replace **p** with **p**<sup>_⋆_</sup> ( **_θ_** ) in the original problem and minimize the new objective function in **_θ_** to obtain **_θ_**<sup>_⋆_</sup> . After this step the optimal **p**<sup>_⋆_</sup> = **p**<sup>_⋆_</sup> ( **_θ_**<sup>_⋆_</sup> ) can be recovered instantly. 

**Phase I – p**<sup>_⋆_</sup> ( **_θ_** ) **:** Let us start with the symmetric positive definite square root of the noise precision matrix **Σ**<sup>_−_</sup><sup><u>1</u></sup> 2 _≻_ **0** . To simplify our notation, we express the weighted _ℓ_<sup>2</sup> norm minimization in (11) as the following unweighted least squares, 



in which **z** ˜ ≜ **Σ**<sup>_−_</sup><sup><u>1</u></sup> 2 **z** , **H** ˜ 1 ≜ **Σ**<sup>_−_</sup><sup><u>1</u></sup> 2 **H** 1 and **H** ˜ 2 ≜ **Σ**<sup>_−_</sup> 2<sup><u>1</u></sup> **H** 2. The fact that the reduced incidence matrix is full rank in (weakly) connected graphs results in the following lemma [17]. 

**Lemma 1.** _In any SLAM problem with the measurement models defined in Section II (including 2D/3D feature-based or pose-graph)_ **H**<sup>˜</sup> 1 _is full column rank regardless of_ **_θ_** _._ 

As mentioned before, given **_θ_** , (12) is a linear least squares problem in **p** . Lemma 1 assures us that for any given **_θ_** , the optimal choice for **p** as a function of **_θ_** is uniquely given by 



in which **H**<sup>˜</sup><sup>_†_</sup> 1<sup>≜( ˜</sup><sup>**H**</sup> 1<sup>_⊤_</sup><sup>**H**˜1)</sup><sup>_−_1 ˜</sup><sup>**H**</sup> 1<sup>_⊤_istheMoore-Penrosepseu-</sup> doinverse of **H**<sup>˜</sup> 1. 

**Remark 4.** Although we do not require any special structure in **Σ** , here we point out an interesting property of spherical noise covariance matrices. Let us denote the covariance matrix of the translational component of the _i_ th measurement with **Σ**<sup>_i_</sup> _p_<sup>. An interesting special case emerges when</sup><sup>**Σ**</sup> _p_<sup>_i_is</sup><sup>_spherical_,</sup> i.e., **Σ**<sup>_i_</sup> _p_<sup>=</sup><sup>_σ_</sup> _p_<sup>_i_</sup> 2 **I** 2. Noting that **R** _θ_ is orthogonal, it is easy to show that in such SLAM problems **H**<sup>˜</sup><sup>_⊤_</sup> 1<sup>**H**˜1isproportionalto</sup> **L** 2 ≜ **L** _⊗_ **I** 2 = **A** 2 **A**<sup>_⊤_</sup> 2<sup>inwhich</sup><sup>**L**isthereducedLaplacian</sup> matrix of graph _G_ . A similar structure exists in 3D SLAM problems with spherical noise covariance matrices. **Phase II – Reduced NLS:** By substituting **p** in the original objective function (12) with **p**<sup>_⋆_</sup> ( **_θ_** ) in (14) and solving the resulting optimization problem we obtain **_θ_**<sup>_⋆_</sup> ≜ arg min **_θ_** _g_ ( **_θ_** ) where 



Note that _g_ ( _·_ ) is a function of only robot headings **_θ_** , while the original optimization problem (12) was over both **p** and **_θ_** . Therefore we have reduced the parameter space from R<sup>2</sup><sup>_n_</sup> _×_ [ _−π,π_ )<sup>_np−_1</sup> to [ _−π,π_ )<sup>_np−_1</sup> . **P** _θ_ ≜ **H**<sup>˜</sup> 1 **H**<sup>˜</sup><sup>_†_</sup> 1<sup>is the orthog-</sup> onal projection onto range( **H**<sup>˜</sup> 1), while **P**<sup>_⊥_</sup> _θ_<sup>≜</sup><sup>**I**</sup><sup>_−_</sup><sup>**H**˜1 ˜</sup><sup>**H**</sup> 1<sup>_†_is its</sup> orthogonal complement. Let us define **r** vp ≜ **P**<sup>_⊥_</sup> _θ_<sup>(˜</sup><sup>**z**</sup><sup>_−_</sup><sup>**H**˜2</sup><sup>**_θ_**). In</sup> order to solve (15) using Newton-based NLS solvers we need to compute the Jacobian matrix of **r** vp, i.e., **J** vp ≜ _∂∂_ **_θ_**<sup>**r**vp.</sup> Computing **J** vp requires differentiating pseudoinverses ( **H**<sup>˜</sup> 1<sup>_†_),</sup> and therefore is more complex than computing the Jacobian 

## **Algorithm 1** SLAM solver based on [16] 

|1:|**repeat**<br><sup>˜</sup>|
|---|---|
|2:|Compute the full QR factorization of **H**1 (18)<br><br><sup>˜</sup>|
|3:|Recover **p**<sup>_⋆_</sup>by solving **R**1**p**<sup>_⋆_</sup>(**_θ_**(_i_)) =**Q**<sup>_⊤_</sup><br>1 <sup>(˜</sup><sup>**z**</sup><sup>_−_</sup><sup>**H**2</sup><sup>**_θ_**(</sup><sup>_i_))</sup>|
|4:|Compute the modified Jacobian matrix (19) (see [17])|
|5:|Construct the normal equations for the reduced problem|
|6:|Solve the normal equations to obtain _δ_**_θ_**(_i_)|
|7:<br>|**_θ_**(_i_+1) _←_**_θ_**(_i_)+_δ_**_θ_**(_i_)<br>|
|8:|**until** convergence|
|9:|**p**<sup>_⋆_</sup>_←_**p**<sup>_⋆_</sup>(**_θ_**<sup>_⋆_</sup>) according to (14)|



matrix of the original full problem, i.e., **J** ≜ _∂∂_ **x**<sup>**r**inwhich</sup> **r** ≜ **z** _−_ **h** ( **x** ). One way to avoid this complexity is to approximate **J** vp using finite differences (see [13] and the references therein). Here we use the exact analytical expression for **J** vp which was derived by Golub and Pereyra [12]. 

**Computing J** vp **:** First note that (15) has a slightly more general form compared to the case which was originally considered by [12] in that we have an additional term, linear with respect to **_θ_** in our residual, i.e., _−_ **H**<sup>˜</sup> 2 **_θ_** . We can show that the _j_ th column of **J** vp is given by, 



After finding **_θ_**<sup>_⋆_</sup> ≜ arg min _g_ ( **_θ_** ) using an iterative NLS solver such as GN, we can recover the optimal **p**<sup>_⋆_</sup> according to (14), i.e., by solving ( **H**<sup>˜</sup><sup>_⊤_</sup> 1<sup>**H**˜1)</sup><sup>**p**</sup><sup>_⋆_=</sup><sup>**H**˜</sup><sup>_⊤_</sup> 1<sup>(˜</sup><sup>**z**</sup><sup>_−_</sup><sup>**H**˜2</sup><sup>**_θ_**</sup><sup>_⋆_). Ingeneral, VP</sup> iterations are computationally much more expensive than GN iterations on the full problem. Therefore directly applying VP to SLAM does not lead to an efficient solver. 

## _B. Kaufman’s Algorithm_ 

In [16] Kaufman proposed to approximate the _j_ th column of **J** vp according to 

## given below, 



IV. SPARSE VARIABLE PROJECTION 

In the previous section we explained how Algorithm 1 exploits the separable structure of SLAM. At first glance, applying this algorithm to SLAM may appear to be computationally advantageous as it reduces the size of the normal equations from (2 _n_ + _np_ ) to only _np_ . However, the normal equations of the reduced problem in SLAM is dense in general. Hence VP, as implemented in Algorithm 1, does not lead to a scalable algorithm as we would need _O_ ( _n_<sup>3</sup> _p_<sup>) time per iteration</sup> just for solving the resulting _dense_ linear system. Therefore it is sensible to ask whether we can exploit separability without giving up the intrinsic sparse structure of SLAM? 

Barham and Drane [1] proposed an intuitive algorithm to solve separable NLS problems. It has been shown that their algorithm and Kaufman’s modification in VP produce identical steps (assuming infinite-precision arithmetic) [22, 24]. Although Barham and Drane’s algorithm does not preserve sparsity, it can be restructured to do so as shown below. Consider the normal equations of the original problem, 



Here _δ_ **x** ( _i_ ) ≜ vec( _δ_ **p** ( _i_ ) _,δ_ **_θ_** ( _i_ )) denotes the _i_ th GN direction, ˜ **r** is the residual vector ˜ **r** ≜ **Σ**<sup>_−_</sup><sup><u>1</u></sup> 2 **r** and **J** ˜ ≜ _<u>∂</u> ∂_ **x**<sup>˜</sup><sup>**r**,bothevaluated</sup> at **x** ( _i_ ). Let **_H_** ≜ **J**<sup>˜</sup><sup>_⊤_</sup> **J**<sup>˜</sup> be the approximated Hessian. Note that **J**<sup>˜</sup> can be divided into two blocks, **J**<sup>˜</sup> = [ **J**<sup>˜</sup> _p_ **J**<sup>˜</sup> _θ_ ] in which **J** ˜ _p_ ≜ _∂∂_ **p**<sup>˜</sup><sup>**r**and</sup><sup>**J**˜</sup><sup>_θ_≜</sup> _∂∂_ **_θ_**<sup>˜</sup><sup>**r**.Thereforewecanexpand(20)as</sup> 





The term ignored in **J**<sup>K</sup> vp<sup>has been theoretically and practically</sup> shown to be negligible in small-residual problems in terms of the convergence rate of GN [16, 24]. Kaufman’s simplification reduces the time per iteration of VP up to 25% [24]. Consequently Kaufman’s method has become the standard way of approaching separable NLS problems in many fields [13]. Algorithm 1 summarizes a SLAM solver based on an efficient implementation of VP using Kaufman’s modification. This algorithm relies on the full QR decomposition of **H**<sup>˜</sup> 1, 



in which the columns of **Q** 1 and **Q** 2 form orthonormal bases for range( **H**<sup>˜</sup> 1) and null( **H**<sup>˜</sup><sup>_⊤_</sup> 1<sup>),respectively.In[17]weshow</sup> that the normal equations associated to the residual-Jacobian ordered pair ( **r** vp _,_ **J**<sup>K</sup> vp<sup>) isidentical tothat of(</sup><sup>**Q**</sup> 2<sup>_⊤_</sup><sup>**r**vp</sup><sup>_,_</sup><sup>**Q**</sup> 2<sup>_⊤_</sup><sup>**J**K</sup> vp<sup>)</sup> 



Solving (22) gives us _δ_ **_θ_** ( _i_ ). It should be clear that using this solution to recover _δ_ **p** ( _i_ ) from (21) leads to the standard GN direction for the original cost function. Barham and Drane proposed to ignore _δ_ **p** ( _i_ ) of (21) and instead compute the conditionally optimal **p** ( _i_ +1) given **_θ_** ( _i_ +1) = **_θ_** ( _i_ ) + _δ_ **_θ_** ( _i_ ) using (14) [1]. This can be achieved by solving the following _sparse_ linear system, 



Repeating this procedure until convergence leads to a sequence of steps for which the cost function (11) has zero gradient with respect to **p** along the path. This algorithm is summarized in Algorithm 2. The equivalence between Algorithm 1 and 



<!-- Start of picture text -->
p ⋆ ( θ )<br>xi xi +1<br>θ<br>p<br><!-- End of picture text -->

Fig. 1. In this figure we see the contour lines of a simplified version of SLAM cost function. The point in the middle is the optimal solution. The gray curve is _p_<sup>_⋆_</sup> ( _θ_ ); a function that maps any given _θ_ to the corresponding conditionally optimal estimate for _p_ . The cost function has zero gradient with respect to _p_ along this curve. The blue vector shows the _i_ th step of Algorithm 1— which is identical to the _i_ th step of Algorithm 2 and Algorithm 3. The red vector is the GN step obtained by starting from _xi_ . Algorithm 3 corrects this intermediate step by projecting the obtained solution back on _p_<sup>_⋆_</sup> ( _θ_ ) (dashed line). Note that Algorithm 1 computes the blue vector directly by performing a GN iteration on the _reduced_ problem (15) with cubic time complexity. However our indirect approach in Algorithm 3 enables us to retain the sparse structure of the original problem. 

Algorithm 2 can be verified by expanding the normal equations of the reduced problem associated to Kaufman’s Jacobian (17). Now recall that our goal is to find a way to simultaneously benefit from the sparsity and separability of SLAM. Unfortunately, the _reduced_ linear system (i.e., the Schur complement) in (22) is dense in general. But note that in each iteration of Algorithm 2, the solution of the reduced system (22) is identical to the _δ_ **_θ_** ( _i_ ) obtained from solving the full system (21). Therefore, instead of eliminating variables using Schur complement, the same outcome can be achieved by solving the sparse full system (21), discarding the obtained _δ_ **p** ( _i_ ) and instead computing the conditionally optimal **p** ( _i_ +1) according to (23). Our proposed algorithm is summarized in Algorithm 3. 

It is of utmost importance to note that our proposed algorithm produces (mathematically) identical steps to those of Algorithm 1 and Algorithm 2. However, unlike Algorithm 1 and Algorithm 2, we only need to solve _sparse_ linear systems in each iteration of our method which leads to a crucial computational benefit. Also note that Algorithm 3 can be easily implemented by a simple modification of existing stateof-the-art back-ends. In fact, we only need to solve (23) using e.g., a sparse Cholesky solver. Figure 1 illustrates how our proposed algorithm works. 

**Remark 5.** Note that (10) is also a separable NLS problem. Therefore Algorithm 3 can be easily modified to find the MAP estimate assuming a Gaussian prior over **x** is available. Nevertheless, here we address the Bayesian formulation from a slightly different angle that gives us new insights into the structure of SLAM. The posterior density _p_ ( **p** _,_ **_θ_** _|_ **z** ) can be factored according to 



Using the Bayes rule we have _p_ ( **p** _|_ **_θ_** _,_ **z** ) _∝ p_ ( **z** _|_ **x** ) _p_ ( **p** _|_ **_θ_** ). From the fact that the measurement function is linear in **p** it readily follows that a Gaussian prior over **x** results in a Gaussian _p_ ( **p** _|_ **_θ_** _,_ **z** ) = _N_ ( **p** ; **_µ_**<sup>_◦_</sup> **_θ_**<sup>_,_</sup><sup>**Σ**</sup> **_θ_**<sup>_◦_).Themeanand</sup> 

covariance matrix of this distribution are computed in [17]. Although in general the original posterior distribution _p_ ( **p** _,_ **_θ_** _|_ **z** ) may be far from being Gaussian (e.g., multi-modal, skewed, etc), recovering the optimal **p** given **_θ_** reduces to a simple linear-Gaussian estimation problem. Such problems are often called _conditionally_ linear-Gaussian. By definition the MAP estimate is the maximizer of the posterior distribution (24), 



It is easy to see that for any given **_θ_** , maximizing the product above implies maximizing _p_ ( **p** _|_ **_θ_** _,_ **z** ) with respect to **p** , 



As in any Gaussian density, the mean of _p_ ( **p** _|_ **_θ_** _,_ **z** ) is equal to its mode, and therefore **_µ_**<sup>_◦_</sup> **_θ_**<sup>is the solution of (26). Maximizing</sup> _p_ ( **p** _,_ **_θ_** _|_ **z** ) subject to **p** = **_µ_**<sup>_◦_</sup> **_θ_**<sup>isequivalenttoaNLSproblem</sup> that can be solved like before. After obtaining the MAP estimate for **_θ_** we can recover **p**<sup>_⋆_</sup> by evaluating (26) at **_θ_**<sup>_⋆_</sup> . In practice we should use the approach taken in Algorithm 3 in order to retain the sparsity of SLAM. 

## V. RESULTS 

In this section we report the performance of the proposed algorithm on both synthetic and real datasets. We used **g**<sup>`2`</sup> **o** ’s implementation of GN [18]. **CHOLMOD** [6] is used as the linear solver with the default choice of fill-reducing permutation. We implemented Algorithm 3 (VP)<sup>5</sup> in C++. An Intel Core i5-2400 CPU operating at 3 _._ 1GHz is used for all of the experiments in this paper. We verified the equivalence between the iterations of Algorithm 1, Algorithm 2 and Algorithm 3 numerically. We used **g**<sup>`2`</sup> **o** ’s 2D simulator to create Manhattanlike pose-graph datasets. This simulator creates a random walk in plane with 1 meter forward motion or 90<sup>_◦_</sup> rotation per step. The valid sensor range for scan matching is between 1 and 5 meters within the 135<sup>_◦_</sup> field of view. In reality, scan matching is an expensive operation. Therefore extracting each and every (potential) loop closure is practically intractable. We imitate this practical limitation by imposing an upper bound on the degree of each vertex in the simulator. 

We generated five test suites, each of which is composed of 100 randomly generated datasets with 10<sup>4</sup> poses per dataset. Each test suite corresponds to a fixed noise level _α ∈{_ 1 _, . . . ,_ 5 _}_ . Noise covariance for each suite is **Σ** _α_ = (0 _._ 01 _α_ )<sup>2</sup> **I** . For each dataset we performed 50 iterations of different solvers. Solvers are initialized using odometry data. The outcome of each run is one of the followings. (i) **Global Min** : the global minimizer is found within 50 iterations, (ii) **Local Min** : a local minimizer (other than the global minimizer) is found within 50 iterations, or (iii) **Not Converged** : the solver has not converged to a solution before 50 iterations. 

Table I summarizes the results obtained under different noise levels. Although in few instances VP outperformed GN, in general the two algorithms exhibit comparable performances 

> 5In this section VP refers to our proposed algorithm, not to be confused with the original or Kaufman’s VP algorithms. 

## **Algorithm 2** SLAM solver based on [1] 

## **Algorithm 3** Proposed Algorithm 



<!-- Start of picture text -->
1: repeat 1: repeat<br>2: Construct the normal equations (21) 2: Construct the normal equations (21)<br>3: Eliminate δ p ( i ) using the Schur complement (22) 3: Use the sparse Cholesky solver to solve (21)<br>4: Solve (22) to obtain δ θ ( i ) 4: θ ( i +1) ← θ ( i ) +  δ θ ( i )<br>5: θ ( i +1) ← θ ( i ) +  δ θ ( i ) 5: p ( i +1) ← p ⋆ ( θ ( i +1)) according to (23) using the sparse<br>6: p ( i +1) ← p ⋆ ( θ ( i +1)) according to (23) Cholesky solver<br>7: until convergence 6: until convergence<br>Spherical (α = 1) Non-spherical (α = 1) Spherical (α = 2) Non-spherical (α = 2)<br>12 12 20 25<br>Gauss-Newton (g2o) Gauss-Newton (g2o) Gauss-Newton (g2o) Gauss-Newton (g2o)<br>10 Proposed Algorithm 10 Proposed Algorithm Proposed Algorithm 20 Proposed Algorithm<br>15<br>8 8<br>15<br>6 6 10<br>10<br>4 4<br>5<br>2 2 5<br>0 0 0 0<br>0 20 40 60 80 100 0 20 40 60 80 100 0 20 40 60 80 100 0 20 40 60 80 100<br>Scenario (% of Loop Closures) Scenario (% of Loop Closures) Scenario (% of Loop Closures) Scenario (% of Loop Closures)<br>(a) α  = 1 (spherical). (b) α  = 1 (non-spherical). (c) α  = 2 (spherical). (d) α  = 2 (non-spherical).<br>(sec)OverallRunTime (sec)OverallRunTime (sec)OverallRunTime (sec)OverallRunTime<br><!-- End of picture text -->

Fig. 3. Overall run time for converging to MLE as a function of edge density under different noise models. In Figure 3d, GN failed to converge to MLE in 8 scenarios (33 _−_ 40). Note that the “100% loop closure density” refers to the 100th scenario in which all of the loop closures of a _realistic_ sparse SLAM problem with _|V|_ = 50 _,_ 000 and _|E|_ = 173 _,_ 000 are included—not the complete graph. 



<!-- Start of picture text -->
16<br>Gauss-Newton (g2o)<br>Proposed Algorithm<br>14<br>12<br>10<br>8<br>6<br>4<br>2<br>1 2 3 4 5<br>Noise Level α<br>Avg.ofNumberIterations<br><!-- End of picture text -->

Fig. 2. Average number of iterations performed to converge to the global minimum (ML estimate) under different noise levels ( _α_ ). For each noise level, 100 random datasets with 10<sup>4</sup> poses has been generated. The error bars show the 95% confidence interval. The increasing length of error bars is partly due to the decreasing number of successful samples (see Table I). Note that there is a one-to-one correspondence between iterations of Algorithm 3 and those of Algorithm 1 performed on the reduced problem (15). 

in terms of converging to the optimal solution. As expected, both algorithms tend to converge to local minima as _α_ increases; a “good” initial guess is crucial for converging to the optimal solution. Nevertheless, according to Table I our algorithm significantly outperforms GN in avoiding divergence (or extremely slow convergence). Therefore, as reported by other researchers in various fields [13], VP iterations lead to a faster and more reliable convergence than solving the full NLS problem. As any other iterative solver, using VP can lead to a local minimizer other than MLE. This can be avoided by using a “sufficiently good” initial guess [15]. It is worth noting that in the case of converging to local minima, the results obtained by both solvers were generally inaccurate and far from the optimal estimate. Out of the 500 simulations used in Table I and II, there are 89 cases for which both GN and VP converge 

to local minima. In 38 of those instances, GN and VP converge to the _same_ local minimum. Furthermore, in 74 of those (89) cases, the local minima found by GN and VP are both at least 10% larger than the true minimum. In addition to the results shown in Table I, we performed another experiment by generating random initial guesses in a neighbourhood of MLE. Random initial guesses were generated by sampling uniformly from the surface of hyperspheres centered at the global minimum with different radii. As in Table I, we did not observe a statistically significant difference in the tendency of VP and GN for converging to local minima. 

Table II shows the results obtained by Levenberg-Marquardt (LM) and a trust-region version of Algorithm 3 using LM (VP-LM). For both solvers we use **g**<sup>`2`</sup> **o** ’s default settings (e.g., strategy to update the damping parameter). Due to the slow progress of LM, here we report the results after both 50 and 100 iterations. According to Table II, LM exhibits extremely slow convergence while the performance of VPLM is comparable to that of GN and VP. That being said, the success rates of GN and VP are slightly higher than VP-LM. 

Figure 2 shows the average number of iterations performed to converge to the optimal solution under different noise levels. It clearly indicates that the proposed algorithm can converge to the optimal solution in less number of iterations than GN. To correctly interpret this result, it is crucial to note that there is a one-to-one correspondence between iterations of Algorithm 3 and those of Algorithm 1 performed on the reduced problem (15). This observation is consistent with numerous reports from other researchers who apply variable projection to separable NLS problems in other contexts [13]. 

Reducing the number of iterations does not necessarily reduce the total computation time as each VP iteration is usually more costly than that of GN. More specifically for SLAM, 

original VP [12], Kaufman’s approach [16] (Algorithm 1) and Barham and Drane’s method [1] (Algorithm 2) are all significantly slower than the state-of-the-art SLAM solvers since they are all incapable of exploiting sparsity. Unlike these algorithms, Algorithm 3 is designed to retain the sparse structure of SLAM. Nevertheless, recall that in each iteration of our algorithm, compared to GN, we have an additional (but smaller) sparse linear system to solve. Therefore each iteration of our algorithm is still slightly more expensive than that of GN. Informally speaking, Figure 2 indicates that by exploiting the separable structure of SLAM we can achieve more _effective_ iterations at the cost of solving an additional sparse linear system in each iteration. 

Consequently we conducted another experiment to compare the overall run time of VP and GN. For this purpose, first we created a Manhattan-like random walk with 5 _×_ 10<sup>4</sup> poses. Four pose-graph datasets were created based on this random walk by simulating noisy measurements for the following noise models: (i) _α_ = 1, (ii) _α_ = 2, (iii) Non-spherical noise covariance matrix with standard deviations similar to _α_ = 1 and (iv) Non-spherical noise covariance matrix with standard deviations similar to _α_ = 2. To study the effect of edge density on the overall run time we created 100 scenarios based on each simulated dataset. The _i_ th scenario contains odometry edges plus _i_ percent of the loop closures of the original simulation (including the ones that were included in the ( _i −_ 1)th scenario). Note that the original simulation is a realistic sparse SLAM problem with a density similar to commonly used benchmarks. Loop closures are selected randomly (i.e., with no particular order) to achieve realistic and balanced scenarios. 

Figure 3 shows the total run time as a function of loop closure density for each noise model. According to Figure 3, in the vast majority of cases, VP has been faster than GN. This shows that in those cases, reducing the number of iterations has paid off the additional cost paid for each iteration. In a small fraction of scenarios we observe minor difference between the run times. There are also a limited number of individual cases where GN is slightly faster than VP. This situation happens mainly in extremely sparse scenarios, in which the initial guess based on odometry is already close to MLE and thus GN can find the solution in 2-3 iterations. Such scenarios are often too sparse to be considered as realistic cases. Figure 3 also indicates that using VP becomes more beneficial (in terms of the overall run time) as noise level increases. This conclusion is consistent with what we saw earlier in Figure 2. 

Datasets with spherical noise covariance matrices possess an additional structure that can be exploited to significantly reduce the cost per iteration of Algorithm 3. Recall that in each iteration of our algorithm we need to solve an additional linear system to recover the conditionally-optimal estimate of linear variables. The cost of this extra step is dominated by the Cholesky factorization of **H**<sup>˜</sup><sup>_⊤_</sup> 1<sup>**H**˜1in(23).Accordingto</sup> Remark 4, this term is constant (i.e., independent of the current estimate) when the noise covariance matrix is spherical. Thus, the Cholesky factorization needs to be done only _once_ in such problems (i.e., for the first iteration). In the rest of iterations 

TABLE I 

OUTCOME (%) OF GN AND VP AFTER 50 ITERATIONS UNDER DIFFERENT NOISE LEVELS. 

|Noise Level|Solver|**Global Min**|**Local Min**|**Not Converged**|
|---|---|---|---|---|
|1|GN|100|0|0|
|_α_ =|VP|100|0|0|
|2|GN|91|8|1|
|_α_ =|VP|94|6|0|
|3|GN|76|16|8|
|_α_ =|VP|78|19|3|
|4|GN|56|36|8|
|_α_ =|VP|57|41|2|
|=5|GN|37|50|13|
|_α_|VP|39|60|1|



TABLE II 

OUTCOME (%) OF LM AND VP-LM AFTER 50 & 100 ITERATIONS UNDER DIFFERENT NOISE LEVELS. 

|NoiseLevel|Solver|**Glob**|**al Min**|**Loca**|**l Min**|**Not Co**|**nverged**|
|---|---|---|---|---|---|---|---|
|||**50 iter.**|**100 iter.**|**50 iter.**|**100 iter.**|**50 iter.**|**100 iter.**|
|1|LM|53|79|10|7|37|14|
|_α_ =|VP-LM|97|97|3|3|0|0|
|2|LM|17|41|22|13|61|46|
|_α_ =|VP-LM|90|90|10|10|0|0|
|3|LM|9|18|18|25|73|57|
|_α_ =|VP-LM|72|73|27|27|1|0|
|4|LM|1|8|15|24|84|68|
|_α_ =|VP-LM|48|48|49|52|3|0|
|5|LM|2|6|16|24|82|0|
|_α_ =|VP-LM|32|33|63|66|5|1|



we only need to solve sparse triangular linear systems by forward and backward substitutions in order to recover the conditionally-optimal **p** . As illustrated by Figure 3, this trick can significantly reduce the cost per iteration and overall run time of our algorithm. 

We also used a number of publicly available datasets to evaluate the performance of the proposed algorithm. Table III provides the number of iterations performed to find the optimal solution, as well as the average of total computation time over 10 runs. Starting from the odometry initial guess, both algorithms are able to converge to MLE. This is true for most of the existing real datasets, although as seen in Table I for simulated datasets, a bad initial guess can cause VP and GN to converge to (different) local minimizers of the cost function. The datasets listed in Table III span the most common forms of SLAM (2D/3D real/synthetic pose-graphs). As expected, VP converges to the optimal estimate in less number of iterations than GN (up to 50%). In most cases VP also outperforms GN in terms of the total computation time (up to 30%). Small datasets and accurate measurements make the SLAM problem less challenging in terms of convergence [3]. In such cases, the computational benefits of exploiting the separable structure of SLAM can be less than more challenging scenarios. This conclusion is consistent with what we saw earlier in Figure 3. 

## VI. RELATED WORKS 

An extensive survey of VP applications can be found in [13, 25]. A theoretical analysis on the convergence properties of variable projection methods is due to Ruhe and Wedin [24]. The high-dimensional state space of SLAM is one of its distinctive features in comparison with many other applications of VP. 

TABLE III 

SUMMARY OF RESULTS FOR SOME OF THE PUBLICLY AVAILABLE REAL AND SYNTHETIC DATASETS. 

|Dataset|_|V|_|_|E|_|Solver|# Iter.|Time (s)|
|---|---|---|---|---|---|
|Cit10K|10000|20678|GN|7|0_._45023|
|y|_,_|_,_|VP|4|0_._31845|
|Mnhttn|3500|5598|GN|6|0_._08757|
|aaa|_,_|_,_|VP|4|0_._07687|
|Intel|943|1837|GN|3|0_._01759|
|||_,_|VP|2|0_._01713|
|UTMDowntown|14549|16365|GN|10|0_._28154|
||_,_|_,_|VP|4|0_._23555|
|Shere2500|2500|9799|GN|5|0_._96145|
|p|_,_|_,_|VP|4|0_._82080|
|NeCollee|52480|52577|GN|8|2_._19560|
|w g|_,_|_,_|VP|6|2_._00967|



A common way of approaching conditionally linearGaussian state space models is to use Rao-Blackwellized particle filters (RBPF), see e.g., [9]. In these methods first _N_ samples _{_ **_θ_**<sup>[</sup><sup>_i_]</sup> _}_<sup>_N_</sup> _i_ =1<sup>aregeneratedaccordingto</sup><sup>**_θ_**[</sup><sup>_i_]</sup><sup>_∼p_(</sup><sup>**_θ_**</sup><sup>_|_</sup><sup>**z**).</sup> Then for each sample the optimal **p** is recovered analytically by finding the mean of _p_ ( **p** _|_ **_θ_**<sup>[</sup><sup>_i_]</sup> _,_ **z** ) using e.g., the Kalman filter. The latter stage is equivalent to (26) as shown in [17]. It is worth noting that this approach naturally leads to the minimum mean-square error point estimate (i.e., mean of the posterior instead of its mode). L-SLAM [30, 31] uses this idea to exploit the separable structure of feature-based SLAM by employing a RBPF based on a clever partitioning of state variables, i.e., **_θ_** vs. **p** , instead of FastSLAM’s choice of poses vs. features [20, 21]. Any sequential Monte Carlo method employed on a high-dimensional state space will eventually suffer from degeneracy and consequently, particle depletion [10]. Particle depletion has a direct negative effect on estimating **_θ_** : at time step _t ≫ t_ 0, eventually all of the particles share the same estimate for _{θi}_<sup>_t_</sup> _i_ =1<sup>_−t_0</sup> for some _t_ 0 (i.e., effectively only one sample is drawn from the corresponding region). 

In our previous work [29] linear variables of 2D featurebased problems with spherical noise are explicitly eliminated to obtain a smaller optimization problem over **_θ_** . This approach is similar to Golub and Pereyra’s VP [12], but with numerical differentiation and Newton iterations. This method is computationally beneficial _only_ in extremely noisy problems with dense graphs. LAGO [4, 5] uses the separable structure of SLAM to bootstrap GN. First a refined estimate for **_θ_** is computed by only considering relative measurements of robot heading. Using this initial estimate of **_θ_** , LAGO then recovers the conditionally-optimal estimate for **p** . Finally the result is used as the initial guess in GN. From this perspective, our algorithm can be roughly interpreted as a constant use of LAGO’s bootstrapping approach, without the initial phase of approximating **_θ_** (which makes our algorithm robust to strong correlations between the components of noise [5, 15]). Unlike our algorithm, LAGO is limited to 2D pose-graphs. The equivalence between the minima of the original optimization problem and those of the reduced problem (15) have allowed researchers to study various properties of SLAM by looking at the reduced problem. For instance in [27, 28] we analyze the number of local minima is in some small special cases using this idea. Similarly in [3] the reduced problem is used 

to analyze the convergence of GN in 2D pose-graphs with spherical noise covariance. 

## VII. CONCLUSION AND FUTURE WORK 

In this paper we proposed a scalable and efficient algorithm to take advantage of the separable structure of SLAM. It was shown that by exploiting this structure, we can achieve faster and more reliable convergence than the state-of-the-art solvers. A key contribution of this work comes from establishing the link to a less-known but vast literature on separable NLS problems. In particular, recognizing the equivalence between Algorithm 1 and Algorithm 2 was the missing link that enabled us to retain sparsity while exploiting the separable structure of problem through Algorithm 3. This link also provides a firm theoretical justification for the proposed algorithm. 

The proposed algorithm can be applied to the most common forms of SLAM (2D/3D feature-based and pose-graphs) without any restrictive assumption. Our algorithm is not limited to a particular type of NLS solver and the benefits it brings along are orthogonal to those of other possible improvements such as a more efficient implementation (of e.g., GN) or using different Newton-based solvers, trust-region or line search techniques. As an advantage, the proposed algorithm can be easily adopted by the existing back-ends (e.g., LM, Powell’s Dog-leg [23], etc) without any major modification. By stripping down SLAM to its nonlinear core and recovering the conditionally optimal estimate for linear variables, our approach yields more effective and reliable iterations than solving the full NLS problem. The number of iterations required for solving the reduced problem (15) was shown to be less than that of the full NLS problem. Exploiting separability is especially beneficial when GN (or other Newton-based solver) iterations are relatively costly and/or when it takes more than few iterations to solve the full NLS problem. Datasets with relatively high measurement noise and bad initial guess are among those cases. 

Our current implementation relies on **g**<sup>`2`</sup> **o** to compute the intermediate GN step. Identifying and merging some of the terms shared between VP and GN to achieve a more tightly integrated implementation can further improve the computational benefits of the proposed method, especially in nonspherical problems. According to our empirical observations, using VP seems to be more crucial in the first few iterations. A hybrid strategy would involve an “iteration management” stage in which the back-end can select the next iteration (e.g., VP or GN) based on the expected gain and cost. Such a strategy may impose negligible extra cost since GN step is already computed in each iteration of Algorithm 3. We plan to investigate this idea in our future work. 

## ACKNOWLEDGMENTS 

We would like to thank C. Stachniss et al. and the EUROPA project for providing the UTM-Downtown dataset, D. Haehnel for the Intel dataset, E. Olson for the Manhattan dataset, M. Kaess for City10K and Sphere2500 datasets, M. Smith et al. for the New College dataset [26], and R. Kuemmerle et al. for **g**<sup>`2`</sup> **o** [18]. This work was supported by the Australian Research Council Discovery Project **DP120102786** . 

REFERENCES 

- [1] RH Barham and Wanzer Drane. An algorithm for least squares estimation of nonlinear parameters when some of the parameters are linear. _Technometrics_ , 14(3):757–766, 1972. 

- [2] Ake Bj¨orck. _Numerical methods for least squares problems_ . SIAM, 1996. 

- [3] Luca Carlone. Convergence analysis of pose graph optimization via gauss-newton methods. In _Proceedings of the IEEE International Conference on Robotics and Automation (ICRA)_ , May 2013. 

- [4] Luca Carlone, Rosario Aragues, Jose Castellanos, and Basilio Bona. A linear approximation for graph-based simultaneous localization and mapping. In _Proceedings of Robotics: Science and Systems_ , Los Angeles, CA, USA, June 2011. 

- [5] Luca Carlone, Rosario Aragues, Jos´e A Castellanos, and Basilio Bona. A fast and accurate approximation for planar pose graph optimization. _The International Journal of Robotics Research_ , pages 965–987, 2014. 

- [6] Yanqing Chen, Timothy A Davis, William W Hager, and Sivasankaran Rajamanickam. Algorithm 887: Cholmod, supernodal sparse cholesky factorization and update/downdate. _ACM Transactions on Mathematical Software (TOMS)_ , 35(3):22, 2008. 

- [7] Frank Dellaert and Michael Kaess. Square root SAM: Simultaneous localization and mapping via square root information smoothing. _The International Journal of Robotics Research_ , 25(12):1181–1203, 2006. 

- [8] Gamini Dissanayake, Paul Newman, Steve Clark, Hugh Durrant-Whyte, and Michael Csorba. A solution to the simultaneous localization and map building (SLAM) problem. _Robotics and Automation, IEEE Transactions on_ , 17(3):229–241, 2001. 

- [9] Arnaud Doucet. On sequential simulation-based methods for bayesian filtering. Technical Report CUED/FINFENG/TR. 310, Cambridge University Department of Engineering, 1998. 

- [10] Arnaud Doucet and Adam M Johansen. A tutorial on particle filtering and smoothing: Fifteen years later. _Handbook of Nonlinear Filtering_ , 12:656–704, 2009. 

- [11] Hugh Durrant-Whyte and Tim Bailey. Simultaneous localisation and mapping (SLAM): Part I the essential algorithms. _Robotics and Automation Magazine_ , 13(2): 99–110, 2006. 

- [12] Gene Golub and Victor Pereyra. The differentiation of pseudo-inverses and nonlinear least squares problems whose variables separate. _SIAM Journal on numerical analysis_ , 10(2):413–432, 1973. 

- [13] Gene Golub and Victor Pereyra. Separable nonlinear least squares: the variable projection method and its applications. _Inverse problems_ , 19(2):R1, 2003. 

- [14] Giorgio Grisetti, Rainer Kummerle, Cyrill Stachniss, and Wolfram Burgard. A tutorial on graph-based slam. _Intelligent Transportation Systems Magazine, IEEE_ , 2(4): 31–43, 2010. 

- [15] Gibson Hu, Kasra Khosoussi, and Shoudong Huang. Towards a reliable SLAM back-end. In _Intelligent Robots and Systems (IROS), 2013 IEEE/RSJ International Conference on_ , pages 37–43. IEEE, 2013. 

- [16] Linda Kaufman. A variable projection method for solving separable nonlinear least squares problems. _BIT Numerical Mathematics_ , 15(1):49–57, 1975. 

- [17] Kasra Khosoussi, Shoudong Huang, and Gamini Dissanayake. Exploiting the separable structure of SLAM (supplemental material), 2015. URL https://github.com/ kasra/rss15-public. 

- [18] Rainer Kuemmerle, Giorgio Grisetti, Hauke Strasdat, Kurt Konolige, and Wolfram Burgard. g2o: A general framework for graph optimization. In _Proc. of the IEEE Int. Conf. on Robotics and Automation (ICRA)_ , 2011. 

- [19] Todd Lupton and Salah Sukkarieh. Visual-inertial-aided navigation for high-dynamic motion in built environments without initial conditions. _Robotics, IEEE Transactions on_ , 28(1):61–76, 2012. 

- [20] Michael Montemerlo, Sebastian Thrun, Daphne Koller, and Ben Wegbreit. FastSLAM: A factored solution to the simultaneous localization and mapping problem. In _Proceedings of the National conference on Artificial Intelligence_ , pages 593–598. Menlo Park, CA; Cambridge, MA; London; AAAI Press; MIT Press; 1999, 2002. 

- [21] Michael Montemerlo, Sebastian Thrun, Daphne Koller, and Ben Wegbreit. FastSLAM 2.0: An improved particle filtering algorithm for simultaneous localization and mapping that provably converges. In _Proceedings of the Sixteenth International Joint Conference on Artificial Intelligence (IJCAI)_ , Acapulco, Mexico, 2003. IJCAI. 

- [22] Teresa Anne Parks. _Reducible nonlinear programming problems (separable least squares)_ . PhD thesis, Rice University, 1985. 

- [23] David M. Rosen, Michael Kaess, and John J. Leonard. RISE: An incremental trust-region method for robust online sparse least-squares estimation. _IEEE Trans. on Robotics, TRO_ , 30(5):1091–1108, Oct 2014. 

- [24] Axel Ruhe and Per Ake Wedin.<sup>˚</sup> Algorithms for separable nonlinear least squares problems. _SIAM Review_ , 22(3): 318–337, 1980. 

- [25] George A. F. Seber and C. J. Wild. _Nonlinear Regression_ . Wiley-Interscience, 1989. 

- [26] Mike Smith, Ian Baldwin, Winston Churchill, Rohan Paul, and Paul Newman. The new college vision and laser data set. _The International Journal of Robotics Research_ , 28(5):595–599, May 2009. ISSN 0278-3649. doi: http://dx.doi.org/10.1177/0278364909103911. URL http://www.robots.ox.ac.uk/NewCollegeData/. 

- [27] Heng Wang, Gibson Hu, Shoudong Huang, and Gamini Dissanayake. On the structure of nonlinearities in pose graph SLAM. In _Proceedings of Robotics: Science and Systems_ , Sydney, Australia, July 2012. 

- [28] Heng Wang, Shoudong Huang, Udo Frese, and Gamini Dissanayake. The nonlinearity structure of point feature SLAM problems with spherical covariance matrices. _Au-_ 

_tomatica_ , 49(10):3112–3119, 2013. 

- [29] Heng Wang, Shoudong Huang, Kasra Khosoussi, Udo Frese, Gamini Dissanayake, and Bingbing Liu. Dimensionality reduction for point feature SLAM problems with spherical covariance matrices. _Automatica_ , 51(0): 149 – 157, 2015. 

- [30] Nikos Zikos and Vassilios Petridis. L-SLAM: Reduced dimensionality FastSLAM with unknown data association. In _Robotics and Automation (ICRA), International Conference on_ , pages 4074–4079. IEEE, 2011. 

- [31] Nikos Zikos and Vassilios Petridis. 6-DoF low dimensionality SLAM (L-SLAM). _Journal of Intelligent & Robotic Systems_ , pages 1–18, 2014.
