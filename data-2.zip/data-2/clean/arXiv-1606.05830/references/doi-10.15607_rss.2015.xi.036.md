<!-- fulltext source=oa_pdf slug=doi-10.15607_rss.2015.xi.036 fetched=2026-09-21T06:25:04+00:00 -->

# Continuous-Time Trajectory Estimation for Event-based Vision Sensors 

Elias Mueggler, Guillermo Gallego and Davide Scaramuzza 

Robotics and Perception Group, University of Zurich 

_{_ mueggler,guillermo.gallego,sdavide _}_ @ifi.uzh.ch 

**_Abstract_ —Event-based vision sensors, such as the Dynamic Vision Sensor (DVS), do not output a sequence of video frames like standard cameras, but a stream of asynchronous events. An event is triggered when a pixel detects a change of brightness in the scene. An event contains the location, sign, and precise timestamp of the change. The high dynamic range and temporal resolution of the DVS, which is in the order of** **_micro_ -seconds, make this a very promising sensor for high-speed applications, such as robotics and wearable computing. However, due to the fundamentally different structure of the sensor’s output, new algorithms that exploit the high temporal resolution and the asynchronous nature of the sensor are required. In this paper, we address ego-motion estimation for an event-based vision sensor using a continuous-time framework to directly integrate the information conveyed by the sensor. The DVS pose trajectory is approximated by a smooth curve in the space of rigid-body motions using cubic splines and it is optimized according to the observed events. We evaluate our method using datasets acquired from sensor-in-the-loop simulations and onboard a quadrotor performing flips. The results are compared to the ground truth, showing the good performance of the proposed technique.** 

## I. INTRODUCTION 

Standard frame-based CMOS cameras operate at fixed frame rates, sending entire images at constant time intervals that are selected based on the considered application [14]. Contrary to standard cameras, where pixels are acquired at regular time intervals (e.g., global shutter or rolling shutter), event-based vision sensors, such as the Dynamic Vision Sensor (DVS) [19], have asynchronous pixels. Each pixel of the DVS immediately triggers an _event_ in case of changing brightness. The temporal resolution of such events is in the order of _micro_ -seconds. It is only these changes that are transmitted, and, consequently, the DVS is also referred to as an event-based vision sensor. Since the output it produces—an event stream—is fundamentally different from video streams of standard CMOS cameras, new algorithms are required to deal with this data. Eventbased adaptations of iterative closest points [24] and optical flow [5] have already been proposed. Recently, event-based visual odometry [9, 17], tracking [28, 23], and Simultaneous Localization And Mapping (SLAM) [29] algorithms have also been presented. The design goal of such algorithms is that each incoming event can asynchronously change the estimated state of the system, thus, preserving the event-based nature of the sensor and allowing the design of highly-reactive systems, such as pen balancing [10] or particle tracking in fluids [12]. 

We aim to use the DVS for ego-motion estimation. The approach provided by traditional visual-odometry frameworks, which estimate the camera pose at discrete times (naturally, the times the images are acquired), is no longer appropriate for event-based vision sensors, mainly due to two issues. First, a single event does not contain enough information to estimate the sensor pose given by the six degrees of freedom (DOF) of a calibrated camera. We cannot simply consider several events to determine the pose using standard computervision techniques (e.g., [18]), because the events typically all have different timestamps, and so the resulting pose will not correspond to any particular time. Second, a DVS typically transmits 10<sup>5</sup> events per second, and so it is intractable to estimate the DVS pose at the discrete times of all events due to the rapidly growing size of the state vector needed to represent all such poses. Instead, we adopt a continuous-time framework approach [7] that solves the previous issues and has additional advantages. Regarding the first issue, an explicit continuous temporal model is a natural representation of the pose trajectory `T` ( _t_ ) of the DVS since it unambiguosly relates each event, occurring at time _tk_ , with its corresponding DVS pose, `T` ( _tk_ ). To solve the second issue, the DVS trajectory is described by a smooth parametric model, with significantly fewer parameters than events, hence achieving state space size reduction and computational efficiency. For example, to remove unnecessary states for the estimation of the trajectory of dynamic objects, [7] proposed to use cubic splines. In the experiments, they could on average reduce the size of the state space by 70-90%. Cubic splines are also used in [13] to model continuous-time trajectories. However, instead of introducing all states and removing them a posteriori, the estimation problem was directly stated in continuous time. Wavelets have also been considered as basis for continuoustime trajectories [3]. The continuous-time framework was also motivated to allow data fusion of multiple sensors working at different rates and to enable increased temporal resolution [7]. For example, [13] adopted it for dealing with two unsynchronized sensors, such as vision and inertial ones. In the same context of visual-inertial fusion, the framework was used by [21] to take into account the different timestamps of the lines of the images acquired by rolling-shutter cameras. Similarly, the continuous-time framework has been applied to actuated lidar [2]. Recently, connections between continuoustime trajectory estimation and Gaussian process regression have been shown both in batch [4] and incremental forms [31]. 

## _A. Contribution_ 

To the authors’ knowledge, this work is the first one where the continuous-time framework is utilized to represent the trajectory of event-based vision sensors (e.g., the DVS), which are asynchronous by design. Previous works used sensors of different rates, but these were not asynchronous by design, but rather _unsynchronized_ with respect to each other. Since events occur at high frequency and do not carry enough information to estimate the full pose of the DVS, this formulation allows us to naturally incorporate all of the information they contain while limiting the size of the state space. It especially allows us to exploit the high temporal resolution of the DVS and enables us to compute the pose at any point in time along the trajectory, with no additional sensing. We describe the DVS pose trajectory using cubic B-splines as temporal basis functions and we estimate it as a _whole_ in a principled optimization approach, as opposed to being estimated from individually-optimized poses. We minimize a geometrically meaningful measure in the image plane of the DVS with respect to the parameters describing the trajectory. The experiments show the good performance of the proposed approach. The method has been tested on datasets acquired from a quadrotor performing flips. 

The remainder of the paper is organized as follows. In Section II, we characterize the Dynamic Vision Sensor (DVS). In Section III, we review previous work on ego-motion methods with event-based vision sensors. The method developed for DVS trajectory estimation is described in Section IV and evaluated in Section V. Section VI draws conclusions and points out future work. 





<!-- Start of picture text -->
Standard CMOS camera<br>∆ t ∆ t ∆ t t<br>DVS<br>t<br><!-- End of picture text -->

(a) Left: The Dynamic Vision Sensor. Right: A standard CMOS camera sends images at a fixed frame rate (blue). A DVS instead sends spike events at the time they occur (red). Each event corresponds to a local, pixel-level change of brightness. 



(b) Visualization of the output of a DVS looking at a rotating dot. Colored dots mark individual events. The polarity of the events is not shown. Events that are not part of the spiral are caused by sensor noise. Figure adapted from [20]. 

Fig. 1. The output of a Dynamic Vision Sensor (DVS). 

## II. DYNAMIC VISION SENSOR (DVS) 

Standard CMOS cameras send full frames at fixed frame rates. On the other hand, event-based vision sensors such as the DVS (Fig. 1(a)) have independent pixels that fire events at local relative brightness changes in continuous time. Specifically, if _I_ ( _x, y_ ) is the brightness or intensity at point **u** = ( _x, y_ )<sup>_⊤_</sup> in the image plane, the DVS generates an event at that location if the change in logarithmic brightness is greater than a threshold [9] (typically 10-15% relative brightness change), 



where _∇_ computes the gradient (with respect to spatial coordinates), **u** ˙ is the _image motion field_ [27, p. 183], _⟨·, ·⟩_ is the dot product, and ∆ _t_ is the time since the previous event at the same pixel location. 

These events are timestamped and transmitted asynchronously at the time they occur using a sophisticated digital circuitry. Each event is a tuple _ek_ = _⟨xk, yk, tk, pk⟩_ , where _xk, yk_ are the pixel coordinates of the event, _tk_ is the timestamp of the event, and _pk ∈{−_ 1 _,_ +1 _}_ is the polarity of the event, which is the sign of the brightness change. This representation is sometimes also referred to as AddressEvents Representation [19]. The set of all events is denoted as _E_ = _{ek}, k_ = 1 _, . . . , nE_ , where _nE_ is the total number of events. 

The DVS has the same optics as traditional perspective cameras, therefore, standard camera models (e.g., pinhole) still apply. The sensor’s spatial resolution is 128 _×_ 128 pixels and it is connected via USB. A visualization of the output of the DVS is shown in Fig. 1(b). An additional advantage of the DVS is its high dynamic range of 120 dB (compared to 60 dB of high quality traditional image sensors). Current research efforts [8] are being carried towards increasing the spatial resolution of the sensor as well as offering the possibility to return the absolute pixel brightness (at standard frame rates) in addition to the events. 

## III. RELATED WORK: EGO-MOTION ESTIMATION WITH EVENT-BASED VISION SENSORS 

A particle-filter approach for robot self-localization using the DVS was introduced in [28] and later extended to SLAM in [29]. However, the system was limited to planar motions and 2-D maps. In the experiments, they used an upward-looking DVS mounted on a ground robot moving at low speed. An externally provided map consisting of line segments on the ceiling was used for navigation. 

In several ego-motion–estimation applications, the DVS has been used in combination with other vision sensors. For example, in [9], an event-based pipeline for visual odometry with the DVS and a regular (CMOS) camera was demonstrated. 

They used a probabilistic framework that processes the events from the DVS to update the relative pose displacement of a mobile platform since the time of the previous CMOS frame. As another example, in the context of SLAM, the DVS was combined with a frame-based RGB-D camera in [30]. The algorithm used a modified particle filter for tracking the current position and orientation of the sensor while at the same time incrementally creating a probabilistic voxel grid map of the previously unknown environment. 

Simultaneous mosaicing and tracking with the DVS was presented in [17]. In that approach, pose tracking was limited to 3-D rotations and they were able to reconstruct superresolution panoramic image mosaics (in absolute grayscale) from estimated brightness gradients. Their probabilistic filtering algorithm was operating on an event-by-event basis. They used a SLAM-like method of two parallel (Bayesian) filters to jointly estimate the camera’s rotational motion and a gradient map of a scene. 

In our previous work [23], we demonstrated robot localization in 3-D (with arbitrary 6-DOF motions) using a DVS, with no additional sensing, during high-speed maneuvers, where rotational speeds of up to 1 _,_ 200<sup>_◦_</sup> /s were measured during quadrotor flips. The focus was to enable a perception pipeline whose latency is negligible compared to the dynamics of the robot. This was done by tracking a set of gradients on a given map on an event-by-event basis, minimizing the reprojection error. 

None of these reviewed ego-motion references has a continuous-time representation of the trajectory of the DVS, which is the approach leveraged in this paper and introduced in the next section. 

## IV. CONTINUOUS-TIME TRAJECTORIES 

Traditional visual odometry and Simultaneous Localization and Mapping (SLAM) formulations use a discrete-time approach, i.e., the camera pose is calculated at the time the image was acquired. Recent works have shown that, for highfrequency data, a continuous-time formulation is preferable to keep the size of the optimization problem bounded [13, 21]. Temporal basis functions, such as B-splines, were proposed for camera-IMU calibration, where the frequencies of the two sensor modalities differ by an order of magnitude. While previous approaches use continuous-time representations mainly to reduce the computational complexity, in the case of an eventbased sensor this representation is required to cope with the asynchronous nature of the events. Unlike a standard camera image or an IMU reading, an event does not carry enough information to estimate the sensor pose by itself. A continuoustime trajectory can be evaluated at any time, in particular at each event’s timestamp, yielding a well-defined pose for every event. Thus, our method is not only computationally effective, but it is also necessary for a proper formulation. 

Following [21], we represent Euclidean space transformations between finite cameras [15, p. 157] by means of 4 _×_ 4 

matrices of the form 



where `R` _∈ SO_ (3) (the rotation group) and **t** _∈_ R<sup>3</sup> are the rotational and translational components of the rigid-body motion, respectively. In homogeneous coordinates, a 3-D point in frame _a_ is mapped to a point in frame _b_ by the change of coordinates **X** _b ∼_ `T` _b,a_ **X** _a_ , where _∼_ means equality up to a non-zero scale factor. Transformations (2) form the special Euclidean group _SE_ (3) [22, p. 30], which has the structure of both a group and a differentiable manifold, i.e., a Lie group. A curve on _SE_ (3) physically represents the motion of a rigid body, e.g., the DVS. The tangent space of _SE_ (3) at the identity is _se_ (3), which has the structure of a Lie algebra. It corresponds to the space of _twists_ , represented by 4 _×_ 4 matrices of the form 



where **v** _∈_ R<sup>3</sup> and **_ω_** � is the 3 _×_ 3 skew-symmetric matrix representing the cross product: **_ω_** � **b** = **_ω_** _×_ **b** _, ∀_ **_ω_** _,_ **b** _∈_ R<sup>3</sup> . Variables **_ω_** and **v** physically represent the angular and linear velocity vectors of the moving DVS. 

Based on the theory of Lie groups, the exponential map from _se_ (3) to _SE_ (3) can be defined, which gives the Euclidean transformation associated to a twist, `T` = exp(<sup>�</sup> **_ξ_** ). The inverse of the exponential map is the logarithmic map � **_ξ_** = log( `T` ). Moreover, every rigid-body motion `T` _∈ SE_ (3) can be represented in such an exponential parametrization, but the resulting twist may not be unique [22, p. 33]. However, to avoid this ambiguity, we adopt a local-chart approach (on the manifold _SE_ (3)) by means of incremental rigid-body motions ( `T` = exp(<sup>�</sup> **_ξ_** ) with small matrix norm _∥_<sup>�</sup> **_ξ_** _∥_ ) given by the relative transformation between two nearby poses along the trajectory of the DVS (see (5)). In addition, this parametrization is free from singularities. Closed-form formulas for the the exp and log maps are given in [22]. 

## _A. Cumulative B-Splines_ 

Following the approaches in [13, 21], we use the continuous trajectory representation given by cubic splines since they are characterized by valuable properties: ( _i_ ) local dependency of the trajectory with respect to the control points defining it, ( _ii_ ) simple analytical derivatives and integrals, and ( _iii_ ) the possibility of having _C_<sup>2</sup> continuity. To this end, we adopt cumulative B-spline basis functions formed using the Lie algebra [11], which produce smooth trajectories in the manifold of rigid-body motions _SE_ (3). 

The continuous trajectory of the DVS is parametrized by control camera poses `T` _w,i_ at times _ti_ , _i ∈{_ 0 _, . . . , n}_ , where, following the sub-index notation in (2), `T` _w,i_ is the transformation from the DVS frame at time _ti_ to a world frame ( _w_ ). We assume that the control poses are uniformly distributed in time, in intervals of size ∆ _t_ . Due to the locality of the cubic B-spline basis, the value of the spline curve at any time _t_ only 

depends on four control poses. Specifically, for _t ∈_ [ _ti, ti_ +1) such control poses occur at times _{ti−_ 1 _, . . . , ti_ +2 _}_ , and we use one absolute pose (in the world frame), `T` _w,i−_ 1, and three incremental poses, parameterized by twists (3)<sup>�</sup> **_ξ_** _q ≡_ `Ω` _q_ , according to the mentioned local approach on _SE_ (3). 

The pose in the spline trajectory at time _t ∈_ [ _ti, ti_ +1) is 



where _u_ ( _t_ ) = ( _t − ti_ ) _/_ ∆ _t ∈_ [0 _,_ 1), the incremental pose from frame at time _tq−_ 1 to frame at time _tq_ is encoded in the twist 



in terms of world-referenced poses, and 



are the cumulative basis functions for the B-splines, derived from the matrix representation of the De Boor-Cox formula [25]. **B**<sup>˜</sup> _j_ is the _j_ -th entry (0 based) of the cubic polynomial vector. 

## _B. Map Representation_ 

To focus on the DVS trajectory estimation problem, we assume that the map of the scene is given and is time invariant. Specifically, the map _M_ is a set of 3-D line segments, 



Line segments _ℓj_ may be parametrized in different ways, for example by their start and end points **X**<sup>_s_</sup> _j_<sup>_,_</sup><sup>**X**</sup><sup>_e_</sup> _j_<sup>_∈_R3.Asitwill</sup> be shown, the objective function (15) measures point-to-line distances in the image plane, so we may relax the requirement of precisely known endpoints of the segments by considering alternative parametrizations, such as Pl¨ucker coordinates of 3-D lines and rough estimates of the segments lengths. The solution of the data association sub-problem (section IV-C2) between events and line segments also confers robustness to our method, which further supports the relaxation of the above representation. 

Given a 3 _×_ 4 projection matrix `P` modeling the perspective projection carried out by the DVS, the lines of the map _M_ can be projected to the image plane by using Pl¨ucker coordinates [26] or by projecting the endpoints of the segments (if they are available) and computing the line through them. The homogeneous coordinates of the projected line through the _j_ -th segment are, respectively, 



where _ℓj_ are the Pl¨ucker coordinates of the _j_ -th 3-D line, Ω is the Klein quadric [15, p.72], and _P_ is the line projection matrix (obtained from `P` ), or 



## _C. DVS Trajectory Estimation_ 

_1) Probabilistic Approach:_ In general, the trajectory estimation problem over an interval [0 _, T_ ] can be cast in a probabilistic form [13], seeking an estimate of the joint posterior density _p_ ( **x** ( _t_ ) _|M,_ **z** 1: _N_ ) of the DVS state **x** ( _t_ ) (pose trajectory) over the interval, given the map _M_ and the set of all measured events **z** 1: _N_ = _{_ **z** 1 _, . . . ,_ **z** _N }_ , **z** _k_ = ( _xk, yk_ )<sup>_⊤_</sup> being the measured event location at time _tk_ . Using Bayes’ rule, and assuming that the map is independent of the DVS trajectory, we may rewrite the posterior as 



In the absence of prior belief for the state, _p_ ( **x** ( _t_ )), the optimal trajectory is the one maximizing the likelihood _p_ ( **z** 1: _N |_ **x** ( _t_ ) _, M_ ). Under the standard assumptions that the measurements are independent of each other (given the trajectory and the map) and that the measurement error in the image coordinates of the events follows a Gaussian distribution, the logarithmic likelihood becomes 



where _K, K, σ_<sup>˜2</sup> are constants. Given the map (7), the predicted value of the event location **z** ˆ _k_ ( **x** ( _tk_ ) _, M_ ) is a point on the projection of one of the 3-D line segments _ℓj_ , and so the reprojection error given by the norm in (14) becomes the Euclidean (perpendicular) distance from the point to a line segment, _d⊥_ ( **z** _, l_ ). The maximization of the likelihood (11) becomes the minimization of the objective function given by the sum of squared distances in the image plane 



where _lj_ ( **x** ( _tk_ )) is the projection of the line segment _ℓj ∈M_ according to the pose specified in the DVS trajectory at the time of the event, _tk_ . Of course, this implies that there is a data association sub-problem consisting of establishing correct correspondences between points and line segments. 

_2) Constrained Optimization in Finite Dimensions:_ The objective function (15) is optimized with respect to the trajectory **x** ( _t_ ) of the DVS, which in general is represented by an arbitrary curve in _SE_ (3), i.e., a “point” in an infinite-dimensional function space. However, because we represent the curve in terms of a finite set of known temporal basis functions (Bsplines, formalized in (4)), the trajectory is parametrized by control poses `T` _w,i_ and, therefore, the optimization problem becomes finite dimensional. In particular, it is a non-linear least squares (NLLS) problem, for which standard numerical 

solvers such as Gauss-Newton or Levenberg-Marquardt can be applied. 

Hence, we estimate the trajectory by minimizing the objective function (15) over the control poses, 



For each event _ek_ , triggered at time _tk_ in the interval [ _ti, ti_ +1), we compute its pose `T` _w,s_ ( _uk_ ) using (4), where _uk_ = ( _tk − ti_ ) _/_ ∆ _t_ . We then project each line segment into the current image plane and compute the distance between the event location **z** _k_ = ( _xk, yk_ )<sup>_⊤_</sup> and the corresponding imaged line segment _lj_ , which is computed using projection matrices `P` ( _tk_ ) _∼_ `K` ( `I` _|_ **0** ) `T`<sup>_−_</sup> _w,s_<sup>1(</sup><sup>_tk_),</sup><sup>`K`beingthetime-invariantintrinsic</sup> parameter matrix of the DVS (once the radial distortion has been removed). To solve the data association sub-problem that establishes correspondences between events and line segments, we use an Iterative Closest Point technique [6]. The optimization problem (16) is then solved in an iterative way using the Ceres solver [1], an efficient numerical implementation for NLLS problems. 

_3) Trajectory Initialization and Extrapolation:_ We assume the first DVS pose to be known: considering that the map consists of line segments (7), the position of the DVS can be computed by integrating the events caused by the segments and using the Hough transform to detect the corresponding lines (see [23]). Due to the local convergence property of the iterative solving strategy, the control poses must be initialized in the basin of attraction of the optimal value. Since we cannot optimize the entire trajectory in one run without prior knowledge, we adopt a growing-window approach, optimizing over all existing control poses. We build up the trajectory by initializing the first four control poses to the known initial pose and run the optimization. We then use the last two control poses to extrapolate the new control pose that we add at the end. Then, we optimize again and repeat until the entire trajectory is approximated. Specifically, for a cubic spline trajectory, to evaluate the pose corresponding to an event with timestamp in the interval _L_ = [ _ti, ti_ +1) we need the two control poses at _ti_ +1 and _ti_ +2 (see section IV-A). A new control pose at time _ti_ +3 is extrapolated when the first event with a timestamp outside the interval _L_ arrives. Extrapolation is performed assuming constant velocity: _Ti_ +3 = _Ti_ +2 _dT_ with _dT_ = _Ti_<sup>_−_</sup> +1<sup>1</sup><sup>_Ti_+2.Intheexperimentswefoundthatthe</sup> influence of new events on the optimization of previous poses decays rapidly, hence if the number of poses becomes very large, one may switch to a sliding-window approach after building up an initial window. 

## V. EXPERIMENTS 

For the experiments, we used the datasets from [23] and compare the results of our continuous-time approach with those achieved by the event-based reprojection error minimization algorithm in [23]. The first experiment uses data captured in a sensor-in-the-loop simulation. The second experiment uses data captured by a DVS mounted on a quadrotor that was performing flips, reaching rotational speeds of 1 _,_ 200<sup>_◦_</sup> /s. In both 



<!-- Start of picture text -->
2 Mueggler [23]<br>Spline<br>Ground Truth<br>1<br>0<br>1<br>0<br>1<br>0<br>− 1 − 1<br>y [m]<br>x [m]<br>[m]z<br><!-- End of picture text -->

Fig. 2. Estimated trajectories for sensor-in-the-loop simulation with respect to the synthetic map (black square). The DVS only senses the apparent motion of the edges of this square. 

cases, the edges of a black square of known size on a white background constitute the map _M_ . The simplicity of the map facilitates the data association problem (see section IV-C2) and allows us to focus on the continuous-time trajectory estimation that naturally incorporates the asynchronous information of event-based cameras. These datasets fulfill all the requirements to test and quantify the results of our method because: (1) the DVS motion is in 6-DOF, (2) the apparent motion is large (this would cause significant motion blur in standard cameras, which would produce a breakdown of tracking algorithms), and (3) ground truth is available. 

## _A. Sensor-in-the-Loop Simulation_ 

In the first experiment, a 3-D simulation on a computer screen was filmed by an actual DVS. The simulation shows a virtual flight in a circle over a black square (see Fig. 2), of which the DVS only senses the apparent motion of the edges. Since the DVS was calibrated with respect to the screen, the ground-truth trajectory is known. The trajectory is shown in Figs. 2 and 3. Control poses were placed every 0 _._ 1 s. The position and orientation errors are shown in Fig. 4, summarized in Table I, and compared to the results of [23]. Among the plots for the six degrees of freedom, those corresponding to _x_ and _y_ positions and roll angle are the most relevant. They reflect the DVS trajectory on a circle while always pointing at the center of the square (cf. Fig 2). The mean reprojection error was 0 _._ 49 pixels. Our results are consistently better than the ones achieved with the algorithm in [23]. 

To measure the error between an estimated orientation `R`<sup>˜</sup> and that of ground truth `R` _gt_ , we use the angle _θ_ of the relative rotation `RR`<sup>˜</sup><sup>_⊤_</sup> _gt_<sup>,computedas(cf.[15,p.584])</sup> 



which is the geodesic distance in _SO_ (3) that comes naturally with the Lie group structure [16]. We compute the position and orientation errors for the pose of every event along the trajectory and then compute the statistics reported in Table I: mean ( _µ_ ), standard deviation ( _σ_ ), and root mean square (RMS). 

The current implementation of our method is not optimized and, similarly to [13] and [21], not real-time. For example, 



<!-- Start of picture text -->
1<br>0 . 5<br>0<br>− 0 . 5<br>− 1<br>0 0 . 5 1 1 . 5 2<br>1<br>0 . 5<br>0<br>− 0 . 5<br>− 1<br>0 0 . 5 1 1 . 5 2<br>1 . 8<br>1 . 7<br>1 . 6<br>1 . 5<br>0 0 . 5 1 1 . 5 2<br>− 150<br>− 155<br>− 160<br>− 165<br>− 170<br>0 0 . 5 1 1 . 5 2<br>10<br>5<br>0<br>− 5<br>− 10<br>0 0 . 5 1 1 . 5 2<br>400<br>300<br>200<br>100<br>0<br>0 0 . 5 1 1 . 5 2<br>time [s]<br>[m]x<br>[m]y<br>[m]z<br>roll[deg]<br>pitch[deg]<br>[deg]yaw<br><!-- End of picture text -->

Fig. 3. Plots of the six degrees of freedom for the sensor-in-the-loop experiment showing results of the method in [23] (cyan), our method (blue), and ground truth (black). 



<!-- Start of picture text -->
0 . 4<br>Mueggler [23]<br>0 . 3<br>Spline<br>0 . 2<br>0 . 1<br>0<br>0 0 . 5 1 1 . 5 2<br>10<br>Mueggler [23]<br>8<br>Spline<br>6<br>4<br>2<br>0<br>0 0 . 5 1 1 . 5 2<br>time [s]<br>Position[m]error<br>Orientation[deg]error<br><!-- End of picture text -->

Fig. 4. Position and orientation errors for the sensor-in-the-loop experiment. 



<!-- Start of picture text -->
TABLE I<br>RESULTS OF THE SENSOR-IN-THE-LOOP EXPERIMENT.<br><!-- End of picture text -->

||Positi|on error|[cm]|Orient|ation error|[<sup>_◦_</sup>]|
|---|---|---|---|---|---|---|
||_µ_|_σ_|RMS|_µ_|_σ_|RMS|
|[23]|7_._79|3_._94|8_._73|2_._74|1_._07|2_._94|
|Spline|5_._47|0_._81|5_._53|1_._72|0_._21|1_._74|



it takes 87 _._ 7 s to optimize a trajectory with 23 control poses from 40 _,_ 518 events. However, our formulation results in an optimization problem with very few variables (i.e., the control poses) compared to the number of observations (i.e., the events) and, thus, is potentially real-time capable: possible optimizations include the computation of analytic derivatives (instead of numerical ones) and motion-dependent controlpose placement. 

## _B. Quadrotor Experiment_ 

The second experiment uses data provided by a DVS mounted on a quadrotor that performed flips around the optical axis of the DVS. The experimental setup is shown in Fig. 5. During high-speed maneuvers of mobile robots, images from standard cameras suffer from strong motion-blur effects (see Fig. 5(c)). However, the high temporal resolution of the DVS, which is in the order of _micro-_ seconds, allows us to track such fast motions. In the present case, the rotational speed of the quadrotor reached 1 _,_ 200<sup>_◦_</sup> /s. Fig. 5(d) shows all events in a time interval of 2 ms during a flip. The color (red or blue) corresponds to the sign of the brightness change. 

Fig. 6 shows the trajectories of our approach together with the estimated poses of [23] and the ground truth, which was measured with an OptiTrack motion capture system. Control poses were placed every 0 _._ 05 s. The errors for both algorithms are shown in Fig. 7 and analyzed in Table II. The most relevant plots of the six degrees of freedom are the height ( _z_ ) and roll angle. The quadrotor accelerates upwards, performs the flip, and stabilizes as it goes down. The mean reprojection error 



(a) The DVS mounted on a quadrotor: (1) DVS (top) and a standard camera (bottom), (2) single-board computer for data recording, and (3) fiducial markers for tracking. 





<!-- Start of picture text -->
(b) Quadrotor performing a flip.<br>(c) Standard CMOS camera. (d) Integrated DVS events (2 ms).<br>Fig. 5. Experimental Setup.<br><!-- End of picture text -->

|RES|ULTS O|F THE|TABLE I<br>QUADRO|I<br>TOREX|PERIM|ENT.|
|---|---|---|---|---|---|---|
||Posit|ion err|or [cm]|Orien|tation|error [<sup>_◦_</sup>]|
||_µ_|_σ_|RMS|_µ_|_σ_|RMS|
|[23]|7_._3|4_._3|8_._5|2_._8|1_._6|3_._3|
|Spline|4_._6|3_._0|5_._5|1_._8|1_._1|2_._1|





<!-- Start of picture text -->
1<br>0 . 8<br>0 . 6<br>0 0 . 2 0 . 4 0 . 6 0 . 8 1 1 . 2 1 . 4<br>0 . 2<br>0<br>− 0 . 2<br>0 0 . 2 0 . 4 0 . 6 0 . 8 1 1 . 2 1 . 4<br>2<br>1 . 5<br>1<br>0 . 5<br>0 0 . 2 0 . 4 0 . 6 0 . 8 1 1 . 2 1 . 4<br>0<br>− 100<br>− 200<br>− 300<br>0 0 . 2 0 . 4 0 . 6 0 . 8 1 1 . 2 1 . 4<br>10<br>0<br>− 10<br>0 0 . 2 0 . 4 0 . 6 0 . 8 1 1 . 2 1 . 4<br>0<br>− 10<br>− 20<br>0 0 . 2 0 . 4 0 . 6 0 . 8 1 1 . 2 1 . 4<br>time [s]<br>[m]x<br>[m]y<br>[m]z<br>roll[deg]<br>pitch[deg]<br>[deg]yaw<br><!-- End of picture text -->

Fig. 6. Plots of the six degrees of freedom for the quadrotor dataset showing the results of the method in [23] (cyan), our method (blue), and ground truth (black). 

after our optimization was 0 _._ 61 pixels. Again, these results outperform those by algorithm [23]. 



<!-- Start of picture text -->
0 . 4<br>Mueggler [23]<br>0 . 3<br>Spline<br>0 . 2<br>0 . 1<br>0<br>0 0 . 2 0 . 4 0 . 6 0 . 8 1 1 . 2 1 . 4<br>15<br>Mueggler [23]<br>10 Spline<br>5<br>0<br>0 0 . 2 0 . 4 0 . 6 0 . 8 1 1 . 2 1 . 4<br>time [s]<br>Position[m]error<br>Orientation[deg]error<br><!-- End of picture text -->

Fig. 7. Position and orientation errors for the quadrotor experiment. 

## VI. CONCLUSIONS AND FUTURE WORK 

In this paper, we presented a method to estimate the trajectory of an event-based vision sensor using a continuoustime framework, which constitutes a first step towards eventbased visual SLAM in 6-DOF and without additional sensing. This approach can deal with the high temporal resolution and asynchronous nature of the DVS’ events in a principled way, while providing a compact and smooth representation of the trajectory using a parametric cubic spline model. We optimized the approximated trajectory according to a geometrically meaningful error measure in the image plane, which has a probabilistic justification. We tested our method on real sensor data from two experiments. In both the sensor-in-theloop and flipping-quadrotor datasets, our method outperformed previous algorithms when comparing to the ground truth. While the experiments were carried out with a simplified map, the method can cope with arbitrary scenes composed of line segments, which are common in man-made environments. 

Control poses are currently placed equidistant in time, but a more sensible strategy would be to add new control poses according to the event rate and scene complexity. Future work may also extend the method to remove the need for a given map, in the spirit of SLAM. For robotic applications with event-based vision sensors on a mobile platform, our method could be extended to incorporate robot-dynamics motion models. 

## ACKNOWLEDGMENTS 

This research was supported by the Swiss National Science Foundation through project number 200021-143607 (Swarm of Flying Cameras), the National Centre of Competence in Research (NCCR) Robotics, and Google. 

## REFERENCES 

- [1] Sameer Agarwal, Keir Mierle, and Others. Ceres solver. http://ceres-solver.org. 

- [2] H. Alismail, L.D. Baker, and B. Browning. Continuous trajectory estimation for 3D SLAM from actuated lidar. In _IEEE Intl. Conf. on Robotics and Automation (ICRA)_ , 2014. 

- [3] S. Anderson, F. Dellaert, and T.D. Barfoot. A hierarchical wavelet decomposition for continuous-time SLAM. In _IEEE Intl. Conf. on Robotics and Automation (ICRA)_ , 2014. 

- [4] T.D. Barfoot, C.H. Tong, and S. S¨arkk¨a. Batch Continuous-Time Trajectory Estimation as Exactly Sparse Gaussian Process Regression. In _Robotics: Science and Systems (RSS)_ , 2014. 

- [5] R. Benosman, C. Clercq, X. Lagorce, S.-H. Ieng, and C. Bartolozzi. Event-Based Visual Flow. _IEEE Trans. Neural Networks and Learning Systems_ , 25(2):407–417, 2014. 

- [6] P.J. Besl and Neil D. McKay. A method for registration of 3-D shapes. _IEEE Trans. Pattern Anal. Machine Intell._ , 14(2):239–256, 1992. 

- [7] C. Bibby and I.D. Reid. A hybrid SLAM representation for dynamic marine environments. In _IEEE Intl. Conf. on Robotics and Automation (ICRA)_ , 2010. 

- [8] C. Brandli, R. Berner, M. Yang, S.-C. Liu, and T. Delbruck. A 240x180 130dB 3us Latency Global Shutter Spatiotemporal Vision Sensor. _IEEE J. of Solid-State Circuits_ , 2014. 

- [9] A. Censi and D. Scaramuzza. Low-Latency Event-Based Visual Odometry. In _IEEE Intl. Conf. on Robotics and Automation (ICRA)_ , 2014. 

- [10] J. Conradt, M. Cook, R. Berner, P. Lichtsteiner, RJ. Douglas, and T. Delbruck. A Pencil Balancing Robot using a Pair of AER Dynamic Vision Sensors. In _Intl. Conf. on Circuits and Systems (ISCAS)_ , 2009. 

- [11] P. Crouch, G. Kun, and F. Silva Leite. The De Casteljau Algorithm on Lie Groups and Spheres. _Journal of Dynamical and Control Systems_ , 5(3):397–429, 1999. 

- [12] D. Drazen, P. Lichtsteiner, P. Hafliger, T. Delbruck, and A. Jensen. Toward real-time particle tracking using an event-based dynamic vision sensor. _Experiments in Fluids_ , 51(5):1465–1469, 2011. ISSN 0723-4864. 

- [13] P. Furgale, T.D. Barfoot, and G. Sibley. ContinuousTime Batch Estimation using Temporal Basis Functions. In _IEEE Intl. Conf. on Robotics and Automation (ICRA)_ , 2012. 

- [14] A. Handa, R.A. Newcombe, A. Angeli, and A.J. Davison. Real-Time Camera Tracking: When is High Frame-Rate Best? In _Eur. Conf. on Computer Vision (ECCV)_ , 2012. 

- [15] R. Hartley and A. Zisserman. _Multiple View Geometry in Computer Vision_ . Cambridge University Press, 2003. Second Edition. 

- [16] D. Q. Huynh. Metrics for 3D Rotations: Comparison and Analysis. _Journal of Mathematical Imaging and Vision_ , 35(2):155–164, 2009. 

- [17] H. Kim, A. Handa, R. Benosman, S.-H. Ieng, and A. J. Davison. Simultaneous Mosaicing and Tracking with an 

Event Camera. In _British Machine Vision Conf. (BMVC)_ , 2014. 

- [18] L. Kneip, D. Scaramuzza, and R. Siegwart. A novel parametrization of the perspective-three-point problem for a direct computation of absolute camera position and orientation. In _Proc. IEEE Int. Conf. Computer Vision and Pattern Recognition_ , pages 2969–2976, 2011. 

- [19] P. Lichtsteiner, C. Posch, and T. Delbruck. A 128 _×_ 128 120 dB 15 _µ_ s latency asynchronous temporal contrast vision sensor. _IEEE J. of Solid-State Circuits_ , 43(2): 566–576, 2008. 

- [20] S.-C. Liu and T. Delbruck. Neuromorphic sensory systems. _Current Opinion in Neurobiology_ , 20(3):288– 295, 2010. 

- [21] S. Lovegrove, A. Patron-Perez, and G. Sibley. Spline Fusion: A continuous-time representation for visual-inertial fusion with application to rolling shutter cameras. In _British Machine Vision Conf. (BMVC)_ , 2013. 

- [22] Y. Ma, S. Soatto, J. Ko˘seck´a, and S. Shankar Sastry. _An Invitation to 3-D Vision: From Images to Geometric Models_ . Springer, 2004. 

- [23] E. Mueggler, B. Huber, and D. Scaramuzza. Event-based, 6-DOF Pose Tracking for High-Speed Maneuvers. In _IEEE/RSJ Intl. Conf. on Intelligent Robots and Systems (IROS)_ , 2014. 

- [24] Z. Ni, A. Bolopion, J. Agnus, R. Benosman, and S. Reg- 

nier. Asynchronous Event-Based Visual Shape Tracking for Stable Haptic Feedback in Microrobotics. _IEEE Trans. Robotics_ , 28:1081–1089, 2012. 

- [25] K. Qin. General matrix representations for B-splines. _The Visual Computer_ , 16(3–4):177–186, 2000. 

- [26] J. I. Ronda, A. Vald´es, and G. Gallego. Line Geometry and Camera Autocalibration. _J. of Math. Imaging Vis._ , 32(2):193–214, 2008. 

- [27] E. Trucco and A. Verri. _Introductory Techniques for 3- D Computer Vision_ . Prentice Hall PTR, Upper Saddle River, NJ, USA, 1998. ISBN 0132611082. 

- [28] D. Weikersdorfer and J. Conradt. Event-based Particle Filtering for Robot Self-Localization. In _IEEE Intl. Conf. on Robotics and Biomimetics (ROBIO)_ , 2012. 

- [29] D. Weikersdorfer, R. Hoffmann, and J. Conradt. Simultaneous Localization and Mapping for event-based Vision Systems. In _Intl. Conf. on Computer Vision Systems (ICVS)_ , 2013. 

- [30] D. Weikersdorfer, D. B. Adrian, D. Cremers, and J. Conradt. Event-based 3D SLAM with a depth-augmented dynamic vision sensor. In _IEEE Intl. Conf. on Robotics and Automation (ICRA)_ , pages 359–364, June 2014. 

- [31] Xinyan Yan, Vadim Indelman, and Byron Boots. Incremental Sparse GP Regression for Continuous-time Trajectory Estimation & Mapping. In _NIPS Workshop on Autonomously Learning Robots_ , 2014.
