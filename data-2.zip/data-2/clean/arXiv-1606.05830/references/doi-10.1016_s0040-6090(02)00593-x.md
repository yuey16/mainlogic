<!-- fulltext source=oa_pdf slug=doi-10.1016_s0040-6090(02)00593-x fetched=2026-09-21T06:24:30+00:00 -->

Thin Solid Films 418 (2002) 51–58 

# Olfaction-based mobile robot navigation 

Lino Marques*, Urbano Nunes, Anıbal´ T. de Almeida 

_Department of Electrical and Computer Engineering, Institute of Systems and Robotics, University of Coimbra, 3030-290 Coimbra, Portugal_ 

### **Abstract** 

It is well known that insects and other animals use olfactory senses in a wide variety of behavioural processes, namely to recognize and locate food sources, detect predators, and find mates. This article discusses the gathering of olfactive information and its utilization by a mobile robot to find a specific odour source in a room with turbulent phenomena’s and multiple sources of odour. Three navigation algorithms are compared with a simple gas sensor and with an electronic nose. Their performance in finding an ethanol source in a room with obstacles is evaluated. The first navigation strategy is based on bacteria chemotaxis. The second strategy is based on the male silkworm moth algorithm that is used to search and track a female moth pheromone plume. The last strategy is based on the estimation of odour geometry and gradient tracking. The electronic nose utilized is composed by an array of different and weakly selective metal oxide gas sensors. The odours are identified and quantified by a pattern recognition algorithm based on an artificial neural network. The test bed for the navigation algorithms was a Nomad Super Scout II mobile robot. � 2002 Elsevier Science B.V. All rights reserved. 

_Keywords:_ Mobile robot navigation; Chemotaxis; Odour source localization; Artificial olfaction 

## **1. Introduction** 

One of the greatest challenge to the robotics research community is the development of intelligent machines capable of autonomous navigation in natural environments. Such machines will rely on a complex sensoring system able to gather the important features of the environment and on intelligent control algorithms that generate the appropriate actions to the sensed environment w1x. Although it is rather common to find robots with sensors that mimic the animal world (particularly the human senses), sensors for taste and smell (chemical sensors) are by far the least found on robotics. The reasons for that are not only the reduced importance of those senses in human motion, but also a consequence of the long way for chemical sensors to evolve in order to become similar to their biological counterparts w2x. 

Robots can take advantage from an electronic nose when they need to carry out some chemically related tasks, such as identification of washed zones by cleaning robots (Fig. 1a), follow odour tracks (Fig. 1b) or find 

*Corresponding author. Tel.: q351-239-796-277; fax: q351-239406-672. _E-mail address:_ lino@isr.uc.pt (L. Marques). 

sources of odour, like gas leaks, drugs, explosives, landmines, etc. (Fig. 1c). 

Other research groups have already addressed the utilization of gas sensors in the robotics field. Ishida et al. used metal oxide gas sensors to build an odour compass w3,4x and to find an odour source w5–7x. Russell and Deveza laid down a camphor track and used two gravimetric sensors to follow that track with a robot w8,9x. In other work, Russell proposed algorithms to follow an odour plume until the source is found w10x. Kuwana and Shimoyama implemented the silkworm moth algorithm in a mobile robot with two insect antennae as pheromone sensors w11x. Kazadi uses a similar algorithm to track a water vapour plume with a small mobile robot equipped with resistive polymer sensors w12x. Grasso et al. developed a biomimetic robot lobster (RoboLobster) to investigate the way lobsters localize and track odour plumes. This robot can move in water and is equipped with left and right conductivity sensors. Grasso’s research team is still improving their robot in order to behave like real lobsters w13x. All these groups explored the utilization of only one kind of sensor or navigation algorithm. Because the used sensors are not very selective, in the presence of multiple odours, 

0040-6090/02/$ - see front matter � 2002 Elsevier Science B.V. All rights reserved. PII: S0040-6090<sup>Ž</sup> 02<sup>.</sup> 00593-X 

<mark>52</mark> 

_<mark>L. Marques et al. / Thin Solid Films 418 (2002) 51–58</mark>_ 



Fig. 1. There are several animal behaviours based on olfactory sensing that can be implemented on mobile robots, namely the following: (a) repellent behaviours, where a robot goes away from an odour. This behaviour can be used on a cleaning robot to detect the pavement already cleaned. (b) and (c) represent attractive behaviours. In (b) the robot A mark a chemical trail on the ground that can be followed (and maybe reinforced) by robots B and C. In (c) the robot follows the chemical gradient of an odour plume in order to find the odour source. 

it is possible to find other odour sources than the one pursuit. Morse et al. simulated the chemotaxis of a _C. elegans_ worm and experimented the simulated algorithms in a small mobile robot equipped with a photosensor to navigate through a light gradient w14x. Holland w15x, Leow w16x, Pierce-Shimomura w17x and Sandini w18x also used software agents to simulate the movement of ‘creatures’ in chemical gradients. 

An interesting aspect to study is how the complexity of the algorithm or the sensing selectivity improves the performance of finding the odour source inside turbulent plumes. This work uses three different algorithms with increasing complexity. One of the most simple algorithms that can be used to move through a chemical gradient is the chemotaxis behaviour presented for instance by _E. coli_ bacteria. A more complex, but also very well studied behaviour is the pheromone plume tracing behaviour presented by the male silkworm moth. The most complex algorithm that can potentially minimize the moving distance consists in plume estimation with gradient tracking. 

## _1.1. The biased random walk of bacteria_ 

Bacteria are microorganisms which are too small to measure concentration gradients over the length of their bodies. In a constant environment, motile bacteria generally move in a random walk of straight runs punctuated by brief periods of reversal that serve to randomise the direction of the next run. The chemotaxis system controls the probability of a reversal. If during a run the bacteria determine that conditions are improving, then it suppresses reversals so the cell keeps moving in the preferred direction. If on the other way the conditions are getting worse then the runs become shorter and the frequency of the tumbles increases so the cell chooses another random heading. The effect of this mechanism 

is to bias the random walks so that bacteria tend to migrate toward attractant and away from repellents w19x w20x. Holland and Melhuish w15x simulated the locomotion of animats toward a point source of stimulation. The simulated animats have a single symmetrical sensor and present behaviours based on those found in bacteria and worms. 

## _1.2. Pheromone searching in the male silkworm moth_ 

In 1959, Adolph Butenandt succeeded to identify the chemical structure of a sex attractant emitted by female silkworm moth, _Bombyx mori_ , and named the substance _bombykol_ . In the same year Karlson and Luscher proposed the term _pheromone_ (from the Greek _pherein_ ‘to transfer’, and _hormon_ ‘to excite’) for substances, such as bombykol that are released to the environment and excite individuals of the same species at a distance w21x. The male moth’s antennae contains approximately 20 000 olfactory hairs that capture about a quarter of the _bombykol_ molecules that passes through it. When a male moth detects _bombykol_ , it starts the following sequence of movements to search for the female releasing the pheromone molecules w22x. 

1. It orients anemotactically in the upwind direction and 

2. Starts a sinusoidal zigzag movement across the longitudinal axis of the odour plume. 

3. Upon loss of contact with the odour plume, the moth flies back in a circle to re-enter in the active space. 

## _1.3. Gradient driven robot motion_ 

A possible way to find the source of an odour plume is to estimate the local concentration gradient and move the robot in the direction of the gradient’s increase. This 

<mark>53</mark> 

_<mark>L. Marques et al. / Thin Solid Films 418 (2002) 51–58</mark>_ 



Fig. 2. Main mobile robot behaviours. 

can be done with a robot equipped with two or more physically separated sensing units where the robot heading should be toward the sensor with higher output w23x. Considering a differential structure mobile robot with two sensors placed perpendicularly to the direction of motion, the robot head is toward the maximum concentration gradient when both sensors have the same output level. A problem experimented with this approach is that for low concentration gradients, the instantaneous concentration fluctuation due to turbulent phenomena is bigger then the average concentration differences between the two sensors. A solution found to this problem was to use the concentration values gathered during the motion of the robot to estimate the odour plume geometry and the local concentration gradient w24x. 

## **2. The sensing system** 

The sensing system developed for measuring chemical plumes with a robot is composed by two arrays (left and right) of four Figaro metal oxide gas sensors (TGS 2600, TGS 2610, TGS 2611, and TGS 2181). The main target gases of these sensors are general air contaminants, combustible gases, methane and ethanol, respectively. Besides the favoured gas, all of them show some sensitivity to other reducing gases. Using this array of sensors, it is possible to test the same control algorithm with different sensing selectivities. The main characteristic of metal oxide gas sensor is an almost linear decrease in the logylog space of its internal resistance with the increase in the concentration of a reducing gas. The following equation is an approximation of the sensor resistance w26x. 

## _1.4. Robot control architecture_ 

A common approach to control the motion of simple mobile robots is to use a behaviour-based reflexive architecture like the _Subsumption Architecture_ proposed by Brooks w25x. In behaviour-based architectures the actuators are tightly coupled to the sensing layers of the robot through independent processes that implement a set of goal oriented reflexive behaviours. In the subsumption architecture the control signal to the actuators is the output of the active behaviour with higher priority level. Other variants might use a combination from the output of all active behaviours (Fig. 2). It is common to find in this robot control architecture a repulsive behaviour to avoid collision with obstacles and an attractive behaviour that moves the robot toward the goal. 



## a _R_ sy _R_ 0s _KC_ 

where _R_ s represents the sensor resistance, _R_ 0 is the resistance in clean air, _C_ is the concentration of the reducing gas, and a represents the sensitivity of the sensor to the considered gas. 

Each array of the nose was mounted on a small printed circuit board with the necessary signal conditioning circuits. The sensor resistance is measured through a 12-bit 16 channel data acquisition board (Advantech PCM-3718). 

Fig. 3 presents the calibration setup. This setup is composed by a Dani CG 1000 gas chromatograph and three Hastings mass flow controllers that control the input mixture of synthetic air, methanol and ethanol vapour. The gas mixture is inserted into a Perspex box that contain both sensor arrays and in parallel is moni- 

<mark>54</mark> 

_<mark>L. Marques et al. / Thin Solid Films 418 (2002) 51–58</mark>_ 



Fig. 3. Calibration setup for both arrays of the nose. 

tored by the chromatograph. The air inside the box is mixed by a small fan. 

The gas identification is made with a three layer (4:4:2) feedforward neural network (Fig. 4). In the training process, different concentrations of the gas mixture were presented to both sensor arrays and their output was compared with the output from the gas chromatograph w27,28x. The errors were back-propagated to adjust the weights of the net. After this process, each array could identify and quantify the amount of methanol and ethanol presented in the mixture and, more important, the two arrays presented similar responses to the same stimuli w24x. 

and in large spaces, fluid flow is the dominant physical force involved in the transport of molecules forming an odour plume. An odour plume carries information not just about the chemical composition, but also about its spatial and temporal profile. The way that plume is perceived can give useful insights to estimate the odour source location. 

Dispersion and diffusion processes can be represented by a set of differential equations. To model odour plumes in real turbulent environments it is necessary to have a rigorous model of the environment geometry and solve the resulting equations using numerical methods. This approach is very complicated and of reduced practical interest to estimate the odour source localization in real- 

## **3. Modelling odour fields** 

Odour molecules move through the environment by two physical forces: fluid flow and diffusion. In outdoors 





Fig. 4. Electronic nose array. 

Fig. 5. Super Scout II mobile robot with the two gas sensing arrays. 

<mark>55</mark> 

_<mark>L. Marques et al. / Thin Solid Films 418 (2002) 51–58</mark>_ 

time by a mobile robot (Fig. 5). A simpler approach to model the odour fields consists of using a statistical model valid for time-averaged gas distributions. Using this approach, the dispersion of an odour released from a point source at a constant rate _Q_ can be expressed by the following Gaussian equation w29x: 



where _C_ is the odour concentration (mgym3), _Q_ is the rate of odour generation (mgys), _U_ is the average wind speed in the _X_ axis direction (mys), s _y_ and s _x_ are the standard deviation of the odour plume in the horizontal and vertical axis respectively (m), _h_ is the effective height of the source (m) and _x_ , _y_ and _z_ are the distances to the emission source (m). The Eq. (2) is valid for the emission source located in the origin of the coordinates and for the wind flowing in the _X_ axis direction. The dispersion coefficients s _y_ and s _z_ are functions of the _x_ coordinate and can be approximated by the following simplified model w29x: 

s _y_ s _axp_ (3) 



where _a_ , _b_ , _p_ and _q_ are constants. It is worth noting that the mass conservation condition requires all concentration fluxes through each plume cross-sectional plane ( _y_ , _z_ ) to be the same; i.e. for each _x_ the following equation should be met. 



Due to turbulent effects, the gathered concentration values _C_ ( _i x_ , _i y_ , _i z_ , _i t_ ) _i_ show large fluctuations and the gradient does not always point in the direction of the steepest ascent value. To smooth this effect, the local concentrations and the gradient dynamics are liMITed by a recursive digital filter and the filtered values are used to estimate the geometry of the plume w30,31x. 

In open spaces, the robot shortest path will be a segment from the current position to the odour source (goal vector). Using a steepest ascent method (gradient) to navigate through a Gaussian plume does not guarantee the shortest path to the goal. A better goal vector can be defined by a linear combination of the concentration gradient and the upwind vector.<sup>1</sup> 



> 1 In the work presented here, the airflow around the robot is not measured in real-time. It was made a characterization of the flow map in the workspace and those values are used during the experiments. 



(The _z_ coordinate is constant for all robot acquisitions). 

## **4. Field tests and experimental results** 

In order to evaluate the performance improvement to the navigation of a mobile robot that comes from the utilization of an electronic nose, three search algorithms were implemented and tested with the nose and with the TGS 2181 gas sensor alone. Each situation was tried 20 times in order to give some statistical value to the study. An experiment is considered finished if the robot enters in a circle of 50-cm radius from an odour release point or if a 10-min timeout is attained. The ground circular area around the release point is marked with a black colour that can be sensed by a reflective photosensor placed on the bottom of the robot. The mobile robot was programmed with a simple behaviour-based architecture like the one represented in Fig. 2. The _OdourTrack_ is the behaviour that differs among the experiments. This behaviour can use one of the following three strategies: 

The _bacteria’s chemotaxis_ strategy, adapted from Holland w15x, uses a minimum amount of memory. It only needs to save the value of the last measured concentration as it can be seen in the following listing: 

Listing 1: E. Coli bacteria’s chemotaxis algorithm 

While (TRUE){ If (curConc)lastConc) Turn ("Random(58)) MoveForward(m"Random(5%m)) Else Turn("Random(1808)) MoveForward(Random(5%)) } 

Because this algorithm only needs the concentration value in one point of the robot (supposedly the centre), the average output of the left and right sensor array was used. 

The _Silkworm moth_ algorithm allows an efficient search and tracking of the odour plume (Fig. 6). The robot starts to cross wind in order to find traces of the target odour. After detecting the odour of interest, the robot implements an upwind surge, a series of sinusoidal movements limited by the plume boundaries (zigzag). If the robot lost contact with the plume it loops back trying to recover w22,11x. 

The direct gradient following intends to minimize the distance run from the starting point to the odour source. This algorithm fit a Gaussian plume model to the concentration map gathered during the motion and to 

<mark>56</mark> 

_<mark>L. Marques et al. / Thin Solid Films 418 (2002) 51–58</mark>_ 



Fig. 6. State diagram of the moth algorithm to track a pheromone plume. 

the air flow information in order to estimate the location of the odour source. 

Listing 2: Motion algorithm with plume geometry estimation 

SearchForPlumeTraces While(odourDetected) { EstimatePlumeGeom If(Concentration)Threshold) FollowGradient Else SearchForPlumeTraces } 



Fi <mark>g</mark> . 7. Ex <mark>p</mark> erimental setu <mark>p</mark> . 

The practical experiments were done in a large acclimatised laboratory with 20 8C and approximately 65% RH. The work space (represented in Fig. 7) is composed by two odour sources 2 m away from each other, three controllable fans that provide an output air flow of approximately 80 cmys and three obstacles that obstruct the direct path from the starting point to the goal and create a turbulent zone. The starting point of the robot is 5 m upwind from the odour source. 

The results from the set of experiments is summarized in Table 1. That table presents the probability (in percentage) to find the correct odour source in less than 10 min. The time column represents the average time (in seconds) of the successful trials in each situation. 

The first set of experiments shown that, using information from only one gas sensor there exists a large probability of finding the wrong odour source (it is possible to track the wrong odour plume). Using gradient following algorithms, the localized odour source depends mainly on the first plume detected by the mobile robot. When the robot is at the interception of the two plumes, it presents a random behaviour moving to any of the odour sources. This random behaviour can be minimized using an appropriate navigation algorithm. 

The moth algorithm increases the probability to find the right odour plume. 

The last set of experiments show the benefits of implementing an electronic nose based navigation algorithm. Basically the implemented nose increases the selectivity of the sensing system. Using the nose output it is possible to know if the detected plume is the ethanol or the methanol plume. This information allowed the gradient search algorithm and the silkworm moth algorithm to always find, in the tested setup, the right odour source. 

## **5. Conclusions** 

There exist some interesting potential applications for mobile robots equipped with an electronic nose (e.g. findin <mark>g</mark> ex <mark>p</mark> losi <mark>v</mark> e traces in landmine fields <mark>),</mark> but there 

Table 1 

Summary of the experiments 

||Ethanol se|nsors|Electronic nose|
|---|---|---|---|
||Prob.|Time (s)|Prob.<br>Time (s)|
|Bacteria’s|65|324|90<br>243|
|Moth|80|97|100<br>89|
|Gradient|75|92|100<br>73|



<mark>57</mark> 

_<mark>L. Marques et al. / Thin Solid Films 418 (2002) 51–58</mark>_ 

does not yet exist adequate gas sensors for most of those applications because current gas sensors present at least one of the following weaknesses: poor selectivity, low sensitivity, slow response time or large size. Even considering these limitations, it is possible to explore the field of olfaction based mobile robot navigation using commercial gas sensors, but with some restrictions, namely the use of artificially high gas concentrations, a small workspace area and low robot velocities. The work carried out so far evaluated the effectiveness of three odour source localization algorithms in a room with turbulent phenomena and two different odour plumes. The algorithms used in the tests were the pseudo random walk of bacteria, the male silkworm moth pheromone plume searching and a gradient ascent-searching algorithm. The effect of increasing the selectivity, through the utilization of an electronic nose, on the effectiveness of each algorithm was also evaluated. Each situation was tested 20 times and the results show that the gradient ascent algorithm performed better than the others, but not much better then the silkworm moth algorithm. Implementing biologically based algorithms for mobile robot navigation is a very effective way to navigate through odour plumes. The results also show that increasing the selectivity with an array of sensors, instead of a single element, improves the navigation efficiency to find the source of a specific odour in all tested algorithms. When the robot uses only the output from the ethanol gas sensor, there exists a large probability to enter in the methanol plume and find the wrong odour source. 

Testing different olfaction navigation strategies in real environments is time consuming and presents low repeatability among experiments. Simulation can resolve some of these problems. On the other hand, it is difficult to simulate the real-time evolution of an odour plume in unstructured environments. The utilization of light sources to generate a gradient field (instead of gas sources) can reduce the time of the experiments and increase the repeatability (the air will not become poisoned), but some of the important peculiarities related with chemical plumes, namely the turbulence effects, will be lost. Our main efforts in the future will be in the development of collective behaviour searching strategies and learning algorithms to effectively find the source of outdoor odour plumes. An envisaged application for these algorithms will be in finding fields of landmines with mobile robots w32x. 

## **Acknowledgments** 

This work was partially supported by the Portuguese Foundation for Science and Technology (FCT) project POSIy36498ySRIy2000. The authors would like to 

acknowledge the valuable assistance of Goncalo¸ Cordeiro and Jose´ Manuel Silva who performed most of the experimental tests for their undergraduate final project. 

## **References** 

- w1x U. Nunes, R. Araujo,´ L. Marques, International Journal of Systems Analysis, Mode. Simul. 38 (2000) 157–173. 

- w2x L. Marques, A.T. de Almeida, Application of odor sensors in mobile robotics, in: A. de Almeida, O. Khatib (Eds.), Auto. Robo. Sys., Springer, Berlin, 1998, pp. 82–95. 

- w3x H. Ishida, T. Nakamoto, T. Moriizumi, Study of odor compass, International Conference on Multisensor Fusion and Integration for Intelligent Systems, 1996, pp. 222–226. 

- w4x H. Ishida, A. Kobayashi, T. Nakamoto, T. Moriizumi, IEEE Trans. Robo. Auto. 15 (2) (1999) 251–257. 

- w5x H. Ishida, H. Hayashi, M. Takakusaki, T. Nakamoto, T. Moriizumi, R. Kanzaki, Sens. Actuat. A99 (1996) 225–230. 

- w6x T. Nakamoto, H. Ishida, T. Moriizumi, Active odor sensing system, International Symposium on Industrial Electronics, 1997, pp. SS128–SS133. 

- w7x H. Ishida, T. Nakamoto, T. Moriizumi, Sens. Actuat. B49 (1998) 52–57. 

- w8x R. Deveza, D. Thiel, A. Russell, A. Mackay-Sim, Inter. J. Robo. Res. 13 (3) (1994) 232–239. 

- w9x R. Russell, D. Thiel, A. Mackay-Sim, Sensing odour trails for mobile robot navigation, IEEE International Conference on Robotics and Automation, 1994, pp. 2672–2677. 

- w10x R. Russell, D. Thiel, R. Deveza, A. Mackay-Sim, A robotic system to locate hazardous chemical leaks, IEEE International Conference on Robotics and Automation, 1995, pp. 556–561. 

- w11x Y. Kuwana, I. Shimoyama, International J. Robo. Res. 17 (9) (1998) 924–933. 

- w12x S. Kazadi, R. Goodman, D. Tsikata, D. Green, H. Lin, Adapt. Behav. 9 (2) (2000) 175–188. 

- w13x F. Grasso, T. Consi, D. Mountain, J. Atema, Robo. Auton. Sys. 30 (2000) 115–131. 

- w14x T. Morse, T. Ferree,´ S. Lockery, Adapt. Behav. 6 (4) (1998) 393–410. 

- w15x O. Holland, C. Melhuish, Some adaptive movements of animats with single symmetrical sensors, From Animals to Animats, MIT Press. vol. 4, 1996, pp. 55–64. 

- w16x W.K. Leow, Adapt. Behav. 6 (3–4) (1998) 393–410. 

- w17x J.T. Pierce-Shimomura, T.M. Morse, S.R. Lockery, J. Neuro. 19 (1999) 9557–9569. 

- w18x L. Buscemi, M. Prati, G. Sandini, Cellular robotics: Behaviour in polluted environments, Second International Symposium on Distributed Autonomous Robotic Systems, 1994. 

- w19x H. Berg, D. Brown, Nature 239 (7) (1972) 500–504. 

- w20x J. Stock, S.D. Re, Encyclopedia of Microbiology, vol. 1, second ed., Academic Press, 2000, pp. 772–780. 

- w21x L. Watson, Jacobson’s Organ and the Remarkable Nature of Smell, W.W. Norton and Co, London, 1999. 

- w22x R. Kanzaki, Robotics and Auton. Sys. 18 (1996) 33–43. 

- w23x G. Sandini, G. Lucarini, M. Varoli, Gradient driven selforganizing system, IEEE International Conference on Intelligent Robots and Systems, 1993, pp. 429–432. 

- w24x L. Marques, A.T. de Almeida, Electronic nose-based odour source localization, Proceedings Sixth International Workshop on Advanced Motion Control, 2000, pp. 36–40. 

- w25x R. Brooks, IEEE Transactions on Robotics and Automation 2 (1) (1986) 14–23. 

<mark>58</mark> 

_<mark>L. Marques et al. / Thin Solid Films 418 (2002) 51–58</mark>_ 

- w26x K. Ihokura, J. Watson, The Stannic Oxide Gas Sensor, CRC Press, 1994. 

- w27x J. Gardner, E. Hines, M. Wilkinson, Meas. Sci. Tech. 1 (1990) 446–451. 

- w28x T. Moriizumi, T. Nakamoto, Y. Sakuraba, in: J. Gardner, P. Bartlett (Eds.), Sensors and Sensory Systems for an Electronic Nose, vol. E212 of NATO ASI Series, Kluwer Academic Publisher, 1992, pp. 217–236. 

- w29x P. Zannetti, Air Pollution Modeling: Theories, Computational Methods and Available Software, Van Nostrand Reinhold, 1990. 

- w30x R. Deutsch, Estim. Theory, Prentice-Hall, 1965. w31x A. Gelb (Ed.), Appl. Opti. Est., The MIT Press, 1974. 

- w32x L. Marques, M. Rachkov, A.T. de Almeida, Robotica 43´ (2001) 

   - 9–13, in Portuguese.
