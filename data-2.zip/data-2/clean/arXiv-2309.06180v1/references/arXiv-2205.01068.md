<!-- fulltext source=arxiv_html slug=arXiv-2205.01068 fetched=2026-09-16T11:53:06+00:00 -->

# OPT: Open Pre-trained Transformer Language ModelsThanks:  Work done while at Meta AI.

Susan Zhang11footnotemark: 
1
,
Stephen Roller11footnotemark: 
1
,
Naman Goyal11footnotemark: 
1
††thanks:  Equal contribution.
Affiliation: Mikel Artetxe,
Moya Chen,
Shuohui Chen,
Christopher Dewan,
Mona Diab,
Xian Li,
Affiliation: Xi Victoria Lin,
Todor Mihaylov,
Myle Ott22footnotemark: 
2
,
Sam Shleifer22footnotemark: 
2
,
Kurt Shuster,
Daniel Simig,
Affiliation: Punit Singh Koura,
Anjali Sridhar,
Tianlu Wang,
Luke Zettlemoyer
Affiliation: Meta AI
Email: [{susanz,roller,naman}@fb.com](mailto:)

###### Abstract

Large language models, which are often trained for hundreds of thousands of compute days, have shown remarkable capabilities for zero- and few-shot learning. Given their computational cost, these models are difficult to replicate without significant capital. For the few that are available through APIs, no access is granted to the full model weights, making them difficult to study. We present Open Pre-trained Transformers (OPT), a suite of decoder-only pre-trained transformers ranging from 125M to 175B parameters, which we aim to fully and responsibly share with interested researchers. We show that OPT-175B is comparable to GPT-3,11
1
Following [Brown et al. (2020)](#bib.bib10), we use GPT-3 to refer to both the 175B model and the smaller scale models as well. while requiring only 1/7th the carbon footprint to develop. We are also releasing our logbook detailing the infrastructure challenges we faced, along with code for experimenting with all of the released models.

## 1 Introduction

Large language models (LLMs) trained on massive text collections have shown surprising emergent capabilities to generate text and perform zero- and few-shot learning [Brown et al. (2020)](#bib.bib10); [Lieber et al. (2021)](#bib.bib40); [Smith et al. (2022)](#bib.bib82); [Rae et al. (2021)](#bib.bib66); [Chowdhery et al. (2022)](#bib.bib13). While in some cases the public can interact with these models through paid APIs, full model access is currently limited to only a few highly resourced labs.22
2
Exceptions include work by EleutherAI, who released dense models up to 20B in size [Black et al. (2022)](#bib.bib6), Salesforce [Nijkamp et al. (2022)](#bib.bib59), and Meta AI, who released dense models up to 13B and sparse models up to 1.1T [Artetxe et al. (2021)](#bib.bib2). There is also ongoing work from the BigScience workshop (<https://bigscience.huggingface.co/>), which aims to open source very large multilingual language models and datasets. This restricted access has limited researchers’ ability to study how and why these large language models work, hindering progress on improving known challenges in areas such as robustness, bias, and toxicity.

In this technical report, we present Open Pre-trained Transformers (OPT), a suite of decoder-only pre-trained transformers ranging from 125M to 175B parameters, which we aim to fully and responsibly share with interested researchers. We train the OPT models to roughly match the performance and sizes of the GPT-3 class of models, while also applying the latest best practices in data collection and efficient training. Our aim in developing this suite of OPT models is to enable reproducible and responsible research at scale, and to bring more voices to the table in studying the impact of these LLMs. Definitions of risk, harm, bias, and toxicity, etc., should be articulated by the collective research community as a whole, which is only possible when models are available for study.

We are releasing all of our models between 125M and 66B parameters, and will provide full research access to OPT-175B upon request. Access will be granted to academic researchers; those affiliated with organizations in government, civil society, and academia; and those in industry research laboratories.
We are also releasing both the logbook of our model creation as well as our codebase, metaseq,33
3
<https://github.com/facebookresearch/metaseq> which enabled training OPT-175B on 992 80GB A100 GPUs, reaching  147 TFLOP/s utilization per GPU. From this implementation, and from using the latest generation of NVIDIA hardware, we are able to develop OPT-175B using only 1/7th the carbon footprint of GPT-3. While this is a significant achievement, the energy cost of creating such a model is still nontrivial, and repeated efforts to replicate a model of this size will only amplify the growing compute footprint of these LLMs.

We believe the entire AI community — academic researchers, civil society, policymakers, and industry — must work together to develop clear guidelines around responsible AI in general and responsible LLMs in particular, given their centrality in many downstream language applications. A much broader segment of the AI community needs access to these models in order to conduct reproducible research and collectively drive the field forward. With the release of OPT-175B and smaller-scale baselines, we hope to increase the diversity of voices defining the ethical considerations of such technologies.

## 2 Method

### 2.1 Models

We present results on eight Transformer language models ranging from 125 million to 175 billion parameters. Architectural details are displayed in Table [1](#S2.T1 "Table 1 ‣ 2.1 Models ‣ 2 Method ‣ OPT: Open Pre-trained Transformer Language Models"). In the interest of transparency, and to reduce risk of training instabilities, our models and hyperparameters largely follow [Brown et al. (2020)](#bib.bib10), with variations in batch size mostly to obtain increased computational efficiency.

| Model | #L | #H | d${}\_{\text{model}}$ | LR | Batch |
| --- | --- | --- | --- | --- | --- |
| 125M | 12 | 12 | 768 | $6.0e{-4}$ | 0.5M |
| 350M | 24 | 16 | 1024 | $3.0e{-4}$ | 0.5M |
| 1.3B | 24 | 32 | 2048 | $2.0e{-4}$ | 1M |
| 2.7B | 32 | 32 | 2560 | $1.6e{-4}$ | 1M |
| 6.7B | 32 | 32 | 4096 | $1.2e{-4}$ | 2M |
| 13B | 40 | 40 | 5120 | $1.0e{-4}$ | 4M |
| 30B | 48 | 56 | 7168 | $1.0e{-4}$ | 4M |
| 66B | 64 | 72 | 9216 | $0.8e{-4}$ | 2M |
| 175B | 96 | 96 | 12288 | $1.2e{-4}$ | 2M |

Table 1: Model architecture details. We report the number of layers (#L),
number of attention heads (#H), and the embedding size (d${}\_{\text{model}}$).
We also report the peak Learning Rate (LR) and global batch size in number of tokens (Batch).

### 2.2 Training Setup

For weight initialization, we follow the same settings provided in the Megatron-LM codebase,44
4
<https://github.com/NVIDIA/Megatron-LM/blob/main/examples/pretrain_gpt3_175B.sh> using a normal distribution with zero mean and standard deviation of 0.006. Standard deviation for output layers are scaled by a $1.0/\sqrt{2L}$ term where $L$ is the total number of layers. All bias terms are initialized as 0, and all models are trained with ReLU activation and a sequence length of 2048.

We use an AdamW optimizer [Loshchilov and Hutter (2017)](#bib.bib45) with $(\beta\_{1},\beta\_{2})$ set to $(0.9,0.95)$, and weight decay of $0.1$. We follow a linear learning rate schedule, warming up from $0$ to the maximum learning rate over the first 2000 steps in OPT-175B, or over 375M tokens in our smaller baselines, and decaying down to 10% of the maximum LR over 300B tokens. A number of mid-flight changes to LR were also required (see Section [2.5](#S2.SS5 "2.5 Training Processes ‣ 2 Method ‣ OPT: Open Pre-trained Transformer Language Models")). Our batch sizes range from 0.5M to 4M depending on the model size (see Table [1](#S2.T1 "Table 1 ‣ 2.1 Models ‣ 2 Method ‣ OPT: Open Pre-trained Transformer Language Models")) and is kept constant throughout the course of training.

We use a dropout of 0.1 throughout, but we do not apply any dropout to embeddings. We clip gradient norms at 1.0, except for some mid-flight changes that reduce this threshold down from 1.0 to 0.3 (see Section [2.5](#S2.SS5 "2.5 Training Processes ‣ 2 Method ‣ OPT: Open Pre-trained Transformer Language Models")). We also include a gradient predivide factor to reduce the risk of over/underflows when computing the gradient across all ranks (splitting the division by the world size of $N$ into two division operations by $\sqrt{N}$).

### 2.3 Pre-training Corpus

The pre-training corpus contains a concatenation of datasets used in RoBERTa [Liu et al. (2019b)](#bib.bib44), the Pile [Gao et al. (2021a)](#bib.bib23), and PushShift.io Reddit [Baumgartner et al. (2020)](#bib.bib3); [Roller et al. (2021)](#bib.bib70). All corpora were previously collected or filtered to contain predominantly English text, but a small amount of non-English data is still present within the corpus via CommonCrawl.

We removed duplicated documents across all datasets by filtering out documents via MinhashLSH [Rajaraman and Ullman (2011)](#bib.bib68) with a Jaccard similarity $\geq.95$. We found the Pile was particularly full of duplicate documents, and advise future researchers using the Pile to perform additional de-duplication processing.

We tokenize all corpora using the GPT-2 byte level BPE tokenizer [Sennrich et al. (2016)](#bib.bib76); [Radford et al. (2019)](#bib.bib65); [Brown et al. (2020)](#bib.bib10). Our final corpus contains roughly 180B tokens.

#### RoBERTa

We included the BookCorpus [Zhu et al. (2015)](#bib.bib98) and Stories [Trinh and Le (2018)](#bib.bib84) subsets of the RoBERTa corpus and utilized an updated version of CCNews, containing news stories crawled through September 28, 2021. This CCNews v2 corpus was preprocessed the same way as the original RoBERTa CCNews [Liu et al. (2019b)](#bib.bib44).

#### The Pile

We included a subset of the Pile [Gao et al. (2021a)](#bib.bib23), including: CommonCrawl, DM Mathematics, Project Gutenberg, HackerNews, OpenSubtitles, OpenWebText2, USPTO and Wikipedia. Other subsets of the Pile were eliminated as we found they increased the risk of instabilities, as measured by tendency to cause spikes in gradient norms at the 1.3B scale, or were otherwise deemed unsuitable. All subsets went through additional ad-hoc whitespace normalization.

#### PushShift.io Reddit

We included a subset of the Pushshift.io corpus produced by [Baumgartner et al. (2020)](#bib.bib3) and previously used by [Roller et al. (2021)](#bib.bib70). To convert the conversational trees into language-model-accessible documents, we extracted the longest chain of comments in each thread and discarded all other paths in the tree. This reduced the corpus by about 66%.

### 2.4 Training Efficiency

We trained OPT-175B on 992 80GB A100 GPUs, by utilizing Fully Sharded Data Parallel [Artetxe et al. (2021)](#bib.bib2) with Megatron-LM Tensor Parallelism [Shoeybi et al. (2019)](#bib.bib79). We achieve utilization of up to 147 TFLOP/s per GPU. We keep Adam state in FP32, since we shard it across all hosts, while the model weights remained in FP16. To avoid underflows, we used dynamic loss scaling, as described in [Micikevicius et al. (2017)](#bib.bib48).

### 2.5 Training Processes

Here we describe significant training process adjustments that arose during OPT-175B pre-training.

#### Hardware Failures

We faced a significant number of hardware failures in our compute cluster while training OPT-175B. In total, hardware failures contributed to at least 35 manual restarts and the cycling of over 100 hosts over the course of 2 months. During manual restarts, the training run was paused, and a series of diagnostics tests were conducted to detect problematic nodes. Flagged nodes were then cordoned off and training was resumed from the last saved checkpoint. Given the difference between the number of hosts cycled out and the number of manual restarts, we estimate 70+ automatic restarts due to hardware failures.

#### Loss Divergences

Loss divergences were also an issue in our training run. When the loss diverged, we found that lowering the learning rate and restarting from an earlier checkpoint allowed for the job to recover and continue training. We noticed a correlation between loss divergence, our dynamic loss scalar crashing to 0, and the $l^{2}$-norm of the activations of the final layer spiking. These observations led us to pick restart points for which our dynamic loss scalar was still in a “healthy” state ($\geq 1.0$), and after which our activation norms would trend downward instead of growing unboundedly. Our empirical LR schedule is shown in Figure [1](#S2.F1 "Figure 1 ‣ Loss Divergences ‣ 2.5 Training Processes ‣ 2 Method ‣ OPT: Open Pre-trained Transformer Language Models"). Early in training, we also noticed that lowering gradient clipping from 1.0 to 0.3 helped with stability; see our released logbook for exact details.
Figure [2](#S2.F2 "Figure 2 ‣ Loss Divergences ‣ 2.5 Training Processes ‣ 2 Method ‣ OPT: Open Pre-trained Transformer Language Models") shows our validation loss with respect to training iterations.

Figure 1: Empirical LR schedule. We found that lowering learning rate was helpful for avoiding instabilities.

Figure 2: Validation Perplexity. Our mid-flight LR
changes had clear effects on validation perplexity.

#### Other Mid-flight Changes

We conducted a number of other experimental mid-flight changes to handle loss divergences. These included: switching to vanilla SGD (optimization plateaued quickly, and we reverted back to AdamW); resetting the dynamic loss scalar (this helped recover some but not all divergences); and switching to a newer version of Megatron (this reduced pressure on activation norms and improved throughput).

## 3 Evaluations

### 3.1 Prompting & Few-Shot

We evaluate our model on 16 standard NLP tasks utilized in the literature: HellaSwag [Zellers et al. (2019)](#bib.bib97), StoryCloze [Mostafazadeh et al. (2016)](#bib.bib55), PIQA [Bisk et al. (2020)](#bib.bib5), ARC Easy and Challenge [Clark et al. (2018)](#bib.bib14), OpenBookQA [Mihaylov et al. (2018)](#bib.bib49), WinoGrad [Levesque et al. (2011)](#bib.bib36), WinoGrande [Sakaguchi et al. (2020)](#bib.bib71), and SuperGLUE [Wang et al. (2019)](#bib.bib87). We follow GPT-3 [Brown et al. (2020)](#bib.bib10) by using their prompts and overall experimental setup. We compare primarily to GPT-3, having aimed to re-implement their evaluation settings, but include reported performance of other LLMs on a per-task basis when available [Lieber et al. (2021)](#bib.bib40); [Rae et al. (2021)](#bib.bib66); [Hoffmann et al. (2022)](#bib.bib29); [Black et al. (2022)](#bib.bib6)

We report performance in accuracy (omitting F1 for MultiRC and ReCoRD for consistency in evaluation metrics). For the Winograd Schema Challenge (WSC) task in the SuperGLUE benchmark, we follow [Brown et al. (2020)](#bib.bib10) and formulate the task as multiple choice questions, which is known to affect performance [Liu et al. (2020)](#bib.bib42).

#### Zero-shot

Overall average zero-shot performance across all 14 tasks may be seen in Figure [3](#S3.F3 "Figure 3 ‣ Zero-shot ‣ 3.1 Prompting & Few-Shot ‣ 3 Evaluations ‣ OPT: Open Pre-trained Transformer Language Models"). Overall, we see our average performance follows the trend of GPT-3. However, performance can vary radically across the tasks: for a full breakdown, see Appendix [A](#A1 "Appendix A Additional Evaluations ‣ OPT: Open Pre-trained Transformer Language Models"). Note that we intentionally removed MultiRC and WIC from these averages, as these datasets seem to systematically favor GPT-3 or OPT disproportionately.

Our performance roughly matched GPT-3 for 10 tasks, and underperformed in 3 tasks (ARC Challenge and MultiRC). In 3 tasks (CB, BoolQ, WSC), we find both GPT and OPT models display unpredictable behavior with respect to scale, likely due to the small size of the validation set in these 3 tasks (56, 277, and 104 examples, respectively). In WIC, we see that the OPT models always outperform the GPT-3 models, though the numbers reported by [Brown et al. (2020)](#bib.bib10) also seem questionable, given WIC being a binary classification task.55
5
[Brown et al. (2020)](#bib.bib10) reports 0% accuracy on WIC, which implies 100% accuracy if the classification was inverted. For MultiRC, we are unable to replicate the GPT-3 results using the Davinci API66
6
<https://beta.openai.com/docs/engines/overview> within our evaluation setup, suggesting differences in the methods of evaluation on this task. For BoolQ and WSC, we note that both OPT and GPT models seem to hover around majority-class accuracy, suggesting small perturbations in probability masses may be dominating the evaluations.

Chinchilla [Hoffmann et al. (2022)](#bib.bib29) and Gopher [Rae et al. (2021)](#bib.bib66) perform roughly consistently with others for their parameter sizes, while PaLM [Chowdhery et al. (2022)](#bib.bib13) generally performs better across all settings, even when controlling for number of parameters. We speculate the high performance of PaLM comes predominantly from higher quality and diversity of pre-training data.

Figure 3: Zero-shot NLP Evaluation Averages. Across a variety of tasks and model sizes, OPT largely matches the reported averages of GPT-3. However, performance varies greatly per task: see Appendix [A](#A1 "Appendix A Additional Evaluations ‣ OPT: Open Pre-trained Transformer Language Models").

Figure 4: Multi-shot performance. OPT performance for one- and few-shot lags behind GPT-3 models, but performance depends heavily per task; see Appendix [A](#A1 "Appendix A Additional Evaluations ‣ OPT: Open Pre-trained Transformer Language Models").

#### One-shot and Few-shot

Average multi-shot in-context performance is shown in Figure [4](#S3.F4 "Figure 4 ‣ Zero-shot ‣ 3.1 Prompting & Few-Shot ‣ 3 Evaluations ‣ OPT: Open Pre-trained Transformer Language Models") (again, omitting MultiRC and WIC), with detailed performances shown in Appendix [A](#A1 "Appendix A Additional Evaluations ‣ OPT: Open Pre-trained Transformer Language Models"). Across the average of all metrics, we find that OPT models perform similarly to GPT-3 models. However, as with zero-shot, breaking down these results per task shows a different story: in the same set of 10 datasets as zero-shot, we see similar performance across the two models. Some of the remaining datasets show inconsistent performance with respect to model size for both OPT and GPT-3 models (BoolQ, CB, WSC, RTE). In MultiRC, we consistently see underperformance of OPT models compared to GPT-3 models. Similar to our zero-shot evaluation, we hypothesize our one- and few-shot evaluation setup may differ significantly from [Brown et al. (2020)](#bib.bib10).

### 3.2 Dialogue

Given that LLMs are known to be an integral component of modern dialogue models [Adiwardana et al. (2020)](#bib.bib1); [Roller et al. (2021)](#bib.bib70); [Thoppilan et al. (2022)](#bib.bib83); [Rae et al. (2021)](#bib.bib66); [Chowdhery et al. (2022)](#bib.bib13), we additionally evaluate OPT-175B on several open source dialogue datasets. In particular, we follow [Roller et al. (2021)](#bib.bib70), and evaluate on ConvAI2 [Dinan et al. (2020b)](#bib.bib21), Wizard of Wikipedia [Dinan et al. (2019b)](#bib.bib22), Empathetic Dialogues [Rashkin et al. (2019)](#bib.bib69), and Blended Skill Talk [Smith et al. (2020)](#bib.bib81). We additionally evaluate on the more recent Wizard of Internet dataset [Komeili et al. (2021)](#bib.bib33).
We focus our comparisons primarily against existing open source dialogue models including the fine-tuned BlenderBot 1 [Roller et al. (2021)](#bib.bib70) and its pre-training counterpart Reddit 2.7B. We also compare against the fine-tuned R2C2 BlenderBot, a 2.7B parameter BlenderBot-like model trained by [Shuster et al. (2022)](#bib.bib80).

We report Perplexity and Unigram F1 (UF1) overlap, following the metrics of the ConvAI2 competition [Dinan et al. (2020b)](#bib.bib21). To control for different tokenization in each of the models, we normalize all perplexities to be in the space of the GPT-2 tokenizer [Radford et al. (2019)](#bib.bib65). We also note which models are supervised with respect to these dialogue tasks and which are unsupervised. For OPT-175B, all generations are performed using greedy decoding up to a maximum of 32 tokens. We do not attempt to prompt the model at all except for alternating “Person 1:” and “Person 2:” lines of dialogue. The remaining models use the generation parameters found in BlenderBot 1.

|  |  | Perplexity ($\downarrow$) | | | | | Unigram F1 ($\uparrow$) | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Model | Eval | C2 | WW | ED | BST | WoI | C2 | WW | ED | BST | WoI |
| Reddit 2.7B | Unsup. | 18.9 | 21.0 | 11.6 | 17.4 | 18.0 | .126 | .133 | .135 | .133 | .124 |
| BlenderBot 1 | Sup. | 10.2 | 12.5 | 9.0 | 11.9 | 14.7 | .183 | .189 | .192 | .178 | .154 |
| R2C2 BlenderBot | Sup. | 10.5 | 12.4 | 9.1 | 11.7 | 14.6 | .205 | .198 | .197 | .186 | .160 |
| OPT-175B | Unsup. | 10.8 | 13.3 | 10.3 | 12.1 | 12.0 | .185 | .152 | .149 | .162 | .147 |

Table 2: Dialogue Evaluations. OPT-175B, in a fully unsupervised setting, performs competitively against fully supervised models.

Results are shown in Table [2](#S3.T2 "Table 2 ‣ 3.2 Dialogue ‣ 3 Evaluations ‣ OPT: Open Pre-trained Transformer Language Models"). We see that OPT-175B significantly outperforms the also-unsupervised Reddit 2.7B model on all tasks, and performs competitively with the fully supervised BlenderBot 1 model, especially in the ConvAI2 dataset. On the Wizard-of-Internet dataset, which is fully unsupervised for all models, we see that OPT-175B obtains the lowest perplexity but still has lower UF1 than the models with Wizard-of-Wikipedia supervision.

We were somewhat surprised that the evaluations of the unsupervised OPT-175B model were as competitive as BlenderBot 1 on the ConvAI2 dataset. This may indicate leakage of the ConvAI2 dataset into the general pre-training corpus or even into the validation data as evaluated in Table [2](#S3.T2 "Table 2 ‣ 3.2 Dialogue ‣ 3 Evaluations ‣ OPT: Open Pre-trained Transformer Language Models"). To address concerns of leakage, we searched our pre-training corpus for the first conversation in the ConvAI2 dataset, but we did not find any overlap.
We additionally evaluated OPT-175B on the ConvAI2 hidden test set, which has never been publicly released, and achieved 10.7 ppl and .185 UF1, matching the performance of the validation set. Furthermore, we evaluated OPT-175B on a subset of the ConvAI2-like MultiSessionChat (MSC) dataset [Xu et al. (2021b)](#bib.bib96) and obtained a perplexity of 9.7 and UF1 of .177, indicating the model is generalizing well across multiple PersonaChat-like datasets. Since both MSC and WoI datasets were released after the CommonCrawl snapshot used in pre-training corpus, there is minimal risk of leakage. We conclude that OPT-175B has a strong ability to maintain a consistent persona across conversations, a behavior also highlighted in LaMDA [Thoppilan et al. (2022)](#bib.bib83).

## 4 Bias & Toxicity Evaluations

To understand the potential harm of OPT-175B, we evaluate a series of benchmarks related to hate speech detection, stereotype awareness, and toxic content generation. While there may be shortcomings in these benchmarks [Blodgett et al. (2021)](#bib.bib7); [Jacobs and Wallach (2021)](#bib.bib31), these measurements provide a first step towards understanding the limitations of OPT-175B. We compare primarily against GPT-3 Davinci, as these benchmarks were not yet available to be included in [Brown et al. (2020)](#bib.bib10).

### 4.1 Hate Speech Detection

Using the ETHOS dataset provided in [Mollas et al. (2020)](#bib.bib54) and instrumented by [Chiu and Alexander (2021)](#bib.bib12), we measure the ability of OPT-175B to identify whether or not certain English statements are racist or sexist (or neither). In the zero-, one-, and few-shot binary cases, the model is presented with text and asked to consider whether the text is racist or sexist and provide a yes/no response. In the few-shot multiclass setting, the model is asked to provide a yes/no/neither response.

Results are presented in Table [3](#S4.T3 "Table 3 ‣ 4.1 Hate Speech Detection ‣ 4 Bias & Toxicity Evaluations ‣ OPT: Open Pre-trained Transformer Language Models").
With all of our one-shot through few-shot configurations, OPT-175B performs considerably better than Davinci. We speculate this occurs from two sources: (1) evaluating via the Davinci API may be bringing in safety control mechanisms beyond the original 175B GPT-3 model used in [Brown et al. (2020)](#bib.bib10); and (2) the significant presence of unmoderated social media discussions in the pre-training dataset has provided additional inductive bias to aid in such classification tasks.

| Setup | Davinci | OPT-175B |
| --- | --- | --- |
| Zero-shot | .628 | .667 |
| One-shot | .616 | .713 |
| Few-shot (binary) | .354 | .759 |
| Few-shot (multiclass) | .672 | .812 |

Table 3: Hate speech detection. F1 scores of detecting hate speech between Davinci and OPT-175B. OPT-175B considerably outperforms Davinci in all settings.

### 4.2 CrowS-Pairs

Developed for masked language models, CrowS-Pairs [Nangia et al. (2020)](#bib.bib58) is a crowdsourced benchmark aiming to measure intrasentence level biases in 9 categories: gender, religion, race/color, sexual orientation, age, nationality, disability, physical appearance, and socioeconomic status. Each example consists of a pair of sentences representing a stereotype, or anti-stereotype, regarding a certain group, with the goal of measuring model preference towards stereotypical expressions. Higher scores indicate higher bias exhibited by a model.

When compared with Davinci in Table [4](#S4.T4 "Table 4 ‣ 4.2 CrowS-Pairs ‣ 4 Bias & Toxicity Evaluations ‣ OPT: Open Pre-trained Transformer Language Models"), OPT-175B appears to exhibit more stereotypical biases in almost all categories except for religion. Again, this is likely due to differences in training data; [Nangia et al. (2020)](#bib.bib58) showed that Pushshift.io Reddit corpus has a higher incidence rate for stereotypes and discriminatory text than other corpora (e.g. Wikipedia). Given this is a primary data source for OPT-175B, the model may have learned more discriminatory associations, which directly impacts its performance on CrowS-Pairs.

| Category | GPT-3 | OPT-175B |
| --- | --- | --- |
| Gender | 62.6 | 65.7 |
| Religion | 73.3 | 68.6 |
| Race/Color | 64.7 | 68.6 |
| Sexual orientation | 76.2 | 78.6 |
| Age | 64.4 | 67.8 |
| Nationality | 61.6 | 62.9 |
| Disability | 76.7 | 76.7 |
| Physical appearance | 74.6 | 76.2 |
| Socioeconomic status | 73.8 | 76.2 |
| Overall | 67.2 | 69.5 |

Table 4: CrowS-Pairs evaluation. Lower is better for all categories, indicating more fairness. The OPT-175B model
performs worse than Davinci in most categories.

### 4.3 StereoSet

Following [Lieber et al. (2021)](#bib.bib40) and [Artetxe et al. (2021)](#bib.bib2), we use StereoSet [Nadeem et al. (2021)](#bib.bib56) to measure stereotypical bias across 4 categories: profession, gender, religion, and race. In addition to intrasentence measurement (similar to CrowS-Pairs), StereoSet includes measurement at the intersentence level to test a model’s ability to incorporate additional context. To account for a potential trade-off between bias detection and language modeling capability, StereoSet includes two metrics: Language Modeling Score (LMS) and Stereotype Score (SS), which are then combined to form the Idealized Context Association Test score (ICAT). Unlike [Lieber et al. (2021)](#bib.bib40), we normalize scores by token count, rather than character count, which they report improves metrics for several models.

Results are shown in Table [5](#S4.T5 "Table 5 ‣ 4.3 StereoSet ‣ 4 Bias & Toxicity Evaluations ‣ OPT: Open Pre-trained Transformer Language Models"). We see that Davinci and OPT-175B exhibit similar scores on aggregate (overall ICAT is very close between the two). In particular, Davinci outperforms in the areas of profession and race, while OPT-175B outperforms in the areas of Gender and Religion. OPT-175B performs better across the board on the SS metric, while Davinci generally outperforms on the LMS metric.

| Category | | Davinci | OPT-175B |
| --- | --- | --- | --- |
| Prof. | LMS ($\uparrow$) | 78.4 | 74.1 |
| SS ($\downarrow)$ | 63.4 | 62.6 |
| ICAT ($\uparrow$) | 57.5 | 55.4 |
| Gend. | LMS ($\uparrow$) | 75.6 | 74.0 |
| SS ($\downarrow)$ | 66.5 | 63.6 |
| ICAT ($\uparrow$) | 50.6 | 53.8 |
| Reli. | LMS ($\uparrow$) | 80.8 | 84.0 |
| SS ($\downarrow)$ | 59.0 | 59.0 |
| ICAT ($\uparrow$) | 66.3 | 68.9 |
| Race | LMS ($\uparrow$) | 77.0 | 74.9 |
| SS ($\downarrow)$ | 57.4 | 56.8 |
| ICAT ($\uparrow$) | 65.7 | 64.8 |
| Overall | LMS ($\uparrow$) | 77.6 | 74.8 |
| SS ($\downarrow)$ | 60.8 | 59.9 |
| ICAT ($\uparrow$) | 60.8 | 60.0 |

Table 5: StereoSet Evaluations. Davinci and OPT-175B perform similarly across all evaluations.

### 4.4 RealToxicityPrompts

We evaluate the tendency of OPT-175B to respond with toxic language via the RealToxicityPrompts [Gehman et al. (2020)](#bib.bib26) dataset. Following PaLM [Chowdhery et al. (2022)](#bib.bib13), we sample 25 generations of 20 tokens using nucleus sampling [Holtzman et al. (2020)](#bib.bib30) ($p=0.9$) for each of $10,000$ randomly sampled prompts from RTP, and report mean toxicity probabilities of the continuations, stratified across bucketed toxicities of the original prompts. For comparison, we report bucketed toxicity rates from Davinci and PaLM.

Figure 5: RealToxicityPompts. OPT-175B is more likely to generate toxic responses than either Davinci or PaLM. Consistent with prior work, toxicity rates increase as prompt toxicity increases.

Results are shown in Figure [5](#S4.F5 "Figure 5 ‣ 4.4 RealToxicityPrompts ‣ 4 Bias & Toxicity Evaluations ‣ OPT: Open Pre-trained Transformer Language Models"). Overall, we see that OPT-175B has a higher toxicity rate than either PaLM or Davinci. We also observe that all 3 models have increased likelihood of generating toxic continuations as the toxicity of the prompt increases, which is consistent with the observations of [Chowdhery et al. (2022)](#bib.bib13). As with our experiments in hate speech detection, we suspect the inclusion of unmoderated social media texts in the pre-training corpus raises model familiarity with, and therefore propensity to generate and detect, toxic text. This strong awareness of toxic language may or may not be desirable depending on the specific requirements of downstream applications. Future applications of OPT-175B should consider this aspect of the model, and take additional mitigations, or avoid usage entirely as appropriate.

### 4.5 Dialogue Safety Evaluations

Finally, we compare OPT-175B on two Dialogue Safety evaluations. The first, SaferDialogues [Ung et al. (2021)](#bib.bib85), measures the ability to recover from explicit safety failures, usually in the form of apologizing or recognizing its mistake. The second, the Safety Bench Unit Tests [Dinan et al. (2021)](#bib.bib18), measures how unsafe a model’s response is, stratified across 4 levels of topic sensitivity: Safe, Realistic, Unsafe, and Adversarial.
As with the other dialogue evaluations (Section [3.2](#S3.SS2 "3.2 Dialogue ‣ 3 Evaluations ‣ OPT: Open Pre-trained Transformer Language Models")), we compare to several existing open source dialogue models.

|  | Safe. Dia. | | Unit Tests ($\downarrow$) | | | |
| --- | --- | --- | --- | --- | --- | --- |
| Model | PPL | F1 | Sa | Re | Un | Ad |
| Reddit 2.7B | 16.2 | .140 | .300 | .261 | .450 | .439 |
| BlenderBot 1 | 12.4 | .161 | .028 | .150 | .250 | .194 |
| R2C2 BlenderBot | 13.8 | .160 | .022 | .133 | .289 | .222 |
| OPT-175B | 14.7 | .141 | .033 | .261 | .567 | .283 |

Table 6: Dialogue Responsible AI evaluations. OPT-175B is roughly on par with the Reddit 2.7B model, but performs
worse in the Unsafe setting.

Results for both experiments are shown in Table [6](#S4.T6 "Table 6 ‣ 4.5 Dialogue Safety Evaluations ‣ 4 Bias & Toxicity Evaluations ‣ OPT: Open Pre-trained Transformer Language Models"). We observe that OPT-175B has similar performance as the Reddit 2.7B model across both SaferDialogues and the Unit Tests, with OPT-175B performing marginally better in the Safe and Adversarial settings. Consistent with [Roller et al. (2021)](#bib.bib70) and [Xu et al. (2020)](#bib.bib94), we find that the models fine-tuned on curated dialogue datasets (BlenderBot 1, R2C2) have overall lower toxicity. We conclude that future experimentation of OPT-175B for dialogue should contain explicit fine-tuning on curated datasets in order to improve the safety profile.

## 5 Limitations

In Sections [3.1](#S3.SS1 "3.1 Prompting & Few-Shot ‣ 3 Evaluations ‣ OPT: Open Pre-trained Transformer Language Models") and  [4](#S4 "4 Bias & Toxicity Evaluations ‣ OPT: Open Pre-trained Transformer Language Models"), we carried out extensive evaluation of all released models at varying scales. We saw parity in performance for standard evaluation datasets used in the GPT-3 models.
Moreover, we performed safety, bias, and inclusion evaluations, again seeing largely comparable performance with some variations in toxicity and hate speech detection.
However, such evaluations may not fully characterize the complete limitations of these models. In general, we qualitatively observe that OPT-175B suffers from the same limitations noted in other LLMs [Brown et al. (2020)](#bib.bib10); [Lieber et al. (2021)](#bib.bib40); [Thoppilan et al. (2022)](#bib.bib83); [Rae et al. (2021)](#bib.bib66); [Smith et al. (2022)](#bib.bib82); [Chowdhery et al. (2022)](#bib.bib13); [Bender et al. (2021)](#bib.bib4).

In particular, we found OPT-175B does not work well with declarative instructions or point-blank interrogatives. Prompting with such instructions tends to produce a simulation of a dialogue beginning with such an instruction, rather than an execution of the instruction. Future work into instruction learning, in the vein of InstructGPT [Ouyang et al. (2022)](#bib.bib60), may alleviate these limitations.

OPT-175B also tends to be repetitive and can easily get stuck in a loop. While sampling can reduce the incidence rate of repetitive behavior [Holtzman et al. (2020)](#bib.bib30), we anecdotally found it did not eliminate it entirely when only one generation is sampled. Future work may wish to incorporate more modern strategies for reducing repetition and improving diversity, such as unlikelihood training [Welleck et al. (2020)](#bib.bib92) or best-first decoding [Meister et al. (2020)](#bib.bib47).

Similar to other LLMs, OPT-175B can produce factually incorrect statements [Adiwardana et al. (2020)](#bib.bib1); [Brown et al. (2020)](#bib.bib10); [Roller et al. (2021)](#bib.bib70); [Rae et al. (2021)](#bib.bib66); [Chowdhery et al. (2022)](#bib.bib13); [Thoppilan et al. (2022)](#bib.bib83). This can be particularly harmful in applications where information accuracy is critical, such as healthcare and scientific discovery [Weidinger et al. (2021b)](#bib.bib91). Recently, several efforts have reported that retrieval-augmented models can improve factual correctness of LLMs [Lewis et al. (2020)](#bib.bib37); [Komeili et al. (2021)](#bib.bib33); [Thoppilan et al. (2022)](#bib.bib83); [Borgeaud et al. (2021)](#bib.bib9); [Shuster et al. (2022)](#bib.bib80); [Nakano et al. (2021)](#bib.bib57). We believe OPT-175B will also benefit from retrieval-augmentation in future iterations.

As shown in Section [4](#S4 "4 Bias & Toxicity Evaluations ‣ OPT: Open Pre-trained Transformer Language Models"), we also find OPT-175B has a high propensity to generate toxic language and reinforce harmful stereotypes, even when provided with a relatively innocuous prompt [Gehman et al. (2020)](#bib.bib26), and adversarial prompts are trivial to find [Dinan et al. (2021)](#bib.bib18). There has been a great deal of work on mitigations for toxicity and biases [Dathathri et al. (2019)](#bib.bib15); [Dinan et al. (2019a)](#bib.bib20); [Sheng et al. (2019)](#bib.bib77); [Dinan et al. (2020a)](#bib.bib19); [Liu et al. (2019a)](#bib.bib41); [Krause et al. (2020)](#bib.bib34); [Xu et al. (2020)](#bib.bib94); [Liang et al. (2021)](#bib.bib39); [Dinan et al. (2021)](#bib.bib18); [Xu et al. (2021a)](#bib.bib95); [Dhamala et al. (2021)](#bib.bib17); [Schick et al. (2021)](#bib.bib75); [Ouyang et al. (2022)](#bib.bib60). Depending on downstream applications, future uses of OPT-175B may need to employ these or novel mitigation approaches, especially before any real world deployment. Given our primary goal as a replication of GPT-3, we choose not to apply these mitigations in this first release.

In summary, we still believe this technology is premature for commercial deployment. Despite including data sheets and model cards, we believe more scrutiny should be afforded to the training data with additional data characterization and selection criteria in order to use data responsibly. The current practice is to feed the model with as much data as possible and minimal selection within these datasets. Despite having comprehensive evaluations, we would ideally have more streamlined and consistent evaluation setups to ensure replicability and reproducibility of evaluation scenarios. Differences in prompting styles and number of shots for in-context learning could create variations that lead to different results. We hope that the public release of the OPT models will enable many more researchers to work on these important issues.

## 6 Considerations for Release

Following the recommendations for individual researchers generated by the Partnership for AI,77
7
<https://partnershiponai.org/paper/responsible-publication-recommendations/> along with the governance guidance outlined by NIST,88
8
<https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.1270.pdf> we are disclosing all of the details involved in training OPT-175B through our logbook,99
9
<https://github.com/facebookresearch/metaseq/blob/main/projects/OPT/chronicles/OPT175B_Logbook.pdf> our code, and providing researchers access to model weights for OPT-175B, along with a suite of smaller baselines mirroring the setup for OPT-175B. We aim to be fully accountable for the development lifecycle of OPT-175B, and only through increasing transparency around LLM development can we start understanding the limitations and risks of LLMs before broader deployment occurs.

By sharing a detailed account of our day-to-day training process, we disclose not only how much compute was used to train the current version of OPT-175B, but also the human overhead required when underlying infrastructure or the training process itself becomes unstable at scale. These details are generally omitted from previous publications, likely due to the inability to fully ablate changes made mid-flight (without drastically increasing the compute budget). We hope that by revealing how certain ad-hoc design decisions were made, we can improve upon these practices in the future, and collectively increase the experimental robustness in developing models at this scale.

Outside of these notes, the metaseq codebase itself is the final source of truth in many of our implementation details. By releasing our development codebase, we aim to shed light on any implementation detail that may have been omitted from being explicitly enumerated in this paper, as it is either considered a detail of standard practice in the field, or is simply a detail we failed to account for. This current codebase is also the only known open-source implementation of training a decoder-only transformer that is $\geq$175B parameters without the use of pipeline paralellism on NVIDIA GPUs.

To enable experimentation at 175B scale, we are providing researchers with direct access to the parameters of OPT-175B. The reasoning here is two-fold: enable Responsible AI research into LLMs while simultaneously reducing the environmental impact of pursuing research at this scale. There is a growing body of work detailing ethical and social risks from deploying language models with emergent capabilities at scale [Weidinger et al. (2021a)](#bib.bib90); [Bommasani et al. (2021)](#bib.bib8); [Dinan et al. (2021)](#bib.bib18); [Kenton et al. (2021)](#bib.bib32). By limiting access to OPT-175B to the research community with a non-commercial license, we aim to focus development efforts on quantifying the limitations of the LLMs first, before broader commercial deployment occurs.

Furthermore, there exists significant compute and carbon cost to reproduce models of this size. While OPT-175B was developed with an estimated carbon emissions footprint (CO2eq) of 75 tons,1010
10
With ablations, baselines and downtime, our own estimates of total cost is roughly 2$\times$ higher. GPT-3 was estimated to use 500 tons [Patterson et al. (2021)](#bib.bib61), while Gopher required 380 tons [Rae et al. (2021)](#bib.bib66). These estimates are not universally reported, and the accounting methodologies for these calculations are also not standardized. In addition, model training is only one component of the overall carbon footprint of AI systems; we must also consider experimentation and eventual downstream inference cost, all of which contribute to the growing energy footprint of creating large-scale models [Wu et al. (2022)](#bib.bib93). By releasing our logbook, we hope to highlight the gap between a theoretical carbon cost estimate that assumes no hardware failures or training instabilities, versus one that aims to include the entire LLM development lifecycle. We need to understand the manufacturing (or embodied) carbon of these systems [Gupta et al. (2021)](#bib.bib27) as they grow increasingly more complex, and we hope that our paper can help future work in defining additional factors to consider when measuring the impact of scale on the environment.

Similarly, by producing a set of baselines across a wide range of scales, we hope to enable the broader research community to study the impact and limitations of these models with respect to scale alone. As reported in [Hoffmann et al. (2022)](#bib.bib29), many of these LLMs may have been under-trained as a function of the amount of training data used, which implies that incorporating more data and continuing to train these baseline models may continue to improve performance. There is also evidence that step-function changes in capabilities may occur at a scale that is much smaller than 175B [Wei et al. (2021)](#bib.bib89), indicating a need to examine a wider range of scales for different research applications.

## 7 Related Work

Since the publication of the Transformer architecture [Vaswani et al. (2017)](#bib.bib86) and BERT [Devlin et al. (2019)](#bib.bib16), the field of NLP has experienced a massive shift towards the use of LLMs with self-supervised pre-training.
Multiple masked langauge models, including T5 [Raffel et al. (2020)](#bib.bib67) and Megatron-LM [Shoeybi et al. (2019)](#bib.bib79), have shown consistent improvements through scale. These scaling gains come not only from growing the total number of parameters in the models, but also the amount and quality of pre-training data [Liu et al. (2019b)](#bib.bib44); [Hoffmann et al. (2022)](#bib.bib29).

Auto-regressive language models [Mikolov et al. (2009)](#bib.bib50) have seen the largest growth in model size, from 117M parameters [Radford et al. (2018)](#bib.bib64) to over 500B parameters [Smith et al. (2022)](#bib.bib82); [Chowdhery et al. (2022)](#bib.bib13). The resulting massive improvement in generative fluency and quality was first characterized in GPT-2 [Radford et al. (2019)](#bib.bib65) and further improved with GPT-3 [Brown et al. (2020)](#bib.bib10) and later models. Although a variety of very large (over 100B parameters) generative models have now been trained [Lieber et al. (2021)](#bib.bib40); [Rae et al. (2021)](#bib.bib66); [Thoppilan et al. (2022)](#bib.bib83); [Smith et al. (2022)](#bib.bib82); [Chowdhery et al. (2022)](#bib.bib13), they are all closed source and accessible only internally or via paid API services. There are a few notable efforts towards open sourcing LLMs from non-profit research organizations including EleutherAI [Black et al. (2022)](#bib.bib6) and BigScience.1111
11
<https://huggingface.co/bigscience/tr11-176B-ml-logs/tensorboard> These models differ from the OPT models in pre-training data, target languages and model scale, making it possible for the community to compare different pre-training strategies.

Since [Brown et al. (2020)](#bib.bib10), the primary evaluation criterion for LLMs has been prompt-based [Black et al. (2022)](#bib.bib6); [Rae et al. (2021)](#bib.bib66); [Chowdhery et al. (2022)](#bib.bib13), as is also performed in this paper. This is largely due to the convenience of evaluating on many tasks without specialized task-specific fine-tuning. Prompting itself has a long history: cloze evaluations go back several decades [Chambers and Jurafsky (2008)](#bib.bib11); [Mostafazadeh et al. (2016)](#bib.bib55). More recently, prompting or masked infilling has been used to probe models for knowledge [Petroni et al. (2019)](#bib.bib63) or perform a variety of NLP tasks [Radford et al. (2019)](#bib.bib65); [Brown et al. (2020)](#bib.bib10).
There has also been work on eliciting prompting behavior in smaller models [Schick and Schütze (2020)](#bib.bib74); [Gao et al. (2021b)](#bib.bib24); [Li and Liang (2021)](#bib.bib38); [Lester et al. (2021)](#bib.bib35); [Scao and Rush (2021)](#bib.bib73), improving the flexibility of prompting [Shin et al. (2020)](#bib.bib78), and understanding why and how prompting works [Liu et al. (2021)](#bib.bib43); [Min et al. (2022)](#bib.bib52).

Recent efforts have shown gains by fine-tuning models to directly respond to instruction-style prompting [Wei et al. (2021)](#bib.bib89); [Min et al. (2021)](#bib.bib51); [Sanh et al. (2021)](#bib.bib72); [Ouyang et al. (2022)](#bib.bib60). However, effective prompt engineering remains an open research challenge. Results vary significantly and unpredictably with the selection of the prompt [Lu et al. (2021)](#bib.bib46), and models do not seem to understand the prompts as fully as we expect [Webson and Pavlick (2021)](#bib.bib88). Furthermore, it is challenging to write prompts without a development set, which leads to questions about the extent to which we are actually achieving zero- or few-shot learning in practice [Perez et al. (2021)](#bib.bib62). We do not attempt to address these concerns of prompting, and instead only aim to provide evaluation of OPT-175B in existing settings. However, we hope the full release of OPT-175B will enable others to better study these challenges in the future.

## 8 Conclusion

In this technical report, we introduced OPT, a collection of auto-regressive language models ranging in size from 125M to 175B parameters.
Our goal was to replicate the performance and sizes of the GPT-3 class of models, while also applying the latest best practices in data curation and training efficiency.
We described training details, evaluated performance in a number of NLP and dialogue settings, and characterized behaviors with respect to bias, toxicity and hate speech. We also described many other limitations the models have, and discussed a wide set of considerations for responsibly releasing the models. We believe the entire AI community would benefit from working together to develop guidelines for responsible LLMs, and we hope that broad access to these types of models will increase the diversity of voices defining the ethical considerations of such technologies.

## Acknowledgements

We would like to thank Scott Jeschonek, Giri Anantharaman, Diego Sarina, Joaquin Colombo, Chris Bray, Stephen Roylance, Kalyan Saladi, Shubho Sengupta, and Brian O’Horo for helping to remove infrastructure blockers along the way; Percy Liang, Rishi Bommasani, and Emily Dinan for discussions on responsible release practices; Carole-Jean Wu for discussions on sustainability and carbon footprint considerations; Srini Iyer, Ramakanth Pasunuru, and Shruti Bhosale for previous contributions to evaluations; Benjamin Lefaudeux, Geeta Chauhan, Natalia Gimelshein, Horace He, and Sam Gross for discussions on performance improvement work; Emily Dinan, Carole-Jean Wu, Daniel McKinnon, and Mark Tygert for feedback on this draft; Antoine Bordes, Joelle Pineau, Mary Williamson, Necip Fazil Ayan, Armand Joulin, Sergey Edunov, Melanie Kambadur, Zornitsa Kozareva, Ves Stoyanov, Vitaliy Liptchinsky, Rahul Iyer, Jing Xu, Jason Weston, and many others for supporting this project internally.

## Appendix A Additional Evaluations

.

Figure 6: Zero-shot NLP Evaluations. Full evaluations on all 16 NLP tasks, with comparisons where available. We find that across most tasks, GPT-3 models and OPT models perform similarly, but some tasks display highly erratic behavior.

Figure 7: Multishot-shot NLP Evaluations. Full evaluations on all 16 NLP tasks, with comparisons to the GPT-3 reported performance. As with zero-shot, performance is roughly similar for most tasks, with some tasks demonstrating erratic behavior.

## Appendix B Contributions

#### Pre-training

* •

  Initial planning: Susan Zhang
* •

  Training infrastructure and initial ablations: Naman Goyal, Myle Ott, Stephen Roller, Sam Shleifer, Susan Zhang
* •

  Training efficiency: Naman Goyal, Myle Ott, Sam Shleifer
* •

  Data curation and deduplication: Shuhoi Chen, Myle Ott, Stephen Roller
* •

  Training and monitoring OPT-175B: Mikel Artetxe, Moya Chen, Naman Goyal, Punit Singh Koura, Myle Ott, Sam Shleifer, Kurt Shuster, Daniel Simig, Stephen Roller, Susan Zhang
* •

  Training 125M–66B baselines: Naman Goyal, Stephen Roller, Susan Zhang

#### Evaluations

* •

  NLP: Xian Li, Xi Victoria Lin, Todor Mihaylov, Stephen Roller, Anjali Sridhar
* •

  Dialogue: Stephen Roller
* •

  Responsible AI Evaluations: Punit Singh Koura, Stephen Roller, Tianlu Wang

#### Paper writing:

Moya Chen, Stephen Roller, Luke Zettlemoyer, Susan Zhang

#### Code release preparation:

Christopher Dewan, Susan Zhang

#### Responsible AI conduct:

Mona Diab, Susan Zhang

## Appendix C Datasheet

We follow the recommendations of [Gebru et al. (2021)](#bib.bib25) and provide a data card for the dataset used to train the OPT models.

### C.1 Motivation

* •

  For what purpose was the dataset created? Was there a specific task in mind? Was there a specific gap that needed to be filled? Please provide a description. The pre-training data for training the OPT-175B model was created by a union of five datasets, including three datasets used by RoBERTa [Liu et al. (2019b)](#bib.bib44), a subset of the Pile [Gao et al. (2021a)](#bib.bib23), along with the Pushshift.io Reddit dataset that was developed in [Baumgartner et al. (2020)](#bib.bib3) and processed in [Roller et al. (2021)](#bib.bib70). These purpose of creating this dataset was to pre-train the language model on a broad corpus of text, with emphasis on human-generated text.
* •

  Who created the dataset (e.g., which team, research group) and on behalf of which entity (e.g., company, institution, organization)? Meta AI.
* •

  Who funded the creation of the dataset? If there is an associated grant, please provide the name of the grantor and the grant name and number. Meta AI.
* •

  Any other comments? No.

### C.2 Composition

* •

  What do the instances that comprise the dataset represent (e.g., documents, photos, people, countries)? Are there multiple types of instances (e.g., movies, users, and ratings; people and interactions between them; nodes and edges)? Please provide a description. The instances are textual documents. The overall dataset is composed from a union of the following datasets:

  + –

    BookCorpus [Zhu et al. (2015)](#bib.bib98) consists of more than 10K unpublished books
  + –

    CC-Stories [Trinh and Le (2018)](#bib.bib84) contains a subset of CommonCrawl data filtered to match the story-like style of Winograd schemas
  + –

    The Pile [Gao et al. (2021a)](#bib.bib23) from which the following was included:

    - \*

      Pile-CC
    - \*

      OpenWebText2
    - \*

      USPTO
    - \*

      Project Gutenberg
    - \*

      OpenSubtitles
    - \*

      Wikipedia
    - \*

      DM Mathematics
    - \*

      HackerNews
  + –

    Pushshift.io Reddit dataset that was developed in [Baumgartner et al. (2020)](#bib.bib3) and processed in [Roller et al. (2021)](#bib.bib70).
  + –

    CCNewsV2 containing an updated version of the English portion of the CommonCrawl News dataset that was used in RoBERTa [Liu et al. (2019b)](#bib.bib44)
* •

  How many instances are there in total (of each type, if appropriate)? The training data contains  180B tokens corresponding to 800 GB of data.
* •

  Does the dataset contain all possible instances or is it a sample (not necessarily random) of instances from a larger set? If the dataset is a sample, then what is the larger set? Is the sample representative of the larger set (e.g., geographic coverage)? If so, please describe how this representativeness was validated/verified. If it is not representative of the larger set, please describe why not (e.g., to cover a more diverse range of instances, because instances were withheld or unavailable). The CC-stories dataset contains a subset of CommonCrawl data filtered to match the story-like style of Winograd schemas. The remainder of the dataset was collected from the above sources, reformatted, and deduplicated.
* •

  What data does each instance consist of? “Raw” data (e.g., unprocessed text or images) or features? In either case, please provide a description. Each instance consists of raw text data.
* •

  Is there a label or target associated with each instance? If so, please provide a description. No.
* •

  Is any information missing from individual instances? If so, please provide a description, explaining why this information is missing (e.g., because it was unavailable). This does not include intentionally removed information, but might include, e.g., redacted text. No.
* •

  Are relationships between individual instances made explicit (e.g., users’ movie ratings, social network links)? If so, please describe how these relationships are made explicit. There are no explicit relationships between individual instances.
* •

  Are there recommended data splits (e.g., training, development/validation, testing)? If so, please provide a description of these splits, explaining the rationale behind them. We hold out a random validation set of approximately 200MB from the pretraining data, sampled proportionally to each dataset’s size in the pretraining corpus.
* •

  Are there any errors, sources of noise, or redundancies in the dataset? If so, please provide a description. Outside of naturally occurring duplication from potential overlaps between the datasets, there are no other redundancies, errors, or sources of noise that we add.
* •

  Is the dataset self-contained, or does it link to or otherwise rely on external resources (e.g., websites, tweets, other datasets)? It’s self-contained.
* •

  Does the dataset contain data that, if viewed directly, might be offensive, insulting, threatening, or might otherwise cause anxiety? If so, please describe why. Parts of the dataset are a subset of public Common Crawl data, along with a subset of public Reddit data, which could contain sentences that, if viewed directly, might be offensive, insulting, threatening, or might otherwise cause anxiety.
* •

  Does the dataset relate to people? If not, you may skip the remaining questions in this section. Some documents of this data relate to people, such as news articles, Wikipedia descriptions, etc.
* •

  Does the dataset identify any subpopulations (e.g., by age, gender)? If so, please describe how these subpopulations are identified and provide a description of their respective distributions within the dataset. No, the dataset does not explicitly include subpopulation identification.
* •

  Any other comments? No.

### C.3 Collection Process

* •

  How was the data associated with each instance acquired? Was the data directly observable (e.g., raw text, movie ratings), reported by subjects (e.g., survey responses), or indirectly inferred/ derived from other data (e.g., part-of-speech tags, model-based guesses for age or language)? If data was reported by subjects or indirectly inferred/derived from other data, was the data validated/verified? If so, please describe how. N/A. The dataset is a union of five publicly available datasets.
* •

  What mechanisms or procedures were used to collect the data (e.g., hardware apparatus or sensor, manual human curation, software program, software API)? How were these mechanisms or procedures validated? The data was downloaded from the internet.
* •

  If the dataset is a sample from a larger set, what was the sampling strategy (e.g., deterministic, probabilistic with specific sampling probabilities)? Please see previous answers for how the dataset was created.
* •

  Who was involved in the data collection process (e.g., students, crowdworkers, contractors) and how were they compensated (e.g., how much were crowdworkers paid)? This data is mined, filtered and sampled by machines.
* •

  Over what timeframe was the data collected? Does this timeframe match the creation timeframe of the data associated with the instances (e.g., recent crawl of old news articles)? If not, please describe the timeframe in which the data associated with the instances was created. The CC-News dataset contains English news articles crawled between September 2016 and September 2021.
* •

  Does the dataset relate to people? If not, you may skip the remainder of the questions in this section. No.
* •

  Did you collect the data from the individuals in question directly, or obtain it via third parties or other sources (e.g., websites)? N/A.
* •

  Were the individuals in question notified about the data collection? If so, please describe (or show with screenshots or other information) how notice was provided, and provide a link or other access point to, or otherwise reproduce, the exact language of the notification itself. N/A.
* •

  Did the individuals in question consent to the collection and use of their data? If so, please describe (or show with screenshots or other information) how consent was requested and provided, and provide a link or other access point to, or otherwise reproduce, the exact language to which the individuals consented. N/A.
* •

  If consent was obtained, were the consenting individuals provided with a mechanism to revoke their consent in the future or for certain uses? If so, please provide a description, as well as a link or other access point to the mechanism (if appropriate). N/A.
* •

  Has an analysis of the potential impact of the dataset and its use on data subjects (e.g., a data protection impact analysis) been conducted? If so, please provide a description of this analysis, including the outcomes, as well as a link or other access point to any supporting documentation. Some toxicity and bias evaluations were performed. Please refer to the main document and the model card for these details.
* •

  Any other comments? No.

### C.4 Preprocessing/cleaning/labeling

* •

  Was any preprocessing/cleaning/labeling of the data done (e.g., discretization or bucketing, tokenization, part-of-speech tagging, SIFT feature extraction, removal of instances, processing of missing values)? If so, please provide a description. If not, you may skip the remainder of the questions in this section. The component datasets went through standard cleaning and re-formatting practices, including removing repetitive/non-informative text like “Chapter One,” or “This ebook by Project Gutenberg.”
* •

  Was the “raw” data saved in addition to the preprocessed/cleaned/labeled data (e.g., to support unanticipated future uses)? If so, please provide a link or other access point to the “raw” data. The “raw” component datasets is publicly available in their respective locations (more details can be seen in the respective papers linked in references).
* •

  Any other comments? No.

### C.5 Uses

* •

  Has the dataset been used for any tasks already? If so, please provide a description. Yes, this dataset was used to pre-train the OPT models.
* •

  Is there a repository that links to any or all papers or systems that use the dataset? If so, please provide a link or other access point. <https://github.com/facebookresearch/metaseq>
* •

  What (other) tasks could the dataset be used for? This data can be used to pre-train language models, which are foundation to many current and future language tasks.
* •

  Is there anything about the composition of the dataset or the way it was collected and preprocessed/cleaned/labeled that might impact future uses? For example, is there anything that a future user might need to know to avoid uses that could result in unfair treatment of individuals or groups (e.g., stereotyping, quality of service issues) or other undesirable harms (e.g., financial harms, legal risks) If so, please provide a description. Is there anything a future user could do to mitigate these undesirable harms? The pipeline for creating this dataset paves a way for building a scalable infrastructure for mining datasets.
* •

  Are there tasks for which the dataset should not be used? If so, please provide a description. None that we are currently aware of.
* •

  Any other comments? No.

### C.6 Distribution

* •

  Will the dataset be distributed to third parties outside of the entity (e.g., company, institution, organization) on behalf of which the dataset was created? If so, please provide a description. Not at this time.
* •

  How will the dataset will be distributed (e.g., tarball on website, API, GitHub)? Does the dataset have a digital object identifier (DOI)? N/A.
* •

  When will the dataset be distributed? N/A.
* •

  Will the dataset be distributed under a copyright or other intellectual property (IP) license, and/or under applicable terms of use (ToU)? If so, please describe this license and/or ToU, and provide a link or other access point to, or otherwise reproduce, any relevant licensing terms or ToU, as well as any fees associated with these restrictions. N/A.
* •

  Do any export controls or other regulatory restrictions apply to the dataset or to individual instances? If so, please describe these restrictions, and provide a link or other access point to, or otherwise reproduce, any supporting documentation. N/A.
* •

  Any other comments? No.

### C.7 Maintenance

* •

  Who is supporting/hosting/maintaining the dataset? Meta AI.
* •

  How can the owner/curator/manager of the dataset be contacted (e.g., email address)? Refer to the main document.
* •

  Is there an erratum? If so, please provide a link or other access point. N/A.
* •

  Will the dataset be updated (e.g., to correct labeling errors, add new instances, delete instances)? If so, please describe how often, by whom, and how updates will be communicated to users (e.g., mailing list, GitHub)? No current plan for updating.
* •

  If the dataset relates to people, are there applicable limits on the retention of the data associated with the instances (e.g., were individuals in question told that their data would be retained for a fixed period of time and then deleted)? If so, please describe these limits and explain how they will be enforced. N/A.
* •

  Will older versions of the dataset continue to be supported/hosted/maintained? If so, please describe how. If not, please describe how its obsolescence will be communicated to users. N/A.
* •

  If others want to extend/augment/build on/contribute to the dataset, is there a mechanism for them to do so? If so, please provide a description. Will these contributions be validated/ verified? If so, please describe how. If not, why not? Is there a process for communicating/ distributing these contributions to other users? If so, please provide a description. No mechanism is available right now.
* •

  Any other comments? No.

## Appendix D Model Card

Following [Mitchell et al. (2018)](#bib.bib53), we provide a model card for OPT-175B.

### D.1 Model Details

* •

  Person or organization developing model: OPT-175B was developed by Meta AI.
* •

  Model date: OPT-175B was released on May 3, 2022.
* •

  Model version: OPT-175B described in this paper is version 1.0.0.
* •

  Model type: OPT-175B is a large decoder-only transformer language model.
* •

  Information about training algorithms, parameters, fairness constraints or other applied approaches, and features: OPT-175B was trained with AdamW for parameter sizes from 125M to 175B. See the Data Card (Appendix [C](#A3 "Appendix C Datasheet ‣ OPT: Open Pre-trained Transformer Language Models")) for information about training data and Section [2.2](#S2.SS2 "2.2 Training Setup ‣ 2 Method ‣ OPT: Open Pre-trained Transformer Language Models") - [2.5](#S2.SS5 "2.5 Training Processes ‣ 2 Method ‣ OPT: Open Pre-trained Transformer Language Models") for information about the training process.
* •

  Paper or other resource for more information: See the rest of this paper for more details on OPT-175B as well as the corresponding post on the Meta AI Research Blog. More details are also available in metaseq, our open-source repository.1212
  12
  <https://github.com/facebookresearch/metaseq/>
* •

  License: OPT-175B and the smaller baseline models are made available through a non-commercial use license agreement provided in our model license.1313
  13
  <https://github.com/facebookresearch/metaseq/blob/main/projects/OPT/MODEL_LICENSE.md>
* •

  Where to send questions or comments about the model: Please contact the corresponding authors {susanz,roller,namangoyal}@fb.com for any questions or comments.

### D.2 Intended Use

* •

  Primary intended uses: We release OPT-175B for research into Language Models, especially as it pertains to Responsible AI. See Section [6](#S6 "6 Considerations for Release ‣ OPT: Open Pre-trained Transformer Language Models") for more detailed Considerations for Release. Information on how to use the model can be found at metaseq, our open-source repository.
* •

  Primary intended users: We primarily target researchers and the related research community.
* •

  Out-of-scope use cases:  OPT-175B is not released for production use or real-world deployments. As we note in Section [5](#S5 "5 Limitations ‣ OPT: Open Pre-trained Transformer Language Models"), OPT-175B, like similar large language models, has a variety of shortcomings that make it premature for commercial use.

### D.3 Data, Limitations, and Recommendations

* •

  Data selection for training: Training data for OPT-175B was selected based on a combination of breadth and availability. See our Data Card (Appendix [C](#A3 "Appendix C Datasheet ‣ OPT: Open Pre-trained Transformer Language Models")) for more detailed information on the data used to train our model.
* •

  Data selection for evaluation: Evaluations in this paper were chosen to provide comparable performance assessments relative to similar scale models in the literature. Given concerns in the community around safety and fairness of large language models in general, we also explicitly provide evaluations on Responsible AI (see Section [4](#S4 "4 Bias & Toxicity Evaluations ‣ OPT: Open Pre-trained Transformer Language Models")).
* •

  Limitations: Like other large language models for which the diversity (or lack thereof) of training data induces downstream impact on the quality of our model, OPT-175B has limitations in terms of bias and safety. OPT-175B can also have quality issues in terms of generation diversity and hallucination. In general, OPT-175B is not immune from the plethora of issues that plague modern large language models. By releasing with a non-commercial license, we also hope to increase communication, transparency, and study of the problems of large language models, especially in areas which may not be aligned with commercial interests. See Section [5](#S5 "5 Limitations ‣ OPT: Open Pre-trained Transformer Language Models") for a more detailed discussion of limitations of OPT-175B.
* •

  Recommendations for future work: See Section [6](#S6 "6 Considerations for Release ‣ OPT: Open Pre-trained Transformer Language Models") for more about our Considerations for Release, including a discussion of potential avenues of research enabled by opening our model to more of the research community. We hope that the release of OPT-175B, as well as information around our model training process, will increase open science around both large language models in specific and natural language processing and deep learning in general.

## Appendix E Sample Model Outputs

For all sample outputs, the initial prompt is given in bold and the remainder is the continuation. These example outputs were intentionally selected to highlight both successes and failures of the OPT-175B model.

Figure 8: Poetry generation. We have observed the model can write entertaining poetry on topics such as dodos, samosas, and performance reviews. However, we struggled to get the model to observe rhyme or meter.

Figure 9: Conversation generation. OPT-175B adopts a patriotic personality when prompted as the Statue of Liberty. However, the model also devolves into somewhat simple and linguistically repetitive generations further into the conversation.

Figure 10: Basic few-shot translation example. OPT was not intentionally trained to be multilingual, but we found anecdotally it has limited success with simple translations in German, Spanish, French, and Chinese.

Figure 11: Paper writing example. Prompting with "1. Introduction" generally yielded more interesting results compared to prompting with “Abstract.” Our prompt here was inspired by the first sentence of the seminal ResNet work [He et al. (2016)](#bib.bib28).

Figure 12: Arithmetic. We observe mistakes when extending from addition to other operations.

Figure 13: Python programming. Simply switching out a variable name can alter the generated output.
