<!-- fulltext source=arxiv_html slug=arXiv-2001.08361 fetched=2026-09-22T13:25:22+00:00 -->

# Scaling Laws for Neural Language Models

Jared Kaplan
††thanks: Equal contribution.
  
  
Contributions: Jared Kaplan and Sam McCandlish led the research. Tom Henighan contributed the LSTM experiments. Tom Brown, Rewon Child, and Scott Gray, and Alec Radford developed the optimized Transformer implementation. Jeff Wu, Benjamin Chess, and Alec Radford developed the text datasets. Dario Amodei provided guidance throughout the project.
  
  
Affiliation: Johns Hopkins University, OpenAI
Email: [jaredk@jhu.edu](mailto:)
  
Sam McCandlish∗
Affiliation: OpenAI
Email: [sam@openai.com](mailto:)
  
Tom Henighan
Affiliation: OpenAI
Email: [henighan@openai.com](mailto:)
  
Tom B. Brown
Affiliation: OpenAI
Email: [tom@openai.com](mailto:)
  
Benjamin Chess
Affiliation: OpenAI
Email: [bchess@openai.com](mailto:)
  
Rewon Child
Affiliation: OpenAI
Email: [rewon@openai.com](mailto:)
  
Scott Gray
Affiliation: OpenAI
Email: [scott@openai.com](mailto:)
  
Alec Radford
Affiliation: OpenAI
Email: [alec@openai.com](mailto:)
  
Jeffrey Wu
Affiliation: OpenAI
Email: [jeffwu@openai.com](mailto:)
  
Dario Amodei
Affiliation: OpenAI
Email: [damodei@openai.com](mailto:)

###### Abstract

We study empirical scaling laws for language model performance on the cross-entropy loss.
The loss scales as a power-law with model size, dataset size, and the amount of compute used for training, with some trends spanning more than seven orders of magnitude.
Other architectural details such as network width or depth have minimal effects within a wide range.
Simple equations govern the dependence of overfitting on model/dataset size and the dependence of training speed on model size.
These relationships allow us to determine the optimal allocation of a fixed compute budget.
Larger models are significantly more sample-efficient, such that optimally compute-efficient training involves training very large models on a relatively modest amount of data and stopping significantly before convergence.

|  |
| --- |
|  |

## 1 Introduction

Language provides a natural domain for the study of artificial intelligence, as the vast majority of reasoning tasks can be efficiently expressed and evaluated in language, and the world’s text provides a wealth of data for unsupervised learning via generative modeling. Deep learning has recently seen rapid progress in language modeling, with state of the art models [[RNSS18](#bib.bibx30), [DCLT18](#bib.bibx7), [YDY+19](#bib.bibx47), [LOG+19](#bib.bibx24), [RSR+19](#bib.bibx33)] approaching human-level performance on many specific tasks [[WPN+19](#bib.bibx44)], including the composition of coherent multi-paragraph prompted text samples [[RWC+19](#bib.bibx34)].

One might expect language modeling performance to depend on model architecture, the size of neural models, the computing power used to train them, and the data available for this training process. In this work we will empirically investigate the dependence of language modeling loss on all of these factors, focusing on the Transformer architecture [[VSP+17](#bib.bibx41), [LSP+18](#bib.bibx25)]. The high ceiling and low floor for performance on language tasks allows us to study trends over more than seven orders of magnitude in scale.

Throughout we will observe precise power-law scalings for performance as a function of training time, context length, dataset size, model size, and compute budget.

Figure 1: Language modeling performance improves smoothly as we increase the model size, datasetset size, and amount of compute11
1
Here we display predicted compute when using a sufficiently small batch size. See Figure [13](#S6.F13 "Figure 13 ‣ 6 Optimal Allocation of the Compute Budget ‣ Scaling Laws for Neural Language Models") for comparison to the purely empirical data. used for training. For optimal performance all three factors must be scaled up in tandem. Empirical performance has a power-law relationship with each individual factor when not bottlenecked by the other two.

### 1.1 Summary

Our key findings for Transformer language models are are as follows:

##### Performance depends strongly on scale, weakly on model shape:

Model performance depends most strongly on scale, which consists of three factors: the number of model parameters $N$ (excluding embeddings), the size of the dataset $D$, and the amount of compute $C$ used for training. Within reasonable limits, performance depends very weakly on other architectural hyperparameters such as depth vs. width. (Section [3](#S3 "3 Empirical Results and Basic Power Laws ‣ Scaling Laws for Neural Language Models"))

##### Smooth power laws:

Performance has a power-law relationship with each of the three scale factors $N,D,C$ when not bottlenecked by the other two, with trends spanning more than six orders of magnitude (see Figure [1](#footnote1 "footnote 1 ‣ Figure 1 ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")). We observe no signs of deviation from these trends on the upper end, though performance must flatten out eventually before reaching zero loss. (Section [3](#S3 "3 Empirical Results and Basic Power Laws ‣ Scaling Laws for Neural Language Models"))

##### Universality of overfitting:

Performance improves predictably as long as we scale up $N$ and $D$ in tandem, but enters a regime of diminishing returns if either $N$ or $D$ is held fixed while the other increases. The performance penalty depends predictably on the ratio $N^{0.74}/D$, meaning that every time we increase the model size 8x, we only need to increase the data by roughly 5x to avoid a penalty. (Section [4](#S4 "4 Charting the Infinite Data Limit and Overfitting ‣ Scaling Laws for Neural Language Models"))

##### Universality of training:

Training curves follow predictable power-laws whose parameters are roughly independent of the model size. By extrapolating the early part of a training curve, we can roughly predict the loss that would be achieved if we trained for much longer. (Section [5](#S5 "5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models"))

##### Transfer improves with test performance:

When we evaluate models on text with a different distribution than they were trained on, the results are strongly correlated to those on the training validation set with a roughly constant offset in the loss – in other words, transfer to a different distribution incurs a constant penalty but otherwise improves roughly in line with performance on the training set. (Section [3.2.2](#S3.SS2.SSS2 "3.2.2 Generalization Among Data Distributions ‣ 3.2 Performance with Non-Embedding Parameter Count 𝑁 ‣ 3 Empirical Results and Basic Power Laws ‣ Scaling Laws for Neural Language Models"))

##### Sample efficiency:

Large models are more sample-efficient than small models, reaching the same level of performance with fewer optimization steps (Figure [2](#S1.F2 "Figure 2 ‣ Sample efficiency: ‣ 1.1 Summary ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")) and using fewer data points (Figure [4](#S1.F4 "Figure 4 ‣ 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")).

Figure 2: We show a series of language model training runs, with models ranging in size from $10^{3}$ to $10^{9}$ parameters (excluding embeddings).

Figure 3: As more compute becomes available, we can choose how much to allocate towards training larger models, using larger batches, and training for more steps. We illustrate this for a billion-fold increase in compute. For optimally compute-efficient training, most of the increase should go towards increased model size. A relatively small increase in data is needed to avoid reuse. Of the increase in data, most can be used to increase parallelism through larger batch sizes, with only a very small increase in serial training time required.

##### Convergence is inefficient:

When working within a fixed compute budget $C$ but without any other restrictions on the model size $N$ or available data $D$, we attain optimal performance by training *very large models* and stopping *significantly short of convergence* (see Figure [3](#S1.F3 "Figure 3 ‣ Sample efficiency: ‣ 1.1 Summary ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")). Maximally compute-efficient training would therefore be far more sample efficient than one might expect based on training small models to convergence, with data requirements growing very slowly as $D\sim C^{0.27}$ with training compute. (Section [6](#S6 "6 Optimal Allocation of the Compute Budget ‣ Scaling Laws for Neural Language Models"))

##### Optimal batch size:

The ideal batch size for training these models is roughly a power of the loss only, and continues to be determinable by measuring the gradient noise scale [[MKAT18](#bib.bibx28)]; it is roughly 1-2 million tokens at convergence for the largest models we can train. (Section [5.1](#S5.SS1 "5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models"))

Taken together, these results show that language modeling performance improves smoothly and predictably as we appropriately scale up model size, data, and compute. We expect that larger language models will perform better and be more sample efficient than current models.

### 1.2 Summary of Scaling Laws

The test loss of a Transformer trained to autoregressively model language can be predicted using a power-law when performance is limited by only either the number of non-embedding parameters $N$, the dataset size $D$, or the optimally allocated compute budget $C\_{\rm min}$ (see Figure [1](#footnote1 "footnote 1 ‣ Figure 1 ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")):

1. 1.

   For models with a limited number of parameters, trained to convergence on sufficiently large datasets:

   |  |  |  |  |
   | --- | --- | --- | --- |
   |  | $L(N)=\left(N\_{\mathrm{c}}/N\right)^{\alpha\_{N}};\penalty\ \penalty\ \alpha\_{N}\sim 0.076,\quad N\_{\mathrm{c}}\sim 8.8\times 10^{13}\penalty\ \text{(non-embedding parameters)}$ |  | (1.1) |
2. 2.

   For large models trained with a limited dataset with early stopping:

   |  |  |  |  |
   | --- | --- | --- | --- |
   |  | $L(D)=\left(D\_{\mathrm{c}}/D\right)^{\alpha\_{D}};\penalty\ \penalty\ \alpha\_{D}\sim 0.095,\quad D\_{\mathrm{c}}\sim 5.4\times 10^{13}\penalty\ \text{(tokens)}$ |  | (1.2) |
3. 3.

   When training with a limited amount of compute, a sufficiently large dataset, an optimally-sized model, and a sufficiently small batch size (making optimal22
   2
   We also observe an empirical power-law trend with the training compute $C$ (Figure [1](#footnote1 "footnote 1 ‣ Figure 1 ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")) while training at fixed batch size, but it is the trend with $C\_{\rm min}$ that should be used to make predictions. They are related by equation ([5.5](#S5.E5 "In 5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models")).  use of compute):

   |  |  |  |  |
   | --- | --- | --- | --- |
   |  | $L(C\_{\rm min})=\left(C\_{\mathrm{c}}^{\rm min}/C\_{\rm min}\right)^{\alpha\_{C}^{\rm min}};\penalty\ \penalty\ \alpha\_{C}^{\rm min}\sim 0.050,\quad C\_{\mathrm{c}}^{\rm min}\sim 3.1\times 10^{8}\penalty\ \text{(PF-days)}$ |  | (1.3) |

These relations hold across eight orders of magnitude in $C\_{\rm min}$, six orders of magnitude in $N$, and over two orders of magnitude in $D$. They depend very weakly on model shape and other Transformer hyperparameters (depth, width, number of self-attention heads), with specific numerical values associated with the Webtext2 training set [[RWC+19](#bib.bibx34)]. The power laws $\alpha\_{\rm N},\alpha\_{\rm D},\alpha\_{C}^{\rm min}$ specify the degree of performance improvement expected as we scale up $N$, $D$, or $C\_{\rm min}$; for example, doubling the number of parameters yields a loss that is smaller by a factor $2^{-\alpha\_{N}}=0.95$. The precise numerical values of $N\_{\mathrm{c}},C\_{\rm c}^{\rm min},$ and $D\_{\mathrm{c}}$ depend on the vocabulary size and tokenization and hence do not have a fundamental meaning.

The critical batch size, which determines the speed/efficiency tradeoff for data parallelism ([[MKAT18](#bib.bibx28)]), also roughly obeys a power law in $L$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $B\_{\rm crit}\left(L\right)=\frac{B\_{\ast}}{L^{1/\alpha\_{B}}},\qquad B\_{\ast}\sim 2\cdot 10^{8}\text{ tokens},\ \ \alpha\_{B}\sim 0.21$ |  | (1.4) |

Figure 4: 
Left: The early-stopped test loss $L(N,D)$ varies predictably with the dataset size $D$ and model size $N$ according to Equation ([1.5](#S1.E5 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")).
Right: After an initial transient period, learning curves for all model sizes $N$ can be fit with Equation ([1.6](#S1.E6 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")), which is parameterized in terms of $S\_{\rm min}$, the number of steps when training at large batch size (details in Section [5.1](#S5.SS1 "5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models")).

Equation ([1.1](#S1.E1 "In item 1 ‣ 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")) and ([1.2](#S1.E2 "In item 2 ‣ 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")) together suggest that as we increase the model size, we should increase the dataset size sublinearly according to $D\propto N^{\frac{\alpha\_{N}}{\alpha\_{D}}}\sim N^{0.74}$. In fact, we find that there is a single equation combining ([1.1](#S1.E1 "In item 1 ‣ 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")) and ([1.2](#S1.E2 "In item 2 ‣ 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")) that governs the simultaneous dependence on $N$ and $D$ and governs the degree of overfitting:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L(N,D)=\left[\left(\frac{N\_{c}}{N}\right)^{\frac{\alpha\_{N}}{\alpha\_{D}}}+\frac{D\_{c}}{D}\right]^{\alpha\_{D}}$ |  | (1.5) |

with fits pictured on the left in figure [4](#S1.F4 "Figure 4 ‣ 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models"). We conjecture that this functional form may also parameterize the trained log-likelihood for other generative modeling tasks.

When training a given model for a finite number of parameter update steps $S$ in the infinite data limit, after an initial transient period, the learning curves can be accurately fit by (see the right of figure [4](#S1.F4 "Figure 4 ‣ 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models"))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L(N,S)=\left(\frac{N\_{c}}{N}\right)^{\alpha\_{N}}+\left(\frac{S\_{c}}{S\_{\rm min}(S)}\right)^{\alpha\_{S}}$ |  | (1.6) |

where $S\_{c}\approx 2.1\times 10^{3}$ and $\alpha\_{S}\approx 0.76$, and $S\_{\rm min}(S)$ is the minimum possible number of optimization steps (parameter updates)
estimated using Equation ([5.4](#S5.E4 "In 5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models")).

When training within a fixed compute budget $C$, but with no other constraints, Equation ([1.6](#S1.E6 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")) leads to the prediction that the optimal model size $N$, optimal batch size $B$, optimal number of steps $S$, and dataset size $D$ should grow as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $N\propto C^{\alpha\_{C}^{\rm min}/\alpha\_{N}},\quad B\propto C^{\alpha\_{C}^{\rm min}/\alpha\_{B}},\quad S\propto C^{\alpha\_{C}^{\rm min}/\alpha\_{S}},\quad D=B\cdot S\quad$ |  | (1.7) |

with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\alpha\_{C}^{\rm min}=1/\left(1/\alpha\_{S}+1/\alpha\_{B}+1/\alpha\_{N}\right)$ |  | (1.8) |

which closely matches the empirically optimal results $N\propto C\_{\rm min}^{0.73}$, $B\propto C\_{\rm min}^{0.24}$, and $S\propto C\_{\rm min}^{0.03}$. As the computational budget $C$ increases, it should be spent primarily on larger models, without dramatic increases in training time or dataset size (see Figure [3](#S1.F3 "Figure 3 ‣ Sample efficiency: ‣ 1.1 Summary ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")). This also implies that as models grow larger, they become increasingly sample efficient. In practice, researchers typically train smaller models for longer than would be maximally compute-efficient because of hardware constraints.
Optimal performance depends on total compute as a power law (see Equation ([1.3](#S1.E3 "In item 3 ‣ 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models"))).

We provide some basic theoretical motivation for Equation ([1.5](#S1.E5 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")), an analysis of learning curve fits and their implications for training time, and a breakdown of our results per token. We also make some brief comparisons to LSTMs and recurrent Transformers [[DGV+18](#bib.bibx8)].

### 1.3 Notation

We use the following notation:

* •

  $L$ – the cross entropy loss in nats. Typically it will be averaged over the tokens in a context, but in some cases we report the loss for specific tokens within the context.
* •

  $N$ – the number of model parameters, *excluding all vocabulary and positional embeddings*
* •

  $C\approx 6NBS$ – an estimate of the total non-embedding training compute, where $B$ is the batch size, and $S$ is the number of training steps (ie parameter updates). We quote numerical values in PF-days, where one PF-day $=10^{15}\times 24\times 3600=8.64\times 10^{19}$ floating point operations.
* •

  $D$ – the dataset size in tokens
* •

  $B\_{\rm crit}$ – the critical batch size [[MKAT18](#bib.bibx28)], defined and discussed in Section [5.1](#S5.SS1 "5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models"). Training at the critical batch size provides a roughly optimal compromise between time and compute efficiency.
* •

  $C\_{\rm min}$ – an estimate of the minimum amount of non-embedding compute to reach a given value of the loss. This is the training compute that would be used if the model were trained at a batch size much less than the critical batch size.
* •

  $S\_{\rm min}$ – an estimate of the minimal number of training steps needed to reach a given value of the loss. This is also the number of training steps that would be used if the model were trained at a batch size much greater than the critical batch size.
* •

  $\alpha\_{X}$ – power-law exponents for the scaling of the loss as $L(X)\propto 1/X^{\alpha\_{X}}$ where $X$ can be any of $N,D,C,S,B,C^{\rm min}$.

## 2 Background and Methods

We train language models on WebText2, an extended version of the WebText [[RWC+19](#bib.bibx34)] dataset, tokenized using byte-pair encoding [[SHB15](#bib.bibx36)] with a vocabulary size $n\_{\rm vocab}=50257$. We optimize the autoregressive log-likelihood (i.e. cross-entropy loss) averaged over a 1024-token context, which is also our principal performance metric. We record the loss on the WebText2 test distribution and on a selection of other text distributions. We primarily train decoder-only [[LSP+18](#bib.bibx25), [RNSS18](#bib.bibx30)] Transformer [[VSP+17](#bib.bibx41)] models, though we also train LSTM models and Universal Transformers [[DGV+18](#bib.bibx8)] for comparison.

### 2.1 Parameter and Compute Scaling of Transformers

|  |  |  |
| --- | --- | --- |
| Operation | Parameters | FLOPs per Token |
| Embed | $\left(n\_{{\rm vocab}}+n\_{{\rm ctx}}\right)d\_{{\rm model}}$ | $4d\_{{\rm model}}$ |
| Attention: QKV | $n\_{{\rm layer}}d\_{{\rm model}}3d\_{{\rm attn}}$ | $2n\_{{\rm layer}}d\_{{\rm model}}3d\_{{\rm attn}}$ |
| Attention: Mask | — | $2n\_{{\rm layer}}n\_{{\rm ctx}}d\_{{\rm attn}}$ |
| Attention: Project | $n\_{{\rm layer}}d\_{{\rm attn}}d\_{{\rm model}}$ | $2n\_{{\rm layer}}d\_{{\rm attn}}d\_{{\rm embd}}$ |
| Feedforward | $n\_{{\rm layer}}2d\_{{\rm model}}d\_{{\rm ff}}$ | $2n\_{{\rm layer}}2d\_{{\rm model}}d\_{{\rm ff}}$ |
| De-embed | — | $2d\_{{\rm model}}n\_{{\rm vocab}}$ |
| Total (Non-Embedding) | $N=2d\_{{\rm model}}n\_{{\rm layer}}\left(2d\_{{\rm attn}}+d\_{{\rm ff}}\right)$ | $C\_{\mathrm{forward}}=2N+2n\_{{\rm layer}}n\_{{\rm ctx}}d\_{{\rm attn}}$ |

Table 1: Parameter counts and compute (forward pass) estimates for a Transformer model. Sub-leading terms such as nonlinearities, biases, and layer normalization are omitted.

We parameterize the Transformer architecture using hyperparameters $n\_{\rm layer}$ (number of layers), $d\_{{\rm model}}$ (dimension of the residual stream), $d\_{\rm ff}$ (dimension of the intermediate feed-forward layer), $d\_{\rm attn}$ (dimension of the attention output), and $n\_{\rm heads}$ (number of attention heads per layer). We include $n\_{\rm ctx}$ tokens in the input context, with $n\_{\rm ctx}=1024$ except where otherwise noted.

We use $N$ to denote the model size, which we define as the number of *non-embedding* parameters

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle N$ | $\displaystyle\approx 2d\_{{\rm model}}n\_{{\rm layer}}\left(2d\_{{\rm attn}}+d\_{{\rm ff}}\right)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=12n\_{\rm layer}d\_{{\rm model}}^{2}\quad\text{ with the standard }\quad d\_{\rm attn}=d\_{\rm ff}/4=d\_{{\rm model}}$ |  | (2.1) |

where we have excluded biases and other sub-leading terms.
Our models also have $n\_{\rm vocab}d\_{{\rm model}}$ parameters in an embedding matrix, and use $n\_{\rm ctx}d\_{{\rm model}}$ parameters for positional embeddings, but we do not include these when discussing the ‘model size’ $N$; we will see that this produces significantly cleaner scaling laws.

Evaluating a forward pass of the Transformer involves roughly

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{\rm forward}\approx 2N+2n\_{{\rm layer}}n\_{{\rm ctx}}d\_{{\rm model}}$ |  | (2.2) |

add-multiply operations, where the factor of two comes from the multiply-accumulate operation used in matrix multiplication. A more detailed per-operation parameter and compute count is included in Table [1](#S2.T1 "Table 1 ‣ 2.1 Parameter and Compute Scaling of Transformers ‣ 2 Background and Methods ‣ Scaling Laws for Neural Language Models").

For contexts and models with $d\_{{\rm model}}>n\_{\rm ctx}/12$, the context-dependent computational cost per token is a relatively small fraction of the total compute.
Since we primarily study models where $d\_{\rm model}\gg n\_{\rm ctx}/12$, we do not include context-dependent terms in our training compute estimate. Accounting for the backwards pass (approximately twice the compute as the forwards pass), we then define the estimated non-embedding compute as $C\approx 6N$ floating point operators per training token.

### 2.2 Training Procedures

Unless otherwise noted, we train models with the Adam optimizer [[KB14](#bib.bibx20)] for a fixed $2.5\times 10^{5}$ steps with a batch size of $512$ sequences of $1024$ tokens.
Due to memory constraints, our largest models (more than 1B parameters) were trained with Adafactor [[SS18](#bib.bibx38)].
We experimented with a variety of learning rates and schedules, as discussed in Appendix [D.6](#A4.SS6 "D.6 Learning Rate Schedules and Error Analysis ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models").
We found that results at convergence were largely independent of learning rate schedule. Unless otherwise noted, all training runs included in our data used a learning rate schedule with a 3000 step linear warmup followed by a cosine decay to zero.

### 2.3 Datasets

We train our models on an extended version of the WebText dataset described in [[RWC+19](#bib.bibx34)]. The original WebText dataset was a web scrape of outbound links from Reddit through December 2017 which received at least 3 karma. In the second version, WebText2, we added outbound Reddit links from the period of January to October 2018, also with a minimum of 3 karma. The karma threshold served as a heuristic for whether people found the link interesting or useful. The text of the new links was extracted with the Newspaper3k python library. In total, the dataset consists of 20.3M documents containing 96 GB of text and $1.62\times 10^{10}$ words (as defined by wc). We then apply the reversible tokenizer described in [[RWC+19](#bib.bibx34)], which yields $2.29\times 10^{10}$ tokens. We reserve $6.6\times 10^{8}$ of these tokens for use as a test set, and we also test on similarly-prepared samples of Books Corpus [[ZKZ+15](#bib.bibx49)], Common Crawl [[Fou](#bib.bibx10)], English Wikipedia, and a collection of publicly-available Internet Books.

## 3 Empirical Results and Basic Power Laws

To characterize language model scaling we train a wide variety of models, varying a number of factors including:

* •

  Model size (ranging in size from 768 to 1.5 billion non-embedding parameters)
* •

  Dataset size (ranging from 22 million to 23 billion tokens)
* •

  Shape (including depth, width, attention heads, and feed-forward dimension)
* •

  Context length (1024 for most runs, though we also experiment with shorter contexts)
* •

  Batch size ($2^{19}$ for most runs, but we also vary it to measure the critical batch size)

In this section we will display data along with empirically-motivated fits, deferring theoretical analysis to later sections.

### 3.1 Approximate Transformer Shape and Hyperparameter Independence

Figure 5: Performance depends very mildly on model shape when the total number of non-embedding parameters $N$ is held fixed. The loss varies only a few percent over a wide range of shapes. Small differences in parameter counts are compensated for by using the fit to $L(N)$ as a baseline. Aspect ratio in particular can vary by a factor of 40 while only slightly impacting performance; an $(n\_{\mathrm{layer}},d\_{\mathrm{model}})=(6,4288)$ reaches a loss within 3% of the $(48,1600)$ model used in [[RWC+19](#bib.bibx34)].

Transformer performance depends very weakly on the shape parameters $n\_{\rm layer},n\_{\rm heads}$, and $d\_{\rm ff}$ when we hold the total non-embedding parameter count $N$ fixed.
To establish these results we trained models with fixed size while varying a single hyperparameter. This was simplest for the case of $n\_{\rm heads}$. When varying $n\_{\rm layer}$, we simultaneously varied $d\_{{\rm model}}$ while keeping $N\approx 12n\_{\rm layer}d\_{{\rm model}}^{2}$ fixed. Similarly, to vary $d\_{\rm ff}$ at fixed model size we also simultaneously varied the $d\_{{\rm model}}$ parameter, as required by the parameter counts in Table [1](#S2.T1 "Table 1 ‣ 2.1 Parameter and Compute Scaling of Transformers ‣ 2 Background and Methods ‣ Scaling Laws for Neural Language Models"). Independence of $n\_{\rm layers}$ would follow if deeper Transformers effectively behave as ensembles of shallower models, as has been suggested for ResNets [[VWB16](#bib.bibx42)]. The results are shown in Figure [5](#S3.F5 "Figure 5 ‣ 3.1 Approximate Transformer Shape and Hyperparameter Independence ‣ 3 Empirical Results and Basic Power Laws ‣ Scaling Laws for Neural Language Models").

### 3.2 Performance with Non-Embedding Parameter Count $N$

Figure 6: 
Left: When we include embedding parameters, performance appears to depend strongly on the number of layers in addition to the number of parameters.
Right: When we exclude embedding parameters, the performance of models with different depths converge to a single trend. Only models with fewer than 2 layers or with extreme depth-to-width ratios deviate significantly from the trend.

In Figure [6](#S3.F6 "Figure 6 ‣ 3.2 Performance with Non-Embedding Parameter Count 𝑁 ‣ 3 Empirical Results and Basic Power Laws ‣ Scaling Laws for Neural Language Models") we display the performance of a wide variety of models, ranging from small models with shape $(n\_{\rm layer},d\_{{\rm model}})=(2,128)$ through billion-parameter models, ranging in shape from $(6,4288)$ through $(207,768)$. Here we have trained to near convergence on the full WebText2 dataset and observe no overfitting (except possibly for the very largest models).

As shown in Figure [1](#footnote1 "footnote 1 ‣ Figure 1 ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models"), we find a steady trend with non-embedding parameter count $N$, which can be fit to the first term of Equation ([1.5](#S1.E5 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")), so that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L(N)\approx\left(\frac{N\_{c}}{N}\right)^{\alpha\_{N}}$ |  | (3.1) |

To observe these trends it is crucial to study performance as a function of $N$; if we instead use the total parameter count (including the embedding parameters) the trend is somewhat obscured (see Figure [6](#S3.F6 "Figure 6 ‣ 3.2 Performance with Non-Embedding Parameter Count 𝑁 ‣ 3 Empirical Results and Basic Power Laws ‣ Scaling Laws for Neural Language Models")). This suggests that the embedding matrix can be made smaller without impacting performance, as has been seen in recent work [[LCG+19](#bib.bibx23)].

Although these models have been trained on the WebText2 dataset, their test loss on a variety of other datasets is also a power-law in $N$ with nearly identical power, as shown in Figure [8](#S3.F8 "Figure 8 ‣ 3.2.2 Generalization Among Data Distributions ‣ 3.2 Performance with Non-Embedding Parameter Count 𝑁 ‣ 3 Empirical Results and Basic Power Laws ‣ Scaling Laws for Neural Language Models").

#### 3.2.1 Comparing to LSTMs and Universal Transformers

Figure 7:

In Figure [7](#S3.F7 "Figure 7 ‣ 3.2.1 Comparing to LSTMs and Universal Transformers ‣ 3.2 Performance with Non-Embedding Parameter Count 𝑁 ‣ 3 Empirical Results and Basic Power Laws ‣ Scaling Laws for Neural Language Models") we compare LSTM and Transformer performance as a function of non-embedding parameter count $N$. The LSTMs were trained with the same dataset and context length. We see from these figures that the LSTMs perform as well as Transformers for tokens appearing early in the context, but cannot match the Transformer performance for later tokens. We present power-law relationships between performance and context position Appendix [D.5](#A4.SS5 "D.5 Context Dependence ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models"), where increasingly large powers for larger models suggest improved ability to quickly recognize patterns.

We also compare the performance of standard Transformers to recurrent Transformers [[DGV+18](#bib.bibx8)] in Figure [17](#A4.F17 "Figure 17 ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models") in the appendix. These models re-use parameters, and so perform slightly better as a function of $N$, at the cost of additional compute per-parameter.

#### 3.2.2 Generalization Among Data Distributions

We have also tested our models on a set of additional text data distributions. The test loss on these datasets as a function of model size is shown in Figure [8](#S3.F8 "Figure 8 ‣ 3.2.2 Generalization Among Data Distributions ‣ 3.2 Performance with Non-Embedding Parameter Count 𝑁 ‣ 3 Empirical Results and Basic Power Laws ‣ Scaling Laws for Neural Language Models"); in all cases the models were trained only on the WebText2 dataset. We see that the loss on these other data distributions improves smoothly with model size, in direct parallel with the improvement on WebText2. We find that generalization depends almost exclusively on the in-distribution validation loss, and does not depend on the duration of training or proximity to convergence. We also observe no dependence on model depth (see Appendix [D.8](#A4.SS8 "D.8 Generalization and Architecture ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models")).

Figure 8: 
Left: Generalization performance to other data distributions improves smoothly with model size, with only a small and very slowly growing offset from the WebText2 training distribution.
Right: Generalization performance depends only on training distribution performance, and not on the phase of training. We compare generalization of converged models (points) to that of a single large model (dashed curves) as it trains.

### 3.3 Performance with Dataset Size and Compute

We display empirical trends for the test loss as a function of dataset size $D$ (in tokens) and training compute $C$ in Figure [1](#footnote1 "footnote 1 ‣ Figure 1 ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models").

For the trend with $D$ we trained a model with $(n\_{\rm layer},n\_{\rm embd})=(36,1280)$ on fixed subsets of the WebText2 dataset. We stopped training once the test loss ceased to decrease. We see that the resulting test losses can be fit with simple power-law

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L(D)\approx\left(\frac{D\_{c}}{D}\right)^{\alpha\_{D}}$ |  | (3.2) |

in the dataset size. The data and fit appear in Figure [1](#footnote1 "footnote 1 ‣ Figure 1 ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models").

The total amount of non-embedding compute used during training can be estimated as $C=6NBS$, where $B$ is the batch size, $S$ is the number of parameter updates, and the factor of $6$ accounts for the forward and backward passes. Thus for a given value of $C$ we can scan over all models with various $N$ to find the model with the best performance on step $S=\frac{C}{6BS}$. Note that in these results *the batch size $B$ remains fixed for all models*, which means that these empirical results are not truly optimal. We will account for this in later sections using an adjusted $C\_{\rm min}$ to produce cleaner trends.

The result appears as the heavy black line on the left-hand plot in Figure [1](#footnote1 "footnote 1 ‣ Figure 1 ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models"). It can be fit with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L(C)\approx\left(\frac{C\_{c}}{C}\right)^{\alpha\_{C}}$ |  | (3.3) |

The figure also includes images of individual learning curves to clarify when individual models are optimal. We will study the optimal allocation of compute more closely later on.
The data strongly suggests that sample efficiency improves with model size, and we also illustrate this directly in Figure [19](#A4.F19 "Figure 19 ‣ D.4 Sample Efficiency vs Model Size ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models") in the appendix.

## 4 Charting the Infinite Data Limit and Overfitting

In Section [3](#S3 "3 Empirical Results and Basic Power Laws ‣ Scaling Laws for Neural Language Models") we found a number of basic scaling laws for language modeling performance. Here we will study the performance of a model of size $N$ trained on a dataset with $D$ tokens while varying $N$ and $D$ simultaneously. We will empirically demonstrate that the optimally trained test loss accords with the scaling law of Equation ([1.5](#S1.E5 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")). This provides guidance on how much data we would need to train models of increasing size while keeping overfitting under control.

### 4.1 Proposed $L(N,D)$ Equation

Figure 9: 
The early-stopped test loss $L(N,D)$ depends predictably on the dataset size $D$ and model size $N$ according to Equation ([1.5](#S1.E5 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")).
Left:
For large $D$, performance is a straight power law in $N$. For a smaller fixed $D$, performance stops improving as $N$ increases and the model begins to overfit. (The reverse is also true, see Figure [4](#S1.F4 "Figure 4 ‣ 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models").)
Right: The extent of overfitting depends predominantly on the ratio $N^{\frac{\alpha\_{N}}{\alpha\_{D}}}/D$, as predicted in equation ([4.3](#S4.E3 "In 4.2 Results ‣ 4 Charting the Infinite Data Limit and Overfitting ‣ Scaling Laws for Neural Language Models")). The line is our fit to that equation.

We have chosen the parameterization ([1.5](#S1.E5 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")) (repeated here for convenience):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L(N,D)=\left[\left(\frac{N\_{c}}{N}\right)^{\frac{\alpha\_{N}}{\alpha\_{D}}}+\frac{D\_{c}}{D}\right]^{\alpha\_{D}}$ |  | (4.1) |

using three principles:

1. 1.

   Changes in vocabulary size or tokenization are expected to rescale the loss by an overall factor. The parameterization of $L(N,D)$ (and all models of the loss) must naturally allow for such a rescaling.
2. 2.

   Fixing $D$ and sending $N\to\infty$, the overall loss should approach $L(D)$. Conversely, fixing $N$ and sending $D\to\infty$ the loss must approach $L(N)$.
3. 3.

   $L(N,D)$ should be analytic at $D=\infty$, so that it has a series expansion in $1/D$ with integer powers. Theoretical support for this principle is significantly weaker than for the first two.

Our choice of $L(N,D)$ satisfies the first requirement because we can rescale $N\_{c},D\_{c}$ with changes in the vocabulary. This also implies that the values of $N\_{c},D\_{c}$ have no fundamental meaning.

Since we stop training early when the test loss ceases to improve and optimize all models in the same way, we expect that larger models should always perform better than smaller models. But with fixed finite $D$, we also do not expect any model to be capable of approaching the best possible loss (ie the entropy of text). Similarly, a model with fixed size will be capacity-limited. These considerations motivate our second principle.
Note that knowledge of $L(N)$ at infinite $D$ and $L(D)$ at infinite $N$ fully determines all the parameters in $L(N,D)$.

The third principle is more speculative. There is a simple and general reason one might expect overfitting to scale $\propto 1/D$ at very large $D$. Overfitting should be related to the variance or the signal-to-noise ratio of the dataset [[AS17](#bib.bibx2)], and this scales as $1/D$. This expectation should hold for any smooth loss function, since we expect to be able to expand the loss about the $D\to\infty$ limit. However, this argument assumes that $1/D$ corrections dominate over other sources of variance, such as the finite batch size and other limits on the efficacy of optimization. Without empirical confirmation, we would not be very confident of its applicability.

Our third principle explains the asymmetry between the roles of $N$ and $D$ in Equation ([1.5](#S1.E5 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")). Very similar symmetric expressions33
3
For example, one might have used $L(N,D)=\left[\left(\frac{N\_{c}}{N}\right)^{\alpha\_{N}}+\left(\frac{D\_{c}}{D}\right)^{\alpha\_{D}}\right]^{\beta}$, but this does not have a $1/D$ expansion. are possible, but they would not have a $1/D$ expansion with integer powers, and would require the introduction of an additional parameter.

In any case, we will see that our equation for $L(N,D)$ fits the data well, which is the most important justification for our $L(N,D)$ ansatz.

### 4.2 Results

We regularize all our models with 10% dropout, and by tracking test loss and stopping once it is no longer decreasing. The results are displayed in Figure [9](#S4.F9 "Figure 9 ‣ 4.1 Proposed 𝐿(𝑁,𝐷) Equation ‣ 4 Charting the Infinite Data Limit and Overfitting ‣ Scaling Laws for Neural Language Models"), including a fit to the four parameters $\alpha\_{N},\alpha\_{D},N\_{c},D\_{c}$ in Equation ([1.5](#S1.E5 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")):

| Parameter | $\alpha\_{N}$ | $\alpha\_{D}$ | $N\_{c}$ | $D\_{c}$ |
| --- | --- | --- | --- | --- |
| Value | $0.076$ | $0.103$ | $6.4\times 10^{13}$ | $1.8\times 10^{13}$ |

Table 2: Fits to $L(N,D)$

We obtain an excellent fit, with the exception of the runs where the dataset has been reduced by a factor of $1024$, to about $2\times 10^{7}$ tokens. With such a small dataset, an epoch consists of only 40 parameter updates. Perhaps such a tiny dataset represents a different regime for language modeling, as overfitting happens very early in training (see Figure [16](#A4.F16 "Figure 16 ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models")). Also note that the parameters differ very slightly from those obtained in Section [3](#S3 "3 Empirical Results and Basic Power Laws ‣ Scaling Laws for Neural Language Models"), as here we are fitting the full $L(N,D)$ rather than just $L(N,\infty)$ or $L(\infty,D)$.

To chart the borderlands of the infinite data limit, we can directly study the extent of overfitting. For all but the largest models, we see no sign of overfitting when training with the full 22B token WebText2 dataset, so we can take it as representative of $D=\infty$. Thus we can compare finite $D$ to the infinite data limit by defining

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\delta L(N,D)\equiv\frac{L(N,D)}{L(N,\infty)}-1$ |  | (4.2) |

and studying it as a function of $N,D$. In fact, we see empirically that $\delta L$ depends only a specific combination of $N$ and $D$, as shown in Figure [16](#A4.F16 "Figure 16 ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models"). This follows from the scaling law of Equation ([1.5](#S1.E5 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")), which implies

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\delta L\approx\left(1+\left(\frac{N}{N\_{c}}\right)^{\frac{\alpha\_{N}}{\alpha\_{D}}}\frac{D\_{c}}{D}\right)^{\alpha\_{D}}-1$ |  | (4.3) |

Note that at large $D$ this formula also has a series expansion in powers of $1/D$.

We estimate that the variation in the loss with different random seeds is roughly $0.02$, which means that to avoid overfitting when training to within that threshold of convergence we require

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D\gtrsim(5\times 10^{3})\,N^{0.74}$ |  | (4.4) |

With this relation, models smaller than $10^{9}$ parameters can be trained with minimal overfitting on the 22B token WebText2 dataset, but our largest models will encounter some mild overfitting. More generally, this relation shows that dataset size may grow sub-linearly in model size while avoiding overfitting. Note however that this does not typically represent maximally compute-efficient training. We should also emphasize that we have not optimized regularization (eg the dropout probability) while varying dataset and model size.

## 5 Scaling Laws with Model Size and Training Time

In this section we will demonstrate that a simple scaling law provides a good description for the loss as a function of model size $N$ and training time. First we will explain how to use the results of [[MKAT18](#bib.bibx28)] to define a universal training step $S\_{\rm min}$, which accounts for the fact that most of our models have not been trained at an optimal batch size. Then we will demonstrate that we can fit the model size and training time dependence of the loss using Equation ([1.6](#S1.E6 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")). Later we will use these results to predict the optimal allocation of training compute between model size and training time, and then confirm that prediction.

### 5.1 Adjustment for Training at $B\_{\rm crit}(L)$

Figure 10: The critical batch size $B\_{\rm crit}$ follows a power law in the loss as performance increase, and does not depend directly on the model size. We find that the critical batch size approximately doubles for every $13\%$ decrease in loss. $B\_{\rm crit}$ is measured empirically from the data shown in Figure [18](#A4.F18 "Figure 18 ‣ D.3 Batch Size ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models"), but it is also roughly predicted by the gradient noise scale, as in [[MKAT18](#bib.bibx28)].

A simple empirical theory for the batch size dependence of training was developed in [[MKAT18](#bib.bibx28)] (see also [[SLA+18](#bib.bibx37), [ZLN+19](#bib.bibx50)]). It was argued that there is a critical batch size $B\_{\rm crit}$ for training; for $B$ up to $B\_{\rm crit}$ the batch size can be increased with very minimal degradation in compute-efficiency, whereas for $B>B\_{\rm crit}$ increases in $B$ result in diminishing returns. It was also argued that the gradient noise scale provides a simple prediction for $B\_{\rm crit}$, and that neither depends directly on model size except through the value of the loss that has been attained. These results can be used to predict how training time and compute will vary with the batch size. To utilize both training time and compute as effectively as possible, it is best to train with a batch size $B\approx B\_{\rm crit}$. Training at $B\gg B\_{\rm crit}$ minimizes the number of training steps, while $B\ll B\_{\rm crit}$ minimizes the use of compute.

More specifically, it was demonstrated that for a wide variety of neural network tasks, the number of training steps $S$ and the number of data examples processed $E=BS$ satisfy the simple relation

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left(\frac{S}{S\_{\rm min}}-1\right)\left(\frac{E}{E\_{\rm min}}-1\right)=1$ |  | (5.1) |

when training to any fixed value of the loss $L$. Here $S\_{\rm min}$ is the minimum number of steps necessary to reach $L$, while $E\_{\rm min}$ is the minimum number of data examples that must be processed.

We demonstrate the relation ([5.1](#S5.E1 "In 5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models")) for Transformers in Figure [18](#A4.F18 "Figure 18 ‣ D.3 Batch Size ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models") in the appendix. This relation defines the critical batch size

|  |  |  |  |
| --- | --- | --- | --- |
|  | $B\_{\rm crit}(L)\equiv\frac{E\_{\rm min}}{S\_{\rm min}}$ |  | (5.2) |

which is a function of the target value of the loss. Training at the critical batch size makes a roughly optimal time/compute tradeoff, requiring $2S\_{\rm min}$ training steps and processing $E=2E\_{\rm min}$ data examples.

In Figure [10](#S5.F10 "Figure 10 ‣ 5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models") we have plotted the critical batch size and gradient noise scale44
4
Although the critical batch size roughly matches the gradient noise scale, we are using a direct measurements of $B\_{\rm crit}$ from Figures [18](#A4.F18 "Figure 18 ‣ D.3 Batch Size ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models") and [10](#S5.F10 "Figure 10 ‣ 5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models") for all our later analyses.  as a function of training loss for two different models. We see that $B\_{\rm crit}(L)$ is independent of model size, and only depends on the loss $L$. So the predictions of [[MKAT18](#bib.bibx28)] continue to hold for Transformer language models. The critical batch size can be fit with a power-law in the loss

|  |  |  |  |
| --- | --- | --- | --- |
|  | $B\_{\rm crit}(L)\approx\frac{B\_{\*}}{L^{1/\alpha\_{B}}}$ |  | (5.3) |

where $B\_{\*}\approx 2\times 10^{8}$ and $\alpha\_{B}\approx 0.21$.

We have chosen this parameterization for $B\_{\rm crit}(L)$ because as the loss approaches its minimum value $L\_{\rm min}$, the gradient noise scale is expected to diverge, and we expect $B\_{\rm crit}$ to track this noise scale. We do not know $L\_{\rm min}$, as we see no sign that our models are approaching it, but $L\_{\rm min}>0$ since the entropy of natural language is non-zero. Since apparently $L\_{\rm min}$ is much smaller than the values of $L$ we have achieved, we used a parameterization where $B\_{\rm crit}$ diverges as $L\to 0$.

We will use $B\_{\rm crit}(L)$ to estimate the relation between the number of training steps $S$ while training at batch size $B=2^{19}$ tokens and the number of training steps while training at $B\gg B\_{\rm crit}$. This is simply

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S\_{\rm min}(S)\equiv\frac{S}{1+B\_{\rm crit}(L)/B}\qquad(\text{minimum steps, at }B\gg B\_{\rm crit})$ |  | (5.4) |

for any given target value $L$ for the loss. This also defines a critical value of the compute needed to train to $L$ with a model of size $N$ if we were to train at $B\ll B\_{\rm crit}(L)$. This is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{\rm min}(C)\equiv\frac{C}{1+B/B\_{\rm crit}(L)}\qquad(\text{minimum compute, at }B\ll B\_{\rm crit})$ |  | (5.5) |

where $C=6NBS$ estimates the (non-embedding) compute used at batch size $B$.

### 5.2 Results for $L(N,S\_{\rm min})$ and Performance with Model Size and Compute

Figure 11: 
When we hold either total compute or number of training steps fixed, performance follows $L(N,S)$ from Equation ([5.6](#S5.E6 "In 5.2 Results for 𝐿(𝑁,𝑆_min) and Performance with Model Size and Compute ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models")). Each value of compute budget has an associated optimal model size that maximizes performance. Mediocre fits at small $S$ are unsurprising, as the power-law equation for the learning curves breaks down very early in training.

Now we will use $S\_{\rm min}$ defined in Equation ([5.4](#S5.E4 "In 5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models")) to obtain a simple and universal fit for the dependence of the loss on model size and training time in the infinite data limit. We will fit the stable, Adam-optimized training runs using Equation ([1.6](#S1.E6 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")), repeated here for convenience:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L(N,S\_{\rm min})=\left(\frac{N\_{c}}{N}\right)^{\alpha\_{N}}+\left(\frac{S\_{c}}{S\_{\rm min}}\right)^{\alpha\_{S}}$ |  | (5.6) |

for the loss. We include all training steps after the warmup period of the learning rate schedule, and find a fit to the data with the parameters:

| Parameter | $\alpha\_{N}$ | $\alpha\_{S}$ | $N\_{c}$ | $S\_{c}$ |
| --- | --- | --- | --- | --- |
| Value | $0.077$ | $0.76$ | $6.5\times 10^{13}$ | $2.1\times 10^{3}$ |

Table 3: Fits to $L(N,S)$

With these parameters, we obtain the learning curve fits in Figure [4](#S1.F4 "Figure 4 ‣ 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models"). Though the fits are imperfect, we believe they are quite compelling given the simplicity of Equation ([5.6](#S5.E6 "In 5.2 Results for 𝐿(𝑁,𝑆_min) and Performance with Model Size and Compute ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models")).

The data and fits can be visualized in a different and more interesting way, as shown in Figure [11](#S5.F11 "Figure 11 ‣ 5.2 Results for 𝐿(𝑁,𝑆_min) and Performance with Model Size and Compute ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models"). There we study the test loss as a function of model size while fixing either the total non-embedding compute $C$ used in training, or the number of steps $S$. For the fits we use Equation ([5.5](#S5.E5 "In 5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models")) and ([5.4](#S5.E4 "In 5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models")) along with the parameters above and Equation ([5.6](#S5.E6 "In 5.2 Results for 𝐿(𝑁,𝑆_min) and Performance with Model Size and Compute ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models")).

The power-law dependence of the loss on $S\_{\rm min}$ reflects the interplay of optimizer dynamics and the loss landscape. Since the fits are best late in training, when the loss may be approximately quadratic, the power-law should provide information about the spectrum of the Hessian of the loss. Its universality suggests that the Hessian eigenvalue density is roughly independent of model size.

### 5.3 Lower Bound on Early Stopping Step

The results for $L(N,S\_{\rm min})$ can be used to derive a lower-bound (and rough estimate) of the step at which early stopping should occur when training is data limited.
It is motivated by the idea that finite and infinite $D$ learning curves for a given model will be very similar until we reach $S\_{\rm min}\approx S\_{\rm stop}$. Thus overfitting should be proportional to the correction from simply ending training at $S\_{\rm stop}$. This will underestimate $S\_{\rm stop}$, because in reality the test loss will decrease more slowly when we have a finite $D$, and therefore we will require more training steps to reach the optimal test loss at finite $D$.
This line of reasoning leads to the inequality

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S\_{\rm stop}(N,D)\gtrsim\frac{S\_{c}}{\left[L(N,D)-L(N,\infty)\right]^{1/\alpha\_{S}}}$ |  | (5.7) |

where $L(N,\infty)$ is the converged loss, evaluated with infinite available data. This inequality and its comparison to the empirical data is displayed in Figure [16](#A4.F16 "Figure 16 ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models") in the appendix. In that figure, the values of $S\_{\rm stop}$ and $L(N,D)$ are empirical (though $S\_{\rm stop}$ is adjusted to mimic training at $B\gg B\_{\rm crit}$), while $L(N,\infty)$ is computed from the fit to $L(N,D)$ evaluated at $D=\infty$.

Figure 12: Left: Given a fixed compute budget, a particular model size is optimal, though somewhat larger or smaller models can be trained with minimal additional compute. Right: Models larger than the compute-efficient size require fewer steps to train, allowing for potentially faster training if sufficient additional parallelism is possible. Note that this equation should not be trusted for very large models, as it is only valid in the power-law region of the learning curve, after initial transient effects.

## 6 Optimal Allocation of the Compute Budget

We displayed the *empirical* trend of performance as a function of the computation used during training in the top-right of Figure [1](#footnote1 "footnote 1 ‣ Figure 1 ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models"). However, this result involved training at a fixed batch size $B$, whereas we know that in fact we could train more efficiently55
5
One might ask why we did not simply train at $B\_{\rm crit}$ in the first place. The reason is that it depends not only on the model but also on the target value of the loss we wish to achieve, and so is a moving target. by training at the batch size $B\_{\rm crit}$ discussed in Section [5.1](#S5.SS1 "5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models"). Large and small values of the loss could have been achieved with fewer samples or fewer steps, respectively, and correcting for this inefficiency by standardizing to the critical batch size results in cleaner and more predictable trends.

Figure 13: 
When adjusting performance to simulate training far below the critical batch size, we find a somewhat altered power law for $L(C\_{\rm min})$ when compared with the fully empirical results. The conspicuous lump at $10^{-5}$ PF-days marks the transition from 1-layer to 2-layer networks; we exclude 1-layer networks in the power-law fits. It is the $L(C\_{\rm min})$ trend that we expect to provide a reliable extrapolation for larger compute.

In this section we will adjust for this oversight. More importantly, we will use the results of Section [5](#S5 "5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models") to determine the optimal *allocation* of compute between model size $N$ and the quantity of data processed during training, namely $2B\_{\rm crit}S\_{\rm min}$. We will determine this allocation both empirically and theoretically, by using the equation for $L(N,S\_{\rm min})$, and we will demonstrate that these methods agree.

### 6.1 Optimal Performance and Allocations

Let us first study the loss as a function of the optimally allocated compute from Equation ([5.5](#S5.E5 "In 5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models")). The result is plotted in Figure [13](#S6.F13 "Figure 13 ‣ 6 Optimal Allocation of the Compute Budget ‣ Scaling Laws for Neural Language Models"), along with a power-law fit. We see that as compared to the compute plot of Figure [1](#footnote1 "footnote 1 ‣ Figure 1 ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models"), the new fit with $C\_{\rm min}$ is somewhat improved.

Given $L(C\_{\rm min})$, it is natural to ask for the optimal model size $N(C\_{\rm min})$ that provides the minimal loss with a given quantity of training compute. The optimal model size is shown in Figure [14](#S6.F14 "Figure 14 ‣ 6.1 Optimal Performance and Allocations ‣ 6 Optimal Allocation of the Compute Budget ‣ Scaling Laws for Neural Language Models"). We observe that $N(C\_{\rm min})$ can be fit very well with a power-law

|  |  |  |  |
| --- | --- | --- | --- |
|  | $N(C\_{\rm min})\propto(C\_{\rm min})^{0.73}.$ |  | (6.1) |

In Figure [12](#S5.F12 "Figure 12 ‣ 5.3 Lower Bound on Early Stopping Step ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models"), we show the effect of training models of sub-optimal sizes (see Appendix [B.4](#A2.SS4 "B.4 Suboptimal Model Sizes ‣ Appendix B Empirical Model of Compute-Efficient Frontier ‣ Scaling Laws for Neural Language Models")).

By definition $C\_{\rm min}\equiv 6NB\_{\rm crit}S$, and so we can use $N(C\_{\rm min})$ to extract further results. In particular, since prior fits show $B\propto L^{-4.8}$ and $L\propto C\_{\rm min}^{-0.05}$, we can conclude that $B\_{\rm crit}\propto C\_{\rm min}^{0.24}$. This leads us to conclude that the optimal number of steps will only grow very slowly with compute, as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S\_{\rm min}\propto(C\_{\rm min})^{0.03},$ |  | (6.2) |

matching the empirical results in Figure [14](#S6.F14 "Figure 14 ‣ 6.1 Optimal Performance and Allocations ‣ 6 Optimal Allocation of the Compute Budget ‣ Scaling Laws for Neural Language Models"). In fact the measured exponent is sufficiently small that our results may even be consistent with an exponent of zero.

Thus we conclude that as we scale up language modeling with an optimal allocation of computation, we should predominantly increase the model size $N$, while simultaneously scaling up the batch size via $B\propto B\_{\rm crit}$ with negligible increase in the number of serial steps. Since compute-efficient training uses relatively few optimization steps, additional work on speeding up early training dynamics may be warranted.

Figure 14: 
Left: Each value of the compute budget $C\_{\rm min}$ has an associated optimal model size $N$. Optimal model size grows very rapidly with $C\_{\rm min}$, increasing by 5x for each 10x increase in compute. The number of data examples processed makes up the remainder of the increase, growing relatively modestly by only 2x.
Right: The batch-adjusted number of optimization steps also grows very slowly, if at all, meaning that most of the growth in data examples processed can be used for increased batch sizes.

### 6.2 Predictions from $L(N,S\_{\rm min})$

The results for $L(C\_{\rm min})$ and the allocations can be predicted from the $L(N,S\_{\rm min})$ equation obtained in Section [5](#S5 "5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models"). Given our equation for $L(N,S\_{\rm min})$, we can substitute $S\_{\rm min}=\frac{C\_{\rm min}}{6NB}$ and then find the minimum of the loss as a function of $N$, while fixing the training compute.
We carry out this procedure in detail in Appendix [B](#A2 "Appendix B Empirical Model of Compute-Efficient Frontier ‣ Scaling Laws for Neural Language Models"), where we also provide some additional predictions.

For the loss as a function of training compute, we predict that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L(C\_{\rm min})=\left(\frac{C\_{c}^{\rm min}}{C\_{\rm min}}\right)^{\alpha\_{C}^{\rm min}}$ |  | (6.3) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\alpha\_{C}^{\rm min}\equiv\frac{1}{1/\alpha\_{S}+1/\alpha\_{B}+1/\alpha\_{N}}\approx 0.054$ |  | (6.4) |

in excellent agreement with the exponent of Figure [13](#S6.F13 "Figure 13 ‣ 6 Optimal Allocation of the Compute Budget ‣ Scaling Laws for Neural Language Models"). We also predict that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $N(C\_{\rm min})\propto(C\_{\rm min})^{\alpha\_{C}^{\rm min}/\alpha\_{N}}\approx(C\_{\rm min})^{0.71}$ |  | (6.5) |

which also matches the scaling of Figure [14](#S6.F14 "Figure 14 ‣ 6.1 Optimal Performance and Allocations ‣ 6 Optimal Allocation of the Compute Budget ‣ Scaling Laws for Neural Language Models") to within a few percent. Our scaling laws provide a predictive framework for the performance of language modeling.

### 6.3 Contradictions and a Conjecture

Figure 15: Far beyond the model sizes we study empirically, we find a contradiction between our equations for $L(C\_{\rm min})$ and $L(D)$ due to the slow growth of data needed for compute-efficient training. The intersection marks the point before which we expect our predictions to break down. The location of this point is highly sensitive to the precise exponents from our power-law fits.

We observe no signs of deviation from straight power-law trends at large values of compute, data, or model size. Our trends must eventually level off, though, since natural language has non-zero entropy.

Indeed, the trends for compute-efficient training described in this section already contain an apparent contradiction. At scales several orders of magnitude above those documented here, the performance predicted by the $L(C\_{\rm min})$ scaling law decreases below what should be possible given the slow growth in training data with compute. This implies that our scaling laws must break down before this point, but we conjecture that the intersection point has a deeper meaning: it provides an estimate of the point at which Transformer language models reach maximal performance.

Since the amount of data used by compute-efficient training grows slowly with the compute budget, the performance predicted by $L(C\_{\rm min})$ eventually hits a lower bound set by the $L(D)$ power law (see Figure [15](#S6.F15 "Figure 15 ‣ 6.3 Contradictions and a Conjecture ‣ 6 Optimal Allocation of the Compute Budget ‣ Scaling Laws for Neural Language Models")). Let us work this out in more detail.

To keep overfitting under control, the results of Section [4](#S4 "4 Charting the Infinite Data Limit and Overfitting ‣ Scaling Laws for Neural Language Models") imply that we should scale the dataset size as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D\propto N^{0.74}\propto C\_{\rm min}^{0.54}$ |  | (6.6) |

where we have used the compute-efficient $N(C\_{\rm min})$ from Figure [14](#S6.F14 "Figure 14 ‣ 6.1 Optimal Performance and Allocations ‣ 6 Optimal Allocation of the Compute Budget ‣ Scaling Laws for Neural Language Models").

Let us compare this to the data requirements of compute-efficient training. If we train at the critical batch size (i.e. $C=2C\_{\rm min}$) and never re-use data during training, we find that data usage grows with compute as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D(C\_{\rm min})=\frac{2C\_{\rm min}}{6N(C\_{\rm min})}\approx\left(4\times 10^{10}\ {\rm tokens}\right)(C\_{\rm min}/\mathrm{PF}{\text{-}}\mathrm{Day})^{0.26}$ |  | (6.7) |

This is the maximum rate at which the dataset size can productively grow with compute, since it means that we are only training for a single epoch. But it grows the dataset much more slowly than in Equation ([6.6](#S6.E6 "In 6.3 Contradictions and a Conjecture ‣ 6 Optimal Allocation of the Compute Budget ‣ Scaling Laws for Neural Language Models")). It appears to imply that compute-efficient training will eventually run into a problem with overfitting, even if the training process never re-uses any data!

According to Figure [1](#footnote1 "footnote 1 ‣ Figure 1 ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models"), we expect that when we are bottlenecked by the dataset size (ie by overfitting), the loss should scale as $L(D)\propto D^{-0.095}$. This implies that the loss would scale with compute as $L(D(C\_{\rm min}))\propto C\_{\rm min}^{-0.03}$ once we are data-limited. Once again, we have a contradiction, as this will eventually intersect with our prediction for $L(C\_{\rm min})$ from Figure [13](#S6.F13 "Figure 13 ‣ 6 Optimal Allocation of the Compute Budget ‣ Scaling Laws for Neural Language Models"), where we found a scaling $L(C\_{\rm min})\propto C\_{\rm min}^{-0.050}$.

The intersection point of $L(D(C\_{\rm min}))$ and $L(C\_{\rm min})$ occurs at

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C^{\*}\sim 10^{4}\penalty\ \mathrm{PF}{\text{-}}\mathrm{Days}\quad N^{\*}\sim 10^{12}\penalty\ \text{parameters},\quad D^{\*}\sim 10^{12}\penalty\ \text{tokens},\quad L^{\*}\sim 1.7\penalty\ \text{nats/token}$ |  | (6.8) |

though the numerical values are highly uncertain, varying by an order or magnitude in either direction depending on the precise values of the exponents from the power-law fits. The most obvious interpretation is that our scaling laws break down at or before we reach this point, which is still many orders of magnitude away in both compute and model size.

One might also conjecture that this intersection point has a deeper meaning. If we cannot increase the model size beyond $N^{\*}$ without qualitatively different data requirements, perhaps this means that once we reach $C\_{\rm min}^{\*}$ and $N^{\*}$, we have extracted all of the reliable information available in natural language data. In this interpretation, $L^{\*}$ would provide a rough estimate for the entropy-per-token66
6
Defining words using the wc utility, the WebText2 dataset has $1.4$ tokens per word and $4.3$ characters per token.  of natural language. In this scenario, we would expect the loss trend to level off at or before $L^{\*}$.

We can guess at the functional form of $L(C\_{\rm min})$ as it levels off by considering a version of our training dataset with added noise. For example, we could append a random string of tokens to each context shown to the model to artificially boost the loss by a constant additive factor. Then, the distance from the noise floor $L-L\_{\rm noise}$ would be a more meaningful performance metric, with even a small decrease in this distance potentially representing a significant boost in qualitative performance. Since the artificial noise would affect all of our trends equally, the critical point of [6.8](#S6.E8 "In 6.3 Contradictions and a Conjecture ‣ 6 Optimal Allocation of the Compute Budget ‣ Scaling Laws for Neural Language Models") would not change (aside from the absolute value of $L^{\*}$), and may be meaningful even if it occurs after the leveling off.

## 7 Related Work

Power laws can arise from a wide variety of sources [[THK18](#bib.bibx39)]. Power-law scalings with model and dataset size in density estimation [[Was06](#bib.bibx43)] and in random forest models [[Bia12](#bib.bibx5)] may be connected with our results. These models suggest that power-law exponents may have a very rough interpretation as the inverse of the number of relevant features in the data.

Some early [[BB01](#bib.bibx3), [Goo01](#bib.bibx14)] work found power-law scalings between performance and dataset size. More recent work [[HNA+17](#bib.bibx18), [HAD19](#bib.bibx16)] also investigated scaling between model size and data size; their work is perhaps the closest to ours in the literature77
7
After this work was completed, [[RRBS19a](#bib.bibx31)] also appeared, which makes similar predictions for the dependence of loss on both model and dataset size.. Note, however, that [[HNA+17](#bib.bibx18)] found super-linear scaling of dataset size with model size, whereas we find a sub-linear scaling. There are some parallels between our findings on optimal allocation of compute and [[Kom19](#bib.bibx21)], including power-law learning curves. EfficientNets [[TL19](#bib.bibx40)] also appear to obey an approximate power-law relation between accuracy and model size. Very recent work [[RRBS19b](#bib.bibx32)] studies scaling with both dataset size and model size for a variety of datasets, and fits an ansatz similar to ours.

EfficientNet [[TL19](#bib.bibx40)] advocates scaling depth and width exponentially (with different coefficients) for optimal performance of image models, resulting in a power-law scaling of width as a function of depth. We find that for language models this power should be roughly one when scaling up (as width/depth should remain fixed). But more importantly, we find that the precise architectural hyperparameters are unimportant compared to the overall scale of the language model. In [[VWB16](#bib.bibx42)] it was argued that deep models can function as ensembles of shallower models, which could potentially explain this finding. Earlier work [[ZK16](#bib.bibx48)] has compared width and depth, and found that wide ResNets can outperform deep ResNets on image classification.
Some studies fix computation per data example, which tends to scale in proportion to the number of model parameters, whereas we investigate scaling with both model size and the quantity of training computation.

Various works [[AS17](#bib.bibx2), [BHMM18](#bib.bibx4)] have investigated generalization in highly overparameterized models, finding a “jamming transition” [[GJS+19](#bib.bibx12)] when the model size reaches the dataset size (this may require training many orders of magnitude beyond typical practice, and in particular does not use early stopping). We do not observe such a transition, and find that the necessary training data scales sublinearly in the model size.
Expansions in the model size, particularly at large width [[JGH18](#bib.bibx19), [LXS+19](#bib.bibx27)], may provide a useful framework for thinking about some of our scaling relations. Our results on optimization, such as the shape of learning curves, can likely be explained using a noisy quadratic model, which can provide quite accurate predictions [[ZLN+19](#bib.bibx50)] in realistic settings. Making this connection quantitative will require a characterization of the Hessian spectrum [[Pap18](#bib.bibx29), [GKX19](#bib.bibx13), [GARD18](#bib.bibx11)].

## 8 Discussion

We have observed consistent scalings of language model log-likelihood loss with non-embedding parameter count $N$, dataset size $D$, and optimized training computation $C\_{\rm min}$, as encapsulated in Equations ([1.5](#S1.E5 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")) and ([1.6](#S1.E6 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")). Conversely, we find very weak dependence on many architectural and optimization hyperparameters. Since scalings with $N,D,C\_{\rm min}$ are power-laws, there are diminishing returns with increasing scale.

We were able to precisely model the dependence of the loss on $N$ and $D$, and alternatively on $N$ and $S$, when these parameters are varied simultaneously. We used these relations to derive the compute scaling, magnitude of overfitting, early stopping step, and data requirements when training large language models. So our scaling relations go beyond mere observation to provide a predictive framework. One might interpret these relations as analogues of the ideal gas law, which relates the macroscopic properties of a gas in a universal way, independent of most of the details of its microscopic consituents.

It is natural to conjecture that the scaling relations will apply to other generative modeling tasks with a maximum likelihood loss, and perhaps in other settings as well. To this purpose, it will be interesting to test these relations on other domains, such as images, audio, and video models, and perhaps also for random network distillation. At this point we do not know which of our results depend on the structure of natural language data, and which are universal. It would also be exciting to find a theoretical framework from which the scaling relations can be derived: a ‘statistical mechanics’ underlying the ‘thermodynamics’ we have observed. Such a theory might make it possible to derive other more precise predictions, and provide a systematic understanding of the limitations of the scaling laws.

In the domain of natural language, it will be important to investigate whether continued improvement on the loss translates into improvement on relevant language tasks. Smooth quantitative change can mask major qualitative improvements: “more is different”. For example, the smooth aggregate growth of the economy provides no indication of the specific technological developments that underwrite it. Similarly, the smooth improvements in language model loss may hide seemingly qualitative changes in capability.

Our results strongly suggest that larger models will continue to perform better, and will also be much more sample efficient than has been previously appreciated. Big models may be more important than big data. In this context, further investigation into model parallelism is warranted. Deep models can be trained using pipelining [[HCC+18](#bib.bibx17)], which splits parameters depth-wise between devices, but eventually requires increased batch sizes as more devices are used. Wide networks on the other hand are more amenable to parallelization [[SCP+18](#bib.bibx35)], since large layers can be split between multiple workers with less serial dependency. Sparsity [[CGRS19](#bib.bibx6), [GRK17](#bib.bibx15)] or branching (e.g. [[KSH12](#bib.bibx22)]) may allow for even faster training of large networks through increased model parallelism. And using methods like [[WRH17](#bib.bibx45), [WYL19](#bib.bibx46)], which grow networks as they train, it might be possible to remain on the compute-efficient frontier for an entire training run.

## Acknowledgements

We would like to thank Shan Carter, Paul Christiano, Jack Clark, Ajeya Cotra, Ethan Dyer, Jason Eisner, Danny Hernandez, Jacob Hilton, Brice Menard, Chris Olah, and Ilya Sutskever for discussions and for feedback on drafts of this work.

## Appendix A Summary of Power Laws

For easier reference, we provide a summary below of the key trends described throughout the paper.

| Parameters | Data | Compute | Batch Size | Equation |
| --- | --- | --- | --- | --- |
| $N$ | $\infty$ | $\infty$ | Fixed | $L\left(N\right)=\left(N\_{{\rm c}}/N\right)^{\alpha\_{N}}$ |
| $\infty$ | $D$ | Early Stop | Fixed | $L\left(D\right)=\left(D\_{{\rm c}}/D\right)^{\alpha\_{D}}$ |
| Optimal | $\infty$ | $C$ | Fixed | $L\left(C\right)=\left(C\_{{\rm c}}/C\right)^{\alpha\_{C}}$ (naive) |
| $N\_{{\rm opt}}$ | $D\_{{\rm opt}}$ | $C\_{{\rm min}}$ | $B\ll B\_{{\rm crit}}$ | $L\left(C\_{{\rm min}}\right)=\left(C\_{{\rm c}}^{{\rm min}}/C\_{{\rm min}}\right)^{\alpha\_{C}^{{\rm min}}}$ |
| $N$ | $D$ | Early Stop | Fixed | $L\left(N,D\right)=\left[\left(\frac{N\_{{\rm c}}}{N}\right)^{\frac{\alpha\_{N}}{\alpha\_{D}}}+\frac{D\_{c}}{D}\right]^{\alpha\_{D}}$ |
| $N$ | $\infty$ | $S$ steps | $B$ | $L\left(N,S\right)=\left(\frac{N\_{{\rm c}}}{N}\right)^{\alpha\_{N}}+\left(\frac{S\_{{\rm c}}}{S\_{{\rm min}}\left(S,B\right)}\right)^{\alpha\_{S}}$ |

Table 4:

The empirical fitted values for these trends are:

| Power Law | Scale (tokenization-dependent) |
| --- | --- |
| $\alpha\_{N}=0.076$ | $N\_{{\rm c}}=8.8\times 10^{13}$ params (non-embed) |
| $\alpha\_{D}=0.095$ | $D\_{{\rm c}}=5.4\times 10^{13}$ tokens |
| $\alpha\_{C}=0.057$ | $C\_{{\rm c}}=1.6\times 10^{7}$ PF-days |
| $\alpha\_{C}^{{\rm min}}=0.050$ | $C\_{{\rm c}}^{{\rm min}}=3.1\times 10^{8}$ PF-days |
| $\alpha\_{B}=0.21$ | $B\_{\ast}=2.1\times 10^{8}$ tokens |
| $\alpha\_{S}=0.76$ | $S\_{{\rm c}}=2.1\times 10^{3}$ steps |

Table 5:

The optimal parameters for compute efficient training are given by:

| Compute-Efficient Value | Power Law | Scale |
| --- | --- | --- |
| $N\_{{\rm opt}}=N\_{e}\cdot C\_{{\rm min}}^{p\_{N}}$ | $p\_{N}=0.73$ | $N\_{e}=1.3\cdot 10^{9}$ params |
| $B\ll B\_{{\rm crit}}=\frac{B\_{\ast}}{L^{1/\alpha\_{B}}}=B\_{e}C\_{{\rm min}}^{p\_{B}}$ | $p\_{B}=0.24$ | $B\_{e}=2.0\cdot 10^{6}$ tokens |
| $S\_{{\rm min}}=S\_{e}\cdot C\_{{\rm min}}^{p\_{S}}$ (lower bound) | $p\_{S}=0.03$ | $S\_{e}=5.4\cdot 10^{3}$ steps |
| $D\_{{\rm opt}}=D\_{e}\cdot C\_{{\rm min}}^{p\_{D}}$ (1 epoch) | $p\_{D}=0.27$ | $D\_{e}=2\cdot 10^{10}$ tokens |

Table 6:

## Appendix B Empirical Model of Compute-Efficient Frontier

Throughout this appendix all values of $C,S,$ and $\alpha\_{C}$ are adjusted for training at the critical batch size $B\_{\rm crit}$. We have left off the ‘adj’ label to avoid cluttering the notation.

### B.1 Defining Equations

The power-law fit to the learning curves implies a simple prescription for compute-efficient training.
In this appendix, we will derive the optimal performance, model size, and number of training steps as a function of the compute budget.
We start with the Equation ([1.6](#S1.E6 "In 1.2 Summary of Scaling Laws ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models")), repeated here for convenience:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L\left(N,S\right)=\left(\frac{N\_{c}}{N}\right)^{\alpha\_{N}}+\left(\frac{S\_{c}}{S}\right)^{\alpha\_{S}}.$ |  | (B.1) |

Here, $S$ represents the number of parameter updates when training at the critical batch size [[MKAT18](#bib.bibx28)], which was defined in Equation ([5.2](#S5.E2 "In 5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models"))88
8
There is a slight ambiguity here: we can imagine training either at a constant batch size $B\left(L\_{{\rm target}}\right)$, or we could instead train at a variable batch size $\tilde{B}\left(L\right)$, where $\tilde{B}$ is the instantaneous critical batch size (as opposed to $B$, which is the averaged version). These two prescriptions result in the same number of steps, so we can ignore this subtlety (see [[MKAT18](#bib.bibx28)]).:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $B\left(L\right)=\frac{B\_{\ast}}{L^{1/\alpha\_{B}}}.$ |  | (B.2) |

We would like to determine optimal training parameters for a fixed compute budget, so we replace $S=C/\left(6NB\left(L\right)\right)$, where $C$ is the number of FLOPs used in the training run:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L\left(N,C\right)=\left(\frac{N\_{c}}{N}\right)^{\alpha\_{N}}+\left(6B\_{\ast}S\_{c}\frac{N}{L^{1/\alpha\_{B}}C}\right)^{\alpha\_{S}}.$ |  | (B.3) |

Now, we set $\partial\_{N}L\big|\_{C}=0$ to find the condition for optimality:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle 0$ | $\displaystyle=\frac{\partial L}{\partial N}\big|\_{C}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=-\frac{\alpha\_{N}}{N}\left(\frac{N\_{c}}{N}\right)^{\alpha\_{N}}+\frac{\alpha\_{S}}{N}\left(6B\_{\ast}S\_{c}\frac{N}{L^{1/\alpha\_{B}}C}\right)^{\alpha\_{S}}\left(1-5\frac{N}{L}\cancel{\frac{\partial L}{\partial N}\big|\_{C}}\right)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\implies\frac{\alpha\_{N}}{\alpha\_{S}}\left(\frac{N\_{c}}{N}\right)^{\alpha\_{N}}$ | $\displaystyle=\left(6B\_{\ast}S\_{c}\frac{N}{L^{1/\alpha\_{B}}C}\right)^{\alpha\_{S}}$ |  | (B.4) |

Equation ([B.3](#A2.E3 "In B.1 Defining Equations ‣ Appendix B Empirical Model of Compute-Efficient Frontier ‣ Scaling Laws for Neural Language Models")) and ([B.4](#A2.E4 "In B.1 Defining Equations ‣ Appendix B Empirical Model of Compute-Efficient Frontier ‣ Scaling Laws for Neural Language Models")) together determine the compute-efficient frontier.

### B.2 Efficient Training

Now we assemble the implications of ([B.3](#A2.E3 "In B.1 Defining Equations ‣ Appendix B Empirical Model of Compute-Efficient Frontier ‣ Scaling Laws for Neural Language Models")) and ([B.4](#A2.E4 "In B.1 Defining Equations ‣ Appendix B Empirical Model of Compute-Efficient Frontier ‣ Scaling Laws for Neural Language Models")).
First, note that inserting ([B.4](#A2.E4 "In B.1 Defining Equations ‣ Appendix B Empirical Model of Compute-Efficient Frontier ‣ Scaling Laws for Neural Language Models")) into ([B.3](#A2.E3 "In B.1 Defining Equations ‣ Appendix B Empirical Model of Compute-Efficient Frontier ‣ Scaling Laws for Neural Language Models")) yields

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L\left(N\_{{\rm eff}}\left(C\right),C\right)=\left(1+\frac{\alpha\_{N}}{\alpha\_{S}}\right)L\left(N\_{{\rm eff}},\infty\right),$ |  | (B.5) |

which implies that for compute-efficient training, we should train to a fixed percentage $\frac{\alpha\_{N}}{\alpha\_{S}}\approx 10\%$ above the converged loss.
Next, let’s determine how the optimal loss depends on the compute budget. Eliminating $N$ yields a power-law dependence of performance on compute:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle L\left(C\right)$ | $\displaystyle=\left(\frac{C\_{c}}{C}\right)^{\alpha\_{C}}$ |  | (B.6) |

where we defined

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\alpha\_{C}$ | $\displaystyle=1/\left(1/\alpha\_{S}+1/\alpha\_{B}+1/\alpha\_{N}\right)\approx 0.052$ |  | (B.7) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle C\_{c}$ | $\displaystyle=6N\_{c}B\_{\ast}S\_{c}\left(1+\frac{\alpha\_{N}}{\alpha\_{S}}\right)^{1/\alpha\_{S}+1/\alpha\_{N}}\left(\frac{\alpha\_{S}}{\alpha\_{N}}\right)^{1/\alpha\_{S}}.$ |  | (B.8) |

Similarly, we can eliminate $L$ to find $N\left(C\right)$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\frac{N\left(C\right)}{N\_{c}}=\left(\frac{C}{C\_{c}}\right)^{\alpha\_{C}/\alpha\_{N}}\left(1+\frac{\alpha\_{N}}{\alpha\_{S}}\right)^{1/\alpha\_{N}}$ |  | (B.9) |

and

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle S\left(C\right)$ | $\displaystyle=\frac{C\_{c}}{6N\_{c}B\_{\ast}}\left(1+\frac{\alpha\_{N}}{\alpha\_{S}}\right)^{-1/\alpha\_{N}}\left(\frac{C}{C\_{c}}\right)^{\alpha\_{C}/\alpha\_{S}}$ |  | (B.10) |

### B.3 Comparison to Inefficient

Typically, researchers train models until they appear to be close to convergence. In this section, we compare the efficient training procedure described above to this more typical setup.
We define a the convergence factor $f$ as the percent deviation from the converged loss:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L\left(N,C\right)=\left(1+f\right)L\left(N,\infty\right).$ |  | (B.11) |

For compute-efficient training we have $f=\alpha\_{N}/\alpha\_{S}\approx 10\%$ from the previous section, but researchers typically use a much smaller value. Here, we choose $f^{\prime}=2\%$ as an estimate.
For a fixed value of the loss, we predict:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{N\_{f}}{N\_{f^{\prime}}}$ | $\displaystyle=\left(\frac{1+f}{1+f^{\prime}}\right)^{1/\alpha\_{N}}\approx 2.7$ |  | (B.12) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{S\_{f}}{S\_{f^{\prime}}}$ | $\displaystyle=\left(\frac{1+\frac{1}{f}}{1+\frac{1}{f^{\prime}}}\right)^{1/\alpha\_{S}}\approx 0.13$ |  | (B.13) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{C\_{f}}{C\_{f^{\prime}}}$ | $\displaystyle=\frac{N\_{f}}{N\_{f^{\prime}}}\frac{S\_{f}}{S\_{f^{\prime}}}\approx 0.35$ |  | (B.14) |

So that compute-efficient training uses 7.7x fewer parameter updates, 2.7x more parameters, and 65% less compute to reach the same loss.

### B.4 Suboptimal Model Sizes

We can solve A.1 to find an expression for the amount of compute needed to reach a given value of the loss $L$ with a model of size $N$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\left(N,L\right)=\left(6B\_{\ast}S\_{c}\frac{N}{L^{1/\alpha\_{B}}}\right)\left(L-\left(\frac{N\_{c}}{N}\right)^{\alpha\_{N}}\right)^{-1/\alpha\_{S}}.$ |  | (B.15) |

Using A.6 and A.9, we can eliminate $L$ in favor of $N\_{{\rm eff}}\left(L\right)$, the model size which reaches $L$ most efficiently. From there, we find an expression for the excess compute needed as a consequence of using a suboptimal model size:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{C\left(N,N\_{{\rm eff}}\right)}{C\left(N\_{{\rm eff}},N\_{{\rm eff}}\right)}=\frac{N}{N\_{{\rm eff}}}\left[1+\frac{\alpha\_{S}}{\alpha\_{N}}\left(1-\left(\frac{N\_{{\rm eff}}}{N}\right)^{\alpha\_{N}}\right)\right]^{-1/\alpha\_{S}}.$ |  | (B.16) |

The result is shown in Figure X. Models between 0.6x and 2.2x the optimal size can be used with only a 20% increase in compute budget. Using a smaller model is useful when accounting for the cost inference. A larger model can be trained the the same level of performance in fewer steps, allowing for more parallelism and faster training if sufficient harware is available (see Figure Y):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{S\left(N,N\_{{\rm eff}}\right)}{S\left(N\_{{\rm eff}},N\_{{\rm eff}}\right)}=\left[1+\frac{\alpha\_{S}}{\alpha\_{N}}\left(1-\left(\frac{N\_{{\rm eff}}}{N}\right)^{\alpha\_{N}}\right)\right]^{-1/\alpha\_{S}}.$ |  | (B.17) |

A 2.2x larger model requires 45% fewer steps at a cost of 20% more training compute. Note that this equation should not be trusted for very large models, as it is only valid in the power-law region of the learning curve after initial transient effects.

## Appendix C Caveats

In this section we list some potential caveats to our analysis.

* •

  At present we do not have a solid theoretical understanding for any of our proposed scaling laws. The scaling relations with model size and compute are especially mysterious. It may be possible to understand scaling at very large $D$ holding model size fixed [[AS17](#bib.bibx2)], and also the shape of learning curves late in training, by modeling the loss with a noisy quadratic. But the scaling with $D$ at very large model size still remains mysterious. Without a theory or a systematic understanding of the corrections to our scaling laws, it’s difficult to determine in what circumstances they can be trusted.
* •

  We are not especially confident in the prediction of $B\_{\rm crit}(L)$ for values of the loss far outside the range we have explored. Changes in $B\_{\rm crit}$ could have a significant impact on trade-offs between data parallelism and the number of serial training steps required, which would have a major impact on training time.
* •

  We did not thoroughly investigate the small data regime, and our fits for $L(N,D)$ were poor for the smallest values of $D$ (where an epoch corresponded to only $40$ steps). Furthermore, we did not experiment with regularization and data augmentation. Improvements in these could alter our results, quantitatively or qualitatively.
* •

  We used the estimated training compute $C\approx 6NBS$, which did not include contributions proportional to $n\_{\rm ctx}$ (see Section [2.1](#S2.SS1 "2.1 Parameter and Compute Scaling of Transformers ‣ 2 Background and Methods ‣ Scaling Laws for Neural Language Models")). So our scalings with compute may be confounded in practice in the regime of very large $n\_{\rm ctx}$, specifically where $n\_{\rm ctx}\gtrsim 12d\_{\rm model}$.
* •

  We tuned learning rates, and we experimented with learning rate schedules. But we may have neglected to tune some hyperparameter (e.g. intialization scale or momentum) that have an important effect on scaling.
* •

  The optimal choice of learning rate is sensitive to the target loss. When training close to convergence, it may be necessary to use a smaller learning rate to avoid divergences. But when conducting a short training run (eg due to compute limitations), it may be possible to use a larger learning rate. We did not experiment with higher learning rates for training runs that did not proceed to convergence.

## Appendix D Supplemental Figures

Figure 16:  Left: We characterize the step on which early stopping occurs, as a function of the extent of overfitting. The red line indicates a lower bound for early stopping that is derived in Section [5.3](#S5.SS3 "5.3 Lower Bound on Early Stopping Step ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models"). Right: We display train and test loss for a series of 300M parameter models trained on different sized dataset sub-samples. The test loss typically follows that of a run done with unrestricted data until diverging. Note that the degree of overfitting (as compared to the infinite data limit) is significantly overestimated by $L\_{\rm test}-L\_{\rm train}$ (denoted by a black bar for each run).

Figure 17: We compare recurrent Transformers [[DGV+18](#bib.bibx8)], which re-use parameters, to standard Transformers. Recurrent Transformers perform slightly better when comparing models with equal parameter count, but slightly worse when accounting for reuse and comparing per FLOP.

### D.1 Early Stopping and Test vs Train

In section [5.3](#S5.SS3 "5.3 Lower Bound on Early Stopping Step ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models") we described the result shown in Figure [16](#A4.F16 "Figure 16 ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models"), which provides a prediction for a lower bound on the early stopping step. We also show the train and test loss for a given model size when training on different sized datasets.

### D.2 Universal Transformers

We compare the performance of standard Transformers to recurrent Transformers [[DGV+18](#bib.bibx8)] in Figure [17](#A4.F17 "Figure 17 ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models"). These models re-use parameters, and so perform slightly better as a function of $N$, but slightly worse as a function of compute $C$. We include several different different possibilities for parameter re-use.

### D.3 Batch Size

We measure the critical batch size using the data displayed in figure [18](#A4.F18 "Figure 18 ‣ D.3 Batch Size ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models"). This made it possible to estimate $B\_{\rm crit}(L)$ in figure [10](#S5.F10 "Figure 10 ‣ 5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models").

Figure 18: These figures demonstrate fits to Equation ([5.1](#S5.E1 "In 5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models")) for a large number of values of the loss $L$, and for two different Transformer model sizes. These fits were used to measure $B\_{\rm crit}(L)$ for Figure [10](#S5.F10 "Figure 10 ‣ 5.1 Adjustment for Training at 𝐵_crit⁢(𝐿) ‣ 5 Scaling Laws with Model Size and Training Time ‣ Scaling Laws for Neural Language Models").

### D.4 Sample Efficiency vs Model Size

It is easy to see from figure [2](#S1.F2 "Figure 2 ‣ Sample efficiency: ‣ 1.1 Summary ‣ 1 Introduction ‣ Scaling Laws for Neural Language Models") that larger models train faster, and are therefore more sample efficient. We provide another way of looking at this phenomenon in figure [19](#A4.F19 "Figure 19 ‣ D.4 Sample Efficiency vs Model Size ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models"), which shows when different models reach various fixed values of the loss.

Figure 19: The number of minimum serial steps needed to reach any fixed value of the test loss decreases precipitously with model size. Sample efficiency (show here for training far below the critical batch size) improves greatly as well, improving by a factor of almost 100 when comparing the smallest possible model to a very large one.

Figure 20:  This figure provides information about the performance per token as a function of model size and training time. Left: Loss per token as a function of its position $T$ in the 1024-token context. Loss scales predictably as a power-law in $T$. Right:  Test loss per token as a function of training step.

### D.5 Context Dependence

Figure 21: In addition to the averaged loss, individual tokens within the 1024-token context also improve smoothly as model size increases. Training runs with shorter context $n\_{\rm ctx}=8$ (dashed lines) perform better on early tokens, since they can allocate all of their capacity to them.

The trends for loss as a function of model size are displayed for different tokens in the context in Figure [21](#A4.F21 "Figure 21 ‣ D.5 Context Dependence ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models"). We see that models trained on $n\_{\rm ctx}=1024$ show steady improvement with model size on all but the first token.

Fixing model size, it appears that the loss scales as a power-law as a function of position $T$ in the context, see Figure [20](#A4.F20 "Figure 20 ‣ D.4 Sample Efficiency vs Model Size ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models"). This may be a consequence of underlying power-law correlations in language [[EP94](#bib.bibx9), [ACDE12](#bib.bibx1), [LT16](#bib.bibx26)], or a more general feature of the model architecture and optimization. It provides some suggestion for the potential benefits (or lack thereof) from training on larger contexts. Not only do larger models converge to better performance at $T=1024$, but they also improve more quickly at early tokens, suggesting that larger models are more efficient at detecting patterns with less contextual information. In the right-hand plot we show how per-token performance varies for a fixed model as a function of the training step. The model begins by learning short-range information, and only learns longer-range correlations later in training.

We have also included models trained with a tiny context $n\_{\rm ctx}=8$ in order to compare with our longer context models. Even modestly sized models trained on $n\_{\rm ctx}=8$ can dominate our largest $n\_{\rm ctx}=1024$ models on very early tokens. This also suggests that further improvements should be possible with much larger models trained on large contexts.

Figure 22: 
We test a variety of learning rate schedules including cosine decay, linear decay, as well as other faster/slower decays schedules on a 3 million parameter model, shown on the left.
For these experiments we do not decay to zero, since we find that this tends to give a fixed improvement close to the end of training.
We find that, as long as the learning rate is not too small and does not decay too quickly, performance does not depend strongly on learning rate.
Run-to-run variation is at the level of 0.05 in the loss, so averaging multiple runs is necessary to validate performance changes smaller than this level.

### D.6 Learning Rate Schedules and Error Analysis

We experimented with a variety of learning rates and schedules. A host of schedules and resulting test performances for a small language model are plotted in Figure [22](#A4.F22 "Figure 22 ‣ D.5 Context Dependence ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models"). We conclude that the choice of learning rate schedule is mostly irrelevant, as long as the total summed learning rate is sufficiently large, and the schedule includes a warmup period and a final decay to near-vanishing learning rate. Variations among schedules appear to be statistical noise, and provide a rough gauge for the scale of variation between different training runs. Experiments on larger models suggest that the variation in the final test loss between different random seeds is roughly constant in magnitude for different model sizes.

We found that larger models require a smaller learning rate to prevent divergence, while smaller models can tolerate a larger learning rate. To implement this, the following rule of thumb was used for most runs:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathrm{LR}(N)\approx 0.003239+-0.0001395\log(N)$ |  | (D.1) |

We expect that this formula could be improved. There may be a dependence on network width, likely set by the initialization scale. The formula also breaks down for $N>10^{10}$ parameters. Nevertheless, we found that it works sufficiently well for the models we considered.

### D.7 Fit Details and Power Law Quality

Figure 23: The trend for performance as a function of parameter count, $L(N)$, is fit better by a power law than by other functions such as a logarithm at a qualitative level.

Figure 24: We show evaluations on a series of datasets for models with approximately 1.5 Billion parameters. We observe no effect of depth on generalization; generalization performance depends primarily on training distribution performance. The 12-layer model overfit the Internet Books dataset and we show the early-stopped performance; we have not seen this surprising result in other experiments.

We experimented with a number of functional forms for the fits to $L(N),L(C)$, and $L(D)$; the power-law fits were qualitatively much more accurate than other functions such as logarithms (see Figure [23](#A4.F23 "Figure 23 ‣ D.7 Fit Details and Power Law Quality ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models")).

For $L(C)$, we do not include small models with only 1 layer in the fit, as the transition from 1 to 2 layers causes a noticable lump in the data. For $L(N)$ we also do not include very small models with only 1 layer in the fit, and we exclude the largest models that have not trained fully to convergence. Fit parameters change marginally if we do include them, and the trend extrapolates well in both directions regardless.

### D.8 Generalization and Architecture

In figure [24](#A4.F24 "Figure 24 ‣ D.7 Fit Details and Power Law Quality ‣ Appendix D Supplemental Figures ‣ Scaling Laws for Neural Language Models") we show that generalization to other data distributions does not depend on network depth when we hold the total parameter count fixed. It seems to depend only on the performance on the training distribution.
