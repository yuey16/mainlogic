<!-- fulltext source=arxiv_html slug=arXiv-1804.09301 fetched=2026-09-22T13:27:39+00:00 -->

# Gender Bias in Coreference Resolution

Rachel Rudinger
  
Jason Naradowsky
  
Brian Leonard
  
and Benjamin Van Durme
Affiliation: Johns Hopkins University

###### Abstract

We present an empirical study of gender bias in coreference resolution systems. We first introduce a novel, Winograd schema-style set of minimal pair sentences that differ only by pronoun gender.
With these Winogender schemas, we evaluate and confirm systematic gender bias in three publicly-available coreference resolution systems, and correlate this bias with real-world and textual gender statistics.

## 1 Introduction

There is a classic riddle: A man and his son get into a terrible car crash. The father dies, and the boy is badly injured. In the hospital, the surgeon looks at the patient and exclaims, “I can’t operate on this boy, he’s my son!” How can this be?

That a majority of people are reportedly unable to solve this riddle11
1
The surgeon is the boy’s mother. is taken as evidence of underlying implicit gender bias [Wapman and Belle (2014)](#bib.bib21): many first-time listeners have difficulty assigning both the role of “mother” and “surgeon” to the same entity.

As the riddle reveals, the task of coreference resolution in English is tightly bound with questions of gender, for humans and automated systems alike (see Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Gender Bias in Coreference Resolution")).
As awareness grows of the ways in which data-driven AI technologies may acquire and amplify human-like biases [Caliskan et al. (2017)](#bib.bib6); [Barocas and Selbst (2016)](#bib.bib1); [Hovy and Spruit (2016)](#bib.bib11), this work investigates how gender biases manifest in coreference resolution systems.

There are many ways one could approach this question; here we focus on gender bias with respect to occupations, for which we have corresponding U.S. employment statistics.
Our approach is to construct a challenge dataset in the style of *Winograd schemas*, wherein a pronoun must be resolved to one of two previously-mentioned entities in a sentence designed to be easy for humans to interpret, but challenging for data-driven systems [Levesque et al. (2011)](#bib.bib15). In our setting, one of these mentions is a person referred to by their occupation; by varying only the pronoun’s gender, we are able to test the impact of gender on resolution. With these ‘‘Winogender schemas,’’ we demonstrate the presence of systematic gender bias in multiple publicly-available coreference resolution systems, and that occupation-specific bias is correlated with employment statistics. We release these test sentences to the public.22
2
https://github.com/rudinger/winogender-schemas

In our experiments, we represent gender as a categorical variable with either two or three possible values: female, male, and (in some cases) neutral. These choices reflect limitations of the textual and real-world datasets we use.

Figure 1: Stanford CoreNLP rule-based coreference system resolves a male and neutral pronoun as coreferent with “The surgeon,” but does not for the corresponding female pronoun.

## 2 Coreference Systems

In this work, we evaluate three publicly-available off-the-shelf coreference resolution systems, representing three different machine learning paradigms: rule-based systems, feature-driven statistical systems, and neural systems.

### Rule-based

In the absence of large-scale data for training coreference models, early systems relied heavily on expert knowledge. A frequently used example of this is the Stanford multi-pass sieve system ([Lee et al., 2011](#bib.bib14)). A deterministic system, the sieve consists of multiple rule-based models which are applied in succession, from highest-precision to lowest. Gender is among the set of mention attributes identified in the very first stage of the sieve, making this information available throughout the system.

### Statistical

Statistical methods, often with millions of parameters, ultimately surpassed the performance of rule-based systems on shared task data ([Durrett and Klein, 2013](#bib.bib9); [Björkelund and Kuhn, 2014](#bib.bib4)). The system of [Durrett and Klein (2013)](#bib.bib9) replaced hand-written rules with simple feature templates. Combinations of these features implicitly capture linguistic phenomena useful for resolving antecedents, but they may also unintentionally capture bias in the data. For instance, for occupations which are not frequently found in the data, an occupation+pronoun feature can be highly informative, and the overly confident model can exhibit strong bias when applied to a new domain.

### Neural

The move to deep neural models led to more powerful antecedent scoring functions, and the subsequent learned feature combinations resulted in new state-of-the-art performance ([Wiseman et al., 2015](#bib.bib22); [Clark and Manning, 2016b](#bib.bib8)). Global inference over these models further improved performance ([Wiseman et al., 2016](#bib.bib23); [Clark and Manning, 2016a](#bib.bib7)), but from the perspective of potential bias, the information available to the model is largely the same as in the statistical models. A notable exception is in the case of systems which make use of pre-trained word embeddings ([Clark and Manning, 2016b](#bib.bib8)), which have been shown to contain bias and have the potential to introduce bias into the system.

### Noun Gender and Number

Many coreference resolution systems, including those described here, make use of a common resource released by [Bergsma and Lin (2006)](#bib.bib2)33
3
This data was distributed in the CoNLL 2011 and 2012 shared tasks on coreference resolution. [Pradhan et al. (2011)](#bib.bib18); [Pradhan et al. (2012)](#bib.bib17) (“B&L”): a large list of English nouns and noun phrases with gender and number counts over 85GB of web news. For example, according to the resource, 9.2% of mentions of the noun “doctor” are female. The resource was compiled by bootstrapping coreference information from the dependency paths between pairs of pronouns. We employ this data in our analysis.

## 3 Winogender Schemas

Our intent is to reveal cases where coreference systems may be more or less likely to recognize a pronoun as coreferent with a particular occupation based on pronoun gender, as observed in Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Gender Bias in Coreference Resolution").
To this end, we create a specialized evaluation set consisting of 120 hand-written sentence templates, in the style of the Winograd Schemas [Levesque et al. (2011)](#bib.bib15). Each sentence contains three referring expressions of interest:

1. 1.

   occupation , a person referred to by their occupation and a definite article, e.g., “the paramedic.”
2. 2.

   participant , a secondary (human) participant, e.g., “the passenger.”
3. 3.

   pronoun , a pronoun that is coreferent with either occupation or participant.

We use a list of 60 one-word occupations obtained from [Caliskan et al. (2017)](#bib.bib6) (see supplement), with corresponding gender percentages available from the U.S. Bureau of Labor Statistics.44
4
50 are from the supplement of [Caliskan et al. (2017)](#bib.bib6), an additional 7 from personal communication with the authors, and three that we added: doctor, firefighter, and secretary. For each occupation, we wrote two similar sentence templates: one in which pronoun is coreferent with occupation, and one in which it is coreferent with participant (see Figure [2](#S3.F2 "Figure 2 ‣ 3 Winogender Schemas ‣ Gender Bias in Coreference Resolution")).
For each sentence template, there are three pronoun instantiations (female, male, or neutral), and two participant instantiations (a specific participant, e.g., “the passenger,” and a generic paricipant, “someone.”) With the templates fully instantiated, the evaluation set contains 720 sentences: 60 occupations $\times$ 2 sentence templates per occupation $\times$ 2 participants $\times$ 3 pronoun genders.

(1a) The paramedic performed CPR on the passenger even though she/he/they knew it was too late.

(2a) The paramedic performed CPR on the passenger even though she/he/they was/were already dead.
(1b) The paramedic performed CPR on someone even though she/he/they knew it was too late.
(2b) The paramedic performed CPR on someone even though she/he/they was/were already dead.

Figure 2: A “Winogender” schema for the occupation paramedic. Correct answers in bold. In general, occupation and participant may appear in either order in the sentence.

### Validation

Like Winograd schemas, each sentence template is written with one intended correct answer (here, either occupation or participant).55
5
Unlike Winograd schemas, we are not primarily concerned with whether these sentences are “hard” to solve, e.g., because they would require certain types of human knowledge or could not be easily solved with word co-occurrence statistics.
We aimed to write sentences where (1) pronoun resolution was as unambiguous for humans as possible (in the absence of additional context), and (2) the resolution would not be affected by changing pronoun gender. (See Figure [2](#S3.F2 "Figure 2 ‣ 3 Winogender Schemas ‣ Gender Bias in Coreference Resolution").)
Nonetheless, to ensure that our own judgments are shared by other English speakers, we validated all 720 sentences on Mechanical Turk, with 10-way redundancy.
Each MTurk task included 5 sentences from our dataset, and 5 sentences from the Winograd Schema Challenge [Levesque et al. (2011)](#bib.bib15)66
6
We used the publicly-available examples from https://cs.nyu.edu/faculty/davise/papers/WinogradSchemas/WSCollection.html, though this additional validation step turned out to be unnecessary.77
7
In the end, we did not use the Winograd schemas to filter annotators, as raw agreement on the Winogender schemas was much higher to begin with (94.9% Winogender vs. 86.5% Winograd).
Out of 7200 binary-choice worker annotations (720 sentences $\times$ 10-way redundancy), 94.9% of responses agree with our intended answers.
With simple majority voting on each sentence, worker responses agree with our intended answers for 718 of 720 sentences (99.7%). The two sentences with low agreement have neutral gender (“they”), and are not reflected in any binary (female-male) analysis.

Figure 3: Gender statistics from [Bergsma and Lin (2006)](#bib.bib2) correlate with Bureau of Labor Statistics 2015. However, the former has systematically lower female percentages; most points lie well below the 45-degree line (dotted). Regression line and 95% confidence interval in blue. Pearson r = 0.67.

| Correlation (r) | Rule | Stat | Neural |
| --- | --- | --- | --- |
| B&L | 0.87 | 0.46 | 0.35 |
| BLS | 0.55 | 0.31 | 0.31 |

Table 1: Correlation values for Figures [3](#S3.F3 "Figure 3 ‣ Validation ‣ 3 Winogender Schemas ‣ Gender Bias in Coreference Resolution") and [4](#S4.F4 "Figure 4 ‣ 4 Results and Discussion ‣ Gender Bias in Coreference Resolution").

## 4 Results and Discussion

Figure 4: These two plots show how gender bias in coreference systems corresponds with occupational gender statistics from the U.S Bureau of Labor Statistics (left) and from text as computed by [Bergsma and Lin (2006)](#bib.bib2) (right); each point represents one occupation. The y-axes measure the extent to which a coref system prefers to match female pronouns with a given occupation over male pronouns, as tested by our Winogender schemas. A value of 100 (maximum female bias) means the system always resolved female pronouns to the given occupation and never male pronouns (100% - 0%); a score of -100 (maximum male bias) is the reverse; and a value of 0 indicates no gender differential. Recall the Winogender evaluation set is gender-balanced for each occupation; thus the horizontal dotted black line (y=0) in both plots represents a hypothetical system with 100% accuracy. Regression lines with 95% confidence intervals are shown.

We evaluate examples of each of the three coreference system architectures described in [2](#S2 "2 Coreference Systems ‣ Gender Bias in Coreference Resolution"): the [Lee et al. (2011)](#bib.bib14) sieve system from the rule-based paradigm (referred to as RULE), [Durrett and Klein (2013)](#bib.bib9) from the statistical paradigm (STAT), and the [Clark and Manning (2016a)](#bib.bib7) deep reinforcement system from the neural paradigm (NEURAL).

By multiple measures, the Winogender schemas reveal varying degrees of gender bias in all three systems. First we observe that these systems do not behave in a gender-neutral fashion. That is to say, we have designed test sentences where correct pronoun resolution is not a function of gender (as validated by human annotators), but system predictions do exhibit sensitivity to pronoun gender: 68% of male-female minimal pair test sentences are resolved differently by the RULE system; 28% for STAT; and 13% for NEURAL.

Overall, male pronouns are also more likely to be resolved as occupation than female or neutral pronouns across all systems: for RULE, 72% male vs 29% female and 1% neutral; for STAT, 71% male vs 63% female and 50% neutral; and for NEURAL, 87% male vs 80% female and 36% neutral. Neutral pronouns are often resolved as neither occupation nor participant, possibly due to the number ambiguity of “they/their/them.”

When these systems’ predictions diverge based on pronoun gender, they do so in ways that reinforce and magnify real-world occupational gender disparities. Figure [4](#S4.F4 "Figure 4 ‣ 4 Results and Discussion ‣ Gender Bias in Coreference Resolution") shows that systems’ gender preferences for occupations correlate with real-world employment statistics (U.S. Bureau of Labor Statistics) and the gender statistics from text [Bergsma and Lin (2006)](#bib.bib2) which these systems access directly; correlation values are in Table [1](#S3.T1 "Table 1 ‣ Validation ‣ 3 Winogender Schemas ‣ Gender Bias in Coreference Resolution"). We also identify so-called “gotcha” sentences in which pronoun gender does not match the occupation’s majority gender (BLS) if occupation is the correct answer; all systems perform worse on these ‘‘gotchas.’’88
8
“ The librarian helped the child pick out a book because he liked to encourage reading.” is an example of a “gotcha” sentence; librarians are $>50\%$ female (BLS). (See Table [2](#S4.T2 "Table 2 ‣ 4 Results and Discussion ‣ Gender Bias in Coreference Resolution").)

Because coreference systems need to make discrete choices about which mentions are coreferent, percentage-wise differences in real-world statistics may translate into absolute differences in system predictions. For example, the occupation “manager” is 38.5% female in the U.S. according to real-world statistics (BLS); mentions of “manager” in text are only 5.18% female (B&L resource); and finally, as viewed through the behavior of the three coreference systems we tested, no managers are predicted to be female.
This illustrates two related phenomena: first, that data-driven NLP pipelines are susceptible to sequential amplification of bias throughout a pipeline, and second, that although the gender statistics from B&L correlate with BLS employment statistics, they are systematically male-skewed (Figure [3](#S3.F3 "Figure 3 ‣ Validation ‣ 3 Winogender Schemas ‣ Gender Bias in Coreference Resolution")).

| System | “Gotcha”? | Female | Male |
| --- | --- | --- | --- |
| Rule | no | 38.3 | 51.7 |
| yes | 10.0 | 37.5 |
| Stat | no | 50.8 | 61.7 |
| yes | 45.8 | 40.0 |
| Neural | no | 50.8 | 49.2 |
| yes | 36.7 | 46.7 |

Table 2: System accuracy (%) bucketed by gender and difficulty (so-called “gotchas,” shaded in purple). For female pronouns, a “gotcha” sentence is one where either (1) the correct answer is occupation but the occupation is $<50\%$ female (according to BLS); or (2) the occupation is $\geq 50\%$ female but the correct answer is participant; this is reversed for male pronouns. Systems do uniformly worse on “gotchas.”

## 5 Related Work

Here we give a brief (and non-exhaustive) overview of prior work on gender bias in NLP systems and datasets. A number of papers explore (gender) bias in English word embeddings: how they capture implicit human biases in modern [Caliskan et al. (2017)](#bib.bib6) and historical [Garg et al. (2018)](#bib.bib10) text, and methods for debiasing them [Bolukbasi et al. (2016)](#bib.bib5). Further work on debiasing models with adversarial learning is explored by [Beutel et al. (2017)](#bib.bib3) and [Zhang et al. (2018)](#bib.bib24).

Prior work also analyzes social and gender stereotyping in existing NLP and vision datasets [van Miltenburg (2016)](#bib.bib16); [Rudinger et al. (2017)](#bib.bib19). [Tatman (2017)](#bib.bib20) investigates the impact of gender and dialect on deployed speech recognition systems, while [Zhao et al. (2017)](#bib.bib25) introduce a method to reduce amplification effects on models trained with gender-biased datasets. [Koolen and van Cranenburgh (2017)](#bib.bib12) examine the relationship between author gender and text attributes, noting the potential for researcher interpretation bias in such studies.
Both [Larson (2017)](#bib.bib13) and [Koolen and van Cranenburgh (2017)](#bib.bib12) offer guidelines to NLP researchers and computational social scientists who wish to predict gender as a variable. [Hovy and Spruit (2016)](#bib.bib11) introduce a helpful set of terminology for identifying and categorizing types of bias that manifest in AI systems, including overgeneralization, which we observe in our work here.

Finally, we note independent but closely related work by [Zhao et al. (2018)](#bib.bib26), published concurrently with this paper. In their work, [Zhao et al. (2018)](#bib.bib26) also propose a Winograd schema-like test for gender bias in coreference resolution systems (called “WinoBias”). Though similar in appearance, these two efforts have notable differences in substance and emphasis. The contribution of this work is focused primarily on schema construction and validation, with extensive analysis of observed system bias, revealing its correlation with biases present in real-world and textual statistics; by contrast, [Zhao et al. (2018)](#bib.bib26) present methods of debiasing existing systems, showing that simple approaches such as augmenting training data with gender-swapped examples or directly editing noun phrase counts in the B&L resource are effective at reducing system bias, as measured by the schemas. Complementary differences exist between the two schema formulations: Winogender schemas (this work) include gender-neutral pronouns, are syntactically diverse, and are human-validated; WinoBias includes (and delineates) sentences resolvable from syntax alone; a Winogender schema has one occupational mention and one “other participant” mention; WinoBias has two occupational mentions. Due to these differences, we encourage future evaluations to make use of both datasets.

## 6 Conclusion and Future Work

We have introduced “Winogender schemas,” a pronoun resolution task in the style of Winograd schemas that enables us to uncover gender bias in coreference resolution systems. We evaluate three publicly-available, off-the-shelf systems and find systematic gender bias in each: for many occupations, systems strongly prefer to resolve pronouns of one gender over another. We demonstrate that this preferential behavior correlates both with real-world employment statistics and the text statistics that these systems use. We posit that these systems overgeneralize the attribute of gender, leading them to make errors that humans do not make on this evaluation.
We hope that by drawing attention to this issue, future systems will be designed in ways that mitigate gender-based overgeneralization.

It is important to underscore the limitations of Winogender schemas. As a diagnostic test of gender bias, we view the schemas as having high positive predictive value and low negative predictive value; that is, they may demonstrate the presence of gender bias in a system, but not prove its absence.
Here we have focused on examples of occupational gender bias, but Winogender schemas may be extended broadly to probe for other manifestations of gender bias.
Though we have used human-validated schemas to demonstrate that existing NLP systems are comparatively more prone to gender-based overgeneralization, we do not presume that matching human judgment is the ultimate objective of this line of research. Rather, human judgements, which carry their own implicit biases, serve as a lower bound for equitability in automated systems.

## Acknowledgments

The authors thank Rebecca Knowles and Chandler May for their valuable feedback on this work. This research was supported by the JHU HLTCOE, DARPA AIDA, and NSF-GRFP (1232825). The U.S. Government is authorized to reproduce and distribute reprints for Governmental purposes. The views and conclusions contained in this publication are those of the authors and should not be interpreted as representing official policies or endorsements of DARPA or the U.S. Government.
