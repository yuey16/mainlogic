<!-- fulltext source=arxiv_html slug=arXiv-1509.08435 fetched=2026-09-18T01:24:07+00:00 -->

# Efficient long distance quantum communication

Sreraman Muralidharan1∗
Affiliation: 1Department of Electrical Engineering, Yale University, New Haven, CT
06511 USA
  
Linshu Li2∗
Affiliation: 1Department of Electrical Engineering, Yale University, New Haven, CT
06511 USA
  
Jungsang Kim3
Affiliation: 1Department of Electrical Engineering, Yale University, New Haven, CT
06511 USA
  
Norbert Lütkenhaus4
Affiliation: 1Department of Electrical Engineering, Yale University, New Haven, CT
06511 USA
  
Mikhail D. Lukin5
Affiliation: 1Department of Electrical Engineering, Yale University, New Haven, CT
06511 USA
  
Liang Jiang2
Affiliation: 1Department of Electrical Engineering, Yale University, New Haven, CT
06511 USA
Affiliation: 2Department of Applied Physics, Yale University, New Haven, CT 06511 USA
Affiliation: 3Department of Electrical and Computer Engineering, Duke University,
Durham, NC 27708 USA
Affiliation: 4Institute of Quantum computing, University of Waterloo, N2L 3G1
Waterloo, Canada
Affiliation: 5Department of Physics, Harvard University, Cambridge, MA 02138, USA
Thanks: Equal contribution

August 24, 2026

###### Abstract

Despite the tremendous progress of quantum cryptography,
efficient quantum communication over long distances ($\geq 1000$km) remains an outstanding challenge
due to fiber attenuation and operation errors accumulated over the
entire communication distance. Quantum repeaters (QRs), as a promising approach,
can overcome both photon loss and operation errors, and hence significantly speedup
the communication rate. Depending on the methods used to correct loss
and operation errors, all the proposed QR schemes can be classified into three categories (generations). Here we present the first systematic
comparison of three generations of quantum repeaters by evaluating
the cost of both temporal and physical resources, and identify the
optimized quantum repeater architecture for a given set of experimental
parameters. Our work provides a roadmap for the experimental realizations of highly efficient quantum
networks over transcontinental distances.

###### pacs

03.67.Dd, 03.67.Hk, 03.67.Pp.

## I Introduction

First developed in the 1970s, fiber-optic communication systems have
boosted the rate of classical information transfer and played a major
role in the advent of the information age. The possibility to encode
information in quantum states using single photons and transmit them
through optical channels has led to the
development of quantum key distribution (QKD) systems [[1](#bib.bib1)]. However,
errors induced by the intrinsic channel attenuation, i.e. loss errors, become a major barrier for efficient quantum
communication over continental scales, due to the exponential decay of communication rate
[[2](#bib.bib2)]. In contrast to classical communication, due to the quantum no-cloning theorem [[3](#bib.bib3)],
quantum states of photons cannot be amplified without any disturbance. In addition to loss errors, depolarization errors introduced by the imperfect optical channel can impair the quality of the single photon transmitted and hence the quantum information encoded.

To overcome these challenges, quantum
repeaters (QRs) have been proposed for the faithful realization of long-distance quantum communication [[4](#bib.bib4)].
The essence of QRs is to divide the total distance of communication
into shorter intermediate segments connected by QR stations, in which loss
errors from fiber attenuation can be corrected. Active mechanisms
are also employed at every repeater station to correct operation errors, i.e. imperfections induced by the channel, measurements and gate operations.

Figure 1: A list of methods to correct loss and operation errors. Depending
on the methods used to correct the errors, QRs are categorized into three generations.

As illustrated in Fig. 1, loss errors can be suppressed by either heralded entanglement
generation (HEG) [[4](#bib.bib4), [5](#bib.bib5)] or quantum error correction
(QEC) [[6](#bib.bib6), [7](#bib.bib7), [8](#bib.bib8), [9](#bib.bib9), [10](#bib.bib10)]. During HEG, quantum entanglement can be generated with techniques such as two-photon interference conditioned on the click patterns of the detectors in between.
Loss errors are suppressed by repeating this heralded
proceDure until the two adjacent stations receive the confirmation of certain
successful detection patterns via two-way classical signaling.

Alternatively, one may encode the logical qubit into a block of physical
qubits that are sent through the lossy channel and use quantum error correction to restore the logical qubit with only one-way signaling.
Quantum error correcting codes can correct no more than $50\%$ loss rates deterministically due to the no-cloning theorem [[11](#bib.bib11), [9](#bib.bib9)].
To suppress operation errors, one may use either heralded entanglement purification (HEP) [[12](#bib.bib12), [13](#bib.bib13)] or QEC [[6](#bib.bib6), [7](#bib.bib7), [8](#bib.bib8), [9](#bib.bib9), [10](#bib.bib10)] as listed in Fig. [1](#S1.F1 "Figure 1 ‣ I Introduction ‣ Efficient long distance quantum communication"). In HEP, multiple low-fidelity Bell pairs are consumed to probabilistically generate a smaller number of higher-fidelity Bell pairs. Like HEG, to confirm the success of purification , two-way classical signaling between repeater stations for exchanging measurement results is required. Alternatively, QEC can correct operation errors using only one-way classical
signaling, but it needs high fidelity local quantum gates.

Based on the methods adopted to suppress loss and operation errors,
we can classify various QRs into three
categories as shown schematically in Fig. [2](#S2.F2 "Figure 2 ‣ II Three generations of quantum repeaters ‣ Efficient long distance quantum communication"), which we refer to as three generations of QRs [[14](#bib.bib14)] 11
1
Note that the combination of QEC for loss errors and HEG for operation errors is sub-optimum compared to the other three combinations..
Each generation of QR performs the best for a specific regime of operational parameters such as local gate speed, gate fidelity, and coupling efficiency. In this paper, we consider both the temporal and physical resources consumed by the three generations of QRs and identify the most efficient architecture for different parameter regimes. The results can guide the design of efficient long distance quantum communication links that act as elementary building blocks for future quantum networks.

The paper is organized as follows: In the following section, we will briefly review the chacracterstics of three generations of QRs. In section III, we use the cost coefficient as an optimization metric to compare the QR performance, and study its dependence on the individual operational parameters including coupling efficiencies, gate fidelities, and gate speed. In section IV, we present a holistic view of the optimization and illustrate the parameter regions where each generation of QRs perform more efficiently than others. In section V, we analyze the advantages and challenges of each generation of QRs and discuss the experimental candidates for their realizations.

## II Three generations of quantum repeaters

The first
generation of QRs uses HEG and HEP to suppress loss and operation
errors, respectively [[4](#bib.bib4), [5](#bib.bib5)]. This approach starts with
purified high-fidelity entangled pairs with separation $L\_{0}=L\_{tot}/2^{n}$
created and stored in adjacent stations. At $k$-th nesting level,
two entangled pairs of distance $L\_{k-1}=2^{k-1}L\_{0}$ are connected
to extend entanglement to distance $L\_{k}=2^{k}L\_{0}$
[[15](#bib.bib15)]. As practical gate operations and entanglement swapping inevitably cause the fidelity of entangled pairs to drop, HEP can be incorporated at each level of entanglement extension [[12](#bib.bib12), [13](#bib.bib13)]. With $n$ nesting levels of connection
and purification, a high-fidelity entangled pair over distance $L\_{n}=L\_{tot}$
can be obtained. The first generation of QRs reduces the exponential overhead in direct state transfer to only polynomial overhead, which is limited by the two-way classical signaling required by HEP between non-adjacent repeater stations. The communication rate still decreases polynomially with distance and thus becomes very slow for long distance quantum communication. The communication rate of the
first generation of QRs can be boosted using temporal, spatial, and/or frequency multiplexing associated with the internal degrees of freedom for the quantum memory [[5](#bib.bib5), [16](#bib.bib16)].

The second generation of QRs uses HEG to suppress loss errors and
QEC to correct operation errors [[6](#bib.bib6), [7](#bib.bib7), [17](#bib.bib17)]. First,
the encoded states $|0\rangle\_{L}$ and $|+\rangle\_{L}$ are fault-tolerantly
prepared using the Calderbank-Shor-Steane (CSS) codes 22
2
CSS codes are considered because of the
fault tolerant implementation of preparation, measurement, and
encoded CNOT gate [[6](#bib.bib6), [53](#bib.bib53)] and stored at two adjacent stations. Then, an encoded Bell
pair $|\Phi^{+}\rangle\_{L}=\frac{1}{\sqrt{2}}\left(|0,0\rangle\_{L}+|1,1\rangle\_{L}\right)$
between adjacent stations can be created using teleportation-based
non-local CNOT gates [[18](#bib.bib18), [19](#bib.bib19)] applied to each physical qubit in the encoded block using the entangled pairs generated through HEG process.
Finally, QEC is carried out when entanglement swapping at the encoded level is performed to extend the range of entanglement. The second generation uses QEC to replace HEP and therefore avoids the time-consuming two-way classical
signaling between non-adjacent stations. The communication rate is then limited by the time delay associated with two-way classical signaling between adjacent stations and local gate operations.
If the probability of accumulated operation errors over all repeater stations is sufficiently small, we can
simply use the second generation of QRs without encoding.

The third generation of QRs relies on QEC to correct both loss and
operation errors [[8](#bib.bib8), [20](#bib.bib20), [9](#bib.bib9), [10](#bib.bib10)]. The quantum
information can be directly encoded in a block of physical qubits
that are sent through the lossy channel. If the loss and operation errors are sufficiently small, the received physical qubits can be used to restore the whole encoding block, which is retransmitted to the next repeater station. The third generation of QRs only needs one-way signaling and thus
can achieve very high communication rate, just like the classical
repeaters only limited by local operation delay. It turns out that
quantum parity codes [[21](#bib.bib21)] with moderate coding blocks (~200
qubits) can efficiently overcome both loss and operation errors [[9](#bib.bib9), [20](#bib.bib20)].

Note that the second and third generations of QRs can achieve communication
rate much faster than the first generation over long distances, but
they are technologically more demanding. For example, they require
high fidelity quantum gates as QEC only works
well when operation errors are below the fault tolerance threshold. The repeater spacing for the third generation of QRs is smaller compared to the first two generation of QRs because error correction can only correct a finite amount of loss errors.
Moreover, quantum
error correcting codes can correct only up to 50$\%$ loss error rates deterministically,
which restricts the applicable parameter range for the third generation
of QRs [[9](#bib.bib9)].

Figure 2: Comparison of three generations of QRs.

## III Comparison of three generations of QRs

To present a systematic comparison of different in terms of efficiency, we need to consider
both temporal and physical resources. The temporal resource depends on the rate, which is limited by the time delay from the two-way classical signaling (first and second generations) and the local gate operation (second and third generations) [[22](#bib.bib22)]. The physical
resource depends on the total number of qubits needed for HEP (first and second generations) and QEC
(second and third generations) [[9](#bib.bib9), [23](#bib.bib23)]. We
propose to quantitatively compare the three generations of QRs
using a cost function [[9](#bib.bib9)] related to the required number of qubit memories to achieve a given transmission rate.
Suppose a total
of $N\_{tot}$ qubits are needed to generate secure keys at $R$ bits/second, the cost function is defined as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C(L\_{tot})=\frac{N\_{tot}}{R}=\frac{N\_{s}}{R}\times\frac{L\_{tot}}{L\_{0}},$ |  | (1) |

where $N\_{s}$ is the number of qubits needed per repeater station,
$L\_{tot}$ the total communication distance, and $L\_{0}$ the
spacing between neighboring stations. Since the cost function scales at least linearly
with $L\_{tot}$, to demonstrate the additional overhead associated with $L\_{tot}$, the cost coefficient can be introduced as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C^{\prime}(L\_{tot})=C/L\_{tot},$ |  | (2) |

which can be interpreted as the resource overhead (qubits
$\times$ time) for the creation of one secret bit over 1km (with
target distance $L\_{tot}$). Besides the fiber attenuation (with $L\_{att}=20$
km), the cost coefficient also depends on other experimental parameters,
in particular the coupling efficiency $\eta\_{c}$ (see supplementary material), the
gate error probability $\epsilon\_{G}$, and the gate time $t\_{0}$ 33
3
For simplicity, we assume that the fidelity of physical Bell pairs $F\_{0}=1-\frac{5}{4}\epsilon\_{g}$
achieved with entanglement purification and measurement error probability $\epsilon\_{m}=\frac{\epsilon\_{g}}{4}$ through a verification proceDure.. For third generation QRs, we restrict the search only up to 200 qubits per logical qubit considering the complexity involved in the production of larger codes and for a fair comparison with second generation of QRs. For simplicity, we will assume that $t\_{0}$ is independent of code size for small encoded blocks for second and third generation QRs.
We will now investigate how $C^{\prime}$ varies with these parameters
for three generations of QRs, and identify the optimum generation
of QR depending on the technological capability.

### III.1 Coupling efficiency

The coupling efficiency $\eta\_{c}$ accounts for
the emission of photon from the memory qubit, coupling of the photon into the optical fiber and vice versa, and the final detection of photons. The first
and second generations of QRs use HEG compatible with arbitrary coupling
efficiency, while the third generation relies on QEC requiring the overall transmission (including the
coupling efficiency $\eta\_{c}$ and the channel transmission) to be at least above 50% [[24](#bib.bib24), [9](#bib.bib9)].
As illustrated in Fig. [3](#S3.F3 "Figure 3 ‣ III.1 Coupling efficiency ‣ III Comparison of three generations of QRs ‣ Efficient long distance quantum communication"), for high coupling efficiency
($\eta\_{c}\apprge 90\%$) the third generation of QRs has an obvious advantage
over the other generations due to the elimination of two-way classical
signaling. As the coupling efficiency is reduced and approaches ($\sim 90\%$) for quantum parity codes, the size of the coding block quickly increases and it becomes less favorable to use this approachsince we restrict the size of the encoded block for third generation of QRs. For coupling efficiency below $\sim 90\%$,
the optimization chooses the first and second generations of QRs, and
then $C^{\prime}$ is proportional to $\eta\_{c}^{-2}$ for HEG
protocols heralded by two-photon detector click patterns.

If the gate error becomes large (e.g., $\epsilon\_{G}=10^{-2}$),
the capability of correcting loss errors will be compromised for the
third generation QRs. Similar trends can be observed
as we fix $\epsilon\_{G}$ and increase $L\_{tot}$. In contrast to
the third generation QRs, the first and second generation QRs with HEG works well even for low coupling efficiencies.

Figure 3: The optimized cost coefficient C’ as a function of $\eta\_{c}$ for
$t\_{0}=1\mu s$, $\epsilon\_{G}\in\left\{10^{-2},10^{-3},10^{-4}\right\}$,
and a) $L\_{tot}=1000$km, b) $L\_{tot}=10,000$km. The associated optimized
QR protocols are indicated in different colors.

### III.2 Speed of quantum gates

We investigate the performance of different generations of QRs for different
gate times in the range $0.1\mu s\leq t\_{0}\leq 100\mu s$. As shown in Fig. [4](#S3.F4 "Figure 4 ‣ III.2 Speed of quantum gates ‣ III Comparison of three generations of QRs ‣ Efficient long distance quantum communication"), for high speed quantum
gates ($t\_{0}\apprle 1\mu s$) the third generation of QRs provides
a very fast communication rate, which makes it the most favorable
protocol, with $C^{\prime}\propto t\_{0}$. For slower quantum gates ($t\_{0}\apprge 10\mu s$),
the gate time becomes comparable or even larger than the delay of
two-way classical signaling between adjacent stations ($t\_{0}\apprge\frac{L\_{0}}{c}\approx\frac{L\_{att}}{c}$);
as the third generation of QRs loses its advantage in communication rate,
the second generation of QRs with less physical resources becomes the optimized
QR protocol, with almost constant $C^{\prime}$ for a wide range of $t\_{0}$.

We notice that for small gate error and intermediate distance (e.g.,
$\epsilon\_{G}=10^{-4}$ and $L\_{tot}=1000$km appeared in Fig. [3](#S3.F3 "Figure 3 ‣ III.1 Coupling efficiency ‣ III Comparison of three generations of QRs ‣ Efficient long distance quantum communication")a
and [4](#S3.F4 "Figure 4 ‣ III.2 Speed of quantum gates ‣ III Comparison of three generations of QRs ‣ Efficient long distance quantum communication")a), encoding might not even be necessary for the
second generation of QRs, because the accumulated errors over the entire
repeater network are within the tolerable range for quantum communication
($\epsilon\_{G}\frac{L\_{tot}}{L\_{att}}\apprle 0.1$). However, for larger
error probability or longer distances ($\epsilon\_{G}\frac{L\_{tot}}{L\_{att}}\gg 0.1$),
encoding is required for the second generation QRs44
4
When $\epsilon\_{G}$ increases from $10^{-4}$ to $10^{-3}$, the cost coefficient for the second generation of QR without encoding
increases by almost a factor of 10 (Fig. [4](#S3.F4 "Figure 4 ‣ III.2 Speed of quantum gates ‣ III Comparison of three generations of QRs ‣ Efficient long distance quantum communication")a), while
the change is less significant for the second and third generations
of QRs with encoding (Fig. [4](#S3.F4 "Figure 4 ‣ III.2 Speed of quantum gates ‣ III Comparison of three generations of QRs ‣ Efficient long distance quantum communication")). This is because at
the logical level, the change in the effective logical error probability
is suppressed for the given set of parameters.. The cost coefficient for the first generation of QRs ($C^{\prime}>1\frac{qubit\times sec}{sbit\times km}$)
lies beyond the scope of Fig. [4](#S3.F4 "Figure 4 ‣ III.2 Speed of quantum gates ‣ III Comparison of three generations of QRs ‣ Efficient long distance quantum communication"), with little dependence
on $t\_{0}$ that is mostly negligible compared to the two-way classical
signaling between non-adjacent stations ($\frac{L\_{tot}}{c}>10ms$).

Figure 4: The optimized cost coefficient C’ as a function of $t\_{0}$ for $\eta\_{c}=0.9$,
$\epsilon\_{G}\in\left\{10^{-3},10^{-4}\right\}$, and a) $L\_{tot.}=1000$km,
b) $L\_{tot.}=10,000$km. The associated optimized QR protocols are
indicated in different colors.

### III.3 Gate fidelity

The three generations of QRs have different thresholds in terms of
gate error probability $\epsilon\_{G}$. The first generation relies
on HEP with the highest operation error threshold
up to about $3\%$ [[4](#bib.bib4)]. The second and third generations
both use QEC to correct operation errors, with error correction thresholds
of approximately $1\%$ [[25](#bib.bib25)]. The gate error threshold
of the second generation is slightly lower than that of the third
generation, because of the extra gates required for teleportation-based
non-local CNOT gates and entanglement swapping in the second generation of QRs (See supplementary material). However, since we restrict the size of the encoded block for third generation of QRs, C’ increases exponentially with $\epsilon\_{G}$ slightly below the theoretical threshold of quantum parity codes.
As illustrated in Fig. [5](#S3.F5 "Figure 5 ‣ III.3 Gate fidelity ‣ III Comparison of three generations of QRs ‣ Efficient long distance quantum communication"), for almost perfect coupling efficiency
(e.g. $\eta\_{c}=100\%$) and fast local operation ($t\_{0}=1\mu s$),
the third generation using QEC to correct both fiber attenuation loss and operation
errors is the optimized protocol for moderate gate errors.
For lower coupling efficiencies (e.g. $\eta\_{c}=30\%$ and $80\%$)
with too many loss errors for the third generation to tolerate, the
first and second generations with HEG yield
good performance. As $\epsilon\_{G}$ increases, there is a transition at
about $0.8\%$($0.6\%$) below which the second generation is more favorable for 1000km (10000km).

Figure 5: The optimized cost coefficient C’ as a function of $\epsilon\_{G}$
for $t\_{0}=1\mu s$, $\eta\_{c}\in\left\{30\%,80\%,100\%\right\}$,
and a) $L\_{tot}=1000$km, b) $L\_{tot}=10,000$km. The associated optimized
QR protocols are indicated in different colors.

## IV Optimum generation of QRs

Based on the above analysis of the cost coefficient that depends on
the coupling efficiency $\eta\_{c}$, the gate time $t\_{0}$, and the
gate infidelities $\epsilon\_{G}$, we may summarize the results using
the bubble plot and the region plot in the three-dimensional parameter space, as shown
in Fig. [6](#S4.F6 "Figure 6 ‣ IV Optimum generation of QRs ‣ Efficient long distance quantum communication"). The bubble color indicates the associated
optimized QR protocol, and the bubble diameter is proportional to the
cost coefficient. The parameter space can be divided into the following
regions: (I) For high gate error probability $(\epsilon\_{G}\gtrsim 1\%)$,
the first generation dominates; (II.A) For intermediate gate error probability,
but poor coupling efficiency or slow local operation [$0.1\frac{L\_{att}}{L\_{tot}}\apprle\epsilon\_{G}\apprle 1\%$
and ($\eta\_{c}\apprle 90\%$ or $t\_{0}\apprge 1\mu s$)], the second
generation with encoding is more favorable; (II.B) For
low gate error probability, but low coupling efficiency or slow local
operation [$\epsilon\_{G}\apprle 0.1\frac{L\_{att}}{L\_{tot}}$ and
($\eta\_{c}\apprle 90\%$ or $t\_{0}\apprge 1\mu s$)], the second generation
without encoding is more favorable; (III) For high coupling
efficiency, fast local operation, and low gate error probability ($\eta\_{c}\apprge 90\%$,
$t\_{0}\apprle 1\mu s$, $\epsilon\_{G}\apprle 1\%$), the third generation
becomes the most favorable scheme in terms of the cost coefficient.

Figure 6:  The bubble plot comparing various QR protocols in the three-dimensional parameter
space spanned by $\eta\_{c}$, $\epsilon\_{G}$, and $t\_{0}$, for a)
$L\_{tot}=1000$km and b) $L\_{tot}=10,000$km. The bubble color indicates
the associated optimized QR protocol, and the bubble diameter is proportional
to the cost coefficient. The region plots (c) and (d) showing the distribution of different optimized QR protocol in the three dimensional parameter space for $L\_{tot}=1000$km and $L\_{tot}=10,000$km respectively. The region plot (c) contains a yellow region of second generation with encoding, which can be verified in a bubble plot with a finer discretization of $\epsilon\_{G}$.

## V Discussions

So far, we have mostly focused on the standard proceDure of HEG and
HEP [[4](#bib.bib4), [5](#bib.bib5), [12](#bib.bib12), [13](#bib.bib13)], the CSS-type
quantum error correcting codes, and the teleportation-based QEC,
which all can be improved and generalized. We have also assumed the
simple cost function that scales linearly with the communication time
and the total number of qubits. In practice, however, the cost function
may have a more complicated dependence on various resources. Nevertheless,
we may extend our analysis by using more realistic cost functions
to compare various QR protocols. As we bridge the architectural
design of QRs and the physical implementations, we may include more
variations of HEG, HEP as well as QEC (such as all optical schemes [[26](#bib.bib26), [14](#bib.bib14)]) and use more realistic cost functions,
while the general trend and different parameter regions should remain
mostly insensitive to these details.

The classification of QR protocols with different performance in the
parameter space also provides a guideline for optimized architectural
design of QRs based on technological capabilities, which are closely
related to physical implementations, including atomic ensembles, trapped
ions, NV centers, quantum dots, nanophotonic devices, etc. (1) The
atomic ensemble can be used as quantum memory with high coupling efficiency
($>80\%$ [[27](#bib.bib27), [28](#bib.bib28)]) and compatible with HEG for the first generation of QRs [[29](#bib.bib29)].
An important challenge for ensemble-based QRs is the use of non-deterministic
quantum gates, which can be partly compensated by multiplexing
various internal modes of the ensemble memory [[5](#bib.bib5), [16](#bib.bib16)].
Alternatively, the atomic ensemble approach can be supplemented by deterministic atom-photon and atom-atom gates using Rydberg blockade, which can dramatically improve the performance of atomic ensemble approaches and make them compatible with both first and second generations of QRs [[30](#bib.bib30), [31](#bib.bib31)]. (2) The trapped ions, NV centers, and quantum dots all can implement
local quantum operations deterministically [[32](#bib.bib32), [33](#bib.bib33), [34](#bib.bib34), [35](#bib.bib35), [36](#bib.bib36)],
as well as HEG [[37](#bib.bib37), [38](#bib.bib38), [39](#bib.bib39), [40](#bib.bib40)]. In
principle, they are all compatible with the first and second generations
of QRs. Although the coupling efficiency is relatively low for single
emitters compared to ensembles, it can be boosted with
cavity Purcell enhancement [[41](#bib.bib41)] (by two orders of magnitude). With high
coupling efficiency [[42](#bib.bib42), [43](#bib.bib43)], these systems can also be used for
the third generation of QRs. (3) The system of nanophotonic cavity
with individual trapped neutral atoms has recently demonstrated quantum
optical switch controlled by a single atom with high coupling efficiency [[44](#bib.bib44), [45](#bib.bib45)],
which can be used for deterministic local encoding and QEC for the
third generation of QRs. Realization of similar techniques with atom-like emitters are likewise being explored. (4) The opto-electro-mechanical systems have
recently demonstrated efficient coherent frequency conversion between
optical and microwave photons [[46](#bib.bib46), [47](#bib.bib47)] and can potentially
enable using superconducting systems [[48](#bib.bib48)] for reliable
fast local quantum gates for QRs.

## VI Conclusion

In this work, we have classified various QR protocols into
three generations based on different methods for suppressing loss and
operation errors. Introducing the cost function to characterize both
temporal and physical resources, we have systematically compared three
generations of QRs for various experimental parameters, including
coupling efficiency, gate fidelity, and gate times. There are different
parameter regions with drastically different architectural designs
of quantum repeaters with different possible physical implementations. Our work will provide a guideline for the optimal design of quantum networks and help in the extension of quantum network of clocks [[49](#bib.bib49)], interferometric telescopes [[50](#bib.bib50)] and distributed quantum computation [[19](#bib.bib19), [51](#bib.bib51)] to global scales. In the future, the integration of different generations of QRs will enable the creation of a secure quantum internet [[52](#bib.bib52)].

## Acknowledgements

This work was supported by the DARPA Quiness program, ARL CDQI program, ARO, AFOSR, NBRPC (973 program), the Alfred P. Sloan Foundation and the Packard Foundation. We thank Anna Wang, Hong Tang, Ryo Namiki, Prasanta Panigrahi and Steven Girvin for discussions.

## Supplementary Material

## Descriptions of error models

### a) Two-qubit gate error

Local two-qubit gates, e.g. CNOT gate, are characterized by the gate
infidelity $\epsilon\_{G}$. With probability $1-\epsilon\_{G}$ the
desired two-qubit gate is applied, while with probability $\epsilon\_{G}$
the state of the two qubits becomes a maximally mixed state. Mathematically
the imperfect two-qubit operation on qubit i and j can be expressed
as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $U\rho U^{\dagger}=(1-\epsilon\_{G})U\_{ij}\rho U\_{ij}^{\dagger}+\frac{\epsilon\_{G}}{4}Tr\_{ij}[\rho]\otimes I\_{ij},$ |  | (3) |

where $U\_{ij}$ stands for perfect two-qubit operation on qubit i
and j, $Tr\_{ij}[\rho]$ the partial trace over qubit i and j, and
$I\_{ij}$ the identity operator for qubits i and j.

### b) Measurement error

Qubit measurement error is described by the measurement infidelity
$\xi$, which is the probability of a wrong measurement.
The error models for projective measurements of states $|0\rangle$and
$|1\rangle$ are

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle P\_{0}$ | $\displaystyle=$ | $\displaystyle(1-\xi)|0\rangle\langle 0|+\xi|1\rangle\langle 1|$ |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle P\_{1}$ | $\displaystyle=$ | $\displaystyle(1-\xi)|1\rangle\langle 1|+\xi|0\rangle\langle 0|.$ |  | (4) |

The measurement error can be suppressed by introducing an ancillary
qubit for measurement and measuring both the data and the ancillary
qubits. If the measurement outcomes don’t match, it can be considered
as a loss error on that qubit. The contribution of the measurement
error to the overall loss error is negligible given the range of the
gate error rates $(10^{-4}-10^{-2})$ we are considering; if they
match, then the effective measurement error is given by $\frac{\epsilon\_{G}}{4}$[key-7-1].

### c) Memory life-times

In the calculations, the memory qubits are assumed to be perfect,
i.e. their life-time is tremendously longer than any characteristic
times involved in each scheme. In this sense the most demanding scheme
is the first generation, which is optimum at long communication distances,
e.g. $L\_{tot}=10^{4}km$, and high gate errors. The required coherence
time $\tau$ for memory qubits is at least limited by the fundamental
two-way classical communication time between Alice and Bob

|  |  |  |  |
| --- | --- | --- | --- |
|  | $t\_{c1}=\frac{L\_{tot}}{c}\sim 50ms,$ |  | (5) |

where $c=2\times 10^{5}km/s$ is the speed of light in telecom-wavelength
optical fiber. Recent experiments with trapped ions, superconducting
qubits, solid state spins and neutral atoms have demonstrated quantum
memory life-times approaching or exceeding this characteristic value.
For the second generation, the characteristic communication time is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $t\_{c2}=\frac{L\_{att}}{c}\sim 100\mu s$ |  | (6) |

where $L\_{att}=20$km at telecomm wavelength. The corresponding coherence
times are far less demanding than that of the first generation, which
relieves the strong life-time requirements on memory qubits and makes
the two generations more plausible in practice. Note that when the
operation time $t\_{0}$ becomes comparable or larger than the characteristic
communication time, it is then the operation time $t\_{0}$ that puts
limits to the coherence time $\tau$. Third generation QRs are not
limited by the two way communication time because it is a fully one
way communication scheme.

## Quantum entanglement generation, purification and connection

### a) Generation of elementary entangled pairs

#### Heralded entanglement generation with two-photon detection

Using two photon-detection in the middle[key-1, key-8], the success
probability of one trial of generating entanglement between two memory
qubits in neighboring stations is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $p=\frac{1}{2}\eta\_{c}^{2}e^{-L\_{0}/L\_{att}},$ |  | (7) |

where $L\_{0}$ is the spacing between neighboring stations and $\eta\_{c}$
is the coupling efficiency accounting for the emission of the photon
from the memory qubit, “upload” of the photon into the optical
fiber, “download” of the photon from the fiber and the final detection
of photons.

#### Fidelity

Practically an entangled pair generated between neighboring stations
may not be a perfect Bell pair and its state is characterized by a
density matrix

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\rho=a|\varphi^{+}\rangle\langle\varphi^{+}|+b|\varphi^{-}\rangle\langle\varphi^{-}|+c|\psi^{+}\rangle\langle\psi^{+}|+d|\psi^{-}\rangle\langle\psi^{-}|,$ |  | (8) |

where $|\varphi^{\pm}\rangle=\frac{1}{\sqrt{2}}(|00\rangle\pm|11\rangle)$
and $|\psi^{\pm}\rangle=\frac{1}{\sqrt{2}}(|01\rangle\pm|10\rangle)$
are the four Bell states. The fidelity of the pair is thus defined
as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $F\equiv a=\langle\varphi^{+}|\rho|\varphi^{+}\rangle,$ |  | (9) |

Both the first and second generations QRs rely on generating elementary
entangled pairs between neighboring repeater stations and then extending
the entanglement to longer distances. With the technique of HEP (see
the next section), the fidelity of entangled pairs can be boosted
to near-unity at the cost of reducing the total number of them and
purified pairs can be connected to obtain longer entangled pairs or
used as resources for the implementation of remote quantum gates.

However, with imperfect quantum operations and measurements, there
is an upper bound on the fidelity of entangled pairs even with entanglement
purification. It is in general, a function of the density matrix of
raw Bell pairs $\rho$, gate infidelity $\epsilon\_{G}$ and measurement
infidelity $\xi$, and depends on the specific purification protocol
one uses. Using Deutsch purification protocol (see the next section),
the value of this upper bound can be approximated as

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle F\_{u.b.}$ | $\displaystyle=$ | $\displaystyle 1-\frac{5}{4}\epsilon\_{G}-(\frac{9}{4}\xi+\frac{19}{4}\epsilon\_{G})\epsilon\_{G}+\mathcal{O}(\epsilon\_{G,}\xi)^{3}$ |  | (10) |
|  |  | $\displaystyle\approx$ | $\displaystyle 1-\frac{5}{4}\epsilon\_{G},$ |  |

in which we assume depolarized states for input raw Bell pairs. This
approximate expression holds at small $\epsilon\_{G}^{\prime}s$ $(\apprle 1\%)$.
In our calculations and comparison, the temporal resources and physical
resources consumed in obtaining purified pairs at the elementary level
are not accounted; elementary entangled pairs generated between neighboring
stations are assumed to directly take this asymptotic value. The associated
additional cost in the purification can be easily added as an overhead
into the cost function.

### b) Deutsch and Dür purification protocols

In general, despite differences in experimental requirements and efficiencies,
the choice of purification protocols will not change the big picture.
In this paper, we mainly consider two widely used entanglement purification
protocols: Deutsch protocol[key-7] and Dür[key-9] protocol.
Compared to other purification schemes, the Deutsch protocol reaches
higher fidelities with fewer rounds of purification so its upper bound
is used as the fidelity of elementary pairs between neighboring stations.
The Dür purification protocol is very similar to the Deutsch protocol,
except that one of the two pairs, call auxiliary pair, is never discarded
and will be prepared in the same state in each round of purification.
This is sometimes also call “entanglement pumping”. The Dür
purification protocol saves qubit resources by keeping making use
of the auxiliary pair, while the state preparation in each purification
round is costly in time as a trade-off and if one round fails, the
whole purification needs to be started over again.

Here we study the purification with two input pairs characterized
by density matrices $\rho\_{1}$ and $\rho\_{2}$ ($\rho\_{1}=\rho\_{2}$
in the case of Deutsch protocol). As mentioned in the previous section,
we express the density matrices in the Bell basis {$|\varphi^{+}\rangle$,
$|\varphi^{-}\rangle$, $|\psi^{+}\rangle$, $|\psi^{-}\rangle$}.
With input states{$a\_{1},b\_{1},c\_{1},d\_{1}$} and {$a\_{2},b\_{2},c\_{2},d\_{2}$},
in the presence of gate infidelity $\epsilon\_{G}$ and measurement
infidelity $\xi$, the success probability $P$ and the purified state
characterized by the diagonal elements {$a,b,c,d$} are the following

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle P$ | $\displaystyle=$ | $\displaystyle(1-\epsilon\_{G})^{2}\{[\xi^{2}+(1-\xi)^{2}][(a\_{1}+d\_{1})(a\_{2}+d\_{2})+(b\_{1}+c\_{1})(c\_{2}+b\_{2})]+2\xi(1-\xi)[(a\_{1}+d\_{1})(b\_{2}+c\_{2})+(b\_{1}+c\_{1})(a\_{2}+d\_{2})]\}$ |  |
|  |  |  | $\displaystyle+\frac{1}{2}[1-(1-\epsilon\_{G})^{2}]$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle a$ | $\displaystyle=$ | $\displaystyle\frac{1}{P}\{(1-\epsilon\_{G})^{2}[(\xi^{2}+(1-\xi)^{2}](a\_{1}a\_{2}+d\_{1}d\_{2})+2\xi(1-\xi)(a\_{1}c\_{2}+d\_{1}b\_{2})\}+\frac{1}{8}\text{[}1-(1-\epsilon\_{G})^{2})]$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle b$ | $\displaystyle=$ | $\displaystyle\frac{1}{P}\{(1-\epsilon\_{G})^{2}[(\xi^{2}+(1-\xi)^{2}](a\_{1}d\_{2}+d\_{1}a\_{2})+2\xi(1-\xi)(a\_{1}b\_{2}+d\_{1}c\_{2})\}+\frac{1}{8}\text{[}1-(1-\epsilon\_{G})^{2})]$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle c$ | $\displaystyle=$ | $\displaystyle\frac{1}{P}\{(1-\epsilon\_{G})^{2}[(\xi^{2}+(1-\xi)^{2}](b\_{1}b\_{2}+c\_{1}c\_{2})+2\xi(1-\xi)(b\_{1}d\_{2}+c\_{1}a\_{2})\}+\frac{1}{8}\text{[}1-(1-\epsilon\_{G})^{2})]$ |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle d$ | $\displaystyle=$ | $\displaystyle\frac{1}{P}\{(1-\epsilon\_{G})^{2}[(\xi^{2}+(1-\xi)^{2}](b\_{1}c\_{2}+c\_{1}b\_{2})+2\xi(1-\xi)(b\_{1}a\_{2}+c\_{1}d\_{2})\}+\frac{1}{8}\text{[}1-(1-\epsilon\_{G})^{2})]$ |  | (11) |

### c) Entanglement Swapping

Entanglement swapping is used in the first generation and second generation
without encoding to extend the distance of entanglement. With imperfect
CNOT operation and measurements, the diagonal elements {$a,b,c,d$}
in the Bell basis of the resulting state obtained from connecting
deterministically the input pairs {$a\_{1},b\_{1},c\_{1},d\_{1}$} and
{$a\_{2},b\_{2},c\_{2},d\_{2}$} is

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle a$ | $\displaystyle=$ | $\displaystyle(1-\epsilon\_{G})\{(1-\xi)^{2}(a\_{1}a\_{2}+b\_{1}b\_{2}+c\_{1}c\_{2}+d\_{1}d\_{2})+\xi(1-\xi)[(a\_{1}+d\_{1})(b\_{2}+c\_{2})+(b\_{1}+c\_{1})(a\_{2}+d\_{2})]$ |  |
|  |  |  | $\displaystyle+\text{$\xi$}^{2}(a\_{1}d\_{2}+d\_{1}a\_{2}+b\_{1}c\_{2}+c\_{1}b\_{2})\}+\frac{\epsilon\_{G}}{4}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle b$ | $\displaystyle=$ | $\displaystyle(1-\epsilon\_{G})\{(1-\xi)^{2}(a\_{1}b\_{2}+b\_{1}a\_{2}+c\_{1}d\_{2}+d\_{1}c\_{2})+\xi(1-\xi)[(a\_{1}+d\_{1})(a\_{2}+d\_{2})+(b\_{1}+c\_{1})(b\_{2}+c\_{2})]$ |  |
|  |  |  | $\displaystyle+\text{$\xi$}^{2}(a\_{1}c\_{2}+c\_{1}a\_{2}+b\_{1}d\_{2}+d\_{1}b\_{2})\}+\frac{\epsilon\_{G}}{4}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle c$ | $\displaystyle=$ | $\displaystyle(1-\epsilon\_{G})\{(1-\xi)^{2}(a\_{1}c\_{2}+c\_{1}a\_{2}+b\_{1}d\_{2}+d\_{1}b\_{2})+\xi(1-\xi)[(a\_{1}+d\_{1})(a\_{2}+d\_{2})+(b\_{1}+c\_{1})(b\_{2}+c\_{2})]$ |  |
|  |  |  | $\displaystyle+\text{$\xi$}^{2}(a\_{1}b\_{2}+b\_{1}a\_{2}+c\_{1}d\_{2}+d\_{1}c\_{2})\}+\frac{\epsilon\_{G}}{4}$ |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle d$ | $\displaystyle=$ | $\displaystyle(1-\epsilon\_{G})\{(1-\xi)^{2}(a\_{1}d\_{2}+d\_{1}a\_{2}+c\_{1}b\_{2}+b\_{1}c\_{2})+\xi(1-\xi)[(a\_{1}+d\_{1})(b\_{2}+c\_{2})+(b\_{1}+c\_{1})(a\_{2}+d\_{2})]$ |  | (12) |
|  |  |  | $\displaystyle+\text{$\xi$}^{2}(a\_{1}a\_{2}+b\_{1}b\_{2}+c\_{1}c\_{2}+d\_{1}d\_{2})\}+\frac{\epsilon\_{G}}{4}$ |  |

Note that deterministic entanglement swapping is crucial for long
distance quantum communication using QRs. Otherwise the success probability
of entangling two qubits separated by $L\_{tot}$ drops exponentially
as $L\_{tot}$ increases.

## Implementation and optimization

### a) First generation

The first generation of QRs corrects photon loss and operation errors
with HEG and HEP, respectively. To overcome the exponential decay
in key generation rate induced by photon loss, the total distance
$L\_{tot}$ is divided into $2^{n}$ segments (n is called nesting
level[key-1, key-9]) and elementary entangled pairs are generated
within each segment, i.e. over repeater spacing $L\_{0}=\frac{L\_{tot}}{2^{n}}$.
An entangled pair covering the total distance $L\_{tot}$ can be generated
via n levels of entanglement swapping: at each level, two adjacent
entangled pairs are connected so that an entangled pair over twice
the distance is produced.

However, entanglement swapping necessarily reduces the fidelity of
the entangled pairs due to the following two reasons: 1) entanglement
swapping involves CNOT operation and measurements, which themselves
are imperfect in reality and will introduce noise. 2) Despite imperfect
operations, the connection of two imperfect Bell pairs gives a pair
with lower fidelity. So multiple rounds of entanglement purification
may need to be incorporated at each level to maintain the fidelity,
so that the final pair covering $L\_{tot}$ is sufficiently robust
for secure key distribution.

In the optimization, to determine the best scheme from the first generation
QRs, we first fix

* •

  Total distance $L\_{tot}$,
* •

  Coupling efficiency $\eta\_{c}$
* •

  Gate error rate $\epsilon\_{G}$ , and thus the fidelity of elementary
  Bell pairs $F\_{0}=1-\frac{5}{4}\epsilon\_{G}$
* •

  Gate time $t\_{0}$

and we vary the following parameters:

* •

  Number of nesting level: $N$
* •

  Number of rounds of purification at each level: $\overrightarrow{M}=(M\_{0},M\_{1},M\_{2},\cdots,M\_{N})$
* •

  Choice of entanglement purification protocol: Deutsch or Dür

In carrying out the time resource consumed in generating one remote
pair, we adopted similar approximations and derivations as in a previous
work[key-1], with three major changes:

1. 1.

   We allow arbitrary number of rounds of purification at each level
   in the optimization, and hence schemes selected could potentially
   be better optimized.
2. 2.

   Without losing generality, we use four-state protocol, instead of
   six-state protocol, in calculating the secure fraction at the asymptotic
   limit.
3. 3.

   For long-distance quantum communication, we only consider deterministic
   entanglement swapping and take into account the gate operation time
   $t\_{0}$.

For a given set of $N$ and $\overrightarrow{M}$, detailed derivations
of expressions of temporal and physical resource consumed in Deutsch
and Dür are given below.

#### Deutsch et al. entanglement purification protocol

The temporal resource to generate one bit of raw key, $T\_{Deu}$,
can be calculated as follows:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle T\_{Deu}$ | $\displaystyle=T\_{0}\cdot\{$ |  |  |
