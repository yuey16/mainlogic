<!-- fulltext source=oa_pdf slug=arXiv-1402.4848 fetched=2026-09-18T01:23:57+00:00 -->

# **Logic gates at the surface code threshold: Superconducting qubits poised for fault-tolerant quantum computing** 

R. Barends,<sup>1,</sup><sup>_∗_</sup> J. Kelly,<sup>1,</sup><sup>_∗_</sup> A. Megrant,<sup>1</sup> A. Veitia,<sup>2</sup> D. Sank,<sup>1</sup> E. Jeffrey,<sup>1</sup> T. C. White,<sup>1</sup> J. Mutus,<sup>1</sup> A. 

G. Fowler,<sup>1, 3</sup> B. Campbell,<sup>1</sup> Y. Chen,<sup>1</sup> Z. Chen,<sup>1</sup> B. Chiaro,<sup>1</sup> A. Dunsworth,<sup>1</sup> C. Neill,<sup>1</sup> P. O’Malley,<sup>1</sup> 

P. Roushan,<sup>1</sup> A. Vainsencher,<sup>1</sup> J. Wenner,<sup>1</sup> A. N. Korotkov,<sup>2</sup> A. N. Cleland,<sup>1</sup> and John M. Martinis<sup>1</sup> 

> _1Department of Physics, University of California, Santa Barbara, CA 93106, USA_ 

> _2Department of Electrical Engineering, University of California, Riverside, CA 92521, USA_ 

> _3Centre for Quantum Computation and Communication Technology,_ 

_School of Physics, The University of Melbourne, Victoria 3010, Australia_ 

**A quantum computer can solve hard problems - such as prime factoring**<sup>**1,2**</sup> **, database searching**<sup>**3,4**</sup> **, and quantum simulation**<sup>**5**</sup> **- at the cost of needing to protect fragile quantum states from error. Quantum error correction**<sup>**6**</sup> **provides this protection, by distributing a logical state among many physical qubits via quantum entanglement. Superconductivity is an appealing platform, as it allows for constructing large quantum circuits, and is compatible with microfabrication. For superconducting qubits the surface code**<sup>**7**</sup> **is a natural choice for error correction, as it uses only nearest-neighbour coupling and rapidly-cycled entangling gates. The gate fidelity requirements are modest: The per-step fidelity threshold is only about 99%. Here, we demonstrate a universal set of logic gates in a superconducting multi-qubit processor, achieving an average single-qubit gate fidelity of 99.92% and a two-qubit gate fidelity up to 99.4%. This places Josephson quantum computing at the fault-tolerant threshold for surface code error correction. Our quantum processor is a first step towards the surface code, using five qubits arranged in a linear array with nearest-neighbour coupling. As a further demonstration, we construct a five-qubit GreenbergerHorne-Zeilinger (GHZ) state**<sup>**8,9**</sup> **using the complete circuit and full set of gates. The results demonstrate that Josephson quantum computing is a high-fidelity technology, with a clear path to scaling up to large-scale, fault-tolerant quantum circuits.** 

The high fidelity performance we demonstrate here is achieved through a combination of highly coherent qubits, a straightforward interconnection architecture, and a novel implementation of the two-qubit controlled-phase (CZ) entangling gate. The CZ gate uses a fast but adiabatic frequency tuning of the qubits<sup>10</sup> , which is easily adjusted yet minimises decoherence and leakage from the computational basis [Martinis, J., _et al._ , in preparation]. We note that previous demonstrations of two-qubit gates achieving better than 99% fidelity used fixed-frequency qubits: Systems based on nuclear magnetic resonance and ion traps have shown two-qubit gates with fidelities of 99.5%<sup>11</sup> and 99.3%<sup>12</sup> . Here, the tuneable nature of the qubits and their entangling gates provides, remarkably, both high fidelity and fast control. 

Superconducting integrated circuits give flexibility in building quantum systems due to the macroscopic nature of the electron condensate. As shown in Fig. 1, we have designed a processor consisting of five Xmon qubits with nearestneighbour coupling, arranged in a linear array. The cross- 

shaped qubit<sup>14</sup> offers a nodal approach to connectivity while maintaining a high level of coherence (see Supplementary Information for decoherence times). Here, the four legs of the cross allow for a natural segmentation of the design into coupling, control and readout. We chose a modest inter-qubit capacitive coupling strength of _g/_ 2 _π_ = 30 MHz and use alternating qubit idle frequencies of 5.5 and 4.7 GHz, enabling a CZ gate in 40 ns when two qubits are brought near resonance, while minimising the effective coupling to 0 _._ 3 MHz when the qubits are at their idle points. Rotations around the X and Y axes in the Bloch sphere representation are performed using pulses on the microwave (XY) line, while Z axis rotations are achieved by a flux-bias current on the frequencycontrol (Z) line. We use dispersive measurement<sup>15</sup> where each qubit is coupled to a readout resonator, each with a different resonance frequency, enabling simultaneous readout using frequency-domain multiplexing through a single coplanar waveguide<sup>16</sup> [Mutus, J., _et al._ , in preparation]. The modularity of this architecture makes it straightforward to integrate more qubits in the circuit. 

We characterise our gate fidelities using Clifford-based randomised benchmarking<sup>11,17,18</sup> . The Clifford group is a set of rotations that evenly samples the Hilbert space, thus averaging across errors. For the single-qubit case the Cliffords are comprised of _π_ , _π/_ 2 and 2 _π/_ 3 rotations, see Supplementary Information. In randomised benchmarking, a logic gate is characterised by measuring its performance when interleaved with many random sequences of gates, making the measured fidelity resilient to state preparation and measurement (SPAM) errors. We perform a control experiment on a ground-state qubit by: I) generating a random sequence of _m_ Cliffords, II) appending the unique recovery Clifford ( _C_ r) that makes the ideal sequence the identity, and III) averaging the experimental sequence fidelity, the final ground state population, over _k_ different sequences<sup>18,19</sup> . The resulting reference sequence fidelity _F_ ref is fit to _F_ ref = _Ap_ ref<sup>_m_</sup> + _B_ , where _p_ ref is the sequence decay, and state preparation and measurement errors are captured in the parameters _A_ and _B_ . The average error per Clifford of the reference is given by _r_ ref = (1 _−p_ ref )( _d−_ 1) _/d_ , with _d_ = 2<sup>_N_qubits</sup> . We then measure the fidelity of a specific gate by interleaving this test gate with _m_ random Cliffords and performing the same measurement. The sequence decay _p_ gate then gives the gate error _r_ gate = (1 _− p_ gate _/p_ ref )( _d −_ 1) _/d_ . 

The benchmarking results for the single-qubit gates are shown in Fig. 2. We generate the Cliffords using microwave pulses, from a basis set of _π_ and _π/_ 2 rotations around the X 

2 

and Y axes (Supplementary Information). We benchmark X and Y axis _π_ and _π/_ 2 rotations, the Hadamard gate (implemented with Y/2 followed by X), and Z axis rotations using pulses on the frequency control line. From the data in Fig. 2 we extract the individual gate fidelities listed in the legend. We find an average fidelity of 99.92 % over all gates and qubits (Supplementary Information). The best fidelities are achieved by optimising the pulse amplitude and frequency, and minimising 2-state leakage<sup>20</sup> [Kelly, J., _et al._ , in preparation]. 

We have also measured the performance when simulta- 



<!-- Start of picture text -->
(a)<br>XY<br>resonator<br>Q4<br>Q3 Z<br>readout out Q1Q2 Z Z ZXYXY<br>Q0 Z XY<br>readout in<br>XY<br>(b) readout line<br>Readout<br>resonator<br>Q0 Q1 Q2 Q3 Q4<br>Qubits<br>Control<br>XY Z XY Z XY Z XY Z Z XY<br>(c) (I) (II) (III)<br>U CZ:<br>1 1 1-1<br>1.5 mm<br>Frequency<br><!-- End of picture text -->

FIG. 1: **Architecture.** (a) Optical image of the integrated Josephson quantum processor, consisting of Al (dark) on sapphire (light). The five cross-shaped devices are the Xmon variant of the transmon qubit<sup>13</sup> , labelled Q0 _−_ Q4, placed in a linear array. To the left of the qubits are five meandering coplanar waveguide resonators used for individual state readout. Control wiring is brought in from the contact pads at the edge of the chip, ending at the right of the qubits. (b) Circuit diagram. Our architecture employs direct, nearestneighbour coupling of the qubits (red/orange), made possible by the nodal connectivity of the Xmon qubit. Using a single readout line, each qubit can be measured using frequency-domain multiplexing (blue). Individual qubits are driven through capacitively-coupled <u>microwave</u> control lines (XY), and frequency control is achieved through inductively-coupled dc lines (Z) (purple). (c) Schematic representation of an entangling operation using a controlled-Z gate with unitary representation _U_ CZ: (I) Qubits at rest, at distinct frequencies with minimal interaction. (II) When brought near resonance, the state-dependent frequency shift brings about a rotation conditional on the qubit states. (III) Qubits are returned to their rest frequency. 

neously operating nearest or next-nearest qubits<sup>21</sup> , operating them at dissimilar idle frequencies to minimise coupling. The fidelities are essentially unchanged, with small added errors _<_ 2 _·_ 10<sup>_−_4</sup> (Supplementary Information), showing a high degree of addressability for this architecture. 

The two-qubit CZ gate is implemented by tuning one qubit in frequency along a “fast adiabatic” trajectory which takes the two-qubit _|_ 11 _⟩_ state close to the avoided-level crossing with the _|_ 02 _⟩_ state, yielding a state-dependent relative phase shift. This implementation is the natural choice for weakly anharmonic, frequency-tunable qubits, as the other computational states are left unchanged<sup>8,22,23</sup> . Having the CZ gate adiabatic as well as fast is advantageous. An adiabatic trajectory is easily optimised and allows for exponentially suppressing leakage into the non-computational _|_ 02 _⟩_ -state with gate duration. Having a fast CZ gate minimises the accumulation of errors from decoherence and unwanted entanglement with other circuit elements, favourable for fault-tolerance. 



<!-- Start of picture text -->
(a) (b)<br>m I Q<br>Reference C C r<br>(   )<br>m -X/2 Y/2 Y X Y/2 X/2 I Y<br>Interleaved H C H C r C C C C C r<br>(      )<br>reference  m =4<br>(c) Gate Fidelity Gate Fidelity<br>0.9 Z 0.9994 X 0.9992<br>Z/2 0.9998 -X 0.9992<br>2T 0.9994 X/2 0.9993<br>0.8 H 0.9991 -X/2 0.9993<br>I 0.9995 Y 0.9993<br>-Y 0.9991<br>Y/2 0.9995<br>0.7 -Y /2 0.9995<br>0.6 0.999<br>0. 998<br>0 100 200 300 400 500<br>m  - Number of Cliffords  C 1<br>reference<br>Sequence Fidelity<br><!-- End of picture text -->

FIG. 2: **Single qubit randomised benchmarking.** (a) A reference experiment is performed by generating a sequence of _m_ random Cliffords, which are inverted by the recovery Clifford C _r_ . A specific gate ( _H_ ) is tested using a sequence that interleaves _H_ with _m_ random Cliffords. The difference between interleaved and reference decay gives the gate fidelity. (b) Representative pulse sequence for a set of four Cliffords and their recovery, generated with _π_ and _π/_ 2 rotations about _X_ and _Y_ , displaying both the real (I) and imaginary (Q) microwave pulse envelopes before up-conversion by quadrature mixing to the qubit frequency. (c) Randomised benchmarking measurement for the set of single-qubit gates for qubit Q2, plotting reference and gate fidelities as a function of the sequence length _m_ ; the fidelity for each value of _m_ was measured for _k_ = 40 different sequences. The fit to the reference set yields an average error per Clifford of _r_ ref = 0 _._ 0011, consistent with an average gate fidelity of 1 _− r_ ref _/_ 1 _._ 875 = 0 _._ 9994 (Supplementary Information). The dashed lines indicate the thresholds for exceeding gate fidelities of 0.998 and 0.999. The fidelities for each of the single-qubit gates are tabulated in the legend, we find that all gates have fidelities greater than 0.999. Standard deviations are typically 5 _·_ 10<sup>_−_5</sup> . 

3 



<!-- Start of picture text -->
(a) l0B2A><br>2 g /p<br>l1B1A><br>43 ns<br>Detuning of Qubit A<br>(b)<br>0.8<br>Gate Fidelity<br>CZ 0.9944(5)<br>0.6<br>0.4<br>0.98 0.99<br>0.2<br>0 20 40 60 80<br>m  - Number of Cliffords  C 2<br>(c) XY<br>Z<br>XY<br>Z<br>iSWAP Clifford<br>m =55: 500 gates<br>adiabatic trajectory<br>non-adiabatic<br>leakage<br>reference<br>Frequency<br>Time<br>Sequence Fidelity<br><!-- End of picture text -->

FIG. 3: **CZ gate physics and randomised benchmarking results.** (a) We use the the _|_ 1B1A _⟩_ and _|_ 0B2A _⟩_ avoided level crossing to implement a high-fidelity CZ gate, with the fast adiabatic tuning of qubit A giving a selective _π_ phase change of the _|_ 1B1A _⟩_ state. The energy level diagram shows qubit A approaching and leaving the avoided level crossing from above (top, blue dashed line), following a fast (43 ns) yet effectively adiabatic trajectory (bottom, solid blue line). Unwanted state leakage from _|_ 1 _B_ 1 _A⟩_ to _|_ 0 _B_ 2 _A⟩_ (red dashed line) is minimised by adjusting the trajectory. (b) Randomised benchmarking data ( _k_ = 100) of the CZ gate for the qubit pair Q2 and Q3, using the two-qubit Clifford group _C_ 2 (Supplementary Information); reference data in black ( _r_ ref = 0 _._ 0189), interleaved in blue ( _rC_ 2+CZ = 0 _._ 0244). Dashed lines indicate the thresholds for gate fidelities of 0.98 and 0.99. We find a CZ gate fidelity of 0 _._ 9944 _±_ 0 _._ 0005 (uncertainty from bootstrapping). (c) Coherent microwave (XY) and frequency (Z) control of the quantum state while performing a complex two-qubit algorithm; the sequence contains over 500 gates, corresponding to the characteristic reference decay of _m_ = 55, and is over 7 _µ_ s long. The right panel shows an example Clifford from the iSWAP class, comprised of single qubit rotations and two CZ gates (Supplementary Information). 

The benchmarking results of the CZ gate are shown in Fig. 3b. Similar to the single-qubit case, we generate sequences of two-qubit Cliffords to produce a reference curve, 

then interleave the CZ gate to extract the fidelity. An example pulse sequence for an _m_ = 55 Clifford sequence is shown in Fig. 3c. We find a CZ gate fidelity of up to 99.44 _±_ 0.05 %, consistent with the average error per Clifford (Supplementary Information). We find fidelities between 99.0-99.44% on all four pairs of nearest-neighbour qubits (Supplementary Information). This comprises a clear demonstration of high-fidelity single- and two-qubit gates in a multi-qubit Josephson quantum processor. The two-qubit gate fidelity compares well with the highest values reported for other mature quantum systems: For nuclear magnetic resonance and ion traps, entangling gate fidelites are as high as 99.5% and 99.3%<sup>11,12</sup> . Importantly, we have verified by simulation that the experimentally obtained gate fidelities are at the threshold for surface code quantum error correction, see Supplementary Information. 

We are optimistic that we can improve upon these gate fidelities with modest effort. The CZ gate fidelity is limited by three error mechanisms: Decoherence (55% of the total error), control error (24%), and state leakage (21%), see Supplementary Information. Decoherence can be suppressed with enhanced materials and optimised fabrication<sup>24,25</sup> . Imperfections in control arise primarily from reflections and stray inductances in wiring, and can be improved using conventional microwave techniques. Given the adiabatic nature of the CZ gate, 2-state leakage can be suppressed by slightly increasing the gate time [Martinis, J., _et al._ , in preparation]. 

We showcase the modularity of this set of quantum logic gates by constructing a maximally-entangled GHZ state across all five qubits in our processor, as shown in Fig. 4a. The _N_ -qubit GHZ state _|_ GHZ _⟩_ = ( _|_ 0 _⟩_<sup>_⊗N_</sup> + _|_ 1 _⟩_<sup>_⊗N_</sup> ) _/√_ 2 is constructed with single and two-qubit gates, using simultaneous control and readout of all qubits. This algorithm is shown in Fig. 4b, where the state is assembled by entangling one additional qubit at a time. The algorithm is highly sensitive to control error and decoherence on any computational element. We fully characterise the Bell and GHZ states by using quantum state tomography<sup>9</sup> , where quadratic maximum likelihood estimation is used to extract each density matrix ( _ρ_ ) from the measurement data, while satisfying the physical constraints that _ρ_ be Hermitian, unit trace, and positive semi-definite (Supplementary Information). The density matrices are plotted in the traditional cityscape style, and show significant elements only at the ideal locations. We find state fidelities Tr � _√ρ_ ideal _<u>ρ</u>_<sup>_√_</sup> _<u>ρ</u>_ ideal� of 99 _._ 5 _±_ 0 _._ 4 %, 96 _._ 0 _±_ 0 _._ 5 %, 86 _._ 3 _±_ 0 _._ 5 % and 81 _._ 7 _±_ 0 _._ 5 % for the _N_ = 2 Bell state and _N_ = 3 _,_ 4 _,_ 5 GHZ states. A GHZ state fidelity over 50 % satisfies the criterion for genuine entanglement<sup>26</sup> . It is interesting to note that the ratio of the off-diagonal to diagonal amplitudes _|ρ|_ 0 _⟩⊗N ,|_ 1 _⟩⊗N |_<sup>2</sup> _/ρ|_ 0 _⟩⊗N ,|_ 0 _⟩⊗N ρ|_ 1 _⟩⊗N ,|_ 1 _⟩⊗N_ have the values 0 _._ 99, 0.98, 0.99 and 0.99, suggesting that dephasing is small and/or uncorrelated. The five-qubit GHZ state is the largest multi-qubit entanglement demonstrated to date in the solid state<sup>8,9</sup> , with state fidelity similar to results obtained in ion traps<sup>27</sup> . This demonstrates that complex quantum states can be constructed with high fidelity in a modular fashion, highlighting the potential for more intricate algorithms on this multi-purpose quantum processor. 

We have shown single and two-qubit gates with fidelities 

4 



<!-- Start of picture text -->
fidelity: 0.995(4) 0.960(5) 0.863(5) 0.817(5)<br>Re(r) 0.0 Re(r) 0.5<br>0.5<br>0.25<br>0.0<br>0<br>0 1<br>0 1 1<br>0 1 0 1<br>1 1 1 0<br>0 0<br>l0> Y/2<br>l0> -Y/2 Y/2<br>l0> -Y/2 Y/2<br>l0> -Y/2 Y/2<br>l0> -Y/2 Y/2<br><!-- End of picture text -->

FIG. 4: **Quantum state tomography and generation of the GHZ state.** Top row: Real part of the density matrix _ρ_ for the _N_ = 2 Bell state and the _N_ = 3, 4 and 5 GHZ states, measured by quantum state tomography. Ideal density matrix elements are transparent, with value 0.5 at the four corners. Bottom row: Algorithm used to construct the states. See Supplementary Information for Im( _ρ_ ), the Pauli operator representation, and the full gate sequence, which includes Hahn spin-echo pulses. 

at the fault-tolerant threshold for the surface code in an integrated circuit quantum processor. With this demonstration, Josephson quantum devices are now poised to explore faulttolerant, multi-qubit computing. Extending the linear array of qubits to larger qubit numbers is straightforward, and generating a two-dimensional grid of qubits appears to be mostly a (significant) engineering challenge. In a separate experiment, we have demonstrated fast, high-fidelity qubit state measurement [Jeffrey, E., _et al._ , in preparation], in a design that can be seamlessly integrated with this architecture. The combination of high-fidelity logic, a multi-qubit architecture, and fast and accurate qubit readout provides the essential ingredients for a Josephson surface code quantum computer. 

**Acknowledgements** We thank F. Wilhelm, D. Egger, and J. Baselmans for helpful discussions. We are indebted to Erik Lucero for photography of the device. This work was supported by the Office of the Director of National Intelligence (ODNI), Intelligence Advanced Research Projects Activity (IARPA), through the Army Research Office grants W911NF09-1-0375 and W911NF-10-1-0334. All statements of fact, opinion or conclusions contained herein are those of the au- 

thors and should not be construed as representing the official views or policies of IARPA, the ODNI, or the U.S. Government. Devices were made at the UC Santa Barbara Nanofabrication Facility, a part of the NSF-funded National Nanotechnology Infrastructure Network, and at the NanoStructures Cleanroom Facility. 

**Author contributions** R.B. and J.K designed the sample, performed the experiment and analysed the data. J.K., A.E.M., and R.B. fabricated the sample. R.B., J.K., J.M.M., and A.N.C. co-wrote the manuscript. A.V. and A.N.K. provided assistance with randomised benchmarking. A.G.F. verified the experimental gate fidelities to be at the surface code threshold. All authors contributed to the fabrication process, experimental set-up and manuscript preparation. 

**Additional information** The authors declare no competing financial interests. Supplementary information accompanies this paper on [weblink to be inserted by editor]. Reprints and permissions information is available at [weblink to be inserted by editor]. Correspondence and requests for materials should be addressed to R.B., J.K or J.M.M. 

> _∗_ These authors contributed equally to this work 

> 1 Vandersypen, L. M. K. _et al._ Experimental realization of Shor’s quantum factoring algorithm using nuclear magnetic resonance. _Nature_ **414** , 883-887 (2001). 

- 2 Lucero, E. _et al._ Computing prime factors with a Josephson phase qubit quantum processor. _Nature Physics_ **8** , 719-723 (2012). 

- 3 Jones, J., Mosca M., & Hansen R. Implementation of a quantum search algorithm on a quantum computer. _Nature_ **393** , 334-346 (1998). 

- 4 Chuang, I. L., Gershenfeld, N., & Kubinec, M. Experimental implementation of fast quantum searching. _Phys. Rev. Lett._ **80** , 3408 

(1998). 

- 5 Feynman, R. P. Simulating physics with computers. _Int. J. Th. Phys._ **21** , 467-488 (1982). 

- 6 Nielsen, M. A., & Chuang, I. L. _Quantum Computation and Quantum Information._ Cambridge university press, Cambridge, U. K. (2010). 

- 7 Fowler, A. G., Mariantoni, M., Martinis, J. M., & Cleland, A. N. Surface codes: Towards practical large-scale quantum computation. _Phys. Rev. A_ **86** , 03232 (2012). 

- 8 DiCarlo, L., _et al._ Preparation and measurement of three-qubit entanglement in a superconducting circuit. _Nature_ **467** , 574-578 

5 

(2010). 

- 9 Neeley, M., _et al._ Generation of three-qubit entangled states using superconducting phase qubits. _Nature_ **467** , 570-573 (2010). 

- 10 Ghosh, J., _et al._ High-fidelity controlled- _σ_ Z gate for resonatorbased superconducting quantum computers. _Phys. Rev. A_ **87** , 022309 (2013). 

- 11 Ryan, C. A., Laforest, M., & Laflamme, R. Randomized benchmarking of single-and multi-qubit control in liquid-state NMR quantum information processing. _New J. Phys._ **11** , 013034 (2009). 

- 12 Benhelm, J., Kirchmair, G., Roos, C. F., & Blatt, R. Towards faulttolerant quantum computing with trapped ions. _Nature Physics_ **4** , 463-466 (2008). 

- 13 Koch, J., _et al._ Charge-insensitive qubit design derived from the Cooper pair box, _Phys. Rev. A_ **76** , 042319 (2013). 

- 14 Barends, R. _et al._ Coherent Josephson qubit suitable for scalable quantum integrated circuits. _Phys. Rev. Lett._ **111** , 080502 (2013). 

- 15 Wallraff, A. _et al._ Strong coupling of a single photon to a superconducting qubit using circuit quantum electrodynamics. _Nature_ **431** , 162-167 (2004). 

- 16 Chen, Y., _et al._ Multiplexed dispersive readout of superconducting phase qubits. _Appl. Phys. Lett._ **101** , 182601 (2012). 

- 17 Brown, K. R. _et al._ Single-qubit-gate error below 10 _−_ 4 in a trapped ion. _Phys. Rev. A._ **84** , 030303 (2011). 

- 18 C´orcoles, A. D., _et al._ Process verification of two-qubit quantum gates by randomized benchmarking. _Phys. Rev. A_ **87** , 030301. 

(2013). 

- 19 Magesan, E., Gambetta, J. M., & Emerson, J. Scalable and robust randomized benchmarking of quantum processes. _Phys. Rev. Lett._ **106** , 180504 (2011). 

- 20 Lucero, E. _et al._ Reduced phase error through optimized control of a superconducting qubit. _Phys. Rev. A 82_ , 042339 (2010). 

- 21 Gambetta, J. M. _et al._ Characterization of addressability by simultaneous randomized benchmarking. _Phys. Rev. Lett._ **109** , 240504 (2012). 

- 22 Mariantoni, M. _et al._ Implementing the quantum von Neumann architecture with superconducting circuits. _Science_ **334** , 61-65 (2011). 

- 23 Strauch, F. W. _et al._ Quantum Logic Gates for Coupled Superconducting Phase Qubits. _Phys. Rev. Lett._ **91** , 167005 (2003). 

- 24 Megrant, A. _et al._ Planar Superconducting Resonators with Internal Quality Factors above One Million. _Appl. Phys. Lett._ **100** , 115310 (2012). 

- 25 Sendelbach, S., Hover, D., M¨uck, M., & McDermott, R. Complex inductance, excess noise, and surface magnetism in dc SQUIDs. _Phys. Rev. Lett._ **103** , 117001 (2009). 

- 26 G¨uhne, O., & Seevinck, M. Separability criteria for genuine multiparticle entanglement. _New J. Phys._ **12** , 053002 (2010). 

- 27 Monz, T. _et al._ 14-qubit entanglement: Creation and coherence. _Phys. Rev. Lett._ **106** , 130506 (2011). 

# **Supplementary Information** 

## **DEVICE FUNDAMENTALS** 

## **Coherence Times** 

## **Fabrication** 

The devices are made in a process similar to the fabrication steps outlined in Ref. [1], with an important improvement: we have added crossovers to suppress stray microwave chip modes by tying the ground planes together with low impedance connections. Otherwise, the many control wires in our chip could lead to segmentation of the ground plane, and the appearance of parasitic slotline modes [2]. The device is made in a fivestep deposition process, (I) Al deposition and control wiring etch, (II) crossover dielectric deposition, (III) crossover Al deposition, (IV) Qubit capacitor and resonator etch, (V) Josephson junction deposition. The qubit capacitor, ground plane, readout resonators, and control wiring are made using molecular beam epitaxy (MBE)-grown Al on sapphire [3]. The control wiring is patterned using lithography and etching with a BCl3/Cl2 reactive ion etch. A 200 nm thick layer of SiO2 for the crossover dielectric is deposited in an e-beam evaporator, followed by lift-off. We fabricate crossovers on all the control wiring, using a SiO2 dielectric that has a non-negligible loss tangent. An in-situ Ar ion mill is used to remove the native AlOx insulator, after which a 200 nm Al layer for the crossover wiring is deposited in an e-beam evaporator, followed by lift-off. We used 0.9 _µ_ m i-line photoresist, lift-off is done in N-methyl-2-pyrrolidone at 80<sup>_◦_</sup> C. A second BCl3/Cl2 etch is used to define the qubit capacitor and resonators; this step is separate from the wiring etch to prevent the sensitive capacitor from seeing extra processing. Lastly, we use electron beam lithography, an in-situ Ar ion mill, and double angle shadow evaporation to deposit the Josephson junctions, in a final lift-off process. See Ref. [1] for details. 

Energy relaxation times _T_ 1 of all qubits are shown in Fig. S1, measured over a frequency range from 4 to 6 GHz. We find typical _T_ 1 values between 20 and 40 _µ_ s. Variations in _T_ 1 arise predominantly from the qubit interacting incoherently with weakly coupled two-level defects, as discussed in Ref. [1]. In this previous work we found that larger area (with longer and wider legs) Xmon qubits showed higher _T_ 1 values as well as large, frequency-specific suppressions in the energy coherence: for certain frequencies the _T_ 1 would decrease to values below 10 _µ_ s. We attribute these large suppressions to chip modes, arising from imbalances in the microwave control lines, to which the larger Xmon geometries can couple more strongly. The data in Fig. S1 exhibit fewer of such suppressions; we believe that this improvement is due to the addition of crossovers. 

We have investigated the Ramsey dephasing times versus frequency for qubit Q1. The Ramsey decay envelope is measured by phase tomography (see Ref. [1]) and fitted to the function exp[ _−t/Tφ,_ 1 _−_ ( _t/Tφ,_ 2)<sup>2</sup> ]. Slow, Gaussian dephasing is captured in _Tφ,_ 1, and fast dephasing, from white noise as well as energy relaxation, is captured in _Tφ,_ 2. Typical dephasing times are plotted in Fig. S2. We find a fast dephasing time on the order of 10 _µ_ s; this value is below the energy coherence time, and may be due to white noise from the room temperature control electronics. The slow, Gaussian dephasing times are consistent with a 1 _<u>/f</u>_ -spectrum with a spectral density of _S_ Φ(1 Hz) = 1 _._ 1 _µ_ Φ0 _/√_ Hz. 

## **Qubit Frequencies and Coupling** 

Qubit frequencies and nearest neighbour coupling strengths are listed in Table S1. 

## **Z Crosstalk** 

TABLE S1: Qubit frequencies and nonlinearities ( _f_ 21 _− f_ 10) at the zero flux bias (degeneracy point) and coupling strengths in MHz. The coupling strength is measured at frequencies between 4.2 and 4.7 GHz. We find a typical next-nearest neighbour coupling of _g/_ 2 _π_ = 1 _._ 3 MHz, consistent with microwave circuit simulations. 

|qubits|Q0|Q1|Q2|Q3|Q4|
|---|---|---|---|---|---|
|f10|5805|5238|5780|5060|5696|
|nonlinearity|-217|-226|-214|-212|-223|
|_g_01_/_2_π_(4.22 GHz)|27|.7||||
|_g_12_/_2_π_(4.70 GHz)||3|0.8|||
|_g_23_/_2_π_(4.66 GHz)|||3|0.4||
|_g_34_/_2_π_ (4.65 GHz)||||30|.9|



We measure a crosstalk between the frequency Z control lines and qubits that is small, approximately 1 _−_ 2%. After adding compensation pulses to orthonormalise the control, we find a remnant crosstalk of below 10<sup>_−_4</sup> . The crosstalk matrix _M_ Φ is shown below, defined as: Φactual = _M_ ΦΦideal, with Φ the flux threaded through each qubit’s superconducting quantum interference device (SQUID) loop. 



**EXPERIMENTAL SETUP** 

## **FLATTENING THE Z RESPONSE** 

The wiring diagram and circuit components are shown in Fig. S3. 



<!-- Start of picture text -->
60<br>40 Q0<br>30<br>20<br>10<br>6<br>60<br>40 Q1<br>30<br>20<br>10<br>6<br>60<br>40 Q2<br>30<br>20<br>10<br>6<br>60<br>40 Q3<br>30<br>20<br>10<br>6<br>60<br>40 Q4<br>30<br>20<br>10<br>6<br>4.0 4.5 5.0 5.5 6.0<br>f (GHz)<br>1<br>T (s)m<br>1<br>T (s)m<br>1<br>T (s)m<br>1<br>T (s)m<br>1<br>T (s)m<br><!-- End of picture text -->

FIG. S1: **Energy Relaxation for Xmon Qubits.** Frequency dependence of _T_ 1 for all qubits. The frequency step size is 2 MHz. The values for _T_ 1 are generally in the 20-40 _µ_ s range. The depression at 4.36 GHz in qubit Q3 is due to a coherently coupled junction defect. 

Imperfections in the frequency control wiring can cause ripples after a pulse. Left unchecked, these can affect gate fidelity significantly, appearing as single qubit phase errors, see Fig. S4. We employ a two-step procedure to correct for these non-idealities. We first calibrate the room temperature electronics by measuring the unit step (Heaviside step) response at the output of the Z control board. 

With the board response corrected by deconvolution, we measure the qubit phase as a function of time ∆ _τ_ after the end of a unit step. This probes the transfer function of the fridge wiring, contact pads and on-chip control lines. When no unit step is applied, the X/2 pulse rotates the qubit state onto the Y axis. When applying a unit step, deviations in frequency will cause the Bloch sphere vector to deviate from the Y axis. A subsequent Y/2 pulse will make this apparent in the measured excited state probability. We note that this measurement is first order sensitive to small deviations – the difference in probability denotes the phase deviation (∆ _φ ≈_ ∆ _P|_ 1 _⟩_ ) – whereas Ramsey and quantum state tomography are second order sensitive: The _π/_ 2 pulses used in tomography project the state onto the Z axis, thus the reconstruction of the phase or state is done from probabilities ( _P ≈_ 1 _−_ ∆ _φ_<sup>2</sup> _/_ 2) which are second order sensitive to _φ_ . 

We find that the transfer function can be described by an exponential response with two timescales. Typical values are 100 ns and 5 ns. The longer timescale is consistent with the _L/R_ time arising from the bias tee, with _L ≈_ 6 _µ_ H and _R_ = 50 Ω. We believe that the short timescale arises from reflections. The impulse response of an imperfect wire with reflection _r_ , placed time _T_ away from the wire’s end is _H_ ( _ω_ ) = 1 _− r_ +<sup>�</sup><sup>_∞_</sup> _k_ =1<sup>_rk_exp(</sup><sup>_−_2</sup><sup>_ikωT_);atlowfrequen-</sup> cies this can be approximated by the impulse response function _h_ ( _t_ ) _∝_ exp( _−t/_ 2 _aT_ ) _u_ ( _t_ ). Assuming reflection coefficients on 



<!-- Start of picture text -->
Tf,1<br>10<br>Tf,2<br>1<br>4.0 4.5 5.0<br>qubit frequency (GHz)<br>Ramsey dephasing time (s)m<br><!-- End of picture text -->

FIG. S2: **Ramsey dephasing.** Frequency dependence of the slow ( _Tφ,_ 1) and fast ( _Tφ,_ 2) Ramsey dephasing times of qubit Q1. Flux bias points Φ _/_ Φ0 range from 0.1 to 0.28, and _δf_ 10 _/δ_ (Φ _/_ Φ0) range from -16 to -50 GHz. 



<!-- Start of picture text -->
9 11<br>A+ 250 MHz + 12<br>A- 250 MHz - I 1 8<br>LO Q 300K<br>B+ 250 MHz +<br>B- 250 MHz -<br>Components List<br>10 77K<br>A+ 250 MHz + Commercial<br>A- 250 MHz - I 2 1 Marki IQ-0307<br>B+B- 250 MHz250 MHz +- LO Q 7.5 GHz 18 5 4K 342 Marki FLP-0750 Mini Circuits VLFX-225Mini Circuits VLFX-500<br>13<br>30mK 5 Low Noise Factory LNC4_8A<br>4 14<br>Voltage  6 QuinStar CTH1392KS<br>Source 7 Marki FLP-0750<br>6 P 8 Miteq AFS3-0010200-22-10P-4<br>A+ 110 MHz + 3 17<br>A- 110 MHz - 225 MHz Custom Made<br>B+ 110 MHz + 15 9 Analog to Digital Converter (ADC)<br>B- 110 MHz - 225MHz 7 1011 Digital to Analog Converter (DAC)Gaussian Filter<br>A+ 250 MHz + 16 12 Differential Amplifier<br>A- 250 MHz - I 13 Voltage Source ("Fastbias Card")<br>LO Q 7.5 GHz 19 14 Copper Powder & Light Tight LPF<br>B+ 250 MHz + 15 Light Tight LPF<br>B- 250 MHz - ProcessorQuantum  1716 DC Bias TParametric Amplifier<br>18 1.5k Cold Resistor<br>19 Magnetic Shield<br>Repeat for other  20 “IR-black” Coating<br>four Qubits 20<br>Dilution Refrigerator<br>Readout Analyzer ADC<br>Readout<br>DAC<br>Readout Generator RC<br>20dB 20dB 20dB HEMT<br>20dB 0.5 GHz CuP 20dB<br>10dB 20dB<br>3dB 10dB<br>Z<br>DAC IR IR IR IR<br>7.5 GHz 7.5 GHz 7.5 GHz<br>6dB<br>XY<br>Qubit Control DAC<br><!-- End of picture text -->

FIG. S3: **Electronics and Control Wiring.** Diagram detailing all of the control electronics, control wiring, and filtering for the experimental setup. Each qubit uses one digital to analog converter (DAC) channel for each of the X, Y, and Z rotations. Additionally, we use a DC bias tee to connect a voltage source to each qubit frequency control line to give a static frequency offset. All five qubits are read out using frequency-domain multiplexing on a single measurement line. The readout DAC generates five measurement tones at the distinct frequencies corresponding to each qubit’s readout resonator. The signal is amplified by a wideband parametric amplifier [Mutus, J. _et al._ in preparation], a high electron mobility transistor (HEMT), and room temperature amplifiers before demodulation and state discrimination by the analog to digital converter (ADC). All control wires go through various stages of attenuation and filtering to prevent unwanted signals from disturbing the quantum processor. 

the order of -10 dB and round trip times 2 _T_ between qubit and mixing plate electronics on the order several ns, the effective decay time 2 _rT_ is on the order of a few ns. 

With the corrections in place, by deconvolving both the board response and fridge wiring, remnant control pulse ripples are suppressed to below 10<sup>_−_4</sup> : We find qubit phase deviations consistent with a 30 kHz drift after applying a 0.5 GHz detuning step pulse, see Fig. S4. The calibrations discussed above are key for obtaining accurate CZ gates. 

## **SINGLE QUBIT AND TWO-QUBIT GATE FIDELITIES OF ALL QUBITS** 

A comprehensive listing of all single qubit gate fidelities of all qubits is shown in Table S2, the gate durations are in Table S3. A listing of all CZ gate fidelities can be found in Table S4. 

## **VERIFYING EXPERIMENTAL FIDELITIES ARE AT THE SURFACE CODE THRESHOLD** 

Nominally, the threshold fidelity of the surface code is 0.99 [7], provided one assumes there is no leakage, the two-qubit interaction is the dominant source of error, and gates can be performed perfectly in parallel. The physical device described in this work has complex behavior outside these assumptions, necessitating a device-specific calculation of the surface code threshold fidelity. 

When a CZ gate is applied, no qubit neighbouring either of the qubits involved in the CZ can be involved in their own CZ gate. We have devised a 16 step CZ application pattern that accounts for these parallelism constraints and still measures all stabilizers. The longest measured CZ time of 45 ns will be used. Furthermore, the CZ gate, which is always applied between one measurement qubit and one data qubit, has a small amount of leakage 



<!-- Start of picture text -->
0.2<br>0.0 corrected<br>Dt<br>-0.2 X/2 Y/2<br>uncorrected<br>-0.4<br>0 100 200 300<br>Dt (ns)<br> (rad)Df<br><!-- End of picture text -->

Measurement with fidelity 0.99 in 200 ns and initialization with fidelity 0.99 in 50 ns will be assumed [Jeffrey, E., _et al._ , in preparation]. Y/2 gates will be used instead of Hadamard gates, with the slowest 20 ns time assumed and an average fidelity of 0.9992 (calculated only from the slower Y/2 gates) assumed. An identity error of 0.05% per 10 ns will be assumed, consistent with experimental data. 

Detailed simulations of 5x5, 9x9, and 13x13 qubit arrays with the above parameters have been performed making use of the latest correction techniques [9]. The logical error rate was found to be the same in all cases, justifying our claim of a device with parameters at the surface code threshold. 

## **CZ GATE ERROR BUDGET** 

FIG. S4: **Control pulse ripple.** Qubit phase response to a unit step (amplitude: 0.5 GHz) applied to the frequency control line, with and without correction. The pulse sequence is shown in the inset, with the dashed line representing the unit step. With correction, a phase drift of 0 _._ 03 rad in 150 ns is observed, consistent with a remnant control pulse ripple of 30 kHz. 

( _<_ 0 _._ 2%) on the measurement qubit, but practically negligible leakage on the data qubit. We shall neglect this small amount of measurement qubit leakage. Methods of coping with leakage in topological codes are known [8]. 

TABLE S2: Single qubit gate fidelities for all qubits, determined by Clifford-based randomised benchmarking. Averaged over all gates and all qubits we find an average fidelity of 0.9992. The standard deviation is typically 5 _·_ 10<sup>_−_5</sup> . The gate times are between 10 and 20 ns, see Table S3, except for the composite gates H and 2T, which are twice as long. The idle is as long as the shortest microwave gate (12 ns to 20 ns). 

|gates|Q0|Q1|Q2|Q3|Q4|
|---|---|---|---|---|---|
|I|0.9990|0.9996|0.9995|0.9994|0.9991|
|X|0.9992|0.9996|0.9992|0.9991|0.9991|
|Y|0.9991|0.9995|0.9993|0.9992|0.9991|
|X/2|0.9992|0.9993|0.9993|0.9994|0.9993|
|Y/2|0.9991|0.9993|0.9995|0.9994|0.9994|
|-X|0.9991|0.9995|0.9992|0.9989|0.9991|
|-Y|0.9991|0.9995|0.9991|0.9987|0.9991|
|-X/2|0.9991|0.9992|0.9993|0.9990|0.9995|
|-Y/2|0.9991|0.9992|0.9995|0.9990|0.9994|
|H|0.9986|0.9986|0.9991|0.9981|0.9988|
|Z|0.9995|0.9988|0.9994|0.9991|0.9993|
|Z/2|0.9998|0.9991|0.9998|0.9995|0.9996|
|2T <sup>_a_</sup>||0.9989|0.9994|0.9989|0.9990|
|average overgates|0.9992|0.9992|0.9994|0.9991|0.9992|
|average overqubits|||0.9992|||



> _a_ As the T gate is not a Clifford generator, a single recovery gate can not be found when interleaving. This precludes Clifford-based randomised benchmarking of the T gate. To quantify this gate to some extent, we have benchmarked 2T gates, physically implemented by applying two T gates in series. If the gate error is predominantly gate-aspecific, the T gate error is half that of the 2T gate, suggesting that the average T gate fidelity is 0.9995 

We experimentally measure the three predominant error mechanisms of the CZ gate: 2-state leakage, decoherence and control error. 2-state leakage is measured using the same technique as outlined in [4]. The system is initialised in the _|_ 11 _⟩_ -state followed by two CZ gates. As the time between these two gates is varied, we measure an interference pattern in the probability where the amplitude is proportional to the _|_ 02 _⟩_ state leakage. The error is given by ∆ _P/_ 4 [4]. We also see additional interference patterns that come from imperfect _|_ 11 _⟩_ preparation at the beginning of the sequence. We note that leakage occurs predominantly in the qubit which undergoes the frequency trajectory. 

TABLE S3: Single qubit gate times in ns. 

|gates|Q0|Q1|Q2|Q3|Q4|
|---|---|---|---|---|---|
|XY axes_π_rotations|20|20|12|18|12|
|XY axes_π/_2rotations|20|20|12|12|12|
|Z axis_π_,_π/_2,_π/_4rotations|10|10|10|10|10|
|I|20|20|12|12|12|
|H|40|40|24|30|24|
|2T|20|20|20|20|20|



TABLE S4: CZ gate fidelities for all qubit pairs, determined by Clifford-based randomised benchmarking. Gate times are between 38 and 45 ns; Q0-Q1: 45 ns, Q1-Q2: 43 ns, Q2-Q3: 43 ns, Q3-Q4: 38 ns. 

|qubits<br>Q0<br><br>|Q1<br>Q2<br>Q3<br>Q4<br>|
|---|---|
|CZQ0_−_Q1<br>0.9924 <br>CZQ1_−_Q2<br>CZQ2_−_Q3<br>CZQ3_−_Q4|_±_0.0005<br>0.9936_±_0.0004<br>0.9944_±_0.0005<br>0.9900_±_0.0006|
|ABLE S5: CZ gate err<br>rror in percent.<br>Decoherence (55%)|or budget, including the contribution to the tota<br>Q2<br>_≥_0_._0017(24%)<br>Q3<br>0.0022(31%)|
|Control (45%)|single qubit phase error<br>_≤_0_._0017(24%)<br>state leakage<br>0.0015(21%)|



TABLE S5: CZ gate error budget, including the contribution to the total error in percent. 



<!-- Start of picture text -->
0.10 1.0<br>1.6 ns<br>0.08 0.8 Q ref2<br>Dt Q3 ref<br>X X idle<br>control<br>X  pulse idle<br>0.06 0.6<br>10 12 14 0 100 200 300<br>(a) Dt (ns) (b)  m<br>P+Pl1>l2><br>sequence fidelity<br><!-- End of picture text -->

FIG. S5: **CZ error budget.** (a) In the Ramsey error filter technique an interference pattern arises in the measured probability (black dots) whose magnitude is proportional to the _|_ 02 _⟩_ -state leakage. The data are smoothed (red) for enhanced visibility. The frequency of these oscillations (indicated by the arrow, 1.6 ns) is the idling frequency difference between qubits (800 MHz), minus the nonlinearity (200 MHz) as we are measuring the crossing between _|_ 11 _⟩_ and _|_ 02 _⟩_ . Other frequencies a ~~re~~ believed to arise from improper _|_ 11 _⟩_ state preparation ~~. (b) Randomised~~ benchmarking sequence fidelity for qubits Q2 and Q3. Decoherence is quantified by idling for the same duration as the CZ gate. Controls error can be identified by applying the control pulse on Q2, without doing a full CZ by detuning Q3. For the randomised benchmarking data of the CZ (not shown): _r_ ref = 0 _._ 0198 and _r_ CZ = 0 _._ 0269. 

We measure the decoherence contribution from each qubit by performing interleaved randomised benchmarking with an idle of the same duration as the CZ gate. The contribution to error from the waveform is measured by interleaved randomised benchmarking on the waveform for the CZ gate alone, with a slightly lower amplitude to avoid interactions with the other qubit. We treat this as a single-qubit phase gate. With the idle error measured, we can separate out decoherence and single qubit phase error. Because we are detuning the qubit down in frequency to a part of the spectrum where it is more sensitive to flux noise, inducing more dephasing, the single qubit phase error is an upper bound. With these experiments we can construct an error budget for all of the dominant error mechanisms, as seen in Table S5. 

## **QUANTIFYING XY CONTROL CROSSTALK USING SIMULTANEOUS RANDOMISED BENCHMARKING** 

Addressability, the ability to individually control a single qubit without affecting neighbouring qubits, is of great importance when building a multi-qubit system. In our five Xmon qubit processor the addressability is mostly compromised in three ways: Z control crosstalk, microwave XY control crosstalk, and off-resonant qubit-qubit coupling. Z crosstalk can be reduced to below the 10<sup>_−_4</sup> level. Microwave XY crosstalk becomes a problem if a qubit’s control pulses perform rotations on a neighbouring qubit. Off-resonant qubit-qubit coupling will very slowly perform a CZ gate between the qubits, potentially 

causing unwanted phase shifts with rate Ω _ZZ_ , 



with _η_ 1 and _η_ 2 the qubit nonlinearities, and ∆ the difference in qubit frequencies. 

We performed crosstalk characterisation on nearest neighbour and next-nearest neighbour qubits. Nearest neighbours are far detuned ( _>_ 800 MHz), hence the microwave XY crosstalk is expected to be negligible, but the off-resonant CZ interaction may be non-negligible. Next-nearest neighbors have a much smaller coupling ( _g_ =1.3 MHz), but are only detuned by 100400 MHz; hence both the off-resonant CZ as well as microwave XY crosstalk may be detrimental. We investigate these mechanisms by using the simultaneous randomised benchmarking techniques outlined in [6]. We can single out errors that come ~~from~~ poor addressability by performing randomised benchmark- ~~ing on each qubit indiv~~ idually, and operating both qubits simultaneously. 

~~The randomised ben~~ chmarking data are shown in Fig. S6. We can determine the effect of controlling qubit Q3 on Q2, by first benchmarking qubit Q2 individually ( _I ⊗ C_ 1, green open squares), and benchmarking both qubit Q2 and Q3 simultaneously, and tracing out the contribution of Q3 ( _C_ 1 _⊗C_ 1, green full squares). The decay for both traces is virtually indistinguishable, the added error is below 10<sup>_−_4</sup> . Likewise, we find that the effect on Q3 of controlling Q2 simultaneously leads to an added error per Clifford of 2 _·_ 10<sup>_−_4</sup> . For next nearest neighbours, we find added errors per Clifford of 1 _·_ 10<sup>_−_4</sup> and 2 _·_ 10<sup>_−_4</sup> . For both the nearest neighbour and next-nearest neighbours the added error of operating them simultaneously is _<_ 2 _·_ 10<sup>_−_4</sup> . We conclude that XY control crosstalk is a minor error mechanism, enabling a high degree of addressability in this architecture. 

## **GENERATION OF THE CLIFFORD GROUPS** 

## **Single qubit Clifford group** _C_ 1 

The single qubit Clifford group _C_ 1 is the group of 24 rotations which preserve the octahedron in the Bloch sphere. We implement the group using microwave pulses only, decomposed into rotations around the X and Y axes using the generators: _{_ I, _±_ X/2, _±_ Y/2, _±_ X, _±_ Y _}_ , as summarised in Table S6. The average number of single qubit gates per single qubit Clifford is 1.875. 

## **Two qubit Clifford group** _C_ 2 

Using the single qubit Cliffords, we can construct the two qubit Clifford group _C_ 2 following Ref. [5]. This group has four classes: the single qubit class, the CNOT-like class, the iSWAPlike class, and the SWAP-like class. The CNOT and SWAP-like 



<!-- Start of picture text -->
I   x  C 1 : Pl00>+Pl10><br>0.9 0.9<br>C 1 x  C 1 : Pl00>+Pl10><br>0.8 0.8<br>0.7 0.7 I   x  C 1 : Pl00>+Pl10><br>C 1 x  C 1 : Pl00>+Pl10><br>0.6 C 1 x  I  : Pl00>+Pl01> 0.6 C 1 x  I  : Pl00>+Pl01><br>C 1 x  C 1 : Pl00>+Pl01> C 1 x  C 1 : Pl00>+Pl01><br>0 100 200 300 0 100 200<br>(a) m (b) m<br>sequence fidelity sequence fidelity<br><!-- End of picture text -->

elements: 



The CNOT-like class has 24<sup>2</sup> _×_ 3<sup>2</sup> = 5184 elements. 



The iSWAP-like class also has 5184 elements, 

FIG. S6: **Simultaneous randomised benchmarking of nearest and next nearest neighbours.** (a) Benchmarking the effect of Q2 on Q3 and vice-versa ( _f_ Q2 = 5 _._ 72 GHz, _f_ Q3 = 4 _._ 67 GHz). The sequence fidelities are shown for operating Q2 individually ( _I ⊗ C_ 1, green open squares), Q3 individually ( _C_ 1 _⊗ I_ , purple open circles), and Q2 and Q3 simultaneously ( _C_ 1 _⊗ C_ 1, full symbols). By tracing out one qubit, its effect on the other qubit becomes apparent: the errors per Clifford are: _r_ Q2=0.0011, _r_ Q2 _|_ Q3=0.0012, _r_ Q3=0.0018, _r_ Q3 _|_ Q2=0.0020. (b) Benchmarking of Q0 and Q2 ( _f_ Q0 = 5 _._ 30 GHz, _f_ Q2 = 5 _._ 72 GHz). The errors per Clifford are: _r_ Q0=0.0016, _r_ Q0 _|_ Q2=0.0018, _r_ Q2=0.0011, _r_ Q2 _|_ Q0=0.0011. Note that the errors per Clifford are consistent with the average gate fidelities in Table S2: for Q2, the average gate fidelity is 1 _− r_ Q2 _/_ 1 _._ 875=0.9994. Coupling strengths can be found in Table S1. 

class are terminated with a gate from the 3-element group _S_ 1, as described in Table S7. The single qubit class has 24<sup>2</sup> = 576 

TABLE S6: The 24 single qubit Cliffords written in terms of the physical microwave gates applied in time. The Paulis and 2 _π/_ 3 rotations form the tetrahedron symmetry group. 

|Singlequbit Cliffords|||
|---|---|---|
||I||
|Paulis|X<br>Y||
||Y,|X|
||X/2,|Y/2|
||X/2,|-Y/2|
||-X/2,|Y/2|
||-X/2,|-Y/2|
|2_π/_3rotations|Y/2,|X/2|
||Y/2,|-X/2|
||-Y/2,|X/2|
||-Y/2,|-X/2|
||X/2||
||-X/2||
||Y/2||
|_π/_2rotations|-Y/2||
||-X/2,|Y/2, X/2|
||-X/2,|-Y/2, X/2|
||X,|Y/2|
||X,|-Y/2|
||Y,|X/2|
|Hadamard-like|Y,|-X/2|
||X/2,|Y/2, X/2|
||-X/2,|Y/2, -X/2|





Finally the SWAP-like class, with 576 elements, is given by 



bringing the full size of the two-qubit Clifford group to 11520. 

Here, we rewrite the two-qubit Cliffords in terms of the CZ entangling gate. We rewrite the CNOT, iSWAP and SWAP in terms of the CZ: 



As the single qubit gates preceeding the entangling operation (CZ gate) can be absorbed into _C_ 1, and the final single qubit 

TABLE S7: The _S_ 1 sets written in terms of physical gates in time; these are elements of the single qubit Clifford group, and therefore physically implemented in the same way. 

||I||
|---|---|---|
|_S_1|Y/2,|X/2|
||-X/2,|-Y/2|
|_S_<sup>_X/_2</sup><br>1|X/2<br>X/2, <br>-Y/2|Y/2, X/2|
|_S_<sup>_Y/_2</sup><br>1|Y/2<br>Y,|X/2|
||-X/2,|-Y/2, X/2|



gates can be absorbed into _S_ 1 (see Table S7), we have for the CNOT-like class, 



the iSWAP-like class, 



and the SWAP-like class, 



The average number of gates for _C_ 2 is 1.5 CZ gates and 8.25 single qubit gates. For the idle, we wait as long as the shortest single qubit gate. For a single qubit gate time of 20 ns and a CZ gate time of 40 ns, the average duration of _C_ 1 is 37.5 ns, and _C_ 2 is 160 ns. 

The Clifford group is a 2-design. A set of unitaries _{Uk}_<sup>_K_</sup> _k_ =1 is a 2-design if and only if [12] 



As a consistency check, we have verified that the single and twoqubit Cliffords we generate are indeed a 2-design with the above equation. 

## **Two qubit Clifford group** _C_ 2 

The four classes of two-qubit Cliffords are composed from the two-qubit CZ gate, and the single-qubit gate sets _C_ 1, _S_ 1, _S_ 1<sup>_Y/_2</sup> , and _S_ 1<sup>_X/_2</sup> . The respective errors are given by: _rS_ 1 = 5 _r_ SQ _/_ 3, _rS_ 1 _X/_ 2 = 5 _r_ SQ _/_ 3, _rS_ 1 _Y/_ 2 = 2 _r_ SQ. We now derive the average gate composition for the two-qubit Cliffords. For the single-qubit class: 



CNOT-like class: 



iSWAP-like class: 



SWAP-like class: 



The error per Clifford for _C_ 2 is then given by 









And the error per two-qubit Cliffords interleaved with a CZ is 

## **ESTIMATING THE ERROR PER CLIFFORD** 

Here, we connect the error per Clifford _r_ to the errors of the single and two-qubit gates, measured when performing randomised benchmarking. This shows the physical significance of the error per Clifford, and is an important self-consistency check. We can give an estimate for the error per Clifford by determining the average number of single and two-qubit gates that go into a Clifford, combined with the single and two-qubit gate fidelities that we measure using interleaved randomised benchmarking. We assume that all the gates have low enough error such that adding error when composing gates is a good approximation. 

## **Single qubit Clifford group** _C_ 1 

There are 45 single qubit gates used across 24 Cliffords. With the assumption that all single gates have the same error, the average error per Clifford is 



with _r_ SQ the average single-qubit gate error. 



## **Comparison to Experiment** 

Using these simple formulas, we find that our randomised benchmarking data are self-consistent. Using reasonable values of 0.001 and 0.006 for the single and two-qubit gates respectively, we calculate _rC_ 2 = 0 _._ 0173, which is close to the experimental value of _r_ ref = 0 _._ 0189 in Fig. 3 in the main Letter; for the interleaved case the calculated value of _rC_ 2+CZ = 0 _._ 0233 is close to the experimental value of 0.0244 as well. 

## _N_ = 5 **GHZ STATE PULSE SEQUENCE** 

The pulse sequence for the algorithm to construct the five qubit GHZ state is shown in Fig. S7a. We use Hahn spin echoes on idling elements to suppress slow dephasing ( _Tφ,_ 2). The frequency diagram for the qubits is shown in Fig. S7b. Nearest neighbour qubits are detuned by 0.7 to 1.5 GHz, next-nearest neighbours are detuned by 0.4 to 0.5 GHz. 



<!-- Start of picture text -->
(a) (b)<br>XY Y/2 (I) X X 5.765 GHz<br>Q0 Z CZ Q0-Q1  5.273 GHz<br>XY -Y/2 Y/2 X X 5.367 GHz<br>Q1 Z (II)<br>XY -Y/2 Y/2 X X<br>CZ Q2-Q1  CZ Q2-Q3<br>Q2 Z<br>4.658 GHz<br>-Y/2 Y/2<br>XY<br>Q3 Z (III) 4.223 GHz<br>-Y/2 Y/2<br>Q4 XYZ CZ Q4-Q3<br>t=0 Time t=290 ns<br>Frequency<br><!-- End of picture text -->

FIG. S7: **Pulse sequence for generating the** _N_ = 5 **GHZ state and frequency diagram.** (a) The control signals for all five qubits. The algorithm consists of a Y/2 pulse on Q0 followed by successive CNOT gates (implemented here with a CZ gate and -Y/2, Y/2 gates applied to the target) on each progressive pair of qubits in the array. The highlighted region (I) shows Hahn spin echo pulses X applied to Q0 to suppress dephasing while idling. Spin echo pulses are also applied to Q1 and Q2. (II) We detune Q1 to bring it closer in frequency to Q2 for the CZ gate. (III) Simultaneously with the Q1-Q2 entangling operation, we detune Q3 away to allow for selective entanglement. (b) The frequency diagram shows the idling frequencies for all qubits, and is one of the operating modes of the quantum processor. 

## **QUANTUM STATE TOMOGRAPHY** 

The density matrices of the _N_ = 2 Bell and _N_ = 3 _,_ 4 _,_ 5 GHZ states are characterised using quantum state tomography. After state preparation, gates from _{_ I, X/2, Y/2, X _}_<sup>_⊗N_</sup> are applied; with the measured probabilities the state can then be reconstructed. We use quadratic maximum likelihood estimation, using the MATLAB packages SeDuMi and YALMIP, to extract the density matrix while constraining it to be Hermitian, unit trace, and positive semidefinite; the estimation is overconstrained. Non-idealities in measurement and state preparation are suppressed by performing tomography on a zero-time idle [10, 11]. We note that tomography is only “as good as” the tomography pulses, which have an average fidelity above 0.999. Fidelities and uncertainties correspond to the mean and standard deviation of 10 measurements, consisting of 10<sup>4</sup> ( _N_ = 2 _,_ 3) or 6 _·_ 10<sup>3</sup> ( _N_ = 4 _,_ 5) repetitions each. The density matrices plotted in the main article are constructed by averaging all measured probabilites, effectively using 10<sup>5</sup> ( _N_ = 2 _,_ 3) or 6 _·_ 10<sup>4</sup> ( _N_ = 4 _,_ 5) repetitions. 

The imaginary part of the density matrices ( _ρ_ ) is plotted in Fig. S8. The Pauli operator representation is shown in Fig. S9. 

   - [2] Chen, Z., _et al._ Fabrication and Characterization of Aluminum Airbridges for Superconducting Microwave Circuits, arXiv:1310.2325. 

   - [3] Megrant A., _et al._ Planar Superconducting Resonators with Internal Quality Factors above One Million. _Appl. Phys. Lett._ **100** , 113510 (2012). 

   - [4] Lucero E., _et al._ Reduced phase error through optimized control of a superconducting qubit. _Phys. Rev. A_ **82** , 042339 (2010). 

   - [5] C´orcoles, A. D., _et al._ Process verification of two-qubit quantum gates by randomized benchmarking. _Phys. Rev. A_ **87** , 030301. (2013). 

   - [6] Gambetta J. M., _et al._ Characterization of addressability by simultaneous randomized benchmarking. _Phys. Rev. Lett._ **109** , 240504 (2012). 

   - [7] Fowler, A. G., Mariantoni, M., Martinis, J. M., & Cleland, A. N. Surface codes: Towards practical large-scale quantum computation. _Phys. Rev. A_ **86** , 03232 (2012). 

   - [8] Fowler, A. G. Coping with qubit leakage in topological codes. _Phys. Rev. A_ **88** , 042308 (2013). 

   - [9] Fowler, A. G. Optimal complexity correction of correlated errors in the surface code. arXiv:1310.0863. 

   - [10] DiCarlo, L. _et al._ Preparation and measurement of three-qubit entanglement in a superconducting circuit. _Nature_ **467** , 574-578 (2010). 

   - [11] Neeley, M. _et al._ Generation of three-qubit entangled states using superconducting phase qubits. _Nature_ **467** , 570-573 (2010). 

   - [12] Gross D., Audenaert K., & Eisert J. Evenly distributed unitaries: On the structure of unitary designs. _J. Math. Phys._ **48** , 052104 (2007). 

- [1] Barends, R. _et al._ Coherent Josephson qubit suitable for scalable quantum integrated circuits. _Phys. Rev. Lett._ **111** , 080502 (2013). 





<!-- Start of picture text -->
Im(r) 0.0 Im(r) 0.5<br>0.5<br>0.25<br>0.0<br>0<br>0 1<br>0 1 1<br>0 1 0 1<br>1 1 1 0<br>0 0<br><!-- End of picture text -->



FIG. S8: **Quantum state tomography of the GHZ state: imaginary parts.** Imaginary parts of the density matrices _ρ_ for the _N_ = 2 Bell state and the _N_ = 3 _,_ 4 and 5 GHZ states. For clarity, the same scale as for the main Letter is used. _|_ Im _ρ|_ is below 0.03, 0.04, 0.04 and 0.07 for _N_ = 2 to 5, respectively. 















FIG. S9: **Pauli operator representation for the** _N_ = 2 **Bell state and the** _N_ = 3 _,_ 4 **and** 5 **GHZ states.** The bars show expectation values of combinations of Pauli operators, ideal in grey, experimental values in colour.
