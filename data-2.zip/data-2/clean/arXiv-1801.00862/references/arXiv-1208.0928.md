<!-- fulltext source=oa_pdf slug=arXiv-1208.0928 fetched=2026-09-18T01:26:50+00:00 -->

# Surface codes: Towards practical large-scale quantum computation 

## Austin G. Fowler 

Centre for Quantum Computation and Communication Technology, School of Physics, The University of Melbourne, Victoria 3010, Australia 

## Matteo Mariantoni 

Department of Physics, University of California, Santa Barbara, CA 93106-9530, USA and California Nanosystems Institute, University of California, Santa Barbara, CA 93106-9530, USA 

## John M. Martinis and Andrew N. Cleland 

California Nanosystems Institute, University of California, Santa Barbara, CA 93106-9530, USA (Dated: October 26, 2012) 

This article provides an introduction to surface code quantum computing. We first estimate the size and speed of a surface code quantum computer. We then introduce the concept of the stabilizer, using two qubits, and extend this concept to stabilizers acting on a two-dimensional array of physical qubits, on which we implement the surface code. We next describe how logical qubits are formed in the surface code array and give numerical estimates of their fault-tolerance. We outline how logical qubits are physically moved on the array, how qubit braid transformations are constructed, and how a braid between two logical qubits is equivalent to a controlled-NOT. We then describe the single-qubit Hadamard, S<sup>ˆ</sup> and T<sup>ˆ</sup> operators, completing the set of required gates for a universal quantum computer. We conclude by briefly discussing physical implementations of the surface code. We include a number of appendices in which we provide supplementary information to the main text. 

PACS numbers: 03.67.Lx 

In this article we describe the surface code approach to quantum computing. We have attempted to maximize clarity and simplicity, while perhaps sacrificing some rigor. The article is targeted at an audience with a good grounding in basic quantum mechanics, but assumes no additional knowledge regarding surface codes, error correction, or topological information processing. We do however assume some prior knowledge of the basics of qubits and quantum computing, including familiarity with single qubit operations such as X<sup>ˆ</sup> bit-flips and Z<sup>ˆ</sup> phase-flips, the Hadamard gate, and the two-qubit controlled-NOT (CNOT) gate as well as the multi-qubit Toffoli gate. We also assume a working understanding of quantum circuits and their terminology. We refer the uninitiated reader to one of the excellent texts on this topic, e.g. Ref. [1] or [2]. 

### I. BACKGROUND 

Quantum computers provide a means to solve certain problems that cannot be solved in a reasonable period of time using a conventional, classical computer. These problems include factoring very large numbers into their primes, which on a quantum computer can be accomplished relatively quickly using Shor’s algorithm [3], and searching large, unstructured data sets, which can be done on a quantum computer using Grover’s search algorithm [4, 5]. A number of physical systems are being explored for their use in quantum computing, including ions, spins in semiconductors, and superconducting circuits [6, 7]. However, none of these systems perform suf- 

ficiently well to serve directly as computational qubits. It is however possible to construct a logical qubit from a collection of physical qubits, such that the logical qubit performs much better than the individual physical qubits. 

One approach to building a quantum computer is based on surface codes [8, 9], operated as stabilizer codes [10]. The surface codes evolved from an invention of Alexei Kitaev known as toric codes [11–14], which arose from his efforts to develop simple models for topological order, using qubits distributed on the surface of a toroid. The toroidal geometry employed by Kitaev turned out to be unnecessary, and planar versions (thus “surface codes”) were developed by Bravyi and Kitaev as well as Freedman and Meyer [8, 15]. 

One of the significant advantages of surface codes is their relative tolerance to local errors, as was first described by Preskill and co-workers [16]. In this publication, the critical logical CNOT operation was implemented using stacked layers of surfaces, a threedimensional structure that significantly complicates potential physical implementations, but the ability of the surface codes to withstand large error rates was apparent: These authors showed that the surface codes could handle error rates of almost 3% per surface code clock cycle, assuming the ability to measure a four-qubit operator. 

Raussendorf and co-workers then discovered that the logical CNOT operation could be implemented by braid transformations on a single surface, a highly significant simplification [17–19]. These authors also evaluated error tolerances for a fully planar implementation using only one- and two-qubit nearest-neighbor gates, arriving at an 

2 

error threshold of 0.75% per operation. 

The literature on surface codes is somewhat opaque. Increasingly accessible descriptions have appeared in more recent publications [20, 21], including thorough analyses of errors and their propagation [21, 22] and the ongoing development of efficient classical control software [23]. A number of authors are working on improving the classical processing associated with the surface code [24– 28], as well as other two-dimensional topological codes [29–32]. 

The tolerance of surface codes to errors, with a peroperation error rate as high as about 1% [22, 23], is far less stringent than that of other quantum computational approaches. For example, calculations of error tolerances of the Steane and Bacon-Shor codes, implemented on two-dimensional lattices with nearest-neighbor coupling, find per-step thresholds of about 2 × 10<sup>−5</sup> [33, 34], thus requiring three orders of magnitude lower error rate than the surface code. The error tolerance of the surface code, along with a simple two-dimensional physical layout with only nearest-neighbor coupling, makes a surface code architecture one of the most realistic approaches to building a solid-state quantum computer. 

As the reader will discover, the price paid for the high error tolerance is that implementations of the surface code involve large numbers of physical qubits — as do most other approaches to quantum computing [33, 34]. It takes a minimum of thirteen physical qubits to implement a single logical qubit. A reasonably fault-tolerant logical qubit that can be used effectively in a surface code takes of order 10<sup>3</sup> to 10<sup>4</sup> physical qubits.<sup>1</sup> The number of physical qubits needed to find a number’s prime factors, using Shor’s algorithm [3], depends on a tradeoff between physical size and time of computation. These trade-offs are apparent in Table I, where we display the approximate number of computational logical qubits, the number of sequential Toffoli gates, and the number of total Toffoli gates needed to factor an N -bit number, for different types of factoring circuits.<sup>2</sup> In general, while the computational time gets smaller as one moves down the table, the spatial extent of the circuit becomes larger, as the number of logical qubits (the circuit “footprint”) scales with the ratio of the total number of Toffoli gates to the number of sequential Toffoli gates. 

We can make a rough estimate of the time and circuit size needed to factor a number with N = 2, 000 bits (600 

> 1 This number depends strongly on the rate that errors occur on the physical qubits. 

> 2 A Toffoli gate is a three-qubit gate, with two controls determining the result on one target. The Toffoli can be described as a “controlled-controlled NOT”: If both controls are “true”, the target is flipped, “false”→“true” or “true”→“false”, while otherwise the target is unchanged. This reversible gate can be implemented in quantum logic using a combination of two-qubit controlled-NOTs and single qubit gates, and can be used to construct any arithmetical operation. The Toffoli is needed to implement Shor’s algorithm; see Ref. [1, 2]. 

|Number of<br>computational|Sequential<br>Toffoli|Total<br>Toffoli|References|
|---|---|---|---|
|logical qubits|gates|gates||
|2N|40N <sup>3</sup>|40N <sup>3</sup>|[35–37]|
|5N<br>2N <sup>2</sup><br>O(N <sup>3</sup>)|600N <sup>2</sup><br>15Nlog<sup>2 </sup>N<br>O(log<sup>3 </sup>N)|O(N <sup>3 </sup>logN)<br>O(N <sup>3 </sup>log<sup>2 </sup>N)<br>O(N <sup>3 </sup>log<sup>3 </sup>N)|[38]<br>[39]<br>[40]|



TABLE I. Trade-off between number of computational logical qubits and number of sequential and total Toffoli gate operations for factoring an N -bit number into its primes using Shor’s algorithm. Each line in the table corresponds to a different quantum circuit implementing the algorithm. The physical size of a circuit scales with the ratio of the total number of Toffoli gates to the number of sequential Toffoli gates. 

decimal digits), using a circuit size scaling as in the first line of Table I, and making assumptions about the physical qubit error rates and gate times; more details on this estimate are provided in Appendix M.<sup>3</sup> This Shor’s algorithm implementation is constructed from ideas in Ref. [35–37], and involves a resource-intensive modular exponentiation that requires approximately 40N<sup>3</sup> ≈ 3 × 10<sup>11</sup> sequential Toffoli gates. The modular exponentiation thus determines the total execution time for the factoring algorithm. A highly optimized version of this circuit [41] can complete each Toffoli gate in approximately three physical qubit measurement cycles. If we assume a physical qubit measurement time of 100 ns, it will take about 26.7 hours to complete the exponentiation. 

The spatial extent of the circuit is determined in part by the number of computational logical qubits, which for this circuit is about 2N = 4,000. A much larger part of the surface code is however needed to generate and purify the special ancilla |AL⟩ states that are used in the Toffoli gates. Each Toffoli gate consumes seven |AL⟩ states [37]. In total, the exponentiation circuit therefore requires approximately 280N<sup>3</sup> ≈ 2.2 × 10<sup>12</sup> |AL⟩ states. The surface code must be able to generate these states at a rate sufficient to keep pace with the exponentiation circuit. 

The number of physical qubits needed to define a logical qubit is strongly dependent on the error rate in the physical qubits. Error rates just below the threshold require larger numbers of physical qubits per logical qubit, while error rates substantially smaller than the threshold allow smaller numbers of physical qubits. Here we assume an error rate approximately one-tenth the threshold rate, which implies that we need about 14,500 physical qubits per logical qubit to give a sufficiently low logical error rate to successfully execute the algorithm. 

We can now estimate the number of physical qubits 

> 3 We look at this circuit in detail, as it has the smallest footprint, albeit with the longest factoring time. 

3 

needed for our factoring problem. The 4,000 computational logical qubits require a total of about 4000 × 14, 500 = 58 million physical qubits. As discussed in Appendix M, generating and purifying one |AL⟩ state takes a surface code area of about 800,000 physical qubits, and takes about 100 µs. Generating the full set of 2.2 × 10<sup>12</sup> |AL⟩ states over the 26.7 hours of execution takes about a billion physical qubits. The computational qubits, which are separate from those used to generate the |AL⟩ states, therefore comprise less than 6% of the quantum computer footprint, so in total we see that with the assumed error rate, the full quantum computer needs about a billion physical qubits, operating for about one day. 

The size of the quantum computer is quite sensitive to the error rate in the physical qubits. For example, improving the overall error rate by about a factor of ten, as detailed in Appendix M, can reduce the number of physical qubits by about an order of magnitude, to about 130 million, although leaving the execution time unchanged. 

Further reduction of the qubit overhead can in principle be achieved by speeding up the surface code operation. Faster operation means fewer qubits are needed to generate |AL⟩ states at the necessary rate. Note however that the algorithm execution time is set by the modular exponentiation, and can only be reduced by reducing the measurement time. However, as will be clear later, operating a surface-code-based quantum computer requires intimate classical monitoring and control of the physical qubits, with the control circuitry driven by classical logic. Reducing the logical gate time will then put severe demands on this classical control hardware. Given the current speed of digital logic, logical gate times for the quantum computer in the range of 0.1-10 microseconds are probably realistic. Longer logical gate times can be used, however this requires more qubits one keeps the overall execution time constant. The number of qubits can be reduced by slowing down the modular exponentiation, as then the rate of |AL⟩ consumption is reduced, resulting in a smaller footprint for the |AL⟩ production. This may, however, lead to unacceptably long factoring times. We return to this question, and the issue of physical implementations, in a brief discussion at the end of this article. 

### II. INTRODUCTION 

Quantum computation relies on the use of qubits, which are two-level quantum systems. The prototypical two-level system is an electron spin in a magnetic field, from which much of the terminology originates; all of the quantum properties of an electron spin are captured by the algebra of the Pauli operators σˆx, σˆy, σˆz and the identity I<sup>ˆ</sup> . In keeping with the literature on quantum computation, we will be using the qubit operators X<sup>ˆ</sup> , Y<sup>ˆ</sup> and Z<sup>ˆ</sup> , defined in terms of the Pauli operators by X<sup>ˆ</sup> = σˆx, Yˆ = −iσˆy, and Zˆ = σˆz (see Appendix A). The algebra of the qubit operators is almost identical to that of the 

Pauli operators: 



where the last relation holds for cyclic permutations of Xˆ , Yˆ and Zˆ, except for [ ˆZ, Xˆ ] = +2 ˆY . 

Any two-level quantum system that satisfies the relations (1) can in principle be used as a qubit. In fact, any system in which one can define X<sup>ˆ</sup> and Z<sup>ˆ</sup> operators that satisfy the relations (1) can be used as a qubit, even if the system has more than two degrees of freedom.<sup>4</sup> Just having X<sup>ˆ</sup> and Z<sup>ˆ</sup> operators on a qubit is not sufficient, as a quantum computer needs a few more single-qubit gates as well as an entangling two-qubit gate. The Solovay-Kitaev theorem [2, 12] implies that one set of operators sufficient to implement an arbitrary quantum algorithm comprises the single-qubit operators X<sup>ˆ</sup> , Z<sup>ˆ</sup> , the Hadamard H<sup>ˆ</sup> , the Sˆ and Sˆ<sup>†</sup> phase gates, and the Tˆ and Tˆ<sup>†</sup> gates, as well as a two-qubit controlled-NOT (CNOT) gate (any twoqubit gate from which a CNOT can be constructed is of course acceptable).<sup>5</sup> The matrix representations of these operators are given in Appendix A. 

In the surface code, physical qubits are entangled together using a sequence of physical qubit CNOT operations, with subsequent measurements of the entangled states providing a means for error correction and error detection. A set of physical qubits entangled in this way is used to define a logical qubit, which due to the entanglement and measurement has far better performance than the underlying physical qubits. We will describe how logical qubits are constructed in the surface code, and also show how the complete set of single logical qubit gates and the two-qubit logical CNOT are constructed, allowing us to implement quantum algorithms based on these logical qubits. 

The qubit Z<sup>ˆ</sup> eigenstates are called the ground state |g⟩ and the excited state |e⟩. The ground state is the +1 eigenstate of Z<sup>ˆ</sup> , with Z<sup>ˆ</sup> |g⟩ = + |g⟩, and the excited state is the −1 eigenstate, with Z<sup>ˆ</sup> |e⟩ = −|e⟩.<sup>6</sup> It is tempting to think of the qubit as a kind of quantum transistor, with the ground state corresponding to “off” and the excited state to “on”. However, in distinct contrast to a classical logic element, a qubit can exist in a superposition of its eigenstates, |ψ⟩ = α|g⟩ + β|e⟩, so a qubit can 

> 4 Note that we are defining a qubit to have two real degrees of freedom. 

> 5 Note this is not a minimal set, which would be Tˆ, the Hadamard Hˆ and the CNOT, as we have the identities Tˆ<sup>2</sup> = Sˆ, Tˆ<sup>4</sup> = Zˆ, Hˆ ˆZHˆ = Xˆ , Z<sup>ˆ</sup> S<sup>ˆ</sup> = S<sup>ˆ†</sup> , and T<sup>ˆ7</sup> = T<sup>ˆ†</sup> . 

> 6 Typically Zˆ serves as the energy quantization axis, from which the names originate; the larger eigenvalue for the ground with respect to the excited state is because the Hamiltonian is proportional to −Z<sup>ˆ</sup> . 

4 

be both “off” and “on” at the same time. A measurement MZ of the qubit will however return only one of two possible measurement outcomes, +1 with the qubit state projected to |g⟩, or −1 with the qubit state projected to |e⟩. A quantum state is furthermore relatively delicate, easily perturbed by interactions with the outside world. These interactions can be intentional, or can arise from errors, energy decay from |e⟩ to |g⟩, or from fluctuations in the energy difference between the qubit eigenstates, i.e. fluctuations in the qubit transition frequency. When unintended, these changes to the qubit state comprise quantum errors, and present one of the largest challenges in quantum computing. 

Qubit errors can be modeled by introducing random X<sup>ˆ</sup> bit-flip and Z<sup>ˆ</sup> phase-flip operators in the evolution of the qubit state (we note that the Y<sup>ˆ</sup> operator is the combination Y<sup>ˆ</sup> = Z<sup>ˆ</sup> X<sup>ˆ</sup> , and is thus a combined bit- and phaseflip). If these errors are rare, the amplitudes for these operators will be correspondingly small. This modeling of errors can describe a quite wide range of single-qubit errors; see e.g. Ref. [42]. 

The operator model for single-qubit errors implies that these errors can, in principle, be undone by quantum correction gates: An erroneous Z<sup>ˆ</sup> can be canceled by subsequently applying an intentional Z<sup>ˆ</sup> , since Z<sup>ˆ2</sup> = I<sup>ˆ</sup> . If we detect all the errors, we can correct them by repeatedly applying quantum correction gates. However, one feature of the surface code is that errors only need to be corrected when they affect measurement outcomes, and thus one merely needs to identify errors, and then correct any measurements that are affected by these errors. This can be done entirely in the classical system used to control the surface code, as we describe in Section IX. For example, a Z<sup>ˆ</sup> phase-flip error that is detected immediately can be corrected by changing the sign of any subsequent X<sup>ˆ</sup> measurements, whereas an X<sup>ˆ</sup> error will have no effect on the same X<sup>ˆ</sup> measurement; any subsequent Zˆ measurements would similarly have to be corrected for an X<sup>ˆ</sup> error but not for a Z<sup>ˆ</sup> error. This means that as long as errors can be detected promptly, they can be undone in classical software. One of the important aspects of the surface code is therefore a focus on error detection rather than error correction. 

As errors occur from the random and unpredictable appearance of X<sup>ˆ</sup> and Z<sup>ˆ</sup> operations, they must be detected by repeatedly measuring each qubit, which can be done with combined X<sup>ˆ</sup> and Z<sup>ˆ</sup> measurements. However, because [ X,<sup>ˆ</sup> Z<sup>ˆ</sup> ]̸ = 0, sequential measurements of Xˆ and Zˆ on the same qubit conflict with one another, causing random projections of the qubit state onto these operators’ respective eigenstates, completely destroying the quantum state. Specifically, a Z<sup>ˆ</sup> measurement MZ probabilistically projects the qubit state onto |g⟩ or |e⟩, yielding the corresponding +1 or −1 eigenvalues respectively, with complete loss of the initial state’s amplitude and phase (unless it was originally in a Z<sup>ˆ</sup> eigenstate). A subsequent measurement MX of X<sup>ˆ</sup> will project the qubit state onto the X<sup>ˆ</sup> eigenstates |+⟩ = (|g⟩ + |e⟩) /√2 

or |−⟩ = (|g⟩−|e⟩) /√2, with +1 and −1 measurement outcomes, respectively, again destroying the state amplitude and phase. This again is in contrast with classical logic, in which a logic element has only bit-flip errors between “off” and “on”, and measurement of the logic state does not perturb that state. 

The projective measurement problem can however be avoided by measuring more than one qubit at a time, making non-destructive quantum error detection possible. Consider a two-qubit system, with qubits a and b, which we measure using the two-qubit operators X<sup>ˆ</sup> aX<sup>ˆ</sup> b and Z<sup>ˆ</sup> aZ<sup>ˆ</sup> b. These operators, even though they represent separate X<sup>ˆ</sup> and Z<sup>ˆ</sup> measurements, actually commute: 



(2) 

We have used the fact that operators on different qubits always commute, so e.g. [ X<sup>ˆ</sup> a, Z<sup>ˆ</sup> b] = 0. Measurements of these two-qubit operators are thus compatible, so a twoqubit state can actually be a simultaneous eigenstate of both X<sup>ˆ</sup> aX<sup>ˆ</sup> b and Z<sup>ˆ</sup> aZ<sup>ˆ</sup> b.<sup>7</sup> 

In Table II we display the four simultaneous eigenstates of X<sup>ˆ</sup> aX<sup>ˆ</sup> b and Z<sup>ˆ</sup> aZ<sup>ˆ</sup> b, with their corresponding eigenvalues. We see that these states are actually the four Bell states. We note that each qubit has two degrees of freedom (ignoring the overall phase), so the pair has four degrees of freedom. Specifying the two-operator eigenvalues, which are by definition real and thus impose two constraints on the qubits, restricts the system to only one quantum state. The operators X<sup>ˆ</sup> aX<sup>ˆ</sup> b and Z<sup>ˆ</sup> aZ<sup>ˆ</sup> b therefore form a complete set for this two-qubit system. 

Any of the eigenstates in Table II can be repeatedly measured by X<sup>ˆ</sup> aX<sup>ˆ</sup> b and Z<sup>ˆ</sup> aZ<sup>ˆ</sup> b, and these measurements will not change the state. If there is an externallyinduced X<sup>ˆ</sup> or Z<sup>ˆ</sup> error on one of the qubits, then the twoqubit measurements will project the qubit state onto one of the other two-qubit eigenstates, and the measurement eigenvalues will change, signaling that an error has occurred. For example, consider the state (|gg⟩ + |ee⟩)/√2, with eigenvalues (+1, +1), in the first line of Table II. An 

> 7 Theuse acarefulqubit readeroperatormayproductbe confusedsuch byas Xourˆ Z<sup>ˆ</sup> notation:without subscriptsWhen we on the operators, the two operators act on the same qubit; the 2 × 2 matrix representations of each operator are multiplied together to give a 2 × 2 matrix representation for the product. When we instead have subscripts, such as X<sup>ˆ</sup> aX<sup>ˆ</sup> b, the operators act on different qubits, so formally we should write this as an outer product X<sup>ˆ</sup> a ⊗ X<sup>ˆ</sup> b; this outer product operator acts on a 4- dimensional Hilbert space, so its matrix representation is a 4 × 4 matrix formed by the outer product of the two 2 × 2 representations of X<sup>ˆ</sup> a and X<sup>ˆ</sup> b. 

5 

|ˆZa ˆZb|ˆ<br>Xa <sup>ˆ</sup><br>Xb|||ψ⟩|
|---|---|---|---|
|+1|+1|(|gg⟩+||ee⟩)/<br>~~√~~<br>2|
|+1|−1|(|gg⟩−||ee⟩)/<br>√<br>2|
|−1|+1|(|ge⟩+||eg⟩)/<br>√<br>2|
|−1|−1|(|ge⟩−||eg⟩) /<br>√<br>2|



TABLEXˆaX<sup>ˆ</sup> b. The four eigenstates are the Bell states for this system.II. Eigenstates of the two-qubit operators Z<sup>ˆ</sup> aZ<sup>ˆ</sup> b and 

Xˆb error on the second qubit will transform this state to (|ge⟩ + |eg⟩)/√2, which is also an eigenstate but with eigenvalues (−1, +1); the change in the first eigenvalue will signal this error. Note however that this error cannot be distinguished from an X<sup>ˆ</sup> a error, which yields the same final state and final eigenvalues. By contrast, a Z<sup>ˆ</sup> a error on the first qubit will transform (|gg⟩ + |ee⟩)/√2 to (|gg⟩−|ee⟩)/√2, which is an eigenstate with eigenvalues (+1, −1), changing the second eigenvalue (a Z<sup>ˆ</sup> b error will give the same outcome as Z<sup>ˆ</sup> a). Hence, while errors can always be detected, they cannot be uniquely identified: A more complex system is needed to achieve that, the surface code being one example. 

The operator products X<sup>ˆ</sup> aX<sup>ˆ</sup> b and Z<sup>ˆ</sup> aZ<sup>ˆ</sup> b are called stabilizers. Stabilizers are very important in preserving quantum states: By repeatedly measuring a quantum system using a complete set of commuting stabilizers, the system is forced into a simultaneous and unique eigenstate of all the stabilizers. One can measure the stabilizers without perturbing the system; when the measurement outcomes change, this corresponds to one or more qubit errors, and the quantum state is projected by the measurements onto a different stabilizer eigenstate. 

### III. THE SURFACE CODE 

The two-qubit stabilizer example demonstrates a simple form of error detection. More complex circuits can detect and precisely identify errors in much larger assemblies of qubits; the surface code is such an example. We implement the surface code on a two-dimensional array of physical qubits, as shown in Fig. 1. The qubits are either data qubits, represented by open circles in Fig. 1a, in which the computational quantum states are stored, or measurement qubits, represented by filled circles. All of the data and measurement qubits must meet the basic requirements for quantum computation: Initialization, single-qubit rotations, and a two-qubit controlled-NOT (CNOT) between nearest neighbors. In addition, in order to perform a topological version of the Hadamard transformation, the data qubits and measurement qubits must be able to exchange their quantum states (a SWAP operation). A method to measure Z<sup>ˆ</sup> for each qubit is also required. 

The measurement qubits are used to stabilize and ma- 

nipulate the quantum state of the data qubits. There are two types of measurement qubits, “measure-Z” qubits, colored green (dark) in Fig. 1a, and “measure-X” qubits, colored orange (light); these are called Z syndrome and X syndrome qubits in the surface code literature; see e.g. Ref. [20]. Each data qubit is coupled to two measureZ and to two measure-X qubits, and each measurement qubit is coupled to four data qubits. A measure-Z qubit is used to force its neighboring data qubits a, b, c and d into an eigenstate of the operator product Z<sup>ˆ</sup> aZ<sup>ˆ</sup> bZ<sup>ˆ</sup> cZ<sup>ˆ</sup> d: Each measure-Z qubit therefore measures a Z<sup>ˆ</sup> stabilizer. A measure-X qubit likewise forces its neighboring data qubits into an eigenstate of X<sup>ˆ</sup> aX<sup>ˆ</sup> bX<sup>ˆ</sup> cX<sup>ˆ</sup> d, and therefore measures an X<sup>ˆ</sup> stabilizer. 

### IV. QUIESCENT STATE OF THE SURFACE CODE 

The measure-Z and measure-X qubits that stabilize the surface code are operated in a very particular sequence, with one complete cycle shown in Fig. 1b and c, for a single measure-Z and measure-X qubit, respectively. After initializing each measure qubit in its ground state |g⟩, the heart of the sequence comprises four CNOT operations followed by a projective measurement. For the measure-Z qubit, the CNOTs target the measure qubit with the four nearest-neighbor data qubits as the controls, with the projective measurement yielding an eigenstate of Z<sup>ˆ</sup> aZ<sup>ˆ</sup> bZ<sup>ˆ</sup> cZ<sup>ˆ</sup> d (see Appendix B, as well as [2]; eigenstates are listed in Table III). For the measure-X qubit, the four CNOTs target the nearest-neighbor data qubits using the measure qubit as the control, and the sequence also includes a Hadamard applied to the measure qubit before and after the CNOTs; the projective measurement yields an eigenstate of X<sup>ˆ</sup> aX<sup>ˆ</sup> bX<sup>ˆ</sup> cX<sup>ˆ</sup> d. Hence, after the projective measurement of all the measure qubits in the array, the state |ψ⟩ of all the data qubits simultaneously satisfies Z<sup>ˆ</sup> aZ<sup>ˆ</sup> bZ<sup>ˆ</sup> cZ<sup>ˆ</sup> d|ψ⟩ = Zabcd|ψ⟩, with eigenvalues Zabcd = ±1, and X<sup>ˆ</sup> aX<sup>ˆ</sup> bX<sup>ˆ</sup> cX<sup>ˆ</sup> d|ψ⟩ = Xabcd|ψ⟩ with eigenvalues Xabcd = ±1. Following measurement, the cycle is repeated.<sup>8</sup> The measure qubits in Fig. 1b and c all operate in lock-step, so that every step in the cycle shown in the figure is completed over the entire 2D array before the next step begins. We note that the zig-zag sequence 

> 8 A capital roman letter with a “hat”, e.g. Xˆ , designates an operator, while a capital roman letter by itself, X, represents the outcome of a measurement of that operator, which must be an eigenvalue of the operator. A stabilizer X<sup>ˆ</sup> aX<sup>ˆ</sup> bX<sup>ˆ</sup> cX<sup>ˆ</sup> d is the outer product of four physical qubit X<sup>ˆ</sup> j operators, so would be represented by a 2<sup>4</sup> × 2<sup>4</sup> = 16 × 16 matrix; its measurement outcome Xabcd is an eigenvalue of this matrix. Note measuring the product X<sup>ˆ</sup> aX<sup>ˆ</sup> bX<sup>ˆ</sup> cX<sup>ˆ</sup> d does not yield the same result as measuring each individual X<sup>ˆ</sup> a, X<sup>ˆ</sup> b, X<sup>ˆ</sup> c and X<sup>ˆ</sup> d, as the qubits are in general not in a product eigenstate of the individual X<sup>ˆ</sup> j operators, so measuring the individual X<sup>ˆ</sup> j would cause undesirable projections. 

6 



<!-- Start of picture text -->
(a) Z Z Z Z Z Z Z Z Z Z<br>X Z X Z X Z X Z X Z X<br>X X X X X X X X X X<br>X Z X Z X Z X Z X Z X<br>Z Z Z Z Z Z Z Z Z Z<br>X Z X Z X Z X Z X Z X<br>X X X X X X X X X X<br>X Z X Z X Z X Z X Z X<br>Z Z Z Z Z Z Z Z Z Z<br>X Z X Z X Z X Z X Z X<br>X X X X X X X X X X<br>X Z X Z X Z X Z X Z X<br>Z Z Z Z Z Z Z Z Z Z<br>1 2 3 4 5 6 7 8<br>(b) a I g - + I<br>Z a<br>b Z Z c b +1:  [Z+<br>Z c 1:  [Z-<br>d d<br>repeat<br>(c) a g H H - +<br>X a<br>b X X c b +1:  [X+<br>X c 1:  [X-<br>d d<br>repeat<br><!-- End of picture text -->

FIG. 1. (Color online)(a) A two-dimensional array implementation of the surface code. Data qubits are open circles (◦), measurement qubits are filled circles (•), with measure-Z qubits colored green (dark) and measure-X qubits colored orange (light). Away from the boundaries, each data qubit contacts four measure qubits, and each measure qubit contacts four data qubits; the measure qubits perform four-terminal measurements. On the boundaries, the measure qubits contact only three data qubits and perform three-terminal measurements, and the data qubits contact either two or three measure qubits. The solid line surrounding the array indicates the array boundary. (b) Geometric sequence of operations (left), and quantum circuit (right) for one surface code cycle for a measure-Z qubit, which stabilizes Z<sup>ˆ</sup> aZ<sup>ˆ</sup> bZ<sup>ˆ</sup> cZ<sup>ˆ</sup> d. (c) Geometry and quantum circuit for a measure-X qubit, which stabilizes X<sup>ˆ</sup> aX<sup>ˆ</sup> bX<sup>ˆ</sup> cX<sup>ˆ</sup> d. The two identity I<sup>ˆ</sup> operators for the measure-Z process, which are performed by simply waiting, ensure that the timing on the measure-X qubit matches that of the measure-Z qubit, the former undergoing two Hadamard Hˆ operations. The identity operators come at the beginning and end of the sequence, reducing the impact of any errors during these steps. 

abcd followed by each of the measure qubits is quite particular, and cannot be easily modified while preserving the stabilizer property (see Appendix B). 

Stabilizer codes have the remarkable property that they do not operate from the system ground state, but instead from the state |ψ⟩ that results from the concurrent measurement of all the stabilizers; we call this the quiescent state. The quiescent state |ψ⟩ is randomly selected by completing one full surface code cycle, which is the sequence shown in Fig. 1b and c, starting for exam- 

|Eigenvalue|ˆZa ˆZb ˆZc ˆZd|ˆ<br>Xa <br>|<sup>ˆ</sup><br>Xb|<sup>ˆ</sup><br>Xc <sup>ˆ</sup><br>Xd|
|---|---|---|---|---|
|+1||gggg⟩<br>|ggee⟩<br>|geeg⟩<br>|eegg⟩<br>||+<br>|+<br>|+<br>| −<br>|+<br>+ <br> −<br>−<br>|+ +⟩<br>−−⟩<br>−+⟩<br>+ +⟩<br>|
|||egge⟩<br>|gege⟩<br>|| −<br>|+<br>|+<br> −<br>|+−⟩<br>+−⟩<br>|
|||egeg⟩<br>|eeee⟩|| −<br>|−|+ <br>−|−+⟩<br>−−⟩|
|−1||ggge⟩<br>|ggeg⟩<br>||+<br>|+<br>|+<br>+ <br>|+−⟩<br>−+⟩<br>|
|||gegg⟩<br>|eggg⟩<br>|geee⟩<br>|egee⟩<br>||+<br>| −<br>|+<br>| −<br>|−<br> +<br> −<br> + <br>|+ +⟩<br>+ +⟩<br>−−⟩<br>−−⟩<br>|
|||eege⟩<br>|eeeg⟩|| −<br>|−|−<br>−|+−⟩<br>−+⟩|



TABLE III. Eigenstates for the four-qubit stabilizers Zˆa ˆZb ˆZc ˆZd and XˆaX<sup>ˆ</sup> bX<sup>ˆ</sup> cX<sup>ˆ</sup> d. 

ple with all data and measurement qubits in their ground states |g⟩. 

Once selected, in the absence of errors, the same state |ψ⟩ will be maintained by each subsequent cycle of the sequence, with each measure qubit yielding a measurement outcome Xabcd or Zabcd equal to that of the previous cycle. This occurs because all X<sup>ˆ</sup> and Z<sup>ˆ</sup> stabilizers commute with one another. This is trivial for stabilizers that do not have any qubits in common, as X<sup>ˆ</sup> and Z<sup>ˆ</sup> operators on different qubits always commute. Stabilizers that have qubits in common will always share two such qubits, so every X<sup>ˆ</sup> stabilizer shares two data qubits with each neighboring Z<sup>ˆ</sup> stabilizer and vice versa.<sup>9</sup> Hence we have, for an X<sup>ˆ</sup> and Z<sup>ˆ</sup> stabilizer that measure data qubits a and b in common, 



as we get a minus sign from commuting X<sup>ˆ</sup> a through Z<sup>ˆ</sup> a as well as one from commuting X<sup>ˆ</sup> b through Z<sup>ˆ</sup> b. Note the similarity of this four-qubit stabilizer commutator with the two-qubit stabilizer example in Eq. (2). 

There are an enormous number of quiescent states that can be selected by the stabilizer measurements: If there are N measure qubits in the array, there are 2<sup>N</sup> measurement outcomes. The measurements at the end of each surface code cycle randomly project the data qubits onto one of these quiescent states. For the array in Fig. 1, with 

> 9 Note this is true both for qubits in the interior of the array as well as for qubits on the array boundaries. 

7 

N = 38 measure qubits, there are 2<sup>38</sup> ≈ 3 × 10<sup>11</sup> possible quiescent states. We also note that the rapid, single-cycle projection onto a quiescent state implies that the quiescent state is not a fully entangled state of the entire array, but instead comprises local collections of highly entangled data qubits, with a smaller degree of entanglement between more distant groups of qubits. This is in some way analogous to the ground state of a superconductor, with Cooper-paired electrons strongly correlated over size scales small compared to the superconducting correlation length, less strongly correlated over larger length scales, yet still described by a single macroscopic order parameter. 

### V. SINGLE QUBIT ERRORS 

Once selected, a quiescent state remains unchanged except when disturbed by errors, for example erroneous single-qubit X<sup>ˆ</sup> bit-flip or Z<sup>ˆ</sup> phase-flip operations. These errors will be indicated by changes in the measurement outcomes. Consider for example a single data qubit error, represented by the erroneous I<sup>ˆ</sup> a + ǫZ<sup>ˆ</sup> a operating on data qubit a; |ǫ| ≪ 1 is a small number equal to the probability amplitude for the Z<sup>ˆ</sup> phase-flip, and we neglect normalization. This error transforms the wavefunction |ψ⟩→|ψ<sup>′</sup> ⟩ = (I<sup>ˆ</sup> a + ǫZ<sup>ˆ</sup> a)|ψ⟩. Following this error, when the next surface code measurement cycle is completed, the state |ψ<sup>′</sup> ⟩ will be projected to an eigenstate of all the X<sup>ˆ</sup> aX<sup>ˆ</sup> bX<sup>ˆ</sup> cX<sup>ˆ</sup> d and Z<sup>ˆ</sup> aZ<sup>ˆ</sup> bZ<sup>ˆ</sup> cZ<sup>ˆ</sup> d operator products. This projects |ψ<sup>′</sup> ⟩ either back to the original state |ψ⟩, which occurs with near unit probability and erases the error, or projects it to Z<sup>ˆ</sup> a|ψ⟩, with probability |ǫ|<sup>2</sup> ; the latter state is an eigenstate of all the stabilizers, as we will see in a moment. In the first case the measurement outcomes are the same as before the error, while in the second case the signs of the two measure-X qubits adjacent to data qubit a will change. This is apparent from the following: 



(recall that Xabcd is the measurement outcome of the measure-X qubit). This shows that Z<sup>ˆ</sup> a|ψ⟩ is an eigenstate of this X<sup>ˆ</sup> stabilizer, but with the opposite sign from |ψ⟩. The same result applies to the other measure-X qubit adjacent to a: Z<sup>ˆ</sup> a|ψ⟩ is an eigenstate of that stabilizer, with opposite sign compared to |ψ⟩. The data qubit error will not change the outcomes of the two neighboring measure-Z qubits, as the Z<sup>ˆ</sup> operators all commute: [ Z<sup>ˆ</sup> aZ<sup>ˆ</sup> bZ<sup>ˆ</sup> cZ<sup>ˆ</sup> d, Z<sup>ˆ</sup> a] = 0. In terms of the quiescent state, 



clearly again an eigenstate but with unchanged sign. Hence, in this second case, the state |ψ<sup>′</sup> ⟩ = (I<sup>ˆ</sup> a + ǫZ<sup>ˆ</sup> a)|ψ⟩ is projected to Z<sup>ˆ</sup> a|ψ⟩, which is a different eigenstate of all the stabilizers in the array. 

The erroneous phase-flip Z<sup>ˆ</sup> a causes sign changes in the measurement outcomes of the two measure-X qubits adjacent to qubit a, allowing us to detect and localize the phase-flip error. We could then apply a second Z<sup>ˆ</sup> a operator to this qubit, correcting the error (using the fact that Z<sup>ˆ</sup> a<sup>2=Iˆa);howeverthisphase-flipcannotbeapplied</sup> with 100% fidelity, so this could introduce more errors into the surface code state. It is safer to instead handle this phase-flip error in software, by recording on which qubit the phase-flip error occurred. The classical control software simply changes the sign of every subsequent measurement of that data qubit’s two adjacent measureX qubits, thus correcting for the effects of the error. The two neighboring measure-Z qubits are not affected by the error, so their measurement outcomes do not need to be corrected. Both bit- and phase-flip errors are handled in this way, with bit-flip errors corrected by changing the sign of the affected qubit’s neighboring measure-Z qubits, leaving the measure-X outcomes unchanged. A second bit-flip error would cancel the first bit-flip error, and a second phase-flip error would cancel the first phase-flip, and any measurement corrections would then end. 

Error detection requires that we locate and identify errors. A single data qubit Z<sup>ˆ</sup> a error is signaled by changes in the measurement outcomes of the two measure-X qubits adjacent to the affected data qubit, with the changes occurring in one surface code cycle. Single qubit Xˆa errors, projecting to the state Xˆa|ψ⟩, will generate sign changes in the two measure-Z outcomes neighboring the data qubit, while the two neighboring measure-X outcomes will be unchanged. A Y<sup>ˆ</sup> a = Z<sup>ˆ</sup> aX<sup>ˆ</sup> a error, projecting to the eigenstate Z<sup>ˆ</sup> aX<sup>ˆ</sup> a|ψ⟩, will be signalled by sign changes in both of the neighboring measure-X and measure-Z qubits. These types of errors with their correlated signals are shown in Fig. 2. Once such an error has occurred, the state resulting from the projective measurements is again a quiescent state, with the difference from the original |ψ⟩ reported by the measurement outcomes. 

Errors occurring in the measurement process itself must also be considered; one such error will yield a sign change for that measure qubit only. On the next cycle, this measurement error will likely vanish, so this error will typically be signaled by a pair of sequential measurement changes occurring on a single measure qubit. Note that a measurement error could of course recur on the subsequent measurement, with a lower probability, and on the measurement following that, with an even lower probability, and so on. Establishing the value of a particular measurement therefore requires several surface code cycles, in order to catch single as well as sequential measurement errors. 

The signal from a measurement error, as it is typically isolated on a single measure qubit, is distinct from that of a data qubit error, which is reported by two or more 

8 



<!-- Start of picture text -->
- + + -<br>- - -<br>+ + + +<br>+ - +<br>- + - -<br>Y<br>- + - + M<br>- + +<br>+ + - +<br>+ - +<br>- + - -<br>X<br>Z - + - -<br>- + +<br>- + - +<br>- + +<br>+ + - -<br>X X X X<br>X X X X X X X X<br>X Z X Z X Z X<br>Z Z Z Z Z Z<br>X Z X Z X Z X<br>X X X X X X X X<br>X Z X Z X Z X<br>Z Z Z Z Z Z<br>X Z X Z X Z X<br>X X X X X X X X<br>X X X X<br>time<br><!-- End of picture text -->

FIG. 2. (Color online) Schematic evolution of measurement outcomes (filled circles with ± signs), over a segment of the 2D array. Time progresses moving up from the array at the bottom of the figure, with measurement steps occurring in each horizontal plane. Vertical heavy red (gray) lines connect time steps in which a measurement outcome has changed, with the spatial correlation indicating an X<sup>ˆ</sup> bit-flip error, a Zˆ phase-flip error, a Yˆ = ZˆXˆ error, and temporal correlation a measurement (M ) error, which is sequential in time. 

measurements separated in space. Other types of errors, such as CNOT errors, are discussed in [22], and also generate distinct patterns of sign changes in the measure-X and measure-Z qubits. 

If the errors are sufficiently rare, the error signals will be well-isolated on the 2D array, i.e. in space as well as in time. The error signals can then be matched up to deduce which specific qubit error occurred, with very high probability of correctly identifying the error. Given the linearity of a quantum computer, if all the qubit errors that occur are correctly identified, it is possible to correct for all these errors in the classical control software, by applying corrective phase- and bit-flips to the qubit measurements, as discussed above. However, if the errors in the array are not so sparse, error identification becomes less straightforward. The inverse problem, determining which qubit errors actually occurred to generate a given set of error signals, does not have a unique solution, and alternative sets of qubit errors become likely as the error density increases. If mistakes are made in backing out the qubit errors, these mistakes will result in erroneous conclusions about the computational result. Ultimately this limits the surface code’s ability to handle errors. 

We will return to this discussion after introducing the surface code logical operators. 

### VI. LOGICAL OPERATORS 

How does one perform quantum logic in the surface code? It may appear that the surface code completely stabilizes the 2D array, and that it therefore locks the quantum system in a particular state, as in our earlier two-qubit example. However, the set of surface code stabilizers is actually not always complete, so the array can have additional degrees of freedom. These additional degrees of freedom can be used to define logical operators, the first step in defining a logical qubit. We can see this by considering the small 2D array shown in Fig. 3. This array has been drawn with two types of boundaries, terminating with measure-X qubits on the right and left, which we call X boundaries, and terminating with measure-Z qubits on the top and bottom, which we call Z boundaries. The X boundaries are called smooth boundaries in the surface code literature, while Z boundaries are called rough boundaries [20]. 

If we count the number of data and measure qubits in the array, we find there are 41 data qubits and 40 measure qubits, so there are 2 × 41 degrees of freedom in the data qubits with 2×40 constraints from the stabilizer measurements (each measurement is real-valued, thus the factor of two). The stabilizers in this array are all linearly independent, and no stabilizer can be written as a product of the other stabilizers, so these 2 × 40 constraints are all linearly independent.<sup>10</sup> The two unconstrained degrees of freedom indicate that this small array might serve as a (single) logical qubit; we still need to define the logical operators that manipulate these degrees of freedom. 

How do we find the operators that will allow us to manipulate the additional degrees of freedom in the array, without affecting the stabilizers? A clue is provided by the fact that the stabilizer measurements commute because the stabilizers share pairs of data qubits. If we pair up operations on pairs of data qubits, we can create multi-qubit operator products that commute with the stabilizers; this is how we will build the logical operators, which we will term X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L. 

We remind the reader that a single data qubit X<sup>ˆ</sup> operation changes the measure-Z outcomes on either side of the data qubit. Consider however two simultaneous X<sup>ˆ</sup> operations on two data qubits a and b that both neighbor 

> 10 This is true for almost all arrays: With N measure qubits, there are 2N linearly independent constraints on the array wavefunction |ψ⟩. The two exceptions to this are arrays with uniquely X or uniquely Z boundaries. In these cases one of the X<sup>ˆ</sup> ( Z<sup>ˆ</sup> ) stabilizers can be written as a product of all the other X<sup>ˆ</sup> ( Z<sup>ˆ</sup> ) stabilizers. As the stabilizers all commute, this in turn means that this one stabilizer does not impose an additional constraint, so with N measure qubits you only have 2N − 2 constraints. However, in these arrays there are only N − 1 data qubits, so in this situation the quiescent state is completely determined by the stabilizers, with no additional degrees of freedom. 

9 

one measure-Z qubit. Then we have 



In other words, the product of two X<sup>ˆ</sup> operations commutes with a single Z<sup>ˆ</sup> stabilizer: [ Z<sup>ˆ</sup> aZ<sup>ˆ</sup> bZ<sup>ˆ</sup> cZ<sup>ˆ</sup> d, X<sup>ˆ</sup> aX<sup>ˆ</sup> b] = 0. Consider now Fig. 3, in particular the operation X<sup>ˆ</sup> 1 on the left boundary. This operation is detected by the measure-Z qubit just to the right of the flipped data qubit, but we can at the same time perform an Xˆ2 operation on the data qubit on the other side of that measure-Z. The first Z<sup>ˆ</sup> stabilizer now commutes with the product of these two operations, but the measureZ qubit to the right of X<sup>ˆ</sup> 2 still reports a change; hence we add a third operation X<sup>ˆ</sup> 3 to the set, and so on, until we have created a product of concurrent X<sup>ˆ</sup> operations X<sup>ˆ</sup> L = X<sup>ˆ</sup> 1X<sup>ˆ</sup> 2X<sup>ˆ</sup> 3X<sup>ˆ</sup> 4X<sup>ˆ</sup> 5, which connects the two X boundaries on the left and right sides of the array. Every measure-Z qubit now interacts with pairs of data qubits appearing in the X<sup>ˆ</sup> L operator, so by construction the product chain X<sup>ˆ</sup> L commutes with all the Z<sup>ˆ</sup> stabilizers in the array (note X<sup>ˆ</sup> L trivially commutes with the X<sup>ˆ</sup> stabilizers). Hence, if the X<sup>ˆ</sup> L operator is applied to a quiescent state |ψ⟩, generating the state |ψX ⟩ = X<sup>ˆ</sup> L|ψ⟩, the new state |ψX ⟩ will be a quiescent state with identical measurement outcomes to |ψ⟩. Note that |ψX ⟩ is not equal to |ψ⟩, as we have bit-flipped five data qubits in going from |ψ⟩ to |ψX ⟩, and as X<sup>ˆ</sup> L cannot be written as a product of stabilizers, |ψX ⟩ is not trivially related to |ψ⟩ (unless |ψ⟩ is an eigenstate of XL, namely |+L⟩ or |−L⟩). The X<sup>ˆ</sup> L operator thus manipulates one of the two degrees of freedom of the array in Fig. 3. 

The other degree of freedom in the array can be manipulated by constructing a Z<sup>ˆ</sup> L operator using a completely analogous product of Z<sup>ˆ</sup> data qubit operations: We again build a chain of operations using Z<sup>ˆ</sup> operators that are paired across each measure-X qubit that would otherwise report a measurement change. The chain of paired Z<sup>ˆ</sup> operators must cross the entire array, and further must start and end on a Z-boundary (rather than the X-boundaries on either end of the X<sup>ˆ</sup> L chain). An example of such a chain is Z<sup>ˆ</sup> L = Z<sup>ˆ</sup> 6Z<sup>ˆ</sup> 7Z<sup>ˆ</sup> 3Z<sup>ˆ</sup> 8Z<sup>ˆ</sup> 9 in Fig. 3. This Z<sup>ˆ</sup> L operator chain commutes with all the stabilizers in the array, and thus when operating on a quiescent state, generates a new quiescent state |ψZ⟩ = Z<sup>ˆ</sup> L|ψ⟩ with the same measurement outcomes as |ψ⟩. The state |ψZ⟩ clearly differs from |ψ⟩, as we have phase-flipped five data qubits, and as Z<sup>ˆ</sup> L cannot be written as a product of stabilizers, |ψZ⟩ is not trivially related to |ψ⟩; Z<sup>ˆ</sup> L thus manipulates a second degree of freedom in the array. We show below that XˆL and ZˆL do not commute, so they manipulate two independent degrees of freedom just as for a physical qubit. 

It may seem that we could choose other chains of single qubit operator products to define different XˆL or ZˆL operators. Consider for example the chain X<sup>ˆ</sup> L<sup>′=</sup> 



<!-- Start of picture text -->
ZL<br>Z Z Z Z Z Z 6 Z Z Z<br>X Z X Z X Z X Z X<br>X X X X X X X X<br>X Z X X 11 Z X Z X Z X<br>Z Z Z Z Z Z 7 Z Z Z<br>X Z X Z X Z X Z X<br>X X 10 X Z X X X Z X X 12 X Z X 3 Z X X X Z X X<br>XL Z Z Z Z Z Z Z Z d=5<br>X X 1 Z X X 2 Z X3 X Z X X 4 Z X X 5<br>X X X X X X X X<br>X Z X Z X Z X Z X<br>Z Z Z Z Z Z 8 Z Z Z<br>X Z X Z X Z X Z X<br>X X X X X X X X<br>X Z X Z X Z X Z X<br>Z Z Z Z Z Z 9 Z Z Z<br><!-- End of picture text -->

FIG. 3. (Color online) A square 2D array of data qubits, with X boundaries on the left and right, and Z boundaries on the topXˆ andandZ<sup>ˆ</sup> bottom.stabilizers.TheAarrayproducthas 41chaindataX<sup>ˆ</sup> Lqubits,= X<sup>ˆ</sup> 1butX<sup>ˆ</sup> 2X<sup>ˆ</sup> only3X<sup>ˆ</sup> 4X40<sup>ˆ</sup> 5 of X<sup>ˆ</sup> operators connects the two X boundaries, commutes withfrom allthethequiescentarray stabilizersstate |ψ⟩ andto |ψchangesX ⟩ = XˆtheL|ψarray⟩ withstatethe same measurement outcomes as |ψ⟩. A second product chain ZˆL = Zˆ6 ˆZ7 ˆZ3 ˆZ8 ˆZ9 connects the two Z boundaries and commutesfrom |ψwith⟩ to the|ψZarray⟩ = Z<sup>ˆ</sup> stabilizers;L|ψ⟩. Theitoperatorchanges chainsthe arrayXˆLstateand ZchainˆL anti-commute.XˆL<sup>′=</sup> Xˆ1X<sup>ˆ</sup> 10AX<sup>ˆ</sup> 11modificationX<sup>ˆ</sup> 12X<sup>ˆ</sup> 3X<sup>ˆ</sup> 4X<sup>ˆ</sup> 5of generatesthe X<sup>ˆ</sup> L chaina quiescentto the state |ψX `′` ⟩ = X2,10,11,12|ψX ⟩, related to |ψX ⟩ by the result of the measurement X2,10,11,12 = ±1 of the encircled measure-X qubit (outlined in black). 

Xˆ1Xˆ10Xˆ11Xˆ12Xˆ3Xˆ4Xˆ5, also shown in Fig. 3. This chain of X<sup>ˆ</sup> operators satisfies the same conditions as X<sup>ˆ</sup> L, as the Xˆ data qubit operators are paired so as to bracket each measure-Z qubit. Hence X<sup>ˆ</sup> L<sup>′commutes with all the stabi-</sup> lizers, and will generate a quiescent state |ψX `′` ⟩ = X<sup>ˆ</sup> L<sup>′|ψ⟩</sup> with the same measurement outcomes as |ψ⟩ and |ψX ⟩. However the state |ψX<sup>`′`</sup> ⟩ is actually linearly related to |ψX ⟩: First, note that we can manipulate the set of operators appearing in X<sup>ˆ</sup> L<sup>′,as</sup> 



where we have used X<sup>ˆ</sup> 2<sup>2=Iˆingoingfromthefirstto</sup> the second line in Eq. (7). Now, the operator product in parentheses in the third line of Eq. (7) is just the stabilizer outlined in black in Fig. 3: In other words, we have simply multiplied X<sup>ˆ</sup> L by an operator product that is stabilized to a ±1 eigenvalue by the surface code. If we operate on a quiescent state |ψ⟩ with X<sup>ˆ</sup> L<sup>′,wecansimply</sup> 

10 

replace this operator product by its eigenvalue: 



where X2,10,11,12 = ±1 is the measurement outcome of the stabilizer X<sup>ˆ</sup> 2X<sup>ˆ</sup> 10X<sup>ˆ</sup> 11X<sup>ˆ</sup> 12. This holds for any operator XˆL<sup>′thatcanbewrittenasastabilizedoperatorproduct</sup> times X<sup>ˆ</sup> L, that is X<sup>ˆ</sup> L<sup>′|ψ⟩=± ˆXL|ψ⟩,wherethesignis</sup> determined by the measurement outcomes of the corresponding stabilizers. In fact, any X<sup>ˆ</sup> L<sup>′chainthatcrosses</sup> the array in Fig. 3 can be written as X<sup>ˆ</sup> L multiplied by a product of X<sup>ˆ</sup> stabilizers, as can easily be verified. Hence there is only one linearly independent X<sup>ˆ</sup> L operator for this array. 

This result may seem mysterious; after all, if we operate on the array with a loop of X<sup>ˆ</sup> operators corresponding to a stabilizer, e.g. the loop X<sup>ˆ</sup> loop = X<sup>ˆ</sup> 2X<sup>ˆ</sup> 10X<sup>ˆ</sup> 11X<sup>ˆ</sup> 12, we are bit-flipping four data qubits, so the state |ψ<sup>′</sup> ⟩ = Xˆloop|ψ⟩ should be different from |ψ⟩. However, the fact that X<sup>ˆ</sup> loop is equal to a stabilizer means that |ψ⟩ already includes superposition states of the un-bit-flipped and the bit-flipped states of the data qubits involved in X<sup>ˆ</sup> loop; this holds for any operator that is equal to the product of one or more stabilizers.<sup>11</sup> 

The same argument applies to alternative Z<sup>ˆ</sup> L<sup>′opera-</sup> tors: Any such operator is equal to the original Z<sup>ˆ</sup> L multiplied by a product of Z<sup>ˆ</sup> stabilizers, and thus any Z<sup>ˆ</sup> L<sup>′|ψ⟩</sup> differs from Z<sup>ˆ</sup> L|ψ⟩ by ±1. Hence there is also only one linearly independent Z<sup>ˆ</sup> L operator for this array. 

We now show that the two operators X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L satisfy the critical anti-commutation relation in Eq. (1). We have 



where all the single qubit operations are on different qubits, and thus commute, except for X<sup>ˆ</sup> 3 and Z<sup>ˆ</sup> 3, which anti-commute, X<sup>ˆ</sup> 3Z<sup>ˆ</sup> 3 = −Z<sup>ˆ</sup> 3X<sup>ˆ</sup> 3. This makes X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L anti-commute. The logical operators X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L therefore have exactly the same commutation relation as the physical qubit operators X<sup>ˆ</sup> and Z<sup>ˆ</sup> . You can show that XˆL<sup>2=Zˆ</sup> L<sup>2=Iˆ.Wecanalsoconstructthelogicalop-</sup> erator Y<sup>ˆ</sup> L = Z<sup>ˆ</sup> LX<sup>ˆ</sup> L, comprising two chains of Z<sup>ˆ</sup> and X<sup>ˆ</sup> 

> 11 In other words, if |ψ⟩ includes qubits 2, 10, 11 and 12 in the state | . . .+−++ . . .⟩, then |ψ⟩ must also include the state where these qubits are in | . . . − + −− . . .⟩, i.e. |ψ⟩ = ±| . . . + − + + . . .⟩± | . . . − + −− . . .⟩ + . . .. Then operating with X<sup>ˆ</sup> loop on |ψ⟩ flips Xtheˆloopfirst|ψ⟩state= ∓|to . . .the − +second −− . . .and⟩∓|vice . . .versa without + − + + . . .⟩ +changing . . . = ∓||ψψ⟩⟩., 

operators that each cross the array. The set of logical operators X<sup>ˆ</sup> L, Y<sup>ˆ</sup> L and Z<sup>ˆ</sup> L satisfy all the commutation relations in Eq. (1), thus making this 2D array a logical qubit. 

We will be using the logical operators X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L to manipulate the degrees of freedom in the 2D array that are not constrained by the stabilizers. The state |ψ⟩ describes the quantum state of all the data qubits; the surface code measurements ensure that |ψ⟩ is an eigenstate of all the stabilizers, but in the case where we have more data qubits than stabilizers, |ψ⟩ is not completely constrained. We can therefore write |ψ⟩ as an outer product, |ψ⟩ = |Q⟩|qL⟩, where |Q⟩ is a vector in the 2<sup>N</sup> - dimensional Hilbert subspace on which the N stabilizers operate, with |Q⟩ constrained to a unique state in this Hilbert space, as determined by the N stabilizer measurement outcomes. The remaining degrees of freedom in |ψ⟩ are captured by |qL⟩. For the array in Fig. 3, with two unconstrained degrees of freedom, |qL⟩ is in a two-dimensional Hilbert space, i.e. represents a single qubit state. The stabilizers have no effect on |qL⟩, and the logical operators X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L have no effect on |Q⟩. The eigenstates of Z<sup>ˆ</sup> L are |qL⟩ = |gL⟩ and |qL⟩ = |eL⟩, such that Z<sup>ˆ</sup> L|gL⟩ = +|gL⟩ and Z<sup>ˆ</sup> L|eL⟩ = −|eL⟩, while the corresponding eigenstates of X<sup>ˆ</sup> L are |qL⟩ = |±L⟩ = (|gL⟩± |eL⟩)/√2, with eigenvalues ±1. Either pair, |gL⟩ and |eL⟩ or |+L⟩ and |−L⟩, can be used as a basis for the states |qL⟩. We can to some extent ignore the presence of |Q⟩ when discussing manipulations of the logical state |qL⟩. 

So far we have only shown how to define a single logical qubit in our array; later we will show how to make larger numbers of logical qubits within an array, which is done by creating more degrees of freedom within the array. Each logical qubit we create will increase the size of the logical Hilbert space of |qL⟩ by two and concomitantly reduce the size of the stabilizer Hilbert space of |Q⟩ by two. With n logical qubits, the Hilbert space for |qL⟩ has dimension 2<sup>n</sup> . 

### VII. ERROR DETECTION 

Now that we can construct surface code logical operators, we turn again to the consideration of errors in the surface code. The errors we consider here are on the physical qubits, either the data or the measure qubits. Errors occur due to single qubit errors (erroneous X<sup>ˆ</sup> , Y<sup>ˆ</sup> or Z<sup>ˆ</sup> operations), measurement errors (reporting the incorrect outcome and projecting to the wrong state), initialization errors (setting a qubit to the wrong state), Hadamard errors (performing a Hadamard but in addition performing an erroneous X<sup>ˆ</sup> , Y<sup>ˆ</sup> or Z<sup>ˆ</sup> ), and CNOT errors. Individual errors of these types are of course the most likely, but concatenated errors can also occur, for example two, three, or more adjacent data qubits suffering X<sup>ˆ</sup> errors in one surface code cycle, creating what are 

11 

called error chains. 

The surface code can deal with all these errors as long as the errors that occur during each surface code cycle can be identified (i.e. decoding which specific error(s) occurred on which particular qubit(s)).<sup>12</sup> Once identified, these errors can be tracked and the information used to correct any subsequent measurement outcomes using the classical control software. Edmonds’ minimumweight perfect-matching algorithm [43, 44] provides an automated method for doing this, and works perfectly for sufficiently sparse errors, but begins to fail as the error density increases, and as the length of the error chains increases. Numerical simulations using this type of algorithm can therefore provide estimates of the tolerance of the surface code to different types of errors. An example of a set of simulations of this kind is shown in Fig. 4. 

The simulations used to generate Fig. 4 include the following types of errors, occurring during the surface code cycle shown in Fig. 1: 

1. Attempting to perform a data qubit identity I<sup>ˆ</sup> , but instead performing a single qubit operation X<sup>ˆ</sup> , Y<sup>ˆ</sup> , or Z<sup>ˆ</sup> , each occurring with probability p/3. 

2. Attempting to initialize a qubit to |g⟩, but instead preparing |e⟩ with probability p. 

3. Attempting to perform a measure qubit Hadamard operation H<sup>ˆ</sup> , but performing in addition one of the single qubit operations X<sup>ˆ</sup> , Y<sup>ˆ</sup> , or Z<sup>ˆ</sup> , each with probability p/3. 

4. Performing a measure qubit Z<sup>ˆ</sup> measurement, but reporting the wrong value and projecting to the wrong state with probability p. 

5. Attempting to perform a measure qubit-data qubit CNOT, but instead performing one of the two-qubit operations I<sup>ˆ</sup> ⊗X<sup>ˆ</sup> , I<sup>ˆ</sup> ⊗Y<sup>ˆ</sup> , I<sup>ˆ</sup> ⊗Z<sup>ˆ</sup> , X<sup>ˆ</sup> ⊗I<sup>ˆ</sup> , X<sup>ˆ</sup> ⊗X<sup>ˆ</sup> , X<sup>ˆ</sup> ⊗Y<sup>ˆ</sup> , Xˆ ⊗ Zˆ, Yˆ ⊗ Iˆ, Yˆ ⊗ Xˆ , Yˆ ⊗ Yˆ , Yˆ ⊗ Zˆ, Zˆ ⊗ Iˆ, Zˆ ⊗ Xˆ , Zˆ ⊗ Yˆ or Zˆ ⊗ Zˆ, each with probability p/15.<sup>13</sup> 

The errors occur randomly during the simulation, with no correlation between errors. The probability p is per step in the surface code cycle (there are eight steps in the cycle used for the simulation (Fig. 1), so the overall rate per cycle of the surface code is approximately 8p, as discussed in more detail in Sect. VII B). Edmonds’ matching algorithm maps changes detected in the stabilizer outcomes to physical qubit errors; the rate at which 

> 12 Actually the surface code does not need to completely identify errors; it is sufficient that it identifies errors or chains of errors that are topologically equivalent to the actual errors, meaning any differences can be written as products of stabilizers. 

> 13 AHereˆ ⊗ B<sup>ˆ</sup> weoperatesuse the ontwo-qubitthe two-qubitouter productstate |abnotation⟩, the A<sup>ˆ</sup> Aoperatorˆ ⊗ B<sup>ˆ</sup> . Whenacts on qubit a’s part of the state, and B<sup>ˆ</sup> acts on qubit b’s part of the state. 

the algorithm makes mistakes, meaning it misidentifies the source of a particular error report, is displayed as PL, the number of X<sup>ˆ</sup> L errors appearing anywhere in the array, per surface code cycle.<sup>14</sup> This error rate is plotted as a function of the per-step error rate p. 

The relation between PL and p depends very strongly on a very important number, the array size d, which we will also call the distance of the array: d is the minimum number of physical qubit bit-flips or phase-flips needed to define an X<sup>ˆ</sup> L or Z<sup>ˆ</sup> L operator. In Fig. 3, for example, we need a minimum of five physical operators to define a logical operator, so that array has a distance d = 5. At distance d = 55, the largest appearing in the simulations in Fig. 4, the equivalent array would have 55 data qubits along the horizontal and 55 data qubits along the vertical. 

For small p, PL is small, and gets smaller as d increases. For large p, PL is larger, and gets larger as d increases. The cross-over between these two regimes occurs when p crosses a threshold error rate pth: For p < pth, the logical error rate falls exponentially with d, while for p > pth, PL increases with d. In Fig. 4, which applies to the stabilizer circuits in Fig. 1 simulated with the error sources listed above, the threshold rate is pth = 0.57%. We note this threshold is smaller than some of those mentioned earlier; this is in part because the threshold depends on the particular surface-code implementation, but mostly because we include more types of errors than were considered in earlier publications. As we discuss in more detail in Sect. VII B, the logical error rate PL responds in a strikingly different way to different types of errors. 

For error rates p < pth, the simulations show that the logical error rate scales with p according to the power law PL ∼ p<sup>de</sup> , where we define the error dimension for odd d as 



For even d, we round down, so de = d/2. Using this, the error rate PL shown in Fig. 4 can be approximated more specifically by the empirical formula 



### A. Statistical model for the logical error rate 

We can qualitatively understand the scaling in Eq. (11) by looking at the types of errors for which the matching algorithm fails. Consider Fig. 5a, in which two measure-Z qubits are reporting errors, marked by “E”s in the figure. Two examples of sets of data qubit errors that would 

> 14 There are of course also ZˆL errors, occurring at about the same rate as X<sup>ˆ</sup> L errors; here we are interested in identifying the scaling relation between physical qubit error rate and the resulting logical error rate, a scaling that is very similar for X<sup>ˆ</sup> L errors and ZˆL errors, so we only look at the scaling for XˆL errors. 

12 



<!-- Start of picture text -->
10 -1 (a) Z EZZ Z Z ZZ Z Z EZZ Z Z ZZ Z<br>d=3<br>d=5d=7 Z E Z E Z Z<br>10 -3 d=9d=11 (b) Z Z Z X Z Z Z X Z Z Z Z Z Z<br>d=15<br>d=25 E Z Z Z E Z E<br>d=35<br>d=45 (c) Z Z Z Z Z Z Z Z<br>10 -5 pth d=55 X Z Z Z X Z X<br>10 -4 10 -3 10 -2<br>FIG. 5. (Color online) (a) An example where two<br>qubits report errors in a single row of a 2D array,<br>d=3 by “E”s. This error report could be generated by<br>d=7 errors appearing in the same surface code cycle on the 2nd and<br>d=11 3rd data qubit from the left, or (c) three X ˆ errors<br>d=25 in the other three data qubits in the row.<br>d=55<br>timated using simple statistical arguments,<br>only errors on the data qubits (and ignoring<br>10 -4 10 -3 10 -2 in the CNOTs between measure qubits and<br>Per-step error rate  p [22]). Chains of errors will give the same<br>Logical X error rate PL<br>Logical X error rate PL<br><!-- End of picture text -->

FIG. 5. (Color online) (a) An example where two measure-Z qubits report errors in a single row of a 2D array, marked by “E”s. This error report could be generated by (b) two X<sup>ˆ</sup> errors appearing in the same surface code cycle on the 2nd and 3rd data qubit from the left, or (c) three X<sup>ˆ</sup> errors appearing in the other three data qubits in the row. 

timated using simple statistical arguments, considering only errors on the data qubits (and ignoring e.g. errors in the CNOTs between measure qubits and data qubits [22]). Chains of errors will give the same measurement outcomes if they are complementary in the way shown in Fig. 5; more formally, two chains of errors are complementary if their product is an array-crossing chain that commutes with all the stabilizers. Since the shortest error chains are the most likely, we need only consider minimum-length array-crossing chains, which have d operators and can cross the array in any one of the d data qubit rows. The most likely misidentifications occur between error chains with length de − 1 = (d − 1)/2 that are complementary to error chains of length de = (d + 1)/2. For a chain of errors in a given row, the number of possible de-fold errors is d(d − 1) . . . de/de!, where the denominator appears because error order does not matter. Given a per-step error rate p, the per-cycle individual error rate is pe<sup>∼</sup> = 8p, as there are eight steps per cycle. The total X<sup>ˆ</sup> L error rate PL<sup>sfromthesestatisticalarguments</sup> is then 

FIG. 4. (Color online) (a) Numerical simulations of surface code error rates, and how these error rates scale with the distance d of the array. Per-step error rates p less than the per-step threshold error rate of pth = 0.57% (dashed line) yield surface code logical error rates PL that vanish rapidly with increasing d. This threshold corresponds to roughly a 4% error rate for the entire surface code measurement cycle. (b) Estimated error rates, using statistical arguments given in main text, for array distances d = 3, 7, 11, 25 and 55. Note the estimate gives a logical error rate PL and a per-step threshold that are qualitatively similar to those from the more precise simulations. 

generate this error report are shown in Fig. 5b and c: In b, two of the five data qubits had X<sup>ˆ</sup> errors, while in c, the other three data qubits had X<sup>ˆ</sup> errors. These two events look identical in terms of measurement outcomes. A natural conclusion would be to assume that just two data qubit errors have occurred; this is of course more likely, as this will occur with probability proportional to p<sup>2</sup> , while the triple error shown in Fig. 5c will occur at a rate scaling as p<sup>3</sup> . More generally, for arrays with distance d, the most misidentifications will occur when (d + 1)/2-fold qubit errors are misidentified as (d − 1)/2fold errors, where the rate these misidentifications occur scales as p<sup>de</sup> . This explains the general scaling seen in Fig. 4 and in Eq. (11), and underlines the primary result that misidentification of qubit errors causes logical errors, and that large arrays are less error-prone than small arrays. 



where the factor of d accounts for the d independent rows in the array. A plot of this prediction is shown in Fig. 4b, and is seen to scale in a way similar to the simulations in Fig. 4a. 

We can use these scaling relations to estimate the number of qubits needed to obtain a desired logical error rate. Using Eq. (11) for the error probability, we plot in Fig. 6 the total number nq of data and measurement qubits, nq = (2d−1)<sup>2</sup> , versus error rate normalized to the threshold p/pth < 1, for three values of the logical error rate PL. We find that nq increases rapidly as p approaches the threshold pth, so that a good target for the gate fidelity is above about 99.9% (p `≲` 10<sup>−3</sup> ). In this case, a logical qubit will need to contain 10<sup>3</sup> − 10<sup>4</sup> physical qubits in order to achieve logical error rates below 10<sup>−14</sup> − 10<sup>−15</sup> , 

The magnitude of the logical error rate can be es- 

13 



<!-- Start of picture text -->
10 5<br>d=<br>10 4<br>40<br>PL  = 10 -20<br>10 3 20<br>10 -10<br>10<br>10 2<br>10 -5 5<br>10 1<br>10 -2 10 -1 10 0<br>Single step error rate  p / pth<br>Number of qubits nq<br><!-- End of picture text -->

FIG. 6. (Color online) Estimated number of physical qubits nq per logical qubit, versus the single-step error rate p, the latter normalized to the threshold error rate pth, plotted for different target logical error rates PL. Notation on the right axis corresponds to the array distance d for a single logical qubit. 

sufficient to perform Shor’s algorithm with a reasonable chance of success.<sup>15</sup> 

Similar considerations apply when detecting and identifying errors in time as opposed to the spatiallycorrelated errors discussed above. If the measurement process gives errors at the rate pM per surface code cycle, the probability of double errors (the same error twice in a row) is p<sup>2</sup> M<sup>, and so on.A particular pattern of errors</sup> in time will suffer misidentifications following the same scaling as in Eq. (12), so we find that we need roughly the same distance d in time (measured in complete surface code cycles) as we do in space to maintain the minimum logical error rate, assuming the measurement error rate pM is comparable to the physical qubit error rate p. 

More complete calculations of this type can be found in Ref. [45]. 

### B. Logical error rate for different error classes 

The logical error rates calculated from simulations such as in Fig. 4 depend on which types of errors are simulated, as well as the number of opportunities there are for each type of error. Errors that occur on the data qubits, primarily data qubit identity (“idle”) operations that are replaced by erroneous X<sup>ˆ</sup> , Y<sup>ˆ</sup> or Z<sup>ˆ</sup> operations, we term “class-0” errors. There are four opportunities per sur- 

> 15 The target logical error rate of 10−14 − 10−15 is explained in Appendix M, and is mostly due to the need to distill a large number of highly purified |AL⟩ states to complete the modular exponentiation in Shor’s algorithm. 

face code cycle for such errors on each data qubit (there are a total of eight surface code cycle steps in Fig. 1, during four of which each data qubit is undergoing a CNOT, leaving four steps in which the data qubit is idle). Errors that occur on the measure qubits, namely initialization, measurement, and Hadamard operations, we term “class-1” errors; note that errors occurring during the two measure-Z identity I<sup>ˆ</sup> (idle) steps have no impact, as they are followed by a ground-state initialization of the measure-Z qubit, so these errors cannot propagate. Each measure-X qubit has four opportunities for class-1 errors per surface code cycle, and each measure-Z two opportunities. There is thus an average of three opportunities per surface code cycle for a class-1 error. Finally, errors in the measure qubit-data qubit CNOT operations we term “class-2” errors. There are four steps per cycle during which class-2 errors can occur, corresponding to the four CNOTs for each measure qubit. 

The logical error rate is least sensitive to class-1 errors, is more sensitive to class-0 errors, and is the most sensitive to class-2 errors. This is demonstrated by simulations in which we examine the dependence of the logical error rate PL on the error rate from each error class separately, with the error rate from the other error classes set to zero, shown in Fig. 7. It is readily apparent that the different error classes have very different thresholds, with the class-0 errors in Fig. 7a having a per-step threshold of 4.3% and a per-cycle threshold of 15.5% (the per-cycle value is not quite four times the per-step value, as multiple errors can cancel). The class-1 measure-Z qubit errors shown in Fig. 7b have a per-step threshold of 25%, translating to a per-cycle threshold of 50% as there are two opportunities for class-1 measure-Z errors per surface code cycle; the equivalent plot for measure-X qubits has a per-step threshold of 12.5%, and as there are four opportunities for class-1 errors per cycle in the measure-X qubits, the per-cycle threshold is again 50%. The class-2 errors shown in Fig. 7c have a per-step threshold of 1.25% (per-cycle threshold of ∼ 5%). Clearly the sensitivity to class-2 errors is greatest and to class-1 errors the smallest. 

We can find empirical expressions for the scaling of the logical error rates due to each error class: 



Here the rates p0, p1 and p2 and their thresholds are per step in the surface code cycle, while the logical error rates are per surface code cycle. The logical error rates display the same dependence on the error dimension de = (d + 1)/2 (in terms of the array distance d) as the expression for the total logical error rate PL given in Eq. (11), but 

14 



<!-- Start of picture text -->
10 -1<br>d =3<br>d =5<br>10 -2 d =7<br>d =9<br>d =11<br>d =15<br>10 -3 d =25<br>d =35<br>d =45<br>(a) Class 0 d =55<br>10 -4<br>0.6<br>0.4 d =3<br>d =5<br>d =7<br>d =9<br>d =11<br>0.2 d =15<br>d =25<br>d =35<br>(b) Class 1<br>0.1<br>10 -1<br>d =3<br>d =5<br>10 -2 d =7<br>d =9<br>d =11<br>d =15<br>10 -3 d =25<br>d =35<br>d =45<br>(c) Class 2 d =55<br>10 -4<br>10 -2 10 -1<br>Physical qubit error rate ( p )<br>Logical X error rate () PL<br>Logical Z error rate () PL<br>Logical X error rate () PL<br><!-- End of picture text -->

FIG. 7. (Color online) X<sup>ˆ</sup> L error rate PL per surface code cycle as a function of the per-step physical error rate p, considering only (a) class-0 (data qubit) errors, (b) class-1 (measure qubit) errors and (c) class-2 (CNOT) errors (see text for full definition). For the class-1 errors in (b), results are for initialization and measurement errors in measure-Z qubits, with two opportunities per surface code cycle, while the equivalent for measure-X qubits includes Hadamard errors, with four opportunities per cycle. 

with different thresholds for each class of error. 

The dependence of the overall logical error rate on the three classes of errors occurring concurrently is shown in Fig. 8, where we display the contours of error rates (p0, p1, p2) that give a total logical error rate PL = 0.02, approximately the value of PL at threshold. This figure shows that class 0 and 2 errors have roughly equal impact on PL, while PL is roughly five times less sensitive to class 1 errors. 



<!-- Start of picture text -->
0.012<br>0.008 Class-1 error<br>rate  p 1<br>0.004<br>p 1=0.05 0.02 0.01 0.003 0.001<br>0<br>0 0.01 0.02<br>Class-0 error rate  p 0<br>Class-2 error rate  p 2<br><!-- End of picture text -->

FIG. 8. (Color online) Contours of the three error class error rates p0, p1 and p2 that combine to give the error threshold, corresponding to the total logical error rate PL = 0.02. Data are from a distance d = 9 numerical simulation, and lines are guides to the eye. The green dot (upper vertical axis) is the class-2 error rate giving PL = 0.02 with no class-0 or class-1 errors. 

Returning to the general error rate discussion, we see that the surface code is able to handle a per-step physical qubit error rate up to the threshold pth = 0.57%, while still preserving the integrity of logical states in the array. This is achieved by identifying the sources of these errors and accounting for them. The error tolerance improves as the array distance d increases; larger values of d give lower logical error rates than do smaller d, as long as the error rate p is smaller than the threshold pth. We see that the array distance d is an important parameter in the implementation. In fact, as we will see, the critical parameter is not the size of the entire 2D array, but instead the size of the logical qubits that are created within the array. We return to this topic in Section XII. 

At the fundamental level, we have physical qubits which are being projectively measured on every surface code cycle, with errors being continuously detected and accounted for in software. Errors that are not erased through the surface code measurement cycle cause changes in the quiescent state |ψ⟩, as indicated by changes in the stabilizer measurements. These errors do not affect the logical state |qL⟩, as they are restricted to the directly-stabilized part |Q⟩ of |ψ⟩ = |Q⟩|qL⟩. When however the matching algorithm makes a mistake, a logical error occurs, in which case typically both |Q⟩ and |qL⟩ are affected; however, for sufficiently small p, these errors are very rare, with the directly-stabilized |Q⟩ and the matching algorithm protecting the logical subspace of |qL⟩ from the vast majority of errors. 

When we build on this platform, we can often ignore the details of this error-accounting apparatus, and instead discuss manipulating the physical qubits without worrying about errors. At this level of abstraction, we are 

15 

thus dealing with “software-corrected” physical qubits. In the next few sections, we will be discussing the creation and operation of logical qubits; we will mostly ignore the error accounting for this discussion, to keep things simple, but we will return to this important issue when necessary. 

### VIII. CREATING LOGICAL QUBITS 

We have described one way to create the logical operators X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L, by building array-crossing chains of X<sup>ˆ</sup> and Z<sup>ˆ</sup> operators. These logical operators commute with all the stabilizers. However, as the chains of operators must cross the entire array, this becomes cumbersome for large arrays, and for arrays with only two X and two Z boundaries, only gives us a single logical qubit no matter how large the array. We can increase the number of logical qubits by creating more varied boundaries in the array; for example, using short alternating X and Z boundaries would allow the creation of multiple logical qubits, increasing the amount of information that can be stored. However, since you cannot deform in any nontrivial manner operators connecting sections of boundary of the same type in different locations as you cannot move sections of boundary of different types past one another, performing logical CNOTs between these boundary qubits is not possible, so this approach has limited utility. A much more powerful approach is to create holes (known as defects in the published literature) inside the boundaries of the array, which can be done by simply turning off one or more of the internal measure-X and measure-Z qubits (“turning off” means that the measure qubit no longer performs the surface code cycle of CNOTs followed by measurement). 

In Fig. 9 we show how this can be done, by turning off a single measure-Z qubit and creating a hole, which we call a “Z-cut hole”. Turning off the measure-Z qubit means that we no longer measure its stabilizer, which creates two additional degrees of freedom in the surface code array. We can manipulate these degrees of freedom in a similar fashion to the way we manipulate the array qubit, by defining logical operators X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L that anticommute. We will call this logical qubit a “single Z-cut qubit”. 

We have positioned the Z-cut hole near an X boundary of the array. Turning off the Z<sup>ˆ</sup> stabilizer leaves a small hole surrounded by measure-X qubits, i.e. this creates an internal X boundary. We define the operator X<sup>ˆ</sup> L = X<sup>ˆ</sup> 1X<sup>ˆ</sup> 2X<sup>ˆ</sup> 3, which connects the array’s outer X boundary with the internal X boundary of the hole. As can be seen, this logical operator comprises a chain of operators that are paired across each Z<sup>ˆ</sup> stabilizer, so it commutes with all the Z<sup>ˆ</sup> stabilizers in the array, and trivially commutes with the X<sup>ˆ</sup> stabilizers as well. We also define Z<sup>ˆ</sup> L = Z<sup>ˆ</sup> 3Z<sup>ˆ</sup> 4Z<sup>ˆ</sup> 5Z<sup>ˆ</sup> 6, a set of data qubit Z<sup>ˆ</sup> operators that form a loop around the Z-cut hole; the Z<sup>ˆ</sup> operators are paired across each X<sup>ˆ</sup> stabilizer, commuting with each 



<!-- Start of picture text -->
X1<br>X2 XL<br>X3<br>Z3<br>Z4 Z5 ZL<br>Z6<br>X X X X<br>Z X Z X Z<br>Z Z Z Z Z Z<br>Z X Z X Z<br>X X X X<br>Z X Z X Z<br>Z Z Z Z Z Z<br>Z X Z X Z<br>X X X X<br>Z X X Z<br>Z Z Z Z<br>Z X X Z<br>X X X X<br>Z X Z X Z<br>Z Z Z Z Z Z<br>Z Z Z<br><!-- End of picture text -->

FIG. 9. (Color online) A single Z-cut qubit. The array boundary is indicated by a solid black line (top), while the other three sides of the array continue outwards indefinitely. Two logical operators, X<sup>ˆ</sup> L = X<sup>ˆ</sup> 1X<sup>ˆ</sup> 2X<sup>ˆ</sup> 3 from the array’s outer X boundary to the internal X boundary of the Z-cut hole, and ZˆL = Zˆ3 ˆZ4 ˆZ5 ˆZ6 surrounding the Z-cut hole, are shown. Note that the operator chains for X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L have one physical data qubit in common (data qubit 3). 

of these, and trivially with all the Z<sup>ˆ</sup> stabilizers as well. This operator loop is not constrained by a Z<sup>ˆ</sup> stabilizer as it would be without the Z-cut hole, so it can change the quiescent state |ψ⟩ in a non-trivial way. 

The X<sup>ˆ</sup> L chain and the Z<sup>ˆ</sup> L loop share one data qubit, number 3 in Fig. 9. These two operators therefore anticommute: 



You can show that X<sup>ˆ</sup> L<sup>2=Zˆ</sup> L<sup>2=Iˆ,andwecandefine</sup> YˆL = ZˆLXˆL. Just as with the 2D array, we have created a set of anti-commuting operators associated with the Z-cut hole that satisfy all the requirements for a logical qubit, so the Z-cut hole is indeed a logical qubit. We note that if the outer perimeter of the array were a single Z boundary, there would be no way to build an appropriate XˆL chain between the Z-cut hole and the array boundary; furthermore, the product of all the Z<sup>ˆ</sup> stabilizers in the array would fix the value of Z<sup>ˆ</sup> L, so creating a Z-cut hole in a Z-boundary array would not create any additional degrees of freedom: At least one X boundary is necessary to create a single Z-cut qubit. Note the distance d of this qubit is d = 3, limited by the length of the X<sup>ˆ</sup> L chain; it could be increased to d = 4 by moving the hole one stabilizer cell further away from the array boundary, but d cannot be increased above 4 without creating a larger qubit hole (see Section XII). A single Z-cut qubit is called a smooth defect or a dual defect in the published literature. 

16 

An analogous single X-cut qubit can be formed by turning off a measure-X qubit in an array that has at least one Z boundary; a Z<sup>ˆ</sup> L operator is then a chain of Zˆ operators from the array Z boundary to the internal Z boundary created by turning off the measure-X qubit, and an X<sup>ˆ</sup> L operator is a loop of X<sup>ˆ</sup> bit-flips surrounding the X-cut hole. You can show that these logical operators satisfy the requisite anti-commutation relations. A single X-cut qubit is called a rough defect or a primal defect in the published literature. 

This concept can be made even more useful by making qubits that do not rely on operator chains that reach one of the array boundaries, simplifying their logical manipulation and greatly increasing the number of qubits that can be stored and manipulated simultaneously. An example of a “double Z-cut qubit,” achieved by turning off two measure-Z qubits in the array, is shown in Fig. 10. Making these two Z-cut holes adds four additional degrees of freedom to the array. We can manipulate each Z-cut hole separately by defining X<sup>ˆ</sup> L1 and Z<sup>ˆ</sup> L1 for the upper Z-cut hole, and X<sup>ˆ</sup> L2 and Z<sup>ˆ</sup> L2 for the lower Z-cut hole, in a way completely analogous to the single Z-cut qubit. These four linearly independent operators manipulate all four degrees of freedom, with each logical operator pair ( X<sup>ˆ</sup> Lj, Z<sup>ˆ</sup> Lj) commuting with the other pair but anti-commuting with each other. 

We can manipulate the two qubit holes in a correlated fashion by replacing X<sup>ˆ</sup> L1 by the product X<sup>ˆ</sup> L1X<sup>ˆ</sup> L2; this operator product anti-commutes with both Z<sup>ˆ</sup> L1 and Z<sup>ˆ</sup> L2, and together with X<sup>ˆ</sup> L2 provides the same functionality as X<sup>ˆ</sup> L1 and X<sup>ˆ</sup> L2 (note that we can recover X<sup>ˆ</sup> L1 by multiplying the operator product by X<sup>ˆ</sup> L2, using X<sup>ˆ</sup> L<sup>2</sup> 2<sup>=IˆL).</sup> Now, we can define a new X<sup>ˆ</sup> L operator linking the two qubit holes, shown in Fig. 10; this operator is the product of three data qubit X<sup>ˆ</sup> operators, and links the internal X<sup>ˆ</sup> boundary of the upper qubit to the internal X<sup>ˆ</sup> boundary of the lower qubit. If you examine the figure, you will see that the product X<sup>ˆ</sup> LX<sup>ˆ</sup> L1X<sup>ˆ</sup> L2 is equal to the product of all the stabilizers enclosed by these operators (these stabilizers have black outlines in Fig. 10). Hence, if we multiply XˆL1XˆL2 by all these stabilizers, we generate XˆL, so in fact X<sup>ˆ</sup> L is equivalent to X<sup>ˆ</sup> L1X<sup>ˆ</sup> L2 to within ±1 (the sign is equal to the product of all the enclosed stabilizers). Hence we can replace X<sup>ˆ</sup> L1X<sup>ˆ</sup> L2 by X<sup>ˆ</sup> L. 

We now have the operator set {X<sup>ˆ</sup> L, X<sup>ˆ</sup> L2, Z<sup>ˆ</sup> L1, Z<sup>ˆ</sup> L2}, where the logical X<sup>ˆ</sup> operators commute with one another, as do the logical Z<sup>ˆ</sup> operators, but X<sup>ˆ</sup> L anti-commutes with both Z<sup>ˆ</sup> L1 and Z<sup>ˆ</sup> L2, as these each have one data qubit in common; X<sup>ˆ</sup> L2 only anti-commutes with Z<sup>ˆ</sup> L2. 

We are only interested in manipulating two of the four degrees of freedom in this double qubit, as using all four degrees of freedom necessitates using operators that connect to potentially distant boundaries. This is not consistent with a 2-D layout of logical qubits as all of those long-range operators will tangle around one another when attempting to perform gates. It is necessary to make each logical qubit local, which means its opera- 



<!-- Start of picture text -->
Z Z Z Z Z Z Z Z Z Z<br>X Z X Z X Z X Z X Z X<br>X X X X X X X X X X<br>X Z X Z X X Z X X L1 Z X<br>Z Z Z Z L1 Z Z Z Z Z<br>X Z X Z X X Z X Z X<br>X X X X X X X X X X<br>X Z X Z X Z X Z X Z X<br>Z Z Z Z Z Z Z Z Z Z<br>X Z X Z X Z X Z X Z X<br>X X Z X X X Z X X X L X Z X X X Z X X X Z X X<br>Z Z Z Z Z Z Z Z Z Z<br>X Z X Z X Z X Z X Z X<br>X X X X X X X X X X<br>X Z X Z X X Z X Z X<br>Z Z Z Z L2 Z Z Z Z Z<br>X Z X Z X X Z X Z X<br>X X X X X X X X X L2 X X<br>X Z X Z X Z X Z X Z X<br>Z Z Z Z Z Z Z Z Z Z<br><!-- End of picture text -->

FIG. 10. (Color online) A double Z-cut qubit, formed by turning off two measure-Z qubits. For each Z-cut hole we can define the logical operators X<sup>ˆ</sup> L1 and Z<sup>ˆ</sup> L1, X<sup>ˆ</sup> L2 and Z<sup>ˆ</sup> L2, where X<sup>ˆ</sup> L1 and X<sup>ˆ</sup> L2 reach from the array X boundary on the right to the internal X boundary of each Z-cut hole, and ZˆL1 and ZˆL2 are loops surrounding each Z-cut hole. We can replace X<sup>ˆ</sup> L1 (dashed blue line) by the product X<sup>ˆ</sup> L1X<sup>ˆ</sup> L2, which performsXˆL2 providesan X<sup>ˆ</sup> equivalentL bit flip offunctionalityboth qubittoholes,the twoand separatealong withX<sup>ˆ</sup> operators. However, the product X<sup>ˆ</sup> L1X<sup>ˆ</sup> L2 can be multiplied by all the outlined X<sup>ˆ</sup> stabilizers, which at most give a sign change to the operator, to yield the equivalent operator X<sup>ˆ</sup> L (solid blue line) that links the two qubit holes. 

tors must be local, to be able to perform logical gates in parallel. Consequently, we choose to use X<sup>ˆ</sup> L along with either Z<sup>ˆ</sup> L1 or Z<sup>ˆ</sup> L2. If we choose to use Z<sup>ˆ</sup> L2 ≡ Z<sup>ˆ</sup> L, and use this pair to define Y<sup>ˆ</sup> L = Z<sup>ˆ</sup> LX<sup>ˆ</sup> L, we have a complete set {X<sup>ˆ</sup> L, Z<sup>ˆ</sup> L, Y<sup>ˆ</sup> L} of logical qubit operators for this double Z-cut qubit. By restricting ourselves to this set of logical operators, we are changing the two qubit holes in a correlated fashion, so that effectively we are manipulating a single two-level logical qubit; we will write the state of this composite logical qubit in the usual way, as e.g. α|gL⟩ + β|eL⟩. Note that in more advanced work [46], more general defect and logical operator configurations are permitted. 

We can create a double X-cut qubit in a similar way to the double Z-cut qubit, by turning off two measure-X qubits. Both the double Z-cut and double X-cut qubit types are shown in Fig. 11. The logical operators for the double X-cut qubit are defined in an analogous fashion to the double Z-cut qubit: The Z<sup>ˆ</sup> L operator is a chain linking the two X-cut holes, and we choose either X<sup>ˆ</sup> L = XˆL1 or XˆL = XˆL2, the operator loops that surround one or the other of the X-cut holes. It is easy to show that these logical operators satisfy the necessary anticommutation relations. 

Double Z-cut (double X-cut) qubits are called smooth (rough) qubits or dual (primal ) qubits in the literature. As we will almost exclusively discuss double-cut qubits 

17 



<!-- Start of picture text -->
Z Z Z X X X<br>(a) Z Z Z Z Z Z (b) X X X X X X<br>Z X Z X Z X Z X Z X<br>X X X X Z Z Z Z<br>Z X X Z X Z Z X<br>Z Z Z Z X X X X<br>Z X X Z X Z Z X<br>X X X 1 X X Z Z Z 1 Z Z<br>Z X Z X Z X Z X Z X<br>Z Z Z Z Z Z X X X X X X<br>Z X Z X Z X Z X Z X<br>X X X 2 X XL X Z Z Z 2 Z ZL Z<br>Z X Z X Z X Z X Z X<br>Z Z Z Z Z Z X X X X X X<br>Z X X3 Z X Z X Z Z3 X Z X<br>X X X X Z Z Z Z<br>Z X Z3 X Z X Z X3 Z X<br>Z Z Z X Z4Z6Z5 X Z ZL Z Z X X X Z X4X6X5 Z X X L X X<br>X X X X Z Z Z Z<br>Z X Z X Z X Z X Z X<br>Z Z Z Z Z Z X X X X X X<br>Z Z Z X X X<br><!-- End of picture text -->

FIG. 11. (Color online) (a) A double Z-cut and (b) a double X-cut qubit, formed in a large array by turning off two measure-Z and two measure-X qubits, respectively; the array is assumed to extend outwards indefinitely. For the double Z-cut qubit the logical operators comprise an X<sup>ˆ</sup> L = X<sup>ˆ</sup> 1X<sup>ˆ</sup> 2X<sup>ˆ</sup> 3 chain that links one Z-cut hole’s internal X boundary to the other, and a Z<sup>ˆ</sup> L = Z<sup>ˆ</sup> 3Z<sup>ˆ</sup> 4Z<sup>ˆ</sup> 5Z<sup>ˆ</sup> 6 loop that encloses the lower Z- cut hole. For the X-cut qubit we have the Z<sup>ˆ</sup> L = Z<sup>ˆ</sup> 1Z<sup>ˆ</sup> 2Z<sup>ˆ</sup> 3 chain that links the two internal X-cut holes’ Z boundaries and the XˆL = X<sup>ˆ</sup> 3X<sup>ˆ</sup> 4X<sup>ˆ</sup> 5X<sup>ˆ</sup> 6 loop that encloses the lower X-cut hole. The X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L operator chains share one data qubit, data qubit 3 for both examples, so the operators anti-commute. Note that the loop operators ( Z<sup>ˆ</sup> L for the Z-cut qubit and X<sup>ˆ</sup> L for the X-cut qubit) can surround either of the two holes in the qubit, as discussed in the text. 

from this point forward, we will simply call these Z-cut and X-cut qubits. 

The two different types of logical qubits, Z-cut and X- cut, are needed to perform the topological braid transformation that provides the logical CNOT operation in the surface code: Only braids between mixed qubit types give the needed functionality. However, as we discuss below, a topological CNOT can be performed between two Z-cut qubits, by using an X-cut qubit as an intermediary; similarly, a CNOT between two X-cut qubits can be performed using a Z-cut as an intermediary. An arbitrary quantum computation can therefore be completed using mostly one flavor of logical qubit, with the other qubit type only making appearances in a supporting role. 

The logical qubits we have introduced are “small” in that we only turn off a single measure qubit (removing a single stabilizer) in each of the two holes. For the Z-cut qubit shown in Fig. 11, the Z<sup>ˆ</sup> L loop consists of four data qubit Z<sup>ˆ</sup> operators, and the X<sup>ˆ</sup> L operator chain linking the two qubit holes has three data qubit X<sup>ˆ</sup> operators. Hence the distance for this qubit is only d = 3, meaning these logical qubits are relatively fault-intolerant. Moving the two holes further apart would increase the distance to d = 4, limited by the length of the Z<sup>ˆ</sup> L loop. In Section 

XII we describe how to create and initialize larger distance d logical qubits, which as discussed in Sect. VII are significantly more fault-tolerant. 

### IX. SOFTWARE-IMPLEMENTED Z<sup>ˆ</sup> L AND X<sup>ˆ</sup> L 

We now must inform the reader of a curious aspect of the surface code: The logical operators X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L that we have spent so much time discussing are not actually implemented in the surface code hardware! These operations are handled entirely by the classical control software, as we shall describe in a moment. These logical gates could be implemented by performing physical bit-flip and phase-flip operations on the data qubits, as the surface code is fairly tolerant to errors in these types of single-qubit gates; however, a hardware-based solution will always have a higher error rate than one implemented in the control software. Instead, whenever a particular quantum algorithm calls for an X<sup>ˆ</sup> L or Z<sup>ˆ</sup> L operator, the operator is commuted through each subsequent logical operation in the algorithm until a second identical operation is called for, in which case the two cancel (since XˆL<sup>2=Zˆ</sup> L<sup>2=IˆL),oruntilameasurementofthelogical</sup> qubit is performed, in which case the operator is applied to the measurement outcome (hence an X<sup>ˆ</sup> L would be applied by reversing the sign of a Z<sup>ˆ</sup> L measurement, while it would have no effect on an X<sup>ˆ</sup> L measurement, and similarly for a Z<sup>ˆ</sup> L operator combined with an X<sup>ˆ</sup> L or a Z<sup>ˆ</sup> L measurement, respectively). 

We demonstrate the concept with an example, accompanied by the warning that this example uses a number of results that we have not introduced; the reader may want to return to this example after reading the discussion of the Heisenberg representation of the CNOT in Sect. XIV C. We represent the two-qubit CNOT operation with the two-qubit operator C<sup>ˆ</sup> L, which transforms two-qubit operators such as I<sup>ˆ</sup> L⊗Z<sup>ˆ</sup> L according to the rules described there (so e.g. C<sup>ˆ</sup> L(I<sup>ˆ</sup> L ⊗ Z<sup>ˆ</sup> L) = ( Z<sup>ˆ</sup> L ⊗ Z<sup>ˆ</sup> L) C<sup>ˆ</sup> L). 

Consider the circuit fragment shown in Fig. 12a, in which a Z<sup>ˆ</sup> L operator on logical qubit 1 and the identity IˆL operator on qubit 2 is followed by a logical Hadamard on qubit 1, a logical CNOT in which qubit 1 is the control and qubit 2 the target, and a second logical Hadamard on qubit 1, with the circuit terminated by X<sup>ˆ</sup> L measurements of both logical qubits. 

Rather than actually applying the Z<sup>ˆ</sup> L operator to qubit 1, the Z<sup>ˆ</sup> L operator is instead commuted through the Hadamard, which transforms Z<sup>ˆ</sup> L to X<sup>ˆ</sup> L (using H<sup>ˆ</sup> LZ<sup>ˆ</sup> L = XˆLHˆL; see e.g. [2]). This is shown in Fig. 12b. The XˆL on qubit 1 and I<sup>ˆ</sup> L on qubit 2 are then commuted through the CNOT, using C<sup>ˆ</sup> L( X<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L) = ( X<sup>ˆ</sup> L ⊗ X<sup>ˆ</sup> L) C<sup>ˆ</sup> L, leaving XˆL on qubit 1 and XˆL on qubit 2 after the CNOT, as shown in Fig. 12c. Commuting the first qubit X<sup>ˆ</sup> L through the second Hadamard, this becomes Z<sup>ˆ</sup> L on qubit 1 with XˆL on qubit 2 (Fig. 12d). We have now reached the terminal measurements at the end of the circuit. At this 

18 



<!-- Start of picture text -->
(a)<br>〉<br>〉 I L<br>(b)<br>〉 X L<br>〉 I L<br>(c)<br>〉 X L<br>〉 X L<br>(d)<br>〉 Z L<br>〉 X L<br>(e) -<br>〉<br>〉<br><!-- End of picture text -->

FIG. 12. (Color online) Example of how Z<sup>ˆ</sup> L and X<sup>ˆ</sup> L operators are handled in the control software. Here we commute a Z<sup>ˆ</sup> L logical operator (colored blue (light)) on one qubit with an identity I<sup>ˆ</sup> L (colored blue (light)) on a second qubit through a sequence of logical operations (colored black), here including two Hadamards and a CNOT, ending with a measurement of each qubit. (a) We start with Z<sup>ˆ</sup> L operating on qubit 1 with the I<sup>ˆ</sup> L identity on qubit 2. (b) The two operations are commuted one step to the right, with Z<sup>ˆ</sup> L transformed by the Hadamard to an X<sup>ˆ</sup> L. (c) The two operations are commuted through the CNOT, with X<sup>ˆ</sup> L on qubit 1 remaining unchanged while I<sup>ˆ</sup> L on the second qubit transforms to X<sup>ˆ</sup> L. (d) X<sup>ˆ</sup> L on qubit 1 is transformed by the second Hadamard to Z<sup>ˆ</sup> L, and finally (e) the Z<sup>ˆ</sup> L on qubit 1 changes the sign of the X<sup>ˆ</sup> measurement from MX = ±1 to −MX = ∓1, while the X<sup>ˆ</sup> L on qubit 2 does nothing to that qubit’s X<sup>ˆ</sup> measurement. 

point the measurements are carried out, and the classical control software, which has calculated the commutations we have stepped through, corrects the measurements as needed using the pending operations: The X<sup>ˆ</sup> L measurement of qubit 1, MX = ±1, has its sign reversed by the pending Z<sup>ˆ</sup> L on that qubit to −MX = ∓1, while the X<sup>ˆ</sup> L measurement of qubit 2 is unaffected by its pending X<sup>ˆ</sup> L. The roles of the Z<sup>ˆ</sup> L and X<sup>ˆ</sup> L operators are ended by these logical measurements. 

In general, single qubit X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L operators can be commuted through the various one- and two-qubit operations in any topological quantum circuit, without actually performing these logical operations, until they either cancel with another identical single-qubit operator or are 

used to correct a measurement as described above.<sup>16</sup> We have shown how this works for a simple circuit involving Hadamards and a logical CNOT. We discuss how this is done for the S<sup>ˆ</sup> L phase gate and the T<sup>ˆ</sup> L gate in Sect. XVI. 

### X. LOGICAL QUBIT INITIALIZATION AND MEASUREMENT 

While we do not actually perform X<sup>ˆ</sup> L or Z<sup>ˆ</sup> L operations on the logical qubits, we do have to initialize and measure the qubits. In this section we described two methods to initialize logical qubits and two methods to measure the logical state. 

### A. Initialization. 

There are two ways to initialize a logical qubit state, which we will call “easy” and “difficult”. The easy way is to initialize the qubit in an eigenstate of the qubit cut; for an X-cut qubit, easy initialization is in the |+L⟩ or |−L⟩ eigenstates of X<sup>ˆ</sup> L, while for a Z-cut qubit, easy initialization is in the |gL⟩ or |eL⟩ eigenstates. The process is illustrated for an X-cut qubit in Fig. 13, starting with a 2D array with no cuts, and stepping immediately to one with a double-X cut qubit, achieved by turning off two measure-X qubits to create two X-cut holes. We know the measurement outcomes of these two measure-X qubits just prior turning them off; if we define X<sup>ˆ</sup> L as the loop surrounding the upper qubit hole, the initial state of the qubit corresponds to the measurement outcome of the upper measure-X qubit just before it is turned off, i.e. |+L⟩ if Xabcd = +1 and |−L⟩ if Xabcd = −1. If the initial state is not the desired one, we can apply a ZˆL phase-flip to that logical qubit; as discussed above, this phase-flip would be applied “in software”, meaning it would not actually be applied, but would instead be commuted through the quantum circuit until it is canceled by a second operator or the logical qubit is measured. 

The alternative to initializing the X-cut logical qubit in the X<sup>ˆ</sup> L basis is to perform a “difficult” initialization in the Z<sup>ˆ</sup> L basis, i.e. in either |gL⟩ or |eL⟩. This can be done using a logical Hadamard after initializing in the X<sup>ˆ</sup> L basis. Logical Hadamards are however somewhat complicated (see Section XV), so it is simpler to initialize in the ZˆL basis directly. This is illustrated for an X-cut qubit in Fig. 14. Briefly, starting with a fully stabilized array, a strip of X<sup>ˆ</sup> stabilizers is turned off, where each end of 

> 16 There is an important distinction between what are called “Clifford gates” and “non-Clifford gates”; the set of logical gates we are developing here, X<sup>ˆ</sup> L, Z<sup>ˆ</sup> L, H<sup>ˆ</sup> L, S<sup>ˆ</sup> L and S<sup>ˆ</sup> L<sup>†,TˆLandTˆ †</sup> L<sup>,and</sup> the two-qubit logical CNOT, are all Clifford gates except T<sup>ˆ</sup> L and T<sup>ˆ</sup> L<sup>†(seeRef.[47]).Wediscusshowtocommute</sup> X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L through the S<sup>ˆ</sup> L and T<sup>ˆ</sup> L gates in Sect. XVI. 

19 



<!-- Start of picture text -->
(a) (b)<br>XL<br>ZL<br><!-- End of picture text -->

FIG. 13. (Color online) Easy initialization of an X-cut logical qubit. Using the logical qubit’s upper hole, the stable measure-X outcome just prior to creating the qubit hole by turning off the measure-X qubit is equal to the initial logical eigenvalue of the qubit. 

the strip will serve as one of the qubit holes. In addition, the Z<sup>ˆ</sup> stabilizers that border the strip are switched from measuring four adjacent data qubits to measuring just three (by simply excluding one data qubit from the surface code CNOT cycle in Fig. 1). There are six Z<sup>ˆ</sup> stabilizers that are switched from four- to three-terminal operation in Fig. 14b.<sup>17</sup> The three isolated data qubits (numbered 1, 2 and 3 in Fig. 14) are measured once along Z<sup>ˆ</sup> to maintain error correction, and then set to the ground |g⟩ state as in Fig. 14c.<sup>18</sup> Setting these three qubits to their ground state ensures that the quiescent state |ψ⟩ will be in the logical ground state of the Z<sup>ˆ</sup> L = Z<sup>ˆ</sup> 1Z<sup>ˆ</sup> 2Z<sup>ˆ</sup> 3 operator. Finally the two X<sup>ˆ</sup> stabilizers internal to the strip are turned back on, and the three-terminal Z<sup>ˆ</sup> stabilizers switched back to four-terminal measurements, completing the process.<sup>19</sup> Details are given in Appendix C. 

Note that the projective measurements of the two X<sup>ˆ</sup> stabilizers that were turned back on at the end of the initialization will leave the three data qubits in a +1 eigenstate of Z<sup>ˆ</sup> L, in other words a |gL⟩ eigenstate, even 

> 17 Note that even though these stabilizers only measure three data qubits, the geometry of the array ensures that two pairs of the three data qubits are also measured by X<sup>ˆ</sup> stabilizers, so the stabilizer measurements still all commute: If e.g. the Z<sup>ˆ</sup> stabilizer measures data qubits a, b and c, one adjacent measure-X qubit will measure a and b, and the other will measure b and c. 

> 18 It might seem that the isolated data qubits need to be measured d times along Z<sup>ˆ</sup> to maintain error detection in time, but the single measurements in this step are combined with the concurrent three-terminal measurements of the adjacent Z<sup>ˆ</sup> stabilizers, and compared to the prior four-terminal Z<sup>ˆ</sup> stabilizer measurements, to provide sufficient distance (continuity) in time. 

> 19 It turns out that easy initialization is never used in practice, as X-cut (Z-cut) logical qubits always need to be initialized in the ZˆL ( ˆXL) basis; see for example the discussion of logical CNOTs between logical qubits of the same type in Sect. XIV D. 

though the data qubits themselves will no longer be in their individual ground states |g⟩. We can see this as follows: After the ground state re-set, the quiescent state |ψ⟩ is transformed to |ψ<sup>′</sup> ⟩ = |ggg⟩|φ⟩, where |ggg⟩ is the state of the three data qubits, and |φ⟩ the state of all the other data qubits in the array. The state |ψ<sup>′</sup> ⟩ is a +1 eigenstate of Z<sup>ˆ</sup> L, but is not an eigenstate of all the X<sup>ˆ</sup> stabilizers, as you can easily verify. However, we know that Z<sup>ˆ</sup> L commutes with all the X<sup>ˆ</sup> stabilizers, so there are common eigenstates of both Z<sup>ˆ</sup> L and these stabilizers. The state |ψ<sup>′</sup> ⟩ can be written as a superposition of X<sup>ˆ</sup> stabilizer eigenstates, where all these eigenstates are still +1 eigenstates of Z<sup>ˆ</sup> L, so the logical qubit remains in |gL⟩. The X<sup>ˆ</sup> stabilizer measurements will project |ψ<sup>′</sup> ⟩ onto one of these eigenstates, leaving us with a state |ψ<sup>′′</sup> ⟩ that is still a +1 eigenstate of Z<sup>ˆ</sup> L but is also an eigenstate of all the X<sup>ˆ</sup> (and Z<sup>ˆ</sup> ) stabilizers in the array. 

Initializing a Z-cut qubit is completely analogous to the X-cut qubit initialization. Initializing in a Z<sup>ˆ</sup> L eigenstate is easy, because the Z<sup>ˆ</sup> stabilizers that are turned off to create the qubit holes ensure the logical qubit is in a Z<sup>ˆ</sup> L eigenstate. Initializing in an X<sup>ˆ</sup> L eigenstate is “difficult:” A strip of Z<sup>ˆ</sup> stabilizers is turned off, and the isolated data qubits then initialized to the X<sup>ˆ</sup> eigenstates |+⟩ or |−⟩, so that the state |ψ⟩ is then in an eigenstate of X<sup>ˆ</sup> L = X<sup>ˆ</sup> 1X<sup>ˆ</sup> 2X<sup>ˆ</sup> 3. The stabilizers are then turned back on, projecting the data qubits to an eigenstate of all the stabilizers, while maintaining it in an eigenstate of X<sup>ˆ</sup> L. 

### B. Measurement 

Measuring a logical qubit uses a procedure nearly the reverse of that used for initialization. As with initialization, measurement can be classified as “easy” or “difficult”. For an easy measurement, the measure qubits in the qubit holes are simply turned on, with the stabilizer measurement projecting the logical qubit onto a stabilizer eigenstate, with the stabilizer eigenvalue equal to the logical qubit measurement outcome (determined in a fault-tolerant manner by completing d surface code cycles). If this is done for the X-cut qubit shown in Fig. 15a, we turn on the two measure-X qubits in the holes, whose measurement projects the data qubits adjacent to them into an X<sup>ˆ</sup> aX<sup>ˆ</sup> bX<sup>ˆ</sup> cX<sup>ˆ</sup> d product eigenstate. This constitutes an X<sup>ˆ</sup> L measurement of the logical qubit, with the X<sup>ˆ</sup> L eigenvalue equal to the stable value of Xabcd. If there is a pending X<sup>ˆ</sup> L operator on that qubit, nothing happens, while if there is a pending Z<sup>ˆ</sup> L operator, the sign of the measurement outcome is reversed. Note that this process destroys the logical qubit, which must be re-initialized to be used again. 

For a difficult measurement, which would be used to e.g. measure the X-cut qubit in the Z<sup>ˆ</sup> L basis, we use the measurement process illustrated in Fig. 15. Details are given in Appendix D. 

A completely analogous process is used to perform an 

20 



<!-- Start of picture text -->
(a) (b)<br>MZ<br>1<br>MZ<br>2<br>MZ<br>3<br>(c) (d)<br>g XL<br>1<br>g<br>2<br>ZL<br>g<br>3<br><!-- End of picture text -->

FIG. 14. (Color online) Z<sup>ˆ</sup> eigenstate (“difficult”) initialization of an X-cut logical qubit. The process steps are as follows: (a) Starting with a fully stabilized array, we (b) turn off a column of four measure-X qubits, switch the adjacent measureZ qubits from 4- to 3-terminal measurements, and perform Zˆ measurements of the data qubits numbered 1, 2 and 3, to maintain error tracking. (c) We reset (re-initialize) the data qubits 1, 2 and 3 to |g⟩, and (d) turn two of the measure-X qubits back on, switch the adjacent measure-Z qubits back to 4-terminal measurements, leaving us with a logical qubit initialized in |gL⟩ due to step (c). 

“easy” measurement of Z<sup>ˆ</sup> L or a “difficult” measurement of X<sup>ˆ</sup> L for a Z-cut qubit. 

### XI. ERRORS DURING STABILIZER MANIPULATIONS 

Our initialization and measurement procedures, especially the “difficult” ones, involve turning stabilizers on and off, switching stabilizers from four- to threeterminal measurements and back, measuring individual data qubits, and re-setting (re-initializing) data qubits to eigenstates of X<sup>ˆ</sup> or Z<sup>ˆ</sup> . These processes are not used just for initialization and measurement, but also form the heart of the topologically-implemented CNOT operation as well as the logical Hadamard. These manipulations would seem to allow errors to occur in some undetectable 



<!-- Start of picture text -->
(a) (b)<br>XL<br>MZ<br>MZ<br>ZL<br>MZ<br>(c) (d)<br>g<br>g<br>g<br><!-- End of picture text -->

FIG. 15. (Color online) Z-axis (“difficult”) measurement process for an X-cut logical qubit. We start (a) with an X-cut qubit, for which we display the logical operators X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L, and begin the measurement (b) by turning off the measure-X qubits between the two qubit cuts while also switching the neighboring measure-Z qubits from four- to three-terminal measurements. We measure the un-stabilized data qubits along Z<sup>ˆ</sup> . The product of the measurement outcomes is the measurement of Z<sup>ˆ</sup> L. A pending Z<sup>ˆ</sup> L operator would have no effect, while a pending X<sup>ˆ</sup> L would be used to reverse the sign of this measurement outcome. We then (c) reset the qubits to their ground states |g⟩ and (d) destroy the logical qubit by turning on all the stabilizers. 

fashion, as we are manipulating the very structure that stabilizes the quiescent states. However, as long as this kind of manipulation is done in the appropriate way, it turns out the quiescent state is still protected. 

Consider for example the Z<sup>ˆ</sup> eigenstate “difficult” initialization of an X-cut qubit that appears in Fig. 14. Passing from panel a to panel b, we turn off a number of X<sup>ˆ</sup> stabilizers and convert some of the Z<sup>ˆ</sup> stabilizers from four- to three-terminal measurements, isolating data qubits 1, 2 and 3 from the array. Passing from panel b to c, we perform data qubit ground state re-sets, and passing from panel c to d we turn the stabilizers back on. It would seem that errors could occur on the isolated data qubits 1, 2 or 3, or on the data qubits bordering the long cut in panels b and c. 

21 

Consider first the isolated data qubits: Zˆ errors on these data qubits will have no effect, as these data qubits are measured along Z<sup>ˆ</sup> in panel b of Fig. 15, a measurement that is not affected by Z<sup>ˆ</sup> errors, and are then re-set to |g⟩ in panel c, a process that is also immune to Z<sup>ˆ</sup> errors. These data qubits are then re-joined with the array and fully stabilized in panel d, with Z<sup>ˆ</sup> errors taken care of in the usual way. An X<sup>ˆ</sup> error on one of these data qubits will however have an effect: If this occurs between panel a and b, the X<sup>ˆ</sup> error will reverse the measurement MZ of the affected data qubit, but by computing the product of this Z<sup>ˆ</sup> measurement with the two three-terminal Z<sup>ˆ</sup> measurements adjacent to that data qubit, and comparing these products with the corresponding four-terminal measurements that occurred prior to panel b, this error can be detected and localized, and we can correct the data qubit Z<sup>ˆ</sup> measurement outcome. An X<sup>ˆ</sup> error between panel b and c will be erased by the ground-state re-set of the data qubit, and an X<sup>ˆ</sup> error between panels c and d will be detected by the usual stabilizer cycle, given that we know the data qubit state prior to the stabilizers being turned on. 

Now consider the data qubits bordering the cut: Xˆ errors will be detected in the usual way, as each of these data qubits is stabilized by two Z<sup>ˆ</sup> stabilizers, which is sufficient to detect and locate these kinds of errors. A Z<sup>ˆ</sup> error on one of these qubits will generate a change of sign in the one X<sup>ˆ</sup> stabilizer that monitors that data qubit; this could then be interpreted either as a measurement error on that stabilizer (as it is an isolated error), or as a data qubit error. A measurement error would however disappear as the surface code cycle continues, so by comparing results in time, the error can be identified as a data qubit error, and any measurements then corrected. 

In summary, maintaining the surface code error detection is done by careful combinations of measurements before and after a stabilizer manipulation, sometimes involving measurements of individual isolated qubits that are combined with three-terminal stabilizers, sometimes by slightly modifying the error locating algorithms when errors occur on only partly-stabilized data qubits (such as those on the edge of a cut). This can however be done with the same fault tolerance as in the rest of the surface code array, and this means that these manipulations, as long as they respect the distances needed for fault tolerance, both in space and in time, do not affect the stabilization required for proper operation. 

### XII. LARGER LOGICAL QUBITS 

We can create logical qubits by turning off e.g. two Z<sup>ˆ</sup> stabilizers some distance apart, creating two small holes with X boundaries. As shown in Fig. 11a, Z<sup>ˆ</sup> L is a chain of Z<sup>ˆ</sup> operators surrounding one of the holes, involving only four physical qubit Z<sup>ˆ</sup> operators, equal to the number of data qubits on the boundary of the hole. Similarly the X<sup>ˆ</sup> L operator is a chain of three X<sup>ˆ</sup> operators link- 

ing the two Z-cut holes. We could put the holes further apart, increasing the distance for X<sup>ˆ</sup> L, but this would of course not increase the length of the Z<sup>ˆ</sup> L loop. An error chain with the same length as Z<sup>ˆ</sup> L or X<sup>ˆ</sup> L can emulate these logical operators, corrupting the logical qubit in an undetectable manner; this therefore sets the distance d that determines the relation between the physical qubit error rate p and the resulting logical error rate PL emerging from the matching algorithm, as discussed in Section VII. For the logical qubits in Fig. 11 we have d = 3, and if we separate the holes further, d = 4 is the limit, determined by number of data qubits bordering a qubit hole. 

The error-handling ability is significantly improved if we increase the size and spacing of the two holes, as this will increase the number of physical qubits involved in Z<sup>ˆ</sup> L and X<sup>ˆ</sup> L. Here we describe how to create a five-stabilizer Z-cut hole, increasing the number of physical qubit operators in the Z<sup>ˆ</sup> L loop from four to eight, significantly improving the error tolerance. The two larger holes that now make up the logical qubit can also be moved further apart, lengthening the operator chain for X<sup>ˆ</sup> L, and improving its stability as well; if the X<sup>ˆ</sup> L chain is increased to eight physical qubit operators, then we have a distance d = 8 logical qubit. This distance must be preserved in all logical qubit operations, and operations that involve turning stabilizers on or off must also be spaced in time by at least d = 8 surface code cycles, in order to preserve the temporal spacing needed for error matching of e.g. measurement errors. Even larger qubits can of course be created; turning off sixteen Z<sup>ˆ</sup> stabilizers and nine X<sup>ˆ</sup> stabilizers in a square pattern would create a d = 16 Z-cut logical qubit (the identity of the qubit is determined by whether it is a loop of Z<sup>ˆ</sup> operators that encloses the qubit holes or a loop of X<sup>ˆ</sup> L operators, the former corresponding to a Z-cut qubit and the latter an X-cut). 

The process to make a larger Z-cut qubit is outlined in Fig. 16; a completely analogous process is used to make larger X-cut qubits. Details are given in the figure caption and in Appendix E. 

The process shown in Fig. 16 initializes the qubit in an eigenstate of Z<sup>ˆ</sup> L, with an eigenvalue equal to the product of the stable measurement outcomes of the four Z<sup>ˆ</sup> stabilizers in the cut. Initializing the qubit instead in an XˆL eigenstate can be done using a procedure analogous to that described in Section X. 

Measuring a larger qubit is also similar to the procedure for measuring small qubits. If we want to measure the logical qubit in Fig. 16 along Z<sup>ˆ</sup> L, an “easy” measurement, we turn on the four Z<sup>ˆ</sup> and the one X<sup>ˆ</sup> stabilizer in the hole; the Z<sup>ˆ</sup> L eigenvalue is equal to the stable product of the four Z<sup>ˆ</sup> stabilizers, Zs1Zs2Zs3Zs4 = ±1 (where e.g. Zs1 = Z1,abcd is the measurement outcome of the stabilizer Z<sup>ˆ</sup> s1). If we want instead to measure the logical qubit along X<sup>ˆ</sup> L, a “difficult” measurement, we follow a procedure analogous to that for the difficult measurement of a small qubit, shown in Fig. 15: We open the strip of Z<sup>ˆ</sup> stabilizers through which the X<sup>ˆ</sup> L chain passes, turn the 

22 



<!-- Start of picture text -->
1 8 ZL<br>MX<br>2 Zs1 Zs4 7<br>M X Xs1 M X<br>3 Zs2 Zs3 6<br>MX<br>4 5<br>XL<br><!-- End of picture text -->

FIG. 16. (Color online) Z-cut qubit with a five-stabilizer hole, showing only the upper qubit multi-cell hole. The logical operator Z<sup>ˆ</sup> L is the chain Z<sup>ˆ</sup> L = Z<sup>ˆ</sup> 1Z<sup>ˆ</sup> 2Z<sup>ˆ</sup> 3Z<sup>ˆ</sup> 4Z<sup>ˆ</sup> 5Z<sup>ˆ</sup> 6Z<sup>ˆ</sup> 7Z<sup>ˆ</sup> 8, shown in red (gray). The four Z<sup>ˆ</sup> stabilizers Z<sup>ˆ</sup> s1, Z<sup>ˆ</sup> s2, Z<sup>ˆ</sup> s3 and Z<sup>ˆ</sup> s4 are turned off along with the X<sup>ˆ</sup> stabilizer X<sup>ˆ</sup> s1, and the four internal data qubits measured along X for error tracking. The initial value of Z<sup>ˆ</sup> L is equal to the product of the four Z<sup>ˆ</sup> stabilizer measurements just prior to turning the stabilizers off (note this stabilizer product commutes with each of the individual data qubit measurements MX ). 

adjacent X<sup>ˆ</sup> stabilizers from four- to three-terminal measurements, and measure each of the isolated data qubits along X<sup>ˆ</sup> .<sup>20</sup> The resulting X<sup>ˆ</sup> eigenvalues of each data qubit are multiplied together, and their product is the value of XL. Finally, we reset these data qubits to their ground states |g⟩, and turn all the stabilizers back on, destroying the logical qubit. 

### XIII. MOVING QUBITS 

We have shown how to create and initialize logical qubits in the surface code array. We will discuss later how the single logical qubit gates S<sup>ˆ</sup> L, T<sup>ˆ</sup> L and the Hadamard HˆL, all required to perform quantum algorithms, can be performed on these logical qubits. We turn now to the very interesting method used to entangle logical qubits. This can be done in a very elegant way by moving the logical qubit holes around on the 2D array, providing a central functionality of the surface code. By moving one logical qubit hole between the two holes of a second logical qubit, thus “braiding” the logical qubits together, we can perform a logical CNOT. We first however need to learn how to move a logical qubit hole. 

Moving a logical qubit is best described in two stages, first outlining what we physically do to the surface code 

> 20 In our initial description, we only required the ability to measure qubits along Z<sup>ˆ</sup> ; an X<sup>ˆ</sup> measurement in addition would be useful here, but the equivalent can be performed by first performing a Hadamard operation on the qubit, followed by a Z<sup>ˆ</sup> measurement. 

array, and second describing how we transform the logical operators X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L, in a way that preserves their identity while matching what is happening to the data qubits in the array. The transformations of the logical operators are described in the context of the Heisenberg representation, so we start by briefly reviewing the Heisenberg representation of quantum mechanics (see e.g. [48] for a more complete introduction, and [47] in relation to quantum computing). 

In quantum mechanics, many processes can be de= scribed by unitary transformations U<sup>ˆ</sup> , with U<sup>ˆ</sup> U<sup>ˆ†</sup> Uˆ<sup>†</sup> Uˆ = Iˆ. These include for example changes of basis, changes of representation, and the temporal evolution of the system. In the Schr¨odinger representation, these unitary transformations are applied to the wavefunction, so that |ψ⟩→ U<sup>ˆ</sup> |ψ⟩, with the operators kept static. Hence for example wavefunctions are time-dependent, arising from the application of the evolution operator U<sup>ˆ</sup> (t), while operators are not. Inner products are invariant under a unitary transformation, since 



However for the matrix elements of an operator A<sup>ˆ</sup> we have 



As in general Aˆ̸ = Uˆ<sup>†</sup> AˆU ˆ , the matrix elements can change under a unitary transformation. The second line in Eq. (16) provides the basis for the Heisenberg representation: We can equivalently assume the wavefunction |ψ⟩ does not change under the unitary transformation Uˆ , and instead modify the operator Aˆ → Aˆ<sup>′</sup> = Uˆ<sup>†</sup> AˆU ˆ . Hence for example in the Heisenberg picture, operators rather than wavefunctions are modified under a change of basis, and operators are time-dependent. The evolution of any measurable quantity will be the same in the Heisenberg representation as in the Schr¨odinger representation, so there is no detectable difference between the two pictures. 

In the surface code, moving and braiding qubits are transformations that affect both the physical array of qubits as well as the logical operators. The physical transformations are not unitary, as these involve projective measurements of the data qubits, but the transformations of the logical operators are unitary, and are best described using the Heisenberg representation. We will assume for this discussion that no errors occur on the physical qubits or during measurements; we discuss error handling after we have worked through the error-free description. 

23 

### A. One-cell logical qubit move 

In Fig. 17 we illustrate how to move a logical Z-cut qubit hole downwards by one cell in the 2D array. We remind the reader that a logical Z-cut qubit is created by turning off a pair of Z<sup>ˆ</sup> stabilizers, creating two Z- cut holes. The logical qubit has the logical operators XˆL = Xˆ1Xˆ2Xˆ3 and ZˆL = Zˆ3 ˆZ4 ˆZ5 ˆZ6, where we define ZˆL as the loop of Zˆ operators surrounding the lower Z- cut hole. A detailed step-by-step description of the move process is given in Appendix F. 

We first describe the physical operations involved in the move, which take two complete surface code cycles. To begin, we wait for the current surface code cycle to finish over the entire array. Before starting the next cycle, we instruct the control software not to measure the Z<sup>ˆ</sup> stabilizer just below the qubit hole that we are moving, that is, the control circuitry will turn off that measure-Z qubit in the next surface code cycle. This means that data qubit 6 will not be measured by a Z<sup>ˆ</sup> stabilizer (see Fig. 17). We also convert the two measure-X qubits adjacent to data qubit 6 from four-terminal to three-terminal measurements, that is, these measure-X qubits will not include data qubit 6 in their CNOTs in the next surface code cycle. We then perform the next surface code cycle, during which we measure data qubit 6 along X<sup>ˆ</sup> and obtain its eigenvalue X6; this measurement is used for tracking errors, as discussed below, and for monitoring the sign of the redefined X<sup>ˆ</sup> L operator, also discussed below. After completing this cycle, we turn on the measureZ qubit in the original lower Z-cut hole, so it begins to perform a normal CNOT cycle. We also convert the two measure-X qubits that monitor data qubit 6 back to fourterminal measurements, so they again include data qubit 6 in their CNOT cycles. We perform the next surface code cycle, which completes the physical operations for the move. To establish all stabilizer values in time, we then wait an additional d − 1 surface code cycles. Altogether this one-cell move takes 1 + d surface code cycles. 

While performing the physical operations, we also need to manipulate the definitions of the two logical operators ZˆL and XˆL to preserve their functionality. Before we perform any physical operations, we redefine Z<sup>ˆ</sup> L so that it encloses two stabilizer cells, its original cell plus the one below it, by multiplying Z<sup>ˆ</sup> L by the four Z<sup>ˆ</sup> operators, Zˆ6 ˆZ7 ˆZ8 ˆZ9, that make up the Zˆ stabilizer below the qubit hole. We term the new extended operator Z<sup>ˆ</sup> L<sup>e,whichis</sup> given by 





as shown in Fig. 17a. We complete the first surface code cycle of the move, turning off the lower Z<sup>ˆ</sup> stabilizer and measuring data qubit 6. We redefine the X<sup>ˆ</sup> L operator by multiplying it by X<sup>ˆ</sup> 6, giving 



<!-- Start of picture text -->
(a) (b) (c)<br>X1 X1 X1<br>X2 XL X2 X2<br>XL ’<br>X3 X3<br>X3<br>Z3<br>Z4 Z5 ZL Z4Z3Z5<br>Z6 e X6<br>X6 ZL Z6 ’<br>7 9 Z7Z8Z9 Z7Z8Z9 ZL<br>8<br><!-- End of picture text -->

FIG. 17. (Color online) Process for moving a Z-cut logical qubit hole vertically down by one cell in the 2D array. (a) Logical qubit with X<sup>ˆ</sup> L = X<sup>ˆ</sup> 1X<sup>ˆ</sup> 2X<sup>ˆ</sup> 3 and Z<sup>ˆ</sup> L = Z<sup>ˆ</sup> 3Z<sup>ˆ</sup> 4Z<sup>ˆ</sup> 5Z<sup>ˆ</sup> 6. (b) We extend the Z<sup>ˆ</sup> L operator by multiplying it by the Z<sup>ˆ</sup> stabilizer just below the lower qubit hole: Z<sup>ˆ</sup> L<sup>e= ( ˆZ6Zˆ7Zˆ8Zˆ9) ˆZL=</sup> Zˆ3 ˆZ4 ˆZ5 ˆZ7 ˆZ8 ˆZ9. We next turn off this Zˆ stabilizer, and also turn the surrounding four-terminal X<sup>ˆ</sup> stabilizers into threeterminalbilizer measurements.stabilizers, leavingWe performdata qubitan 6Xˆ withoutmeasurementany sta-of data qubit 6 (using either an idle measure-Z qubit, or directlyfineXˆL<sup>′=</sup> theXmeasuring<sup>ˆ</sup> 6extendedX<sup>ˆ</sup> L = X<sup>ˆ</sup> 1theX<sup>ˆ</sup> operator2X<sup>ˆ</sup> data3X<sup>ˆ</sup> 6. qubit,XWeˆL<sup>′</sup> now<sup>by</sup> as<sup>multiplying</sup> turnshown).on the (c)XZ<sup>ˆ</sup> ˆLstabilizerWeby Xde-ˆ6: just above qubit 6; we wait d surface code cycles in order to properly establish the value of this stabilizer. We define Z<sup>ˆ</sup> L<sup>′</sup> as the product of this Z<sup>ˆ</sup> stabilizer and Z<sup>ˆ</sup> L<sup>e:Zˆ</sup> L<sup>′=Zˆ6Zˆ7Zˆ8Zˆ9.</sup> 

see Fig. 17b. 

We next complete the second surface code cycle of the move, turning the original qubit hole stabilizer back on. We redefine Z<sup>ˆ</sup> L<sup>ebymultiplyingitbythefourZˆopera-</sup> tors that make up the stabilizer that was just turned on, Zˆ3 ˆZ4 ˆZ5 ˆZ6, giving 



The two new logical operators Z<sup>ˆ</sup> L<sup>′andXˆ</sup> L<sup>′arenowas</sup> drawn in Fig. 17c. Note the new logical operators still share a single data qubit and commute with all the stabilizers, so these continue to define a logical qubit. The process of moving the qubit hole involves operations similar to those used for the “easy” and “difficult” initializations, so error processes are as discussed in Sect. XI. 



24 

### B. Byproduct operators 

One problem that is created in the move transformation is that the extension of X<sup>ˆ</sup> L through multiplication by Xˆ6 can yield an extended XˆL<sup>′that differs in sign fromXˆL;</sup> this will occur if the measurement outcome X6 = −1. Similarly the final Z<sup>ˆ</sup> L<sup>′can differ in sign fromZˆL, depend-</sup> ing on the product of the two Z<sup>ˆ</sup> stabilizer measurement outcomes involved in the move. Given the initial state |ψ⟩ prior to the transformation, the transformation coupled with these sign changes results in 



where |ψ<sup>′</sup> ⟩ is the desired state, which would result if there were no sign changes in the logical operators. Hence we must operate on the resulting state with the operator product Z<sup>ˆ</sup> L<sup>′pX</sup> XˆL<sup>′pZ</sup> to regain the desired state |ψ<sup>′</sup> ⟩. The additional bit- and phase-flip operators appearing in Eq. (20) are called “byproduct operators”. The power pX appearing in Eq. (20) is determined by whether a sign change occurred in XˆL during the move, with pX = 0(1) if a sign change did not (did) occur; the power pZ is determined similarly for sign changes in Z<sup>ˆ</sup> L. The byproduct operator Z<sup>ˆ</sup> L<sup>′correctsthesignofthetrans-</sup> formed X<sup>ˆ</sup> L<sup>′through their anti-commutation relation, and</sup> the byproduct operator X<sup>ˆ</sup> L<sup>′similarlycorrectsZˆ</sup> L<sup>′.</sup> 

We do not actually apply the byproduct operators as explicit gates; instead, we simply track these additional XˆL and ZˆL operators in the control software, as discussed in Sect. IX. These corrective operators are thus only applied when the logical qubit is measured, reversing the sign of a Z<sup>ˆ</sup> L measurement if that qubit has an XˆL byproduct operator, and reversing the sign of an XˆL measurement if that qubit has a Z<sup>ˆ</sup> L byproduct operator. Two corrective X<sup>ˆ</sup> Ls or two corrective Z<sup>ˆ</sup> Ls cancel, as XˆL<sup>2=Zˆ</sup> L<sup>2=IˆL.</sup> 

We can also look at what happens to our description of the 2D array wavefunction |ψ⟩ in terms of the stabilizer and logical qubit subspaces. Prior to the move, we have |ψ⟩ = |Q⟩|qL⟩; after the move, we have XˆL<sup>′pZ</sup> ZˆL<sup>′pX</sup> |ψ<sup>′</sup> ⟩ = X<sup>ˆ</sup> L<sup>′pZ</sup> ZˆL<sup>′pX</sup> |Q<sup>′</sup> ⟩|qL<sup>′⟩,where|Q′⟩|q</sup> L<sup>′⟩isthe</sup> desired state. The byproduct operators only affect the logical state, so we can write the equivalent to Eq. (20) as 



where |qL<sup>′⟩isthedesiredlogicalstate.</sup> 

### C. Multi-cell logical qubit move 

We can easily generalize the one-cell move to a multicell move. A multi-cell move can be done in the same number of surface code clock cycles as a one-cell move, and we can translate the logical qubit hole over an unlimited number of cells. Multi-cell moves are performed 



<!-- Start of picture text -->
(a) (b) (c)<br>X ˆ L X ˆ L X ˆ ’ L<br>Z ˆ L X 1e Zs1f<br>Z s2i X 2e Z s2f<br>Z s3i Z ˆ Le<br>X n-1e Z s, n-1f<br>Z s,ni Z ˆ L’<br>… …<br>…<br><!-- End of picture text -->

FIG. 18. (Color online) Process for moving a Z-cut logical qubit hole through multiple cells, using a simplified representation where the X<sup>ˆ</sup> L chain is a blue (light) line linking the logical qubit holes and passing through the data qubits (open circles), and the Z<sup>ˆ</sup> L loop is in red (gray). The upper (gray) and lower (white) Z-cut holes enclose idle Z<sup>ˆ</sup> stabilizers; the outlines of these holes have measure-X qubits on the vertices with data qubits on the edges. (a) Initial state, showing the logical operators X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L, with the initial (pre-move) software-corrected Z<sup>ˆ</sup> stabilizer measurement outcomes Zs<sup>i</sup> 2<sup>,Z</sup> s<sup>i</sup> 3<sup>. . . Z</sup> s,n<sup>i.TheZˆstabilizers involved in the next</sup> step are shown with thin black outlines; the jth stabilizer Z<sup>ˆ</sup> s,j is the stabilizer cell marked by that stabilizer’s initial measurement outcome Zs,j<sup>i.(b)ExtensionofZˆLtoZˆ</sup> L<sup>e,with</sup> X<sup>ˆ</sup> measurements of the isolated data qubits yielding the measurement eigenvalues X1<sup>e,X</sup> 2<sup>e, . . . X</sup> n<sup>e</sup> −1<sup>(dataqubitsfilledin</sup> blue (light)). (c) Final state, with Z<sup>ˆ</sup> L<sup>′theshiftedZˆLlogical</sup> operator and X<sup>ˆ</sup> L<sup>′theextendedchainfor</sup> X<sup>ˆ</sup> L, with the Z<sup>ˆ</sup> stabilizers (thin black outlines) turned back on; after waiting d surface code cycles, we establish the software-corrected final (post-move) measurement outcomes Zs<sup>f</sup> 1<sup>,Z</sup> s<sup>f</sup> 2<sup>, . . . Z</sup> s,n<sup>f</sup> −1<sup>.</sup> 

by extending the one-cell move to a contiguous strip of cells. A multi-cell move is shown in Fig. 18 for a Z-cut qubit hole, using a somewhat more abstract representation than we used in Fig. 17; we have mostly dropped identification of the individual physical qubits, but the analogy with Fig. 17 should be clear. Details for the multi-cell move are given in the figure caption and in Appendix G. 

Briefly, Z<sup>ˆ</sup> L is extended by multiplying it by all the stabilizers through which the logical qubit is to be moved, giving the extended Z<sup>ˆ</sup> L<sup>e:</sup> 



Here each stabilizer operator Z<sup>ˆ</sup> sj represents the product of the four Z<sup>ˆ</sup> operators on the four data qubits surrounding the jth stabilizer cell. These stabilizers are then turned off, and the four-terminal X<sup>ˆ</sup> stabilizers adjacent 

25 

to the strip switched to three-terminal measurements. The un-stabilized data qubits in the strip are all measured along X<sup>ˆ</sup> , and X<sup>ˆ</sup> L is extended by multiplying it by all the X<sup>ˆ</sup> operators on these data qubits, 



We complete the move for Z<sup>ˆ</sup> L by then multiplying Z<sup>ˆ</sup> L<sup>e</sup> by all the stabilizers except the one that is in the new shifted qubit hole, 



where we use the fact that Z<sup>ˆ</sup> sj<sup>2=IˆandthatZˆL=Zˆs1,</sup> i.e. the original Z<sup>ˆ</sup> L is just the set of four Z<sup>ˆ</sup> data qubit operators that define Z<sup>ˆ</sup> s1. After the move, we wait an additional d−1 surface code cycles to establish all stabilizer values in time. Byproduct operators may be appear due to any sign changes that occur to the logical operators X<sup>ˆ</sup> L<sup>′andZˆ</sup> L<sup>′</sup> during this move; see Appendix G for details. 

A completely analogous process is used to move X-cut logical qubit holes, exchanging the roles of the X<sup>ˆ</sup> and Z<sup>ˆ</sup> stabilizers and measurements. 

We note that multi-cell moves can be done very quickly, as a very long cut can be made in just one step of the surface code cycle, and the qubit holes moved in 1 + d surface code cycles, the same as for a one-cell move. This therefore enables long-distance interaction and communication between logical qubits, a very powerful capability. 

### D. Errors during move transformations 

In Sect. XI we discussed the handling of errors when the surface code stabilizers are being manipulated, where we focussed on errors occurring when an X-cut logical qubit is initialized in a Z<sup>ˆ</sup> L eigenstate. A very similar discussion applies to errors that occur during the move transformations, with some differences in the details. The data qubits that are left isolated during the move can suffer from both Z<sup>ˆ</sup> and X<sup>ˆ</sup> errors; X<sup>ˆ</sup> errors have no impact, as they are erased by the single data qubit X<sup>ˆ</sup> measurements during the move. Z<sup>ˆ</sup> errors will be detected by computing the product of each data qubit X<sup>ˆ</sup> measurement with its corresponding three-terminal X<sup>ˆ</sup> stabilizer measurement, and comparing this product with that stabilizer’s prior four-terminal X<sup>ˆ</sup> measurement (this is how Xˆ errors were handled in Sect. XI). Zˆ errors on the data qubits bordering the cut are detected and localized by the two X<sup>ˆ</sup> stabilizers that monitor each of these data qubits. An X<sup>ˆ</sup> error on one of these data qubits changes the sign of the solitary Z<sup>ˆ</sup> stabilizer that monitors that data qubit, 

but this error will persist in time, and can thus be distinguished from a stabilizer measurement error by waiting d surface code cycles. 

### XIV. THE BRAIDING TRANSFORMATION AND THE LOGICAL CNOT 

A braiding transformation is a particularly important type of move. A braid comprises a pair of multi-cell moves involving one of the two holes in a double-cut logical qubit. The shifted hole travels over a path that forms a closed loop in the 2D array, starting and ending in the same location, with the first move taking the hole partway around the loop, and the second move completing the loop. As with the move transformations, braids are described in terms of their effect on the logical qubit operators. 

Most importantly, as we shall see, the braid transformation can entangle two logical qubits, in a way that makes the braid transformation equivalent to a logical CNOT. 

### A. Braid transformation of one logical qubit 

We begin by describing the braid transformation of a single logical qubit, using as an example the Z-cut logical qubit. In Fig. 19 we show the transformation of the XˆL operator and in Fig. 20 that of the ZˆL operator. The braid shifts the qubit hole along a path that, in this example, encloses an area containing only fully stabilized cells; we will discuss below what happens when the braid path encloses another logical qubit hole. The braid’s first move shifts the qubit hole eight cells along the path (for a general braid transformation, this can be any number of cells between one and the array distance d less than the total number of cells in the braid path).<sup>21</sup> This move is completed before the second move is started, meaning that all the stabilizers that were switched off during the move have been turned back on (except for the last cell). After waiting d surface code cycles, to catch measurement errors during the first move, the second multi-cell move is then performed, shifting the qubit hole the remaining four cells in the path, and returning the hole to where it started. The braid cannot be completed in a single multi-cell move, as this would isolate the part of the surface code array enclosed by the braid. 

As can be seen in Figs. 19 and 20, the braid transforms the two logical operators X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L in somewhat different ways. The X<sup>ˆ</sup> L operator for this qubit is a chain 

> 21 Moving the hole so that after this move it ends up less than d cells from the start point would effectively reduce the array distance, and thus reduce the fault tolerance during the braid transformation. 

26 

of three data qubit X<sup>ˆ</sup> operators linking the two holes (Fig. 19a). As shown in Fig. 19b-e, this operator is extended in each of the moves, such that after the second move, the X<sup>ˆ</sup> L<sup>′′operatorinFig. 19eincludestheoriginal</sup> chain of three data qubit operators in addition to a closed loop of X<sup>ˆ</sup> operators, X<sup>ˆ</sup> loop = X<sup>ˆ</sup> 1 . . . X<sup>ˆ</sup> 12. This closed loop encloses only fully stabilized cells, with stabilizers X<sup>ˆ</sup> s1, Xˆs2 . . . Xˆs9, so Xˆloop = Xˆs1 . . . Xˆs9. The quiescent state |ψ⟩ is necessarily an eigenstate of X<sup>ˆ</sup> loop, with eigenvalue given by the measurement outcomes of the enclosed stabilizers, Xloop = Xs1 . . . Xs9. Another way to understand this is that the closed loop of operators X<sup>ˆ</sup> loop can be deformed through all the enclosed X<sup>ˆ</sup> stabilizers, leaving only a product of measurement outcomes. 

The Z<sup>ˆ</sup> L operator is the loop of physical qubit Z<sup>ˆ</sup> operators that encloses the lower qubit hole. As shown in Fig. 20, the braid transformation alternately extends and then collapses the operator loop that surrounds the Z-cut hole, once for each of the two moves; other than sign changes from Z<sup>ˆ</sup> stabilizers that the loop passes over, the final Z<sup>ˆ</sup> L loop is the same as the initial loop. The difference between the transformation of X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L is the key to how the braid acts as a CNOT. 

Details of the braid transformation involving just one logical qubit are given in the captions for Figs. 19 and 20, with a discussion of the sign changes and byproduct operators given in Appendix H. Note that in Figs. 19 and 20, while we separate the actions that affect the X<sup>ˆ</sup> L operator from those that affect Z<sup>ˆ</sup> L, all X<sup>ˆ</sup> measurements of the isolated data qubits and measurements of the Z<sup>ˆ</sup> stabilizers are performed as part of the braid, independent of what logical operators are involved in the transformation, just as they are for the one-cell and multi-cell moves. 

### B. Braiding two qubits 

We now turn to the less trivial situation where the braid path encloses another logical qubit hole. The easiest way to understand this is to examine how operators on the two logical qubits are transformed by the braid. The two-qubit operators will be outer products of the single-qubit operators X<sup>ˆ</sup> L, Z<sup>ˆ</sup> L and I<sup>ˆ</sup> L. The Y<sup>ˆ</sup> L operator is the product of Z<sup>ˆ</sup> L and X<sup>ˆ</sup> L, and its transformation can be understood in terms of the X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L transformations. 

We quickly review two-qubit operators, using as an example X<sup>ˆ</sup> L ⊗Z<sup>ˆ</sup> L. We write the two-qubit logical state as |aLbL⟩, where |aL⟩ represents the state of the first logical qubit and |bL⟩ that of the second qubit. The notation XˆL ⊗ ZˆL means that XˆL acts on the first qubit state |aL⟩, and Z<sup>ˆ</sup> L acts on the second qubit state |bL⟩. Using the eigenstates |gL⟩ and |eL⟩ as basis states, the outer product X<sup>ˆ</sup> L ⊗Z<sup>ˆ</sup> L can be represented in the standard twoqubit basis |gLgL⟩, |gLeL⟩, |eLgL⟩, |eLeL⟩ by the 4 × 4 

matrix 



We will see that the braid transforms each two-qubit operator into some other two-qubit operator, with the outcome depending on the particular pair of operators, and on the order in which their product is formed (so that e.g. XˆL ⊗ ZˆL does not transform the same way as ZˆL ⊗ XˆL). The outcome of a braid also depends on what types of qubits we are braiding together; we focus here on braiding a Z-cut qubit through an X-cut qubit, as shown in Fig. 21. As we will see, only a braid between a Z-cut and an X-cut qubit yields an operator transformation that is equivalent to a logical CNOT. It is not possible to obtain the desired CNOT transformations when braiding two Z-cut qubits together, or two X-cut qubits; we discuss these situations in Sect. XIV D. 

In Fig. 21, the Z-cut qubit is in the upper part of the figure, with the braid moving the lower Z-cut hole of this qubit around a closed loop. The X-cut qubit is in the lower part of the figure, with the braid taking the Z-cut hole between the two X-cut holes, enclosing the upper X-cut hole in the braid loop. As we will work out later, proving that a braid is equivalent to a CNOT only involves showing that four of the sixteen possible twoqubit operator combinations transform correctly; these are X<sup>ˆ</sup> L ⊗I<sup>ˆ</sup> L, I<sup>ˆ</sup> L ⊗X<sup>ˆ</sup> L, Z<sup>ˆ</sup> L ⊗I<sup>ˆ</sup> L and I<sup>ˆ</sup> L ⊗Z<sup>ˆ</sup> L. The transformations for all the other two-qubit combinations of X<sup>ˆ</sup> L, ZˆL and IˆL can be constructed from these four. Here we give a brief outline of these transformations, with details given in Appendix I. 

XˆL1 ⊗ IˆL2 → XˆL1 ⊗ XˆL2: Figure 21 shows the transformation of X<sup>ˆ</sup> L1 on the first, Z-cut qubit, with no operation (I<sup>ˆ</sup> L2) on the second qubit. As with the empty loop braid, the extension of X<sup>ˆ</sup> L1 operator chain in the two moves creates an operator X<sup>ˆ</sup> L<sup>′′</sup> 1<sup>thatcomprisesaclosed</sup> loop of X<sup>ˆ</sup> operators in addition to the original operator chain X<sup>ˆ</sup> L1. The loop encloses the X-cut qubit’s upper hole. For the empty loop braid, we could move the loop through all the enclosed cells, as these were all stabilized, so the loop operator resolved to a simple product of measurement outcomes. Here, we cannot do this, as the X-cut hole is inside the loop and is not stabilized; instead, we can transform the loop through each stabilized cell, until it wraps tightly around the X-cut hole. This loop of X<sup>ˆ</sup> operators is then equivalent to X<sup>ˆ</sup> L2, a logical Xˆ operation on the second qubit. The remaining chain of operators in X<sup>ˆ</sup> L<sup>′′′</sup> 1<sup>is the same as the originalXˆL1chain</sup> prior to the braid. We see therefore that the braid takes XˆL1 on the first qubit and IˆL2 on the second qubit to XˆL1 on the first qubit and XˆL2 on the second qubit, i.e. 



27 



<!-- Start of picture text -->
(a) (b) (c) (d) (e) (f)<br>’’’<br>X ˆ L X ˆ L<br>X1e X12e X11e X10e<br>e e Xsf1 X sf2 X sf3<br>X2 ’ X9 ’’ f f f<br>X3e X8e X ˆ L X ˆ L X s4 X s5 X s6<br>f f f<br>e e e e X s7 X s8 X s9<br>X4 X5 X6 X7<br><!-- End of picture text -->

XFIG.ˆL operator19. (Color(delineatedonline) inBraidbluetransformation(dark)). (a) Doubleof a singleZ-cutZ-cutqubit qubitwith thein alogicalfully-stabilizedoperator X<sup>ˆ</sup> array,L, showingshowingthestepsthreeaffectingdata qubitsthe (open circles) that define the logical operator. (b) Extended opening (heavy grey) for first move in the braid. Data qubits XisolatedˆL<sup>′=</sup> X<sup>ˆ</sup> by1 . . .theX<sup>ˆ</sup> 8Xextension<sup>ˆ</sup> L. (d) Secondare measuredmove inintheX<sup>ˆ</sup> braid,with outcomeswhich againX1<sup>e, . . . , X</sup> involves8<sup>e.</sup> measuring<sup>(c)The</sup> X<sup>ˆ</sup> isolatedL operatordata(blue,qubitsdark)in X<sup>ˆ</sup> is. extended(e) The X<sup>ˆ</sup> toL<sup>′</sup> operator is extended to X<sup>ˆ</sup> L<sup>′′andnowincludestheoriginalchainlinkingthetwoqubitholes,andinadditionaclosedloopof</sup> operators. (f) The closed loop is completely stabilized by the nine X<sup>ˆ</sup> stabilizers X<sup>ˆ</sup> s1 . . . X<sup>ˆ</sup> s9 (blue (dark) squares). We can thus reduce the operator chain X<sup>ˆ</sup> L<sup>′′toachain</sup> X<sup>ˆ</sup> L<sup>′′′thatisidenticaltotheoriginal</sup> X<sup>ˆ</sup> L, other than possible sign changes. The sign changes are captured as in the multi-cell move by defining the power pX through (−1)<sup>pX</sup> ≡ Xs<sup>f</sup> 1<sup>X</sup> s<sup>f</sup> 2<sup>. . . X</sup> s<sup>f</sup> 9<sup>= ±1,givenbythe</sup> product of all the X<sup>ˆ</sup> stabilizer measurement outcomes enclosed by the X<sup>ˆ</sup> L<sup>′′loop.ThepowerpX=0(1)determineswhethera</sup> ZˆL byproduct operator does not (does) appear, multiplying the final wavefunction. 



<!-- Start of picture text -->
(a) (b) (c) (d) (e)<br>Z  ˆ L e ’<br>Z ˆ L Z sf1 Z si13 Z si12 Z si11 Z si10 Z ˆ ’’L Z sf12 Z sf11 Z sf10<br>Z si 2 Zsi 9 Z sf2 Z ˆ L’ Z sf9<br>Z ˆ Le ZZ ssii 34 Zsi 5 Zsi 6 ZZ ssii 78 Z Zssff34 Z sf5 Z sf6 Z Z s8s7ff<br><!-- End of picture text -->

FIG. 20. (Color online) Braid transformation of a Z<sup>ˆ</sup> L operator on a single Z-cut qubit in a fully-stabilized array. (a) Double Z-cut qubit with Z<sup>ˆ</sup> L in red (gray); data qubits are open circles; dashed line linking the two qubit holes does not represent an operator. (b) Extended opening (solid red (gray) loop) for first move in the braid. The pre-move Z<sup>ˆ</sup> stabilizer outcomes Zs<sup>i</sup> 2<sup>, . . . , Z</sup> s<sup>i</sup> 9<sup>areallequalto±1.TheZˆ</sup> L<sup>eoperator(solidred(gray)loop)isextendedfromZˆL,Zˆ</sup> L<sup>e≡Zˆs2. . .Zˆs9ZˆL.(c)The</sup> extended opening is closed up by turning on the stabilizers Z<sup>ˆ</sup> s1, . . . , Zˆs8, and waiting d surface code cycles to obtain the error-corrected outcomes Zs<sup>e</sup> 1<sup>, . . . , Z</sup> s<sup>e</sup> 8<sup>.The newZˆ</sup> L<sup>′operator is the red (gray) loop formed by four data qubitZˆoperators, equal</sup> to Z<sup>ˆ</sup> L<sup>′= ( ˆZs1. . .Zˆs8)( ˆZs2. . .Zˆs9) ˆZL.(d) Second move in the braid,which involves extendingZˆ</sup> L<sup>′toZˆ</sup> L<sup>e</sup><sup>`′`,using the associatedZˆ</sup> stabilizer outcomes. (e) The final Z<sup>ˆ</sup> L<sup>′′isaclosedloopoffourdataqubitoperatorsidenticaltotheoriginalZˆL.Zˆ</sup> L<sup>′′maydifferin</sup> sign with respect to Z<sup>ˆ</sup> L, captured by defining (−1)<sup>pZ</sup> ≡ (Zs<sup>f</sup> 9<sup>. . . Z</sup> s<sup>f</sup> 12<sup>)(Z</sup> s<sup>i</sup> 10<sup>. . . Z</sup> s<sup>i</sup> 13<sup>)(Z</sup> s<sup>f</sup> 1<sup>. . . Z</sup> s<sup>f</sup> 8<sup>)(Z</sup> s<sup>i</sup> 2<sup>. . . Z</sup> s<sup>i</sup> 9<sup>) = ±1.Thepower</sup> pZ determines whether an X<sup>ˆ</sup> L byproduct operator appears, multiplying the final wavefunction. 

with details provided in Appendix I. 

IˆL1 ⊗ XˆL2 → IˆL1 ⊗ XˆL2: Figure 22 shows the braid transformation of I<sup>ˆ</sup> L1 on the first Z-cut qubit with X<sup>ˆ</sup> L2 on the second X-cut qubit. Braiding the Z-cut qubit hole through the X-cut qubit does not generate any chains of operators from either qubit that wrap around or otherwise interact with the other qubit, so the braid transformation in this case does nothing (other than sign changes). Hence we find 



(details and sign changes in Appendix I). 

IˆL1 ⊗ ZˆL2 → ZˆL1 ⊗ ZˆL2: Figure 23 shows the transformation of I<sup>ˆ</sup> L1 on the first Z-cut qubit and Z<sup>ˆ</sup> L2 on the second X-cut qubit. In Fig. 23b, Z<sup>ˆ</sup> L2 is extended as shown in the figure, by multiplying it by the Z<sup>ˆ</sup> stabilizers outlined by the dashed boxes. The first qubit’s hole is then moved through the path left open by the extension of Z<sup>ˆ</sup> L2 (Fig. 23c). Z<sup>ˆ</sup> L2 is then multiplied by all the stabilizers shown in the dashed boxes (Fig. 23d), leaving behind a loop of Z<sup>ˆ</sup> operators surrounding the first qubit’s hole, a loop that is exactly a Z<sup>ˆ</sup> L1 operation on the first Z-cut qubit, as well as the original Z<sup>ˆ</sup> L2 on qubit 2, unchanged from prior to the braid (other than possible sign 

28 



<!-- Start of picture text -->
(a) (b) (c) (d) (e) (f)<br>Z-cut X ˆ L1 X ˆ L1 ’’’<br>X1e X12e X11e X10e<br>e e Xsf1 X sf2 X sf3<br>XX32e X8e X ˆ L1 ’ X9 X ˆ L1 ’’ X sf4 X sf6<br>f f f<br>X-cut I ˆ L2 X4e X5e X6e X7e X s7 X s8 X s9<br>X ˆ L2<br><!-- End of picture text -->

FIG. 21. (Color online) A braid on a Z-cut qubit, where the lower Z-cut hole of the qubit is braided around the upper X-cut hole of an X-cut qubit. The braid’s effect on the X<sup>ˆ</sup> L1 operator on Z-cut qubit 1 is displayed. (a) Z-cut qubit (above) and X-cut qubit (below) with corresponding logical operators; data qubits are shown as open circles. (b) Extension for first move in braid, where data qubits are measured along X<sup>ˆ</sup> , with measurement outcomes X1<sup>e,X</sup> 2<sup>e, . . . X</sup> 8<sup>e.(c)</sup> X<sup>ˆ</sup> L1 operator is extended in length to X<sup>ˆ</sup> L<sup>′</sup> 1<sup>.(d)Extensionforsecondmoveinbraid,wheredataqubitsaremeasuredalong</sup> X<sup>ˆ</sup> with measurement outcomes X9<sup>e, . . . X</sup> 12<sup>e.(e)</sup> X<sup>ˆ</sup> L<sup>′′</sup> 1<sup>operatorisextendedinlength,comprisingtheoriginalchainplusaclosedloopofdataqubitoperators,</sup> the loop enclosing the upper hole of the X-cut qubit. (f) The loop part of the X<sup>ˆ</sup> L<sup>′′</sup> 1<sup>operatorismovedthroughtheenclosed</sup> stabilized cells, leaving a loop of X<sup>ˆ</sup> data qubit operators that is equal to X<sup>ˆ</sup> L2 on the second qubit, with X<sup>ˆ</sup> L1 unchanged from before the braid (other than possible sign changes). 



<!-- Start of picture text -->
(a) (b) (c) (d)<br>Z-cut I ˆ L1 I ˆ L1<br>I ˆ L1<br>X ˆ L2 X ˆ L2 I ˆ L1 X ˆ L2 X ˆ L2<br>X-cut<br><!-- End of picture text -->

FIG. 22. (Color online) (a)-(d) Illustration of the braid transformation of the I<sup>ˆ</sup> L1 ⊗ X<sup>ˆ</sup> L2 operator product. After the move, there is no net change of either operator. 

changes). The braid therefore performs the transformation 



ZˆL1 ⊗ IˆL2 → ZˆL1 ⊗ IˆL2: Finally we consider the braid transformation of Z<sup>ˆ</sup> L1 on the first qubit with I<sup>ˆ</sup> L2 on the second qubit. Braiding the first qubit hole through the second qubit drags the loop of Z<sup>ˆ</sup> operators along as it did for the empty loop braid, but as the loop preserves its closed form during the two moves, it does not generate a chain or loop of operators that can act on the second qubit, so the braid transformation does nothing (other than sign changes). Hence we find 



In general, a braid transformation leaves logical operators that are built from closed loops of data qubit operators unchanged, and there is no braid-induced interaction with the other qubit hole. By contrast, logical operators that are built from open chains of data qubit 

operators linking the two qubit holes end up leaving a loop of operators surrounding the other qubit hole. The different braid outcomes arise because the first logical qubit is a Z-cut qubit, for which the X<sup>ˆ</sup> L operator is an open chain that interacts with the second qubit, while the second logical qubit is an X-cut qubit, for which the ZˆL operator is an open chain that interacts with the first qubit. 

The braid is made of two move transformations that induce sign changes in the first qubit’s logical operators, which appear as qubit 1 byproduct logical operators X<sup>ˆ</sup> L1 and Z<sup>ˆ</sup> L1 acting on the surface code wavefunction, as was discussed for the one-cell and multi-cell moves. The braid transformation also generates sign changes in the second qubit’s logical operators, even though that qubit is not displaced during the braid. These sign changes generate qubit 2 byproduct logical operators X<sup>ˆ</sup> L2 and Z<sup>ˆ</sup> L2 acting on the wavefunction. Details regarding the byproduct operators are given in Appendix I. 

We now turn to a discussion of the CNOT gate, and make clear why the transformations we have detailed ac- 

29 



<!-- Start of picture text -->
(a) (b)<br>Z-cut<br>I ˆ L1<br>X-cut Z ˆ L2<br>(c) (d)<br>Z ˆ L1 Z ˆ s1 Z ˆ s2 Z ˆ s3<br>Z ˆ s4<br>Z ˆ s5<br>Z ˆ L2 ‘ Z ˆ s7 Z ˆ s6<br><!-- End of picture text -->

FIG. 23. (Color online) Braid transformation of I<sup>ˆ</sup> L1 ⊗ Z<sup>ˆ</sup> L2. (a) Prior to the move, displaying I<sup>ˆ</sup> L1 on qubit 1 and Z<sup>ˆ</sup> L2 on qubit 2. Data qubits are shown as open circles where relevant. (b) The Z<sup>ˆ</sup> L2 operator is extended by multiplying it by a set of stabilizers (dotted boxes), resulting in the heavy red (gray) line that is equivalent to the original Z<sup>ˆ</sup> L2, with the exception of possible sign changes. (c) Qubit 1’s hole is moved through the path opened up by extending Z<sup>ˆ</sup> L2. (d) Z<sup>ˆ</sup> L2 is moved back to its original form, leaving behind a loop of Z<sup>ˆ</sup> physical qubit operators that comprise a Z<sup>ˆ</sup> L1 operator on qubit 1. 

tually identify the braid as a CNOT between two logical qubits. 

### C. The CNOT gate 

The two-qubit CNOT gate is a fundamental gate for quantum computation. One of the two qubits in the CNOT serves as the control, and the other as the target. In the standard two-qubit basis |gg⟩, |ge⟩, |eg⟩, |ee⟩, the CNOT is represented by the 4 × 4 real matrix 



If the control qubit is in |g⟩, the target qubit state is unchanged, while if the control qubit is in |e⟩, the target qubit undergoes an X<sup>ˆ</sup> bit-flip, exchanging |g⟩ and |e⟩. Note that C<sup>ˆ</sup> is Hermitian, C<sup>ˆ†</sup> = C<sup>ˆ</sup> , and unitary, C<sup>ˆ</sup> C<sup>ˆ†</sup> = Cˆ<sup>†</sup> Cˆ = Cˆ ˆC = Iˆ. 

One way to test an experimental CNOT gate is to perform the CNOT on each of the four two-qubit basis states, and then do projective measurements of the result onto each of the four basis states. These sixteen experiments can be compared to the matrix in Eq. (30) to verify that the CNOT has been implemented correctly. This is essentially a Schr¨odinger picture test of the CNOT. 

An equivalent method is to use the Heisenberg picture, by examining the transformation of the various two-qubit operators due to the action of the CNOT. This would seem to involve showing that the CNOT performs the correct transformation for all sixteen outer products of pairs of the four single qubit operators, I<sup>ˆ</sup> , Xˆ , Yˆ and Zˆ. It turns out you only need to show that the CNOT transforms four of these outer products correctly: 





The other twelve relations are either trivial (I<sup>ˆ</sup> ⊗ I<sup>ˆ</sup> transforms to itself), or can be written in terms of these four transformations. Hence C<sup>ˆ†</sup> ( X<sup>ˆ</sup> ⊗X<sup>ˆ</sup> ) C<sup>ˆ</sup> = X<sup>ˆ</sup> ⊗I<sup>ˆ</sup> is the same as Eq. (32), as can be seen by multiplying both sides of Eq. (32) by C<sup>ˆ†</sup> on the left and by C<sup>ˆ</sup> on the right, and using the fact that C<sup>ˆ</sup> is unitary. Combinations such as Xˆ ⊗ Zˆ transform according to 



Other combinations involving Y<sup>ˆ</sup> can be worked out using the identity Y<sup>ˆ</sup> = Z<sup>ˆ</sup> X<sup>ˆ</sup> ; hence 



We can therefore validate a CNOT implementation by verifying that it satisfies the four relations given by 

30 

Eqs. (31-34). However, these are precisely the four transformations that we worked out for the braid, so indeed a braid is a CNOT. 

Note that the full braid transformation, including all the operations on the physical data qubits, involves a number of projective measurements and is therefore not unitary. However, if we consider the effect of the braid on the product |Q⟩|qL⟩, while the transformation of the stabilized state |Q⟩ is not unitary, the transformation of the logical state |qL⟩ is indeed a unitary one. 

### D. CNOT between two Z-cut qubits 

We have only shown how to perform CNOTs using a braid with a Z-cut qubit as the control and an X-cut qubit as the target. We can extend this to a CNOT between two Z-cut qubits using the circuit shown in Fig. 24a-c. The circuit performs a CNOT of the logical Z-cut “targetin” qubit using the logical Z-cut control qubit, with the Z-cut “target-out” qubit carrying the result. An ancillary X-cut qubit is the target for the three logical CNOTs in the circuit, so all the CNOTs are braid transformations between a Z-cut and an X-cut qubit. The circuit includes two logical measurements, with outcomes MZ and MX . If the target-in qubit is measured to be in |+L⟩ (|−L⟩), with MX = +1(−1), then the target-out qubit does not (does) have a Z<sup>ˆ</sup> L applied to it prior to the CNOT. If the X-cut qubit is measured to be in |gL⟩ (|eL⟩), with MZ = +1(−1), then the target does not (does) have an XˆL applied to it after the CNOT. 

You can verify that this circuit works properly by using operator transformations, or alternatively by testing it with the four input basis states |gg⟩, |ge⟩, |eg⟩ and |ee⟩ for the control and target-in Z-cut qubits (dropping the logical subscript L for now). For example, consider |eg⟩, where the control is in |e⟩ and the target-in is in |g⟩. We write the four-qubit state |abcd⟩ where a is the top, Z-cut control qubit, b the X-cut qubit, c the target-out and d the target-in qubit. The state is initially |eg +g⟩. This state is unchanged after the first CNOT in the circuit, while the second CNOT yields |ee+g⟩. The third CNOT generates the entangled state |eegg⟩ + |egeg⟩. We now measure the second (X-cut) qubit in Z<sup>ˆ</sup> , which can yield two outcomes: 

1. If the Z<sup>ˆ</sup> measurement of the second (X-cut) qubit yields MZ = +1 (meaning the second qubit was measured in |g⟩), the state is projected to |egeg⟩ with the target-out qubit in |e⟩; with MZ = +1 we do not apply X<sup>ˆ</sup> L to this qubit. The outcome of the target-in qubit measurement has no effect (a ZˆL applied to the target doesn’t affect it), so we see that the target-out ends up in |e⟩, and we have the circuit performing the transformation |eLgL⟩→ |eLeL⟩ as desired. 

2. If instead the Z<sup>ˆ</sup> measurement of the second qubit 

yields MZ = −1 (meaning projection of the second qubit to |e⟩), after the measurement the state is |eegg⟩ with the target-out in |g⟩. As we have MZ = +1, we need to apply an X<sup>ˆ</sup> L to the targetout qubit, which transforms it to |e⟩. Hence the circuit performs the same transformation, |eg⟩→|ee⟩. 

We encourage the reader to test the other possible input states, to show that |gg⟩→|gg⟩, |ge⟩→|ge⟩, and |ee⟩→ |eg⟩. 

There is an analogous circuit for performing a CNOT between two X-cut qubits, using a Z-cut qubit as an intermediate ancillary to perform the braid. This is shown in Fig. 24d-f, with a state transfer between the control-in and control-out qubits. 

### E. Single-control, multi-target CNOTs 

It is frequently necessary to implement single-control, multi-target CNOTs; these appear for example in the distillation circuits used to purify imperfect states, as we shall see when we discuss the S<sup>ˆ</sup> and T<sup>ˆ</sup> gates. It turns out that these kinds of CNOTs are actually no more complicated than a single-control, single-target CNOT, and in fact can be implemented in the same number of surface code cycles as a CNOT between two Z-cut or between two X-cut qubits. We display such a circuit in Fig. 25, implementing a single-control, triple-target logical CNOT between X-cut qubits. This circuit uses a single Z-cut qubit as an intermediary to perform the braid transformation, and an X-cut control-out ancillary to which the control-in state is transferred during the circuit operation. The Z- cut intermediary is braided through the control and the three target qubit holes, a process that can be performed in just 2d surface code cycles, followed by measurements that are used to interpret the result. This can of course be extended to any number of target qubits, without any additional surface code cycles needed to complete the operation. 

### XV. THE HADAMARD TRANSFORMATION 



In the Schr¨odinger picture, this unitary Hermitian operator<sup>22</sup> takes the Z<sup>ˆ</sup> eigenstates |g⟩ and |e⟩ and transforms 

> 22 There is an unfortunate collision between the notation for the Hadamard and the Hamiltonian operators, which both use H<sup>ˆ</sup> ; however, we have managed to avoid invoking the Hamiltonian at any point in this article, so this should not cause confusion. 

31 



<!-- Start of picture text -->
Z-cut Z-cut X-cut<br>(a) control in control out (d) X-cut 〉 control out<br>X-cut<br>X-cut 〉 control in<br>Z-cut<br>Z-cut |+ 〉 Z-cut |+ 〉<br>target out<br>Z-cut  X-cut  X-cut<br>target in target in target out<br>(b) control in control out (e) 〉 control out<br>〉 control in<br>|+ 〉 target out |+ 〉<br>target in target in target out<br>(c) control in control out (f) control in control out<br>target in target out target in target out<br><!-- End of picture text -->

FIG. 24. (Color online) (a) Logical CNOT between two Z-cut qubits. The control, target in, and the second ancilla (in |+L⟩) are all Z-cut qubits, while the first ancilla is an X-cut qubit. The logical CNOTs are all between Z- and X-cut qubits, generated by braiding transformations. The measure outcomes MZ and MX signal how the output state should be interpreted, as described in the main text. (b) Simplified representation using braids, with black lines for Z-cut qubits and blue (light) lines for the X-cut qubit. There are a pair of lines for each logical qubit, one line for each qubit hole. The two lines join when a logical qubit is created or measured. (c) Even more condensed representation. (d) Logical CNOT between two X-cut qubits. The control, target in, and the first ancilla are all X-cut qubits, while the second ancilla is a Z-cut qubit. The logical CNOTs are all between X- and Z-cut qubits, generated by braiding transformations with the Z-cut as the control. The measure outcomes MZ and MX signal how the output state should be interpreted. (e) Simplified representation, with black lines for the Z-cut qubits and blue (light) for the X-cut qubit. (f) Even more simplified representation. 



> target 3 Xˆ to Zˆ and vice versa, so it satisfies 

> target 2 Hˆ<sup>†</sup> Xˆ Hˆ = Z,ˆ (38) target 1 Hˆ<sup>†</sup> ZˆHˆ = X.ˆ 

> control A logical Hadamard is implemented in the surface code as shown in Figs. 26, 27 and 28, with details of the process given in Appendix J and in Ref. [49]. We start in Fig. 26 with an array of d = 7 logical qubits. The first (Color online) Schematic of circuit used to implestep in the process is to isolate the logical qubit to be single-qubit control, triple target logical CNOT (cirtransformed from the larger 2D array, by turning off a cuit equivalent on right), using the same notation as was used ring of stabilizers, isolating the logical qubit in a sepaThe blue (light) lines are the logical X-cut qubits rate patch of the 2D array, as shown in Fig. 27a. The Z<sup>ˆ</sup> L used for the control and targets, and the black line is an anciloperator loop is transformed to a patch-crossing chain lary logical Z-cut qubit that serves as an intermediary between by multiplying it by a number of stabilizers in the patch. qubits. The sequence involves a total of six logical By widening the ring that isolates the logical qubit into analogous to Fig. 24. a “moat”, so that the moat engulfs the two qubit holes, the logical qubit is transformed to a simple “patch” qubit as shown in Fig. 27b-d, similar to the d = 5 array qubit X<sup>ˆ</sup> eigenstates |+⟩+⟩⟩ and |−⟩,, respectively. It we discussed in Section VI. 

FIG. 25. (Color online) Schematic of circuit used to implement a single-qubit control, triple target logical CNOT (circuit equivalent on right), using the same notation as was used in Fig. 24. The blue (light) lines are the logical X-cut qubits used for the control and targets, and the black line is an ancillary logical Z-cut qubit that serves as an intermediary between the X-cut qubits. The sequence involves a total of six logical qubits, analogous to Fig. 24. 

them to the X<sup>ˆ</sup> eigenstates |+⟩+⟩⟩ and |−⟩,, respectively. It similarly takes the |+⟩ and |−⟩ eigenstates to |g⟩ and |e⟩. In terms of the Bloch sphere, the Hadamard is represented by a 180<sup>◦</sup> rotation about an axis in the x − z plane, at 45<sup>◦</sup> to the z axis. In the surface code, such arbitrary rotations cannot be performed, so an equivalent logical rotation is not possible. 

The key to the logical Hadamard is now implemented, by performing physical Hadamards on all the data qubits in the patch; this exchanges the X<sup>ˆ</sup> L operator for Z<sup>ˆ</sup> L and vice versa, as well as swapping the identities of the X and Z stabilizers (Fig. 27e). This however results in a misalignment of the stabilizers in the patch with those in the larger 2D array, so we then perform two swaps, from 

In the Heisenberg representation, the Hadamard takes 

32 





<!-- Start of picture text -->
XL<br>ZL<br><!-- End of picture text -->

FIG. 26. (Color online) Initial 2D array for the logical Hadamard example. The spacing and size of the Z-cut qubit holes corresponds to a distance d = 7. The two holes in the center of the array form the logical qubit that is the target for the logical Hadamard, and for which we display the X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L logical operators. The dashed box outlines the limits for what is shown in Figs. 27 and 28. 

These repeat numbers are therefore specific to this distance d = 7 geometry [49], and larger distance codes will require more repetitions. 

In this process, we performed physical Hadamards on the data qubits, and then did two swaps to realign the stabilizers. A completely equivalent process is to first perform a data qubit-measure qubit swap, then perform a physical Hadamard on all the measure qubits, which now store the data qubit states. The process is completed by swapping the Hadamard-transformed measure qubit states to the appropriate data qubits, after which the measure qubits regain their original X<sup>ˆ</sup> or Z<sup>ˆ</sup> stabilizer roles. 

### XVI. SINGLE QUBIT S<sup>ˆ</sup> L AND T<sup>ˆ</sup> L OPERATORS 

To complete our set of logical gates, we need surfacecode implementations of the S<sup>ˆ</sup> L and T<sup>ˆ</sup> L operators and their adjoints. These operators are represented in the standard |gL⟩, |eL⟩ basis by the 2 × 2 matrices 



and 



The S<sup>ˆ</sup> L gate is also sometimes called the P or phase gate, and T<sup>ˆ</sup> L is also called the π/8 gate.<sup>23</sup> 

We note the important identities 



and 

data qubit to measure qubit, then from measure qubit to data qubit, shifting the patch by one stabilizer cell and realigning the stabilizers (Fig. 27f). The two Z-cut holes are then recreated (Fig. 28g), positioned so that the Hadamard-transformed X<sup>ˆ</sup> L chain ends on the internal boundary of each hole, and the Z<sup>ˆ</sup> L chain is multiplied by a set of stabilizers that returns it to a loop around one of the qubit holes. The qubit holes are then moved to realign them with their original positions (Fig. 28h-j), a move that is split into two steps to preserve the array distance d. In the final step, the qubits are rejoined with the main array (as in Fig. 26). 

The surface code is used to correct and stabilize any errors that occur in this process, including potential errors from the physical Hadamards. This will maintain error correction as long as the distance d of the “patch qubit” that undergoes the Hadamard is sufficiently large, and errors in the physical Hadamards sufficiently rare. The distance d determines the number of times some of the stabilizer measurements need to be repeated in the Hadamard process, as noted in the figure captions. 



We also have the identities 



and correspondingly 



As we will see, the circuit used to implement T<sup>ˆ</sup> L is probabilistic, and half the time generates T<sup>ˆ</sup> L<sup>†.FromEq. (43),</sup> when this occurs T<sup>ˆ</sup> L<sup>†canbeconvertedtoTˆLbyapplica-</sup> tion of an S<sup>ˆ</sup> L gate. T<sup>ˆ</sup> L can be similarly converted to T<sup>ˆ</sup> L<sup>†</sup> 

> 23 The π/8 name originates from defining TˆL by the matrix in Eq. (40) multiplied by an overall (and unimportant) phase factor of e<sup>−iπ/8</sup> . 

33 



<!-- Start of picture text -->
(a) (b)<br>XL<br>XL<br>ZL<br>ZL<br>(c) (d)<br>M X<br>XL XL<br>ZL ZL<br>M X<br>(e) (f)<br>ZL ZL<br>XL<br>XL<br><!-- End of picture text -->

FIG. 27. (Color online) (a) In the first surface code cycle for the Hadamard, a ring of X<sup>ˆ</sup> stabilizers surrounding the target logical qubit is turned off, and the four-terminal Z<sup>ˆ</sup> stabilizers on the ring’s borders are reduced to three- and two-terminal measurements. The data qubits isolated within the ring itself are measured in the Z<sup>ˆ</sup> basis to maintain error tracking with the reduced-size Z<sup>ˆ</sup> stabilizers. This stabilizer measurement pattern is applied three times (three is specific to the distance-7 qubits used here; see Ref. [49]). (b) The Z<sup>ˆ</sup> L operator (dashed red line) is multiplied by all the black outline Z<sup>ˆ</sup> stabilizers, transforming Z<sup>ˆ</sup> L to a chain of operators (solid red line) going from left to right. (c) In the next surface code cycle, all X<sup>ˆ</sup> and Zˆ stabilizers in 2D patch outside the dashed box are turned off, widening the ring into a “moat” as in (d), eliminating the two qubit holes. In the same cycle, all isolated data qubits are measured in the Z<sup>ˆ</sup> basis, except those colored blue (light), which are measured in the X<sup>ˆ</sup> basis to preserve error tracking with the adjacent three-terminal X<sup>ˆ</sup> stabilizers. Note that the other un-stabilized data qubits do not need to be measured, as changes in their quantum states will be accounted for once their respective stabilizers are turned back on. (e) Before the next surface code cycle starts, a physical Hadamard is performed on all data qubits, swapping X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L and the stabilizer identities. (f) Following the Hadamard, a pair of swap operations is performed between each patch data qubit and its neighboring measure qubits, first between each data qubit and the measure qubit above it, then between each measure qubit and the data qubit to its left. This shifts the patch by one stabilizer cell in the array, aligning the measure qubits in the patch with those in the larger array. The dashed box shows the location of the patch prior to these swaps. This sequence continues in Fig. 28. 

34 



<!-- Start of picture text -->
(g) (h)<br>XL<br>XL<br>ZL<br>ZL<br>(i) (j)<br>XL XL<br>ZL ZL<br><!-- End of picture text -->

FIG. 28. (Color online) (continued from Fig. 27) (g) In the next surface code cycle, most of the X<sup>ˆ</sup> and Z<sup>ˆ</sup> stabilizers are turned back on, leaving two Z-cut enlarged holes and a ring, one stabilizer cell wide, isolating the 2D patch from the array, as in (a). The Z-cut holes are positioned so that the X<sup>ˆ</sup> L chain ends on the internal boundary of each hole. The Z<sup>ˆ</sup> L chain (dashed red line) is multiplied by all the black outline Z<sup>ˆ</sup> stabilizers, leaving a Z<sup>ˆ</sup> L loop (solid red line) that encloses the right Z-cut hole. (h) In the subsequent surface code cycle, and the first step of returning the Z-cut holes to original locations, the Z-cut holes are expanded and Z<sup>ˆ</sup> L and X<sup>ˆ</sup> L modified accordingly. This move is split in two steps to preserve the distance d during this process; the process pauses here for d surface code cycles to establish all values in time. (i) In the second step of returning the Z-cut holes to their original locations, the Z-cuts are expanded to encompass the original positions. The stabilizer measurements are performed twice. (j) In the final step, the cuts are reduced to their original size, as in Fig. 26. This stabilizer measurement pattern is applied three times (see Ref. [49]). Following this, the isolated patch is reconnected by turning on the appropriate stabilizers. 

by application of S<sup>ˆ</sup> L, with the result having a byproduct Z<sup>ˆ</sup> L operator; in other words, S<sup>ˆ</sup> LT<sup>ˆ</sup> L|ψL⟩ = Z<sup>ˆ</sup> LT<sup>ˆ</sup> L<sup>†|ψL⟩,</sup> and the Z<sup>ˆ</sup> L byproduct operator is handled in software. A high-fidelity logical implementation of S<sup>ˆ</sup> L and T<sup>ˆ</sup> L involves special ancilla states. Implementing S<sup>ˆ</sup> L relies on the |YL⟩ ancilla state 



while implementing T<sup>ˆ</sup> L relies on the |AL⟩ ancilla state 



The |YL⟩ and |AL⟩ ancilla states are created in a special “short qubit,” which can be put in an arbitrary but concomitantly imperfect state, a process known as “state injection.” Once the state has been injected, the “short qubit” is increased to the standard distance d to make it less error-prone, and the imperfect logical state of the standard-distance qubit is then purified by a high-fidelity process known as “distillation”; we discuss these steps below. The S<sup>ˆ</sup> L and T<sup>ˆ</sup> L gates are then implemented with circuits using logical CNOTs and Hadamards involving these ancilla states, as shown in Fig. 29 and Fig. 30, respectively. 

The S<sup>ˆ</sup> L gate implementation shown in Fig. 29 involves two logical CNOTs and two logical Hadamard opera- 

35 



<!-- Start of picture text -->
〉 〉<br><!-- End of picture text -->

FIG. 29. Logic circuit that implements the S<sup>ˆ</sup> L gate. The circuit uses the ancilla state |YL⟩ = (|gL⟩ + i|eL⟩)/√2, on which two controlled logical CNOTs and two logical Hadamards are performed, resulting in the input state |ψL⟩ being transformed to S<sup>ˆ</sup> L|ψL⟩. Note that as S<sup>ˆ</sup> L<sup>†=ZˆL ˆSL,thesamecircuittrans-</sup> forms |ψL⟩ to Z<sup>ˆ</sup> LS<sup>ˆ</sup> L<sup>†|ψL⟩whereZˆLisabyproductoperator.</sup> 

We can test this circuit with the input state |ψ⟩ = α|g⟩ + β|e⟩ (dropping the L subscript) and the ancilla state with θ = π/4 (this is the state |AL⟩). Hence the initial state is 



The CNOT transforms this to 





tions. An input state |ψL⟩ in one logical qubit is deterministically transformed into S<sup>ˆ</sup> L|ψL⟩ by interacting with the ancilla qubit in the |YL⟩ state. This can be most easily seen by testing the circuit with the input state |ψL⟩ = α|g⟩ + β|e⟩, where we drop the L subscript for simplicity. We consider the states |g⟩ and |e⟩ of |ψL⟩ separately. For |g⟩, the CNOT does nothing, so the |YL⟩ ancilla state transforms according to Hˆ Hˆ |YL⟩ = |YL⟩. For |e⟩, the CNOT performs an XˆL on the ancilla state, which then transforms according to Hˆ Xˆ Hˆ Xˆ |YL⟩ = ZˆXˆ |YL⟩ = −|e⟩ + i|g⟩, where we have dropped normalization. Writing the circuit state as |ab⟩ where a represents the input state and b the ancilla, the circuit produces the output 









as desired. 

To instead apply S<sup>ˆ</sup> L<sup>†,weusetheidentitySˆ</sup> L<sup>†=ZˆL ˆSL,</sup> which means we use the circuit shown in Fig. 29 and have a byproduct Z<sup>ˆ</sup> L appear on the output, in other words |ψL⟩ transforms to Z<sup>ˆ</sup> L( S<sup>ˆ</sup> L<sup>†|ψL⟩).</sup> 

The T<sup>ˆ</sup> L gate is implemented with the non-deterministic circuit shown in Fig. 30. Given the input ancilla state |θL⟩ = |gL⟩ + e<sup>iθ</sup> |eL⟩, the output |φL⟩ of this circuit is 



The first operator is a byproduct operator, whose power pZ is equal to 0(1) if the Z<sup>ˆ</sup> L measurement MZ of the logical qubit state is +1(−1). The second operator is a rotation by the angle θ, 



For the T<sup>ˆ</sup> L gate, the rotation angle is θ = +π/4(−π/4) depending on the sign +1(−1) of the Z<sup>ˆ</sup> L measurement. 

If we measure the second qubit in |g⟩, i.e. we have the outcome MZ = 1, the first qubit state is α|g⟩ + e<sup>iπ/4</sup> β|e⟩, which is precisely T<sup>ˆ</sup> L|ψL⟩, so we have succeeded. If instead we measure the second qubit in |e⟩, i.e. the measurement outcome is MZ = −1, the first qubit state is 



which is X<sup>ˆ</sup> LT<sup>ˆ</sup> L<sup>†|ψL⟩multiplied by an overall phase, which</sup> can be neglected. 

Hence approximately half of the times we run the circuit we will succeed in generating T<sup>ˆ</sup> L|ψL⟩, signaled by the measurement MZ = +1. However, the other times we run the circuit the measurement MZ = −1 will signal the output state 



In this case, to achieve the desired result, we must fix the output using S<sup>ˆ</sup> LT<sup>ˆ</sup> L<sup>†=TˆL.Thereisaslightcomplication</sup> if there are byproduct X<sup>ˆ</sup> L or Z<sup>ˆ</sup> L operators, which we discuss in the next section; here we assume there are no byproduct operators. The correction to the output is achieved by applying S<sup>ˆ</sup> L to |φL⟩: 



where we use the identity S<sup>ˆ</sup> LX<sup>ˆ</sup> L = i X<sup>ˆ</sup> LS<sup>ˆ</sup> L<sup>†anddropthe</sup> unimportant phase factor of i. Hence passing the output state |φL⟩ through the S<sup>ˆ</sup> L circuit gives the result ( X<sup>ˆ</sup> LZ<sup>ˆ</sup> L) T<sup>ˆ</sup> L|ψL⟩, where X<sup>ˆ</sup> LZ<sup>ˆ</sup> L are byproduct operators that are handled by the control software. 

If we need to perform T<sup>ˆ</sup> L<sup>†,we use the circuitinFig. 30,</sup> and about half the time we will get the measurement outcome MZ = −1, which indicates the circuit produced XˆL ˆTL<sup>†,whichisthedesiredoutput(withabyproduct</sup> operator X<sup>ˆ</sup> L). The other half of the time we get the measurement outcome MZ = +1, and we can correct 

36 



<!-- Start of picture text -->
IL<br>AL S L TL<br>XLZL<br><!-- End of picture text -->

FIG. 30. Logic circuit for the T<sup>ˆ</sup> L gate. The circuit uses the ancilla state |AL⟩ = (|gL⟩ + e<sup>iπ/4</sup> |eL⟩)/√2, which is used to control a CNOT on the target state |ψL⟩, transforming the ancilla to the output state |φL⟩. The CNOT target state is measured along Z<sup>ˆ</sup> L, resulting in a projective, probabilistic outcome. Following this, the CNOT control qubit is processed by a conditional S<sup>ˆ</sup> L gate: If the Z<sup>ˆ</sup> L measurement MZ yields a +1 outcome, the output state is the desired one, |φL⟩ = T<sup>ˆ</sup> L|ψL⟩, and the S<sup>ˆ</sup> L gate is not applied. If however the measurement yields a −1 outcome, the output is |φL⟩ = X<sup>ˆ</sup> LT<sup>ˆ</sup> L<sup>†and theSˆLgate is applied,resulting in the out-</sup> put X<sup>ˆ</sup> LZ<sup>ˆ</sup> LT<sup>ˆ</sup> L|ψL⟩. Note the double lines represent the classical measurement data with a probabilistic outcome, with these data controlling the S<sup>ˆ</sup> L gate. The bracketed operators in the output correspond to MZ = +1 (I<sup>ˆ</sup> L) and MZ = −1 ( X<sup>ˆ</sup> LZ<sup>ˆ</sup> L). 

the circuit output T<sup>ˆ</sup> L|ψL⟩ by applying S<sup>ˆ</sup> L, as S<sup>ˆ</sup> LT<sup>ˆ</sup> L = ZˆL ˆTL<sup>†;thisisdoneusingtheSˆLcircuit,withtheoutput</sup> including the byproduct operator Z<sup>ˆ</sup> L that is handled by the control software. 

### A. Commuting X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L through S<sup>ˆ</sup> L and T<sup>ˆ</sup> L 

We turn briefly to the issue of commuting the X<sup>ˆ</sup> L and ZˆL operators through the SˆL and TˆL gates, which is necessary if the classical control hardware is to handle all XˆL and ZˆL operations, as discussed in Sect. IX. The commutation relations are most easily worked out using the circuits that implement S<sup>ˆ</sup> L and T<sup>ˆ</sup> L, Figs. 29 and 30. 

First we show that Z<sup>ˆ</sup> L and S<sup>ˆ</sup> L commute, which can be seen by applying the S<sup>ˆ</sup> L circuit to the input state Z<sup>ˆ</sup> L|ψL⟩. We have an implicit I<sup>ˆ</sup> L operation on the CNOT target state |YL⟩, and we can commute the operator pair Z<sup>ˆ</sup> L⊗I<sup>ˆ</sup> L through the first CNOT, as Z<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L → Z<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L. The Hadamard and the identity operator commute, and Z<sup>ˆ</sup> L ⊗ IˆL can then be commuted through the second CNOT. The second Hadamard likewise commutes with I<sup>ˆ</sup> L, so the operator pair Z<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L can be commuted through the entire circuit. Hence Z<sup>ˆ</sup> L and S<sup>ˆ</sup> L commute. This result should not be surprising, as the S<sup>ˆ</sup> L gate represents a form of logical rotation about the Z<sup>ˆ</sup> axis, and therefore should commute with Z<sup>ˆ</sup> L. 

When passing the X<sup>ˆ</sup> L operator through the S<sup>ˆ</sup> L circuit, we have for the first CNOT transformation X<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L → XˆL ⊗ XˆL, and commuting through the Hadamard, which acts on the second operator, we have XˆL ⊗ XˆL → XˆL ⊗ ZˆL. The second CNOT performs the transformation X<sup>ˆ</sup> L ⊗Z<sup>ˆ</sup> L → Y<sup>ˆ</sup> L ⊗Y<sup>ˆ</sup> L, and the second Hadamard does not affect the second Y<sup>ˆ</sup> L (other than an unimportant sign change). Hence X<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L is transformed to Y<sup>ˆ</sup> L ⊗ Y<sup>ˆ</sup> L, and 

the control software must note the byproduct operator transformation X<sup>ˆ</sup> L → Y<sup>ˆ</sup> L = Z<sup>ˆ</sup> LX<sup>ˆ</sup> L on the output state, with the two byproduct operators handled in software. An additional Y<sup>ˆ</sup> L also appears on the ancilla |YL⟩, but as YˆL|YL⟩ = i|YL⟩, this does nothing other than the unimportant phase factor i, which can be ignored. 

In summary then, the S<sup>ˆ</sup> L gate commutes with Z<sup>ˆ</sup> L and XˆL as follows: 



To show that Z<sup>ˆ</sup> L and T<sup>ˆ</sup> L commute, we use similar reasoning using the circuit in Fig. 30. As T<sup>ˆ</sup> L also represents a form of rotation about Z<sup>ˆ</sup> , this makes sense. There is a slight wrinkle when we get the measurement outcome MZ = −1, which means that a S<sup>ˆ</sup> L gate will be applied, in this case to the state |φL⟩ = X<sup>ˆ</sup> LT<sup>ˆ</sup> L<sup>†( ˆZL|ψL⟩).Then we</sup> have 



which is the desired result, with a byproduct operator XˆL that is handled by the control software. 

The commutation of X<sup>ˆ</sup> L through the T<sup>ˆ</sup> L gate is similar. We take the input state X<sup>ˆ</sup> L|ψL⟩, and commute XˆL through the CNOT with an implicit IˆL operating on the CNOT control qubit. The CNOT takes I<sup>ˆ</sup> L ⊗ X<sup>ˆ</sup> L → IˆL ⊗ XˆL. Hence we have an additional XˆL that reverses the sign of the terminal MZ measurement. If after applying this X<sup>ˆ</sup> L, the measurement outcome is MZ = −1, we have the correct output, T<sup>ˆ</sup> L|ψL⟩. 

However, if after applying X<sup>ˆ</sup> L, the measurement gives MZ = +1, the circuit will apply S<sup>ˆ</sup> L to |φL⟩ = X<sup>ˆ</sup> LT<sup>ˆ</sup> L<sup>†|ψL⟩.</sup> Using S<sup>ˆ</sup> LT<sup>ˆ</sup> L<sup>†=TˆL, and dropping global phase factors, we</sup> have 



which is as desired, with the appearance of two byproduct operators X<sup>ˆ</sup> LZ<sup>ˆ</sup> L. 

We summarize the T<sup>ˆ</sup> L logic circuit outcomes, as well as the commutation of T<sup>ˆ</sup> L with Z<sup>ˆ</sup> L and X<sup>ˆ</sup> L in Table IV. 

37 

|Input|Output|Measurement|
|---|---|---|
||ψL⟩|ˆTL|ψL⟩<br>ˆ<br>XL <sup>ˆ</sup>ZL <sup>ˆ</sup>TL|ψL⟩|MZ = +1<br>MZ =−1|
|ˆZL|ψL⟩|ˆZL ˆTL|ψL⟩<br>ˆ<br>XL <sup>ˆ</sup>TL|ψL⟩|MZ = +1<br>MZ =−1|
|ˆ<br>XL|ψL⟩|ˆ<br>XL <sup>ˆ</sup>ZL <sup>ˆ</sup>TL|ψL⟩<br>ˆTL|ψL⟩|MZ = +1<br>MZ =−1|



TABLE IV. T<sup>ˆ</sup> L logic circuit outcomes and commutation relations for T<sup>ˆ</sup> L with Z<sup>ˆ</sup> L and X<sup>ˆ</sup> L. The measurement MZ indicates which state is output from the circuit. 

### B. Short qubits and state distillation 

The ancilla |YL⟩ and |AL⟩ states used in the S<sup>ˆ</sup> L and TˆL gates are XˆL rotations of |gL⟩ by 90<sup>◦</sup> and 45<sup>◦</sup> , respectively, which are not easy to perform in the surface code. Consider a distance d = 3 Z-cut qubit, with XˆL = Xˆ1Xˆ2Xˆ3 the operator chain connecting the two Z-cut holes. There is no obvious way to perform an arbitrary rotation of this logical qubit. For example, how would we perform a differential rotation of the state |ψL⟩ using ǫX<sup>ˆ</sup> L, with the desired final state (I<sup>ˆ</sup> L + ǫX<sup>ˆ</sup> L)|ψL⟩? You cannot perform this rotation by operating with Iˆ + ǫ ˆXj on each of the j = 1, 2, 3 data qubits, as this will give the result (I<sup>ˆ</sup> + ǫX<sup>ˆ</sup> 1 + ǫX<sup>ˆ</sup> 2 + ǫX<sup>ˆ</sup> 3))|ψL⟩, to first order in ǫ, which is not what we want. To get around this problem, we need to create a qubit in which the X<sup>ˆ</sup> L chain is just one qubit in length; such a “short qubit” would of course be error-prone, but if we minimize the number of surface code cycles in which the qubit remains small, these errors will not accumulate significantly. 

We can create and initialize a short X-cut qubit using the procedure shown in Fig. 31, which is known as “state injection”; details are in Appendix K. 

The state injected in the short qubit is necessarily imprecise; even the best possible classically-controlled state preparation will have insufficient precision to achieve error rates below 10<sup>−14</sup> , needed for our example Shor’s algorithm problem. The two target states we are interested in, |YL⟩ and |AL⟩, can however be made significantly more precise through distillation. This is a probabilistic process in which an imperfect input state can be purified by multiple executions of a particular logic circuit, with the output state from each execution rapidly approaching the perfect desired result. Circuits for distilling the |YL⟩ and |AL⟩ ancilla states are shown in Figs. 32 and 33, which implement the 7-qubit Steane [50] and the 15-qubit Reed-Muller encodings [17], respectively. These circuits may look very complicated, but the reader should note that these circuits only involve single-control, multitarget logical CNOTs, and as discussed in Sect. XIV E, these CNOTs take the same number of surface code cycles as a single-target logical CNOT. Hence, to complete the |YL⟩ distillation, only six logical CNOT cycles are 



<!-- Start of picture text -->
(a) (b)<br>1<br>2 3<br>4 5 6<br>7 8<br>9<br>(c) (d)<br>MX<br>gL  + e i s eL<br><!-- End of picture text -->

FIG. 31. (Color online) Sequence to generate a short X-cut qubit. (a) Surface code array, with the array extending indefinitely outside the region shown here. (b) Two X<sup>ˆ</sup> stabilizers are turned off, creating a short X-cut qubit, with a single data qubit separating the two holes. (c) In the next surface code cycle, the central data qubit (qubit 5) is measured along X<sup>ˆ</sup> simultaneously with the measurement of the four-terminal Z<sup>ˆ</sup> stabilizers adjacent to it; the remainder of the array has the standard surface code cycle for all stabilizers. This creates a logical qubit initialized in either |+L⟩ (X5 = +1) or |−L⟩ (X5 = −1). Prior to starting the next surface code cycle, the central data qubit is rotated using R<sup>ˆ</sup> Z (θ) to the desired final state |gL⟩ + e<sup>iθ</sup> |eL⟩. (d) The surface code stabilization is restarted. After this the short qubit is enlarged to protect against errors. 

needed, and for the |AL⟩ distillation, at most eight such cycles are needed. Hence the temporal overhead to complete a distillation is actually relatively small; the surface code can implement these circuits very efficiently. 

In the circuit shown in Fig. 32, a logical Bell pair is created, and one logical qubit from the pair is entangled with six other logical qubits using the Steane code. Each of the seven encoded qubits is then rotated with an approximate S<sup>ˆ</sup> L gate, each of these gates using an approximate |Y<sup>ˆ</sup> L⟩ states as an ancilla. In the first stage of distillation, each of these ancilla states is directly produced by state injection in a short qubit, while in later distillation stages the ancillae will be purified versions of these states. The distillation circuit generates one output state |ψL⟩ in the other logical qubit of the Bell pair, and performs seven X<sup>ˆ</sup> L measurements of the other qubits. The measurement outcomes are used to interpret the output state |ψL⟩, by evaluating the three Steane code X<sup>ˆ</sup> stabilizers X<sup>ˆ</sup> S1 = X<sup>ˆ</sup> L3X<sup>ˆ</sup> L4X<sup>ˆ</sup> L5X<sup>ˆ</sup> L6, X<sup>ˆ</sup> S2 = X<sup>ˆ</sup> L2X<sup>ˆ</sup> L5X<sup>ˆ</sup> L6X<sup>ˆ</sup> L7 and X<sup>ˆ</sup> S3 = X<sup>ˆ</sup> L1X<sup>ˆ</sup> L4X<sup>ˆ</sup> L6X<sup>ˆ</sup> L7 (numbering as in Fig. 32). These products are evaluated by taking the appropriate 

38 



<!-- Start of picture text -->
+ 〉 S L 1<br>+ 〉 S L 2<br>+ 〉 S L 3<br>g 〉 S L 4<br>g 〉 S L 5<br>g 〉 S L 6<br>g 〉 S L 7<br>+ 〉<br><!-- End of picture text -->

FIG. 32. (Color online) Distillation circuit for the |YL⟩ ancilla state. A logical Bell pair is created (dashed box, bottom left), and one qubit from the pair is encoded with 6 ancilla logical qubits using the Steane code [17, 51]. The seven encoded qubits are then each rotated with an S<sup>ˆ</sup> L gate (dotted blue); the ancilla states used by the S<sup>ˆ</sup> L gates are precisely the |YL⟩ states that are being purified, produced in the first round of distillation by state injection in a short qubit, or are from a prior round of distillation. The output from each S<sup>ˆ</sup> L gate is then measured along X<sup>ˆ</sup> L, and the results indicate whether the output state |ψL⟩ in the other qubit of the Bell pair should be discarded, or is a purified version of |YL⟩, possibly involving a Z<sup>ˆ</sup> L phase-flip (in software) as discussed in the main text. 

products of the individual X<sup>ˆ</sup> Lj measurements.<sup>24</sup> If each of the stabilizer measurement outcomes {XS1, XS2, XS3} is equal to {+1, +1, +1}, then the output state |ψL⟩ is a purified version of |YL⟩ and will be kept (otherwise the state is discarded). If the product of all the individual logical measurements is XL1XL2 . . . XL7 = −1, nothing additional is needed, but if this product is +1, then the output will include a Z<sup>ˆ</sup> L byproduct operator. 

If the ancilla |YL⟩ states used in the S<sup>ˆ</sup> L gates in Fig. 32 are perfect, and the circuit is operated flawlessly, the output state |ψL⟩ will always be a perfect |YL⟩. The ancilla |YL⟩ states can however suffer from errors; a Y<sup>ˆ</sup> L error does nothing, as Y<sup>ˆ</sup> L|YL⟩ = i|YL⟩, while Z<sup>ˆ</sup> L|YL⟩ = |YL<sup>⋆⟩and</sup> XˆL|YL⟩ = −i|YL<sup>⋆⟩.Ifthereisaprobabilitypofhaving</sup> an X<sup>ˆ</sup> L or Z<sup>ˆ</sup> L error, and the circuit is operated flawlessly, then the output state will have a probability 7p<sup>3</sup> ≪ p of having an error. The output will be successfully distilled with a probability 1 − 7p. 

Clearly the distillation converges rapidly to a nearly perfect output state. If one cycle of distillation does not result in a sufficiently accurate output, more cycles can be added. To run the circuit twice, one needs to prepare 



<!-- Start of picture text -->
(a) + 〉 T L † 1<br>+ 〉 T L † 2<br>g 〉 T L † 3<br>+ 〉 T L † 4<br>g 〉 T L † 5<br>g 〉 TL † 6<br>g 〉 T L † 7<br>+ 〉 T L † 8<br>g 〉 T L † 9<br>g 〉 TL † 10<br>g 〉 T L † 11<br>g 〉 TL † 12<br>g 〉 T L † 13<br>g 〉 TL † 14<br>g 〉 TL † 15<br>+ 〉<br>(b)<br>ZL<br>AL S L TL † e L<br>XL<br>e L<br><!-- End of picture text -->

FIG. 33. (Color online) Distillation circuit for the |AL⟩ ancilla state [19, 51]. (a) A logical Bell pair is created (dashed box, bottom left), and one qubit from the pair encoded with 14 ancilla logical qubits using the Reed-Muller code [17, 51]. The fifteen encoded logical qubits are then each rotated with a T<sup>ˆ</sup> L<sup>†</sup> gate (dotted blue). The ancillae for the T<sup>ˆ</sup> L<sup>†gates are the |AL⟩</sup> states that are being purified, prepared either by state injection in a short qubit or are produced in a previous distillation round. Following the T<sup>ˆ</sup> L<sup>†gates,fifteen</sup> X<sup>ˆ</sup> L measurements MX are made, with the measurement pattern indicating whether to discard the output state |ψL⟩ of the other qubit of the Bell pair, or indicating that |ψL⟩ is a purified |AL⟩ state, possibly with an additional Z<sup>ˆ</sup> L byproduct operator. (b) Diagram for the T<sup>ˆ</sup> L<sup>†gate,whichissimilartotheTˆLgateinFig. 30,with</sup> a CNOT using the imperfect |AL⟩ (blue, light) as the control on the input state |χL⟩. When the measurement MZ = −1, the output is X<sup>ˆ</sup> LT<sup>ˆ</sup> L<sup>†|χL⟩;the</sup> X<sup>ˆ</sup> L has no effect when the MX measurement is made in panel (a). When the measurement MZ = +1, the output is T<sup>ˆ</sup> L|χL⟩, and must be corrected (up to byproduct operators) using the S<sup>ˆ</sup> L circuit in Fig. 29, giving SˆL ˆTL|χL⟩ = ZˆL ˆTL<sup>†|χL⟩.ThebyproductoperatorZˆLwillre-</sup> verse the sign of the measurement MX that occurs after this gate in panel (a). 

> 24 Note that the Steane code stabilizers XˆSj are formed from products of logical operators, and are not to be confused with the surface code stabilizers! 

39 

at least 7<sup>2</sup> = 49 approximate |YL⟩ input states, with the outputs |ψL⟩ of each distillation circuit providing the seven input states for the second distillation circuit.<sup>25</sup> If the original states have a probability p of X<sup>ˆ</sup> or Z<sup>ˆ</sup> errors, the first set of output states will have an error rate 7p<sup>3</sup> , and the output from the second distillation an error rate 7(7p<sup>3</sup> )<sup>3</sup> = 7<sup>4</sup> p<sup>9</sup> , with exponential improvement. To run the circuit three times, 7<sup>3</sup> = 343 input states are required, with an output error rate 7<sup>13</sup> p<sup>27</sup> , and so on. Note that if the error rate p is of order 1%, running the distillation circuit twice generates states with an error rate of about 10<sup>−15</sup> , below the target of 10<sup>−14</sup> set by the size of the Shor’s algorithm problem we consider here. 

A similar discussion applies to the |AL⟩ distillation circuit shown in Fig. 33. In this circuit, a logical Bell pair is created, and one qubit from the pair encoded with fourteen other logical qubits using the Reed-Muller code. The fifteen qubits are then rotated with T<sup>ˆ</sup> L<sup>†gates,where</sup> each T<sup>ˆ</sup> L<sup>†gateusesanapproximationofthe|AL⟩stateas</sup> an ancilla, either from a short qubit injection in the first round of distillation, or a previously purified |AL⟩ in later rounds. 

The T<sup>ˆ</sup> L<sup>†circuitisshowninFig. 33b.TheTˆ †</sup> L<sup>gateis</sup> probabilistic, where given the input |χL⟩, about half the time it generates T<sup>ˆ</sup> L|χL⟩, signalled by the measurement MZ = +1, and S<sup>ˆ</sup> L is then applied using the circuit in Fig. 29, giving S<sup>ˆ</sup> LT<sup>ˆ</sup> L|χL⟩ = Z<sup>ˆ</sup> LT<sup>ˆ</sup> L<sup>†|χL⟩, with aZˆL byprod-</sup> uct operator appearing in the output state. The rest of the time the circuit generates X<sup>ˆ</sup> LT<sup>ˆ</sup> L<sup>†|χL⟩,signalledby</sup> MZ = −1, with a byproduct X<sup>ˆ</sup> L. 

The outputs of the T<sup>ˆ</sup> L<sup>†gatesareallmeasuredalong</sup> XˆL, where the sign of the measurement result MX is reversed due to the byproduct ZˆL if the SˆL circuit had to be used. The pattern of measurement outcomes is used to evaluate the four Xˆ stabilizers for the Reed-Muller code, X<sup>ˆ</sup> R1 = X<sup>ˆ</sup> L4X<sup>ˆ</sup> L5 . . . X<sup>ˆ</sup> L11, X<sup>ˆ</sup> R2 = XˆL1XˆL2 . . . XˆL7XˆL15, XˆR3 = XˆL2 . . . XˆL5XˆL10 . . . XˆL13 and XˆR4 = XˆL1XˆL2XˆL5XˆL6XˆL9XˆL10XˆL13XˆL14 (using the qubit numbering in Fig. 33).<sup>26</sup> If each of the measurement outcomes {XR1, XR2, XR3, XR4} is {+1, +1, +1, +1}, the state |ψL⟩ of the other qubit of the Bell pair is a purified |AL⟩ state. If the product of all the measurements XL1XL2 . . . XL15 = +1, no postprocessing is needed, while if this product is −1, then a ZˆL byproduct operator will appear. 

If the probability of an error containing a Z<sup>ˆ</sup> L component in the approximate |AL⟩ states is p, the output state |ψL⟩ will have an error rate 35p<sup>3</sup> . The distillation will succeed with a probability 1 − 15p, so if p is of order 1%, 

> 25 Note that this may take more than 49 attempts, as a fraction of the circuits, of order p, will fail to successfully distill their input states. 

> 26 Again, the Reed-Muller stabilizers here are defined in terms of logical qubits, and should not be confused with the surface code stabilizers. 

the distillation will have to be re-run about one-sixth of the attempts. Additional distillation cycles, built in the same way as for the |YL⟩ distillation, will improve the output exponentially. 

### XVII. PHYSICAL IMPLEMENTATIONS 

We have now covered all the basic aspects of the surface code approach to quantum computing. We have described all the gates that are required to implement e.g. Shor’s algorithm or Grover’s search algorithm. The discussion has been mostly theoretical, while the motivation for developing the surface code is of course to find a realistic and practical physical implementation for a quantum computer. There are a number of physical systems in which this scheme could in principle be implemented, ranging from cold atoms [52, 53] and ions [54–56], to semiconductor-based approaches [57], to superconducting integrated circuits [58–63]. Each of these systems has certain advantages and certain disadvantages. For any system to be a candidate for a surface code implementation, it must of course meet the requirements for single-qubit and two-qubit gate and measurement fidelities, which is not true for any system to date, although a number of systems are close to these requirements. The surface code clearly also requires a very large number of physical qubits (of order 10<sup>8</sup> is probably the smallest number needed for a practical factoring computer), so a separate requirement is the ability to assemble and integrate a large number of nominally identical qubits. Furthermore, the operation and error detection of the surface code assumes classical logic support, with the classical logic operating significantly faster than the qubits, in order that state preparation, qubit interactions, and error tracking can be maintained with a high level of fidelity. 

Given classical processor clock rates of order 3 GHz, it is difficult to imagine performing the surface code classical processing if the rounds of error detection are applied much faster than 10<sup>6</sup> to 10<sup>7</sup> Hz. This implies physical quantum gates of duration 10-100 ns, and hence physical qubit coherence times of at least 1-10 µs, if the minimum physical gate fidelities of 99% are to be achieved. Gates operating at these speeds, and physical qubits with these coherence times, have already been achieved experimentally in superconducting systems [64, 65]. We believe that a surface-code cycle time of 200 nanoseconds is thus a reasonable target. Slower surface code operation implies higher qubit overhead or longer factoring times (a surface code cycle time of 2 ms would take 30 years to factor a 600 digit number, as per the scaling in Table I, if no additional qubits were devoted to the task). 

The intimate intermingling of classical and quantum logic requires high-speed interconnects to each qubit, which makes very dense qubit geometries harder to implement. It will be challenging to integrate qubits with spacings of order of or less than 1 µm with classical electronics, while spacings of tens to hundreds of µm should 

40 

be more straightforward. Note that a 10<sup>4</sup> × 10<sup>4</sup> array of physical qubits with inter-qubit spacing of 100 µm implies a physical size for the 2D array of about 1 × 1 m<sup>2</sup> , which is perhaps manageable, so “large” qubits are not unrealistic. 

These considerations appear to point to superconducting circuits as one of the best candidates for implementing the surface code: All of the physical and operating parameters for superconducting circuits fall into the ranges discussed here. There are clearly significant challenges in achieving sufficient gate and measurement fidelities. This is compounded by the need for tight integration of superconducting quantum circuitry with classical logic, all operating in tandem. However, we believe that with a continued, and significant, investment in superconducting quantum circuits, and in developing the necessary accompanying high-speed and closely-integrated classical logic, a quantum computer could be built. 

### XVIII. ACKNOWLEDGEMENTS 

We thank John Preskill for providing us with a brief history of surface code theory development, and James Wenner for assistance with numerical simulations. We also thank Frank K. Wilhelm, Michael R. Geller, Daniel Sank and James Wenner for their critical readings of a draft of this article. M.M. acknowledges support from an Elings Postdoctoral Fellowship. Support for this work was provided by IARPA under ARO award W911NF08-1-0336 and under ARO award W911NF-09-1-0375. A.G.F. acknowledges support from the Australian Research Council Centre of Excellence for Quantum Computation and Communication Technology (project number CE110001027), with support from the US National Security Agency and the US Army Research Office under contract number W911NF-08-1-0527, and by the Intelligence Advanced Research Projects Activity (IARPA) via Department of Interior National Business Center contract number D11PC20166. The U.S. Government is authorized to reproduce and distribute reprints for Governmental purposes notwithstanding any copyright annotation thereon. Disclaimer: The views and conclusions contained herein are those of the authors and should not be interpreted as necessarily representing the official policies or endorsements, either expressed or implied, of IARPA, DoI/NBC, or the U.S. Government. 

### Appendix A: Notation 

The notation in this article is mostly standard. We use the following conventions: 





3. In the same Z<sup>ˆ</sup> axis basis, the operator Z<sup>ˆ</sup> = σˆz = 1 0 , with eigenvalues +1, −1 for |g⟩, |e⟩. 

0 −1 

� � The measurement MZ returns these eigenvalues and projects to these respective eigenstates. Note the Z<sup>ˆ</sup> eigenvalue for |e⟩ is smaller than that for |g⟩; the Hamiltonian is positively proportional to −Z<sup>ˆ</sup> . 





6. We have the commutation relations [ X,<sup>ˆ</sup> Y<sup>ˆ</sup> ] = −2 Z<sup>ˆ</sup> , [ Y ,<sup>ˆ</sup> Z<sup>ˆ</sup> ] = −2 X<sup>ˆ</sup> , and [ Z,<sup>ˆ</sup> X<sup>ˆ</sup> ] = +2 Y<sup>ˆ</sup> (not having an i in the definition for Y<sup>ˆ</sup> interrupts the cyclic permutation of the Pauli operators). 

7. Hadamard operator Hˆ = ~~√~~ <u>12</u> �Xˆ + Zˆ� = ~~√~~ <u>12</u> 11 −11 . Note that H<sup>ˆ</sup> |g⟩ = |+⟩, H<sup>ˆ</sup> |e⟩ = |−⟩, � � 

Hˆ |+⟩ = |g⟩, Hˆ |−⟩ = |e⟩, Hˆ<sup>2</sup> = Iˆ. 

8. The S<sup>ˆ</sup> gate is another Z<sup>ˆ</sup> -axis rotation, represented 1 0 

in the Z<sup>ˆ</sup> basis by the matrix S<sup>ˆ</sup> = . 0 i 

� � 

9. The T<sup>ˆ</sup> gate is a Z<sup>ˆ</sup> -axis rotation, represented in the 0 

Zˆ basis by the matrix Tˆ = . This gate 0 e<sup>iπ/4</sup> 

� 1 � 

is also called the π/8 gate, as one can also write it e<sup>−iπ/8</sup> 0 

in the form T<sup>ˆ</sup> = e<sup>iπ/8</sup> . Note that � 0 e<sup>iπ/8</sup> � 

Tˆ<sup>2</sup> = Sˆ, Sˆ<sup>2</sup> = Zˆ, Sˆ<sup>4</sup> = Iˆ. 

10. A controlled-NOT C<sup>ˆ</sup> in the basis |gg⟩, |ge⟩, |eg⟩, |ee⟩, where the first state is the control and the second the target, is given by 



Hence if the control is in |g⟩ the CNOT is equivalent to I<sup>ˆ</sup> operating on the target, while if the control is in |e⟩ the CNOT is equivalent to X<sup>ˆ</sup> operating on the target. 

41 

11. A Toffoli gate is a three-qubit, controlled-controlled NOT gate. In the basis |ggg⟩, |gge⟩, |geg⟩, |gee⟩, |egg⟩, |ege⟩, |eeg⟩, |eee⟩, where the first and second states are the two controls and the third state is the target, the Toffoli is represented by 



Hence if both controls are in |e⟩ the Toffoli is equivalent to X<sup>ˆ</sup> operating on the target, while otherwise the Toffoli is equivalent to I<sup>ˆ</sup> operating on the target. 

12. The jth Z (X) stabilizer operator Z<sup>ˆ</sup> sj ( X<sup>ˆ</sup> sj) is a product Z<sup>ˆ</sup> sj = Z<sup>ˆ</sup> j,aZ<sup>ˆ</sup> j,bZ<sup>ˆ</sup> j,cZ<sup>ˆ</sup> j,d of its four neighboring a, b, c and d physical qubit Z<sup>ˆ</sup> operators (analogously for X<sup>ˆ</sup> ). Each cycle of the surface code yields a measurement of these operators, yielding the measurement outcome Zsj (Xsj). 

We have chosen to modify the names we apply to many of the functional elements in the surface code, using terms we believe are more suggestive of each element’s function. We have compiled these names changes as shown in Table V. 

|Published<br>terminology<br>||
|---|---|
|(Ref. [20])<br>|This paper|
|code state|quiescent state|
|X syndrome (light)<br>|measure-X (orange/light)<br>|
|Z syndrome (dark)|measure-Z (green/dark)|
|syndrome symbol•|measure symbol•|
|data symbol◦|data symbol◦<br><br>|
|Z, X, H, I|ˆZ, ˆ<br>X, <sup>ˆ</sup>H, <sup>ˆ</sup>I|
|smooth boundary|X boundary|
|rough boundary<br>|Z boundary|
|rough/primal qubit<br>smooth/dual qubit|single X-cut qubit<br>single Z-cut qubit<br>|
|double rough defect|(double) X-cut qubit<br>|
|double smooth defect|(double) Z-cut qubit<br>measurement Xabcd<br>measurement Zabcd|



TABLE V. Translation between the “traditional” language used in the published literature (e.g. from [20]) and the terminology used here. 

### Appendix B: Z<sup>ˆ</sup> and X<sup>ˆ</sup> stabilizer circuits 



<!-- Start of picture text -->
(a) X X a<br>X<br>Z<br>b Z Z<br>1 2 3 4 5 6 7 8<br>(b) X g H H - +<br>a<br>b<br>Z g I I - +<br>X ˆ a X ˆ b Z ˆ a Z ˆ b<br><!-- End of picture text -->

FIG. 34. (Color online) (a) Two data qubits a and b are stabilized by one measure-Z and one measure-X qubit, connected as shown. (b) Quantum circuit for the two measure qubits operating on the two data qubits. The CNOT order is critical: First, the measure-X qubit acts as the control of the CNOT on data qubits a followed by that on b; the two CNOTs are preceded and followed by a Hadamard H<sup>ˆ</sup> . The measure-Z qubit is then the target of a CNOT with a as the control, followed by that with b as a control. The two identity Iˆ operators for the measure-Z process, which are performed by simply waiting, ensure that the timing on the measure-Z qubit matches that of the measure-X qubit. The measurement operators that correspond to steps 3 through 6 of the control sequence, followed by the projective measurement at the end of the circuit, are indicated below the relevant CNOTs, with the measure-X qubit stabilizing the product X<sup>ˆ</sup> aX<sup>ˆ</sup> b and the measure-Z qubit stabilizing Z<sup>ˆ</sup> aZ<sup>ˆ</sup> b. 

shown in Fig. 1b and c of the main text, respectively. For simplicity, we will look at a system with just two data qubits, a and b, stabilized by one measure-Z and one measure-X qubit; the extension to the full four-qubit stabilization is straightforward. The simplified layout and corresponding stabilizer circuits are shown in Fig. 34, which now involve two CNOTs per measure qubit instead of the four CNOTs in the full circuit. 

The claim is that this circuit will stabilize the two data qubits a and b in a simultaneous eigenstate of X<sup>ˆ</sup> aX<sup>ˆ</sup> b and Zˆa ˆZb, i.e. precisely the Bell states listed in Table II in the main text, with the measurement outcomes corresponding to the eigenvalues listed in that table. We show how this occurs, using an arbitrary entangled state of the two data qubits as an input to the circuits in Fig. 34. Note the circuit will entangle all the qubits together during the CNOT operations; we write the quantum states in the form |ψX ψaψbψZ⟩, i.e. the first element is the state of the measure-X qubit, the second and third those of data qubits a and b, respectively, and the fourth element that of the measure-Z qubit (this order makes the CNOTs easier to compute, with the measure-X controlling data qubits a and b, and the data qubits controlling the measure-Z qubit). 

The state after executing the N th step of the circuit is |ψN ⟩. We work through each numbered step in Fig. 34. 

Step 1: The measure-X and measure-Z qubits are reset to their ground states. The data qubits can be entangled 

In this Appendix, we explicitly work through the operation of the surface code Z<sup>ˆ</sup> and X<sup>ˆ</sup> stabilizer circuits 

42 

in a general two-qubit state; using the notation |ψaψb⟩ where ψa represents the state of qubit a and ψb that of qubit b, we can write the data qubit state in the form 



where the coefficients A, B, C and D are complex, and we ignore normalization throughout. The state of the full circuit is now 







Step 2: The identity I<sup>ˆ</sup> leaves the state of the measureZ qubit unchanged. The measure-X qubit undergoes a Hadamard, which takes |g⟩→|+⟩ = |g⟩ + |e⟩ and |e⟩→ |−⟩ = |g⟩−|e⟩ (again, ignoring normalization). The state of the full circuit is now 





Step 3: The first CNOT transforms the states of a control and target qubit |c t⟩ according to |gg⟩→|gg⟩, |ge⟩→|ge⟩, |eg⟩→|ee⟩, and |ee⟩→|eg⟩. By applying the CNOT between the control measure-X qubit and the target data qubit a, the 1st to 2nd element, we obtain 





Step 4: The second CNOT applies the control (the measure-X qubit) to the target (data qubit b), the 1st to 3rd element, yielding 





Step 5: The third CNOT applies the control (data qubit a) to the target (the measure-Z qubit), the 2nd to 4th elements, 





Step 6: The fourth and last CNOT applies the control (data qubit b) to the target (the measure-Z qubit), the 3rd to 4th elements, 



Step 7: The measure-X qubit undergoes its second Hadamard, giving 



Step 8: The terminal Z<sup>ˆ</sup> measurements are performed on both the measure-Z and measure-X qubits. Each qubit has two possible outcomes, +1 for the |g⟩ state and −1 for the |e⟩ state. The four possible outcomes and the corresponding projection to the final state of the data qubits are 



The probabilities to project to each of these states is given by the modulus-squared of each corresponding amplitude in Eq. (B8). 

Note that the measurement outcomes, and the corresponding states of the two data qubits, are precisely those appearing in Table II for the Bell states. Hence, given an arbitrary input state, at the end of the circuit we project the two data qubits onto one of the four eigenstates of Zˆa ˆZb and XˆaXˆb. 

If we take one of the output states in Eq. (B9), and use it as an input to the stabilizer circuit, you can easily check that the output will precisely reproduce the input, with the same measurement outcomes. For example, if we have the measurement outcome {MX , MZ} = {−1, −1}, the data qubits end up in the state |ge⟩−|eg⟩. This is the input state in Eq. (B1) with the coefficients A = D = 0 and B = −C = 1. Looking at Eq. (B8), the amplitude coefficients for A + D, A − D, and B + C will all be zero, implying the output state will always project to the 

43 

input state |ge⟩−|eg⟩. Hence, as promised, the stabilizer circuit returns the same measurement outcomes and the same data qubit state. 

An alternative, and much more compact, way to see this result is to realize that we can perform the same calculation using stabilizers to identify the qubit states rather than using state notation itself (this assumes you have read the discussion of the Heisenberg representation of the CNOT transformation in Sect. XIV C.) We write the stabilizers in the form Q<sup>ˆ</sup> X ⊗ Q<sup>ˆ</sup> a ⊗ Q<sup>ˆ</sup> b ⊗ Q<sup>ˆ</sup> Z = QˆX Qˆa ˆQb ˆQZ with subscripts corresponding to the qubit labeling in Fig. 34, and Q<sup>ˆ</sup> j represents either X<sup>ˆ</sup> j or Z<sup>ˆ</sup> j on the jth qubit. The initial state of the system, after initialization of the X and Z qubits, is given by the two stabilizers X<sup>ˆ</sup> X I<sup>ˆ</sup> aI<sup>ˆ</sup> bI<sup>ˆ</sup> Z and I<sup>ˆ</sup> X I<sup>ˆ</sup> aI<sup>ˆ</sup> bZ<sup>ˆ</sup> Z; this means that the system is in an eigenstate of these two operator products, and we actually know what the eigenvalue is for each stabilizer (+1 for each, as the X qubit is initialized in |+⟩ and the Z qubit is initialized in |g⟩). Now, the first CNOT, between X and a, transforms the first stabilizer to X<sup>ˆ</sup> X X<sup>ˆ</sup> aI<sup>ˆ</sup> bI<sup>ˆ</sup> Z, using the Heisenberg transformation rule for the CNOT ( X<sup>ˆ</sup> X ⊗ I<sup>ˆ</sup> a → X<sup>ˆ</sup> X ⊗ X<sup>ˆ</sup> a). It does nothing to the second stabilizer, as I<sup>ˆ</sup> X ⊗ I<sup>ˆ</sup> a is trivially unchanged. The second CNOT, between X and b, takes the first stabilizer to X<sup>ˆ</sup> X X<sup>ˆ</sup> aX<sup>ˆ</sup> bI<sup>ˆ</sup> Z, using the same rule, and again does nothing to the second stabilizer. The third CNOT, between a and Z, takes the first stabilizer to X<sup>ˆ</sup> X X<sup>ˆ</sup> aX<sup>ˆ</sup> bX<sup>ˆ</sup> Z and the second stabilizer to I<sup>ˆ</sup> X Z<sup>ˆ</sup> aI<sup>ˆ</sup> bZ<sup>ˆ</sup> Z, using the CNOT transformation I<sup>ˆ</sup> a ⊗ Z<sup>ˆ</sup> Z → Z<sup>ˆ</sup> a ⊗ Z<sup>ˆ</sup> Z. Finally, the fourth CNOT between b and Z, takes the first stabilizer to X<sup>ˆ</sup> X X<sup>ˆ</sup> aX<sup>ˆ</sup> bI<sup>ˆ</sup> Z, using X<sup>ˆ</sup> b ⊗ X<sup>ˆ</sup> Z → X<sup>ˆ</sup> b ⊗ I<sup>ˆ</sup> Z, and the second stabilizer to I<sup>ˆ</sup> X Z<sup>ˆ</sup> aZ<sup>ˆ</sup> bZ<sup>ˆ</sup> Z. Note that the stabilizers commute as they each have operators on the two qubits a and b. Now, the X<sup>ˆ</sup> measurement of the X qubit at the end gives us the product X<sup>ˆ</sup> aX<sup>ˆ</sup> b, and does not interfere with the second stabilizer, as X<sup>ˆ</sup> X commutes with that stabilizer. The Z<sup>ˆ</sup> measurement of Z likewise commutes with the first stabilizer, and gives us the product Zˆa ˆZb. These two measurements thus completely identify the states of these two qubits. 

We note that the sequence of CNOT operations in Fig. 34 is critical for properly producing the measurement stabilizers X<sup>ˆ</sup> aX<sup>ˆ</sup> b and Z<sup>ˆ</sup> aZ<sup>ˆ</sup> b. If instead of using the sequence as given in Fig. 1b and c (top, left, right, bottom) the clockwise sequence is used (top, right, bottom, left), then you can work out the sequence of stabilizer transformations as was done in the preceding paragraph. The result is the pair of stabilizers X<sup>ˆ</sup> X X<sup>ˆ</sup> aX<sup>ˆ</sup> bX<sup>ˆ</sup> Z and Z<sup>ˆ</sup> X Z<sup>ˆ</sup> aZ<sup>ˆ</sup> bZ<sup>ˆ</sup> Z. These two stabilizers no longer commute with the single qubit measurements of X<sup>ˆ</sup> X and Z<sup>ˆ</sup> Z, so the final measurements will just give random results. Likewise, the sequence of CNOTs given in Fig. 1b and c produces the correct stabilizers for data-qubit pairs on both the up and down diagonals. 

### Appendix C: X-cut qubit initialization in a Z<sup>ˆ</sup> eigenstate 

In this appendix we give the detailed steps for the “difficult” initialization of an X-cut qubit in the |gL⟩ state, as illustrated in Fig. 14. 

1. We start with a nominally infinite lattice with no qubit cuts (Fig. 14a). 

2. A column of four measure-X qubits is turned off, opening a rectangular cut, and the six measure-Z qubits adjacent to the cut are switched to threeterminal stabilizer measurements. In order to maintain error tracking, we perform a Z<sup>ˆ</sup> measurement on the three data qubits 1, 2 and 3 inside the cut (Fig. 14b); this could be done by direct measurement of the data qubits, if the hardware implementation allows this, or by measuring with the idle measure-X qubits in the cut. The combination of the three-terminal measure-Z stabilizers and these three single-qubit Z<sup>ˆ</sup> measurements maintains error detection, as each three-terminal measure-Z result can be multiplied with the corresponding single data qubit Z<sup>ˆ</sup> measurement to compare to the prior four-terminal Z<sup>ˆ</sup> stabilizer measurements. 

3. The data qubits inside the cut are reset to |g⟩ (Fig. 14c). This operation will result in the logical qubit being initialized to |gL⟩. 

4. The two measure-X qubits in the middle of the cut are turned back on, and all the measure-Z qubits are switched back to four-terminal measurements. The measure-Z outcomes can be compared with the previous cycle three-terminal measure-Z outcomes to maintain error detection, accounting of course for the fact that the internal data qubits were set to |g⟩. As the internal data qubits were in |g⟩ prior to the measure-X qubits being turned on, the two measure-X qubits will return random outcomes; however, the projective measurement of the measure-X qubits keeps the data qubits in an eigenstate of Z<sup>ˆ</sup> L = Z<sup>ˆ</sup> 1Z<sup>ˆ</sup> 2Z<sup>ˆ</sup> 3, as Z<sup>ˆ</sup> L commutes with all the stabilizers in the array. The ground-state initialization of the three data qubits thus ensures that the X-cut qubit is left in the |gL⟩ eigenstate of ZˆL. 

The third step can be omitted if the measurements in step 2 are nondestructive and leave the data qubits in the measured eigenstates. In this case, the eigenvalue and corresponding eigenstate of Z<sup>ˆ</sup> L will equal the product of the Z<sup>ˆ</sup> measurements for these qubits; if a different initial state is desired, an X<sup>ˆ</sup> L bit-flip can be performed in software. 

44 

### Appendix D: Measuring an X-cut qubit in the Z<sup>ˆ</sup> L basis 

Here we give the procedure for the “difficult” measurement of an X-cut qubit in the Z<sup>ˆ</sup> L basis, using Fig. 15 in the main text. 

1. We start with the logical X-cut qubit in some state (Fig. 15a). 

2. We turn off the two measure-X qubits between the two cuts, and also switch the neighboring measureZ qubits from four-terminal to three-terminal measurements. We measure the three data qubits inside the rectangular cut in the Z<sup>ˆ</sup> basis (Fig. 15b); the product of these measurements is the value of ZˆL. By combining the three-terminal measure-Z outcomes with the single data qubit Z<sup>ˆ</sup> measurements, we can maintain the surface code error tracking. 

3. We reset the three data qubits to their ground states |g⟩. This step is not strictly necessary if the Zˆ measurement in the prior step has a high fidelity for projecting to the Z<sup>ˆ</sup> eigenstates. 

4. We “destroy” the logical qubit by resuming full four-terminal Z<sup>ˆ</sup> stabilization and turning all the measure-X qubits back on, leaving us with the original 2D array (Fig. 15d). Because the data qubits were set to |g⟩, the measure-X qubits will report random outcomes on this step. 

Note that the measurement MZ of the individual qubits in step 2 projects the data qubits onto a product eigenstate of Z<sup>ˆ</sup> a, Z<sup>ˆ</sup> b and Z<sup>ˆ</sup> c of the three individual qubits, which was not the state prior to this measurement; however, as Z<sup>ˆ</sup> L commutes with the individual Z<sup>ˆ</sup> j data qubit operators, this projection commutes with Z<sup>ˆ</sup> L, so the product of the individual measurement outcomes ZaZbZc is equal to the eigenvalue ZL of Z<sup>ˆ</sup> L. 

### Appendix E: Making a larger qubit 

Here we describe how to make a distance d = 8 logical qubit, twice the distance of the logical qubits we have been discussing, in which only one stabilizer was turned off per qubit hole. Figure 16, which accompanies this description, can be found in the main text. 

We first define the the logical operator Z<sup>ˆ</sup> L as the chain 



This is shown outlined in red (gray) in Fig. 16; the analogous X<sup>ˆ</sup> L chain, that links the two larger-distance qubits, is not shown. 

1. In one surface code cycle, we stop measuring the four Z<sup>ˆ</sup> stabilizers Z<sup>ˆ</sup> s1, Z<sup>ˆ</sup> s2, Z<sup>ˆ</sup> s3 and Z<sup>ˆ</sup> s4 inside the 

ZˆL loop. Note we are using a shorthand notation for the stabilizers, where Z<sup>ˆ</sup> s1 represents the fourelement stabilizer Z<sup>ˆ</sup> s1 = Z<sup>ˆ</sup> 1aZ<sup>ˆ</sup> 1bZ<sup>ˆ</sup> 1cZ<sup>ˆ</sup> 1d; Z<sup>ˆ</sup> 1a is the first Z<sup>ˆ</sup> physical qubit operator in the Z<sup>ˆ</sup> stabilizer loop, etc. The Z<sup>ˆ</sup> L operator is the product of these four Z<sup>ˆ</sup> stabilizers, Z<sup>ˆ</sup> L = Z<sup>ˆ</sup> s1Z<sup>ˆ</sup> s2Z<sup>ˆ</sup> s3Z<sup>ˆ</sup> s4, so the initial qubit logical state will be either |gL⟩ or |eL⟩, as determined by the product of the stable outcomes Zs1Zs2Zs3Zs4 = ±1. 

2. In the same surface code cycle, we turn off the one Xˆ stabilizer Xˆs1 inside the ZˆL loop, and we also turn the X<sup>ˆ</sup> stabilizers bordering the qubit hole from four-terminal to three-terminal measurements. We perform X<sup>ˆ</sup> measurements of the four internal data qubits, projecting them onto a product of X<sup>ˆ</sup> eigenstates. This can be done either by direct measurements of these data qubits, if the hardware allows this, or by using the now-idle measure-Z qubits to perform the measurement. This measurement allows us to continue to track errors, by combining these measurements with the three-terminal X<sup>ˆ</sup> stabilizer measurements bordering the hole. 

### Appendix F: One-cell qubit move 

This appendix describes the details in moving a Z-cut logical qubit by one cell in the surface code array. The figure that relates to this process, Fig. 17, is in the main text. The move involves the following four steps: 

1. We extend the logical operator Z<sup>ˆ</sup> L by multiplying it by the set of single-qubit Z<sup>ˆ</sup> operators Z<sup>ˆ</sup> 6Z<sup>ˆ</sup> 7Z<sup>ˆ</sup> 8Z<sup>ˆ</sup> 9 that comprise the Z<sup>ˆ</sup> stabilizer just below the lower Z-cut hole, as shown in Fig. 17a: 



ZˆL<sup>enow encircles two cells, as illustrated in Fig. 17b.</sup> The result of operating with Z<sup>ˆ</sup> L<sup>eon a quiescent state</sup> |ψ⟩ is the same as Z<sup>ˆ</sup> L, other than a possible sign change from the stabilizer outcome Z6789 = ±1. 

2. We turn off the Z<sup>ˆ</sup> stabilizer Z<sup>ˆ</sup> 6Z<sup>ˆ</sup> 7Z<sup>ˆ</sup> 8Z<sup>ˆ</sup> 9. We also switch the two X<sup>ˆ</sup> stabilizers that neighbor data qubit 6 from four-terminal to three-terminal measurements, so that they no longer measure data qubit 6. This data qubit is now not stabilized by any measurements; we therefore perform an X<sup>ˆ</sup> measurement of data qubit 6, projecting it to |+⟩ or |−⟩ with the eigenvalue outcome X6 = ±1. This measurement is either performed directly on the data qubit, if allowed by the physical implementation, or by the idle measure-Z qubit just below data qubit 6 (see Fig. 17a). The product of this measurement outcome with the adjacent three-terminal X<sup>ˆ</sup> 

45 

stabilizer measurements is compared with the prior four-terminal X<sup>ˆ</sup> stabilizer measurements to maintain error detection. 

We extend X<sup>ˆ</sup> L to X<sup>ˆ</sup> L<sup>′bymultiplyingitbyXˆ6:</sup> 



3. As the distance d here is only three, we do not need to wait to stabilize the result. If we perform this process with a larger distance logical qubit, we would at this point have to wait d/4 (rounded up) surface code cycles to ensure no chain can wrap around a qubit hole. 

4. We turn on the Z<sup>ˆ</sup> stabilizer Z<sup>ˆ</sup> 3Z<sup>ˆ</sup> 4Z<sup>ˆ</sup> 5Z<sup>ˆ</sup> 6. We also switch the two X<sup>ˆ</sup> stabilizers that neighbor data qubit 6 back to four-terminal measurements, so data qubit 6 is now fully stabilized. A single measurement of each of these stabilizers is not sufficient to protect against errors, so we wait a minimum of d cycles to properly establish their values. 

   - We define the new logical operator Z<sup>ˆ</sup> L<sup>′as the prod-</sup> uct of Z<sup>ˆ</sup> L<sup>eandtheZˆstabilizerwejustturnedon,</sup> Zˆ3 ˆZ4 ˆZ5 ˆZ6: 



Clearly Z<sup>ˆ</sup> L<sup>′istheloopshowninFig. 17c,andXˆ</sup> L<sup>′</sup> is the extended chain shown in the same figure. 

### Byproduct operators 

One problem that is created in the move transformation is that the extension of X<sup>ˆ</sup> L through multiplication by Xˆ6 can yield an extended XˆL<sup>′that differs in sign fromXˆL;</sup> this will occur if the measurement outcome X6 = −1. Similarly the final Z<sup>ˆ</sup> L<sup>′candifferinsignfromZˆL,by</sup> the product of the two Z<sup>ˆ</sup> stabilizer measurement outcomes involved in the move, Z6789 and Z3456. In order to prevent these unwanted sign changes from occurring, we could multiply X<sup>ˆ</sup> L<sup>′byX6andZˆ</sup> L<sup>′byZ6789Z3456,which</sup> would correct for any sign changes (note these multipliers would be stable measurement outcomes, not the operators). However, a more efficient way to account for this is to instead modify the quiescent state |ψ⟩ by using logical bit- and phase-flips. It is convenient to define two parameters pX and pZ, using 



and 



With these definitions, pX = 0(1) if the stable X6 measurement is +1(−1), that is, if X<sup>ˆ</sup> L<sup>′does(doesnot)have</sup> 

the same sign as X<sup>ˆ</sup> L. Similarly, pZ = 0(1) if the product Z3456Z6789 = +1(−1), that is, if Z<sup>ˆ</sup> L<sup>′does (does not) have</sup> the same sign as Z<sup>ˆ</sup> L. 

Prior to performing any of the steps in the logical qubit move, the quiescent state is |ψ⟩, which we will write as |ψ<sup>pre</sup> ⟩. The various operations and measurements in the move transform this to the post-move state, which in the ideal case would be |ψ<sup>′</sup> ⟩. Due to sign changes in the X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L operators during the move, the transformation instead gives 



These additional operators are called “byproduct” operators. The expression Eq. (F6) looks complicated but is in fact quite simple: If pX = 0(1), then X<sup>ˆ</sup> L<sup>′hasthesame</sup> (opposite) sign as X<sup>ˆ</sup> L, so Z<sup>ˆ</sup> L<sup>′doesnot(does)appearin</sup> Eq. (F6). Similarly, if pZ = 0(1), then Z<sup>ˆ</sup> L<sup>′hasthesame</sup> (opposite) sign as Z<sup>ˆ</sup> L, and X<sup>ˆ</sup> L<sup>′doesnot(does)appear.</sup> The way the byproduct operators account for the sign change is through the anti-commutation of X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L, as can be seen by operating with X<sup>ˆ</sup> L on the byproduct adjusted |ψ<sup>′</sup> ⟩: 



If X<sup>ˆ</sup> L<sup>′has the same (opposite) sign asXˆL, then pX= 0(1)</sup> and the sign change is canceled by the factor +1(−1). Similarly, the presence of the byproduct operator X<sup>ˆ</sup> L<sup>′pZ</sup> will guarantee that Z<sup>ˆ</sup> L<sup>′has the same sign when operating</sup> on X<sup>ˆ</sup> L<sup>′pZ</sup> ZˆL<sup>′pX</sup> |ψ<sup>′</sup> ⟩, through their anti-commutation. 

The byproduct operators are just X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L, the bitand phase-flip logical operators, and are handled by the software control system, by changing the signs of any logical measurements of that qubit in the appropriate fashion: If pX = 0(1), then a Z<sup>ˆ</sup> L measurement will not have (will have) its sign reversed, and similarly for pZ. The byproduct operators are never actually applied to the logical qubits directly. 

A more complete description and formal theory for the byproduct (byproduct) operators can be found in Ref. [66]. 

### Appendix G: Multi-cell moves 

A multi-cell qubit shift is performed using the following steps (Fig. 18 is in the main text): 





Here Zˆsj is the jth Zˆ stabilizer, i.e. Zˆsj = Zˆja ˆZjb ˆZjc ˆZjd, the product of the four neighboring data qubit Z<sup>ˆ</sup> operators. By writing out each 

46 

Zˆsj in terms of its Zˆ operators, you can easily convince yourself that Z<sup>ˆ</sup> L<sup>eisthechainofZˆoperators</sup> that forms the extended loop in Fig. 18b. Note that ZˆL<sup>ecandifferinsignfromZˆL,dependingonthe</sup> value of the product of the pre-move stabilizer values Zs<sup>i</sup> 2<sup>Z</sup> s<sup>i</sup> 3<sup>. . . Z</sup> s,n<sup>i=±1;thebyproductoperators</sup> will be corrected as described above. 

2. We turn off the Z<sup>ˆ</sup> stabilizers Z<sup>ˆ</sup> sj now enclosed by ZˆL<sup>e, and also turn all the four-terminalXˆstabilizers</sup> that border Z<sup>ˆ</sup> L<sup>etothree-terminalstabilizers,leav-</sup> ing all the internal data qubits disconnected from the surface. 

In the same surface code cycle, we measure all the disconnected data qubits along X<sup>ˆ</sup> , either directly or using the now-idle neighboring measure-Z qubits to perform this measurement. This yields the measurement outcomes X1, X2 . . . Xn−1, each equal to ±1, which when multiplied by the appropriate three-terminal X<sup>ˆ</sup> stabilizers can be compared to the prior values of the corresponding four-terminal X<sup>ˆ</sup> stabilizers. 

We define the new X<sup>ˆ</sup> L<sup>′operatoras</sup> 



You can easily see that X<sup>ˆ</sup> L<sup>′isthechainofXˆoper-</sup> ators shown in Fig. 18c. Any sign change from the product of measurement outcomes X1 . . . Xn−1 = ±1 will be accounted for with a byproduct operator, and corrected for in any subsequent measurement. 

3. We define the new logical operator Z<sup>ˆ</sup> L<sup>′by</sup> 



You can easily convince yourself that Z<sup>ˆ</sup> L<sup>′is just the</sup> loop of physical Z<sup>ˆ</sup> operators surrounding the lower Z-cut hole shown in Fig. 18c, which is algebraically the same as the nth stabilizer Z<sup>ˆ</sup> s,n. 

We turn on the Z<sup>ˆ</sup> stabilizers Z<sup>ˆ</sup> s1, . . ., Z<sup>ˆ</sup> s,n−1, and wait at least d surface code cycles to establish the values of these stabilizers. The product of the stable post-move values, Zs<sup>f</sup> 1<sup>Z</sup> s<sup>f</sup> 2<sup>. . . Z</sup> s,n<sup>f</sup> −1<sup>=±1,will</sup> be used to determine the byproduct operators. 

4. We correct the logical wavefunction for any byproduct operators. We define the byproduct powers in the same way as for the one-cell move, 



and 



Using these, we multiply the (ideal) post-move state |ψ<sup>′</sup> ⟩ by byproduct operators to obtain the sign-corrected post-move logical state: 



### Appendix H: Single qubit braid transformation 

This appendix gives a more detailed explanation of the sign changes involved in the braid transformation of a single qubit. In Fig. 19a through f (Fig. 20a through e), shown in the main text, we show how the X<sup>ˆ</sup> L ( Z<sup>ˆ</sup> L) operator is transformed by the two moves in the braid. After the extension for the first move is closed up in Fig. 19c, XˆL is extended to XˆL<sup>′bymultiplyingXˆLbyallthedata</sup> qubits isolated in the first move: 



The second move extends X<sup>ˆ</sup> L<sup>′toXˆ</sup> L<sup>′′(Fig. 19e),again</sup> by multiplying X<sup>ˆ</sup> L<sup>′byallthedataqubitsisolatedinthe</sup> second move: 



These transformations may involve a sign change from XˆL to XˆL<sup>′′,aswiththeone-cellandmulti-cellmoves,de-</sup> pending on the stable measurement outcomes of the data qubits used in the extension of X<sup>ˆ</sup> L, which were all measured along X<sup>ˆ</sup> . The sign change is captured by the power pX , (−1)<sup>pX</sup> = (X1<sup>e. . . X</sup> 8<sup>e)(X</sup> 9<sup>e. . . X</sup> 12<sup>e),witheachparen-</sup> thetical set the product of measurement outcomes from one of the two moves. The power pX is equal to 0(1) if XˆL<sup>′′has the same (different) sign fromXˆL.Now, the loop</sup> of physical qubit operators encloses only fully-stabilized cells, as shown in Fig. 19e, and the surface code ensures that the wavefunction |ψ⟩ is an eigenstate of this loop of operators. Hence the measurement product giving pX has to be equal to the product of all the X<sup>ˆ</sup> stabilizers enclosed by the loop: 



the product of the stable measure-X stabilizers Xs,j<sup>f= ±1</sup> enclosed by the loop. A way to see this is to write out each of the stabilizers X<sup>ˆ</sup> s1 through X<sup>ˆ</sup> s9 in terms of their four data qubit X<sup>ˆ</sup> j operators, and then multiply these all together to get the product X<sup>ˆ</sup> s1X<sup>ˆ</sup> s2 . . . X<sup>ˆ</sup> s9. All the data qubits shared by any two stabilizers appear twice in this product, and thus cancel as X<sup>ˆ</sup> j<sup>2=Iˆ,leavingonly</sup> 

47 

the data qubits on the periphery of this set of stabilizers. The product (X1<sup>e. . . X</sup> 8<sup>e)(X</sup> 9<sup>e. . . X</sup> 12<sup>e) that determines pX</sup> is precisely the measurement outcome of these peripheral data qubits. 

The Z<sup>ˆ</sup> L loop operator is similarly transformed by the braid to Z<sup>ˆ</sup> L<sup>′′,usingtwosetsofexpansionsfollowedby</sup> contractions, and any sign change is determined by the Zˆ stabilizers that are enclosed in the two expansions. The sign change is equal to (−1)<sup>pZ</sup> , where pZ is equal to 0(1) if Z<sup>ˆ</sup> L<sup>′′hasthesame(opposite)signasZˆL.Intermsofall</sup> the stabilizer values in the move, we have 



The braid transforms the 2D array wavefunction |ψ⟩ in the two move operations, ending up after the second move with the wavefunction |ψ<sup>′′</sup> ⟩. Any sign changes indicated by the powers pX and pZ are accounted for by modifying the post-braid state |ψ<sup>′′</sup> ⟩ using byproduct operators that are tracked, and corrected for, in the control software: 



The notation reminds us that |ψ<sup>′′</sup> ⟩ is the ideal result, with no sign changes, but that because of move-induced sign changes, we need to keep track of these sign changes with the additional byproduct operators appearing in Eq. (H5). Hence we see that other than sign changes and byproduct operators, determined by projective measurements during the move and thus accountable in software, the braid transformation around a fully stabilized part of the array leaves the two logical operators of the Z-cut qubit unchanged. 

### Appendix I: Two-qubit braid transformation 

Here we work through braiding a Z-cut qubit hole through an X-cut qubit, as shown in Figs. 21, 22 and 23 (main text). We want to show that the braid between these two qubit types is equivalent to a logical CNOT, with the Z-cut qubit as the control and the X-cut qubit the target. The same result holds when braiding an X- cut qubit through a Z-cut, with the X-cut qubit still the target of the CNOT with the Z-cut as the control, but braiding two Z-cut qubits or two X-cut qubits requires other logic circuitry, as discussed in Sect. XIV D. 

As we discuss in the main text, it turns out we only need to show that the braid transforms a total of four of the sixteen two-qubit operator combinations correctly in order to prove a braid is a CNOT: X<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L, I<sup>ˆ</sup> L ⊗ X<sup>ˆ</sup> L, ZˆL⊗IˆL and IˆL⊗ZˆL. We consider each of these in turn, in addition to working out the transformation of X<sup>ˆ</sup> L ⊗ X<sup>ˆ</sup> L, providing an example of how two sequential braids are equivalent to an identity operation. 

XˆL ⊗ IˆL → XˆL ⊗ XˆL: We first consider the effect of the braid on the two-qubit operator X<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L = X<sup>ˆ</sup> L1I<sup>ˆ</sup> L2, 

as shown in Fig. 21. The X<sup>ˆ</sup> L1 bit-flip is directed at the first, Z-cut qubit, and I<sup>ˆ</sup> L2 is directed at the second, X-cut qubit (the subscripts 1 and 2 indicate on which logical qubit the operator acts). In the first move for the braid, we have 



Note we are mixing logical and physical qubit operators, but as the logical operators are constructed from products of physical qubit operators, this is formally acceptable. 

In the second move, we have 



As shown in Fig. 21e, the combination of the two moves of X<sup>ˆ</sup> L1 generates an operator X<sup>ˆ</sup> L<sup>′′</sup> 2<sup>thatcomprisesthe</sup> original X<sup>ˆ</sup> L1 chain along with a closed loop of data qubit operators, with the loop enclosing the upper hole of the X-cut qubit 2, as well as a number of fully stabilized cells. We can re-write this as 



To obtain this result, we have deformed the closed loop Xˆloop from the transformed XˆL<sup>′</sup> 1<sup>througheachoftheen-</sup> closed X<sup>ˆ</sup> stabilizers X<sup>ˆ</sup> sj, including a loop of physical X<sup>ˆ</sup> bit-flips that wrap tightly around the upper hole of X-cut qubit 2, which is precisely an X<sup>ˆ</sup> L2 bit-flip. The X<sup>ˆ</sup> stabilizers resolve to measurement eigenvalues ±1, leaving the outer product of logical operators X<sup>ˆ</sup> L2X<sup>ˆ</sup> L<sup>′′′</sup> 1<sup>=Xˆ</sup> L<sup>′′′</sup> 1<sup>XˆL2,</sup> as in the last line of Eq. (I3). 

There are a number of sign changes that can occur, depending on the stabilizer outcomes. We again use powers pX and pZ to capture these sign changes. The braid of the first logical qubit generates a sign change (−1)<sup>pX1</sup> ≡ (X1<sup>e. . . X</sup> 8<sup>e)(X</sup> 9<sup>e. . . X</sup> 12<sup>e)=±1,equaltothe</sup> product of the stable single data qubit measurements in the two moves. This is the same sign change as for an empty-loop braid. 

The braid also generates sign changes on the second qubit, as in the braid we have transformed the identity operator on that qubit to an XˆL2 logical operator. The sign change is very similar to that for the first qubit, where we define a power pX2 given by (−1)<sup>pX2</sup> ≡ Xs<sup>f</sup> 1<sup>. . . X</sup> s<sup>f</sup> 4<sup>X</sup> s<sup>f</sup> 6<sup>. . . X</sup> s<sup>f</sup> 9<sup>= ±1, the product of theXˆstabi-</sup> lizers involved in deforming the loop X<sup>ˆ</sup> loop surrounding the second qubit’s upper hole to the loop that is the X<sup>ˆ</sup> L2 operator. 

To account for the sign changes from the two logical qubits, we modify the post-braid wavefunction |ψ<sup>′′</sup> ⟩ with 

48 

two byproduct operators Z<sup>ˆ</sup> L<sup>pX</sup> 1<sup>1</sup> and Z<sup>ˆ</sup> L<sup>pX</sup> 2<sup>2,suchthatwe</sup> end up with 



This is not yet the whole story, as we still need to determine the byproduct operators associated with any braidinduced sign changes of the Z<sup>ˆ</sup> L1 and Z<sup>ˆ</sup> L2 operators; see Eq. (I8) for the complete expression. 

Ignoring any byproduct operators, the braid therefore generates the transformation 



XˆL ⊗ XˆL → XˆL ⊗ IˆL: Here we apply the braid transformation to the outer product of two XˆL operators on the two logical qubits. This is thus a braid transformation of the result of the braid we just discussed, XˆL ⊗ IˆL → XˆL ⊗ XˆL. A braid is not a reversible process, as there are projective measurements involved during the moves, but as we will see, the braid transformation of X<sup>ˆ</sup> L ⊗ X<sup>ˆ</sup> L reverses the braid transformation of XˆL ⊗IˆL. The simple argument is the following: When we start with X<sup>ˆ</sup> L ⊗ X<sup>ˆ</sup> L, the braid process “wraps” the X<sup>ˆ</sup> L chain from the Z-cut qubit 1 around the loop representing X<sup>ˆ</sup> L for the X-cut qubit 2, just as with X<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L. We can again deform the loop in Z-cut qubit 1’s transformed XˆL through the enclosed Xˆ stabilizers, so that it wraps tightly around the X-cut qubit 2, giving us the equivalent of two X<sup>ˆ</sup> L bit-flips on the X-cut qubit 2; these however cancel out ( X<sup>ˆ</sup> L<sup>2=IˆL), leaving us withIˆLas the resulting</sup> operation on qubit 2. Note there is no net modification of the Z-cut qubit 1 X<sup>ˆ</sup> L operator during this process, other than byproduct operations on the wavefunction. Hence we find X<sup>ˆ</sup> L ⊗ X<sup>ˆ</sup> L → X<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L under the braid transformation. 

We write out the detailed process. For the first move, just as with X<sup>ˆ</sup> L1 ⊗ I<sup>ˆ</sup> L2, we have 



In the second move, we have 



where we use the double primes on X<sup>ˆ</sup> L<sup>′′</sup> 2<sup>to distinguish the</sup> second X<sup>ˆ</sup> L2 logical operator on qubit 2 from the original XˆL2. However the product of these XˆL2 operators is the identity, as in the last line of this equation. 

In general, performing the same braid operation twice is equivalent to an identity, other than the appearance of byproduct operators. 

IˆL ⊗ XˆL → IˆL ⊗ XˆL: Consider now a braid involving IˆL1 directed at the Z-cut qubit 1, and XˆL2 directed at the X-cut qubit 2; this is shown in Fig. 22a through d. The X<sup>ˆ</sup> L2 operator is a loop of X<sup>ˆ</sup> bit-flips on the data qubits surrounding the X-cut qubit’s upper hole. The braid has no effect on the identity I<sup>ˆ</sup> L1, as the identity involves no operations, so dragging the upper qubit hole around a closed loop does not leave a trail of operators from the moving qubit that can interact with the X-cut qubit 2, and vice versa. Hence the braid leaves these two operators unchanged, as in Fig. 22d, and I<sup>ˆ</sup> L ⊗X<sup>ˆ</sup> L → I<sup>ˆ</sup> L ⊗ XˆL (other than byproduct operators not shown here). 

IˆL ⊗ ZˆL → ZˆL ⊗ ZˆL: Consider now the braid involving IˆL1 directed at the Z-cut qubit 1, and ZˆL2 directed at the X-cut qubit 2; this is shown in Fig. 23a. This is completely analogous to X<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L but with the roles of the Z- and X-cut qubits exchanged. We deform the X-cut qubit 2 Z<sup>ˆ</sup> L2 operator so that it has the form shown in Fig. 23b. The qubit 1 hole is moved through this path until it returns to its original location, shown in Fig. 23c. We can then multiply the Z<sup>ˆ</sup> L2 operator by all the Z<sup>ˆ</sup> stabilizers shown in the dashed boxes in Fig. 23d, Z<sup>ˆ</sup> s1, Z<sup>ˆ</sup> s2 . . . Z<sup>ˆ</sup> s7, whose stable measurement outcomes are all known, using the identity Z<sup>ˆ</sup> L2 = Z<sup>ˆ</sup> L1Z<sup>ˆ</sup> s1 . . . Z<sup>ˆ</sup> s7Z<sup>ˆ</sup> L<sup>′</sup> 2<sup>,whereZˆL1is</sup> the loop of Z<sup>ˆ</sup> data qubit operators surrounding the lower qubit 1 hole, thus corresponding to Z<sup>ˆ</sup> L on that qubit, and ZˆL<sup>′</sup> 2<sup>istheoriginalZˆL2chain,asshowninFig. 23d.We</sup> have thus generated a Z<sup>ˆ</sup> L1 phase-flip operation on Z-cut qubit 1. Other than possible byproduct operators, the ZˆL2 operation on the X-cut qubit 2 is not modified by the braid. Hence we see that I<sup>ˆ</sup> L ⊗ Z<sup>ˆ</sup> L transforms to Z<sup>ˆ</sup> L ⊗ Z<sup>ˆ</sup> L. Performing this braid a second time, i.e. starting now with Z<sup>ˆ</sup> L ⊗ Z<sup>ˆ</sup> L, will generate a second Z<sup>ˆ</sup> L1 operation on the Z-cut qubit 1, so this will transform back to the original pair of operators, i.e. to ( Z<sup>ˆ</sup> L · Z<sup>ˆ</sup> L) ⊗ Z<sup>ˆ</sup> L = I<sup>ˆ</sup> L ⊗ Z<sup>ˆ</sup> L, in a manner completely analogous to X<sup>ˆ</sup> L ⊗ X<sup>ˆ</sup> L → X<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L. ZˆL ⊗ IˆL → ZˆL ⊗ IˆL: Finally, consider the braid transformation involving a Z<sup>ˆ</sup> L1 operation on the Z-cut qubit 1, and I<sup>ˆ</sup> L2 directed at the X-cut qubit 2. This situation is completely analogous to I<sup>ˆ</sup> L ⊗ X<sup>ˆ</sup> L: Z<sup>ˆ</sup> L1 is a loop of Z<sup>ˆ</sup> phase-flips of the data qubits surrounding the Z-cut hole, and during the braid the wavefunction acquires byproduct operators. The loop however does not enclose the X-cut qubit 2 in a way that interacts with that qubit, so the braid does nothing to X-cut qubit 2. Hence we see that other than byproduct operators, Z<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L transforms to Z<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L. 

### Byproduct operators for two-qubit transformations 

When discussing the X<sup>ˆ</sup> L ⊗ I<sup>ˆ</sup> L → X<sup>ˆ</sup> L ⊗ X<sup>ˆ</sup> L transformation, we gave expressions for the powers pX1 and pX2 that determine whether there is a sign change associated with the final X<sup>ˆ</sup> L1X<sup>ˆ</sup> L2 operators that must be corrected with phase-flips Z<sup>ˆ</sup> L1 and Z<sup>ˆ</sup> L2. Braid transformations that result in Z<sup>ˆ</sup> L1 or Z<sup>ˆ</sup> L2 operators must similarly be corrected 

49 

for any unwanted sign changes in these operators, as determined in the usual way by the outcomes of the various stabilizer and single data qubit measurements involved in the braid transformation: If there is (is not) a sign change due to the braid transformation of the Z<sup>ˆ</sup> L1 operator, the power pZ1 = 1(0), while if there is (is not) a sign change due to the transformation of the Z<sup>ˆ</sup> L2 operator, the power pZ2 = 1(0). In either case, the transformed state wavefunction is modified by the byproduct operators X<sup>ˆ</sup> L<sup>pZ</sup> 1<sup>1</sup> and X<sup>ˆ</sup> L<sup>pZ</sup> 2<sup>2</sup> to indicate these sign changes. 

Combined with the byproduct operators Z<sup>ˆ</sup> L1 and Z<sup>ˆ</sup> L2, the final wavefunction |ψ<sup>′′</sup> ⟩ following a braid is given by 



### Appendix J: Logical Hadamard process 

The process for performing a logical Hadamard on a single logical qubit is detailed in Figs. 26, 27 and 28. The detailed sequence is as follows: 

1. We turn off a ring of X<sup>ˆ</sup> stabilizers surrounding both Z-cut holes of the logical qubit to be Hadamardtransformed, and also reduce the Z<sup>ˆ</sup> stabilizers on either side of the ring from four- to three- and twoterminal measurements, effectively isolating the target qubit in a patch of the 2D array. The unstabilized data qubits in the gap between the two Z boundaries are measured along Z<sup>ˆ</sup> , maintaining the surface code error tracking. This is shown in Fig. 27a. By comparing this figure to Fig. 26, it is apparent that the ring boundary comes very close to the logical qubits outside the ring, and it may seem that the proximity of these logical qubits reduces the array distance d to a small value; however, the internal Z boundary of the moat does not allow short undetectable error chains to reach the internal X boundaries of the Z-cut logical qubits outside the ring, so actually the distance d = 7 is preserved. If any qubits exterior to the ring were X-cut qubits, however, these would have to be kept a distance d from the ring. The same applies to the Z-cut qubit inside the ring; it is also protected by the internal Z boundary of the ring. 

2. We deform the Z<sup>ˆ</sup> L loop by multiplying it by all the ZˆL<sup>sstabilizers shown outline in Fig. 27b;this leaves</sup> us with the Z<sup>ˆ</sup> L chain of operators going from the left to the right boundary of the isolated 2D patch, shown as the horizontal solid line in Fig. 27b. 

3. We turn off, or reduce in terminal number, all the X<sup>ˆ</sup> and Z<sup>ˆ</sup> stabilizers inside the ring, creating a “moat”, leaving those within the dashed box in Fig. 27c; this leaves us with the smaller 2D patch shown in Fig. 27d, eliminating both qubit holes, with Z<sup>ˆ</sup> L still crossing from left to right, and X<sup>ˆ</sup> L now crossing 

from top to bottom. Note this 2D patch is now just a larger (d = 7) version of the d = 5 array qubit we discussed earlier (Fig. 3); the two X boundaries on top and bottom, and Z boundaries on left and right, make this a logical qubit with two degrees of freedom. The data qubits just beyond the two internal X boundaries of the moat are measured in X<sup>ˆ</sup> to preserve error tracking with the adjacent three-terminal X<sup>ˆ</sup> stabilizers still active on the inside boundary of the moat. 

4. We perform the key to this process, executing physical Hadamards on all the data qubits in the patch. As this changes the eigenbases from Z<sup>ˆ</sup> to X<sup>ˆ</sup> and vice versa, we change the identity of the measure qubits from X<sup>ˆ</sup> to Z<sup>ˆ</sup> stabilization and vice versa, as shown in Fig. 27e. Also, the X<sup>ˆ</sup> L and Z<sup>ˆ</sup> L logical operators swap their identities. This step, and the two that follow, are done in between two cycles of the surface code (so the measure-X and measureZ qubits do not perform any stabilization on the isolated patch during these three steps). 

5. The X<sup>ˆ</sup> and Z<sup>ˆ</sup> stabilizers in the patch are now misaligned with those in the larger 2D array. To correct this, we perform a data qubit-measure qubit swap, between each patch data qubit and the measure qubit directly above it. 

6. We perform a second swap, between each measure qubit and the patch data qubit to its left, as shown in Fig. 27f. The data qubits now hold the Hadamard-transformed logical state of the patch. The surface code cycle is re-started, with the measure qubits continuing to measure in X and Z as before the physical Hadamard, in alignment with the larger 2D array; the two swaps ensure that the Hadamard-transformed state in the 2D patch is consistent with this stabilization. 

7. Most of the X<sup>ˆ</sup> and Z<sup>ˆ</sup> stabilizers isolating the 2D patch from the 2D array are turned back on, reducing the width of the moat to a ring one data qubit wide, separating the patch from the 2D array, as we had in Fig. 27a. This is done in a way that creates two logical qubit holes in the patch as shown in Fig. 28g, with the two qubit holes positioned so that the X<sup>ˆ</sup> L operator chain terminates on the internal X boundaries of the two qubit holes. 

8. The Z<sup>ˆ</sup> L chain is deformed so it wraps tightly around the right qubit Z-cut hole, as shown in Fig. 28g. This is done by multiplying Z<sup>ˆ</sup> L by all the outlined Zˆ stabilizers. 

9. The left and right qubit holes are moved in the usual way around the patch, as shown in Fig. 28h partway through the move transformation, and in Fig. 28i, after the open cells have been re-stabilized, closing the move cut. The holes move must be split 

50 

into two steps to avoid reducing the distance d of logical qubit. We wait d surface code cycles to establish all stabilizer values in time. 

10. Each of the two Z-cut holes is moved one cell to return each to its original start point, as shown in Fig. 28j. 

11. The stabilizers isolating the patch from the 2D array are all turned back on, reunifying the patch with the array and completing the Hadamard transformation, after waiting d surface code cycles to establish the stabilizer values in time. 

### Appendix K: Short qubits 

Here we outline how to create and inject a state into a short X-cut qubit (the process for a short Z-cut qubit is completely analogous, simply exchanging the roles of X and Z). Figure 31 is in the main text. 

1. We start with a completely stabilized section of the 2D array, as in Fig. 31(a). 

2. We turn off the two X<sup>ˆ</sup> stabilizers X<sup>ˆ</sup> 1X<sup>ˆ</sup> 2X<sup>ˆ</sup> 3X<sup>ˆ</sup> 5 and Xˆ5Xˆ7Xˆ8Xˆ9, creating a pair of X-cut holes. These holes are separated by just one data qubit, qubit 5; this is the “short qubit”. 

   - During the same surface code cycle, we perform measurements of the two Zˆ stabilizers Zˆs1 = Zˆ2 ˆZ4 ˆZ5 ˆZ7 and Zˆs2 = Zˆ3 ˆZ5 ˆZ6 ˆZ7, and at the same time measure data qubit 5 along X<sup>ˆ</sup> , yielding the eigenvalue X5. Note that X<sup>ˆ</sup> 5 anti-commutes with the two Z<sup>ˆ</sup> stabilizers Z<sup>ˆ</sup> s1 and Z<sup>ˆ</sup> s2, so these three measurements cannot result in a simultaneous eigenstate of all three stabilizers. However, the operator formed by the product Zˆs1 ˆZs2 = Zˆ2 ˆZ3 ˆZ4 ˆZ6 ˆZ7 ˆZ8 commutes with Zˆs1, Zˆs2 and with Xˆ5, so the simultaneous measurements will select states that are eigenstates of Z<sup>ˆ</sup> s1Z<sup>ˆ</sup> s2 and X<sup>ˆ</sup> 5. The measurement outcome Zs1Zs2 will be equal to the product of Zs1 and Zs2 from the previous surface code cycle, with X5 = ±1. 

3. We have now created a short qubit that we can manipulate. We prepare the qubit, presently in a known eigenstate of X<sup>ˆ</sup> 5, by applying the appropriate rotation about the Z axis, using R<sup>ˆ</sup> Z(θ) (see Eq. 52)) to put the qubit in |gL⟩ + e<sup>iθ</sup> |eL⟩; the specific rotation will depend on whether the logical qubit was initialized in |+L⟩ (X5 = +1) or |−L⟩ (X5 = −1). If we are interested in injecting the |YL⟩ state, the angle θ = π/2, while for the |AL⟩ state we would use θ = π/4. 

4. The surface code stabilization sequence is now restarted, with the two X<sup>ˆ</sup> stabilizers left idle. The two holes of the qubit can now be separated and enlarged to better protect against errors. The state 

in the qubit can now be purified in a distillation process, prior to its use in an S<sup>ˆ</sup> L or T<sup>ˆ</sup> L gate. 

### Appendix L: S<sup>ˆ</sup> L and T<sup>ˆ</sup> L distillation sub-circuits 

In this Appendix, we look explicitly at some of the operations used in the |YL⟩ and |AL⟩ distillation circuits, focussing on the terminal S<sup>ˆ</sup> L and T<sup>ˆ</sup> L<sup>†gatesrespectively,</sup> followed the measurement MX , i.e. the last two steps for each ancilla qubit’s distillation in Figs. 32 and 33. The S<sup>ˆ</sup> L gate as shown in Fig. 29 is deterministic, but to provide a parallel discussion to the analysis of the |AL⟩ distillation, we instead use the circuit in Fig. 30, replacing the |AL⟩ ancilla state in that circuit with |YL⟩. Using |YL⟩, this circuit will execute S<sup>ˆ</sup> L, although only about half the time, as using this non-deterministic circuit the output states need to be corrected the other half of the time, just as for the T<sup>ˆ</sup> L gate. 

Figure 35 shows the corresponding sub-circuits, along with equivalent circuits that include the conditional measurements. As all states and operations will be logical in this appendix, we will drop the L subscript for compactness. 

We first consider Fig. 35a, which implements the S<sup>ˆ</sup> gate. For the state going into the MX<sup>′measurement,the</sup> CNOT followed by the MZ<sup>′measurementgives|ψ′⟩=</sup> Sˆ|ψ⟩ for MZ<sup>′= +1,and|ψ′⟩=Xˆ ˆZ ˆS|ψ⟩forM</sup> Z<sup>′= −1.</sup> The result of the subsequent MX<sup>′measurement is then</sup> given by 





<!-- Start of picture text -->
’<br>(a)<br>Y MX’<br>S MX<br>MZ’<br>(b)<br>A S MX’<br>T † MX<br>MZ’<br><!-- End of picture text -->

FIG. 35. (Color online) (a) Left panel shows original portion of the |Y<sup>ˆ</sup> ⟩ distillation circuit, involving the S<sup>ˆ</sup> gate followed by measurement MX , whereas right panel shows the expanded Sˆ circuit displaying the logical CNOT and measurements MZ<sup>′</sup> and MX<sup>′.(b)Sameas(a)butforaportionofthe|A⟩distil-</sup> lation circuit, involving the T<sup>ˆ†</sup> gate. A conditional S<sup>ˆ</sup> gate is applied to the upper qubit if MZ<sup>′= +1.</sup> 

51 

|Input||Y ⟩|ˆZ|Y ⟩= |Y <sup>⋆</sup>⟩|ˆ<br>X|Y ⟩=i|Y <sup>⋆</sup>⟩|ˆY |Y ⟩=−i|Y ⟩|ˆXˆT <sup>†</sup>|ψ⟩. The result of the M <sup>′</sup><br>X <sup>measurement is thus</sup>|
|---|---|---|---|---|---|
|θ|π/2|−π/2|−π/2|π/2||
|M <sup>′</sup><br>Z <sup>=</sup><br>+1|M <sup>′</sup><br>X<sup>[ˆS]</sup>|M <sup>′</sup><br>X<sup>[ˆZ ˆS]</sup><br>=−M <sup>′</sup><br>X<sup>[ ˆS]</sup>|M <sup>′</sup><br>X<sup>[ˆZ ˆS]</sup><br>=−M <sup>′</sup><br>X<sup>[ ˆS]</sup>|M <sup>′</sup><br>X<sup>[ˆS]</sup>|M <sup>′</sup><br>X <sup>= MX[ ˆS ˆT|ψ⟩]</sup><br>(for M <sup>′</sup><br>Z <sup>= +1)</sup><br> <sup>ˆˆ</sup> <sup>†</sup>|
|M <sup>′</sup><br>Z <sup>=</sup>|M <sup>′</sup><br>X<sup>[ˆ</sup><br>X <sup>ˆ</sup>Z <sup>ˆ</sup>S]|M <sup>′</sup><br>X<sup>[ˆ</sup><br>X <sup>ˆ</sup>S]|M <sup>′</sup><br>X<sup>[ˆ</sup><br>X <sup>ˆ</sup>S]|M <sup>′</sup><br>X<sup>[ˆ</sup><br>X <sup>ˆ</sup>Z <sup>ˆ</sup>S]|= MX[Z T |ψ⟩]|
|−1|=−M <sup>′</sup><br>X<sup>[ ˆS]</sup>|= +M <sup>′</sup><br>X<sup>[ ˆS]</sup>|= +M <sup>′</sup><br>X<sup>[ ˆS]</sup>|=−M <sup>′</sup><br>X<sup>[ ˆS]</sup>|= −MX[<sup>ˆ</sup>T <sup>†</sup>|ψ⟩], and<br>|





TABLE VI. Table of measurement outcomes for the S<sup>ˆ</sup> operation and MZ<sup>′andM ′</sup> X<sup>measurement.Forcompactness,the</sup> state |ψ⟩ has been dropped from inside the MX<sup>′measurement</sup> brackets. The second row shows the angle θ for the input state |g⟩ + exp(iθ)|e⟩ after application of Z<sup>ˆ</sup> , X<sup>ˆ</sup> , or Y<sup>ˆ</sup> errors to the state |Y ⟩. 

Hence we find for the T<sup>ˆ†</sup> circuit 



For a general ancilla state |g⟩ + e<sup>iθ</sup> |e⟩, passing the input state |ψ⟩ = α|g⟩ + β|e⟩ to the T<sup>ˆ†</sup> circuit generates two outcomes depending on the MZ<sup>′measurement.For</sup> MZ<sup>′= +1,Sˆis applied and the result α|g⟩+βei(θ−π/2)|e⟩</sup> is passed to the MX<sup>′measurement.For the M</sup> Z<sup>′= −1 out-</sup> come, the conditional S<sup>ˆ</sup> is not applied, and instead the result β|g⟩ + αe<sup>iθ</sup> |e⟩ = e<sup>iθ</sup> X<sup>ˆ</sup> (α|g⟩ + βe<sup>−iθ</sup> |e⟩) is passed to the MX<sup>′measurement.Inthelattercasethephase</sup> factor and the X<sup>ˆ</sup> do not affect the measurement, so the MX<sup>′measurementisperformedonα|g⟩+ βe−iθ|e⟩.For</sup> the |A⟩ ancilla with θ = π/4, the two states sent to the measurement are identical, as per (L3). Errors on the |A⟩ ancilla however change the angle. For a Z<sup>ˆ</sup> error the ancilla angle changes to θ = −3π/4, for X<sup>ˆ</sup> it becomes e<sup>iπ/4</sup> |A<sup>⋆</sup> ⟩, equivalent to θ = −π/4, and for Y<sup>ˆ</sup> the angle is θ = 3π/4. 

using MX [ X<sup>ˆ</sup> |ψ⟩] = MX [|ψ⟩] and MX [ Z<sup>ˆ</sup> |ψ⟩] = −MX [|ψ⟩]. Hence when the circuit fails to generate S<sup>ˆ</sup> and instead generates X<sup>ˆ</sup> Z<sup>ˆ</sup> S<sup>ˆ</sup> , the final measurement acquires a minus sign. This result is summarized in the |Y ⟩ column of Table VI. From these equations, it is easy to see that the net result for the desired MX measurement is equal to the product of the two sub-measurements 



As the goal of distillation is to reduce errors in |Y ⟩, we next consider the effect of errors on the input |Y ⟩ ancilla state, and how these affect the output measurement. These errors can be modeled as probabilistic applications of Xˆ , Yˆ , or Zˆ to the |Y ⟩ state, which give Z<sup>ˆ</sup> |Y ⟩ = |Y<sup>⋆</sup> ⟩ = |g⟩− i|e⟩, Xˆ |Y ⟩ = i|Y<sup>⋆</sup> ⟩ and Yˆ |Y ⟩ = −i|Y ⟩, where ±i represents an overall phase factor that can be dropped. With a general input state given by |g⟩ + exp(iθ)|e⟩, the |Y ⟩ (|Y<sup>⋆</sup> ⟩) state corresponds to θ = π/2 (θ = −π/2). When we have the erroneous input |Y<sup>⋆</sup> ⟩ state, i.e. θ = −π/2, the MZ<sup>′=+1measurement</sup> outcome feeds the state S<sup>ˆ†</sup> |ψ⟩ = Z<sup>ˆ</sup> S<sup>ˆ</sup> |ψ⟩ to the measurement MX<sup>′,whileM</sup> Z<sup>′=−1feedsthestateXˆ ˆS|ψ⟩to</sup> the measurement. Table VI lists the MX<sup>′measurement</sup> results for both MZ<sup>′outcomesandallerrortypes,and</sup> shows that the measurement result MX is reversed in sign for Z<sup>ˆ</sup> and X<sup>ˆ</sup> errors, signalling the error in the distillation process. Although Y<sup>ˆ</sup> errors are undetectable (the overall phase factor cannot be measured), the distillation is not affected since this error produces no significant change to the input state Y<sup>ˆ</sup> |Y ⟩ = −i|Y ⟩. All errors are thus described by X<sup>ˆ</sup> or Z<sup>ˆ</sup> operations and are successfully and directly detected by the circuit. 

The results for the correct |A⟩, as well as for Z<sup>ˆ</sup> , X<sup>ˆ</sup> , and Y<sup>ˆ</sup> errors to the ancilla, are listed in Table VII. To calculate some of these entries, we used the identity 



A measurement MX<sup>′ofTˆ|ψ⟩thus yields the same as M</sup> X<sup>′</sup> on T<sup>ˆ†</sup> |ψ⟩ about half the time (meaning things worked out), while it yields −MX<sup>′theotherhalfofthetime</sup> (meaning we throw the result away). We see from Table VII that whenever an error in the |A⟩ state generates the incorrect output, it is signalled by a sign change in the measurement MX<sup>′,sothatstatewouldbethrown</sup> away. 

For the T<sup>ˆ†</sup> circuit in Fig. 35b, the measurement outcome MZ<sup>′=+1indicatesthecircuitproducedTˆ|ψ⟩,</sup> which is corrected by applying S<sup>ˆ</sup> , using the identity Sˆ ˆT = Zˆ ˆT<sup>†</sup> , the desired result accompanied by a byproduct Z<sup>ˆ</sup> L operator. For MZ<sup>′=−1,thecircuitproduces</sup> 

When computing the effect of errors on the input state |A⟩, simulations of the (error-free) logic circuit show that the T<sup>ˆ†</sup> circuit with the expected Reed code stabilizer outcomes produces a perfect output when zero, one or two ancilla states have X<sup>ˆ</sup> , Z<sup>ˆ</sup> or Y<sup>ˆ</sup> errors, but when three or more ancilla states have errors, the output is purified with a probability scaling as the error rate p<sup>3</sup> ; statistical arguments indicate that the error rate should be 35p<sup>3</sup> as above. The rate at which the distillation circuit fails is 1 − 15p. 

52 

### Appendix M: Estimating the time and size of a factoring circuit 

We provide here a few more details on the surface code quantum computer size and execution time that are needed to factor a N = 2000 bit number into its primes. 

We use the general Shor circuit as described in Ref. [35], using the addition circuit described in Ref. [37]. The most resource-intensive part of Shor’s algorithm is the modular exponentiation circuit, which is the backbone of the factoring algorithm; in this implementation, modular exponentiation involves 40N<sup>3</sup> sequential Toffoli gates, where each Toffoli gate uses a total of seven T<sup>ˆ</sup> L non-Clifford gates, using three in parallel, then one, then three in parallel again. The T<sup>ˆ</sup> L gate sequence is essentially incompressible, and is the most resource-intensive part of the modular exponentiation circuit, because each TˆL gate uses up one highly-distilled |AL⟩ ancilla state. 

A highly time-optimized version of the T<sup>ˆ</sup> L circuit from Ref. [41] indicates that each T<sup>ˆ</sup> L gate can be completed in one measurement time tM , a fraction of the surface code cycle time, so each Toffoli gate requires a time 3tM to complete. The total time for the exponentiation circuit is thus 120N<sup>3</sup> tM . With a target measurement time of tM = 100 ns (see Sect. XVII), this implies 26.7 hours to factor a N = 2000 bit number. The remainder of the surface code must be designed to supply this circuit with sufficient resources to allow execution in this time. 

Each of the TˆL gates consumes one ancilla |AL⟩ state, so in total the exponentiation circuit consumes 7 × 40N<sup>3</sup> = 280N<sup>3</sup> ≈ 2 × 10<sup>12</sup> |AL⟩ states. These states must be generated at a rate sufficient to keep pace with the exponentiation circuit, and generated with a logical error rate sufficiently small that the exponentiation circuit makes a negligible number of errors; we would like the rate of errors in the final |AL⟩ states to be much less than PA = (280N<sup>3</sup> )<sup>−1</sup> ≈ 4 × 10<sup>−13</sup> to ensure good fidelity. 

With a state injection error rate pI = 0.005 (meaning 

|Input||A⟩|ˆZ|A⟩|ˆ<br>X|A⟩|ˆY |A⟩|
|---|---|---|---|---|
|θ|π/4|−3π/4|−π/4|3π/4|
|M <sup>′</sup><br>Z <sup>=</sup><br>+1|M <sup>′</sup><br>X<sup>[ˆS ˆT]</sup><br>=−M <sup>′</sup><br>X<sup>[ ˆT †]</sup>|M <sup>′</sup><br>X<sup>[ˆS ˆS†</sup> <sup>ˆT †]</sup><br>= +M <sup>′</sup><br>X<sup>[ ˆT †]</sup>|M <sup>′</sup><br>X<sup>[ˆS ˆT †]</sup><br>=M <sup>′</sup><br>X<sup>[ ˆT]</sup><br>=−M <sup>′</sup><br>X<sup>[ ˆT †]</sup><br>∨+M <sup>′</sup><br>X<sup>[ ˆT †]</sup>|M <sup>′</sup><br>X<sup>[ˆS ˆS ˆT]</sup><br>=−M <sup>′</sup><br>X<sup>[ ˆT]</sup><br>= +M <sup>′</sup><br>X<sup>[ ˆT †]</sup><br>∨−M <sup>′</sup><br>X<sup>[ ˆT †]</sup>|
|M <sup>′</sup><br>Z <sup>=</sup><br>−1|M <sup>′</sup><br>X<sup>[ˆ</sup><br>X <sup>ˆ</sup>T <sup>†</sup>]<br>= +M <sup>′</sup><br>X<sup>[ ˆT †]</sup>|M <sup>′</sup><br>X<sup>[ˆ</sup><br>X <sup>ˆ</sup>S <sup>ˆ</sup>T]<br>=−M <sup>′</sup><br>X<sup>[ ˆT †]</sup>|M <sup>′</sup><br>X<sup>[ˆ</sup><br>X <sup>ˆ</sup>T]<br>=M <sup>′</sup><br>X<sup>[ ˆT]</sup><br>= +M <sup>′</sup><br>X<sup>[ ˆT †]</sup><br>∨−M <sup>′</sup><br>X<sup>[ ˆT †]</sup>|M <sup>′</sup><br>X<sup>[ˆ</sup><br>X <sup>ˆ</sup>S<sup>†</sup> <sup>ˆ</sup>T <sup>†</sup>]<br>=−M <sup>′</sup><br>X<sup>[ ˆT]</sup><br>=−M <sup>′</sup><br>X<sup>[ ˆT †]</sup><br>∨+M <sup>′</sup><br>X<sup>[ ˆT †]</sup>|



TABLE VII. Table of measurement outcomes for the T<sup>ˆ</sup> operation and MZ<sup>′andM ′</sup> X<sup>measurements.Columnsshowideal</sup> input state |A⟩ and after application of Z<sup>ˆ</sup> , X<sup>ˆ</sup> , or Y<sup>ˆ</sup> errors. Entries with ∨ (“or”) yield one entry or the other, so approximately half the time succeed and the other half fail. 

a 0.5% error rate in the |AL⟩ states injected in short qubits), the first stage of distillation will yield |AL⟩ states with an error rate p1 = 35p<sup>3</sup> I<sup>≈4 × 10−6,assumingthe</sup> distillation circuit is error-free; the second stage will yield states with an error rate p2 = 35p<sup>3</sup> 1<sup>≈3 × 10−15.Asthis</sup> error rate is below the target rate PA for errors in the |AL⟩ state, two stages of distillation are sufficient with this injection error rate. 

The distillation circuits are of course not flawless; given a per-surface code step physical qubit error rate of p = 10<sup>−3</sup> , we must find the surface code distance d that yields a sufficiently low logical error rate. The second and last stage of distillation for an |AL⟩ state takes 16 logical qubits (15 ancillae plus one logical qubit for the Bell pair) and is executed in 8 × 1.25 × d2 surface code cycles, including the various CNOTs in a compressed format and sufficient distance d2 in time, as we perform this distillation with a surface code distance d2. The prior (first) stage of distillation requires more logical qubits, using 15 × 16 logical qubits (15 sets of distillation circuits, each with 16 logical qubits), operated with a surface code distance d1 in 10d1 surface code cycles. We want to reduce the distance d in the first stage of distillation over that in the second stage, as this reduces the required surface code footprint; the distance reduction will concomitantly increase the logical error rate over that of the following stage, but these errors will be distilled out. 

For the second and final stage of distillation, an error rate PL2 per surface code cycle with a distance d2 surface code will yield an |AL⟩ error rate of about 16 × 2 × 3 × 1.25d2 × PL2 = 120d2PL2 (16 logical qubits, 2 types of logical qubits, multiplier of 3 kinds of error chains, and 5d2/4 surface code cycles). We need d2 sufficient to keep this error rate below PA. With an error rate p = 10<sup>−3</sup> , a distance d2 = 34 code yields PL2 ≈ 3 × 10<sup>−19</sup> , with 120d2PL ≈ 1 × 10<sup>−15</sup> < PA, just below the target error rate. For the first stage of distillation, a logical error rate PL1 with a distance d1 surface code will generate states with an error rate 15 × 16 × 2 × 3 × 1.25d1 × PL1 = 1800d1PL1. This rate can be higher than PA as we distill the output, so we actually only need 35(1800d1PL1)<sup>3</sup> < PA. A distance d1 = 17 code will give PL1 ≈ 1 × 10<sup>−10</sup> , so |AL⟩ states will be output with an error rate of about 3 × 10<sup>−6</sup> . The following distillation stage will reduce this to 1 × 10<sup>−15</sup> , again just below the target rate. 

The first stage of distillation occupies the largest footprint in the surface code, since to generate one final purified |AL⟩ state we need 16 × 15 = 240 logical qubits. In a distance d1 = 17 code, a logical qubit takes 2.5 × 1.25 × (2d1)<sup>2</sup> ≈ 3600 physical qubits. Hence the first stage of distillation will take 240×3600 ≈ 8×10<sup>5</sup> physical qubits, with the distillation taking 10d1 = 170 surface code cycles. The second and final stage uses a d2 = 34 code, so one logical qubit takes 2.5×1.25×(2d2)<sup>2</sup> ≈ 14500 physical qubits. The distillation then takes 16 × 14500 ≈ 2.4 × 10<sup>5</sup> physical qubits and about 340 surface code cycles. The surface code footprint occupied by the first stage can be re-used in the second stages, so in total about 800,000 

53 

physical qubits are required to generate a sufficiently purified |AL⟩ state, which takes about 500 surface code cycles. The surface code footprint used to generate this one state is active in a volume comprising a square pyramid in space-time, with a large base for the first stage of distillation, reduced by a factor of about three in the subsequent stage. The total space-time volume of the two stages is 170 × 8 × 10<sup>5</sup> + 340 × 2.4 × 10<sup>5</sup> ∼ 2.2 × 10<sup>8</sup> . The space-time volume available when using the full footprint for the full duration is 500 × 8 × 10<sup>5</sup> ∼ 4 × 10<sup>8</sup> . The full footprint can thus be used to generate approximately two |AL⟩ states in the same number of surface code cycles, forming what we call the “AA factory”. 

Each surface code cycle involves single physical qubit resets and gates, physical qubit CNOTs, and readout of the measure qubits; as discussed in Sect. XVII, we believe a 200 ns time for this cycle is not unreasonable, limited mostly by the measurement time tM , which we take as 100 ns, but also in part by microwave technology as well as by classical processing speeds. Hence an AA factory can produce two |AL⟩ states every 500 × 200 ns ≈ 100 µs, and can generate 2×10<sup>9</sup> states in the 26.7 hour factoring time. The 280N<sup>3</sup> ≈ 2.2 × 10<sup>12</sup> required |AL⟩ states translates to then needing about 1200 AA factories working in parallel, and thus 1200 × 8 × 10<sup>5</sup> ≈ 10<sup>9</sup> physical qubits. The remainder of Shor’s algorithm requires about 2N = 4000 logical qubits, which in a d2 = 34 dis- 

- [1] N. D. Mermin, Quantum Computer Science: An Introduction (Cambridge University Press, 2007). 

- [2] M. A. Nielsen and I. L. Chuang, Quantum Computation and Quantum Information (Cambridge University Press, 2000). 

- [3] P. W. Shor, in Algorithmic Number Theory: First International Symposium ANTS-I (1994) p. 289. 

- [4] L. K. Grover, Phys. Rev. Lett. 79, 325 (1997). 

- [5] L. K. Grover, in Proc. 28th Annual ACM Symposium on the Theory of Computing (STOC) (1996) pp. 212–219. 

- [6] T. D. Ladd, F. Jelezko, R. Laflamme, Y. Nakamura, C. Monroe, and J. L. O’Brien, Nature 464, 45 (2010), arXiv:1009.2267. 

- [7] I. Buluta, S. Ashhab, and F. Nori, Rep. Prog. Phys. 74, 104401 (2011), arXiv:1002.1871. 

- [8] S. B. Bravyi and A. Y. Kitaev, “Quantum codes on a lattice with boundary,” (1998), arXiv:quant-ph/9811052, http://arxiv.org/abs/quant-ph/9811052. 

- [9] E. Dennis, A. Y. Kitaev, A. Landahl, and J. Preskill, J. Math. Phys. 43, 4452 (2002), http://arxiv.org/abs/ quant-ph/0110143. 

- [10] D. Gottesman, Stabilizer Codes and Quantum Error Correction, Ph.D. thesis, Caltech (May 1997), arXiv:quantph/9705052. 

- [11] A. Y. Kitaev, “Quantum communication, computing and measurement,” (Plenum Publishing Corporation, 1997) Chap. Quantum error correction with imperfect gates. 

- [12] A. Y. Kitaev, Russian Math Surveys 52, 1191 (1997). 

- [13] A. Y. Kitaev, “Fault-tolerant quantum computation by anyons,” (1997), arXiv:quant-ph/9707021. 

tance surface code takes about 4000 × 14500 ≈ 5.6 × 10<sup>7</sup> additional physical qubits, adding a fairly negligible 6% to the AA factory footprint, for a total of about a billion physical qubits. 

Improving the performance of the surface code can reduce these numbers somewhat. Eliminating the first stage of |AL⟩ distillation (so we only did one round of distillation) would require a state injection error rate pI `≲` (PA/35)<sup>1/3</sup> ≈ 2 × 10<sup>−5</sup> , which is probably not realizable. Improving the physical qubit error rate by a factor of ten, to p = 10<sup>−4</sup> , would reduce the distance d at the top level, allowing a d2 = 16 top-level surface code, with PL2 ≈ 3 × 10<sup>−19</sup> . The first stage of distillation with 240 logical qubits could be run using a d1 = 8 code with PL1 ≈ 3 × 10<sup>−15</sup> , with an output error rate of ≈ 4 × 10<sup>−11</sup> . The total footprint for a AA factory would then be 240 × 2.5 × 1.25 × (2d1)<sup>2</sup> ≈ 2 × 10<sup>5</sup> physical qubits, and would produce |AL⟩ states at twice the rate due to the reduction in the code distance, so only half the number of factories would be needed, for a total of about 120 million physical qubits. The 2N = 4000 computational qubits in a d2 = 16 surface code would take 4000×3200 ≈ 12 million qubits. The overall surface code could thus be implemented with about 130 million physical qubits, albeit with no change in the overall execution time. 

- [14] A. Y. Kitaev, Annals of Physics 303, 2 (2003), http: //arxiv.org/abs/quant-ph/9707021. 

- [15] M. H. Freedman and D. A. Meyer, Foundations of Computational Mathematics 1, 325 (2001), http://arxiv. org/abs/quant-ph/9810055. 

- [16] C. Wang, J. Harrington, and J. Preskill, Annals of Physics 303, 31 (2003), http://arxiv.org/abs/ quant-ph/0207088. 

- [17] R. Raussendorf, J. Harrington, and K. Goyal, Annals of Physics 321, 2242 (2006), http://arxiv.org/abs/ quant-ph/0510135. 

- [18] R. Raussendorf and J. Harrington, Phys. Rev. Lett. 98, 190504 (2007), http://arxiv.org/abs/quant-ph/ 0610082. 

- [19] R. Raussendorf, J. Harrington, and K. Goyal, New Journal of Physics 9, 199 (2007), http://arxiv.org/abs/ quant-ph/0703143. 

- [20] A. G. Fowler, A. M. Stephens, and P. Groszkowski, Phys. Rev. A 80, 052312 (2009), http://arxiv.org/ abs/0803.0272. 

- [21] A. G. Fowler, D. S. Wang, and L. C. L. Hollenberg, Quant. Info. Comput. 11, 8 (2011), arXiv:quantph/1004.0255. 

- [22] D. S. Wang, A. G. Fowler, and L. C. L. Hollenberg, Phys. Rev. A 83, 020302(R) (2011), arXiv:quant-ph/1009.3686. 

- [23] A. G. Fowler, A. C. Whiteside, and L. C. L. Hollenberg, Phys. Rev. Lett. 108, 180501 (2012), arXiv:1110.5133. 

- [24] G. Duclos-Cianci and D. Poulin, Physical Review Letters 104, 050504 (Feb. 2010), arXiv:quant-ph/0911.0581. 

- [25] G. Duclos-Cianci and D. Poulin, “A renormalization 

54 

   - group decoding algorithm for topological quantum codes,” (Jun. 2010), arXiv:quant-ph/1006.1362. 

- [26] H. Bombin, R. S. Andrist, M. Ohzeki, H. G. Katzgraber, and M. A. Martin-Delgado, “Strong resilience of topological codes to depolarization,” (Feb. 2012), arXiv:quantph/1202.1852. 

- [27] J. R. Wootton and D. Loss, “High threshold error correction for the surface code,” (Feb. 2012), arXiv:quantph/1202.4316. 

- [28] A. G. Fowler, A. C. Whiteside, A. L. McInnes, and A. Rabbani, “Topological code Autotune,” (Feb. 2012), arXiv:quant-ph/1202.6111. 

- [29] D. S. Wang, A. G. Fowler, C. D. Hill, and L. C. L. Hollenberg, Quant. Info. Comp. 10, 780 (2010), arXiv:0907.1708. 

- [30] H. Bombin, G. Duclos-Cianci, and D. Poulin, “Universal topological phase of 2D stabilizer codes,” (Mar. 2011), arXiv:quant-ph/1103.4606. 

- [31] A. J. Landahl, J. T. Anderson, and P. R. Rice, “Faulttolerant quantum computing with color codes,” (Aug. 2011), arXiv:quant-ph/1108.5738. 

- [32] P. Sarvepalli and R. Raussendorf, “Efficient Decoding of Topological Color Codes,” (Nov. 2011), arXiv:quantph/1111.0831. 

- [33] K. M. Svore, D. P. DiVincenzo, and B. M. Terhal, Quantum Inf. Comput. 7, 297 (2007). 

- [34] F. M. Spedalieri and V. P. Roychowdhury, Quantum Information & Computation 9, 666 (2009). 

- [35] V. Vedral, A. Barenco, and A. Ekert, Phys. Rev. A 54, 147 (Jul 1996), http://link.aps.org/doi/10.1103/ PhysRevA.54.147. 

- [36] S. Beauregard, “Circuit for Shor’s algorithm using 2n+3 qubits,” (May 2002), arXiv:quant-ph/0205095. 

- [37] S. A. Cuccaro, T. G. Draper, S. A. Kutin, and D. P. Moulton, “A new quantum ripply-carry addition circuit,” (2004), arXiv:quant-ph/0410184. 

- [38] C. Zalka, “Fast versions of Shor’s quantum factoring algorithm,” (Jun. 1998), arXiv:quant-ph/9806084. 

- [39] R. Van Meter, K. M. Itoh, and T. D. Ladd, “Architecture-Dependent Execution Time of Shor’s Algorithm,” (Jul. 2005), arXiv:quant-ph/0507023. 

- [40] A. Y. Kitaev, A. H. Shen, and M. N. Vyalyi, Classical and Quantum Computation (American Mathematical Society, Providence, RI, 2002). 

- [41] A. G. Fowler(2012), unpublished. 

- [42] P. W. Shor, Phys. Rev. A 52, 2493 (1995). 

- [43] J. Edmonds, Canad. J. Math. 17, 449 (1965). 

- [44] J. Edmonds, J. Res. Nat. Bur. Standards 69B, 125 (1965). 

logical codes,” (2012), arXiv:quant-ph/1208.1334. 

   - [46] A. G. Fowler and S. J. Devitt, arXiv:1209.0510(2012). 

   - [47] D. Gottesman, “The Heisenberg representation of quantum computers,” (2008), arXiv:quant-ph/9807006. 

   - [48] J. J. Sakurai, Modern Quantum Mechanics (Addison Wesley, 1994). 

   - [49] A. G. Fowler, “Low-overhead surface code logical H,” (2012), arXiv:quant-ph/1202.2369. 

   - [50] A. M. Steane, Proc. R. Soc. Lond. A 452, 2551 (1996), quant-ph/9601029. 

   - [51] S. Bravyi and A. Kitaev, Phys. Rev. A 71, 022316 (Feb 2005), http://link.aps.org/doi/10.1103/PhysRevA. 71.022316. 

   - [52] I. Bloch, J. Dalibard, and W. Zwerger, Rev. Mod. Phys. 80, 885 (2008). 

   - [53] I. Bloch, J. Dalibard, and S. Nascimbene, Nature Physics 8, 267 (2012). 

   - [54] D. Leibfried, R. Blatt, C. Monroe, and D. J. Wineland, Rev. Mod. Phys. 75, 281 (2003). 

   - [55] R. Blatt and D. Wineland, Nature 453, 1008 (2008). 

   - [56] D. Kielpinski, C. R. Monroe, and D. J. Wineland, Nature 417, 709 (2002). 

   - [57] M. A. Eriksson, M. Friesen, S. N. Coppersmith, R. Joynt, L. J. Klein, K. Slinker, C. Tahan, P. M. Mooney, J. O. Chu, and S. J. Koester, Quantum Information Processing 3, 133 (2004). 

   - [58] Y. Makhlin, G. Sch¨on, and A. Shnirman, Rev. Mod. Phys. 73, 357 (2001). 

   - [59] M. H. Devoret and J. M. Martinis, Quantum Inf. Process. 3, 163 (2004). 

   - [60] J. Q. You and F. Nori, Physics Today 58, 42 (2005). 

   - [61] J. Clarke and F. K. Wilhelm, Nature 453, 1031 (2008). 

   - [62] R. J. Schoelkopf and S. M. Girvin, Nature 451, 664 (2008). 

   - [63] D. P. DiVincenzo, Phys. Scr. T137, 014020 (2009). 

   - [64] H. Paik, D. I. Schuster, L. S. Bishop, G. Kirchmair, G. Catelani, A. P. Sears, B. R. Johnson, M. J. Reagor, L. Frunzio, L. I. Glazman, S. M. Girvin, M. H. Devoret, and R. J. Schoelkopf, Phys. Rev. Lett. 107, 240501 (Dec 2011), http://link.aps.org/doi/10. 1103/PhysRevLett.107.240501. 

   - [65] M. Mariantoni, H. Wang, T. Yamamoto, M. Neeley, R. C. Bialczak, Y. Chen, M. Lenander, E. Lucero, A. D. O’Connell, D. Sank, M. Weides, J. Wenner, Y. Yin, J. Zhao, A. N. Korotkov, A. N. Cleland, and J. M. Martinis, Science 334, 61 (2011). 

   - [66] R. Raussendorf, D. E. Browne, and H. J. Briegel, Phys. Rev. A 68, 022312 (Aug 2003), http://link.aps.org/ doi/10.1103/PhysRevA.68.022312. 

- [45] A. G. Fowler, “Analytic asymptotic performance of topo-
