<!-- fulltext source=arxiv_html slug=arXiv-1105.1186 fetched=2026-09-21T06:51:50+00:00 -->

# Sampling-based Algorithms for Optimal Motion Planning

Sertac Karaman
  
Emilio Frazzoli
††thanks: The authors are with the Laboratory for
Information and Decision Systems, Massachusetts Institute of Technology, Cambridge,
MA.

###### Abstract

During the last decade, sampling-based path planning algorithms, such as Probabilistic RoadMaps (PRM) and Rapidly-exploring Random Trees (RRT), have been shown to work well in practice and possess theoretical guarantees such as probabilistic completeness. However, little effort has been devoted to the formal analysis of the quality of the solution returned by such algorithms, e.g., as a function of the number of samples. The purpose of this paper is to fill this gap, by rigorously analyzing the asymptotic behavior of the cost of the solution returned by stochastic sampling-based algorithms as the number of samples increases. A number of negative results are provided, characterizing existing algorithms, e.g., showing that, under mild technical conditions, the cost of the solution returned by broadly used sampling-based algorithms converges almost surely to a non-optimal value. The main contribution of the paper is the introduction of new algorithms, namely, PRM∗ and RRT∗, which are provably asymptotically optimal, i.e., such that the cost of the returned solution converges almost surely to the optimum. Moreover, it is shown that the computational complexity of the new algorithms is within a constant factor of that of their probabilistically complete (but not asymptotically optimal) counterparts. The analysis in this paper hinges on novel connections between stochastic sampling-based path planning algorithms and the theory of random geometric graphs.

Keywords: Motion planning, optimal path planning, sampling-based algorithms, random geometric graphs.

## 1 Introduction

The robotic motion planning problem has received a considerable amount of attention, especially over the last decade, as robots started becoming a vital part of modern industry as well as our daily life ([Latombe, 1991](#bib.bib60); [LaValle, 2006](#bib.bib62); [Choset et al., 2005](#bib.bib25)). Even though modern robots may possess significant differences in sensing, actuation, size,
workspace, application, etc., the problem of navigating through a complex environment is embedded
and essential in almost all robotics applications. Moreover, this problem is relevant to
other disciplines such as verification, computational biology, and computer
animation ([Latombe, 1999](#bib.bib61); [Bhatia and Frazzoli, 2004](#bib.bib13); [Branicky et al., 2006](#bib.bib18); [Cortes et al., 2007](#bib.bib26); [Liu and Badler, 2003](#bib.bib72); [Finn and Kavraki, 1999](#bib.bib32)).

Informally speaking, given a robot with a description of its dynamics, a description of the
environment, an initial state, and a set of goal states, the motion planning problem is to
find a sequence of control inputs so as the drive the robot from its initial state to one of
the goal states while obeying the rules of the environment, e.g., not colliding with the
surrounding obstacles. An algorithm to address this problem is said to be complete
if it terminates in finite time, returning a valid solution if one exists, and failure otherwise.

Unfortunately, the problem is known to be very hard from the computational point of view.
For example, a basic version of the motion planning problem, called the generalized piano movers problem, is PSPACE-hard ([Reif, 1979](#bib.bib84)). In fact, while complete planning algorithms exist ([Lozano-Perez and Wesley, 1979](#bib.bib73); [Schwartz and Sharir, 1983](#bib.bib92); [Canny, 1988](#bib.bib22), see, e.g.,), their complexity makes them unsuitable for practical applications.

Practical planners came around with the development of cell decomposition methods ([Brooks and Lozano-Perez, 1983](#bib.bib19)) and potential fields ([Khatib, 1986](#bib.bib53)). These approaches, if properly implemented, relaxed the completeness requirement to, for instance, resolution completeness, i.e., the ability to return a valid solution, if one exists, if the resolution parameter of the algorithm is set fine enough. These planners demonstrated remarkable performance in accomplishing various tasks in complex environments within reasonable time bounds ([Ge and Cui, 2002](#bib.bib34)). However, their practical applications were mostly limited to state spaces with up to five dimensions, since decomposition-based methods suffered from large number of cells, and potential field methods from local minima ([Koren and Borenstein, 1991](#bib.bib54)). Important contributions towards broader applicability of these methods include navigation functions ([Rimon and Koditschek, 1992](#bib.bib86)) and randomization ([Barraquand and Latombe, 1993](#bib.bib9)).

The above methods rely on an explicit representation of the obstacles in the configuration space, which is used directly to construct a solution. This may result in an excessive computational burden in high dimensions, and in environments described by a large number of obstacles. Avoiding such a representation is the main underlying idea leading to the development of sampling-based algorithms ([Kavraki and Latombe, 1994](#bib.bib50); [Kavraki et al., 1996](#bib.bib51); [LaValle and Kuffner, 2001](#bib.bib63)). See  [Lindemann and LaValle (2005)](#bib.bib71) for a historical perspective. These algorithms proved to be very effective for motion planning in high-dimensional spaces, and attracted significant attention over the last decade, including very recent work  ([Prentice and Roy, 2009](#bib.bib82); [Tedrake et al., 2010](#bib.bib98); [Luders et al., 2010](#bib.bib74); [Berenson et al., 2008](#bib.bib11); [Yershova and LaValle, 2008](#bib.bib106); [Stilman et al., 2007](#bib.bib96); [Koyuncu et al., 2010](#bib.bib55), see, e.g.,). Instead of using an explicit representation of the environment, sampling-based algorithms rely on a collision checking module, providing information about feasibility of candidate trajectories, and connect a set of points sampled from the obstacle-free space in order to build a graph (roadmap) of feasible trajectories. The roadmap is then used to construct the solution to the original motion-planning problem.

Informally speaking, sampling-based methods provide large amounts of computational savings by avoiding explicit construction of obstacles in the state space, as opposed to most complete motion planning algorithms. Even though these algorithms are not complete, they provide probabilistic completeness guarantees in the sense that the probability that the planner fails to return a solution, if one exists, decays to zero as the number of samples approaches infinity ([Barraquand et al., 1997](#bib.bib10))  ([Hsu et al., 1997](#bib.bib41); [Kavraki et al., 1998](#bib.bib52); [Ladd and Kavraki, 2004](#bib.bib59), see also). Moreover, the rate of decay of the probability of failure is exponential, under the assumption that the environment has good “visibility” properties ([Barraquand et al., 1997](#bib.bib10)). More recently, the empirical success of sampling-based algorithms was argued to be strongly tied to the hypothesis that most practical robotic applications, even though involving robots with many degrees of freedom, feature environments with such good visibility properties ([Hsu et al., 2006](#bib.bib44)).

### 1.1 Sampling-Based Algorithms

Arguably, the most influential sampling-based motion planning algorithms to date include Probabilistic RoadMaps (PRMs) ([Kavraki et al., 1996](#bib.bib51); [Kavraki et al., 1998](#bib.bib52)) and Rapidly-exploring Random Trees (RRTs) ([Kuffner and LaValle, 2000](#bib.bib56); [LaValle and Kuffner, 2001](#bib.bib63); [LaValle, 2006](#bib.bib62)). Even though the idea of connecting points sampled randomly from the state space is essential in both approaches, these two algorithms differ in the way that they construct a graph connecting these points.

The PRM algorithm and its variants are multiple-query methods that first construct a graph (the roadmap), which represents a rich set of collision-free trajectories, and then answer queries by computing a shortest path that connects the initial state with a final state through the roadmap. The PRM algorithm has been reported to perform well in high-dimensional state spaces ([Kavraki et al., 1996](#bib.bib51)). Furthermore, the PRM algorithm is probabilistically complete, and such that the probability of failure decays to zero exponentially with the number of samples used in the construction of the roadmap ([Kavraki et al., 1998](#bib.bib52)).
During the last two decades, the PRM algorithm has been a focus of robotics research: several improvements were suggested by many authors and the reasons to why it performs well in many practical cases were better understood (see, e.g., [Branicky et al., 2001](#bib.bib16); [Hsu et al., 2006](#bib.bib44); [Ladd and Kavraki, 2004](#bib.bib59), for some examples).

Even though multiple-query methods are valuable in highly structured environments, such as factory floors, most online planning problems do not require multiple queries, since, for instance, the robot moves from one environment to another, or the environment is not known a priori. Moreover, in some applications, computing a roadmap a priori may be computationally challenging or even infeasible. Tailored mainly for these applications, incremental sampling-based planning algorithms such as RRTs have emerged as an online, single-query counterpart to PRMs ([Kuffner and LaValle, 2000](#bib.bib56); [Hsu et al., 2002](#bib.bib43), see, e.g.,). The incremental nature of these algorithms avoids the necessity to set the number of samples a priori, and returns a solution as soon as the set of trajectories built by the algorithm is rich enough, enabling on-line implementations. Moreover, tree-based planners do not require connecting two states exactly and more easily handle systems with differential constraints.
The RRT algorithm has been shown to be probabilistically complete ([Kuffner and LaValle, 2000](#bib.bib56)), with an exponential rate of decay for the probability of
failure ([Frazzoli et al., 2002](#bib.bib33)).
The basic version of the RRT algorithm has been extended in several directions, and found many applications in the robotics domain and elsewhere ([Frazzoli et al., 2002](#bib.bib33); [Bhatia and Frazzoli, 2004](#bib.bib13); [Cortes et al., 2007](#bib.bib26); [Branicky et al., 2006](#bib.bib18); [Branicky et al., 2003](#bib.bib17); [Zucker et al., 2007](#bib.bib107), see, for instance,). In particular, RRTs have been shown to work effectively for systems with differential constraints and nonlinear dynamics ([LaValle and Kuffner, 2001](#bib.bib63); [Frazzoli et al., 2002](#bib.bib33)) as well as purely discrete or hybrid systems ([Branicky et al., 2003](#bib.bib17)). Moreover, the RRT algorithm was demonstrated in major robotics events on various experimental robotic platforms ([Bruce and Veloso, 2003](#bib.bib20); [Kuwata et al., 2009](#bib.bib58); [Teller et al., 2010](#bib.bib99); [Shkolnik et al., 2011](#bib.bib93); [Kuffner et al., 2002](#bib.bib57)).

Other sampling-based planners of note include Expansive Space Trees (EST) ([Hsu et al., 1997](#bib.bib41); [Hsu et al., 1999](#bib.bib42)) and Sampling-based Roadmap of Trees (SRT) ([Plaku et al., 2005](#bib.bib81)). The latter combines the main features of multiple-query algorithms such as PRM with those of single-query algorithms such as RRT and EST.

### 1.2 Optimal Motion Planning

In most applications, the quality of the solution returned by a motion planning algorithm is important. For example, one may be interested in solution paths of minimum cost, with respect to a given cost functional, such as the length of a path, or the time required to execute it. The problem of computing optimal motion plans has been proven in [Canny and Reif (1987)](#bib.bib23) to be very challenging even in basic cases.

In the context of sampling-based motion planning algorithms, the importance of computing
optimal solutions has been pointed out in early seminal papers ([LaValle and Kuffner, 2001](#bib.bib63)).
However, optimality properties of sampling-based motion planning algorithms have not been systematically investigated, and most of the relevant work relies on heuristics.
For example, in many field implementations of sampling-based planning algorithms ([Kuwata et al., 2009](#bib.bib58), see, e.g.,), it is often the case that since a feasible path is found quickly, additional available computation time is devoted to improving the solution with heuristics until the solution is executed. [Urmson and Simmons (2003)](#bib.bib100) proposed heuristics to bias the tree growth in RRT towards those regions that result in low-cost solutions. They have also shown experimental results evaluating the performance of different heuristics in terms of the quality of the solution returned. [Ferguson and Stentz (2006)](#bib.bib31) considered running the RRT algorithm multiple times in order to progressively improve the quality of the solution. They showed that each run of the algorithm results in a path with smaller cost, even though the procedure is not guaranteed to converge to an optimal solution. Criteria for restarting multiple RRT runs, in a different context, were also proposed in [Wedge and Branicky (2008)](#bib.bib103).
A more recent approach is the transition-based RRT (T-RRT) designed to combine rapid exploration properties of the RRT with stochastic global optimization methods ([Jaillet et al., 2010](#bib.bib45); [Berenson et al., 2011](#bib.bib12)).

A different approach that also offers optimality guarantees is based on graph search algorithms, such as A∗, applied over a finite discretization (based, e.g., on a grid, or a cell decomposition of the configuration space) that is generated offline.
Recently, these algorithms received a large amount of attention. In particular, they were extended to run in an anytime fashion ([Likhachev et al., 2004](#bib.bib68); [Likhachev et al., 2008](#bib.bib69)), deal with dynamic environments ([Stentz, 1995](#bib.bib95); [Likhachev et al., 2008](#bib.bib69)), and handle systems with differential constraints ([Likhachev and Ferguson, 2009](#bib.bib67)).
These have also been successfully demonstrated on various robotic platforms ([Likhachev and Ferguson, 2009](#bib.bib67); [Dolgov et al., 2009](#bib.bib27)).
However, optimality guarantees of these algorithms are only ensured up to the grid resolution. Moreover, since the number of grid points grows exponentially with the dimensionality of the state space, so does the (worst-case) running time of these algorithms.

### 1.3 Statement of Contributions

To the best of the author’s knowledge, this paper provides the first systematic and thorough analysis of optimality and complexity properties of the major paradigms for sampling-based path planning algorithms, for multiple- or single-query applications, and introduces
the first algorithms that are both asymptotically optimal and
computationally efficient, with respect to other algorithms in this class.
A summary of the contributions can be found below, and is shown in Table [1](#S1.T1 "Table 1 ‣ 1.3 Statement of Contributions ‣ 1 Introduction ‣ Sampling-based Algorithms for Optimal Motion Planning").

As a first set of results, it is proven that the standard PRM and RRT algorithms are not asymptotically optimal, and that the “simplified” PRM algorithm is asymptotically optimal, but computationally expensive. Moreover, it is shown that the $k$-nearest variant of the (simplified) PRM algorithm is not necessarily probabilistically complete (e.g., it is not probabilistically complete for $k=1$), and is not asymptotically optimal for any fixed $k$.

In order to address the limitations of sampling-based path planning algorithms available in the literature, new algorithms are proposed, i.e., PRM∗, RRG, and RRT∗,
and proven to be probabilistically complete, asymptotically optimal, and computationally efficient. Of these, PRM∗ is a batch variable-radius PRM, applicable to multiple-query problems, in which the radius is scaled with the number of samples in a way that provably ensures both asymptotic optimality and computational efficiency. RRG is an incremental algorithm that builds a connected roadmap, providing similar performance to PRM∗ in a single-query setting, and in an anytime fashion (i.e., a first solution is provided quickly,
and monotonically improved if more computation time is available). The RRT∗ algorithm is a variant of RRG that incrementally builds a tree, providing anytime solutions, provably converging to an optimal solution, with minimal computational and memory requirements.

Table 1: Summary of results. Time and space complexity are expressed as a function of the number of samples $n$, for a fixed environment.

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  | Algorithm | Probabilistic Completeness | Asymptotic Optimality | Monotone Convergence | Time Complexity | | Space Complexity |
|  |  |  |  | Processing | Query |  |
| Existing  Algorithms | PRM | Yes | No | Yes | $O(n\log n)$ | $O(n\log n)$ | $O(n)$ |
|  | sPRM | Yes | Yes | Yes | $O(n^{2})$ | $O(n^{2})$ | $O(n^{2})$ |
|  | $k$-sPRM | Conditional | No | No | $O(n\log n)$ | $O(n\log n)$ | $O(n)$ |
|  | RRT | Yes | No | Yes | $O(n\log n)$ | $O(n)$ | $O(n)$ |
| Proposed  Algorithms | PRM∗ | Yes | Yes | No | $O(n\log n)$ | $O(n\log n)$ | $O(n\log n)$ |
|  | $k$-PRM∗ |  |  |  |  |  |  |
|  | RRG | Yes | Yes | Yes | $O(n\log n)$ | $O(n\log n)$ | $O(n\log n)$ |
|  | $k$-RRG |  |  |  |  |  |  |
|  | RRT∗ | Yes | Yes | Yes | $O(n\log n)$ | $O(n)$ | $O(n)$ |
|  | $k$-RRT∗ |  |  |  |  |  |  |

In this paper, the problem of planning a path through a connected bounded subset of a $d$-dimensional Euclidean space is considered. As in the early seminal papers on incremental sampling-based motion planning algorithms such as [Kuffner and LaValle (2000)](#bib.bib56), no differential constraints are considered (i.e., the focus of the paper is on path planning problems), but our methods can be easily extended to planning in configuration spaces and applied to several practical problems of interest. The extension to systems with differential constraints is deferred to future work (see [Karaman and Frazzoli (2010a)](#bib.bib46) for preliminary results).

Finally, the results presented in this article, and the techniques used in the analysis of the algorithms, hinge on novel connections established between sampling-based path planning algorithms in robotics and the theory of random geometric graphs, which may be of independent interest.

A preliminary version of this article has appeared in [Karaman and Frazzoli (2010b)](#bib.bib47). Since then a variety of new algorithms based on the the ideas behind PRM∗, RRG, and RRT∗ have been proposed in the literature. For instance, a probabilistically complete and probabilistically sound algorithm for solving a class of differential games has appeared in [Karaman and Frazzoli (2010c)](#bib.bib48). Algorithms based on the RRG were used to solve belief-space planning problems in [Bry and Roy (2011)](#bib.bib21). The RRT∗ algorithm was used for anytime motion planning in [Karaman et al. (2011)](#bib.bib49), where it was also demonstrated experimentally on a full-size robotic fork truck. In [Alterovitz et al. (2011)](#bib.bib2), the analysis given in [Karaman and Frazzoli (2010b)](#bib.bib47) was used to guarantee computational efficiency and asymptotic optimality of a new algorithm that can trade off between exploration and optimality during planning.

A software library implementing the new algorithms introduced in this paper has been released as open-source software by the authors, and is currently available at
<http://ares.lids.mit.edu/software/>

### 1.4 Paper Organization

This paper is organized as follows. Section [2](#S2 "2 Preliminary Material ‣ Sampling-based Algorithms for Optimal Motion Planning") lays the ground in terms of
notation and problem formulation. Section [3](#S3 "3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") is devoted to the discussion of the algorithms that are considered in the paper: first, the main paradigms for sampling-based motion planning algorithms available in the literature are presented, together with their main variants. Then, the new proposed algorithms are presented and motivated.
In Section [4](#S4 "4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") the properties of these algorithms are rigorously analyzed, formally establishing their probabilistic completeness and asymptotically optimality (or lack thereof), as well as their computational complexity as a function of the number of samples and of the number of obstacles in the environment. Experimental results are presented in Section [5](#S5 "5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning"), to illustrate and validate the theoretical findings.
Finally, Section [6](#S6 "6 Conclusion ‣ Sampling-based Algorithms for Optimal Motion Planning") contains conclusions and perspectives for future work. In order not to excessively disrupt the flow of the presentation, a summary of notation used throughout the paper, as well as lengthy proofs of important results are presented in the Appendix.

## 2 Preliminary Material

This section contains some preliminary material that will be necessary for the discussion in the remainder of the paper. Namely, the problems of feasible and optimal motion planning is introduced, and some important results from the theory of random geometric graphs are summarized. The notation used in the paper is summarized in Appendix [A](#A1 "Appendix A Notation ‣ Sampling-based Algorithms for Optimal Motion Planning").

### 2.1 Problem Formulation

In this section, the feasible and optimal path planning problems are formalized.

Let ${\cal X}=(0,1)^{d}$ be the *configuration space*, where $d\in\mathbb{N}$, $d\geq 2$.
Let ${\cal X}\_{\mathrm{obs}}$ be the obstacle region, such that ${\cal X}\setminus{\cal X}\_{\mathrm{obs}}$ is an open set, and denote the obstacle-free space as ${\cal X}\_{\mathrm{free}}=\mathrm{cl}({\cal X}\setminus{\cal X}\_{\mathrm{obs}})$, where $\mathrm{cl}(\cdot)$ denotes the closure of a set. The initial condition $x\_{\mathrm{init}}$ is an element of ${\cal X}\_{\mathrm{free}}$, and the goal region ${\cal X}\_{\mathrm{goal}}$ is an open subset of ${\cal X}\_{\mathrm{free}}$.
A path planning problem is defined by a triplet $({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$.

Let $\sigma:[0,1]\to\mathbb{R}^{d}$; the total variation of $\sigma$ is defined as

|  |  |  |
| --- | --- | --- |
|  | $\mathrm{TV}(\sigma)=\sup\_{\left\{n\in\mathbb{N},0=\tau\_{0}<\tau\_{1}<\dots<\tau\_{n}=s\right\}}\sum\_{i=1}^{n}|\sigma(\tau\_{i})-\sigma(\tau\_{i-1})|.$ |  |

A function $\sigma$ with $\mathrm{TV}(\sigma)<\infty$ is said to have bounded variation.

###### Definition 1 (Path)

A function $\sigma:[0,1]\to\mathbb{R}^{d}$ of bounded variation is called a

* •

  Path, if it is continuous;
* •

  *Collision-free path*, if it is a path, and $\sigma(\tau)\in{\cal X}\_{\mathrm{free}}$, for all $\tau\in[0,1]$;
* •

  *Feasible path*, if it is a collision-free path, $\sigma(0)=x\_{\mathrm{init}}$, and $\sigma(1)\in\mathrm{cl}({\cal X}\_{\mathrm{goal}})$.

The total variation of a path is essentially its length, i.e., the Euclidean distance traversed by the path in $\mathbb{R}^{d}$.
The feasibility problem of path planning is to find a feasible path, if one exists, and report
failure otherwise:

###### Problem 2 (Feasible path planning)

Given a path planning problem $({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$, find a feasible path $\sigma:[0,1]\to{\cal X}\_{\mathrm{free}}$ such that $\sigma(0)=x\_{\mathrm{init}}$ and $\sigma(1)\in\mathrm{cl}({\cal X}\_{\mathrm{goal}})$, if one exists. If no such path exists, report failure.

Let $\Sigma$ denote the set of all paths, and $\Sigma\_{\mathrm{free}}$ the set of all collision-free paths. Given two paths $\sigma\_{1},\sigma\_{2}\in\Sigma$, such that $\sigma\_{1}(1)=\sigma\_{2}(0)$, let $\sigma\_{1}|\sigma\_{2}\in\Sigma$ denote their concatenation, i.e., $(\sigma\_{1}|\sigma\_{2})(\tau):=\sigma\_{1}(2\,\tau)$ for all $\tau\in[0,1/2]$ and $(\sigma\_{1}|\sigma\_{2})(\tau):=\sigma\_{2}(2\,\tau-1)$ for all $\tau\in(1/2,1]$. Both $\Sigma$ and $\Sigma\_{\mathrm{free}}$ are closed under concatenation.
Let $c:\Sigma\to\mathrm{R}\_{\geq 0}$ be a function, called the cost function, which assigns a strictly positive cost to all non-trivial collision-free paths (i.e., $c(\sigma)=0$ if and only if $\sigma(\tau)=\sigma(0),\forall\tau\in[0,1]$). The cost function is assumed to be monotonic, in the sense that
for all $\sigma\_{1},\sigma\_{2}\in\Sigma$, $c(\sigma\_{1})\leq c(\sigma\_{1}|\sigma\_{2})$, and bounded, in the sense that there exists $k\_{c}$ such that
$c(\sigma)\leq k\_{c}\mathrm{TV}(\sigma)$, $\forall\sigma\in\Sigma$.

The optimality problem of path planning asks for finding a feasible path with minimum cost:

###### Problem 3 (Optimal path planning)

Given a path planning problem $({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$ and a cost function $c:\Sigma\to\mathbb{R}\_{\geq 0}$, find a feasible path $\sigma^{\*}$ such that $c(\sigma^{\*})=\min\{c(\sigma):\sigma\mbox{ is feasible}\}$. If no such path exists, report failure.

### 2.2 Random Geometric Graphs

The objective of this section is to summarize some of the results on random geometric graphs that are available in the literature, and are relevant to the analysis of sampling-based path planning algorithms. In the remainder of this article, several connections are made between the theory of random geometric graphs and path-planning algorithms in robotics, providing insight on a number of issues, including, e.g., probabilistic completeness and asymptotic optimality, as well as technical tools to analyze the algorithms and establish their properties. In fact, it turns out that the data structures constructed by most sampling-based motion planning algorithms in the literature coincide, in the absence of obstacles, with standard models of random geometric graphs.

Random geometric graphs are in general defined as stochastic collections of points in a metric space, connected pairwise by edges if certain conditions (e.g., on the distance between the points) are satisfied. Such objects have been studied since their introduction by [Gilbert (1961)](#bib.bib35); see, e.g., [Penrose (2003)](#bib.bib79) and  [Balister et al. (2009a)](#bib.bib7) for an overview of recent results. From the theoretical point of view, the study of random geometric graphs makes a connection between random graphs ([Bollobás, 2001](#bib.bib14)) and percolation theory ([Bollobás and Riordan, 2006](#bib.bib15)). On the application side, in recent years, random geometric graphs have attracted significant attention as models of ad hoc wireless networks ([Gupta and Kumar, 1998](#bib.bib37); [Gupta and Kumar, 2000](#bib.bib38)).

Much of the literature on random geometric graphs deals with infinite graphs defined on unbounded domains, with vertices generated as a homogeneous Poisson point process. Recall that a Poisson random variable of parameter $\lambda\in\mathbb{R}\_{>0}$ is an integer-valued random variable $\mathrm{Poisson}(\lambda):\Omega\to\mathbb{N}\_{0}$ such that $\mathbb{P}(\mathrm{Poisson}(\lambda)=k)=e^{-\lambda}\lambda^{k}/k!$. A homogeneous Poisson point process of intensity $\lambda$ on $\mathbb{R}^{d}$ is a random countable set of points $\mathcal{P}^{d}\_{\lambda}\subset\mathbb{R}^{d}$ such that, for any disjoint measurable sets $\mathcal{S}\_{1},\mathcal{S}\_{2}\subset\mathbb{R}^{d}$, $\mathcal{S}\_{1}\cap\mathcal{S}\_{2}=\emptyset$, the numbers of points of $\mathcal{P}^{d}\_{\lambda}$ in each set are independent Poisson variables, i.e., $\operatorname{card}\left(\mathcal{P}^{d}\_{\lambda}\cap\mathcal{S}\_{1}\right)=\mathrm{Poisson}(\mu(\mathcal{S}\_{1})\lambda)$ and $\operatorname{card}\left(\mathcal{P}^{d}\_{\lambda}\cap\mathcal{S}\_{2}\right)=\mathrm{Poisson}(\mu(\mathcal{S}\_{2})\lambda)$.
In particular, the intensity of a homogeneous Poisson point process can be interpreted as the expected number of points generated in the unit cube, i.e., $\mathbb{E}(\operatorname{card}\left(\mathcal{P}^{d}\_{\lambda}\cap(0,1)^{d}\right))=\mathbb{E}(\mathrm{Poisson}(\lambda))=\lambda$.

Perhaps the most studied model of infinite random geometric graph is the following, introduced in [Gilbert (1961)](#bib.bib35), and often called Gilbert’s disc model, or Boolean model:

###### Definition 4 (Infinite random $r$-disc graph)

Let $\lambda,r\in\mathbb{R}\_{>0}$, and $d\in\mathbb{N}$. An infinite random $r$-disc graph $G\_{\infty}^{\mathrm{disc}}(\lambda,r)$ in $d$ dimensions is an infinite graph with vertices $\{X\_{i}\}\_{i\in\mathbb{N}}=\mathcal{P}^{d}\_{\lambda}$, and such that $(X\_{i},X\_{j})$, $i,j\in\mathbb{N}$, is an edge if and only if $\|X\_{i}-X\_{j}\|<r$.

A fundamental issue in infinite random graphs is whether the graph contains an infinite connected component, with non-zero probability. If it does, the random graph is said to percolate. Percolation is an important paradigm in statistical physics, with many applications in disparate fields such as material science, epidemiology, and microchip manufacturing, just to name a few ([Sahimi, 1994](#bib.bib88), see, e.g.,).

Consider the infinite random $r$-disc graph, for $r=1$, i.e., $G\_{\infty}^{\mathrm{disc}}(\lambda,1)$, and assume, without loss of generality, that the origin is one of the vertices of this graph. Let $p\_{k}(\lambda)$ denote the probability that the connected component of $G\_{\infty}^{\mathrm{disc}}(\lambda,1)$ containing the origin contains $k$ vertices, and define $p\_{\infty}(\lambda)$ as $p\_{\infty}(\lambda)=1-\sum\_{k=1}^{\infty}p\_{k}(\lambda)$. The function $p\_{\infty}:\lambda\to p\_{\infty}(\lambda)$ is monotone, and $p\_{\infty}(0)=0$ and $\lim\_{\lambda\to\infty}p\_{\infty}(\lambda)=1$ ([Penrose, 2003](#bib.bib79)). A key result in percolation theory is that there exists a non-zero critical intensity $\lambda\_{\mathrm{c}}$ defined as $\lambda\_{\mathrm{c}}:=\sup\{\lambda:p\_{\infty}(\lambda)=0\}$. In other words, for all $\lambda>\lambda\_{\mathrm{c}}$, there is a non-zero probability that the origin is in an infinite connected component of $G\_{\infty}^{\mathrm{disc}}(\lambda,1)$; moreover, under these conditions, the graph has precisely one infinite connected component, almost surely ([Meester and Roy, 1996](#bib.bib75)). The function $p\_{\infty}$ is continuous for all $\lambda\neq\lambda\_{\mathrm{c}}$: in other words, the graph undergoes a phase transition at the critical density $\lambda\_{\mathrm{c}}$, often also called the continuum percolation threshold ([Penrose, 2003](#bib.bib79)). The exact value of $\lambda\_{\mathrm{c}}$ is not known; Meester and Roy provide $0.696<\lambda\_{c}<3.372$ for $d=2$ ([Meester and Roy, 1996](#bib.bib75)), and simulations suggest that $\lambda\_{c}\approx 1.44$ ([Quintanilla et al., 2000](#bib.bib83)).

For many applications, including the ones in this article, models of finite graphs on a bounded domain are more relevant. Penrose introduced the following model ([Penrose, 2003](#bib.bib79)):

###### Definition 5 (Random $r$-disc graph)

Let $r\in\mathbb{R}\_{>0}$, and $n,d\in\mathbb{N}$. A random $r$-disc graph $G^{\mathrm{disc}}(n,r)$ in $d$ dimensions is a graph whose $n$ vertices, $\{X\_{1},X\_{2},\ldots,X\_{n}\}$, are independent, uniformly distributed random variables in $(0,1)^{d}$, and such that $(X\_{i},X\_{j})$, $i,j\in\{1,\ldots,n\}$, $i\neq j$, is an edge if and only if $\|X\_{i}-X\_{j}\|<r$.

For finite random geometric graph models, one is typically interested in whether a random geometric graph possesses certain properties asymptotically as $n$ increases.
Since the number of vertices is finite in random graphs, percolation can not be defined easily. In this case, percolation is studied in terms of the scaling of the number of vertices in the largest connected component with respect to the total number of vertices; in particular, a finite random geometric graph is said to percolate if it contains a “giant”
connected component containing at least a constant fraction of all the nodes. As in the infinite case, percolation in finite random geometric graphs is often a phase transition phenomenon. In the case of random $r$-disc graphs,

###### Theorem 6 (Percolation of random $r$-disc graphs ([Penrose, 2003](#bib.bib79)))

Let $G^{\mathrm{disc}}(n,r)$ be a random $r$-disc graph in $d\geq 2$ dimensions, and let $N\_{\mathrm{max}}(G^{\mathrm{disc}}(n,r))$ be the number of vertices in its largest connected component. Then, almost surely,

|  |  |  |
| --- | --- | --- |
|  | $\lim\_{n\to\infty}\frac{N\_{\mathrm{max}}(G^{\mathrm{disc}}(n,r\_{n}))}{n}=0,\qquad\mbox{ if }r\_{n}<\left(\lambda\_{\mathrm{c}}/{n}\right)^{1/d},$ |  |

and

|  |  |  |
| --- | --- | --- |
|  | $\lim\_{n\to\infty}\frac{N\_{\mathrm{max}}(G^{\mathrm{disc}}(n,r))}{n}>0,\qquad\mbox{ if }r\_{n}>\left(\lambda\_{\mathrm{c}}/{n}\right)^{1/d},$ |  |

where $\lambda\_{\mathrm{c}}$ is the continuum percolation threshold.

A random $r$-disc graph with $\lim\_{n\to\infty}nr\_{n}^{d}=\lambda\in(0,\infty)$ is said to operate in the thermodynamic limit. It is said to be in subcritical regime when $\lambda<\lambda\_{c}$ and supercritical regime when $\lambda>\lambda\_{c}$.

Another property of interest is connectivity. Clearly, connectivity implies percolation. Interestingly, emergence of connectivity in random geometric graphs is a phase transition phenomenon, as percolation. The following result is available in the literature:

###### Theorem 7 (Connectivity of random $r$-disc graphs ([Penrose, 2003](#bib.bib79)))

Let $G^{\mathrm{disc}}(n,r)$ be a random $r$-disc graph in $d$ dimensions. Then,

|  |  |  |
| --- | --- | --- |
|  | $\lim\_{n\to\infty}\mathbb{P}\left(\{G^{\mathrm{disc}}(n,r)\mbox{ is connected }\}\right)=\left\{\begin{array}[]{ll}1,&\mbox{ if }\zeta\_{d}r^{d}>\log(n)/n,\\[4.30554pt] 0,&\mbox{ if }\zeta\_{d}r^{d}<\log(n)/n,\\ \end{array}\right.$ |  |

where $\zeta\_{d}$ is the volume of the unit ball in $d$ dimensions.

Another model of random geometric graphs considers edges between $k$ nearest neighbors. (Note that there are no ties, almost surely.) Both infinite and finite models are considered, as follows.

###### Definition 8 (Infinite random $k$-nearest neighbor graph)

Let $\lambda\in\mathbb{R}\_{>0}$, and $d,k\in\mathbb{N}$.
An infinite random $k$-nearest neighbor graph $G\_{\infty}^{\mathrm{near}}(\lambda,k)$ in $d$ dimensions is an infinite graph with vertices $\{X\_{i}\}\_{i\in\mathbb{N}}=\mathcal{P}^{d}\_{\lambda}$, and such that $(X\_{i},X\_{j})$, $i,j\in\mathbb{N}$, is an edge if $X\_{j}$ is among the $k$ nearest neighbors of $X\_{i}$, or if $X\_{i}$ is among the $k$ nearest neighbors of $X\_{j}$.

###### Definition 9 (Random $k$-nearest neighbor graph)

Let $d,k,n\in\mathbb{N}$.
A random $k$-nearest neighbor graph $G^{\mathrm{near}}(n,k)$ in $d$ dimensions is a graph whose $n$ vertices, $\{X\_{1},X\_{2},\ldots,X\_{n}\}$, are independent, uniformly distributed random variables in $(0,1)^{d}$, and such that $(X\_{i},X\_{j})$, $i,j\in\{1,\ldots,n\}$, $i\neq j$, is an edge if $X\_{j}$ is among the $k$ nearest neighbors of $X\_{i}$, or if $X\_{i}$ is among the $k$ nearest neighbors of $X\_{j}$.

Percolation and connectivity for random $k$-nearest neighbor graphs exhibit phase transition phenomena, as in the random $r$-disc case. However, the results available in the literature are more limited. Results on percolation are only available for infinite graphs:

###### Theorem 10 (Percolation in infinite random $k$-nearest graphs ([Balister et al., 2009a](#bib.bib7)))

Let $G^{\mathrm{near}}\_{\infty}(\lambda,k)$ be an infinite random $k$-nearest neighbor graph in $d\geq 2$ dimensions. Then, there exists a constant $k^{\mathrm{p}}\_{d}>0$ such that

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{G^{\mathrm{near}}\_{\infty}(1,k)\mbox{ has an infinite component }\right\}\right)=\left\{\begin{array}[]{ll}1,&\mbox{ if }k\geq k^{\mathrm{p}}\_{d},\\[4.30554pt] 0,&\mbox{ if }k<k^{\mathrm{p}}\_{d}.\end{array}\right.$ |  |

The value of $k^{\mathrm{p}}\_{d}$ is not known. However, it is believed that $k^{\mathrm{p}}\_{2}=3$, and $k^{\mathrm{p}}\_{d}=2$ for all $d\geq 3$ ([Balister et al., 2009a](#bib.bib7)). It is known that percolation does not occur for $k=1$ ([Balister et al., 2009a](#bib.bib7)).

Regarding connectivity of random $k$-nearest neighbor graphs, the only available results in the literature are not stated in terms of a given number of vertices: rather, the results are stated in terms of the restriction of a homogeneous Poisson point process to the unit cube.
In other words, the vertices of the graph are obtained as $\{X\_{1},X\_{2},\ldots\}=\mathcal{P}^{d}\_{\lambda}\cap(0,1)^{d}$. This is equivalent to setting the number of vertices as a Poisson random variable of parameter $n$, and then sampling the $\mathrm{Poisson}(n)$ vertices independently and uniformly in $(0,1)^{d}$:

###### Lemma 11 ([Stoyan et al. (1995)](#bib.bib97))

Let $\{X\_{i}\}\_{i\in\mathbb{N}}$ be a sequence of points drawn independently and uniformly from $\mathcal{S}\subseteq{\cal X}$. Let $\mathrm{Poisson}(n)$ be a Poisson random variable with parameter $n$. Then, $\{X\_{1},X\_{2},\dots,X\_{\mathrm{Poisson}(n)}\}$ is the restriction to $\mathcal{S}$ of a homogeneous Poisson point process with intensity $n/\mu(\mathcal{S})$.

The main advantage in using such a model to generate the vertices of a random geometric graph is independence: in the Poisson case, the numbers of points in any two disjoint measurable regions $\mathcal{S}\_{1},\mathcal{S}\_{2}\subset[0,1]^{d}$, $\mathcal{S}\_{1}\cap\mathcal{S}\_{2}=\emptyset$, are independent Poisson random variables, with mean $\mu(\mathcal{S}\_{1})\lambda$ and $\mu(\mathcal{S}\_{2})\lambda$, respectively. These two random variables would not be independent if the total number of vertices were fixed a priori (also called a binomial point process). With some abuse of notation, such a random geometric graph model will be indicated as $G^{\mathrm{near}}(\mathrm{Poisson}(n),k)$.

###### Theorem 12 (Connectivity of random $k$-nearest graphs ([Balister et al., 2009b](#bib.bib8); [Xue and Kumar, 2004](#bib.bib104)))

Let $G^{\mathrm{near}}(\mathrm{Poisson}(n),k)$ indicate a $k$-nearest neighbor graph model in $d=2$ dimensions, such that its vertices are generated using a Poisson point process of intensity $n$. Then, there exists a constant $k^{\mathrm{c}}\_{2}>0$ such that

|  |  |  |
| --- | --- | --- |
|  | $\lim\_{n\to\infty}\mathbb{P}\left(\left\{G^{\mathrm{near}}(\mathrm{Poisson}(n),\lfloor k\log(n)\rfloor)\mbox{ is connected }\right\}\right)=\left\{\begin{array}[]{ll}1,&\mbox{ if }k\geq k^{\mathrm{c}}\_{2},\\[4.30554pt] 0,&\mbox{ if }k<k^{\mathrm{c}}\_{2}.\end{array}\right.$ |  |

The value of $k^{\mathrm{c}}\_{2}$ is not known; the current best estimate is
$0.3043\leq k^{\mathrm{c}}\_{2}\leq 0.5139$ ([Balister et al., 2005](#bib.bib6)).

Finally, the last model of random geometric graph that will be relevant for the analysis of the algorithms in this paper is the following:

###### Definition 13 (Online nearest neighbor graph)

Let $d,n\in\mathbb{N}$.
An online nearest neighbor graph $G^{\mathrm{ONN}}(n)$ in $d$ dimensions is a graph whose $n$ vertices, $(X\_{1},X\_{2},\ldots,X\_{n})$, are independent, uniformly distributed random variables in $(0,1)^{d}$, and such that $(X\_{i},X\_{j})$, $i,j\in\{1,\ldots,n\}$, $j>1$, is an edge if and only if $\|X\_{i}-X\_{j}\|=\min\_{1\leq k<j}\|X\_{k}-X\_{j}\|$.

Clearly, the online nearest neighbor graph is connected by construction, and trivially percolates. Recent results for this random geometric graph model include estimates of the total power-weighted edge length and an analysis of the vertex degree distribution, see, e.g., [Wade (2009)](#bib.bib102).

## 3 Algorithms

In this section, a number of sampling-based motion planning algorithms are introduced.
First, some common primitive procedures are defined. Then, the PRM and the RRT algorithms are outlined, as they are representative of the major paradigms for sampling-based motion planning algorithms in the literature. Then, new algorithms, namely PRM∗ and RRT∗, are introduced, as asymptotically optimal and computationally efficient versions of their “standard” counterparts.

### 3.1 Primitive Procedures

Before discussing the algorithms, it is convenient to introduce the primitive procedures that they rely on.

##### Sampling:

Let $\mathtt{Sample}:\omega\mapsto\{\mathtt{Sample}\_{i}(\omega)\}\_{i\in\mathbb{N}\_{0}}\subset{\cal X}$ be a map from $\Omega$ to sequences of points in ${\cal X}$, such that the random variables $\mathtt{Sample}\_{i}$, $i\in\mathbb{N}\_{0}$, are independent and identically distributed (i.i.d.). For simplicity, the samples are assumed to be drawn from a uniform distribution, even though results extend naturally to any absolutely continuous distribution with density bounded away from zero on ${\cal X}$. It is convenient to consider another map, $\mathtt{SampleFree}:\omega\mapsto\{\mathtt{SampleFree}\_{i}(\omega)\}\_{i\in\mathbb{N}\_{0}}\subset{\cal X}\_{\mathrm{free}}$ that returns sequences of i.i.d. samples from ${\cal X}\_{\mathrm{free}}$. For each $\omega\in\Omega$, the sequence $\{\mathtt{SampleFree}\_{i}(\omega)\}\_{i\in\mathbb{N}\_{0}}$ is the subsequence of $\{\mathtt{Sample}\_{i}(\omega)\}\_{i\in\mathbb{N}\_{0}}$ containing only the samples in ${\cal X}\_{\mathrm{free}}$, i.e., $\{\mathtt{SampleFree}\_{i}(\omega)\}\_{i\in\mathbb{N}\_{0}}=\{\mathtt{Sample}\_{i}(\omega)\}\_{i\in\mathbb{N}\_{0}}\cap{\cal X}\_{\mathrm{free}}$.

##### Nearest Neighbor:

Given a graph $G=(V,E)$, where $V\subset{\cal X}$, a point $x\in{\cal X}$ , the function ${\tt Nearest}:(G,x)\mapsto v\in V$ returns the vertex in $V$ that is
“closest” to $x$ in terms of a given distance function. In this paper, the Euclidean distance is used (see, e.g., [LaValle and Kuffner (2001)](#bib.bib63) for alternative choices), and
hence

|  |  |  |
| --- | --- | --- |
|  | ${\tt Nearest}(G=(V,E),x):=\mathrm{argmin}\_{v\in V}\|x-v\|.$ |  |

A set-valued version of this function is also considered, ${\tt kNearest}:(G,x,k)\mapsto\{v\_{1},v\_{2},\ldots,v\_{k}\}$, returning the $k$ vertices in $V$ that are nearest to $x$, according to the same distance function as above. (By convention, if the cardinality of $V$ is less than $k$, then the function returns $V$.)

##### Near Vertices:

Given a graph $G=(V,E)$, where $V\subset{\cal X}$, a point $x\in{\cal X}$, and a positive real number $r\in\mathbb{R}\_{>0}$, the function ${\tt Near}:(G,x,r)\mapsto V^{\prime}\subseteq V$ returns the vertices in $V$ that are contained in a ball of radius $r$ centered
at $x$, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathtt{Near}(G=(V,E),x,r):=\left\{v\in V:v\in\mathcal{B}\_{x,r}\right\}.$ |  |

##### Steering:

Given two points $x,y\in{\cal X}$, the function ${\tt Steer}:(x,y)\mapsto z$ returns
a point $z\in{\cal X}$ such that $z$ is “closer” to $y$ than $x$ is. Throughout the paper,
the point $z$ returned by the function ${\tt Steer}$ will be such that $z$ minimizes $\|z-y\|$ while at the same time maintaining $\|z-x\|\leq\eta$, for a prespecified $\eta>0$,11
1
This steering procedure is used widely in the robotics literature, since its
introduction in [Kuffner and LaValle (2000)](#bib.bib56). Our results also extend to the Rapidly-exploring
Random Dense Trees ([LaValle, 2006](#bib.bib62), see, e.g.,), which are slightly modified versions of the
RRTs that do not require tuning any prespecified parameters such as $\eta$ in this case. i.e.,

|  |  |  |
| --- | --- | --- |
|  | ${\tt Steer}(x,y):=\displaystyle\mathrm{argmin}\_{z\in\mathcal{B}\_{x,\eta}}\|z-y\|.$ |  |

##### Collision Test:

Given two points $x,x^{\prime}\in{\cal X}$, the Boolean function ${\tt CollisionFree}(x,x^{\prime})$ returns ${\tt True}$ if the line segment between $x$ and $x^{\prime}$ lies in
${\cal X}\_{\mathrm{free}}$, i.e., $[x,x^{\prime}]\subset{\cal X}\_{\mathrm{free}}$, and ${\tt False}$ otherwise.

### 3.2 Existing Algorithms

Next, some of the sampling-based algorithms available in the literature are outlined.
For convenience, inputs and outputs of the algorithms are not shown explicitly, but are as follows.
All algorithms take as input a path planning problem $({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$, an integer $n\in\mathbb{N}$, and a cost function $c:\Sigma\to\mathbb{R}\_{\geq 0}$, if appropriate. These inputs are shared with functions and procedures called within the algorithms. All algorithms return a graph $G=(V,E)$, where $V\subset{\cal X}\_{\mathrm{free}}$, $\operatorname{card}\left(V\right)\leq n+1$, and $E\in\mathrm{V}\times\mathrm{V}$. The solution of the path planning problem can be easily computed from such a graph, e.g., using standard shortest-path algorithms.

##### Probabilistic RoadMaps (PRM):

The Probabilistic RoadMaps algorithm is primarily aimed at multi-query applications. In its basic version, it consists of a pre-processing phase, in which a roadmap is constructed by attempting connections among $n$ randomly-sampled points in ${\cal X}\_{\mathrm{free}}$, and a query phase, in which paths connecting initial and final conditions through the roadmap are sought.
“Expansion” heuristics for enhancing the roadmap’s connectivity are available in the literature ([Kavraki et al., 1996](#bib.bib51)) but have no impact on the analysis in this paper, and will not be discussed.

The pre-processing phase, outlined in Algorithm [1](#algorithm1 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning"), begins with an empty graph. At each iteration, a point $x\_{\mathrm{rand}}\in{\cal X}\_{\mathrm{free}}$ is sampled, and added to the vertex set $V$. Then, connections are attempted between $x\_{\mathrm{rand}}$ and other vertices in $V$ within a ball of radius $r$ centered at $x\_{\mathrm{rand}}$, in order of increasing distance from $x\_{\mathrm{rand}}$, using a simple local planner (e.g., straight-line connection). Successful (i.e., collision-free) connections result in the addition of a new edge to the edge set $E$. To avoid unnecessary computations (since the focus of the algorithm is establishing connectivity), connections between $x\_{\mathrm{rand}}$ and vertices in the same connected component are avoided. Hence, the roadmap constructed by PRM is a forest, i.e., a collection of trees.

Algorithm 1 PRM (preprocessing phase)

```
1
V←∅V\leftarrow\emptyset; E←∅E\leftarrow\emptyset;

2
for i=0,…,ni=0,\ldots,n do
   
                3
xrand←𝚂𝚊𝚖𝚙𝚕𝚎𝙵𝚛𝚎𝚎ix_{\mathrm{rand}}\leftarrow{\tt SampleFree}_{i};
   
                4
U←𝙽𝚎𝚊𝚛⁡(G=(V,E),xrand,r)U\leftarrow\mathtt{Near}(G=(V,E),x_{\mathrm{rand}},r) ;
   
                5
V←V∪{xrand}V\leftarrow V\cup\{x_{\mathrm{rand}}\};
   
                6
foreach u∈Uu\in U, in order of increasing ‖u−xrand‖\|u-x_{\mathrm{rand}}\|, do
      
                7
if xrandx_{\mathrm{rand}} and uu are not in the same connected component of G=(V,E)G=(V,E)
 then
         
                8
if  𝙲𝚘𝚕𝚕𝚒𝚜𝚒𝚘𝚗𝙵𝚛𝚎𝚎⁡(xrand,u)\mathtt{CollisionFree}(x_{\mathrm{rand}},u) then
E←E∪{(xrand,u),(u,xrand)}E\leftarrow E\cup\{(x_{\mathrm{rand}},u),(u,x_{\mathrm{rand}})\};

9
return G=(V,E)G=(V,E);
```

Analysis results in the literature are only available for a “simplified” version of the PRM algorithm ([Kavraki et al., 1998](#bib.bib52)), referred to as sPRM in this paper. The simplified algorithm initializes the vertex set with the initial condition, samples $n$ points from ${\cal X}\_{\mathrm{free}}$,
and then attempts to connect points within a distance $r$, i.e., using a similar logic as PRM, with the difference that connections between vertices in the same connected component are allowed. Notice that in the absence of obstacles, i.e., if ${\cal X}\_{\mathrm{free}}={\cal X}$, the roadmap constructed in this way is a random $r$-disc graph.

Algorithm 2 sPRM

```
1
V←{xinit}∪{𝚂𝚊𝚖𝚙𝚕𝚎𝙵𝚛𝚎𝚎i}i=1,…,nV\leftarrow\{x_{\mathrm{init}}\}\cup\{\mathtt{SampleFree}_{i}\}_{i=1,\ldots,n}; E←∅E\leftarrow\emptyset;

2
foreach v∈Vv\in V do
   
                3
U←𝙽𝚎𝚊𝚛⁡(G=(V,E),v,r)∖{v}U\leftarrow\mathtt{Near}(G=(V,E),v,r)\setminus\{v\};
   
                4
foreach u∈Uu\in U do
      
                5
if 𝙲𝚘𝚕𝚕𝚒𝚜𝚒𝚘𝚗𝙵𝚛𝚎𝚎⁡(v,u)\mathtt{CollisionFree}(v,u) then
E←E∪{(v,u),(u,v)}E\leftarrow E\cup\{(v,u),(u,v)\}

6
return G=(V,E)G=(V,E);
```

Practical implementation of the (s)PRM algorithm have often considered different choices for the
set $U$ of vertices to which connections are attempted (i.e., line [1](#algorithm1 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") in Algorithm [1](#algorithm1 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning"), and line [2](#algorithm2 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") in Algorithm [2](#algorithm2 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning")). In particular, the following criteria are of particular interest:

* •

  $k$-Nearest (s)PRM: Choose the nearest $k$ neighbors to the vertex under consideration, for a given $k$ (a typical value is reported as $k=15$ ([LaValle, 2006](#bib.bib62))). In other words, $U\leftarrow\mathtt{kNearest}(G=(V,E),x\_{\mathrm{rand}},k)$ in line [1](#algorithm1 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") of Algorithm [1](#algorithm1 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") and
  $U\leftarrow\mathtt{kNearest}(G=(V,E),v,k)\setminus\{v\}$
  in line [2](#algorithm2 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") of Algorithm [2](#algorithm2 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning"). The roadmap constructed in this way in an obstacle-free environment is a random $k$-nearest graph.
* •

  Bounded-degree (s)PRM: For any fixed $r$, the average number of connections attempted at each iteration is proportional to the number of vertices in $V$, and can result in an excessive computational burden for large $n$. To address this, an upper bound
  $k$ can be imposed on the cardinality of the set $U$ (a typical value is reported as $k=20$ ([LaValle, 2006](#bib.bib62))). In other words,
  $U\leftarrow\mathtt{Near}(G,x\_{\mathrm{rand}},r)\cap\mathtt{kNearest}(G,x\_{\mathrm{rand}},k)$ in line [1](#algorithm1 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") of Algorithm [1](#algorithm1 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning"), and
  $U\leftarrow(\mathtt{Near}(G,v,r)\cap\mathtt{kNearest}(G,v,k))\setminus\{v\}$ in line [2](#algorithm2 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") of Algorithm [2](#algorithm2 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning").
* •

  Variable-radius (s)PRM: Another option to maintain the degree of the vertices in the roadmap small is to make the connection radius $r$ a function of $n$, as opposed to a fixed parameter. However, there are no clear indications in the literature on the appropriate functional relationship between $r$ and $n$.

##### Rapidly-exploring Random Trees (RRT):

The Rapidly-exploring Random Tree algorithm is primarily aimed at single-query applications.
In its basic version, the algorithm incrementally builds a tree of feasible trajectories, rooted at the initial condition. An outline of the algorithm is given in Algorithm [3](#algorithm3 "In Rapidly-exploring Random Trees (RRT): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning").
The algorithm is initialized with a graph that includes the initial state as its single vertex, and no edges. At each iteration, a point $x\_{\mathrm{rand}}\in{\cal X}\_{\mathrm{free}}$ is sampled. An attempt is made to connect the nearest vertex $v\in V$ in the tree to the new sample. If such a connection is successful, $x\_{\mathrm{rand}}$ is added to the vertex set, and $(v,x\_{\mathrm{rand}})$ is added to the edge set. In the original version of this algorithm, the iteration is stopped as soon as the tree contains a node in the goal region. In this paper, for consistency with the other algorithms (e.g., PRM), the iteration is performed $n$ times. In the absence of obstacles, i.e., if ${\cal X}\_{\mathrm{free}}={\cal X}$, the tree constructed in this way is an online nearest neighbor graph.

Algorithm 3 RRT

```
1
V←{xinit}V\leftarrow\{x_{\mathrm{init}}\}; E←∅E\leftarrow\emptyset;

2
for i=1,…,ni=1,\ldots,n do
   
                3
xrand←𝚂𝚊𝚖𝚙𝚕𝚎𝙵𝚛𝚎𝚎ix_{\mathrm{rand}}\leftarrow{\tt SampleFree}_{i};
   
                4
xnearest←𝙽𝚎𝚊𝚛𝚎𝚜𝚝⁡(G=(V,E),xrand)x_{\mathrm{nearest}}\leftarrow\mathtt{Nearest}(G=(V,E),x_{\mathrm{rand}});
   
                5
xnew←𝚂𝚝𝚎𝚎𝚛⁡(xnearest,xrand)x_{\mathrm{new}}\leftarrow\mathtt{Steer}(x_{\mathrm{nearest}},x_{\mathrm{rand}}) ;
   
                6
if 𝙾𝚋𝚝𝚊𝚌𝚕𝚎𝙵𝚛𝚎𝚎⁡(xnearest,xnew)\mathtt{ObtacleFree}(x_{\mathrm{nearest}},x_{\mathrm{new}}) then
      
                7
V←V∪{xnew}V\leftarrow V\cup\{x_{\mathrm{new}}\};
E←E∪{(xnearest,xnew)}E\leftarrow E\cup\{(x_{\mathrm{nearest}},x_{\mathrm{new}})\} ;

8
return G=(V,E)G=(V,E);
```

A variant of RRT consists of growing two trees, respectively rooted at the initial state, and at a state in the goal set. To highlight the fact that the sampling procedure must not necessarily be stochastic, the algorithm is also referred to as Rapidly-exploring Dense Trees (RDT) ([LaValle, 2006](#bib.bib62)).

### 3.3 Proposed algorithms

In this section, the new algorithms considered in this paper are presented. These algorithms are proposed as asymptotically optimal and computationally efficient versions of their “standard” counterparts, as will be made clear through the analysis in the next section.
Input and output data are the same as in the algorithms introduced in Section [3.2](#S3.SS2 "3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning").

##### Optimal Probabilistic RoadMaps (PRM∗):

In the standard PRM algorithm, as well as in its simplified “batch” version considered in this paper, connections are attempted between roadmap vertices that are within a fixed radius $r$ from one another. The constant $r$ is thus a parameter of PRM.
The proposed algorithm—shown in Algorithm [4](#algorithm4 "In Optimal Probabilistic RoadMaps (PRM∗): ‣ 3.3 Proposed algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning")—is similar to sPRM, with the only difference being that the connection radius $r$ is chosen as a function of $n$, i.e., $r=r(n):=\gamma\_{\mathrm{PRM}}(\log(n)/n)^{1/d}$, where $\gamma\_{\mathrm{PRM}}>\gamma^{\*}\_{\mathrm{PRM}}=2(1+1/d)^{1/d}\left(\mu({\cal X}\_{\mathrm{free}})/\zeta\_{d}\right)^{1/d}$, $d$ is the dimension of the space ${\cal X}$, $\mu({\cal X}\_{\mathrm{free}})$ denotes the Lebesgue measure (i.e., volume) of the obstacle-free space, and $\zeta\_{d}$ is the volume of the unit ball in the $d$-dimensional Euclidean space. Clearly, the connection radius decreases with the number of samples. The rate of decay is such that the average number of connections attempted from a roadmap vertex is proportional to $\log(n)$.

Note that in the discussion of variable-radius PRM in [LaValle (2006)](#bib.bib62), it is suggested that the radius be chosen as a function of sample dispersion. (Recall that the dispersion of a point set contained in a bounded set $\mathcal{S}\subset\mathbb{R}^{d}$ is the radius of the largest empty ball centered in $\mathcal{S}$.)
Indeed, the dispersion of a set of $n$ random points sampled uniformly and independently in a bounded set is $O((\log(n)/n)^{1/d})$ ([Niederreiter, 1992](#bib.bib78)), which is precisely the rate at which the connection radius is scaled in the PRM∗ algorithm.

Algorithm 4 PRM∗

```
1
V←{xinit}∪{𝚂𝚊𝚖𝚙𝚕𝚎𝙵𝚛𝚎𝚎i}i=1,…,nV\leftarrow\{x_{\mathrm{init}}\}\cup\{\mathtt{SampleFree}_{i}\}_{i=1,\ldots,n}; E←∅E\leftarrow\emptyset;

2
foreach v∈Vv\in V do
   
                3
U←𝙽𝚎𝚊𝚛⁡(G=(V,E),v,γPRM​(log⁡(n)/n)1/d)∖{v}U\leftarrow\mathtt{Near}(G=(V,E),v,\gamma_{\mathrm{PRM}}(\log(n)/n)^{1/d})\setminus\{v\};
   
                4
foreach u∈Uu\in U do
      
                5
if 𝙲𝚘𝚕𝚕𝚒𝚜𝚒𝚘𝚗𝙵𝚛𝚎𝚎⁡(v,u)\mathtt{CollisionFree}(v,u) then
E←E∪{(v,u),(u,v)}E\leftarrow E\cup\{(v,u),(u,v)\}

6
return G=(V,E)G=(V,E);
```

Another version of the algorithm, called $k$-nearest PRM∗, can be considered, motivated by the $k$-nearest PRM implementation previously mentioned, whereby the number $k$ of nearest neighbors to be considered is not a constant, but is chosen as a function of the cardinality of the roadmap $n$. More precisely, $k(n):=k\_{\mathrm{PRM}}\log(n)$, where
$k\_{\mathrm{PRM}}>k^{\*}\_{\mathrm{PRM}}=e\,(1+1/d)$, and $U\leftarrow\mathtt{kNearest}(G=(V,E),v,k\_{\mathrm{PRM}}\log(n))\setminus\{v\}$ in line [4](#algorithm4 "In Optimal Probabilistic RoadMaps (PRM∗): ‣ 3.3 Proposed algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") of Algorithm [4](#algorithm4 "In Optimal Probabilistic RoadMaps (PRM∗): ‣ 3.3 Proposed algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning").

Note that $k^{\*}\_{\mathrm{PRM}}$ is a constant that only depends on $d$, and does not otherwise depend on the problem instance, unlike $\gamma^{\*}\_{\mathrm{PRM}}$. Moreover, $k\_{\mathrm{PRM}}=2e$ is a valid choice for all problem instances.

##### Rapidly-exploring Random Graph (RRG):

The Rapidly-exploring Random Graph algorithm was introduced as an incremental (as opposed to batch) algorithm to build a connected roadmap, possibly containing cycles.
The RRG algorithm is similar to RRT in that it first attempts to connect the nearest node to the new sample. If the connection attempt is successful, the new node is added to the vertex set.
However, RRG has the following difference. Every time a new point $x\_{\mathrm{new}}$ is added to the vertex set $V$, then connections are attempted from all other vertices in $V$ that are within a ball of radius $r(\operatorname{card}\left(V\right))=\min\{\gamma\_{\mathrm{RRG}}(\log(\operatorname{card}\left(V\right))/\operatorname{card}\left(V\right))^{1/d},\eta\}$, where $\eta$ is the constant appearing in the definition of the local steering function, and $\gamma\_{\mathrm{RRG}}>\gamma\_{\mathrm{RRG}}^{\*}=2\,(1+1/d)^{1/d}\left(\mu({\cal X}\_{\mathrm{free}})/\zeta\_{d}\right)^{1/d}$. For each successful connection, a new edge is added to the edge set $E$. Hence, it is clear that, for the same sampling sequence, the RRT graph (a directed tree) is a subgraph of the RRG graph (an undirected graph, possibly containing cycles). In particular, the two graphs share the same vertex set, and the edge set of the RRT graph is a subset of that of the RRG graph.

Algorithm 5 RRG

```
1
V←{xinit}V\leftarrow\{x_{\mathrm{init}}\}; E←∅E\leftarrow\emptyset;

2
for i=1,…,ni=1,\ldots,n do
   
                3
xrand←𝚂𝚊𝚖𝚙𝚕𝚎𝙵𝚛𝚎𝚎ix_{\mathrm{rand}}\leftarrow{\tt SampleFree}_{i};
   
                4
xnearest←𝙽𝚎𝚊𝚛𝚎𝚜𝚝⁡(G=(V,E),xrand)x_{\mathrm{nearest}}\leftarrow\mathtt{Nearest}(G=(V,E),x_{\mathrm{rand}});
   
                5
xnew←𝚂𝚝𝚎𝚎𝚛⁡(xnearest,xrand)x_{\mathrm{new}}\leftarrow\mathtt{Steer}(x_{\mathrm{nearest}},x_{\mathrm{rand}}) ;
   
                6
if 𝙾𝚋𝚝𝚊𝚌𝚕𝚎𝙵𝚛𝚎𝚎⁡(xnearest,xnew)\mathtt{ObtacleFree}(x_{\mathrm{nearest}},x_{\mathrm{new}}) then
      
                7
Xnear←𝙽𝚎𝚊𝚛⁡(G=(V,E),xnew,min⁡{γRRG​(log⁡(card⁡(V))/card⁡(V))1/d,η})X_{\mathrm{near}}\leftarrow\mathtt{Near}(G=(V,E),x_{\mathrm{new}},\min\{\gamma_{\mathrm{RRG}}(\log(\operatorname{card}\left(V\right))/\operatorname{card}\left(V\right))^{1/d},\eta\}) ;
      
                8
V←V∪{xnew}V\leftarrow V\cup\{x_{\mathrm{new}}\};
E←E∪{(xnearest,xnew),(xnew,xnearest)}E\leftarrow E\cup\{(x_{\mathrm{nearest}},x_{\mathrm{new}}),(x_{\mathrm{new}},x_{\mathrm{nearest}})\} ;
      
                9
foreach xnear∈Xnearx_{\mathrm{near}}\in X_{\mathrm{near}} do
         
                10
if 𝙲𝚘𝚕𝚕𝚒𝚜𝚒𝚘𝚗𝙵𝚛𝚎𝚎⁡(xnear,xnew)\mathtt{CollisionFree}(x_{\mathrm{near}},x_{\mathrm{new}}) then
E←E∪{(xnear,xnew),(xnew,xnear)}E\leftarrow E\cup\{(x_{\mathrm{near}},x_{\mathrm{new}}),(x_{\mathrm{new}},x_{\mathrm{near}})\}

11
return G=(V,E)G=(V,E);
```

Another version of the algorithm, called $k$-nearest RRG, can be considered, in which connections are sought to $k$ nearest neighbors, with $k=k(\operatorname{card}\left(V\right)):=k\_{\mathrm{RRG}}\log(\operatorname{card}\left(V\right))$, where $k\_{\mathrm{RRG}}>k^{\*}\_{\mathrm{RRG}}=e\,(1+1/d)$, and $X\_{\mathrm{near}}\leftarrow\mathtt{kNearest}(G=(V,E),x\_{\mathrm{new}},k\_{\mathrm{RRG}}\log(\operatorname{card}\left(V\right)))$, in line [5](#algorithm5 "In Rapidly-exploring Random Graph (RRG): ‣ 3.3 Proposed algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") of Algorithm [5](#algorithm5 "In Rapidly-exploring Random Graph (RRG): ‣ 3.3 Proposed algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning").

Note that $k^{\*}\_{\mathrm{RRG}}$ is a constant that depends only on $d$, and does not depend otherwise on the problem instance, unlike $\gamma^{\*}\_{\mathrm{RRG}}$. Moreover, $k\_{\mathrm{RRG}}=2e$ is a valid choice for all problem instances.

##### Optimal RRT (RRT∗):

Maintaining a tree structure rather than a graph is not only economical in terms of memory requirements, but may also be advantageous in some applications, due to,
for instance, relatively easy extensions to motion planning problems with differential constraints,
or to cope with modeling errors. The RRT∗ algorithm is obtained by modifying RRG in such a way that formation of cycles is avoided, by removing “redundant” edges, i.e., edges that are not part of a shortest path from the root of the tree (i.e., the initial state) to a vertex. Since the RRT and RRT∗ graphs are directed trees with the same root and vertex set, and edge sets that are subsets of that of RRG, this amounts to a “rewiring” of the RRT tree, ensuring that vertices are reached through a minimum-cost path.

Before discussing the algorithm, it is necessary to introduce a few new functions. Given two points $x\_{1},x\_{2}\in\mathbb{R}^{d}$, let ${\tt Line}(x\_{1},x\_{2}):[0,s]\to{\cal X}$ denote the straight-line path from $x\_{1}$ to $x\_{2}$. Given a tree $G=(V,E)$, let ${\tt Parent}:V\to V$ be a function that maps a vertex $v\in V$ to the unique vertex $u\in V$ such that $(u,v)\in E$. By convention, if $v\_{0}\in V$ is the root vertex of $G$, $\mathtt{Parent}(v\_{0})=v\_{0}$. Finally, let $\mathtt{Cost}:V\to\mathbb{R}\_{\geq 0}$ be a function that maps a vertex $v\in V$ to the cost of the unique path from the root of the tree to $v$. For simplicity, in stating the algorithm we will assume an additive cost function, so that
$\mathtt{Cost}(v)=\mathtt{Cost}(\mathtt{Parent}(v))+c(\mathtt{Line}(\mathtt{Parent}(v),v))$, although this is not necessary for the analysis in the next section.
By convention, if $v\_{0}\in V$ is the root vertex of $G$, then $\mathtt{Cost}(v\_{0})=0$.

Algorithm 6 RRT∗

```
1
V←{xinit}V\leftarrow\{x_{\mathrm{init}}\}; E←∅E\leftarrow\emptyset;

2
for i=1,…,ni=1,\ldots,n do
   
                3
xrand←𝚂𝚊𝚖𝚙𝚕𝚎𝙵𝚛𝚎𝚎ix_{\mathrm{rand}}\leftarrow{\tt SampleFree}_{i};
   
                4
xnearest←𝙽𝚎𝚊𝚛𝚎𝚜𝚝⁡(G=(V,E),xrand)x_{\mathrm{nearest}}\leftarrow\mathtt{Nearest}(G=(V,E),x_{\mathrm{rand}});
   
                5
xnew←𝚂𝚝𝚎𝚎𝚛⁡(xnearest,xrand)x_{\mathrm{new}}\leftarrow\mathtt{Steer}(x_{\mathrm{nearest}},x_{\mathrm{rand}}) ;
   
                6
if 𝙾𝚋𝚝𝚊𝚌𝚕𝚎𝙵𝚛𝚎𝚎⁡(xnearest,xnew)\mathtt{ObtacleFree}(x_{\mathrm{nearest}},x_{\mathrm{new}}) then
      
                7
Xnear←𝙽𝚎𝚊𝚛⁡(G=(V,E),xnew,min⁡{γRRT∗​(log⁡(card⁡(V))/card⁡(V))1/d,η})X_{\mathrm{near}}\leftarrow\mathtt{Near}(G=(V,E),x_{\mathrm{new}},\min\{\gamma_{\mathrm{RRT^{*}}}(\log(\operatorname{card}\left(V\right))/\operatorname{card}\left(V\right))^{1/d},\eta\}) ;
      
                8
V←V∪{xnew}V\leftarrow V\cup\{x_{\mathrm{new}}\};
      
                9
xmin←xnearestx_{\mathrm{min}}\leftarrow x_{\mathrm{nearest}}; cmin←𝙲𝚘𝚜𝚝⁡(xnearest)+c⁡(𝙻𝚒𝚗𝚎⁡(xnearest,xnew))c_{\mathrm{min}}\leftarrow\mathtt{Cost}(x_{\mathrm{nearest}})+c(\mathtt{Line}(x_{\mathrm{nearest}},x_{\mathrm{new}}));
      
                10
foreach xnear∈Xnearx_{\mathrm{near}}\in X_{\mathrm{near}} do  // Connect along a minimum-cost path
         
                11
if 𝙲𝚘𝚕𝚕𝚒𝚜𝚒𝚘𝚗𝙵𝚛𝚎𝚎⁡(xnear,xnew)∧𝙲𝚘𝚜𝚝⁡(xnear)+c⁡(𝙻𝚒𝚗𝚎⁡(xnear,xnew))<cmin\mathtt{CollisionFree}(x_{\mathrm{near}},x_{\mathrm{new}})\wedge\mathtt{Cost}(x_{\mathrm{near}})+c(\mathtt{Line}(x_{\mathrm{near}},x_{\mathrm{new}}))<c_{\mathrm{min}} then
            
                12
xmin←xnearx_{\mathrm{min}}\leftarrow x_{\mathrm{near}}; cmin←𝙲𝚘𝚜𝚝⁡(xnear)+c⁡(𝙻𝚒𝚗𝚎⁡(xnear,xnew))c_{\mathrm{min}}\leftarrow\mathtt{Cost}(x_{\mathrm{near}})+c(\mathtt{Line}(x_{\mathrm{near}},x_{\mathrm{new}}))
      
                13
E←E∪{(xmin,xnew)}E\leftarrow E\cup\{(x_{\mathrm{min}},x_{\mathrm{new}})\};
      
                14
foreach xnear∈Xnearx_{\mathrm{near}}\in X_{\mathrm{near}} do  // Rewire the tree
         
                15
if 𝙲𝚘𝚕𝚕𝚒𝚜𝚒𝚘𝚗𝙵𝚛𝚎𝚎⁡(xnew,xnear)∧𝙲𝚘𝚜𝚝⁡(xnew)+c⁡(𝙻𝚒𝚗𝚎⁡(xnew,xnear))<𝙲𝚘𝚜𝚝⁡(xnear)\mathtt{CollisionFree}(x_{\mathrm{new}},x_{\mathrm{near}})\wedge\mathtt{Cost}(x_{\mathrm{new}})+c(\mathtt{Line}(x_{\mathrm{new}},x_{\mathrm{near}}))<\mathtt{Cost}(x_{\mathrm{near}}) then
xparent←𝙿𝚊𝚛𝚎𝚗𝚝⁡(xnear)x_{\mathrm{parent}}\leftarrow\mathtt{Parent}(x_{\mathrm{near}});
         
                16
E←(E∖{(xparent,xnear)})∪{(xnew,xnear)}E\leftarrow(E\setminus\{(x_{\mathrm{parent}},x_{\mathrm{near}})\})\cup\{(x_{\mathrm{new}},x_{\mathrm{near}})\}

17
return G=(V,E)G=(V,E);
```

The RRT∗ algorithm, shown in Algorithm [6](#algorithm6 "In Optimal RRT (RRT∗): ‣ 3.3 Proposed algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning"), adds points to the vertex set $V$ in the same way as RRT and RRG. It also considers connections from the new vertex $x\_{\mathrm{new}}$ to vertices in $X\_{\mathrm{near}}$, i.e., other vertices that are within distance $r(\operatorname{card}\left(V\right))=\min\{\gamma\_{\mathrm{RRT^{\*}}}(\log(\operatorname{card}\left(V\right))/\operatorname{card}\left(V\right))^{1/d},\eta\}$ from $x\_{\mathrm{new}}$. However, not all feasible connections result in new edges being inserted in the edge set $E$. In particular, (i) an edge is created from the vertex in $X\_{\mathrm{near}}$ that can be connected to $x\_{\mathrm{new}}$ along a path with minimum cost, and (ii) new edges are created from $x\_{\mathrm{new}}$ to vertices in $X\_{\mathrm{near}}$, if the path through $x\_{\mathrm{new}}$ has lower cost than the path through the current parent; in this case, the edge linking the vertex to its current parent is deleted, to maintain the tree structure.

Another version of the algorithm, called $k$-nearest RRT∗, can be considered, in which connections are sought to $k$ nearest neighbors, with $k(\operatorname{card}\left(V\right))=k\_{\mathrm{RRG}}\log(\operatorname{card}\left(V\right))$, and
$X\_{\mathrm{near}}\leftarrow\mathtt{kNearest}(G=(V,E),x\_{\mathrm{new}},k\_{\mathrm{RRG}}\log(i))$,
in line [6](#algorithm6 "In Optimal RRT (RRT∗): ‣ 3.3 Proposed algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") of Algorithm [6](#algorithm6 "In Optimal RRT (RRT∗): ‣ 3.3 Proposed algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning").

## 4 Analysis

In this section, a number of results concerning the probabilistic completeness, asymptotic optimality, and complexity of the algorithms in Section [3](#S3 "3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") are presented.

The return value of Algorithms [1](#algorithm1 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning")-[6](#algorithm6 "In Optimal RRT (RRT∗): ‣ 3.3 Proposed algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") is a graph. Since the sampling procedure $\mathtt{SampleFree}$ is stochastic, the returned graph is in fact a random variable.22
2
We will not address the case in which the sampling procedure is deterministic, but refer the reader to [LaValle et al. (2004)](#bib.bib65), which contains an in-depth discussion of the relative merits of randomness and determinism in sampling-based motion planning algorithms.
Since the sampling procedure is modeled as a map from the sample space $\Omega$ to infinite sequences in $\mathcal{X}$, sets of vertices and edges of the graphs maintained by the algorithms can be defined as functions from the sample space $\Omega$ to appropriate sets.
More precisely, let ${\mathrm{ALG}}$ be a label indicating one of the algorithms in Section [3](#S3 "3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning"), and let $\{{V}^{\mathrm{ALG}}\_{i}(\omega)\}\_{i\in\mathbb{N}}$
and
$\{{E}^{\mathrm{ALG}}\_{i}(\omega)\}\_{i\in\mathbb{N}}$
be, respectively, the sets of vertices and edges in the graph returned by algorithm ${\mathrm{ALG}}$, indexed by the number of samples, for a particular realization of the sample sequence. (In other words, these are sequences of functions defined from $\Omega$ into finite subsets of ${\cal X}\_{\mathrm{free}}$ or ${\cal X}\_{\mathrm{free}}\times{\cal X}\_{\mathrm{free}}$.) Similarly, let ${G}^{\mathrm{ALG}}\_{i}=({V}^{\mathrm{ALG}}\_{i},{E}^{\mathrm{ALG}}\_{i})$. (The label ${\mathrm{ALG}}$ will be at times omitted when the algorithm being used is clear from the context.)

All algorithms considered in the paper are sound, in the sense that they only return graphs with vertices and edges representing points and paths in ${\cal X}\_{\mathrm{free}}$.This statement can be easily verified by inspection of the algorithms in Section [3](#S3 "3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning").

### 4.1 Probabilistic Completeness

In this section, the feasibility problem is considered, and the (probabilistic) completeness properties of the algorithms in Section [3](#S3 "3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") are analyzed.
First, some preliminary definitions are given, followed by a definition of probabilistic completeness. Then, completeness properties of various sampling-based motion planning algorithms are stated.

Let $\delta>0$ be a real number. A state $x\in{\cal X}\_{\mathrm{free}}$ is said to be a $\delta$-interior state of ${\cal X}\_{\mathrm{free}}$, if the closed ball of radius $\delta$ centered at $x$ lies entirely inside ${\cal X}\_{\mathrm{free}}$. The $\delta$-interior of ${\cal X}\_{\mathrm{free}}$, denoted as $\mathrm{int}\_{\delta}({\cal X}\_{\mathrm{free}})$, is defined as the collection of all $\delta$-interior states, i.e., $\mathrm{int}\_{\delta}({\cal X}\_{\mathrm{free}}):=\{x\in{\cal X}\_{\mathrm{free}}\,|\,{\cal B}\_{x,\delta}\subseteq{\cal X}\_{\mathrm{free}}\}$. In other words, the $\delta$-interior of ${\cal X}\_{\mathrm{free}}$ is the set of all states that are at least a distance $\delta$ away from any point in the obstacle set (see Figure [1](#S4.F1 "Figure 1 ‣ 4.1 Probabilistic Completeness ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning")).
A collision-free path $\sigma:[0,1]\to{\cal X}\_{\mathrm{free}}$ is said to have strong $\delta$-clearance, if $\sigma$ lies entirely inside the $\delta$-interior of ${\cal X}\_{\mathrm{free}}$, i.e., $\sigma(\tau)\in\mathrm{int}\_{\delta}({\cal X}\_{\mathrm{free}})$ for all $\tau\in[0,1]$.
A path planning problem $({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$ is said to be robustly feasible if there exists a path with strong $\delta$-clearance, for some $\delta>0$, that solves it.
In terms of the notation used in this paper, the notion of probabilistic completeness can be stated as follows.

###### Definition 14 (Probabilistic Completeness)

An algorithm ALG is probabilistically complete, if, for any robustly feasible path planning problem $({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$,

|  |  |  |
| --- | --- | --- |
|  | $\liminf\_{n\to\infty}\mathbb{P}\left(\{\exists x\_{\mathrm{goal}}\in V^{\mathrm{ALG}}\_{n}\cap{\cal X}\_{\mathrm{goal}}\mbox{ such that }x\_{\mathrm{init}}\mbox{ is connected to }x\_{\mathrm{goal}}\mbox{ in }G^{\mathrm{ALG}}\_{n}\ \}\right)=1.$ |  |

If an algorithm is probabilistically complete, and the path planning problem is robustly feasible, the limit

|  |  |  |
| --- | --- | --- |
|  | $\lim\nolimits\_{n\to\infty}\mathbb{P}\left(\{\exists x\_{\mathrm{goal}}\in V^{\mathrm{ALG}}\_{n}\cap{\cal X}\_{\mathrm{goal}}\mbox{ such that }x\_{\mathrm{init}}\mbox{ is connected to }x\_{\mathrm{goal}}\mbox{ in }G^{\mathrm{ALG}}\_{n}\ \}\right)$ |  |

exists and is equal to 1. On the other hand, the same limit is equal to zero for any sampling-based algorithm (including probabilistically complete ones) if the problem is not robustly feasible, unless the samples are drawn from a singular distribution adapted to the problem.

Figure 1: An illustration of the $\delta$-interior of ${\cal X}\_{\mathrm{free}}$. The obstacle region ${\cal X}\_{\mathrm{obs}}$ is shown in dark grey and the $\delta$-interior of ${\cal X}\_{\mathrm{free}}$ is shown in light grey. The distance between the dashed boundary of $\mathrm{int}\_{\delta}({\cal X}\_{\mathrm{free}})$ and the solid boundary of ${\cal X}\_{\mathrm{free}}$ is precisely $\delta$.

It is known from the literature that the sPRM and RRT algorithms are probabilistically complete, and that the probability of finding a solution if one exists approaches one exponentially fast with the number of vertices in the graph returned by the algorithms. In other words,

###### Theorem 15 (Probabilistic completeness of sPRM ([Kavraki et al., 1998](#bib.bib52)))

Consider a robustly feasible path planning problem $({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$. There exist constants $a>0$ and $n\_{0}\in\mathbb{N}$, dependent only on ${\cal X}\_{\mathrm{free}}$ and ${\cal X}\_{\mathrm{goal}}$, such that

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\exists\,x\_{\mathrm{goal}}\in V^{\mathrm{sPRM}}\_{n}\cap{\cal X}\_{\mathrm{goal}}:x\_{\mathrm{goal}}\mbox{ is connected to }x\_{\mathrm{init}}\mbox{ in }G^{\mathrm{sPRM}}\_{n}\right\}\right)>1-e^{-a\,n},\quad\forall n>n\_{0}.$ |  |

###### Theorem 16 (Probabilistic Completeness of RRT ([LaValle and Kuffner, 2001](#bib.bib63)))

Consider a robustly feasible path planning problem $({\cal X}\_{\mathrm{free}}$, $x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$. There exist constants $a>0$ and $n\_{0}\in\mathbb{N}$, both dependent only on ${\cal X}\_{\mathrm{free}}$ and ${\cal X}\_{\mathrm{goal}}$, such that

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{V^{\mathrm{RRT}}\_{n}\cap{\cal X}\_{\mathrm{goal}}\neq\emptyset\right\}\right)>1-e^{-a\,n},\quad\forall n>n\_{0}.$ |  |

On the other hand, the probabilistic completeness results do not necessarily extend to the heuristics used in practical implementations of the (s)PRM algorithm, as detailed in Section [3](#S3 "3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning"). For example, consider the $k$-nearest sPRM algorithm, where $k=1$. That is, each vertex is connected to its nearest neighbor and the resulting undirected graph is returned as the output. This sPRM algorithm will be called the 1-nearest sPRM, and indicated with the label $\mathrm{1PRM}$. The RRT algorithm can be thought of as the incremental version of the 1-nearest sPRM algorithm: the RRT algorithm also connects each sample to its nearest neighbor, but forces connectivity of the graph by an incremental construction. The following theorem shows that the 1-nearest sPRM algorithm is not probabilistically complete, although the RRT is (see Theorem [16](#Thmtheorem16 "Theorem 16 (Probabilistic Completeness of RRT ( , )) ‣ 4.1 Probabilistic Completeness ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning")).
Furthermore, the probability that it fails to find a path converges to one as the number of samples approaches infinity.

###### Theorem 17 (Incompleteness of $k$-nearest sPRM for $k=1$)

The $k$-nearest sPRM algorithm is not probabilistically complete for $k=1$. Furthermore,

|  |  |  |
| --- | --- | --- |
|  | $\lim\_{n\to\infty}\mathbb{P}\left(\{\exists x\_{\mathrm{goal}}\in V^{\mathrm{1PRM}}\_{n}\cap{\cal X}\_{\mathrm{goal}}\mbox{ such that }x\_{\mathrm{init}}\mbox{ is connected to }x\_{\mathrm{goal}}\mbox{ in }G^{\mathrm{ALG}}\_{n}\ \}\right)=0.$ |  |

The proof of this theorem requires two intermediate results that are provided below.
For simplicity of presentation, consider the case when ${\cal X}\_{\mathrm{free}}={\cal X}$.
Let $G^{1\mathrm{PRM}}\_{n}=(V^{1\mathrm{PRM}}\_{n},E^{1\mathrm{PRM}}\_{n})$ denote the graph returned by the 1-nearest sPRM algorithm, when the algorithm is run with $n$ samples. Let ${L}\_{n}$ denote the total length of all the edges present in $G^{1\mathrm{PRM}}\_{n}$. Recall that $\zeta\_{d}$ denotes the volume of the unit ball in the $d$-dimensional Euclidean space. Let $\zeta\_{d}^{\prime}$ denote the volume of the union of two unit balls whose centers are a unit distance apart.

###### Lemma 18 (Total length of the 1-nearest neighbor graph ([Wade, 2007](#bib.bib101)))

For all $d\geq 2$, ${L}\_{n}/n^{1-1/d}$ converges to a constant in mean square, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\lim\_{n\to\infty}\mathbb{E}\left[\left(\frac{{L}\_{n}}{n^{1-1/d}}-\left(1+\frac{1}{d}\right)\left(\frac{1}{\zeta\_{d}}-\frac{\zeta\_{d}}{2\,(\zeta\_{d}^{\prime})^{1+1/d}}\right)\right)^{2}\right]=0.$ |  |

###### Proof.

This lemma is a direct consequence of Theorem 3 of [Wade (2007)](#bib.bib101). ∎∎

Let $N\_{n}$ denote the number of connected components of $G^{1\mathrm{PRM}}\_{n}$.

###### Lemma 19 (Number of connected components of the 1-nearest neighbor graph)

For all $d\geq 2$, $N\_{n}/n$ converges to a constant in mean square, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\lim\_{n\to\infty}\mathbb{E}\left[\left(\frac{N\_{n}}{n}-\frac{\zeta\_{d}}{2\,\zeta\_{d}^{\prime}}\right)^{2}\right]=0.$ |  |

###### Proof.

A reciprocal pair is a pair of vertices each of which is the other one’s nearest neighbor. In a graph formed by connecting each vertex to its nearest neighbor, any connected component includes exactly one reciprocal pair whenever the number of vertices is greater than 2 ([Eppstein et al., 1997](#bib.bib30), see, e.g.,).
The number of reciprocal pairs in such a graph was shown to converge to $\zeta\_{d}/(2\zeta\_{d}^{\prime})$ in mean square in [Henze (1987)](#bib.bib39) (see also Remark 2 in [Wade (2007)](#bib.bib101)).
∎∎

###### Proof of Theorem [17](#Thmtheorem17 "Theorem 17 (Incompleteness of 𝑘-nearest sPRM for 𝑘=1) ‣ 4.1 Probabilistic Completeness ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").

Let $\widetilde{{L}}\_{n}$ denote the average length of a connected component in $G^{1\mathrm{PRM}}\_{n}$, i.e., $\widetilde{{L}}\_{n}={L}\_{n}/N\_{n}$.
Let ${L}\_{n}^{\prime}$ denote the length of the connected component that includes $x\_{\mathrm{init}}$. Since the samples are drawn independently and uniformly, the random variables $\widetilde{{L}}\_{n}$ and ${L}\_{n}^{\prime}$ have the same distribution (although they are clearly dependent).
Let $\gamma\_{L}$ denote the constant that ${L}\_{n}/n^{1-1/d}$ converges to (see Lemma [18](#Thmtheorem18 "Lemma 18 (Total length of the 1-nearest neighbor graph ( , )) ‣ 4.1 Probabilistic Completeness ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning")). Similarly, let $\gamma\_{N}$ denote the constant that $N\_{n}/n$ converges to (see Lemma [19](#Thmtheorem19 "Lemma 19 (Number of connected components of the 1-nearest neighbor graph) ‣ 4.1 Probabilistic Completeness ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning")).

Recall that convergence in mean square implies convergence in probability and hence convergence in distribution ([Grimmett and Stirzaker, 2001](#bib.bib36)). Since both ${L}\_{n}/n^{1-1/d}$ and $N\_{n}/n$ converge in mean square to constants and $\mathbb{P}(\{N\_{n}=0\})=0$ for all $n\in\mathbb{N}$, by Slutsky’s theorem ([Resnick, 1999](#bib.bib85)), $n^{1/d}\,\widetilde{{L}}\_{n}=\frac{{L}\_{n}/n^{1-1/d}}{N\_{n}/n}$ converges to $\gamma:=\gamma\_{L}/\gamma\_{N}$ in distribution. In this case, it also converges in probability, since $\gamma$ is a constant ([Grimmett and Stirzaker, 2001](#bib.bib36)). Then, $n^{1/d}\,{L}\_{n}^{\prime}$ also converges to $\gamma$ in probability, since $\widetilde{{L}}\_{n}$ and ${L}\_{n}^{\prime}$ are identically distributed for all $n\in\mathbb{N}$. Thus, ${L}^{\prime}\_{n}$ converges to $0$ in probability, i.e.,
$\lim\_{n\to\infty}\mathbb{P}\left(\left\{{L}\_{n}^{\prime}>\epsilon\right\}\right)=0$, for all $\epsilon>0$.

Let $\epsilon>0$ be such that $\epsilon<\inf\_{x\in{\cal X}\_{\mathrm{goal}}}\|x-x\_{\mathrm{init}}\|$.
Let $A\_{n}$ denote the event that the graph returned by the 1-nearest sPRM algorithm contains a feasible path, i.e., one that starts from $x\_{\mathrm{init}}$ and reaches the goal region
Clearly, the event $\{{L}^{\prime}\_{n}>\epsilon\}$ occurs whenever $A\_{n}$ does, i.e., $A\_{n}\subseteq\{{L}^{\prime}\_{n}>\epsilon\}$. Then, $\mathbb{P}(A\_{n})\leq\mathbb{P}(\{{L}^{\prime}\_{n}>\epsilon\})$. Taking the limit superior of both sides

|  |  |  |
| --- | --- | --- |
|  | $\liminf\_{n\to\infty}\mathbb{P}(A\_{n})\,\,\leq\,\,\limsup\_{n\to\infty}\mathbb{P}(A\_{n})\,\,\leq\,\,\limsup\_{n\to\infty}\mathbb{P}(\{{L}^{\prime}\_{n}>\epsilon\})\,\,=\,\,0.$ |  |

In other words, the limit $\lim\_{n\to\infty}\mathbb{P}(A\_{n})$ exists and is equal zero.
∎∎

Consider the variable-radius sPRM algorithm.
The following theorem asserts that variable-radius sPRM algorithm is not probabilistically complete in the subcritical regime.

###### Theorem 20 (Incompleteness of variable-radius sPRM with $r(n)=\gamma n^{-1/d}$)

There exists a constant $\gamma>0$ such that the variable radius sPRM with connection radius $r(n)=\gamma n^{-1/d}$ is not probabilistically complete.

The proof of this result requires some intermediate results from random geometric graph theory. Recall that $\lambda\_{c}$ is the critical density, or continuum percolation threshold (see Section [2.2](#S2.SS2 "2.2 Random Geometric Graphs ‣ 2 Preliminary Material ‣ Sampling-based Algorithms for Optimal Motion Planning")).
Given a Borel set $\Gamma\subseteq\mathbb{R}^{d}$, let $G^{\mathrm{disc}}\_{\Gamma}(n,r)$ denote the random $r$-disc graph formed with vertices independent and uniformly sampled from $\Gamma$ and edges connecting two vertices, $v$ and $v^{\prime}$, whenever $\|v-v^{\prime}\|<r\_{n}$.

###### Lemma 21 ([Penrose (2003)](#bib.bib79))

Let $\lambda\in(0,\lambda\_{c})$ and $\Gamma\subset\mathbb{R}^{d}$ be a Borel set.
Consider a sequence $\{r\_{n}\}\_{n\in\mathbb{N}}$ that satisfies $n\,r\_{n}^{d}\leq\lambda$, $\forall n\in\mathbb{N}$. Let $N\_{\mathrm{max}}(G^{\mathrm{disc}}\_{\Gamma}(n,r\_{n}))$ denote the size of the largest component in $G^{\mathrm{disc}}\_{\Gamma}(n,r\_{n})$.
Then, there exist constants $a,b>0$ and $m\_{0}\in\mathbb{N}$ such that for all $m\geq m\_{0}$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{N\_{\mathrm{max}}(G^{\mathrm{disc}}\_{\Gamma}(n,r\_{n}))\geq m\right\}\right)\leq n\left(e^{-a\,m}+e^{-b\,n}\right).$ |  |

###### Proof of Theorem [20](#Thmtheorem20 "Theorem 20 (Incompleteness of variable-radius sPRM with 𝑟(𝑛)=𝛾𝑛^{-1/𝑑}) ‣ 4.1 Probabilistic Completeness ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").

Let $\epsilon>0$ such that $\epsilon<\inf\_{x\in X\_{\mathrm{goal}}}\|x-x\_{\mathrm{init}}\|$ and that the $2\,\epsilon$-ball centered at $x\_{\mathrm{init}}$ lies entirely within the obstacle-free space.
Let $G\_{n}^{\mathrm{PRM}}=(V\_{n}^{\mathrm{PRM}},E\_{n}^{\mathrm{PRM}})$ denote the graph returned by this variable radius sPRM algorithm, when the algorithm is run with $n$ samples.
Let $G\_{n}=(V\_{n},E\_{n})$ denote the the restriction of $G\_{n}^{\mathrm{PRM}}$ to the $2\,\epsilon$-ball centered at $x\_{\mathrm{init}}$ defined as $V\_{n}=V\_{n}^{\mathrm{PRM}}\cap{\cal B}\_{x\_{\mathrm{init}},2\,\epsilon}$ and $E\_{n}=(V\_{n}\times V\_{n})\cap E\_{n}^{\mathrm{PRM}}$.

Clearly, $G\_{n}$ is equivalent to the random $r$-disc graph on $\Gamma={\cal B}\_{x\_{\mathrm{init}},2\,\epsilon}$.
Let $N\_{\mathrm{max}}(G\_{n})$ denote the number of vertices in the largest connected component of $G\_{n}$. By Lemma [21](#Thmtheorem21 "Lemma 21 ( ( ) ) ‣ 4.1 Probabilistic Completeness ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"), there exists constants $a,b>0$ and $m\_{0}\in\mathbb{N}$ such that

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}(\{N\_{\mathrm{max}}(G\_{n})\geq m\})\leq n\left(e^{-a\,m}+e^{-b\,n}\right),$ |  |

for all $m\geq m\_{0}$.
Then, for all $m=\lambda^{-1/d}\,(\epsilon/2)\,n^{1/d}>m\_{0}$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{N\_{\mathrm{max}}(G\_{n})\geq\lambda^{-1/d}\frac{\epsilon}{2}\,n^{1/d}\right\}\right)\leq n\left(e^{-a\,\lambda^{-1/d}\,(\epsilon/2)\,n^{1/d}}+e^{-b\,n}\right).$ |  |

Let ${L}\_{n}$ denote the total length of all the edges in the connected component that includes $x\_{\mathrm{init}}$. Since $r\_{n}=\lambda^{1/d}n^{-1/d}$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{{L}\_{n}\geq\frac{\epsilon}{2}\right\}\right)\leq n\left(e^{-a\,\lambda^{-1/d}\,(\epsilon/2)\,n^{1/d}}+e^{-b\,n}\right).$ |  |

Since the right hand side is summable, by the Borel-Cantelli lemma the event
$\left\{{L}\_{n}\geq\epsilon/2\right\}$
occurs infinitely often with probability zero, i.e., $\mathbb{P}(\limsup\_{n\to\infty}\{{L}\_{n}\geq\epsilon/2\})=0$.

Given a graph $G=(V,E)$ define the diameter of this graph as the distance between the farthest pair of vertices in $V$, i.e., $\max\_{v,v^{\prime}\in V}\|v-v^{\prime}\|$.
Let $D\_{n}$ denote the diameter of the largest component in $G\_{n}$. Clearly, $D\_{n}\leq{L}\_{n}$ holds surely. Thus, $\mathbb{P}\left(\limsup\_{n\to\infty}\left\{D\_{n}\geq\epsilon/2\right\}\right)=0$.

Let $I\in\mathbb{N}$ be the smallest number that satisfies $r\_{I}\leq\epsilon/2$.
Notice that the edges connected to the vertices $V\_{n}^{\mathrm{PRM}}\cap{\cal B}\_{x\_{\mathrm{init}},\epsilon}$ coincide with those connected to $V\_{n}\cap{\cal B}\_{x\_{\mathrm{init}},\epsilon}$, for all $n\geq I$.
Let $R\_{n}$ denote distance of the farthest vertex $v\in V\_{n}^{\mathrm{PRM}}$ to $x\_{\mathrm{init}}$ in the component that contains $x\_{\mathrm{init}}$ in $G\_{n}^{\mathrm{PRM}}$.
Notice also that $R\_{n}\geq\epsilon$ only if $D\_{n}\geq\epsilon/2$, for all $n\geq I$.
That is, for all $n\geq I$, $\left\{R\_{n}\geq\epsilon\right\}\subseteq\left\{D\_{n}\geq\epsilon/2\right\}$, which implies $\mathbb{P}\left(\limsup\_{n\to\infty}\left\{R\_{n}\geq\epsilon\right\}\right)=0$.

Let $A\_{n}$ denote the event that the graph returned by this variable radius sPRM algorithm includes a path that reaches the goal region. Clearly, $\{R\_{n}\geq\epsilon\}$ holds, whenever $A\_{n}$ holds. Hence, $\mathbb{P}(A\_{n})\leq\mathbb{P}(\{R\_{n}\geq\epsilon\})$. Taking the limit superior of both sides yields

|  |  |  |
| --- | --- | --- |
|  | $\liminf\_{n\to\infty}\mathbb{P}(A\_{n})\,\,\leq\,\,\limsup\_{n\to\infty}\mathbb{P}(A\_{n})\,\,\leq\,\,\limsup\_{n\to\infty}\mathbb{P}\left(\left\{R\_{n}\geq\epsilon\right\}\right)\,\,\leq\,\,\mathbb{P}\Big(\limsup\_{n\to\infty}\left\{R\_{n}\geq\epsilon\right\}\Big)=0.$ |  |

Hence, $\lim\_{n\to\infty}\mathbb{P}(A\_{n})=0$. ∎∎

Finally, the probabilistic completeness of the new algorithms proposed in Section [3](#S3 "3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") is established. Probabilistic completeness of PRM∗ is implied by its asymptotic optimality, proved in Section [4.2](#S4.SS2 "4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").

###### Theorem 22 (Completeness of PRM∗)

The PRM∗ algorithm is probabilistically complete.

Probabilistic completeness of RRG and RRT∗ is a straightforward consequence of the probabilistic completeness of RRT:

###### Theorem 23 (Probabilistic completeness of RRG and RRT∗)

The RRG and RRT∗ algorithms are probabilistically complete. Furthermore, for any robustly feasible path planning problem $({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$,
there exist constants $a>0$ and $n\_{0}\in\mathbb{N}$, both dependent only on ${\cal X}\_{\mathrm{free}}$ and ${\cal X}\_{\mathrm{goal}}$, such that

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{V^{\mathrm{RRG}}\_{n}\cap{\cal X}\_{\mathrm{goal}}\neq\emptyset\right\}\right)>1-e^{-a\,n},\quad\forall n>n\_{0},$ |  |

and

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{V^{\mathrm{RRT}^{\*}}\_{n}\cap{\cal X}\_{\mathrm{goal}}\neq\emptyset\right\}\right)>1-e^{-a\,n},\quad\forall n>n\_{0}.$ |  |

###### Proof.

By construction, $V^{\mathrm{RRG}}\_{n}(\omega)=V^{\mathrm{RRT}^{\*}}\_{n}(\omega)=V^{\mathrm{RRT}}\_{n}(\omega)$, for all $\omega\in\Omega$ and $n\in\mathbb{N}$. Moreover, the RRG and RRT∗ algorithms return connected graphs. Hence the result follows directly from the probabilistic completeness of RRT. ∎∎

In particular, note that if the RRT algorithm returns a feasible solution by iteration $n$,
so will the RRG and RRT∗ algorithms, assuming the same sample sequence.

### 4.2 Asymptotic Optimality

In this section, the optimality problem of path planning is considered. The algorithms presented in Section [3](#S3 "3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") are analyzed, in terms of their ability to return solutions whose cost converge to the global optimum. First, a definition of asymptotic optimality is provided as almost-sure convergence to optimal paths. Second, it is shown that the RRT algorithm lacks the asymptotic optimality property. Third, the PRM∗, RRG, and RRT∗ algorithms, as well as their $k$-nearest implementations, are shown to be asymptotically optimal.

Recall from Section [4.1](#S4.SS1 "4.1 Probabilistic Completeness ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") that an algorithm is probabilistically complete if the algorithm finds with high probability a solution to path planning problems that are robustly feasible, i.e., for which feasible path exists with strong $\delta$-clearance. A similar approach is used to define asymptotic optimality, relying on a notion of weak $\delta$-clearance and on a continuity property for the cost of paths, which will be introduced below.

Let $\sigma\_{1},\sigma\_{2}\in\Sigma\_{\mathrm{free}}$ be two collision-free paths with the same end points. A path $\sigma\_{1}$ is said to be homotopic to $\sigma\_{2}$, if there exists a continuous function $\psi:[0,1]\to\Sigma\_{\mathrm{free}}$, called the homotopy, such that $\psi(0)=\sigma\_{1}$, $\psi(1)=\sigma\_{2}$, and $\psi(\tau)$ is a collision-free path in for all $\tau\in[0,1]$. Intuitively, a path that is homotopic to $\sigma$ can be continuously transformed to $\sigma$ through ${\cal X}\_{\mathrm{free}}$  ([Munkres, 2000](#bib.bib76), see).
A collision-free path $\sigma:[0,s]\to{\cal X}\_{\mathrm{free}}$ is said to have weak $\delta$-clearance, if there exists a path $\sigma^{\prime}$ that has strong $\delta$-clearance and there exist a homotopy $\psi$, with $\psi(0)=\sigma$, $\psi(1)=\sigma^{\prime}$, and for all $\alpha\in(0,1]$ there exists $\delta\_{\alpha}>0$ such that $\psi(\alpha)$ has strong $\delta\_{\alpha}$-clearance. See Figure [2](#S4.F2 "Figure 2 ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") for an illustration of the weak $\delta$-clearance property.
A path that violates the weak $\delta$-clearance property is shown in Figure [3](#S4.F3 "Figure 3 ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").
Weak $\delta$-clearance does not require points along a path to be at least a distance $\delta$ away from the obstacles (see Figure [4](#S4.F4 "Figure 4 ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning")). In fact, a collision-free path with uncountably many points lying on the boundary of an obstacle can still have weak $\delta$-clearance.

Figure 2: An illustration of a path $\sigma$ with weak $\delta$-clearance. The path $\sigma^{\prime}$ that lies inside $\mathrm{int}\_{\delta}({\cal X}\_{\mathrm{free}})$ and is in the same homotopy class as $\sigma$ is also shown in the figure. Note that $\sigma$ does not have strong $\delta$-clearance.

Figure 3: An illustration of an example path $\sigma$ that does not have weak $\delta$-clearance. For any positive value of $\delta$, there is no path in $\mathrm{int}\_{\delta}({\cal X}\_{\mathrm{free}})$ that is in the same homotopy class as $\sigma$.

  

Figure 4: An illustration of a path that has weak $\delta$-clearance. The path passes through a point where two spheres representing the obstacle region are in contact. Clearly, the path does not have strong $\delta$-clearance.

Next, the set of all paths with bounded length is introduced as a normed space, which allows taking the limit of a sequence of paths.
Recall that $\Sigma$ is the set of all paths, and $TV(\cdot)$ denotes the total variation, i.e., the length, of a path (see Section [2.1](#S2.SS1 "2.1 Problem Formulation ‣ 2 Preliminary Material ‣ Sampling-based Algorithms for Optimal Motion Planning")). Given $\sigma\_{1},\sigma\_{2}\in\Sigma$ with $\sigma\_{1}:[0,1]\to{\cal X}$ and $\sigma\_{2}:[0,1]\to{\cal X}$, the addition operation is defined as $(\sigma\_{1}+\sigma\_{2})(\tau)=\sigma\_{1}(\tau)+\sigma\_{2}(\tau)$ for all $\tau\in[0,1]$.
The set of paths $\Sigma$ is closed under addition. Given a path $\sigma:[0,1]\to{\cal X}$ and a scalar $\alpha\in\mathbb{R}$, the multiplication by a scalar operation is defined as $(\alpha\sigma)(\tau):=\alpha\,\sigma(\tau)$ for all $\tau\in[0,1]$. With these addition and multiplication by a scalar operations, the function space $\Sigma$ is, in fact, a vector space.
On the vector space $\Sigma$, define the norm $\|\sigma\|\_{\mathrm{BV}}:=\int\_{0}^{1}|\sigma(\tau)|\;d\tau+\mathrm{TV}(\sigma)$, and denote the function space $\Sigma$ endowed with the norm $\|\cdot\|\_{\mathrm{BV}}$ by $\mathrm{BV}({\cal X})$.
The norm $\|\cdot\|\_{\mathrm{BV}}$ induces the following distance function:

|  |  |  |
| --- | --- | --- |
|  | $\mathrm{dist}(\sigma\_{1},\sigma\_{2})=\|\sigma\_{1}-\sigma\_{2}\|\_{\mathrm{BV}}=\int\_{0}^{1}\big\|(\sigma\_{1}-\sigma\_{2})(\tau)\big\|d\tau+\mathrm{TV}(\sigma\_{1}-\sigma\_{2})$ |  |

where $\|\cdot\|$ is the usual Euclidean norm.
A sequence $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$ of paths is said to converge to a path $\bar{\sigma}$, denoted as $\lim\_{n\to\infty}\sigma\_{n}=\bar{\sigma}$, if the norm of the difference between $\sigma\_{n}$ and $\bar{\sigma}$ converges to zero, i.e., $\lim\_{n\to\infty}\|\sigma\_{n}-\bar{\sigma}\|\_{\mathrm{BV}}=0$.

A feasible path $\sigma^{\*}\in{\cal X}\_{\mathrm{free}}$ that solves the optimality problem (Problem [3](#Thmtheorem3 "Problem 3 (Optimal path planning) ‣ 2.1 Problem Formulation ‣ 2 Preliminary Material ‣ Sampling-based Algorithms for Optimal Motion Planning")) is said to be a robustly optimal solution if it has weak $\delta$-clearance and, for any sequence of collision-free paths $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$, $\sigma\_{n}\in{\cal X}\_{\mathrm{free}}$, $\forall n\in\mathbb{N}$, such that $\lim\_{n\to\infty}\sigma\_{n}=\sigma^{\*}$, $\lim\_{n\to\infty}c(\sigma\_{n})=c(\sigma^{\*})$.
Clearly, a path planning problem that has a robustly optimal solution is necessarily robustly feasible. Let $c^{\*}=c(\sigma^{\*})$ be the cost of an optimal path, and let ${Y}\_{n}^{\mathrm{ALG}}$ be the extended random variable corresponding to the cost of the minimum-cost solution included in the graph returned by ${\mathrm{ALG}}$ at the end of iteration $n$.

###### Definition 24 (Asymptotic Optimality)

An algorithm ALG is asymptotically optimal if, for any path planning problem $({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$ and cost function $c:\Sigma\to\mathbb{R}\_{\geq 0}$ that admit a robustly optimal solution with finite cost $c^{\*}$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\limsup\_{n\to\infty}{Y}\_{n}^{\mathrm{ALG}}=c^{\*}\right\}\right)=1.$ |  |

Note that, since ${Y}\_{n}^{\mathrm{ALG}}\geq c^{\*}$, $\forall n\in\mathbb{N}$, asymptotic optimality of ${\mathrm{ALG}}$ implies that the limit $\lim\nolimits\_{n\to\infty}{Y}^{\mathrm{ALG}}\_{n}$ exists, and is equal to $c^{\*}$. Clearly, probabilistic completeness is necessary for asymptotic optimality. Moreover, the probability that a sampling-based algorithm converges to an optimal solution almost surely has probability either zero or one. That is, a sampling-based algorithm either converges to the optimal solution in almost all runs, or the convergence does not occur in almost all runs.

###### Lemma 25

Given that $\limsup\_{n\to\infty}Y\_{n}^{\mathrm{ALG}}<\infty$, i.e., ${\mathrm{ALG}}$ finds a feasible solution eventually, the probability that $\limsup\nolimits\_{n\to\infty}Y\_{n}^{\mathrm{ALG}}=c^{\*}$ is either zero or one.

###### Proof.

Conditioning on the event $\{\limsup\_{n\to\infty}Y\_{n}^{\mathrm{ALG}}<\infty\}$ ensures that $Y\_{n}^{\mathrm{ALG}}$ is finite, thus a random variable, for all large $n$.
Given a sequence $\{Y\_{n}\}\_{n\in\mathbb{N}}$ of random variables, let ${\cal F}\_{m}^{\prime}$ denote the $\sigma$-field generated by the sequence $\{Y\_{n}\}\_{n=m}^{\infty}$ of random variables.
The tail $\sigma$-field ${\cal T}$ is defined as ${\cal T}=\bigcap\_{n\in\mathbb{N}}{\cal F}\_{n}^{\prime}$.
An event $A$ is said to be a tail event if $A\in{\cal T}$. Any tail event occurs with probability either zero or one by the Kolmogorov zero-one law ([Resnick, 1999](#bib.bib85)).
Consider the sequence $\{Y\_{n}^{\mathrm{ALG}}\}\_{n\in\mathbb{N}}$ of random variables. Let ${\cal F}\_{m}^{\prime}$ denote the $\sigma$-fields generated by $\{Y\_{n}^{\mathrm{ALG}}\}\_{n=m}^{\infty}$. Then,
$\left\{\limsup\nolimits\_{n\to\infty}Y\_{n}^{\mathrm{ALG}}=c^{\*}\right\}=\left\{\limsup\nolimits\_{n\to\infty,\,n\geq m}Y\_{n}^{\mathrm{ALG}}=c^{\*}\right\}\in{\cal F}\_{m}^{\prime}\mbox{ for all }n\in\mathbb{N}.$
Hence, $\left\{Y\_{n}^{\mathrm{ALG}}=c^{\*}\right\}\in\bigcap\_{n\in\mathbb{N}}{\cal F}\_{m}^{\prime}$ is a tail event. The result follows by the Kolmogorov zero-one law.∎∎

Among the first steps in assessing the asymptotic optimality properties of an algorithm ${\mathrm{ALG}}$ is determining whether the limit $\lim\nolimits\_{n\to\infty}Y\_{n}^{\mathrm{ALG}}$ exists. It turns out that if the graphs returned by ${\mathrm{ALG}}$ satisfy a monotonicity property, then the limit exists, and is in general a random variable, indicated with $Y\_{\infty}^{\mathrm{ALG}}$.

###### Lemma 26

If $G\_{i}^{\mathrm{ALG}}(\omega)\subseteq G\_{i+1}^{\mathrm{ALG}}(\omega)$, $\forall\omega\in\Omega$ and $\forall i\in\mathbb{N}$, then
$\lim\_{n\to\infty}Y\_{n}^{\mathrm{ALG}}(\omega)=Y^{\mathrm{ALG}}\_{\infty}(\omega).$

###### Proof.

Since $G\_{i}^{\mathrm{ALG}}(\omega)\subseteq G\_{i+1}^{\mathrm{ALG}}(\omega)$, then $Y\_{i+1}^{\mathrm{ALG}}(\omega)\leq Y\_{i}^{\mathrm{ALG}}(\omega)$, for all $\omega\in\Omega$. Since $Y\_{i}^{\mathrm{ALG}}\geq c^{\*}$, then the sequence converges to some limiting value, dependent on $\omega$, i.e., $Y\_{\infty}^{\mathrm{ALG}}(\omega)$.∎∎

Of the algorithms presented in Section [3](#S3 "3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning"), it is easy to check that PRM, sPRM, RRT, RRG, and RRT∗ satisfy the monotonicity property in Lemma [26](#Thmtheorem26 "Lemma 26 ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").
On the other hand, $k$-nearest sPRM and PRM∗ do not: in these cases, the random variable $Y^{\mathrm{ALG}}\_{i+1}$ is not necessarily dominated by $Y^{\mathrm{ALG}}\_{i}$. This is evident in numerical experiments,
e.g., see Figures [10](#S5.F10 "Figure 10 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning") and [11](#S5.F11 "Figure 11 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning") in Section [5](#S5 "5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning").

In order to avoid trivial cases of asymptotic optimality, it is necessary to rule out problems in which optimal solutions can be computed after a finite number of samples.
Let $\Sigma^{\*}$ denote the set of all optimal paths, i.e., the set of all paths that solve the
optimal planning problem (Problem [3](#Thmtheorem3 "Problem 3 (Optimal path planning) ‣ 2.1 Problem Formulation ‣ 2 Preliminary Material ‣ Sampling-based Algorithms for Optimal Motion Planning")), and ${\cal X}\_{\mathrm{opt}}$ denote the set
of states that an optimal path in $\Sigma^{\*}$ passes through, i.e.,

|  |  |  |
| --- | --- | --- |
|  | ${\cal X}\_{\mathrm{opt}}=\{x\in X\_{\mathrm{free}}\,|\,\exists\sigma^{\*}\in\Sigma^{\*},\tau\in[0,1]\mbox{ such that }x=\sigma^{\*}(\tau)\}.$ |  |

###### Assumption 27 (Zero-measure Optimal Paths)

The set of all points traversed by an optimal trajectory has measure
zero, i.e., $\mu\left({\cal X}\_{\mathrm{opt}}\right)=0$.

Most cost functions and problem instances of interest satisfy this assumption, including, e.g., the Euclidean length of the path when the goal region is convex. This assumption does not imply that there is a single optimal path; indeed, there are problem instances with uncountably many optimal paths, for which Assumption [27](#Thmtheorem27 "Assumption 27 (Zero-measure Optimal Paths) ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") holds. (A simple example is the motion planning problem in three dimensional Euclidean space where a ball shaped obstacle is placed between the initial state and the goal region.)
Assumption [27](#Thmtheorem27 "Assumption 27 (Zero-measure Optimal Paths) ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") implies that no sampling-based planning algorithm can find a solution to the optimality problem in a finite number of iterations.

###### Lemma 28

If Assumption [27](#Thmtheorem27 "Assumption 27 (Zero-measure Optimal Paths) ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") holds, the probability that a sampling-based algorithm ${\mathrm{ALG}}$ returns a graph containing an optimal path at a finite iteration $n\in\mathbb{N}$
is zero, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\cup\_{n\in\mathbb{N}}\{{Y}^{\mathrm{ALG}}\_{n}=c^{\*}\}\right)=0.$ |  |

###### Proof.

Let $B\_{n}$ denote the event that ${\mathrm{ALG}}$ constructs a graph containing a path with cost exactly equal to $c^{\*}$ at the end of iteration $i$, i.e., $B\_{n}=\{{Y}^{\mathrm{ALG}}\_{n}=c^{\*}\}$. Let $B$ denote the event that
${\mathrm{ALG}}$ returns a graph containing a path that costs exactly $c^{\*}$ at some finite iteration $i$. Then, $B$ can be written as $B=\cup\_{n\in\mathbb{N}}B\_{n}$. Since $B\_{n}\subseteq B\_{n+1}$, by monotonocity of measures, $\lim\_{i\to\infty}\mathbb{P}(B\_{n})=\mathbb{P}(B)$. By Assumption [27](#Thmtheorem27 "Assumption 27 (Zero-measure Optimal Paths) ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") and the definition of the sampling procedure, $\mathbb{P}(B\_{n})=0$ for all $n\in\mathbb{N}$, since the probability that the set $\bigcup\_{i=1}^{n}\{{\tt SampleFree}(i)\}$ of points contains a point from a zero-measure set is zero. Hence, $\mathbb{P}(B)=0$.
∎∎

In the remainder of the paper, it will be tacitly assumed that Assumption [27](#Thmtheorem27 "Assumption 27 (Zero-measure Optimal Paths) ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"), and hence Lemma [28](#Thmtheorem28 "Lemma 28 ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"), hold.

#### 4.2.1 Existing algorithms

The algorithms in Section [3.2](#S3.SS2 "3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") were originally introduced to efficiently solve the feasibility problem, relaxing the completeness requirement to probabilistic completeness. Nevertheless, it is of interest to establish whether these algorithms are asymptotically optimal in addition to being probabilistically complete. (The first two results in this section rely on results that will be proven in Section [4.2.2](#S4.SS2.SSS2 "4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"), i.e., the fact that the RRT algorithm is not asymptotically optimal, and the PRM∗ algorithm is asymptotically optimal)

First, consider the PRM algorithm and its variants. The PRM algorithm, in its original form, is not asymptotically optimal.

###### Theorem 29 (Non-optimality of PRM)

The PRM algorithm is not asymptotically optimal.

###### Proof.

The proof is based on a counterexample, establishing a form of equivalence between PRM and RRT, which in turn will be proven not to be asymptotically optimal in Theorem [33](#Thmtheorem33 "Theorem 33 (Non-optimality of RRT) ‣ Rapidly-exploring Random Trees ‣ 4.2.1 Existing algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").
Consider a convex obstacle-free environment, e.g.,
${\cal X}\_{\mathrm{free}}={\cal X}$, and choose the connection radius for PRM and the steering parameter for RRT such that $r,\eta>\mathrm{diam}({\cal X})$. At each iteration, exactly one vertex and one edge is added to the graph, since (i) all connection attempts using the local planner (e.g., straight line connections as considered in this paper) are collision-free, and (ii) at the end of each iteration, the graph is connected (i.e., it contains only one connected component). In particular, the graph returned by the PRM algorithm in this case is a tree, and the arborescence obtained by choosing as the root the first sample point, i.e., $\mathtt{SampleFree}\_{0}$, is an online nearest-neighbor graph (see Section [2.2](#S2.SS2 "2.2 Random Geometric Graphs ‣ 2 Preliminary Material ‣ Sampling-based Algorithms for Optimal Motion Planning")) coinciding with the graph returned by RRT with the random initial condition $x\_{\mathrm{init}}=\mathtt{SampleFree}\_{0}$.

Recall that the PRM algorithm is applicable for multiple-query planning problems: in other words, the graph returned by the PRM algorithm is used to solve path planning problems from arbitrary $x\_{\mathrm{init}}\in{\cal X}\_{\mathrm{free}}$ and ${\cal X}\_{\mathrm{goal}}\subset{\cal X}\_{\mathrm{free}}$. (Note that all such problems admit robust optimal solutions.) In particular, for $x\_{\mathrm{init}}=\mathtt{SampleFree}\_{0}$, and any $X\_{\mathrm{goal}}$, then $Y\_{n}^{\mathrm{PRM}}(\omega)=Y\_{n}^{\mathrm{RRT}}(\omega)$, for all $\omega\in\Omega$, $n\in\mathbb{N}$. In particular, since both PRM and RRT satisfy the monotonicity condition in Lemma [26](#Thmtheorem26 "Lemma 26 ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"), Theorem [33](#Thmtheorem33 "Theorem 33 (Non-optimality of RRT) ‣ Rapidly-exploring Random Trees ‣ 4.2.1 Existing algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") implies that

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\limsup\_{n\to\infty}Y\_{n}^{\mathrm{PRM}}=c^{\*}\right\}\right)=\mathbb{P}\left(\left\{\lim\_{n\to\infty}Y\_{n}^{\mathrm{PRM}}=c^{\*}\right\}\right)=\mathbb{P}\left(\left\{\lim\_{n\to\infty}Y\_{n}^{\mathrm{RRT}}=c^{\*}\right\}\right)=0.$ |  |

∎∎

The lack of asymptotic optimality of PRM is due to its incremental construction, coupled with the constraint eliminating edges making unnecessary connections within a connected component.
Such a constraint is not present in the batch construction of the sPRM algorithm, which is indeed asymptotically optimal (at the expense of computational complexity, see Section [4.3](#S4.SS3 "4.3 Computational Complexity ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning")).

###### Theorem 30 (Asymptotic Optimality of sPRM)

The sPRM algorithm is asymptotically optimal.

###### Proof.

By construction, $V\_{n}^{\mathrm{sPRM}}(\omega)=V\_{n}^{\mathrm{PRM}^{\*}}(\omega)$, and $E\_{n}^{\mathrm{sPRM}}(\omega)\supseteq E\_{n}^{\mathrm{PRM}^{\*}}(\omega)$ for all $\omega\in\Omega$. Hence, the graph returned by sPRM includes all the paths that are present in the graph returned by PRM∗. Then, asymptotic optimality of sPRM follows from that of PRM∗, which will be proven in Theorem [34](#Thmtheorem34 "Theorem 34 (Asymptotic optimality of PRM∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").
∎∎

On the other hand, as in the case of probabilistic completeness, the heuristics that are often used in the practical implementation of (s)PRM are not asymptotically optimal.

###### Theorem 31 (Non-optimality of $k$-nearest sPRM)

The $k$-nearest sPRM algorithm is not asymptotically optimal, for any constant $k\in\mathbb{N}$.

This theorem will be proven under the assumption that the underlying point process is Poisson. More precisely, the algorithm is analyzed when it is run with $\mathrm{Poisson}(n)$ samples. That is, the realization of the random variable $\mathrm{Poisson}(n)$ determines the number of points sampled independently and uniformly in ${\cal X}\_{\mathrm{free}}$. Hence, the expected number of samples is equal to $n$, although its realization may slightly differ. However, since the Poisson random variable has exponentially-decaying tails, its large deviations from its mean is unlikely (see, e.g., [Grimmett and Stirzaker (2001)](#bib.bib36) for a more precise statement). With a slight abuse of notation, the cost of the best path in the graph returned by the $k$-nearest sPRM algorithm when the algorithm is run with $\mathrm{Poisson}(n)$ number of samples is denoted by $Y\_{n}^{k\mathrm{PRM}}$, and
it is shown that $\mathbb{P}(\{\limsup\_{n\to\infty}Y\_{n}^{k\mathrm{PRM}}=c^{\*}\})=0$.

###### Proof of Theorem [31](#Thmtheorem31 "Theorem 31 (Non-optimality of 𝑘-nearest sPRM) ‣ 4.2.1 Existing algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").

Let $\sigma^{\*}$ denote an optimal path and $s^{\*}$ denote its length, i.e., $s^{\*}=TV(\sigma^{\*})$. For each $n$, consider a tiling of $\sigma^{\*}$ with disjoint open hypercubes, each with edge length $2\,n^{-1/d}$, such that the center of each cube is a point on $\sigma^{\*}$. See Figure [5](#S4.F5 "Figure 5 ‣ Proof of Theorem . ‣ 4.2.1 Existing algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"). Let $M\_{n}$ denote the maximum number of tiles that can be generated in this manner and note
$M\_{n}\geq\frac{s^{\*}}{2}\,n^{1/d}.$
Partition each tile into several open cubes as follows: place an inner cube with edge length $n^{-1/d}$ at the center of the tile and place several outer cubes each with edge length $\frac{1}{2}\,n^{-1/d}$ around the cube at the center as shown in Figure [5](#S4.F5 "Figure 5 ‣ Proof of Theorem . ‣ 4.2.1 Existing algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").
Let $F\_{d}$ denote the number of outer cubes.
The volumes of the inner cube and each of the outer cubes are $n^{-1}$ and $2^{-d}\,n^{-1}$, respectively.

Figure 5: An illustration of the tiles mention in the proof of Theorem [31](#Thmtheorem31 "Theorem 31 (Non-optimality of 𝑘-nearest sPRM) ‣ 4.2.1 Existing algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"). A single tile is shown in the left; a tiling of the optimal trajectory $\sigma^{\*}$ is shown on the right.

For $n\in\mathbb{N}$ and $m\in\{1,2,\dots,M\_{n}\}$, consider the tile $m$ when the algorithm is run with $\mathrm{Poisson}(n)$ samples. Let $I\_{n,m}$ denote the indicator random variable for the event that the center cube of this tile contains no samples, whereas every outer cube contains at least $k+1$ samples, in tile $m$.

The probability that the inner cube contains no samples is $e^{-1/\mu({\cal X}\_{\mathrm{free}})}$. The probability that an outer cube contains at least $k+1$ samples is $1-\mathbb{P}\left(\{\mathrm{Poisson}{(2^{-d}/\mu({\cal X}\_{\mathrm{free}}))}\geq k+1\}\right)=1-\mathbb{P}(\{\mathrm{Poisson}{(2^{-d}/\mu({\cal X}\_{\mathrm{free}}))}\leq k\})=1-\frac{\Gamma(k+1,2^{-d}/\mu({\cal X}\_{\mathrm{free}}))}{k!}$, where $\Gamma(\cdot,\cdot)$ is the incomplete gamma function ([Abramowitz and Stegun, 1964](#bib.bib1)).
Then, noting that the cubes in a given tile are disjoint and using the independence property of the Poisson process (see Lemma [11](#Thmtheorem11 "Lemma 11 ( ( ) ) ‣ 2.2 Random Geometric Graphs ‣ 2 Preliminary Material ‣ Sampling-based Algorithms for Optimal Motion Planning")),

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}\left[I\_{n,m}\right]\,\,=\,\,e^{-1/\mu({\cal X}\_{\mathrm{free}})}\,\left(1-\frac{\Gamma(k+1,2^{-d}/\mu({\cal X}\_{\mathrm{free}}))}{k!}\right)^{F\_{d}}\,\,>\,\,0,$ |  |

which is a constant that is independent of $n$; denote this constant by $\alpha$.

Let $G\_{n}=(V\_{n},E\_{n})$ denote the graph returned by the $k$-nearest PRM algorithm by the end of $\mathrm{Poisson}(n)$ iterations. Observe that if $I\_{n,m}=1$, then there is no edge of $G\_{n}$ crossing the cube of side length $\frac{1}{2}\,n^{-1/d}$ that is centered at the center of the inner cube in tile $m$ (shown as the white cube in Figure [6](#S4.F6 "Figure 6 ‣ Proof of Theorem . ‣ 4.2.1 Existing algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning")). To prove this claim, note the following two facts. First, no point that is outside of the cubes can have an edge that crosses the inner cube. Second, no point in one of the outer cubes has an edge that has length greater than $\frac{\sqrt{d}}{2}\,i^{-1/d}$. Thus, no edge can cross the white cube illustrated in Figure [6](#S4.F6 "Figure 6 ‣ Proof of Theorem . ‣ 4.2.1 Existing algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").

Figure 6: The event that the inner cube contains no points and each outer cube contains at least $k$ points of the point process is illustrated. The cube of side length $\frac{1}{2}\,n^{-1/d}$ is shown in white.

Let $\sigma\_{n}$ denote the path in $G\_{n}$ that is closest to $\sigma^{\*}$ in terms of the bounded variation norm. Let $U\_{n}:=\|\sigma\_{n}-\sigma^{\*}\|\_{\mathrm{BV}}$. Notice that $U\_{n}\geq\frac{1}{2}\,n^{-1/d}\,\sum\_{m=1}^{M\_{n}}I\_{n,m}=\frac{1}{2}\,n^{-1/d}\,M\_{n}\,I\_{n,1}=\frac{s^{\*}}{4}I\_{n,1}$. Then,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}\left[\limsup\_{n\to\infty}U\_{n}\right]\,\,\geq\,\,\limsup\_{n\to\infty}\mathbb{E}\left[U\_{n}\right]\,\,\geq\,\,\limsup\_{n\to\infty}\frac{s^{\*}}{4}\,\mathbb{E}\left[I\_{n,m}\right]\,\,\geq\,\,\frac{\alpha\,s^{\*}}{4}\,\,>\,\,0,$ |  |

where the first inequality follows from Fatou’s lemma ([Resnick, 1999](#bib.bib85)). This implies $\mathbb{P}(\{\limsup\_{n\to\infty}U\_{n}>0\})>0$. Since $U\_{i}>0$ implies $Y\_{n}>c^{\*}$ surely,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\limsup\nolimits\_{n\to\infty}Y\_{n}>c^{\*}\right\}\right)\geq\mathbb{P}\left(\left\{\limsup\nolimits\_{n\to\infty}U\_{n}>0\right\}\right)>0.$ |  |

That is, $\mathbb{P}\left(\left\{\limsup\nolimits\_{n\to\infty}Y\_{n}=c^{\*}\right\}\right)<1$. In fact, by Lemma [25](#Thmtheorem25 "Lemma 25 ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"), $\mathbb{P}\left(\left\{\limsup\nolimits\_{n\to\infty}Y\_{n}=c^{\*}\right\}\right)=0$.∎∎

Second, asymptotic optimality of a large class of variable radius sPRM algorithms is considered.
Consider a variable radius sPRM in which connection radius satisfies $r(n)\leq\gamma\,n^{-1/d}$ for some $\gamma>0$ and for all $n\in\mathbb{N}$. The next theorem shows that this algorithm lacks the asymptotic optimality property.

###### Theorem 32 (Non-optimality of variable radius sPRM with $r(n)=\gamma\,n^{-1/d}$)

Consider a variable radius sPRM algorithm with connection radius
$r(n)=\gamma\,n^{-1/d}.$
This sPRM algorithm is not asymptotic optimal for any $\gamma\in\mathbb{R}\_{\geq 0}$.

###### Proof.

Let $\sigma^{\*}$ denote a path that is a robust solution to the optimality problem.
Let $n$ denote the number of samples that the algorithm is run with.
For all $n$, construct a set $B\_{n}=\{B\_{n,1},B\_{n,2},\dots,B\_{n,M\_{n}}\}$ of openly disjoint balls as follows. Each ball in $B\_{n}$ has radius $r\_{n}=\gamma\,n^{-1/d}$, and lies entirely inside ${\cal X}\_{\mathrm{free}}$. Furthermore, the balls in $B\_{n}$ “tile” $\sigma^{\*}$ such that the center of each ball lies on $\sigma^{\*}$ (see Figure [7](#S4.F7 "Figure 7 ‣ Proof. ‣ 4.2.1 Existing algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning")).
Let $M\_{n}$ denote the maximum number of balls, $\bar{s}$ denote the length of the portion of $\sigma^{\*}$ that lies within the $\delta$-interior of ${\cal X}\_{\mathrm{free}}$, and $n\_{0}\in\mathbb{N}$ denote the number for which $r\_{n}\leq\delta$ for all $n\geq n\_{0}$.

Then, for all $n\geq n\_{0}$,

|  |  |  |
| --- | --- | --- |
|  | $M\_{n}\geq\frac{\bar{s}}{2\,\gamma\,\left(\frac{1}{n}\right)^{1/d}}=\frac{\bar{s}}{2\,\gamma}\,n^{1/d}.$ |  |

Figure 7: An illustration of the covering of the optimal path, $\sigma^{\*}$, with openly disjoint balls. The balls cover only a portion of $\sigma^{\*}$ that lies within the $\delta$-interior of ${\cal X}\_{\mathrm{free}}$.

Indicate the graph returned by this sPRM algorithm as $G\_{n}=(V\_{n},E\_{n})$. Denote the event that the ball $B\_{n,m}$ contains no vertex in $V\_{n}$ by $A\_{n,m}$. Denote the indicator random variable for the event $A\_{n,m}$ by $I\_{n,m}$, i.e., $I\_{n,m}=1$ when $A\_{n,m}$ holds and $I\_{n,m}=0$ otherwise. Then, for all $n\geq n\_{0}$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}[I\_{n,m}]=\mathbb{P}(A\_{n,m})=\left(1-\frac{\mu(B\_{n,m})}{\mu({\cal X}\_{\mathrm{free}})}\right)^{n}=\left(1-\frac{\zeta\_{d}\,\gamma^{d}}{\mu({\cal X}\_{\mathrm{free}})}\,\frac{1}{n}\right)^{n}$ |  |

Let $N\_{n}$ be the random variable that denotes the total number of balls in $B\_{n}$ that contain no vertex in $V\_{n}$, i.e., $N\_{n}=\sum\_{m=1}^{M\_{n}}I\_{n,m}$. Then, for all $n\geq n\_{0}$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}[N\_{n}]\,\,=\,\,\mathbb{E}\left[\sum\nolimits\_{m=1}^{M\_{n}}I\_{n,m}\right]\,\,=\,\,\sum\_{m=1}^{M\_{n}}\mathbb{E}[I\_{n,m}]\,\,=\,\,M\_{n}\,\,\mathbb{E}[I\_{n,1}]\,\,\geq\,\,\frac{\bar{s}}{2\,\gamma}\,n^{1/d}\,\left(1-\frac{\zeta\_{d}\,\gamma^{d}}{\mu({\cal X}\_{\mathrm{free}})}\frac{1}{n}\right)^{n}.$ |  |

Consider a ball $B\_{n,m}$ that contains no vertices of this sPRM algorithm. Then, no edges of the graph returned by this algorithm cross the ball of radius $\frac{\sqrt{3}}{2}r\_{n}$ centered at the center of $B\_{n,m}$. See Figure [8](#S4.F8 "Figure 8 ‣ Proof. ‣ 4.2.1 Existing algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").

Figure 8: If the outer ball does not contain vertices of the PRM graph, then no edge of the graph corresponds to a path crossing the inner ball.

Let $P\_{n}$ denote the (finite) set of all acyclic paths that reach the goal region in the graph returned by this sPRM algorithm when the algorithm is run with $n$ samples.
Let $U\_{n}$ denote the total variation of the path that is closest to $\sigma^{\*}$ among all paths in $P\_{n}$, i.e., $U\_{n}:=\min\_{\sigma\_{n}\in P\_{n}}\|\sigma\_{n}-\sigma^{\*}\|\_{\mathrm{BV}}$. Then,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}[U\_{n}]\,\,\geq\,\,\mathbb{E}\left[\gamma\left(\frac{1}{n}\right)^{1/d}\,N\_{n}\right]\,\,\geq\,\,\frac{\bar{s}}{2}\,\left(1-\frac{\zeta\_{d}\,\gamma^{d}}{\mu({\cal X}\_{\mathrm{free}})}\frac{1}{n}\right)^{n}.$ |  |

Taking the limit superior of both sides, the following inequality can be established:

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}\left[\limsup\_{n\to\infty}U\_{n}\right]\,\,\geq\,\,\limsup\_{n\to\infty}\mathbb{E}\left[U\_{n}\right]\,\,\geq\,\,\limsup\_{n\to\infty}\frac{\bar{s}}{2}\,\left(1-\frac{\zeta\_{d}\,\gamma^{d}}{\mu({\cal X}\_{\mathrm{free}})}\frac{1}{n}\right)^{n}\,\,=\,\,\frac{\bar{s}}{2}\,e^{-\frac{\zeta\_{d}\,\gamma^{d}}{\mu({\cal X}\_{\mathrm{free}})}}>0,$ |  |

where the first inequality follows from Fatou’s lemma ([Resnick, 1999](#bib.bib85)). Hence, $\mathbb{P}(\{\limsup\_{n\to\infty}U\_{n}>0\})>0$, which implies that
$\mathbb{P}\left(\left\{\limsup\_{n\to\infty}Y\_{n}^{\mathrm{ALG}}>c^{\*}\right\}\right)>0$. That is, $\mathbb{P}\left(\left\{\limsup\_{n\to\infty}Y\_{n}^{\mathrm{ALG}}=c^{\*}\right\}\right)<1$. In fact, $\mathbb{P}\left(\left\{\limsup\_{n\to\infty}Y\_{n}^{\mathrm{ALG}}=c^{\*}\right\}\right)=0$ by the Kolmogorov zero-one law (see Lemma [25](#Thmtheorem25 "Lemma 25 ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning")).
∎∎

##### Rapidly-exploring Random Trees

In this section, it is shown that the minimum-cost path in the RRT algorithm converges to a certain random variable, however, under mild technical assumptions, this random variable is not equal to the optimal cost, with probability one.

###### Theorem 33 (Non-optimality of RRT)

The RRT algorithm is not asymptotically optimal.

The proof of this theorem can be found in Appendix [B](#A2 "Appendix B Proof of Theorem (Non-optimality of RRT) ‣ Sampling-based Algorithms for Optimal Motion Planning").
Note that, since at each iteration the RRT algorithm either adds a vertex and an edge, or leaves the graph unchanged, $G\_{i}^{\mathrm{RRT}}(\omega)\subseteq G\_{i+1}^{\mathrm{RRT}}(\omega)$, for all $i\in\mathbb{N}$ and all $\omega\in\Omega$, and hence the limit $\lim\_{n\to\infty}Y\_{n}^{\mathrm{RRT}}$ exists and is equal to the random variable $Y\_{\infty}^{\mathrm{RRT}}$.
In conjunction with Lemma [25](#Thmtheorem25 "Lemma 25 ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"), Theorem [33](#Thmtheorem33 "Theorem 33 (Non-optimality of RRT) ‣ Rapidly-exploring Random Trees ‣ 4.2.1 Existing algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") implies that this limit is strictly greater than $c^{\*}$ almost surely, i.e., $\mathbb{P}\left(\{\lim\_{n\to\infty}{Y}^{\mathrm{RRT}}\_{n}>c^{\*}\}\right)=1$. In other words, the cost of the best solution returned by RRT converges to a suboptimal value, with probability one. In fact, it is possible to construct problem instances such that the probability that the first solution returned by the RRT algorithm has arbitrarily high cost is bounded away from zero ([Nechushtan et al., 2010](#bib.bib77)).

Since the cost of the best path returned by the RRT algorithm converges to a random variable, Theorem [33](#Thmtheorem33 "Theorem 33 (Non-optimality of RRT) ‣ Rapidly-exploring Random Trees ‣ 4.2.1 Existing algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") provides new insight explaining the effectiveness of approaches as in [Ferguson and Stentz (2006)](#bib.bib31). In fact, running multiple instances of the RRT algorithm amounts to drawing multiple samples of ${Y}^{\mathrm{RRT}}\_{\infty}$.

#### 4.2.2 Proposed algorithms

In this section, the proposed algorithms are analyzed for asymptotic optimality, i.e., almost sure convergence to optimal solutions. It is shown that the PRM∗, RRG, and RRT∗ algorithms, as well as their $k$-nearest implementations, are all asymptotically optimal.
The proofs of the following theorems are quite lengthy, and will be provided in the appendix.

Recall that $d$ denotes the dimensionality of the configuration space, $\mu({\cal X}\_{\mathrm{free}})$ denotes the Lebesgue measure of the obstacle-free space, and $\zeta\_{d}$ denotes the volume of the unit ball in the $d$-dimensional Euclidean space. Proofs of the following theorems can be found in Appendices [C](#A3 "Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning")–[G](#A7 "Appendix G Proof of Theorem (Asymptotic optimality of RRT∗) ‣ Sampling-based Algorithms for Optimal Motion Planning").

###### Theorem 34 (Asymptotic optimality of PRM∗)

If $\gamma\_{\mathrm{PRM}}>2\,(1+1/d)^{1/d}\,\left(\frac{\mu(X\_{\mathrm{free}})}{\zeta\_{d}}\right)^{1/d}$, then the PRM∗ algorithm is asymptotically optimal.

###### Theorem 35 (Asymptotic optimality of $k$-nearest PRM∗)

If $k\_{\mathrm{PRM}}>e\,(1+1/d)$, then the $k$-nearest implementation of the PRM∗ algorithm is asymptotically optimal.

###### Theorem 36 (Asymptotic optimality of RRG)

If $\gamma\_{\mathrm{PRM}}>2\,(1+1/d)^{1/d}\,\left(\frac{\mu(X\_{\mathrm{free}})}{\zeta\_{d}}\right)^{1/d}$, then the RRG algorithm is asymptotically optimal.

###### Theorem 37 (Asymptotic optimality of $k$-nearest RRG)

If $k\_{\mathrm{RRG}}>e\,(1+1/d)$, then the $k$-nearest implementation of the RRG algorithm is asymptotically optimal.

###### Theorem 38 (Asymptotic optimality of RRT∗)

If $\gamma\_{\mathrm{RRT}^{\*}}>(2\,(1+1/d))^{1/d}\,\left(\frac{\mu(X\_{\mathrm{free}})}{\zeta\_{d}}\right)^{1/d}$, then the RRT∗ algorithm is asymptotically optimal.

###### Theorem 39 (Asymptotic optimality of $k$-nearest RRT∗)

If $k\_{\mathrm{RRT}^{\*}}>2^{d+1}\,e\,(1+1/d)$, then the $k$-nearest implementation of the RRT∗ algorithm is asymptotically optimal.

The proof of the latter theorem follows from those of Theorems [37](#Thmtheorem37 "Theorem 37 (Asymptotic optimality of 𝑘-nearest RRG) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") and [38](#Thmtheorem38 "Theorem 38 (Asymptotic optimality of RRT∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").

### 4.3 Computational Complexity

The objective of this section is to compare the computational complexity of the algorithms provided in Section [3](#S3 "3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning"). First, each algorithm is analyzed in terms of the number of calls to the ${\tt CollisionFree}$ procedure. Second, the computational complexity of certain primitive procedures such as ${\tt Nearest}$ and ${\tt Near}$ (see Section [3.1](#S3.SS1 "3.1 Primitive Procedures ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning")) are analyzed. Using these results, a thorough analysis of the computational complexity of the all the algorithms is given in terms of the number of simple operations, such as comparisons, additions, multiplications. An analysis of the computational complexity of the query phase, i.e., the complexity of extracting the optimal solution from the graph returned by these algorithms, is also provided.

The following notation for asymptotic computational complexity will be used throughout this section.
Let $W^{\mathrm{ALG}}\_{n}(P)$ be a function of the graph returned by algorithm ${\mathrm{ALG}}$ when ${\mathrm{ALG}}$ is run with inputs $P=({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$ and $n$. Clearly, $W^{\mathrm{ALG}}\_{n}(P)$ is a random variable. Let $f:\mathbb{N}\to\mathbb{N}$ be an increasing function with $\lim\_{n\to\infty}f(n)=\infty$. The random variable $W^{\mathrm{ALG}}\_{n}$ is said belong to $\Omega(f(n))$, denoted as $W^{\mathrm{ALG}}\_{n}\in\Omega(f(n))$, if there exists a problem instance $P=({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$ such that $\liminf\_{n\to\infty}\mathbb{E}[W^{\mathrm{ALG}}\_{n}(P)/f(n)]>0$. Similarly, $W^{\mathrm{ALG}}\_{n}$ is said to belong to $O(f(n))$ if $\limsup\_{n\to\infty}\mathbb{E}[W^{\mathrm{ALG}}\_{n}(P)/f(n)]<\infty$ for all problem instances $P=({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$.

##### Number of calls to the ${\tt CollisionFree}$ procedure

Let $M\_{n}^{\mathrm{ALG}}$ denote the total number of calls to the ${\tt CollisionFree}$ procedure by algorithm ${\mathrm{ALG}}$ in iteration $n$.

First, lower-bounds are established for the PRM and sPRM algorithms.

###### Lemma 40 (PRM)

$M^{\mathrm{PRM}}\_{n}\in\Omega(n)$.

###### Proof.

Consider the problem instance $({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$, where ${\cal X}\_{\mathrm{free}}$ is composed of two openly-disjoint sets ${\cal X}\_{1}$ and ${\cal X}\_{2}$ (see Figure [9](#S4.F9 "Figure 9 ‣ Proof. ‣ Number of calls to the 𝙲𝚘𝚕𝚕𝚒𝚜𝚒𝚘𝚗𝙵𝚛𝚎𝚎 procedure ‣ 4.3 Computational Complexity ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning")). The set ${\cal X}\_{2}$ is designed to be a hyperrectangle shaped set with one side equal to $r/2$, where $r$ is the connection radius.

Figure 9: An illustration of ${\cal X}\_{\mathrm{free}}={\cal X}\_{1}\cup{\cal X}\_{2}$.

Any $r$-ball centered at a point in ${\cal X}\_{2}$ will certainly contain a nonzero measure part of ${\cal X}\_{2}$. Define $\bar{\mu}$ as the volume of the smallest region in ${\cal X}\_{2}$ that can be intersected by an $r$-ball centered at ${\cal X}\_{2}$, i.e., $\bar{\mu}:=\inf\_{x\in{\cal X}\_{2}}\mu({\cal B}\_{x,r}\cap{\cal X}\_{1})$. Clearly, $\bar{\mu}>0$.

Thus, for any sample $X\_{n}$ that falls into ${\cal X}\_{2}$, the PRM algorithm will attempt to connect $X\_{n}$ to a certain number of vertices that lies in a subset ${\cal X}\_{1}^{\prime}$ of ${\cal X}\_{1}$ such that $\mu({\cal X}\_{1}^{\prime})\geq\bar{\mu}$. The expected number of vertices in ${\cal X}\_{1}^{\prime}$ is at least $\bar{\mu}\,n$. Moreover, none of these vertices can be in the same connected component with $X\_{n}$. Thus, $\mathbb{E}[M^{\mathrm{PRM}}\_{n}/n]>\bar{\mu}$. The result is obtained by taking the limit inferior of both sides.
∎∎

###### Lemma 41 (sPRM)

$M^{\mathrm{sPRM}}\_{n}\in\Omega(n)$.

###### Proof.

The proof of a stronger result is provided. It is shown that for all problem instances $P=({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$, $\liminf\_{n\to\infty}\mathbb{E}[M^{\mathrm{sPRM}}\_{n}/n]>0$, which implies the lemma.
Recall from Algorithm [2](#algorithm2 "In Probabilistic RoadMaps (PRM): ‣ 3.2 Existing Algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") that $r$ denotes the connection radius. Let $\bar{\mu}$ denote the volume of the smallest region that can be formed by intersecting ${\cal X}\_{\mathrm{free}}$ with an $r$-ball centered at a point inside ${\cal X}\_{\mathrm{free}}$, i.e.,
$\bar{\mu}:=\inf\_{x\in{\cal X}\_{\mathrm{free}}}\mu({\cal B}\_{x,r}\cap{\cal X}\_{\mathrm{free}}).$
Recall that ${\cal X}\_{\mathrm{free}}$ is the closure of an open set. Hence, $\bar{\mu}>0$.

Clearly, $M\_{n}$, the number of calls to the ${\tt CollisionFree}$ procedure in iteration $n$, is equal to the number of nodes inside the ball of radius $r$ centered at the last sample point $X\_{n}$. Moreover, the volume of the ${\cal X}\_{\mathrm{free}}$ that lies inside this ball is at least $\bar{\mu}$.
Then, the expected value of $M\_{n}$ is lower bounded by the expected value of a binomial random variable with parameters $\bar{\mu}/\mu({\cal X}\_{\mathrm{free}})$ and $n$, since the underlying point process is binomial. Thus,
$\mathbb{E}[M^{\mathrm{sPRM}}\_{n}]\geq\frac{\bar{\mu}}{\mu({\cal X}\_{\mathrm{free}})}\,n.$
Then, $\mathbb{E}[M\_{n}/n]\geq\bar{\mu}/{\cal X}\_{\mathrm{free}}$ for all $n\in\mathbb{N}$. Taking the limit inferior of both sides gives the result.
∎∎

Clearly, for $k$-nearest PRM, $M^{k\mbox{-}\mathrm{sPRM}}\_{n}=k$ for all $n\in\mathbb{N}$ with $n>k$. Similarly, for the RRT, $M^{\mathrm{RRT}}\_{n}=1$ for all $n\in\mathbb{N}$.

The next lemma upper-bounds the number of calls to the ${\tt CollisionFree}$ procedure in the proposed algorithms.

###### Lemma 42 (PRM∗, RRG, and RRT∗)

$M^{\mathrm{PRM}^{\*}}\_{n},\,M^{\mathrm{RRG}}\_{n},\,M^{\mathrm{RRT}^{\*}}\_{n}\in O(\log n)$.

###### Proof.

First, consider PRM∗.
Recall that $r\_{n}$ denotes the connection radius of the PRM∗ algorithm.
Recall that the $r\_{n}$ interior of ${\cal X}\_{\mathrm{free}}$, denoted by $\mathrm{int}\_{r\_{n}}({\cal X}\_{\mathrm{free}})$, is defined as the set of all points $x$, for which the $r\_{n}$-ball centered at $x$ lies entirely inside ${\cal X}\_{\mathrm{free}}$.
Let $A$ denote the event that the sample $X\_{n}$ drawn at the last iteration falls into the $r\_{n}$ interior of ${\cal X}\_{\mathrm{free}}$. Then,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}\big[M\_{n}^{\mathrm{PRM}^{\*}}\big]=\mathbb{E}\big[M\_{n}^{\mathrm{PRM}^{\*}}\,\big|\,A\big]\,\mathbb{P}(A)+\mathbb{E}\big[M\_{n}^{\mathrm{PRM}^{\*}}\,\big|\,A^{c}\big]\,\mathbb{P}(A^{c}).$ |  |

Let $n\_{0}\in\mathbb{N}$ be the smallest number such that $\mu(\mathrm{int}\_{r\_{n}}({\cal X}\_{\mathrm{free}}))>0$. Clearly, such $n\_{0}$ exists, since $\lim\_{n\to\infty}r\_{n}=0$ and ${\cal X}\_{\mathrm{free}}$ has non-empty interior.
Recall that $\zeta\_{d}$ is the volume of the unit ball in the $d$-dimensional Euclidean space and that the connection radius of the PRM∗ algorithm is $r\_{n}=\gamma\_{\mathrm{PRM}}(\log n/n)^{1/d}$.
Then, for all $n\geq n\_{0}$

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}\big[M\_{n}^{\mathrm{PRM}^{\*}}\,\big|\,A\big]=\frac{\zeta\_{d}\,\gamma\_{\mathrm{PRM}}}{\mu(\mathrm{int}\_{r\_{n}}({\cal X}\_{\mathrm{free}}))}\log n.$ |  |

On the other hand, given that $X\_{n}\notin\mathrm{int}\_{r\_{n}}({\cal X}\_{\mathrm{free}})$, the $r\_{n}$-ball centered at $X\_{n}$ intersects a fragment of ${\cal X}\_{\mathrm{free}}$ that has volume less than the volume of an $r\_{n}$-ball in the $d$-dimensional Euclidean space. Then, for all $n>n\_{0}$,
$\mathbb{E}\big[M\_{n}^{\mathrm{PRM}^{\*}}\,\big|\,A^{c}\big]\leq\mathbb{E}\big[M\_{n}^{\mathrm{PRM}^{\*}}\,\big|\,A\big].$

Hence, for all $n\geq n\_{0}$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}\left[\frac{M\_{n}^{\mathrm{PRM}^{\*}}}{\log n}\right]\leq\frac{\zeta\_{d}\,\gamma\_{\mathrm{PRM}}}{\mu(\mathrm{int}\_{r\_{n}}({\cal X}\_{\mathrm{free}}))}\leq\frac{\zeta\_{d}\,\gamma\_{\mathrm{PRM}}}{\mu(\mathrm{int}\_{r\_{n\_{0}}}({\cal X}\_{\mathrm{free}}))}.$ |  |

Next, consider the RRG. Recall that $\eta$ is the parameter provided in the ${\tt Steer}$ procedure (see Section [3.1](#S3.SS1 "3.1 Primitive Procedures ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning")). Let $D$ denote the diameter of the set ${\cal X}\_{\mathrm{free}}$, i.e., $D:=\sup\_{x,x^{\prime}\in{\cal X}\_{\mathrm{free}}}\|x-x^{\prime}\|$. Clearly, whenever $\eta\geq D$, $V^{\mathrm{PRM}^{\*}}=V^{\mathrm{RRG}}=V^{\mathrm{RRT}^{\*}}$ surely, and the claim holds.

To prove the claim when $\eta<D$, let $C\_{n}$ denote the event that for any point $x\in{\cal X}\_{\mathrm{free}}$ the RRG algorithm has a vertex $x^{\prime}\in V^{\mathrm{RRG}}\_{n}$ such that $\|x-x^{\prime}\|\leq\eta$. As shown in the proof of Theorem [36](#Thmtheorem36 "Theorem 36 (Asymptotic optimality of RRG) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") (see Lemma [63](#Thmtheorem63 "Lemma 63 ‣ E.3 Probability that each ball in 𝐵_𝑛 contains at least one vertex ‣ Appendix E Proof of Theorem (Asymptotic optimality of RRG) ‣ Sampling-based Algorithms for Optimal Motion Planning")), there exists $a,b>0$ such that $\mathbb{P}(C\_{n}^{c})\leq a\,e^{-b\,n}$. Then,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}\left[M\_{n}^{\mathrm{RRG}}\right]=\mathbb{E}\left[M\_{n}^{\mathrm{RRG}}\,\big|\,C\_{n}\right]\,\mathbb{P}(C\_{n})+\mathbb{E}\left[M\_{n}^{\mathrm{RRG}}\,\big|\,C\_{n}^{c}\right]\,\mathbb{P}(C\_{n}^{c}),$ |  |

Clearly, $\mathbb{E}\left[M\_{n}^{\mathrm{RRG}}\,\big|\,C\_{n}^{c}\right]\leq n$. Hence, the second term of the sum on the right hand side converges to zero as $n$ approaches infinity. On the other hand, given that $C\_{n}$ holds, the new vertex that will be added to the graph at iteration $n$, if such a vertex is added at all, will be the same as the last sample, $X\_{n}$. To complete the argument, given any set of $n$ points placed inside $\mu(X\_{\mathrm{free}})$, let $N\_{n}$ denote the number of points that are inside a ball of radius $r\_{n}$ that is centered at a point $X\_{n}$ sampled uniformly at random from $\mu(X\_{\mathrm{free}})$. The expected number of points inside this ball is no more than
$\frac{\zeta\_{d}\,r\_{n}^{d}}{\mu(X\_{\mathrm{free}})}\,n.$
Hence, $\mathbb{E}[M\_{n}^{\mathrm{RRG}}\,|\,C\_{n}]<\frac{\zeta\_{d}\,\gamma\_{\mathrm{PRM}}}{\mu(X\_{\mathrm{free}})}\log n$, which implies the existence of a constant $\phi\_{1}\in\mathbb{R}\_{\geq 0}$ such that $\limsup\_{n\to\infty}\mathbb{E}[M^{\mathrm{RRG}}\_{n}/(\log n)]\leq\phi\_{1}$.

Finally, since $M\_{n}^{\mathrm{RRT}^{\*}}=M\_{n}^{\mathrm{RRG}}$ holds surely, $\limsup\_{n\to\infty}\mathbb{E}[M^{\mathrm{RRG}}\_{n}/(\log n)]\leq\phi\_{1}$ also.
∎∎

Trivially, $M^{k\mbox{-}\mathrm{PRM}^{\*}}\_{n}=M^{k\mbox{-}\mathrm{RRG}}\_{n}=M^{k\mbox{-}\mathrm{RRT}^{\*}}\_{n}=k\,\log n$ for all $n$ with $n/\log n>k$.

##### Complexity of the ${\tt CollisionFree}$ procedure

In this section, complexity of the ${\tt CollisionFree}$ procedure in terms of the number of obstacles in the environment is analyzed, which is a widely-studied problem in the literature (see, e.g., [Lin and Manocha (2004)](#bib.bib70) for a survey). The main result is based on [Six and Wood (1982)](#bib.bib94), which shows that checking collision with $m$ obstacles can be executed in $O(\log^{d}m)$ time using data structures based on spatial trees ([Edelsbrunner and Maurer, 1981](#bib.bib29); [Hopcroft et al., 1983](#bib.bib40), see also).

##### Complexity of the ${\tt Nearest}$ procedure

The nearest neighbor search problem has been widely studied in the literature, since it has many applications in, e.g., computer graphics, database systems, image processing, data mining, pattern recognition, etc. ([Samet, 1989b](#bib.bib90); [Samet, 1989a](#bib.bib89)).
Clearly, a brute-force algorithm that examines every vertex runs in $O(n)$ time and requires $O(1)$ space. However, in many online real-time applications such as robotics, it is highly desirable to reduce the computation time of each iteration under sublinear bounds, e.g., in $O(\log n)$ time, especially for anytime algorithms that provide better solutions as the number of iterations increase.

Fortunately, existing algorithms for computing an “approximate” nearest neighbor, if not an exact one, are computationally very efficient. In the sequel, a vertex $y$ is said to be an $\varepsilon$-approximate nearest neighbor of a point $x$ if $\|y-x\|\leq(1+\varepsilon)\,\|z-x\|$, where $z$ is the true nearest neighbor of $x$. An approximate nearest neighbor can be computed using balanced-box decomposition (BBD) trees, which achieves $O(c\_{d,\varepsilon}\log n)$ query time using $O(d\,n)$ space ([Arya et al., 1999](#bib.bib4)), where $c\_{d,\varepsilon}\leq d\lceil 1+6d/\varepsilon\rceil^{d}$. This algorithm is computationally optimal in fixed dimensions, since it closely matches a lower bound for algorithms that use a tree structure stored in roughly linear space ([Arya et al., 1999](#bib.bib4)). Using approximate nearest neighbor computation in the context of both PRMs and RRTs was discussed very recently in [Yershova and LaValle (2007)](#bib.bib105); [Plaku and Kavraki (2008)](#bib.bib80).

Let $G=(V,E)$ be a graph with $V\subseteq{\cal X}$ and let $x\in{\cal X}$. The discussion above implies that the number of simple operations executed by the ${\tt Nearest}(G,x)$ procedure is $\Theta(\log|V|)$ in fixed dimensions, if the ${\tt Nearest}$ procedure is implemented using a tree structure that is stored in linear space.

##### Complexity of the ${\tt Near}$ procedure

Problems similar to that solved by the ${\tt Near}$ procedure are also widely-studied in the literature, generally under the name of range search problems, as they have many applications in, for instance, computer graphics and spatial database systems ([Samet, 1989a](#bib.bib89)). In the worst case and in fixed dimensions, computing the exact set of vertices that reside in a ball of radius $r\_{n}$ centered at a query point $x$ takes $O(n^{1-1/d}+m)$ time using $k$-d trees ([Lee and Wong, 1977](#bib.bib66)), where $m$ is the number of vertices returned by the search (see also [Chanzy et al. (2001)](#bib.bib24) for an analysis of the average case).

Similar to the nearest neighbor search, computing approximate solutions to the range search problem is computationally easier. A range search algorithm is said to be $\varepsilon$-approximate if it returns all vertices that reside in the ball of size $r\_{n}$ and no vertices outside a ball of radius $(1+\varepsilon)\,r\_{n}$, but may or may not return the vertices that lie outside the former ball and inside the latter ball. Computing $\varepsilon$-approximate solutions using BBD-trees requires $O(2^{d}\log n+d^{2}(3\sqrt{d}/\varepsilon)^{d-1})$ time when using $O(d\,n)$ space, in the worst case ([Arya and Mount, 2000](#bib.bib3)). Thus, in fixed dimensions, the complexity of this algorithm is $O(\log n+(1/\varepsilon)^{d-1})$, which is known to be optimal, closely matching a lower bound ([Arya and Mount, 2000](#bib.bib3)). More recently, algorithms that can provide trade-offs between time and space were also proposed ([Arya et al., 2005](#bib.bib5)).

Note that the ${\tt Near}$ procedure can be implemented as an approximate range search while maintaining the asymptotic optimality guarantee. Notice that the expected number of vertices returned by the ${\tt Near}$ procedure also does not change, except by a constant factor.
Hence, the ${\tt Near}$ procedure can be implemented to run in order $\log n$ expected time in the limit and linear space in fixed dimensions.

##### Time complexity of the processing phase

The following results characterize the asymptotic computational complexity of various sampling-based algorithms in terms of the number of simple operations such as comparisons, additions, and multiplications.

Let $n$ denote the total number of iterations (or, alternatively, the number of samples), and $m$ denote the number of obstacles in the environment. Then, by Lemmas [40](#Thmtheorem40 "Lemma 40 (PRM) ‣ Number of calls to the 𝙲𝚘𝚕𝚕𝚒𝚜𝚒𝚘𝚗𝙵𝚛𝚎𝚎 procedure ‣ 4.3 Computational Complexity ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") and [41](#Thmtheorem41 "Lemma 41 (sPRM) ‣ Number of calls to the 𝙲𝚘𝚕𝚕𝚒𝚜𝚒𝚘𝚗𝙵𝚛𝚎𝚎 procedure ‣ 4.3 Computational Complexity ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"), $N^{\mathrm{PRM}}\_{n},\,N^{\mathrm{sPRM}}\_{n}\in\Omega(n^{2}\log^{d}m)$. In the $k$-nearest sPRM and RRT algorithms, $\Omega(\log n)$ time is spent on finding the ($k$-)nearest neighbor(s) and $\Omega(\log^{d}m)$ time is spent on collision checking at each iteration. Hence, $N^{k\mbox{-}\mathrm{sPRM}}\_{n},N^{\mathrm{RRT}}\_{n}\in\Omega(n\log n+n\log^{d}m)$.

In all the proposed algorithms, $O(\log n)$ time is spent on finding the near neighbors, and $\log n\log^{d}m$ time is spent on collision checking. Thus, $N^{\mathrm{ALG}}\_{n}\in O(n\,\log n\log^{d}m)$ for $ALG\in\{{\mathrm{PRM}^{\*}},{k\mbox{-}\mathrm{PRM}^{\*}},$ ${\mathrm{RRG}},{k\mbox{-}\mathrm{RRG}},{\mathrm{RRT}^{\*}},{k\mbox{-}\mathrm{RRT}^{\*}}\}$.

##### Time complexity of the query phase

After algorithm ${\mathrm{ALG}}$ returns the graph $G^{\mathrm{ALG}}\_{n}$, the optimal path must be extracted from this graph using, e.g., Dijkstra’s shortest path algorithm ([Schrijver, 2003](#bib.bib91)). In this section, the complexity of this operation, called the query phase, is discussed.

The following lemma yields the asymptotic computational complexity of computing shortest paths. Let $G=(V,E)$ be a graph. A length function $l:E\to\mathbb{R}\_{>0}$ is a function that assigns each edge in $E$ a positive length.
Given a vertex $v\in V$, the shortest paths tree for $G$, $l$, and $v$ is a graph $G^{\prime}=(V,E^{\prime})$, where $E^{\prime}\subseteq E$ such that for any $v^{\prime}\in V\setminus\{v\}$, there exists a unique path in $G$ that starts from $v$ and reaches $v^{\prime}$, moreover, this path is the optimal such path in $G$.

###### Lemma 43 (Complexity of shortest paths ([Schrijver, 2003](#bib.bib91)))

Given a graph $G=(V,E)$, a length function $l:E\to\mathbb{R}\_{>0}$, and a vertex $v\in V$, the shortest path tree for $G$, $l$, and $v$ can be found in time $O(|V|\log(|V|)+|E|)$.

It remains to determine the number of vertices and edges in $G^{\mathrm{ALG}}\_{n}=(V^{\mathrm{ALG}}\_{n},E^{\mathrm{ALG}}\_{n})$, for each algorithm ${\mathrm{ALG}}$.

Trivially, $|E^{\mathrm{ALG}}\_{n}|\in\Omega(n)$ holds for all the algorithms discussed in this paper, in particular, for $ALG\in\{{\mathrm{PRM}},{k\mbox{-}\mathrm{sPRM}},{\mathrm{RRT}}\}$.
For the sPRM algorithm, a stronger bound can be provided: $|E^{\mathrm{sPRM}}\_{n}|\in\Omega(n^{2})$. To prove this claim, consider the problem instance $({\cal X}\_{\mathrm{free}},x\_{\mathrm{init}},{\cal X}\_{\mathrm{goal}})$, where ${\cal X}\_{\mathrm{free}}={\cal X}=(0,1)^{d}$. Then, the straight path between any two vertices will be collision-free. Thus, the number of edges is exactly equal to the number of calls to the CollisionFree procedure. Then, the result follows from Lemma [41](#Thmtheorem41 "Lemma 41 (sPRM) ‣ Number of calls to the 𝙲𝚘𝚕𝚕𝚒𝚜𝚒𝚘𝚗𝙵𝚛𝚎𝚎 procedure ‣ 4.3 Computational Complexity ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").

For the proposed algorithms, $|E^{\mathrm{PRM}^{\*}}\_{n}|,|E^{\mathrm{RRG}}\_{n}|\in O(n\log n)$. Since the number of edges is always less than or equal to the total number of calls to the ${\tt CollisionFree}$ procedure, this claim follows directly from Lemma [42](#Thmtheorem42 "Lemma 42 (PRM∗, RRG, and RRT∗) ‣ Number of calls to the 𝙲𝚘𝚕𝚕𝚒𝚜𝚒𝚘𝚗𝙵𝚛𝚎𝚎 procedure ‣ 4.3 Computational Complexity ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").
Finally, $|E^{k\mbox{-}\mathrm{PRM}^{\*}}\_{n}|,|E^{k\mbox{-}\mathrm{RRG}}\_{n}|\in O(n\,\log n)$ and $|E^{\mathrm{RRT}^{\*}}\_{n}|,\,|E^{k\mbox{-}\mathrm{RRT}^{\*}}\_{n}|\in O(n)$ all hold trivially.

##### Space complexity

Space complexity of an algorithm ${\mathrm{ALG}}$ is defined as the amount of memory that is used by ${\mathrm{ALG}}$ to compute the graph $G^{\mathrm{ALG}}\_{n}=(V^{\mathrm{ALG}}\_{n},E^{\mathrm{ALG}}\_{n})$. Clearly, in all algorithms discussed in this paper, the space complexity is the size of $G^{\mathrm{ALG}}\_{n}$, i.e., $|V^{\mathrm{ALG}}\_{n}|+|E^{\mathrm{ALG}}\_{n}|$. Since the number of edges is at least as much as the number of vertices in $G^{\mathrm{ALG}}\_{n}$ for all algorithms discussed in this paper, the space complexity of an algorithm, in this context, is the number edges in the graph that it returns, which was determined in the previous section.

## 5 Numerical Experiments

This section is devoted to an experimental study of the algorithms considered in the paper.
All algorithms were implemented in C and run on a computer with 2.66 GHz processor and 4GB RAM
running the Linux operating system. Unless otherwise noted, total variation of a path is its cost.

A first set of experiments were run to illustrate the different performance of $k$-nearest PRM and of PRM∗. The $k$-nearest PRM and the PRM∗ algorithms were run alongside in two dimensional configuration-space and the cost of the best path in both algorithms is plotted versus the number of iterations in Figure [10](#S5.F10 "Figure 10 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning"). The $k$-nearest PRM does not converge to optimal solutions, unlike PRM∗.
The performance of the PRM∗ algorithm is also shown in configuration spaces of dimensions up to five in Figure [11](#S5.F11 "Figure 11 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning").

The main bulk of the experiments were aimed at demonstrating the performance of the RRT∗ algorithm, especially in comparison with its “standard” counterpart, i.e., RRT.
Three problem instances were considered. In the first two, the cost function is the Euclidean path
length.

The first scenario includes no obstacles. Both algorithms are run in a square environment.
The trees maintained by the algorithms are shown in Figure [12](#S5.F12 "Figure 12 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning") at several stages. The
figure illustrates that, in this case, the RRT algorithm does not improve the feasible solution to
converge to an optimum solution. On the other hand, running the RRT∗ algorithm further improves
the paths in the tree to lower cost ones. The convergence properties of the two algorithms are also
investigated in Monte-Carlo runs. Both algorithms were run for 20,000 iterations 500 times and the
cost of the best path in the trees were averaged for each iteration. The results are shown in
Figure [13](#S5.F13 "Figure 13 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning"), which shows that in the limit the RRT algorithm has cost very close to
a $\sqrt{2}$ factor the optimal solution (see [LaValle and Kuffner (2009)](#bib.bib64) for a similar result
in a deterministic setting), whereas the RRT∗ converges to the optimal solution. Moreover, the
variance over different RRT runs approaches 2.5, while that of the RRT∗ approaches zero. Hence,
almost all RRT∗ runs have the property of convergence to an optimal solution, as expected.

In the second scenario, both algorithms are run in an environment in presence of obstacles. In
Figure [14](#S5.F14 "Figure 14 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning"), the trees maintained by the algorithms are shown after 20,000 iterations.
The tree maintained by the RRT∗ algorithm is also shown in Figure [15](#S5.F15 "Figure 15 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning") in
different stages. It can be observed that the RRT∗ first rapidly explores the state space just
like the RRT. Moreover, as the number of samples increase, the RRT∗ improves its tree to include
paths with smaller cost and eventually discovers a path in a different homotopy class, which reduces
the cost of reaching the target considerably. Results of a Monte-Carlo study for this scenario is
presented in Figure [16](#S5.F16 "Figure 16 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning"). Both algorithms were run alongside up until 20,000
iterations 500 times and cost of the best path in the trees were averaged for each iteration. The
figures illustrate that all runs of the RRT∗ algorithm converges to the optimum, whereas the RRT
algorithm is about 1.5 of the optimal solution on average. The high variance in solutions returned
by the RRT algorithm stems from the fact that there are two different homotopy classes of paths that
reach the goal. If the RRT luckily converges to a path of the homotopy class that contains an
optimum solution, then the resulting path is relatively closer to the optimum than it is on average.
If, on the other hand, the RRT first explores a path of the second homotopy class, which is often
the case for this particular scenario, then the solution that RRT converges to is generally around
twice the optimum.

Finally, in the third scenario, where no obstacles are present, the cost function is selected to be
the line integral of a function, which evaluates to 2 in the high cost region, 1/2 in the low cost
region, and 1 everywhere else. The tree maintained by the RRT∗ algorithm is shown after 20,000
iterations in Figure [17](#S5.F17 "Figure 17 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning"). Notice that the tree either avoids the high cost region or
crosses it quickly, and vice-versa for the low-cost region. (Incidentally, this behavior corresponds
to the well known Snell-Descartes law for refraction of light, see [Rowe and Alexander (2000)](#bib.bib87) for a
path-planning application.)

To compare the running time, both algorithms were run alongside in an environment with no obstacles for
up to one million iterations. Figure [18](#S5.F18 "Figure 18 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning"), shows the ratio of the running time
of RRT∗ and that of RRT versus the number of iterations averaged over 50 runs. As expected from
the complexity analysis of Section [4.3](#S4.SS3 "4.3 Computational Complexity ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"), this ratio converges to a constant
value. A similar figure is produced for the second scenario and provided in
Figure [19](#S5.F19 "Figure 19 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning").

The RRT∗ algorithm was also run in a 5-dimensional state space. The number of iterations versus the cost of the best path averaged over 100 trials is shown in Figure [20](#S5.F20 "Figure 20 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning"). A comparison with the RRT algorithm is provided in the same figure. The ratio of the running times of the RRT∗ and the RRT algorithms is provided in Figure [21](#S5.F21 "Figure 21 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning").
The same experiment is carried out for a 10-dimensional configuration space. The results are shown in Figure [22](#S5.F22 "Figure 22 ‣ 5 Numerical Experiments ‣ Sampling-based Algorithms for Optimal Motion Planning").

Figure 10: The cost of the best path in the $k$-nearest sPRM algorithm, and that in the PRM∗ algorithm are shown versus the number of iterations in simulation examples with no obstacles. The $k$-nearest sPRM algorithm was run for $k=5,7,10,13,15$, each of which is shown separately in blue, and the PRM∗ algorithm is shown in red. The values are normalized so that the cost of the optimal path is equal to one. The iterations were stopped when the query phase of the algorithms exceeded the memory limit (approximately 4GB).

Figure 11: Cost of the best path in the PRM∗ algorithm is shown in up to 2, 3, 4, and 5 dimensional configuration spaces, in Figures (a), (b), (c), and (d), respectively. The initial condition and goal region are on opposite vertices of the unit cube $(0,1)^{d}$. The obstacle region is a cube centered at $(0.5,0.5,\dots,0.5)$ and has volume $0.5$ in all cases.

(a)

(b)

(c)

(d)

(e)

(f)

(g)

Figure 12: A Comparison of the RRT∗ and RRT algorithms on a simulation example with no
obstacles. Both algorithms were run with the same sample sequence. Consequently, in this case,
the vertices of the trees at a given iteration number are the same for both of the algorithms;
only the edges differ. The edges formed by the RRT algorithm are shown in (a)-(d) and (i),
whereas those formed by the RRT∗ algorithm are shown in (e)-(h) and (j). The tree snapshots
(a), (e) contain 250 vertices, (b), (f) 500 vertices, (c), (g) 2500 vertices, (d), (h) 10,000 vertices and
(i), (j) 20,000 vertices. The goal regions are shown in magenta (in upper right). The best paths
that reach the target in all the trees are highlighted with red.

(a)

Figure 13: The cost of the best paths in the RRT (shown in red) and the RRT∗ (shown in blue)
plotted against iterations averaged over 500 trials in (a). The optimal cost is shown in
black. The variance of the trials is shown in (b).

(a)

Figure 14: A Comparison of the RRT (shown in (a)) and RRT∗ (shown in (b)) algorithms on a
simulation example with obstacles. Both algorithms were run with the same sample sequence
for 20,000 samples. The cost of best path in the RRT and the RRG were 21.02 and 14.51,
respectively.

(a)

(b)

(c)

Figure 15: RRT∗ algorithm shown after 500 (a), 1,500 (b), 2,500 (c), 5,000 (d), 10,000 (e), 15,000
(f) iterations.

Figure 16: An environment cluttered with obstacles is considered. The cost of the best paths in
the RRT (shown in red) and the RRT∗ (shown in blue) plotted against iterations averaged
over 500 trials in (a). The optimal cost is shown in black. The variance of the trials is
shown in (b).

Figure 17: RRT∗ algorithm at the end of iteration 20,000 in an environment with no obstacles.
The upper yellow region is the high-cost region, whereas the lower yellow region is low-cost.

Figure 18: A comparison of the running time of the RRT∗ and the RRT algorithms. The ratio of
the running time of the RRT∗ over that of the RRT up until each iteration is plotted versus
the number of iterations.

Figure 19: A comparison of the running time of the RRT∗ and the RRT algorithms in an
environment with obstacles. The ratio of the running time of the RRT∗ over that of the RRT
up until each iteration is plotted versus the number of iterations.

(a)

Figure 20: The cost of the best paths in the RRT (shown in red) and the RRT∗ (shown in blue) run in a 5 dimensional obstacle-free configuration space plotted against iterations averaged over 100 trials in (a). The optimal cost is shown in black. The variance of the trials is shown in (b).

(a)

Figure 21: The ratio of the running time of the RRT and the RRT∗ algorithms is shown versus the number of iterations.

(a)

Figure 22: The cost of the best paths in the RRT (shown in red) and the RRT∗ (shown in blue) run in a 10 dimensional configuration space involving obstacles plotted against iterations averaged over 25 trials in (a). The variance of the trials is shown in (b).

## 6 Conclusion

This paper presented the results of a thorough analysis of sampling-based algorithms for optimal path planning. It is shown that broadly used algorithms from the literature, while probabilistically complete, are not asymptotically optimal, i.e., they will return
a solution to the path planning problem with high probability if one exists, but the cost of the solution returned by the algorithm will not converge to the optimal cost as the number of samples increases. In particular, it is proven that the PRM and RRT algorithms are not asymptotically optimal. A simplified version of PRM is asymptotically optimal, but is computationally expensive. In addition, it is shown that certain heuristic versions of PRM are not only not asymptotically complete, but also not necessarily complete.

In order to address these limitations of existing algorithms, a number of new algorithms are introduced, and proven to be asymptotically optimal and computational efficient, with respect to probabilistically complete algorithms in this class. In other words, asymptotic optimality imposes only a constant factor increase in complexity with respect to probabilistic completeness. The first algorithm, called PRM∗, is a variant of PRM, with a variable connection radius that scales as $\log(n)/n$, where $n$ is the number of samples. In other words, the average number of connections made at each iteration is proportional to $\log(n)$. The second new algorithm, called RRG, incrementally builds a connected roadmap, augmenting the RRT algorithm with connections within a ball scaling as $\log(n)/n$. The third new algorithm, called RRT∗, is a version of RRG that incrementally builds a tree. Experimental evidence that demonstrate the effectiveness of the algorithms proposed and support the
theoretical claims were also provided.

A common theme in the paper is that, in order to ensure both asymptotic optimality and computational efficiency, connections between samples should be sought within balls of radius scaling as $\log(n)/n$. If these balls shrink faster as $n$ increases, the algorithms are not asymptotically optimal (but may still be probabilistically complete); on the other hand, if these balls shrink slower, the complexity of the algorithms will suffer.
On average, the proposed scaling laws will result in an average number of connections per iteration that is proportional to $\log(n)$. Hence, it is natural to consider variants of these algorithms that make connections to $k\log(n)$ neighbors surely. Indeed, it is shown that these algorithms do share the same asymptotic optimality and computational efficiency properties of their counterparts, as long as $k$ is no smaller than a constant $k^{\*}\_{\mathrm{RRG}}$. It is remarkable that this constant only depends on the dimension of the space, and is otherwise independent from the problem instance.

The analysis of the results in the paper relies on techniques used to analyze random geometric graphs. Indeed, the algorithms considered in this paper build graphs that have many characteristics in common with well known classes of random geometric graphs. Interestingly, such geometric graphs exhibit phase transition phenomena, including percolation and connectivity, for thresholds matching those found for probabilistic completeness and asymptotic optimality of sampling-based algorithms. This leads to a natural conjecture that
a sampling-based path planning algorithm is probabilistically complete if and only if the underlying random geometric graph percolates, and is asymptotically optimal if and only if the underlying random geometric graph is connected.

The work presented in this paper can be extended in numerous directions.
First of all, it would be of interest to establish broader connections between sampling-based path planning algorithms and random geometric graphs, e.g., by proving or disproving the conjecture above, and by possibly improving on current algorithms through a better understanding of the underlying mathematical objects. Similar analysis techniques can also be used to analyze other sampling-based path planning algorithms that were not analyzed in this paper, such as EST. In addition, it is of interest to investigate deterministic sampling-based algorithms, in which samples are generated using deterministic dense sequences of points with, e.g., low dispersion, as opposed to random sequences.

Second, it is of great practical interest to address motion planning problems subject to more complex constraints. For example, motion planning problems for mobile robots should consider the robot’s dynamics, and hence differential constraints on the feasible trajectories (these are also called kino-dynamic planning problems). In addition, it is of interest to consider optimal planning problems in the presence of
temporal/logic constraints on the trajectories, e.g., expressed using formal specification languages
such as Linear Temporal Logic, or the $\mu$-calculus. Such constraints correspond to, e.g., rules of
the road constraints for autonomous ground vehicles, mission specifications for autonomous robots,
and rules of engagement in military applications. Ultimately, incremental sampling-based algorithms
with asymptotic optimality properties may provide the basic elements for the on-line solution of
differential games, as those arising when planning in the presence of dynamic obstacles.

Finally, it is noted that the proposed algorithms may have applications outside of the robotic
motion planning domain. In fact, the class of sampling-based algorithm described in this paper
can be readily extended to deal with problems described by partial differential equations, such as the eikonal equation and the Hamilton-Jacobi-Bellman equation.

## Acknowledgments

The authors are grateful to Professors M.S. Branicky, G.J. Gordon, and S. LaValle, as well as the anonymous reviewers, for their insightful comments on draft versions of this paper. This research was supported in part by the Michigan/AFRL Collaborative Center on Control Sciences, AFOSR grant #FA 8650-07-2-3744, and by the National Science Foundation, grant CNS-1016213.

## Appendix

## Appendix A Notation

Let $\mathbb{N}$ denote the set of positive integers and $\mathbb{R}$ denote the set of reals. Let $\mathbb{N}\_{0}=\mathbb{N}\cup\{0\}$, and $\mathbb{R}\_{>0}$, $\mathbb{R}\_{\geq 0}$ denote the sets of positive and non-negative reals, respectively. A sequence on a set $A$ is a mapping from $\mathbb{N}$ to $A$, denoted as $\{a\_{i}\}\_{i\in\mathbb{N}}$, where $a\_{i}\in A$ is the element that $i\in\mathbb{N}$ is mapped to. Given $a,b\in\mathbb{R}$, closed and open intervals between $a$ and $b$ are denoted by $[a,b]$ and $(a,b)$, respectively. The Euclidean norm is denoted by $\|\cdot\|$.
Given a set ${\cal X}\subset\mathbb{R}^{d}$, the closure of ${\cal X}$ is denoted by $\Cl({\cal X})$. The closed ball of radius $r>0$ centered at $x\in\mathbb{R}^{d}$, i.e., , i.e., $\{y\in\mathbb{R}^{d}\,|\,\,\|y-x\|\leq r\}$, is denoted as ${\cal B}\_{x,r}$; ${\cal B}\_{x,r}$ is also called the $r$-ball centered at $x$. Given a set ${\cal X}\subseteq\mathbb{R}^{d}$, the Lebesgue measure of $X$ is denoted by $\mu({\cal X})$. The Lebesgue measure of a set is also referred to as its volume. The volume of the unit ball in $\mathbb{R}^{d}$, is denoted by $\zeta\_{d}$, i.e., $\zeta\_{d}=\mu({\cal B}\_{0,1})$.
The letter $e$ is used to denote the base of the natural logarithm, also called Euler’s number.

Given a probability space $(\Omega,{\cal F},\mathbb{P})$, where $\Omega$ is a sample space, ${\cal F}\subseteq 2^{\Omega}$ is a $\sigma-$algebra, and $\mathbb{P}$ is a probability measure, an event $A$ is an element of ${\cal F}$. The complement of an event $A$ is denoted by $A^{c}$. Given a sequence of events $\{A\_{n}\}\_{n\in\mathbb{N}}$, the event $\cap\_{n=1}^{\infty}\cup\_{i=n}^{\infty}A\_{i}$ is denoted by $\limsup\_{n\to\infty}A\_{n}$ (also called the event that $A\_{n}$ occurs infinitely often); the event $\cup\_{n=1}^{\infty}\cap\_{i=n}^{\infty}A\_{i}$ is denoted by $\liminf\_{n\to\infty}A\_{n}$. A (real) random variable is a measurable function that maps $\Omega$ into $\mathbb{R}$. An extended (real) random variable can also take the values $\pm\infty$. The expected value of a random variable $Y$ is $\mathbb{E}[Y]=\int\_{\Omega}Y\;d\mathbb{P}$.
A sequence of random variables $\{Y\_{n}\}\_{n\in\mathbb{N}}$ is said to converge surely to a random variable $Y$ if $\lim\_{n\to\infty}Y\_{n}(\omega)=Y(\omega)$ for all $\omega\in\Omega$; the sequence is said to converge almost surely if $\mathbb{P}(\{\lim\_{n\to\infty}Y\_{n}=Y\})=1$. Finally, if $\varphi(\omega)$ is a property that is either true or false for a given $\omega\in\Omega$, the event that denotes the set of all samples $\omega$ for which $\varphi(\omega)$ holds, i.e., $\{\omega\in\Omega\,|\,\varphi(\omega)\mbox{ holds}\}$, is written as $\{\varphi\}$, e.g., $\{\omega\in\Omega\,|\,\lim\_{n\to\infty}Y\_{n}(\omega)=Y(\omega)\}$ is simply written as $\{\lim\_{n\to\infty}Y\_{n}=Y\}$. The Poisson random variable with parameter $\lambda$ is denoted by $\mathrm{Poisson}(\lambda)$. The binomial random variable with parameters $n$ and $p$ is denoted by $\mathrm{Binomial}(n,p)$.

Let $f(n)$ and $g(n)$ be two functions with domain and range $\mathbb{N}$ or $\mathbb{R}$. The function $f(n)$ is said to be $O(g(n))$, denoted as $f(n)\in O(g(n))$, if there exists two constants $M$ and $n\_{0}$ such that $f(n)\leq Mg(n)$ for all $n\geq n\_{0}$. The function $f(n)$ is said to be $\Omega(g(n))$, denoted as $f(n)\in\Omega(g(n))$, if there exists constants $M$ and $n\_{0}$ such that $f(n)\geq Mg(n)$ for all $n\geq n\_{0}$. The function $f(n)$ is said to be $\Theta(g(n))$, denoted as $f(n)\in\Theta(g(n))$, if $f(n)\in O(g(n))$ and $f(n)\in\Omega(g(n))$.

Let ${\cal X}$ be a subset of $\mathbb{R}^{d}$. A (directed) graph $G=(V,E)$ on ${\cal X}$ is composed of a vertex set $V$ and an edge set $E$, such that $V$ is a finite subset of ${\cal X}$, and $E$ is a subset of $V\times V$. A directed path on $G$ is a sequence $(v\_{1},v\_{2},\dots,v\_{n})$ of vertices such that $(v\_{i},v\_{i+1})\in E$ for all $1\leq i\leq n-1$. Given a vertex $v\in V$, the sets $\{u\in V\,|\,(u,v)\in E\}$ and $\{u\in V\,|\,(v,u)\in E\}$ are said to be its incoming neighbors and outgoing neighbors, respectively. A (directed) tree is a directed graph, in which each vertex but one has a unique incoming neighbor; the vertex with no incoming neighbor is called the root vertex. Vertices of a tree are often also called nodes.

## Appendix B Proof of Theorem [33](#Thmtheorem33 "Theorem 33 (Non-optimality of RRT) ‣ Rapidly-exploring Random Trees ‣ 4.2.1 Existing algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") (Non-optimality of RRT)

For simplicity, the theorem will be proven assuming that (i) the environment contains no obstacles, i.e., $\mathcal{X}\_{\mathrm{free}}=[0,1]^{d}$, and (ii) the parameter $\eta$ of the steering procedure is set large enough, e.g., $\eta\geq\mathrm{diam}\left(\mathcal{X}\_{\mathrm{free}}\right)=\sqrt{d}$. One one hand, considering this case is enough to prove that the RRT algorithm is not asymptotically optimal, as it demonstrates a case for which the RRT algorithm fails to converge to an optimal solution, although the problem instance is clearly robustly optimal. On the other hand, these assumptions are not essential, and the claims extend to the more general case, but the technical details of the proof are considerably more complicated.

The proof can be outlined as follows. Order the vertices in the RRT according to the iteration at which they are added to the tree. The set of vertices that contains the $k$-th child of the root along with all its descendants in the tree is called the $k$-th branch of the tree. First, it is shown that a necessary condition for the asymptotic optimality of RRT is that infinitely many branches of the tree contain vertices outside a small ball centered at the initial condition. Then, the RRT algorithm is shown to violate this condition, with probability one.

### B.1 A necessary condition

First, we provide a necessary condition for the RRT algorithm to be asymptotically optimal.

###### Lemma 44

Let $0<R<\inf\_{y\in\mathcal{X}\_{\mathrm{goal}}}\|y-x\_{\mathrm{init}}\|$.
The event $\{\lim\_{N\to\infty}Y\_{n}^{\mathrm{RRT}}=c^{\*}\}$ occurs only if the $k$-th branch of the RRT contains vertices outside the $R$-ball centered at $x\_{\mathrm{init}}$ for infinitely many $k$.

###### Proof.

Let $\{x\_{1},x\_{2},\dots\}$ denote the set of children to the root vertex in the order they are added to the tree. Let $\Gamma(x\_{k})$ denote the optimal cost of a path starting from the root vertex, passing through $x\_{k}$, and reaching the goal region. By our assumption that the measure of the set of all points that are on the optimal path is zero (see Assumption 27 and Lemma 28), the probability that $\Gamma(x\_{k})=c^{\*}$ is zero for all $k\in\mathbb{N}$. Hence,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\Big(\bigcup\nolimits\_{k\in\mathbb{N}}\left\{\Gamma(x\_{k})=c^{\*}\right\}\Big)\,\,\leq\,\,\sum\_{k=1}^{\infty}\mathbb{P}\big(\{\Gamma(x\_{k})=c^{\*}\}\big)=0.$ |  |

Let $A\_{k}$ denote the event that at least one vertex in the $k$-th branch of the tree is outside the ball of radius $R$ centered at $x\_{\mathrm{init}}$ in some iteration of the RRT algorithm.
Consider the case when the event $\{\limsup\_{k\to\infty}A\_{k}\}$ does not occur and the events $\{\Gamma(x\_{k})>c^{\*}\}$ occur for all $k\in\mathbb{N}$. Then, $A\_{k}$ occurs for only finitely many $k$. Let $K$ denote the largest number such that $A\_{K}$ occurs. Then, the cost of the best path in the tree is at least $\sup\{\Gamma(x\_{k})\,|\,k\in\{1,2,\dots,K\}\}$, which is strictly larger than $c^{\*}$, since $\{\Gamma(x\_{k})>c^{\*}\}$ for all finite $k$. Thus, $\lim\_{n\to\infty}Y\_{n}^{\mathrm{RRT}}>c^{\*}$ must hold.
That is, we have argued that

|  |  |  |
| --- | --- | --- |
|  | $\Big(\limsup\_{k\to\infty}A\_{k}\Big)^{c}\cap\Big(\bigcap\_{k\in\mathbb{N}}\{\Gamma(x\_{k})>c^{\*}\}\Big)\subseteq\Big\{\lim\_{n\to\infty}Y\_{n}^{\mathrm{RRT}}>c^{\*}\Big\}.$ |  |

Taking the complement of both sides and using monotonicity of probability measures,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}\left(\big\{\lim\_{n\to\infty}Y\_{n}^{\mathrm{RRT}}=c^{\*}\big\}\right)$ | $\displaystyle\leq$ | $\displaystyle\mathbb{P}\Big(\big(\limsup\_{k\to\infty}A\_{k}\big)\cup\big(\bigcup\nolimits\_{k\in\mathbb{N}}\{\Gamma(x\_{k})=c^{\*}\}\big)\Big),$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle\mathbb{P}\Big(\limsup\_{k\to\infty}A\_{k}\Big)+\mathbb{P}\Big(\bigcup\nolimits\_{k\in\mathbb{N}}\{\Gamma(x\_{k})=c^{\*}\}\Big),$ |  |

where the last inequality follows from the union bound. The lemma follows from the fact that the last term in the right hand side is equal to zero as shown above.
∎∎

### B.2 Length of the first path in a branch

The following result provides a useful characterization of the RRT structure.

###### Lemma 45

Let $U=\{X\_{1},X\_{2},\dots,X\_{n}\}$ be a set of independently sampled and uniformly distributed points in the $d$-dimensional unit cube, $[0,1]^{d}$. Let $X\_{n+1}$ be a point that is sampled independently from all the other points according to the uniform distribution on $[0,1]^{d}$. Then, the probability that among all points in $U$ the point $X\_{i}$ is the one that is closest to $X\_{n+1}$ is $1/n$, for all $i\in\{1,2,\dots,n\}$. Moreover, the expected distance from $X\_{n+1}$ to its nearest neighbor in $U$ is $n^{-1/d}$.

###### Proof.

Since the probability distribution is uniform, the probability that $X\_{n+1}$ is closest to $X\_{i}$ is the same for all $i\in\{1,2,\dots,n\}$, which implies that this probability is equal to $1/n$. The expected distance to the closest point in $U$ is an application of the order statistics of the uniform distribution.
∎∎

An immediate consequence of this result is that each vertex of the RRT has unbounded degree, almost surely, as the number of samples approaches infinity.

One can also define a notion of infinite paths in the RRT, as follows. Let $\Lambda$ be the set of infinite sequences of natural numbers $\alpha=(\alpha\_{1},\alpha\_{2},\ldots)$. For any $i\in\mathbb{N}$, let $\pi\_{i}:\Sigma\to\mathbb{N}^{i},(\alpha\_{1},\alpha\_{2},\ldots,\alpha\_{i},\ldots)\mapsto(\alpha\_{1},\alpha\_{2},\ldots,\alpha\_{i})$, be a function returning the prefix of length $i$ of an infinite sequence in $\Lambda$. The lexicographic ordering of $\Lambda$ is such that, given $\alpha,\beta\in\Sigma$, $\alpha\leq\beta$ if and only if there exists $j\in\mathbb{N}$ such that $\alpha\_{i}=\beta\_{i}$ for all $i\in\mathbb{N}$, $i\leq j-1$, and $\alpha\_{j}\leq\beta\_{j}$. This is a total ordering of $\Lambda$, since $\mathbb{N}$ is a totally ordered set. Given $\alpha\in\Lambda$ and $i\in\mathbb{N}$, let $\mathcal{L}\_{\pi\_{i}(\alpha)}$ be the sum of the distances from the root vertex $x\_{\mathrm{init}}$ to its $\alpha\_{1}$-th child, from this vertex to its $\alpha\_{2}$-th child, etc., for a total of $i$ terms. Because of Lemma
[45](#Thmtheorem45 "Lemma 45 ‣ B.2 Length of the first path in a branch ‣ Appendix B Proof of Theorem (Non-optimality of RRT) ‣ Sampling-based Algorithms for Optimal Motion Planning"), this construction is well defined, almost surely, for a sufficiently large number of samples.
For any infinite sequence $\alpha\in\Lambda$, let $\mathcal{L}\_{\alpha}=\lim\_{i\to+\infty}\mathcal{L}\_{\pi\_{i}(\alpha)}$; the limit exists since $\mathcal{L}\_{\pi\_{i}(\alpha)}$ is non-decreasing in $i$.

Consider infinite strings of the form $\mathbf{k}=(k,1,1,\ldots)$, $k\in\mathbb{N}$, and introduce the shorthand $\mathcal{L}\_{\mathbf{k}}:=\mathcal{L}\_{(k,1,1,\ldots)}$. The following lemma shows that, for any $k\in\mathbb{N}$, $\mathcal{L}\_{\mathbf{k}}$ has finite expectation, which immediately implies that $\mathcal{L}\_{\mathbf{k}}$ takes only finite values with probability one. The lemma also provides a couple of other useful properties of $\mathcal{L}\_{\mathbf{k}}$, which will be used later on.

###### Lemma 46

The expected value $\mathbb{E}[\mathcal{L}\_{\mathbf{k}}]$ is non-negative and finite, and monotonically non-increasing, in the sense that $\mathbb{E}[\mathcal{L}\_{\mathbf{k+1}}]\leq\mathbb{E}[\mathcal{L}\_{\mathbf{k}}]$, for any $k\in\mathbb{N}$. Moreover, $\lim\_{k\to\infty}\mathbb{E}[\mathcal{L}\_{\mathbf{k}}]=0$.

###### Proof.

Under the simplifying assumptions that there are no obstacles in the unit cube and $\eta$ is large enough, the vertex set $V\_{n}^{\mathrm{RRT}}$ of the graph maintained by the RRT algorithm is precisely the first $n$ samples and each new sample is connected to its nearest neighbor in $V\_{n}^{\mathrm{RRT}}$.

Define $Z\_{i}$ as a random variable describing the contribution to $\mathcal{L}\_{\mathbf{1}}$
realized at iteration $i$; in other words, $Z\_{i}$ is the distance of the $i$-th sample to its nearest neighbor among the first $i-1$ samples if the $i$-th sample is on the path
used in computing $\mathcal{L}\_{\mathbf{1}}$, and zero otherwise. Then, using Lemma [45](#Thmtheorem45 "Lemma 45 ‣ B.2 Length of the first path in a branch ‣ Appendix B Proof of Theorem (Non-optimality of RRT) ‣ Sampling-based Algorithms for Optimal Motion Planning"),

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}[\mathcal{L}\_{\mathbf{1}}]=\mathbb{E}\left[\sum\_{i=1}^{\infty}Z\_{i}\right]=\sum\_{i=1}^{\infty}\mathbb{E}[Z\_{i}]=\sum\_{i=1}^{\infty}i^{-1/d}\,\,i^{-1}={\tt Zeta}(1+1/d),$ |  |

where the second equality follows from the monotone convergence theorem and ${\tt Zeta}$ is the Riemann zeta function. Since ${\tt Zeta}(y)$ is finite for any $y>1$, $\mathbb{E}[\mathcal{L}\_{\mathbf{1}}]$ is a finite number for all $d\in\mathbb{N}$.

Let $N\_{k}$ be the iteration at which the first sample contributing to $\mathcal{L}\_{k}$ is generated. Then, an argument similar to the one given above yields

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}[\mathcal{L}\_{\mathbf{k+1}}]=\sum\_{i=N\_{k}+1}^{\infty}i^{-(1+1/d)}=\mathbb{E}[\mathcal{L}\_{\mathbf{1}}]-\sum\_{i=1}^{N\_{k}}i^{-(1+1/d)}.$ |  |

Then, clearly, $\mathbb{E}[\mathcal{L}\_{\mathbf{k+1}}]<\mathbb{E}[\mathcal{L}\_{\mathbf{k}}]$
for all $k\in\mathbb{N}$. Moreover, since $N\_{k}\geq k$, it is the case that $\lim\_{k\to\infty}\mathbb{E}[{\cal L}\_{\mathbf{k}}]=0$.
∎∎

### B.3 Length of the longest path in a branch

Given $k\in\mathbb{N}$, and the sequence $\mathbf{k}=(k,1,1,\ldots)$, the quantity $\sup\_{\alpha\geq\mathbf{k}}{\cal L}\_{\alpha}$ is an upper bound on the length of any path in the $k$-th branch of the RRT, or in any of the following branches.
The next result bounds the probability that this quantity is very large.

###### Lemma 47

For any $\epsilon>0$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\sup\_{\alpha\geq\mathbf{k}}\mathcal{L}\_{\alpha}>\epsilon\right\}\right)\,\,\leq\,\,\frac{\mathbb{E}[\mathcal{L}\_{\mathbf{k}}]}{\epsilon}.$ |  |

First, we state and prove the following intermediate result.

###### Lemma 48

$\mathbb{E}[\mathcal{L}\_{\alpha}]\leq\mathbb{E}[\mathcal{L}\_{\mathbf{k}}]$, for all $\alpha\geq\mathbf{k}$.

###### Proof.

The proof is by induction. Since $\alpha\geq\mathbf{k}$, then $\pi\_{1}(\alpha)\geq k$, and Lemma [46](#Thmtheorem46 "Lemma 46 ‣ B.2 Length of the first path in a branch ‣ Appendix B Proof of Theorem (Non-optimality of RRT) ‣ Sampling-based Algorithms for Optimal Motion Planning") implies that
$\mathbb{E}[\mathcal{L}\_{(\pi\_{1}(\alpha),1,1,\ldots)}]\leq\mathbb{E}[\mathcal{L}\_{\mathbf{k}}]$. Moreover, it is also the case that, for any $i\in\mathbb{N}$ (and some abuse of notation),
$\mathbb{E}[\mathcal{L}\_{(\pi\_{i+1}(\alpha),1,1,\ldots)}]\leq\mathbb{E}[\mathcal{L}\_{(\pi\_{i}(\alpha),1,1,\ldots)}]$, by a similar argument considering a tree rooted at
the last vertex reached by the finite path $\pi\_{i}(\alpha)$. Since $(\pi\_{i+1}(\alpha),1,1,\ldots)\geq(\pi\_{i}(\alpha),1,1,\ldots)\geq(k,1,1,\ldots)$, the result follows.
∎∎

###### Proof of Lemma [47](#Thmtheorem47 "Lemma 47 ‣ B.3 Length of the longest path in a branch ‣ Appendix B Proof of Theorem (Non-optimality of RRT) ‣ Sampling-based Algorithms for Optimal Motion Planning").

Define the random variable $\bar{\alpha}:=\inf\{\alpha\geq\mathbf{k}\,|\,{\cal L}\_{\alpha}>\epsilon\}$, and set $\bar{\alpha}:=\mathbf{k}$ if ${\cal L}\_{\alpha}\leq\epsilon$ for all $\alpha\geq\mathbf{k}$. Note that $\bar{\alpha}\geq\mathbf{k}$ holds surely. Hence, by Lemma [48](#Thmtheorem48 "Lemma 48 ‣ B.3 Length of the longest path in a branch ‣ Appendix B Proof of Theorem (Non-optimality of RRT) ‣ Sampling-based Algorithms for Optimal Motion Planning"), $\mathbb{E}[{\cal L}\_{\bar{\alpha}}]\leq\mathbb{E}[{\cal L}\_{\mathbf{k}}]$.
Let $I\_{\epsilon}$ be the indicator random variable for the event $S\_{\epsilon}:=\{\sup\_{\alpha\geq\mathbf{k}}{\cal L}\_{\alpha}>\epsilon\}$. Then,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}[{\cal L}\_{\mathbf{k}}]\geq\mathbb{E}[{\cal L}\_{\bar{\alpha}}]=\mathbb{E}[{\cal L}\_{\bar{\alpha}}I\_{\epsilon}]+\mathbb{E}[{\cal L}\_{\bar{\alpha}}(1-I\_{\epsilon})]\geq\epsilon\,\mathbb{P}(S\_{\epsilon}),$ |  |

where the last inequality follows from the fact that ${\cal L}\_{\bar{\alpha}}$ is at least $\epsilon$ whenever the event $S\_{\epsilon}$ occurs. ∎∎

A useful corollary of Lemmas [46](#Thmtheorem46 "Lemma 46 ‣ B.2 Length of the first path in a branch ‣ Appendix B Proof of Theorem (Non-optimality of RRT) ‣ Sampling-based Algorithms for Optimal Motion Planning") and [47](#Thmtheorem47 "Lemma 47 ‣ B.3 Length of the longest path in a branch ‣ Appendix B Proof of Theorem (Non-optimality of RRT) ‣ Sampling-based Algorithms for Optimal Motion Planning") is the following.

###### Corollary 49

For any $\epsilon>0$, $\lim\_{k\to\infty}\mathbb{P}(\{\sup\_{\alpha\geq\mathbf{k}}{\cal L}\_{\alpha}>\epsilon\})=0$.

### B.4 Violation of the necessary condition

Recall from Lemma [44](#Thmtheorem44 "Lemma 44 ‣ B.1 A necessary condition ‣ Appendix B Proof of Theorem (Non-optimality of RRT) ‣ Sampling-based Algorithms for Optimal Motion Planning") that a necessary condition for asymptotic optimality is that the $k$-th branch of the RRT contains vertices outside the $R$-ball centered at $x\_{\mathrm{init}}$ for infinitely many $k$, where $0<R<\inf\_{y\in{\cal X}\_{\mathrm{goal}}}\|y-x\_{\mathrm{init}}\|$. Clearly, the latter event can occur only if longest path in the $k$-th branch of the RRT is longer than $R$ for infinitely many $k$. That is,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\lim\_{n\to\infty}Y\_{n}^{\mathrm{RRT}}=c^{\*}\right\}\right)\leq\mathbb{P}\left(\limsup\_{k\to\infty}\left\{\sup\nolimits\_{\alpha\geq\mathbf{k}}{\cal L}\_{\alpha}>R\right\}\right).$ |  |

The event on the right hand side is monotonic in the sense that $\{\sup\_{\alpha>\mathbf{k}+1}{\cal L}\_{\alpha}>R\}\supseteq\{\sup\_{\alpha\geq\mathbf{k}}{\cal L}\_{\alpha}>R\}$ for all $k\in\mathbb{N}$. Hence, $\lim\_{k\to\infty}\{\sup\_{\alpha\geq\mathbf{k}}{\cal L}\_{\alpha}>R\}$ exists. In particular, $\mathbb{P}(\limsup\_{k\to\infty}\{\sup\_{\alpha\geq\mathbf{k}}{\cal L}\_{\alpha}>R\})=\mathbb{P}(\lim\_{k\to\infty}\{\sup\_{\alpha\geq\mathbf{k}}{\cal L}\_{\alpha}>R\})=\lim\_{k\to\infty}\mathbb{P}(\{\sup\_{\alpha\geq\mathbf{k}}{\cal L}\_{\alpha}>R\})$, where the last equality follows from the continuity of probability measures. Since $\lim\_{k\to\infty}\mathbb{P}\left(\left\{\sup\_{\alpha\geq\mathbf{k}}{\cal L}\_{\alpha}>R\right\}\right)=0$ for all $R>0$ by Corollary [49](#Thmtheorem49 "Corollary 49 ‣ B.3 Length of the longest path in a branch ‣ Appendix B Proof of Theorem (Non-optimality of RRT) ‣ Sampling-based Algorithms for Optimal Motion Planning"), $\mathbb{P}(\{\lim\_{n\to\infty}Y\_{n}^{\mathrm{RRT}}=c^{\*}\})=0$.

## Appendix C Proof of Theorem [34](#Thmtheorem34 "Theorem 34 (Asymptotic optimality of PRM∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") (Asymptotic optimality of PRM∗)

An outline of the proof is given below, before the details are provided.

### C.1 Outline of the proof

Let $\sigma^{\*}$ denote a robustly optimal path. By definition, $\sigma^{\*}$ has weak $\delta$-clearance.
First, define a sequence $\{\delta\_{n}\}\_{n\in\mathbb{N}}$ such that $\delta\_{n}>0$ for all $n\in\mathbb{N}$ and $\delta\_{n}$ approaches zero as $n$ approaches infinity. Construct a sequence $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$ of paths such that $\sigma\_{n}$ has strong $\delta\_{n}$-clearance for all $n\in\mathbb{N}$ and $\sigma\_{n}$ converges to $\sigma^{\*}$ as $n$ approaches infinity.

Second, define a sequence $\{q\_{n}\}\_{n\in\mathbb{N}}$. For all $n\in\mathbb{N}$, construct a set $B\_{n}=\{B\_{n,1},B\_{n,2},\dots,B\_{n,M\_{n}}\}$ of overlapping balls, each with radius $q\_{n}$, that collectively “cover” the path $\sigma\_{n}$. See Figures [23](#A3.F23 "Figure 23 ‣ C.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") and [24](#A3.F24 "Figure 24 ‣ C.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"). Let $x\_{m}\in B\_{n,m}$ and $x\_{m+1}\in B\_{n,m+1}$ be any two points from two consecutive balls in $B\_{n}$. Construct $B\_{n}$ such that (i) $x\_{m}$ and $x\_{m+1}$ have distance no more than the connection radius $r(n)$ and (ii) the straight path connecting $x\_{m}$ and $x\_{m+1}$ lies entirely within the obstacle free space.
These requirements can be satisfied by setting $\delta\_{n}$ and $q\_{n}$ to certain constant fractions of $r(n)$.

Let $A\_{n}$ denote the event that each ball in $B\_{n}$ contains at least one vertex of the graph returned by the PRM∗ algorithm, when the algorithm is run with $n$ samples.
Third, show that $A\_{n}$ occurs for all large $n$, with probability one. Clearly, in this case, the PRM∗ algorithm will connect the vertices in consecutive balls with an edge, and any path formed in this way will be collision-free.

Finally, show that any sequence of paths generated in this way converges to the optimal path $\sigma^{\*}$. Using the robustness of $\sigma^{\*}$, show that the cost of the best path in the graph returned by the PRM∗ algorithm converges to $c(\sigma^{\*})$ almost surely.

### C.2 Construction of the sequence $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$ of paths

The following lemma establishes a connection between the notions of strong and weak $\delta$-clearance.

###### Lemma 50

Let $\sigma^{\*}$ be a path be a path that has strong $\delta$-clearance.
Let $\{\delta\_{n}\}\_{n\in\mathbb{N}}$ be a sequence of real numbers such that $\lim\_{n\to\infty}\delta\_{n}=0$ and $0\leq\delta\_{n}\leq\delta$ for all $n\in\mathbb{N}$. Then, there exists a sequence $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$ of paths such that $\lim\_{n\to\infty}\sigma\_{n}=\sigma^{\*}$ and $\sigma\_{n}$ has strong $\delta\_{n}$-clearance for all $n\in\mathbb{N}$.

###### Proof.

First, define a sequence $\{{\cal X}\_{n}\}\_{n\in\mathbb{N}}$ of subsets of ${\cal X}\_{\mathrm{free}}$ such that ${\cal X}\_{n}$ is the closure of the $\delta\_{n}$-interior of ${\cal X}\_{\mathrm{free}}$, i.e.,

|  |  |  |
| --- | --- | --- |
|  | ${\cal X}\_{n}:=\mathrm{cl}(\mathrm{int}\_{\delta\_{n}}({\cal X}\_{\mathrm{free}}))$ |  |

for all $n\in\mathbb{N}$. Note that, by definition, (i) ${\cal X}\_{n}$ are closed subsets of ${\cal X}\_{\mathrm{free}}$, and (ii) any point ${\cal X}\_{n}$ has distance at least $\delta\_{n}$ to any point in the obstacle set ${\cal X}\_{\mathrm{obs}}$.

Then, construct the sequence $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$ of paths, where $\sigma\_{n}\in\Sigma\_{{\cal X}\_{n}}$, as follows.
Let $\psi:[0,1]\to\Sigma\_{\mathrm{free}}$ denote the homotopy with $\psi(0)=\sigma^{\*}$; the existence of $\psi$ is guaranteed by weak $\delta$-clearance of $\sigma^{\*}$.
Define

|  |  |  |
| --- | --- | --- |
|  | $\alpha\_{n}:=\max\_{\alpha\in[0,1]}\{\alpha\,|\,\psi(\alpha)\in\Sigma\_{{\cal X}\_{n}}\}\quad\mbox{ and }\quad\sigma\_{n}:=\psi(\alpha\_{n}).$ |  |

Since $\Sigma\_{{\cal X}\_{n}}$ is closed, the maximum in the definition of $\alpha\_{n}$ is attained. Moreover, since $\psi(1)$ has strong $\delta$-clearance and $\delta\_{n}\leq\delta$, $\sigma\_{n}\in\Sigma\_{{\cal X}\_{n}}$,
which implies the strong $\delta\_{n}$-clearance of $\sigma\_{n}$.

Clearly, $\bigcup\_{n\in\mathbb{N}}{\cal X}\_{n}={\cal X}\_{\mathrm{free}}$, since $\lim\_{n\to\infty}\delta\_{n}=0$.
Also, by weak $\delta$-clearance of $\sigma^{\*}$, for any $\alpha\in(0,1]$, there exists some $\delta\_{\alpha}\in(0,\delta]$ such that $\psi(\alpha)$ has strong $\delta\_{\alpha}$-clearance.
Then, $\lim\_{n\to\infty}\alpha\_{n}=0$, which implies $\lim\_{n\to\infty}\sigma\_{n}=\sigma^{\*}$.∎∎

Recall that the connection radius of the PRM∗ algorithm was defined as

|  |  |  |
| --- | --- | --- |
|  | $r\_{n}=\gamma\_{\mathrm{PRM}}\left(\frac{\log n}{n}\right)^{1/d}\,>\,2(1+1/d)^{1/d}\left(\frac{\mu(X\_{\mathrm{free}})}{\zeta\_{d}}\right)^{1/d}\left(\frac{\log n}{n}\right)^{1/d}$ |  |

(see Algorithm [4](#algorithm4 "In Optimal Probabilistic RoadMaps (PRM∗): ‣ 3.3 Proposed algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning") and the definition of the ${\tt Near}$ procedure in Section [3.1](#S3.SS1 "3.1 Primitive Procedures ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning")). Let $\theta\_{1}$ be a small positive constant; the precise value of $\theta\_{1}$ will be provided shortly in the proof of Lemma [52](#Thmtheorem52 "Lemma 52 ‣ C.4 The probability that each ball in 𝐵_𝑛 contains at least one vertex ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"). Define

|  |  |  |
| --- | --- | --- |
|  | $\delta\_{n}:=\min\left\{\delta,\frac{1+\theta\_{1}}{2+\theta\_{1}}r\_{n}\right\},\quad\quad\mbox{ for all }n\in\mathbb{N}.$ |  |

By definition, $0\leq\delta\_{n}\leq\delta$ holds. Moreover, $\lim\_{n\to\infty}\delta\_{n}=0$, since $\lim\_{n\to\infty}r\_{n}=0$. Then, by Lemma [50](#Thmtheorem50 "Lemma 50 ‣ C.2 Construction of the sequence {𝜎_𝑛}_{𝑛∈ℕ} of paths ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"), there exists a sequence $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$ of paths such that $\lim\_{n\to\infty}\sigma\_{n}=\sigma^{\*}$ and $\sigma\_{n}$ has strong $\delta\_{n}$-clearance for all $n\in\mathbb{N}$.

### C.3 Construction of the sequence $\{B\_{n}\}\_{n\in\mathbb{N}}$ of sets of balls

First, a construction of a finite set of balls that collectively “cover” a path $\sigma\_{n}$ is provided. The construction is illustrated in Figure [23](#A3.F23 "Figure 23 ‣ C.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning").

###### Definition 51 (Covering balls)

Given a path $\sigma\_{n}:[0,1]\to{\cal X}$, and the real numbers $q\_{n},l\_{n}\in\mathbb{R}\_{>0}$, the set ${\tt CoveringBalls}(\sigma\_{n},q\_{n},l\_{n})$ is defined as a set $\{B\_{n,1},B\_{n,2},\dots,B\_{n,M\_{n}}\}$ of $M\_{n}$ balls of radius $q\_{n}$ such that $B\_{n,m}$ is centered at $\sigma(\tau\_{m})$, and

* •

  the center of $B\_{n,1}$ is $\sigma(0)$, i.e., $\tau\_{1}=0$,
* •

  the centers of two consecutive balls are exactly $l\_{n}$ apart, i.e., $\tau\_{m}:=\min\{\tau\in[\tau\_{m-1},1]\,|\,\|\sigma(\tau)-\sigma(\tau\_{m-1})\|\geq l\_{n}\}$ for all $m\in\{2,3,\dots,M\_{n}\}$,
* •

  and $M-1$ is the largest number of balls that can be generated in this manner while the center of the last ball, $B\_{n,M\_{n}}$ is $\sigma(1)$, i.e., $\tau\_{M\_{n}}=1$.

Figure 23: An illustration of the ${\tt CoveringBalls}$ construction. A set of balls that collectively cover the trajectory $\sigma\_{n}$ is shown. All balls have the same radius, $q\_{n}$. The spacing between the centers of two consecutive balls is $l\_{n}$.

For each $n\in\mathbb{N}$, define

|  |  |  |
| --- | --- | --- |
|  | $q\_{n}:=\frac{\delta\_{n}}{1+\theta\_{1}}.$ |  |

Construct the set $B\_{n}=\{B\_{n,1},B\_{n,2},\dots,B\_{n,M\_{n}}\}$ of balls as $B\_{n}:={\tt CoveringBalls}(\sigma\_{n},q\_{n},\theta\_{1}q\_{n})$ using Definition [51](#Thmtheorem51 "Definition 51 (Covering balls) ‣ C.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") (see Figure [23](#A3.F23 "Figure 23 ‣ C.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning")).
By construction, each ball in $B\_{n}$ has radius $q\_{n}$ and the centers of consecutive balls in $B\_{n}$ are $\theta\_{1}q\_{n}$ apart (see Figure [24](#A3.F24 "Figure 24 ‣ C.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") for an illustration of covering balls with this set of parameters). The balls in $B\_{n}$ collectively cover the path $\sigma\_{n}$.

Figure 24: An illustration of the covering balls for PRM∗ algorithm. The $\delta\_{n}$-ball is guaranteed to be inside the obstacle-free space. The connection radius $r\_{n}$ is also shown as the radius of the connection ball centered at a vertex $x\in B\_{n,m}$. The vertex $x$ is connected to all other vertices that lie within the connection ball.

### C.4 The probability that each ball in $B\_{n}$ contains at least one vertex

Recall that $G^{\mathrm{PRM}^{\*}}\_{n}=(V^{\mathrm{PRM}^{\*}}\_{n},E^{\mathrm{PRM}^{\*}}\_{n})$ denotes the graph returned by the PRM∗ algorithm, when the algorithm is run with $n$ samples.
Let $A\_{n,m}$ denote the event that the ball $B\_{n,m}$ contains at least one vertex of the graph generated by the PRM∗ algorithm, i.e., $A\_{n,m}=\left\{B\_{n,m}\cap V^{\mathrm{PRM}^{\*}}\_{n}\neq\emptyset\right\}$.
Let $A\_{n}$ denote the event that all balls in $B\_{n}$ contain at least one vertex of the PRM∗ graph, i.e., $A\_{n}=\bigcap\_{m=1}^{M\_{n}}A\_{n,m}$.

###### Lemma 52

If $\gamma\_{\mathrm{PRM}}>2\,(1+1/d)^{1/d}\,\left(\frac{\mu(X\_{\mathrm{free}})}{\zeta\_{d}}\right)^{1/d}$, then there exists a constant $\theta\_{1}>0$ such that the event that every ball in $B\_{n}$ contains at least one vertex of the PRM∗ graph occurs for all large enough $n$ with probability one, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\liminf\_{n\to\infty}A\_{n}\right)=1.$ |  |

###### Proof.

The proof is based on a Borel-Cantelli argument which can be summarized as follows.
Recall that $A\_{n}^{c}$ denotes the complement of $A\_{n}$.
First, the sum $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{c})$ is shown to be bounded. By the Borel-Cantelli lemma ([Grimmett and Stirzaker, 2001](#bib.bib36)), this implies that the probability that $A\_{n}$ holds infinitely often as $n$ approaches infinity is zero. Hence, the probability that $A\_{n}$ holds infinitely often is one.
In the rest of the proof, an upper bound on $\mathbb{P}(A\_{n})$ is computed, and this upper bound is shown to be summable.

First, compute a bound on the number of balls in $B\_{n}$ as follows. Let $s\_{n}$ denote the length of $\sigma\_{n}$, i.e., $s\_{n}:=\mathrm{TV}(\sigma\_{n})$. Recall that the balls in $B\_{n}$ were constructed such that the centers of two consecutive balls in $B\_{n}$ have distance $\theta\_{1}\,q\_{n}$. The segment of $\sigma\_{n}$ that starts at the center of $B\_{n,m}$ and ends at the center of $B\_{n,m+1}$ has length at least $\theta\_{1}q\_{n}$, except for the last segment, which has length less than or equal to $\theta\_{1}q\_{n}$. Let $n\_{0}\in\mathbb{N}$ be the number such that $\delta\_{n}<\delta$ for all $n\geq n\_{0}$. Then, for all $n\geq n\_{0}$,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\operatorname{card}\left(B\_{n}\right)=M\_{n}$ | $\displaystyle\leq$ | $\displaystyle\frac{s\_{n}}{\theta\_{1}q\_{n}}=\frac{(1+\theta\_{1})s\_{n}}{\theta\_{1}\delta\_{n}}=\frac{(2+\theta\_{1})\,s\_{n}}{\theta\_{1}\,r\_{n}}$ |  |
|  |  | $\displaystyle=$ | $\displaystyle\frac{(2+\theta\_{1})\,s\_{n}}{\theta\_{1}\,\gamma\_{\mathrm{PRM}}}\left(\frac{n}{\log n}\right)^{1/d}.$ |  |

Second, compute the volume of a single ball in $B\_{i}$ as follows.
Recall that $\mu(\cdot)$ denotes the usual Lebesgue measure, and $\zeta\_{d}$ denotes the volume of a unit ball in the $d$-dimensional Euclidean space. For all $n\geq n\_{0}$,

|  |  |  |
| --- | --- | --- |
|  | $\mu(B\_{n,m})=\zeta\_{d}\,q\_{n}^{d}=\zeta\_{d}\left(\frac{\delta\_{n}}{1+\theta\_{1}}\right)^{d}=\zeta\_{d}\left(\frac{r\_{n}}{2+\theta\_{1}}\right)^{d}=\zeta\_{d}\,\left(\frac{\gamma\_{\mathrm{PRM}}}{2+\theta\_{1}}\right)^{d}\,\frac{\log n}{n}$ |  |

For all $n\geq I$, the probability that a single ball, say $B\_{n,1}$, does not contain a vertex of the graph generated by the PRM∗ algorithm, when the algorithm is run with $n$ samples, is

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}\left(A\_{n,1}^{c}\right)$ | $\displaystyle=$ | $\displaystyle\left(1-\frac{\mu(B\_{n,1})}{\mu(X\_{\mathrm{free}})}\right)^{n}$ |  |
|  |  | $\displaystyle=$ | $\displaystyle\left(1-\frac{\zeta\_{d}}{\mu(X\_{\mathrm{free}})}\left(\frac{\gamma\_{\mathrm{PRM}}}{2+\theta\_{1}}\right)^{d}\frac{\log n}{n}\right)^{n}$ |  |

Using the inequality $(1-1/f(n))^{r}\leq e^{-r/f(n)}$, the right-hand side can be bounded as

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}(A\_{n,1})\leq e^{-\frac{\zeta\_{d}}{\mu(X\_{\mathrm{free}})}\left(\frac{\gamma\_{\mathrm{PRM}}}{2+\theta\_{1}}\right)^{d}\log n}=n^{-\frac{\zeta\_{d}}{\mu(X\_{\mathrm{free}})}\left(\frac{\gamma\_{\mathrm{PRM}}}{2+\theta\_{1}}\right)^{d}}.$ |  |

Hence,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}\left(A\_{n}^{c}\right)=\mathbb{P}\left(\bigcup\nolimits\_{m=1}^{M\_{n}}A\_{n,m}^{c}\right)$ | $\displaystyle\leq$ | $\displaystyle\sum\_{m=1}^{M\_{n}}\mathbb{P}\left(A\_{n,m}^{c}\right)=M\_{n}\,\,\mathbb{P}(A\_{n,1}^{c})$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle\frac{(2+\theta\_{1})s\_{n}}{\theta\_{1}\,\gamma\_{\mathrm{PRM}}}\left(\frac{n}{\log n}\right)^{1/d}i^{-\frac{\zeta\_{d}}{\mu(X\_{\mathrm{free}})}\left(\frac{\gamma\_{\mathrm{PRM}}}{2+\theta\_{1}}\right)^{d}}$ |  |
|  |  | $\displaystyle=$ | $\displaystyle\frac{(2+\theta\_{1})s\_{n}}{\theta\_{1}\,\gamma\_{\mathrm{PRM}}}\,\frac{1}{(\log n)^{d}}\,\,n^{-\left(\frac{\zeta\_{d}}{\mu(X\_{\mathrm{free}})}\left(\frac{\gamma\_{\mathrm{PRM}}}{2+\theta\_{1}}\right)^{d}-\frac{1}{d}\right)}$ |  |

where the first inequality follows from the union bound.

Finally, $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{c})<\infty$ holds, if $\frac{\zeta\_{d}}{\mu(X\_{\mathrm{free}})}\left(\frac{\gamma\_{\mathrm{PRM}}}{2+\theta\_{1}}\right)^{d}-\frac{1}{d}>1$, which can be satisfied for any $\gamma\_{PRM}>2(1+1/d)^{1/d}\left(\frac{\mu(X\_{\mathrm{free}})}{\zeta\_{d}}\right)^{1/d}$ by appropriately choosing $\theta\_{1}$.
Then, by the Borel-Cantelli lemma ([Grimmett and Stirzaker, 2001](#bib.bib36)), $\mathbb{P}(\limsup\_{n\to\infty}A\_{n}^{c})=0$, which implies $\mathbb{P}(\liminf\_{n\to\infty}A\_{n})=1$.∎∎

### C.5 Connecting the vertices in subsequent balls in $B\_{n}$

Let $Z\_{n}:=\{x\_{1},x\_{2},\dots,x\_{M\_{n}}\}$ be any set of points such that $x\_{m}\in B\_{n,m}$ for each $m\in\{1,2,\dots,M\_{n}\}$.
The following lemma states that for all $n\in\mathbb{N}$ and all $m\in\{1,2,\dots,M\_{n}-1\}$, the distance between $x\_{m}$ and $x\_{m+1}$ is less than the connection radius, $r\_{n}$, which implies that the PRM∗ algorithm will attempt to connect the two points $x\_{m}$ and $x\_{m+1}$ if they are in the vertex set of the PRM∗ algorithm.

###### Lemma 53

If $x\_{n,m}\in B\_{n,m}$ and $x\_{n,m+1}\in B\_{n,m+1}$, then $\|x\_{n,m+1}-x\_{n,m}\|\leq r\_{n}$, for all $n\in\mathbb{N}$ and all $m\in\{1,2,\dots,M\_{i}-1\}$.

###### Proof.

Recall that each ball in $B\_{n}$ has radius $q\_{n}=\frac{\delta\_{n}}{(1+\theta\_{1})}$. Given any two points $x\_{m}\in B\_{n,m}$ and $x\_{m+1}\in B\_{n,m+1}$, all of the following hold: (i) $x\_{m}$ has distance $q\_{n}$ to the center of $B\_{n,m}$, (ii) $x\_{m+1}$ has distance $q\_{n}$ to the center of $B\_{n,m+1}$, and (iii) centers of $B\_{n,m}$ and $B\_{n,m+1}$ have distance $\theta\_{1}\,q\_{n}$ to each other. Then,

|  |  |  |
| --- | --- | --- |
|  | $\|x\_{n,m+1}-x\_{n,m}\|\leq(2+\theta\_{1})\,q\_{n}=\frac{2+\theta\_{1}}{1+\theta\_{1}}\,\delta\_{n}\leq r\_{n},$ |  |

where the first inequality is obtained by an application of the triangle inequality and the last inequality follows from the definition of $\delta\_{n}=\min\{\delta,\frac{1+\theta\_{1}}{2+\theta\_{1}}\,r\_{n}\}$. ∎∎

By Lemma [53](#Thmtheorem53 "Lemma 53 ‣ C.5 Connecting the vertices in subsequent balls in 𝐵_𝑛 ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"), conclude that the PRM∗ algorithm will attempt to connect any two vertices in consecutive balls in $B\_{n}$. The next lemma shows that any such connection attempt will, in fact, be successful. That is, the path connecting $x\_{n,m}$ and $x\_{n,m+1}$ is collision-free for all $m\in\{1,2,\dots,M\_{n}\}$.

###### Lemma 54

For all $n\in\mathbb{N}$ and all $m\in\{1,2,\dots,M\_{n}\}$, if $x\_{m}\in B\_{n,m}$ and $x\_{m+1}\in B\_{n,m+1}$, then the line segment connecting $x\_{n,m}$ and $x\_{n,m+1}$ lies in the obstacle-free space, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\alpha\,x\_{n,m}+(1-\alpha)\,x\_{n,m+1}\in X\_{\mathrm{free}},\quad\quad\mbox{ for all }\alpha\in[0,1].$ |  |

###### Proof.

Recall that $\sigma\_{n}$ has strong $\delta\_{n}$-delta clearance and that the radius $q\_{n}$ of each ball in $B\_{n}$ was defined as $q\_{n}=\frac{\delta\_{n}}{1+\theta\_{1}}$, where $\theta\_{1}>0$ is a constant. Hence, any point along the trajectory $\sigma\_{n}$ has distance at least $(1+\theta\_{1})\,q\_{n}$ to any point in the obstacle set.
Let $y\_{m}$ and $y\_{m+1}$ denote the centers of the balls $B\_{n,m}$ and $B\_{n,m+1}$, respectively.
Since $y\_{m}=\sigma(\tau\_{m})$ and $y\_{m+1}=\sigma(\tau\_{m+1})$ for some $\tau\_{m}$ and $\tau\_{m+1}$, $y\_{m}$ and $y\_{m+1}$ also have distance $(1+\theta\_{1})q\_{n}$ to any point in the obstacle set.

Clearly, $\|x\_{m}-y\_{m}\|\leq q\_{n}$. Moreover, the following inequality holds:

|  |  |  |
| --- | --- | --- |
|  | $\|x\_{m+1}-y\_{m}\|\leq\|(x\_{m}-y\_{m+1})+(y\_{m+1}-y\_{m})\|\leq\|x\_{m+1}-y\_{m+1}\|+\|y\_{m+1}-y\_{m}\|\leq q\_{n}+\theta\_{1}\,q\_{n}=(1+\theta\_{1})\,q\_{n}.$ |  |

where the second inequality follows from the triangle inequality and the third inequality follows from the construction of balls in $B\_{n}$.

For any convex combination $x\_{\alpha}:=\alpha\,x\_{m}+(1-\alpha)\,x\_{m+1}$, where $\alpha\in[0,1]$, the distance between $x\_{\alpha}$ and $y\_{m}$ can be bounded as follows:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\big\|\big(\alpha\,x\_{m}+(1+\alpha)\,x\_{m+1}\big)-y\_{m}\big\|$ | $\displaystyle=$ | $\displaystyle\big\|\alpha\,(x\_{m}-y\_{m})+(1+\alpha)\,(x\_{m+1}-y\_{m})\big\|$ |  |
|  |  | $\displaystyle=$ | $\displaystyle\alpha\,\|x\_{m}-y\_{m}\|+(1+\alpha)\,\|x\_{m+1}-y\_{m}\|$ |  |
|  |  | $\displaystyle=$ | $\displaystyle\alpha\,q\_{n}+(1+\alpha)\,(1+q\_{n})\leq(1+\theta\_{1})\,q\_{n},$ |  |

where the second equality follows from the linearity of the norm. Hence, any point along the line segment connecting $x\_{m}$ and $x\_{m+1}$ has distance at most $(1+\theta\_{1})\,q\_{n}$ to $y\_{m}$. Since, $y\_{m}$ has distance at least $(1+\theta\_{1})q\_{n}$ to any point in the obstacle set, the line segment connecting $x\_{m}$ and $x\_{m+1}$ is collision-free. ∎∎

### C.6 Convergence to the optimal path

Let $P\_{n}$ denote the set of all paths in the graph $G^{\mathrm{PRM}^{\*}}\_{n}=(V^{\mathrm{PRM}^{\*}}\_{n},E^{\mathrm{PRM}^{\*}}\_{n})$. Let $\sigma\_{n}^{\prime}$ be the path that is closest to $\sigma\_{n}$ in terms of the bounded variation norm among all those paths in $P\_{n}$, i.e.,
$\sigma\_{n}^{\prime}:=\min\_{\sigma^{\prime}\in P\_{n}}\|\sigma^{\prime}-\sigma\_{n}\|.$
Note that the sequence $\{\sigma\_{n}^{\prime}\}\_{n\in\mathbb{N}}$ is a random sequence of paths, since the graph $G^{\mathrm{PRM}^{\*}}\_{n}$, hence the set $P\_{n}$ of paths is random.
The following lemma states that the bounded variation distance between $\sigma\_{n}^{\prime}$ and $\sigma\_{n}$ approaches to zero, with probability one.

###### Lemma 55

The random variable $\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}$ converges to zero almost surely, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\lim\nolimits\_{n\to\infty}\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}=0\right\}\right)=1.$ |  |

###### Proof.

The proof of this lemma is based on a Borel-Cantelli argument.
It is shown that $\sum\_{n\in\mathbb{N}}\mathbb{P}(\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}>\epsilon)$ is finite for any $\epsilon>0$, which implies that $\|\sigma\_{n}^{\prime}-\sigma\_{n}\|$ converges to zero almost surely by the Borel-Cantelli lemma ([Grimmett and Stirzaker, 2001](#bib.bib36)).
This proof uses a Poissonization argument in one of the intermediate steps. That is, a particular result is shown to hold in the Poisson process described in Lemma [11](#Thmtheorem11 "Lemma 11 ( ( ) ) ‣ 2.2 Random Geometric Graphs ‣ 2 Preliminary Material ‣ Sampling-based Algorithms for Optimal Motion Planning"). Subsequently, the result is de-Poissonized, i.e., shown to hold also for the original process.

Fix some $\epsilon>0$.
Let $\alpha,\beta\in(0,1)$ be two constants, both independent of $n$.
Recall that $q\_{n}$ is the radius of each ball in the set $B\_{n}$ of balls covering the path $\sigma\_{n}$. Let $I\_{n,m}$ denote the indicator variable for the event that the ball $B\_{n,m}$ has no point that is within a distance $\beta\,q\_{n}$ from the center of $B\_{n,m}$.
For a more precise definition, let $\beta\,B\_{n,m}$ denote the ball that is centered at the center of $B\_{n,m}$ and has radius $\beta\,r\_{n}$. Then,

|  |  |  |
| --- | --- | --- |
|  | $I\_{n,m}:=\begin{cases}1,&\mbox{if }(\beta\,B\_{n,m})\cap V^{\mathrm{PRM}^{\*}}=\emptyset,\\ 0,&\mbox{otherwise.}\end{cases}$ |  |

Let $K\_{n}$ denote the number of balls in $B\_{n}$ that do not contain a vertex that is within a $\beta\,q\_{n}$ distance to the center of that particular ball, i.e., $K\_{n}:=\sum\_{m=1}^{M\_{n}}I\_{n,m}$.

Consider the event that $I\_{n,m}$ holds for at most an $\alpha$ fraction of the balls in $B\_{n}$, i.e.,
$\{K\_{n}\leq\alpha\,M\_{n}\}.$
This event is important for the following reason.
Recall that the vertices in subsequent balls in $B\_{n}$ are connected by edges in $G^{\mathrm{PRM}^{\*}}\_{n}$ by Lemmas [53](#Thmtheorem53 "Lemma 53 ‣ C.5 Connecting the vertices in subsequent balls in 𝐵_𝑛 ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") and [54](#Thmtheorem54 "Lemma 54 ‣ C.5 Connecting the vertices in subsequent balls in 𝐵_𝑛 ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning").
If only at most an $\alpha$ fraction of the balls do not have a vertex that is less than a distance of $\beta\,r\_{n}$ from their centers (hence, a $(1-\alpha)$ fraction have at least one vertex within a distance of $\beta\,r\_{n}$ from their centers), i.e., $\{K\_{n}\leq\alpha\,M\_{n}\}$ holds, then the bounded variation difference between $\sigma\_{n}^{\prime}$ and $\sigma\_{n}$ is at most $(\sqrt{2}\,\alpha+\beta(1-\alpha))L\leq\sqrt{2}\,(\alpha+\beta)L$, where $L$ is a finite bound on the length of all paths in $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$, i.e., $L:=\sup\_{n\in\mathbb{N}}\mathrm{TV}(\sigma\_{n})$.
That is,

|  |  |  |
| --- | --- | --- |
|  | $\{K\_{n}\leq\alpha\,M\_{n}\}\subseteq\left\{\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}\leq\sqrt{2}\,(\alpha+\beta)\,L\right\}$ |  |

Taking the complement of both sides and using the monotonicity of probability measures,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}>\sqrt{2}\,(\alpha+\beta)\,L\right\}\right)\leq\mathbb{P}\left(\{K\_{n}\geq\alpha\,M\_{n}\}\right).$ |  |

In the rest of the proof, it is shown that the right hand side of the inequality above is summable for all small $\alpha,\beta>0$, which implies that $\mathbb{P}\left(\{\|\sigma\_{n}^{\prime}-\sigma\_{n}\ \|>\epsilon\}\right)$ is summable for all small $\epsilon>0$.

For this purpose, the process that provides independent uniform samples from ${\cal X}\_{\mathrm{free}}$ is approximated by an equivalent Poisson process described in Section [2.2](#S2.SS2 "2.2 Random Geometric Graphs ‣ 2 Preliminary Material ‣ Sampling-based Algorithms for Optimal Motion Planning"). A more precise definition is given as follows. Let $\{X\_{1},X\_{2},\dots,X\_{n}\}$ denote the binomial point process corresponding to the ${\tt SampleFree}$ procedure. Let $\nu<1$ be a constant independent of $n$. Recall that $\mathrm{Poisson}(\nu\,n)$ denotes the Poisson random variable with intensity $\nu\,n$ (hence, mean value $\nu\,n$). Then, the process ${\cal P}\_{\nu\,n}:=\{X\_{1},X\_{2},\dots,X\_{\mathrm{Poisson}(\nu\,n)}\}$ is a Poisson process restricted to $\mu({\cal X}\_{\mathrm{free}})$ with intensity $\nu\,n/\mu({\cal X}\_{\mathrm{free}})$ (see Lemma [11](#Thmtheorem11 "Lemma 11 ( ( ) ) ‣ 2.2 Random Geometric Graphs ‣ 2 Preliminary Material ‣ Sampling-based Algorithms for Optimal Motion Planning")). Thus, the expected number of points of this Poisson process is $\nu\,n$.

Clearly, the set of points generated by one process is a subset of the those generated by the other. However, since $\nu<1$, in most trials the Poisson point process ${\cal P}\_{\nu\,n}$ is a subset of the binomial point process.

Define the random variable $\widetilde{K}\_{n}$ denote the number of balls of that fail to have one sample within a distance $\beta\,r\_{n}$ to their centers, when the underlying point process is ${\cal P}\_{\nu\,n}$ (instead of the independent uniform samples provided by the ${\tt SampleFree}$ procedure). In other words, $\widetilde{K}\_{n}$ is the random variable that is defined similar to $K\_{n}$, except that the former is defined with respect to the points of ${\cal P}\_{\nu\,n}$ whereas the latter is defined with respect to the $n$ samples returned by ${\tt SampleFree}$ procedure.

Since $\{\widetilde{K}\_{n}>\alpha\,M\_{n}\}$ is a decreasing event, i.e., the probability that it occurs increases if ${\cal P}\_{\nu n}$ includes fewer samples, the following bound holds ([Penrose, 2003](#bib.bib79), see, e.g.,)

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\big(\left\{K\_{n}\geq\alpha\,M\_{n}\right\}\big)\leq\mathbb{P}\big(\{\widetilde{K}\_{n}\geq\alpha\,M\_{n}\}\big)+\mathbb{P}(\{\mathrm{Poisson}(\nu\,n)\geq n\}).$ |  |

Since a Poisson random variable has exponentially-decaying tails, the second term on the right hand side can be bounded as

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\mathbb{P}(\{\mathrm{Poisson}(\nu\,n)\geq n\})\leq e^{-cn},$ |  |

where $c>0$ is a constant.

The first term on the right hand side can be computed directly as follows. First, for all small $\beta$, the balls of radius $\beta\,r\_{n}$ are all disjoint (see Figure [25](#A3.F25 "Figure 25 ‣ Proof. ‣ C.6 Convergence to the optimal path ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning")). Denote this set of balls by $\widetilde{B}\_{n,m}=\{\widetilde{B}\_{n,1},\widetilde{B}\_{n,2},\dots,\widetilde{B}\_{n,M\_{n}}\}$. More precisely, $\widetilde{B}\_{n,m}$ is the ball of radius $\beta\,q\_{n}$ centered at the center of $B\_{n,m}$.
Second, observe that the event $\{K\_{n}>\alpha\,M\_{n}\}$ is equivalent to the event that at least an $\alpha$ fraction of all the balls in $\widetilde{B}\_{n}$ include at least one point of the process ${\cal P}\_{\nu\,n}$. Since, the point process ${\cal P}\_{\nu\,n}$ is Poisson and the balls in $\widetilde{B}\_{n}$ are disjoint for all small enough $\beta$, the probability that a single ball in $\widetilde{B}\_{n}$ does not contain a sample is
$p\_{n}:=\exp(-\zeta\_{d}\,(\beta q\_{n})^{d}\,\nu\,n/\mu({\cal X}\_{\mathrm{free}}))\leq\exp(-c\,\beta\,\nu\,\log n)$
for some constant $c$.
Third, by the independence property of the Poisson point process, the number of balls in $\widetilde{B}\_{n}$ that do not include a point of the point process ${\cal P}\_{\nu\,n}$ is a binomial random variable with parameters $M\_{n}$ and $p\_{n}$. Then, for all large $n$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\Big(\big\{\widetilde{K}\_{n}\geq\alpha\,M\_{n}\big\}\Big)\leq\mathbb{P}\left(\left\{\mathrm{Binomial}(M\_{n},p\_{n})\geq\alpha M\_{n}\right\}\right)\leq\exp(-M\_{n}\,p\_{n}).$ |  |

Figure 25: The set $\widetilde{B}\_{n,m}$ of non-intersection balls is illustrated.

Combining the two inequalities above, the following bound is obtained for the original sampling process

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{K\_{n}\geq\alpha\,M\_{n}\right\}\right)\leq e^{-c\,n}+e^{-M\_{n}\,p\_{n}}.$ |  |

Summing up both sides,

|  |  |  |
| --- | --- | --- |
|  | $\sum\_{n=1}^{\infty}\mathbb{P}\left(\left\{K\_{n}\geq\alpha\,n\right\}\right)<\infty.$ |  |

This argument holds for all $\alpha,\beta,\nu>0$. Hence, for all $\epsilon>0$,

|  |  |  |
| --- | --- | --- |
|  | $\sum\_{n=1}^{\infty}\mathbb{P}\left(\left\{\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}>\epsilon\right\}\right)<\infty.$ |  |

Then, by the Borel-Cantelli lemma, $\mathbb{P}\left(\left\{\lim\_{n\to\infty}\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}=0\right\}\right)=1$.∎∎

Finally, the following lemma states that the cost of the minimum cost path in the graph returned by the ${\mathrm{PRM}^{\*}}$ algorithm converges to the optimal cost $c^{\*}$ with probability one.
Recall that $Y^{\mathrm{PRM}^{\*}}\_{n}$ denotes the cost of the minimum-cost path in the graph returned by the ${\mathrm{PRM}^{\*}}$ algorithm, when the algorithm is run with $n$ samples.

###### Lemma 56

Under the assumptions of Theorem [34](#Thmtheorem34 "Theorem 34 (Asymptotic optimality of PRM∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"), the cost of the minimum-cost path present in the graph returned by the ${\mathrm{PRM}^{\*}}$ algorithm converges to the optimal cost $c^{\*}$ as the number of samples approaches infinity, with probability one, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\lim\_{n\to\infty}Y^{\mathrm{PRM}^{\*}}\_{n}=c^{\*}\right\}\right)=1.$ |  |

###### Proof.

Recall that $\sigma^{\*}$ denotes the optimal path, and that $\lim\_{n\to\infty}\sigma\_{n}=\sigma^{\*}$ holds surely. By Lemma [55](#Thmtheorem55 "Lemma 55 ‣ C.6 Convergence to the optimal path ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"), $\lim\_{n\to\infty}\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}=0$ holds with probability one. Thus, by repeated application of the triangle inequality,
$\lim\_{n\to\infty}\|\sigma\_{n}^{\prime}-\sigma^{\*}\|\_{\mathrm{BV}}=0,$
i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\big\{\lim\_{n\to\infty}\|\sigma\_{n}^{\prime}-\sigma^{\*}\|\_{\mathrm{BV}}=0\big\}\right)=1.$ |  |

Then, by the robustness of the optimal path $\sigma^{\*}$, it follows that

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\big\{\lim\_{n\to\infty}c(\sigma\_{n}^{\prime})=c^{\*}\big\}\right)=1.$ |  |

That is the costs of the paths $\{\sigma\_{n}^{\prime}\}\_{n\in\mathbb{N}}$ converges to the optimal cost almost surely, as the number of samples approaches infinity.
∎∎

## Appendix D Proof of Theorem [35](#Thmtheorem35 "Theorem 35 (Asymptotic optimality of 𝑘-nearest PRM∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") (Asymptotic Optimality of $k$-nearest PRM∗)

The proof of this theorem is similar to that of Theorem [34](#Thmtheorem34 "Theorem 34 (Asymptotic optimality of PRM∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"). For the reader’s convenience, a complete proof is provided at the expense of repeating some of the arguments.

### D.1 Outline of the proof

Let $\sigma^{\*}$ be a robust optimal path with weak $\delta$-clearance. First, define the sequence $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$ of paths as in the proof of Theorem [34](#Thmtheorem34 "Theorem 34 (Asymptotic optimality of PRM∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").

Second, define a sequence $\{q\_{n}\}\_{n\in\mathbb{N}}$ and tile $\sigma\_{n}$ with a set $B\_{n}=\{B\_{n,1},B\_{n,2},\dots,B\_{n,M}\}$ of overlapping balls of radius $q\_{n}$. See Figures [23](#A3.F23 "Figure 23 ‣ C.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") and [26](#A4.F26 "Figure 26 ‣ D.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix D Proof of Theorem (Asymptotic Optimality of 𝑘-nearest PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"). Let $x\_{m}\in B\_{n,m}$ and $x\_{m+1}\in B\_{n,m+1}$ be any two points from subsequent balls in $B\_{n}$. Construct $B\_{n}$ such that the straight path connecting $x\_{m}$ and $x\_{m+1}$ lies entirely inside the obstacle free space.
Also, construct a set $B\_{n}^{\prime}$ of balls such that (i) $B\_{n,m}^{\prime}$ and $B\_{n,m}$ are centered at the same point and (ii) $B\_{n,m}$ contains $B\_{n,m}$, and $B\_{n,m+1}$, for all $m\in\{1,2,\dots,M\_{n}-1\}$.

Let $A\_{n}$ denote the event that each ball in $B\_{n}$ contains at least one vertex, and $A\_{n}^{\prime}$ denote the event that each ball in $B\_{n}^{\prime}$ contains at most $k(n)$ vertices of the graph returned by the $k$-nearest PRM∗ algorithm.
Third, show that $A\_{n}$ and $A\_{n}^{\prime}$ occur together for all large $n$, with probability one. Clearly, this implies that the PRM∗ algorithm will connect vertices in subsequent ball in $B\_{n}$ with an edge, and any path formed by connecting such vertices will be collision-free.

Finally, show that any sequence of paths formed in this way converges to $\sigma^{\*}$. Using the robustness of $\sigma^{\*}$, show that the best path in the graph returned by the $k$-nearest PRM∗ algorithm converges to $c(\sigma^{\*})$ almost surely.

### D.2 Construction of the sequence $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$ of paths

Let $\theta\_{1},\theta\_{2}\in\mathbb{R}\_{>0}$ be two constants, the precise values of which will be provided shortly.
Define

|  |  |  |
| --- | --- | --- |
|  | $\delta\_{n}:=\min\left\{\delta,\,(1+\theta\_{1})\left(\frac{(1+1/d+\theta\_{2})\,\mu(X\_{\mathrm{free}})}{\zeta\_{d}}\right)^{1/d}\left(\frac{\log n}{n}\right)^{1/d}\right\}.$ |  |

Since $\lim\_{n\to\infty}\delta\_{n}=0$ and $0\leq\delta\_{n}\leq\delta$ for all $n\in\mathbb{N}$, by Lemma [50](#Thmtheorem50 "Lemma 50 ‣ C.2 Construction of the sequence {𝜎_𝑛}_{𝑛∈ℕ} of paths ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"), there exists a sequence $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$ of paths such that $\lim\_{n\to\infty}\sigma\_{n}=\sigma^{\*}$ and $\sigma\_{n}$ is strongly $\delta\_{n}$-clear for all $n\in\mathbb{N}$.

### D.3 Construction of the sequence $\{B\_{n}\}\_{n\in\mathbb{N}}$ of sets of balls

Define

|  |  |  |
| --- | --- | --- |
|  | $q\_{n}:=\frac{\delta\_{n}}{1+\theta\_{1}}.$ |  |

For each $n\in\mathbb{N}$, use Definition [51](#Thmtheorem51 "Definition 51 (Covering balls) ‣ C.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") to construct a set $B\_{n}=\{B\_{n,1},B\_{n,2},\dots,B\_{n,M\_{n}}\}$ of overlapping balls that collectively cover $\sigma\_{n}$ as $B\_{n}:={\tt CoveringBalls}(\sigma\_{n},q\_{n},\theta\_{1}q\_{n})$ (see Figures [23](#A3.F23 "Figure 23 ‣ C.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") and [26](#A4.F26 "Figure 26 ‣ D.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix D Proof of Theorem (Asymptotic Optimality of 𝑘-nearest PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") for an illustration).

Figure 26: An illustration of the covering balls for the $k$-nearest PRM∗ algorithm. The $\delta\_{n}$ ball is guaranteed to contain the balls $B\_{n,m}$ and $B\_{n,m+1}$.

### D.4 The probability that each ball in $B\_{n}$ contains at least one vertex

Recall that $G^{k\mathrm{PRM}^{\*}}\_{n}=(V^{k\mathrm{PRM}^{\*}}\_{n},E^{k\mathrm{PRM}^{\*}}\_{n})$ denotes the graph returned by the $k$-nearest PRM∗ algorithm, when the algorithm is run with $n$ samples.
Let $A\_{n,m}$ denote the event that the ball $B\_{n,m}$ contains at least one vertex from $V^{k\mathrm{PRM}^{\*}}\_{n}$, i.e., $A\_{n,m}=\left\{B\_{n,m}\cap V^{k\mathrm{PRM}^{\*}}\_{n}\neq\emptyset\right\}$. Let $A\_{n}$ denote the event that all balls in $B\_{n,m}$ contains at least one vertex of $G^{k\mathrm{PRM}^{\*}}\_{n}$, i.e., $A\_{n}=\bigcap\_{m=1}^{M\_{n}}A\_{n,m}$.

Recall that $A\_{n}^{c}$ denotes the complement of the event $A\_{n}$, $\mu(\cdot)$ denotes the Lebesgue measure, and $\zeta\_{d}$ is the volume of the unit ball in the $d$-dimensional Euclidean space.
Let $s\_{n}$ denote the length of $\sigma\_{n}$.

###### Lemma 57

For all $\theta\_{1},\theta\_{2}>0$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}(A\_{n}^{c})\,\,\leq\,\,\frac{s\_{n}}{\theta\_{1}}\left(\frac{\zeta\_{d}}{\theta\_{1}\,(1+1/d+\theta\_{2})\,\mu(X\_{\mathrm{free}})}\right)^{1/d}\,\frac{1}{(\log n)^{1/d}\,\,\,n^{1+\theta\_{2}}}.$ |  |

In particular, $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{c})<\infty$ for all $\theta\_{1},\theta\_{2}>0$.

###### Proof.

Let $n\_{0}\in\mathbb{N}$ be a number for which $\delta\_{n}<\delta$ for all $n>n\_{0}$.
A bound on the number of balls in $B\_{n}$ can computed as follows.
For all $n>n\_{0}$,

|  |  |  |
| --- | --- | --- |
|  | $M\_{n}=|B\_{n}|\leq\frac{s\_{n}}{\theta\_{1}\,q\_{n}}=\frac{s\_{n}}{\theta\_{1}}\left(\frac{\zeta\_{d}}{(1+1/d+\theta\_{2})\mu(X\_{\mathrm{free}})}\right)^{1/d}\left(\frac{n}{\log n}\right)^{1/d}.$ |  |

The volume of each ball $B\_{n}$ can be computed as

|  |  |  |
| --- | --- | --- |
|  | $\mu(B\_{n,m})=\zeta\_{d}(q\_{n})^{d}=(1+1/d+\theta\_{2})\,\mu(X\_{\mathrm{free}})\frac{\log n}{n}.$ |  |

The probability that the ball $B\_{n,m}$ does not contain a vertex of the $k$-nearest PRM∗ algorithm can be bounded as

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\mathbb{P}(A\_{n,m}^{c})=\left(1-\frac{\mu(B\_{n,m})}{\mu(X\_{\mathrm{free}})}\right)^{n}=\left(1-(1+1/d+\theta\_{2})\frac{\log n}{n}\right)^{n}\leq n^{-(1+1/d+\theta\_{2})}.$ |  |

Finally, the probability that at least one of the balls in $B\_{n}$ contains no vertex of the $k$-nearest PRM∗ can be bounded as

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}(A\_{n})$ | $\displaystyle=$ | $\displaystyle\mathbb{P}\left(\bigcup\nolimits\_{m=1}^{M\_{n}}A\_{n,m}\right)\leq\sum\_{m=1}^{M\_{n}}\mathbb{P}(A\_{n,m})=M\_{n}\,\mathbb{P}(A\_{n,1})$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle\frac{s\_{n}}{\theta\_{1}}\left(\frac{\zeta\_{d}}{(1+1/d+\theta\_{2})\,\mu(X\_{\mathrm{free}})}\right)^{1/d}\left(\frac{n}{\log n}\right)^{1/d}n^{-(1+1/d+\theta\_{2})}$ |  |
|  |  | $\displaystyle=$ | $\displaystyle\frac{s\_{n}}{\theta\_{1}}\left(\frac{\zeta\_{d}}{(1+1/d+\theta\_{2})\,\mu(X\_{\mathrm{free}})}\right)^{1/d}\frac{1}{(\log n)^{1/d}\,\,\,n^{1+\theta\_{2}}}.$ |  |

Clearly, $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{c})<\infty$ for all $\theta\_{1},\theta\_{2}>0$.
∎∎

### D.5 Construction of the sequence $\{B\_{n}^{\prime}\}\_{n\in\mathbb{N}}$ of sets of balls

Construct a set $B\_{n}^{\prime}=\{B\_{n,1},B\_{n,2},\dots,B\_{n,M\_{n}}\}$ of balls as $B\_{n}^{\prime}:={\tt CoveringBalls}(\sigma\_{n},\delta\_{n},\theta\_{1}q\_{n})$ so that each ball in $B\_{n}^{\prime}$ has radius $\delta\_{n}$ and the spacing between two balls is $\theta\_{1}q\_{n}$ (see Figure [26](#A4.F26 "Figure 26 ‣ D.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix D Proof of Theorem (Asymptotic Optimality of 𝑘-nearest PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning")).

Clearly, the centers of balls in $B\_{n}^{\prime}$ coincide with the centers of the balls in $B\_{n}$, i.e., the center of $B\_{n,m}^{\prime}$ is the same as the center of $B\_{n,m}$ for all $m\in\{1,2,\dots,M\_{n}\}$ and all $n\in\mathbb{N}$. However, the balls in $B\_{n}^{\prime}$ have a larger radius than those in $B\_{n}$.

### D.6 The probability that each ball in $B\_{n}^{\prime}$ contains at most $k(n)$ vertices

Recall that the $k$-nearest PRM algorithm connects each vertex in the graph with its $k(n)$ nearest vertices when the algorithm is run with $n$ samples, where $k(n)=k\_{\mathrm{PRM}}\log n$.
Let $A\_{n}^{\prime}$ denote the event that all balls in $B\_{n}^{\prime}$ contain at most $k(n)$ vertices of $G^{k\mathrm{PRM}^{\*}}\_{n}$.

Recall that $A\_{n}^{\prime c}$ denotes the complement of the event $A\_{n}$.

###### Lemma 58

If $k\_{\mathrm{PRM}}>e\,(1+1/d)$, then there exists some $\theta\_{1},\theta\_{2}>0$ such that

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}(A\_{n}^{\prime c})\leq\frac{s\_{n}}{\theta\_{1}}\left(\frac{\zeta\_{d}}{(1+1/d+\theta\_{2})\mu(X\_{\mathrm{free}})}\right)^{1/d}\frac{1}{(\log n)^{1/d}\,\,\,n^{-(1+\theta\_{1})^{d}(1+1/d+\theta\_{2})}}.$ |  |

In particular, $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{\prime c})<\infty$ for some $\theta\_{1},\theta\_{2}>0$.

###### Proof.

Let $n\_{0}\in\mathbb{N}$ be a number for which $\delta\_{n}<\delta$ for all $n>n\_{0}$.
As shown in the proof of Lemma [57](#Thmtheorem57 "Lemma 57 ‣ D.4 The probability that each ball in 𝐵_𝑛 contains at least one vertex ‣ Appendix D Proof of Theorem (Asymptotic Optimality of 𝑘-nearest PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"), the number of balls in $B\_{n}^{\prime}$ satisfies

|  |  |  |
| --- | --- | --- |
|  | $M\_{n}\,\,=\,\,|B\_{n}^{\prime}|\,\,\leq\,\,\frac{s\_{n}}{\theta\_{1}q\_{n}}\,\,=\,\,\frac{s\_{n}}{\theta\_{1}}\left(\frac{\zeta\_{d}}{(1+1/d+\theta\_{2})\mu(X\_{\mathrm{free}})}\right)^{1/d}\left(\frac{n}{\log n}\right)^{1/d}.$ |  |

For all $n>n\_{0}$, the volume of $B\_{n,m}^{\prime}$ can be computed as

|  |  |  |
| --- | --- | --- |
|  | $\mu(B\_{n,m}^{\prime})=\zeta\_{d}\,(\delta\_{n})^{d}=(1+\theta\_{1})^{d}\,(1+1/d+\theta\_{2})\,\mu(X\_{\mathrm{free}})\,\frac{\log n}{n}.$ |  |

Let $I\_{n,m,i}$ denote the indicator random variable of the event that sample $i$ falls into ball $B\_{n,m}^{\prime}$. The expected value of $I\_{n,m,i}$ can be computed as

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}[I\_{n,m,i}]=\frac{\mu(B\_{n,m}^{\prime})}{\mu(X\_{\mathrm{free}})}=(1+\theta\_{1})^{d}\,(1+1/d+\theta\_{2})\,\frac{\log n}{n}.$ |  |

Let $N\_{n,m}$ denote the number of vertices that fall inside the ball $B\_{n,m}^{\prime}$, i.e., $N\_{n,m}=\sum\_{i=1}^{n}I\_{n,m,i}$. Then,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}[N\_{n,m}]=\sum\_{i=1}^{n}\mathbb{E}[I\_{n,m,i}]=n\,\,\mathbb{E}[I\_{n,m,1}]=(1+\theta\_{1})^{d}(1+1/d+\theta\_{2})\log n.$ |  |

Since $\{I\_{n,m,i}\}\_{i=1}^{n}$ are independent identically distributed random variables, large deviations of their sum, $M\_{n,m}$, can be bounded by the following Chernoff bound ([Dubhashi and Panconesi, 2009](#bib.bib28)):

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\big(\,\big\{\,N\_{n,m}>(1+\epsilon)\,\mathbb{E}[N\_{n,m}]\,\big\}\,\big)\,\,\leq\,\,\left(\frac{e^{\epsilon}}{(1+\epsilon)^{(1+\epsilon)}}\right)^{\mathbb{E}[N\_{n,m}]},$ |  |

for all $\epsilon>0$. In particular, for $\epsilon=e-1$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\big(\,\big\{\,N\_{n,m}>e\,\mathbb{E}[N\_{n,m}]\,\big\}\,\big)\,\,\leq\,\,e^{-\mathbb{E}[N\_{n,m}]}\,\,=\,\,e^{-(1+\theta\_{1})^{d}(1+1/d+\theta\_{2})\log n}\,\,=\,\,n^{-(1+\theta\_{1})^{d}(1+1/d+\theta\_{2})}.$ |  |

Since $k(n)>e\,(1+1/d)\,\log n$, there exists some $\theta\_{1},\theta\_{2}>0$ independent of $n$ such that
$e\,\mathbb{E}[N\_{n,k}]=e\,(1+\theta\_{1})\,(1+1/d+\theta\_{2})\,\log n\leq k(n).$
Then, for the same values of $\theta\_{1}$ and $\theta\_{2}$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\big(\,\big\{\,N\_{n,m}>k(n)\,\big\}\,\big)\,\,\leq\,\,\mathbb{P}\big(\,\big\{\,N\_{n,m}>e\,\mathbb{E}[N\_{n,m}]\,\big\}\,\big)\,\,\leq\,\,n^{-(1+\theta\_{1})^{d}(1+1/d+\theta\_{2})}.$ |  |

Finally, consider the probability of the event that at least one ball in $B\_{n}$ contains more than $k(n)$ nodes. Using the union bound together with the inequality above

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\mathbb{P}\left(\bigcup\nolimits\_{m=1}^{M\_{n}}\big\{N\_{n,m}>k(n)\big\}\right)\,\,\leq\,\,\sum\_{m=1}^{M\_{n}}\mathbb{P}\big(\big\{N\_{n,m}>k(n)\big\}\big)\,\,=\,\,M\_{n}\,\,\mathbb{P}\big(\{N\_{n,1}>k(n)\}\big)$ |  |

Hence,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}(A\_{n}^{\prime c})=\mathbb{P}\left(\bigcup\nolimits\_{m=1}^{M\_{n}}\big\{N\_{n,m}>k(n)\big\}\right)\,\,\leq\,\,\frac{s\_{n}}{\theta\_{1}}\left(\frac{\zeta\_{d}}{(1+1/d+\theta\_{2})\mu(X\_{\mathrm{free}})}\right)^{1/d}\frac{1}{(\log n)^{1/d}\,\,\,n^{-(1+\theta\_{1})^{d}(1+1/d+\theta\_{2})}}.$ |  |

Clearly, $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{\prime c})<\infty$ for the same values of $\theta\_{1}$ and $\theta\_{2}$.
∎∎

### D.7 Connecting the vertices in the subsequent balls in $B\_{n}$

First, note the following lemma.

###### Lemma 59

If $k\_{\mathrm{PRM}}>e\,(1+1/d)^{1/d}$, then there exists $\theta\_{1},\theta\_{2}>0$ such that the event that each ball in $B\_{n}$ contains at least one vertex and each ball in $B\_{n}^{\prime}$ contains at most $k(n)$ vertices occurs for all large $n$, with probability one, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\liminf\_{n\to\infty}(A\_{n}\cap A\_{n}^{\prime})\right)=1.$ |  |

###### Proof.

Consider the event $A\_{n}^{c}\cup A\_{n}^{\prime c}$, which is the complement of $A\_{n}\cap A\_{n}^{\prime}$. Using the union bound,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(A\_{n}^{c}\cup A\_{n}^{\prime c}\right)\leq\mathbb{P}(A\_{n}^{c})+\mathbb{P}(A\_{n}^{\prime c}).$ |  |

Summing both sides,

|  |  |  |
| --- | --- | --- |
|  | $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{c}\cup A\_{N}^{\prime c})\leq\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{c})+\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{\prime c})<\infty,$ |  |

where the last inequality follows from Lemmas [57](#Thmtheorem57 "Lemma 57 ‣ D.4 The probability that each ball in 𝐵_𝑛 contains at least one vertex ‣ Appendix D Proof of Theorem (Asymptotic Optimality of 𝑘-nearest PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") and [58](#Thmtheorem58 "Lemma 58 ‣ D.6 The probability that each ball in 𝐵_𝑛^′ contains at most 𝑘(𝑛) vertices ‣ Appendix D Proof of Theorem (Asymptotic Optimality of 𝑘-nearest PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"). Then, by the Borel-Cantelli lemma, $\mathbb{P}\left(\limsup\_{n\to\infty}(A\_{n}^{c}\cup A\_{n}^{\prime c})\right)=\mathbb{P}\left(\limsup\_{n\to\infty}(A\_{n}\cap A\_{n}^{\prime})^{c}\right)=0$, which implies $\mathbb{P}\left(\liminf\_{n\to\infty}(A\_{n}\cap A\_{n}^{\prime})\right)=1$. ∎∎

Note that for each $m\in\{1,2,\dots,M\_{n}-1\}$, both $B\_{n,m}$ and $B\_{n,m+1}$ lies entirely inside the ball $B\_{n,m}^{\prime}$ (see Figure [26](#A4.F26 "Figure 26 ‣ D.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix D Proof of Theorem (Asymptotic Optimality of 𝑘-nearest PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning")).
Hence, whenever the balls $B\_{n,m}$ and $B\_{n,m+1}$ contain at least one vertex each, and $B\_{n,m}^{\prime}$ contains at most $k(n)$ vertices, the $k$-nearest PRM∗ algorithm attempts to connect all vertices in $B\_{n,m}$ and $B\_{n,m+1}$ with one another.

The following lemma guarantees that connecting any two points from two consecutive balls in $B\_{n}$ results in a collision-free trajectory. The proof of the lemma is essentially the same as that of Lemma [54](#Thmtheorem54 "Lemma 54 ‣ C.5 Connecting the vertices in subsequent balls in 𝐵_𝑛 ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning").

###### Lemma 60

For all $n\in\mathbb{N}$ and all $m\in\{1,2,\dots,M\_{n}\}$, if $x\_{m}\in B\_{n,m}$ and $x\_{m+1}\in B\_{n,m+1}$, then the line segment connecting $x\_{m}$ and $x\_{m+1}$ lies in the obstacle-free space, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\alpha\,x\_{m}+(1-\alpha)\,x\_{m+1}\in X\_{\mathrm{free}},\quad\quad\mbox{ for all }\alpha\in[0,1].$ |  |

### D.8 Convergence to the optimal path

The proof of the following lemma is similar to that of Lemma [55](#Thmtheorem55 "Lemma 55 ‣ C.6 Convergence to the optimal path ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"), and is omitted here.

Let $P\_{n}$ denote the set of all paths in the graph returned by ${k\mbox{-}\mathrm{PRM}^{\*}}$ algorithm at the end of $n$ iterations.
Let $\sigma\_{n}^{\prime}$ be the path that is closest to $\sigma\_{n}$ in terms of the bounded variation norm among all those paths in $P\_{n}$, i.e.,
$\sigma\_{n}^{\prime}:=\min\_{\sigma^{\prime}\in P\_{n}}\|\sigma^{\prime}-\sigma\_{n}\|.$

###### Lemma 61

The random variable $\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}$ converges to zero almost surely, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\lim\nolimits\_{n\to\infty}\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}=0\right\}\right)=1.$ |  |

A corollary of the lemma above is that $\lim\_{n\to\infty}\sigma\_{n}^{\prime}=\sigma^{\*}$ with probability one. Then, the result follows by the robustness of the optimal solution (see the proof of Lemma [56](#Thmtheorem56 "Lemma 56 ‣ C.6 Convergence to the optimal path ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") for details).

## Appendix E Proof of Theorem [36](#Thmtheorem36 "Theorem 36 (Asymptotic optimality of RRG) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") (Asymptotic optimality of RRG)

### E.1 Outline of the proof

The proof of this theorem is similar to that of Theorem [34](#Thmtheorem34 "Theorem 34 (Asymptotic optimality of PRM∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"). The main difference is the definition of $C\_{n}$ that denotes the event that the RRG algorithm has sufficiently explored the obstacle free space. More precisely, $C\_{n}$ is the event that for any point $x$ in the obstacle free space, the graph maintained by the RRG algorithm algorithm includes a vertex that can be connected to $x$.

Construct the sequence $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$ of paths and the sequence $\{B\_{n}\}\_{n\in\mathbb{N}}$ of balls as in the proof of Theorem [34](#Thmtheorem34 "Theorem 34 (Asymptotic optimality of PRM∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").
Let $A\_{n}$ denote the event that each ball in $B\_{n}$ contains a vertex of the graph maintained by the RRG by the end of iteration $n$. Compute $n$ by conditioning on the event that $C\_{i}$ holds for all $i\in\{\lfloor\theta\_{3}\,n\rfloor,\ldots,n\}$, where $0<\theta\_{3}<1$ is a constant. Show that the probability that $C\_{i}$ fails to occur for any such $i$ is small enough to guarantee that $A\_{n}$ occurs for all large $n$ with probability one. Complete the proof as in the proof of Theorem [34](#Thmtheorem34 "Theorem 34 (Asymptotic optimality of PRM∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").

### E.2 Definitions of $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$ and $\{B\_{n}\}\_{n\in\mathbb{N}}$

Let $\theta\_{1}>0$ be a constant.
Define $\delta\_{n}$, $\sigma\_{n}$, $q\_{n}$, and $B\_{n}$ as in the proof of Theorem [34](#Thmtheorem34 "Theorem 34 (Asymptotic optimality of PRM∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").

### E.3 Probability that each ball in $B\_{n}$ contains at least one vertex

Let $A\_{n,m}$ be the event that the ball $B\_{n,m}$ contains at least one vertex of the RRG at the end of $n$ iterations. Let $A\_{n}$ be the event that all balls in $B\_{n}$ contain at least one vertex of the RRG at the end of iteration $n$, i.e., $A\_{n}=\bigcap\_{m=1}^{M\_{n}}A\_{n,m}$, where $M\_{n}$ is the number of balls in $B\_{n}$. Recall that $\gamma\_{\mathrm{RRG}}$ is the constant used in defining the connection radius of the RRG algorithm (see Algorithm [5](#algorithm5 "In Rapidly-exploring Random Graph (RRG): ‣ 3.3 Proposed algorithms ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning")).

###### Lemma 62

If $\gamma\_{\mathrm{RRG}}>2(1+1/d)^{1/d}\left(\frac{\mu(X\_{\mathrm{free}})}{\zeta\_{d}}\right)^{1/d}$ then there exists $\theta\_{1}>0$ such that $A\_{n}$ occurs for all large $n$ with probability one, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\liminf\nolimits\_{n\to\infty}A\_{n}\right)=1.$ |  |

The proof of this lemma requires two intermediate results, which are provided next.

Recall that $\eta$ is the parameter used in the ${\tt Steer}$ procedure (see the definition of Steer procedure in Section [3.1](#S3.SS1 "3.1 Primitive Procedures ‣ 3 Algorithms ‣ Sampling-based Algorithms for Optimal Motion Planning")).
Let $C\_{n}$ denote the event that for any point $x\in X\_{\mathrm{free}}$, the graph returned by the RRG algorithm includes a vertex $v$ such that $\|x-v\|\leq\eta$ and the line segment joining $v$ and $x$ is collision-free.
The following lemma establishes an bound on the probability that this event fails to occur at iteration $n$.

###### Lemma 63

There exists constants $a,b\in\mathbb{R}\_{>0}$ such that $P(C\_{n}^{c})\leq a\,e^{-b\,n}$ for all $n\in\mathbb{N}$.

###### Proof.

Partition $X\_{\mathrm{free}}$ into finitely many convex sets such that each partition is bounded by a ball a radius $\eta$. Such a finite partition exists by the boundedness of $X\_{\mathrm{free}}$. Denote this partition by $X\_{1}^{\prime},X\_{2}^{\prime},\dots,X\_{M}^{\prime}$. Since the probability of failure decays to zero with an exponential rate, for any $m\in\{1,2,\dots,M\}$, the probability that $X\_{m}^{\prime}$ fails to contain a vertex of the RRG decays to zero with an exponential rate, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\nexists x\in V\_{n}^{\mathrm{RRG}}\cap X\_{m}^{\prime}\right\}\right)\leq a\_{m}\,e^{-b\_{m}\,n}$ |  |

The probability that at least one partition fails to contain one vertex of the RRG also decays to zero with an exponential rate. That is, there exists $a,b\in\mathbb{R}\_{>0}$ such that

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\bigcup\nolimits\_{m=1}^{M}\left\{\nexists x\in V\_{n}^{\mathrm{RRG}}\cap X\_{m}^{\prime}\right\}\right)\leq\sum\_{m=1}^{M}\mathbb{P}\left(\left\{\nexists x\in V\_{n}^{\mathrm{RRG}}\cap X\_{m}^{\prime}\right\}\right)\leq\sum\_{m=1}^{M}a\_{m}\,e^{-b\_{m}n}\leq a\,e^{-b\,n},$ |  |

where the first inequality follows from the union bound.
∎∎

Let $0<\theta\_{3}<1$ be a constant independent of $n$. Consider the event that $C\_{i}$ occurs for all $i$ that is greater than $\theta\_{3}\,n$, i.e., $\bigcap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}$. The following lemma analyzes the probability of the event that $\bigcap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}$ fails to occur.

###### Lemma 64

For any $\theta\_{3}\in(0,1)$,

|  |  |  |
| --- | --- | --- |
|  | $\sum\_{n=1}^{\infty}\mathbb{P}\left(\left(\bigcap\nolimits\_{i=\lfloor\theta\_{3}n\rfloor}^{n}C\_{i}\right)^{c}\right)\,\,<\,\,\infty.$ |  |

###### Proof.

The following inequalities hold:

|  |  |  |
| --- | --- | --- |
|  | $\sum\_{n=1}^{\infty}\mathbb{P}\left(\left(\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)^{c}\right)\,\,=\,\,\sum\_{n=1}^{\infty}\mathbb{P}\left(\bigcup\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}^{c}\right)\,\,\leq\,\,\sum\_{n=1}^{\infty}\sum\_{i=\lfloor\theta\_{3}\,i\rfloor}^{n}\mathbb{P}(C\_{i}^{c})\,\,\leq\,\,\sum\_{n=1}^{\infty}\sum\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}a\,e^{-b\,i},$ |  |

where the last inequality follows from Lemma [63](#Thmtheorem63 "Lemma 63 ‣ E.3 Probability that each ball in 𝐵_𝑛 contains at least one vertex ‣ Appendix E Proof of Theorem (Asymptotic optimality of RRG) ‣ Sampling-based Algorithms for Optimal Motion Planning"). The right-hand side is finite for all $a,b>0$. ∎∎

###### Proof of Lemma [62](#Thmtheorem62 "Lemma 62 ‣ E.3 Probability that each ball in 𝐵_𝑛 contains at least one vertex ‣ Appendix E Proof of Theorem (Asymptotic optimality of RRG) ‣ Sampling-based Algorithms for Optimal Motion Planning").

It is shown that $\sum\_{n=1}^{\infty}\mathbb{P}\left(A\_{n}^{c}\right)<\infty$, which, by the Borel-Cantelli Lemma ([Grimmett and Stirzaker, 2001](#bib.bib36)), implies that $A\_{n}^{c}$ occurs infinitely often with probability zero, i.e., $\mathbb{P}(\limsup\_{n\to\infty}A\_{n}^{c})=0$, which in turn implies $\mathbb{P}(\liminf\_{n\to\infty}A\_{n})=1$.

Let $n\_{0}\in\mathbb{N}$ be a number for which $\delta\_{n}<\delta$ for all $n>n\_{0}$.
First, for all $n>n\_{0}$, the number of balls in $B\_{n}$ can be bounded by (see the proof of Lemma [52](#Thmtheorem52 "Lemma 52 ‣ C.4 The probability that each ball in 𝐵_𝑛 contains at least one vertex ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") for details)

|  |  |  |
| --- | --- | --- |
|  | $M\_{n}=|B\_{n}|\leq\frac{(2+\theta\_{1})\,s\_{n}}{\theta\_{1}\,\gamma\_{\mathrm{RRG}}}\left(\frac{n}{\log n}\right)^{1/d}.$ |  |

Second, for all $n>n\_{0}$, the volume of each ball in $B\_{n}$ can be calculated as (see the proof of Lemma [52](#Thmtheorem52 "Lemma 52 ‣ C.4 The probability that each ball in 𝐵_𝑛 contains at least one vertex ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"))

|  |  |  |
| --- | --- | --- |
|  | $\mu(B\_{n,m})\,\,=\,\,\zeta\_{d}\,\left(\frac{\gamma\_{\mathrm{PRM}}}{2+\theta\_{1}}\right)^{d}\frac{\log n}{n},$ |  |

where $\zeta\_{d}$ is the volume of the unit ball in the $d$-dimensional Euclidean space.

Third, conditioning on the event $\bigcap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}$, each new sample will be added to the graph maintained by the RRG algorithm as a new vertex between iterations $i=\lfloor\theta\_{3}\,n\rfloor$ and $i=n$.
Thus,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}\left(A\_{n,m}^{c}\,\Big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)$ | $\displaystyle\leq$ | $\displaystyle\left(1-\frac{\mu(B\_{n,m})}{\mu(X\_{\mathrm{free}})}\right)^{n-\lfloor\theta\_{3}\,n\rfloor}\,\,\leq\,\,\left(1-\frac{\mu(B\_{n,m})}{\mu(X\_{\mathrm{free}})}\right)^{(1-\theta\_{3})\,n}$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle\left(1-\frac{\zeta\_{d}}{\mu(X\_{\mathrm{free}})}\left(\frac{\gamma\_{\mathrm{RRG}}}{2+\theta\_{1}}\right)^{d}\frac{\log n}{n}\right)^{(1-\theta\_{3})\,n}$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle e^{-\frac{(1-\theta\_{3})\,\zeta\_{d}}{\mu(X\_{\mathrm{free}})}\left(\frac{\gamma\_{\mathrm{RRG}}}{2+\theta\_{1}}\right)^{d}\log n}\leq n^{-\frac{(1-\theta\_{3})\,\zeta\_{d}}{\mu(X\_{\mathrm{free}})}\left(\frac{\gamma\_{\mathrm{RRG}}}{2+\theta\_{1}}\right)^{d}},$ |  |

where the fourth inequality follows from $(1-1/f(n))^{g(n)}\leq e^{g(n)/f(n)}$.

Fourth,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}\left(A\_{n}^{c}\,\Big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)$ | $\displaystyle\leq$ | $\displaystyle\mathbb{P}\left(\bigcup\nolimits\_{m=1}^{M\_{n}}A\_{n,m}^{c}\,\Big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle\sum\_{m=1}^{M\_{n}}\mathbb{P}\left(A\_{n,m}^{c}\,\big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)$ |  |
|  |  | $\displaystyle=$ | $\displaystyle M\_{n}\,\,\mathbb{P}\left(A\_{n,1}^{c}\,\big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle\frac{(2+\theta\_{1})\,s\_{n}}{\theta\_{1}\,\gamma\_{\mathrm{RRG}}}\left(\frac{n}{\log n}\right)^{1/d}\,\,n^{-\frac{(1-\theta\_{3})\,\zeta\_{d}}{\mu(X\_{\mathrm{free}})}\left(\frac{\gamma\_{\mathrm{RRG}}}{2+\theta\_{1}}\right)^{d}}.$ |  |

Hence,

|  |  |  |
| --- | --- | --- |
|  | $\sum\_{n=1}^{\infty}\mathbb{P}\left(A\_{n}^{c}\,\Big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)\,\,<\,\,\infty,$ |  |

whenever $\frac{(1-\theta\_{3})\,\zeta\_{d}}{\mu(X\_{\mathrm{free}})}\left(\frac{\gamma\_{\mathrm{RRG}}}{2+\theta\_{1}}\right)^{d}-1/d>1$, i.e., $\gamma\_{\mathrm{RRG}}>(2+\theta\_{1})(1+1/d)^{1/d}\left(\frac{\mu(X\_{\mathrm{free}})}{(1-\theta\_{3})\,\zeta\_{d}}\right)^{1/d}$, which is satisfied by appropriately choosing the constants $\theta\_{1}$ and $\theta\_{3}$, since $\gamma\_{\mathrm{RRG}}>2\,(1+1/d)^{1/d}\left(\frac{\mu(X\_{\mathrm{free}})}{\zeta\_{d}}\right)^{1/d}$.

Finally,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}\left(A\_{n}^{c}\,\big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)$ | $\displaystyle=$ | $\displaystyle\frac{\mathbb{P}\left(A\_{n}^{c}\cap\left(\cap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)\right)}{\mathbb{P}\left(\bigcap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)}$ |  |
|  |  | $\displaystyle\geq$ | $\displaystyle\mathbb{P}(A\_{n}^{c}\cap(\cap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}))$ |  |
|  |  | $\displaystyle=$ | $\displaystyle 1-\mathbb{P}(A\_{n}\cup(\cap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i})^{c})$ |  |
|  |  | $\displaystyle\geq$ | $\displaystyle 1-\mathbb{P}(A\_{n})-\mathbb{P}\big((\cap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i})^{c}\big)$ |  |
|  |  | $\displaystyle=$ | $\displaystyle\mathbb{P}(A\_{n}^{c})-\mathbb{P}\big((\cap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i})^{c}\big).$ |  |

Taking the infinite sum of both sides yields

|  |  |  |
| --- | --- | --- |
|  | $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{c})\leq\sum\_{n=1}^{\infty}\mathbb{P}\left(A\_{n}^{c}\,\big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{n}\right)+\sum\_{n=1}^{\infty}\mathbb{P}\left(\left(\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{n}\right)^{c}\right).$ |  |

The first term on the right hand side is shown to be finite above. The second term is finite by Lemma [64](#Thmtheorem64 "Lemma 64 ‣ E.3 Probability that each ball in 𝐵_𝑛 contains at least one vertex ‣ Appendix E Proof of Theorem (Asymptotic optimality of RRG) ‣ Sampling-based Algorithms for Optimal Motion Planning"). Hence, $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n})<\infty$. Then, by the Borel Cantelli lemma, $A\_{n}^{c}$ occurs infinitely often with probability zero, which implies that its complement $A\_{n}$ occurs for all large $n$, with probability one. ∎∎

### E.4 Convergence to the optimal path

The proof of the following lemma is similar to that of Lemma [55](#Thmtheorem55 "Lemma 55 ‣ C.6 Convergence to the optimal path ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"), and is omitted here.

Let $P\_{n}$ denote the set of all paths in the graph returned by ${\mathrm{RRG}}$ algorithm at the end of $n$ iterations.
Let $\sigma\_{n}^{\prime}$ be the path that is closest to $\sigma\_{n}$ in terms of the bounded variation norm among all those paths in $P\_{n}$, i.e.,
$\sigma\_{n}^{\prime}:=\min\_{\sigma^{\prime}\in P\_{n}}\|\sigma^{\prime}-\sigma\_{n}\|.$

###### Lemma 65

The random variable $\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}$ converges to zero almost surely, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\lim\nolimits\_{n\to\infty}\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}=0\right\}\right)=1.$ |  |

A corollary of the lemma above is that $\lim\_{n\to\infty}\sigma\_{n}^{\prime}=\sigma^{\*}$ with probability one. Then, the result follows by the robustness of the optimal solution (see the proof of Lemma [56](#Thmtheorem56 "Lemma 56 ‣ C.6 Convergence to the optimal path ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") for details).

## Appendix F Proof of Theorem [37](#Thmtheorem37 "Theorem 37 (Asymptotic optimality of 𝑘-nearest RRG) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") (asymptotic optimality of $k$-nearest RRG)

### F.1 Outline of the proof

The proof of this theorem is a combination of that of Theorem [35](#Thmtheorem35 "Theorem 35 (Asymptotic optimality of 𝑘-nearest PRM∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") and [36](#Thmtheorem36 "Theorem 36 (Asymptotic optimality of RRG) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").

Define the sequences $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$, $\{B\_{n}\}\_{n\in\mathbb{N}}$, and $\{B\_{n}^{\prime}\}\_{n\in\mathbb{N}}$ as in the proof of Theorem [35](#Thmtheorem35 "Theorem 35 (Asymptotic optimality of 𝑘-nearest PRM∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning"). Define the event $C\_{n}$ as in the proof of Theorem [36](#Thmtheorem36 "Theorem 36 (Asymptotic optimality of RRG) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").
Let $A\_{n}$ denote the event that each ball in $B\_{n}$ contains at least one vertex, and $A\_{n}^{\prime}$ denote the event that each ball in $B\_{n}^{\prime}$ contains at most $k(n)$ vertices of the graph maintained by the RRG algorithm, by the end of iteration $n$. Compute $A\_{n}$ and $A\_{n}^{\prime}$ by conditioning on the event that $C\_{i}$ holds for all $i=\theta\_{3}\,n$ to $n$. Show that this is enough to guarantee that $A\_{n}$ and $A\_{n}^{\prime}$ hold together for all large $n$, with probability one.

### F.2 Definitions of $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$, $\{B\_{n}\}\_{n\in\mathbb{N}}$, and $\{B\_{n}^{\prime}\}\_{n\in\mathbb{N}}$

Let $\theta\_{1},\theta\_{2}>0$ be two constants. Define $\delta\_{n}$, $\sigma\_{n}$, $q\_{n}$, $B\_{n}$, and $B\_{n}^{\prime}$ as in the proof of Theorem [35](#Thmtheorem35 "Theorem 35 (Asymptotic optimality of 𝑘-nearest PRM∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning").

### F.3 The probability that each ball in $B\_{n}$ contains at least one vertex

Let $A\_{n,m}$ denote the event that the ball $B\_{n,m}$ contains at least one vertex of the graph maintained by the $k$-nearest RRG algorithm by the end of iteration $n$. Let $A\_{n}$ denote the event that all balls in $B\_{n,m}$ contain at least one vertex of the same graph, i.e., $A\_{n}=\bigcup\_{m=1}^{M\_{n}}A\_{n,m}$.
Let $s\_{n}$ denote the length of $\sigma\_{n}$, i.e., $TV(\sigma\_{n})$.
Recall $\eta$ is the parameter in the ${\tt Steer}$ procedure. Let $C\_{n}$ denote the event that for any point $x\in X\_{\mathrm{free}}$, the $k$-nearest RRG algorithm includes a vertex $v$ such that $\|x-v\|\leq\eta$.

###### Lemma 66

For any $\theta\_{1},\theta\_{2}>0$ and any $\theta\_{3}\in(0,1)$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(A\_{n}^{c}\,\Big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)\,\,\leq\,\,\frac{s\_{n}}{\theta\_{1}}\left(\frac{\zeta\_{d}}{\theta\_{1}\,(1+1/d+\theta\_{2})\,\mu(X\_{\mathrm{free}})}\right)^{1/d}\,\frac{1}{(\log n)^{1/d}\,\,\,n^{(1-\theta\_{3})(1+1/d+\theta\_{2})-1/d}}.$ |  |

In particular, $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{c}\,|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i})<\infty$ for any $\theta\_{1},\theta\_{2}>0$ and some $\theta\_{3}\in(0,1)$.

###### Proof.

Let $n\_{0}\in\mathbb{N}$ be a number for which $\delta\_{n}<\delta$ for all $n>n\_{0}$.
Then, for all $n>n\_{0}$,

|  |  |  |
| --- | --- | --- |
|  | $M\_{n}=|B\_{n}|\leq\frac{s\_{n}}{\theta\_{1}\,q\_{n}}=\frac{s\_{n}}{\theta\_{1}}\left(\frac{\zeta\_{d}}{(1+1/d+\theta\_{2})\mu(X\_{\mathrm{free}})}\right)^{1/d}\left(\frac{n}{\log n}\right)^{1/d}.$ |  |

The volume of each ball $B\_{n}$ can be computed as

|  |  |  |
| --- | --- | --- |
|  | $\mu(B\_{n,m})=\zeta\_{d}(q\_{n})^{d}=(1+1/d+\theta\_{2})\,\mu(X\_{\mathrm{free}})\frac{\log n}{n}.$ |  |

Given $\bigcap\_{i=\lceil\theta\_{3}\,n\rceil}^{n}C\_{i}$, the probability that the ball $B\_{n,m}$ does not contain a vertex of the $k$-nearest PRM∗ algorithm can be bounded as

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\mathbb{P}\Big(A\_{n,m}^{c}\,\big|\,\bigcap\nolimits\_{i=\lceil\theta\_{3}\,n\rceil}^{n}C\_{i}\Big)\,\,=\,\,\left(1-\frac{\mu(B\_{n,m})}{\mu(X\_{\mathrm{free}})}\right)^{(1-\theta\_{3})\,n}=\left(1-(1+1/d+\theta\_{2})\frac{\log n}{n}\right)^{(1-\theta\_{3})\,n}\leq n^{-(1-\theta\_{3})\,(1+1/d+\theta\_{2})}.$ |  |

Finally, the probability that at least one of the balls in $B\_{n}$ contains no vertex of the $k$-nearest PRM∗ can be bounded as

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}(A\_{n})$ | $\displaystyle=$ | $\displaystyle\mathbb{P}\left(\bigcup\nolimits\_{m=1}^{M\_{n}}A\_{n,m}\right)\,\,\leq\,\,\sum\_{m=1}^{M\_{n}}\mathbb{P}(A\_{n,m})=M\_{n}\,\mathbb{P}(A\_{n,1})$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle\frac{s\_{n}}{\theta\_{1}}\left(\frac{\zeta\_{d}}{(1+1/d+\theta\_{2})\,\mu(X\_{\mathrm{free}})}\right)^{1/d}\frac{1}{(\log n)^{1/d}\,\,\,n^{(1-\theta\_{3})\,(1+1/d+\theta\_{2})-1/d}}.$ |  |

Clearly, for all $\theta\_{1},\theta\_{2}>0$, there exists some $\theta\_{3}\in(0,1)$ such that $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{c})<\infty$.
∎∎

### F.4 The probability that each ball in $B\_{n}^{\prime}$ contains at most $k(n)$ vertices

Let $A\_{n}^{\prime}$ denote the event that all balls in $B\_{n}^{\prime}$ contain at most $k(n)$ vertices of the graph maintained by the RRG algorithm, by end of iteration $n$.

###### Lemma 67

If $k\_{\mathrm{PRM}}>e\,(1+1/d)$, then there exists $\theta\_{1},\theta\_{2},\theta\_{3}>0$ such that

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(A\_{n}^{\prime c}\,\Big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)\,\,\leq\,\,\frac{s\_{n}}{\theta\_{1}}\left(\frac{\zeta\_{d}}{(1+1/d+\theta\_{2})\mu(X\_{\mathrm{free}})}\right)^{1/d}\frac{1}{(\log n)^{1/d}\,\,\,n^{-(1-\theta\_{3})(1+\theta\_{1})^{d}(1+1/d+\theta\_{2})}}.$ |  |

In particular, $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{c}\,|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i})<\infty$ for some $\theta\_{1},\theta\_{2}>0$ and some $\theta\_{3}>0$.

###### Proof.

Let $n\_{0}\in\mathbb{N}$ be a number for which $\lambda\_{n}<\delta$ for all $n>n\_{0}$.
Then, the number of balls in $B\_{n}^{\prime}$ and the volume of each ball can be computed as

|  |  |  |
| --- | --- | --- |
|  | $M\_{n}\,\,=\,\,|B\_{n}^{\prime}|\,\,\leq\,\,\frac{s\_{n}}{\theta\_{1}q\_{n}}\,\,=\,\,\frac{s\_{n}}{\theta\_{1}}\left(\frac{\zeta\_{d}}{(1+1/d+\theta\_{2})\mu(X\_{\mathrm{free}})}\right)^{1/d}\left(\frac{n}{\log n}\right)^{1/d}.$ |  |

|  |  |  |
| --- | --- | --- |
|  | $\mu(B\_{n,m}^{\prime})=\zeta\_{d}\,(\lambda\_{n})^{d}=(1+\theta\_{1})^{d}\,(1+1/d+\theta\_{2})\,\mu(X\_{\mathrm{free}})\,\frac{\log n}{n}.$ |  |

Let $I\_{n,m,i}$ denote the indicator random variable of the event that sample $i$ falls into ball $B\_{n,m}^{\prime}$. The expected value of $I\_{n,m,i}$ can be computed as

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}[I\_{n,m,i}]=\frac{\mu(B\_{n,m}^{\prime})}{\mu(X\_{\mathrm{free}})}=(1+\theta\_{1})^{d}\,(1+1/d+\theta\_{2})\,\frac{\log n}{n}.$ |  |

Let $N\_{n,m}$ denote the number of vertices that fall inside the ball $B\_{n,m}^{\prime}$ between iterations $\lfloor\theta\_{3}\,n\rfloor$ and $n$, i.e., $N\_{n,m}=\sum\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}I\_{n,m,i}$. Then,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{E}[N\_{n,m}]=\sum\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}\mathbb{E}[I\_{n,m,i}]=(1-\theta\_{3})\,n\,\,\mathbb{E}[I\_{n,m,1}]=(1-\theta\_{3})\,(1+\theta\_{1})^{d}\,(1+1/d+\theta\_{2})\log n.$ |  |

Since $\{I\_{n,m,i}\}\_{i=1}^{n}$ are independent identically distributed random variables, large deviations of their sum, $M\_{n,m}$, can be bounded by the following Chernoff bound ([Dubhashi and Panconesi, 2009](#bib.bib28)):

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\big(\,\big\{\,N\_{n,m}>(1+\epsilon)\,\mathbb{E}[N\_{n,m}]\,\big\}\,\big)\,\,\leq\,\,\left(\frac{e^{\epsilon}}{(1+\epsilon)^{(1+\epsilon)}}\right)^{\mathbb{E}[N\_{n,m}]},$ |  |

for all $\epsilon>0$. In particular, for $\epsilon=e-1$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\big(\,\big\{\,N\_{n,m}>e\,\mathbb{E}[N\_{n,m}]\,\big\}\,\big)\,\,\leq\,\,e^{-\mathbb{E}[N\_{n,m}]}\,\,=\,\,n^{-(1-\theta\_{3})\,(1+\theta\_{1})^{d}\,(1+1/d+\theta\_{2})}.$ |  |

Since $k(n)>e\,(1+1/d)\,\log n$, there exists some $\theta\_{1},\theta\_{2}>0$ and $\theta\_{3}\in(0,1)$, independent of $n$, such that
$e\,\mathbb{E}[N\_{n,k}]=e\,(1-\theta\_{3})\,(1+\theta\_{1})\,(1+1/d+\theta\_{2})\,\log n\leq k(n).$
Then, for the same values of $\theta\_{1}$ and $\theta\_{2}$,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\big(\,\big\{\,N\_{n,m}>k(n)\,\big\}\,\big)\,\,\leq\,\,\mathbb{P}\big(\,\big\{\,N\_{n,m}>e\,\mathbb{E}[N\_{n,m}]\,\big\}\,\big)\,\,\leq\,\,n^{-(1-\theta\_{3})\,(1+\theta\_{1})^{d}\,(1+1/d+\theta\_{2})}.$ |  |

Finally, consider the probability of the event that at least one ball in $B\_{n}$ contains more than $k(n)$ nodes. Using the union bound together with the inequality above

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\mathbb{P}\left(\bigcup\nolimits\_{m=1}^{M\_{n}}\big\{N\_{n,m}>k(n)\big\}\right)\,\,\leq\,\,\sum\_{m=1}^{M\_{n}}\mathbb{P}\big(\big\{N\_{n,m}>k(n)\big\}\big)\,\,=\,\,M\_{n}\,\,\mathbb{P}\big(\{N\_{n,1}>k(n)\}\big)$ |  |

Hence,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}\Big(A\_{n}^{\prime c}\,\big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\Big)$ | $\displaystyle=$ | $\displaystyle\mathbb{P}\left(\bigcup\nolimits\_{m=1}^{M\_{n}}\big\{N\_{n,m}>k(n)\big\}\right)$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle\frac{s\_{n}}{\theta\_{1}}\left(\frac{\zeta\_{d}}{(1+1/d+\theta\_{2})\mu(X\_{\mathrm{free}})}\right)^{1/d}\frac{1}{(\log n)^{1/d}\,\,\,n^{-(1-\theta\_{3})\,(1+\theta\_{1})^{d}(1+1/d+\theta\_{2})}}.$ |  |

Clearly, $\sum\_{n=1}^{\infty}\mathbb{P}\big(A\_{n}^{\prime c}\,|\,\cap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\big)<\infty$ for the same values of $\theta\_{1}$, $\theta\_{2}$, and $\theta\_{3}$.
∎.
∎

### F.5 Connecting the vertices in subsequent balls in $B\_{n}$

###### Lemma 68

If $k\_{\mathrm{PRM}}>e\,(1+1/d)^{1/d}$, then there exists $\theta\_{1},\theta\_{2}>0$ such that the event that each ball in $B\_{n}$ contains at least one vertex and each ball in $B\_{n}^{\prime}$ contains at most $k(n)$ vertices occurs for all large $n$, with probability one, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\liminf\_{n\to\infty}(A\_{n}\cap A\_{n}^{\prime})\right)=1.$ |  |

First note the following lemma.

###### Lemma 69

For any $\theta\_{3}\in(0,1)$,

|  |  |  |
| --- | --- | --- |
|  | $\sum\_{n=1}^{\infty}\mathbb{P}\left(\left(\bigcap\nolimits\_{i=\lfloor\theta\_{3}n\rfloor}^{n}C\_{n}\right)^{c}\right)\,\,<\,\,\infty.$ |  |

###### Proof.

Since the RRG algorithm and the $k$-nearest RRG algorithm have the same vertex sets, i.e., $V^{\mathrm{RRG}}\_{n}=V^{k\mathrm{RRG}}\_{n}$ surely for all $n\in\mathbb{N}$, the lemma follows from Lemma [64](#Thmtheorem64 "Lemma 64 ‣ E.3 Probability that each ball in 𝐵_𝑛 contains at least one vertex ‣ Appendix E Proof of Theorem (Asymptotic optimality of RRG) ‣ Sampling-based Algorithms for Optimal Motion Planning"). ∎∎

###### Proof of Lemma [68](#Thmtheorem68 "Lemma 68 ‣ F.5 Connecting the vertices in subsequent balls in 𝐵_𝑛 ‣ Appendix F Proof of Theorem (asymptotic optimality of 𝑘-nearest RRG) ‣ Sampling-based Algorithms for Optimal Motion Planning").

Note that

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}\left((A\_{n}^{c}\cup A\_{n}^{\prime c})\,\big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)$ | $\displaystyle=$ | $\displaystyle\frac{\mathbb{P}\left(A\_{n}^{c}\cap\left(\cap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)\right)}{\mathbb{P}\left(\bigcap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)}$ |  |
|  |  | $\displaystyle\geq$ | $\displaystyle\mathbb{P}\left((A\_{n}^{c}\cup A\_{n}^{\prime c})\cap\big(\cap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\big)\right)$ |  |
|  |  | $\displaystyle\geq$ | $\displaystyle\mathbb{P}(A\_{n}^{c}\cup A\_{n}^{\prime c})-\mathbb{P}\big((\cap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i})^{c}\big),$ |  |

where the last inequality follows from the union bound. Rearranging and using the union bound,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}(A\_{n}^{c}\cup A\_{n}^{\prime c})\,\,\leq\,\,\mathbb{P}\big(A\_{n}^{c}\,\big|\,\cap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\big)+\mathbb{P}\big(A\_{n}^{c}\,\big|\,\cap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\big)+\mathbb{P}\big(\big(\cap\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\big)^{c}\big).$ |  |

Summing both sides,

|  |  |  |
| --- | --- | --- |
|  | $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{c}\cup A\_{n}^{\prime c})\,\,\leq\,\,\sum\_{n=1}^{\infty}\mathbb{P}\left(A\_{n}^{c}\,\big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)+\sum\_{n=1}^{\infty}\mathbb{P}\left(A\_{n}^{\prime c}\,\big|\,\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)+\sum\_{n=1}^{\infty}\mathbb{P}\left(\left(\bigcap\nolimits\_{i=\lfloor\theta\_{3}\,n\rfloor}^{n}C\_{i}\right)^{c}\right),$ |  |

where the right hand side is finite by Lemmas [66](#Thmtheorem66 "Lemma 66 ‣ F.3 The probability that each ball in 𝐵_𝑛 contains at least one vertex ‣ Appendix F Proof of Theorem (asymptotic optimality of 𝑘-nearest RRG) ‣ Sampling-based Algorithms for Optimal Motion Planning"), [67](#Thmtheorem67 "Lemma 67 ‣ F.4 The probability that each ball in 𝐵_𝑛^′ contains at most 𝑘(𝑛) vertices ‣ Appendix F Proof of Theorem (asymptotic optimality of 𝑘-nearest RRG) ‣ Sampling-based Algorithms for Optimal Motion Planning"), and [69](#Thmtheorem69 "Lemma 69 ‣ F.5 Connecting the vertices in subsequent balls in 𝐵_𝑛 ‣ Appendix F Proof of Theorem (asymptotic optimality of 𝑘-nearest RRG) ‣ Sampling-based Algorithms for Optimal Motion Planning"), by picking $\theta\_{3}$ close to one. Hence, $\sum\_{n=1}^{\infty}\mathbb{P}(A\_{n}^{c}\cup A\_{n}^{\prime c})<\infty$. Then, by the Borel-Cantelli lemma, $\mathbb{P}(\limsup\_{n\to\infty}(A\_{n}^{c}\cup A\_{n}^{\prime c}))=0$, or equivalently $\mathbb{P}(\liminf\_{n\to\infty}(A\_{n}\cap A\_{n}^{\prime}))=1$.
∎∎

### F.6 Convergence to the optimal path

The proof of the following two lemmas are essentially the same as that of Lemma [55](#Thmtheorem55 "Lemma 55 ‣ C.6 Convergence to the optimal path ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"), and is omitted here.
Let $P\_{n}$ denote the set of all paths in the graph returned by ${k\mbox{-}\mathrm{RRG}}$ algorithm at the end of $n$ iterations.
Let $\sigma\_{n}^{\prime}$ be the path that is closest to $\sigma\_{n}$ in terms of the bounded variation norm among all those paths in $P\_{n}$, i.e.,
$\sigma\_{n}^{\prime}:=\min\_{\sigma^{\prime}\in P\_{n}}\|\sigma^{\prime}-\sigma\_{n}\|.$

###### Lemma 70

The random variable $\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}$ converges to zero almost surely, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\lim\nolimits\_{n\to\infty}\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}=0\right\}\right)=1.$ |  |

A corollary of the lemma above is that $\lim\_{n\to\infty}\sigma\_{n}^{\prime}=\sigma^{\*}$ with probability one. Then, the result follows by the robustness of the optimal solution (see the proof of Lemma [56](#Thmtheorem56 "Lemma 56 ‣ C.6 Convergence to the optimal path ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") for details).

## Appendix G Proof of Theorem [38](#Thmtheorem38 "Theorem 38 (Asymptotic optimality of RRT∗) ‣ 4.2.2 Proposed algorithms ‣ 4.2 Asymptotic Optimality ‣ 4 Analysis ‣ Sampling-based Algorithms for Optimal Motion Planning") (Asymptotic optimality of RRT∗)

For simplicity, the proof will assume the steering parameter $\eta$ to be large enough, i.e.,
$\eta\geq\mathrm{diam}({\cal X})$, although the results hold for any $\eta>0$.

### G.1 Marked point process

Consider the following marked point process. Let $\{X\_{1},X\_{2},\dots,X\_{n}\}$ be a independent uniformly distributed points drawn from $X\_{\mathrm{free}}$ and let $\{Y\_{1},Y\_{2},\dots,Y\_{n}\}$ be independent uniform random variables with support $[0,1]$. Each point $X\_{i}$ is associated with a mark $Y\_{i}$ that describes the order of $X\_{i}$ in the process. More precisely, a point $X\_{i}$ is assumed to be drawn after another point $X\_{i^{\prime}}$ if $Y\_{i^{\prime}}<Y\_{i}$. We will also assume that the point process includes the point $x\_{\mathrm{init}}$ with mark $Y=0$.

Consider the graph formed by adding an edge $(X\_{i^{\prime}},X\_{i})$, whenever (i) $Y\_{i^{\prime}}<Y\_{i}$ and (ii) $\|X\_{i}-X\_{i^{\prime}}\|\leq r\_{n}$ both hold. Notice that, formed in this way, $G\_{n}$ includes no directed cycles. Denote this graph by $G\_{n}=(V\_{n},E\_{n})$. Also, consider a subgraph $G^{\prime}\_{n}$ of $G\_{n}$ formed as follows. Let $c(X\_{i})$ denote the cost of best path starting from $x\_{\mathrm{init}}$ and reaching $X\_{i}$. In $G\_{n}^{\prime}$, each vertex $X\_{i}$ has a single parent $X\_{i}$ with the smallest cost $c(X\_{i})$. Since the graph is built incrementally, the cost of the best path reaching $X\_{i}$ will be the same as the one reaching $X\_{i^{\prime}}$ in both $G\_{n}$ and $G\_{n}^{\prime}$. Clearly, $G\_{n}^{\prime}$ is equivalent to the graph returned by the RRT∗ algorithm at the end of $n$ iterations, if the steering parameter $\eta$ is large enough.

Let $Y\_{n}$ and the $Y\_{n}^{\prime}$ denote the costs of the best paths starting from $x\_{\mathrm{init}}$ and reaching the goal region in $G\_{n}$ and $G\_{n}^{\prime}$, respectively. Then, $\limsup\_{n\to\infty}Y\_{n}=\limsup\_{n\to\infty}Y\_{n}^{\prime}$ surely. In the rest of the proof, it is shown that $\mathbb{P}(\{\limsup\_{n\to\infty}Y\_{n}\})=1$, which implies that $\mathbb{P}(\{\limsup\_{n\to\infty}Y\_{n}^{\prime}\})=1$, which in turn implies the result.

### G.2 Definitions of $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$ and $\{B\_{n}\}\_{n\in\mathbb{N}}$

Let $\sigma^{\*}$ denote an optimal path. Define

|  |  |  |
| --- | --- | --- |
|  | $\delta\_{n}:=\min\{\delta,4\,r\_{n}\},$ |  |

where $r\_{n}$ is the connection radius of the RRT∗ algorithm.
Let $\{\sigma\_{n}\}\_{n\in\mathbb{N}}$ be the sequence paths, the existence of which is guaranteed by Lemma [50](#Thmtheorem50 "Lemma 50 ‣ C.2 Construction of the sequence {𝜎_𝑛}_{𝑛∈ℕ} of paths ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning").

For each $n\in\mathbb{N}$, construct a sequence $\{B\_{n}\}\_{n\in\mathbb{N}}$ of balls that cover $\sigma\_{n}$ as $B\_{n}=\{B\_{n,1},B\_{n,2},\dots,B\_{n,M\_{n}}\}:={\tt CoveringBalls}(\sigma\_{n},r\_{n},2\,r\_{n})$ (see Definition [51](#Thmtheorem51 "Definition 51 (Covering balls) ‣ C.3 Construction of the sequence {𝐵_𝑛}_{𝑛∈ℕ} of sets of balls ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning")), where $r\_{n}$ is the connection radius of the RRT∗ algorithm, i.e., $r\_{n}=\gamma\_{\mathrm{RRT}^{\*}}\left(\frac{\log n}{n}\right)^{1/d}$. Clearly, the balls in $B\_{n}$ are openly disjoint, since the spacing between any two consecutive balls is $2\,r\_{n}$.

### G.3 Connecting the vertices in subsequent balls in $B\_{n}$

For all $m\in\{1,2,\dots,M\_{n}\}$, let $A\_{n,m}$ denote the event that there exists two vertices $X\_{i},X\_{i^{\prime}}\in V^{\mathrm{RRT}^{\*}}\_{n}$ such that $X\_{i}\in B\_{n,m},\,X\_{i^{\prime}}\in B\_{n,m+1}$ and $Y\_{i^{\prime}}\leq Y\_{i}$, where $Y\_{i}$ and $Y\_{i^{\prime}}$ are the marks associated with points $X\_{i}$ and $X\_{i^{\prime}}$, respectively. Notice that, in this case, $X\_{i}$ and $X\_{i^{\prime}}$ will be connected with an edge in $G\_{n}$. Let $A\_{n}$ denote the event that $A\_{n,m}$ holds for all $m\in\{1,2,\dots,M\}$, i.e., $A\_{n}=\bigcap\_{m=1}^{M}A\_{n,m}$.

###### Lemma 71

If $\gamma\_{\mathrm{RRT}^{\*}}>4\,\left(\frac{\mu({\cal X}\_{\mathrm{free}})}{\zeta\_{d}}\right)^{1/d}$, then $A\_{n}$ occurs for all large $n$, with probability one, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\liminf\_{n\to\infty}A\_{n}\right)=1.$ |  |

###### Proof.

The proof of this result is based on a Poissonization argument. Let $\mathrm{Poisson}(\lambda)$ be a Poisson random variable with parameter $\lambda=\theta\,n$, where $\theta\in(0,1)$ is a constant independent of $n$. Consider the point process that consists of exactly $\mathrm{Poisson}(\theta\,n)$ points, i.e., $\{X\_{1},X\_{2},\dots,X\_{\mathrm{Poisson}(\theta\,n)}\}$. This point process is a Poisson point process with intensity $\theta\,n\,/\mu(X\_{\mathrm{free}})$ by Lemma [11](#Thmtheorem11 "Lemma 11 ( ( ) ) ‣ 2.2 Random Geometric Graphs ‣ 2 Preliminary Material ‣ Sampling-based Algorithms for Optimal Motion Planning").

Let $\tilde{A}\_{n,m}$ denote the event that there exists two vertices $X\_{i}$ and $X\_{i^{\prime}}$ in the vertex set of the RRT∗ algorithm such that $X\_{i}$ and $X\_{i^{\prime}}$ are connected with an edge in $\tilde{G}\_{n}$, where $\tilde{G}\_{n}$ is the graph returned by the RRT∗ when the algorithm is run for $\mathrm{Poisson}(\theta\,n)$ many iterations, i.e., $\mathrm{Poisson}(\theta\,n)$ samples are drawn from ${\cal X}\_{\mathrm{free}}$.

Clearly,
$\mathbb{P}(A\_{n,m}^{c})=\mathbb{P}(\tilde{A}\_{n,m}^{c}\,|\,\{\mathrm{Poisson}(\theta\,n)=n\}).$
Moreover,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}(A\_{n,m}^{c})\,\,\leq\,\,\mathbb{P}(\tilde{A}\_{n,m}^{c})+\mathbb{P}(\{\mathrm{Poisson}(\theta\,n)>n\}).$ |  |

since $\mathbb{P}(A\_{n,m}^{c})$ is non-increasing with $n$ ([Penrose, 2003](#bib.bib79), see, e.g.,).
Since $\theta<1$,
$\mathbb{P}(\{\mathrm{Poisson}(\theta\,n)>n\})\,\,\leq\,\,e^{-a\,n},$
where $a>0$ is a constant independent of $n$.

To compute $\mathbb{P}(\widetilde{A}\_{n,m}^{c})$, a number of definitions are provided. Let $N\_{n,m}$ denote the number of vertices that lie in the interior of $B\_{n,m}$. Clearly, $\mathbb{E}[N\_{n,m}]=\frac{\zeta\_{d}\,\gamma\_{{\mathrm{RRT}^{\*}}}^{d}}{\mu(X\_{\mathrm{free}})}\,\log n$, for all $m\in\{1,2,\dots,M\_{n}\}$. For notational simplicity, define $\alpha:=\frac{\zeta\_{d}\,\gamma\_{{\mathrm{RRT}^{\*}}}^{d}}{\mu(X\_{\mathrm{free}})}$. Let $\epsilon\in(0,1)$ be a constant independent of $n$. Define the event

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle C\_{n,m,\epsilon}$ | $\displaystyle:=$ | $\displaystyle\left\{N\_{n,m}\geq(1-\epsilon)\,\mathbb{E}[N\_{n,m}]\right\}=\left\{N\_{n,m}\geq(1-\epsilon)\,\alpha\,\log n\right\}$ |  |

Since $N\_{n,m,\epsilon}$ is binomially distributed, its large deviations from its mean can be bounded as follows ([Penrose, 2003](#bib.bib79)),

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(C\_{n,m,\epsilon}^{c}\right)=\mathbb{P}(\{N\_{n,m,\epsilon}\leq(1-\epsilon)\,\mathbb{E}[N\_{n,m}]\})\leq e^{-\alpha\,H(\epsilon)\,\log n}=n^{-\alpha H(\epsilon)},$ |  |

where $H(\epsilon)=\epsilon+(1-\epsilon)\log(1-\epsilon)$. Notice that $H(\epsilon)$ is a continuous function of $\epsilon$ with $H(0)=0$ and $H(1)=1$. Hence, $H(\epsilon)$ can be made arbitrary close to one by taking $\epsilon$ close to one.

Then,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}(\tilde{A}\_{n,m}^{c})$ | $\displaystyle=$ | $\displaystyle\mathbb{P}(\tilde{A}\_{n,m}^{c}\,|\,C\_{n,m,\epsilon}\cap C\_{n,m+1,\epsilon})\,\mathbb{P}(C\_{n,m,\epsilon}\cap C\_{n,m+1,\epsilon})$ |  |
|  |  |  | $\displaystyle+\mathbb{P}(\tilde{A}\_{n,m}^{c}\,|\,(C\_{n,m,\epsilon}\cap C\_{n,m+1,\epsilon})^{c})\,\mathbb{P}((C\_{n,m,\epsilon}\cap C\_{n,m+1,\epsilon})^{c})$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle\mathbb{P}(\tilde{A}\_{n,m}^{c}\,|\,C\_{n,m,\epsilon}\cap C\_{n,m+1,\epsilon})\,\mathbb{P}(C\_{n,m,\epsilon}\cap C\_{n,m+1,\epsilon})+\mathbb{P}(C\_{n,m,\epsilon}^{c})+\mathbb{P}(C\_{n,m+1,\epsilon}^{c}),$ |  |

where the last inequality follows from the union bound.

First, using the spatial independence of the underlying point process,

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\mathbb{P}\left(C\_{n,m,\epsilon}\cap C\_{n,m+1,\epsilon}\right)=\mathbb{P}\left(C\_{n,m,\epsilon}\right)\,\mathbb{P}\left(C\_{n,m+1,\epsilon}\right)\leq n^{-2\,\alpha\,H(\epsilon)}.$ |  |

Second, observe that $\mathbb{P}(A\_{n,m}^{c}\,|\,N\_{n,m}=k,N\_{n,m+1}=k^{\prime})$ is a non-increasing function of both $k$ and $k^{\prime}$, since the probability of the event $\tilde{A}\_{n,m}$ can not increase with the increasing number of points in both balls, $B\_{n,m}$ and $B\_{n,m+1}$.
Then,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}(\tilde{A}\_{n,m}^{c}\,|\,C\_{n,m,\epsilon}\cap C\_{n,m+1,\epsilon})$ | $\displaystyle=$ | $\displaystyle\mathbb{P}(\tilde{A}\_{n,m}^{c}\,|\,\{N\_{n,m}\geq(1-\epsilon)\,\alpha\,\log N\_{n,m},N\_{n,m+1}\geq(1-\epsilon)\,\alpha\,\log N\_{n,m+1}\})$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle\mathbb{P}(\tilde{A}\_{n,m}^{c}\,|\,\{N\_{n,m}=(1-\epsilon)\,\alpha\,\log N\_{n,m},N\_{n,m+1}=(1-\epsilon)\,\alpha\,\log N\_{n,m+1}\})$ |  |

The term on the right hand side is one minus the probability that the maximum of $\alpha\,\log n$ number of uniform samples drawn from $[0,1]$ is smaller than the minimum of $\alpha\,\log n$ number of samples again drawn from $[0,1]$, where all the samples are drawn independently. This probability can be calculated as follows. From the order statistics of uniform distribution, the minimum of $\alpha\,\log n$ points sampled independently and uniformly from $[0,1]$ has the following probability distribution function:

|  |  |  |
| --- | --- | --- |
|  | $f\_{\mathrm{min}}(x)=\frac{(1-x)^{\alpha\,\log n-1}}{{{\tt Beta}(1,\alpha\,\log(n))}},$ |  |

where ${{\tt Beta}(\cdot,\cdot)}$ is the Beta function (also called the Euler integral) ([Abramowitz and Stegun, 1964](#bib.bib1)). The maximum of the same number of independent uniformly distributed random variables with support $[0,1]$ has the following cumulative distribution function:

|  |  |  |
| --- | --- | --- |
|  | $F\_{\mathrm{max}}(x)=x^{\alpha\log n}$ |  |

Then,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}(\tilde{A}\_{n,m}^{c}\,|\,C\_{n,m,\epsilon}\cap C\_{n,m+1,\epsilon})$ | $\displaystyle\leq$ | $\displaystyle\int\_{0}^{1}F\_{\mathrm{max}}(x)\,f\_{\mathrm{min}}(x)\,dx$ |  |
|  |  | $\displaystyle=$ | $\displaystyle\frac{{{\tt Gamma}((1-\epsilon)\,\alpha\,\log n)}\,{{\tt Gamma}((1-\epsilon)\,\epsilon\,\log n)}}{2\,{{\tt Gamma}(2(1-\epsilon)\,\alpha\,\log(n))}}$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle\frac{((1-\epsilon)\,\alpha\,\log n)!\,((1-\epsilon)\,\alpha\,\log n)!}{2\,(2\,(1-\epsilon)\,\alpha\,\log n)!}$ |  |
|  |  | $\displaystyle=$ | $\displaystyle\frac{((1-\epsilon)\,\alpha\,\log n)!}{2(2(1-\epsilon)\,\alpha\,\log n)(2(1-\epsilon)\,\alpha\,\log n-1)\cdots 1}$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle\frac{1}{2^{(1-\epsilon)\,\alpha\,\log n}}=n^{-\,\log(2)\,(1-\epsilon)\,\alpha\,},$ |  |

where ${{\tt Gamma}(\cdot)}$ is the gamma function ([Abramowitz and Stegun, 1964](#bib.bib1)).

Then,

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\mathbb{P}(\tilde{A}\_{n,m}^{c})\leq n^{-\alpha\big(2\,H(\epsilon)+\log(2)\,(1-\epsilon)\big)}+2\,n^{-\alpha\,H(\epsilon)}.$ |  |

Since $2\,H(\epsilon)+\log(2)\,(1-\epsilon)$ and $H(\epsilon)$ are both continuous and increasing in the interval $(0.5,1)$, the former is equal to $2-\log(4)>0.5$ and the latter is equal to $1$ as $\epsilon$ approaches one from below, there exists some $\bar{\epsilon}\in(0.5,1)$ such that both $2\,H(\bar{\epsilon})+\log(2)\,(1-\bar{\epsilon})>0.5$ and $H(\bar{\epsilon})>0.5$. Thus,

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\mathbb{P}(\tilde{A}\_{n,m}^{c})\leq n^{-\alpha/2}+2\,n^{-\alpha/2}=3\,n^{-\alpha/2}.$ |  |

Hence,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbb{P}(A\_{n,m}^{c})$ | $\displaystyle\leq$ | $\displaystyle\mathbb{P}(\tilde{A}\_{n,m}^{c})+\mathbb{P}(\mathrm{Poisson}(\theta\,n)>n)$ |  |
|  |  | $\displaystyle\leq$ | $\displaystyle 3\,n^{-\alpha/2}+e^{-a\,n}$ |  |

Recall that $A\_{n}$ denotes the event that $A\_{n,m}$ holds for all $m\in\{1,2,\dots,M\_{n}\}$. Then,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}(A\_{n}^{c})\,\,=\,\,\mathbb{P}\left(\left(\bigcap\nolimits\_{m=1}^{M\_{n}}A\_{n,m}\right)^{c}\right)\,\,=\,\,\mathbb{P}\left(\bigcup\nolimits\_{m=1}^{M\_{n}}A\_{n,m}^{c}\right)\,\,\leq\,\,\sum\_{m=1}^{M\_{n}}\,\mathbb{P}\left(A\_{n,m}^{c}\right)\,\,=\,\,M\_{n}\,\mathbb{P}(A\_{n,1}^{c}),$ |  |

where the last inequality follows from the union bound. The number of balls in $B\_{n}$ can be bounded as

|  |  |  |
| --- | --- | --- |
|  | $|B\_{n}|\,\,=\,\,M\_{n}\,\,\leq\,\,\beta\,\left(\frac{n}{\log n}\right)^{1/d},$ |  |

where $\beta$ is a constant. Combining this with the inequality above,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}(A\_{n}^{c})\,\,\leq\,\,\beta\left(\frac{n}{\log n}\right)^{1/d}\,\left(3\,n^{-\alpha/2}+e^{-a\,n}\right),$ |  |

which is summable for $\alpha>2\,(1+1/d)$. Thus, by the Borel-Cantelli lemma, the probability that $A\_{n}^{c}$ occurs infinitely often is zero, i.e., $\mathbb{P}(\limsup\_{n\to\infty}A\_{n}^{c})=0$, which implies that $A\_{n}$ occurs for all large $n$ with probability one, i.e., $\mathbb{P}(\liminf\_{n\to\infty}A\_{n})=1$.
∎∎

### G.4 Convergence to the optimal path

The proof of the following lemma is similar to that of Lemma [55](#Thmtheorem55 "Lemma 55 ‣ C.6 Convergence to the optimal path ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning"), and is omitted here.

Let $P\_{n}$ denote the set of all paths in the graph returned by ${\mathrm{RRT}^{\*}}$ algorithm at the end of $n$ iterations.
Let $\sigma\_{n}^{\prime}$ be the path that is closest to $\sigma\_{n}$ in terms of the bounded variation norm among all those paths in $P\_{n}$, i.e.,
$\sigma\_{n}^{\prime}:=\min\_{\sigma^{\prime}\in P\_{n}}\|\sigma^{\prime}-\sigma\_{n}\|.$

###### Lemma 72

The random variable $\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}$ converges to zero almost surely, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\mathbb{P}\left(\left\{\lim\nolimits\_{n\to\infty}\|\sigma\_{n}^{\prime}-\sigma\_{n}\|\_{\mathrm{BV}}=0\right\}\right)=1.$ |  |

A corollary of the lemma above is that $\lim\_{n\to\infty}\sigma\_{n}^{\prime}=\sigma^{\*}$ with probability one. Then, the result follows by the robustness of the optimal solution (see the proof of Lemma [56](#Thmtheorem56 "Lemma 56 ‣ C.6 Convergence to the optimal path ‣ Appendix C Proof of Theorem (Asymptotic optimality of PRM∗) ‣ Sampling-based Algorithms for Optimal Motion Planning") for details).
