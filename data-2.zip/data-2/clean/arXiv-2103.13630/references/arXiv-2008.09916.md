<!-- fulltext source=arxiv_html slug=arXiv-2008.09916 fetched=2026-09-21T06:41:45+00:00 -->

# One Weight Bitwidth to Rule Them All

Ting-Wu Chin
Affiliation: Eletrical and Computer Engineering, Carnegie Mellon University
E-mail [{tingwuc,dianam}@cmu.edu](mailto:%7Btingwuc,dianam%7D@cmu.edu)
  
Pierce I-Jen Chuang
Affiliation: Facebook Inc.
E-mail [{pichuang,vchandra}@fb.com](mailto:%7Bpichuang,vchandra%7D@fb.com)
  
Vikas Chandra
Affiliation: Facebook Inc.
E-mail [{pichuang,vchandra}@fb.com](mailto:%7Bpichuang,vchandra%7D@fb.com)
  
Diana Marculescu
Affiliation: Eletrical and Computer Engineering, Carnegie Mellon University
E-mail [{tingwuc,dianam}@cmu.edu](mailto:%7Btingwuc,dianam%7D@cmu.edu)
Affiliation: Eletrical and Computer Engineering, The University of Texas at Austin
E-mail [{dianam}@utexas.edu](mailto:%7Bdianam%7D@utexas.edu)

###### Abstract

Weight quantization for deep ConvNets has shown promising results for applications such as image classification and semantic segmentation and is especially important for applications where memory storage is limited. However, when aiming for quantization without accuracy degradation, different tasks may end up with different bitwidths. This creates complexity for software and hardware support and the complexity accumulates when one considers mixed-precision quantization, in which case each layer’s weights use a different bitwidth. Our key insight is that optimizing for the least bitwidth subject to no accuracy degradation is not necessarily an optimal strategy. This is because one cannot decide optimality between two bitwidths if one has smaller model size while the other has better accuracy. In this work, we take the first step to understand if some weight bitwidth is better than others by aligning all to the same model size using a width-multiplier. Under this setting, somewhat surprisingly, we show that using a single bitwidth for the whole network can achieve better accuracy compared to mixed-precision quantization targeting zero accuracy degradation when both have the same model size. In particular, our results suggest that when the number of channels becomes a target hyperparameter, a single weight bitwidth throughout the network shows superior results for model compression.

###### Keywords:

Model Compression, Deep Learning Architectures, Quantization, ConvNets, Image Classification

## 1 Introduction

Recent success of ConvNets in computer vision applications such as image classification and semantic segmentation has fueled many important applications in storage-constrained devices, *e.g.*, virtual reality headsets, drones, and IoT devices. As a result, improving the parameter-efficiency (the top-1 accuracy to the parameter counts ratio) of ConvNets while maintaining their attractive features (*e.g.*, accuracy for a task) has gained tremendous research momentum recently.

Among the efforts of improving ConvNets’ efficiency, weight quantization was shown to be an effective technique [[39](#bib.bib39), [38](#bib.bib38), [10](#bib.bib10), [5](#bib.bib5)]. The majority of research efforts in quantization has targeted quantization algorithms for finding the lowest possible weight bitwidth without compromising the figure-of-merit (*i.e.*, accuracy). Mixed-precision quantization methods, which allow different bitwidths to be selected for different layers in the network, have recently been proposed to further compress deep ConvNets [[29](#bib.bib29), [31](#bib.bib31), [6](#bib.bib6)]. Nevertheless, having different bitwidths for different layers greatly increases the neural network implementation complexity from both hardware and software perspectives. For example, hardware and software implementations optimized for executing an 8 bits convolution are sub-optimal for executing a 4 bits convolution, and vice versa.

To minimize the efforts of hardware and software support, it is natural to wonder: ‘‘Is some weight bitwidth better than others?’’ However, this is an ill-posed problem as one cannot decide optimality between two bitwidths if one has smaller model size while the other has better accuracy. This work takes a first step towards understanding if some bitwidth is better than other bitwidths under a given model size constraint. Given the multi-objective nature of the problem, we need to align different bitwidths to the same model size to further decide the optimality for the bitwidth selection. To realize model size alignment for different bitwidths, we use the width-multiplier11
1
Width-multiplier grows or shrinks the number of channels across the layers with identical proportion for a certain network, *e.g.*, grow the number of channels for all the layers by $2\times$. [[11](#bib.bib11)] as a tool to compare the performance of different weight bitwidths under *the same model size*.

With this setting, we find that there exists some weight bitwidth that consistently outperforms others across different model sizes when both are considered under a given model size constraint. This suggests that one can decide the optimal bitwidth for small model sizes to save computing cost and the result generalizes to large model sizes22
2
Note that we use width-multiplier to scale model across different sizes.. Additionally, we show that the optimal bitwidth of a convolutional layer negatively correlates to the convolutional kernel fan-in. As an example, depth-wise convolutional layers turn to have optimal bitwidth values that are higher than that of all-to-all convolutions. We further provide a theoretical reasoning for this phenomenon. These findings suggest that architectures such as VGG and ResNets are more parameter-efficient when they are wide and use binarized weights. On the other hand, networks such as MobileNets [[11](#bib.bib11)] might require different weight bitwidths for all-to-all convolutions and depth-wise convolutions. Somewhat surprisingly, we find that on ImageNet, under a given model size constraint, a single bitwidth for both ResNet-50 and MobileNetV2 can outperform mixed-precision quantization using reinforcement learning [[29](#bib.bib29)] that targets minimum total bitwidth without accuracy degradation. This suggests that searching for the minimum bitwidth configuration that does not introduce accuracy degradation without considering other hyperparameters affecting model size is a sub-optimal strategy. Our results suggest that when the number of channels becomes one of the hyperparameters under consideration, a single weight bitwidth throughout the network shows great potential for model compression.

In summary, we systematically analyze the model size and accuracy trade-off considering both weight bitwidths and the number of channels for various modern networks architectures (variants of ResNet, VGG, and MobileNet) and datasets (CIFAR and ImageNet) and have the following contributions:

* •

  We empirically show that when allowing the network width to vary, lower weight bitwidths outperform higher ones in a Pareto sense (accuracy vs. model size) for networks with standard convolutions. This suggests that for such ConvNets, further research on wide binary weight networks is likely to identify better network configurations which will require further hardware/software platform support.
* •

  We empirically show that the optimal bitwidth of a convolutional layer negatively correlates to the convolutional kernel fan-in and provide theoretical reasoning for such a phenomenon. This suggests that one could potential categorize ConvNets based on the convolutional kernel fan-in when designing the corresponding bitwidth support from both software and hardware.
* •

  We empirically show that one can achieve a more accurate model (under a given model size) by using a single bitwidth when compared to mixed-precision quantization that uses deep reinforcement learning to search for layer-wise weight precision values. Moreover, the results are validated on a large-scale dataset, *i.e.*, ImageNet.

The remainder of the paper is organized as follows. Section [2](#S2 "2 Related Work ‣ One Weight Bitwidth to Rule Them All") discusses related work. Section [3](#S3 "3 Methodology ‣ One Weight Bitwidth to Rule Them All") discusses the methodology used to discover our findings. Section [4](#S4 "4 Experiments ‣ One Weight Bitwidth to Rule Them All") discusses our experiments for all our findings. In particular, Section [4.2](#S4.SS2 "4.2 bitwidth comparisons ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All") shows that some bitwidth can outperform others consistently across model sizes when both are compared under the same model size constraint using width-multipliers. Section [4.3](#S4.SS3 "4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All") discusses how fan-in channel count per convolutional kernel affects the resilience of quantization for convolution layers, which further affects the optimal bitwidth for a convolution layer. Section [4.4](#S4.SS4 "4.4 Remarks and scaling up to ImageNet ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All") scales up our experiments to ImageNet and demonstrates that a single weight bitwidth manages to outperform mixed-precision quantization given the same model size. Section [5](#S5 "5 Conclusion ‣ One Weight Bitwidth to Rule Them All") concludes the paper.

## 2 Related Work

Several techniques for improving the efficiency of ConvNets have been recently proposed. For instance, pruning removes the redundant connections of a trained neural network [[41](#bib.bib41), [33](#bib.bib33), [28](#bib.bib28), [16](#bib.bib16), [7](#bib.bib7), [3](#bib.bib3), [34](#bib.bib34)], neural architecture search (NAS) tunes the number of channels, size of kernels, and depth of a network [[27](#bib.bib27), [26](#bib.bib26), [2](#bib.bib2), [25](#bib.bib25)], and convolution operations can be made more efficient via depth-wise convolutions [[11](#bib.bib11)], group convolutions [[12](#bib.bib12), [37](#bib.bib37)], and shift-based convolutions [[9](#bib.bib9), [30](#bib.bib30)]. In addition to the aforementioned techniques, network quantization introduces an opportunity for hardware-software co-design to achieve better efficiency for ConvNets.

There are in general two directions for weight quantization in prior literature, post-training quantization [[20](#bib.bib20), [18](#bib.bib18), [36](#bib.bib36), [23](#bib.bib23)] and quantization-aware training [[21](#bib.bib21), [40](#bib.bib40), [13](#bib.bib13), [14](#bib.bib14), [35](#bib.bib35), [10](#bib.bib10), [4](#bib.bib4)]. The former assumes training data is not available when quantization is applied. While being fast and training-data-free, its performance is worse compared to quantization-aware training. In contrast, our work falls under the category of quantization-aware training.

In quantization-aware training, [[21](#bib.bib21)] introduces binary neural networks, which lead to significant efficiency gain by replacing multiplications with XNOR operations at the expense of significant accuracy degradation. Later, [[40](#bib.bib40)] propose ternary quantization and [[39](#bib.bib39), [13](#bib.bib13)] bridge the gap between floating-point and binarized neural networks by introducing fixed-point quantization. Building upon prior art, the vast majority of existing work focuses on reducing the accuracy degradation by improving the training strategy [[38](#bib.bib38), [32](#bib.bib32), [17](#bib.bib17), [5](#bib.bib5)] and developing better quantization schemes [[14](#bib.bib14), [29](#bib.bib29), [35](#bib.bib35)]. However, prior art has studied quantization by fixing the network architecture, which may lead to a sub-optimal bitwidth selection in terms of parameter-efficiency (the top-1 accuracy to the parameter counts ratio).

Related to our work, [[19](#bib.bib19)] have also considered the impact of channel count in quantization. In contrast, our work has the following novel features. First, we find that in ConvNets with standard convolutions, *a lower bitwidth outperforms higher ones under a given model size constraint*. Second, we find that the Pareto optimal bitwidth negatively correlates to the convolutional kernel fan-in and we provide theoretical insights for it. Last, we show that a single weight bitwidth can outperform *mixed-precision* quantization on ImageNet for ResNet50 and MobileNetV2.

## 3 Methodology

In this work, we are interested in comparing different bitwidths under a given model size. To do so, we make use of the width-multiplier to scale the models. To be precise in the following discussion, we define an ordering relation across bitwidths as follows:

###### Definition 1 (bitwidth ordering)

We say bitwidth $A$ is better than bitwidth $B$ for a network family $\mathcal{F}$, if,

|  |  |  |
| --- | --- | --- |
|  | $Acc(N(A,s))>Acc(N(B,s))~~\forall s,$ |  |

where $Acc(\cdot)$ evaluates the validation accuracy of a network, $N(A,s)$ produces a network in $\mathcal{F}$ that has bitwidth $A$ and model size of $s$ by using width-multiplier.

With Definition [1](#Thmdefinition1 "Definition 1 (bitwidth ordering) ‣ 3 Methodology ‣ One Weight Bitwidth to Rule Them All"), we can now compare weight bitwidths for their parameter-efficiency.

### 3.1 Quantization

This work focuses on weight quantization and we use a straight-through estimator [[1](#bib.bib1)] to conduct quantization-aware training. Specifically, for bitwidth values larger than 2 bit ($b>2$), we use the following quantization function for weights during the forward pass:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}Q({\bm{W}}\_{i,:})&=\lfloor\frac{clamp({\bm{W}}\_{i,:},-{a}\_{i},{a}\_{i})}{{r}\_{i}}\rceil\times{r}\_{i},~~{r}\_{i}=\frac{{a}\_{i}}{2^{b-1}-1}\end{split}$ |  | (1) |

where

|  |  |  |
| --- | --- | --- |
|  | $clamp(w,min,max)=\begin{cases}w,&\text{if}\ min\leq w\leq max\\ min,&\text{if}\ w<min\\ max&\text{if}\ w>max\end{cases}$ |  |

and $\lfloor\cdot\rceil$ denotes the round-to-nearest-neighbor function, ${\bm{W}}\in\mathbb{R}^{C\_{out}\times d},~d=C\_{in}K\_{w}K\_{h}$ denotes the real-value weights for the $i^{\text{th}}$ output filter of a convolutional layer that has $C\_{in}$ channels and $K\_{w}\times K\_{h}$ kernel size. ${\bm{a}}\in\mathbb{R}^{C\_{out}}$ denotes the vector of clipping factors which are selected to minimize $\lVert Q({\bm{W}}\_{i,:})-{\bm{W}}\_{i,:}\rVert^{2}\_{2}$ by assuming ${\bm{W}}\_{i,:}~\sim\mathcal{N}(0,\sigma^{2}{\bm{I}})$. More details about the determination of ${a}\_{i}$ is in Appendix [0.A](#Pt0.A1 "Appendix 0.A Clipping Point for Quantization-aware Training ‣ One Weight Bitwidth to Rule Them All").

For special cases such as 2 bits and 1 bit, we use schemes proposed in prior literature. Specifically, let us first define:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bar{|{\bm{W}}\_{i,:}|}=\frac{1}{d}\sum\_{j=1}^{d}|{\bm{W}}\_{i,j}|.$ |  | (2) |

For 2 bit, we follow trained ternary networks [[40](#bib.bib40)] and define the quantization function as follows:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}Q({\bm{W}}\_{i,:})&=\left(sign({\bm{W}}\_{i,:})\odot{\bm{M}}\_{i,j}\right)\times\left(\bar{|{\bm{W}}\_{i,:}|}\right)\\ {\bm{M}}\_{i,j}&=\begin{cases}0,&{\bm{W}}\_{i,j}<0.7\bar{|{\bm{W}}\_{i,:}|}.\\ 1,&otherwise.\end{cases}\end{split}$ |  | (3) |

For 1 bit, we follow DoReFaNets [[39](#bib.bib39)] and define the quantization function as follows:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}Q({\bm{W}}\_{i,:})&=sign({\bm{W}}\_{i,:})\times\left(\bar{|{\bm{W}}\_{i,:}|}\right).\end{split}$ |  | (4) |

For the backward pass for all the bitwidths, we use a straight-through estimator as in prior literature to make the training differentiable. That is,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}\frac{\partial Q({\bm{W}}\_{i,:})}{\partial{\bm{W}}\_{i,:}}={\bm{I}}.\end{split}$ |  | (5) |

In the sequel, we quantize the *first and last layers to 8 bits*. They are fixed throughout the experiments. We note that it is a common practice to leave the first and the last layer *un-quantized* [[39](#bib.bib39)], however, we find that using 8 bits can achieve comparable results to the floating-point baselines.

As for activation, we use the technique proposed in [[13](#bib.bib13)] and use 4 bits for CIFAR-100 and 8 bits for ImageNet experiments. The activation bitwidths are chosen such that the quantized network has comparable accuracy to the floating-point baselines.

### 3.2 Model size

The size of the model ($C\_{size}$) is defined as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}\mathcal{C}\_{size}=\sum\_{i=1}^{O}b(i)C\_{in}(i)K\_{w}(i)K\_{h}(i)\end{split}$ |  | (6) |

where $O$ denotes the total number of filters, $b(i)$ is the bitwidth for filter $i$, $C\_{in}(i)$ denotes the number of channels for filter $i$, and $K\_{w}(i)$ and $K\_{h}(i)$ are the kernel height and width for filter $i$.

## 4 Experiments

We conduct all our experiments on image classification datasets including CIFAR-100 [[15](#bib.bib15)] and ImageNet. All experiments are trained from scratch to ensure different weight bitwidths are trained equally long. While we do not start from a pre-trained model, we note that our baseline fixed-point models (*i.e.*, 4 bits for CIFAR and 8 bits for ImageNet) have accuracy comparable to their floating-point counterparts. For all the experiments on CIFAR, we run the experiments three times and report the mean and standard deviation.

### 4.1 Training hyper-parameters

For CIFAR, we use a learning rate of 0.05, cosine learning rate decay, linear learning rate warmup (from 0 to 0.05) with 5 epochs, batch size of 128, total training epoch of 300, weight decay of $5e^{-4}$, SGD optimizer with Nesterov acceleration and 0.9 momentum.

For ImageNet, we have identical hyper-parameters as CIFAR except for the following hyper-parameters batch size of 256, 120 total epochs for MobileNetV2 and 90 for ResNets, weight decay $4e^{-5}$, and 0.1 label smoothing.

### 4.2 bitwidth comparisons

In this subsection, we are primarily interested in the following question:

When taking network width into account, does one bitwidth

consistently outperform others across model sizes?

To our best knowledge, this is an open question and we take a first step to answer this question empirically. If the answer is affirmative, it may be helpful to focus the software/hardware support on the better bitwidth when it comes to parameter-efficiency. We consider three kinds of commonly adopted ConvNets, namely, ResNets with basic block [[8](#bib.bib8)], VGG [[24](#bib.bib24)], and MobileNetV2 [[22](#bib.bib22)]. These networks differ in the convolution operations, connections, and filter counts. For ResNets, we explored networks from 20 to 56 layers in six layer increments. For VGG, we investigate the case of eleven layers. Additionally, we also study MobileNetV2, which is a mobile-friendly network. We note that we modify the stride count in of the original MobileNetV2 to match the number of strides of ResNet for CIFAR. The architectures that we introduce for the controlled experiments are discussed in detail in Appendix [0.B](#Pt0.A2 "Appendix 0.B Network Architectures ‣ One Weight Bitwidth to Rule Them All").

For CIFAR-100, we only study weight bitwidths below 4 since it achieves performance comparable to its floating-point counterpart. Specifically, we consider 4 bits, 2 bits, and 1 bit weights. To compare different weight bitwidths using Definition [1](#Thmdefinition1 "Definition 1 (bitwidth ordering) ‣ 3 Methodology ‣ One Weight Bitwidth to Rule Them All"), we use the width-multiplier to align the model size among them. For example, one can make a 1-bit ConvNet twice as wide to match the model size of a 4-bit ConvNet 33
3
Increase the width of a layer increases the number of output filters for that layer as well as the number of channels for the subsequent layer. Thus, number of parameters and number of operations grow approximately quadratically with the width-multiplier.. For each of the networks we study, we sweep the width-multiplier to consider points at multiple model sizes. Specifically, for ResNets, we investigate seven depths, four model sizes for each depth, and three bitwidths, which results in $7\times 4\times 3\times 3$ experiments. For both VGG11 and MobileNetV2, we consider eight model sizes and three bitwidths, which results in $2\times 8\times 3\times 3$ experiments.

As shown in Fig. [1](#S4.F1 "Figure 1 ‣ 4.2 bitwidth comparisons ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), across the three types of networks we study, there exists some bitwidth that is better than others. That is, the answer to the question we raised earlier in this subsection is affirmative. For ResNets and VGG, this value is 1 bit. In contrast, for MobileNetV2, it is 4 bits. The results for ResNets and VGG are particularly interesting since lower weight bitwidths are better than higher ones. In other words, binary weights in these cases can achieve the best accuracy and model size trade-off. On the other hand, MobileNetV2 exhibits a different trend where higher bitwidths are better than lower bitwidths up to 4 bits44
4
However, not higher than 4 bits since the 4-bit model has accuracy comparable to the floating-point model..

(a) ResNets (20 to 56 layers in increments of 6)

(b) VGG11

(c) MobileNetV2

Figure 1: Some bitwidth is consistently better than other bitwidths across model sizes. $\mathcal{C}\_{size}$ denotes model size. $x$W$y$A denotes $x$-bit weight quantization and $y$-bit activation quantization. The experiments are done on the CIFAR-100 dataset. For each network, we sweep the width-multiplier to cover points at multiple model sizes. For each dot, we plot the mean and standard deviation of three random seeds. The standard deviation might not be visible due to little variances.

### 4.3 ConvNet architectures and quantization

While there exists an ordering among different bitwidths as shown in Fig. [1](#S4.F1 "Figure 1 ‣ 4.2 bitwidth comparisons ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), it is not clear what determines the optimal weight bitwidth. To further uncover the relationship between ConvNet’s architectural parameters and its optimal weight bitwidth, we ask the following questions.

What architectural components determine the MobileNetV2

optimal weight bitwidth of 4 bits as opposed to 1 bit?

As it can be observed in Fig. [1](#S4.F1 "Figure 1 ‣ 4.2 bitwidth comparisons ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), MobileNetV2 is a special case where the higher bitwidth is better than lower ones. When comparing MobileNetV2 to the other two networks, there are many differences, including how convolutions are connected, how many convolutional layers are there, how many filters in each of them, and how many channels for each convolution. To narrow down which of these aspects result in the reversed trend compared to the trend exhibits in ResNets and VGG, we first consider the inverted residual blocks, *i.e.*, the basic component in MobileNetV2. To do so, we replace all basic blocks (two consecutive convolutions) of ResNet26 with the inverted residual blocks as shown in Fig. [2(c)](#S4.F2.sf3 "In Figure 2 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All") and [2(d)](#S4.F2.sf4 "In Figure 2 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"). We refer to this new network as Inv-ResNet26. As shown in Fig. [2(a)](#S4.F2.sf1 "In Figure 2 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All") and [2(b)](#S4.F2.sf2 "In Figure 2 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), the optimal bitwidth shifts from 1 bit to 4 bit once the basic blocks are replaced with inverted residual blocks. Thus, we can infer that the inverted residual block itself or its components are responsible for such a reversed trend.

(a) ResNet26

(b) Inv-ResNet26

(c) Basic block

(d) Inverted residual block

Figure 2: The optimal bitwidth for ResNet26 changes from 1 bit (a) to 4 bit (b) when the building blocks change from basic blocks (c) to inverted residual blocks (d). $\mathcal{C}\_{size}$ in (a) and (b) denotes model size. ($C\_{out}$, $C\_{in}$, $K$, $K$) in (c) and (d) indicate output channel count, input channel count, kernel width, and kernel height of a convolution.

Since an inverted residual block is composed of a point-wise convolution and a depth-wise separable convolution, we further consider the case of depth-wise separable convolution (DWSConv). To identify whether DWSConv can cause the inverted trend, we use VGG11 as a starting point and gradually replace each of the convolutions with DWSConv. We note that doing so results in architectures that gradually resemble MobileNetV1 [[11](#bib.bib11)]. Specifically, we introduce three variants of VGG11 that have an increasing number of convolutions replaced by DWSConvs. Starting with the second layer, *variant A* has one layer replaced by DWSConv, *variant B* has four layers replaced by DWSConvs, and *variant C* has all of the layers except for the first layer replaced by DWSConvs (the architectures are detailed in Appendix [0.B](#Pt0.A2 "Appendix 0.B Network Architectures ‣ One Weight Bitwidth to Rule Them All")).

As shown in Fig. [4](#S4.F4 "Figure 4 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), as the number of DWSConv increases (from variant A to variant C), the optimal bitwidth shifts from 1 bit to 4 bits, which implies that depth-wise separable convolutions or the layers within it are affecting the optimal bitwidth. To identify which of the layers of the DWSConv (*i.e.*, the depth-wise convolution or the point-wise convolution) has more impact on the optimal bitwidth, we keep the bitwidth of depth-wise convolutions fixed at 4 bits and quantize other layers. As shown in Fig. [4(d)](#S4.F4.sf4 "In Figure 4 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), the optimal curve shifts from 4 bits being the best back to 1 bit, with a similarly performing 2 bits. Thus, depth-wise convolutions appear to directly affect the optimal bitwidth trends.

Is depth-wise convolution less resilient to quantization or

less sensitive to channel increase?

Figure 3: Visualization of our accuracy decomposition, which is used for analyzing depth-wise convolutions.

After identifying that depth-wise convolutions have a different characteristic in optimal bitwidth compared to standard all-to-all convolutions, we are interested in understanding the reason behind this. In our setup, the process to obtain a lower bitwidth network that has the same model size as a higher bitwidth network can be broken down into two steps: (1) quantize a network to lower bitwidth and (2) grow the network with width-multiplier to compensate for the reduced model size. As a result, the fact that depth-wise convolution has higher weight bitwidth better than lower weight bitwidth might potentially be due to the large accuracy degradation introduced by quantization or the small accuracy improvements from the use of more channels.

To further diagnose the cause, we decompose the accuracy difference between a lower bitwidth but wider network and a higher bitwidth but narrower network into accuracy differences incurred in the aforementioned two steps as shown in Fig. [3](#S4.F3 "Figure 3 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"). Specifically, let $\Delta Acc\_{Q}$ denote the accuracy difference incurred by quantizing a network and let $\Delta Acc\_{G}$ denote the accuracy difference incurred by increasing the channel count of the quantized network.

(a) Variant A

(b) Variant B

(c) Variant C

(d) Variant C without quantizing depth-wise convolutions

Figure 4: The optimal bitwidth for VGG shifts from 1 bit to 4 bit as more convolutions are replaced with depth-wise separable convolutions (DWSConv), i.e., from (a) to (c). Variant A, B, and C have 30%, 60%, and 90% of the convolution layers replaced with DWSConv, respectively. As shown in (d), the optimal bitwidth changes back to 1 bit if we only quantize point-wise convolution but not depth-wise convolutions.

We analyze $\Delta Acc\_{G}$ and $\Delta Acc\_{Q}$ for networks with and without quantizing depth-wise convolutions, *i.e.*, Fig. [4(c)](#S4.F4.sf3 "In Figure 4 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All") and Fig. [4(d)](#S4.F4.sf4 "In Figure 4 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"). In other words, we would like to understand how depth-wise convolutions affect $\Delta Acc\_{G}$ and $\Delta Acc\_{Q}$. On one hand, $\Delta Acc\_{Q}$ is evaluated by comparing the accuracy of the 4-bit model and the corresponding 1-bit model. On the other hand, $\Delta Acc\_{G}$ is measured by comparing the accuracy of the 1-bit model and its 2$\times$ grown counterpart. As shown in Table [1](#S4.T1 "Table 1 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), when quantizing depth-wise convolutions, $\Delta Acc\_{Q}$ becomes more negative such that $\Delta Acc\_{Q}~+~\Delta Acc\_{G}~<~0$. This implies that the main reason for the optimal bitwidth change is that quantizing depth-wise convolutions introduce more accuracy degradation than it can be recovered by increasing the channel count when going below 4 bits compared to all-to-all convolutions. We note that it is expected that quantizing the depth-wise convolutions would incur smaller $\Delta Acc\_{Q}$ compared to their no-quantization baseline because we essentially quantized more layers. However, depth-wise convolutions only account for 2% of the model size but incur on average near $4\times$ more accuracy degradation when quantized.

We would like to point out that Sheng et al. [[23](#bib.bib23)] also find that quantizing depth-wise separable convolutions incurs large accuracy degradation. However, their results are based on post-training layer-wise quantization. As mentioned in their work [[23](#bib.bib23)], the quantization challenges in their setting could be resolved by quantization-aware training, which is the scheme considered in this work. Hence, our observation is novel and interesting.

Table 1: Quantizing depth-wise convolution introduces large accuracy degradation across model sizes. $\Delta Acc\_{Q}=Acc\_{1bit}-Acc\_{4bit}$ denotes the accuracy introduced by quantization and $\Delta Acc\_{G}=Acc\_{1bit,2\times}-Acc\_{1bit}$ denotes the accuracy improvement by increasing channel counts. The ConvNet is VGG variant C with and without quantizing the depth-wise convolutions from 4 bits to 1 bit.

Width-multiplier
$1.00\times$
$1.25\times$
$1.50\times$
$1.75\times$
$2.00\times$
Average

Variant C
$\Delta Acc\_{Q}$
$\Delta Acc\_{G}$
$\Delta Acc\_{Q}$
$\Delta Acc\_{G}$
$\Delta Acc\_{Q}$
$\Delta Acc\_{G}$
$\Delta Acc\_{Q}$
$\Delta Acc\_{G}$
$\Delta Acc\_{Q}$
$\Delta Acc\_{G}$
$\Delta Acc\_{Q}$
$\Delta Acc\_{G}$

w/o Quantizing DWConv
-1.54
+2.61
-2.76
+2.80
-1.77
+1.74
-1.82
+1.64
-1.58
+1.55
-1.89
+2.07

Quantizing DWConv
-8.60
+4.39
-7.60
+3.41
-7.74
+3.19
-8.61
+4.09
-7.49
+2.25
-8.01
+3.47

Why is depth-wise convolution less resilient to quantization?

Having uncovered that depth-wise convolutions introduce large accuracy degradation when weights are quantized below 4 bits, in this section, we investigate depth-wise convolutions from a quantization perspective. When comparing depth-wise convolutions and all-to-all convolutions in the context of quantization, they differ in the number of elements to be quantized, *i.e.*, $C\_{in}=1$ for depth-wise convolutions and $C\_{in}>>1$ for all-to-all convolutions.

Why does the number of elements matter? In quantization-aware training, one needs to estimate some statistics of the vector to be quantized (*i.e.*, ${\bm{a}}$ in Equation [1](#S3.E1 "In 3.1 Quantization ‣ 3 Methodology ‣ One Weight Bitwidth to Rule Them All") and $\bar{|{\bm{w}}|}$ in Equations [3](#S3.E3 "In 3.1 Quantization ‣ 3 Methodology ‣ One Weight Bitwidth to Rule Them All"),[4](#S3.E4 "In 3.1 Quantization ‣ 3 Methodology ‣ One Weight Bitwidth to Rule Them All")) based on the elements in the vector. The number of elements affect the robustness of the estimate that further decides the quantized weights. More formally, we provide the following proposition.

###### Proposition 1

Let ${\bm{w}}\in\mathbb{R}^{d}$ be the weight vector to be quantized where ${\bm{w}}\_{i}$ is characterized by normal distribution $\mathcal{N}(0,\sigma^{2})~\forall~i$ without assuming samples are drawn independently and $d=C\_{in}K\_{w}K\_{h}$. If the average correlation of the weights is denoted by $\rho$, the variance of $\bar{|{\bm{w}}|}$ can be written as follows:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}\mathrm{Var}(\bar{|{\bm{w}}|})=\frac{\sigma^{2}}{d}+\frac{(d-1)\rho\sigma^{2}}{d}-\frac{2\sigma^{2}}{\pi}.\end{split}$ |  | (7) |

The proof is in Appendix [0.C](#Pt0.A3 "Appendix 0.C Proof for Proposition 5.1 ‣ One Weight Bitwidth to Rule Them All"). This proposition states that, as the number of elements ($d$) increases, the variance of the estimate can be reduced (due to the first term in equation ([7](#S4.E7 "In Proposition 1 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"))). The second term depends on the correlation between weights. Since the weights might not be independent during training, the variance is also affected by their correlations.

Figure 5: The average estimate $\mathrm{Var}(\bar{|{\bm{w}}|})$ for each depth-wise convolution under different $d=(C\_{in}\times K\_{w}\times K\_{h}$) values.

We empirically validate Proposition [1](#Thmproposition1 "Proposition 1 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All") by looking into the sample variance of $\bar{|{\bm{w}}|}$ across the course of training55
5
We treat the calculated $\bar{|{\bm{w}}|}$ at each training step as a sample and calculate the sample variance across training steps. for different $d$ values by increasing $(K\_{w},K\_{h})$ or $C\_{in}$. Specifically, we consider the $0.5\times$ VGG variant C and change the number of elements of the depth-wise convolutions. Let $d=(C\_{in}\times K\_{w}\times K\_{h})$ for a convolutional layer, we consider the original depth-wise convolution, *i.e.*, $d=1\times 3\times 3$ and increased channels with $d=4\times 3\times 3$ and $d=16\times 3\times 3$, and increased kernel size with $d=1\times 6\times 6$ and $d=1\times 12\times 12$. The numbers are selected such that increasing the channel count results in the same $d$ compared to increasing the kernel sizes. We note that when the channel count ($C\_{in}$) is increased, it is no longer a depth-wise convolution, but rather a group convolution.

In Fig. [5](#S4.F5 "Figure 5 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), we analyze layer-level sample variance by averaging the kernel-level sample variance in the same layer. First, we observe that results align with Proposition [1](#Thmproposition1 "Proposition 1 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"). That is, one can reduce the variance of the estimate by increasing the number of elements along both the channel ($C\_{in}$) and kernel size dimensions ($K\_{w},K\_{h}$). Second, we find that increasing the number of channels ($C\_{in}$) is more effective in reducing the variance than increasing kernel size ($K\_{w},K\_{h}$), which could be due to the weight correlation, *i.e.*, intra-channel weights have larger correlation than inter-channel weights.

Figure 6: $d$ negatively correlates with the variance and positively correlates with the accuracy difference induced by quantization $\Delta Acc\_{Q}=Acc\_{1bit}-Acc\_{4bit}$.

Nonetheless, while lower variance suggests a more stable value during training, it might not necessarily imply lower quantization error for the quantized models. Thus, we conduct an accuracy sensitivity analysis with respect to quantization for different $d$ values. More specifically, we want to understand how $d$ affects the accuracy difference between lower bitwidth (1 bit) and higher bitwidth (4 bits) models ($\Delta Acc\_{Q}$). As shown in Fig. [6](#S4.F6 "Figure 6 ‣ 4.3 ConvNet architectures and quantization ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), we empirically find that $d$ positively correlates with $\Delta Acc\_{Q}$, i.e., the larger the $d$, the smaller the accuracy degradation is. On the other hand, when comparing channel counts and kernel sizes, we observe that increasing the number of channels is more effective than increasing the kernel size in reducing accuracy degradation caused by quantization. This analysis sheds light on the two different trends observed in Fig. [1](#S4.F1 "Figure 1 ‣ 4.2 bitwidth comparisons ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All").

### 4.4 Remarks and scaling up to ImageNet

We have two intriguing findings so far. First, there exists some bitwidth that is better than others across model sizes when compared under a given model size. Second, the optimal bitwidth is architecture-dependent. More specifically, the optimal weight bitwidth negatively correlates with the fan-in channel counts per convolutional kernel. These findings show promising results for the hardware and software researchers to support only a certain set of bitwidths when it comes to parameter-efficiency. For example, use binary weights for networks with all-to-all convolutions.

Next, we scale up our analysis to the ImageNet dataset. Specifically, we study ResNet50 and MobileNetV2 on the ImageNet dataset. Since we keep the bitwidth of the first and last layer quantized at 8 bits, scaling them in terms of width will grow the number of parameters much more quickly than other layers. As a result, we keep the number of channels for the first and last channel fixed for the ImageNet experiments. As demonstrated in Section [4.2](#S4.SS2 "4.2 bitwidth comparisons ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), the bit ordering is consistent across model sizes, we conduct our analysis for ResNet50 and MobileNetV2 by scaling them down with a width-multiplier of $0.25\times$ for computational considerations. The choices of bitwidths are limited to $\{1,2,4,8\}$.

Table 2: bitwidth ordering for MobileNetV2 and ResNet50 with *the model size aligned to the $0.25\times$ 8 bits models* on ImageNet. Each cell reports the top-1 accuracy of the corresponding model. The trend for the optimal bitwidth is similar to that of CIFAR-100 (4 bit for MobileNetV2 and 1 bit for ResNet).

Weight bitwidth for
MobileNetV2
ResNet50

Convs $\backslash$ DWConvs
8 bits
4 bits
2 bits
1 bit
None

8 bits
52.17
53.89
50.51
48.78
71.11

4 bits
56.84
59.51
57.37
55.91
74.65

2 bits
53.89
57.10
55.26
54.04
75.12

1 bit
54.82
58.16
56.90
55.82
75.44

As shown in Table [2](#S4.T2 "Table 2 ‣ 4.4 Remarks and scaling up to ImageNet ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), we can observe a trend similar to the CIFAR-100 experiments, *i.e.*, for networks without depth-wise convolutions, the lower weight bitwidths the better, and for networks with depth-wise convolutions, there are sweet spots for depth-wise and other convolutions. Specifically, the final weight bitwidth selected for MobileNetV2 is 4 bits for both depth-wise and standard convolutions. On the other hand, the selected weight bitwidth for ResNet50 is 1 bit. If bit ordering is indeed consistent across model sizes, these results suggest that the optimal bitwidth for MobileNetV2 is 4 bit and it is 1 bit for ResNet50. However, throughout our analysis, we have not considered mixed-precision, which makes it unclear if the so-called optimal bitwidth (4 bit for MobileNetV2 and 1 bit for ResNet-50) is still optimal when compared to mixed-precision quantization.

As a result, we further compare with mixed-precision quantization that uses reinforcement learning to find the layer-wise bitwidth [[29](#bib.bib29)]. Specifically, we follow [[29](#bib.bib29)] and use a reinforcement learning approach to search for the lowest bitwidths without accuracy degradation (compared to the 8 bits fixed point models). To compare the searched model with other alternatives, we use width-multipliers on top of the searched network match the model size of the 8 bit quantized model. We consider networks of three sizes, *i.e.*, the size of $1\times,0.5\times$ and $0.25\times$ 8-bit fixed point models. As shown in Table [3](#S4.T3 "Table 3 ‣ 4.4 Remarks and scaling up to ImageNet ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), we find that a single bitwidth (selected via Table [2](#S4.T2 "Table 2 ‣ 4.4 Remarks and scaling up to ImageNet ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All")) outperforms both 8 bit quantization and mixed-precision quantization by a significant margin for both networks considered. This results suggest that searching for the bitwidth without accuracy degradation is indeed a sub-optimal strategy and can be improved by incorporating channel counts into the search space and reformulate the optimization problem as maximizing accuracy under storage constraints. Moreover, our results also imply that when the number of channels are allowed to be altered, a single weight bitwidth throughout the network shows great potential for model compression, which has the potential of greatly reducing the software and hardware optimization costs for quantized ConvNets.

Table 3: The optimal bitwidth selected in Table [2](#S4.T2 "Table 2 ‣ 4.4 Remarks and scaling up to ImageNet ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All") is indeed better than 8 bit when scaled to larger model sizes and more surprisingly, it is better than mixed-precision quantization. All the activations are quantized to 8 bits.

Width-multiplier for 8-bit model
$1\times$
$0.5\times$
$0.25\times$

Networks
Methods
Top-1 (%)
$\mathcal{C}\_{size}~(10^{6})$
Top-1 (%)
$\mathcal{C}\_{size}~(10^{6})$
Top-1 (%)
$\mathcal{C}\_{size}~(10^{6})$

ResNet50
Floating-point
76.71
816.72
74.71
411.48
71.27
255.4

8 bits
76.70
204.18
74.86
102.87
71.11
63.85

Flexible [[29](#bib.bib29)]
77.23
204.18
76.04
102.90
74.30
63.60

Optimal (1 bit)
77.58
204.08
76.70
102.83
75.44
63.13

MobileNetV2
Floating-point
71.78
110.00
63.96
61.76
52.79
47.96

8 bits
71.73
27.50
64.39
15.44
52.17
11.99

Flexible [[29](#bib.bib29)]
72.13
27.71
65.00
15.54
55.20
12.10

Optimal (4 bit)
73.91
27.56
68.01
15.53
59.51
12.15

## 5 Conclusion

In this work, we provide the first attempt to understand the ordering between different weight bitwidths by allowing the channel counts of the considered networks to vary using the width-multiplier. If there exists such an ordering, it may be helpful to focus on software/hardware support for higher-ranked bitwidth when it comes to parameter-efficiency, which in turn reduces software/hardware optimization costs. To this end, we have three surprising findings: (1) there exists a weight bitwidth that is better than others across model sizes under a given model size constraint, (2) the optimal weight bitwidth of a convolutional layer negatively correlates to the fan-in channel counts per convolutional kernel, and (3) with a single weight bitwidth for the whole network, one can find configurations that outperform layer-wise mixed-precision quantization using reinforcement learning when compared under a given same model size constraint. Our results suggest that when the number of channels are allowed to be altered, a single weight bitwidth throughout the network shows great potential for model compression.

## Acknowledgement

This research was supported in part by NSF CCF Grant No. 1815899, NSF CSR Grant No. 1815780, and NSF ACI Grant No. 1445606 at the Pittsburgh Supercomputing Center (PSC).

## Appendix 0.A Clipping Point for Quantization-aware Training

As mentioned earlier, ${\bm{a}}\in\mathbb{R}^{C\_{out}}$ denotes the vector of clipping factors which is selected to minimize $\lVert Q({\bm{W}}\_{i,:})-{\bm{W}}\_{i,:}\rVert^{2}\_{2}$ by assuming ${\bm{W}}\_{i,:}~\sim\mathcal{N}(0,\sigma^{2}{\bm{I}})$. More specifically, we run simulations for weights drawn from a zero-mean Gaussian distribution with several variances and identify the best ${a}\_{i}^{\*}=\arg\min\_{{a}\_{i}}\lVert Q\_{{a}\_{i}}({\bm{W}}\_{i,:})-{\bm{W}}\_{i,:}\rVert^{2}\_{2}$ empirically. According to our simulation, we find that one can infer ${a}\_{i}$ from the sample mean $\bar{|{\bm{W}}\_{i,:}|}$, which is shown in Fig. [7](#Pt0.A1.F7 "Figure 7 ‣ Appendix 0.A Clipping Point for Quantization-aware Training ‣ One Weight Bitwidth to Rule Them All"). As a result, for the different precision values considered, we find $c=\frac{\bar{|{\bm{W}}\_{i,:}|}}{{a}\_{i}^{\*}}$ via simulation and use the obtained $c$ to calculate ${a}\_{i}$ on-the-fly throughout training.

Figure 7: Finding best ${a}\_{i}$ for different precision values empirically through simulation using Gaussian with various $\sigma^{2}$.

## Appendix 0.B Network Architectures

For the experiments in Section [4.2](#S4.SS2 "4.2 bitwidth comparisons ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), the ResNets used are detailed in Table [4](#Pt0.A2.T4 "Table 4 ‣ Appendix 0.B Network Architectures ‣ One Weight Bitwidth to Rule Them All"). Specifically, for the points in Fig. [1(a)](#S4.F1.sf1 "In Figure 1 ‣ 4.2 bitwidth comparisons ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All"), we consider ResNet20 to ResNet56 with width-multipliers of $0.5\times,1\times,1.5\times$, and $2\times$ for the 4-bit case. Based on these values, we consider additional width-multipliers $2.4\times$ and $2.8\times$ for the 2-bit case and $2.5\times,3\times,3.5\times,$ and $3.9\times$ for the 1-bit case. We note that the right-most points in Fig. [1(a)](#S4.F1.sf1 "In Figure 1 ‣ 4.2 bitwidth comparisons ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All") is a $10\times$ ResNet26 for the 4 bits case. On the other hand, VGG11 is detailed in Table [6](#Pt0.A2.T6 "Table 6 ‣ Appendix 0.B Network Architectures ‣ One Weight Bitwidth to Rule Them All") for which we consider width-multipliers from $0.25\times$ to $2\times$ with a step of $0.25$ for the 4 bits case (blue dots in Fig. [1(b)](#S4.F1.sf2 "In Figure 1 ‣ 4.2 bitwidth comparisons ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All")). The architecture of MobileNetV2 used in the CIFAR-100 experiments follows the original MobileNetV2 (Table 2 in [[22](#bib.bib22)]) but we change the stride of all the bottleneck blocks to 1 except for the fifth bottleneck block, which has a stride of 2. As a result, we down-sample the image twice in total, which resembles the ResNet design for the CIFAR experiments [[8](#bib.bib8)]. Similar to VGG11, we consider width-multipliers from $0.25\times$ to $2\times$ with a step of $0.25$ for MobileNetV2 for the 4 bits case (blue dots in Fig. [1(c)](#S4.F1.sf3 "In Figure 1 ‣ 4.2 bitwidth comparisons ‣ 4 Experiments ‣ One Weight Bitwidth to Rule Them All")).

Table 4: ResNet20 to ResNet56

Layers
20
26
32
38
44
50
56

Stem
$\text{Conv2d (16,3,3)}\text{ Stride }1$

Stage 1
$3\times\begin{cases}\text{Conv2d}(16,3,3)\text{ Stride }1\\
\text{Conv2d}(16,3,3)\text{ Stride }1\end{cases}$
$4\times$
$5\times$
$6\times$
$7\times$
$8\times$
$9\times$

Stage 2
$3\times\begin{cases}\text{Conv2d}(32,3,3)\text{ Stride }2\\
\text{Conv2d}(32,3,3)\text{ Stride }1\end{cases}$
$4\times$
$5\times$
$6\times$
$7\times$
$8\times$
$9\times$

Stage 3
$3\times\begin{cases}\text{Conv2d}(64,3,3)\text{ Stride }2\\
\text{Conv2d}(64,3,3)\text{ Stride }1\end{cases}$
$4\times$
$5\times$
$6\times$
$7\times$
$8\times$
$9\times$

Table 5: Inv-ResNet26

Stem
$\text{Conv2d (16,3,3)}\text{ Stride }1$

Stage 1
$4\times\begin{cases}\text{Conv2d}(16\times 6,1,1)\text{ Stride }1\\
\text{DWConv2d}(16\times 6,3,3)\text{ Stride }1\\
\text{Conv2d}(16,1,1)\text{ Stride }1\end{cases}$

Stage 2
$4\times\begin{cases}\text{Conv2d}(32\times 6,1,1)\text{ Stride }1\\
\text{DWConv2d}(32\times 6,3,3)\text{ Stride }2\\
\text{Conv2d}(32,1,1)\text{ Stride }1\end{cases}$

Stage 3
$4\times\begin{cases}\text{Conv2d}(64\times 6,1,1)\text{ Stride }1\\
\text{DWConv2d}(64\times 6,3,3)\text{ Stride }2\\
\text{Conv2d}(64,1,1)\text{ Stride }1\end{cases}$

Table 6: VGGs

VGG11
Variant A
Variant B
Variant C

Conv2d (64,3,3)

MaxPooling

Conv2d (128,3,3)
$\begin{cases}\text{Conv2d}(128,1,1)\\
\text{DWConv2d}(128,3,3)\end{cases}$
$\begin{cases}\text{Conv2d}(128,1,1)\\
\text{DWConv2d}(128,3,3)\end{cases}$
$\begin{cases}\text{Conv2d}(128,1,1)\\
\text{DWConv2d}(128,3,3)\end{cases}$

MaxPooling

Conv2d (256,3,3)
Conv2d (256,3,3)
$\begin{cases}\text{Conv2d}(256,1,1)\\
\text{DWConv2d}(256,3,3)\end{cases}$
$\begin{cases}\text{Conv2d}(256,1,1)\\
\text{DWConv2d}(256,3,3)\end{cases}$

Conv2d (256,3,3)
Conv2d (256,3,3)
$\begin{cases}\text{Conv2d}(256,1,1)\\
\text{DWConv2d}(256,3,3)\end{cases}$
$\begin{cases}\text{Conv2d}(256,1,1)\\
\text{DWConv2d}(256,3,3)\end{cases}$

MaxPooling

Conv2d (512,3,3)
Conv2d (512,3,3)
$\begin{cases}\text{Conv2d}(512,1,1)\\
\text{DWConv2d}(512,3,3)\end{cases}$
$\begin{cases}\text{Conv2d}(512,1,1)\\
\text{DWConv2d}(512,3,3)\end{cases}$

Conv2d (512,3,3)
Conv2d (512,3,3)
Conv2d (512,3,3)
$\begin{cases}\text{Conv2d}(512,1,1)\\
\text{DWConv2d}(512,3,3)\end{cases}$

MaxPooling

Conv2d (512,3,3)
Conv2d (512,3,3)
Conv2d (512,3,3)
$\begin{cases}\text{Conv2d}(512,1,1)\\
\text{DWConv2d}(512,3,3)\end{cases}$

Conv2d (512,3,3)
Conv2d (512,3,3)
Conv2d (512,3,3)
$\begin{cases}\text{Conv2d}(512,1,1)\\
\text{DWConv2d}(512,3,3)\end{cases}$

MaxPooling

## Appendix 0.C Proof for Proposition 5.1

Based on the definition of variance, we have:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathrm{Var}(\frac{1}{d}\sum\_{i=1}^{d}|{\bm{w}}\_{i}|)$ | $\displaystyle:=\mathbb{E}\left[\left(\frac{1}{d}\sum\_{i=1}^{d}|{\bm{w}}\_{i}|\right)^{2}-\left(\mathbb{E}\frac{1}{d}\sum\_{i=1}^{d}|{\bm{w}}\_{i}|\right)^{2}\right]$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\mathbb{E}\left[\left(\frac{1}{d}\sum\_{i=1}^{d}|{\bm{w}}\_{i}|\right)^{2}-\frac{2\sigma^{2}}{\pi}\right]$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\frac{1}{d^{2}}\mathbb{E}\left(\sum\_{i=1}^{d}|{\bm{w}}\_{i}|\right)^{2}-\frac{2\sigma^{2}}{\pi}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\frac{\sigma^{2}}{d}+\frac{d-1}{d}\rho\sigma^{2}-\frac{2\sigma^{2}}{\pi}.$ |  |
