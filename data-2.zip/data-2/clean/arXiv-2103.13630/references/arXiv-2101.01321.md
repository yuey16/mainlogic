<!-- fulltext source=arxiv_html slug=arXiv-2101.01321 fetched=2026-09-21T06:45:42+00:00 -->

# I-BERT: Integer-only BERT Quantization

Sehoon Kim
Affiliation: University of California, Berkeley
Correspondence to: [sehoonkim@berkeley.edu](mailto:sehoonkim@berkeley.edu)
  
Amir Gholami
Affiliation: University of California, Berkeley
Correspondence to: [amirgh@berkeley.edu](mailto:amirgh@berkeley.edu)
  
Zhewei Yao
Affiliation: University of California, Berkeley
Correspondence to: [zheweiy@berkeley.edu](mailto:zheweiy@berkeley.edu)
  
Michael W. Mahoney
Affiliation: University of California, Berkeley
Correspondence to: [mahoneymw@berkeley.edu](mailto:mahoneymw@berkeley.edu)
  
Kurt Keutzer
Affiliation: University of California, Berkeley
Correspondence to: [keutzer@berkeley.edu](mailto:keutzer@berkeley.edu)

###### Abstract

Transformer based models, like BERT and RoBERTa, have achieved state-of-the-art results in many Natural Language Processing tasks.
However, their memory footprint, inference latency, and power consumption are prohibitive
for efficient inference at the edge, and even at the data center.
While quantization can be a viable solution for this,
previous work on quantizing Transformer based models use floating-point arithmetic during inference, which cannot efficiently utilize integer-only logical units
such as the recent Turing Tensor Cores, or traditional integer-only ARM processors.
In this work, we propose I-BERT, a novel quantization scheme for Transformer based
models that quantizes the entire inference with integer-only arithmetic.
Based on lightweight integer-only approximation methods for nonlinear operations, e.g., GELU, Softmax, and Layer Normalization, I-BERT performs an end-to-end integer-only BERT inference without any floating point calculation.
We evaluate our approach on GLUE downstream tasks using RoBERTa-Base/Large.
We show that for both cases, I-BERT achieves similar (and slightly higher) accuracy as compared to the full-precision baseline.
Furthermore, our preliminary implementation of I-BERT shows a speedup of $2.4-4.0\times$ for INT8 inference on a T4 GPU system as compared to FP32 inference.
The framework has been developed in PyTorch and has been open-sourced [[36](#bib.bib36)].

###### Keywords:

Machine Learning, ICML

††affiliationnotice: Equal contribution

## 1 Introduction

The recent Transformer based Neural Network (NN) models [[79](#bib.bib79)], pre-trained from large unlabeled data (e.g., BERT [[15](#bib.bib15)], RoBERTa [[46](#bib.bib46)], and the GPT family [[57](#bib.bib57), [58](#bib.bib58), [5](#bib.bib5)]), have achieved a significant accuracy improvement
when fine-tuned on a wide range of Natural Language Processing (NLP) tasks
such as sentence classification [[80](#bib.bib80)] and question answering [[61](#bib.bib61)].
Despite the state-of-the-art results in various NLP tasks, pre-trained Transformer models are
generally orders of magnitude larger than prior models.
For example, the BERT-Large model [[15](#bib.bib15)] contains 340M parameters.
Much larger Transformer models have been introduced in the past few years, with even more parameters [[58](#bib.bib58), [5](#bib.bib5), [70](#bib.bib70), [64](#bib.bib64), [90](#bib.bib90), [42](#bib.bib42), [59](#bib.bib59)].
Efficient deployment of these models has become a major challenge, even in data centers, due to limited resources (energy, memory footprint, and compute) and the need for real-time inference.
Obviously, these challenges are greater for edge devices, where the compute and energy
resources are more constrained.

One promising method to tackle this challenge is quantization [[37](#bib.bib37), [18](#bib.bib18), [86](#bib.bib86), [94](#bib.bib94), [87](#bib.bib87), [33](#bib.bib33)],
a procedure which compresses NN models into smaller size by representing parameters and/or activations with low bit precision, e.g., 8-bit integer (INT8) instead of 32-bit floating point (FP32).
Quantization reduces memory footprint by storing parameters/activations in low precision.
With the recent integer-only quantization methods, one can also benefit from faster inference speed by using
low precision integer multiplication and accumulation, instead of floating point arithmetic.
However, previous quantization schemes for Transformer based models use simulated quantization (aka fake quantization),
where all or part of operations in the inference (e.g., GELU [[27](#bib.bib27)], Softmax, and Layer Normalization [[2](#bib.bib2)]) are carried out with floating point arithmetic [[69](#bib.bib69), [93](#bib.bib93), [4](#bib.bib4)].
This approach has multiple drawbacks for deployment in real edge application scenarios.
Most importantly, the resulting NN models cannot be deployed on neural accelerators or popular edge processors that do not support floating point arithmetic.
For instance, the recent server class of Turing Tensor Cores have added
high throughput integer logic that are faster than single/half-precision.
Similarly,
some of the edge processor cores in ARM Cortex-M [[1](#bib.bib1)] family for embedded systems only contain integer arithmetic units, and they can only support NN deployment with the integer-only kernels [[39](#bib.bib39)].
Moreover, one has to consider that compared to the integer-only inference, the approaches that use floating point arithmetic are inferior in latency and power efficiency.
For chip designers wishing to support BERT-like models, adding floating point arithmetic logic occupies larger die area on a chip, as compared to integer arithmetic logic.
Thus, the complete removal of floating point arithmetic for inference could have a major impact on designing applications, software, and hardware for efficient inference at the edge [[1](#bib.bib1)].

While prior work has shown the feasibility of integer-only inference [[33](#bib.bib33), [91](#bib.bib91)], these approaches have only
focused on models in computer vision with simple CNN layers, Batch Normalization (BatchNorm) [[31](#bib.bib31)], and ReLU activations.
These are all linear or piece-wise linear operators.
Due to the non-linear operations used in Transformer architecture, e.g., GELU, Softmax, and Layer Normalization (LayerNorm), these methods cannot be applied to Transformer based models.
Unlike ReLU, computing GELU and Softmax with integer-only arithmetic is not straightforward, due to their non-linearity.
Furthermore, unlike BatchNorm whose parameters/statistics can be fused into the previous convolutional layer in inference,
LayerNorm requires the dynamic computation of the square root of the variance for each input.
This cannot be naïvely computed with integer-only arithmetic.
Another challenge is that processing
GELU, Softmax, and LayerNorm with low precision can result in signifciant accuracy degradation [[93](#bib.bib93), [4](#bib.bib4)].
For these reasons, other quantization methods such as [[93](#bib.bib93), [69](#bib.bib69), [4](#bib.bib4)] keep these operations in FP32 precision.

In this work, we propose I-BERT to address these challenges.
I-BERT incorporates a series of novel integer-only quantization scheme for Transformer based models.
Specifically, our contributions are:

* •

  We propose new kernels for the efficient and accurate integer-only computation of GELU and Softmax.
  In particular, we approximate GELU and Softmax with light-weight second-order polynomials, which can
  be evaluated with integer-only arithmetic.
  We utilize different techniques to improve the approximation error, and achieve
  a maximum error of $1.8\times 10^{-2}$ for GELU, and $1.9\times 10^{-3}$ for Softmax.
  See § [3.4](#S3.SS4 "3.4 Integer-only GELU ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization") and [3.5](#S3.SS5 "3.5 Integer-only Softmax ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization") for details.
* •

  For LayerNorm, we perform integer-only computation by leveraging a known algorithm for integer calculation of square root [[11](#bib.bib11)].
  See § [3.6](#S3.SS6 "3.6 Integer-only LayerNorm ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization") for details.
* •

  We use these approximations of GELU, Softmax, and LayerNorm to design integer-only quantization for Transformer based models.
  Specifically, we process Embedding and matrix multiplication (MatMul) with INT8 multiplication
  and INT32 accumulation. The following non-linear operations (GELU, Softmax, and LayerNorm)
  are then calculated on the INT32 accumulated result and then requantized back to INT8.
  We represent all parameters and activations in the entire computational graph with integers, and we never cast them into floating point.
  See  Fig. [1](#S2.F1 "Figure 1 ‣ 2 Related Work ‣ I-BERT: Integer-only BERT Quantization") (right) for a schematic description.
* •

  We apply I-BERT to RoBERTa-Base/Large, and we evaluate their accuracy on the GLUE [[80](#bib.bib80)] downstream tasks.
  I-BERT achieves similar results as compared to full-precision baseline. Specifically, I-BERT outperforms the baseline by 0.3 and 0.5 on the GLUE downstream tasks for RoBERTa-Base and RoBERTa-Large, respectively.
  See Tab. [2](#S4.T2 "Table 2 ‣ 4 Results ‣ I-BERT: Integer-only BERT Quantization") in § [4.1](#S4.SS1 "4.1 Accuracy Evaluation on GLUE ‣ 4 Results ‣ I-BERT: Integer-only BERT Quantization") for details.
* •

  We deploy INT8 BERT models with the integer-only kernels for non-linear operations on a T4 GPU using TensorRT [[53](#bib.bib53)].
  We show that INT8 inference achieves up to 4$\times$ speedup as compared to FP32 inference.
  See Tab. [3](#S4.T3 "Table 3 ‣ 4.2 Latency Evaluation ‣ 4 Results ‣ I-BERT: Integer-only BERT Quantization") in § [4.2](#S4.SS2 "4.2 Latency Evaluation ‣ 4 Results ‣ I-BERT: Integer-only BERT Quantization") for details.

## 2 Related Work

Efficient Neural Network.
There are several different approaches
to reduce the memory footprint, latency, and power of modern NN
architectures.
These techniques can be broadly categorized into:
(1) pruning [[25](#bib.bib25), [45](#bib.bib45), [47](#bib.bib47), [41](#bib.bib41), [51](#bib.bib51), [89](#bib.bib89), [49](#bib.bib49), [20](#bib.bib20), [23](#bib.bib23), [60](#bib.bib60), [48](#bib.bib48), [67](#bib.bib67)];
(2) knowledge distillation [[28](#bib.bib28), [50](#bib.bib50), [56](#bib.bib56), [63](#bib.bib63), [66](#bib.bib66), [73](#bib.bib73), [34](#bib.bib34), [76](#bib.bib76), [78](#bib.bib78), [74](#bib.bib74), [82](#bib.bib82), [88](#bib.bib88)];
(3) efficient neural architecture design [[30](#bib.bib30), [65](#bib.bib65), [75](#bib.bib75), [29](#bib.bib29), [40](#bib.bib40), [13](#bib.bib13)];
(4) hardware-aware NN co-design [[24](#bib.bib24), [22](#bib.bib22), [38](#bib.bib38)]; and
(5) quantization.

Here, we only focus on quantization and briefly discuss the related work.

Figure 1: Comparison of different quantization schemes applied to the self-attention layer in the Transformer architecture.
(Left) Simulated quantization, where all operations are performed with floating point arithmetic.
Parameters are quantized and stored as integer, but they are dequantized into floating point for inference.
(Middle) Simulated quantization, where only a part of operations are performed with integer arithmetic.
Because the Softmax in this figure is performed with floating point arithmetic, the input to the Softmax should be dequantized; and the output from the Softmax should be quantized back into integer to perform the subsequent integer MatMul.
(Right) The integer-only quantization that we propose.
There is neither floating point arithmetic nor dequantization during the entire inference.

Quantization.
For quantization, the parameters and/or activations are represented with low bit precision [[8](#bib.bib8), [9](#bib.bib9), [18](#bib.bib18), [33](#bib.bib33), [62](#bib.bib62), [94](#bib.bib94), [96](#bib.bib96), [44](#bib.bib44), [87](#bib.bib87), [10](#bib.bib10), [81](#bib.bib81)].
While this line of research mostly focuses on CNN models, there have been recent attempts to introduce quantization techniques into Transformer based models as well.
For example, [[4](#bib.bib4)] and [[93](#bib.bib93)] propose an 8-bit quantization scheme for Transformer based models and compress the model size up to 25% of the original size.
Another work [[69](#bib.bib69)] applies uniform and mixed-precision to quantize BERT model,
where a second-order sensitivity method is used for the mixed-precision setting.
[[21](#bib.bib21)] quantizes a different subset of weights in each training iteration to make models more robust to quantization.
Recently, there have been attempts to quantize BERT with even lower precision.
[[92](#bib.bib92)] presents a 3/4-bit centroid-based quantization method that does not require fine-tuning.
[[95](#bib.bib95), [3](#bib.bib3)] leverage knowledge distillation [[28](#bib.bib28)] to ternarize/binarize weights.
[[35](#bib.bib35)] combines knowledge distillation and learned step size quantization [[19](#bib.bib19)] method to achieve up to 2-bit quantization of BERT.

However, to the best of our knowledge, all of the prior quantization work on Transformer based models use simulated quantization (aka fake quantization), where all or part of operations are performed with floating point arithmetic.
This requires the quantized parameters and/or activations to be dequantized back to FP32 for the floating point operations.
For example, [[69](#bib.bib69), [92](#bib.bib92)] perform the entire inference using floating point arithmetic, as schematically shown in Fig. [1](#S2.F1 "Figure 1 ‣ 2 Related Work ‣ I-BERT: Integer-only BERT Quantization") (left).
While [[4](#bib.bib4), [93](#bib.bib93), [95](#bib.bib95), [3](#bib.bib3)] attempt to process Embedding and MatMul efficiently with integer arithmetic, they keep the remaining operations (i.e., GELU, Softmax, and LayerNorm) in FP32, as illustrated in Fig. [1](#S2.F1 "Figure 1 ‣ 2 Related Work ‣ I-BERT: Integer-only BERT Quantization") (middle).
However, our method I-BERT uses integer-only quantization for the entire inference process—i.e., without any floating point arithmetic and without any dequantization during the entire inference.
This is illustrated in Fig. [1](#S2.F1 "Figure 1 ‣ 2 Related Work ‣ I-BERT: Integer-only BERT Quantization") (right).
This allows more efficient hardware deployment on specialized accelerators or integer-only processors [[1](#bib.bib1)] as well as faster and less energy consuming inference.
While we focus on uniform quantization, our method is complementary to other mixed and/or low-precision methods, and can be deployed for those settings as well.

To briefly discuss, there are also several quantization works for computer vision.
[[33](#bib.bib33)] introduces an integer-only quantization scheme for popular CNN models,
by replacing all floating point operations (e.g., convolution, MatMul, and ReLU) with integer operations.
Similarly, the recent work of [[91](#bib.bib91)] extends this approach to low precision and mixed precision dyadic quantization, which is an extension of integer-only quantization where no integer division is used.
However, both of these works are limited to CNN models that only contain linear and piece-wise linear operators, and they cannot be applied to Transformer based models with non-linear operators, e.g., GELU, Softmax, and LayerNorm.
Our work aims to address this limitation by extending the integer-only scheme to the Transformer based models without accuracy drop.

## 3 Methodology

### 3.1 Basic Quantization Method

Under uniform symmetric quantization scheme, a real number $x$ is
uniformly mapped to an integer value $q\in[-2^{b-1},2^{b-1}-1]$, where
$b$ specifies the quantization bit precision.
The formal definition is:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small q=\mathrm{Q}(x,b,S)=\mathrm{Int}\bigg(\frac{\mathrm{clip}(x,-\alpha,\alpha)}{S}\bigg),$ |  | (1) |

where $\mathrm{Q}$ is the quantization operator, $\mathrm{Int}$ is the integer map (e.g., round to the nearest integer), $\mathrm{clip}$ is the truncation function, $\alpha$ is the
clipping parameter used to control the outliers, and $S$ is the scaling factor defined as $\alpha/(2^{b-1}-1)$.
The reverse mapping from the quantized values $q$ to the real values (aka dequantization) is:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\tilde{x}=\mathrm{DQ}(q,S)=Sq\approx x,$ |  | (2) |

where $\mathrm{DQ}$ denotes the dequantization operator.
This approach is referred to as uniform symmetric quantization.
It is uniform because the spacing between quantized values and their corresponding mapping to real
values is constant. However, several different non-uniform quantization methods have also been proposed [[87](#bib.bib87), [94](#bib.bib94), [8](#bib.bib8), [55](#bib.bib55)].
While non-uniform quantization approaches may better capture the distribution of parameters/activations than uniform quantization, they are in general difficult to deploy on hardware (as they often require a look up table which results in overhead).
Thus, we focus only on uniform quantization in this work.
In addition, this approach is symmetric because we clip the values symmetrically within a range $[-\alpha,\alpha]$;
while in asymmetric quantization, the left and right side of this range could be asymmetric/different.
Finally, we use static quantization where all the scaling factors $S$ are fixed during inference to avoid runtime overhead of computing them.
See § [A](#A1 "Appendix A Quantization Methods ‣ I-BERT: Integer-only BERT Quantization") for more details in quantization methods.

### 3.2 Non-linear Functions with Integer-only Arithmetic

The key to integer-only quantization is to perform all operations with integer arithmetic without using any floating point calculation.
Unlike linear (e.g., MatMul) or piece-wise linear operations (e.g., ReLU), this is not straightforward for non-linear operations (e.g., GELU, Softmax, and LayerNorm).
This is because the integer-only quantization algorithms in previous works [[91](#bib.bib91), [33](#bib.bib33)] rely on the linear property of the operator.
For example, $\mathrm{MatMul}(Sq)$ is equivalent to $S\cdot\mathrm{MatMul}(q)$
for the linear MatMul operation.
This property allows us to apply integer MatMul to the quantized input $q$ and then multiply the scaling factor $S$ to obtain the same result as applying floating point MatMul to the dequantized input $Sq$.
Importantly, this property *does not* hold for non-linear operations, e.g., $\mathrm{GELU}(Sq)\not=S\cdot\mathrm{GELU}(q)$.
One naïve solution is to compute the results of these operations and store them in a look up table [[39](#bib.bib39)].
However, such an approach can have overhead when deployed on chips with limited on-chip memory,
and will create a bottleneck proportional to how fast the look up table could be performed.
Another solution is to dequantize the activations and convert them to floating point, and then compute these non-linear operations with single precision logic [[93](#bib.bib93), [4](#bib.bib4)].
However, this approach is not integer-only and cannot be used on specialized efficient hardware that does not support floating point arithmetic, e.g., ARM Cortex-M [[1](#bib.bib1)].

To address this challenge, we approximate non-linear activation functions, GELU and Softmax, with polynomials that can be computed with integer-only arithmetic.
Computing polynomials consists of only addition and multiplication,
which can be performed with integer arithmetic.
As such, if we can find good polynomial approximations to these operations, then we can perform the entire inference with integer-only
arithmetic.
For instance, a second-order polynomial represented as $a(x+b)^{2}+c$ can be efficiently calculated with integer-only arithmetic as shown in Alg. [1](#alg1 "Algorithm 1 ‣ 3.2 Non-linear Functions with Integer-only Arithmetic ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization").11
1
In Alg. [1](#alg1 "Algorithm 1 ‣ 3.2 Non-linear Functions with Integer-only Arithmetic ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization"), $\lfloor\cdot\rfloor$ means the floor function. Note that, $q\_{b}$, $q\_{c}$, and $S\_{out}$ can be pre-computed under static quantization. That is to say, there is no floating point calculation, e.g., of $S/b$, in inference.

Algorithm 1  Integer-only Computation of Second-order Polynomial $a(x+b)^{2}+c$

```
 Input: q,Sq,S: quantized input and scaling factor

 Output: qo​u​t,So​u​tq_{out},S_{out}: quantized output and scaling factor

 function I-Poly(q,S)(q,S)
⊳\triangleright q​S=xqS=x

  qb←⌊b/S⌋q_{b}\leftarrow\lfloor b/S\rfloor

  qc←⌊c/a​S2⌋q_{c}\leftarrow\lfloor c/aS^{2}\rfloor

  So​u​t←⌊a​S2⌋S_{out}\leftarrow\lfloor aS^{2}\rfloor

  qo​u​t←(q+qb)2+qcq_{out}\leftarrow(q+q_{b})^{2}+q_{c}

  return qo​u​t,So​u​tq_{out},S_{out}
⊳\triangleright
qo​u​t​So​u​t≈a​(x+b)2+cq_{out}S_{out}\approx a(x+b)^{2}+c\kern 4.62497pt

 end function
```

### 3.3 Polynomial Approximation of Non-linear Functions

There is a large body of work on approximating a function with a polynomial [[72](#bib.bib72)].
We use a class of interpolating polynomials, where we are given
the function value for a set of $n+1$ different data points $\{(x\_{0},f\_{0}),\dots,(x\_{n},f\_{n})\}$, and we seek
to find a polynomial of degree at most $n$ that exactly matches the function value at these points.
It is known that there exists a unique polynomial of degree at most $n$ that passes through all the data points [[83](#bib.bib83)].
We denote this polynomial by $L$, defined as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small L(x)=\sum\_{i=0}^{n}f\_{i}l\_{i}(x)\kern 4.62497pt\text{where}\kern 4.62497ptl\_{i}(x)=\prod\_{\begin{subarray}{c}0\leq j\leq n\\ j\neq i\end{subarray}}\frac{x-x\_{j}}{x\_{i}-x\_{j}}.$ |  | (3) |

Interestingly for our problem, we have two knobs to change to find the best polynomial approximation.
Since we know the actual target function and can query its exact value
for any input,
we can choose the interpolating point $(x\_{i},f\_{i})$ to be any point on the function.
The second knob is to choose the degree of the polynomial.
While choosing a high-order polynomial results in smaller error (see Appendix [B](#A2 "Appendix B Error Term of Eq. ‣ I-BERT: Integer-only BERT Quantization")), there are two problems with this.
First, high-order polynomials have higher computational and memory overhead.
Second, it is challenging to evaluate
them with low-precision integer-only arithmetic,
as overflow can happen when multiplying integer values. For every multiplication, we need
to use double bit-precision to avoid overflow.
As such, the challenge is to find a good low-order polynomial that can closely approximate the
non-linear functions used in Transformers.
This is what we discuss next, for GELU and Softmax, in § [3.4](#S3.SS4 "3.4 Integer-only GELU ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization") and [3.5](#S3.SS5 "3.5 Integer-only Softmax ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization"), respectively, where we show that one can
get a close approximation by using only a second-order polynomial.

### 3.4 Integer-only GELU

GELU [[27](#bib.bib27)] is a non-linear activation function used in Transformer models, defined as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\begin{split}\mathrm{GELU}(x)&:=x\cdot\frac{1}{2}\left[1+\mathrm{erf}(\frac{x}{\sqrt{2}})\right],\\ \text{where}\kern 4.62497pt\mathrm{erf}(x)&:=\frac{2}{\sqrt{\pi}}\int\_{0}^{x}\exp{(-t^{2})}dt.\end{split}$ |  | (4) |

Here, $\mathrm{erf}$ is the error function. Figure [2](#S3.F2 "Figure 2 ‣ 3.4 Integer-only GELU ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization") shows the behaviour of the GELU function (shown in red).
GELU has a similar behaviour as ReLU (shown in green) in the limit of large positive/negative values,
but it behaves differently near zero.
Direct evaluation of the integration term in $\mathrm{erf}$ is not computationally efficient.
For this reason, several different approximations have been
proposed for evaluating GELU. For example, [[27](#bib.bib27)] suggests using
Sigmoid to approximate $\mathrm{erf}$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\mathrm{GELU}(x)\approx x\sigma(1.702x),$ |  | (5) |

where $\sigma(\cdot)$ is the Sigmoid function.
This approximation, however, is not a viable solution for integer-only quantization, as the Sigmoid itself is another non-linear function which requires
floating point arithmetic.
One way to address this is to approximate Sigmoid with the so-called
hard Sigmoid (h-Sigmoid) proposed by [[29](#bib.bib29)] (designed in the context of efficient computer vision models) to obtain an integer-only approximation for GELU:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\mathrm{h{\text{-}}GELU}(x):=x\frac{\mathrm{ReLU6}(1.702x+3)}{6}\approx\mathrm{GELU}(x).$ |  | (6) |

We refer to this approximation as h-GELU.
Although h-GELU can be computed with integer arithmetic, we observed that replacing GELU with h-GELU in Transformers results in a significant accuracy drop.
This is due to the large gap between h-GELU and GELU as depicted in Tab. [1](#S3.T1 "Table 1 ‣ 3.4 Integer-only GELU ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization").22
2
Later in our ablation study, we show this can lead to accuracy degradation of up to 2.2 percentages, as reported in Tab. [4](#S4.T4 "Table 4 ‣ 4.3 Ablation Studies ‣ 4 Results ‣ I-BERT: Integer-only BERT Quantization").
Figure [2](#S3.F2 "Figure 2 ‣ 3.4 Integer-only GELU ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization") (left) also shows the noticeable gap between those two functions.

A simple way to address the above problem is to use polynomials to approximate GELU, by solving
the following optimization problem:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\begin{split}&\min\_{a,b,c}\frac{1}{2}\left\|\mathrm{GELU}(x)-x\cdot\frac{1}{2}\left[1+\mathrm{L}(\frac{x}{\sqrt{2}})\right]\right\|\_{2}^{2},\\ &\mathrm{s.t.}\hskip 9.24994ptL(x)=a(x+b)^{2}+c,\end{split}$ |  | (7) |

where $\mathrm{L}(x)$ is a second-order polynomial used to approximate the $\mathrm{erf}$ function.
Directly optimizing Eq. [7](#S3.E7 "In 3.4 Integer-only GELU ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization") results in a poor approximation since the definition domain of $\mathrm{erf}$ contains the entire real numbers.
To address this, we only optimize $L(x)$ in a limited range since $\mathrm{erf}$ approaches to 1 ($-$1) for large values of $x$.
We also take advantage of the fact that $\mathrm{erf}$ is an odd function (i.e., $\mathrm{erf}(-x)=-\mathrm{erf}(x)$), and thus only consider approximating it in the positive
domain.
After finding the best interpolating points, i.e., $(x\_{i},f\_{i})$ in Eq. [3](#S3.E3 "In 3.3 Polynomial Approximation of Non-linear Functions ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization"), and applying these adjustments we arrive at the following polynomial:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\mathrm{L}(x)=\mathrm{sgn}(x)\left[a(\mathrm{clip}(|x|,\max=-b)+b)^{2}+1\right],$ |  | (8) |

where $a=-0.2888$ and $b=-1.769$, and $\mathrm{sgn}$ denotes the sign function.
33
3
Note that $L(x)$ is approximating GELU in the range of $[0,-b]$.
Using this polynomial we arrive at i-GELU, the integer-only approximation for GELU, defined as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\mathrm{i{\text{-}}GELU}(x):=x\cdot\frac{1}{2}\left[1+\mathrm{L}(\frac{x}{\sqrt{2}})\right].$ |  | (9) |

Figure 2: 
(Left) Comparison between RELU, GELU, h-GELU and i-GELU.
(Right) Comparison between exponential (exp) and our integer-only exponential (i-exp).

Algorithm [2](#alg2 "Algorithm 2 ‣ 3.4 Integer-only GELU ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization") summarizes the integer-only computation of GELU using i-GELU.
We illustrate the behaviour of i-GELU in Fig. [2](#S3.F2 "Figure 2 ‣ 3.4 Integer-only GELU ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization") (left). As one
can see, i-GELU closely approximates GELU, particularly around the origin.
We also report the approximation error of i-GELU along with h-GELU
in Tab. [1](#S3.T1 "Table 1 ‣ 3.4 Integer-only GELU ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization"), where i-GELU has an
average error of $8.2\times 10^{-3}$ and a maximum error of $1.8\times 10^{-2}$.
This is $\sim 3\times$ more accurate than h-GELU whose average and maximum errors are $3.1\times 10^{-2}$ and $6.8\times 10^{-2}$, respectively.
Also, i-GELU even slightly outperforms the Sigmoid based approximation of Eq. [5](#S3.E5 "In 3.4 Integer-only GELU ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization"), but without using any floating point
arithmetic.
Note that computing the Sigmoid requires floating point.
Later in the results section, we show that this improved approximation, actually
results in better accuracy of i-GELU as compared to h-GELU (see Tab. [4](#S4.T4 "Table 4 ‣ 4.3 Ablation Studies ‣ 4 Results ‣ I-BERT: Integer-only BERT Quantization")).

Algorithm 2  Integer-only GELU

```
 Input: q,Sq,S: quantized input and scaling factor

 Output: qo​u​t,So​u​tq_{out},S_{out}: quantized output and scaling factor

 function I-Erf(q,S)(q,S)
⊳\triangleright q​S=xqS=x

  a,b,c←−0.2888,−1.769,1a,b,c\leftarrow-0.2888,-1.769,1

  qsgn,q←sgn(q),clip(|q|,max=−b/S)q_{\mathrm{sgn}},q\leftarrow\mathrm{sgn}(q),\mathrm{clip}(|q|,\mathrm{max}=-b/S)

  qL,SL←q_{L},S_{L}\leftarrow I-Poly(q,S){(q,S)} with a,b,ca,b,c
⊳\triangleright Eq. 8  

  qo​u​t,So​u​t←qsgn​qL,SLq_{out},S_{out}\leftarrow q_{\mathrm{sgn}}q_{L},S_{L}

  return qo​u​t,So​u​tq_{out},S_{out}
⊳\triangleright
qo​u​t​So​u​t≈erf⁡(x)q_{out}S_{out}\approx\mathrm{erf}(x)\kern 4.62497pt

 end function

 function I-Gelu(q,S)(q,S)
⊳\triangleright q​S=xqS=x

  qerf,Serf←q_{\mathrm{erf}},S_{\mathrm{erf}}\leftarrow I-Erf(q,S/2){(q,S/\sqrt{2})}

  q1←⌊1/Serf⌋q_{1}\leftarrow\lfloor 1/S_{\mathrm{erf}}\rfloor

  qo​u​t,So​u​t←q⁡(qerf+q1),S​Serf/2q_{out},S_{out}\leftarrow q(q_{\mathrm{erf}}+q_{1}),SS_{\mathrm{erf}}/2

  return qo​u​t,So​u​tq_{out},S_{out}
⊳\triangleright
qo​u​t​So​u​t≈GELU⁡(x)q_{out}S_{out}\approx\mathrm{GELU}(x)\kern 4.62497pt

 end function
```

Table 1: 
Comparison of different approximation methods for GELU.
The second column (Int-only) indicates whether each approximation method can be computed with integer-only arithmetic.
As metrics for approximation error, we report L2 and L∞ distance from GELU across the range of [-4, 4].

Int-only
L2 dist
L∞ dist

$x\sigma(1.702x)$
✗
0.012
0.020

h-GELU
✓
0.031
0.068

i-GELU (Ours)
✓
0.0082
0.018

### 3.5 Integer-only Softmax

Softmax normalizes an input vector and maps it to
a probability distribution:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\mathrm{Softmax}(\mathbf{x})\_{i}:=\frac{\exp{x\_{i}}}{\sum\_{j=1}^{k}\exp{x\_{j}}},\kern 4.62497pt\text{where}\kern 4.62497pt\mathbf{x}=[x\_{1},\dots,x\_{k}].$ |  | (10) |

Approximating the
Softmax layer with integer arithmetic is quite challenging, as the exponential
function used in Softmax is unbounded and changes rapidly.
As such, prior Transformer quantization techniques [[4](#bib.bib4), [93](#bib.bib93)] treat this layer using floating point arithmetic.
Some prior work have proposed look up tables with interpolation [[68](#bib.bib68)],
but as before we avoid look up tables and strive for a pure arithmetic based approximation.
In addition, although [[26](#bib.bib26)] proposes polynomial approximation
methods for the exponential function,
it uses significantly high-degree polynomials, and is only applicable on a limited finite domain.

Similar to GELU, we cannot use a high-order polynomial, but even using such polynomial
is ineffective to approximate the exponential function in Softmax.
However, it is possible to address problem by limiting the approximation range of Softmax.
First, we subtract the maximum value from the input to the exponential for numerical stability:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\mathrm{Softmax}(\mathbf{x})\_{i}=\frac{\exp{(x\_{i}-x\_{\max})}}{\sum\_{j=1}^{k}\exp{(x\_{j}-x\_{\max})}},$ |  | (11) |

where $x\_{\max}=\max\_{i}(x\_{i})$.
Note that now all the inputs to the exponential function, i.e., $\tilde{x}\_{i}=x\_{i}-x\_{\max}$, become non-positive.
We can decompose any
non-positive real number $\tilde{x}$ as $\tilde{x}=(-\ln{2})z+p$,
where the quotient $z$ is a non-negative integer and the remainder $p$ is a real number in $(-\ln 2,0]$.
Then, the exponential of $\tilde{x}$ can be written as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\exp(\tilde{x})=2^{-z}\exp(p)=\exp(p)\verb|>>|z,$ |  | (12) |

where `>>` is the bit shifting operation.
As a result, we only need to approximate the exponential function in the compact interval of $p\in(-\ln 2,0]$.
This is a much smaller range as compared to the domain of all real numbers.
Interestingly, a variant of this method was used in the Itanium 2 machine from HP [[77](#bib.bib77), [14](#bib.bib14)], but with a look up table
for evaluating $\exp(p)$.

We use a second-order polynomial to approximate the exponential
function in this range. To find the coefficients of the polynomial, we minimize the L2 distance from exponential function in the interval of $(-\ln 2,0]$.
This results in the following approximation:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small L(p)=0.3585(p+1.353)^{2}+0.344\approx\exp(p).$ |  | (13) |

Substituting the exponential term in Eq. [12](#S3.E12 "In 3.5 Integer-only Softmax ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization") with this polynomial results in i-exp:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathrm{i\text{-}exp}(\tilde{x}):=L(p)\verb|>>|z$ |  | (14) |

where $\kern 5.0ptz=\lfloor-\tilde{x}/\ln 2\rfloor$ and $p=\tilde{x}+z\ln 2$. This can be calculated with integer arithmetic.
Algorithm [3](#alg3 "Algorithm 3 ‣ 3.5 Integer-only Softmax ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization") describes the integer-only computation of the Softmax fucntion using i-exp.
Figure [2](#S3.F2 "Figure 2 ‣ 3.4 Integer-only GELU ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization") (right) plots the result of i-exp,
which is nearly identical to the exponential function.
We find that the largest gap between these two functions is only $1.9\times 10^{-3}$.
Considering that 8-bit quantization of a unit interval introduces a quantization error of $1/256=3.9\times 10^{-3}$, our approximation error is relatively negligible and can be subsumed into the quantization error.

Algorithm 3  Integer-only Exponential and Softmax

```
 Input: q,Sq,S: quantized input and scaling factor

 Output: qo​u​t,So​u​tq_{out},S_{out}: quantized output and scaling factor

 function I-Exp(q,S)(q,S)
⊳\triangleright q​S=xqS=x

  a,b,c←0.3585,1.353,0.344a,b,c\leftarrow 0.3585,1.353,0.344

  qln⁡2←⌊ln⁡2/S⌋q_{\ln 2}\leftarrow\lfloor\ln 2/S\rfloor

  z←⌊−q/qln⁡2⌋z\leftarrow\lfloor-q/q_{\ln 2}\rfloor

  qp←q+z​qln⁡2q_{p}\leftarrow q+zq_{\ln 2}
⊳\triangleright qp​S=pq_{p}S=p\kern 4.62497pt

  qL,SL←q_{L},S_{L}\leftarrow I-Poly(qp,S){(q_{p},S)} with a,b,ca,b,c
⊳\triangleright Eq. 13  

  qo​u​t,So​u​t←qL​>>​z,SLq_{out},S_{out}\leftarrow q_{L}\verb|>>|z,S_{L}

  return qo​u​t,So​u​tq_{out},S_{out}
⊳\triangleright
qo​u​t​So​u​t≈exp⁡(x)q_{out}S_{out}\approx\mathrm{exp}(x)\kern 4.62497pt

 end function

 function I-Softmax(q,S)(q,S)
⊳\triangleright q​S=xqS=x

  q~←q−max⁡(q)\tilde{q}\leftarrow q-\mathrm{max}(q)

  qexp,Sexp←q_{\mathrm{exp}},S_{\mathrm{exp}}\leftarrow I-Exp(q~,S){(\tilde{q},S)}

  qo​u​t,So​u​t←qexp/sum⁡(qexp),Sexpq_{out},S_{out}\leftarrow q_{\mathrm{exp}}/\mathrm{sum}(q_{\mathrm{exp}}),S_{\mathrm{exp}}

  return qo​u​t,So​u​tq_{out},S_{out}
⊳\triangleright
qo​u​t​So​u​t≈Softmax⁡(x)q_{out}S_{out}\approx\mathrm{Softmax}(x)\kern 4.62497pt

 end function
```

### 3.6 Integer-only LayerNorm

LayerNorm is commonly used in Transformers and involves several non-linear operations, such as division, square, and square root.
This operation is used for normalizing the input activation across the channel dimension.
The normalization process is described as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\tilde{x}=\frac{x-\mu}{\sigma}\kern 4.62497pt\text{where}\kern 4.62497pt\mu=\frac{1}{C}\sum\_{i=1}^{C}x\_{i}\kern 4.62497pt\text{and}\kern 4.62497pt\sigma=\sqrt{\frac{1}{C}\sum\_{i=1}^{C}(x\_{i}-\mu)^{2}}.$ |  | (15) |

Here, $\mu$ and $\sigma$ are the mean and standard deviation of the input across the channel dimension.
One subtle challenge here is that the input statistics (i.e., $\mu$ and $\sigma$) change
rapidly for NLP tasks, and these values need to be
calculated dynamically during runtime. While computing
$\mu$ is straightforward, evaluating $\sigma$ requires the square-root
function.

The square-root function can be efficiently evaluated with integer-only
arithmetic through an iterative algorithm proposed in [[11](#bib.bib11)], as described in Alg. [4](#alg4 "Algorithm 4 ‣ 3.6 Integer-only LayerNorm ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization").
Given any non-negative integer input $n$, this algorithm iteratively searches for the exact value of $\lfloor\sqrt{n}\rfloor$ based on Newton’s Method and only requires integer arithmetic.
This algorithm is computationally lightweight, as it converges within at most
four iterations for any INT32 inputs and each iteration consists only of one integer division, one integer addition, and one bit-shifting operation.
The rest of the the non-linear operations in LayerNorm such as division and square are straightforwardly computed with integer arithmetic.

Algorithm 4  Integer-only Square Root

```
 Input: nn: input integer

 Output: integer square root of nn, i.e., ⌊n⌋\lfloor\sqrt{n}\rfloor

 function I-Sqrt(n)(n)

  if n=0n=0 then return 00

  Intialize x0x_{0} to 2⌈B​i​t​s​(n)/2⌉2^{\lceil Bits(n)/2\rceil} and ii to 00

  repeat

     xi+1←⌊(xi+⌊n/xi⌋)/2⌋x_{i+1}\leftarrow\lfloor(x_{i}+\lfloor n/x_{i}\rfloor)/2\rfloor

     if xi+1≥xix_{i+1}\geq x_{i} then return xix_{i}

     else i←i+1i\leftarrow i+1

 end function
```

## 4 Results

Table 2: 
Integer-only quantization result for RoBERTa-Base and RoBERTa-Large on the development set of the GLUE benchmark.
Baseline is trained by the authors from the pre-trained models, and I-BERT is quantized and fine-tuned from the baseline.
We also report the difference (Diff) between the baseline accuracy and the I-BERT accuracy.

Precision
Int-only
MNLI-m
MNLI-mm
QQP
QNLI
SST-2
CoLA
STS-B
MRPC
RTE
Avg.

Baseline
FP32
✗
87.8
87.4
90.4
92.8
94.6
61.2
91.1
90.9
78.0
86.0

I-BERT
INT8
✓
87.5
87.4
90.2
92.8
95.2
62.5
90.8
91.1
79.4
86.3

Diff

-0.3
0.0
-0.2
0.0
+0.6
+1.3
-0.3
+0.2
+1.4
+0.3

(a) RoBERTa-Base

Precision
Int-only
MNLI-m
MNLI-mm
QQP
QNLI
SST-2
CoLA
STS-B
MRPC
RTE
Avg.

Baseline
FP32
✗
90.0
89.9
92.8
94.1
96.3
68.0
92.2
91.8
86.3
89.0

I-BERT
INT8
✓
90.4
90.3
93.0
94.5
96.4
69.0
92.2
93.0
87.0
89.5

Diff

+0.4
+0.4
+0.2
+0.4
+0.1
+1.0
0.0
+1.2
+0.7
+0.5

(b) RoBERTa-Large

In this section, we first measure the accuracy of I-BERT using the General Language Understanding Evaluation [[80](#bib.bib80)] (GLUE) benchmark (§ [4.1](#S4.SS1 "4.1 Accuracy Evaluation on GLUE ‣ 4 Results ‣ I-BERT: Integer-only BERT Quantization")).
Then, we discuss the latency speedup of I-BERT using direct hardware deployment and compare it with pure FP32 model (§ [4.2](#S4.SS2 "4.2 Latency Evaluation ‣ 4 Results ‣ I-BERT: Integer-only BERT Quantization")).
Finally, we conduct ablation studies to showcase the effectiveness of our integer-only approximation methods (§ [4.3](#S4.SS3 "4.3 Ablation Studies ‣ 4 Results ‣ I-BERT: Integer-only BERT Quantization")).

### 4.1 Accuracy Evaluation on GLUE

We implement I-BERT on the RoBERTa [[46](#bib.bib46)] model using [[54](#bib.bib54)].
For the integer-only implementation, we replace all the floating point operations in the original
model with the corresponding integer-only operations that were discussed in § [3](#S3 "3 Methodology ‣ I-BERT: Integer-only BERT Quantization").
In particular, we perform MatMul and Embedding with INT8 precision, and the non-linear operations with INT32 precision, as using INT32 for computing these operations has little overhead.
See § [C.1](#A3.SS1 "C.1 Implementation ‣ Appendix C Experimental Details ‣ I-BERT: Integer-only BERT Quantization") for implementation details.
For each of the GLUE downstream tasks, we train both FP32 baseline and integer-only I-BERT models, and evaluate the accuracy on the development set.
See Appendix [C.2](#A3.SS2 "C.2 Training ‣ Appendix C Experimental Details ‣ I-BERT: Integer-only BERT Quantization") and [C.3](#A3.SS3 "C.3 Accuracy Evaluation on the GLUE Tasks ‣ Appendix C Experimental Details ‣ I-BERT: Integer-only BERT Quantization") for training and evaluation details.
While we only test RoBERTa-Base/Large, our method is not restricted to RoBERTa.
The integer-only approximations can be performed for any NN models including Transformers that uses similar non-linear operations.

The integer-only quantization results for RoBERTa-Base/Large are presented in Tab. [2](#S4.T2 "Table 2 ‣ 4 Results ‣ I-BERT: Integer-only BERT Quantization").
As one can see, I-BERT consistently achieves comparable or slightly higher accuracy than baseline.
For RoBERTa-Base, I-BERT achieves higher accuracy for all cases (up to 1.4 for RTE), except for MNLI-m, QQP, and STS-B tasks, where we observe a small
accuracy degradation up to 0.3.
We observe a similar behaviour on the RoBERTa-Large model, where I-BERT matches or outperforms the baseline accuracy for all the downstream tasks.
On average, I-BERT outperforms the baseline by 0.3/0.5 for RoBERTa-Base/Large, respectively.

### 4.2 Latency Evaluation

We evaluate the latency speedup of INT8 inference of I-BERT, by direct deployment on
a Tesla T4 GPU with Turing Tensor Cores that supports accelerated INT8 execution.
Although T4 GPU is not a pure integer-only hardware, we select it as our target device due to its extensive software support [[53](#bib.bib53), [7](#bib.bib7)], and in
particular Nvidia’s TensorRT library [[53](#bib.bib53)].
Furthermore, as we do not exploit any T4-specific exclusive features or requirements, our work can be extensively deployed on other hardware as well.
See § [C.4](#A3.SS4 "C.4 Environment Setup for Latency Evaluation ‣ Appendix C Experimental Details ‣ I-BERT: Integer-only BERT Quantization") for the detailed environment setup.
For evaluation, we implement two variants of BERT-Base/Large: (1) pure FP32 models using naïve FP32 kernels for non-linear operations; and (2) quantized INT8 models using customized kernels for the non-linear operations.
The customized kernels compute GELU, Softmax, and LayerNorm based on the integer-only methods described in § [3](#S3 "3 Methodology ‣ I-BERT: Integer-only BERT Quantization").
We measure the inference latency for different sequence lengths (128 and 256) and batch sizes (1, 2, 4, and 8).

Table [3](#S4.T3 "Table 3 ‣ 4.2 Latency Evaluation ‣ 4 Results ‣ I-BERT: Integer-only BERT Quantization") shows the inference latency speedup of INT8 models with respect to FP32 models.
As one can see, the INT8 inference of I-BERT is on average 3.08$\times$ and 3.56$\times$ faster than pure FP32 inference for BERT-Base and BERT-Large, respectively, achieving up to 4.00$\times$ speedup.
The result implies that, when deployed on specialized hardware that supports efficient integer computations, I-BERT can achieve significant speedup as compared to FP32 models.
Further speedups are possible with NVIDIA’s custom Transformer plugins [[52](#bib.bib52)] which fuse
the multi-head attention and Softmax layers (see  § [C.4](#A3.SS4 "C.4 Environment Setup for Latency Evaluation ‣ Appendix C Experimental Details ‣ I-BERT: Integer-only BERT Quantization")).

While the greatest value of our work will become evident when
our approach enables quantization on lower-end microprocessors
without floating-point hardware,
this demonstration must wait for improved software
support for implementing quantized NN models on those processors.
In the meantime, we believe the promise of our approach is
illustrated by these latency reductions shown above.

Table 3: 
Inference latency speedup of INT8 inference with respect to FP32 inference for BERT-Base and BERT-Large.
Latency is measured for different sentence lengths (SL) and batch sizes (BS).

SL
128
256
Avg.

BS
1
2
4
8
1
2
4
8

Base
2.42
3.36
3.39
3.31
3.11
2.96
2.94
3.15
3.08

Large
3.20
4.00
3.98
3.81
3.19
3.51
3.37
3.40
3.56

### 4.3 Ablation Studies

Here, we perform an ablation study to show the benefit of i-GELU as compared to
other approximation methods for GELU, and in particular h-GELU in  Eq. [6](#S3.E6 "In 3.4 Integer-only GELU ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization").
For comparison, we implement two variants of I-BERT by replacing i-GELU with GELU and h-GELU, respectively.
The former is the exact computation of GELU with floating point arithmetic,
and the later is another integer-only approximation method for GELU (see § [3](#S3 "3 Methodology ‣ I-BERT: Integer-only BERT Quantization")).
We use RoBERTa-Large model as baseline along with the QNLI, SST-2, MPRC, and RTE tasks.
All models are trained and fine-tuned according to the procedure described in § [4.1](#S4.SS1 "4.1 Accuracy Evaluation on GLUE ‣ 4 Results ‣ I-BERT: Integer-only BERT Quantization"), and the final accuracies are reported in Tab. [4](#S4.T4 "Table 4 ‣ 4.3 Ablation Studies ‣ 4 Results ‣ I-BERT: Integer-only BERT Quantization").

As one can see, replacing GELU with h-GELU approximation results in accuracy degradation for all downstream tasks except for MRPC.
Accuracy drops by 0.5 on average and up to 1.1 for RTE task.
Although accuracy slightly improves for MRPC, the amount of increase is smaller than replacing GELU with i-GELU.
This empirically demonstrates that h-GELU is not sufficiently tight enough to approximate GELU well.
Approximating GELU with i-GELU results in strictly better accuracy for all four downstream tasks than h-GELU.
In particular, i-GELU outperforms h-GELU by 0.7 on average, and it achieves comparable or slightly better result to the non-approximated full-precision GELU.
i-GELU also performs better than GELU, which is quite interesting, but at this
time, we do not have an explanation for this behaviour.

Table 4: 
Accuracy of models that use GELU, h-GELU and i-GELU for GELU computation. Note that the former is full-precision, floating point computation while the latter two are integer-only approximations.

Int-only
QNLI
SST-2
MRPC
RTE
Avg.

GELU
✗
94.4
96.3
92.6
85.9
92.3

h-GELU
✓
94.3
96.0
92.8
84.8
92.0

i-GELU
✓
94.5
96.4
93.0
87.0
92.7

## 5 Conclusions

We have proposed I-BERT, a novel integer-only quantization scheme for Transformers, where the entire inference is performed with pure integer arithmetic.
Key elements of I-BERT are approximation methods for nonlinear operations such as GELU, Softmax, and LayerNorm, which enable their approximation with integer computation.
We empirically evaluated I-BERT on RoBERTa-Base/Large models, where our quantization method improves
the average GLUE score by 0.3/0.5 points as comapred to baseline.
Furthermore, we directly deployed the quantized models and measured the end-to-end inference latency, showing that I-BERT can achieve up to 4.00$\times$ speedup on a Tesla T4 GPU as compared to floating point baseline.
As part of future work, one could consider
using our approximation to improve the training speed as well. For instance, one
could consider replacing GELU with i-GELU during training. Also,
further studies are needed to evaluate the performance benefit of i-GELU as compared to
GELU.

## Acknowledgments

The UC Berkeley team acknowledges gracious support from Intel corporation, Intel VLAB team, Google Cloud, Google TRC team, and Nvidia, as well as valuable feedback from Prof. Dave Patterson, and Prof. Joseph Gonzalez.
Amir Gholami was supported through a gracious fund from Samsung SAIT.
Michael W. Mahoney would also like to acknowledge the UC Berkeley CLTC, ARO, NSF, and ONR.
Our conclusions do not necessarily reflect the position or the policy of our sponsors, and no official endorsement should be inferred.

## Appendix A Quantization Methods

### A.1 Symmetric and Asymmetric Quantization

Symmetric and asymmetric quantization are two different methods for uniform quantization.
Uniform quantization is a uniform mapping from floating point $x\in[x\_{\mathrm{min}},x\_{\mathrm{max}}]$ to $b$-bit integer $q\in[-2^{b-1},2^{b-1}-1]$.
Before the mapping, input $x$ that does not fall into the range of $[x\_{\mathrm{min}},x\_{\mathrm{max}}]$ should be clipped.
In asymmetric quantization, the left and the right side of the clipping range can be different, i.e., $-x\_{\mathrm{min}}\neq x\_{\mathrm{max}}$.
However, this results in a bias term that needs to be considered when performing multiplication or convolution operations [[33](#bib.bib33)].
For this reason, we only use symmetric quantization in this work.
In symmetric quantization, the left and the right side of the clipping range must be equal, i.e., $-x\_{\mathrm{min}}=x\_{\mathrm{max}}=\alpha$,
and the mapping can be represented as Eq. [1](#S3.E1 "In 3.1 Basic Quantization Method ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization").

### A.2 Static and Dynamic Quantization

There is a subtle but important factor to consider when computing the scaling factor, $S$.
Computing this scaling factor requires determining the range of parameters/activations (i.e., $\alpha$ parameter in Eq. [1](#S3.E1 "In 3.1 Basic Quantization Method ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization")).
Since the model parameters are fixed during inference, their range and the corresponding scaling factor can be precomputed.
However, activations vary across different inputs, and thus their range varies.
One way to address this issue is to use dynamic quantization, where the activation range and the scaling factor are calculated during inference.
However, computing the range of activation is costly as it requires a scan over the entire data and often results in significant overhead.
Static quantization avoids this runtime computation by precomputing a fixed range based on the statistics of activations during training, and then uses that fixed range during inference.
As such, it does not have the runtime overhead of computing the range of activations.
For maximum efficiency, we adopt static quantization, with all the scaling factors fixed during inference.

## Appendix B Error Term of Eq. [3](#S3.E3 "In 3.3 Polynomial Approximation of Non-linear Functions ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization")

As one can see, the polynomial approximation of Eq. [3](#S3.E3 "In 3.3 Polynomial Approximation of Non-linear Functions ‣ 3 Methodology ‣ I-BERT: Integer-only BERT Quantization") exactly
matches the data at the interpolating points $(x\_{j},f\_{j})$.
The error between a target function $f(x)$ and the polynomial approximation $L(x)$ is then:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small|f(x)-L(x)|=\left|\frac{f^{(n+1)}(\xi)}{(n+1)!}(x-x\_{0})\dots(x-x\_{n})\right|,$ |  | (16) |

where $\xi$ is some number that lies in the smallest interval containing $x\_{0},...,x\_{n}$.
In general, this error reduces for large $n$ (for a properly selected
set of interpolating points).
Therefore, a sufficiently high-order polynomial that interpolates a target function is guaranteed to be a good approximation for it.
We refer interested readers to [[72](#bib.bib72)] for more details on polynomial interpolation.

## Appendix C Experimental Details

### C.1 Implementation

In I-BERT, all the MatMul operations are performed with INT8 precision, and are accumulated to INT32 precision.
Furthermore, the Embedding layer is kept at INT8 precision.
Moreover, the non-linear operations (i.e., GELU, Softmax, and LayerNorm) are processed with INT32 precision,
as we found that keeping them at high precision is important to
ensure no accuracy degradation after quantization.
Importantly, note that using INT32 for computing these operations has little overhead, as input data is already accumulated with INT32 precision, and these non-linear operations have
linear computational complexity.
We perform Requantization [[91](#bib.bib91)] operation after these operations to
bring the precision down from INT32 back to INT8 so that the follow up operations (e.g., next MatMuls) can be performed with low precision.

### C.2 Training

We evaluate I-BERT on the GLUE benchmark [[80](#bib.bib80)],
which is a set of 9 natural language understanding tasks, including sentimental analysis, entailment, and question answering.
We first train the pre-trained RoBERTa model on the different GLUE downstream tasks until the model achieves the best result on the development set.
We report this as the baseline accuracy.
We then quantize the model and perform quantization-aware fine-tuning to recover the accuracy degradation caused by quantization.
We refer the readers to [[91](#bib.bib91)] for more details about the quantization-aware fine-tuning method for integer-only quantization.
We search the optimal hyperparameters in a search space of learning rate $\{5\mathrm{e}-7,1\mathrm{e}-6,1.5\mathrm{e}-6,2\mathrm{e}-6\}$,
self-attention layer dropout $\{0.0,0.1\}$, and fully-connected layer dropout $\{0.1,0.2\}$, except for the one after GELU activation that is fixed to 0.0.
We fine-tune up to 6 epochs for larger datasets (e.g., MNLI and QQP), and 12 epochs for the smaller datasets.
We report the best accuracy of the resulting quantized model on the development set as I-BERT accuracy.

### C.3 Accuracy Evaluation on the GLUE Tasks

For evaluating the results, we use the standard metrics for each task in GLUE.
In particular, we use classification accuracy and F1 score for QQP [[32](#bib.bib32)] and MRPC [[17](#bib.bib17)],
Pearson Correlation and Spearman Correlation for STS-B [[6](#bib.bib6)],
and Mathews Correlation Coefficient for CoLA [[84](#bib.bib84)].
For the remaining tasks [[85](#bib.bib85), [61](#bib.bib61), [71](#bib.bib71), [12](#bib.bib12)], we use classification accuracy.
For the tasks with multiple metrics, we report the average of them.
Since there are two development sets for MNLI [[85](#bib.bib85)], i.e., MNLI-match (MNLI-m) for in-domain evaluation, and MNLI-mismatch (MNLI-mm) for cross-domain evaluation, and we report the accuracy on both datasets.
We exclude WNLI [[43](#bib.bib43)] as it has relatively small dataset and shows an unstable behaviour [[16](#bib.bib16)].

### C.4 Environment Setup for Latency Evaluation

We use TensorRT 7.2.1 to deploy and tune the latency of BERT-Base and BERT-Large models (both INT8 and FP32) on Google Cloud Platform virtual machine with a single Tesla T4 GPU, CUDA 11.1, and cuDNN 8.0.

We should also mention that the
most efficient way of implementing BERT with TensorRT is to use NVIDIA’s plugins [[52](#bib.bib52)] that optimize and accelerate key operations in the Transformer architecture via operation fusion.
Our estimates are that INT8 inference using NVIDIA’s plugins is about 2 times faster than
naïvely using TensorRT APIs.
However, we cannot modify those plugins to support our integer-only kernels as they are partially closed sourced and pre-compiled.
Therefore, our latency evaluation is conducted without fully utilizing NVIDIA’s plugins.
This leaves us a chance for further optimization to achieve our latency speedup relative to FP32 even more significant. As such, one could expect the potential for a further $\sim 2\times$ speed up with INT8 quantization.
