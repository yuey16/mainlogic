<!-- fulltext source=arxiv_html slug=arXiv-2011.10680 fetched=2026-09-21T06:50:42+00:00 -->

# HAWQ-V3: Dyadic Neural Network Quantization

Zhewei Yao
Affiliation: University of California, Berkeley
  
Zhen Dong
Affiliation: University of California, Berkeley
  
Zhangcheng Zheng
Affiliation: University of California, Berkeley
  
Amir Gholami
Affiliation: University of California, Berkeley
Correspondence to: [amirgh@berkeley.edu](mailto:amirgh@berkeley.edu)
  
Jiali Yu
Affiliation: Shanghai Jiao Tong University
Affiliation: Amazon
  
Eric Tan
Affiliation: University of California, Berkeley
  
Leyuan Wang
Affiliation: Amazon
  
Qijing Huang
Affiliation: University of California, Berkeley
  
Yida Wang
Affiliation: Amazon
  
Michael W. Mahoney
Affiliation: University of California, Berkeley
  
Kurt Keutzer
Affiliation: University of California, Berkeley

###### Abstract

Current low-precision quantization algorithms often have the hidden
cost of conversion back and forth from floating point to quantized integer values.
This hidden cost limits the latency improvement realized by quantizing Neural Networks.
To address this, we present HAWQ-V3, a novel mixed-precision integer-only quantization framework.
The contributions of HAWQ-V3 are the following:
(i)
An integer-only inference where the entire computational
graph is performed
only with integer multiplication, addition, and bit shifting,
without any floating point operations or even integer division;
(ii)
A novel hardware-aware mixed-precision quantization method where the bit-precision
is calculated by solving an integer linear programming problem
that balances the trade-off between model perturbation and other constraints, e.g., memory footprint and latency;
(iii) Direct hardware deployment and open source contribution for 4-bit uniform/mixed-precision
quantization in TVM, achieving an average speed up of $1.45\times$ for uniform 4-bit, as compared
to uniform 8-bit for ResNet50 on T4 GPUs; and
(iv) extensive evaluation of the proposed methods on
ResNet18/50 and InceptionV3, for various
model compression levels with/without mixed precision.
For ResNet50, our INT8 quantization achieves an
accuracy of $77.58\%$, which is $2.68\%$
higher than prior integer-only work, and our mixed-precision INT4/8 quantization can
reduce INT8 latency by $23\%$ and still achieve $76.73\%$ accuracy.
Our framework and the TVM implementation have been open sourced [[23](#bib.bib23)].

###### Keywords:

Machine Learning, ICML

††affiliationnotice: Equal contribution

## 1 Introduction

An important step toward realizing pervasive deep learning is enabling
real-time inference, both at the edge and in the cloud, with low energy consumption and
state-of-the-art model accuracy.
This will have a significant impact on applications such as
real-time intelligent healthcare monitoring, autonomous driving,
audio analytics, and speech recognition.
Over the past decade, we have observed significant improvements in the
accuracy of Neural Networks (NNs) for various tasks.
However, the state-of-the-art models are often prohibitively large and too compute-heavy to be deployed for real-time use.
A promising approach to address this is through quantization [[18](#bib.bib18), [22](#bib.bib22)],
where low-precision quantized integer
values are used to express the model parameters and feature maps.
That can help reduce the model footprint, and improve inference speed and energy consumption.

However, existing quantization algorithms often use simulated quantization, where
the parameters are stored with quantization, but are cast to floating point for inference.
As a result, all or part of the inference operations (e.g. convolution, matrix operations, batch norm layers, residual connections)
are performed using floating point precision.
This of course limits the speed up as we cannot utilize low precision logic.
To address this, we build upon existing integer-only quantization methods [[30](#bib.bib30)], and propose systematic methods to extend them to low and mixed-precision
quantization.
In particular, we make the following contributions:

* •

  We develop HAWQ-V3, a mixed-precision integer-only quantization framework with integer-only multiplication, addition, and bit shifting with static quantization.
  Importantly, no floating point and no integer division calculation is performed in the entire inference.
  This includes the batch norm layers and residual connections, which are typically kept at floating point precision in prior integer-only quantization work [[13](#bib.bib13)]. While keeping these operations in floating point helps
  accuracy, this is not allowed for integer-only hardware.
  We show that ignoring this and attempting to deploy a model that uses floating point residual on integer-only hardware can lead to more than 90% mismatch ( Figure [G.1](#A7.F1 "Figure G.1 ‣ Appendix G Error Accumulation of Fake Quantization ‣ HAWQ-V3: Dyadic Neural Network Quantization")).
  HAWQ-V3 completely avoids this by using a novel approach to perform residual connections in
  pure integer-only arithmetic.
  See Section [3.3](#S3.SS3 "3.3 Residual Connection ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization") and Appendix [G](#A7 "Appendix G Error Accumulation of Fake Quantization ‣ HAWQ-V3: Dyadic Neural Network Quantization") for details.
* •

  We propose a novel hardware-aware mixed-precision quantization formulation that
  uses an Integer Linear Programming (ILP) problem to find the best bit-precision setting.
  The ILP solver
  minimizes the model perturbation while observing application-specific
  constraints on model size, latency, and total bit operations.
  Compared to the contemporary work of [[28](#bib.bib28)], our approach
  is hardware-aware and uses direct hardware measurement to find a bit precision setting
  that has the optimal balance between latency and accuracy.
  See Section [3.4](#S3.SS4 "3.4 Mixed Precision and Integer Linear Programming ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization") and Appendix [I](#A9 "Appendix I ILP Result Interpolation ‣ HAWQ-V3: Dyadic Neural Network Quantization") for details.
* •

  To verify the feasibility of our approach, we deploy the quantized integer-only models using Apache TVM [[8](#bib.bib8)] for INT8, INT4, and mixed-precision
  settings. To the best of our knowledge,
  our framework is the first that adds INT4 support to TVM. By profiling the latency of different layers, we show that we can achieve an average of $1.47\times$ speed up with INT4, as compared to INT8 on a T4 GPU for ResNet50.
  See Section [3.5](#S3.SS5 "3.5 Hardware Deployment ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization") and Table [2](#S4.T2 "Table 2 ‣ 4.1 Low Precision Integer-Only Quantization Results ‣ 4 Results ‣ HAWQ-V3: Dyadic Neural Network Quantization") for more details.
* •

  We extensively test HAWQ-V3 on a wide range of workloads, including ResNet18, ResNet50, and InceptionV3, and
  show that we can achieve a substantial performance improvement, as compared to the prior state-of-the-art.
  For instance, we achieve an
  accuracy of $78.50\%$ with INT8 quantization, which is more than $4\%$
  higher than prior integer-only work for InceptionV3.
  Furthermore, we show that mixed-precision INT4/8 quantization can be used to achieve higher speed up as compared to INT8 inference with smaller impact on accuracy as compared to INT4 quantization. For example, for ResNet50 we can speedup latency
  by 23% as compared to INT8 and still achieve 76.73% accuracy.
  See Section [4](#S4 "4 Results ‣ HAWQ-V3: Dyadic Neural Network Quantization") and Table [1](#S4.T1 "Table 1 ‣ 4 Results ‣ HAWQ-V3: Dyadic Neural Network Quantization"), [2](#S4.T2 "Table 2 ‣ 4.1 Low Precision Integer-Only Quantization Results ‣ 4 Results ‣ HAWQ-V3: Dyadic Neural Network Quantization") for more details.

Figure 1: 
Illustration of fake vs true quantization for convolution and batch normalization folding.
For simplicity, we ignore the affine coefficient of BN.
(Left) In the simulated quantization (aka fake quantization approach), weights and activations
are simulated as integers with floating point representation, and all the multiplication and accumulation happen
in FP32 precision. Furthermore, the BN parameters (i.e. $\mu$ and $\sigma$) are stored and
computed using FP32 precision. This is undesirable but can significantly help accuracy since BN parameters
are sensitive to quantization.
However, with this approach, one cannot benefit from low-precision ALUs.
(Right) An illustration of the integer-only pipeline with dyadic arithmetic for convolution and BN folding.
The standard deviation ($\sigma$) in BN is merged into the quantization scale of the weights, and the mean
is quantized to INT32 and merged as a bias into the weights (denoted by $b^{\color[rgb]{0,0.88,0}i32}$)
Note that with this approach, all the weights and activations
are stored in integer format, and all the multiplications are performed with INT4 and accumulated in INT32 precision.
Finally, the accumulated result is requantized to INT4 with dyadic scaling (denoted by $\frac{S\_{w}S\_{h}}{\sigma S\_{a}}$). Importantly, no floating point or even
integer division is performed.
See Section [3.2](#S3.SS2 "3.2 Batch Normalization ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization") and Appendix [D](#A4 "Appendix D Batch Normalization Fusion ‣ HAWQ-V3: Dyadic Neural Network Quantization") for more details.

## 2 Related Work

There have been significant efforts recently to improve the trade-off between accuracy and efficiency of NN models.
These can be broadly categorized as follows:
(i) Designing new NN architectures [[29](#bib.bib29), [49](#bib.bib49), [54](#bib.bib54)];
(ii) Co-designing NN architecture and hardware together [[20](#bib.bib20), [17](#bib.bib17), [59](#bib.bib59), [26](#bib.bib26)];
(iii) Pruning redundant filters [[36](#bib.bib36), [21](#bib.bib21), [40](#bib.bib40), [37](#bib.bib37), [38](#bib.bib38), [60](#bib.bib60)];
(iv) knowledge distillation [[25](#bib.bib25), [39](#bib.bib39), [46](#bib.bib46), [62](#bib.bib62)];
and (v) using quantization (reduced precision).
Here, we provide a more detailed overview of this related work.

Quantization.
A common solution is to compress NN models with quantization [[3](#bib.bib3), [27](#bib.bib27), [47](#bib.bib47), [64](#bib.bib64), [65](#bib.bib65), [30](#bib.bib30), [63](#bib.bib63), [13](#bib.bib13), [10](#bib.bib10), [53](#bib.bib53), [5](#bib.bib5), [34](#bib.bib34), [51](#bib.bib51), [43](#bib.bib43)],
where low-bit precision is used for weights/activations.
Quantization reduces model size without changing the original network architecture,
and it could potentially permit the use of low-precision matrix multiplication or convolution.

While the gains on speed/power increase for low-precision quantization, low-precision quantization suffers from accuracy degradation.
To address this, recent work uses
non-uniform quantizers [[63](#bib.bib63)], channel-wise
quantization [[35](#bib.bib35)], and progressive quantization-aware
fine-tuning [[64](#bib.bib64)].
Other works try to include periodic regularization to assist
quantization [[41](#bib.bib41), [16](#bib.bib16)], apply post training
quantization [[4](#bib.bib4), [6](#bib.bib6), [28](#bib.bib28)], or improve
accuracy by changing the channel counts accordingly for different
layers [[10](#bib.bib10)].
Despite these advances, performing uniform ultra low-bit quantization still results in a
significant accuracy degradation.
A promising direction is to use mixed-precision quantization [[66](#bib.bib66), [57](#bib.bib57), [13](#bib.bib13), [52](#bib.bib52)],
where some layers are kept at higher precision, while others are kept at a lower precision.
However, a challenge with this approach is finding the right
the mixed-precision setting for the different layers.
A brute force approach is not feasible since the search space is exponentially
large in the number of layers.

HAQ [[57](#bib.bib57)] proposes to search this space by applying a
Reinforcement Learning algorithm, while [[58](#bib.bib58)] uses a Differentiable
Neural Architecture Search.
However, these searching methods require large computational
resources, and their performance is very sensitive to hyper-parameters and even
initialization.
To address these issues, HAWQ [[13](#bib.bib13), [14](#bib.bib14)] introduces an automatic way to find
good mixed-precision settings based on the sensitivity obtained using the Hessian spectrum.
However, the Pareto frontier method in [[14](#bib.bib14)] is not flexible enough to satisfy simultaneously different requirements on hardware.
To address this, we propose here an ILP solution that can generate mixed-precision settings with various constraints (such as model size, BOPS, and latency), and which can be solved within seconds on commodity hardware.
The contemporary work of [[28](#bib.bib28)] also proposes to use an ILP.
However, their approach is not hardware aware, and their approach uses FP32 casting.

Another issue is that the quantized weights and
activations need to be converted to floating point precision during inference, as shown in Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ HAWQ-V3: Dyadic Neural Network Quantization").
This high-precision casting can have high overhead and limits inference speed, especially for hardware with limited on-chip memory. Using FP32 ALUs also requires a larger die area
in the chip, further limiting the peak computational capacity of the hardware.
The work of [[30](#bib.bib30)] addresses
this casting problem by using integer-only quantization in INT8 precision.
However, there are several
shortcomings associated with their approach (which are addressed in HAWQ-V3).
First, [[30](#bib.bib30)] does not support
low-precision or mixed-precision quantization.
We show that this is useful in practice, as it
can improve the inference speed by up to 50%
with a small impact on accuracy.
Second,
both [[30](#bib.bib30)] and HAWQ are hardware agnostic and do not
co-design/adapt the quantization for the target hardware.
In contrast, the ILP approach in HAWQ-V3 is hardware aware, and it directly takes this into account
when determining mixed-precision bit setting.
Third, as we discuss in Section [3.2](#S3.SS2 "3.2 Batch Normalization ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization"), the approach used in [[30](#bib.bib30)]
leads to sub-optimal accuracy for INT8 quantization,
while our approach can achieve up to 5% higher accuracy for INT8 inference.
Finally, to address the absence of low-precision support in previous works [[30](#bib.bib30), [13](#bib.bib13)], we extend TVM to support INT4
and mixed-precision quantization, and we validate our results by directly running the quantized model with low bit-width on the hardware.
See Appendix [A](#A1 "Appendix A Deployment Frameworks ‣ HAWQ-V3: Dyadic Neural Network Quantization") for the discussion of different deployment frameworks.

## 3 Methodology

Assume that the NN has $L$ layers with learnable parameters, denoted as $\{W\_{1},W\_{2},...,W\_{L}\}$, with $\theta$ denoting the combination of all such parameters.
For a supervised setting, the goal is to optimize the following empirical risk minimization loss function:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\mathcal{L}(\theta)=\frac{1}{N}\sum\nolimits\_{i=1}^{N}l(x\_{i},y\_{i};\theta),$ |  | (1) |

where $(x,y)$ is the input data and the corresponding label, $l(x,y;\theta)$ is the loss function (e.g., MSE or Cross Entropy loss),
and $N$ is the total number of data points.
We assume that we have the trained model parameters $\theta$ given
in floating point precision. Our goal is to quantize the model with the optimal trade-offs among
memory footprint, speed, and accuracy.
Below, we first define quantization and then present HAWQ-V3.

Uniform Quantization.
Quantization restricts NN weights/activations to a finite set of values as follows:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small Q(r)=\text{Int}\big({r}/{S}\big)-Z,$ |  | (2) |

where $Q$ is the quantization operator, $r$ is a real valued number (activation or a weight),
$S$ is a real valued scaling factor, and $Z$ is the zero point,
chosen such that the $0$ value would exactly map to quantized values.
Furthermore, Int maps a floating point value to an integer value
through a rounding operation (e.g., round to nearest and
truncation).

This formulation for $Q$ corresponds to uniform quantization.
However, some work in the literature has also explored non-uniform
quantization [[63](#bib.bib63), [44](#bib.bib44), [57](#bib.bib57)].
Although non-uniform quantization may achieve higher accuracy for a fixed bit-width, such approaches
are typically difficult to deploy on hardware to reduce latency.11
1
However, they can reduce total model footprint.
As such, for HAWQ-V3, we only focus on uniform quantization.
Meanwhile, for HAWQ-V3, we use (i) symmetric quantization for weights and asymmetric quantization for activations; and (ii) static quantization for all the scaling factors $S$.
Meanwhile, we apply channel-wise quantization for different convolutional output channels.
Please see Appendix [B](#A2 "Appendix B Quantization Method ‣ HAWQ-V3: Dyadic Neural Network Quantization") for more details.

### 3.1 Quantized Matrix Multiplication and Convolution

Consider a layer with hidden activation denoted as $h$ and weight tensor denoted as $W$,
followed by ReLU activation.
First, $h$ and $W$ are quantized to $S\_{h}q\_{h}$ and $S\_{w}q\_{w}$,
where $S\_{h}$ and $S\_{w}$ are the real valued quantization scales,
$q\_{h}$ and $q\_{W}$ are the corresponding quantized integer values.
The output result, denoted with $a$, can be computed as follows:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small a=S\_{w}S\_{h}(q\_{w}\*q\_{h}),$ |  | (3) |

where $q\_{w}\*q\_{h}$ is the matrix multiplication (or convolution)
calculated with integer in low precision (e.g., INT4) and accumulated in INT32 precision.
This result is then requantized
and sent to the next layer as follows:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small q\_{a}=\text{Int}\left(\frac{a}{S\_{a}}\right)=\text{Int}\left(\frac{S\_{w}S\_{h}}{S\_{a}}(q\_{w}\*q\_{h})\right),$ |  | (4) |

where $S\_{a}$ is the pre-calculated scale factor for the output activation.

In HAWQ-V3, the $q\_{w}\*q\_{h}$ operation is performed with low-precision
integer-only multiplication and INT32 accumulation, and the final
INT32 result is quantized by scaling it with ${S\_{w}S\_{h}}/{S\_{a}}$.
The latter is a floating point scaling that needs to be multiplied
with the accumulated result (in INT32 precision).
A naive implementation requires floating point multiplication for this stage.
However, this can be avoided by enforcing the scaling to be a
dyadic number. Dyadic numbers are rational numbers with the format of ${b}/{2^{c}}$,
where $b,\penalty\ c$ are two integer numbers.
As such, a dyadic scaling in Eq. [4](#S3.E4 "In 3.1 Quantized Matrix Multiplication and Convolution ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization") can be efficiently performed
using INT32 integer multiplication and bit shifting.
Given a specific ${S\_{w}S\_{h}}/{S\_{a}}$, we use $DN$ (representing Dyadic Number) to denote the function that can calculate the corresponding $b$ and $c$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small{b}/{2^{c}}=\text{DN}\left({S\_{w}S\_{h}}/{S\_{a}}\right).$ |  | (5) |

An advantage of using dyadic numbers besides avoiding floating point arithmetic, is that it removes the need to support division (which typically has an order of magnitude higher latency than multiplication) in the hardware.
This approach is used for INT8 quantization in [[30](#bib.bib30)],
and we enforce all the rescaling to be dyadic for low-precision and mixed-precision
quantization as well.

### 3.2 Batch Normalization

Batch normalization (BN) is an important component of most NN architectures, especially for computer vision applications.
BN performs the following
operation to an input activation $a$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\text{BN}(a)=\beta\frac{a-\mu\_{B}}{\sigma\_{B}}+\gamma$ |  | (6) |

where $\mu\_{B}$ and $\sigma\_{B}$ are the mean and standard deviation of $a$, and $\beta,\ \gamma$ are trainable parameters.
During inference, these parameters (both statistics and trainable parameters) are fixed, and
therefore the BN operations could be fused with the convolution (see Appendix [D](#A4 "Appendix D Batch Normalization Fusion ‣ HAWQ-V3: Dyadic Neural Network Quantization")).
However, an important problem is that quantizing the BN parameters often leads to significant accuracy degradation.
As such, many prior quantization methods keep BN parameters in FP32 precision (e.g., [[14](#bib.bib14), [6](#bib.bib6), [10](#bib.bib10), [11](#bib.bib11), [63](#bib.bib63), [44](#bib.bib44)], just to name a few).
This makes such approaches not suitable for integer-only hardware.
While using such techniques help accuracy, HAWQ-V3 completely avoids that.
We fuse the BN parameters with the convolution and quantized them
with integer-only approach
(Please see Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ HAWQ-V3: Dyadic Neural Network Quantization") where we compare simulated qauntization and HAWQ-V3 for BN and convolution.).

Another important point to discuss here is that we found the BN folding used
in [[30](#bib.bib30)] to be sub-optimal.
In their approach BN and CONV layers are fused together while BN running
statistics are still kept updating.
This actually requires computing each convolution layer
twice, once without BN and then with BN (as illustrated in [[30](#bib.bib30), Figure C8]).
However, we found that this is unnecessary and degrades the accuracy.
Instead, in HAWQ-V3, we follow a simpler approach where we first keep the Conv and BN layer unfolded, and allow the BN statistics to update.
After several epochs, we then freeze the running statistics in the BN layer and fold the CONV and BN layers (please see Appendix [D](#A4 "Appendix D Batch Normalization Fusion ‣ HAWQ-V3: Dyadic Neural Network Quantization") for details).
As we will show in Section [4](#S4 "4 Results ‣ HAWQ-V3: Dyadic Neural Network Quantization"), this approach results in better accuracy as compared to [[30](#bib.bib30)].

Figure 2: Illustration of HAWQ-V3 for a residual block with and without transition layer.
Input feature map is given in INT32 precision, which is requantized to
INT4 precision (green boxes) before any convolution layer (gray boxes).
The BN layer is folded into the convolution.
The residual addition is performed in INT32 precision, and the final
accumulated result is re-scaled and sent to the next layer.
For blocks with a transition layer, we only quantize the input once to
INT4 and we use the same result for both $1\times 1$ convolutions.

### 3.3 Residual Connection

Residual connection [[24](#bib.bib24)] is another important component in many NN architectures.
Similar to BN, quantizing the residual connections can lead to accuracy degradation,
and as such, some prior quantization works perform the operation in FP32 precision [[11](#bib.bib11), [63](#bib.bib63), [57](#bib.bib57)].
There is a common misunderstanding that this may not be a big problem.
However, this actually leads to complete loss of signal, especially for low
precision quantization. The main reason for this is that
quantization is not a linear operation, that is $Q(a+b)\neq Q(a)+Q(b)$ ($a$, $b$ are floating point numbers).
As such, performing the accumulation in FP32 and then quantizing
is not the same as accumulating quantized values.
Therefore, it is not possible to deploy quantization methods that keep
residual connection in FP32 in integer-only hardware (we provide more detailed
discussion of this in Appendix [F](#A6 "Appendix F Fake Quantization for Residual Connection ‣ HAWQ-V3: Dyadic Neural Network Quantization") and also
quantify the resulting error which can be more than 90%).

We avoid this in HAWQ-V3, and use INT32 for the residual branch.
We perform the following steps to
ensure that the addition operation can happen with dyadic arithmetic.
Let us denote the activation passing through the residual connection as
$r=S\_{r}q\_{r}$.22
2
This is either the input or the output activation after
the downsampling layer.
Furthermore, let us denote the activation of the main branch before residual addition as
$m=S\_{m}q\_{m}$, and the final output after
residual accumulation by $a=S\_{a}q\_{a}$.
Then we will have:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small q\_{a}=\text{DN}\left({S\_{m}}/{S\_{a}}\right)q\_{m}+\text{DN}\left({S\_{r}}/{S\_{a}}\right)q\_{r}.$ |  | (7) |

Note that with this approach, we only need to perform a dyadic scaling of
$q\_{m}$ and add the result with the dyadically scaled $q\_{r}$. All of these
operations can happen with integer-only arithmetic.
Also we should note that in our approach all the scales are statically known.
These steps are schematically illustrated in Figure [2](#S3.F2 "Figure 2 ‣ 3.2 Batch Normalization ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization") for
a residual connection with/without downsampling.
Similar approach is performed for concatenation layer as well (see Appendix [E](#A5 "Appendix E Concatenation Layer ‣ HAWQ-V3: Dyadic Neural Network Quantization")).

Figure 3: 
Illustration of inference speed and generalization performance trade-off of ResNet18.
For each layer, we need to consider the speedup of INT4 vs INT8 and the sensitivity based on the second order (Hessian) sharpness [[14](#bib.bib14)] of this layer.

### 3.4 Mixed Precision and Integer Linear Programming

Uniformly quantizing all the layers to low
bit-width (e.g. INT4) could lead to significant accuracy degradation.
However, it is possible
to benefit from low-precision quantization by keeping a subset of sensitive layers
at high precision [[13](#bib.bib13)].
The basic idea is to keep sensitive layers at higher precision and insensitive layers at lower precision.
An important component of HAWQ-V3 is that we directly consider hardware-specific metrics
such as latency, to select the bit-precision configuration.
This is important since a layer’s latency does not necessarily halve when quantized from INT8 to INT4 precision.
In fact, as we discuss in Section [4](#S4 "4 Results ‣ HAWQ-V3: Dyadic Neural Network Quantization"), there are specific
layer configurations that do not gain any speed up when quantized to low precision,
and some that superlinearly benefit from quantization.33
3
The speedup of each layer is calculated by the latency of INT8 divided by that of INT4. For uniform 4-bit and mixed-precision models, the speedup is calculated related to uniform 8-bit model.
As such, quantizing the former will not lead to any latency improvement, and will only hurt accuracy. Therefore, it is better to keep such layers at high precision,
even if they have low sensitivity.
These trade-offs between accuracy and latency should be taken into consideration when quantizing them to low precision.
Importantly, these trade-offs are hardware-specific as latency in general does not correlate with the model size and/or FLOPS.
However, we can consider this by
directly measuring the latency of executing a layer in quantized precision on the target hardware platform.
This trade-off is schematically shown in Figure [3](#S3.F3 "Figure 3 ‣ 3.3 Residual Connection ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization") (and
later quantified in Figure [I.1](#A9.F1 "Figure I.1 ‣ Appendix I ILP Result Interpolation ‣ HAWQ-V3: Dyadic Neural Network Quantization")).
We can use an Integer Linear Programming (ILP) problem to formalize the problem definition of finding
the bit-precision setting that has optimal trade-off as described next.

Assume that we have $B$ choices
for quantizing each layer (i.e., 2 for INT4 or INT8). For a
model with $L$ layers, the search space of the ILP will be $B^{L}$.
The goal of solving the ILP problem is to find the best bit configuration among these
$B^{L}$ possibilities that results in optimal trade-offs between model perturbation $\Omega$,
and user-specified constraints such as model size, BOPS, and latency.
Each of these bit-precision
settings could result in a different model perturbation.
To make the problem
tractable, we assume that the perturbations for each layer are independent of each
other (i.e., $\Omega=\sum\_{i=1}^{L}\Omega\_{i}^{(b\_{i})}$, where $\Omega\_{i}^{(b\_{i})}$ is the $i$-th layer’s perturbation with $b\_{i}$ bit)44
4
Similar assumption can be found in [[13](#bib.bib13), [14](#bib.bib14)]..
This allows us to precompute the sensitivity of each
layer separately, and it only requires $BL$ computations.
For the sensitivity metric, we use the Hessian based perturbation proposed in [[14](#bib.bib14), Eq. 2.11].
The ILP problem tries to find the right bit precision that minimizes this sensitivity, as follows:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | Objective: | $\displaystyle\min\nolimits\_{\{b\_{i}\}\_{i=1}^{L}}\sum\nolimits\_{i=1}^{L}\Omega\_{i}^{(b\_{i})},$ |  | (8) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | Subject to: | $\displaystyle\sum\nolimits\_{i=1}^{L}M\_{i}^{(b\_{i})}\leq\text{ Model Size Limit},$ |  | (9) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\sum\nolimits\_{i=1}^{L}G\_{i}^{(b\_{i})}\leq\text{ BOPS Limit},$ |  | (10) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\sum\nolimits\_{i=1}^{L}Q\_{i}^{(b\_{i})}\leq\text{ Latency Limit}.$ |  | (11) |

Here, $M\_{i}^{(b\_{i})}$ denotes the size of $i$-th layer with $b\_{i}$ bit quantization,
$Q\_{i}^{(b\_{i})}$ is the associated latency, and
$G\_{i}^{(b\_{i})}$ is the corresponding BOPS required for computing that layer.
The latter measures the total Bit Operations for calculating a layer [[55](#bib.bib55)]:

|  |  |  |
| --- | --- | --- |
|  | $\small G\_{i}^{(b\_{i})}=b\_{w\_{i}}b\_{a\_{i}}\text{MAC}\_{i},$ |  |

where MACi is the total Multiply-Accumulate operations for computing the $i$-th layer,
and $b\_{w\_{i}},\ b\_{a\_{i}}$ are the bit precision used for weight and activation.55
5
$b\_{w\_{i}}$ and $b\_{a\_{i}}$ are always the same in HAWQ-V3.
As such, HAWQ-V3 does not need to cast lower-precision integer numbers, e.g., INT4, to higher-precision integer numbers, e.g., INT8, which is more efficient than [[14](#bib.bib14), [6](#bib.bib6), [57](#bib.bib57)].
Note that it is not necessary to set all these constraints at the same time.
Typically, which constraint to use depends on the end-user application.

We solve the ILP using open source PULP library [[48](#bib.bib48)] in Python,
where we found that for all the configurations tested in the paper, the ILP solver can find the solution
in less than 1 second given the sensitivity metric.
For comparison, the RL based method of [[57](#bib.bib57)] could take tens of hours
to find the right bit-precision setting.
Meanwhile, as can be seen, our ILP solver can be easily used for multiple constraints.
However, the complexity of Pareto frontier proposed by [[14](#bib.bib14)] is exponentially increasing for multiple constraints.
In Section [4.2](#S4.SS2 "4.2 Mixed-precision Results with Different Constraints ‣ 4 Results ‣ HAWQ-V3: Dyadic Neural Network Quantization"), we show the results with different constraints.

We should also mention that the contemporary work of [[28](#bib.bib28)],
also proposed an ILP formulation. However, our approach is hardware-aware and we directly
deploy and measure the latency of each layer in hardware.

### 3.5 Hardware Deployment

Model size alone is not a good metric to measure the efficiency (speed and energy consumption) of NNs.
In fact, it is quite possible that a small model would have higher latency and consume
a larger amount of energy for inference.
The same is also true for FLOPs.
The reason is that neither model size nor FLOPs can account for cache misses, data locality, memory bandwidth, underutilization of hardware, etc.
To address this, we need to deploy and directly measure the latency.

We target Nvidia Turing Tensor Cores of T4 GPU for deployment, as it supports both INT8 and INT4 precision and has been enhanced for deep learning network inference.
The only API available is the WMMA kernel call which is a micro-kernel for performing matrix-matrix operations in INT4 precision on Tensor Cores.
However, there is also no existing compiler that would map a NN quantized to INT4 to Tensor Cores using WMMA instructions.
To address this challenge, another contribution of our work is extending TVM [[8](#bib.bib8)]
to support INT4 inference with/without mixed precision with INT8.
This is important so we can verify the speed benefits of mixed-precision inference.
To accomplish this, we had to
add new features in both graph-level IR and operator schedules to make INT4 inference efficient.
For instance, when we perform optimizations such as memory planning, constant folding,
and operator fusion, at the graph-level IR, 4-bit data are involved.
However, on byte-addressable machines, manipulating 4-bit data individually leads to inefficiency in storage and communication. Instead, we pack eight 4-bit elements into an INT32
data type and perform the memory movement as a chunk. In the final code generation stage, the data type and all memory access will be adjusted for INT32.
By adopting similar scheduling strategies to Cutlass [[42](#bib.bib42)], we implement a new direct convolution
schedule for Tensor Cores for both 8-bit and 4-bit data in TVM.
We set the knobs for the configurations such as thread size, block size, and loop ordering so
that the auto-tuner in TVM could search for the best latency settings.

Another important point is that we have completed the pipeline to test directly the trained weights and to avoid using random weights for speed measurements.
This is important, since small discrepancies between the hardware implementation may go
unnoticed from the quantization algorithm in the NN training framework (PyTorch in our case) which does not use TVM for the forward and backward propagation.
To avoid any such issue, we made sure that the results between TVM and PyTorch match for every single layer and stage to machine-precision accuracy, and we verified
the final Top-1 accuracy when executed in the hardware with integer-only arithmetic.
In Appendix [G](#A7 "Appendix G Error Accumulation of Fake Quantization ‣ HAWQ-V3: Dyadic Neural Network Quantization"), we present the error accumulation of feature maps for ResNet50 with INT4 quantization, which uses fake quantization in PyTorch and is deployed in TVM.

## 4 Results

In this section, we first discuss ImageNet results on various models
(ResNet18/50 and InceptionV3) for INT8, INT4, and mixed-precision INT4/8 with/without distillation.
Afterward, we study the different use cases of the ILP formulation, and
the corresponding trade-offs between model size, latency, and accuracy.
Detailed discussion on the implementation and set up is provided in Appendix [H](#A8 "Appendix H Implementation Details ‣ HAWQ-V3: Dyadic Neural Network Quantization").
For all the experiments we made sure to report and compare with the highest
accuracy known for the baseline NN model in FP32 (i.e., we use a strong baseline for comparison).
This is important since using a weak baseline accuracy could lead to misleading
quantization accuracy.

Table 1: Quantization results for ResNet18/50 and InceptionV3.
Here, we abbreviate Integer-Only Quantization as “Int”, Uniform Quantization as “Uni”, the Baseline Accuracy as "BL", Weight Precision and Activation Precision as “Precision”, Model Size as “Size” (in MB), Bit Operations as “BOPS” (in G), and Top-1 Accuracy as “Top-1”.
Also, “WxAy” means weight with x-bit and activation with y-bit, and 4/8 means mixed precision with 4 and 8 bits. “MP” means mixed precision with bitwidth ranging from 1-bit to 8-bit, and “W1\*” means the bitwidth is 1-bit but the network architecture is changed (by using more channels).
Our result with/without distillation is represented as HAWQV3+Dist/HAWQ-V3.

Method
Int
Uni
BL
Precision
Size
BOPS
Top-1

Baseline
✗
–
71.47
W32A32
44.6
1858
71.47

RVQuant [[44](#bib.bib44)]
✗
✗
69.91
W8A8
11.1
116
70.01

HAWQ-V3
✓
✓
71.47
W8A8
11.1
116
71.56

PACT [[11](#bib.bib11)]
✗
✓
70.20
W5A5
7.2
50
69.80

LQ-Nets [[63](#bib.bib63)]
✗
✗
70.30
W4A32
5.8
225
70.00

HAWQ-V3
✓
✓
71.47
W4/8A4/8
6.7
72
70.22

HAWQV3+Dist
✓
✓
71.47
W4/8A4/8
6.7
72
70.38

CalibTIB[[28](#bib.bib28)]
✗
✓
71.97
W4A4
5.8
34
67.50

HAWQ-V3
✓
✓
71.47
W4A4
5.8
34
68.45

(a) ResNet18

Method
Int
Uni
BL
Precision
Size
BOPS
Top-1

Baseline
✓
✓
77.72
W32A32
97.8
3951
77.72

Integer Only [[30](#bib.bib30)]
✓
✓
76.40
W8A8
24.5
247
74.90

RVQuant [[44](#bib.bib44)]
✗
✗
75.92
W8A8
24.5
247
75.67

HAWQ-V3
✓
✓
77.72
W8A8
24.5
247
77.58

PACT [[11](#bib.bib11)]
✗
✓
76.90
W5A5
16.0
101
76.70

LQ-Nets [[63](#bib.bib63)]
✗
✗
76.50
W4A32
13.1
486
76.40

RVQuant [[44](#bib.bib44)]
✗
✗
75.92
W5A5
16.0
101
75.60

HAQ [[57](#bib.bib57)]
✗
✗
76.15
WMPA32
9.62
520
75.48

OneBitwidth [[10](#bib.bib10)]
✗
✓
76.70
W1\*A8
12.3
494
76.70

HAWQ-V3
✓
✓
77.72
W4/8A4/8
18.7
154
75.39

HAWQV3+Dist
✓
✓
77.72
W4/8A4/8
18.7
154
76.73

CalibTIB[[28](#bib.bib28)]
✗
✓
77.20
W4A4
13.1
67
73.70

HAWQ-V3
✓
✓
77.72
W4A4
13.1
67
74.24

(b) ResNet50

Method
Int
Uni
BL
Precision
Size
BOPS
Top-1

Baseline
✗
✓
78.88
W32A32
90.9
5850
78.88

Integer Only [[30](#bib.bib30)]
✓
✓
78.30
W8A8
22.7
366
74.20

RVQuant [[44](#bib.bib44)]
✗
✗
74.19
W8A8
22.7
366
74.22

HAWQ-V3
✓
✓
78.88
W8A8
22.7
366
78.76

Integer Only [[30](#bib.bib30)]
✓
✓
78.30
W7A7
20.1
280
73.70

HAWQ-V3
✓
✓
78.88
W4/8A4/8
19.6
265
74.65

HAWQV3+Dist
✓
✓
78.88
W4/8A4/8
19.6
265
74.72

HAWQ-V3
✓
✓
78.88
W4A4
12.3
92
70.39

(c) InceptionV3

### 4.1 Low Precision Integer-Only Quantization Results

We first start with ResNet18/50 and InceptionV3 quantization on ImageNet, and compare the performance
of HAWQ-V3 with other approaches, as shown in Table [1](#S4.T1 "Table 1 ‣ 4 Results ‣ HAWQ-V3: Dyadic Neural Network Quantization").

Uniform 8-bit Quantization.
Our 8-bit quantization achieves similar accuracy compared to
the baseline.
Importantly, for all the models HAWQ-V3 achieves higher accuracy
than the integer-only approach of [[30](#bib.bib30)].
For instance, on ResNet50, we achieve 2.68% higher accuracy as compared to [[30](#bib.bib30)].
This is in part due to our BN folding strategy that was described in Section [3.2](#S3.SS2 "3.2 Batch Normalization ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization").

Uniform 4-bit Quantization.
To the best of our knowledge, 4-bit results of HAWQ-V3 are the first integer-only quantization results
reported in the literature.
The accuracy results for ResNet18/50, and InceptionV3 are quite high, despite the fact that all of the inference computations are restricted
to be integer multiplication, addition, and bit shifting.
While there is some accuracy drop,
this should not be incorrectly interpreted
that uniform INT4 is not useful. On the contrary, one has to keep in mind that
certain use cases have strict latency and memory footprint limit for which this may
be the best solution.
However, higher accuracy can be achieved through mixed-precision quantization.

Mixed 4/8-bit Quantization.
The mixed-precision results improve the accuracy by several percentages for all the
models, while slightly increasing the memory footprint of the model.
For instance, the mixed-precision result for ResNet18 is 1.88% higher than its INT4 counterpart with just a 1.9MB increase in model size.
Further improvements are also possible with distillation (denoted as HAWQV3+Dist in the table).
For ResNet50, the distillation can boost the mixed-precision by 1.34%.
We found that distillation helps most for mixed-precision quantization, and we found little to no improvement
for uniform INT8, or uniform INT4 quantization cases.66
6
We used simple distillation without
extensive tuning. One might be able to improve the results further with more sophisticated distillation algorithms.

Overall, the results show that HAWQ-V3 achieves comparable accuracy to prior quantization methods
including both uniform and mixed-precision quantization (e.g., PACT, RVQuant, OneBitwidth, HAQ which use FP32 arithmetic,
and/or non-standard bit precision such as 5 bits, or different bit-width for weights and activations).
Similar observations hold for InceptionV3, as reported in Table [1c](#S4.T1.sf3 "In Table 1 ‣ 4 Results ‣ HAWQ-V3: Dyadic Neural Network Quantization").

Table 2: Mixed-precision quantization results for ResNet18 and ResNet50 with different constraints.
Here, we abbreviate constraint level as “Level”.
Model Size as “Size”, Bit Operations as “BOPS”,
the speedup as compared to INT8 results as “Speed”, and Top-1 Accuracy as “Top-1”,
The last column of Top-1 represents results of HAWQ-V3 and HAWQV3+Dist.
Note that for uniform INT8 ResNet50 (ResNet18), the latency is 1.06ms (0.40ms) per images.

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | Level | Size (MB) | BOPS (G) | Speed | Top-1 |
| INT8 | – | 11.2 | 114 | 1x | 71.56 |
| Size | High | 9.9 | 103 | 1.03x | 71.20/71.59 |
| Medium | 7.9 | 98 | 1.06x | 70.50/71.09 |
| Low | 7.3 | 95 | 1.08x | 70.01/70.66 |
| BOPS | High | 8.7 | 92 | 1.12x | 70.40/71.05 |
| Medium | 6.7 | 72 | 1.21x | 70.22/70.38 |
| Low | 6.1 | 54 | 1.35x | 68.72/69.72 |
| Latency | High | 8.7 | 92 | 1.12x | 70.40/71.05 |
| Medium | 7.2 | 76 | 1.19x | 70.34/70.55 |
| Low | 6.1 | 54 | 1.35x | 68.56/69.72 |
| INT4 | – | 5.6 | 28 | 1.48x | 68.45 |

(a) ResNet18

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | Level | Size (MB) | BOPS (G) | Speed | Top-1 |
| INT8 | – | 24.5 | 247 | 1x | 77.58 |
| Size | High | 21.3 | 226 | 1.09x | 77.38/ 77.58 |
| Medium | 19.0 | 197 | 1.13x | 75.95/76.96 |
| Low | 16.0 | 168 | 1.18x | 74.89/76.51 |
| BOPS | High | 22.0 | 197 | 1.16x | 76.10/76.76 |
| Medium | 18.7 | 154 | 1.23x | 75.39/76.73 |
| Low | 16.7 | 110 | 1.30x | 74.45/76.03 |
| Latency | High | 22.3 | 199 | 1.13x | 76.63/76.97 |
| Medium | 18.5 | 155 | 1.21x | 74.95/76.39 |
| Low | 16.5 | 114 | 1.28x | 74.26/76.19 |
| INT4 | – | 13.1 | 67 | 1.45x | 74.24 |

(b) ResNet50

### 4.2 Mixed-precision Results with Different Constraints

Here, we discuss various scenarios where different constraints could
be imposed for quantization, and the interesting trade-offs associated with each scenario.
The ILP problem in Eq. [8](#S3.E8 "In 3.4 Mixed Precision and Integer Linear Programming ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization") has three constraints of
model size, BOPS, and latency.
We consider three different thresholds
for each of the constraints and study how the ILP balances the trade-offs to obtain an optimal
quantized model.
We also focus on the case, where the practitioner is not satisfied with the
performance of the INT4 quantization and wants to improve the performance (accuracy, speed, and
model size) through mixed-precision quantization (INT4 and INT8).
The ILP formulation enables the practitioner to set each or all of these constraints.
Here, we present results when only one of these constraints is set at a time.
The results are shown in Table [2](#S4.T2 "Table 2 ‣ 4.1 Low Precision Integer-Only Quantization Results ‣ 4 Results ‣ HAWQ-V3: Dyadic Neural Network Quantization"), which is split into three sections of Size (model size), BOPS, and Latency. Each section represents the corresponding
constraint as specified by the practitioner. The ILP solver then finds the optimal
mixed-precision setting to satisfy that constraint, while maximizing accuracy.
See Appendix [I](#A9 "Appendix I ILP Result Interpolation ‣ HAWQ-V3: Dyadic Neural Network Quantization") for the example of the latency constraint for ResNet18.

We start with the model size and BOPS constraints for ResNet18.
The model size of pure INT4 quantization is 5.6MB, and INT8 is 11.2MB.
However, the accuracy of INT4 quantization is 68.45% which maybe low
for a particular application. The practitioner then has the option to
set the model size constraint to be slightly higher than pure INT4.
One option is to choose 7.9MB which is almost in between INT4 and INT8.
For this case, the ILP solver finds a bit-precision setting that results
in 71.09% accuracy which is almost the same as INT8. This model
is also 6% faster than INT8 quantization.

Another possibility is to set the speed/latency as a constraint.
The results for this setting are represented under the “Latency” row in Table [2](#S4.T2 "Table 2 ‣ 4.1 Low Precision Integer-Only Quantization Results ‣ 4 Results ‣ HAWQ-V3: Dyadic Neural Network Quantization").
For example, the practitioner could request the ILP to find a bit-precision
setting that would result in 19% faster latency as compared to the INT8 model (see “Medium” row).
This results in a model with an accuracy of 70.55% with a model size of only 7.2MB.
A similar constraint could also be made for BOPS.

Several very interesting observations can be made from these results.
(i) The correlation between model size and BOPS is weak which is expected. That is a larger model size does not mean higher BOPS and vice versa.
For example, compare Medium-Size and High-BOPS for ResNet18.
The latter has lower BOPS despite being larger (and is actually faster as well).
(ii) The model size does not directly correlate with accuracy.
For example, for ResNet50, High-BOPS has a model size of 22MB and accuracy
of 76.76%, while High-Size has a smaller model size of 21.3MB but higher accuracy of 77.58%.

In summary, although directly using INT4 quantization may result in large accuracy degradation, we can achieve significantly improved
accuracy with much faster inference as compared to INT8 results. This gives the practitioner a wider range of choices beyond
just INT8 quantization.
Finally, we should mention that the accuracy and speed for all of the results shown for ResNet18/50 and InceptionV3 have been verified
by directly measuring them when executed in quantized precision in hardware through TVM. As such, these results are actually
what the practitioner will observe, and these are not simulated results.

## 5 Conclusions

In this work, we presented HAWQ-V3, a new low-precision integer-only quantization framework,
where the entire inference is executed with only integer multiplication, addition,
and bit shifts. In particular, no FP32 arithmetic or even integer division is used in the entire inference.
We presented results for uniform and mixed-precision INT4/8.
For the latter, we proposed a hardware-aware ILP based method that
finds the optimal trade-off between model perturbation and application
specific constraints such as model size, inference speed, and total BOPS.
The ILP problem can be solved very efficiently, under a second for all the models considered here.
We showed that our approach can achieve up to 5% higher accuracy as
compared to the prior integer-only approach of [[30](#bib.bib30)].
Finally, we directly implemented the low-precision quantized models
in hardware by extending TVM to support INT4 and INT4/8 inference.
We verified all the results, by matching the activation of each layer
with our PyTorch framework (up to machine precision), including the verification of
the final accuracy of the model.
The framework, the TVM implementation, and the quantized models have been open sourced [[23](#bib.bib23)].

## Acknowledgments

The UC Berkeley team also acknowledges gracious support from Samsung (in particular Joseph Hassoun), Intel corporation, Intel VLAB team, Google TRC team, and Google Brain (in particular Prof. David Patterson, Dr. Ed Chi, and Jing Li).
Amir Gholami was supported through through funding from Samsung SAIT.
Michael W. Mahoney would also like to acknowledge the UC Berkeley CLTC, ARO, NSF, and ONR.
Our conclusions do not necessarily reflect the position or the policy of our sponsors, and no official endorsement should be inferred.

## Appendix A Deployment Frameworks

A number of frameworks [[33](#bib.bib33), [7](#bib.bib7), [2](#bib.bib2), [50](#bib.bib50), [45](#bib.bib45), [19](#bib.bib19), [56](#bib.bib56), [8](#bib.bib8)] have
been developed for deep learning. Many [[33](#bib.bib33), [7](#bib.bib7), [2](#bib.bib2), [45](#bib.bib45)] offer a dataflow DAG abstraction for specifying NN workloads and provide optimization support for inference as well as training with automatic differentiation.
These frameworks significantly reduce development cycles for deep learning algorithms and thus facilitate innovations in deep learning.
However, a majority of these frameworks [[33](#bib.bib33), [7](#bib.bib7), [45](#bib.bib45)] adopt a library-based approach that maps the NN operations to
hardware through existing high-performance libraries, such as cuDNN [[9](#bib.bib9)] for GPUs, and GEMMLOWP [[31](#bib.bib31)] and NNPACK [[15](#bib.bib15)] for CPUs.
These libraries currently do not support low-precision inference (INT4),
and since they are not open source we could not add that functionality.
As such, for our analysis we adopted to use TVM [[8](#bib.bib8)],
which provides
a general graph and a tensor expression intermediate representation (IR)
to support automatic code transformation and generation.
TVM also equips a QNN dialect [[32](#bib.bib32)] to compile the quantization-specific operators of a quantized model.
We choose TVM as our deployment framework for several reasons including:
(i) its extensive support in the frontend high-level frameworks and the backend hardware platforms; and
(ii) its decoupled IR abstraction that separates the algorithm specifications and the
scheduling decisions.
Augmenting TVM with our mixed-precision quantization support allows this optimization
to be used by NNs written in different frameworks as well as for various target
hardware platforms.
In addition, the decoupled IR design in TVM allows the mixed-precision quantization
optimization to be applied without affecting the specification of algorithms.

## Appendix B Quantization Method

Symmetric and Asymmetric Quantization.
For uniform quantization, the scaling factor $S$ is chosen to equally partition the range of real
values $r$ for a given bit width:

|  |  |  |
| --- | --- | --- |
|  | $\small S=\frac{r\_{max}-r\_{min}}{2^{b}-1},$ |  |

where $r\_{max},\ r\_{min}$ denotes the max/min value of the real values, and $b$ is the quantization bit
width. This approach is referred to as *asymmetric quantization*.
It is also possible to use a *symmetric quantization* scheme
where $S={2\max(|r\_{max}|,|r\_{min}|)}/{(2^{b}-1)}$ and $Z=0$ (since zero will be exactly represented).
As such, the quantization mapping can be simplified as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small Q(r)=\text{Int}\left(\frac{r}{S}\right).$ |  | (12) |

Conversely, the real values $r$ could be recovered from the quantized values $Q(r)$ as follows:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\tilde{r}=S\penalty\ Q(r).$ |  | (13) |

Note that the recovered real values $\tilde{r}$ will not exactly
match $r$ due to the rounding operation.
For HAWQ-V3, we use symmetric quantization for weights and asymmetric quantization for the activations.

Static and Dynamic Quantization.
The scaling factor $S$ depends on $r\_{max}$ and $r\_{min}$.
These can be precomputed for weights. However, for activations, each input will have a
different range of values across the NN layers.
In dynamic quantization, this range and the corresponding scaling factor is computed for each activation map during runtime.
However, computing these values during inference has high
overhead.
This can be addressed with static quantization, in which this range is pre-calculated during the quantization phase and made independent of the input data, by analyzing the range of activations for different batches.
We use static quantization for all of the experiments with HAWQ-V3.
With these definitions, we next discuss how quantized inference is performed.

## Appendix C Fake Quantization for Convolution

In simulated quantization (also referred to as fake quantization in literature), all the calculations happen in FP32, which is different from the approach we used in Section [3.1](#S3.SS1 "3.1 Quantized Matrix Multiplication and Convolution ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization").
Similar to Section [3.1](#S3.SS1 "3.1 Quantized Matrix Multiplication and Convolution ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization"), suppose that the hidden activation is $h=S\_{h}q\_{h}$ and weight tensor is $W=S\_{w}q\_{w}$.
In fake quantization, the output is calculated as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small a=(S\_{w}q\_{w})\*(S\_{h}q\_{h}).$ |  | (14) |

That is the weight and activation are first represented back to FP32 precision,
and then the calculation is performed.
This result is then requantized and sent to the next layer as follows:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $q\_{a}=\text{Int}\left(\frac{a}{S\_{a}}\right),$ |  | (15) |

where $S\_{a}$ is the pre-calculated scale factor for the output activation.
However, notice that here the requantization operation requires FP32 arithmetic (division by $S\_{a}$), which is different from HAWQ-V3’s Dyadic arithmetic that only uses integer operations.
Figure [C.1](#A3.F1 "Figure C.1 ‣ Appendix C Fake Quantization for Convolution ‣ HAWQ-V3: Dyadic Neural Network Quantization") shows the illustration of fake vs true quantization for a convolution (fully-connected) layer, without the BN layer. We also
showed the corresponding illustration when BN is used in Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ HAWQ-V3: Dyadic Neural Network Quantization").

Figure C.1: 
Illustration of fake vs true quantization for a convolution (fully-connected) layer.
(Left) In the simulated quantization (aka fake quantization), weights and activations
are simulated as integers with floating point representation, and all the multiplication
and accumulation happens
in FP32 precision.
However, with this approach, one cannot benefit from low-precision ALUs.
(Right) An illustration of the integer-only pipeline with integer-only quantization.
Note that with this approach, all the weights and activations
are stored in integer format, and all the multiplications are performed with INT4 and accumulated in INT32 precision.
Finally, the accumulated result is requantized to INT4 with dyadic scaling (denoted by $(\frac{S\_{w}S\_{h}}{S\_{a}}$)). Importantly, no floating point or even
integer division is performed.

## Appendix D Batch Normalization Fusion

During inference, the mean and standard deviation used in the BN layer are the running statistics (denoted as $\mu$ and $\sigma$).
Therefore, the BN operation can be fused into the previous convolutional layer.
That is to say, we can combine BN and CONV into one operator as,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\begin{split}\text{CONV\\_BN}(h)&=\beta\frac{Wh-\mu}{\sigma}+\gamma\\ &=\frac{\beta W}{\sigma}h+(\gamma-\frac{\beta\mu}{\sigma})\equiv\bar{W}h+\bar{b},\end{split}$ |  | (16) |

where $W$ is the weight parameter of the convolution layer and $h$ is the input feature map.
In HAWQ-V3, we use the fused BN and CONV layer and quantize $\bar{W}$ to 4-bit or 8-bit based on the setting, and quantize the bias term, $\bar{b}$ to 32-bit.
More importantly, suppose the scaling factor of $h$ is $S\_{h}$ and the scaling factor of $\bar{W}$ is $S\_{\bar{W}}$.
The scaling factor of $\bar{b}$ is enforced to be

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small S\_{\bar{b}}=S\_{h}S\_{\bar{W}}.$ |  | (17) |

So that the integer components of $\bar{W}h$ and $\bar{b}$ can be directly added during inference.

## Appendix E Concatenation Layer

The concatenation operation in Inception is an important component, which needs to be quantized carefully to avoid significant accuracy degradation.
Concatenation layers are often used in the presence of pooling layers and other convolutions
(a good example is the inception family of NNs).
In HAWQ-V3, we use INT32 for the pooling layer since performing pooling on 4-bit can result in significant information loss. Furthermore, we perform separate dyadic arithmetic for the following concatenation operator in the inception module.
Suppose the input of a concatenation block is denoted as $h=S\_{h}q\_{h}$, the output of the three
convolutional branches are $m=S\_{m}q\_{m}$, $n=S\_{n}q\_{n}$, and $l=S\_{l}q\_{l}$, the output of the pooling branch is $p=S\_{p}q\_{p}$, and the
final output is $a=S\_{a}q\_{a}$.

The pooling branch directly takes $h$ as input, and the rest of the three convolutional branches take the quantized 4-bit tensor as input.
After the computation of four separate branches, the output $q\_{a}$ is calculated with four DN operators:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small q\_{a}=\sum\_{i\in\{m,n,l\}}\text{DN}\left(\frac{S\_{i}}{S\_{a}}\right)q\_{i}+\text{DN}\left(\frac{S\_{p}}{S\_{a}}\right)q\_{p}.$ |  | (18) |

This scheme is represented in Figure [E.1](#A5.F1 "Figure E.1 ‣ Appendix E Concatenation Layer ‣ HAWQ-V3: Dyadic Neural Network Quantization").

Figure E.1: 
Illustration of HAWQ-V3 for an inception module.
Input feature map is given in INT32 precision, which is requantized to
INT4 precision (green boxes) before
being passed to the three convolutional branches.
The pooling layer, however, is performed on the original input feature
map in INT32. This is important since performing pooling on 4-bit data
can result in significant information loss.
The outputs for all the branches are scaled and requantized before being
concatenated.

## Appendix F Fake Quantization for Residual Connection

Similar to Section [3.3](#S3.SS3 "3.3 Residual Connection ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization"),
Let us denote the activation passing through the residual connection as
$r=S\_{r}q\_{r}$.
the activation of the main branch before residual addition as
$m=S\_{m}q\_{m}$. the final output after
residual accumulation as $a=S\_{a}q\_{a}$.
In fake quantization, the output $a$ is calculated in FP32 as,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small a=S\_{r}q\_{r}+S\_{m}q\_{m}.$ |  | (19) |

Afterwards, requantization is performed,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small q\_{a}=\text{Int}(\frac{S\_{r}q\_{r}+S\_{m}q\_{m}}{S\_{a}}),$ |  | (20) |

where the Int operator requires FP32 multiplication.

Similarly, fake quantization for concatenation layer is calculated as (see Appendix [E](#A5 "Appendix E Concatenation Layer ‣ HAWQ-V3: Dyadic Neural Network Quantization") for notations):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small q\_{a}=\text{Int}(\frac{m+n+l+p}{S\_{a}}).$ |  | (21) |

## Appendix G Error Accumulation of Fake Quantization

Figure G.1: The normalized difference between activation tensors in TVM and activation tensors in
PyTorch during inference. The normalized difference is the $L\_{2}$ norm of the difference between two activation counterparts divided by the $L\_{2}$ norm of the TVM activation tensor.

There has been a common misunderstanding that
using fake quantization is acceptable since one
can use FP32 precision to perform Integer operations exactly.
First, this is only true if the matrix multiplications
only use integer numbers, without using very large numbers.
The latter is the case in most ML applications.
However, the problem is that many quantization approaches use
fake quantization in a way that is different than the above argument.

For example, keeping the BN parameters in FP32 and not quantizing them
is a major problem. It is not possible to simply ignore that and deploy
a quantized model with FP32 BN parameters on integer-only hardware.
This difference was discussed and illustrated in Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ HAWQ-V3: Dyadic Neural Network Quantization").

Another very important subtle issue is how the residual connection is treated.
As discussed in the previous section, the fake quantization approaches use
FP32 arithmetic to perform the residual addition. The common (but incorrect)
argument here again is that the INT arithmetic can be performed without error with
FP32 logic. However, this is not the problem, since there is a subtle difference
in how requantization is performed.
In fake quantization, the results are first accumulated in FP32 and then requantized.
However, it is not possible to perform such an operation on integer-only hardware, where the results are always quantized and then accumulated.
This difference can actually lead to O(1) error.

For example consider the following case: assume $S\_{a}=1$, $r=2.4$, $m=4.4$ (see definition in Appendix [F](#A6 "Appendix F Fake Quantization for Residual Connection ‣ HAWQ-V3: Dyadic Neural Network Quantization")), and the requantization operator (Int) uses the “round to the nearest integer”.
Then using fake quantization, the output $q\_{a}$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small q\_{a}=\text{Int}(4.4+2.4)=7.$ |  | (22) |

However for true quantization, the output $q\_{a}$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small q\_{a}=\text{Int}(4.4)+\text{Int}(2.4)=6.$ |  | (23) |

This is an O(1) error that will propagate throughout the network. Also
note that the problem will be much worse for low precision error. This is because
an O(1) error for INT8 quantization is equivalent to a constant times (1/256), while
for INT4 quantization it will be a constant times (1/16).

We also performed a realistic example on ResNet50 for the uniform quantization
case.
We perform fake quantization in PyTorch for fine-tuning and then deploy the model in TVM
using integer-only arithmetic.
Afterwards, we calculate the error between the feature map of PyTorch (fake quantization) and TVM (integer-only).
In particular, we measure the normalized difference using $L\_{2}$ norm:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\small\text{Normalized\\_Difference}=\frac{\|x\_{1}-x\_{2}\|}{\|x\_{1}\|},$ |  | (24) |

where $x\_{1},\ x\_{2}$ are the feature maps with fake quantization and the corresponding values calculated
in hardware with integer-only arithmetic.
In Figure [G.1](#A7.F1 "Figure G.1 ‣ Appendix G Error Accumulation of Fake Quantization ‣ HAWQ-V3: Dyadic Neural Network Quantization") we show the normalized difference between activation tensors in TVM and activation tensors in PyTorch during inference.
As one can see, the numerical differences of the first layers are relatively small.
However, this error accumulates throughout the layers and becomes quite significant in the last layers.
Particularly, for uniform 4-bit quantization, the final difference becomes $>95\%$.

## Appendix H Implementation Details

#### Models

All the empirical results are performed using pretrained models from
PyTorchCV [[1](#bib.bib1)] library.
In particular, we do not make any architectural changes to the models, even though doing so might
lead to better accuracy.
We consider three NN models, ResNet18, ResNet50, and InceptionV3, trained on
the ImageNet dataset [[12](#bib.bib12)].
For all the NNs, we perform BN folding to speed up
the inference.
All the calculations during inference are performed using dyadic arithmetic (i.e., integer addition, multiplication, and bit shifting),
with no floating point or integer division anywhere in the network, including
requantization stages.

#### Training details

We use PyTorch (version 1.6) for quantizing models with HAWQ-V3.
For all the quantization results, we follow the standard practice of keeping the first and last layer in 8-bit (note that input data
is encoded with 8-bits for the RGB channels, which is quantized with symmetric quantization).
We only use uniform quantization along with channel-wise symmetric quantization for weights, and we use layer-wise asymmetric quantization for activations.
In order to perform static quantization, we set our momentum factor of quantization range (i.e., minimum and maximum) of activations to be 0.99 during training.
Although further hyperparameter tuning may achieve better accuracy, for uniformity, all our experiments are conducted using
learning rate 1e-4, weight decay 1e-4, and batch size 128.

#### Distillation

As pointed out previously [[46](#bib.bib46)], for extra-low bit quantization
(in our case uniform 4 bit and mixed 4/8 bit quantization), distillation may alleviate the performance degradation from quantization.
Therefore, in addition to our basic results, we also present results with distillation (denoted with HAWQV3+Dist).
Among other things, we do confirm the findings of previous work [[46](#bib.bib46)] that distillation can boost the accuracy of quantized models.
For all different models, we apply ResNet101 [[24](#bib.bib24)] as the teacher,
and the quantized model as the student.
For simplicity, we directly use the naive distillation method proposed in [[25](#bib.bib25)].
(More aggressive distillation or fine-tuning with hyperparameter may lead to better results).

#### Latency Measurement

We use TVM to deploy and tune the latency of
the quantized models using Google Cloud Platform virtual machines with Tesla T4 GPUs and CUDA 10.2.
We build the same NN models in TVM and tune the layerwise performance by using the autotuner.
Once we have the tuned models, we run the end-to-end inference multiple times to measure the average latency.
For the accuracy test, we load the parameters trained from PyTorch and preprocess it to the corresponding data layout that TVM requires.
Then, we do inference in TVM and verify that the final accuracy matches the results in PyTorch.

#### Mixed-precision configuration

For mixed-precision configuration,
we first compute the trace of each layer [[14](#bib.bib14)] using PyHessian [[61](#bib.bib61)], and then solve the ILP problem using PULP [[48](#bib.bib48)].
Our mixed-precision ILP problem can find the right bit-precision configuration with orders of magnitude faster run time, as compared to the RL based method [[57](#bib.bib57), [58](#bib.bib58)].
For instance, the entire trace computation can be finished within 30 minutes for all layers of ResNet50/InceptionV3 with only 4 RTX 6000 GPUs.
Afterward, the ILP problem can be solved in less than a second
(on a 15 inch MacBook Pro), as compared to more than 10/50 hours searching using RL [[57](#bib.bib57)] with 4 RTX 6000 GPUs.

## Appendix I ILP Result Interpolation

Figure I.1: 
Illustration of the final model specification that the ILP solver finds
for ResNet18 with latency constraint.
The black line shows the percentage of latency reduction for
a layer executed in INT4 versus INT8, normalized by total inference reduction.
Higher values mean higher speedup with INT4.
The orange line shows the sensitivity difference between INT8 and INT4 quantization using second order Hessian sensitivity [[14](#bib.bib14)].
The bit-precision setting found by ILP is shown in bar plots, with
the blue and taller bars denoting INT8, and cyan and shorter
bars denoting INT4.
Each row corresponds to the three results presented in Table [2a](#S4.T2.sf1 "In Table 2 ‣ 4.1 Low Precision Integer-Only Quantization Results ‣ 4 Results ‣ HAWQ-V3: Dyadic Neural Network Quantization")
with latency constraint.
For the low latency constraint, the ILP solver
favors assigning INT4 for layers that exhibit large gains in latency when executed
in INT4 (i.e., higher values in dark plot) and that have low sensitivity (lower values
in the orange plot).

We plot the bit-precision setting for each layer of ResNet18 that the ILP solver finds for different latency constraints, as shown in Figure [I.1](#A9.F1 "Figure I.1 ‣ Appendix I ILP Result Interpolation ‣ HAWQ-V3: Dyadic Neural Network Quantization").
Additionally, we also plot the sensitivity ($\Omega\_{i}$ in Eq. [8](#S3.E8 "In 3.4 Mixed Precision and Integer Linear Programming ‣ 3 Methodology ‣ HAWQ-V3: Dyadic Neural Network Quantization")) and the corresponding speed up for each layer computed by quantizing the
respective layer in INT8 quantization versus INT4.
As can be seen, the bit configuration chosen by the ILP solver is highly intuitive based
on the latency speed-up and the sensitivity.
Particularly, when the mixed-precision model is constrained by the High-Latency setting (the first row of Figure [I.1](#A9.F1 "Figure I.1 ‣ Appendix I ILP Result Interpolation ‣ HAWQ-V3: Dyadic Neural Network Quantization")),
only relatively insensitive layers, along with those that enjoy high INT4 speed-up, are quantized (i.e., layers 9, 14, and 19).
However, for the more strict Low-Latency setting (last row of Figure [I.1](#A9.F1 "Figure I.1 ‣ Appendix I ILP Result Interpolation ‣ HAWQ-V3: Dyadic Neural Network Quantization")),
only very sensitive layers are kept at INT8 precision (layer 1, 2, 3, 5, and 7).77
7
Note that here layer 7 is the downsampling layer along with layer 5, so it is in the same bit setting as layer 5 even though the latency gain of layer 7 is limited.
