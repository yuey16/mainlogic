<!-- fulltext source=arxiv_html slug=arXiv-1912.01274 fetched=2026-09-21T06:43:34+00:00 -->

# The Knowledge Within: Methods for Data-Free Model Compression

Matan Haroush, Itay Hubara
Affiliation: Habana Labs Research, Caesarea, Israel
Affiliation: Department of Electrical Engineering, Technion, Haifa , Israel
  
{mharoush,ihubara,ehoffer}@habana.ai,
daniel.soudry@gmail.com
  
Elad Hoffer
Affiliation: Habana Labs Research, Caesarea, Israel
  
Daniel Soudry
Affiliation: Department of Electrical Engineering, Technion, Haifa , Israel
  
{mharoush,ihubara,ehoffer}@habana.ai,
daniel.soudry@gmail.com

###### Abstract

Background: Recently, an extensive amount of research has been focused on compressing and accelerating Deep Neural Networks (DNN). So far, high compression rate algorithms require part of the training dataset for a low precision calibration, or a fine-tuning process. However, this requirement is unacceptable when the data is unavailable or contains sensitive information, as in medical and biometric use-cases.

Contributions: We present three methods for generating synthetic samples from trained models. Then, we demonstrate how these samples can be used to calibrate and fine-tune quantized models without using any real data in the process. Our best performing method has a negligible accuracy degradation compared to the original training set. This method, which leverages intrinsic batch normalization layers’ statistics of the trained model, can be used to evaluate data similarity. Our approach opens a path towards genuine data-free model compression, alleviating the need for training data during model deployment.

Figure 1: Synthetic samples generated from ResNet-18 trained on Imagenet, using our methods: $BNS$ (right;[3.3](#S3.SS3 "3.3 BN-Statistics Scheme ‣ 3 Methods for data-free distillation ‣ The Knowledge Within: Methods for Data-Free Model Compression")) and the class-conditional $BNS+\mathcal{I}$ (left;[3.4](#S3.SS4 "3.4 Combining 𝐵⁢𝑁⁢𝑆+ℐ ‣ 3 Methods for data-free distillation ‣ The Knowledge Within: Methods for Data-Free Model Compression")). Additional samples are available in appendix-[C](#A3 "Appendix C Generating CIFAR10 and ImageNet ‣ The Knowledge Within: Methods for Data-Free Model Compression").

## 1 Introduction

Quantization is a prevalent, accelerator friendly, compression method [[13](#bib.bib13), [15](#bib.bib15)] employed prior to DNNs deployment within real-world applications. However, high compression rates typically demand additional information to minimize quality loss. For example, when using low precision arithmetic, it is often beneficial to trade-off the numerical representation range with its resolution by clipping the dynamic range based on its real expected values. Thus, it is a common practice to gather per tensor statistics [[15](#bib.bib15), [1](#bib.bib1)] from a subset of samples drawn from the training set (Calibration). Furthermore, in cases of very high compression rates, model parameters often require additional adjustment to recover from catastrophic error accumulation, where access to the entire training data is needed.
This may lead to an undesired coupling between deployment and training phases of a model through data. Especially in cases where the training data is sensitive or simply unavailable at the time of deployment. Therefore, it is appealing to investigate new methods to alleviate the need for real data for deployment purposes, for example, via substitution with synthetic data.

Generating high-quality samples requires capturing the prior distribution of the data which is often hard. A large body of work dedicated to generative models has shown that it is possible to learn such priors and generate high-resolution synthetic images [[16](#bib.bib16), [6](#bib.bib6), [27](#bib.bib27), [9](#bib.bib9), [4](#bib.bib4)]. Unfortunately, these techniques come at the cost of training a dedicated generative model. This training requires access to the real training data which we want to avoid.

We aim to understand the potential and limitations of synthetic samples for model compression tasks, specifically for reduced precision deployment i.e., calibration and fine-tune via Knowledge Distillation (KD [[10](#bib.bib10)]). In the context of this work, the full precision model (or parts of it) serves as the teacher, while the student is the low precision counterpart. We will focus our attention on DNNs for classification tasks (e.g. CIFAR and ImageNet [[18](#bib.bib18), [26](#bib.bib26)]). In the process, we revisit a feature visualization process dubbed ”Inceptionism” [[22](#bib.bib22)] which is based solely on the trained model. This process typically starts with an arbitrary input, which is iteratively adjusted to maximize the response of a set of target features via back-propagation. Furthermore, the optimization process is typically constrained using some prior knowledge about the input, such as a high correlation between nearby pixels within an image, to avoid over-fitting the generated sample. A similar approach was recently adapted for several use-cases including for data-free distillation [[19](#bib.bib19), [3](#bib.bib3), [24](#bib.bib24)] with limited success.

Our contribution is twofold: First, we offer novel methods for generating and leveraging synthetic samples for the use of knowledge distillation. These samples are created under a realistic data-free regime by exploiting the encapsulated knowledge within the provided model. We then empirically evaluate the usefulness of these samples for model compression, yielding comparable results to the original training dataset with minimal accuracy degradation. Second, we propose a novel approach for evaluating the similarity between a reference dataset and a set of arbitrary samples. In a nutshell, we suggest measuring the mean divergence of the second-order statistics drawn from a set of intermediate layers of a given model that was trained on the reference dataset (reference model). This can be done without relying on access to any real data by leveraging intrinsic measurements provided by Batch Normalization (BN) layers [[14](#bib.bib14)].

## 2 Related work

The notion of ”data-free” quantization was recently introduced by Nagel et al., [[23](#bib.bib23)] who proposed using the pre-determined measurements of batch-normalization statistics [[14](#bib.bib14)], that are gathered during training to determine the proper dynamic range for each layer. However, this method requires either access to all of the layers’ statistics or relying on a closed-form analytical solution for layers for which measurements are not available, based on their input distribution. Furthermore, this method is unable to handle cases where calibration leads to extreme degradation, so fine-tuning is required.

Previous work explored using data-free knowledge distillation for model compression by collecting metadata related to the statistics of a trained model output [[19](#bib.bib19), [3](#bib.bib3)]. In both cases, the generation scheme consists of sampling a set of random target tensors and minimizing the mean square error between the output and the sampled targets. Lopes et al.,[[19](#bib.bib19)] proposed collecting means and co-variance for a set of layers after training, while optimization targets are sampled per layer independently under multivariate Gaussian assumption. The authors mention this method fails to capture inter-layer relations and proposed an alternative approach to capture inter-layer relations via graph spectral analysis with compelling results for models trained on the MNIST dataset. However, this is impractical for large models or models with large input size, due to its computational cost.

Bhardwaj et al., [[3](#bib.bib3)] suggested it is sufficient to collect metadata from the layer before the linear classifier. Metadata collection is done by processing a small portion of the training set, clustering the high dimensional outputs and applying Principle Component Analysis (PCA) per cluster. The optimization target is based on the collected centroids and a random noise projected in the direction of the primary principle components. Bhardwaj et al., [[3](#bib.bib3)] presented a small set of experiments on CIFAR10 dataset, with relatively large degradation between real data to the generated samples.

Recently, Nayak et al., [[24](#bib.bib24)] proposed similar data-free method dubbed as zero-shot distillation, which relies solely on the final layer weights to compute a class similarity matrix. Then, sample soft targets via Dirichlet distribution for generating synthetic images. However, KD results on synthetic samples are only comparable to real data on easily separable datasets such as MNIST, while performing poorly on CIFAR10.

In this work, we aim to generate samples that mimic the training data distribution by some measure. This can be achieved with naive noise sampling according to the low-order statistics of original data, or by directly optimizing a similarity measure of the internal activations’ statistics in a trained model. In contrast to previous attempts [[19](#bib.bib19), [3](#bib.bib3)] which required sampling activation generated by real data, our method relies on low order statistics captured by existing BN layers (i.e., channel-wise mean and standard deviation). We then track the statistics induced by the synthetic samples and directly optimize a divergence score with respect to the reference set, while relying on the model structure to naturally maintain inter-layer statistics’ relations.

## 3 Methods for data-free distillation

We are interested in a data-free regime, wherein a model is given without its corresponding dataset used for training. This regime reflects a realistic scenario, as training data is often confidential or private. Therefore, we offer three methods for generating useful synthetic data for distillation and calibration:

* •

  Gaussian scheme: samples are randomly drawn from a Gaussian distribution.
* •

  Inception scheme: samples are generated via logit maximization (i.e., a special case of the Inceptionism scheme).
* •

  BN-Statistics scheme: samples are generated by optimizing a novel internal statistics’ divergence measure.

### 3.1 Gaussian Scheme

As a naive approximation of the original dataset, it is natural to consider a simple Gaussian generator (denoted as $\mathcal{G}$) with first and second moments defined to match the original input data. We suggest this alone may be sufficient for model calibration tasks required for low numerical precision inference, under mild compression demands. Such a generation scheme is appealing since an indefinite number of samples can be generated at will with minimal compute and storage requirements. However, as one would expect, under extreme compression demands, when the model parameters need to be adjusted (e.g., fine-tune using distillation), this method may prove to be insufficient.

Since this method does not preserve the original input’s structure, the internal activation’s statistics may differ significantly from the original statistic induced by the training data. This change can harm the model accuracy especially if it contains Batch-Normalization (BN) layers [[14](#bib.bib14)]. BN layers are commonly used in DNNs workloads, as they have been shown to improve both accuracy and speed of convergence by normalizing the input to the layer to have zero mean and unit variance before applying its operation. During training, each BN layer keeps a running estimate of the empirical mean and standard-deviation per-channel of its inputs which latter applied to normalized the input data during inference.

Adjusting the model’s parameters by using distillation over the randomly generated samples, will irretrievably alter the existing BN layer parameter to accommodate for the observed statistical properties, resulting in an imminent failure when turning back to evaluate real data. Thus, we suggest forcing all BN layers in the model to maintain their original running estimates for evaluation. As shown in section [4](#S4 "4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression") this may negate this obstacle to some extent, enabling the use of such samples for the task of distillation.

### 3.2 Inception Scheme

Inceptionism [[22](#bib.bib22)] related generation schemes, typically impose constraints solely on the input and output of the model. We shall focus on a special case, which we term the Inception scheme (denoted as $\mathcal{I}$), where only a single neuron from the final model output is maximized under an input smoothness requirement.
We define the optimization objective is the sum of a Domain Prior term and an Inception loss term. As a domain prior, we use a Gaussian smoothing kernel to produce a smoothed version of the provided input. The loss term is then computed as the mean squared error between the input image and the smoothed variant, encouraging nearby pixels to have similar values. The Inception Loss term is derived by choosing an arbitrary label and perform gradient descent on the negative exponent of the appropriate class logit drawn from the Fully Connected (FC) layer output, i.e. $e^{-logit/scale}$. The Inception Loss injects the desired class information, where the exponent and temperature-scale control the impact of the logit magnitude on the loss, preventing the model from producing inputs that cause the output to explode by exponentially decaying the logit contribution to the general loss as its magnitude increases. This scheme often results in high confidence outputs, however, it is highly sensitive to the hyper-parameters (see appendix-[A](#A1 "Appendix A Hyper-Parameters ‣ The Knowledge Within: Methods for Data-Free Model Compression")).

### 3.3 BN-Statistics Scheme

Based on our Gaussian and Inception scheme experiments we hypothesize that the lack of regularization on the internal statistic during the sample generation process may result in significant internal statistics’ divergence from the observed statistics on real data. Indicating such samples are not drawn from a distribution similar to the original data (as we show later, in Figure [2(a)](#S4.F2.sf1 "In Figure 2 ‣ 4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression")). This, in turn, may impede their use for model compression and KD. Thus, our proposed approach is to directly minimize the internal statistics’ divergence, by optimizing a novel measure which we term ”BN-Stats” (denoted as $BNS$). $BNS$ only assumes access to the predetermined empirical measurements that occur for each BN layer. We will use these estimates as targets and compare new data samples by the similarity between their measured statistics.

More formally, given the running estimates $\hat{\mu}$ and $\hat{\sigma}$ of a given batch-norm layer, we wish to measure $\tilde{\mu}=\mu(D)$ and $\tilde{\sigma}=\sigma(D)$ of our new data activations $D$ and evaluate their similarity to the reference statistics. $BNS$ define this similarity using the Kullback-Leibler (KL) divergence under a simplistic isotropic Gaussian assumption such that

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\begin{split}BNS(D,\hat{\mu},\hat{\sigma})&=KL\left(\mathcal{N}(\hat{\mu},\hat{\sigma}^{2})||\mathcal{N}(\tilde{\mu},\tilde{\sigma}^{2})\right)\\ &=\log\frac{\tilde{\sigma}}{\hat{\sigma}}-\frac{1}{2}\left(1-\frac{\hat{\sigma}^{2}+(\hat{\mu}-\tilde{\mu})^{2}}{\tilde{\sigma}^{2}}\right)\end{split}$ | |  | (1) |

Our generation process starts with a batch of random input samples, which are then iterativly adjusted to minimize the mean statistical divergence across all layers in the reference set. Namely, for each optimization step over an input batch $X$, we extract per-BN-layer activation set $\{D\_{l}\}\_{l=1}^{N}$. We then define the optimization objective as the mean statistics’ divergence over all $BNS(D\_{l},\hat{\mu}\_{l},\hat{\sigma}\_{l})$. Formally, we define the first and second moments sets as:

$T,S:=\{P\_{l}\sim\mathcal{N}(\hat{\mu}\_{l},\hat{\sigma}\_{l})\}\_{l=1}^{N},\{Q\_{l}\sim\mathcal{N}(\tilde{\mu}\_{l},\tilde{\sigma}\_{l})\}\_{l=1}^{N}$

while the optimization objective (i.e., BNS measure) is defined as the mean KL divergence on the set $\{T,S\}$, i.e.

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{J}\_{KL}(X|T,S):=\frac{1}{N}\sum\_{l=1}^{N}KL(P\_{l}||Q\_{l})$ |  | (2) |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle=\frac{1}{N}\sum\_{l=1}^{N}BNS(D\_{l},\hat{\mu}\_{l},\hat{\sigma}\_{l})$ |  | (3) |

A small $\epsilon=1e^{-8}$, is added to the measured variance of the induced synthetic distribution to accommodate for zero-variance channels. We note that alternative metrics can be used for $BNS$ under the same underlying assumptions, such as Mean Square Error over the empirical moments which is symmetric and can handle zero variance channels. Finally, standard backpropagation is used to adjust $X$.

### 3.4 Combining $BNS+\mathcal{I}$

In addition to the three schemes described above, we experiment with a combination of BN-Statistics and Inception schemes objectives denoted as $BNS+\mathcal{I}$, see Algorithm [1](#algorithm1 "In 3.4 Combining 𝐵⁢𝑁⁢𝑆+ℐ ‣ 3 Methods for data-free distillation ‣ The Knowledge Within: Methods for Data-Free Model Compression"). This method of generation attempts to harness the strength of each method. The class constraint imposed by $\mathcal{I}$ impacts the induced statistics depending on the batch composition, forcing the optimization process to compensate for the sampled classes. The drawback of this method is the additional loss scaling parameters which are now added to the original hyper-parameters of the Inception scheme. We didn’t exhaustively investigate the best method to combine the two however, results of a simple aggregation provides an encouraging improvement in some cases.

Algorithm 1 Generating $BNS+\mathcal{I}$ samples

```
Input: a pre-trained model with NN BN layers
Param: i​n​p​u​t​_​s​h​a​p​e,b​a​t​c​h​_​s​i​z​e,b​u​d​g​e​tinput\_shape,batch\_size,budget
Param: c​l​a​s​s​_​t​e​m​p,θp​r​i​o​r,α,β,γclass\_temp,\theta_{prior},\alpha,\beta,\gamma
Param: o​p​t​i​m​i​z​e​r​(θ),#​d​u​p​l​i​c​a​t​e​soptimizer(\theta),\#duplicates
Output: a batch of synthetic samples — Xb​u​d​g​e​tX_{budget}

1
Init: X0←r​a​n​d​n​(b​a​t​c​h​_​s​i​z​e,i​n​p​u​t​_​s​h​a​p​e)X_{0}\xleftarrow{}randn(batch\_size,input\_shape)

2
Init: t​a​r​g​e​t​s←r​a​n​d​_​i​n​t​(b​a​t​c​h​_​s​i​z​e,#​c​l​a​s​s​e​s)targets\xleftarrow{}rand\_int(batch\_size,\#classes) 

3
Extract T:={μ^l,σ^l}l=1NT:=\{\hat{\mu}_{l},\hat{\sigma}_{l}\}_{l=1}^{N} // Pl∼𝒩⁡(μ^l,σ^l)P_{l}\sim\mathcal{N}(\hat{\mu}_{l},\hat{\sigma}_{l}) 

4
while i<b​u​d​g​e​ti<budget do
     
5
Compute: Xi←c​l​a​m​p​(Xi,0,1)X_{i}\xleftarrow{}clamp(X_{i},0,1) 
     
6
Compute: X^i←a​u​g​m​e​n​t​(Xi,#​d​u​p​l​i​c​a​t​e​s)\hat{X}_{i}\xleftarrow{}augment(X_{i},\#duplicates) 
     
7
Compute: l​o​s​sp←p​r​i​o​r​(X^i|θp​r​i​o​r)loss_{p}\xleftarrow{}prior(\hat{X}_{i}|\theta_{prior}) // e.g. s​m​o​o​t​h​(X^i|k,σ)smooth(\hat{X}_{i}|k,\sigma)
     
8
Compute: l​o​g​i​t​s←f​o​r​w​a​r​d​(X^i)logits\xleftarrow{}forward(\hat{X}_{i}) 
     
9
Record: S:={μ~l,σ~l}l=1NS:=\{\tilde{\mu}_{l},\tilde{\sigma}_{l}\}_{l=1}^{N} // Ql∼𝒩⁡(μ~l,σ~l)Q_{l}\sim\mathcal{N}(\tilde{\mu}_{l},\tilde{\sigma}_{l})
     
10
Compute: l​o​s​si←e−l​o​g​i​t​s​[t​a​r​g​e​t​s]s​c​a​l​eloss_{i}\xleftarrow{}e^{-\frac{logits[targets]}{scale}} 
     
11
Compute: l​o​s​ss←𝒥K​L​(X^i|T,S)loss_{s}\xleftarrow{}\mathcal{J}_{KL}(\hat{X}_{i}|T,S) 
     
12
Compute: l​o​s​s←α∗l​o​s​ss+β∗l​o​s​si+γ∗l​o​s​sploss\xleftarrow{}\alpha*loss_{s}+\beta*loss_{i}+\gamma*loss_{p} 
     
13
Compute: GXi←b​a​c​k​w​a​r​d​(l​o​s​s,Xi)G_{X_{i}}\xleftarrow{}backward(loss,X_{i}) // i.e., ∂l​o​s​s∂Xi\frac{\partial loss}{\partial{X_{i}}}
     
14
Update: Xi+1←o​p​t​i​m​i​z​e​r.s​t​e​p​(GXi,θ)X_{i+1}\xleftarrow{}optimizer.step(G_{X_{i}},\theta) 
     
15
Update: i←i+1i\xleftarrow{}i+1
```

## 4 Experiments

### 4.1 Generating data samples

We first describe several components used in our sample generation methods. Specifically, note that $\mathcal{I}$ & $BNS$ can be seen as special cases of the $BNS+\mathcal{I}$ method, by scaling the appropriate loss components. $BNS+\mathcal{I}$ method is described in algorithm-[1](#algorithm1 "In 3.4 Combining 𝐵⁢𝑁⁢𝑆+ℐ ‣ 3 Methods for data-free distillation ‣ The Knowledge Within: Methods for Data-Free Model Compression"), the reader may refer to appendix-[A](#A1 "Appendix A Hyper-Parameters ‣ The Knowledge Within: Methods for Data-Free Model Compression") for specific hyperparameters details.

* •

  Inception Loss: The Inception loss is defined as the exponent of the negative value of the appropriate class logit drawn from the Fully Connected (FC) layer of the model i.e., $e^{-logit/scale}$. A random set of labels are chosen as targets.
* •

  Image Prior: Nearby pixels of an image often have similar values, common techniques attempt to encourage such relations. In practice we use a Gaussian smoothing prior, by applying a convolution with a Gaussian kernel on the input, creating a smoothed version that is then used to compute the mean squared error from the original input.
* •

  Statistics Loss: we define $\mathcal{J}\_{KL}$ as our statistics loss. Reference statistics are extracted from all BN layers in the model. Those are simply the running mean and variance gathered during training. Additionally, we treat the reported dataset normalization in the same manner.
* •

  Input Trimming: At the start of each optimization step we clip the input values to $[0,1]$ range to match real data values.
* •

  In-Batch Augmentations: Since activation gradients are not aggregated across batch during back standard propagation, we use in-batch augmentations [[11](#bib.bib11)] technique to gain a gradient smoothing effect per sample; Specifically, each sample is duplicated $N$ times with a set of random differential augmentations chosen from a set containing Random-N-Cutout, Crop-Resize and Flip.

Since the generation process must start with a previously trained model, we concentrate most of our experiments on ResNet meta-architecture [[8](#bib.bib8), [30](#bib.bib30)], as it is a popular example of an architecture in which training quality heavily relies on batch normalization layers.

### 4.2 Data-free model compression

General settings. Model compression for deployment usually requires some additional effort. The compression level correlates with the amount of information and work necessary to reduce accuracy degradation. Using low numerical precision as a model compression technique for inference typically requires a prior calibration step to determine the dynamic range (which sets the scale and zero-point values) [[17](#bib.bib17)] for each intermediate layer. This restriction sacrifices the dynamic range for an improved numerical resolution. When enforcing highly demanding compression rates on a model it is often required to retrain the model under similar compression constraints to recover from any significant accuracy loss. The process of adjusting the model parameters to the compression constrains is commonly called fine-tuning. Since each model responds differently to quantization, we choose numerical precision to ensure that calibration or fine-tuning is needed. We will consistently use the notation of $\#w\#a$, to denote the number of numerical precision bits used for representing the quantized activations and weights throughout the model.

In all our experiments the case of uniform quantization is considered, with per-channel scale for the weights and a per-tensor scale for the layer’s activation values as detailed in [[17](#bib.bib17)]. A copy of the weights [[13](#bib.bib13)], as well as the biases and gradients, are kept in single-precision where the latter is derived using a straight-through estimator [[2](#bib.bib2)]. All results are reported for simulated quantization (i.e. discretizing the inputs and weights before applying float operators). Additionally, Batch-Normalization layers were kept in single precision.

Calibration details. Our experiments begin by calibrating each model using real and synthetic data, under increasing compression rates. During calibration, we use a smoothed absolute dynamic range measurement. That is, the dynamic range is measured via running estimates of the mean absolute min/max values within chunks containing 16 samples each. We argue that more advanced calibration methods [[23](#bib.bib23), [1](#bib.bib1)] may improve final accuracy as they are uncoupled to our proposed approach of using synthetic data. Unless otherwise specified, 200 calibration steps are used with batch size 256. Samples are drawn with replacement out of a balanced dataset with size limited to $1\%$ of the training dataset size. Standard data augmentations (e.g., random crop and mirroring) are applied on each input batch to maximize the utilization of available data. Additionally, results are reported as mean and standard deviation with 5 different seeds.

Fine-tuning details. In our KD setting, the float model is the teacher while the student is its quantized variant. Specifically, we apply the most demanding configuration from the previous calibration experiment to create the student. Additionally, teacher predictions are used as targets without additional labels. Furthermore, optimization settings were fixed throughout each set of experiments to enable a fair comparison: all models are optimized with a fixed number of Stochastic Gradient Decent (SGD) iterations, the learning rate scheduler starts with a short warm-up phase followed by a cosine decay phase, while for each optimization step, a batch is drawn with replacement from the target dataset and augmented using standard augmentations methods. We also follow McKinstry et al., [[20](#bib.bib20)] and freeze the dynamic range of the student activations during the entire optimization process (we didn’t find the suggestion of freezing the dynamic range of the weights necessary).

We also take advantage of the shared teacher and student networks’ structure, and apply a simple tweak under the assumption that a good low precision proxy exists within the vicinity of the reference model in the parameters space. Specifically, we use intermediate layer outputs to compute the smoothed-$\ell\_{1}$ distance between the teacher and the student features, we named this loss Intermediate Quantization (IQ) loss. We found IQ generally lead to a more stable training convergence under extreme quantization and improve KD results for both synthetic and real samples. Additionally, we apply in batch MixUp technique on the inputs similar to [[31](#bib.bib31)], without mixing the teacher’s outputs. The full distillation process is illustrated by algorithm-[2](#algorithm2 "In 4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression"), along with an ablation experiment results (table-[1](#S4.T1 "Table 1 ‣ 4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression")).

Algorithm 2 Quantized Distillation with IQ

```
Input: T:T: the teacher model with parameters Θt\Theta_{t}
Input: L:={la​u​xi}NL:=\{l^{i}_{aux}\}^{N}: a set of auxiliary layers (e.g., pointers)
Input: 𝒟:\mathcal{D}: dataset
Param: c​r​i​t​e​r​i​o​nI​Q,c​r​i​t​e​r​i​o​nK​Dcriterion_{IQ},criterion_{KD}
Param: α,β,θm​i​x\alpha,\beta,\theta_{mix}
Param: q​u​a​n​t​i​z​e​r​(θq),o​p​t​i​m​i​z​e​r​(θo​p​t)quantizer(\theta_{q}),optimizer(\theta_{opt})
Output: a fine-tuned quantized model

1
Init: S←q​u​a​n​t​i​z​e​r​(T,𝒟,θq)S\xleftarrow{}quantizer(T,\mathcal{D},\theta_{q}) // quantize and calibrate the student

2
for Xi∈𝒟X_{i}\in\mathcal{D} do
     
3
Compute: X^i←I​n​p​u​t​M​i​x​(Xi,θm​i​x)\hat{X}_{i}\xleftarrow{}InputMix(X_{i},\theta_{mix}) 
     
4
Compute: l​o​g​i​t​st,a​u​xt←T.f​o​r​w​a​r​d​(X^i,L)logits_{t},aux_{t}\xleftarrow{}T.forward(\hat{X}_{i},L) 
     
5
Compute: l​o​g​i​t​ss,a​u​xs←S.f​o​r​w​a​r​d​(X^i,L)logits_{s},aux_{s}\xleftarrow{}S.forward(\hat{X}_{i},L) 
     
6
Compute: l​o​s​sI​Q←∑li∈Lc​r​i​t​e​r​i​o​nI​Q​(a​u​xtli,a​u​xsli)loss_{IQ}\xleftarrow{}\sum_{l_{i}\in L}{criterion_{IQ}(aux_{t}^{l_{i}},aux_{s}^{l_{i}})} // e.g., Smooth-L1 loss
     
7
Compute: l​o​s​sK​D←c​r​i​t​e​r​i​o​nK​D​(l​o​g​i​t​st,l​o​g​i​t​ss)loss_{KD}\xleftarrow{}criterion_{KD}(logits_{t},logits_{s}) // e.g., KL-Divergence loss
     
8
Compute: l​o​s​s←α∗l​o​s​sK​D+β∗l​o​s​sI​Qloss\xleftarrow{}\alpha*loss_{KD}+\beta*loss_{IQ} 
     
9
Compute: GS←b​a​c​k​w​a​r​d​(l​o​s​s,Θsi)G_{S}\xleftarrow{}backward(loss,\Theta^{i}_{s}) // i.e., ∂l​o​s​s∂Θsi,w​h​e​r​e​Θsi​a​r​e​t​h​e​w​e​i​g​h​t​s​o​f​S\frac{\partial loss}{\partial{\Theta^{i}_{s}}},\ where\ \Theta^{i}_{s}\ are\ the\ weights\ of\ S\ 
     
10
Update: Θsi+1←o​p​t​i​m​i​z​e​r.s​t​e​p​(GS,θo​p​t)\Theta^{i+1}_{s}\xleftarrow{}optimizer.step(G_{S},\theta_{opt})
```

Table 1: KD ablation study on input-mixing and IQ. We fine-tune a quantized ResNet-44 (2w4a, first & final layers are in 4 bits) on CIFAR10 dataset with varying dataset size.

| #samples | KD | KD+IQ | KD+Mix | KD+IQ+Mix |
| --- | --- | --- | --- | --- |
| 1 | 76.32 | 79.67 | 82.49 | 83.68 |
| 10 | 81.12 | 81.71 | 84.01 | 85.44 |
| 100 | 80.16 | 81.64 | 85.05 | 85.95 |
| 1000 | 84.03 | 84.66 | 87.2 | 87.28 |
| 2000 | 85.41 | 85.74 | 87.84 | 88.36 |

Small scale experimental details.
We wish to evaluate the applicability of synthetic samples for model calibration and distillation compared to real data. For this experiment we use ResNet44 and Wide-Resnet28-10 [[8](#bib.bib8), [30](#bib.bib30)] on CIFAR10, CIFAR100 datasets [[18](#bib.bib18)] respectively.

We start the process by following each of the proposed generation schemes to produce synthetic samples. Next, we apply increasingly demanding quantization configurations to the models and calibrate each variant using samples drawn from the target dataset which is limited to 50 samples per class. After the initial calibration, we optimize the selected models for 16,000 iterations of SGD with a batch size of 512 and 256 for ResNet44 and Wide-ResNet28-10 respectively. IQ loss is computed as the mean of the smoothed-l1 over the outputs of blocks 2-5 from ResNet architecture and multiplied by a scale of 0.001.

Table 2: CIFAR validation accuracy for low precision models using data from synthetic and real datasets. The Settings column refers to the number of bits used as well as the number of samples-per-class in the dataset. The Reference column presents the original training data results. Fine-tune (KD) and calibration with synthetic samples is on par compared to real data, while the results reflect the importance of using statistics preserving samples for demanding compression settings.11
1

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Settings | Reference | $BNS$ | $\mathcal{I}$ | $BNS+\mathcal{I}$ | $\mathcal{G}$ |
| ResNet-44 - CIFAR10, fp32 accuracy 93.23 | | | | | | |
| Calibration | 4w8a, 5011 1 | 92.18 (0.05) | 92.21 (0.03) | 92.37 (0.03) | 92.25 (0.04) | 92.24 (0.01) |
|  | 4w4a, 50 | 89.19 (0.15) | 88.5 (0.13) | 87.44 (0.13) | 89.1 (0.09) | 87.51 (0.18) |
|  | 2w4a, 5022 2 | 19.47 (0.16) | 19.14 (0.05) | 19.42 (0.2) | 19.49 (0.1) | 18.48 (0.2) |
| KD | 2w4a, 5022 2 | 90.27 | 88.52 | 79.62 | 88.16 | 70.03 |
|  | 2w4a, 400022 2 | 91.24 | 89.6 | 79.59 | 88.51 | 71.02 |
| Wide ResNet-28-10 - CIFAR100, fp32 accuracy 83.69 | | | | | | |
| Calibration | 8w8a, 50 | 82.96 (0.03) | 83.11 (0.04) | 83.01 (0.04) | 83.06 (0.02) | 83.15 (0.04) |
|  | 4w4a, 5011 1 | 76.96 (0.15) | 74.4 (0.11) | 62.78 (0.32) | 74.56 (0.15) | 58.79 (0.09) |
|  | 4w4a, 50 | 64.52 (0.15) | 61.48 (0.08) | 51.22 (0.23) | 61.82 (0.02) | 47.81 (0.19) |
| KD | 4w4a, 50 | 81.7 | 79.21 | 53.64 | 78.88 | 64.8 |
|  | 4w4a, 200 | 82.11 | 79.16 | 54.02 | 78.75 | 65.15 |

First & final layers are in 8 bits
22
2
First & final layers are in 4 bits

Small scale results. Results on post-calibration and KD fine-tuning are shown in table-[2](#footnotex7 "footnote 2 ‣ Table 2 ‣ 4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression"). We find that synthetic samples which minimize $BNS$ are superior to samples from other generation schemes, while achieving comparable accuracy to real data, as the fine-tuned models recover from extreme accuracy degradation. Additionally, we observe a surprising outcome regarding the usefulness of Gaussian samples for calibration and distillation — under mild compression requirements. We noticed that performing performing KD with Gaussian samples requires an additional step to freeze all batch normalization layers, to prevent corruption of the intermediates statistics of the original training data. We believe the full potential Gaussian samples are yet to be discovered and we encourage it as a future research direction. One simple path is truncating the model to disjoint intervals between BN layers then retrain each interval using KD over synthetic data generated by the applying Gaussian scheme on the statistics of the previous BN layer. We also note that Inception related schemes appear to be more sensitive to the hyper-parameters choice (see appendix-[A](#A1 "Appendix A Hyper-Parameters ‣ The Knowledge Within: Methods for Data-Free Model Compression")).

Large scale experimental details. To demonstrate the applicability of our findings in a large-scale setting, we provide our results on ImageNet [[26](#bib.bib26)]. ImageNet has been noted to be a challenging generative task even when full data access is granted, due to the relatively large spatial size of the data and the number of classes [[27](#bib.bib27)]. Previous work [[23](#bib.bib23)] showed that 8-bit models can be calibrated without any data if BN layers exist. However, they did not investigate more challenging numerical precision levels and thus did not need to fine-tune the model. We conduct our experiment with a pre-trained models from torchvision model-zoo [[25](#bib.bib25)]. First, we generate 10K/100k samples (see examples in appendix-[C](#A3 "Appendix C Generating CIFAR10 and ImageNet ‣ The Knowledge Within: Methods for Data-Free Model Compression")), then perform KD to fine-tune the quantized student, following similar settings to ones described in the previous section, except for a longer regime of 44000 steps and a batch size of 256. Throughout our experiments, the quantization scheme is fixed to a widely used method described in [[17](#bib.bib17)]. Methods that improve this scheme (such as bit allocation, bias correction [[1](#bib.bib1)], and equalization [[23](#bib.bib23), [21](#bib.bib21)]) are orthogonal to this work and are expected to improve accuracy respectively.

Table 3: ImageNet validation accuracy for low precision models using data from synthetic and real datasets. We use pre-trained weights from torchvision model-zoo [[25](#bib.bib25)] for several meta-architectures under varying compression settings. $BNS$ results are on par with the real data, while KD performs well on the limited size dataset compared to standard cross-entropy loss, see appendix-[B](#A2 "Appendix B Additional results for ImageNet dataset ‣ The Knowledge Within: Methods for Data-Free Model Compression") for more details.11
1

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Settings | Reference | $BNS$ | $\mathcal{I}$ | $BNS+\mathcal{I}$ | $\mathcal{G}$ |
| ResNet-18 [[8](#bib.bib8)] - ImageNet, fp32 accuracy - 69.75 | | | | | | |
| Calibration | 8w8a, 1011 1 | 69.63 (0.03) | 69.55 (0.01) | 69.6 (0.02) | 69.57 (0.04) | 68.94 (0.02) |
|  | 4w4a, 1022 2 | 54.72 (0.06) | 55.29 (0.1) | 38.25 (0.1) | 55.49 (0.06) | 53.02 (0.1) |
| KD | 4w4a, 1022 2 | 68.63 | 67.98 | 62.8 | 68.06 | 63.98 |
|  | 4w4a, 10022 2 | 68.68 | 68.14 | 63.1 | 67.95 | 63.58 |
| MobileNet-V2 [[28](#bib.bib28)] - ImageNet, fp32 accuracy - 71.88 | | | | | | |
| Calibration | 8w8a, 1011 1 | 71.26 (0.05) | 71.34 (0.03) | 71.2 (0.01) | 71.32 (0.04) | 71.17 (0.02) |
|  | 4w4a, 1033 3 | 15.1 (0.1) | 16.17 (0.1) | 10.55 (0.04) | 16.1 (0.06) | 13.36 (0.04) |
| KD | 4w4a, 1033 3 | 68.5 | 66.4 | 53.13 | 66.07 | 36.95 |
| DenseNet-121 [[12](#bib.bib12)] - ImageNet, fp32 accuracy - 74.65 | | | | | | |
| Calibration | 8w8a, 10 | 74.41 (0.01) | 74.41 (0.03) | 74.22 (0.02) | 74.23 (0.02) | 74.16 (0.02) |
|  | 4w4a, 10 | 45.27 (0.04) | 43.54 (0.15) | 40.46 (0.1) | 43.88 (0.09) | 46.89 (0.03) |
| KD | 4w4a, 10 | 71.08 | 71.26 | 63.98 | 70.72 | 63.59 |

Compared to [[23](#bib.bib23)] (without weights adjustments): 69.6, 69.7
22
2
First & final layers are in 8 bits
33
3
1x1 convolution layers are in 8 bits

Large scale results. Table-[3](#footnotex17 "footnote 3 ‣ Table 3 ‣ 4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression") presents promising results for recovering lost model accuracy on ImageNet classification task. To the best of the authors’ knowledge, this is the first time a compressed model was successfully fine-tuned without using any real data other than the trained model itself at this scale.

We observe an accuracy gap (relative 1.5% degradation) between standard Cross-Entropy (CE) objective and KD when fine-tuning the model with the full dataset is available. However, results are in favor of KD when using significantly fewer samples (a detailed comparison is available in appendix-[B](#A2 "Appendix B Additional results for ImageNet dataset ‣ The Knowledge Within: Methods for Data-Free Model Compression")). We believe this can be attributed to a couple of factors. First, semi-supervised KD does not use the ground truth label information. Thus, final accuracy depends solely on the prediction quality of the teacher, whereas label information can be used to penalize the student when repeating similar mistakes made by the teacher. Additionally, we speculate that a given bias in the reference model’s prediction towards certain classes may degrade the student accuracy when training on raw teacher outputs.

Finally, we conclude that using synthetic data leads to either equivalent or slightly lower final accuracy compared to real data. We associate the accuracy loss with the synthetic data optimization process (i.e. higher $\mathcal{J}\_{KL}$ than real data), as well as with the limited ability of the provided weights to capture the true variance of the data, which in turn leads to a limited sample space.

(a) Measured $BNS$ loss quickly diverges when optimizing Inception loss, indicating that the generated samples may be out of the original data distribution.

(b) Gaussian smoothing loss is decreasing during $BNS$ loss optimization, revealing a correlation between statistics loss and the spatial structure within feature maps.

Figure 2: Generating synthetic samples from ResNet-44 trained on CIFAR10.

### 4.3 Analysis of Data Generation Schemes

For this section we consider ResNet44 trained on CIFAR10 as the reference model, in an attempt to understand the relations between generation schemes and provide further explanation to the success of $BNS$ scheme over its counterparts. We will consider the differences between methods from the perspective of the optimization objectives for generating synthetic samples. Additionally, we evaluate the impact of the internal statistics’ divergence on KD’s potential for recovering lost accuracy.

Monitoring Internal Statistics.
As an initial step in our evaluation, we perform a pair of experiments on Inception and $BNS$ schemes. In each experiment, we follow the process of one scheme and observe the other’s objective behavior. More specifically, we generate a batch of samples using the Inception scheme while monitoring the behavior of the internal statistics through $\mathcal{J}\_{KL}$. For the alternative view, we generate a second batch of samples using the $BNS$ scheme, and observe the input smoothness loss. In both experiments, we perform 1000 optimization steps on a batch of 128 samples. For each iteration we use in-batch augmentations with N=4, additionally, a Gaussian kernel of size 3x3 and sigma=1 is used for the smoothing loss operation. Results are described in Figure [2](#S4.F2 "Figure 2 ‣ 4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression").

Under the Inception generation scheme, we find evidence for the divergence of the internal statistics as seen in figure [2(a)](#S4.F2.sf1 "In Figure 2 ‣ 4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression"). Additionally, figure [2(b)](#S4.F2.sf2 "In Figure 2 ‣ 4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression") indicates that minimizing $\mathcal{J}\_{KL}$ leads to lower smoothness loss. Interestingly, figure [2(a)](#S4.F2.sf1 "In Figure 2 ‣ 4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression") the initial improvement in $\mathcal{J}\_{KL}$ during optimization of $\mathcal{I}$ hints to the existence of a connection in a reversed direction as well. However, smoothing loss alone proves to be insufficient in regularizing the internal statistics’ divergence as the Inception loss greedily attempts to maximize the target class predictions and the measured $\mathcal{J}\_{KL}$ is increasing after several iterations.

BN-Stats and Model Accuracy. For the next part of our evaluation, we generated samples from the reference model using the $BNS$ scheme. During the sample generation phase, several snapshots of the training data were saved at different step intervals. The snapshots reflect different stages of the $\mathcal{J}\_{KL}$ loss curve. We then perform a series of KD experiments on the quantized reference model to observe the impact of dataset size and $\mathcal{J}\_{KL}$ loss value on the final model accuracy.
Each experiment is repeated with five different seeds, the student model precision configuration is fixed to 4-bit activations and 2-bit weights except for the first and last layers which are using 4 bit.

(a) Dataset size impact on final model accuracy.

(b) Statistics loss impact on final error.

Figure 3: KD on a quantized ResNet-44 model (2w4a, CIFAR10) using real and $BNS$ data with varying number of data points (per-class). Demonstrates the connection between dataset size and $\mathcal{J}\_{KL}$ with model accuracy. Providing more synthetic samples improves final accuracy.

Final results are presented in Figure [4](#A3.F4 "Figure 4 ‣ Appendix C Generating CIFAR10 and ImageNet ‣ The Knowledge Within: Methods for Data-Free Model Compression") as follows: Figure [3(b)](#S4.F3.sf2 "In Figure 3 ‣ 4.3 Analysis of Data Generation Schemes ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression") demonstrates that samples with lower statistic loss lead to better validation accuracy, while Figure [3(a)](#S4.F3.sf1 "In Figure 3 ‣ 4.3 Analysis of Data Generation Schemes ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression") shows results are very close to real data with slight degradation under identical settings.

### 4.4 Data Correspondence: BNS Across Datasets

In this section we observe how the internal statistics of a model respond to different inputs, illustrating that similar input data should not lead to significantly different internal activation statistics.
In table-[4](#S4.T4 "Table 4 ‣ 4.4 Data Correspondence: BNS Across Datasets ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression") we demonstrate this by measuring $\mathcal{J}\_{KL}$ of various datasets on a set of pre-trained ResNet44 [[8](#bib.bib8)] models. We also measure the $\mathcal{J}\_{KL}$ divergence in response to the original training data modified with Fast Gradient Sign Method (FGSM [[7](#bib.bib7)]). A small perturbation ratio of $\epsilon=0.1$ is used to reduce model accuracy without considerably altering the perceived input.

Table 4: The value of $\mathcal{J}\_{KL}$ normalized by the value of $\mathcal{J}\_{KL}$ that is measured on the original training dataset. Values are computed on the entire train split, raw measurements are available in appendix-[D](#A4 "Appendix D BN-Stats measurement ‣ The Knowledge Within: Methods for Data-Free Model Compression").11
1

| Train/Measure | CIFAR10 | CIFAR100 | MNIST | SVHN | STL10 | Random | FGSM11 1 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| CIFAR10 | 1.0 | 1.0 | 6.6 | 7.9 | 1.3 | 21.7 | 3.3 |
| CIFAR100 | 1.1 | 1.0 | 3.9 | 4.1 | 1.3 | 14.8 | 1.9 |
| MNIST | 103.5 | 111.5 | 1.0 | 196.0 | 138.5 | 327.5 | 2.0 |
| SVHN | 1.4 | 1.2 | 1.2 | 1.0 | 2.7 | 4.1 | 0.9 |

Ratio grows with the $\epsilon$ parameter of FGSM, as the image perturbation becomes more apparent.

As expected from a similarity score, table-[4](#S4.T4 "Table 4 ‣ 4.4 Data Correspondence: BNS Across Datasets ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression") demonstrates that $\mathcal{J}\_{KL}$ maintains its proportion compared to the original training dataset, although magnitude may change across models and datasets. We further observe that in some cases, perturbed samples results in a significant increase in the internal statistics’ divergence. This invites further exploration in the direction of possible applications of monitoring internal statistics to explain and detect adversarial attacks through tailored outlier sensitive measures.

## 5 Discussion and Future Work

In this work, we addressed the case of data-free KD for model quantization under realistic data and hardware acceleration constrains. To overcome this challenge, we suggested a set of new sample-generation methods, and demonstrated the applicability of such samples for a true data-free model compression in both small and large scale image classification tasks. In the process we explored techniques to leverage such samples in a student-teacher training procedure.

In addition, our best performing method, $BNS$ leveraged the common batch-norm layer to generate examples that mimic the per-channel mean and variance of each BN layer input, by explicitly optimizing $\mathcal{J}\_{KL}$ divergence loss.
We show evidence that optimizing this loss, results in smooth input features, indicating a strong connection between BN-Stats loss and the local structure of the input (figure-[2(b)](#S4.F2.sf2 "In Figure 2 ‣ 4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression")). This invites further study to determine the viability of the method for the reproduction of inputs other than images, where prior knowledge may be harder to apply directly.

Alternatively, our random data approach $\mathcal{G}$ can serve as a cheap replacement to the real data. In particular, for calibration under mild quantization (8-bit) demands. We also noticed that compared to $BNS$, the naive inception scheme $\mathcal{I}$ generates samples with a high model prediction confidence, yet causes the internal statistics’ divergence to grow significantly (figure-[2(a)](#S4.F2.sf1 "In Figure 2 ‣ 4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression")). Furthermore, the success of $BNS$, leads us to consider it as a possible measure for evaluating correspondence between the reference dataset, used during model’s training, and alternative samples.

To the best of our knowledge, this is the first time a data-free distillation-based approach was applied to a model and achieved final accuracy results comparable with real samples — under identical optimization conditions and at large scale. Ultimately, we believe our approach can open a path to improve data privacy by reducing the extent of real data exposure during the production phase of deployment.

The release of this paper was followed by [[29](#bib.bib29), [5](#bib.bib5)], which utilize the same principle of leveraging the internal statistics’ divergence for a range of data-free tasks, including low precision calibration and knowledge distillation. These papers explore interesting ideas such as adaptive sample generation and layer sensitivity heuristics for mixed-precision, while their results further support our findings.
In contrast to [[29](#bib.bib29)], which presents a wide range of experiments on data-free applications such as classical KD and pruning with a limited analysis, we focused our attention on the applicability of the method for DNN’s deployment on low precision accelerators and provide further insight into the success of the method and to the importance of the internal divergence measure. Additionally, we present data-free KD results for low precision models, which are not explored by [[5](#bib.bib5)], and show highly compressed models can recover from extreme accuracy degradation which enables much more demanding configurations without requiring access to the original training data.

We consider two drawbacks of the proposed method. One is the computational cost of generating samples through back-propagation, which can impede the practical use with large scale models for continuous train-deploy scenarios. However, we note that as long as the new training data does not significantly change, the behavior of the internal statistics of the generated samples can potentially be shared — to avoid reproducing an entirely new synthetic dataset at each deployment cycle. We leave the exploration of cross-model and cross-dataset applications for future work. Second, we find the $BNS$ method produces datasets which are unbalanced in terms of the mean output distribution of the reference model, due to the lack of explicit conditioning on the model output. However, our experiments with $BNS+\mathcal{I}$ did not show a dramatic improvement despite their added balance control and the additional information injection from the final layer weights. We suspect this is due to the tension between the $BNS$ objective and $\mathcal{I}$ which may require balancing or a longer optimization to reach comparable $\mathcal{J\_{KL}}$. Still, there is a lot to unveil and we are excited by the diverse opportunities to exploit the suggested scheme beyond model compression. For instance, applying $BNS$ measure to detect outliers and adversarial examples, or to avoid catastrophic forgetting in a continual learning setting.

## Appendix A Hyper-Parameters

### A.1 Generation

Using ADAM optimizer with learning rate 0.1, betas(0.9,0.999) for all experiments, when image-prior scale is non-zero we use a $\mathcal{N}$(0,1) smoothing kernel of size 5. Generally batch size is chosen to fit in available memory (statistics are accumulated across devices).

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| scheme | batch size | in-batch | steps | lr drops (1e-1) | scales (bns,cls,prior) |
| ResNet-44-CIFAR10 | | | | | |
| $BNS$ | 800 | 4 | 1000 | 800 | 1,0,0 |
| $BNS+\mathcal{I}$ | 1,1e-3,1 |
| $\mathcal{I}$ | 0,1e-3,1 |
| Wide ResNet-28-10-CIFAR100 | | | | | |
| $BNS$ | 256 | 4 | 1000 | 800 | 1,0,0 |
| $BNS+\mathcal{I}$ | 1,1e-3,1 |
| $\mathcal{I}$ | 0,1e-3,1 |
| ResNet-18-ImageNet | | | | | |
| $BNS$ | 80 | 4 | 1000 | 800 | 1,0,0 |
| $BNS+\mathcal{I}$ | 1,1e-3,1 |
| $\mathcal{I}$ | 0,1e-3,1 |
| MobileNet-V2-ImageNet | | | | | |
| $BNS$ | 400 | 2 | 6000 | 1500,4200 | 1,0,0 |
| $BNS+\mathcal{I}$ | 10000 | 1500,6000 | 1,1e-4,0 |
| $\mathcal{I}$ | 1000 | 800 | 0,1e-4,1 |
| DenseNet-121-ImageNet | | | | | |
| $BNS$ | 200 | 2 | 6000 | 1500,4200 | 1,0,0 |
| $BNS+\mathcal{I}$ | 10000 | 1500,6000 | 1,1e-4,0 |
| $\mathcal{I}$ | 1000 | 800 | 0,1e-4,1 |

### A.2 Hyper-Parameters sensitivity for calibration

Here we present evidence of hyper-parameter sensitivity for Inception related generation schemes. Specifically, we demonstrate how changing the variance parameter of the Gaussian smoothing kernel, used as the image prior, to regularize the optimization process, impacts the usability of the generated data. In table-[5](#A1.T5 "Table 5 ‣ A.2 Hyper-Parameters sensitivity for calibration ‣ Appendix A Hyper-Parameters ‣ The Knowledge Within: Methods for Data-Free Model Compression"), we compare calibration results for quantized ResNet44 from Small scale results section.

Table 5: Post calibration validation accuracy, additional fixed hyper-parameters: kernel 5x5, inception loss scale 0.001. Results on $\mathcal{I}$ and $BNS+\mathcal{I}$ datasets appear to be sensitive to hyper-parameter adjustments. We report our best results without performing an exhaustive search.11
1

|  |  |  |
| --- | --- | --- |
| sigma | $\mathcal{I}$ | $BNS+\mathcal{I}$ |
| ResNet-44, 4w4a, real data calibration accuracy - 89.19 (0.15) | | |
| 0.375 | 89.22 (0.22) | 88.87 (0.22) |
| 1.0 | 87.44 (0.13) | 89.1 (0.09) |
| ResNet-44, 4w4a11 1 , real data calibration accuracy - 91.64 (0.13) | | |
| 0.375 | 91.26 (0.16) | 91.3 (0.1) |
| 1.0 | 90.89 (0.11) | 91.76 (0.22) |
| ResNet-44, 4w8a11 1 ], real data calibration accuracy - 92.18 (0.05) | | |
| 0.375 | 92.04 (0.03) | 92.33 (0.04) |
| 1.0 | 92.37 (0.03) | 92.25 (0.04) |

First & final layers are in 8 bits

### A.3 Distillation

Algorithm-[2](#algorithm2 "In 4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression") describes the general KD framework with IQ and input-mixup tweaks (see ablation in table-[1](#S4.T1 "Table 1 ‣ 4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression")). These are not strictly required when the full dataset is available, yet tend to offer improved convergence when the available dataset is limited in size. We use standard KL divergence as KD loss, smoothed-l1 is used for IQ term and the calibration algorithm is as described in section-[4.2](#S4.SS2 "4.2 Data-free model compression ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression"). We use SGD with a learning rate of 0.1 and a batch size of 256 in all experiments, while sampling with replacement for a fixed number of steps per epoch (CIFAR-200 ,ImageNet-400), additional shared hyper-parameters: $\alpha,\beta,\theta\_{mixup}$ = 1, 0.01, {mix\_rate=0.5}.

## Appendix B Additional results for ImageNet dataset

Table 6: Comparison of dataset size and fine-tune objective impact on ImageNet validation accuracy for ResNet-18 quantized to 4 bits. ∗ Regime follows [[20](#bib.bib20)].

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| dataset | samples | objective | steps | top1 | $\mathcal{J}\_{KL}$ |
| ImageNet | 1.3M | CE | \*550440 | 69.95 | 0.05 |
|  | 1.3M | CE | \*45036 | 68.36 |  |
|  | 100K | CE | 44000 | 67.47 |  |
| ImageNet | 1.3M | KLD | 550440 | 68.87 | 0.05 |
|  | 100K | KLD | 44000 | 68.68 |  |
| $BNS$ | 100K | KLD | 44000 | 68.14 | 0.052 |
| $BNS+\mathcal{I}$ | 100K | KLD | 44000 | 67.95 | 0.059 |
| $BNS$+$BNS+\mathcal{I}$ | 50K+50K | KLD | 44000 | 68.07 | 0.053 |

There exists an accuracy gap between the fine-tuned model and the distilled variants even when the full data-set is available as seen in table-[6](#A2.T6 "Table 6 ‣ Appendix B Additional results for ImageNet dataset ‣ The Knowledge Within: Methods for Data-Free Model Compression"). We believe this can be attributed to using KD without an additional ground truth loss term which is common in an unsupervised setting. Thus, final accuracy depends solely on the prediction quality of the teacher. Whereas additional label information can be used to penalize the student when repeating similar mistakes made by the teacher and contribute to improved final accuracy. Additionally, we speculate that a given bias in the reference model’s prediction towards certain classes (see figure-[7](#A5.F7 "Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression")) may degrade the student accuracy when training on raw teacher outputs.

## Appendix C Generating CIFAR10 and ImageNet

In figure-[4](#A3.F4 "Figure 4 ‣ Appendix C Generating CIFAR10 and ImageNet ‣ The Knowledge Within: Methods for Data-Free Model Compression"), we provide a several synthetic samples per class generated from a CIFAR10 trained ResNet44 model, using Inception scheme ($\mathcal{I}$) and samples generated using the BN-stats + Inception scheme ($BNS+\mathcal{I}$). The generation process follows the settings detailed in Generating data samples section. Samples seem to share similar visual features between generation schemes. while $BNS+\mathcal{I}$ samples are smoother and appear clearer.

(a) samples generated with $BNS+\mathcal{I}$, Gaussian smoothing Kernel 5x5, sigma 1.0

(b) samples generated with Inception loss + Gaussian smoothing Kernel 5x5, sigma 1.0

Figure 4: CIFAR10 samples generated from ResNet-44

Additionally, a subset of samples generated using ResNet-18 model trained over ImageNet dataset is presented in figure-[6(b)](#A3.F6.sf2 "In Figure 6 ‣ Appendix C Generating CIFAR10 and ImageNet ‣ The Knowledge Within: Methods for Data-Free Model Compression"). Visual inspection of those generated samples indicated considerable improvement in detail and diversity over naive inception generation scheme. Furthermore, some instances seem to preserve the represented class physical structure better than others. Despite the lack of consensus regarding objective image quality evaluation methods, we find it is intriguing to further explore means to improve reproduced class visual quality and investigate its connection to the model’s prediction quality. We believe the $BNS+\mathcal{I}$ method may serve as a powerful tool for DNNs interpretability, providing insight into the featured learned by DNNs.

Figure 5: Comparison of ImageNet and synthetic samples generated from ResNet-18

(a) Reference ImageNet samples

(b) $\mathcal{I}$, smoothing kernel 9x9, sigma 0.7 yielded best visual result

(c) $BNS+\mathcal{I}$, smoothing kernel 5x5, sigma 1

(d) $BNS$ only

Figure 6: Additional synthetic samples generated from DenseNet-121

(a) $BNS$ only samples

(b) $BNS+\mathcal{I}$, no image prior is used during sample generation.

## Appendix D BN-Stats measurement

In table-[7](#A4.T7 "Table 7 ‣ Appendix D BN-Stats measurement ‣ The Knowledge Within: Methods for Data-Free Model Compression"), we provide raw measurements of $\mathcal{J}\_{KL}$ on select datasets using pre-trained ResNet44 from table-[4](#S4.T4 "Table 4 ‣ 4.4 Data Correspondence: BNS Across Datasets ‣ 4 Experiments ‣ The Knowledge Within: Methods for Data-Free Model Compression") of the main paper.

Table 7: $\mathcal{J}\_{KL}$ values are computed on the entire training data-set and include all BN layers within the reference model.
  
∗Fast Gradient Sign Method (FGSM) was used to create adversarial samples with small perturbation ratio $\epsilon=0.1$, the measured loss generally grows with epsilon.

| Train/Measure | CIFAR10 | CIFAR100 | MNIST | SVHN | STL10 | Random | ∗FGSM |
| --- | --- | --- | --- | --- | --- | --- | --- |
| CIFAR10 | 0.023 | 0.022 | 0.151 | 0.182 | 0.031 | 0.498 | 0.075 |
| CIFAR100 | 0.065 | 0.057 | 0.223 | 0.236 | 0.072 | 0.845 | 0.106 |
| MNIST | 0.207 | 0.223 | 0.002 | 0.392 | 0.277 | 0.655 | 0.004 |
| SVHN | 0.037 | 0.032 | 0.032 | 0.027 | 0.073 | 0.111 | 0.024 |

## Appendix E Perceived dataset bias

Given a reference classification model, we loosely consider the per-class mean prediction of the model as unbiased if it is close to uniform when presented with a balanced set of examples, since no particular class should be favoured over other classes by an unbiased model. To provide a qualitative evaluation, we record the softmax output of a pretrained ResNet-18 model from torchvision, over the entire ImageNet validation set. Then, compute the mean prediction of the ”soft” outputs (i.e., $\frac{1}{N}\sum\_{i=1}^{N}{output\_{i}}$) where $output\_{i}\in R^{\#classes}$ is the model softmax output for sample $i$, as well as the ”hard” mean prediction (i.e., $\frac{1}{N}\sum\_{i=1}^{N}e^{argmax\{output\_{i}\}}$ where $e$ is the standard vector). In figures-[7(a)](#A5.F7.sf1 "In Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression"),[7(b)](#A5.F7.sf2 "In Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression"),[7(c)](#A5.F7.sf3 "In Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression"), we plot the mean soft and hard predictions of the model for a given dataset, while classes are sorted according to the mean soft prediction. Figure-[7(a)](#A5.F7.sf1 "In Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression") reveals that although the validation dataset is balanced (ignoring possible annotation errors and class similarity), the model produces a somewhat biased prediction. We hypothesize this bias may impede KD performance as discussed in Large scale experiment section, even when the entire dataset is available.

(a) Reference model (fp32) mean prediction over ImageNet validation set reveals a classifier bias.

(b) Reference model (fp32) mean prediction over $BNS$ samples, presents a highly biased preference towards certain classes.

(c) Reference model (fp32) mean prediction over $BNS+\mathcal{I}$ samples. As expected prediction mean is balanced since the samples are tailored through optimization to favor a single class with uniform target class sampling.

(d) Mean relative tail degradation on ImageNet validation set. Classes are sorted according to the hard prediction rate from [7(b)](#A5.F7.sf2 "In Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression").
Degradation ratio is computed as the mean of $\frac{s^{i}\_{fp32}-s^{i}\_{ft}}{s^{i}\_{fp32}}$ over increasing number of classes from least favored to most favored. $s$ denotes per-class accuracy and $i$ is the class index. The $BNS+\mathcal{I}$ fine-tuned model present a small improvement over the $BNS$ variation with respect to the worst case accuracy degradation.

Figure 7: Bias analysis on ResNet-18, soft and hard plots refer to means of raw model outputs and a hard class index choice (i.e., a hot-1 vector) over the entire validation set

Additionally, in figures-[7(b)](#A5.F7.sf2 "In Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression"),[7(c)](#A5.F7.sf3 "In Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression") we provide the mean prediction plots for $BNS$ and $BNS+\mathcal{I}$ datasets appropriately, each containing 100K synthetic samples. Figure-[7(b)](#A5.F7.sf2 "In Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression") shows a clear preference towards certain classes, which does not necessarily align with the model’s prediction bias over the validation set (figure-[7(a)](#A5.F7.sf1 "In Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression")). While figure-[7(c)](#A5.F7.sf3 "In Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression") shows that $BNS+\mathcal{I}$ dataset appears balanced in terms of the mean prediction, which is not a surprising result. However, our KD experiments did not show any significant benefit to using the $BNS+\mathcal{I}$ dataset compared to the $BNS$ dataset in terms of the final validation accuracy, despite the perceived class imbalance.

## Appendix F Mean tail degradation

To further investigate the impact of $BNS$ dataset bias on fine-tuned (quantized) model’s accuracy, we consider the mean relative accuracy degradation over N least frequent classes (mean tail degradation). First, we measure the per-class validation accuracy for each of the fine-tuned models (i.e., ResNet18 fine-tuned with $BNS$ or $BNS+\mathcal{I}$ dataset, see Large scale experiment section). Then, we compute the relative degradation compared to the float model for each class. Finally, classes are sorted according to the reference model (fp32) mean hard prediction over $BNS$ dataset (figure-[7(b)](#A5.F7.sf2 "In Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression")). Essentially, the least frequently predicted classes are considered first under the tail limit (N). Figure-[7(d)](#A5.F7.sf4 "In Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression") shows the mean degradation with an increasing number of classes N, while only considering classes where accuracy degradation is observed (i.e., we ignore classes which present an improvement in accuracy). Figure-[7(d)](#A5.F7.sf4 "In Figure 7 ‣ Appendix E Perceived dataset bias ‣ The Knowledge Within: Methods for Data-Free Model Compression") presents evidence for an improved mean tail degradation, which can serve as motivation for using $BNS+\mathcal{I}$ over $BNS$ dataset since the worst-case accuracy is improved despite the overall accuracy being slightly worse.
