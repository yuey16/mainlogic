<!-- fulltext source=arxiv_html slug=arXiv-2301.06015 fetched=2026-09-18T00:56:26+00:00 -->

# Diffusion-based Generation, Optimization, and Planning in 3D Scenes

Siyuan Huang
  
Zan Wang
Affiliation:  National Key Laboratory of General Artificial Intelligence, BIGAI
  
Puhao Li
Affiliation:  National Key Laboratory of General Artificial Intelligence, BIGAI
Affiliation:  Dept. of Automation, Tsinghua University
  
Baoxiong Jia
Affiliation:  National Key Laboratory of General Artificial Intelligence, BIGAI
  
Tengyu Liu
Affiliation:  National Key Laboratory of General Artificial Intelligence, BIGAI
  
Yixin Zhu
Affiliation:  Institute for AI, Peking University
<https://scenediffuser.github.io>
  
Wei Liang
  
Song-Chun Zhu
Affiliation:  National Key Laboratory of General Artificial Intelligence, BIGAI
Affiliation:  Dept. of Automation, Tsinghua University
Affiliation:  Institute for AI, Peking University
<https://scenediffuser.github.io>

Affiliation:  School of Computer Science & Technology, Beijing Institute of Technology

###### Abstract

We introduce SceneDiffuser, a conditional generative model for 3D scene understanding. SceneDiffuser provides a unified model for solving scene-conditioned generation, optimization, and planning. In contrast to prior work, SceneDiffuser is intrinsically scene-aware, physics-based, and goal-oriented. With an iterative sampling strategy, SceneDiffuser jointly formulates the scene-aware generation, physics-based optimization, and goal-oriented planning via a diffusion-based denoising process in a fully differentiable fashion. Such a design alleviates the discrepancies among different modules and the posterior collapse of previous scene-conditioned generative models. We evaluate SceneDiffuser on various 3D scene understanding tasks, including human pose and motion generation, dexterous grasp generation, path planning for 3D navigation, and motion planning for robot arms. The results show significant improvements compared with previous models, demonstrating the tremendous potential of SceneDiffuser for the broad community of 3D scene understanding.

Figure 1: Illustration of the SceneDiffuser, applicable to various scene-conditioned 3D tasks: (a) human pose generation, (b) human motion generation, (c) dexterous grasp generation, (d) path planning for 3D navigation with goals, and (e) motion planning for robot arms.

††
∗ These authors contributed equally to this work.††
${}^{\textrm{{\char 0\relax}}}$ Corresponding authors: Siyuan Huang (syhuang@bigai.ai) and Wei Liang (liangwei@bit.edu.cn).

## 1 Introduction

The ability to generate, optimize, and plan in 3D scenes is a long-standing goal for multiple research domains across computer vision, graphics, and robotics. Various tasks have been devised to achieve these goals, fostering downstream applications in motion generation [[32](#bib.bib32), [83](#bib.bib83), [67](#bib.bib67), [70](#bib.bib70)], motion planning [[40](#bib.bib40), [58](#bib.bib58), [41](#bib.bib41), [72](#bib.bib72)], grasp generation [[25](#bib.bib25), [33](#bib.bib33), [31](#bib.bib31)], navigation [[88](#bib.bib88), [1](#bib.bib1)], embodied perception and manipulation [[37](#bib.bib37), [59](#bib.bib59), [30](#bib.bib30)], and autonomous driving [[50](#bib.bib50), [3](#bib.bib3)].

Despite rich applications and great successes, existing models designed for these tasks exhibit two fundamental limitations for real-world 3D scene understanding.

First, most prior work [[32](#bib.bib32), [70](#bib.bib70), [47](#bib.bib47), [67](#bib.bib67), [14](#bib.bib14), [68](#bib.bib68), [58](#bib.bib58), [8](#bib.bib8), [66](#bib.bib66)] leverages the cvae (cvae) for the conditional generation in 3D scenes. cvae model utilizes an encoder-decoder structure to learn the posterior distribution and relies on the learned latent variables to sample. Although cvae is easy to train and sample due to its simple architecture and one-step sampling procedure, it suffers from the posterior collapse problem [[86](#bib.bib86), [62](#bib.bib62), [26](#bib.bib26), [17](#bib.bib17), [12](#bib.bib12), [77](#bib.bib77), [67](#bib.bib67)]; the learned latent variable is ignored by a strong decoder, leading to limited generation diversity from these collapsed modes. Such collapse is further magnified in 3D tasks with stronger 3D decoders and more complex and noisy input conditions, *e.g*., the natural 3D scans [[9](#bib.bib9)].

Second, despite the close relations among generation, optimization, and planning in 3D scenes, there lacks a unified framework that could address existing discrepancies among these models. Previous work [[15](#bib.bib15), [33](#bib.bib33), [67](#bib.bib67)] applies off-the-shelf physics-based post-optimization methods over outputs of generative models and often produces inconsistent and implausible generations, especially when transferring to novel scenes. Similarly, planners are usually standalone modules over results of generative model [[14](#bib.bib14), [8](#bib.bib8)] for trajectory planning or learned separately with the rl (rl) [[88](#bib.bib88)], leading to gaps between planning and other modules (*e.g*., generation) during inference, especially in novel scenes where explorations are limited.

To tackle these limitations, we introduce SceneDiffuser, a conditional generative model based on the diffusion process. SceneDiffuser eliminates the discrepancies and provides a single home for scene-conditioned generation, optimization, and planning. Specifically, with a denoising process, it learns a diffusion model for scene-conditioned generation while training. During inference, SceneDiffuser jointly solves the scene-aware generation, physics-based optimization, and goal-oriented planning through a unified iterative guided-sampling framework. Such a design equips SceneDiffuser with the following superiority:

#### Generation

Building upon the diffusion model, SceneDiffuser significantly alleviates the posterior collapse problem of scene-conditioned generative models. Since the forward diffusion process can be treated as data augmentation in 3D scenes, it helps traverse sufficient scene-conditioned distribution modes.

#### Optimization

SceneDiffuser integrates the physics-based objective into each step of the sampling process as conditional guidance, enabling the differentiable physics-based optimization during both the learning and sampling process. This design facilitates the physically-plausible generation, which is critical for tasks in 3D scenes.

#### Planning

Based on the scene-conditioned trajectory-level generator, SceneDiffuser possesses a global trajectory planner with physics and goal awareness, making the learned planner generalize better to long-horizon trajectories and novel 3D scenes.

As illustrated in [Fig. 1](#S0.F1 "In Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), we evaluate SceneDiffuser on diverse 3D scene understanding tasks. The results on human pose, motion, and dexterous grasp generation significantly improve, demonstrating plausible and diverse generations with 3D scene and object conditions. The results on path planning for 3D navigation and motion planning for robot arms reveal the generalizable and long-horizon planning capability of SceneDiffuser.

## 2 Related Work

#### Conditional Generation in 3D Scenes

Generating diverse contents and rich interactions in 3D scenes is essential for understanding the 3D scene affordances. Recently, we have witnessed several applications on conditional scene generation [[24](#bib.bib24), [45](#bib.bib45), [81](#bib.bib81), [69](#bib.bib69)], human pose [[32](#bib.bib32), [83](#bib.bib83), [80](#bib.bib80), [16](#bib.bib16), [85](#bib.bib85)] and motion generation [[32](#bib.bib32), [70](#bib.bib70), [47](#bib.bib47), [67](#bib.bib67), [14](#bib.bib14), [68](#bib.bib68), [58](#bib.bib58), [66](#bib.bib66)] in furnished 3D indoor scenes, and object-conditioned grasp pose generation [[31](#bib.bib31), [33](#bib.bib33), [25](#bib.bib25), [60](#bib.bib60), [74](#bib.bib74)].
However, most previous methods [[60](#bib.bib60), [70](#bib.bib70), [31](#bib.bib31), [25](#bib.bib25), [66](#bib.bib66), [16](#bib.bib16), [14](#bib.bib14), [6](#bib.bib6), [72](#bib.bib72)] rely on cvae and suffer from the posterior collapse problem [[86](#bib.bib86), [62](#bib.bib62), [26](#bib.bib26), [17](#bib.bib17), [12](#bib.bib12), [77](#bib.bib77), [67](#bib.bib67)], especially when the 3D scene is natural and complex. In this work, SceneDiffuser addresses the posterior collapse with the diffusion-based denoising process.

#### Physics-based Optimization in 3D Scenes

Producing physically plausible generations compatible with 3D scenes is one of the challenges in the scene-conditioned generation. Previous work uses physics-based post-optimization [[15](#bib.bib15), [33](#bib.bib33), [67](#bib.bib67)] or differentiable objective [[83](#bib.bib83), [70](#bib.bib70), [25](#bib.bib25)] to integrate collision and contact constraints into the generation framework. However, post-optimization approaches [[15](#bib.bib15), [33](#bib.bib33), [67](#bib.bib67)] are oftentimes inefficient and cannot be learned jointly with the generative models, yielding inconsistent generation results. Similarly, differentiable approaches [[83](#bib.bib83), [70](#bib.bib70), [25](#bib.bib25)] post constraints on the final objective, thus cannot optimize the physical interactions during the sampling, producing implausible generations, especially when adapting to novel scenes. In this work, SceneDiffuser eliminates such inconsistency with the differentiable physics-based optimization integrated into each step of the sampling process.

#### Planning in 3D Scenes

The ability to act and plan in 3D scenes is critical for an intelligent agent and has led to the recent culmination of embodied AI research  [[28](#bib.bib28), [52](#bib.bib52), [53](#bib.bib53), [30](#bib.bib30)]. Among all tasks, visual navigation has been most studied in the vision and robotics community [[88](#bib.bib88), [73](#bib.bib73), [38](#bib.bib38), [4](#bib.bib4), [13](#bib.bib13), [21](#bib.bib21), [87](#bib.bib87)]. However, existing works rely heavily on model-based planning with the single-step dynamic model [[75](#bib.bib75), [46](#bib.bib46), [71](#bib.bib71), [11](#bib.bib11), [5](#bib.bib5), [65](#bib.bib65)], lacking a trajectory-level optimization for long-horizon planning. Further, the physical interactions are not explicitly modeled into the planning. This deficiency makes it challenging to generalize to natural scenes, where exploration is limited, and fast learning and adaptation are required. In comparison, with the global trajectory planner based on a trajectory-level generator, SceneDiffuser demonstrates better generalization in long-horizon plans and novel 3D scenes.

#### Diffusion-based Models

Diffusion model [[55](#bib.bib55), [19](#bib.bib19), [57](#bib.bib57), [22](#bib.bib22)] has come forth into a promising class of generative model for learning and sampling data distributions with an iterative denoising process, facilitating the image [[10](#bib.bib10), [56](#bib.bib56)], text [[76](#bib.bib76)], and shape generation [[34](#bib.bib34)]. With flexible conditioning, it is further extended to the language-conditioned image [[51](#bib.bib51), [39](#bib.bib39), [49](#bib.bib49)], video [[18](#bib.bib18), [54](#bib.bib54)], and 3D generation [[42](#bib.bib42), [61](#bib.bib61), [78](#bib.bib78)]. Notably, Janner *et al*. [[23](#bib.bib23)] integrate the generation and planning into the same sampling framework for behavior synthesis. To our best knowledge, SceneDiffuser is the first framework that models the 3D scene-conditioned generation with a diffusion model and integrates the generation, optimization, and planning into a unified framework.

## 3 Background

### 3.1 Problem Definition

Given a 3D scene $\mathcal{S}$, we aim to generate the optimal solution for completing the tasks (*e.g*., navigation, manipulation) given the goal $\mathcal{G}$ in the scene. We denote the state and action of an agent as $(\mathbf{s},\mathbf{a})$. The dynamic model defines the state transition as $p(\mathbf{s}\_{i+1}|\mathbf{s}\_{i},\mathbf{a}\_{i})$, which is often deterministic in scene understanding (*i.e*., $f(\mathbf{s}\_{i},\mathbf{a}\_{i})$). The trajectory is defined as $\boldsymbol{\boldsymbol{\tau}}=(\mathbf{s}\_{0},\mathbf{a}\_{0},\cdots,\mathbf{s}\_{i},\mathbf{a}\_{i},\cdots,\mathbf{s}\_{N})$, where $N$ denotes the horizon of task solving in discrete time.

### 3.2 Planning with Trajectory Optimization

The scene-conditional trajectory optimization is defined as maximizing the task objective:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\boldsymbol{\tau}^{\*}=\argmax\_{\boldsymbol{\tau}}\mathcal{J}(\boldsymbol{\tau}|\mathcal{S},\mathcal{G}).$ |  | (1) |

The dynamic model is usually known for trajectory optimization. Considering the future actions and states with predictable dynamics, the entire trajectory $\boldsymbol{\tau}$ can be optimized jointly and non-progressively with traditional [[29](#bib.bib29)] or data-driven [[7](#bib.bib7)] planning algorithms. Trajectory-based optimization benefits from its global awareness of history and future states, thus can better model the long-horizon tasks compared with single-step models in rl, where $\mathbf{a}\_{0:N}^{\*}=\argmax\_{\mathbf{a}\_{0:N}}\sum\_{i=0}^{N}r(\mathbf{s}\_{i},\mathbf{a}\_{i}|\mathcal{S},\mathcal{G})$.

### 3.3 Diffusion Model

Diffusion models [[22](#bib.bib22), [55](#bib.bib55), [19](#bib.bib19)] are a class of generative models that represent the data generation with an iterative denoising process from Gaussian noise. It consists of a forward and a reverse process. The forward process $q(\boldsymbol{\tau}^{t}|\boldsymbol{\tau}^{t-1})$ gradually destroys data $\boldsymbol{\tau}^{0}\sim q(\boldsymbol{\tau}^{0})$ into Gaussian noise. The parametrized reverse process $p\_{\theta}(\boldsymbol{\tau}^{t-1}|\boldsymbol{\tau}^{t})$ recovers the data from noise with the learned normal distribution from a fixed timestep. The training objective for $\theta$ is denoising score matching over multiple noise scale [[22](#bib.bib22), [64](#bib.bib64)]. Please refer to the [Appendix A](#A1 "Appendix A Background for Diffusion Model ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") for detailed descriptions of the diffusion model and its variants.

## 4 SceneDiffuser

SceneDiffuser models planning as trajectory optimization and solves the aforementioned problem with the spirit of planning as sampling, where the trajectory optimization is achieved by sampling trajectory-level distribution learned by the model. Leveraging the diffusion model with gradient-based sampling and flexible conditioning, SceneDiffuser models the scene-conditioned goal-oriented trajectory $p(\boldsymbol{\tau}^{0}|\mathcal{S},\mathcal{G})$:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle p(\boldsymbol{\tau}^{0}|\mathcal{S},\mathcal{G})=$ | $\displaystyle\frac{p\_{\theta}(\boldsymbol{\tau}^{0}|\mathcal{S})p\_{\phi}(\mathcal{G}|\boldsymbol{\tau}^{0},\mathcal{S})}{p(\mathcal{G}|\mathcal{S})}$ |  | (2) |
|  | $\displaystyle\propto$ | $\displaystyle p\_{\theta}(\boldsymbol{\tau}^{0}|\mathcal{S})p\_{\phi}(\mathcal{G}|\boldsymbol{\tau}^{0},\mathcal{S}).$ |  |

#### Generation

$p\_{\theta}(\boldsymbol{\tau}^{0}|\mathcal{S})$ characterizes the probability of generating certain trajectories with the scene condition. It can be modeled using a conditional diffusion model [[55](#bib.bib55), [19](#bib.bib19)] with an iterative denoising process:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle p\_{\theta}(\boldsymbol{\tau}^{0}|\mathcal{S})$ | $\displaystyle=p(\boldsymbol{\tau}^{T})\prod\_{t=1}^{T}p(\boldsymbol{\tau}^{t-1}|\boldsymbol{\tau}^{t},\mathcal{S}),$ |  | (3) |
|  | $\displaystyle p(\boldsymbol{\tau}^{t-1}|\boldsymbol{\tau}^{t},\mathcal{S})$ | $\displaystyle=\mathcal{N}(\boldsymbol{\tau}^{t-1};\boldsymbol{\mu}\_{\theta}(\boldsymbol{\tau}^{t},t,\mathcal{S}),\boldsymbol{\Sigma}\_{\theta}(\boldsymbol{\tau}^{t},t,\mathcal{S})).$ |  |

#### Optimization and Planning

$p\_{\phi}(\mathcal{G}|\boldsymbol{\tau}^{0},\mathcal{S})$ represents the probability of reaching the goal with the sampled trajectory, where the goal can be flexibly defined by customized objective functions in various tasks. As shown in [Eq. 4](#S4.E4 "In Optimization and Planning ‣ 4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), the precise definition of this probability is $p\_{\phi}(\mathcal{O}=1|\boldsymbol{\tau}^{0},\mathcal{S},\mathcal{G})$, where $O$ is an optimality indicator that represents if the goal were achieved.
Intuitively, the trajectory objective in [Eq. 1](#S3.E1 "In 3.2 Planning with Trajectory Optimization ‣ 3 Background ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") can be a good indicator for such optimality. We therefore expand $p\_{\phi}(\mathcal{G}|\boldsymbol{\tau}^{t},\mathcal{S})$ as its exponential in [Eq. 5](#S4.E5 "In Optimization and Planning ‣ 4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"):

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle p\_{\phi}(\mathcal{G}|\boldsymbol{\tau}^{t},\mathcal{S})=$ | $\displaystyle\ p\_{\phi}(\mathcal{O}=1|\boldsymbol{\tau}^{t},\mathcal{S},\mathcal{G})$ |  | (4) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\propto$ | $\displaystyle\exp(\mathcal{J}(\boldsymbol{\tau}^{t}|\mathcal{S},\mathcal{G}))$ |  | (5) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle=$ | $\displaystyle\exp(\varphi\_{p}(\boldsymbol{\tau}^{t}|\mathcal{S},\mathcal{G})+\varphi\_{o}(\boldsymbol{\tau}^{t}|\mathcal{S}).$ |  | (6) |

Here, $\varphi\_{o}(\boldsymbol{\tau}^{t}|\mathcal{S})$ denotes the objective for optimizing the trajectory with scene condition and is independent of task goal $\mathcal{G}$. In scene understanding, $\varphi\_{o}$ usually denotes plausible physical relationships (*e.g*., collision, contact, and intersection). $\varphi\_{p}(\boldsymbol{\tau}^{t}|\mathcal{S},\mathcal{G})$ indicates the objective for planning (*i.e*., goal-reaching) with scene condition. Both $\varphi\_{o}$ and $\varphi\_{p}$ can be explicitly defined or implicitly learned from observed trajectories with proper parametrization.

### 4.1 Learning

$p\_{\theta}(\boldsymbol{\tau}^{0}|\mathcal{S})$ is the scene-conditioned generator, which can be learned by the conditional diffusion model with the simplified objective of estimating the noise $\boldsymbol{\epsilon}$ [[19](#bib.bib19), [10](#bib.bib10), [20](#bib.bib20)], where

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{L}\_{\theta}(\boldsymbol{\tau}^{0}|\mathcal{S})=$ | $\displaystyle\mathbb{E}\_{t,\boldsymbol{\epsilon},\boldsymbol{\tau}^{0}}\!\left[\|\boldsymbol{\epsilon}-\boldsymbol{\epsilon}\_{\theta}(\sqrt{\hat{\alpha}^{t}}\boldsymbol{\tau}^{0}+\sqrt{1-\hat{\alpha}^{t}}\boldsymbol{\epsilon},t,\mathcal{S})\|^{2}\right]$ |  | (7) |
|  | $\displaystyle=$ | $\displaystyle\mathbb{E}\_{t,\boldsymbol{\epsilon},\boldsymbol{\tau}^{0}}\!\left[\|\boldsymbol{\epsilon}-\boldsymbol{\epsilon}\_{\theta}(\boldsymbol{\tau}^{t},t,\mathcal{S})\|^{2}\right],$ |  |

where $\hat{\alpha}^{t}$ is the pre-determined function in the forward process. With the learned $p\_{\theta}(\boldsymbol{\tau}^{0}|\mathcal{S})$, we sample $p(\boldsymbol{\tau}^{0}|\mathcal{S},\mathcal{G})$ by taking the advantage of the diffusion model’s flexible conditioning [[10](#bib.bib10), [23](#bib.bib23)]. Specifically, we approximate $p\_{\phi}(\mathcal{G}|\boldsymbol{\tau}^{t},\mathcal{S})$ using the Taylor expansion around $\boldsymbol{\tau}^{t}=\boldsymbol{\mu}$ at timestep $t$ as

|  |  |  |
| --- | --- | --- |
|  | $\log p\_{\phi}(\mathcal{G}|\boldsymbol{\tau}^{t},\mathcal{S})\approx(\boldsymbol{\tau}^{t}-\boldsymbol{\mu})\mathbf{g}+C,$ |  |

where $C$ is a constant, $\boldsymbol{\mu}=\boldsymbol{\mu}\_{\theta}(\boldsymbol{\tau}^{t},t,\mathcal{S})$ and $\boldsymbol{\Sigma}=\boldsymbol{\Sigma}\_{\theta}(\boldsymbol{\tau}^{t},t,\mathcal{S})$ are the inferred parameters of original diffusion process, and

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbf{g}=$ | $\displaystyle\nabla\_{\boldsymbol{\tau}^{t}}\log p\_{\phi}(\mathcal{G}|\boldsymbol{\tau}^{t},\mathcal{S})|\_{\boldsymbol{\tau}^{t}=\boldsymbol{\mu}}$ |  | (8) |
|  | $\displaystyle=$ | $\displaystyle\nabla\_{\boldsymbol{\tau}^{t}}(\varphi\_{o}(\boldsymbol{\tau}^{t}|\mathcal{S})+\varphi\_{p}(\boldsymbol{\tau}^{t}|\mathcal{S},\mathcal{G}))|\_{\boldsymbol{\tau}^{t}=\boldsymbol{\mu}}.$ |  |

Therefore, we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $p(\boldsymbol{\tau}^{t-1}|\boldsymbol{\tau}^{t},\mathcal{S},\mathcal{G})=\mathcal{N}(\boldsymbol{\tau}^{t-1};\boldsymbol{\mu}+\lambda\boldsymbol{\Sigma}\mathbf{g},\boldsymbol{\Sigma}),$ |  | (9) |

where $\lambda$ is the scaling factor for the guidance. With [Eq. 9](#S4.E9 "In 4.1 Learning ‣ 4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), we can sample $\boldsymbol{\tau}^{t}$ with the guidance of optimizing and planning objectives.

Of note, $\varphi\_{p}$ and $\varphi\_{o}$ serve as the pre-defined guidance for tilting the original trajectory with physical and goal constraints. However, they can also be learned from the observed trajectories. During training, we first fix the learned base model of $p\_{\theta}(\boldsymbol{\tau}^{0}|\mathcal{S})$, then learn $\phi\_{o}$ and $\phi\_{p}$ for optimization and planning with the following objective:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{L}\_{\phi}(\boldsymbol{\tau}^{0}|\mathcal{S},\mathcal{G})=\mathbb{E}\_{t,\boldsymbol{\epsilon},\boldsymbol{\tau}^{0}}\!\left[\|\boldsymbol{\epsilon}-\boldsymbol{\epsilon}\_{\theta}(\boldsymbol{\tau}^{t},t,\mathcal{S})-\boldsymbol{\Sigma}\mathbf{g}\|^{2}\right].$ |  | (10) |

[Alg. 1](#alg1 "In 4.1 Learning ‣ 4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") summarizes the training procedure.

Algorithm 1 Training of the SceneDiffuser

```
// train base generation model
Input: Trajectory in 3D scene (𝝉0,𝒮)(\boldsymbol{\tau}^{0},\mathcal{S})

1
repeat
   
              2
𝝉0∼p⁡(𝝉0|𝒮)\boldsymbol{\tau}^{0}\sim p(\boldsymbol{\tau}^{0}|\mathcal{S})
   
              3
ϵ∼𝒩⁡(𝟎,𝐈)\boldsymbol{\epsilon}\sim\mathcal{N}({\bf 0},{\bf I}), t∼𝒰⁡({1,⋯,T})t\sim\mathcal{U}(\{1,\cdots,T\})
   
              4
𝝉t=α^t​𝝉0+1−α^t​ϵ\boldsymbol{\tau}^{t}=\sqrt{\hat{\alpha}_{t}}\boldsymbol{\tau}_{0}+\sqrt{1-\hat{\alpha}_{t}}\boldsymbol{\epsilon}
   
              5
θ=θ−η​∇θ‖ϵ−ϵθ​(𝝉t,t,𝒮)‖22\theta=\theta-\eta\nabla_{\theta}\|{\bf\boldsymbol{\epsilon}}-{\bf\boldsymbol{\epsilon}}_{\theta}(\boldsymbol{\tau}^{t},t,\mathcal{S})\|^{2}_{2}

6
until converged;

7
// (optional) train optimization and planning model
Input: Trajectory in 3D scene with goal (𝝉0,𝒮,𝒢)(\boldsymbol{\tau}^{0},\mathcal{S},\mathcal{G}), learned θ\theta for pθ​(𝝉0|𝒮)p_{\theta}(\boldsymbol{\tau}^{0}|\mathcal{S})

8
repeat
   
              9
𝝉0∼p⁡(𝝉0|𝒮,𝒢)\boldsymbol{\tau}^{0}\sim p(\boldsymbol{\tau}^{0}|\mathcal{S},\mathcal{G})
   
              10
ϵ∼𝒩⁡(𝟎,𝐈)\boldsymbol{\epsilon}\sim\mathcal{N}({\bf 0},{\bf I}), t∼𝒰⁡({1,⋯,T})t\sim\mathcal{U}(\{1,\cdots,T\})
   
              11
𝝁=𝝁θ​(𝝉t,t,𝒮)\boldsymbol{\mu}=\boldsymbol{\mu}_{\theta}(\boldsymbol{\tau}^{t},t,\mathcal{S}), 𝚺=𝚺θ​(𝝉t,t,𝒮)\boldsymbol{\Sigma}=\boldsymbol{\Sigma}_{\theta}(\boldsymbol{\tau}^{t},t,\mathcal{S})
   
              12
𝐠=∇𝝉t​log​pϕ​(𝒢|𝝉t,𝒮)|𝝉t=𝝁\mathbf{g}=\nabla_{\boldsymbol{\tau}^{t}}\log p_{\phi}(\mathcal{G}|\boldsymbol{\tau}^{t},\mathcal{S})|_{\boldsymbol{\tau}^{t}=\boldsymbol{\mu}}
   
              13
𝝉t=α^t​𝝉0+1−α^t​ϵ\boldsymbol{\tau}^{t}=\sqrt{\hat{\alpha}_{t}}\boldsymbol{\tau}_{0}+\sqrt{1-\hat{\alpha}_{t}}\boldsymbol{\epsilon}
   
              14
ϕ=ϕ−η​∇ϕ‖ϵ−ϵθ​(𝝉t,t,𝒮)−λ​𝚺​𝐠‖22\phi=\phi-\eta\nabla_{\phi}\|{\bf\boldsymbol{\epsilon}}-{\bf\boldsymbol{\epsilon}}_{\theta}(\boldsymbol{\tau}^{t},t,\mathcal{S})-\lambda\boldsymbol{\Sigma}\mathbf{g}\|^{2}_{2}

15
until converged;
```

### 4.2 Sampling

With different sampling strategies, SceneDiffuser can generate, optimize, and plan the trajectory in 3D scenes, under a unified framework of guided sampling. [Alg. 2](#alg2 "In 4.2 Sampling ‣ 4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") summarizes the detailed sampling algorithm.

Algorithm 2 Sampling of the SceneDiffuser for generation, optimization, and planning

```
Modules : Model pθ(⋅|𝒮)p_{\theta}(\cdot|\mathcal{S}), optimization objective φo(⋅|𝒮)\varphi_{o}(\cdot|\mathcal{S}), and planner objective φp(⋅|𝒮,𝒢)\varphi_{p}(\cdot|\mathcal{S},\mathcal{G})

1
// one-step guided sampling

2
function sample (𝛕t,𝒥)(\boldsymbol{\tau}^{t},\mathcal{J}):
   
              3
𝝁=𝝁θ​(𝝉t,t,𝒮)\boldsymbol{\mu}=\boldsymbol{\mu}_{\theta}(\boldsymbol{\tau}^{t},t,\mathcal{S}), 𝚺=𝚺θ​(𝝉t,t,𝒮)\boldsymbol{\Sigma}=\boldsymbol{\Sigma}_{\theta}(\boldsymbol{\tau}^{t},t,\mathcal{S})
   
              4
𝝉t−1=𝒩⁡(𝝉t−1,𝝁+λ​𝚺​∇𝝉t(𝒥⁡(𝝉t|𝒮,𝒢))|𝝉t=𝝁,𝚺)\boldsymbol{\tau}^{t-1}=\mathcal{N}(\boldsymbol{\tau}^{t-1};\boldsymbol{\mu}+\lambda\boldsymbol{\Sigma}\nabla_{\boldsymbol{\tau}^{t}}(\mathcal{J}(\boldsymbol{\tau}^{t}|\mathcal{S},\mathcal{G}))|_{\boldsymbol{\tau}^{t}=\boldsymbol{\mu}},\boldsymbol{\Sigma})
   
              5
return 𝝉t−1\boldsymbol{\tau}^{t-1}

6
// physics-based generation
Input: initial trajectory 𝝉T∼𝒩⁡(𝟎,𝐈)\boldsymbol{\tau}^{T}\sim\mathcal{N}({\bf 0},{\bf I})

7
for t=T,⋯,1t=T,\cdots,1 do
   
              8
// sampling with optimization
   
              9
𝝉t−1=sample(𝝉t,φo(⋅|𝒮))\boldsymbol{\tau}^{t-1}=\textnormal{{{\bf sample}}}(\boldsymbol{\tau}^{t},\varphi_{o}(\cdot|\mathcal{S}))

10
return 𝝉0\boldsymbol{\tau}^{0}

11
// goal-oriented planning
Input: planning steps NN, starting state 𝐬^0\hat{\mathbf{s}}_{0}, initial plan 𝝉0T∼𝒩⁡(𝟎,𝐈)\boldsymbol{\tau}^{T}_{0}\sim\mathcal{N}({\bf 0},{\bf I})

12
i=1i=1

13
while not done and planning step i<Ni<N do
   
              14
for t=T,⋯,1t=T,\cdots,1 do
      
              15
𝝉it−1=sample(𝝉it,φo(⋅|𝒮)+φp(⋅|𝒮,𝒢))\boldsymbol{\tau}^{t-1}_{i}=\textnormal{{{\bf sample}}}(\boldsymbol{\tau}^{t}_{i},\varphi_{o}(\cdot|\mathcal{S})+\varphi_{p}(\cdot|\mathcal{S},\mathcal{G}))
      
              16
// planning as inpainting
      
              17
𝝉it−1[0:i]=𝐬^0:i\boldsymbol{\tau}^{t-1}_{i}[0:i]=\hat{\mathbf{s}}_{0:i}
   
              18
            Act a^i−1\hat{a}_{i-1} to reach 𝐬^i=𝝉i0​[i]\hat{\mathbf{s}}_{i}=\boldsymbol{\tau}^{0}_{i}[i], 𝐬^0:i=𝐬^0:i−1∪𝐬^i\hat{\mathbf{s}}_{0:i}=\hat{\mathbf{s}}_{0:i-1}\cup\hat{\mathbf{s}}_{i}
   
              19
            Increment planning step i=i+1i=i+1
```

#### Scene-aware Generation

Sampling $\boldsymbol{\tau}^{0}$ from the distribution $p\_{\theta}(\boldsymbol{\tau}^{0}|\mathcal{S})$ in [Eq. 3](#S4.E3 "In Generation ‣ 4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") directly solves the conditional generation tasks. The sampled trajectories represent diverse modes and possible interactions with the 3D scenes.

#### Physics-based Optimization

The physical relations between each state and the environment are defined by $\varphi\_{o}$ in [Eq. 4](#S4.E4 "In Optimization and Planning ‣ 4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") in a differentiable manner. For general optimization without the planning objective, the task goal $\mathcal{G}$ is to sample a plausible trajectory in 3D scenes. Therefore, we can draw physically plausible trajectories in 3D scenes by sampling from $p(\boldsymbol{\tau}^{0}|\mathcal{S},\mathcal{G})$ with [Eq. 9](#S4.E9 "In 4.1 Learning ‣ 4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes").

#### Goal-oriented Planning

The goal-oriented planning can be formulated as motion inpainting under the sampling framework. Given the start state $\hat{\mathbf{s}}\_{s}$ and the goal state $\hat{\mathbf{s}}\_{g}$, the planning module returns trajectory $\hat{\boldsymbol{\tau}}=(\hat{\mathbf{s}}\_{0},\hat{\mathbf{a}}\_{0},\cdots,\hat{\mathbf{s}}\_{i},\hat{\mathbf{a}}\_{i},\cdots,\hat{\mathbf{s}}\_{g})$ that can reach the goal state. We set the first state as $\hat{\mathbf{s}}\_{0}=\hat{\mathbf{s}}\_{s}$ and define the goal state and reward of goal-reaching in $\varphi\_{p}$. For each step $i$, we first keep the previous states and inpaint the remaining trajectory by sampling the goal-oriented SceneDiffuser with an iterative denoising process. Next, we take the action that can reach the next sampled state with $(\hat{\mathbf{a}}\_{i-1},\hat{\mathbf{s}}\_{i})$. As illustrated in [Alg. 2](#alg2 "In 4.2 Sampling ‣ 4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), we repeat the planning steps until reaching the goal or the maximal planning step. Our planner leverages the trajectory-level generator, thus more generalizable to long-horizon trajectories and novel scenes.

Figure 2: Model architecture of the SceneDiffuser. We use cross-attention to learn the relation between the input trajectory and scene condition. The optimizer and planner serve as the guidance for physically-plausible and goal-oriented trajectories.

### 4.3 Model Architecture

The design of SceneDiffuser follows the practices of conditional diffusion model [[49](#bib.bib49), [51](#bib.bib51), [20](#bib.bib20)]. Specifically, we augment the time-conditional diffusion model with cross-attention [[63](#bib.bib63)] for flexible conditioning. As shown in [Fig. 2](#S4.F2 "In Goal-oriented Planning ‣ 4.2 Sampling ‣ 4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), for each sampling step, the model computes the cross-attention between the 3D scene condition and input trajectory, wherein the key and value are learned from the condition, and the query is learned from the input trajectory. The computed vector is fed into a feed-forward layer to estimate the noise $\boldsymbol{\epsilon}$. The 3D scene is processed by a scene encoder (*i.e*., Point Transformer [[84](#bib.bib84)] or PointNet [[43](#bib.bib43)]). Please refer to the [Appendix B](#A2 "Appendix B Model Architectures ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") for details.

### 4.4 Objective Design

For optimization and planning objectives discussed in [Sec. 4](#S4 "4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), we consider two types of trajectory objectives: (i) trajectory-level objective, and (ii) the accumulation of step-wise objective.
For optimization, we consider step-wise collision and contact objective, as well as trajectory level smoothness objective, *i.e*., $\{\varphi\_{o}^{\text{collision}},\varphi\_{o}^{\text{contact}},\varphi\_{o}^{\text{smoothness}}\}$.
For planning, we consider the accumulation of simple step-wise distance *i.e*., $\varphi\_{p}^{L\_{2}}$.
Please refer to the [Appendix C](#A3 "Appendix C Objective Design ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") for implementation details of our objective design. Empirically, we observe that parameterizing the objectives with timestep $t$ and increasing the guidance during the last several diffusion steps will enhance the effect of guidance.

## 5 Experiments

To demonstrate SceneDiffuser is general and applicable to various scenarios, we evaluate SceneDiffuser on five scene understanding tasks. For generation, we evaluate the scene-conditioned human pose and motion generation and object-conditioned dexterous grasp generation. For planning, we evaluate the path planning for 3D navigation and motion planning for robot arms. We first introduce the compared methods used in our experiments, followed by detailed settings, results analyses, and ablative studies for each task. Due to the page limit, we refer to the Appendix for more details about the implementation, experimental settings, and additional results and ablations.

### 5.1 Compared Methods

For conditional generation tasks, we primarily compare SceneDiffuser with the widely-adopted cvae model [[32](#bib.bib32), [83](#bib.bib83), [25](#bib.bib25), [70](#bib.bib70), [31](#bib.bib31)] and its variants. We also compare with strategies for optimizing the physics of the trajectory in the cvae, including integrating into training as loss and plugging upon as the post-optimization. For planning, we compare with a stochastic planner learned by imitation learning using bc (bc) and a simple heuristic-based deterministic planner guided by $L\_{2}$ distance.

### 5.2 Human Pose Generation in 3D Scenes

#### Setup

Scene-conditioned human pose generation aims to generate semantically plausible and physically feasible single-frame human bodies within the given 3D scenes. We evaluate the task on the 12 indoor scenes provided by PROX [[15](#bib.bib15)] and the refined version of PROX’S per-frame SMPL-X parameters from LEMO [[79](#bib.bib79)]. The input is the colored point cloud extracted by randomly downsampling the scene meshes provided in PROX. Training/testing splits are created following the literature [[83](#bib.bib83), [67](#bib.bib67)], resulting in $\sim{}53$k frames in 8 scenes for training and others for testing.

Table 1: Quantitative results of human pose generation in 3D scenes. We report metrics for physical plausibility and diversity.

|  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| model | plausible rate$\uparrow$ | non-collision score$\uparrow$ | contact score$\uparrow$ | APD (trans.)$\uparrow$ | std (trans.)$\uparrow$ | APD (param)$\uparrow$ | std (param)$\uparrow$ | APD (marker)$\uparrow$ | std (marker)$\uparrow$ |
| cvae (w/o. $L\_{\text{HS}}$)  [[83](#bib.bib83)] | 12.57 | 99.78 | 96.42 | 1.218 | 0.494 | 2.878 | 0.166 | 3.638 | 0.172 |
| cvae (w/ $L\_{\text{HS}}$) [[83](#bib.bib83)] | 14.64 | 99.75 | 99.25 | 1.013 | 0.416 | 2.994 | 0.170 | 3.614 | 0.169 |
| our (w/o opt.) | 24.83 | 99.74 | 99.43 | 0.776 | 0.331 | 3.204 | 0.195 | 3.483 | 0.167 |
| our (w/ opt.) | 49.35 | 99.93 | 98.05 | 1.009 | 0.413 | 3.297 | 0.197 | 3.679 | 0.177 |

Table 2: Quantitative results of human motion generation in 3D scenes. We report model variants with and without the start pose.

|  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| model | plausible rate$\uparrow$ | non-collision score$\uparrow$ | contact score$\uparrow$ | APD (trans.)$\uparrow$ | std (trans.)$\uparrow$ | APD (param)$\uparrow$ | std (param)$\uparrow$ | APD (marker)$\uparrow$ | std (marker)$\uparrow$ |
| cvae (w/o start) [[70](#bib.bib70)] | 5.88 | 99.86 | 86.26 | 1.628 | 0.613 | 2.766 | 0.155 | 3.275 | 0.150 |
| ours (w/o start) | 24.70 | 99.71 | 97.92 | 0.568 | 0.237 | 2.339 | 0.126 | 3.299 | 0.151 |
| ours (w/o start & w/ opt.) | 23.53 | 99.70 | 97.84 | 0.542 | 0.226 | 2.338 | 0.125 | 3.301 | 0.151 |
| cvae (w/ start) [[70](#bib.bib70)] | 16.24 | 99.88 | 95.44 | 0.478 | 0.188 | 1.747 | 0.091 | 2.308 | 0.105 |
| Ours (w/ start) | 41.76 | 99.85 | 99.63 | 0.193 | 0.081 | 1.372 | 0.065 | 1.568 | 0.072 |
| Ours (w/ start & w/ opt.) | 42.30 | 99.85 | 99.62 | 0.192 | 0.080 | 1.368 | 0.063 | 1.565 | 0.075 |

Figure 3: Qualitative results of human pose generation in 3D scenes. From left to right: (a) cvae generation, (b) SceneDiffuser generation without optimization, and poses generated (c) with and (d) without applying our optimization-guided sampling.

#### Metrics

We evaluate the physical plausibility of generated poses with both direct human evaluations and indirect collision and contact scores. For the direct measure, we randomly selected 1000 frames in the four test scenes and instructed seven participants to decide whether the generated human pose was plausible. We compute the mean percentage of plausible generation and term this metric as the plausible rate. For indirect measures, we report (i) the non-collision score of the generated human bodies by calculating the proportion of the scene vertices with positive SDF to the human body and (ii) the contact score by checking if the body contact with the scene in a distance [[15](#bib.bib15)] below a pre-defined threshold. Following the literature [[77](#bib.bib77), [83](#bib.bib83)], we evaluate the diversities of global translation, generated SMPL-X parameters, and the marker-based body-mesh representation [[82](#bib.bib82)]. Specifically, we calculate the diversity of generated pose with the Average Pairwise Distance (APD) and standard deviation (std).

#### Results

[Tab. 1](#S5.T1 "In Setup ‣ 5.2 Human Pose Generation in 3D Scenes ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") quantitatively demonstrates that SceneDiffuser generates significantly better poses while maintaining generation diversity. We further provide qualitative comparisons between baseline models and SceneDiffuser in [Fig. 3](#S5.F3 "In Setup ‣ 5.2 Human Pose Generation in 3D Scenes ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"). While achieving a comparable performance of diversity, collision, and contact, our model generates results that contain considerably more physically plausible poses (*e.g*., floating, severe collision). This is reflected by the significant superiority (*i.e*., over 30%) over cvae-based baselines on plausible rates. We observe this large improvement both quantitatively from the plausible rate and non-collision score and qualitatively in [Fig. 3](#S5.F3 "In Setup ‣ 5.2 Human Pose Generation in 3D Scenes ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"). Notably, our optimization-guided sampling improves the generator with 25% on the plausible rate, showing the efficacy of the proposed optimization-guided sampling strategy and its potential for a broader range of 3D tasks with physic-based constraints or objectives.

### 5.3 Human Motion Generation in 3D Scenes

#### Setup

We consider generating human motion sequences under two different settings: (1) condition solely on the 3D scene, and (2) condition on both the starting pose and the 3D scene. We use the same human and scene representation as in [Sec. 5.2](#S5.SS2 "5.2 Human Pose Generation in 3D Scenes ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") and clip the original LEMO motion sequence into segments with a fixed duration (60 frames). In total, we obtain 28k motion segments with the distance between each start and end pose being longer than 0.2 meters. We follow the same split in [Sec. 5.2](#S5.SS2 "5.2 Human Pose Generation in 3D Scenes ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") for training/testing and the same evaluation metrics for the pose generation. We report the average values of pose metrics over motion sequence as our performance measure.

Figure 4: Human motions generated by SceneDiffuser. Each row shows sampled human motions from the same start pose.

Figure 5: Qualitative results of dexterous grasp generation. Compared to grasps generated by cvae (first row), SceneDiffuser (second row) generates fewer colliding or floating poses, which helps to achieve a higher success rate.

#### Results

As quantitatively shown in [Tab. 2](#S5.T2 "In Setup ‣ 5.2 Human Pose Generation in 3D Scenes ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), SceneDiffuser consistently generates high-quality motion sequences compared to cvae baselines. Specifically, our generated motion outperforms baseline models on both plausible rate and contact scores. This performance gain indicates better coverage of motion that involves rich interaction with the scene while remaining physically plausible. It also causes lower diversity in metrics (*e.g*., translation variance) since the plausible space for the motion is limited compared with cvae. Empirically, we observe that providing the start position of motion as a condition constrains possible future motion sequences and leads to a drop in generation diversity for all models. In addition, providing the start condition benefits the physical plausibility since the motion starts from a plausible pose. We also note only a marginal performance improvement after applying optimization-guided sampling. One potential reason is that the generated motions are already plausible and receive small guidance from the optimization. As qualitatively shown in [Fig. 4](#S5.F4 "In Setup ‣ 5.3 Human Motion Generation in 3D Scenes ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), SceneDiffuser generates diverse motions (*e.g*., “sit,” “walk”) from the same start position in unseen 3D scenes.

### 5.4 Dexterous Grasp Generation for 3D Objects

#### Setup

Dexterous grasp generation aims to generate diverse and stable grasping poses for the given object with a human-like dexterous hand. We use the Shadowhand subset of the MultiDex [[31](#bib.bib31)] dataset, which contains diverse dexterous grasping poses for 58 daily objects. We represent the pose of Shadowhand as $q\coloneq(t,R,\theta)\in\mathbb{R}^{33}$, where $t\in\mathbb{R}^{3}$ and $R\in\mathbb{R}^{6}$ denote the global translation and orientation respectively, and $\theta\in\mathbb{R}^{24}$ describes the rotation angles of the revolute joints. An object is represented by its point cloud $\mathcal{O}\in\mathbb{R}^{2048\times 3}$. We split the dataset into 48 seen objects and 10 unseen objects for training and testing, respectively.

#### Metrics

We evaluate models in terms of success rate, diversity, and collision depth. We test if a grasp is successful in IsaacGym [[35](#bib.bib35)] by applying external forces to the object and measuring the movement of the object. To measure how learned models capture the diversity of successful grasping pose in the training data, we report the success rate of generated poses that lies at different variance levels from the mean pose of training data. We measure the collision depth as the maximum depth that the hand penetrates the object in each successful grasp for testing models’ performance on physically correct grasps. In all cases, we ignore the root transformation of the hand as it does not contribute to the diversity of grasping types.

Table 3: Quantitative results of dexterous grasp generation on MultiDex [[31](#bib.bib31)] dataset. We measure the success rates under different diversities and depth collisions. TTA. denotes test-time optimization with physics and contact.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| model | succ. rate (%)$\uparrow$ | | | depth coll. (mm)$\downarrow$ |
| $\sigma$ | $2\sigma$ | all |
| cvae [[25](#bib.bib25)] | 0.00 | 10.09 | 14.06 | 22.98 |
| cvae (w/ TTA.) [[25](#bib.bib25)] | 0.00 | 21.91 | 17.97 | 15.19 |
| ours (w/o opt.) | 70.65 | 71.25 | 71.25 | 17.34 |
| ours (w/ opt.) | 71.27 | 69.84 | 69.84 | 14.61 |

#### Results

[Tab. 3](#S5.T3 "In Metrics ‣ 5.4 Dexterous Grasp Generation for 3D Objects ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") quantitatively demonstrates that SceneDiffuser generates significantly better grasp poses in terms of success rate while correctly balancing the diversity of generation and grasp success. This result indicates that the SceneDiffuser achieves a consistently high success rate without much performance drop when the generated pose diverges from the mean pose in the training data. We also show that, by applying optimizer upon SceneDiffuser, the guided sampling process can reduce the violation of physically implausible grasping poses, outperforming the state-of-the-art baseline [[25](#bib.bib25)] without additional training or intermediate representation (*i.e*., contact maps). We provide qualitative results in [Fig. 5](#S5.F5 "In Setup ‣ 5.3 Human Motion Generation in 3D Scenes ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") for visualization.

### 5.5 Path Planning for 3D Scene Navigation

#### Setup

We manually selected 61 indoor scenes from ScanNet [[9](#bib.bib9)] to construct room-level scenarios for navigational path planning and annotated these scenes with navigation graphs. As shown in [Fig. 6(b)](#S5.F6.sf2 "In Figure 6 ‣ Setup ‣ 5.5 Path Planning for 3D Scene Navigation ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), these annotations are more spatially dense and physically plausible compared to previous methods [[1](#bib.bib1)]. We represent the physical robot with a cylinder to simulate physically plausible trajectories; see [Fig. 6(a)](#S5.F6.sf1 "In Figure 6 ‣ Setup ‣ 5.5 Path Planning for 3D Scene Navigation ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"). In total, we collected around 6k trajectories by searching the shortest paths between the randomly selected start and target nodes on the graph. We use trajectories in 46 scenes for training and trajectories in the rest 15 scenes for evaluation. Models take the input as the scene point cloud $\mathcal{S}\in\mathbb{R}^{32768\times 3}$, a given start position $\hat{\mathbf{s}}\_{0}\in\mathbb{R}^{2}$, and a target position $\mathcal{G}\in\mathbb{R}^{2}$ on the floor plane.

(a) path planning

(b) navigation graph

Figure 6: Path planning for 3D scene navigation. SceneDiffuser generates trajectories in long-horizon tasks.

#### Metrics

We evaluate the planned results by checking if the “robot” can move from the start to the target without collision along the planned trajectory. We report the average success rate and planning steps over all test cases.

#### Results

As shown in [Tab. 4](#S5.T4 "In Results ‣ 5.5 Path Planning for 3D Scene Navigation ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), SceneDiffuser outperforms both the bc and the deterministic planner baseline. These results indicate the efficacy of guided sampling with the planning objective, especially given that all test scenes are unseen during training. Crucially, as simple heuristics (like $L\_{2}$) oftentimes lead to dead-ends in path planning, SceneDiffuser can correctly combine past knowledge on the scene-conditioned trajectory distribution and planning objective under specific unseen scenes to redirect planning direction, which helps to avoid obstacles and dead-ends to reach the goal successfully.
Compared with the baseline models, our model also requires fewer planning steps while maintaining a higher success rate.
This suggests that SceneDiffuser successfully navigates to the target without diverging even in long-horizon tasks, where classic RL-based stochastic planners suffer (*i.e*., the low performance of bc).

Table 4: Quantitative results of path planning in 3D navigation and motion planning for robot arms.

|  |  |  |  |
| --- | --- | --- | --- |
| task | model | succ. rate(%)$\uparrow$ | planning steps$\downarrow$ |
| path plan | bc | 0 | 150 |
| deterministic($L\_{2}$) | 13.50 | 137.98 |
| ours | 73.75 | 90.38 |
| arm motion | bc | 0.31 | 299.08 |
| deterministic($L\_{2}$) | 72.87 | 141.28 |
| ours | 78.59 | 147.60 |

### 5.6 Motion Planning for Robot Arms

#### Setup

Aiming to generate valid robot arm motion trajectories in cluttered scenes, we used the Franka Emika arm with seven revolute joints and collected 19,800 trajectories over 200 randomly generated cluttered scenes using the MoveIt 2.0 [[48](#bib.bib48)], as shown in [Fig. 7](#S5.F7 "In Results ‣ 5.6 Motion Planning for Robot Arms ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"). We represent the scene with point clouds $\mathcal{S}\in\mathbb{R}^{4096\times 3}$ and the robot arm trajectory with a sequence of joint angles $\mathcal{R}\in[-\pi,\pi]$. We train our model on 160 scenes and test on 40 unseen scenes.

#### Metrics

Similar to [Sec. 5.5](#S5.SS5 "5.5 Path Planning for 3D Scene Navigation ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), we evaluate the generated trajectories by success rate on unseen scenes and the average number of planning steps. We consider a trajectory successful if the robot arm reaches the goal pose by a certain distance threshold within a limited number of steps.

#### Results

We observe similar overall performance as in [Sec. 5.5](#S5.SS5 "5.5 Path Planning for 3D Scene Navigation ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"). [Tab. 4](#S5.T4 "In Results ‣ 5.5 Path Planning for 3D Scene Navigation ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") shows that SceneDiffuser consistently outperforms both the RL-based bc baseline and the deterministic planner baseline. SceneDiffuser’s planning steps for successful trials are also comparable with the deterministic planner, showing the efficacy of the planner in long-horizon scenarios.

(a) motion planning

(b) cluttered scenes

Figure 7: Motion planning for robot arms. SceneDiffuser generates arm motions in tabletop scenes with obstacles.

### 5.7 Ablation Analyses

We explore how the scaling coefficient $\lambda$ influences the human pose generation results. We report the diversity and physics metrics of sampling results under different $\lambda$s, ranging from 0.1 to 100.
As shown in [Tab. 5](#S5.T5 "In 5.7 Ablation Analyses ‣ 5 Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), $\lambda$ balances generation collision/contact and diversity in human pose generation. Specifically, $\lambda=1.0$ leads to the best physical plausibility while larger $\lambda$ values lead to diverse generation results. We attribute this effect to the optimization as with bigger $\lambda$s; the optimization will draw poses away from the scene. Due to the page limit, we provide more ablative studies in [Appendix E](#A5 "Appendix E Additional Ablative Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), including the sampling steps, choices and hyperparameters of objectives, and model architectures.

Table 5: Ablation of the scale coefficient for optimization.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| metric | $\lambda=0.1$ | $\lambda=1.0$ | $\lambda=10.0$ | $\lambda=100.0$ |
| plausible rate $\uparrow$ | 28.75 | 52.5 | 21.25 | 0 |
| APD (trans.) $\uparrow$ | 0.764 | 0.886 | 1.564 | 23.96 |
| APD (param) $\uparrow$ | 3.206 | 3.243 | 9.040 | 573.6 |
| non-collison score $\uparrow$ | 99.76 | 99.87 | 99.85 | 74.9 |
| contact score $\uparrow$ | 99.70 | 99.65 | 81.75 | 0.0 |

### 5.8 Limitation

The primary limitation of the SceneDiffuser is its slow training and test speed compared to previous scene-conditioned generative models, a common issue of diffusion-based methods. We also observe that the optimization and planning are highly dependent on the objective designs, which requires efforts on hyper-parameter tuning.

## 6 Conclusion

We propose the SceneDiffuser as a general conditional generative model for generation, optimization, and planning in 3D scenes. SceneDiffuser is designed with appealing properties including scene-aware, physics-based, and goal-oriented. We demonstrate that the SceneDiffuser outperforms previous models by a large margin on various tasks, establishing its efficacy and flexibility.

A promising future direction is extending SceneDiffuser to richer 3D representations, including RGB-D images, semantic images, bird-eye view (BEV) images, videos, 3D meshes, and neural radiance field (NeRF) [[36](#bib.bib36)]. Such flexible conditions consume a tremendous amount of 3D training data, which is also a significant challenge. We also hope to extend the SceneDiffuser to outdoor scenes, *e.g*., the autonomous driving scenarios [[3](#bib.bib3)]. Moreover, the SceneDiffuser can be combined with recent large language models (LLMs) [[2](#bib.bib2)] for automatic generation and planning with natural language instructions in 3D scenes, which is promising for the vision and robotics community. Finally, SceneDiffuser can serve as the tool for analyzing the behaviors of humans and agents if we can properly learn the planning objective, which naturally encodes the values and preferences that underlie the trajectories.

## 7 Acknowledgement

We thank Ruiqi Gao and Ying Nian Wu for their helpful discussions and suggestions. This work is supported in part by the National Key R&D Program of China (2021ZD0150200) and the Beijing Nova Program.

## Appendix A Background for Diffusion Model

A diffusion model [[55](#bib.bib55), [19](#bib.bib19)] is defined by a forward process that gradually corrupts data $\boldsymbol{\tau}^{0}\sim q(\boldsymbol{\tau}^{0})$ over $T$ timesteps

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle q(\boldsymbol{\tau}^{1:T}|\boldsymbol{\tau}^{0})$ | $\displaystyle=\prod\_{t=1}^{T}q(\boldsymbol{\tau}^{t}|\boldsymbol{\tau}^{t-1})$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle q(\boldsymbol{\tau}^{t}|\boldsymbol{\tau}^{t-1})$ | $\displaystyle=\mathcal{N}(\boldsymbol{\tau}^{t};\sqrt{1-\beta^{t}}\boldsymbol{\tau}^{t-1},\beta\mathbf{I})$ |  |

and a reverse process $p\_{\theta}(\boldsymbol{\tau}^{0})=\int p\_{\theta}(\boldsymbol{\tau}^{0:T})d\boldsymbol{\tau}^{1:T}$ where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle p\_{\theta}(\boldsymbol{\tau}^{0:T})$ | $\displaystyle=p(\boldsymbol{\tau}^{T})\sum\_{t=1}^{T}p\_{\theta}(\boldsymbol{\tau}^{t-1}|\boldsymbol{\tau}^{t})$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle p\_{\theta}(\boldsymbol{\tau}^{t-1}|\boldsymbol{\tau}^{t})$ | $\displaystyle=\mathcal{N}(\boldsymbol{\tau}^{t-1};\boldsymbol{\mu}\_{\theta}(\boldsymbol{\tau}^{t},t),\boldsymbol{\Sigma}\_{\theta}(\boldsymbol{\tau}^{t},t)).$ |  |

The forward process hyperparameters $\beta^{t}$ are set so that $\boldsymbol{\tau}^{T}$ is approximately distributed according to a standard normal distribution, so $\boldsymbol{\tau}^{T}$ is set to a standard normal prior as well. The reverse process is trained to match the joint distribution of the forward process by optimizing the evidence lower bound (ELBO) [[55](#bib.bib55), [19](#bib.bib19)]. As suggested by the literature [[19](#bib.bib19), [39](#bib.bib39)], we can use the reverse process parametrizations as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\boldsymbol{\mu}\_{\theta}(\boldsymbol{\tau}^{t},t)$ | $\displaystyle=\frac{1}{\sqrt{\alpha^{t}}}(\boldsymbol{\tau}^{t}-\frac{\beta^{t}}{\sqrt{1-\hat{\alpha^{t}}}}\boldsymbol{\epsilon}\_{\theta}(\boldsymbol{\tau}^{t},t))$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\boldsymbol{\Sigma}\_{\theta}^{ii}(\boldsymbol{\tau}^{t},t)$ | $\displaystyle=\exp(\log\hat{\beta}^{t}+(\log\beta^{t}-\log\hat{\beta}^{t})v\_{\theta}^{i}(\boldsymbol{\tau}^{t},t))$ |  |

where $\alpha^{t}=1-\beta^{t}$, $\hat{\alpha}^{t}=\sum^{t}\_{s=1}\alpha^{s}$, and $\hat{\beta}^{t}=\frac{1-\hat{\alpha}^{t-1}}{1-\hat{\alpha}^{t}}\beta^{t}$.

We can optimize modified loss instead of the ELBO to improve the sample quality, depending on whether we learn $\boldsymbol{\Sigma}$ or treat it as a fixed hyper-parameter. For the non-learned case, we use the simplified loss:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{L}\_{simple}(\theta)$ | $\displaystyle=\mathbb{E}\_{t,\boldsymbol{\epsilon},\boldsymbol{\tau}^{0}}\!\left[\|\boldsymbol{\epsilon}-\boldsymbol{\epsilon}\_{\theta}(\sqrt{\hat{\alpha}^{t}\boldsymbol{\tau}^{0}}+\sqrt{1-\hat{\alpha}^{t}}\boldsymbol{\epsilon},t)\|^{2}\right]$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\mathbb{E}\_{t,\boldsymbol{\epsilon},\boldsymbol{\tau}^{0}}\!\left[\|\boldsymbol{\epsilon}-\boldsymbol{\epsilon}\_{\theta}(\boldsymbol{\tau}^{t},t)\|^{2}\right]$ |  |

It is a weighted form of the ELBO that resembles denoising score matching over multiple noise scale [[19](#bib.bib19), [57](#bib.bib57)].

#### Conditional Diffusion Model

The goal of the conditional diffusion model is to learn a conditional distribution $p\_{\theta}(\boldsymbol{\tau}^{0}|\mathbf{c})$. We modify the diffusion model to include the condition $\mathbf{c}$ as input to the inverse process:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle p\_{\theta}(\boldsymbol{\tau}^{0:T}|\mathbf{c})$ | $\displaystyle=p(\boldsymbol{\tau}^{T})\prod^{T}\_{t=1}p\_{\theta}(\boldsymbol{\tau}^{t-1}|\boldsymbol{\tau}^{t},\mathbf{c})$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle p\_{\theta}(\boldsymbol{\tau}^{t-1}|\boldsymbol{\tau}^{t},\mathbf{c})$ | $\displaystyle=\mathcal{N}(\boldsymbol{\tau}^{t-1};\boldsymbol{\mu}\_{\theta}(\boldsymbol{\tau}^{t},t,\mathbf{c}),\boldsymbol{\Sigma}\_{\theta}(\boldsymbol{\tau}^{t},t,\mathbf{c}))$ |  |

## Appendix B Model Architectures

For the tasks of human pose/motion generation in 3D scenes and path planning for 3D scene navigation, we use the same scene encoder, *i.e*., the PointTransformer [[84](#bib.bib84)] adopted from the original architecture. We pre-train the scene encoder with indoor scene semantic segmentation task on ScanNet dataset and freeze it while training SceneDiffuser. The outputs of the scene encoder are used as the key and value of the cross-attention module.

For processing the trajectory, we employ an FC layer and positional embedding to obtain the high-dimensional feature of the trajectory. We then fuse the trajectory feature with denoising timestep embedding with a ResBlock. After that, we feed the fused feature vectors to a self-attention module and use them as the query of the cross-attention module. Finally, the computed vector is fed into a feedforward layer to estimate the noise $\boldsymbol{\epsilon}$.

For the task of dexterous grasp generation for 3D objects, we use PointNet [[43](#bib.bib43)] as the 3D object encoder. Before the cross-attention module, the outputs of PointNet are reshaped to $(N\_{\text{token}},N\_{\text{feat}})$, where $N\_{\text{token}}$ refers to the number of tokens and $N\_{\text{feat}}$ refers to the dimensions of the feature.

For the task of motion planning for robot arms, we adopt PointTransformer [[84](#bib.bib84)] as the scene encoder, which is jointly trained from scratch with SceneDiffuser.

## Appendix C Objective Design

For human pose and motion generation in 3D scenes, we encourage contact and non-collision between the generated human body meshes and the scene meshes. Following [[83](#bib.bib83)], we design optimization objective $\varphi\_{o}(\boldsymbol{\tau}^{t}|\mathcal{S})=\alpha\_{1}\varphi\_{o}^{\text{collision}}+\alpha\_{2}\varphi\_{o}^{\text{contact}}$ for pose generation and $\varphi\_{o}(\boldsymbol{\tau}^{t}|\mathcal{S})=\alpha\_{1}\varphi\_{o}^{\text{collision}}+\alpha\_{2}\varphi\_{o}^{\text{contact}}+\alpha\_{3}\varphi\_{o}^{\text{smoothness}}$ for motion generation. $\alpha$ is the balancing weight.
$\varphi\_{o}^{\text{collision}}$ minimizes the negative signed-distance values of the body mesh vertices given the negative signed distance field (SDF) of the 3D scene $\Phi\_{s}^{-}(\cdot)$, which is formulated as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\varphi\_{o}^{\text{collision}}=-\mathbb{E}\left[|\Phi\_{s}^{-}(\mathcal{M}^{t})|\right],$ |  | (A1) |

where $\mathcal{M}^{t}$ is the SMPL-X body mesh at denoising step $t$.
$\varphi\_{o}^{\text{contact}}$ minimize the distance between contact body parts of the generated body mesh and the scene mesh, which is formulated as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\varphi\_{o}^{\text{contact}}=-\sum\_{v\_{c}\in C(\mathcal{M}^{t})}\min\_{v\_{s}\in\mathcal{S}}|v\_{c}-v\_{s}|,$ |  | (A2) |

where $C(\cdot)$ is the operation of selecting contact part vertices from the SMPL-X body mesh according to the annotation in [[15](#bib.bib15)].
We design the smoothness objective to smooth the motion over time by minimizing the velocity difference of consecutive frames, which is formulated as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\varphi\_{o}^{\text{smoothness}}=-\sum\_{v\in\mathcal{M}^{t}}\sum\_{i=1}^{L-2}\|v^{i+2}-2v^{i+1}+v^{i}\|^{2},$ |  | (A3) |

where $L$ is the length of the motion sequence.
We empirically set $\alpha\_{1}=1.0$, $\alpha\_{2}=0.02$, and $\alpha\_{3}=0.001$.

For dexterous grasp generation, we punish the collision between the robotic hand mesh and the object mesh. We design optimization $\varphi\_{o}(\boldsymbol{\tau}^{t}|\mathcal{S})=\varphi\_{o}^{\text{collision}}$. $\varphi\_{o}^{\text{collision}}$ is similar to [Eq. A1](#A3.E1 "In Appendix C Objective Design ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), where 3D scene is represented as an object and $\mathcal{M}^{t}$ as the robotic hand mesh at denoising step $t$.

For path planning for the 3D scene navigation task, we design an optimization objective $\varphi\_{o}$ and $\varphi\_{p}$ for generating collision-free paths toward the goals.
The collision-free objective maximizes the distance between the robot and the scene vertices in the robot cylinder, formulated as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\varphi\_{o}=-\sum\_{i=1}^{L}\sum\_{v\_{s}\in\mathcal{S}}\text{ReLU}(r-\text{dist}(v\_{s},\tau^{t}\_{i})),$ |  | (A4) |

where $\text{ReLU}(x)=\text{max}(0,x)$, $r$ is the radius of the robot cylinder, and $\text{dist}(\cdot)$ compute the Euler distance between scene vertices and robot position on the 2D plane.
The planning objective $\varphi\_{p}$ encourages the generated paths toward the target position. In our work, we formulate it as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\varphi\_{p}=\sum\_{i=1}^{L}\exp\left(\frac{1}{\|\mathcal{G}-\tau^{t}\_{i}\|\_{1}}\right).$ |  | (A5) |

For robot arm motion planning, we design the planning objective $\varphi\_{p}$ similar to [Eq. A5](#A3.E5 "In Appendix C Objective Design ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes").
The objective is defined as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\varphi\_{p}=\sum\_{i=1}^{L}\exp\left(\frac{1}{\sum\_{j=1}^{N}\|\mathcal{G}\_{j}-\tau^{t}\_{ij}\|\_{1}}\right).$ |  | (A6) |

where $N$ denotes to the number of revolute joints and $j$ refers to $j$-th revolute joint.

## Appendix D Implementation Details

### D.1 Human Pose Generation in 3D Scenes

Following prior work [[83](#bib.bib83)], we represent the human body with the SMPL-X model. We denote the parameters of SMPL-X in our setting as $x\_{h}\coloneq(t,R,\beta,\theta\_{b})^{T}\in\mathbb{R}^{79}$, where $t$ is the global translation in meters, $R$ is the global orientation represented in axis-angle, $\beta\in\mathbb{R}^{10}$ is the body shape feature, and $\theta\_{b}\in\mathbb{R}^{63}$ is the axis-angle representation of 21 body joints.
SMPL-X can map these low-dimensional parameters into a watertight mesh with a fixed topology, enabling physical collision and contact modeling.
Unlike [[83](#bib.bib83)] using scene depth and semantics, we directly represent the scene with a point cloud $\mathcal{S}\in\mathbb{R}^{32768\times 3}$, which provides raw information about the 3D scene.

For quantitative evaluation, we randomly sample 1000 examples in each test scene to compute the diversity and physics metrics. Specifically, we separately calculate the Average Pairwise Distance (APD) and standard deviation (std) for global translation $t\in\mathbb{R}^{3}$, the rest of local SMPL-X parameters $(R,\beta,\theta\_{b})^{T}\in\mathbb{R}^{76}$, and the marker-based representation [[82](#bib.bib82)] of generated bodies without global translation.
We also report the non-collision score of the generated human bodies by calculating the proportion of the scene vertices with positive SDF to the human body and the contact score by checking whether the body contacts with the scene within a pre-defined distance threshold, *i.e*., 0.02m.

To train SceneDiffuser, we use Adam [[27](#bib.bib27)] optimizer with 0.0001 as the learning rate. We use 4 NVIDIA A100 GPUs to train 100 epochs with a batch size of 128. The number of diffusion steps $T$ in this task is set as 100. For optimization guidance sampling, we empirically set scale coefficient $\lambda=2.5$.

### D.2 Human Motion Generation in 3D Scenes

For the two different settings (with and without start position) of human motion generation in 3D scenes, we represent the single-frame human body of the motion sequence as the same as the pose generation.
To collect training data, we clip the motion sequences in the PROX dataset into motion segments with a fixed duration, *i.e*., 60 frames.
We use the same evaluation metrics as pose generation and report the average values over motion sequence as the motion generation performance measure.
In this task, the optimizer is Adam, and the learning rate is 0.0001. We use 4 NVIDIA A100 GPUs to train 300 epochs with 200 diffusion steps and 128 batch size. For optimization guidance sampling, we empirically set scale coefficient $\lambda=2.5$.

### D.3 Dexterous Grasp Generation for 3D Objetcs

We use Shadowhand as our dexterous robotic hand and denote qpos as $q\coloneq(t,R,\theta)\in\mathbb{R}^{33}$, where $t\in\mathbb{R}^{3}$ and $R\in\mathbb{R}^{6}$ represent the global translation and orientation respectively, $\theta\in\mathbb{R}^{24}$ describes the rotation angles of the revolute joints. We split the MultiDex [[31](#bib.bib31)] into 48 seen objects and 10 unseen objects for training and testing.

For each grasp, we apply $0.5\mathrm{ms}^{-2}$ acceleration to the object along $\pm xyz$ directions, and the grasping is successful if the movements of the object are all within $2\mathrm{cm}$. For the diversity, we first capture the mean $\mu\_{i}$ and the standard deviation $\sigma\_{i}$ of $i$ revolute joint in the training data grasping pose. We define the mean pose as $\mu\_{q}\coloneq(\mu\_{1},\mu\_{2},...,\mu\_{24})\in\mathbb{R}^{24}$ and the standard deviation pose as $\sigma\_{q}\coloneq(\sigma\_{1},\sigma\_{2},...,\sigma\_{24})\in\mathbb{R}^{24}$. We report the success rate of generated poses that lie at the $k$ standard deviation level, which means these poses $q$ satisfy the constraint as $\mu\_{q}-k\sigma\leq q\leq\mu\_{q}+k\sigma$. For the depth collision computation, we sample the surface points $\mathcal{H}\in\mathbb{R}^{3200\times 3}$ on the ShadowHand related to the pose $q$ and the surface points with normal $\mathcal{O}\in\mathbb{R}^{4096\times 6}$ on the object. We compute the collision for ShadowHand surface to the object and report the depth collision among $\mathcal{H}$ to show the quality of generated poses.

To train SceneDiffuser on this task, we use Adam optimizer, set the learning rate as 0.0001, and use 1 NVIDIA A100 GPU to train 2100 epochs with 64 batch size. For optimization guidance sampling, we empirically set scale coefficient $\lambda=1.0$.

### D.4 Path Planning for 3D Scene Navigation

In this task, we consider 3D navigation in realistic scenes, where the goal is to plan plausible trajectories for a physical robot from the given start position $\hat{\mathbf{s}}\_{0}$ to the given target position $\mathcal{G}$ in a furnished 3D indoor scene $\mathcal{S}$. We represent the hallucinated physical robot as a cylinder to simulate physically plausible trajectories which are collision-free in the 3D scene. The robot can move in all directions within a distance in each step without height change. We set the maximum moving distance as 0.08m, the robot radius as 0.08m, and the robot height as infinite, which means the robot can only move on the floor that is not occupied.

To construct room-level realistic scenarios for path planning, we manually select 61 indoor scenes from ScanNet [[9](#bib.bib9)], as shown in [Fig. A1](#A4.F1 "In D.4 Path Planning for 3D Scene Navigation ‣ Appendix D Implementation Details ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes").
We annotate these scenes with spatially dense and physically plausible navigation graphs and collect about 6.3k trajectories by searching the shortest paths between the randomly selected start and target graph nodes. As the distance between nodes may be too long for a robot to move in one step, we refined the trajectories according to the maximum moving distance. These trajectories have an average step of 60.0, a minimal step of 32, and a maximum step of 120. We use 4.7k trajectories in 46 scenes as the training data and the rest 1.6k trajectories in 15 unseen scenes for evaluation. We set the maximum number of planning steps as 150.

During training, we set the fixed trajectory horizon as 32. We use 4 NVIDIA A100 GPUs to train 50 epochs with 100 diffusion steps and a batch size of 128. The optimizer is Adam, and the learning rate is 0.0001. During inference, we empirically set the scale coefficient of optimization guidance as 1.0 and the scale coefficient of planning guidance as 0.2.

Figure A1: Scenes and corresponding navigation graphs for path planning. The selected scenes have various regions, diverse room types, and sufficient layout complexity.

### D.5 Motion Planning for Robot Arm

We use the Franka Emika with seven revolute joints as the robot arm and randomly generate cluttered tabletop scenes with primitives following specific heuristics. For each scene, we position the robot arm at the center of the table and use moveit2 motion planner [[48](#bib.bib48)] to synthesize trajectories constrained by a pair of start and goal poses of the end effector. We collected 19,800 collision-free trajectories over 200 clustered scenes.

During inference, we execute the planned motions of SceneDiffuser in IsaacGym [[35](#bib.bib35)]. We consider the planning is successful if our robot arm reaches the goal pose by a certain $L\_{2}$ norm distance (e.g., $0.2$) in the space of revolute joints. Note that the simulation can not run infinitely; therefore, we set a limited number of simulation steps (e.g., $300$). For the efficiency evaluation, we capture the average number of simulation steps.

To train SceneDiffuser on this task, we use Adam optimizer, set the learning rate as 0.0001, and use 4 NVIDIA A100 GPUs to train 200 epochs with 128 batch size. We empirically set the scale coefficient of planning guidance as 0.2 during inference.

### D.6 Scaling Factor for the Guidance

Similar to Ho *et al*. [[19](#bib.bib19)], we notice that the parameter $\Sigma$ in [Eq. 9](#S4.E9 "In 4.1 Learning ‣ 4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") decreases as the denoising step $t$ decreases, which gradually weakens the guidance during the denoising process. Instead of using a constant as the scaling factor, we empirically schedule the scaling factor by dividing it by $\Sigma$. It reformulates [Eq. 9](#S4.E9 "In 4.1 Learning ‣ 4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") as

|  |  |  |
| --- | --- | --- |
|  | $p(\boldsymbol{\tau}^{t-1}|\boldsymbol{\tau}^{t},\mathcal{S},\mathcal{G})\approx\mathcal{N}(\boldsymbol{\tau}^{t-1};\boldsymbol{\mu}+\lambda\mathbf{g},\boldsymbol{\Sigma})$ |  |

## Appendix E Additional Ablative Experiments

We ablate different model architectures, including the scene encoder and noise prediction module in SceneDiffuser, diffusion steps and scale coefficient in the optimizer of dexterous grasp generation task, and fixed frames and planning objectives of path planning for 3D scene navigation task.

### E.1 Model Architecture

As shown in [Tab. A1](#A5.T1 "In E.1 Model Architecture ‣ Appendix E Additional Ablative Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), we study how different scene model influences the dexterous grasp generation results. We use PointNet [[43](#bib.bib43)] and PointNet++ [[44](#bib.bib44)] as different scene models to extract the object feature. For more diversity evaluation, we capture the mean standard deviation among all revolute joints of the robotic hand qpos. We find that the global feature extracting from PointNet makes it easier for the model to learn a mean pose to obtain a higher grasping success rate. In contrast, the local feature extracting from PointNet++ makes the generated grasp pose more diverse.

Table A1: Ablation on different scene encoder.

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Scene Encoder | Succ. Rate (%)$\uparrow$ | | | Div. (rad.)$\uparrow$ | Coll. (mm)$\downarrow$ |
| $\sigma$ | $2\sigma$ | all |
| PointNet (w/o opt.) | 70.65 | 71.25 | 71.25 | 0.0718 | 17.34 |
| PointNet (w/ opt.) | 71.27 | 70.32 | 69.84 | 0.0838 | 14.61 |
| PointNet++ (w/o opt.) | 56.47 | 66.29 | 66.25 | 0.1568 | 18.53 |
| PointNet++ (w/ opt.) | 64.33 | 60.51 | 59.53 | 0.1670 | 14.37 |

As shown in [Tab. A2](#A5.T2 "In E.1 Model Architecture ‣ Appendix E Additional Ablative Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), we ablate the module for noise prediction. We compare the design of cross-attention and self-attention for processing the condition and input. Cross-attention indicates learning query from the input $\boldsymbol{\tau}\_{t}$ and learning key and value from the scene condition $\mathcal{S}$. Self-attention indicates concatenating $\boldsymbol{\tau}\_{t}$ and scene features $\mathcal{S}$ and learning with self-attention. Through our experiments, we find that with self-attention, the model learns better to capture the joint distribution of input and condition. This leads to a slightly lower diversity but better generation quality and success rate.

Table A2: Ablation on different model architecture.

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Epsilon Model | Succ. Rate (%)$\uparrow$ | | | Div. (rad.)$\uparrow$ | Coll. (mm)$\downarrow$ |
| $\sigma$ | $2\sigma$ | all |
| CrossAttn. (w/o opt.) | 70.65 | 71.25 | 71.25 | 0.0718 | 17.34 |
| CrossAttn. (w/ opt.) | 71.27 | 70.32 | 69.84 | 0.0838 | 14.61 |
| SelfAttn. (w/o opt.) | 74.27 | 75.94 | 75.94 | 0.0535 | 16.49 |
| SelfAttn. (w/ opt.) | 72.01 | 71.56 | 71.09 | 0.0605 | 13.94 |

### E.2 Diffusion Steps

We study different diffusion steps $T$ in [Tab. A3](#A5.T3 "In E.2 Diffusion Steps ‣ Appendix E Additional Ablative Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), where we use PointNet++ as the scene encoder with cross-attention design. We report the success rate, diversity, and depth collision of sampling results in the test set under different diffusion steps, ranging from 30 to 1000. $T$ balance the diversity and success rate in dexterous grasp generation, where $T=30$ leads to the best diversity of generated grasp pose and $T=1000$ leads to the best all success rate.

Table A3: Ablation on diffusion steps and scale coefficient.

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Time Steps | Optimizer Scale | Succ. Rate (%)$\uparrow$ | | | | Diversity (rad.)$\uparrow$ | Depth Collision (mm)$\downarrow$ |
| $\sigma$ | $2\sigma$ | $3\sigma$ | all |
| 30 | w/o | 0.00 | 60.01 | 50.94 | 48.13 | 0.3418 | 21.19 |
| 30 | 0.1 | 0.00 | 58.72 | 54.90 | 51.09 | 0.3415 | 19.96 |
| 30 | 0.5 | 0.00 | 64.24 | 51.63 | 47.81 | 0.3397 | 17.41 |
| 30 | 1.0 | 0.00 | 60.41 | 48.76 | 43.59 | 0.3393 | 16.05 |
| 100 | w/o | 0.00 | 66.62 | 60.12 | 58.91 | 0.2865 | 19.07 |
| 100 | 0.1 | 0.00 | 66.54 | 60.60 | 59.53 | 0.2836 | 17.55 |
| 100 | 0.5 | 0.00 | 61.23 | 56.71 | 53.75 | 0.2898 | 14.63 |
| 100 | 1.0 | 0.00 | 56.79 | 53.13 | 48.91 | 0.2920 | 14.53 |
| 500 | w/o | 75.00 | 67.50 | 67.34 | 67.34 | 0.1753 | 19.29 |
| 500 | 0.1 | 68.56 | 65.19 | 65.00 | 65.00 | 0.1733 | 17.68 |
| 500 | 0.5 | 62.83 | 60.25 | 58.94 | 58.75 | 0.1814 | 15.12 |
| 500 | 1.0 | 62.21 | 57.76 | 55.17 | 54.37 | 0.1872 | 14.36 |
| 1000 | w/o | 56.47 | 66.29 | 66.26 | 66.25 | 0.1568 | 18.53 |
| 1000 | 0.1 | 73.24 | 71.43 | 71.04 | 71.09 | 0.1572 | 16.88 |
| 1000 | 0.5 | 70.18 | 65.99 | 65.55 | 65.62 | 0.1611 | 14.37 |
| 1000 | 1.0 | 64.33 | 60.51 | 59.61 | 59.53 | 0.1670 | 14.37 |

### E.3 Scale Coefficient

Among different time steps $T$, we ablate scale coefficient $\lambda$ of the optimization guidance in dexterous grasp generation in [Tab. A3](#A5.T3 "In E.2 Diffusion Steps ‣ Appendix E Additional Ablative Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), ranging from $0.0$ (denoted as w/o in the table) to $1.0$. Through extensive experiments, we observe that, in general, the $\alpha$ trade off the depth collision and grasp success rate. A larger $\alpha$ value leads to fewer collisions and draws the grasp pose away from the object simultaneously, which losses the grasp stability and lowers the success rate.

We also ablate the scale coefficient of the planner in path planning for 3D scene navigation, as shown in [Tab. A4](#A5.T4 "In E.3 Scale Coefficient ‣ Appendix E Additional Ablative Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"). Too small or too large scale coefficients both lead to a performance drop. It is due to that a small value cannot provide sufficient guidance. In contrast, a large value diminishes trajectory diversity with strong guidance, preventing it from escaping obstacles and dead-ends.

Table A4: Ablation on different inpainting horizons and scale coefficients of the planning guidance.

|  |  |  |  |
| --- | --- | --- | --- |
| Fixed Frames | Planner Scale | Succ. Rate(%)$\uparrow$ | Planning Steps$\downarrow$ |
| 1 | 0.2 | 31.25 | 135.14 |
| 7 | 0.2 | 65.50 | 104.30 |
| 15 | 0.2 | 73.75 | 90.38 |
| 23 | 0.2 | 73.25 | 87.49 |
| 31 | 0.1 | 53.50 | 106.23 |
| 0.2 | 62.37 | 97.02 |
| 0.3 | 56.81 | 101.54 |
| 0.4 | 50.94 | 105.11 |

### E.4 Fixed Frames for Planning

Since we formulate the planning algorithm as inpainting, we also ablate the number of the fixed frame in it. In path planning for 3D scene navigation, we train the SceneDiffuser with a trajectory length of 32. Therefore, we compare the settings of fixing the first 1, 7, 15, 23, and 31 frames for inpainting during the denoising process. The results in [Tab. A4](#A5.T4 "In E.3 Scale Coefficient ‣ Appendix E Additional Ablative Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") show that the model achieves the best performance while fixing the first 15 frames.

### E.5 Planning Objectives

To explore the influence of different planning objectives, we design the following four planning objectives and compare them with [Eq. A5](#A3.E5 "In Appendix C Objective Design ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes").

* •

  We compute the L1 distance between the last frame of the denoised trajectory and the target position, *i.e*.,

  |  |  |  |  |
  | --- | --- | --- | --- |
  |  | $\varphi\_{p}=-\|\mathcal{G}-\tau^{t}\_{L}\|\_{1}.$ |  | (A7) |
* •

  We summarize the L1 distance between all frames of the denoised trajectory and the target position, *i.e*.,

  |  |  |  |  |
  | --- | --- | --- | --- |
  |  | $\varphi\_{p}=-\sum\_{i=1}^{L}\|\mathcal{G}-\tau^{t}\_{i}\|\_{1}.$ |  | (A8) |
* •

  Similar to [Eq. A5](#A3.E5 "In Appendix C Objective Design ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), we only consider the last frame of the denoised trajectory, *i.e*.,

  |  |  |  |  |
  | --- | --- | --- | --- |
  |  | $\varphi\_{p}=\exp\left(\frac{1}{\|\mathcal{G}-\tau^{t}\_{L}\|\_{1}}\right).$ |  | (A9) |
* •

  We compute the L1 distance between the target position and the frame closest to the target, *i.e*.,

  |  |  |  |  |
  | --- | --- | --- | --- |
  |  | $\varphi\_{p}=-\min\limits\_{i}\|\mathcal{G}-\tau^{t}\_{i}\|\_{1}.$ |  | (A10) |

The planning results in [Tab. A5](#A5.T5 "In E.5 Planning Objectives ‣ Appendix E Additional Ablative Experiments ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") indicate that encouraging all frames of the denoised trajectory to reach the target position surpasses considering only one frame. Besides, directly using $L1$ distance tends to achieve a better performance than additionally applying the exponential function.

Table A5: Ablation on different planning objectives.

|  |  |  |
| --- | --- | --- |
| Objective | Succ. Rate(%)$\uparrow$ | Planning Steps$\downarrow$ |
| $\varphi\_{p}=-\|\mathcal{G}-\tau^{t}\_{L}\|\_{1}$ | 57.06 | 116.22 |
| $\varphi\_{p}=-\sum\_{i=1}^{L}\|\mathcal{G}-\tau^{t}\_{i}\|\_{1}$ | 75.69 | 88.02 |
| $\varphi\_{p}=\exp\left(\frac{1}{\|\mathcal{G}-\tau^{t}\_{L}\|\_{1}}\right)$ | 34.31 | 131.74 |
| $\varphi\_{p}=\sum\_{i=1}^{L}\exp\left(\frac{1}{\|\mathcal{G}-\tau^{t}\_{i}\|\_{1}}\right)$ | 73.75 | 90.38 |
| $\varphi\_{p}=-\min\limits\_{i}\|\mathcal{G}-\tau^{t}\_{i}\|\_{1}$ | 56.00 | 109.02 |

## Appendix F Trainable Optimization and Planning

As shown in [Alg. 1](#alg1 "In 4.1 Learning ‣ 4 SceneDiffuser ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"), we can optionally train the optimization and planning process with observed trajectories. To verify its efficacy, we optimize the trainable scaling factor $\lambda$ of the optimization guidance in pose generation and path planning tasks. Specifically, we use a small MLP model to map the timestep embedding of each step into a scalar, *i.e*., the scaling factor. During training, we only optimize the MLP while fixing the pre-trained diffusion model. We plot the learned scaling factor varying with the denoising step from 100 to 1, as shown in [Fig. A2](#A6.F2 "In Appendix F Trainable Optimization and Planning ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"). We observe that the scaling factor of the denoising process at the beginning is much smaller than at the end. We speculate that the target signal at the beginning of the denoising process is mostly noise so a large scaling factor cannot optimize it properly. The scaling factor decrease in the last several steps may be because this can alleviate excessive guidance and balance the guidance from other modules, such as the planner.

(a) pose generation

(b) path planning

Figure A2: Trainable scaling factor varying with the denoising step.

## Appendix G More Qualitative Results

#### Pose Generation in 3D Scenes

We show more qualitative results in [Fig. A3](#A7.F3 "In Pose Generation in 3D Scenes ‣ Appendix G More Qualitative Results ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes").

Figure A3: More qualitative results of pose generation in 3D scenes.

#### Motion Generation in 3D Scenes

We provide more sampled human motions from the same start pose in other scenes, as shown in [Fig. A4](#A7.F4 "In Motion Generation in 3D Scenes ‣ Appendix G More Qualitative Results ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"). Please refer to the supplemental demo video for better visualization with rendered animations.

Figure A4: More qualitative results of motion generation in 3D scenes.

#### Path Planning for 3D Scene Navigation

[Fig. A5](#A7.F5 "In Path Planning for 3D Scene Navigation ‣ Appendix G More Qualitative Results ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes") shows some qualitative results of path planning for 3D scene navigation.

Figure A5: Qualitative results of path planning for 3D scene navigation. The red balls represent the planning result, starting with the lightest red ball and ending with the darkest red ball. The green ball indicates the target position.

#### Dexterous Grasp Generation for 3D Objects

We show more qualitative results in [Fig. A6](#A7.F6 "In Dexterous Grasp Generation for 3D Objects ‣ Appendix G More Qualitative Results ‣ Diffusion-based Generation, Optimization, and Planning in 3D Scenes"). Note that the objects are unseen during training time.

Figure A6: More qualitative results of dexterous grasp pose generation for 3D object.

#### Motion Planning for Robot Arm

We render the planning results into animations for visualization. Please refer to the supplemental demo video for the qualitative results.
