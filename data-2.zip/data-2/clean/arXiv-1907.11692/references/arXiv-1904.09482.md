<!-- fulltext source=arxiv_html slug=arXiv-1904.09482 fetched=2026-09-22T16:33:23+00:00 -->

# Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding

Xiaodong Liu
Affiliation:  Microsoft Research
Email: [xiaodl@microsoft.com](mailto:xiaodl@microsoft.com)
  
Pengcheng He
Affiliation:  Microsoft Dynamics 365 AI
Email: [penhe@microsoft.com](mailto:penhe@microsoft.com)
  
Weizhu Chen
Affiliation:  Microsoft Dynamics 365 AI
Email: [wzchen@microsoft.com](mailto:wzchen@microsoft.com)
  
Jianfeng Gao
Affiliation:  Microsoft Research
Email: [jfgao@microsoft.com](mailto:jfgao@microsoft.com)

###### Abstract

This paper explores the use of knowledge distillation to improve a Multi-Task Deep Neural Network (MT-DNN) [Liu et al. (2019)](#bib.bib14) for learning text representations across multiple natural language understanding tasks. Although ensemble learning can improve model performance, serving an ensemble of large DNNs such as MT-DNN can be prohibitively expensive. Here we apply the knowledge distillation method [Hinton et al. (2015)](#bib.bib10) in the multi-task learning setting.
For each task, we train an ensemble of different MT-DNNs (teacher) that outperforms any single model,
and then train a single MT-DNN (student) via multi-task learning to *distill* knowledge from these ensemble teachers. We show that the distilled MT-DNN significantly outperforms the original MT-DNN on 7 out of 9 GLUE tasks, pushing the GLUE benchmark (single model) to 83.7% (1.5% absolute improvement11
1
Based on the GLUE leaderboard at https://gluebenchmark.com/leaderboard as of April 1, 2019.).
The code and pre-trained models will be made publicly available at https://github.com/namisan/mt-dnn.

## 1 Introduction

Ensemble learning is an effective approach to improve model generalization, and has been used to achieve new state-of-the-art results in a wide range of natural language understanding (NLU) tasks, including question answering and machine reading comprehension [Devlin et al. (2018)](#bib.bib7); [Liu et al. (2018)](#bib.bib15); [Huang et al. (2017)](#bib.bib11); [Hancock et al. (2019)](#bib.bib9). A recent survey is included in [Gao et al. (2019)](#bib.bib8).
However, these ensemble models typically consist of tens or hundreds of different deep neural network (DNN) models and are prohibitively expensive to deploy due to the computational cost of runtime inference.
Recently, large-scale pre-trained models, such as BERT [Devlin et al. (2018)](#bib.bib7) and GPT [Radford et al. (2018)](#bib.bib17), have been used effectively as the base models for building task-specific NLU models via fine-tuning.
The pre-trained models by themselves are already expensive to serve at runtime (e.g. BERT contains 24 transformer layers with 344 million parameters, and GPT-2 contains 48 transformer layers with 1.5 billion parameters), the ensemble versions of these models multiplying the extreme for online deployment.

Knowledge distillation is a process of distilling or transferring the knowledge from a (set of) large, cumbersome model(s) to a lighter, easier-to-deploy single model, without significant loss in performance [Buciluǎ et al. (2006)](#bib.bib3); [Hinton et al. (2015)](#bib.bib10); [Balan et al. (2015)](#bib.bib2); [Ba et al. (2016)](#bib.bib1); [Chen et al. (2015)](#bib.bib5); [Tan et al. (2019)](#bib.bib18).

In this paper, we explore the use of knowledge distillation to improve a Multi-Task Deep Neural Network (MT-DNN) [Liu et al. (2019)](#bib.bib14) for learning text representations across multiple NLU tasks.
Since MT-DNN incorporates a pre-trained BERT model, its ensemble is expensive to serve at runtime.

We extend the knowledge distillation method [Hinton et al. (2015)](#bib.bib10) to the multi-task learning setting [Caruana (1997)](#bib.bib4); [Xu et al. (2018)](#bib.bib21); [Collobert et al. (2011)](#bib.bib6); [Zhang and Yang (2017)](#bib.bib22); [Liu et al. (2015)](#bib.bib13).
In the training process, we first pick a few tasks, each with an available task-specific training dataset which is stored in the form of $(x,y)$ pairs, where $x$ is an input and $y$ is its correct target.
For each task, we train an ensemble of MT-DNN models (teacher) that outperform the best single model. Although the ensemble model is not feasible for online deployment, it can be utilized, in an offline manner, to produce a set of *soft targets* for each $x$ in the training dataset , which, for example, in a classification task are the class probabilities averaged over the ensemble of different models.
Then, we train a single MT-DNN (student) via multi-task learning with the help of the teachers by using both the soft targets and correct targets across different tasks. We show in our experiments that knowledge distillation effectively transfers the generalization ability of the teachers to the student. As a result, the distilled MT-DNN outperforms the vanilla MT-DNN that is trained in a normal way, as described in [Liu et al. (2019)](#bib.bib14), on the same training data as was used to train the teachers.

We validate the effectiveness of our approach on the General Language Understanding Evaluation (GLUE) dataset [Wang et al. (2019)](#bib.bib20) which consists of 9 NLU tasks. We find that the distilled MT-DNN outperforms the vanilla MT-DNN on 7 tasks, including the tasks where we do not have teachers. This distilled model improves the GLUE benchmark (single model) to 83.7%, amounting to 3.2% absolute improvement over BERT and 1.5% absolute improvement over the previous state of the art model based on the GLUE leaderboard22
2
https://gluebenchmark.com as of April 1, 2019.

In the rest of the paper, Section 2 describes the MT-DNN of [Liu et al. (2019)](#bib.bib14) which is the baseline and vanilla model for this study. Section 3 describes in detail knowledge distillation for multi-task learning. Section 4 presents our experiments on GLUE. Section 5 concludes the paper.

## 2 MT-DNN

Figure 1: Architecture of the MT-DNN model for representation learning [Liu et al. (2019)](#bib.bib14). The lower layers are shared across all tasks while the top layers are task-specific. The input $X$ (either a sentence or a set of sentences) is first represented as a sequence of embedding vectors, one for each word, in $l\_{1}$. Then the Transformer encoder captures the contextual information for each word and generates the shared contextual embedding vectors in $l\_{2}$. Finally, for each task, additional task-specific layers generate task-specific representations, followed by operations necessary for classification, similarity scoring, or relevance ranking.

The architecture of the MT-DNN model is shown in Figure [1](#S2.F1 "Figure 1 ‣ 2 MT-DNN ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"). The lower layers are shared across all tasks, while the top layers represent task-specific outputs. The input $X$, which is a word sequence (either a sentence or a set of sentences packed together) is first represented as a sequence of embedding vectors, one for each word, in $l\_{1}$. Then the transformer encoder captures the contextual information for each word via self-attention, and generates a sequence of contextual embeddings in $l\_{2}$. This is the shared semantic representation that is trained by our multi-task objectives.

#### Lexicon Encoder ($l\_{1}$):

The input $X=\{x\_{1},...,x\_{m}\}$ is a sequence of tokens of length $m$. Following [Devlin et al. (2018)](#bib.bib7), the first token $x\_{1}$ is always the [CLS] token.
If $X$ is packed by a set of sentences $(X\_{1},X\_{2})$, we separate the these sentences with special tokens [SEP]. The lexicon encoder maps $X$ into a sequence of input embedding vectors, one for each token, constructed by summing the corresponding word, segment, and positional embeddings.

#### Transformer Encoder ($l\_{2}$):

We use a multi-layer bidirectional Transformer encoder ([Vaswani et al., 2017](#bib.bib19)) to map the input representation vectors ($l\_{1}$) into a sequence of contextual embedding vectors
$\mathbf{C}\in\mathbb{R}^{d\times m}$.
This is the shared representation across different tasks.

#### Task-Specific Output Layers:

We can incorporate arbitrary natural language tasks, each with its task-specific output layers. For example, we implement the output layers as a neural decoder for text generation, a neural ranker for relevance ranking, a logistic regression for text classification, and so on. Below, we elaborate the implementation detail using text classification as an example.

Suppose that $\mathbf{x}$ is the contextual embedding ($l\_{2}$) of the token [CLS], which can be viewed as the semantic representation of input sentence $X$. The probability that $X$ is labeled as class $c$ (i.e., the sentiment is postive or negative) is predicted by a logistic regression with softmax:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P\_{r}(c|X)=\text{softmax}(\mathbf{W}\_{t}\cdot\mathbf{x}),$ |  | (1) |

where $\mathbf{W}\_{t}$ is the task-specific parameter matrix for task $t$.

### 2.1 The Training Procedure

The training procedure of MT-DNN consists of two stages: pre-training and multi-task learning (MTL). In the pre-training stage, [Liu et al. (2019)](#bib.bib14) used a publicly available pre-trained BERT model to initialize the parameters of the shared layers (i.e., the lexicon encoder and the transformer encoder).

In the MTL stage, mini-batch based stochastic gradient descent (SGD) is used to learn the model parameters (i.e., the parameters of all the shared layers and the task-specific layers), as shown in Algorithm [1](#algorithm1 "In 2.1 The Training Procedure ‣ 2 MT-DNN ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"). First, the training samples from multiple tasks (e.g., 9 GLUE tasks) are packed into mini-batches. We denote a mini-batch by $b\_{t}$, indicating that it contains only the samples from task $t$. In each epoch, a mini-batch $b\_{t}$ is selected, and the model is updated according to the task-specific objective for task $t$, denoted by $L\_{t}(\Theta)$. This approximately optimizes the sum of all multi-task objectives.

Take text classification as an example. We use the cross-entropy loss as the objective in Line 3 of Algorithm [1](#algorithm1 "In 2.1 The Training Procedure ‣ 2 MT-DNN ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $-\sum\_{c}\mathbbm{1}(X,c)\log(P\_{r}(c|X)),$ |  | (2) |

where $\mathbbm{1}(X,c)$ is the binary indicator (0 or 1) if class label $c$ is the correct classification for $X$, and $P\_{r}(.)$ is defined by Equation [1](#S2.E1 "In Task-Specific Output Layers: ‣ 2 MT-DNN ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding").

Then, in Line 5, the parameters of the shared layers and the output layers corresponding to task $t$ are updated using the gradient computed in Line 4.

After MT-DNN is trained via MTL, it can be fine-tuned (or adapted) using task-specific labeled training data to perform prediction on any individual task, which can be a task used in the MTL stage or a new task that is related to the ones used in MTL.
[Liu et al. (2019)](#bib.bib14) showed that the shared layers of MT-DNN produce more universal text representations than that of BERT. As a result, MT-DNN allows fine-tuning or adaptation with substantially fewer task-specific labels.

Algorithm 1  Training a MT-DNN model.

```
Initialize model parameters Θ\Theta randomly. 
Initialize the shared layers (i.e., the lexicon encoder and the transformer encoder) using a pre-trained BERT model. 
Set the max number of epoch: e​p​o​c​hm​a​xepoch_{max}.
//Prepare the data for TT tasks.
for tt in 1,2,…,T1,2,...,T  do
   Pack the dataset tt into mini-batch: DtD_{t}.
end for
for e​p​o​c​hepoch in 1,2,…,e​p​o​c​hm​a​x1,2,...,epoch_{max} do
   1. Merge all the datasets: D=D1∪D2​…∪DTD=D_{1}\cup D_{2}...\cup D_{T}
   2. Shuffle DD
   for btb_{t} in D do
      //btb_{t} is a mini-batch of task tt.
      3. Compute task-specific loss : Lt​(Θ)L_{t}(\Theta)
      4. Compute gradient: ∇(Θ)\nabla(\Theta)
      5. Update model: Θ=Θ−ϵ∇(Θ)\Theta=\Theta-\epsilon\nabla(\Theta)
   end for
end for
```

## 3 Knowledge Distillation

Figure 2: Process of knowledge distillation for multi-task learning. A set of tasks where there is task-specific labeled training data are picked. Then, for each task, an ensemble of different neural nets (teacher) is trained. The teacher is used to generate for each task-specific training sample a set of soft targets. Given the soft targets of the training datasets across multiple tasks, a single MT-DNN (student) is trained using multi-task learning and back propagation as described in Algorithm [1](#algorithm1 "In 2.1 The Training Procedure ‣ 2 MT-DNN ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"), except that if task $t$ has a teacher, the task-specific loss in Line 3 is the average of two objective functions, one for the correct targets and the other for the soft targets assigned by the teacher.

The process of knowledge distillation for MTL is illustrated in Figure [2](#S3.F2 "Figure 2 ‣ 3 Knowledge Distillation ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding").
First, we pick a few tasks where there are task-specific labeled training data.
Then, for each task, we train an ensemble of different neural nets as a teacher. Each neural net is an instance of MT-DNN described in Section [2](#S2 "2 MT-DNN ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"), and is fine-tuned using task-specific training data while the parameters of its shared layers are initialized using the MT-DNN model pre-trained on the GLUE dataset via MTL, as in Algorithm [1](#algorithm1 "In 2.1 The Training Procedure ‣ 2 MT-DNN ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"), and the parameters of its task-specific output layers are randomly initialized.

For each task, a teacher generates a set of soft targets for each task-specific training sample.
Take text classification as an example.
A neural network model typically produces class probabilities using a softmax layer as in Equation [1](#S2.E1 "In Task-Specific Output Layers: ‣ 2 MT-DNN ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"). Let $Q^{k}$ be the class probabilities produced by the $k$-th single network of the ensemble. The teacher produces the soft targets by averaging the class probabilities across networks:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $Q=\text{avg}([Q^{1},Q^{2},...,Q^{K}]).$ |  | (3) |

We want to approximate the teacher using a student neural network model, which also has a softmax output for the same task $P\_{r}(c|X)$, as in Equation [1](#S2.E1 "In Task-Specific Output Layers: ‣ 2 MT-DNN ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"). Hence, we use the standard cross entropy loss:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $-\sum\_{c}Q(c|X)\log(P\_{r}(c|X)).$ |  | (4) |

Note that the above loss function differs from the cross entropy loss in Equation [2](#S2.E2 "In 2.1 The Training Procedure ‣ 2 MT-DNN ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding") in that the former uses the soft targets $Q(c|X)$ while the latter uses the hard correct target via the indicator $\mathbbm{1}(X,c)$.

As pointed out by [Hinton et al. (2015)](#bib.bib10), the use of soft targets produced by the teacher is the key to successfully transferring the generalization ability of the teacher to the student. The relative probabilities of the teacher labels contain information
about how the teacher generalizes. For example, the sentiment of the sentence “I really enjoyed the conversation with Tom” has a small chance of being classified as negative.
But the sentence “Tom and I had an interesting conversation” can be either positive or negative, depending on its context if available, leading to a high entropy of the soft targets assigned by the teacher.
In these cases, the soft targets provide more information per training sample than the hard targets and less variance in the gradient between training samples.
By optimizing the student for the soft targets produced by the teacher, we expect the student to learn to generalize in the same way as the teacher. In our case, each task-specific teacher is the average of a set of different neural networks, and thus generalizes well. The single MT-DNN (student) trained to generalize in the same way as the teachers is expected to do much better on test data than the vanilla MT-DNN that is trained in the normal way on the same training dataset. We will demonstrate in our experiments that this is indeed the case.

We also find that when the correct targets are known, the model performance can be significantly improved by training the distilled model on a combination of soft and hard targets.
We do so by defining a loss function for each task that take a weighted average between the cross entropy loss with the correct targets as Equation [2](#S2.E2 "In 2.1 The Training Procedure ‣ 2 MT-DNN ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding") and the cross entropy with the soft targets as Equation [4](#S3.E4 "In 3 Knowledge Distillation ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding").
[Hinton et al. (2015)](#bib.bib10) suggested using a considerably lower weight on the first loss term.
But in our experiments we do not observe any significant difference by using different weights for the two loss terms, respectively.

Finally, given the soft targets of the training datasets across multiple tasks, the student MT-DNN can be trained using MTL as described in Algorithm [1](#algorithm1 "In 2.1 The Training Procedure ‣ 2 MT-DNN ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"), except that if task $t$ has a teacher, the task-specific loss in Line 3 is the average of two objective functions, one for the correct targets and the other for the soft targets assigned by the teacher.

## 4 Experiments

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| Corpus | Task | #Train | #Dev | #Test | #Label | Metrics |
| Single-Sentence Classification (GLUE) | | | | | |  |
| CoLA | Acceptability | 8.5k | 1k | 1k | 2 | Matthews corr |
| SST-2 | Sentiment | 67k | 872 | 1.8k | 2 | Accuracy |
| Pairwise Text Classification (GLUE) | | | | | |  |
| MNLI | NLI | 393k | 20k | 20k | 3 | Accuracy |
| RTE | NLI | 2.5k | 276 | 3k | 2 | Accuracy |
| WNLI | NLI | 634 | 71 | 146 | 2 | Accuracy |
| QQP | Paraphrase | 364k | 40k | 391k | 2 | Accuracy/F1 |
| MRPC | Paraphrase | 3.7k | 408 | 1.7k | 2 | Accuracy/F1 |
| Text Similarity (GLUE) | | | | |  |  |
| STS-B | Similarity | 7k | 1.5k | 1.4k | 1 | Pearson/Spearman corr |
| Relevance Ranking (GLUE) | | | | | |  |
| QNLI | QA/NLI | 108k | 5.7k | 5.7k | 2 | Accuracy |

Table 1: Summary of the GLUE benchmark.

We evaluate the MT-DNN trained using Knowledge Distillation, termed as MT-DNNKD in this section, on the General Language Understanding Evaluation (GLUE) benchmark. GLUE is a collection of nine NLU tasks as in Table [1](#S4.T1 "Table 1 ‣ 4 Experiments ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"), including question answering, sentiment analysis, text similarity and textual entailment.
We refer readers to [Wang et al. (2019)](#bib.bib20) for a detailed description of GLUE.
We compare MT-DNNKD with existing state-of-the-art models including BERT [Devlin et al. (2018)](#bib.bib7), STILT [Phang et al. (2018)](#bib.bib16), Snorkel MeTal [Hancock et al. (2019)](#bib.bib9), and MT-DNN [Liu et al. (2019)](#bib.bib14). Furthermore, we investigate the relative contribution of using knowledge distillation for MTL with an ablation study.

### 4.1 Implementation details

Our implementation is based on the PyTorch implementations of MT-DNN33
3
https://github.com/namisan/mt-dnn and BERT44
4
https://github.com/huggingface/pytorch-pretrained-BERT.
We used Adamax [Kingma and Ba (2014)](#bib.bib12) as our optimizer with a learning rate of 5e-5 and a batch size of 32. The maximum number of epochs was set to 5.
A linear learning rate decay schedule with warm-up over 0.1 was used, unless stated otherwise.
We also set the dropout rate of all the task-specific layers as 0.1, except 0.3 for MNLI and 0.05 for CoLA/SST-2.
To avoid the gradient explosion issue, we clipped the gradient norm within 1.
All the texts were tokenized using wordpieces, and were chopped to spans no longer than 512 tokens.

To obtain a set of diverse single models to form ensemble models (teachers), we first trained 6 single MT-DNNs, initialized using Cased/Uncased BERT models as [Hancock et al. (2019)](#bib.bib9) with a different dropout rate, ranged in {0.1, 0.2, 0.3}, on the shared layers, while keeping other training hyperparameters the same as aforementioned.
Then, we selected top 3 best models according to the results on the MNLI and RTE development datasets.
Finally, we fine-tuned the 3 models on each of the MNLI, QQP, RTE and QNLI tasks to form four task-specific ensembles (teachers), each consisting of 3 single MT-DNNs fine-tuned for the task.
The teachers are used to generate soft targets for the four tasks as Equation [3](#S3.E3 "In 3 Knowledge Distillation ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"), described in Section [3](#S3 "3 Knowledge Distillation ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding").
We only pick four out of nine GLUE tasks to train teachers to investigate the generalization ability of MT-DNNKD, i.e., its performance on the tasks with and without teachers.

|  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Model | CoLA | SST-2 | MRPC | STS-B | QQP | MNLI-m/mm | QNLI | RTE | WNLI | AX | Score |
|  | 8.5k | 67k | 3.7k | 7k | 364k | 393k | 108k | 2.5k | 634 |  |  |
| BiLSTM+ELMo+Attn 1 | 36.0 | 90.4 | 84.9/77.9 | 75.1/73.3 | 64.8/84.7 | 76.4/76.1 | 79.8 | 56.8 | 65.1 | 26.5 | 70.0 |
| |  | | --- | | Singletask Pretrain | | Transformer 2 | | 45.4 | 91.3 | 82.3/75.7 | 82.0/80.0 | 70.3/88.5 | 82.1/81.4 | 87.4 | 56.0 | 53.4 | 29.8 | 72.8 |
| GPT on STILTs 3 | 47.2 | 93.1 | 87.7/83.7 | 85.3/84.8 | 70.1/88.1 | 80.8/80.6 | - | 69.1 | 65.1 | 29.4 | 76.9 |
| BERT${}\_{\text{LARGE}}$4 | 60.5 | 94.9 | 89.3/85.4 | 87.6/86.5 | 72.1/89.3 | 86.7/85.9 | 92.7 | 70.1 | 65.1 | 39.6 | 80.5 |
| MT-DNN5 | 61.5 | 95.6 | 90.0/86.7 | 88.3/87.7 | 72.4/89.6 | 86.7/86.0 | - | 75.5 | 65.1 | 40.3 | 82.2 |
| Snorkel MeTaL 6 | 63.8 | 96.2 | 91.5/88.5 | 90.1/89.7 | 73.1/89.9 | 87.6/87.2 | 93.9 | 80.9 | 65.1 | 39.9 | 83.2 |
| ALICE ∗ | 63.5 | 95.2 | 91.8/89.0 | 89.8/88.8 | 74.0/90.4 | 87.9/87.4 | 95.7 | 80.9 | 65.1 | 40.7 | 83.3 |
| MT-DNNKD | 65.4 | 95.6 | 91.1/88.2 | 89.6/89.0 | 72.7/89.6 | 87.5/86.7 | 96.0 | 85.1 | 65.1 | 42.8 | 83.7 |
| Human Performance | 66.4 | 97.8 | 86.3/80.8 | 92.7/92.6 | 59.5/80.4 | 92.0/92.8 | 91.2 | 93.6 | 95.9 | - | 87.1 |

Table 2: GLUE test set results scored using the GLUE evaluation server. The number below each task denotes the number of training examples. The state-of-the-art results are in bold. MT-DNNKD uses BERTLARGE to initialize its shared layers.
All the results are obtained from <https://gluebenchmark.com/leaderboard> on April 1, 2019. Note that Snorkel MeTaL is an ensemble model.
- denotes the missed result of the latest GLUE version.
∗ denotes the unpublished work, thus not knowing whether it is a single model or an ensemble model.
For QNLI, we treat it as two tasks, pair-wise ranking and classification task on v1 and v2 training datasets, respectively, and then merge results on the test set.
Model references: 1:[Wang et al. (2019)](#bib.bib20) ; 2:[Radford et al. (2018)](#bib.bib17); 3: [Phang et al. (2018)](#bib.bib16); 4:[Devlin et al. (2018)](#bib.bib7); 5: [Liu et al. (2019)](#bib.bib14); 6: [Hancock et al. (2019)](#bib.bib9).

|  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Model | MNLI-m/mm | QQP | RTE | QNLI(v2) | MRPC | CoLa | SST-2 | STS-B |
| BERT${}\_{\text{LARGE}}$ | 86.3/86.2 | 91.1/88.0 | 71.1 | 92.4 | 89.5/85.8 | 61.8 | 93.5 | 89.6/89.3 |
| MT-DNN | 87.1/86.7 | 91.9/89.2 | 83.4 | 92.9 | 91.0/87.5 | 63.5 | 94.3 | 90.7/90.6 |
| MT-DNNKD | 87.3/87.3 | 91.9/89.4 | 88.6 | 93.2 | 93.3/90.7 | 64.5 | 94.3 | 91.0/90.8 |
| MT-DNN-ensemble | 88.1/87.9 | 92.5/90.1 | 86.7 | 93.5 | 93.4/91.0 | 64.5 | 94.7 | 92.1/91.6 |

Table 3: GLUE dev set results. The best result on each task produced by a single model is in bold.
MT-DNN uses BERTLARGE as their initial shared layers.
MT-DNNKD is the MT-DNN trained using the proposed knowledge distillation based MTL.
MT-DNN-ensemble denotes the results of the ensemble models described in Section [4.1](#S4.SS1 "4.1 Implementation details ‣ 4 Experiments ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"). The ensemble models on MNLI, QQP, RTE and QNLI are used as teachers in the knowledge distillation based MTL, while the other ensemble modes, whose results are in blue and italic,
are not used as teachers.

### 4.2 GLUE Main Results

We compare MT-DNNKD with a list of state-of-the-art models that have been submitted to the GLUE leaderboard.

#### BERTLARGE

This is the large BERT model released by [Devlin et al. (2018)](#bib.bib7), which we used as a baseline. We used single-task fine-tuning to produce the best result for each GLUE task according to the development set.

#### MT-DNN

This is the model described in Section [2](#S2 "2 MT-DNN ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding") and [Liu et al. (2019)](#bib.bib14). We used the pre-trained BERTLARGE model to initialize its shared layers, refined the shared layers via MTL on all GLUE tasks,
and then perform a fine-tune for each GLUE task using the task-specific data.

#### MT-DNNKD

This is the MT-DNN model trained using knowledge distillation as described in Section [3](#S3 "3 Knowledge Distillation ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding").
MT-DNNKD uses the same model architecture as that of MT-DNN. But the former is trained with the help from four task-specific ensembles (teachers). MT-DNNKD is optimized for the multi-task objectives that are based on the hard correct targets, as well as the soft targets produced by the teachers if available.
After knowledge distillation based MTL, MT-DNNKD is further fine-tuned for each task using task-specific data to produce the final predictions for each GLUE task on blind test data for evaluation.

The main results on the official test datasets of GLUE are reported in Table [2](#S4.T2 "Table 2 ‣ 4.1 Implementation details ‣ 4 Experiments ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding").
Compared to other recent submissions on the GLUE leaderboard, MT-DNNKD is the best performer,
creating a new state-of-the-art result of 83.7%.
The margin between MT-DNNKD and the second-best model ALICE is 0.5%, larger than the margin of 0.1% between the second and the third (and the fourth) places.
It is worth noting that MT-DNNKD is a single model while Snorkel MetaL [Hancock et al. (2019)](#bib.bib9) is an ensemble model. The description of ALICE is not disclosed yet.

Table [2](#S4.T2 "Table 2 ‣ 4.1 Implementation details ‣ 4 Experiments ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding") also shows that MT-DNNKD significantly outperforms MT-DNN not only in overall score but on 7 out of 9 GLUE tasks, including the tasks without a teacher.
Since MT-DNNKD and MT-DNN use the same network architecture, and are trained with the same initialization and on the same datasets, the improvement of MT-DNNKD is solely attributed to the use of knowledge distillation in MTL.

We note that the most significant per-task improvements are from CoLA (65.4% vs. 61.5%) and RTE (85.1% vs. 75.5%). Both tasks have relatively small amounts of in-domain data. Similarly, for the same type of tasks, the improvements of MT-DNNKD over MT-DNN are much more substantial for the tasks with less in-domain training data e.g., for the two NLI tasks, the improvement in RTE is much larger than that in MNLI; for the two paraphrase tasks, the improvement in MRPC is larger than that in QQP.
These results suggest that knowledge distillation based MTL is effective at improving model performance for not only tasks with teachers but also ones without teachers, and more so for tasks with fewer in-domain labels.

### 4.3 Ablation Study

We perform an ablation study to investigate how effective it can distill knowledge from the ensemble models (teachers) to a single MT-DNN (student). To this end, we compare the performance of the ensemble models with the corresponding student model.

The results on dev sets are shown in Table [3](#S4.T3 "Table 3 ‣ 4.1 Implementation details ‣ 4 Experiments ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"), where MT-DNN-ensemble are the task-specific ensemble models trained using the process described in Section [3](#S3 "3 Knowledge Distillation ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"). We only use four ensemble models (i.e., the models for MNLI, QQP, RTE, QNLI) as teachers. The results of the other ensemble models (i.e., MRPC, CoLa, SST-2, STS-B) are reported to show the effectiveness of the knowledge distillation based MTL at improving the performance on tasks without a teacher.

We can draw several conclusions from the results in Table [3](#S4.T3 "Table 3 ‣ 4.1 Implementation details ‣ 4 Experiments ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding"). First, MT-DNNKD significantly outperforms MT-DNN and BERTLARGE across multiple GLUE tasks on the dev sets, which is consistent with what we observe on test sets in Table [2](#S4.T2 "Table 2 ‣ 4.1 Implementation details ‣ 4 Experiments ‣ Improving Multi-Task Deep Neural Networks via Knowledge Distillation for Natural Language Understanding").
Second, comparing MT-DNNKD with MT-DNN-ensemble, we see that the MT-DNNKD successfully distills knowledge from the teachers. Although the distilled model is simpler than the teachers, it retains nearly all of the improvement that is achieved by the ensemble models. More interestingly, we find that incorporating knowledge distillation into MTL improves the model performance on the tasks where no teacher is used. On MRPC, CoLA, and STS-B, the performance of MT-DNNKD is much better than MT-DNN and is close to the ensemble models although the latter are not used as teachers in MTL.

## 5 Conclusion

In this work, we have extended knowledge distillation to MTL in training a MT-DNN for natural language understanding.
We have shown that distillation works very well for transferring knowledge from a set of ensemble models (teachers) into a single, distilled MT-DNN (student). On the GLUE datasets, the distilled MT-DNN creates new state of the art result on 7 out of 9 NLU tasks, including the tasks where there is no teacher, pushing the GLUE benchmark (single model) to 83.7%.

We show that the distilled MT-DNN retains nearly all of the improvements achieved by ensemble models, while keeping the model size the same as the vanilla MT-DNN model.

There are several research areas for future exploration.
First, we will seek better ways of combining the soft targets and hard correct targets for multi-task learning. Second, the teachers might be used to produce the soft targets for large amounts of unlabeled data, which in turn can be used to train a better student model in a way conceptually similar to semi-supervised learning.
Third, instead of compressing a complicated model to a simpler one, knowledge distillation can also be used to improve the model performance regardless of model complexity, in machine learning scenarios such as self-learning in which both the student and teacher are the same model.

## Acknowledgments

We thank
Asli Celikyilmaz,
Xuedong Huang,
Moontae Lee,
Chunyuan Li,
Xiujun Li,
and Michael Patterson
for helpful discussions and comments.
