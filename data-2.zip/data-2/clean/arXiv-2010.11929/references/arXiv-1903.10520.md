<!-- fulltext source=arxiv_html slug=arXiv-1903.10520 fetched=2026-09-18T01:33:08+00:00 -->

# Micro-Batch Training with Batch-Channel Normalization and Weight Standardization

Siyuan Qiao
  
Huiyu Wang
  
Chenxi Liu
  
Wei Shen
  
and Alan Yuille
  
Fellow, IEEE
††thanks: All authors are with the Department
of Computer Science, Johns Hopkins University, Baltimore,
MD, 21218.
E-mail: {siyuan.qiao, hwang157, cxliu}@jhu.edu
{shenwei1231, alan.l.yuille}@gmail.com
Corresponding author: W. Shen
††thanks: Manuscript received April 19, 2005; revised August 26, 2015.

###### Abstract

Batch Normalization (BN) has become an out-of-box technique to improve deep network training.
However, its effectiveness is limited for
micro-batch training, *i.e.*, each GPU typically has only 1-2 images for training, which is inevitable for many computer vision tasks, e.g., object detection and semantic segmentation, constrained by memory consumption. To address this issue, we propose Weight Standardization (WS) and Batch-Channel Normalization (BCN) to bring two success factors of BN into micro-batch training: 1) the smoothing effects on the loss landscape and 2) the ability to avoid harmful elimination singularities along the training trajectory.
WS standardizes the weights in convolutional layers to smooth the loss landscape by reducing the Lipschitz constants of the loss and the gradients; BCN combines batch and channel normalizations and leverages estimated statistics of the activations in convolutional layers to keep networks away from elimination singularities.
We validate WS and BCN on comprehensive computer vision tasks, including image classification, object detection, instance segmentation, video recognition and semantic segmentation.
All experimental results consistently show that WS and BCN improve micro-batch training significantly. Moreover, using WS and BCN with micro-batch training is even able to match or outperform the performances of BN with large-batch training.

###### Index Terms:

Micro-Batch Training, Group Normalization, Weight Standardization, Batch-Channel Normalization.

## I Introduction

Deep learning has advanced the state-of-the-arts in many vision tasks [[1](#bib.bib1), [2](#bib.bib2)].
Many deep networks use Batch Normalization (BN) [[3](#bib.bib3)] in their architectures because BN in most cases is able to accelerate training and help the models to converge to better solutions.
BN stabilizes the training by controlling the first two moments of the distributions of the layer outputs in each mini-batch during training and is especially helpful for training very deep networks that have hundreds of layers [[4](#bib.bib4), [5](#bib.bib5)].
Despite its practical success, BN has a shortcoming that it works well only when the batch size is sufficiently large, which prohibits it from being used in micro-batch training. Micro-batch training, *i.e.*, the batch size is small, *e.g.*, 1 or 2, is inevitable for many computer vision tasks, such as object detection and semantic segmentation, due to limited GPU memory. This shortcoming draws a lot of attentions from researchers, which urges them to design specific normalization methods for micro-batch training, such as Group Normalization (GN) [[6](#bib.bib6)] and Layer Normalization (LN) [[7](#bib.bib7)], but they have difficulty matching the performances of BN in large-batch training (Fig. [1](#S1.F1 "Fig. 1 ‣ I Introduction ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization")).

Fig. 1: Comparing BN [[3](#bib.bib3)], GN [[6](#bib.bib6)], our WS used with GN, and WS used with BCN on ImageNet and COCO.
On ImageNet, BN and BCN+WS are trained with large batch sizes while GN and GN+WS are trained with 1 image/GPU.
On COCO, BN is frozen for micro-batch training, and BCN uses its micro-batch implementation.
GN+WS outperforms both BN and GN comfortably and BCN+WS further improves the performances.

In this paper, our goal is to bring the success factors of BN into micro-batch training but without relying on large batch sizes during training. This requires good understandings of the reasons of BN’s success, among which we focus on two factors:

1. 1.

   BN’s smoothing effects:
   [[8](#bib.bib8)] proves that BN makes the landscape of the corresponding optimization problem significantly smoother, thus is able to stabilize the training process and accelerate the convergence speed of training deep neural networks.
2. 2.

   BN avoids elimination singularities:
   Elimination singularities refer to the points along the training trajectory where neurons in the networks get eliminated.
   Eliminable neurons waste computations and decrease the effective model complexity.
   Getting closer to them will harm the training speed and the final performances.
   By forcing each neuron to have zero mean and unit variance, BN keeps the networks at far distances from elimination singularities caused by non-linear activation functions.

We find that these two success factors are not properly addressed by some methods specifically designed for micro-batch training.
For example, channel-based normalizations, e.g., Layer Normalization (LN) [[7](#bib.bib7)] and Group Normalization (GN) [[6](#bib.bib6)], are unable to guarantee far distances from elimination singularities.
This might be the reason for their inferior performance compared with BN in large-batch training.
To bring the above two success factors into micro-batch training, we propose Weight Standardization (WS) and Batch-Channel Normalization (BCN) to improve network training.
WS standardizes the weights in convolutional layers, *i.e.*, making the weights have zero mean and unit variance.
BCN uses estimated means and variances of the activations in convolutional layers by combining batch and channel normalization.
WS and BCN are able to run in both large-batch and micro-batch settings and accelerate the training and improve the performances.

We study WS and BCN from both theoretical and experimental viewpoints.
The highlights of the results are:

1. 1.

   Theoretically, we prove that WS reduces the Lipschitz constants of the loss and the gradients.
   Hence, WS smooths loss landscape and improves training.
2. 2.

   We empirically show that WS and BCN are able to push the models away from the elimination singularities.
3. 3.

   Experiments show that on tasks where large-batches are available (e.g. ImageNet [[9](#bib.bib9)]), GN [[6](#bib.bib6)] + WS with batch size 1 is able to match or outperform the performances of BN with large batch sizes (Fig. [1](#S1.F1 "Fig. 1 ‣ I Introduction ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization")).
4. 4.

   For tasks where only micro-batch training is available (e.g. COCO [[10](#bib.bib10)]), GN + WS will significantly improve the performances (Fig. [1](#S1.F1 "Fig. 1 ‣ I Introduction ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization")).
5. 5.

   Replacing GN with BCN further improves the results in both large-batch and micro-batch training settings.

To show that our WS and BCN are applicable to many vision tasks, we conduct comprehensive experiments, including image classification on CIFAR-10/100 [[11](#bib.bib11)] and ImageNet dataset [[9](#bib.bib9)], object detection and instance segmentation on MS COCO dataset [[10](#bib.bib10)],
video recognition on Something-SomethingV1 dataset [[12](#bib.bib12)],
and semantic image segmentation on PASCAL VOC [[13](#bib.bib13)].
The experimental results show that our WS and BCN are able to accelerate training and improve performances.

## II Related Work

Deep neural networks advance state-of-the-arts in many computer vision tasks [[1](#bib.bib1), [5](#bib.bib5), [14](#bib.bib14), [15](#bib.bib15), [16](#bib.bib16), [17](#bib.bib17), [18](#bib.bib18), [19](#bib.bib19), [20](#bib.bib20), [21](#bib.bib21), [22](#bib.bib22), [23](#bib.bib23)].
But deep networks are hard to train.
To speed up training, proper model initialization strategies are widely used as well as data normalization based on the assumption of the data distribution [[24](#bib.bib24), [25](#bib.bib25)].
On top of data normalization and model initialization, Batch Normalization [[3](#bib.bib3)] is proposed to ensure certain distributions so that the normalization effects will not fade away during training.
By performing normalization along the batch dimension, Batch Normalization achieves state-of-the-art performances in many tasks in addition to accelerating the training process.
When the batch size decreases, however, the performances of Batch Normalization drop dramatically since the batch statistics are not representative enough of the dataset statistics.
Unlike Batch Normalization that works on the batch dimension, Layer Normalization [[7](#bib.bib7)] normalizes data on the channel dimension, Instance Normalization [[26](#bib.bib26)] does Batch Normalization for each sample individually.
Group Normalization [[6](#bib.bib6)] also normalizes features on the channel dimension, but it finds a better middle point between Layer Normalization and Instance Normalization.

Batch Normalization, Layer Normalization, Group Normalization, and Instance Normalization are all activation-based normalization methods.
Besides them, there are also weight-based normalization methods, such as Weight Normalization [[27](#bib.bib27)] and Centered Weight Normalization [[28](#bib.bib28)].
Weight Normalization decouples the length and the direction of the weights, and Centered Weight Normalization also centers the weights to have zero mean.
Weight Standardization is similar, but removes the learnable weight length.
Instead, the weights are standardized to have zero mean and unit variance, and then directly sent to the convolution operations.
When used with GN, it narrows the performance gap between BN and GN.

In this paper, we study normalization from the perspective of elimination singularity [[29](#bib.bib29), [30](#bib.bib30)] and smoothness [[8](#bib.bib8)].
There are also other perspectives to understand normalization methods.
For example, from training robustness, BN is able to make optimization trajectories more robust to parameter initialization [[31](#bib.bib31)].
[[8](#bib.bib8)] shows that normalizations are able to reduce the Lipschitz constants of the loss and the gradients, thus the training becomes easier and faster.
From the angle of model generalization, [[32](#bib.bib32)] shows that Batch Normalization relies less on single directions of activations, thus has better generalization properties, and [[33](#bib.bib33)] studies the regularization effects of Batch Normalization.
[[34](#bib.bib34)] also explores length-direction decoupling in BN and WN [[27](#bib.bib27)].
Other work also approaches normalizations from the gradient explosion issues [[35](#bib.bib35)] and learning rate tuning [[36](#bib.bib36)].
Our WS is also related to converting constrained optimization to unconstrained optimization [[37](#bib.bib37), [38](#bib.bib38)].

Our BCN uses Batch Normalization and Group Normalization at the same time for one layer.
Some previous work also uses multiple normalizations or a combined version of normalizations for one layer.
For example, SN [[39](#bib.bib39)] computes BN, IN, and LN at the same time and uses AutoML [[40](#bib.bib40)] to determine how to combine them.
SSN [[41](#bib.bib41)] uses SparseMax to get sparse SN.
DN [[42](#bib.bib42)] proposes a more flexible form to represent normalizations and finds better normalizations.
Unlike them, our method is based on analysis and theoretical understandings instead of searching solutions through AutoML, and our normalizations are used together as a composite function rather than linearly adding up the normalization effects in a flat way.

## III Lipschitz Smoothness and Elimination Singularities

We first describe Lipschitz Smoothness and Elimination Singularities to provide the background of our analyses.

### III-A Lipschitz Smoothness

A function $f:A\rightarrow\mathbb{R}^{m}$, $A\in\mathbb{R}^{n}$ is $L$-Lipschitz [[43](#bib.bib43)] if

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\forall a,b\in A:~~||f(a)-f(b)||\leq L||a-b||.$ |  | (1) |

A continuously differentiable function $f$ is $\beta$-smooth if the gradient $\nabla f$ is
$\beta$-Lipschitz, i.e.,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\forall a,b\in A:~~||\nabla f(a)-\nabla f(b)||\leq\beta||a-b||.$ |  | (2) |

Many results show that training smooth functions using gradient descent algorithms is faster than training non-smooth functions [[44](#bib.bib44)].
Intuitively, gradient descent based training algorithms can be unstable due to exploding or vanishing gradients.
As a result, they are sensitive to the selections of the learning rate and initialization if the loss landscape is not smooth.
Using an algorithm (e.g. WS) that smooths the loss landscape will make the gradients more reliable and predictive; thus, larger steps can be taken and the training will be accelerated.

### III-B Elimination singularities

Deep neural networks are hard to train partly due to the singularities caused by the non-identifiability of the model [[30](#bib.bib30)].
These singularities include overlap singularities, linear dependence singularities, elimination singularities, etc.
Degenerate manifolds in the loss landscape will be caused by these singularities, getting closer to which will slow down learning and impact model performances [[29](#bib.bib29)].
In this paper, we focus on elimination singularities, which correspond to the points on the training trajectory where neurons in the model become constantly deactivated.

The original definition of elimination singularities is based on weights [[30](#bib.bib30)]: if we use $\bm{\omega}\_{c}$ to denote the weights that take the channel $c$ as input,
then an elimination singularity is encountered when $\bm{\omega}\_{c}=\bm{0}$.
However, this definition is not suitable for real-world deep network training as most of $\bm{\omega}\_{c}$ will not be close to $0$.
For example, in a ResNet-50 [[2](#bib.bib2)] well-trained on ImageNet [[9](#bib.bib9)], $\frac{1}{L}\sum\_{l}\frac{\text{min}\_{c\in l}{|\bm{\omega}\_{c}|\_{1}}}{\text{avg}\_{c\in l}{|\bm{\omega}\_{c}|\_{1}}}=0.55$, where $L$ is the number of all the layers $l$ in the network.
Note that weight decay is already used in training this network to encourage weight sparsity.
In other words, defining elimination singularities based on weights is not proper for networks trained in real-world settings.

In this paper, we consider elimination singularities for networks that use ReLU as their activation functions.
We focus on a basic building element that is widely used in neural networks: a convolutional layer followed by a normalization method (e.g. BN, LN) and ReLU [[45](#bib.bib45)], i.e.,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bm{X^{\text{out}}}=\text{ReLU}(\text{Norm}(\text{Conv}(\bm{X^{\text{in}}}))).$ |  | (3) |

When ReLU is used, $\bm{\omega}\_{c}=\bm{0}$ is no longer necessary for a neuron to be eliminatable.
This is because ReLU sets any values below $0$ to $0$; thus a neuron is constantly deactivated if its maximum value after the normalization layer is below $0$.
Their gradients will also be $0$ because of ReLU, making them hard to revive; hence, a singularity is created.

Fig. 2: Comparing normalization methods on activations (blue) and Weight Standardization (orange).

## IV Weight Standardization

In this section, we introduce Weight Standardization, which is inspired by BN.
It has been demonstrated that BN influences network training in a fundamental way: it makes the landscape of
the optimization problem significantly smoother [[8](#bib.bib8)].
Specifically, [[8](#bib.bib8)] shows that BN reduces the Lipschitz constants of the loss function, and makes the gradients more Lipschitz, too,
i.e., the loss will have a better $\beta$-smoothness [[43](#bib.bib43)].

We notice that BN considers the Lipschitz constants with respect to *activations*, not the *weights* that the optimizer is directly optimizing.
Therefore, we argue that we can also standardize the *weights* in the convolutional layers to further smooth the landscape.
By doing so, we do not have to worry about transferring smoothing effects from activations to weights; moreover, the smoothing effects on activations and weights are also additive.
Based on these motivations, we propose Weight Standardization.

### IV-A Weight Standardization

Here, we show the detailed modeling of Weight Standardization (WS) (Fig. [2](#S3.F2 "Fig. 2 ‣ III-B Elimination singularities ‣ III Lipschitz Smoothness and Elimination Singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization")).
Consider a standard convolutional layer with its bias term set to 0:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bm{y}=\hat{\bm{W}}\*\bm{x},$ |  | (4) |

where $\hat{\bm{W}}\in\mathbb{R}^{O\times I}$ denotes the weights in the layer and $\*$ denotes the convolution operation.
For $\hat{\bm{W}}\in\mathbb{R}^{O\times I}$, $O$ is the number of the output channels, $I$ corresponds to the number of input channels within the kernel region of each output channel.
Taking Fig. [2](#S3.F2 "Fig. 2 ‣ III-B Elimination singularities ‣ III Lipschitz Smoothness and Elimination Singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") as an example, $O=C\_{\text{out}}$ and $I=C\_{\text{in}}\times\text{Kernel\\_Size}$.
In Weight Standardization, instead of directly optimizing the loss $\mathcal{L}$ on the original weights $\hat{\bm{W}}$, we reparameterize the weights $\hat{\bm{W}}$ as a function of $\bm{W}$, i.e., $\hat{\bm{W}}=\text{WS}(\bm{W})$, and optimize the loss $\mathcal{L}$ on $\bm{W}$ by SGD:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\hat{\bm{W}}$ | $\displaystyle=\Big[\hat{\bm{W}}\_{i,j}~\big|~\hat{\bm{W}}\_{i,j}=\dfrac{\bm{W}\_{i,j}-\mu\_{\bm{W}\_{i,\cdot}}}{\sigma\_{\bm{W}\_{i,\cdot}}}\Big],$ |  | (5) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\bm{y}$ | $\displaystyle=\hat{\bm{W}}\*\bm{x},$ |  | (6) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mu\_{\bm{W}\_{i,\cdot}}=\dfrac{1}{I}\sum\_{j=1}^{I}\bm{W}\_{i,j},~~\sigma\_{\bm{W}\_{i,\cdot}}=\sqrt{\dfrac{1}{I}\sum\_{j=1}^{I}\bm{W}\_{i,j}^{2}-\mu\_{\bm{W}\_{i,\cdot}}^{2}+\epsilon}.$ |  | (7) |

Similar to BN, WS controls the first and second moments of the weights of each output channel individually in convolutional layers.
Note that many initialization methods also initialize the weights in some similar ways.
Different from those methods, WS standardizes the weights in a differentiable way which aims to normalize gradients during back-propagation.
Note that we do not have any affine transformation on $\hat{\bm{W}}$.
This is because we assume that normalization layers such as BN or GN will normalize this convolutional layer again, and having affine transformation will confuse and slow down training.
In the following, we first discuss the normalization effects of WS to the gradients.

### IV-B Comparing WS with WN and CWN

Weight Normalization (WN) [[27](#bib.bib27)] and Centered Weight Normalization (CWN) [[28](#bib.bib28)] also normalize weights to speed up deep network training.
Weight Normalization reparameterizes weights by separating the direction $\frac{W}{\left\lVert W\right\rVert}$ and length $g$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{\bm{W}}=g\frac{\bm{W}}{\left\lVert\bm{W}\right\rVert}.$ |  | (8) |

WN is able to train good models on many tasks.
But as shown in [[46](#bib.bib46)], WN has difficulty matching the performances of models trained with BN on large-scale datasets.
Later, CWN adds a centering operation for WN, i.e.,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{W}=g\frac{\bm{W}-\overline{\bm{W}}}{\left\lVert\bm{W}-\overline{\bm{W}}\right\rVert}.$ |  | (9) |

To compare with WN and CWN, we consider the weights for only one of the output channel and reformulate the corresponding weights output by WS in Eq. [5](#S4.E5 "In IV-A Weight Standardization ‣ IV Weight Standardization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{W}=\dfrac{\bm{W}-\overline{\bm{W}}}{\sqrt{\overline{\bm{W}^{2}}-{\overline{\bm{W}}}^{2}}},$ |  | (10) |

which removes the learnable length $g$ from Eq. [9](#S4.E9 "In IV-B Comparing WS with WN and CWN ‣ IV Weight Standardization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and divides the weights with their standard deviation instead.
Experiments in Sec. [VIII](#S8 "VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") show that WS outperforms WN and CWN on large-scale tasks [[9](#bib.bib9)].

## V The smoothing effects of WS

In this section, we discuss the smoothing effects of WS.
Sec. [V-A](#S5.SS1 "V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows that WS normalizes the gradients.
This normalization effect on gradients lowers the Lipschitz constants of the loss and the gradients as will be shown in Sec. [V-B](#S5.SS2 "V-B WS smooths landscape ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), where Sec. [V-B1](#S5.SS2.SSS1 "V-B1 Effects of WS on the Lipschitz constant of the loss ‣ V-B WS smooths landscape ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") discusses the effects on the loss and Sec. [V-B2](#S5.SS2.SSS2 "V-B2 Effects of WS on the Lipschitz constant of gradients ‣ V-B WS smooths landscape ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") discusses the effects on the gradients.

### V-A WS normalizes gradients

For convenience, we set $\epsilon=0$ (in Eq. [7](#S4.E7 "In IV-A Weight Standardization ‣ IV Weight Standardization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization")).
We first focus on one output channel $c$.
Let $\bm{y}\_{c}\in\mathbb{R}^{b}$ be all the outputs of channel $c$ during one pass of feedforwarding and back-propagation, and $\bm{x}\_{c}\in\mathbb{R}^{b,I}$ be the corresponding inputs.
Then, we can rewrite Eq. [5](#S4.E5 "In IV-A Weight Standardization ‣ IV Weight Standardization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and  [6](#S4.E6 "In IV-A Weight Standardization ‣ IV Weight Standardization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") as

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\dot{\bm{W}}\_{c,\cdot}$ | $\displaystyle=\bm{W}\_{c,\cdot}-\dfrac{1}{I}\mathbf{1}\langle\mathbf{1},\bm{W}\_{c,\cdot}\rangle,$ |  | (11) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\hat{\bm{W}}\_{c,\cdot}$ | $\displaystyle=\dot{\bm{W}}\_{c,\cdot}/\Big(\sqrt{\dfrac{1}{I}\langle\mathbf{1},\dot{\bm{W}}^{\circ 2}\_{c,\cdot}\rangle}\Big),$ |  | (12) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\bm{y}\_{c}$ | $\displaystyle=\bm{x}\_{c}\hat{\bm{W}}\_{c,\cdot},$ |  | (13) |

where $\langle~,~\rangle$ denotes dot product and ∘2 denotes Hadamard power.
Then, the gradients are

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\nabla\_{\dot{\bm{W}}\_{c,\cdot}}\mathcal{L}=\dfrac{1}{\sigma\_{\bm{W}\_{c,\cdot}}}\Big(\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}-\dfrac{1}{I}\langle\hat{\bm{W}}\_{c,\cdot},\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\rangle\hat{\bm{W}}\_{c,\cdot}\Big),$ |  | (14) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\nabla\_{\bm{W}\_{c,\cdot}}\mathcal{L}=\nabla\_{\dot{\bm{W}}\_{c,\cdot}}\mathcal{L}-\dfrac{1}{I}\mathbf{1}\langle\mathbf{1},\nabla\_{\dot{\bm{W}}\_{c,\cdot}}\mathcal{L}\rangle.$ |  | (15) |

Fig. [3](#S5.F3 "Fig. 3 ‣ V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows the computation graph.
Based on the equations, we observe that different from the original gradients $\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}$ which is back-propagated through Eq. [13](#S5.E13 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), the gradients are normalized by Eq. [14](#S5.E14 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") & [15](#S5.E15 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization").

In Eq. [14](#S5.E14 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), to compute $\nabla\_{\dot{\bm{W}}\_{c,\cdot}}\mathcal{L}$, $\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}$ is first subtracted by a weighted average of $\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}$ and then divided by $\sigma\_{\hat{\bm{W}}\_{c,\cdot}}$.
Note that when BN is used to normalize this convolutional layer, as BN will compute again the scaling factor $\sigma\_{\bm{u}}$, the effects of dividing the gradients by $\sigma\_{\hat{\bm{W}}\_{c,\cdot}}$ will be canceled in both feedforwarding and back-propagation.
As for the additive term, its effect will depend on the statistics of $\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}$ and ${\hat{\bm{W}}}\_{c,\cdot}$.
We will later show that this term will reduce the gradient norm regardless of the statistics.
As for Eq. [15](#S5.E15 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), it zero-centers the gradients from $\dot{\bm{W}}\_{c,\cdot}$.
When the mean gradient is large, zero-centering will significantly affect the gradients passed to $\bm{W}\_{c,\cdot}$.

Fig. 3: Computation graph for WS in feed-forwarding and back-propagation.
$\bm{W}$, $\dot{\bm{W}}$ and $\hat{\bm{W}}$ are defined in Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and [13](#S5.E13 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization").

Fig. 4: Training ResNet-50 on ImageNet with GN, Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization").
The left and the middle figures show the training dynamics.
The right figure shows the reduction percentages on the Lipschitz constant.
Note that the y-axis of the right figure is in log scale.

### V-B WS smooths landscape

We will show that WS is able to make the loss landscape smoother.
Specifically, we show that optimizing $\mathcal{L}$ on $\bm{W}$ has smaller Lipschitz constants on both the loss and the gradients than optimizing $\mathcal{L}$ on $\hat{\bm{W}}$.
Lipschitz constant of a function $f$ is the value of $L$ if $f$ satisfies
$|f(x\_{1})-f(x\_{2})|\leq L\lVert x\_{1}-x\_{2}\rVert,~\forall x\_{1},x\_{2}$.
For the loss and gradients, $f$ will be $\mathcal{L}$ and $\nabla\_{\bm{W}}\mathcal{L}$, and $x$ will be $\bm{W}$.
Smaller Lipschitz constants on the loss and gradients mean that the changes of the loss and the gradients during training will be bounded more.
They will provide more confidence when the optimizer takes a big step in the gradient direction as the gradient direction will vary less within the range of the step.
In other words, the optimizer can take longer steps without worrying about sudden changes of the loss landscape and gradients.
Therefore, WS is able to accelerate training.

#### V-B1 Effects of WS on the Lipschitz constant of the loss

Here, we show that both Eq. [14](#S5.E14 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and Eq. [15](#S5.E15 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") are able to reduce the Lipschitz constant of the loss.
We first study Eq. [14](#S5.E14 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"):

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\begin{split}\big\lVert\nabla\_{\dot{{\bm{W}}}\_{c,\cdot}}\mathcal{L}\big\rVert^{2}=\dfrac{1}{\sigma\_{{W}\_{c,\cdot}}^{2}}\Big(\big\lVert\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\big\rVert^{2}+\\ \dfrac{1}{I^{2}}\big\langle\hat{\bm{W}}\_{c,\cdot},\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\big\rangle^{2}\big(\langle\hat{\bm{W}}\_{c,\cdot},\hat{\bm{W}}\_{c,\cdot}\rangle-2I\big)\Big).\end{split}$ | |  | (16) |

By Eq. [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), we know that $\lVert\hat{\bm{W}}\_{c,\cdot}\rVert^{2}=I$.
Then,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\begin{split}\big\lVert\nabla\_{\dot{{\bm{W}}}\_{c,\cdot}}\mathcal{L}\big\rVert^{2}=\dfrac{1}{\sigma\_{{W}\_{c,\cdot}}^{2}}\Big(\big\lVert\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\big\rVert^{2}-\\ \dfrac{1}{I}\big\langle\hat{\bm{W}}\_{c,\cdot},\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\big\rangle^{2}\Big).\end{split}$ | |  | (17) |

Since we assume that this convolutional layer is followed by a normalization layer such as BN or GN, the effect of $1/\sigma\_{{W}\_{c,\cdot}}^{2}$ will be canceled.
Therefore, the real effect on the gradient norm is the reduction $\dfrac{1}{I}\big\langle\hat{\bm{W}}\_{c,\cdot},\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\big\rangle^{2}$, which reduces the Lipschitz constant of the loss.

Next, we study the effect of Eq. [15](#S5.E15 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization").
By definition,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\big\lVert\nabla\_{\bm{W}\_{c,\cdot}}\mathcal{L}\big\rVert^{2}=\big\lVert\nabla\_{\dot{{\bm{W}}}\_{c,\cdot}}\mathcal{L}\big\rVert^{2}-\dfrac{1}{I}\langle\mathbf{1},\nabla\_{\dot{{\bm{W}}}\_{c,\cdot}}\mathcal{L}\rangle^{2}.$ |  | (18) |

By Eq. [14](#S5.E14 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), we rewrite the second term:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\begin{split}\dfrac{1}{I}\langle\mathbf{1},\nabla\_{\dot{{\bm{W}}}\_{c,\cdot}}\mathcal{L}\rangle^{2}=\dfrac{1}{I\cdot\sigma^{2}\_{W\_{c,\cdot}}}\Big(\langle\mathbf{1},\nabla\_{\hat{{\bm{W}}}\_{c,\cdot}}\mathcal{L}\rangle\\ -\dfrac{1}{I}\langle\hat{\bm{W}}\_{c,\cdot},\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\rangle\cdot\langle\mathbf{1},~\hat{\bm{W}}\_{c,\cdot}\rangle\Big)^{2}.\end{split}$ | |  | (19) |

Since $\langle\mathbf{1},~\hat{\bm{W}}\_{c,\cdot}\rangle=0$, we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\big\lVert\nabla\_{\bm{W}\_{c,\cdot}}\mathcal{L}\big\rVert^{2}=\big\lVert\nabla\_{\dot{{\bm{W}}}\_{c,\cdot}}\mathcal{L}\big\rVert^{2}-\dfrac{1}{I\cdot\sigma^{2}\_{W\_{c,\cdot}}}\langle\mathbf{1},\nabla\_{\hat{{\bm{W}}}\_{c,\cdot}}\mathcal{L}\rangle^{2}.$ |  | (20) |

Summarizing the effects of Eq. [14](#S5.E14 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and [15](#S5.E15 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") on the Lipschitz constant of the loss: ignoring $1/\sigma\_{{W}\_{c,\cdot}}^{2}$, Eq. [14](#S5.E14 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") reduces it by $\frac{1}{I}\big\langle\hat{\bm{W}}\_{c,\cdot},\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\big\rangle^{2}$, and Eq. [15](#S5.E15 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") reduces it by $\frac{1}{I}\langle\mathbf{1},\nabla\_{\hat{{\bm{W}}}\_{c,\cdot}}\mathcal{L}\rangle^{2}$.

Although both Eq. [14](#S5.E14 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and [15](#S5.E15 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") reduce the Lipschitz constant, their real effects depend on the statistics of the weights and the gradients.
For example, the reduction effect of Eq. [15](#S5.E15 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") depends on the average gradients on $\hat{\bm{W}}$.
As for Eq. [14](#S5.E14 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), note that $\langle\mathbf{1},~\hat{\bm{W}}\_{c,\cdot}\rangle=0$, its effect might be limited when $\hat{\bm{W}}\_{c,\cdot}$ is evenly distributed around $0$.
To understand their real effects, we conduct a case study on ResNet-50 trained on ImageNet to see which one of Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") has bigger effects or they contribute similarly to smoothing the landscape.

#### V-B2 Effects of WS on the Lipschitz constant of gradients

Before the Lipschitzness study on the gradients, we first show a case study where we train ResNet-50 models on ImageNet following the conventional training procedure [[2](#bib.bib2)].
In total, we train four models, including ResNet-50 with GN, ResNet-50 with GN+Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), ResNet-50 with GN+Eq. [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and ResNet-50 with GN+Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization")&[12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization").
The training dynamics are shown in Fig. [4](#S5.F4 "Fig. 4 ‣ V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"),
from which we observe that Eq. [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") slightly improves the training speed and performances of models with or without Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") while the major improvements are from Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization").
This observation motivates us to study the real effects of Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") on the Lipschitz constant of the loss.
To investigate this, we take a look at the values of $\frac{1}{I}\big\langle\hat{\bm{W}}\_{c,\cdot},\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\big\rangle^{2}$, and $\frac{1}{I}\langle\mathbf{1},\nabla\_{\hat{{\bm{W}}}\_{c,\cdot}}\mathcal{L}\rangle^{2}$ during training.

To compute the two values above, we gather and save the intermediate gradients $\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}$, and the weights for the convolution $\hat{\bm{W}}\_{c,\cdot}$.
In total, we train ResNet-50 with GN, Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") for 90 epochs, and we save the gradients and the weights of the first training iteration of each epoch.
The right figure of Fig. [4](#S5.F4 "Fig. 4 ‣ V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows the average percentages of $\frac{1}{I}\big\langle\hat{\bm{W}}\_{c,\cdot},\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\big\rangle^{2}$, $\frac{1}{I}\langle\mathbf{1},\nabla\_{\hat{{\bm{W}}}\_{c,\cdot}}\mathcal{L}\rangle^{2}$, and $\sigma^{2}\_{\bm{W}\_{c,\cdot}}\lVert\nabla\_{\bm{W}\_{c,\cdot}}\mathcal{L}\rVert^{2}$.
From the right figure we can see that $\frac{1}{I}\big\langle\hat{\bm{W}}\_{c,\cdot},\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\big\rangle^{2}$ is small compared with other two components ($<0.02$).
In other words, although Eq. [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") decreases the gradient norm regardless of the statistics of the weights and gradients, its real effect is limited due to the distribution of $\hat{\bm{W}}\_{c,\cdot}$ and $\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}$.
Nevertheless, from the left figures we can see that Eq. [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") still improves the training.
Since Eq. [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") requires very little computations, we will keep it in WS.

From the experiments above, we observe that the training speed boost is mainly due to Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization").
As the effect of Eq. [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") is limited, in this section, we only study the effect of Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") on the Hessian of $\bm{W}\_{c,\cdot}$ and $\dot{\bm{W}}\_{c,\cdot}$.
Here, we will show that Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") decreases the Frobenius norm of the Hessian matrix of the weights, i.e., $\lVert\nabla^{2}\_{\bm{W}\_{c,\cdot}}\mathcal{L}\rVert\_{F}\leq\lVert\nabla^{2}\_{\dot{\bm{W}}\_{c,\cdot}}\mathcal{L}\rVert\_{F}$.
With smaller Frobenius norm, the gradients of $\bm{W}\_{c,\cdot}$ are more predictable, thus the loss is smoother and easier to optimize.

We use $\bm{H}$ and $\dot{\bm{H}}$ to denote the Hessian matrices of $\bm{W}\_{c,\cdot}$ and $\dot{\bm{W}}\_{c,\cdot}$, respectively, i.e.,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bm{H}\_{i,j}=\dfrac{\partial^{2}\mathcal{L}}{\partial\bm{W}\_{c,i}\partial\bm{W}\_{c,j}},~~~\dot{\bm{H}}\_{i,j}=\dfrac{\partial^{2}\mathcal{L}}{\partial\bm{\dot{W}}\_{c,i}\partial\bm{\dot{W}}\_{c,j}}.$ |  | (21) |

We first derive the relationship between $\bm{H}\_{i,j}$ and $\dot{\bm{H}}\_{i,j}$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bm{H}\_{i,j}=\dot{\bm{H}}\_{i,j}-\dfrac{1}{I}\sum\_{k=1}^{I}(\dot{\bm{H}}\_{i,k}+\dot{\bm{H}}\_{k,j})+\dfrac{1}{I^{2}}\sum\_{p=1}^{I}\sum\_{q=1}^{I}\dot{\bm{H}}\_{p,q}.$ |  | (22) |

Note that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sum\_{i=1}^{I}\sum\_{j=1}^{I}\bm{H}\_{i,j}=0.$ |  | (23) |

Therefore, Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") not only zero-centers the feedforwarding outputs and the back-propagated gradients, but also the Hessian matrix.
Next, we compute its Frobenius norm:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\begin{split}\lVert\bm{H}\rVert\_{F}=&\sum\_{i=1}^{I}\sum\_{j=1}^{I}\bm{H}^{2}\_{i,j}\\ =&\lVert\bm{\dot{H}}\rVert\_{F}+\dfrac{1}{I^{2}}\big(\sum\_{i=1}^{I}\sum\_{j=1}^{I}\bm{\dot{H}}\_{i,j}\big)^{2}\\ &-\dfrac{1}{I}\sum\_{i=1}^{I}\Big(\sum\_{j=1}^{I}\bm{\dot{H}}\_{i,j}\Big)^{2}-\dfrac{1}{I}\sum\_{j=1}^{I}\Big(\sum\_{i=1}^{I}\bm{\dot{H}}\_{i,j}\Big)^{2}\\ \leq&\lVert\bm{\dot{H}}\rVert\_{F}-\dfrac{1}{I^{2}}\big(\sum\_{i=1}^{I}\sum\_{j=1}^{I}\bm{\dot{H}}\_{i,j}\big)^{2}.\end{split}$ | |  | (24) |

As shown in Eq. [24](#S5.E24 "In V-B2 Effects of WS on the Lipschitz constant of gradients ‣ V-B WS smooths landscape ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") reduces the Frobenius norm of the Hessian matrix by at least $\big(\sum\_{i=1}^{I}\sum\_{j=1}^{I}\bm{\dot{H}}\_{i,j}\big)^{2}/I^{2}$, which makes the gradients more predictable than directly optimizing on the weights of the convolutional layer.

### V-C Connections to constrained optimization

WS imposes constraints to the weight $\hat{\bm{W}}\_{c,\cdot}$ such that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sum\_{i=1}^{I}\hat{\bm{W}}\_{c,i}=0,~~~\sum\_{i=1}^{I}\hat{\bm{W}}^{2}\_{c,i}=I,~~~\forall c.$ |  | (25) |

Therefore, an alternative to the proposed WS is to consider the problem as constrained optimization and uses Projected Gradient Descent (PGD) to find the solution.
The update rule for PGD can be written as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\hat{\bm{W}}^{t+1}\_{c,i}=\texttt{Proj}\big(\hat{\bm{W}}^{t}\_{c,i}-\epsilon\cdot\nabla\_{\hat{\bm{W}}^{t}\_{c,i}}\mathcal{L}\big)$ |  | (26) |

where $\texttt{Proj}(\cdot)$ denotes the projection function and $\epsilon$ denotes the learning rate.
To satisfy Eq. [25](#S5.E25 "In V-C Connections to constrained optimization ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), $\texttt{Proj}(\cdot)$ standardizes its input. We can approximate the right hand side of Eq. [26](#S5.E26 "In V-C Connections to constrained optimization ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") by minimizing the Lagrangian of the loss function $\mathcal{L}$, which obtains

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\hat{\bm{W}}^{t+1}\_{c,i}$ | $\displaystyle\approx\hat{\bm{W}}^{t}\_{c,i}-\epsilon\Big(\nabla\_{\hat{\bm{W}}^{t}\_{c,i}}\mathcal{L}-\langle\hat{\bm{W}}\_{c,\cdot},\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\rangle\hat{\bm{W}}\_{c,i}$ |  | (27) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle-\frac{1}{I}\langle\mathbf{1},\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\rangle\Big)$ |  |

Different from Eq. [26](#S5.E26 "In V-C Connections to constrained optimization ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), the update rule of WS is

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\begin{split}\hat{\bm{W}}^{t+1}\_{c,i}=&\texttt{Proj}\Big(\bm{W}^{t}\_{c,i}-\epsilon\cdot\nabla\_{{\bm{W}}^{t}\_{c,i}}\mathcal{L}\Big)\\ =&\texttt{Proj}\Big(\bm{W}^{t}\_{c,i}-\dfrac{\epsilon}{\sigma\_{\bm{W}\_{c,\cdot}}}\big(\nabla\_{\hat{\bm{W}}\_{c,i}}\mathcal{L}-\dfrac{1}{I}\langle\hat{\bm{W}}\_{c,\cdot},\\ &\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\rangle\hat{\bm{W}}\_{c,i}-\dfrac{1}{I}\langle\mathbf{1},\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\rangle\big)\\ &-\dfrac{\epsilon}{I^{2}\cdot\sigma\_{\bm{W}\_{c,\cdot}}}\big\langle\mathbf{1},\langle\hat{\bm{W}}\_{c,\cdot},\nabla\_{\hat{\bm{W}}\_{c,\cdot}}\mathcal{L}\rangle\hat{\bm{W}}\_{c,\cdot}\big\rangle\Big).\end{split}$ | |  | (28) |

Eq. [28](#S5.E28 "In V-C Connections to constrained optimization ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") is more complex than Eq. [27](#S5.E27 "In V-C Connections to constrained optimization ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), but the increased complexity is neglectable compared with training deep networks.
For simplicity, Eq. [28](#S5.E28 "In V-C Connections to constrained optimization ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") reuses Proj to denote the standardization process, despite that WS uses Stochastic Gradient Descent instead of Projected Gradient Descent to optimize the weights.

## VI WS’s effects on elimination singularities

In this section, we will provide the background of BN, GN and LN, discuss the negative correlation between the performance and the distance to elimination singularities, and show LN and GN are unable to keep the networks away from elimination singularities as BN.
Next, we will show that WS helps avoiding elimination singularities.

### VI-A Batch- and channel-based normalizations and their effects on elimination singularities

#### VI-A1 Batch- and channel-based normalizations

Based on how activations are normalized, we group the normalization methods into two types: batch-based normalization and channel-based normalization, where the batch-based normalization method corresponds to BN and the channel-based normalization methods include LN and GN.

Suppose we are going to normalize a 2D feature map $\bm{X}\in\mathds{R}^{B\times C\times H\times W}$, where $B$ is the batch size, $C$ is the number of channels, $H$ and $W$ denote the height and the width.
For each channel $c$, BN normalizes $\bm{X}$ by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bm{Y}\_{\cdot c\cdot\cdot}=\dfrac{\bm{X}\_{\cdot c\cdot\cdot}-\mu\_{\cdot c\cdot\cdot}}{\sigma\_{\cdot c\cdot\cdot}},$ |  | (29) |

where $\mu\_{\cdot c\cdot\cdot}$ and $\sigma\_{\cdot c\cdot\cdot}$ denote the mean and the standard deviation of all the features of the channel $c$, $\bm{X}\_{\cdot c\cdot\cdot}$.
Throughout the paper, we use $\cdot$ in the subscript to denote all the features along that dimension for convenience.

Unlike BN which computes statistics on the batch dimension in addition to the height and width, channel-based normalization methods (LN and GN) compute statistics on the channel dimension.
Specifically, they divide the channels to several groups, and normalize each group of channels, i.e.,
$\bm{X}$ is reshaped as $\bm{\dot{X}}\in\mathds{R}^{B\times G\times C/G\times H\times W}$, and then:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bm{\dot{Y}}\_{bg\cdot\cdot\cdot}=\dfrac{\bm{\dot{X}}\_{bg\cdot\cdot\cdot}-\mu\_{bg\cdot\cdot\cdot}}{\sigma{{}\_{bg\cdot\cdot\cdot}}},$ |  | (30) |

for each sample $b$ of $B$ samples in a batch and each channel group $g$ out of all $G$ groups.
After Eq. [30](#S6.E30 "In VI-A1 Batch- and channel-based normalizations ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), the output $\bm{\dot{Y}}$ is reshaped as $\bm{\dot{X}}$ and denoted by $\bm{Y}$.

Both batch- and channel-based normalization methods have an optional affine transformation, i.e.,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bm{Z}\_{\cdot c\cdot\cdot}=\gamma\_{c}\bm{Y}\_{\cdot c\cdot\cdot}+\beta\_{c}.$ |  | (31) |

#### VI-A2 BN avoids elimination singularities

Here, we study the effect of BN on elimination singularities.
Since the normalization methods all have an optional affine transformation, we focus on the distinct part of BN, which normalizes all channels to zero mean and unit variance, i.e.,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbb{E}\_{y\in Y\_{\cdot c\cdot\cdot}}\big[y\big]=0,~~\mathbb{E}\_{y\in Y\_{\cdot c\cdot\cdot}}\big[y^{2}\big]=1,~~\forall c.$ |  | (32) |

As a result, regardless of the weights and the distribution of the inputs, it guarantees that the activations of each channel are zero-centered with unit variance.
Therefore, each channel cannot be constantly deactivated because there are always some activations that are $>0$, nor underrepresented due to the channel having a very small activation scale compared with the others.

Fig. 5: Model accuracy and distance to singularities.
Larger circles correspond to higher performances.
Red crosses represent failure cases (accuracy $<70\%$).
Circles are farther from singularities/closer to BN if they are closer to the origin.

#### VI-A3 Statistical distance and its affects on performance

> BN avoids singularities by normalizing each channel to zero mean and unit variance.
> What if they are normalized to other means and variances?

We ask this question because this is similar to what happens in channel-normalized models.
In the context of activation-based normalizations, BN completely resolve the issue of elimination singularities as each channel is zero-centered with unit variance.
By contrast, channel-based normalization methods, as they do not have batch information, are unable to make sure that all neurons have zero mean and unit variance after normalization.
In other words, there are likely some underrepresented channels after training if the model is using channel-based normalizations.
Since BN represents the ideal case which has the furthest distance to elimination singularities, and any dissimilarity with BN will lead to lightly or heavily underrepresented channels and thus make the models closer to singularities,
*we use the distance to BN as the distance to singularities for activation-based normalizations.*
Specifically, in this definition, the model is closer to singularities when it is far from BN.
Fig. [5](#S6.F5 "Fig. 5 ‣ VI-A2 BN avoids elimination singularities ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows that this definition is useful, where we study the relationship between the performance and the distance to singularities (i.e., how far from BN) caused by statistical differences.
We conduct experiments on a 4-layer convolutional network, the results of which are shown in Fig [5](#S6.F5 "Fig. 5 ‣ VI-A2 BN avoids elimination singularities ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization").
Each convolutional layer has 32 output channels, and is followed by an average pooling layer which down-samples the features by a factor of 2.
Finally, a global average pooling layer and a fully-connected layer output the logits for Softmax.
The experiments are done on CIFAR-10 [[11](#bib.bib11)].

In the experiment, each channel $c$ will be normalized to a pre-defined mean $\hat{\mu}\_{c}$ and a pre-defined variance $\hat{\sigma}\_{c}$ that are drawn from two distributions, respectively:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{\mu}\_{c}\sim\mathcal{N}(0,\sigma\_{\mu})~~\text{and}~~\hat{\sigma}\_{c}=e^{\dot{\sigma}\_{c}}~\text{where}~\dot{\sigma}\_{c}\sim\mathcal{N}(0,\sigma\_{\sigma}).$ |  | (33) |

The model will be closer to singularities when $\sigma\_{\mu}$ or $\sigma\_{\sigma}$ increases.
BN corresponds to the case where $\sigma\_{\mu}=\sigma\_{\sigma}=0$.

After getting $\hat{\mu}\_{c}$ and $\hat{\sigma}\_{c}$ for each channel, we compute

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bm{Y}\_{\cdot c\cdot\cdot}=\gamma\_{c}\big(\hat{\sigma}\_{c}\dfrac{\bm{X}\_{\cdot c\cdot\cdot}-\mu\_{\cdot c\cdot\cdot}}{\sigma\_{\cdot c\cdot\cdot}}+\hat{\mu}\_{c}\big)+\beta\_{c}.$ |  | (34) |

Note that $\hat{\mu}\_{c}$ and $\hat{\sigma}\_{c}$ are fixed during training while $\gamma\_{c}$ and $\beta\_{c}$ are trainable parameters in the affine transformation.

Fig. 6: 
Means and standard deviations of the statistical differences (StatDiff defined in Eq. [35](#S6.E35 "In VI-A4 Statistics in Channel-based Normalization ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization")) of all layers in a ResNet-110 trained on CIFAR-10 with GN, GN+WS, LN, and LN+WS.

Fig. [5](#S6.F5 "Fig. 5 ‣ VI-A2 BN avoids elimination singularities ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows the experimental results.
When $\sigma\_{\mu}$ and $\sigma\_{\sigma}$ are closer to the origin, the normalization method is more close to BN.
When their values increase, we observe performance decreases.
For extreme cases, we also observe training failures.
These results indicate that although the affine transformation theoretically can find solutions that cancel the negative effects of normalizing channels to different statistics, their capability is limited by the gradient-based training.
They show that defining distance to singularities as the distance to BN is useful.
They also raise concerns about channel normalizations regarding their distances.

#### VI-A4 Statistics in Channel-based Normalization

Following our concerns about channel-based normalization and their distance to singularities, we study the statistical differences between channels when they are normalized by a channel-based normalization such as GN or LN.

Statistical differences in GN, LN and WS:
We train a ResNet-110 [[2](#bib.bib2)] on CIFAR-10 [[11](#bib.bib11)] normalized by GN, LN, with and without WS.
During training, we keep record of the running mean $\mu^{r}\_{c}$ and variance $\sigma\_{c}^{r}$ of each channel $c$ after convolutional layers.
For each group $g$ of the channels that are normalized together, we compute their channel statistical difference defined as the standard deviation of their means divided by the mean of their standard deviations, i.e.,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\text{StatDiff}(g)=\dfrac{\sqrt{\mathbb{E}\_{c\in g}\big[(\mu^{r}\_{c})^{2}\big]-\big(\mathbb{E}\_{c\in g}\big[\mu^{r}\_{c}\big]\big)^{2}}}{\mathbb{E}\_{c\in g}\big[\sigma\_{c}\big]}.$ |  | (35) |

We plot the average statistical differences of all the groups after every training epoch as shown in Fig. [6](#S6.F6 "Fig. 6 ‣ VI-A3 Statistical distance and its affects on performance ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization").

By Eq. [35](#S6.E35 "In VI-A4 Statistics in Channel-based Normalization ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), $\text{StatDiff}(g)\geq 0,~\forall g$.
In BN, all their means are the same, as well as their variances, thus $\text{StatDiff}(g)=0$.
As the value of $\text{StatDiff}(g)$ goes up, the differences between channels within a group become larger.
Since they will be normalized together as in Eq. [30](#S6.E30 "In VI-A1 Batch- and channel-based normalizations ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), large differences will inevitably lead to underrepresented channels.
Fig. [7](#S6.F7 "Fig. 7 ‣ VI-A4 Statistics in Channel-based Normalization ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") plots 3 examples of 2 channels before and after normalization in Eq. [30](#S6.E30 "In VI-A1 Batch- and channel-based normalizations ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization").
Compared with those examples, it is clear that the models in Fig. [6](#S6.F6 "Fig. 6 ‣ VI-A3 Statistical distance and its affects on performance ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") have many underrepresented channels.

Fig. 7: Examples of normalizing two channels in a group when they have different means and variances.
Transparent bars mean they are $0$ after ReLU.
StatDiff is defined in Eq. [35](#S6.E35 "In VI-A4 Statistics in Channel-based Normalization ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization").

Why GN performs better than LN:
Fig. [6](#S6.F6 "Fig. 6 ‣ VI-A3 Statistical distance and its affects on performance ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") also provides explanations why GN performs better than LN.
Comparing GN and LN, the major difference is their numbers of groups for channels: LN has only one group for all the channels in a layer while GN collects them into several groups.
A strong benefit of having more than one group is that it guarantees that each group will at least have one neuron that is not suppressed by the others from the same group.
Therefore, GN provides a mechanism to prevent the models from getting too close to singularities.

Fig. [6](#S6.F6 "Fig. 6 ‣ VI-A3 Statistical distance and its affects on performance ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") also shows the statistical differences when WS is used.
From the results, we can clearly see that WS makes StatDiff much closer to $0$.
Consequently, the majority of the channels are not underrepresented in WS: most of them are frequently activated and they are at similar activation scales.
This makes training with WS easier and their results better.

### VI-B WS helps avoiding elimination singularities

The above discussions show that WS helps keeping models away from elimination singularities.
Here, we discuss why WS is able to achieve this.
Recall that WS adds constraints to the weight $\bm{W}\in\mathds{R}^{\text{O}\times\text{I}}$ of a convolutional layer with O output channels and I inputs such that $\forall c$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sum\_{i=1}^{I}\bm{W}\_{c,i}=0,~~~\sum\_{i=1}^{I}\bm{W}^{2}\_{c,i}=1.$ |  | (36) |

With the constraints of WS, $\mu\_{c}^{\text{out}}$ and $\sigma\_{c}^{\text{out}}$ become

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mu\_{c}^{\text{out}}=\sum\_{i=1}^{I}\bm{W}\_{c,i}\mu\_{i}^{\text{in}},~~~(\sigma\_{c}^{\text{out}})^{2}=\sum\_{i=1}^{I}\bm{W}\_{c,i}^{2}(\sigma\_{i}^{\text{in}})^{2},$ |  | (37) |

when we follow the assumptions in Xavier initialization [[24](#bib.bib24)].
When the input channels are similar in their statistics, i.e., $\mu\_{i}^{\text{in}}\approx\mu\_{j}^{\text{in}}$, $\sigma\_{i}^{\text{in}}\approx\sigma\_{j}^{\text{in}}$, $\forall i,j$,

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\mu\_{c}^{\text{out}}$ | $\displaystyle\approx$ | $\displaystyle\mu\_{1}^{\text{in}}\sum\_{i=1}^{I}\bm{W}\_{c,i}=0,$ |  | (38) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle(\sigma\_{c}^{\text{out}})^{2}$ | $\displaystyle\approx$ | $\displaystyle(\sigma\_{1}^{\text{in}})^{2}\sum\_{i=1}^{I}\bm{W}\_{c,i}^{2}=(\sigma\_{1}^{\text{in}})^{2}.$ |  | (39) |

In other words, WS can pass the statistical similarities from the input channels to the output channels, all the way from the image space where RGB channels are properly normalized.
This is similar to the objective of Xavier initialization [[24](#bib.bib24)] or Kaiming initialization [[25](#bib.bib25)], except that WS enforces it by reparameterization throughout the entire training process, thus is able to reduce the statistical differences a lot, as shown in Fig. [6](#S6.F6 "Fig. 6 ‣ VI-A3 Statistical distance and its affects on performance ‣ VI-A Batch- and channel-based normalizations and their effects on elimination singularities ‣ VI WS’s effects on elimination singularities ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization").

Here, we summarize this subsection.
We have shown that channel-based normalization methods, as they do not have batch information, are not able to ensure a far distance from elimination singularities.
Without the help of batch information, GN alleviates this issue by assigning channels to more than one group to encourage more activated neurons, and WS adds constraints to pull the channels to be not so statistically different.
We notice that the batch information is not hard to collect in reality.
This inspires us to equip channel-based normalization with batch information, and the result is Batch-Channel Normalization.

## VII Batch-Channel Normalization

The previous section discusses elimination singularities and shows WS is able to keep models away from them.
To fully address the issue of elimination singularities, we propose Batch-Channel Normalization (BCN).
This section presents the definition of BCN, discusses why adding batch statistics to channel normalization is not redundant, and shows how BCN runs in large-batch and micro-batch training settings.

### VII-A Definition

Batch-Channel Normalization (BCN) adds batch information and constraints to channel-based normalization methods.
Let $\bm{X}\in\mathds{R}^{B\times C\times H\times W}$ be the features to be normalized.
Then, the normalization is done as follows.
$\forall c$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bm{\dot{X}}\_{\cdot c\cdot\cdot}=\gamma\_{c}^{b}\dfrac{\bm{X}\_{\cdot c\cdot\cdot}-\hat{\mu}\_{c}}{\hat{\sigma}\_{c}}+\beta\_{c}^{b},$ |  | (40) |

where the purpose of $\hat{\mu}\_{c}$ and $\hat{\sigma}\_{c}$ is to make

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbb{E}\Big\{\dfrac{\bm{X}\_{\cdot c\cdot\cdot}-\hat{\mu}\_{c}}{\hat{\sigma}\_{c}}\Big\}=0~\text{and}~\mathbb{E}\Big\{\big(\dfrac{\bm{X}\_{\cdot c\cdot\cdot}-\hat{\mu}\_{c}}{\hat{\sigma}\_{c}}\big)^{2}\Big\}=1.$ |  | (41) |

Then, $\bm{\dot{X}}$ is reshaped as $\bm{\dot{X}}\in\mathds{R}^{B\times G\times C/G\times H\times W}$ to have $G$ groups of channels.
Next, $\forall g,b$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bm{\dot{Y}}\_{bg\cdot\cdot\cdot}=\gamma\_{g}^{c}\dfrac{\bm{\dot{X}}\_{bg\cdot\cdot\cdot}-\mu\_{bg\cdot\cdot\cdot}}{\sigma{{}\_{bg\cdot\cdot\cdot}}}+\beta\_{g}^{c}.$ |  | (42) |

Finally, $\bm{\dot{Y}}$ is reshaped back to $\bm{Y}\in\mathds{R}^{B\times C\times H\times W}$, which is the output of the Batch-Channel Normalization.

### VII-B Large- and Micro-batch Implementations

Note that in Eq. [40](#S7.E40 "In VII-A Definition ‣ VII Batch-Channel Normalization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and [42](#S7.E42 "In VII-A Definition ‣ VII Batch-Channel Normalization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), only two statistics need batch information: $\hat{\mu}\_{c}$ and $\hat{\sigma}\_{c}$, as their values depend on more than one sample.
Depending on how we obtain the values of $\hat{\mu}\_{c}$ and $\hat{\sigma}\_{c}$, we have different implementations for large-batch and micro-batch training settings.

#### VII-B1 Large-batch training

When the batch size is large, estimating $\hat{\mu}\_{c}$ and $\hat{\sigma}\_{c}$ is easy: we just use a Batch Normalization layer to achieve the function of Eq. [40](#S7.E40 "In VII-A Definition ‣ VII Batch-Channel Normalization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and [41](#S7.E41 "In VII-A Definition ‣ VII Batch-Channel Normalization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization").
As a result, the proposed BCN can be written as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\text{BCN}(\bm{X})=\text{CN}(\text{BN}(\bm{X})).$ |  | (43) |

Implementing it is also easy with modern deep learning libraries, which is omitted here.

#### VII-B2 Micro-batch training

One of the motivations of channel normalization is to allow deep networks to train on tasks where the batch size is limited by the GPU memory.
Therefore, it is important for Batch-Channel Normalization to be able to work in the micro-batch training setting.

Algorithm 1 Micro-batch BCN

```
Input: 𝑿∈ℝB×C×H×W\bm{X}\in\mathds{R}^{B\times C\times H\times W}, the current estimates of μ^c\hat{\mu}_{c} and σ^c2\hat{\sigma}^{2}_{c}, and the update rate rr.
Output: Normalized 𝒀\bm{Y}.

1
              Compute μ˙c←1B​H​W​∑b,h,w𝑿b,c,h,w\dot{\mu}_{c}\leftarrow\frac{1}{BHW}\sum_{b,h,w}\bm{X}_{b,c,h,w};

2
              Compute σ˙c2←1B​H​W​∑b,h,w(𝑿b,c,h,w−μ^c)2\dot{\sigma}^{2}_{c}\leftarrow\frac{1}{BHW}\sum_{b,h,w}\big(\bm{X}_{b,c,h,w}-\hat{\mu}_{c}\big)^{2};

3
              Update μ^c←μ^c+r⁡(μ˙c−μ^c)\hat{\mu}_{c}\leftarrow\hat{\mu}_{c}+r(\dot{\mu}_{c}-\hat{\mu}_{c});

4
              Update σ^c2←σ^c2+r⁡(σ˙c2−σ^c2)\hat{\sigma}^{2}_{c}\leftarrow\hat{\sigma}^{2}_{c}+r(\dot{\sigma}^{2}_{c}-\hat{\sigma}^{2}_{c});

5
              Normalize 𝑿˙⋅c⋅⋅=γcb𝑿⋅c⋅⋅−μ^cσ^c+βcb\bm{\dot{X}}_{\cdot c\cdot\cdot}=\gamma_{c}^{b}\dfrac{\bm{X}_{\cdot c\cdot\cdot}-\hat{\mu}_{c}}{\hat{\sigma}_{c}}+\beta_{c}^{b};

6
              Reshape 𝑿˙\bm{\dot{X}} to 𝑿˙∈ℝB×G×C/G×H×W\bm{\dot{X}}\in\mathds{R}^{B\times G\times C/G\times H\times W};

7
              Normalize 𝒀˙bg⋯=γgc𝑿˙bg⋯−μbg⋯σbg⋯+βgc\bm{\dot{Y}}_{bg\cdot\cdot\cdot}=\gamma_{g}^{c}\dfrac{\bm{\dot{X}}_{bg\cdot\cdot\cdot}-\mu_{bg\cdot\cdot\cdot}}{\sigma{{}_{bg\cdot\cdot\cdot}}}+\beta_{g}^{c};

8
              Reshape 𝒀˙\bm{\dot{Y}} to 𝒀∈ℝB×C×H×W\bm{{Y}}\in\mathds{R}^{B\times C\times H\times W};
```

Algorithm [1](#algorithm1 "In VII-B2 Micro-batch training ‣ VII-B Large- and Micro-batch Implementations ‣ VII Batch-Channel Normalization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows the feed-forwarding implementation of the micro-batch Batch-Channel Normalization.
The basic idea behind this algorithm is to constantly estimate the values of $\hat{\mu}\_{c}$ and $\hat{\sigma}\_{c}$, which are initialized as $0$ and $1$, respectively, and normalize $\bm{X}$ based on these estimates.
It is worth noting that in the algorithm, $\hat{\mu}\_{c}$ and $\hat{\sigma}\_{c}$ are not updated by the gradients computed from the loss function;
instead, they are updated towards more accurate estimates of those statistics.
Step 3 and 4 in Algorithm [1](#algorithm1 "In VII-B2 Micro-batch training ‣ VII-B Large- and Micro-batch Implementations ‣ VII Batch-Channel Normalization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") resemble the update steps in gradient descent; thus, the implementation can also be written in gradient descent by storing the difference $\Delta\hat{\mu}\_{c}$ and $\Delta\hat{\sigma}\_{c}$ as their gradients.
Moreover, we set the update rate $r$ to be the learning rate of trainable parameters.

Algorithm [1](#algorithm1 "In VII-B2 Micro-batch training ‣ VII-B Large- and Micro-batch Implementations ‣ VII Batch-Channel Normalization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") also raises an interesting question: when researchers study the micro-batch issue of BN before, why not just using the estimates to batch-normalize the features?
In fact, [[47](#bib.bib47)] tries a similar idea, but does not fully solve the micro-batch issue: it needs a bootstrap phase to make the estimates meaningful, and the performances are usually not satisfactory.
The underlying difference between micro-batch BCN and [[47](#bib.bib47)] is that BCN has a channel normalization following the estimate-based normalization.
This makes the previously unstable estimate-based normalization stable, and the reduction of Lipschitz constants which speeds up training is also done in the channel-based normalization part, which is also impossible to do in estimate-based normalization.
In summary, channel-based normalization makes estimate-based normalization possible, and estimate-based normalization helps channel-based normalization to keep models away from elimination singularities.

| Method | Top-1 | Method | Top-1 |
| --- | --- | --- | --- |
| LN [[7](#bib.bib7)] | 27.22 | LN+WS | 24.60 |
| IN [[26](#bib.bib26)] | 29.49 | IN+WS | 28.24 |
| GN [[6](#bib.bib6)] | 24.81 | GN+WS | 23.72 |
| BN [[3](#bib.bib3)] | 24.30 | BN+WS | 23.76 |

TABLE I: Top-1 error rates of ResNet-50 on ImageNet.
All models except BN are trained with batch size 1 per GPU.
BN models are trained with batch size 64 per GPU.

### VII-C Is Batch-Channel Normalization Redundant?

Batch- and channel-based normalizations are similar in many ways.
Is BCN thus redundant as it normalizes normalized features?
Our answer is no.
Channel normalizations need batch knowledge to keep the models away from elimination singularities; at the same time, it also brings benefits to the batch-based normalization, including:

Batch knowledge without large batches.
Since BCN runs in both large-batch and micro-batch settings, it provides a way to utilize batch knowledge to normalize activations without relying on large training batch sizes.

Additional non-linearity.
Batch Normalization is linear in the test mode or when the batch size is large in training.
By contrast, channel-based normalization methods, as they normalize each sample individually, are not linear.
They will add strong non-linearity and increase the model capacity.

Test-time normalization.
Unlike BN that relies on estimated statistics on the training dataset for testing, channel normalization normalizes testing data again, thus allows the statistics to adapt to different samples.
As a result, channel normalization will be more robust to statistical changes and show better generalizability for unseen data.

## VIII Experimental Results

| Method – Batch Size | BN [[3](#bib.bib3)] – 64 / 32 | | SN [[39](#bib.bib39)] – 1 | | GN [[6](#bib.bib6)] – 1 | | BN+WS – 64 / 32 | | GN+WS – 1 | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Top-1 | Top-5 | Top-1 | Top-5 | Top-1 | Top-5 | Top-1 | Top-5 | Top-1 | Top-5 |
| ResNet-50 [[2](#bib.bib2)] | 24.30 | 7.19 | 25.00 | – | 24.81 | 7.46 | 23.76 | 7.13 | 23.72 | 6.99 |
| ResNet-101 [[2](#bib.bib2)] | 22.44 | 6.21 | – | – | 22.87 | 6.51 | 21.89 | 6.01 | 22.10 | 6.07 |

TABLE II: Error rates of ResNet-50 and ResNet-101 on ImageNet.
ResNet-50 models with BN are trained with batch size 64 per GPU, and ResNet-101 models with BN are trained with 32 images per GPU.
The others are trained with 1 image per GPU.

In this section, we will present the experimental results of using our proposed Weight Standardization and Batch-Channel Normalization, including image classification on CIFAR-10/100 [[11](#bib.bib11)] and ImageNet [[9](#bib.bib9)], object detection and instance segmentation on COCO [[10](#bib.bib10)], video
recognition on Something-SomethingV1 dataset [[12](#bib.bib12)], and semantic segmentation on PASCAL VOC [[13](#bib.bib13)].

### VIII-A Image Classification on ImageNet

#### VIII-A1 Weight Standardization

ImageNet is a large-scale image classification dataset.
There are about 1.28 million training samples and 50K validation images.
It has 1000 categories, each has roughly 1300 training images and exactly 50 validation samples.

Table [I](#S7.T1 "TABLE I ‣ VII-B2 Micro-batch training ‣ VII-B Large- and Micro-batch Implementations ‣ VII Batch-Channel Normalization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows the top-1 error rates of ResNet-50 on ImageNet when it is trained with different normalization methods, including Layer Normalization [[7](#bib.bib7)], Instance Normalization [[26](#bib.bib26)], Group Normalization [[6](#bib.bib6)] and Batch Normalization.
From Table [I](#S7.T1 "TABLE I ‣ VII-B2 Micro-batch training ‣ VII-B Large- and Micro-batch Implementations ‣ VII Batch-Channel Normalization ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), we can see that when the batch size is limited to 1, GN+WS is able to achieve performances comparable to BN with large batch size.
Therefore, we will use GN+WS for micro-batch training because GN shows the best results among all the normalization methods that can be trained with 1 image per GPU.

Table [II](#S8.T2 "TABLE II ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows our major experimental results of WS on the ImageNet dataset [[9](#bib.bib9)].
Note that Table [II](#S8.T2 "TABLE II ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") only shows the error rates of ResNet-50 and ResNet-101.
This is to compare with the previous work that focus on micro-batch training problem, e.g. Switchable Normalization [[39](#bib.bib39)] and Group Normalization [[6](#bib.bib6)].
We run all the experiments using the official PyTorch implementations of the layers except for SN [[39](#bib.bib39)] which are the performances reported in their paper.
This makes sure that all the experimental results are comparable, and our improvements are reproducible.

| Backbone | WN | CWN | WS | Top-1 |
| --- | --- | --- | --- | --- |
| ResNet-50 + GN |  |  |  | 24.81 |
| ResNet-50 + GN | ✓ |  |  | 25.09 |
| ResNet-50 + GN |  | ✓ |  | 24.23 |
| ResNet-50 + GN |  |  | ✓ | 23.72 |

TABLE III: Comparing Top-1 error rates between WS, WN and CWN on ImageNet.
The backbone is a ResNet-50 normalized by GN and trained with batch size 1 per GPU.

Table [III](#S8.T3 "TABLE III ‣ VIII-A1 Weight Standardization ‣ VIII-A Image Classification on ImageNet ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") compares WS with other weight-based normalization methods including WN and CWN.
To show the comparisons, we train the same ResNet-50 normalized by GN on activations with different weight-based normalizations.
The code of WN uses the official PyTorch implementation, and the code of CWN is from the official implementation of their github.
From the results, we can observe that these normalization methods have different effects on the performances of the models.
Compared with WN and CWN, the proposed WS achieves lower top-1 error rate.

Table [IV](#S8.T4 "TABLE IV ‣ VIII-A1 Weight Standardization ‣ VIII-A Image Classification on ImageNet ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows the individual effects of Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") on training deep neural networks.
Consistent with Fig. [4](#S5.F4 "Fig. 4 ‣ V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") is the major component that brings performance improvements.
These results are also consistent with the theoretical results we have on the Lipschitz analysis.

| Backbone | - mean | / std | Top-1 |
| --- | --- | --- | --- |
| ResNet-50 + GN |  |  | 24.81 |
| ResNet-50 + GN | ✓ |  | 23.96 |
| ResNet-50 + GN |  | ✓ | 24.60 |
| ResNet-50 + GN | ✓ | ✓ | 23.72 |

TABLE IV: Comparing Top-1 error rates between WS (“- mean”: Eq. [11](#S5.E11 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), and “/ div”: Eq. [12](#S5.E12 "In V-A WS normalizes gradients ‣ V The smoothing effects of WS ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization")) and its individual effects.
The backbone is a ResNet-50-GN trained with batch size 1 per GPU.

| Method | GN [[6](#bib.bib6)] | | GN+WS [[6](#bib.bib6)] | |
| --- | --- | --- | --- | --- |
| Batch Size = 1 | Top-1 | Top-5 | Top-1 | Top-5 |
| ResNeXt-50 [[48](#bib.bib48)] | 24.24 | 7.27 | 22.71 | 6.38 |
| ResNeXt-101 [[48](#bib.bib48)] | 22.86 | 6.51 | 21.80 | 6.03 |

TABLE V: ResNeXt-50 and ResNeXt-101 on ImageNet. All models are trained with batch size 1 per GPU.

In Table [V](#S8.T5 "TABLE V ‣ VIII-A1 Weight Standardization ‣ VIII-A Image Classification on ImageNet ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), we also provide the experimental results on ResNeXt [[48](#bib.bib48)].
Here, we show the performance comparisons between ResNeXt+GN and ResNeXt+GN+WS.
Note that GN originally did not provide results on ResNeXt.
Without tuning the hyper-parameters in the Group Normalization layers, we use 32 groups for each of them which is the default configuration for ResNet that GN was originally proposed for.
ResNeXt-50 and 101 are 32x4d.
We train the models for 100 epochs with batch size set to 1 and iteration size set to 32.
As the table shows, the performance of GN on training ResNeXt is unsatisfactory: they perform closely to the original ResNets.
In the same setting, WS is able to make training ResNeXt a lot easier.

#### VIII-A2 Batch-Channel Normalization

Fig. [8](#S8.F8 "Fig. 8 ‣ VIII-A2 Batch-Channel Normalization ‣ VIII-A Image Classification on ImageNet ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows the training dynamics of ResNet-50 with GN, GN+WS and BCN+WS, and Table [VI](#S8.T6 "TABLE VI ‣ VIII-A2 Batch-Channel Normalization ‣ VIII-A Image Classification on ImageNet ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows the top-1 and top-5 error rates of ResNet-50 and ResNet-101 trained with different normalization methods.
From the results, we observe that adding batch information to channel-based normalizations strongly improves their accuracy.
As a result, GN, whose performances are similar to BN when used with WS, now is able to achieve better results than the BN baselines.
And we find improvements not only in the final model accuracy, but also in the training speed.
As shown in Fig. [8](#S8.F8 "Fig. 8 ‣ VIII-A2 Batch-Channel Normalization ‣ VIII-A Image Classification on ImageNet ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), we see a big drop of training error rates at each epoch.
This demonstrates that the model is now farther from elimination singularities, resulting in an easier and faster learning.

Fig. 8: Training and validation error rates of ResNet-50 on ImageNet. The comparison is between the baselines GN  [[6](#bib.bib6)], GN + WS, and Batch-Channel Normalization (BCN) with WS. Our method BCN and WS not only significantly improve the training speed, they also lower the error rates of the final models by a comfortable margin.

| Backbone | GN | WS | BCN | Top-1 | Top-5 |
| --- | --- | --- | --- | --- | --- |
| ResNet-50 | ✓ |  |  | 24.81 | 7.46 |
| ResNet-50 | ✓ | ✓ |  | 23.72 | 6.99 |
| ResNet-50 |  | ✓ | ✓ | 23.09 | 6.55 |
| ResNet-101 | ✓ |  |  | 22.87 | 6.51 |
| ResNet-101 | ✓ | ✓ |  | 22.10 | 6.07 |
| ResNet-101 |  | ✓ | ✓ | 21.29 | 5.60 |

TABLE VI: Top-1/5 error rates of ResNet-50, ResNet-101, and ResNeXt-50 on ImageNet. The test size is $224\times 224$ with center cropping. All normalizations are trained with batch size $32$ or $64$ per GPU without synchronization.

#### VIII-A3 Experiment settings

Here, we list the hyper-parameters used for getting all those results.
For all models, the learning rate is set to 0.1 initially, and is multiplied by $0.1$ after every 30 epochs.
We use SGD to train the models, where the weight decay is set to 0.0001 and the momentum is set to 0.9.
For ResNet-50 with BN or BN+WS, the training batch is set to 256 for 4 GPUs.
Without synchronized BN [[49](#bib.bib49)], the effective batch size is 64.
For other ResNet-50 where batch size is $1$ per GPU, we set the iteration size to $64$, i.e., the gradients are averaged across every 64 iterations and then one step is taken.
This is to ensure fair comparisons because by doing so the total numbers of parameter updates are the same even if their batch sizes are different.
We train ResNet-50 with different normalization techniques for 90 epochs.
For ResNet-101, we set the batch size to 128 because some of the models will use more than 12GB per GPU when setting their batch size to 256.
In total, we train all ResNet-101 models for 100 epochs.
Similarly, we set the iteration size for models trained with 1 image per GPU to be 32 in order to compensate for the total numbers of parameter updates.

### VIII-B Image Classification on CIFAR

CIFAR has two image datasets, CIFAR-10 (C10) and CIFAR-100 (C100).
Both C10 and C100 have color images of size $32\times 32$.
C10 dataset has 10 categories while C100 dataset has 100 categories.
Each of C10 and C100 has 50,000 images for training and 10,000 images for testing and the categories are balanced in terms of the number of samples.
In all the experiments shown here, the standard data augmentation schemes are used, i.e., mirroring and shifting, for these two datasets.
We also standardizes each channel of the datasets for data pre-processing.

Table [VII](#S8.T7 "TABLE VII ‣ VIII-B Image Classification on CIFAR ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows the experimental results that compare our proposed BCN with BN and GN.
The results are grouped into 4 parts based on whether the training is large-batch or micro-batch, and whether the dataset is C10 and C100.
On C10, our proposed BCN is better than BN on large-batch training, and is better than GN (with or without WS) which is specifically designed for micro-batch training.
Here, micro-batch training assumes the batch size is 1, and RN110 is the 110-layer ResNet [[2](#bib.bib2)] with basic block as the building block.
The number of groups here for GN is $\min\{32,(\text{the number of channels})/4\}$.

Table [VIII](#S8.T8 "TABLE VIII ‣ VIII-B Image Classification on CIFAR ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows comparisons with more recent normalization methods, Switchable Normalization (SN) [[39](#bib.bib39)] and Dynamic Normalization (DN) [[42](#bib.bib42)] which were tested for a variant of ResNet for CIFAR: ResNet-18.
To provide readers with direct comparisons, we also evaluate BCN on ResNet-18 with the group number set to $32$ for models that use GN.
Again, all the results are organized based on whether they are trained in the micro-batch setting.
Based on the results shown in Table [VII](#S8.T7 "TABLE VII ‣ VIII-B Image Classification on CIFAR ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") and [VIII](#S8.T8 "TABLE VIII ‣ VIII-B Image Classification on CIFAR ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), it is clear that BCN is able to outperform the baselines effortlessly in both large-batch and micro-batch training settings.

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  | Model | Micro | BN | GN | BCN | WS | Error |
| C10 | RN110 |  | ✓ |  |  |  | 6.43 |
| C10 | RN110 |  |  |  | ✓ | ✓ | 5.90 |
| C10 | RN110 | ✓ |  | ✓ |  |  | 7.45 |
| C10 | RN110 | ✓ |  | ✓ |  | ✓ | 6.82 |
| C10 | RN110 | ✓ |  |  | ✓ | ✓ | 6.31 |
| C100 | RN110 |  | ✓ |  |  |  | 28.86 |
| C100 | RN110 |  |  |  | ✓ | ✓ | 28.36 |
| C100 | RN110 | ✓ |  | ✓ |  |  | 32.86 |
| C100 | RN110 | ✓ |  | ✓ |  | ✓ | 29.49 |
| C100 | RN110 | ✓ |  |  | ✓ | ✓ | 28.28 |

TABLE VII: Error rates of a 110-layer ResNet [[2](#bib.bib2)] on CIFAR-10/100 [[11](#bib.bib11)] trained with BN [[3](#bib.bib3)], GN [[6](#bib.bib6)], and our BCN and WS.
The results are grouped based on dataset and large/micro-batch training.
Micro-batch assumes $1$ sample per batch while large-batch uses 128 samples in each batch.
WS indicates whether WS is used for weights.

| Dataset | Model | Micro | Method | Error |
| --- | --- | --- | --- | --- |
| C10 | RN18 |  | BN | 5.20 |
| C10 | RN18 |  | SN | 5.60 |
| C10 | RN18 |  | DN | 5.02 |
| C10 | RN18 |  | BCN+WS | 4.96 |
| C10 | RN18 | ✓ | BN | 8.45 |
| C10 | RN18 | ✓ | SN | 7.62 |
| C10 | RN18 | ✓ | DN | 7.55 |
| C10 | RN18 | ✓ | BCN+WS | 5.43 |

TABLE VIII: Error rates of ResNet-18 on CIFAR-10 trained with SN [[39](#bib.bib39)], DN [[42](#bib.bib42)], and our BCN and WS.
The results are grouped based on large/micro-batch training.
The performances of BN, SN and DN are from [[42](#bib.bib42)].
Micro-batch for BN, SN and DN uses 2 images per batch, while BCN uses 1.

### VIII-C Object Detection and Instance Segmentation

| Model | GN | WS | BCN | APb | AP${}^{b}\_{.5}$ | AP${}^{b}\_{.75}$ | AP${}^{b}\_{l}$ | AP${}^{b}\_{m}$ | AP${}^{b}\_{s}$ | APm | AP${}^{m}\_{.5}$ | AP${}^{m}\_{.75}$ | AP${}^{m}\_{l}$ | AP${}^{m}\_{m}$ | AP${}^{m}\_{s}$ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| RN50 | ✓ |  |  | 39.8 | 60.5 | 43.4 | 52.4 | 42.9 | 23.0 | 36.1 | 57.4 | 38.7 | 53.6 | 38.6 | 16.9 |
| RN50 | ✓ | ✓ |  | 40.8 | 61.6 | 44.8 | 52.7 | 44.0 | 23.5 | 36.5 | 58.5 | 38.9 | 53.5 | 39.3 | 16.6 |
| RN50 |  | ✓ | ✓ | 41.4 | 62.2 | 45.2 | 54.7 | 45.0 | 24.2 | 37.3 | 59.4 | 39.8 | 55.0 | 40.1 | 17.9 |
| RN101 | ✓ |  |  | 41.5 | 62.0 | 45.5 | 54.8 | 45.0 | 24.1 | 37.0 | 59.0 | 39.6 | 54.5 | 40.0 | 17.5 |
| RN101 | ✓ | ✓ |  | 42.7 | 63.6 | 46.8 | 56.0 | 46.0 | 25.7 | 37.9 | 60.4 | 40.7 | 56.3 | 40.6 | 18.2 |
| RN101 |  | ✓ | ✓ | 43.6 | 64.4 | 47.9 | 57.4 | 47.5 | 25.6 | 39.1 | 61.4 | 42.2 | 57.3 | 42.1 | 19.1 |

TABLE IX: Object detection and instance segmentation results on COCO val2017 [[10](#bib.bib10)] of Mask R-CNN [[50](#bib.bib50)] and FPN [[51](#bib.bib51)] with ResNet-50 and ResNet-101 [[2](#bib.bib2)] as backbone.
The models are trained with different normalization methods, which are used in their backbones, bounding box heads, and mask heads.

Unlike image classification on ImageNet where we could afford large batch training when the models are not too big, object detection and segmentation on COCO [[10](#bib.bib10)] usually use 1 or 2 images per GPU for training due to the high resolution.
Given the good performances of our method on ImageNet which are comparable to the large-batch BN training, we expect that our method is able to significantly improve the performances on COCO because of the training setting.

We use a PyTorch-based Mask R-CNN framework11
1
https://github.com/facebookresearch/maskrcnn-benchmark for all the experiments.
We take the models pre-trained on ImageNet, fine-tune them on COCO train2017 set, and test them on COCO val2017 set.
To maximize the comparison fairness, we use the models we pre-trained on ImageNet instead of downloading the pre-trained models available online.
We use 4 GPUs to train the models and apply the learning rate schedules for all models following the practice used in the Mask R-CNN framework our work is based on.
We use 1X learning rate schedule for Faster R-CNN and 2X learning rate schedule for Mask R-CNN.
For ResNet-50, we use 2 images per GPU to train the models, and for ResNet-101, we use 1 image per GPU because the models cannot fit in 12GB GPU memory.
We then adapt the learning rates and the training steps accordingly.
The configurations we run use FPN [[51](#bib.bib51)] and a 4conv1fc bounding box head.
All the training procedures strictly follow their original settings.

Table [IX](#S8.T9 "TABLE IX ‣ VIII-C Object Detection and Instance Segmentation ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") reports the Average Precision for bounding box (APb) and instance segmentation (APm) and Table [X](#S8.T10 "TABLE X ‣ VIII-C Object Detection and Instance Segmentation ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") reports the Average Precision (AP) of Faster R-CNN trained with different methods.
From the two tables, we can observe results similar to those on ImageNet.
GN has limited performance improvements when it is used on more complicated architectures such as ResNet-101 and ResNet-101.
But when we add WS to GN or use BCN, we are able to train the models much better.
The improvements become more significant when the network complexity increases.
Considering nowadays deep networks are becoming deeper and wider, having a normalization technique such as our WS will ease the training a lot without worrying about the memory and batch size issues.

| Model | GN | WS | BCN | APb | AP${}^{b}\_{.5}$ | AP${}^{b}\_{.75}$ | AP${}^{b}\_{l}$ | AP${}^{b}\_{m}$ | AP${}^{b}\_{s}$ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| RN50 | ✓ |  |  | 38.0 | 59.1 | 41.2 | 49.5 | 40.9 | 22.4 |
| RN50 | ✓ | ✓ |  | 38.9 | 60.4 | 42.1 | 50.4 | 42.4 | 23.5 |
| RN50 |  | ✓ | ✓ | 39.7 | 60.9 | 43.1 | 51.7 | 43.2 | 24.0 |
| RN101 | ✓ |  |  | 39.7 | 60.9 | 43.3 | 51.9 | 43.3 | 23.1 |
| RN101 | ✓ | ✓ |  | 41.3 | 62.8 | 45.1 | 53.9 | 45.2 | 24.7 |
| RN101 |  | ✓ | ✓ | 41.8 | 63.4 | 45.8 | 54.1 | 45.6 | 25.6 |

TABLE X: Object detection results on COCO using Faster R-CNN [[52](#bib.bib52)] and
FPN with different normalization methods.

### VIII-D Semantic Segmentation on PASCAL VOC

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| Dataset | Model | GN | BN | WS | BCN | mIoU |
| VOC Val | RN101 | ✓ |  |  |  | 74.90 |
| VOC Val | RN101 | ✓ |  | ✓ |  | 77.20 |
| VOC Val | RN101 |  | ✓ |  |  | 76.49 |
| VOC Val | RN101 |  | ✓ | ✓ |  | 77.15 |
| VOC Val | RN101 |  |  | ✓ | ✓ | 78.22 |

TABLE XI: Comparisons of semantic segmentation performance of DeepLabV3 [[53](#bib.bib53)] trained with different normalizations on PASCAL VOC 2012 [[13](#bib.bib13)] validation set. Output stride is 16, without multi-scale or flipping when testing.

After evaluating BCN and WS on classification and detection, we test it on dense prediction tasks.
We start with semantic segmentation on PASCAL VOC [[13](#bib.bib13)].
We choose DeepLabV3 [[53](#bib.bib53)] as the evaluation model for its good performances and its use of the pre-trained ResNet-101 backbone.

Table [XI](#S8.T11 "TABLE XI ‣ VIII-D Semantic Segmentation on PASCAL VOC ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows our results on PASCAL VOC, which has $21$ different categories with background included.
We take the common practice to prepare the dataset, and the training set is augmented by
the annotations provided in [[54](#bib.bib54)], thus has 10,582 images.
We take our ResNet-101 pre-trained on ImageNet and finetune it for the task.
Here, we list all the implementation details for easy reproductions of our results:
the batch size is set to $16$, the image crop size is $513$, the learning rate follows polynomial decay with an initial rate $0.007$.
The model is trained for $30K$ iterations, and the multi-grid is $(1,1,1)$ instead of $(1,2,4)$.
For testing, the output stride is set to $16$, and we do not use multi-scale or horizontal flipping test augmentation.
As shown in Table [XI](#S8.T11 "TABLE XI ‣ VIII-D Semantic Segmentation on PASCAL VOC ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization"), by only changing the normalization methods from BN and GN to our BCN, mIoU increases by about $2\%$, which is a significant improvement for PASCAL VOC dataset.
As we strictly follow the hyper-parameters used in the previous work, there could be even more room of improvements if we tune them to favor BCN or WS, which we do not explore in this paper and leave to future work.

### VIII-E Video Recognition on Something-Something

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Model | #Frame | GN | BN | WS | BCN | Top-1 | Top-5 |
| RN50 | 8 | ✓ |  |  |  | 42.07 | 73.20 |
| RN50 | 8 | ✓ |  | ✓ |  | 44.26 | 75.51 |
| RN50 | 8 |  | ✓ |  |  | 44.30 | 74.53 |
| RN50 | 8 |  | ✓ | ✓ |  | 46.49 | 76.46 |
| RN50 | 8 |  |  | ✓ | ✓ | 45.27 | 75.22 |

TABLE XII: Comparing video recognition accuracy of TSM [[55](#bib.bib55)] on Something-SomethingV1 [[12](#bib.bib12)].

In this subsection, we show the results of applying our method on video recognition on Something-SomethingV1 dataset [[12](#bib.bib12)].
Something-SomethingV1 is a video dataset which includes a large number of video clips that show humans performing pre-defined basic actions.
The dataset has 86,017 clips for training and 11,522 clips for validation.

We use the state-of-the-art method TSM [[55](#bib.bib55)] for video recognition, which uses a ResNet-50 with BN as its backbone network.
The codes are based on TRN [[56](#bib.bib56)] and then adapted to TSM.
The reimplementation is different from the original TSM [[55](#bib.bib55)]:
we use models pre-trained on ImageNet rather than Kinetics dataset [[57](#bib.bib57)] as the starting points.
Then, we fine-tune the pre-trained models on Something-SomethingV1 for 45 epochs.
The batch size is set to 32 for 4 GPUs, and the learning rate is initially set to 0.0125, then divided by 10 at the 26th and the 36th epochs.
The batch normalization layers are not fixed during training.
With all the changes, the reimplemented TSM-BN achieves top-1/5 accuracy 44.30/74.53, higher than 43.4/73.2 originally reported in the paper.

Then, we compare the performances when different normalization methods are used in training TSM.
Table [XII](#S8.T12 "TABLE XII ‣ VIII-E Video Recognition on Something-Something ‣ VIII Experimental Results ‣ Micro-Batch Training with Batch-Channel Normalization and Weight Standardization") shows the top-1/5 accuracies of TSM when trained with GN, GN+WS, BN and BN+WS.
From the table we can see that WS increases the top-1 accuracy about $2\%$ for both GN and BN.
The improvements help GN to cache up the performances of BN, and boost BN to even better accuracies, which roughly match the performances of the ensemble TSM with 24 frames reported in the paper.
Despite that BCN improves performances of GN, it does not surpass BN.
This shows the limitation of BCN.

## IX Conclusion

In this paper, we proposed two novel normalization methods, Weight Standardization (WS) and Batch-Channel Normalization (BCN) to bring the success factors of Batch Normalization (BN) into micro-batch training, including 1) the smoothing effects on the loss landscape and 2) the ability to avoid harmful elimination singularities along the training trajectory.
WS standardizes the weights in convolutional layers and BCN leverages estimated batch statistics of the activations in convolutional layers.
We provided theoretical analysis to show that WS reduces the Lipschitz constants of the loss and the gradients, and thus it smooths the loss landscape.
By investigating normalization methods from the perspective of elimination singularities, we found that channel-based normalization methods, such as Layer Normalization (LN) and Group Normalization (GN) are unable to keep far distances from elimination singularities, caused by lack of batch knowledge.
We showed that WS is able to alleviate this issue and BCN can further push models away from elimination singularities by incorporating estimated batch statistics channel-normalized models.
Experiments on comprehensive computer vision tasks, including image classification, object detection, instance segmentation, video recognition and semantic segmentation, demonstrate 1) WS and BCN improve micro-batch training significantly, 2) WS+GN with batch size 1 is even able to match or outperform the performances of BN with large batch sizes, and 3) replacing GN by BCN leads to further improvement.

|  |  |
| --- | --- |
|  | Siyuan Qiao received B.E. in Computer Science at Shanghai Jiao Tong University in 2016. He is currently a Ph.D. student at Johns Hopkins University, where he is advised by Bloomberg Distinguished Professor Alan Yuille. From June 2017 to August 2017, he worked at Baidu IDL as an intern. He interned at Adobe Inc. from June 2018 to August 2018. He has also spent time at University of California, Los Angeles, and YITU Technology. His research interests are computer vision and deep learning. |

|  |  |
| --- | --- |
|  | Huiyu Wang is a Ph.D. student in Computer Science at Johns Hopkins University, advised by Bloomberg Distinguished Professor Alan Yuille. He received M.S. in Electrical Engineering at University of California, Los Angeles in 2017 and B.S. in Information Engineering at Shanghai Jiao Tong University in 2015. He also spent wonderful summers at Google, Allen Institute for Artificial Intelligence(AI2), and TuSimple. His research interests are computer vision and machine learning. |

|  |  |
| --- | --- |
|  | Chenxi Liu is a Ph.D. student at Johns Hopkins University, where his advisor is Bloomberg Distinguished Professor Alan Yuille. Before that, he received M.S. at University of California, Los Angeles and B.E. at Tsinghua University. He has also spent time at Facebook, Google, Adobe, Toyota Technological Institute at Chicago, University of Toronto, and Rice University. His research lies in computer vision and natural language processing. |

|  |  |
| --- | --- |
|  | Wei Shen received his B.S. and Ph.D. degree both in Electronics and Information Engineering from the Huazhong University of Science and Technology, Wuhan, China, in 2007 and in 2012. From April 2011 to November 2011, he worked in Microsoft Research Asia as an intern. In 2012, he joined the School of Communication and Information Engineering, Shanghai University and served as an assistant and associate professor until Oct 2018. He is currently an Assistant Research Professor at the Department of Computer Science, Johns Hopkins University. His current research interests include computer vision, deep learning and biomedical image analysis. |

|  |  |
| --- | --- |
|  | Alan Yuille received his B.A. in mathematics from the University of Cambridge in 1976, and completed his Ph.D. in theoretical physics at Cambridge in 1980. He then held a postdoctoral position with the Physics Department, University of Texas at Austin, and the Institute for Theoretical Physics, Santa Barbara. He then became a research scientists at the Artificial Intelligence Laboratory at MIT (1982-1986) and followed this with a faculty position in the Division of Applied Sciences at Harvard (1986-1995), rising to the position of associate professor. From 1995-2002 he worked as a senior scientist at the Smith-Kettlewell Eye Research Institute in San Francisco. From 2002-2016 he was a full professor in the Department of Statistics at UCLA with joint appointments in Psychology, Computer Science, and Psychiatry. In 2016 he became a Bloomberg Distinguished Professor in Cognitive Science and Computer Science at Johns Hopkins University. He has won a Marr prize, a Helmholtz prize, and is a Fellow of IEEE. |
