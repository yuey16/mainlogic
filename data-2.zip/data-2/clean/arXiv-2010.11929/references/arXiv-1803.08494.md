<!-- fulltext source=arxiv_html slug=arXiv-1803.08494 fetched=2026-09-18T01:33:41+00:00 -->

# Group Normalization

Yuxin Wu
Affiliation: Facebook AI Research (FAIR)
  
Kaiming He
Affiliation: {yuxinwu,kaiminghe}@fb.com

###### Abstract

Batch Normalization (BN) is a milestone technique in the development of deep learning, enabling various networks to train. However, normalizing along the batch dimension introduces problems --- BN’s error increases rapidly when the batch size becomes smaller, caused by inaccurate batch statistics estimation. This limits BN’s usage for training larger models and transferring features to computer vision tasks including detection, segmentation, and video, which require small batches constrained by memory consumption. In this paper, we present Group Normalization (GN) as a simple alternative to BN. GN divides the channels into groups and computes within each group the mean and variance for normalization. GN’s computation is independent of batch sizes, and its accuracy is stable in a wide range of batch sizes. On ResNet-50 trained in ImageNet, GN has 10.6% lower error than its BN counterpart when using a batch size of 2; when using typical batch sizes, GN is comparably good with BN and outperforms other normalization variants. Moreover, GN can be naturally transferred from pre-training to fine-tuning. GN can outperform its BN-based counterparts for object detection and segmentation in COCO,11
1
<https://github.com/facebookresearch/Detectron/blob/master/projects/GN>. and for video classification in Kinetics, showing that GN can effectively replace the powerful BN in a variety of tasks. GN can be easily implemented by a few lines of code in modern libraries.

## 1 Introduction

Batch Normalization (Batch Norm or BN) [[26](#bib.bib26)] has been established as a very effective component in deep learning, largely helping push the frontier in computer vision [[59](#bib.bib59), [20](#bib.bib20)] and beyond [[54](#bib.bib54)]. BN normalizes the features by the mean and variance computed within a (mini-)batch. This has been shown by many practices to ease optimization and enable very deep networks to converge. The stochastic uncertainty of the batch statistics also acts as a regularizer that can benefit generalization. BN has been a foundation of many state-of-the-art computer vision algorithms.

Figure 1: ImageNet classification error *vs*. batch sizes. This is a ResNet-50 model trained in the ImageNet training set using 8 workers (GPUs), evaluated in the validation set.

Despite its great success, BN exhibits drawbacks that are also caused by its distinct behavior of normalizing along the batch dimension.
In particular, it is required for BN to work with a *sufficiently large batch size* (*e.g*., 32 per worker22
2
In the context of this paper, we use “batch size” to refer to the number of samples *per worker* (*e.g*., GPU). BN’s statistics are computed for each worker, but *not* broadcast across workers, as is standard in many libraries. [[26](#bib.bib26), [59](#bib.bib59), [20](#bib.bib20)]). A small batch leads to inaccurate estimation of the batch statistics, and *reducing BN’s batch size increases the model error dramatically* (Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Group Normalization")). As a result, many recent models [[59](#bib.bib59), [20](#bib.bib20), [57](#bib.bib57), [24](#bib.bib24), [63](#bib.bib63)] are trained with non-trivial batch sizes that are memory-consuming. The heavy reliance on BN’s effectiveness to train models in turn prohibits people from exploring higher-capacity models that would be limited by memory.

The restriction on batch sizes is more demanding in computer vision tasks including detection [[12](#bib.bib12), [47](#bib.bib47), [18](#bib.bib18)], segmentation [[38](#bib.bib38), [18](#bib.bib18)], video recognition [[60](#bib.bib60), [6](#bib.bib6)], and other high-level systems built on them. For example, the Fast/er and Mask R-CNN frameworks [[12](#bib.bib12), [47](#bib.bib47), [18](#bib.bib18)] use a batch size of 1 or 2 images because of higher resolution, where BN is “frozen” by transforming to a linear layer [[20](#bib.bib20)]; in video classification with 3D convolutions [[60](#bib.bib60), [6](#bib.bib6)], the presence of spatial-temporal features introduces a trade-off between the temporal length and batch size. The usage of BN often requires these systems to compromise between the model design and batch sizes.

This paper presents Group Normalization (GN) as a simple alternative to BN. We notice that many classical features like SIFT [[39](#bib.bib39)] and HOG [[9](#bib.bib9)] are *group-wise* features and involve *group-wise normalization*. For example, a HOG vector is the outcome of several spatial cells where each cell is represented by a normalized orientation histogram.
Analogously, we propose GN as a layer that divides channels into groups and normalizes the features within each group (Figure [2](#S2.F2 "Figure 2 ‣ Addressing small batches. ‣ 2 Related Work ‣ Group Normalization")).
GN does not exploit the batch dimension, and its computation is independent of batch sizes.

GN behaves very stably over a wide range of batch sizes (Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Group Normalization")).
With a batch size of 2 samples, GN has 10.6% lower error than its BN counterpart for ResNet-50 [[20](#bib.bib20)] in ImageNet [[50](#bib.bib50)]. With a regular batch size, GN is comparably good as BN (with a gap of $\scriptstyle\sim$0.5%) and outperforms other normalization variants [[3](#bib.bib3), [61](#bib.bib61), [51](#bib.bib51)]. Moreover, although the batch size may change, GN can naturally transfer from pre-training to fine-tuning.
GN shows improved results *vs*. its BN counterpart on Mask R-CNN for COCO object detection and segmentation [[37](#bib.bib37)], and on 3D convolutional networks for Kinetics video classification [[30](#bib.bib30)]. The effectiveness of GN in ImageNet, COCO, and Kinetics demonstrates that GN is a competitive alternative to BN that has been dominant in these tasks.

There have been existing methods, such as Layer Normalization (LN) [[3](#bib.bib3)] and Instance Normalization (IN) [[61](#bib.bib61)] (Figure [2](#S2.F2 "Figure 2 ‣ Addressing small batches. ‣ 2 Related Work ‣ Group Normalization")), that also avoid normalizing along the batch dimension.
These methods are effective for training sequential models (RNN/LSTM [[49](#bib.bib49), [22](#bib.bib22)]) or generative models (GANs [[15](#bib.bib15), [27](#bib.bib27)]).
But as we will show by experiments, both LN and IN have limited success in visual recognition, for which GN presents better results.
Conversely, GN could be used in place of LN and IN and thus is applicable for sequential or generative models. This is beyond the focus of this paper, but it is suggestive for future research.

## 2 Related Work

#### Normalization.

It is well-known that normalizing the input data makes training faster [[33](#bib.bib33)]. To normalize hidden features, initialization methods [[33](#bib.bib33), [14](#bib.bib14), [19](#bib.bib19)] have been derived based on strong assumptions of feature distributions, which can become invalid when training evolves.

Normalization layers in deep networks had been widely used before the development of BN. Local Response Normalization (LRN) [[40](#bib.bib40), [28](#bib.bib28), [32](#bib.bib32)] was a component in AlexNet [[32](#bib.bib32)] and following models [[64](#bib.bib64), [53](#bib.bib53), [58](#bib.bib58)]. Unlike recent methods [[26](#bib.bib26), [3](#bib.bib3), [61](#bib.bib61)], LRN computes the statistics in a small neighborhood for each pixel.

Batch Normalization [[26](#bib.bib26)] performs more global normalization along the batch dimension (and as importantly, it suggests to do this for all layers).
But the concept of “batch” is not always present, or it may change from time to time. For example, batch-wise normalization is not legitimate at inference time, so the mean and variance are pre-computed from the training set [[26](#bib.bib26)], often by running average;
consequently, there is no normalization performed when testing. The pre-computed statistics may also change when the target data distribution changes [[45](#bib.bib45)]. These issues lead to inconsistency at training, transferring, and testing time. In addition, as aforementioned, reducing the batch size can have dramatic impact on the estimated batch statistics.

Several normalization methods [[3](#bib.bib3), [61](#bib.bib61), [51](#bib.bib51), [2](#bib.bib2), [46](#bib.bib46)] have been proposed to avoid exploiting the batch dimension. Layer Normalization (LN) [[3](#bib.bib3)] operates along the channel dimension, and Instance Normalization (IN) [[61](#bib.bib61)] performs BN-like computation but only for each sample (Figure [2](#S2.F2 "Figure 2 ‣ Addressing small batches. ‣ 2 Related Work ‣ Group Normalization")).
Instead of operating on features, Weight Normalization (WN) [[51](#bib.bib51)] proposes to normalize the filter weights. These methods do not suffer from the issues caused by the batch dimension, but they have not been able to approach BN’s accuracy in many visual recognition tasks.
We provide comparisons with these methods in context of the remaining sections.

#### Addressing small batches.

Ioffe [[25](#bib.bib25)] proposes Batch Renormalization (BR) that alleviates BN’s issue involving small batches. BR introduces two extra parameters that constrain the estimated mean and variance of BN within a certain range, reducing their drift when the batch size is small.
BR has better accuracy than BN in the small-batch regime. But BR is also batch-dependent, and when the batch size decreases its accuracy still degrades [[25](#bib.bib25)].

There are also attempts to *avoid* using small batches. The object detector in [[43](#bib.bib43)] performs synchronized BN whose mean and variance are computed across multiple GPUs.
However, this method does not solve the problem of small batches; instead, it migrates the algorithm problem to engineering and hardware demands, using a number of GPUs proportional to BN’s requirements.
Moreover, the synchronized BN computation prevents using *asynchronous* solvers (ASGD [[10](#bib.bib10)]), a practical solution to large-scale training widely used in industry. These issues can limit the scope of using synchronized BN.

Instead of addressing the batch statistics computation (*e.g*., [[25](#bib.bib25), [43](#bib.bib43)]), our normalization method inherently avoids this computation.

Figure 2: Normalization methods. Each subplot shows a feature map tensor, with $N$ as the batch axis, $C$ as the channel axis, and $(H,W)$ as the spatial axes.
The pixels in blue are normalized by the same mean and variance, computed by aggregating the values of these pixels.

#### Group-wise computation.

*Group convolutions* have been presented by AlexNet [[32](#bib.bib32)] for distributing a model into two GPUs. The concept of *groups* as a dimension for model design has been more widely studied recently. The work of ResNeXt [[63](#bib.bib63)] investigates the trade-off between depth, width, and groups, and it suggests that a larger number of groups can improve accuracy under similar computational cost. MobileNet [[23](#bib.bib23)] and Xception [[7](#bib.bib7)] exploit *channel-wise* (also called “depth-wise”) convolutions, which are group convolutions with a group number equal to the channel number. ShuffleNet [[65](#bib.bib65)] proposes a channel shuffle operation that permutes the axes of grouped features. These methods all involve dividing the channel dimension into groups.
Despite the relation to these methods, GN does *not* require group convolutions. GN is a generic layer, as we evaluate in standard ResNets [[20](#bib.bib20)].

## 3 Group Normalization

The channels of visual representations are not entirely independent.
Classical features of SIFT [[39](#bib.bib39)], HOG [[9](#bib.bib9)], and GIST [[41](#bib.bib41)] are *group-wise* representations by design, where each group of channels is constructed by some kind of histogram.
These features are often processed by *group-wise normalization* over each histogram or each orientation. Higher-level features such as VLAD [[29](#bib.bib29)] and Fisher Vectors (FV) [[44](#bib.bib44)] are also group-wise features where a group can be thought of as the sub-vector computed with respect to a cluster.

Analogously, it is not necessary to think of deep neural network features as unstructured vectors. For example, for conv1 (the first convolutional layer) of a network, it is reasonable to expect a filter and its horizontal flipping to exhibit similar distributions of filter responses on natural images. If conv1 happens to approximately learn this pair of filters, or if the horizontal flipping (or other transformations) is made into the architectures by design [[11](#bib.bib11), [8](#bib.bib8)], then the corresponding channels of these filters can be normalized together.

The higher-level layers are more abstract and their behaviors are not as intuitive. However, in addition to orientations (SIFT [[39](#bib.bib39)], HOG [[9](#bib.bib9)], or [[11](#bib.bib11), [8](#bib.bib8)]), there are many factors that could lead to grouping, *e.g*., frequency, shapes, illumination, textures. Their coefficients can be interdependent.
In fact, a well-accepted computational model in neuroscience is to normalize across the cell responses [[21](#bib.bib21), [52](#bib.bib52), [55](#bib.bib55), [5](#bib.bib5)], “with various receptive-field centers (covering the visual field) and with various spatiotemporal frequency tunings” (p183, [[21](#bib.bib21)]); this can happen not only in the primary visual cortex, but also “throughout the visual system” [[5](#bib.bib5)].
Motivated by these works, we propose new generic group-wise normalization for deep neural networks.

### 3.1 Formulation

We first describe a general formulation of feature normalization, and then present GN in this formulation.
A family of feature normalization methods, including BN, LN, IN, and GN,
perform the following computation:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{x}\_{i}=\frac{1}{\sigma\_{i}}(x\_{i}-\mu\_{i}).$ |  | (1) |

Here $x$ is the feature computed by a layer, and $i$ is an index. In the case of 2D images, $i=(i\_{N},i\_{C},i\_{H},i\_{W})$ is a 4D vector indexing the features in $(N,C,H,W)$ order, where $N$ is the batch axis, $C$ is the channel axis, and $H$ and $W$ are the spatial height and width axes.

$\mu$ and $\sigma$ in ([1](#S3.E1 "In 3.1 Formulation ‣ 3 Group Normalization ‣ Group Normalization")) are the mean and standard deviation (std) computed by:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mu\_{i}=\frac{1}{m}\sum\_{k\in\mathcal{S}\_{i}}x\_{k},\quad\sigma\_{i}=\sqrt{\frac{1}{m}\sum\_{k\in\mathcal{S}\_{i}}(x\_{k}-\mu\_{i})^{2}+\epsilon},$ |  | (2) |

with $\epsilon$ as a small constant. $\mathcal{S}\_{i}$ is the set of pixels in which the mean and std are computed, and $m$ is the size of this set. Many types of feature normalization methods mainly differ in how the set $\mathcal{S}\_{i}$ is defined (Figure [2](#S2.F2 "Figure 2 ‣ Addressing small batches. ‣ 2 Related Work ‣ Group Normalization")), discussed as follows.

In Batch Norm [[26](#bib.bib26)], the set $\mathcal{S}\_{i}$ is defined as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{S}\_{i}=\{k\penalty\ |\penalty\ k\_{C}=i\_{C}\},$ |  | (3) |

where $i\_{C}$ (and $k\_{C}$) denotes the sub-index of $i$ (and $k$) along the $C$ axis. This means that the pixels sharing the same channel index are normalized together, *i.e*., for each channel, BN computes $\mu$ and $\sigma$ along the $(N,H,W)$ axes.
In Layer Norm [[3](#bib.bib3)], the set is:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{S}\_{i}=\{k\penalty\ |\penalty\ k\_{N}=i\_{N}\},$ |  | (4) |

meaning that LN computes $\mu$ and $\sigma$ along the $(C,H,W)$ axes for each sample.
In Instance Norm [[61](#bib.bib61)], the set is:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{S}\_{i}=\{k\penalty\ |\penalty\ k\_{N}=i\_{N},k\_{C}=i\_{C}\}.$ |  | (5) |

meaning that IN computes $\mu$ and $\sigma$ along the $(H,W)$ axes for each sample and each channel.
The relations among BN, LN, and IN are in Figure [2](#S2.F2 "Figure 2 ‣ Addressing small batches. ‣ 2 Related Work ‣ Group Normalization").

As in [[26](#bib.bib26)], all methods of BN, LN, and IN learn a per-channel linear transform to compensate for the possible lost of representational ability:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $y\_{i}=\gamma\hat{x}\_{i}+\beta,$ |  | (6) |

where $\gamma$ and $\beta$ are trainable scale and shift (indexed by $i\_{C}$ in all case, which we omit for simplifying notations).

#### Group Norm.

Formally, a Group Norm layer computes $\mu$ and $\sigma$ in a set $\mathcal{S}\_{i}$ defined as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{S}\_{i}=\{k\penalty\ |\penalty\ k\_{N}=i\_{N},\lfloor\frac{k\_{C}}{C/G}\rfloor=\lfloor\frac{i\_{C}}{C/G}\rfloor\}.$ |  | (7) |

Here $G$ is the number of groups, which is a pre-defined hyper-parameter ($G=32$ by default). $C/G$ is the number of channels per group.
$\lfloor\cdot\rfloor$ is the floor operation, and “$\lfloor\frac{k\_{C}}{C/G}\rfloor=\lfloor\frac{i\_{C}}{C/G}\rfloor$” means that the indexes $i$ and $k$ are in the same group of channels, assuming each group of channels are stored in a sequential order along the $C$ axis.
GN computes $\mu$ and $\sigma$ along the $(H,W)$ axes and along a group of $\frac{C}{G}$ channels.
The computation of GN is illustrated in Figure [2](#S2.F2 "Figure 2 ‣ Addressing small batches. ‣ 2 Related Work ‣ Group Normalization") (rightmost), which is a simple case of 2 groups ($G=2$) each having 3 channels.

Given $\mathcal{S}\_{i}$ in Eqn.([7](#S3.E7 "In Group Norm. ‣ 3.1 Formulation ‣ 3 Group Normalization ‣ Group Normalization")), a GN layer is defined by Eqn.([1](#S3.E1 "In 3.1 Formulation ‣ 3 Group Normalization ‣ Group Normalization")), ([2](#S3.E2 "In 3.1 Formulation ‣ 3 Group Normalization ‣ Group Normalization")), and ([6](#S3.E6 "In 3.1 Formulation ‣ 3 Group Normalization ‣ Group Normalization")). Specifically, the pixels in the same group are normalized together by the same $\mu$ and $\sigma$. GN also learns the per-channel $\gamma$ and $\beta$.

#### Relation to Prior Work.

LN, IN, and GN all perform independent computations along the batch axis.
The two extreme cases of GN are equivalent to LN and IN (Figure [2](#S2.F2 "Figure 2 ‣ Addressing small batches. ‣ 2 Related Work ‣ Group Normalization")).

*Relation to Layer Normalization* [[3](#bib.bib3)]. GN becomes LN if we set the group number as $G=1$. LN assumes *all* channels in a layer make “similar contributions” [[3](#bib.bib3)]. Unlike the case of fully-connected layers studied in [[3](#bib.bib3)], this assumption can be less valid with the presence of convolutions, as discussed in [[3](#bib.bib3)]. GN is less restricted than LN, because each group of channels (instead of all of them) are assumed to subject to the shared mean and variance; the model still has flexibility of learning a different distribution for each group. This leads to improved representational power of GN over LN, as shown by the lower training and validation error in experiments (Figure [4](#S3.F4 "Figure 4 ‣ 3.2 Implementation ‣ 3 Group Normalization ‣ Group Normalization")).

*Relation to Instance Normalization* [[61](#bib.bib61)]. GN becomes IN if we set the group number as $G=C$ (*i.e*., one channel per group). But IN can only rely on the spatial dimension for computing the mean and variance and it misses the opportunity of exploiting the channel dependence.

```
def GroupNorm(x, gamma, beta, G, eps=1e-5):
    # x: input features with shape [N,C,H,W]
    # gamma, beta: scale and offset, with shape [1,C,1,1]
    # G: number of groups for GN

    N, C, H, W = x.shape
    x = tf.reshape(x, [N, G, C // G, H, W])

    mean, var = tf.nn.moments(x, [2, 3, 4], keep_dims=True)
    x = (x - mean) / tf.sqrt(var + eps)

    x = tf.reshape(x, [N, C, H, W])

    return x * gamma + beta
```

Figure 3: Python code of Group Norm based on TensorFlow.

### 3.2 Implementation

GN can be easily implemented by a few lines of code in PyTorch [[42](#bib.bib42)] and TensorFlow [[1](#bib.bib1)] where automatic differentiation is supported. Figure [3](#S3.F3 "Figure 3 ‣ Relation to Prior Work. ‣ 3.1 Formulation ‣ 3 Group Normalization ‣ Group Normalization") shows the code based on TensorFlow. In fact, we only need to specify how the mean and variance (“moments”) are computed, along the appropriate axes as defined by the normalization method.

Figure 4: Comparison of error curves with a batch size of 32 images/GPU. We show the ImageNet training error (left) and validation error (right) *vs*. numbers of training epochs. The model is ResNet-50.

Figure 5: Sensitivity to batch sizes: ResNet-50’s validation error of BN (left) and GN (right) trained with 32, 16, 8, 4, and 2 images/GPU.

## 4 Experiments

### 4.1 Image Classification in ImageNet

We experiment in the ImageNet classification dataset [[50](#bib.bib50)] with 1000 classes. We train on the $\scriptstyle\sim$1.28M training images and evaluate on the 50,000 validation images, using the ResNet models [[20](#bib.bib20)].

#### Implementation details.

As standard practice [[20](#bib.bib20), [17](#bib.bib17)], we use 8 GPUs to train all models, and the batch mean and variance of BN are computed *within* each GPU. We use the method of [[19](#bib.bib19)] to initialize all convolutions for all models. We use 1 to initialize all $\gamma$ parameters, except for each residual block’s last normalization layer where we initialize $\gamma$ by 0 following [[16](#bib.bib16)] (such that the initial state of a residual block is identity). We use a weight decay of 0.0001 for all weight layers, including $\gamma$ and $\beta$ (following [[17](#bib.bib17)] but unlike [[20](#bib.bib20), [16](#bib.bib16)]).
We train 100 epochs for all models, and decrease the learning rate by 10$\times$ at 30, 60, and 90 epochs. During training, we adopt the data augmentation of [[58](#bib.bib58)] as implemented by [[17](#bib.bib17)].
We evaluate the top-1 classification error on the center crops of 224$\times$224 pixels in the validation set. To reduce random variations, we report the median error rate of the final 5 epochs [[16](#bib.bib16)]. Other implementation details follow [[17](#bib.bib17)].

Our baseline is the ResNet trained with BN [[20](#bib.bib20)]. To compare with LN, IN, and GN, we replace BN with the specific variant. We use the same hyper-parameters for all models. We set $G=32$ for GN by default.

#### Comparison of feature normalization methods.

We first experiment with a regular batch size of 32 images (per GPU) [[26](#bib.bib26), [20](#bib.bib20)]. BN works successfully in this regime, so this is a strong baseline to compare with.
Figure [4](#S3.F4 "Figure 4 ‣ 3.2 Implementation ‣ 3 Group Normalization ‣ Group Normalization") shows the error curves, and Table [1](#S4.T1 "Table 1 ‣ Comparison of feature normalization methods. ‣ 4.1 Image Classification in ImageNet ‣ 4 Experiments ‣ Group Normalization") shows the final results.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | BN | LN | IN | GN |
| val error | 23.6 | 25.3 | 28.4 | 24.1 |
| $\triangle$ (*vs*. BN) | - | *1.7* | *4.8* | *0.5* |

Table 1: Comparison of error rates (%) of ResNet-50 in the ImageNet validation set, trained
with a batch size of 32 images/GPU. The error curves are in Figure [4](#S3.F4 "Figure 4 ‣ 3.2 Implementation ‣ 3 Group Normalization ‣ Group Normalization").

Figure [4](#S3.F4 "Figure 4 ‣ 3.2 Implementation ‣ 3 Group Normalization ‣ Group Normalization") shows that *all* of these normalization methods are able to converge. LN has a small degradation of 1.7% comparing with BN. This is an encouraging result, as it suggests that normalizing along *all* channels (as done by LN) of a *convolutional* network is reasonably good. IN also makes the model converge, but is 4.8% worse than BN.33
3
For completeness, we have also trained ResNet-50 with WN [[51](#bib.bib51)], which is *filter* (instead of *feature*) normalization. WN’s result is 28.2%.

In this regime where BN works well, GN is able to approach BN’s accuracy, with a decent degradation of 0.5% in the validation set. Actually, Figure [4](#S3.F4 "Figure 4 ‣ 3.2 Implementation ‣ 3 Group Normalization ‣ Group Normalization") (left) shows that GN has *lower training error* than BN, indicating that GN is effective for easing *optimization*. The slightly higher validation error of GN implies that GN loses some regularization ability of BN. This is understandable, because BN’s mean and variance computation introduces uncertainty caused by the stochastic batch sampling, which helps regularization [[26](#bib.bib26)]. This uncertainty is missing in GN (and LN/IN). But it is possible that GN combined with a suitable regularizer will improve results. This can be a future research topic.

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| batch size | 32 | 16 | 8 | 4 | 2 |
| BN | 23.6 | 23.7 | 24.8 | 27.3 | 34.7 |
| GN | 24.1 | 24.2 | 24.0 | 24.2 | 24.1 |
| $\triangle$ | *0.5* | *0.5* | *-0.8* | *-3.1* | *-10.6* |

Table 2: Sensitivity to batch sizes. We show ResNet-50’s validation error (%) in ImageNet. The last row shows the differences between BN and GN.
The error curves are in Figure [5](#S3.F5 "Figure 5 ‣ 3.2 Implementation ‣ 3 Group Normalization ‣ Group Normalization"). This table is visualized in Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Group Normalization").

|  | error |
| --- | --- |
| none | 29.2 |
| BN | 28.0 |
| GN | 27.6 |

Figure 6: Evolution of feature distributions of conv5\_3’s output (before normalization and ReLU) from VGG-16, shown as the {1, 20, 80, 99} percentile of responses. The table on the right shows the ImageNet validation error (%). Models are trained with 32 images/GPU.

#### Small batch sizes.

Although BN benefits from the stochasticity under some situations, its error increases when the batch size becomes smaller and the uncertainty gets bigger. We show this in Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Group Normalization"), Figure [5](#S3.F5 "Figure 5 ‣ 3.2 Implementation ‣ 3 Group Normalization ‣ Group Normalization"), and Table [2](#S4.T2 "Table 2 ‣ Comparison of feature normalization methods. ‣ 4.1 Image Classification in ImageNet ‣ 4 Experiments ‣ Group Normalization").

We evaluate batch sizes of 32, 16, 8, 4, 2 images per GPU. In all cases, the BN mean and variance are computed within each GPU and not synchronized. All models are trained in 8 GPUs. In this set of experiments, we adopt the linear learning rate scaling rule [[31](#bib.bib31), [4](#bib.bib4), [16](#bib.bib16)] to adapt to batch size changes — we use a learning rate of 0.1 [[20](#bib.bib20)] for the batch size of 32, and 0.1$N/$32 for a batch size of $N$. This linear scaling rule works well for BN if the total batch size changes (by changing the number of GPUs) but the per-GPU batch size does not change [[16](#bib.bib16)].
We keep the same number of training epochs for all cases (Figure [5](#S3.F5 "Figure 5 ‣ 3.2 Implementation ‣ 3 Group Normalization ‣ Group Normalization"), x-axis). All other hyper-parameters are unchanged.

Figure [5](#S3.F5 "Figure 5 ‣ 3.2 Implementation ‣ 3 Group Normalization ‣ Group Normalization") (left) shows that BN’s error becomes considerably higher with small batch sizes. GN’s behavior is more stable and insensitive to the batch size. Actually, Figure [5](#S3.F5 "Figure 5 ‣ 3.2 Implementation ‣ 3 Group Normalization ‣ Group Normalization") (right) shows that GN has very similar curves (subject to random variations) across a wide range of batch sizes from 32 to 2. In the case of a batch size of 2, GN has 10.6% lower error rate than its BN counterpart (24.1% *vs*. 34.7%).

These results indicate that the batch mean and variance estimation can be overly stochastic and inaccurate, especially when they are computed over 4 or 2 images. However, this stochasticity disappears if the statistics are computed from 1 image, in which case BN becomes similar to IN at training time. We see that IN has a better result (28.4%) than BN with a batch size of 2 (34.7%).

The robust results of GN in Table [2](#S4.T2 "Table 2 ‣ Comparison of feature normalization methods. ‣ 4.1 Image Classification in ImageNet ‣ 4 Experiments ‣ Group Normalization") demonstrate GN’s strength. It allows to remove the batch size constraint imposed by BN, which can give considerably more memory (*e.g*., 16$\times$ or more).
This will make it possible to train higher-capacity models that would be otherwise bottlenecked by memory limitation. We hope this will create new opportunities in architecture design.

| # groups ($G$) | | | | | | |
| --- | --- | --- | --- | --- | --- | --- |
| 64 | 32 | 16 | 8 | 4 | 2 | 1 (=LN) |
| 24.6 | 24.1 | 24.6 | 24.4 | 24.6 | 24.7 | 25.3 |
| *0.5* | - | *0.5* | *0.3* | *0.5* | *0.6* | *1.2* |

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| # channels per group | | | | | | |
| 64 | 32 | 16 | 8 | 4 | 2 | 1 (=IN) |
| 24.4 | 24.5 | 24.2 | 24.3 | 24.8 | 25.6 | 28.4 |
| *0.2* | *0.3* | - | *0.1* | *0.6* | *1.4* | *4.2* |

Table 3: Group division. We show ResNet-50’s validation error (%) in ImageNet, trained with 32 images/GPU. (Top): a given number of groups. (Bottom): a given number of channels per group. The last rows show the differences with the best number.

#### Comparison with Batch Renorm (BR).

BR [[25](#bib.bib25)] introduces two extra parameters ($r$ and $d$ in [[25](#bib.bib25)]) that constrain the estimated mean and variance of BN. Their values are controlled by $r\_{\text{max}}$ and $d\_{\text{max}}$. To apply BR to ResNet-50, we have carefully chosen these hyper-parameters, and found that $r\_{\text{max}}=1.5$ and $d\_{\text{max}}=0.5$ work best for ResNet-50. With a batch size of 4, ResNet-50 trained with BR has an error rate of 26.3%. This is better than BN’s 27.3%, but still 2.1% higher than GN’s 24.2%.

#### Group division.

Thus far all presented GN models are trained with a group number of $G=32$. Next we evaluate different ways of dividing into groups.
With a given fixed group number, GN performs reasonably well for all values of $G$ we studied (Table [3](#S4.T3 "Table 3 ‣ Small batch sizes. ‣ 4.1 Image Classification in ImageNet ‣ 4 Experiments ‣ Group Normalization"), top panel). In the extreme case of $G=1$, GN is equivalent to LN, and its error rate is higher than all cases of $G>1$ studied.

We also evaluate fixing the number of channels per group (Table [3](#S4.T3 "Table 3 ‣ Small batch sizes. ‣ 4.1 Image Classification in ImageNet ‣ 4 Experiments ‣ Group Normalization"), bottom panel). Note that because the layers can have different channel numbers, the group number $G$ can change across layers in this setting. In the extreme case of 1 channel per group, GN is equivalent to IN. Even if using as few as 2 channels per group, GN has substantially lower error than IN (25.6% *vs*. 28.4%). This result shows the effect of grouping channels when performing normalization.

#### Deeper models.

We have also compared GN with BN on ResNet-101 [[20](#bib.bib20)]. With a batch size of 32, our BN baseline of ResNet-101 has 22.0% validation error, and the GN counterpart has 22.4%, slightly worse by 0.4%. With a batch size of 2, GN ResNet-101’s error is 23.0%. This is still a decently stable result considering the very small batch size, and it is 8.9% better than the BN counterpart’s 31.9%.

#### Results and analysis of VGG models.

To study GN/BN compared to *no normalization*, we consider VGG-16 [[56](#bib.bib56)] that can be healthily trained without normalization layers. We apply BN or GN right after each convolutional layer.
Figure [6](#S4.F6 "Figure 6 ‣ Comparison of feature normalization methods. ‣ 4.1 Image Classification in ImageNet ‣ 4 Experiments ‣ Group Normalization") shows the evolution of the feature distributions of conv5\_3 (the last convolutional layer). GN and BN behave *qualitatively similar*, while being substantially different with the variant that uses no normalization; this phenomenon is also observed for all other convolutional layers. This comparison suggests that performing normalization is essential for controlling the distribution of features.

For VGG-16, GN is *better* than BN by 0.4% (Figure [6](#S4.F6 "Figure 6 ‣ Comparison of feature normalization methods. ‣ 4.1 Image Classification in ImageNet ‣ 4 Experiments ‣ Group Normalization"), right). This possibly implies that VGG-16 benefits less from BN’s regularization effect, and GN (that leads to lower training error) is superior to BN in this case.

### 4.2 Object Detection and Segmentation in COCO

Next we evaluate fine-tuning the models for transferring to object detection and segmentation. These computer vision tasks in general benefit from higher-resolution input, so the batch size tends to be small in common practice (1 or 2 images/GPU [[12](#bib.bib12), [47](#bib.bib47), [18](#bib.bib18), [36](#bib.bib36)]). As a result, BN is turned into a *linear* layer $y=\frac{\gamma}{\sigma}(x-\mu)+\beta$ where $\mu$ and $\sigma$ are pre-computed from the pre-trained model and frozen [[20](#bib.bib20)]. We denote this as BN${}^{\text{\*}}$, which in fact performs no normalization during fine-tuning. We have also tried a variant that fine-tunes BN (normalization is performed and not frozen) and found it works poorly (reducing $\scriptstyle\sim$6 AP with a batch size of 2), so we ignore this variant.

We experiment on the Mask R-CNN baselines [[18](#bib.bib18)], implemented in the publicly available codebase of *Detectron* [[13](#bib.bib13)]. We use the end-to-end variant with the same hyper-parameters as in [[13](#bib.bib13)].
We replace BN${}^{\text{\*}}$ with GN during fine-tuning, using the corresponding models pre-trained from ImageNet.44
4
Detectron [[13](#bib.bib13)] uses pre-trained models provided by the authors of [[20](#bib.bib20)]. For fair comparisons, we instead use the models pre-trained in this paper. The object detection and segmentation accuracy is statistically similar between these pre-trained models.
During fine-tuning, we use a weight decay of 0 for the $\gamma$ and $\beta$ parameters, which is important for good detection results when $\gamma$ and $\beta$ are being tuned. We fine-tune with a batch size of 1 image/GPU and 8 GPUs.

The models are trained in the COCO train2017 set and evaluated in the COCO val2017 set (a.k.a minival). We report the standard COCO metrics of Average Precision (AP), AP${}\_{\text{50}}$, and AP${}\_{\text{75}}$, for bounding box detection (AP${}^{\text{bbox}}$) and instance segmentation (AP${}^{\text{mask}}$).

Figure 7: Error curves in Kinetics with an input length of 32 frames. We show ResNet-50 I3D’s validation error of BN (left) and GN (right) using a batch size of 8 and 4 clips/GPU. The monitored validation error is the 1-clip error under the same data augmentation as the training set, while the final validation accuracy in Table [8](#S4.T8 "Table 8 ‣ 4.3 Video Classification in Kinetics ‣ 4 Experiments ‣ Group Normalization") is 10-clip testing without data augmentation.

#### Results of C4 backbone.

Table [4](#S4.T4 "Table 4 ‣ Results of C4 backbone. ‣ 4.2 Object Detection and Segmentation in COCO ‣ 4 Experiments ‣ Group Normalization") shows the comparison of GN *vs*. BN${}^{\text{\*}}$ on Mask R-CNN using a conv4 backbone (“C4” [[18](#bib.bib18)]). This C4 variant uses ResNet’s layers of up to conv4 to extract feature maps, and ResNet’s conv5 layers as the Region-of-Interest (RoI) heads for classification and regression. As they are inherited from the pre-trained model, the backbone and head both involve normalization layers.

On this baseline, GN improves over BN${}^{\text{\*}}$ by 1.1 box AP and 0.8 mask AP. We note that the pre-trained GN model is slightly worse than BN in ImageNet (24.1% *vs*. 23.6%), but GN still outperforms BN${}^{\text{\*}}$ for fine-tuning. BN${}^{\text{\*}}$ creates inconsistency between pre-training and fine-tuning (frozen), which may explain the degradation.

We have also experimented with the LN variant, and found it is 1.9 box AP worse than GN and 0.8 worse than BN${}^{\text{\*}}$. Although LN is also independent of batch sizes, its representational power is weaker than GN.

| backbone | AP${}^{\text{bbox}}$ | AP${}^{\text{bbox}}\_{\text{50}}$ | AP${}^{\text{bbox}}\_{\text{75}}$ | AP${}^{\text{mask}}$ | AP${}^{\text{mask}}\_{\text{50}}$ | AP${}^{\text{mask}}\_{\text{75}}$ |
| --- | --- | --- | --- | --- | --- | --- |
| BN${}^{\text{\*}}$ | 37.7 | 57.9 | 40.9 | 32.8 | 54.3 | 34.7 |
| GN | 38.8 | 59.2 | 42.2 | 33.6 | 55.9 | 35.4 |

Table 4: Detection and segmentation ablation results in COCO, using Mask R-CNN with ResNet-50 C4. BN${}^{\text{\*}}$ means BN is frozen.

| backbone | box head | AP${}^{\text{bbox}}$ | AP${}^{\text{bbox}}\_{\text{50}}$ | AP${}^{\text{bbox}}\_{\text{75}}$ | AP${}^{\text{mask}}$ | AP${}^{\text{mask}}\_{\text{50}}$ | AP${}^{\text{mask}}\_{\text{75}}$ |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BN${}^{\text{\*}}$ | - | 38.6 | 59.5 | 41.9 | 34.2 | 56.2 | 36.1 |
| BN${}^{\text{\*}}$ | GN | 39.5 | 60.0 | 43.2 | 34.4 | 56.4 | 36.3 |
| GN | GN | 40.0 | 61.0 | 43.3 | 34.8 | 57.3 | 36.3 |

Table 5: Detection and segmentation ablation results in COCO, using Mask R-CNN with ResNet-50 FPN and a 4conv1fc bounding box head. BN${}^{\text{\*}}$ means BN is frozen.

|  | AP${}^{\text{bbox}}$ | AP${}^{\text{bbox}}\_{\text{50}}$ | AP${}^{\text{bbox}}\_{\text{75}}$ | AP${}^{\text{mask}}$ | AP${}^{\text{mask}}\_{\text{50}}$ | AP${}^{\text{mask}}\_{\text{75}}$ |
| --- | --- | --- | --- | --- | --- | --- |
| R50 BN${}^{\text{\*}}$ | 38.6 | 59.8 | 42.1 | 34.5 | 56.4 | 36.3 |
| R50 GN | 40.3 | 61.0 | 44.0 | 35.7 | 57.9 | 37.7 |
| R50 GN, long | 40.8 | 61.6 | 44.4 | 36.1 | 58.5 | 38.2 |
| R101 BN${}^{\text{\*}}$ | 40.9 | 61.9 | 44.8 | 36.4 | 58.5 | 38.7 |
| R101 GN | 41.8 | 62.5 | 45.4 | 36.8 | 59.2 | 39.0 |
| R101 GN, long | 42.3 | 62.8 | 46.2 | 37.2 | 59.7 | 39.5 |

Table 6: Detection and segmentation results in COCO using Mask R-CNN and FPN. Here BN${}^{\text{\*}}$ is the default Detectron baseline [[13](#bib.bib13)], and GN is applied to the backbone, box head, and mask head. “long” means training with more iterations. Code of these results are in <https://github.com/facebookresearch/Detectron/blob/master/projects/GN>.

#### Results of FPN backbone.

Next we compare GN and BN${}^{\text{\*}}$ on Mask R-CNN using a Feature Pyramid Network (FPN) backbone [[35](#bib.bib35)], the currently state-of-the-art framework in COCO. Unlike the C4 variant, FPN exploits all pre-trained layers to construct a pyramid, and appends randomly initialized layers as the head. In [[35](#bib.bib35)], the box head consists of two hidden fully-connected layers (2fc). We find that replacing the 2fc box head with 4conv1fc (similar to [[48](#bib.bib48)]) can better leverage GN.
The resulting comparisons are in Table [5](#S4.T5 "Table 5 ‣ Results of C4 backbone. ‣ 4.2 Object Detection and Segmentation in COCO ‣ 4 Experiments ‣ Group Normalization").

As a baseline, BN${}^{\text{\*}}$ has 38.6 box AP using the 4conv1fc head, on par with its 2fc counterpart using the same pre-trained model (38.5 AP). By adding GN to all convolutional layers of the box head (but still using the BN${}^{\text{\*}}$ backbone), we increase the box AP by 0.9 to 39.5 (2nd row, Table [5](#S4.T5 "Table 5 ‣ Results of C4 backbone. ‣ 4.2 Object Detection and Segmentation in COCO ‣ 4 Experiments ‣ Group Normalization")). This ablation shows that a substantial portion of GN’s improvement for detection is from *normalization in the head* (which is also done by the C4 variant). On the contrary, applying BN to the box head (that has 512 RoIs per image) does not provide satisfactory result and is $\scriptstyle\sim$9 AP worse — in detection, the batch of RoIs are sampled from the same image and their distribution is not *i.i.d.*, and the *non-i.i.d.* distribution is also an issue that degrades BN’s batch statistics estimation [[25](#bib.bib25)]. GN does not suffer from this problem.

Next we replace the FPN backbone with the GN-based counterpart, *i.e*., the GN pre-trained model is used during fine-tuning (3rd row, Table [5](#S4.T5 "Table 5 ‣ Results of C4 backbone. ‣ 4.2 Object Detection and Segmentation in COCO ‣ 4 Experiments ‣ Group Normalization")).
Applying GN to the backbone *alone* contributes a 0.5 AP gain (from 39.5 to 40.0), suggesting that GN helps when transferring features.

Table [6](#S4.T6 "Table 6 ‣ Results of C4 backbone. ‣ 4.2 Object Detection and Segmentation in COCO ‣ 4 Experiments ‣ Group Normalization") shows the full results of GN (applied to the backbone, box head, and mask head), compared with the standard Detectron baseline [[13](#bib.bib13)] based on BN${}^{\text{\*}}$. Using the same hyper-parameters as [[13](#bib.bib13)], GN increases over BN${}^{\text{\*}}$ by a healthy margin. Moreover, we found that GN is not fully trained with the default schedule in [[13](#bib.bib13)], so we also tried increasing the iterations from 180k to 270k (BN${}^{\text{\*}}$ does not benefit from longer training).
Our final ResNet-50 GN model (“long”, Table [6](#S4.T6 "Table 6 ‣ Results of C4 backbone. ‣ 4.2 Object Detection and Segmentation in COCO ‣ 4 Experiments ‣ Group Normalization")) is 2.2 points box AP and 1.6 points mask AP better than its BN${}^{\text{\*}}$ variant.

| *from scratch* | AP${}^{\text{bbox}}$ | AP${}^{\text{bbox}}\_{\text{50}}$ | AP${}^{\text{bbox}}\_{\text{75}}$ | AP${}^{\text{mask}}$ | AP${}^{\text{mask}}\_{\text{50}}$ | AP${}^{\text{mask}}\_{\text{75}}$ |
| --- | --- | --- | --- | --- | --- | --- |
| R50 BN [[34](#bib.bib34)] | 34.5 | 55.2 | 37.7 | - | - | - |
| R50 GN | 39.5 | 59.8 | 43.6 | 35.2 | 56.9 | 37.6 |
| R101 GN | 41.0 | 61.1 | 44.9 | 36.4 | 58.2 | 38.7 |

Table 7: Detection and segmentation results trained from scratch in COCO using Mask R-CNN and FPN. Here the BN results are from [[34](#bib.bib34)], and BN is synced across GPUs [[43](#bib.bib43)] and is *not* frozen. Code of these results are in <https://github.com/facebookresearch/Detectron/blob/master/projects/GN>.

#### Training Mask R-CNN from scratch.

GN allows us to easily investigate training object detectors *from scratch* (without any pre-training). We show the results in Table [7](#S4.T7 "Table 7 ‣ Results of FPN backbone. ‣ 4.2 Object Detection and Segmentation in COCO ‣ 4 Experiments ‣ Group Normalization"), where the GN models are trained for 270k iterations.55
5
For models trained from scratch, we turn off the default StopGrad in Detectron that freezes the first few layers.
To our knowledge, our numbers (41.0 box AP and 36.4 mask AP) are the best *from-scratch* results in COCO reported to date; they can even compete with the ImageNet-pretrained results in Table [6](#S4.T6 "Table 6 ‣ Results of C4 backbone. ‣ 4.2 Object Detection and Segmentation in COCO ‣ 4 Experiments ‣ Group Normalization").
As a reference, with synchronous BN [[43](#bib.bib43)], a concurrent work [[34](#bib.bib34)] achieves a from-scratch result of 34.5 box AP using R50 (Table [7](#S4.T7 "Table 7 ‣ Results of FPN backbone. ‣ 4.2 Object Detection and Segmentation in COCO ‣ 4 Experiments ‣ Group Normalization")), and 36.3 using a specialized backbone.

### 4.3 Video Classification in Kinetics

Lastly we evaluate video classification in the Kinetics dataset [[30](#bib.bib30)]. Many video classification models [[60](#bib.bib60), [6](#bib.bib6)] extend the features to 3D spatial-temporal dimensions. This is memory-demanding and imposes constraints on the batch sizes and model designs.

We experiment with Inflated 3D (I3D) convolutional networks [[6](#bib.bib6)].
We use the ResNet-50 I3D *baseline* as described in [[62](#bib.bib62)].
The models are pre-trained from ImageNet.
For both BN and GN, we extend the normalization from over $(H,W)$ to over $(T,H,W)$, where $T$ is the temporal axis. We train in the 400-class Kinetics training set and evaluate in the validation set. We report the top-1 and top-5 classification accuracy, using standard 10-clip testing that averages softmax scores from 10 clips regularly sampled.

We study two different temporal lengths: 32-frame and 64-frame input clips. The 32-frame clip is regularly sampled with a frame interval of 2 from the raw video, and the 64-frame clip is sampled continuously. The model is fully convolutional in spacetime, so the 64-frame variant consumes about 2$\times$ more memory. We study a batch size of 8 or 4 clips/GPU for the 32-frame variant, and 4 clips/GPU for the 64-frame variant due to memory limitation.

| clip length | 32 | 32 | 64 |
| --- | --- | --- | --- |
| batch size | 8 | 4 | 4 |
| BN | 73.3 / 90.7 | 72.1 / 90.0 | 73.3 / 90.8 |
| GN | 73.0 / 90.6 | 72.8 / 90.6 | 74.5 / 91.7 |

Table 8: Video classification results in Kinetics: ResNet-50 I3D baseline’s top-1 / top-5 accuracy (%).

#### Results of 32-frame inputs.

Table [8](#S4.T8 "Table 8 ‣ 4.3 Video Classification in Kinetics ‣ 4 Experiments ‣ Group Normalization") (col. 1, 2) shows the video classification accuracy in Kinetics using 32-frame clips. For the batch size of 8, GN is slightly worse than BN by 0.3% top-1 accuracy and 0.1% top-5. This shows that GN is competitive with BN when BN works well. For the smaller batch size of 4, GN’s accuracy is kept similar (72.8 / 90.6 *vs*. 73.0 / 90.6), but is better than BN’s 72.1 / 90.0. BN’s accuracy is decreased by 1.2% when the batch size decreases from 8 to 4.

Figure [7](#S4.F7 "Figure 7 ‣ 4.2 Object Detection and Segmentation in COCO ‣ 4 Experiments ‣ Group Normalization") shows the error curves. BN’s error curves (left) have a noticeable gap when the batch size decreases from 8 to 4, while GN’s error curves (right) are very similar.

#### Results of 64-frame inputs.

Table [8](#S4.T8 "Table 8 ‣ 4.3 Video Classification in Kinetics ‣ 4 Experiments ‣ Group Normalization") (col. 3) shows the results of using 64-frame clips. In this case, BN has a result of 73.3 / 90.8. These appear to be acceptable numbers (*vs*. 73.3 / 90.7 of 32-frame, batch size 8), but *the trade-off between the temporal length (64 *vs*. 32) and batch size (4 *vs*. 8) could have been overlooked*. Comparing col. 3 and col. 2 in Table [8](#S4.T8 "Table 8 ‣ 4.3 Video Classification in Kinetics ‣ 4 Experiments ‣ Group Normalization"), we find that the temporal length actually has positive impact (+1.2%), but it is veiled by BN’s negative effect of the smaller batch size.

GN does not suffer from this trade-off. The 64-frame variant of GN has 74.5 / 91.7 accuracy, showing healthy gains over its BN counterpart and all BN variants. GN helps the model benefit from temporal length, and the longer clip boosts the top-1 accuracy by 1.7% (top-5 1.1%) with the same batch size.

The improvement of GN on detection, segmentation, and video classification demonstrates that GN is a strong alternative to the powerful and currently dominant BN technique in these tasks.

## 5 Discussion and Future Work

We have presented GN as an effective normalization layer without exploiting the batch dimension. We have evaluated GN’s behaviors in a variety of applications. We note, however, that BN has been so influential that many state-of-the-art systems and their hyper-parameters have been designed for it, which may not be optimal for GN-based models. It is possible that re-designing the systems or searching new hyper-parameters for GN will give better results.

In addition, we have shown that GN is related to LN and IN, two normalization methods that are particularly successful in training recurrent (RNN/LSTM) or generative (GAN) models. This suggests us to study GN in those areas in the future. We will also investigate GN’s performance on learning representations for reinforcement learning (RL) tasks, *e.g*., [[54](#bib.bib54)], where BN is playing an important role for training very deep models [[20](#bib.bib20)].

#### Acknowledgement.

We would like to thank Piotr Dollár and Ross Girshick for helpful discussions.
