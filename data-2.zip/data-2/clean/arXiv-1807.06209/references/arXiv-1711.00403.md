<!-- fulltext source=arxiv_html slug=arXiv-1711.00403 fetched=2026-09-18T01:02:43+00:00 -->

# Dark Energy Survey Year 1 Results: A Precise $\bm{H\_{0}}$ Measurement from DES Y1, BAO, and $\bm{D/H}$ Data

T. M. C. Abbott,
F. B. Abdalla,
J. Annis,
K. Bechtol,
B. A. Benson,
R. A. Bernstein,
G. M. Bernstein,
E. Bertin,
D. Brooks,
D. L. Burke,
A. Carnero Rosell,
M. Carrasco Kind,
J. Carretero,
F. J. Castander,
C. L. Chang,
T. M. Crawford,
C. E. Cunha,
C. B. D’Andrea,
L. N. da Costa,
C. Davis,
S. Desai,
H. T. Diehl,
J. P. Dietrich,
P. Doel,
A. Drlica-Wagner,
A. E. Evrard,
E. Fernandez,
B. Flaugher,
J. Frieman,
J. García-Bellido,
E. Gaztanaga,
D. W. Gerdes,
T. Giannantonio,
D. Gruen,
R. A. Gruendl,
J. Gschwend,
G. Gutierrez,
W. G. Hartley,
J. W. Henning,
K. Honscheid,
B. Hoyle,
B. Jain,
D. J. James,
M. Jarvis,
T. Jeltema,
M. D. Johnson,
M. W. G. Johnson,
E. Krause,
K. Kuehn,
S. Kuhlmann,
N. Kuropatkin,
O. Lahav,
A. R. Liddle,
M. Lima,
H. Lin,
M. A. G. Maia,
A. Manzotti,
M. March,
J. L. Marshall,
R. Miquel,
J. J. Mohr,
T. Natoli,
P. Nugent,
R. L. C. Ogando,
Y. Park,
A. A. Plazas,
C. L. Reichardt,
K. Reil,
A. Roodman,
A. J. Ross,
E. Rozo,
E. S. Rykoff,
E. Sanchez,
V. Scarpine,
M. Schubnell,
D. Scolnic,
I. Sevilla-Noarbe,
M. Smith,
R. C. Smith,
M. Soares-Santos,
F. Sobreira,
E. Suchyta,
G. Tarle,
D. Thomas,
M. A. Troxel,
A. R. Walker,
R. H. Wechsler,
J. Weller,
W. Wester,
W. L. K. Wu,
J. Zuntz
(The Dark Energy Survey and the South Pole Telescope Collaborations)†

###### Abstract

We combine Dark Energy Survey Year 1 clustering and weak lensing data
with Baryon Acoustic Oscillations (BAO) and Big Bang Nucleosynthesis (BBN)
experiments to constrain the Hubble constant. Assuming a flat
$\Lambda$CDM model with minimal neutrino mass ($\sum m\_{\nu}=0.06\ {\rm eV}$)
we find $H\_{0}=67.2^{+1.2}\_{-1.0}\ \mbox{km/s/Mpc}$ (68% CL).
This result is completely independent of Hubble constant measurements based on the distance
ladder, Cosmic Microwave Background (CMB) anisotropies (both temperature and polarization),
and strong lensing constraints.
There are now five data sets that: a) have no
shared observational systematics; and b) each constrain the Hubble constant
with a few percent level precision. We compare these five independent measurements,
and find that, as a set, the differences between them are significant at the $2.1\sigma$
level ($\chi^{2}/dof=20.1/11$, probability to exceed=4%). This difference is low enough
that we consider the data sets statistically consistent with each other.
The best fit Hubble constant obtained by combining all five data sets is $H\_{0}=69.1^{+0.4}\_{-0.6}\ \mbox{km/s/Mpc}$.

## 1 Introduction

The current standard model of cosmology is remarkably
successful.††
†For correspondence use des-publication-queries@fnal.gov
With only six free parameters,
it can accurately describe the entire history of the Universe.
The variety of data fit by this remarkable model includes: primoridal
light element abundances (e.g. [Cooke et al. 2016](#bib.bib15), hereafter C16);
the temperature and polarization angular power spectra of the CMB
anisotropies ([Planck
Collaboration 2015](#bib.bib44); [Henning
et al. 2017](#bib.bib34), e.g.); the distance–redshift
relation of standard candles such as Type IA supernovae (SNe) ([Betoule
et al. 2014](#bib.bib12), e.g.);
galaxy–galaxy (gg) clustering in the late-time Universe ([Gaztañaga et al. 2009](#bib.bib32); [Beutler
et al. 2011](#bib.bib13); [Ross et al. 2015](#bib.bib47); [Alam
et al. 2017a](#bib.bib4), e.g.);
the time delays of multiply imaged quasars ([Bonvin
et al. 2017](#bib.bib14), e.g.);
and weak gravitational lensing measurements
([Mandelbaum
et al. 2013](#bib.bib42); [Alsing
et al. 2017](#bib.bib6); [Hildebrandt
et al. 2017](#bib.bib35); [van Uitert
et al. 2017](#bib.bib51); [Troxel
et al. 2017a](#bib.bib49); [DES
Collaboration 2017](#bib.bib19), e.g.).

Despite its tremendous success and its remarkable simplicity, the standard model of cosmology is theoretically
surprising. In this model, $\approx 85\%$ of the matter in the Universe
is dark matter, detected only through its gravitational impact on observable matter.
Additionally, the current accelerating expansion of the Universe
requires $\approx 70\%$ of the energy in the Universe
to take the form of either a cosmological constant, a dynamical field with negative pressure,
or a modification of general relativity. While the cosmological constant is usually viewed
as the most conservative solution to this theoretical challenge,
its interpretation as a manifestation of vacuum energy leads to naive predictions that
differ from the observed value by many orders of magnitude
([Weinberg 1989](#bib.bib52)).

In short, the standard model of cosmology has provided indirect evidence of not one but two
distinct extensions of the standard model of particle physics.
It is therefore reasonable to expect that any cracks in this standard cosmological
model might herald yet another surprise in our understanding of the cosmos.

One such possible crack arises from the value of the Hubble constant, i.e. the current rate of expansion of the
Universe. The Hubble constant can be directly measured using type-IA SNe, whose luminosities are calibrated
using SNe hosted by nearby galaxies with known distances.
Alternatively, measurements of the CMB indirectly constrain the Hubble constant via its
impact on the CMB anisotropies. Both of these measurements are remarkably precise. Currently,
the most precise SN measurement of the Hubble constant
is that of the SH0ES collaboration ([Riess
et al. 2016](#bib.bib46)),
who report $H\_{0}=73.24\pm 1.74\ \mbox{km/s/Mpc}$. This value is in excellent agreement with
that of [Freedman
et al. (2012,
=
H
0
±
74.3
1.5
⁢
2.1
km/s/Mpc
)](#bib.bib28), and is to be compared
to that inferred from Planck measurements assuming a flat $\Lambda$CDM
model with minimal neutrino mass, $H\_{0}=67.3\pm 1.0\ \mbox{km/s/Mpc}$ (Planck TT + low-$l$ only).
These two values are discrepant at $3.0\sigma$.11
1
Throughout this work,
we rely exclusively on Planck TT + low-$l$ polarization data. This ensures the Planck data
set is independent of the SPTpol data set ([Henning
et al. 2017](#bib.bib34)).
Including high-$l$ Planck polarization data increases
the discrepancy between Planck and SH0ES to $3.4\sigma$, as quoted in [Riess
et al. (2016)](#bib.bib46). However,
[Planck
Collaboration (2015)](#bib.bib44) find evidence for instrumental systematics in their high-$l$ polarization spectra,
and urge caution while interpreting features in them.
This difference provides a strong motivation for searching for
alternative methods of measuring the Hubble constant ([Freedman 2017](#bib.bib27)).

As first highlighted by [Aubourg
et al. (2015)](#bib.bib8), the Baryon Acoustic Oscillation (BAO) signature
in the clustering of galaxies provides a standard ruler that enables us to determine $H\_{0}$.
Slight density fluctuations in the early universe launched
sound waves at the epoch of the Big Bang. These sound waves traveled through the photon–baryon plasma
until the epoch of decoupling, at which point the waves were no longer pressure supported and stalled.
The distance traveled by these waves before stalling — the so-called sound horizon $r\_{s}$ —
can be readily computed a priori for any set of cosmological parameters.
The overdensities due to these sound waves
seeded galaxy formation, leading to a bump in the galaxy correlation function at distances
equal to the sound horizon $r\_{s}$. This bump is the so-called BAO feature.

Observationally, the BAO feature allows us to measure either the
angle spanned by the distance $r\_{\rm s}$ — leading to a constraint on $D\_{\rm M}/r\_{\rm s}$ —
or the redshift interval corresponding to two galaxies separated by a
distance $r\_{\rm s}$ along the line of sight — leading to a constraint on $cH^{-1}/r\_{\rm s}$.
Here, $D\_{\rm M}$ is the co-moving angular diameter distance
to the galaxies in question, and $H(z)$ is the Hubble expansion rate at the redshift of the observed galaxies.
In a flat $\Lambda$CDM model,
the Hubble rate is primarily sensitive
to the Hubble constant $H\_{0}$ — typically parameterized via $h$,
where $H\_{0}=100h\ \mbox{km/s/Mpc}$ — and the total matter density parameter $\Omega\_{\rm m}$.
As an integral over the Hubble rate, these parameters also govern the behavior of
the angular diameter distance $D\_{\rm M}$.
Finally, the sound horizon $r\_{\rm s}$ depends on: 1) the mean
temperature of the CMB; 2) the
dark matter density $\Omega\_{{\rm dm}}h^{2}$, and 3) the baryon density $\Omega\_{\rm b}h^{2}$. In practice,
the precision with which the mean CMB temperature is known is already sufficiently high that we
may ignore its observational uncertainties.

In summary, assuming the CMB temperature is known,
the BAO observables $D\_{\rm M}/r\_{\rm s}$ and $cH^{-1}/r\_{\rm s}$ fundamentally depend on
three key cosmological parameters only: $\Omega\_{\rm m}$, $\Omega\_{\rm b}h^{2}$, and $h$.
BAO measurements at a single redshift will necessarily result in strong degeneracies between these
parameters. Fortunately, the sensitivity of the sound horizon $r\_{\rm s}$ to $\Omega\_{\rm b}h^{2}$ is relatively
mild ([Aubourg
et al. 2015](#bib.bib8), $d\ln r\_{\rm s}/d\ln\Omega\_{\rm b}h^{2}\approx 0.13$,), so even
modest independent (i.e. non-BAO) constraints on $\Omega\_{\rm b}h^{2}$ suffice to break the $\Omega\_{\rm b}h^{2}$ degeneracy.

Big Bang Nucleosynthesis (BBN) enables us to measure $\Omega\_{\rm b}h^{2}$ through its impact on the primordial deuterium-to-hydrogen
($D/H$) ratio. During BBN, deuterium is burned to create ${}^{4}{\rm He}$. The reaction rate increases with increasing
baryon density, so $D/H$ decreases monotonically with $\Omega\_{\rm b}h^{2}$.22
2
Here, we follow [Planck
Collaboration (2015)](#bib.bib44) and
focus exclusively on $D/H$ observations because of the more difficult nature of the observations and interpretation
of other light elements, e.g. lithium ([Fields
et al. 2014](#bib.bib25), for a review, see).
The current best method for determining the primordial $D/H$ ratio relies on extremely
low-metallicity lines of sight to quasars, as determined from the quasar absorption spectrum. Such pristine
lines of sight are unpolluted by baryonic processes in stars, so their element abundance ratios are expected
to be primordial. Measurements of damped Ly-$\alpha$ systems in the quasar absorption spectra are used to infer the
$D/H$ ratio along these lines of sight, which in turn enables us to infer $\Omega\_{\rm b}h^{2}$.

Even after including BBN data, a single BAO measurement will exhibit a strong $\Omega\_{\rm m}$–$h$ degeneracy.
This degeneracy
ellipse rotates as the redshift is varied, so two BAO measurements that span a large redshift range can
break this degeneracy. [Aubourg
et al. (2015)](#bib.bib8) and
[Addison
et al. (2017, henceforth referred to as A17)](#bib.bib3) combined low-redshift galaxy BAO measurements with
high-redshift Ly-$\alpha$ BAO data to arrive at a measurement of $h$.
A17 found $H\_{0}=67.4\pm 1.3\ \mbox{km/s/Mpc}$, though the authors also note
that there is an $\approx 2\sigma$ difference between the galaxy and Ly-$\alpha$ BAO
measurements.33
3
We quote the $H\_{0}$ value obtained
by the mean of the two values reported in A17, the more recent of the two analyses. The two values in A17
differ on the adopted value for the $d(p\mathord{\mathchar 59\relax}\gamma)^{3}\mbox{He}$ reaction rate in the BBN calculation.
We also adopted the larger of the two error bars quoted in A17.

In this work, we break the $\Omega\_{\rm m}$–$h$ degeneracy of the galaxy BAO+BBN measurement
with clustering and weak lensing data from the Dark Energy Survey (DES) Year 1 data set.
In [DES
Collaboration (2017)](#bib.bib19), we have shown
that our analysis of the DES Y1 data results in the most accurate and precise constraints on
the total matter density $\Omega\_{\rm m}$ from any lensing analysis to date.
In combination with galaxy BAO measurements and
BBN constraints derived from $D/H$ observations, we derive remarkably tight constraints on
the Hubble rate that are independent of both CMB anisotropies and local supernova measurements.
Throughout this work we adopt $3\sigma$ (0.27%) as the threshold
for “evidence of tension”, and the usual $5\sigma$ ($5.7\times 10^{-7}$)
threshold for “definitive evidence of tension”,
though we recognize these thresholds are necessarily subjective.

## 2 Analysis

Our analysis relies on four sets of data:

1. 1.

   The COBE/FIRAS measurements of the temperature of the CMB ([Fixsen 2009](#bib.bib26))
2. 2.

   Galaxy BAO measurements from a variety of spectroscopic surveys.
3. 3.

   Observational estimates of the primordial $D/H$ ratio.
4. 4.

   Tomographic shear, galaxy-galaxy lensing (gg-lensing), and galaxy-galaxy clustering (gg-clustering)
   data on linear scales measured in the DES Y1 data set.

Our BAO constraints are taken directly from the constraints derived from the 6dF galaxy survey ([Beutler
et al. 2011](#bib.bib13)),
the SDSS Data Release 7 Main Galaxy sample ([Ross et al. 2015](#bib.bib47)), and the BOSS Data Release 12 ([Alam
et al. 2017b](#bib.bib5)).
The 6dF and SDSS Main analyses were based on the monopole of the anisotropic galaxy correlation function,
and therefore do not constrain $D\_{\rm M}/r\_{\rm s}$ and $cH^{-1}/r\_{\rm s}$ individually; rather, they constrain
the combination $D\_{\rm V}=[D\_{\rm M}^{2}czH^{-1}]^{1/3}$. Our BAO priors are listed in Table [1](#S2.T1 "Table 1 ‣ 2 Analysis ‣ Dark Energy Survey Year 1 Results: A Precise 𝑯_𝟎 Measurement from DES Y1, BAO, and 𝑫/𝑯 Data").

Our BBN priors are taken from the recent analysis by C16. Adopting
the CMB temperature of [Fixsen (2009)](#bib.bib26), C16 reports two separate constraints on $\Omega\_{\rm b}h^{2}$:
one obtained using a theoretical calculation for the $d(p\mathord{\mathchar 59\relax}\gamma)^{3}$He reaction rate, and one obtained using
experimental constraints for the same rate. The two results are discrepant at $3.5\sigma$.
We adopt a conservative prior that places the central value of
$\Omega\_{\rm b}h^{2}$ halfway between the two values reported in C16. The corresponding uncertainty
is set to half the difference between the two results. Our BBN prior is reported in Table [1](#S2.T1 "Table 1 ‣ 2 Analysis ‣ Dark Energy Survey Year 1 Results: A Precise 𝑯_𝟎 Measurement from DES Y1, BAO, and 𝑫/𝑯 Data").
We note that because of the mild sensitivity of the sound horizon $r\_{s}$ to the baryon density $\Omega\_{b}h^{2}$,
even a perfect measurement of $\Omega\_{b}h^{2}$ would not improve the posterior of our Hubble constant
measurement in any appreciable way.

| Prior or Data Set | Citation |
| --- | --- |
| $D\_{\rm V}(z=0.106)/r\_{\rm s}=3.047\pm 0.137$ | [Beutler et al. (2011)](#bib.bib13) |
| $D\_{\rm V}(z=0.15)/r\_{\rm s}=4.480\pm 0.168$ | [Ross et al. (2015)](#bib.bib47) |
| $D\_{\rm M}(z=0.38)r\_{\rm s\mathord{\mathchar 59\relax}fid}/r\_{\rm s}=1512\pm 24\ \mbox{Mpc}$ | [Alam et al. (2017b)](#bib.bib5) |
| $D\_{\rm M}(z=0.51)r\_{\rm s\mathord{\mathchar 59\relax}fid}/r\_{\rm s}=1975\pm 30\ \mbox{Mpc}$ | [Alam et al. (2017b)](#bib.bib5) |
| $D\_{\rm M}(z=0.61)r\_{\rm s\mathord{\mathchar 59\relax}fid}/r\_{\rm s}=2307\pm 37\ \mbox{Mpc}$ | [Alam et al. (2017b)](#bib.bib5) |
| $H(z=0.38)r\_{\rm s}/r\_{\rm s\mathord{\mathchar 59\relax}fid}=81.2\pm 2.4\ \mbox{km/s/Mpc}$ | [Alam et al. (2017b)](#bib.bib5) |
| $H(z=0.51)r\_{\rm s}/r\_{\rm s\mathord{\mathchar 59\relax}fid}=90.9\pm 2.4\ \mbox{km/s/Mpc}$ | [Alam et al. (2017b)](#bib.bib5) |
| $H(z=0.61)r\_{\rm s}/r\_{\rm s\mathord{\mathchar 59\relax}fid}=99.0\pm 2.5\ \mbox{km/s/Mpc}$ | [Alam et al. (2017b)](#bib.bib5) |
| $100\Omega\_{\rm b}h^{2}=2.208\pm 0.052$ | [Cooke et al. (2016)](#bib.bib15) |
| $T\_{\rm CMB}=2.7255\pm 0.0006\ \rm{K}$ | [Fixsen (2009)](#bib.bib26) |
| redMaGiC clustering | [Elvin-Poole et al. (2017)](#bib.bib24) |
| redMaGiC shear profiles | [Prat et al. (2017)](#bib.bib45) |
| Cosmic shear | [Troxel et al. (2017b)](#bib.bib50) |

Table 1: 
BAO and BBN priors, and DES data sets used in this analysis. The BOSS BAO priors report the
comoving angular distance and Hubble expansion relative to a fiducial sound horizon
$r\_{\rm s\mathord{\mathchar 59\relax}fid}=147.78\ \mbox{Mpc}$. In practice, our analysis uses the full covariance matrix
for the BAO measurements quoted above as reported in [Alam
et al. (2017a)](#bib.bib4) Table 8.
The parameter $D\_{\rm V}(z)$ is defined via $\equiv[D\_{\rm M}^{2}cH^{-1}]^{1/3}$.

Finally, we use the likelihood framework described in [Krause
et al. (2017)](#bib.bib37) to analyze the
clustering of redMaGiC galaxies ([Rozo
et al. 2016](#bib.bib48); [Elvin-Poole
et al. 2017](#bib.bib24)), the
shear profile around redMaGiC galaxies ([Prat
et al. 2017](#bib.bib45)), and the tomographic cosmic
shear signal in the DES Y1 data ([Troxel
et al. 2017b](#bib.bib50)). The shear profile and cosmic shear analyses
rely on the shape catalogs described in [Zuntz
et al. (2017)](#bib.bib54), and the photometric redshift
analyses in [Hoyle
et al. (2017)](#bib.bib36). The latter include extensive validation of photometric
redshift uncertainties via cross-correlation
methods ([Gatti
et al. 2017](#bib.bib31); [Davis
et al. 2017](#bib.bib16), Cawthon et al. in prep).
We refer the reader to these papers for a detailed
description of the likelihood, data vectors, and robustness and systematics checks of the
DES data. The entire framework was tested in simulations as described in MacCrann et al. (in preparation).
The DES priors employed and the
corresponding DES posteriors are presented in [DES
Collaboration (2017)](#bib.bib19).
Both the BBN and DES analyses were performed blind, with all analyses choices fixed
prior to revealing cosmological constraints ([DES
Collaboration 2017](#bib.bib19); [Cooke et al. 2016](#bib.bib15)).
There are also no parameter or configuration choices
made by us when performing this analysis: we are simply combining BBN, BAO, and DES data
as published.

## 3 Results and Consistency with External Data Sets

Unless otherwise noted, we adopt a flat $\Lambda$CDM model with neutrino masses fixed at
their minimal value of $\sum m\_{\nu}=0.06\ {\rm eV}$, as determined from neutrino
oscillation experiments (see [Lesgourgues &
Pastor 2006](#bib.bib38); [Olive
et al. 2014](#bib.bib43), for reviews).
$N\_{\mathrm{eff}}$ is also held at its expected
value $N\_{{\rm eff}}=3.046$. This is contrary to what was done in
[DES
Collaboration (2017)](#bib.bib19), where the neutrino mass was allowed to float by default.
Our goal here is to measure the Hubble rate with a combined DES+BAO+BBN analysis,
and explore consistency in measurements of the Hubble constant within the context
of this maximally restrictive cosmological model. We will, however,
demonstrate that letting the neutrino mass float has a minimal impact on our measurement
of the Hubble constant.

Unless otherwise noted, consistency between two data sets is evaluated as follows. Let $p$ be the vector of
model parameters shared between two experiments $A$ and $B$. We take $A$ and $B$
to be consistent with one another if the hypothesis $p\_{A}-p\_{B}=0$ is acceptable. Specifically,
for mutually independent experiments we calculate

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\chi^{2}=(p\_{A}-p\_{B})^{{\rm T}}C\_{{\rm tot}}^{-1}(p\_{A}-p\_{B})$ |  | (1) |

and compute the probability to exceed the observed value assuming the number of degrees of freedom
is equal to the number of shared parameters.
In the above expression, $C\_{{\rm tot}}=C\_{A}+C\_{B}$ is the expected
variance of the random variable $p\_{A}-p\_{B}$, with $C\_{A}$ and $C\_{B}$ being the covariance matrix of
the shared cosmological parameters. Both matrices are marginalized over any additional parameters
exclusive to each data set. We evaluate the Probability-To-Exceed (PTE) $P\_{\chi^{2}}$ of the recovered $\chi^{2}$ value,
and turn it into a Gaussian-$\sigma$ using the equation

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P\_{\chi^{2}}={\rm erf}\left(\frac{\mbox{No. of }\sigma}{\sqrt{2}}\right)$ |  | (2) |

With this definition, a probability
of $1-P\_{\chi^{2}}=68\%$ (95%) corresponds to $1\sigma$ ($2\sigma$) difference.
As a reminder, we have adopted $3\sigma$ difference (PTE=0.27%)
as our threshold for “evidence of tension,” and
$5\sigma$ ($\mbox{PTE}=5.96\times 10^{-7}$)
as “definitive evidence of tension.”

Figure [1](#S3.F1 "Figure 1 ‣ 3 Results and Consistency with External Data Sets ‣ Dark Energy Survey Year 1 Results: A Precise 𝑯_𝟎 Measurement from DES Y1, BAO, and 𝑫/𝑯 Data") shows the $\Omega\_{\rm m}$–$h$ degeneracy from the BAO+BBN
data (blue and purple ellipses).
Also shown are the corresponding constraints achieved by the DES Y1 analysis (solid curves).
The two are consistent with each other at $0.6\sigma$.
A joint analysis of these data sets (yellow and orange ellipses) results in

|  |  |  |  |
| --- | --- | --- | --- |
|  | $h=0.672^{+0.012}\_{-0.010}.$ |  | (3) |

Throughout, we quote the most likely $h$ value, and the error bars are set by the 68%
contour of the posterior.
This result is in excellent agreement with and has similar precision to
that of A17 ($h=0.674\pm 0.013$) obtained from combining our same BAO+BBN data set with
BAO measurements in the Ly-$\alpha$.

Figure 1: Constraints in the $\Omega\_{\rm m}$–$h$ plane from the DES and BAO+BBN data as labeled.
We have adopted a definition in which $\Omega\_{\rm m}$ includes the contribution from massive neutrinos.
All inner and outer contours enclose 68% and 95% of the posterior respectively.
Solid black lines show the DES $\Omega\_{m}$–$h$ degeneracy, while the blue and purple
contours show the BAO+BBN degeneracy. The DES+BAO+BBN contours are shown in yellow and orange.
For reference, we have also included the corresponding contours
for the Planck TT+lowP data set (see text).

We compare our posterior on $H\_{0}$ to constraints derived from four fully independent
datasets. These are:

* •

  Planck measurements of CMB anisotropies as probed by the
  temperature-temperature ($TT$) and low-$l$ polarization power spectra.
  The Planck TT+lowP data constrains $h$ when adopting a flat $\Lambda$CDM cosmology
  with minimal neutrino mass. Planck finds $h=0.673\pm 0.010$ ([Planck
  Collaboration 2015](#bib.bib44)).
* •

  SPTpol has measured anisotropies in the CMB via the TE and EE angular power spectra ([Henning
  et al. 2017](#bib.bib34)).
  In our fiducial cosmological model, they find $h=0.712\pm 0.021$.
* •

  The SH0ES collaboration constrains the Hubble parameter by using type-Ia supernovae as standard candles.
  They find $h=0.732\pm 0.017$ ([Riess
  et al. 2016](#bib.bib46)).
* •

  The H0LiCOW collaboration constrains the Hubble parameter by measuring the time delay between
  images of multiply-imaged quasars ([Bonvin
  et al. 2017](#bib.bib14)). They find $h=0.719^{+0.024}\_{-0.030}$.

A comparison of these various estimates of the Hubble rate and ours is shown
in Figure [2](#S3.F2 "Figure 2 ‣ 3 Results and Consistency with External Data Sets ‣ Dark Energy Survey Year 1 Results: A Precise 𝑯_𝟎 Measurement from DES Y1, BAO, and 𝑫/𝑯 Data").
All five measurements in Figure [2](#S3.F2 "Figure 2 ‣ 3 Results and Consistency with External Data Sets ‣ Dark Energy Survey Year 1 Results: A Precise 𝑯_𝟎 Measurement from DES Y1, BAO, and 𝑫/𝑯 Data") are effectively
statistically independent, and do not share observational systematics.
Note in particular that the Planck and SPTpol data sets rely on non-overlapping
$l$-ranges in the polarization spectra with minimal sky overlap (SPTpol covers only
a small fraction of the Planck sky).
While the SPTpol analysis does utilize a $\tau$ prior from Planck, the posterior on
$h$ is insensitive to this prior: the constraint on $h$ is sensitive to
the relative amplitudes and positions of the acoustic peaks, not their overall amplitude.
We have explicitly verified that the SPTpol posterior on $h$ does not change
when we relax the $\tau$ prior.
Finally, while the Planck data does contain some information on local structures due to
gravitational lensing,
the volume overlap with the BAO and DES data sets is minimal, both because Planck is all-sky, and
because the lensing kernel for the CMB peaks at $z\approx 2$.44
4
In principle, we could
remove lensing information from Planck by marginalizing over the so-called $A\_{L}$
parameter. Doing so increases the central value of the Planck constraint in $h$ from 0.673 to 0.689,
moving Planck towards the combined $h$ constraint found in this work.

Visually, the data points in Figure [2](#S3.F2 "Figure 2 ‣ 3 Results and Consistency with External Data Sets ‣ Dark Energy Survey Year 1 Results: A Precise 𝑯_𝟎 Measurement from DES Y1, BAO, and 𝑫/𝑯 Data") appear to be consistent with five independent
realizations of a single value.
We note that the two lowest $h$ values are the Planck and DES+BAO+BBN values.
A quick look at Figure [1](#S3.F1 "Figure 1 ‣ 3 Results and Consistency with External Data Sets ‣ Dark Energy Survey Year 1 Results: A Precise 𝑯_𝟎 Measurement from DES Y1, BAO, and 𝑫/𝑯 Data") makes it obvious that when combining
these two data sets, the resulting best-fit Hubble parameter is higher that that obtained
from either data set alone, improving the agreement with the remaining data sets.
A combined DES+BAO+BBN+Planck analysis yields $h=0.687\pm 0.005$, a
value higher than that of DES+BAO+BBN or Planck alone.55
5
Combining with Planck improves not just the constraints on $h$, but also other cosmological
parameters, particularly $\sigma\_{8}$ and $\Omega\_{m}$. Here, we focus exclusively on $h$, as this
is the key addition to the extended analysis presented in [DES
Collaboration (2017)](#bib.bib19).
Consistency between DES and Planck was established in [DES
Collaboration (2017)](#bib.bib19) using evidence
ratios. Using the method employed in this work, we again find the two data sets
to be consistent at $1.6\sigma$.

We test for the consistency of all five data sets as follows:
Planck and SPTpol provide precise measurements of $h$, $\Omega\_{m}$, $\Omega\_{b}$, $\sigma\_{8}$, and $n\_{s}$ (10 measurements).
DES+BAO+BBN measures these same parameters with the exception of $n\_{s}$, which is not well constrained by DES.
Thus, DES+BAO+BBN adds four independent measurements. Finally, SH0ES and H0LiCOW each measures $h$, for a total
of 16 measurements. These are modeled using a single set of cosmological parameters (5 parameters), resulting in 11 degrees
of freedom. We evaluate the $\chi^{2}$ of the best fit model to the full data vector of cosmological parameter estimates,
finding $\chi^{2}/dof=20.7/11$. The probability to exceed is $4\%$, a $2.1\sigma$ difference. We conclude that all five data sets are consistent
with each other.

We combine all five data sets to arrive at our best-fit Hubble parameter as follows.
First, we combine DES+BAO+BBN with Planck. We then
evaluate the combined DES+BAO+BBN+Planck+SPTpol likelihood
using importance sampling (see Appendix [A](#A1 "Appendix A Importance Sampling with Nuisance Parameters ‣ Dark Energy Survey Year 1 Results: A Precise 𝑯_𝟎 Measurement from DES Y1, BAO, and 𝑫/𝑯 Data") for details).
Finally, we follow a similar approach for incorporating the SH0ES and H0LiCOW constraints.66
6
Since we
do not have the H0LiCOW likelihood, we have symmetrized the error bars and adopted a Gaussian likelihood.
We do not expect this approximation has a large impact on the combined posterior.
Combining all five data sets, we arrive at $h=0.691^{+0.004}\_{-0.006}$.
This value is consistent with earlier efforts that combined CMB, SN, and BAO oscillation
data ([Gaztañaga et al. 2009](#bib.bib33)).

Of the five data sets we consider, the most discrepant $H\_{0}$ measurement is clearly that of the
SH0ES collaboration. As a naive estimate of the difference between SH0ES and the remaining data
sets, we combine all four non-SH0ES measurements to arrive at a best estimate of the Hubble parameter
($h=0.687^{+0.005}\_{-0.004}$).
The difference between this combined value and SH0ES is $2.5\sigma$.
This value fails to satisfy our criteria for evidence of tension.
Moreover, because we have five different independent measurements,
there is an important look-elsewhere effect. Properly estimating this
effect through brute force Monte Carlo realizations of each of the five independent
data sets
is numerically intractable. However, we can provide a rough estimate by
modeling the five measurements as independent Gaussian random draws of the same mean.
For each realization, we identify the random draw that is most discrepant
relative to the remaining four values. These four values are combined to form
a single best-estimate, and the difference between the combined result of the four
most consistent draws is compared to the remaining data point using our standard
test for consistency.
We perform $10^{5}$ realizations
of this numerical experiment, and determine that the probability of finding
a difference in excess of that observed between SH0ES and the remaining
data sets is 6% ($1.9\sigma$).
If we instead combine the DES+BAO+BBN with Planck and SPTpol, we arrive
at three independent $h$ measurements for which we can ignore the remaining cosmological
parameters. The $\chi^{2}$ of these 3 independent measurements is $\chi^{2}/dof=7.7/2$,
corresponding to a 2.1% probability to exceed ($2.3\sigma$). In principle, this difference is also
subject to a look elsewhere effect — we are focusing on $h$ precisely because of the Planck vs SH0ES comparison —
so the significance of this difference should be slightly reduced.

We have also explored the impact of floating the sum of the neutrino masses
in our analysis. The corresponding constraints are shown in Figure [2](#S3.F2 "Figure 2 ‣ 3 Results and Consistency with External Data Sets ‣ Dark Energy Survey Year 1 Results: A Precise 𝑯_𝟎 Measurement from DES Y1, BAO, and 𝑫/𝑯 Data"),
below the dashed line.
Opening up neutrino masses hardly impacts the recovered Hubble constant
for a DES+BAO+BBN analysis, as we would expect from the discussion in the introduction.
Because CMB anisotropies are degenerate in $h$ and $\sum m\_{\nu}$ — CMB observables
are roughly constant if one increases $\sum m\_{\nu}$ while decreasing $h$ —
allowing $\sum m\_{\nu}$ to float greatly increases the uncertainties in the recovered
Hubble rate from CMB experiments. In addition, because our fiducial model corresponds
to the lower limit of $\sum m\_{\nu}$, floating $\sum m\_{\nu}$ necessarily shifts $h$
towards lower values, as seen in Figure [2](#S3.F2 "Figure 2 ‣ 3 Results and Consistency with External Data Sets ‣ Dark Energy Survey Year 1 Results: A Precise 𝑯_𝟎 Measurement from DES Y1, BAO, and 𝑫/𝑯 Data").

The above shift is noteworthy within the broader cosmological context in that
massive neutrinos have been proposed as one way to bring the clustering amplitude
predicted from Planck in better agreement with low redshift measurements of $S\_{8}=\sigma\_{8}(\Omega\_{m}/0.3)^{1/2}$
([Wyman
et al. 2014](#bib.bib53), see e.g.). The idea is simple: neutrinos don’t
cluster at small scales, so increasing the fractional contribution of neutrinos to the
mass budget of the Universe decreases the predicted clustering amplitude of matter.
However, such a shift must be accompanied by a lowering of the Hubble rate in order to
hold CMB observables fixed. Doing so increases the difference between
distance-ladder estimates of the Hubble constant and the DES+CMB constraints.
That is, reducing differences in $S\_{8}$ come at the expense of increasing differences
in $H\_{0}$. Moreover, once we combine a CMB experiment with DES+BAO+BBN, the $\sum m\_{\nu}$–$h$ degeneracy
from CMB observables is broken, and our Hubble constant constraints snap back into place.
The posterior in $h$ when combining all five data sets while letting the neutrino mass float
is $h=0.689^{+0.004}\_{-0.006}$. Neutrino masses are also forced back towards their lower
limit: our posterior on the neutrino mass is $\sum m\_{\nu}<0.20\ {\rm eV}$ (95% CL).

Figure 2: Posteriors on the Hubble parameter $h$ from five independent
experiments, as labeled.
Constraints above the dashed line are obtained while
holding $\sum m\_{\nu}$ fixed, while the constraints below the line allow the
sum of the neutrino masses to float. In both cases, the red diamond is obtained by combining DES+BAO+BBN
with Planck. The shift in $h$ and the greatly reduced error bars for the combined
DES+BAO+BBN and Planck experiments reflect the
degeneracy breaking illustrated in Figure [1](#S3.F1 "Figure 1 ‣ 3 Results and Consistency with External Data Sets ‣ Dark Energy Survey Year 1 Results: A Precise 𝑯_𝟎 Measurement from DES Y1, BAO, and 𝑫/𝑯 Data").
The broadening and left-wards shift in the $h$ posterior from CMB experiments
reflects the degeneracy between $\sum m\_{\nu}$ and $h$ in CMB observables (see text for
further discussion).
We emphasize that once this degeneracy is broken, all the constraints snap back into
place. The cyan and yellow bands show
the $68\%$ confidence region obtained when combining all five data sets for each of the
two analysis (fixed and free $\sum m\_{\nu}$). The five experiments above are
statistically independent of each other, and share no common observational systematics.
Combining all five data sets, we arrive at $h=0.691^{+0.004}\_{-0.006}$ (fixed neutrino mass)
or $h=0.689^{+0.004}\_{-0.006}$ (free neutrino mass).

|  |  |  |
| --- | --- | --- |
| $h$ | Data Set | Citation |
| $0.672^{+0.012}\_{-0.010}$ | DES+BAO+BBN | This work |
| $0.673\pm 0.010$ | Planck | [Planck Collaboration (2015)](#bib.bib44) |
| $0.712\pm 0.021$ | SPTpol | [Henning et al. (2017)](#bib.bib34) |
| $0.732\pm 0.017$ | SH0ES | [Riess et al. (2016)](#bib.bib46) |
| $0.719^{+0.024}\_{-0.030}$ | H0LiCOW | [Bonvin et al. (2017)](#bib.bib14) |
| $h=0.691^{+0.004}\_{-0.006}$ | Combined | This work |
| $h=0.677^{+0.012}\_{-0.012}$ | DES+BAO+BBN ($\sum m\_{\nu}$ free) | This work |
| $h=0.689^{+0.004}\_{-0.006}$ | Combined ($\sum m\_{\nu}$ free) | This work |

Table 2: 
Hubble parameter $h$ from the 5 independent data sets considered in this work,
along with the best fit estimate coming from combining all data sets.
All data sets are mutually statistically independent, and there are no shared
sources of observational systematics between them. Our fiducial analysis
holds $\sum m\_{\nu}=0.06\ {\rm eV}$, but we also report results obtained by
marginalizing over $\sum m\_{\nu}$.

## 4 Discussion

Our combined DES+BAO+BBN analysis is similar
in spirit to that of A17. In particular,
whereas we break the $\Omega\_{m}$–$h$ degeneracy inherent to a BAO+BBN measurement using DES data,
they break it using Ly-$\alpha$-BAO data to find
$h=0.674\pm 0.013$, in perfect agreement with the earlier result by
[Aubourg
et al. (2015)](#bib.bib8).77
7
We averaged the two reported values from Table 3 in A17,
adding in quadrature half the difference between the two central values to the statistical error bar.
We can directly incorporate Ly-$\alpha$-BAO in our analysis using the
Ly-$\alpha$$\times$Ly-$\alpha$ measurements of [Bautista
et al. (2017)](#bib.bib9) and the
Ly-$\alpha$$\times$QSO measurements of [du Mas des
Bourboux et al. (2017)](#bib.bib23). These results are summarized
in the latter work as

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle cH^{-1}(z=2.40)/r\_{\rm s}$ | $\displaystyle=$ | $\displaystyle 8.94\pm 0.22$ |  | (4) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle D\_{\rm M}(z=2.40)/r\_{\rm s}$ | $\displaystyle=$ | $\displaystyle 36.6\pm 1.2.$ |  | (5) |

The difference between these values and the galaxy BAO measurements is $2.4\sigma$,
increasing do $2.8\sigma$ when the DES data is added to the BAO.
The addition of the Ly-$\alpha$ data has a minimal impact on our constraints, resulting
in a posterior $h=0.674^{+0.011}\_{-0.010}$.
In principle, we could also add the recent BAO result of [Ata
et al. (2017)](#bib.bib7),
who used quasars from the eBOSS experiment to constrain the spherically
averaged distance to $z=1.52$, but the lower precision
of this early eBOSS result will have no significant impact on our results.

Our DES+BAO+BBN analysis is also qualitatively similar to the inverse distance ladder approach
presented in [Aubourg
et al. (2015)](#bib.bib8), though the underlying motivation for the analysis is rather
different. In [Aubourg
et al. (2015)](#bib.bib8), the sound horizon scale $r\_{\rm s}$ was calibrated using CMB data.
With $r\_{\rm s}$ in hand, [Aubourg
et al. (2015)](#bib.bib8) used BAO to measure the comoving angular diameter distance
to redshift $z=0.57$, which was in turn used to calibrate the absolute magnitude of type Ia supernova.
This, in turn, allowed [Aubourg
et al. (2015)](#bib.bib8) to use the Joint-Lightcurve Analysis (JLA) data set
of [Betoule
et al. (2014)](#bib.bib12) to measure the local Hubble parameter directly.

Compared to our analysis, the inverse distance ladder approach has the significant benefit of being
less model dependent: the local Hubble rate is measured directly in much
the same way as in the work from the SH0ES collaboration, only now the
absolute magnitude calibration of the supernova
is based on BAO measurements at cosmological distances.

By contrast, while our DES+BAO+BBN analysis is clearly
model dependent — we have explicitly assumed
a flat $\Lambda$CDM model with minimal neutrino mass — the resulting constraint on $h$ is completely
independent of both CMB anisotropies and supernova data.
Consequently, relative to the inverse distance-ladder, we view our analysis as a cleaner test of
observational systematics within the specific context of a flat $\Lambda$CDM model.

Broadly speaking, our results and conclusions mirror and update those of [Bennett et al. (2014)](#bib.bib10), who
pursued a similar examination to that of this work. Like us, they find no significant evidence
of tension in Hubble constant measurements, reaching a consensus value from WMAP, BAO, and SN
data of $H\_{0}=69.6\pm 0.7\ \mbox{km/s/Mpc}$. This is to be compared to our own result
of $H\_{0}=69.1^{+0.4}\_{-0.6}\ \mbox{km/s/Mpc}$. The agreement between the two values is remarkable,
particularly given the various data updates, including Planck 2015 results for WMAP,
the addition of SPTpol and DES data, and updated SN constraints.

As this paper was being completed, a similar paper appeared on the arXiv ([Lin &
Ishak 2017](#bib.bib40)).
That work compares five different estimates of $H\_{0}$: Planck, SH0ES, H0LiCOW, and two more:
one from BAO+BBN in conjunction with supernova, and one due to a broad variety of large scale structure
measurements, including several BAO data sets, redshift space distortion analyses, cosmic shear, and
cluster abundance data. Relative to the analysis in [Lin &
Ishak (2017)](#bib.bib40),
our analysis benefits from the fact that all the
probes we consider are clearly statistically independent and share no common systematics.
While our conclusions
are superficially different, we agree with their basic result: the most discrepant outlier
in our collection of $H\_{0}$ measurements is the local $H\_{0}$ measurement from SH0ES.
Our reduced estimate of the significance of this difference incorporates the
look-elsewhere effects present in these type of analyses.

## 5 Summary

The combination of BAO+BBN produces a tight degeneracy between $\Omega\_{\rm m}$ and
$h$ ([Aubourg
et al. 2015](#bib.bib8)).
Any independent probe of $\Omega\_{\rm m}$ can effectively break this degeneracy, enabling a direct
measurement of the Hubble parameter that is fully independent of local $H\_{0}$ measurements and
CMB anisotropies. Constraints on the matter density from lensing analyses is an especially
attractive way of breaking this degeneracy: these constraints
are sensitive to dark matter via its inhomogeneities rather than through
its impact on the expansion history.
In that sense, they enable a holistic test of the Big Bang theory
that probes not just the expanding Universe framework, but also our understanding of
density perturbations in the Universe.

We have used the recent DES Y1 data set ([Drlica-Wagner
et al. 2017](#bib.bib22); [Zuntz
et al. 2017](#bib.bib54))
to place a precise measurement
of the Hubble constant by combining it with BAO and BBN data.
We find $H\_{0}=67.3^{+1.1}\_{-1.2}\ \mbox{km/s/Mpc}$.
Our result is in $2.8\sigma$ difference with Ly-$\alpha$ BAO measurements, though the
combined galaxy and Ly-$\alpha$ BAO measurement is in good agreement with DES. Adding Ly-$\alpha$-BAO data to
our DES+BAO+BBN measurement has minimal impact on our results. While our fiducial
analysis holds the sum of neutrino masses fixed, marginalizing over neutrino mass does
not significantly relax our constraint on the Hubble constant.

We have compared our measurement of $H\_{0}$ to four additional experimental values
of comparable precision: Planck TT+lowP measurements of $H\_{0}$ assuming a flat $\Lambda$CDM
model of minimal neutrino mass; SPTpol measurements of $H\_{0}$ in the same cosmological model;
the local supernovae-based distance ladder measurement of $H\_{0}$ from the SH0ES collaboration
([Riess
et al. 2016](#bib.bib46));
and the H0LiCOW measurement using multiply imaged quasars from [Bonvin
et al. (2017)](#bib.bib14).
All five measurements are mutually statistically independent of each other,
and there are no shared observational systematics between them.
Amongst these five, the most discrepant data set is that of the SH0ES collaboration, which
is in $2.5\sigma$ difference with the remaining four experiments. We estimate the probability
of finding a fluctuation this large or larger in a set of five independent measurements to be 6%,
a $1.9\sigma$ fluctuation. Viewed in this broader context, the $H\_{0}$ value from the SH0ES collaboration
does not appear to be especially problematic.

Importantly, all $H\_{0}$ measurements used in this work are expected to improve in precision
in the coming years. Future CMB experiments like Advanced ACTPol ([De Bernardis
et al. 2016](#bib.bib18)),
SPT-3G ([Benson
et al. 2014](#bib.bib11)),
and CMB-S4 ([Abitbol
et al. 2017](#bib.bib2)) will survey an order of magnitude more sky area with factors of several
lower noise than SPTpol. By resolving the acoustic oscillations in the damping tail in the
polarization power spectra of the CMB, these experiments will eventually surpass Planck in
terms of their ability to constraint cosmological parameters, including $h$ ([Galli
et al. 2014](#bib.bib30)).
Likewise, the DES survey area will more than triple while doubling the integrated
exposure per galaxy. Future surveys like the LSST ([LSST Science
Collaboration. 2009](#bib.bib41))
will further improve upon the DES five year constraints. BAO constraints from
eBOSS ([Dawson
et al. 2016](#bib.bib17))
will increase the galaxy BAO measurements to redshifts $z\sim 1$, only to be surpassed
by DESI ([DESI
Collaboration 2016a](#bib.bib20); [DESI
Collaboration 2016b](#bib.bib21)) on a few years time scale. Local $H\_{0}$ measurements will improve with improved distance
calibration from Gaia ([Gaia
Collaboration 2016](#bib.bib29)), and innovative techniques such as using the tip of the
red giant branch to build the distance ladder ([Freedman 2017](#bib.bib27)).
Finally, continued monitoring and improved
lens modeling techniques will further reduce the uncertainty of strong-lens estimates of $H\_{0}$.
Together, these improvements. along with new measurements from gravitational wave events ([Abbott
et al. 2017](#bib.bib1)),
will lead to ever more stringent tests of the Big Bang model and the currently standard flat $\Lambda$CDM model
across its full 13.8 billion year history.

Acknowledgements: This paper has gone through internal review by the DES collaboration.
ER is supported by DOE grant DE-SC0015975 and by the Sloan Foundation, grant FG-2016-6443. YP is
supported by DOE grant DE-SC0015975.
Funding for the DES Projects has been provided by the U.S. Department of Energy, the U.S. National Science Foundation, the Ministry of Science and Education of Spain,
the Science and Technology Facilities Council of the United Kingdom, the Higher Education Funding Council for England, the National Center for Supercomputing
Applications at the University of Illinois at Urbana-Champaign, the Kavli Institute of Cosmological Physics at the University of Chicago,
the Center for Cosmology and Astro-Particle Physics at the Ohio State University,
the Mitchell Institute for Fundamental Physics and Astronomy at Texas A&M University, Financiadora de Estudos e Projetos,
Fundação Carlos Chagas Filho de Amparo à Pesquisa do Estado do Rio de Janeiro, Conselho Nacional de Desenvolvimento Científico e Tecnológico and
the Ministério da Ciência, Tecnologia e Inovação, the Deutsche Forschungsgemeinschaft and the Collaborating Institutions in the Dark Energy Survey.

The Collaborating Institutions are Argonne National Laboratory, the University of California at Santa Cruz, the University of Cambridge, Centro de Investigaciones Energéticas,
Medioambientales y Tecnológicas-Madrid, the University of Chicago, University College London, the DES-Brazil Consortium, the University of Edinburgh,
the Eidgenössische Technische Hochschule (ETH) Zürich,
Fermi National Accelerator Laboratory, the University of Illinois at Urbana-Champaign, the Institut de Ciències de l’Espai (IEEC/CSIC),
the Institut de Física d’Altes Energies, Lawrence Berkeley National Laboratory, the Ludwig-Maximilians Universität München and the associated Excellence Cluster Universe,
the University of Michigan, the National Optical Astronomy Observatory, the University of Nottingham, The Ohio State University, the University of Pennsylvania, the University of Portsmouth,
SLAC National Accelerator Laboratory, Stanford University, the University of Sussex, Texas A&M University, and the OzDES Membership Consortium.

Based in part on observations at Cerro Tololo Inter-American Observatory, National Optical Astronomy Observatory, which is operated by the Association of
Universities for Research in Astronomy (AURA) under a cooperative agreement with the National Science Foundation.

The DES data management system is supported by the National Science Foundation under Grant Numbers AST-1138766 and AST-1536171.
The DES participants from Spanish institutions are partially supported by MINECO under grants AYA2015-71825, ESP2015-66861, FPA2015-68048, SEV-2016-0588, SEV-2016-0597, and MDM-2015-0509,
some of which include ERDF funds from the European Union. IFAE is partially funded by the CERCA program of the Generalitat de Catalunya.
Research leading to these results has received funding from the European Research
Council under the European Union’s Seventh Framework Program (FP7/2007-2013) including ERC grant agreements 240672, 291329, and 306478.
We acknowledge support from the Australian Research Council Centre of Excellence for All-sky Astrophysics (CAASTRO), through project number CE110001020.

The South Pole Telescope program is supported by the National Science Foundation through grant PLR-1248097. Partial support is also provided by the NSF Physics Frontier Center grant PHY-0114422 to the Kavli Institute of Cosmological Physics at the University of Chicago, the Kavli Foundation, and the Gordon and Betty Moore Foundation through Grant GBMF#947 to the University of Chicago.

This manuscript has been authored by Fermi Research Alliance, LLC under Contract No. DE-AC02-07CH11359 with the U.S. Department of Energy, Office of Science, Office of High Energy Physics. The United States Government retains and the publisher, by accepting the article for publication, acknowledges that the United States Government retains a non-exclusive, paid-up, irrevocable, world-wide license to publish or reproduce the published form of this manuscript, or allow others to do so, for United States Government purposes.

## Appendix A Importance Sampling with Nuisance Parameters

The SPTpol likelihood was written as a CosmoMC ([Lewis &
Bridle 2002](#bib.bib39)) module,
whereas the DES likelihood was written as a CosmoSIS ([Zuntz et al. 2015](#bib.bib55)) module.
This difference makes it difficult to run a combined chain. Consequently, we rely on importance sampling,
evaluating the SPTpol likelihood at each of the links of the DES+BAO+BBN+Planck chains.
However, the SPTpol likelihood includes
several nuisance parameters, including two which are not prior dominated:
$A\_{80}^{\mathrm{EE}}$, the EE dust amplitude; and $D\_{3000}^{\mathrm{PS\_{EE}}}$, the EE Poisson foreground amplitude.
One must correctly account for these nuisance
parameters in the calculation. We describe how we do so here.

Consider two experiments $A$ and $B$. The two experiments share a set of parameters $p$,
but each experiment additionally
contains a set of nuisance parameters exclusive to itself, namely $q\_{A}$ and $q\_{B}$.
Given an arbitrary function $f(p\mathchar 59\relax q\_{A}\mathchar 59\relax q\_{B})$, we wish to be
able to evaluate

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\left\langle f\right\rangle$ | $\displaystyle=$ | $\displaystyle\int dpdq\_{A}dq\_{B}\ \mbox{$\cal{L}$}\_{A}(p\mathord{\mathchar 59\relax}q\_{A})\mbox{$\cal{L}$}\_{B}(p\mathord{\mathchar 59\relax}q\_{B})$ |  | (6) |
|  |  |  | $\displaystyle\quad\quad\times P\_{0}(p)P\_{0}(q\_{A})P\_{0}(q\_{B})f(p\mathord{\mathchar 59\relax}q\_{A}\mathord{\mathchar 59\relax}q\_{B})\mathchar 59\relax$ |  |

Where $\mbox{$\cal{L}$}\_{X}$ is the likelihood for experiment $X$ and $P\_{0}$ represents the priors for different parameter sets. We assume here that the experiments are independent of each other, and that the priors on $p$, $q\_{A}$, and $q\_{B}$ are separable.

We wish to importance sample MCMC results from experiment A using the likelihood from experiment B.
In order to efficiently sample the parameter space spanned by $q\_{B}$, we multiply and divide the integrand by
$G(q\_{B})$ where $G$ is a probability distribution chosen to be
wider than the posterior of $q\_{B}$ (as estimated from the chains of experiment $B$ alone). We can rewrite
the above expression as

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\left\langle f\right\rangle$ | $\displaystyle=$ | $\displaystyle\int dpdq\_{A}dq\_{B}\ \left[\mbox{$\cal{L}$}\_{A}(p\mathord{\mathchar 59\relax}q\_{A})P\_{0}(p)P\_{0}(q\_{A})P\_{0}(q\_{B})G(q\_{B})\right]$ |  | (7) |
|  |  |  | $\displaystyle\quad\quad\times\left[\frac{\mbox{$\cal{L}$}\_{B}(p\mathord{\mathchar 59\relax}q\_{B})}{G(q\_{B})}f(p\mathord{\mathchar 59\relax}q\_{A}\mathord{\mathchar 59\relax}q\_{B})\right]$ |  |
|  |  | $\displaystyle=$ | $\displaystyle\left\langle\frac{\mbox{$\cal{L}$}\_{B}}{G}f\right\rangle\_{A}$ |  |

where the last expectation value refers to evaluating the expectation value of the function $f\mbox{$\cal{L}$}\_{B}/G$ over
the distribution $\mbox{$\cal{L}$}\_{A}(p\mathord{\mathchar 59\relax}q\_{A})P\_{0}(p)P\_{0}(q\_{A})P\_{0}(q\_{B})G(q\_{B})$. Note this distribution is
separable in $(p\mathord{\mathchar 59\relax}q\_{A})$, and $q\_{B}$. Random draws
from $\mbox{$\cal{L}$}\_{A}(p\mathord{\mathchar 59\relax}q\_{A})P\_{0}(p)P\_{0}(q\_{A})$ are given by the chain from experiment $A$, while we can readily sample from the
distribution $P\_{0}(q\_{B})G(q\_{B})$.
To decrease the numerical noise of the integration over the nuisance parameters,
we sample 20 different sets of $q\_{B}$ values for each link in $p$. We found this was sufficient
to achieve good convergence, and explicitly tested using chains with both half as many points,
and twice as many points.

In short, to importance sample the SPTpol likelihood, we first oversample the DES chain according to the weights.
For each link, we assign nuisance parameters for SPTpol by randomly drawing from the distribution
$P\_{0}(q\_{B})G(q\_{B})$. Each link is then assigned a weight of $\mbox{$\cal{L}$}\_{B}/G$.

Finally, to achieve more efficient sampling of the posterior of the combined DES+BAO+BBN+Planck+SPTpol chain,
we further modified our method as follows. First, we used the SPTpol chain to compute the parameter covariance
matrix. We use this to define a Gaussian approximation $G\_{{\rm SPT}}$ to the SPT likelihood. This Gaussian
approximation is then included in the DES+BAO+BBN+Planck chain, and the assigned weight to each link
becomes $\mbox{$\cal{L}$}\_{{\rm SPT}}/(G\times G\_{\rm SPT})$.

## Affiliations

1 Cerro Tololo Inter-American Observatory, National Optical Astronomy Observatory, Casilla 603, La Serena, Chile
  
2 Department of Physics and Electronics, Rhodes University, PO Box 94, Grahamstown, 6140, South Africa
  
3 Department of Physics & Astronomy, University College London, Gower Street, London, WC1E 6BT, UK
  
4 Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
5 LSST, 933 North Cherry Avenue, Tucson, AZ 85721, USA
  
6 Department of Astronomy and Astrophysics, University of Chicago, Chicago, IL 60637, USA
  
7 Kavli Institute for Cosmological Physics, University of Chicago, Chicago, IL 60637, USA
  
8 Observatories of the Carnegie Institution of Washington, 813 Santa Barbara St., Pasadena, CA 91101, USA
  
9 Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
10 CNRS, UMR 7095, Institut d’Astrophysique de Paris, F-75014, Paris, France
  
11 Sorbonne Universités, UPMC Univ Paris 06, UMR 7095, Institut d’Astrophysique de Paris, F-75014, Paris, France
  
12 Kavli Institute for Particle Astrophysics & Cosmology, P. O. Box 2450, Stanford University, Stanford, CA 94305, USA
  
13 SLAC National Accelerator Laboratory, Menlo Park, CA 94025, USA
  
14 Observatório Nacional, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
  
15 Laboratório Interinstitucional de e-Astronomia - LIneA, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
  
16 Department of Astronomy, University of Illinois, 1002 W. Green Street, Urbana, IL 61801, USA
  
17 National Center for Supercomputing Applications, 1205 West Clark St., Urbana, IL 61801, USA
  
18 Institut de Física d’Altes Energies (IFAE), The Barcelona Institute of Science and Technology, Campus UAB, 08193 Bellaterra (Barcelona) Spain
  
19 Institute of Space Sciences, IEEC-CSIC, Campus UAB, Carrer de Can Magrans, s/n, 08193 Barcelona, Spain
  
20 High Energy Physics Division, Argonne National Laboratory, 9700 S. Cass Avenue, Argonne, IL 60439, USA
  
21 Department of Physics, IIT Hyderabad, Kandi, Telangana 502285, India
  
22 Faculty of Physics, Ludwig-Maximilians-Universität, Scheinerstr. 1, 81679 Munich, Germany
  
23 Excellence Cluster Universe, Boltzmannstr. 2, 85748 Garching, Germany
  
24 Department of Astronomy, University of Michigan, Ann Arbor, MI 48109, USA
  
25 Department of Physics, University of Michigan, Ann Arbor, MI 48109, USA
  
26 Instituto de Fisica Teorica UAM/CSIC, Universidad Autonoma de Madrid, 28049 Madrid, Spain
  
27 Universitäts-Sternwarte, Fakultät für Physik, Ludwig-Maximilians Universität München, Scheinerstr. 1, 81679 München, Germany
  
28 Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, UK
  
29 Kavli Institute for Cosmology, University of Cambridge, Madingley Road, Cambridge CB3 0HA, UK
  
30 Department of Physics, ETH Zurich, Wolfgang-Pauli-Strasse 16, CH-8093 Zurich, Switzerland
  
31 Department of Physics, The Ohio State University, Columbus, OH 43210, USA
  
32 Center for Cosmology and Astro-Particle Physics, The Ohio State University, Columbus, OH 43210, USA
  
33 Max Planck Institute for Extraterrestrial Physics, Giessenbachstrasse, 85748 Garching, Germany
  
34 Astronomy Department, University of Washington, Box 351580, Seattle, WA 98195, USA
  
35 Santa Cruz Institute for Particle Physics, Santa Cruz, CA 95064, USA
  
36 Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Dr., Pasadena, CA 91109, USA
  
37 Australian Astronomical Observatory, North Ryde, NSW 2113, Australia
  
38 Argonne National Laboratory, 9700 South Cass Avenue, Lemont, IL 60439, USA
  
39 Institute for Astronomy, University of Edinburgh, Edinburgh EH9 3HJ, UK
  
40 Departamento de Física Matemática, Instituto de Física, Universidade de São Paulo, CP 66318, São Paulo, SP, 05314-970, Brazil
  
41 Institut d’Astrophysique de Paris, F-75014, Paris, France
  
42 George P. and Cynthia Woods Mitchell Institute for Fundamental Physics and Astronomy, and Department of Physics and Astronomy, Texas A&M University, College Station, TX 77843, USA
  
43 Institució Catalana de Recerca i Estudis Avançats, E-08010 Barcelona, Spain
  
44 Dunlap Institute for Astronomy and Astrophysics, University of Toronto, 50 St George St, Toronto, ON, M5S 3H4, Canada
  
45 Lawrence Berkeley National Laboratory, 1 Cyclotron Road, Berkeley, CA 94720, USA
  
46 Department of Physics, University of Arizona, Tucson, AZ 85721, USA
  
47 School of Physics, University of Melbourne, Parkville, VIC 3010, Australia
  
48 Centro de Investigaciones Energéticas, Medioambientales y Tecnológicas (CIEMAT), Madrid, Spain
  
49 School of Physics and Astronomy, University of Southampton, Southampton, SO17 1BJ, UK
  
50 Instituto de Física Gleb Wataghin, Universidade Estadual de Campinas, 13083-859, Campinas, SP, Brazil
  
51 Computer Science and Mathematics Division, Oak Ridge National Laboratory, Oak Ridge, TN 37831
  
52 Institute of Cosmology & Gravitation, University of Portsmouth, Portsmouth, PO1 3FX, UK
  
53 Department of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305, USA
