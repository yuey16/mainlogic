<!-- fulltext source=arxiv_html slug=arXiv-1004.2595 fetched=2026-09-18T01:18:17+00:00 -->

# Planck pre-launch status: High Frequency Instrument polarization calibration

C. Rosset
Affiliation: LAL, Laboratoire de l’Accélerateur Linéaire, CNRS Université Paris 11, Bâtiment 200, Orsay, France
Affiliation: APC, Astroparticule et Cosmologie, Université
Paris Diderot, Bâtiment Condorcet, 10 rue Alice Domon et Léonie
Duquet, F-75205 Paris Cedex 13, France
  
M. Tristram
Affiliation: LAL, Laboratoire de l’Accélerateur Linéaire, CNRS Université Paris 11, Bâtiment 200, Orsay, France
  
N. Ponthieu
Affiliation: IAS, Institut d’Astrophysique Spatiale, CNRS Université Paris 11, Bâtiment 121, 91405 Orsay, France
  
P. Ade
Affiliation: Astronomy and Instrumentation Group, Cardiff University, Cardiff, Wales
  
A. Catalano
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, 75014 Paris, France
Affiliation: APC, Astroparticule et Cosmologie, Université
Paris Diderot, Bâtiment Condorcet, 10 rue Alice Domon et Léonie
Duquet, F-75205 Paris Cedex 13, France
  
L. Conversi
Affiliation: European Space Astronomy Centre, P.O.Box 78, 28691 Villanueava de la Cañada (Madrid), Spain
  
F. Couchot
Affiliation: LAL, Laboratoire de l’Accélerateur Linéaire, CNRS Université Paris 11, Bâtiment 200, Orsay, France
  
B. P. Crill
Affiliation: Observational Cosmology, California Institute of Technology, Mail code:367-17, Pasadena, CA 91125, USA
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, Pasadena, CA 91109, USA
  
F.-X. Désert
Affiliation: LAOG, Laboratoire d’Astrophysique Observatoire de Grenoble, CNRS, Grenoble, France
  
K. Ganga
Affiliation: APC, Astroparticule et Cosmologie, Université
Paris Diderot, Bâtiment Condorcet, 10 rue Alice Domon et Léonie
Duquet, F-75205 Paris Cedex 13, France
  
M. Giard
Affiliation: CESR, CNRS, 9 av. du colonel Roche, BP44346, 31038 Toulouse Cedex 4, France
  
Y. Giraud-Héraud
Affiliation: APC, Astroparticule et Cosmologie, Université
Paris Diderot, Bâtiment Condorcet, 10 rue Alice Domon et Léonie
Duquet, F-75205 Paris Cedex 13, France
  
J. Haïssinski
Affiliation: LAL, Laboratoire de l’Accélerateur Linéaire, CNRS Université Paris 11, Bâtiment 200, Orsay, France
  
S. Henrot-Versillé
Affiliation: LAL, Laboratoire de l’Accélerateur Linéaire, CNRS Université Paris 11, Bâtiment 200, Orsay, France
  
W. Holmes
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, Pasadena, CA 91109, USA
  
W. C. Jones
Affiliation: Observational Cosmology, California Institute of Technology, Mail code:367-17, Pasadena, CA 91125, USA
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, Pasadena, CA 91109, USA
Affiliation: Department of Physics, Princeton University, Princeton, NJ 08544
  
J.-M. Lamarre
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, 75014 Paris, France
  
A. Lange†
Affiliation: Observational Cosmology, California Institute of Technology, Mail code:367-17, Pasadena, CA 91125, USA
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, Pasadena, CA 91109, USA
  
C. Leroy
Affiliation: IAS, Institut d’Astrophysique Spatiale, CNRS Université Paris 11, Bâtiment 121, 91405 Orsay, France
Affiliation: CESR, CNRS, 9 av. du colonel Roche, BP44346, 31038 Toulouse Cedex 4, France
  
J. Macías-Pérez
Affiliation: LAOG, Laboratoire d’Astrophysique Observatoire de Grenoble, CNRS, Grenoble, France
  
B. Maffei
Affiliation: The University of Manchester, JCBA, School of Physics and Astronomy, Manchester M13 9PL, UK
  
P. de Marcillac
Affiliation: IAS, Institut d’Astrophysique Spatiale, CNRS Université Paris 11, Bâtiment 121, 91405 Orsay, France
  
M.-A. Miville-Deschênes
Affiliation: IAS, Institut d’Astrophysique Spatiale, CNRS Université Paris 11, Bâtiment 121, 91405 Orsay, France
  
L. Montier
Affiliation: CESR, CNRS, 9 av. du colonel Roche, BP44346, 31038 Toulouse Cedex 4, France
  
F. Noviello
Affiliation: IAS, Institut d’Astrophysique Spatiale, CNRS Université Paris 11, Bâtiment 121, 91405 Orsay, France
  
F. Pajot
Affiliation: IAS, Institut d’Astrophysique Spatiale, CNRS Université Paris 11, Bâtiment 121, 91405 Orsay, France
  
O. Perdereau
Affiliation: LAL, Laboratoire de l’Accélerateur Linéaire, CNRS Université Paris 11, Bâtiment 200, Orsay, France
  
F. Piacentini
Affiliation: Dipartimento di Fisica, Universitá di Roma “La Sapienza”, 00185 Roma, Italy
  
M. Piat
Affiliation: APC, Astroparticule et Cosmologie, Université
Paris Diderot, Bâtiment Condorcet, 10 rue Alice Domon et Léonie
Duquet, F-75205 Paris Cedex 13, France
  
S. Plaszczynski
Affiliation: LAL, Laboratoire de l’Accélerateur Linéaire, CNRS Université Paris 11, Bâtiment 200, Orsay, France
  
E. Pointecouteau
Affiliation: CESR, CNRS, 9 av. du colonel Roche, BP44346, 31038 Toulouse Cedex 4, France
  
J.-L. Puget
Affiliation: IAS, Institut d’Astrophysique Spatiale, CNRS Université Paris 11, Bâtiment 121, 91405 Orsay, France
  
I. Ristorcelli
Affiliation: CESR, CNRS, 9 av. du colonel Roche, BP44346, 31038 Toulouse Cedex 4, France
  
G. Savini
Affiliation: Astronomy and Instrumentation Group, Cardiff University, Cardiff, Wales
Affiliation: Optical Science Laboratory, University College London, Gower Street, WC1E 6BT London, UK
  
R. Sudiwala
Affiliation: Astronomy and Instrumentation Group, Cardiff University, Cardiff, Wales
  
M. Veneziani
Affiliation: APC, Astroparticule et Cosmologie, Université
Paris Diderot, Bâtiment Condorcet, 10 rue Alice Domon et Léonie
Duquet, F-75205 Paris Cedex 13, France
Affiliation: Dipartimento di Fisica, Universitá di Roma “La Sapienza”, 00185 Roma, Italy
  
D. Yvon
Affiliation: CEA, Service de Physique des Particules, Saclay, France

Affiliation: LPSC, Laboratoire de Physique Subatomique et Cosmologie, CNRS, Grenoble, France

Accepted April, 7${}^{\mbox{\tiny th}}$ 2010

###### Abstract

The High Frequency Instrument of Planck will map the entire sky in the
millimeter and sub-millimeter domain from 100 to 857 GHz with
unprecedented sensitivity to polarization ($\Delta P/T\_{\mbox{\tiny cmb}}\sim 4\cdot 10^{-6}$ for $P$ either $Q$ or $U$ and $T\_{\mbox{\tiny cmb}}\simeq 2.7\,$K) at 100, 143, 217 and 353 GHz. It
will lead to major improvements in our understanding of the Cosmic Microwave Background
anisotropies and polarized foreground signals. Planck will
make high resolution measurements of the $E$-mode spectrum (up to $\ell\sim 1500$) and will also play a prominent role in the search for
the faint imprint of primordial gravitational waves on
the CMB polarization.
  
This paper addresses the effects of calibration of both temperature
(gain) and polarization (polarization efficiency and detector
orientation) on polarization measurements. The specific requirements
on the polarization parameters of the instrument are set and we
report on their pre-flight measurement on HFI bolometers.
  
We present a semi-analytical method that exactly accounts for the
scanning strategy of the instrument as well as the combination of
different detectors. We use this method to propagate errors through
to the CMB angular power spectra in the particular case of Planck-HFI,
and to derive constraints on polarization parameters.
  
We show that in order to limit the systematic error to 10% of the
cosmic variance of the $E$-mode power spectrum, uncertainties in gain,
polarization efficiency and detector orientation must be below 0.15%,
0.3% and 1∘ respectively. Pre-launch ground measurements reported
in this paper already fulfill these requirements.

## 1 Introduction

The Planck satellite, launched on May 14th, 2009, will map the whole
sky in the range 30–857 GHz. One of the most exciting challenges for
Planck is to measure the polarization anisotropies of the Cosmic
Microwave Background (CMB), which offers a unique way to constrain the
energy scale of inflation.

CMB polarization can be decomposed into modes of even-parity
($E$-mode) and odd-parity ($B$-mode). Gravitational waves generated
during inflation (hereafter “primordial” gravitational waves) create
$B$-modes with a specific angular power spectrum, whose amplitude is
related to the energy scale of inflation. A detection of these
“primordial” $B$-modes would therefore provide the first measure of
the energy scale of inflation.

$E$-modes were first detected by Dasi in 2002, followed by
other ground and balloon-borne experiments ([Kovac et al. 2002](#bib.bib17); [Readhead et al. 2004](#bib.bib27); [Wu et al. 2007](#bib.bib33); [Montroy et al. 2006](#bib.bib22); [QUaD collaboration: C. Pryke et al. 2009](#bib.bib26)) covering a few percent of the
sky. These detections are complemented by the Wmap satellite
observations of the whole sky ([Page et al. 2007](#bib.bib24)). All these
measurements have confirmed the existence of an $E$-mode polarization
compatible with the $\Lambda CDM$ model, and are compatible with a
$B$-mode polarization of zero. The tensor-to-scalar ratio $r$
parametrizes the amplitude of $B$-mode polarization. The most stringent
upper limit on $r$ is obtained by [Komatsu et al. (2009)](#bib.bib16), combining
Wmap measurements of TT, TE and EE power spectra with Baryon
Acoustic Oscillations and supernovae data. They obtain $r<0.22$ if the
scalar spectral index $n\_{S}$ is constant, or $r<0.55$ if a running
spectral index is allowed.

Planck has been designed to map the $E$-mode of polarization with high
precision and good control over the polarization foreground
contamination up to multipoles as large as $\ell\sim 1500$. Planck
may also detect the $B$-mode polarization anisotropies, if tensor
modes contribute at a level of a few percent or more of the amplitude
of the scalar modes ([Efstathiou & Gratton 2009](#bib.bib7)). However, various
instrumental systematic effects, induced by error on the knowledge of
detector characteristics, may alter these measurements. Most of the
properties of the detectors, such as the gain, time constant, bandpass
and beam, are independent of the sensitivity to linear
polarization. These properties are described in detail in companion
papers ([Pajot et al. 2010](#bib.bib25); [Lamarre et al. 2010](#bib.bib18); [Tauber et al. 2010a](#bib.bib30); [Maffei et al. 2010](#bib.bib21)).
In this paper, we study the systematic effects induced by
uncertainties in temperature and polarization calibration (gains,
polarization efficiencies and orientations) on Stokes parameters and
$E$ and $B$-mode power spectra. We also report on the ground
calibration of the polarization efficiencies and orientations of High
Frequency Instrument (HFI) detectors.
A study of polarization systematics for the Low Frequency Instrument
(LFI) of Planck is presented in [Leahy et al. (2010)](#bib.bib19).

The paper is organized as follows. In Sect. [2](#S2 "2 Detectors and focal plane layout ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"), we
present the Polarization Sensitive Bolometers (PSBs) used by the
Planck HFI and the layout of the focal plane. Section [3](#S3 "3 Polarized photometric equation ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")
gives the generic expression of the polarized photometric equation and
introduces the polarization-related systematic effects discussed in
Sect. [4](#S4 "4 Systematics for polarization ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"). In Sect. [5](#S5 "5 Propagation of errors for polarization calibration ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"), we describe a
semi-analytical method to propagate uncertainties on temperature and
polarization calibration of detectors up to angular power spectra
while exactly accounting for the scanning strategy and the combination
of multiple detectors. We apply this method to the Planck HFI
in Sect. [6](#S6 "6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration") and derive requirements on the knowledge of
these parameters. Finally, Sect. [7](#S7 "7 Ground measurements ‣ Planck pre-launch status: High Frequency Instrument polarization calibration") describes the
procedure used to measure polarization parameters of the detectors on
ground and compares them to the requirements derived in the previous
section.

## 2 Detectors and focal plane layout

HFI uses bolometric detectors cooled to 100 mK to measure
millimeter-wave radiation. They comprise a micro-mesh absorber in a
form resembling a spider web to reduce cosmic ray interactions ([Bock et al. 1995](#bib.bib2); [Yun et al. 2004](#bib.bib34), hence the
name Spider Web Bolometer or SWB, see),
heated by ohmic power dissipation, and a neutron transmutation doped
(NTD) germanium thermistor that measures the temperature
variation. Polarization is measured with specifically designed
polarization sensitive bolometers ([Jones et al. 2003](#bib.bib14), PSBs, see),
composed of a pair of bolometers that couple to orthogonal linear
polarizations, allowing the measurement of $I$ and (local) $Q$ Stokes
parameters (respectively the sum and difference of the signals of the
two bolometers). The
SWBs are only slightly sensitive to polarization, and PSBs do not perfectly
reject the cross-polarization component. We define precisely the
cross-polarization leakage in the next section. The HFI focal plane is
composed of 20 SWBs and 16 PSB pairs, i.e., 32 polarization sensitive
bolometers (see Fig. [1](#S2.F1 "Figure 1 ‣ 2 Detectors and focal plane layout ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")). The PSB pairs are
grouped in pairs rotated by $45^{\circ}$ and following the same track
on the sky, with the angular separation between associated pairs ranging
from 0.∘5 to 2.∘5. Thus, the difference signal within one pair
measures Stokes $Q$ (in some local reference frame) while the difference
signal within the other pair measures Stokes $U$. Both pairs allow
measurements of the total intensity through the sum of signals. This
layout was chosen in order to minimize the noise on the Stokes
parameters and their correlation ([Couchot et al. 1999](#bib.bib4)).

Figure 1:  Sky projection of the Planck HFI
focal plane. The crosses symbolize the Polarization Sensitive
Bolometers and indicate the orientation of the two linear
polarization measured in each horn. The scanning direction is
horizontal in this sketch, so that PSB pairs at same frequency
follow the same track on the sky.

The satellite scans the sky by spinning at 1 rpm. The spin axis
remains within 7.∘5 of the anti-solar direction ([Tauber et al. 2010b](#bib.bib31), for a
detailed presentation of the Planck scanning strategy, see
). The angle between the spin axis and the line of
sight is $85^{\circ}\pm 2$.${}^{\circ}5$ depending on detector position in focal
plane. The ecliptic pole regions are thus much more covered than the
equatorial region, both in terms of number of hits per pixel and in
different observation orientations. This means that around the
ecliptic poles, each detector observes the sky with several focal
plane orientations and hence measures $I$, $Q$ and $U$. In contrast,
in the equatorial region, at least three detectors must be combined to
obtain the polarization signal. This is very different from currently
designed ground or balloon-borne experiments in which the Stokes
parameters can be measured using a single detector. This impacts
the propagation of errors, as discussed in detail in
Sect. [5](#S5 "5 Propagation of errors for polarization calibration ‣ Planck pre-launch status: High Frequency Instrument polarization calibration").

## 3 Polarized photometric equation

In this section, we derive the expression for the power received by a
PSB. Following Jones’s notation ([Jones 1941](#bib.bib13)), the polarization
state of a plane wave can be described by its transverse electric
field $\mathbf{e}=(E\_{x},E\_{y})$, where $E\_{x}$ and $E\_{y}$ are complex
amplitudes. The transmission through an instrument can be described by
its Jones matrix $\mathbf{J}\_{\mbox{\tiny tot}}$, a $2\times 2$
complex matrix, which relates the radiation $\mathbf{e}\_{\mbox{\tiny det}}$ that hits a detector to the incoming radiation on the
telescope $\mathbf{e}\_{\mbox{\tiny sky}}$:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbf{e}\_{\mbox{\tiny det}}(\nu,\mathbf{n})$ | $\displaystyle=$ | $\displaystyle\mathbf{J}\_{\mbox{\tiny tot}}(\nu,\mathbf{n})\,\mathbf{e}\_{\mbox{\tiny sky}}(\nu,\mathbf{n})$ |  | (1) |
|  |  | $\displaystyle=$ | $\displaystyle\mathbf{J}\_{\mbox{\tiny det}}\,\mathbf{J}\_{\mbox{\tiny filter}}(\nu)\,\mathbf{J}\_{\mbox{\tiny beam}}(\nu,\mathbf{n})\,\mathbf{e}\_{\mbox{\tiny sky}}$ |  |

where $\nu$ is the electromagnetic frequency, $\mathbf{n}$ is the
direction of observation and we have decomposed the Jones matrix into
optical element Jones matrices. As the detector is sensitive to
polarization, we can write the associated Jones matrix
$\mathbf{J}\_{\mbox{\tiny det}}$ as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{J}\_{\mbox{\tiny det}}=\left(\begin{array}[]{cc}1&0\\ 0&\sqrt{\eta}\end{array}\right),$ |  | (2) |

where $\eta$ is the cross-polarization leakage. We assume it
is independent of the frequency of the incoming radiation, which is
reasonable as it is mainly due to absorption of the cross-polarization
component on the edge of the absorbing grid ([Jones et al. 2003](#bib.bib14)).

The filter can also be described by a Jones matrix, as it is not a
depolarizing element in the sense defined by [Ditchburn (1976)](#bib.bib5). It
is simply given by:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{J}\_{\mbox{\tiny filter}}=\left(\begin{array}[]{cc}\sqrt{\tau(\nu)}&0\\ 0&\sqrt{\tau(\nu)}\end{array}\right)$ |  | (3) |

where $\tau(\nu)$ is the bandpass transmission of the filter, which
has been measured accurately on ground.

Finally, the beam of both the telescope and the horns is described by
a generic Jones matrix, $\mathbf{J}\_{\mbox{\tiny beam}}(\nu,\mathbf{n})$, which depends on both radiation frequency and direction
on the sky. The electric field received by the detector is thus given
by:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{e\_{\mbox{\tiny det}}}(\nu,\mathbf{n})=\sqrt{\tau(\nu)}\,\mathbf{R}\,\left(\begin{array}[]{cc}J\_{xx}&J\_{xy}\\ \sqrt{\eta}J\_{yx}&\sqrt{\eta}J\_{yy}\end{array}\right)\mathbf{R}^{-1}\mathbf{e\_{\mbox{\tiny sky}}}(\nu,\mathbf{n})$ |  | (4) |

where we have included the matrix $\mathbf{R}$ which rotates the
incoming radiation from the sky reference frame to the intrument
reference frame. The coefficients $J\_{ij}$, with $i$, $j$ in $\{x,y\}$,
are the elements of the beam Jones matrix $\mathbf{J}\_{\mbox{\tiny beam}}(\nu,\mathbf{n})$.

The intensity measured by the detector is the sum of the intensities
coming from each direction and for each frequency:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $I\_{\mbox{\tiny det}}=\int\!\!\!\int\langle\mathbf{e\_{\mbox{\tiny det}}}(\nu,\mathbf{n})^{\dagger}\cdot\mathbf{e}\_{\mbox{\tiny det}}(\nu,\mathbf{n})\rangle\,d\mathbf{n}\,d\nu.$ |  | (5) |

To describe the sky signal, we use the Stokes parameters $I$, $Q$, $U$
and $V$ ([Born & Wolf 1964](#bib.bib3), see, e.g.,):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}I(\nu,\mathbf{n})&=\langle E\_{x}E\_{x}^{\*}\rangle+\langle E\_{y}E\_{y}^{\*}\rangle\\ Q(\nu,\mathbf{n})&=\langle E\_{x}E\_{x}^{\*}\rangle-\langle E\_{y}E\_{y}^{\*}\rangle\\ U(\nu,\mathbf{n})&=\langle E\_{x}E\_{y}^{\*}\rangle+\langle E\_{y}E\_{x}^{\*}\rangle\\ V(\nu,\mathbf{n})&=-i\left(\langle E\_{x}E\_{y}^{\*}\rangle-\langle E\_{y}E\_{x}^{\*}\rangle\right).\end{split}$ |  | (6) |

where $I$ is the intensity, $Q$ and $U$ charaterize the linear
polarization and $V$ the circular polarization of the sky
radiation. We define analogously the beam Stokes parameters as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}\tilde{I}\_{\alpha}(\nu,\mathbf{n})&=J\_{\alpha x}J\_{\alpha x}^{\*}+J\_{\alpha y}J\_{\alpha y}^{\*}\\ \tilde{Q}\_{\alpha}(\nu,\mathbf{n})&=J\_{\alpha x}J\_{\alpha x}^{\*}-J\_{\alpha y}J\_{\alpha y}^{\*}\\ \tilde{U}\_{\alpha}(\nu,\mathbf{n})&=J\_{\alpha x}J\_{\alpha y}^{\*}+J\_{\alpha y}J\_{\alpha x}^{\*}\\ \tilde{V}\_{\alpha}(\nu,\mathbf{n})&=-i\left(J\_{\alpha x}J\_{\alpha y}^{\*}-J\_{\alpha y}J\_{\alpha x}^{\*}\right)\end{split}$ |  | (7) |

($\alpha=x,y$). Note that in general the beam Stokes parameters
depend on both frequency and sky direction. Therefore, we can write the
intensity measured by the detector as:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle I\_{\mbox{\tiny det}}$ | $\displaystyle=$ | $\displaystyle\frac{1}{2}\int\!\!\!\int\tau(\nu)\left[I(\tilde{I}\_{x}+\eta\tilde{I}\_{y})\right.$ |  | (8) |
|  |  |  | $\displaystyle{}+Q\left[(\tilde{Q}\_{x}+\eta\tilde{Q}\_{y})\cos 2\theta+(\tilde{U}\_{x}+\eta\tilde{U}\_{y})\sin 2\theta\right]$ |  |
|  |  |  | $\displaystyle{}+U\left[-(\tilde{Q}\_{x}+\eta\tilde{Q}\_{y})\sin 2\theta+(\tilde{U}\_{x}+\eta\tilde{U}\_{y})\cos 2\theta\right]$ |  |
|  |  |  | $\displaystyle\left.{}-V(\tilde{V}\_{x}+\eta\tilde{V}\_{y})\right]$ |  |

where $\theta$ is the angle of orientation between the sky and
detector reference frames, and we have not explicitly written the
dependency of radiation and beam Stokes parameters to frequency $\nu$
and direction $\mathbf{n}$ for clarity.

## 4 Systematics for polarization

In Eq. ([8](#S3.E8 "In 3 Polarized photometric equation ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")) each term that couples to one of the
Stokes parameters may depend on the direction of observation,
$\mathbf{n}$, and on frequency in non trivial ways. Several other
instrumental effects could be added to give an accurate description
of a detector measurement, such as its time constant, noise or
pointing errors.

The final calibration and analysis of HFI data needs to address all
these effects and will rely on both ground and in-flight
measurements. This is beyond the scope of this paper. However, some
comments can already be made.

HFI beam patterns have been simulated with GRASP
([Maffei et al. 2010](#bib.bib21); [Tauber et al. 2010a](#bib.bib30), see) and these simulations have
been verified by ground calibration performed by Thales Industries. It
was shown that *optical* cross-polarization and circular
polarization $\tilde{V}$ due to telescope were less than 0.1%. Their
impact has been studied separately ([Rosset et al. 2007](#bib.bib28)).

We will thus consider in the following an ideal optical system for
which $\mathbf{J}\_{\mbox{\tiny beam}}$ is proportional to the identity
matrix resulting in $\tilde{I}\_{x}=\tilde{I}\_{y}=\tilde{Q}\_{x}=-\tilde{Q}\_{y}$
and $\tilde{U}\_{x}=\tilde{U}\_{y}=\tilde{V}\_{x}=\tilde{V}\_{y}=0$.
Equation [8](#S3.E8 "In 3 Polarized photometric equation ‣ Planck pre-launch status: High Frequency Instrument polarization calibration") therefore simplifies to

|  |  |  |  |
| --- | --- | --- | --- |
|  | $I\_{\mbox{\tiny det}}=\frac{1}{2}\iint\tau(\nu)\tilde{I}\_{x}[(1+\eta)I+(1-\eta)(Q\cos 2\theta+U\sin 2\theta)]\,d\Omega d\nu.$ |  | (9) |

Realistic bandpasses and frequency dependence of optical beam coupling
terms are non-trivial effects that affect absolute calibration. More
specifically, calibration could depend on the electromagnetic spectrum
of the source. This is expected to impact component separation. In
this work, we focus on systematic effects on CMB polarization and rely
on absolute calibration on the CMB dipole, the amplitude f which is
known to 0.5% accuracy ([Fixsen et al. 1994](#bib.bib8)). We expect to measure in
flight the relative gain to an accuracy of better than 0.2%, given
the gain stability expected for HFI ([Hinshaw et al. 2009](#bib.bib11), i.e. better than
WMAP, see). Beam asymmetries and pointing
errors couple to the scanning strategy of the instrument. A general
framework to assess their impact is presented in
[Shimon et al. (2008)](#bib.bib29) and [O’Dea et al. (2007)](#bib.bib23).

Leaving these effects aside for this work, the measurement of a
detector reads:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $m=g\Big(I+\rho[Q\cos 2(\psi+\alpha)+U\sin 2(\psi+\alpha)]\Big)+n$ |  | (10) |

in which $n$ is the noise, $g$ is the total gain, $\rho=(1-\eta)/(1+\eta)$ is commonly
referred to as *polarization efficiency*, $\psi$ is the
dependence on the focal plane orientation on the sky and $\alpha$
stands for the relative *detector orientation* with respect to it.

## 5 Propagation of errors for polarization calibration

In this section, we propagate errors on gain $g$, on polarization
efficiency $\rho$ and detector orientation $\alpha$ (as defined in the
previous section) up to Stokes parameters
(Sect. [5.1](#S5.SS1 "5.1 Error on Stokes parameters ‣ 5 Propagation of errors for polarization calibration ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")) and angular power spectra
(Sect. [5.2](#S5.SS2 "5.2 Errors on Angular Power Spectra ‣ 5 Propagation of errors for polarization calibration ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")).

This method applies to all polarization experiments observing with
total power detectors such as HFI bolometers. It is close to the
approach taken by [Shimon et al. (2008)](#bib.bib29) and [O’Dea et al. (2007)](#bib.bib23). A similar
approach, focused on coherent receivers, was first proposed by
[Hu et al. (2003)](#bib.bib12). The main difference of the method presented here is
that it addresses the specific case of Planck which combines
different detectors to determine $Q$ and $U$.

### 5.1 Error on Stokes parameters

Given a pixelization of the sky and gathering all samples that fall
into the same pixel $p$ in a vector $\mathbf{m}$, Eq. [10](#S4.E10 "In 4 Systematics for polarization ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")
generalizes to the usual matrix form:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $m\_{t}=A\_{tp}s\_{p}+n\_{t},$ |  | (11) |

in which $\mathbf{s}=(I,Q,U)$ is the pixelized polarized sky signal
and $\mathbf{n}$ represents the noise vector. The pointing matrix
$\mathbf{A}$ encodes both the direction of observation and the
photometric equation including the calibration parameters $g$, $\rho$
and $\alpha$. Projection of time-ordered data into a pixelized map is
done by solving Eq. ([11](#S5.E11 "In 5.1 Error on Stokes parameters ‣ 5 Propagation of errors for polarization calibration ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")) for $\mathbf{s}$, knowing
$\mathbf{m}$ and the noise covariance matrix $N\equiv\langle\mathbf{n}\mathbf{n}^{T}\rangle$. The maximum likelihood solution is
$\widehat{\mathbf{s}}=(\mathbf{A}^{T}\mathbf{N}^{-1}\mathbf{A})^{-1}\mathbf{A}^{T}\mathbf{N}^{-1}\mathbf{m}=(\mathbf{A}^{T}\mathbf{A})^{-1}\mathbf{A}^{T}\mathbf{m}$ if we consider only Gaussian,
white and piece wise stationary noise, as we shall do in the remaining
part of this work in order to focus on systematic effects.

We use a perturbative approach of assumed parameters $\tilde{g}$,
$\tilde{\rho}$ and $\tilde{\alpha}$ (leading to a pointing matrix
$\tilde{\mathbf{A}}$) around their true values $g$, $\rho$ and
$\alpha$ (leading to $\mathbf{A}$). From Eq. ([10](#S4.E10 "In 4 Systematics for polarization ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")),
we can see that for $Q$ and $U$ Stokes parameters, errors on the gain
and polarization efficiency are degenerate. In the following, we use
an effective polarization efficiency $\rho^{\prime}\equiv g\rho$ and
keep $g$ for intensity only. The actual gain, polarization efficiency and
orientation for a given detector $d$ are therefore $g\_{d}=\tilde{g}\_{d}+\gamma\_{d}$, $\rho^{\prime}\_{d}=\tilde{\rho\_{d}}^{\prime}+\epsilon\_{d}$ and
$\alpha\_{d}=\tilde{\alpha\_{d}}+\omega\_{d}$ respectively11
1
In the
following, when a relation holds for $\gamma$, $\epsilon$ or
$\omega$, we simply write $e$. Thus, ignoring noise,

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\hat{\mathbf{s}}$ | $\displaystyle=$ | $\displaystyle(\tilde{\mathbf{A}}^{T}\tilde{\mathbf{A}})^{-1}\tilde{\mathbf{A}}^{T}\mathbf{m}$ |  | (12) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  | $\displaystyle=$ | $\displaystyle\left[\sum\_{d}\tilde{\mathbf{A}}\_{d}^{T}\tilde{\mathbf{A}}\_{d}\right]^{-1}\left[\sum\_{d}\tilde{\mathbf{A}}\_{d}^{T}\mathbf{A}\_{d}\right]\mathbf{s}$ |  | (13) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  | $\displaystyle\equiv$ | $\displaystyle\left[\sum\_{d}\tilde{\mathbf{A}}\_{d}^{T}\tilde{\mathbf{A}}\_{d}\right]^{-1}\left[\sum\_{d}\mathbf{\Lambda}\_{d}(\gamma\_{d},\epsilon\_{d},\omega\_{d})\right]{\bf s}.$ |  | (14) |

In this expression, $\mathbf{\Lambda}\_{d}(\gamma,\epsilon\_{d},\omega\_{d})$
is an explicit function of $\gamma$, $\epsilon\_{d}$ and $\omega\_{d}$, and
$\tilde{g}$, $\tilde{\rho}^{\prime}$ and $\tilde{\alpha}$ are only
parameters.

Considering small variations around $g$, $\rho^{\prime}$ and $\alpha$,
we can write the perturbative expansion to first order for both
$\gamma\ll 1$, $\epsilon\ll 1$ and $\omega\ll 1$:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\mathbf{s}$ | $\displaystyle=$ | $\displaystyle\hat{\mathbf{s}}-\mathbf{s}$ |  | (15) |
|  |  | $\displaystyle=$ | $\displaystyle\left[\sum\_{d}\tilde{\mathbf{A}}\_{d}^{T}\tilde{\mathbf{A}}\_{d}\right]^{-1}\left[\sum\_{d}\mathbf{\Lambda}\_{d}(\gamma\_{d},\epsilon\_{d},\omega\_{d})-\mathbf{\Lambda}\_{d}(0,0,0)\right]\mathbf{s}$ |  |
|  |  | $\displaystyle\simeq$ | $\displaystyle\left[\sum\_{d}\tilde{\mathbf{A}}\_{d}^{T}\tilde{\mathbf{A}}\_{d}\right]^{-1}\sum\_{d}\left[\frac{\partial\mathbf{\Lambda}\_{d}}{\partial\gamma\_{d}}\gamma\_{d}+\frac{\partial\mathbf{\Lambda}\_{d}}{\partial\epsilon\_{d}}\epsilon\_{d}\right.$ |  |
|  |  |  | $\displaystyle\qquad\qquad\qquad\qquad\qquad\qquad\qquad\left.{}+\frac{\partial\mathbf{\Lambda}\_{d}}{\partial\omega\_{d}}\omega\_{d}\right]{\mathbf{s}}.$ |  |

Partial derivatives with respect to gain $\gamma\_{d}$, polarization
efficiency $\epsilon\_{d}$ and orientation $\omega\_{d}$ uncertainties are
derived in appendix [A](#A1 "Appendix A Explicit forms of pointing related functions ‣ Planck pre-launch status: High Frequency Instrument polarization calibration").

The errors $\Delta\mathbf{s}$ strongly depend on the scanning strategy
through the number of hits per pixel and the distribution of detector
orientations. These are accounted for exactly by taking the scanning
strategy of the instrument and the positions of all detectors, and
computing the pointing-related quantities per pixel on which
$\mathbf{\Lambda}\_{d}$ and its derivatives depend. This part of the work
may be intensive in terms of memory or disk access requirements
depending on which experiment is being modeled but needs to be
performed only once. Then, given a sky model, the generation of an
arbitrary large set of error maps $\Delta\mathbf{s}$ requires fewer resources and
involves only distributions of $\gamma\_{d}$, $\epsilon\_{d}$ and $\omega\_{d}$.

Note that in the particular case of an experiment whose scanning
strategy is such that each detector observes each pixel of the map
under angles uniformly distributed over $[0,\pi]$, making a combined
map as in Eq. ([12](#S5.E12 "In 5.1 Error on Stokes parameters ‣ 5 Propagation of errors for polarization calibration ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")) is equivalent to making one set of
$I$, $Q$, and $U$ maps per detector and co-adding them to obtain the
final optimal maps of the experiment. In that case, sums of cosines
and sines vanish, which means that off diagonal terms of
$\tilde{\mathbf{A}}^{T}\_{d}\tilde{\mathbf{A}}\_{d}$ are zero and
Eq. ([15](#S5.E15 "In 5.1 Error on Stokes parameters ‣ 5 Propagation of errors for polarization calibration ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")) reads simply

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta\mathbf{s}=\langle\gamma{\rangle}\_{d}\left(\begin{array}[]{c}I\\ 0\\ 0\end{array}\right)+\langle\frac{\epsilon}{\rho^{\prime}}{\rangle}\_{d}\left(\begin{array}[]{c}0\\ Q\\ U\end{array}\right)+2\langle\omega{\rangle}\_{d}\left(\begin{array}[]{c}0\\ U\\ -Q\end{array}\right)$ |  | (16) |

Because of the linearization, the final map is sensitive to the
averages of these parameters. If errors are correlated (or identical
at worst), they do not average down; if they are randomly distributed around zero
mean, they do. These results are in agreement with
[O’Dea et al. (2007)](#bib.bib23). As we will see in the Sect. [6](#S6 "6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"), this
is not the case for HFI, for which none of these simplifications
applies.

### 5.2 Errors on Angular Power Spectra

Following conventions of [Zaldarriaga & Seljak (1997)](#bib.bib35), the projection onto
spherical harmonics of intensity and polarization reads:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle a\_{\ell m}^{T}$ | $\displaystyle=$ | $\displaystyle\int I(\mathbf{n})Y^{\*}\_{lm}(\mathbf{n})\;d\mathbf{n},$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle a\_{\ell m}^{E}$ | $\displaystyle=$ | $\displaystyle-\int\left[Q(\mathbf{n})R^{+}\_{lm}(\mathbf{n})+iU(\mathbf{n})R^{-}\_{lm}(\mathbf{n})\right]\;d\mathbf{n},$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle a\_{\ell m}^{B}$ | $\displaystyle=$ | $\displaystyle i\int\left[Q(\mathbf{n})R^{-}\_{\ell m}(\mathbf{n})+iU(\mathbf{n})R^{+}\_{lm}(\mathbf{n})\right]\;d\mathbf{n}$ |  |

where the $R^{\pm}\_{lm}=\ \_{2}Y^{\*}\_{lm}\pm\ \_{-2}Y^{\*}\_{lm}$ depend on
the $s$-spin spherical harmonic functions $\ {}\_{s}Y\_{lm}(\mathbf{n})$
($s=\{0,2,-2\}$).

Spherical harmonics transforms are linear, so derivatives of $\mathbf{a}\_{\ell m}=\left(a^{T}\_{\ell m},a^{E}\_{\ell m},a^{B}\_{\ell m}\right)$ read

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{\partial\mathbf{a}\_{\ell m}}{\partial e}$ | $\displaystyle=$ | $\displaystyle\int\left(\begin{array}[]{ccc}Y^{\*}\_{lm}&0&0\\ 0&-R^{+}\_{lm}&-iR^{-}\_{lm}\\ 0&iR^{-}\_{lm}&-R^{+}\_{\ell m}\end{array}\right)\_{(\mathbf{n})}\frac{\partial\mathbf{s}}{\partial e}(\mathbf{n})\;d\mathbf{n}$ |  |

We use a simple pseudo-$C\_{\ell}$ estimator, $\tilde{C}\_{\ell}$, which is
$\chi^{2}$-distributed with a mean equal to the underlying $C\_{\ell}$,
$\nu\_{\ell}=(2\ell+1)$ degrees of freedom and a variance of $2C\_{\ell}/\nu\_{\ell}$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\tilde{C}^{XY}\_{\ell}=\frac{1}{(2\ell+1)}\sum\_{m=-\ell}^{\ell}a^{X\*}\_{\ell m}a^{Y}\_{\ell m}.$ |  | (21) |

This estimator neglects the E-B mixing due to incomplete sky coverage
([Lewis et al. 2002](#bib.bib20)) and assumes a cross-power spectrum for which noise bias
is null (or if auto-spectra are used, that the noise bias has been
previously removed) because their interaction with the systematic
effects introduced here are of second order.

Using the previous relations, straightforward algebra leads from Eq. ([15](#S5.E15 "In 5.1 Error on Stokes parameters ‣ 5 Propagation of errors for polarization calibration ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")) to its counterpart in harmonic space:

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\Delta\tilde{C}\_{\ell}=\sum\_{d}\frac{\partial\tilde{C}\_{\ell}}{\partial\gamma\_{d}}\gamma\_{d}+\sum\_{d}\frac{\partial\tilde{C}\_{\ell}}{\partial\epsilon\_{d}}\epsilon\_{d}+\sum\_{d}\frac{\partial\tilde{C}\_{\ell}}{\partial\omega\_{d}}\omega\_{d}$ |  |
|  |  |  |
| --- | --- | --- |
|  | $\displaystyle{}+\frac{1}{2}\sum\_{d,d^{\prime}}\left[\frac{\partial^{2}\tilde{C}\_{\ell}}{\partial\gamma\_{d}\partial\gamma\_{d^{\prime}}}\gamma\_{d}\gamma\_{d^{\prime}}+\frac{\partial^{2}\tilde{C}\_{\ell}}{\partial\epsilon\_{d}\partial\epsilon\_{d^{\prime}}}\epsilon\_{d}\epsilon\_{d^{\prime}}\right.$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\quad\qquad\qquad\qquad\qquad\qquad\qquad\left.{}+\frac{\partial^{2}\tilde{C}\_{\ell}}{\partial\omega\_{d}\partial\omega\_{d^{\prime}}}\omega\_{d}\omega\_{d^{\prime}}\right],$ |  | (22) |

where, for $e=\gamma$, $\epsilon$ or $\omega$,

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{\partial C^{XY}\_{\ell}}{\partial e}$ | $\displaystyle=$ | $\displaystyle\frac{1}{2\ell+1}\sum\_{m=-\ell}^{\ell}\left[\frac{\partial a^{X\*}\_{\ell m}}{\partial e}a^{Y}\_{\ell m}+a^{X\*}\_{\ell m}\frac{\partial a^{Y}\_{\ell m}}{\partial e}\right]$ |  | (23) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{\partial^{2}C^{XY}\_{\ell}}{\partial e\partial e^{\prime}}$ | $\displaystyle=$ | $\displaystyle\frac{1}{2\ell+1}\sum\_{m=-\ell}^{\ell}\left[\frac{\partial^{2}a^{X\*}\_{\ell m}}{\partial e\partial e^{\prime}}a^{Y}\_{\ell m}+\frac{\partial a^{X\*}\_{\ell m}}{\partial e}\frac{\partial a^{Y}\_{\ell m}}{\partial e^{\prime}}\right.$ |  | (24) |
|  |  |  | $\displaystyle\quad\quad\quad\quad\quad\left.{}+\frac{\partial a^{X\*}\_{\ell m}}{\partial e^{\prime}}\frac{\partial a^{Y}\_{\ell m}}{\partial e}+a^{X\*}\_{\ell m}\frac{\partial^{2}a^{Y}\_{\ell m}}{\partial e\partial e^{\prime}}\right].$ |  |

We ignore cross-terms between different systematic parameters so the
previous expressions are only applicable when all but one of the
parameters are set to zero. The cross-terms have been checked to be
one order of magnitude below the direct terms. Note that we push the
perturbative expansion to second order, since $E$-modes are much larger
than $B$-modes and a second order effect on $E$-modes has an impact
comparable to a first order effect on $B$-modes.

### 5.3 Monte-Carlo Simulations

We have now everything in hand to perform the semi-analytical estimate of the polarization calibration systematic effects.
The method can be described in 5 main steps:

1. 1.

   From the scanning strategy of the instrument, for each detector $d$, project into a map : $\cos 2\psi$, $\sin 2\psi$, $\cos 2\psi\sin 2\psi$, and $\cos^{2}2\psi$.
2. 2.

   With these quantities, compute for each pixel of the map the following $3\times 3$ matrices: $\left[\sum\_{d}\tilde{\mathbf{A}}\_{d}^{T}\tilde{\mathbf{A}}\_{d}\right]^{-1}$, $\mathbf{\Lambda}\_{d}$, and its first and second derivatives.
3. 3.

   Use a simulated CMB sky $\mathbf{s}$ and Eq. ([15](#S5.E15 "In 5.1 Error on Stokes parameters ‣ 5 Propagation of errors for polarization calibration ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")) to compute partial derivatives $\partial\mathbf{s}/\partial e$ (up to second order)
4. 4.

   Compute all cross-power spectra between $\mathbf{s}$ and its derivatives
5. 5.

   Combine these results using gaussian random distributions of $\gamma\_{d}$, $\epsilon\_{d}$ and $\omega\_{d}$ (with various rms $\sigma$) in Eq. ([22](#S5.E22 "In 5.2 Errors on Angular Power Spectra ‣ 5 Propagation of errors for polarization calibration ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")) to obtain the final error on the angular power spectrum.

The power spectra estimator used is a pseudo-$C\_{\ell}$ estimator based
on the cross-power spectra algorithm ([Tristram et al. 2005](#bib.bib32)), extended
to polarization ([Kogut et al. 2003](#bib.bib15); [Grain et al. 2009](#bib.bib10)). The semi-analytic method
described in this section has been compared to full Monte-Carlo
simulations and gives results compatible with statistical expectations
for the number of simulations performed.

## 6 Application to Planck-HFI focal plane

We apply the method described in the previous section to the Planck
HFI to set requirements on gain, polarization efficiency and
orientation. We simulated HEALPix ([Górski et al. 2005](#bib.bib9)) full-sky maps
at a resolution of $\sim 3.5$ arcmin ($nside=1024$) so that all pixels
are seen and each pixel is uniformly sampled. This avoids the
complications of estimating power spectra on a cut sky when allowing
for the same conclusions, as our power spectrum estimator is not
biased in the mean. The scanning strategy that we use is a realistic
simulation of what Planck will actually do in a 14-month mission. The
sky signal is pure CMB simulated from the best $\Lambda CDM$ fit to
WMAP 5 years data ([Dunkley et al. 2009](#bib.bib6)) with $r=0.05$, supposing the
CMB signal to be dominant over foregrounds residuals (at least for
intensity and $E$-mode CMB signals).

As described in Sect. [2](#S2 "2 Detectors and focal plane layout ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"), the Planck scanning strategy
and focal plane design do not allow the data from a single PSB pair to
provide independent maps of the Stokes parameters. Here, we will use
two PSB pairs calibrated in intensity and consider small variations
around their gain $g\_{d}=1$, nominal angles $\alpha\_{d}=\{0^{\circ},90^{\circ},45^{\circ},135^{\circ}\}$ and nominal polarization
efficiency $\rho^{\prime}\_{d}=1$ (corresponding to perfect PSB).

### 6.1 Error on Stokes parameter for HFI

We refer to appendix [A](#A1 "Appendix A Explicit forms of pointing related functions ‣ Planck pre-launch status: High Frequency Instrument polarization calibration") for the explicit form of
the derivative terms of the Stokes parameters. Here, we emphasize the
issues specific to HFI. In this case,
Eq. ([15](#S5.E15 "In 5.1 Error on Stokes parameters ‣ 5 Propagation of errors for polarization calibration ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")) reads (see
Eqs. [A](#A1.EGx19 "Appendix A Explicit forms of pointing related functions ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")-[A](#A1.EGx20 "Appendix A Explicit forms of pointing related functions ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"))

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\mathbf{s}$ | $\displaystyle=$ | $\displaystyle\left(\begin{array}[]{ccc}\Delta\_{II}&\Delta\_{IQ}&\Delta\_{IU}\\ \Delta\_{QI}&\Delta\_{QQ}&\Delta\_{QU}\\ \Delta\_{UI}&\Delta\_{UQ}&\Delta\_{UU}\end{array}\right)\mathbf{s}.$ |  |

For gain variations only, non-zero elements of the matrix are given
for each pixel, to first order, by

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{II}^{g}$ | $\displaystyle=$ | $\displaystyle\textstyle\frac{1}{4}(\gamma\_{1}+\gamma\_{2}+\gamma\_{3}+\gamma\_{4})$ |  | (29) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{QI}^{g}$ | $\displaystyle=$ | $\displaystyle\textstyle\frac{1}{4}(\gamma\_{1}-\gamma\_{2})\left<\cos 2\psi\right>-\frac{1}{4}(\gamma\_{3}-\gamma\_{4})\left<\sin 2\psi\right>$ |  | (30) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{UI}^{g}$ | $\displaystyle=$ | $\displaystyle\textstyle\frac{1}{4}(\gamma\_{1}-\gamma\_{2})\left<\sin 2\psi\right>+\frac{1}{4}(\gamma\_{3}-\gamma\_{4})\left<\cos 2\psi\right>$ |  | (31) |

For polarization efficiency only, elements of the matrix are given for
each pixel, to first order, by

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{IQ}^{\rho}$ | $\displaystyle=$ | $\displaystyle\textstyle\frac{1}{4}(\epsilon\_{1}-\epsilon\_{2})\left<\cos 2\psi\right>-\frac{1}{4}(\epsilon\_{3}-\epsilon\_{4})\left<\sin 2\psi\right>$ |  | (32) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{IU}^{\rho}$ | $\displaystyle=$ | $\displaystyle\textstyle\frac{1}{4}(\epsilon\_{1}-\epsilon\_{2})\left<\sin 2\psi\right>+\frac{1}{4}(\epsilon\_{3}-\epsilon\_{4})\left<\cos 2\psi\right>$ |  | (33) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{QQ}^{\rho}$ | $\displaystyle=$ | $\displaystyle\textstyle\frac{1}{2}(\epsilon\_{1}+\epsilon\_{2})\left<\cos^{2}2\psi\right>+\frac{1}{2}(\epsilon\_{3}+\epsilon\_{4})\left<\sin^{2}2\psi\right>$ |  | (34) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{QU}^{\rho}$ | $\displaystyle=$ | $\displaystyle\textstyle\frac{1}{2}\left[(\epsilon\_{1}+\epsilon\_{2})-(\epsilon\_{3}+\epsilon\_{4})\right]\left<\cos 2\psi\sin 2\psi\right>$ |  | (35) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{UQ}^{\rho}$ | $\displaystyle=$ | $\displaystyle\textstyle\frac{1}{2}\left[(\epsilon\_{1}+\epsilon\_{2})-(\epsilon\_{3}+\epsilon\_{4})\right]\left<\cos 2\psi\sin 2\psi\right>$ |  | (36) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{UU}^{\rho}$ | $\displaystyle=$ | $\displaystyle\textstyle\frac{1}{2}(\epsilon\_{1}+\epsilon\_{2})\left<\sin^{2}2\psi\right>+\frac{1}{2}(\epsilon\_{3}+\epsilon\_{4})\left<\cos^{2}2\psi\right>.$ |  | (37) |

In the case of orientation errors only, to first order,

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{IQ}^{\alpha}$ | $\displaystyle=$ | $\displaystyle\textstyle-\frac{1}{2}(\omega\_{1}-\omega\_{2})\left<\sin 2\psi\right>-\frac{1}{2}(\omega\_{3}-\omega\_{4})\left<\cos 2\psi\right>$ |  | (38) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{IU}^{\alpha}$ | $\displaystyle=$ | $\displaystyle\textstyle\frac{1}{2}(\omega\_{1}-\omega\_{2})\left<\cos 2\psi\right>-\frac{1}{2}(\omega\_{3}-\omega\_{4})\left<\sin 2\psi\right>$ |  | (39) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{QQ}^{\alpha}$ | $\displaystyle=$ | $\displaystyle\textstyle-\left[(\omega\_{1}+\omega\_{2})-(\omega\_{3}+\omega\_{4})\right]\left<\cos 2\psi\sin 2\psi\right>$ |  | (40) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{QU}^{\alpha}$ | $\displaystyle=$ | $\displaystyle\textstyle(\omega\_{1}+\omega\_{2})\left<\cos^{2}2\psi\right>+(\omega\_{3}+\omega\_{4})\left<\sin^{2}2\psi\right>$ |  | (41) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{UQ}^{\alpha}$ | $\displaystyle=$ | $\displaystyle\textstyle-(\omega\_{1}+\omega\_{2})\left<\sin^{2}2\psi\right>\!-(\omega\_{3}+\omega\_{4})\left<\cos^{2}2\psi\right>$ |  | (42) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta\_{UU}^{\alpha}$ | $\displaystyle=$ | $\displaystyle\textstyle\left[(\omega\_{1}+\omega\_{2})-(\omega\_{3}+\omega\_{4})\right]\left<\cos 2\psi\sin 2\psi\right>.$ |  | (43) |

In these
Eqs ([29](#S6.E29 "In 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")-[43](#S6.E43 "In 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")), the
average is over the samples falling into a given pixel. It depends
only on the scanning strategy. Figure [2](#S6.F2 "Figure 2 ‣ 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration") shows
the angle distribution on the sky for a realistic Planck
scanning strategy. Planck shows large inhomogeneities that induce
additional terms with respect to the case of a single bolometer.

Figure 2:  Amplitude of the various terms in
Eqs. ([29](#S6.E29 "In 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")-[43](#S6.E43 "In 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"))
describing the focal plane angle distribution on the sky for
a mock but realistic Planck scanning coverage (HEALPix maps
at $nside=1024$, Galactic coordinates). From top to bottom : $|\langle\cos 2\psi\rangle|$, $|\langle\sin 2\psi\rangle|$, $|\langle\sin 4\psi\rangle|/2$, $\langle\cos^{2}2\psi\rangle$.

Leakage from intensity to polarization.
:   Error on gain only produces leakage from intensity to polarization (see eq [A](#A1.EGx19 "Appendix A Explicit forms of pointing related functions ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")).
    This leakage is driven by the relative errors inside a given horn which indicates that an absolute error on the gain (same for all detectors) will not produce any leakage.
    Neither polarization efficiency nor detector orientation errors induce any leakage from $I$ into polarization $Q$ and $U$ (see Eqs. [A](#A1.EGx19 "Appendix A Explicit forms of pointing related functions ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")-[A](#A1.EGx20 "Appendix A Explicit forms of pointing related functions ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")).

Leakage from polarization to intensity.
:   Both polarization
    efficiency and orientation error produce leakage from polarization to
    intensity. It is driven by the difference of errors within one horn
    and the relative weight of each horn depends on the distribution of
    $\psi$ (see Fig. [2](#S6.F2 "Figure 2 ‣ 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")).

Polarization mixing.
:   Polarization calibration parameters
    mix both $Q$ and $U$. This means that they induce leakage from $Q$
    to $U$ through the term $\Delta^{\rho}\_{QU}$ (and from $U$ to $Q$
    through the term $\Delta^{\rho}\_{UQ}$) but also alter the amplitude of
    polarization ($\Delta^{\rho}\_{QQ}$ and $\Delta^{\rho}\_{UU}\neq 0$). If
    we consider identical errors for each detector, we are in the
    limiting case where orientation error induces only leakage
    (Eqs. [41](#S6.E41 "In 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"),[42](#S6.E42 "In 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"))
    and polarization efficiency only changes the amplitude of
    polarization (Eqs. [34](#S6.E34 "In 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"),[37](#S6.E37 "In 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")) as
    described by Eq. [16](#S5.E16 "In 5.1 Error on Stokes parameters ‣ 5 Propagation of errors for polarization calibration ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"). In the case of
    Planck-HFI, and considering independent errors, none of these
    simplifications apply. In particular, different parameter averages
    from one horn to the other induce both $Q$ and $U$ mixing and
    amplitude modification.

### 6.2 Results for $E$ and $B$-mode power spectra

The semi-analytical method described in Sect. [5](#S5 "5 Propagation of errors for polarization calibration ‣ Planck pre-launch status: High Frequency Instrument polarization calibration") is
able to propagate instrumental errors up to the six CMB power spectra:
$TT$, $EE$, $BB$, $TE$, $TB$ and $EB$. In this section, we will focus
on the $E$ and $B$-mode power spectra and discuss results obtained for
Planck-HFI in case of absolute (Sect. [6.2.1](#S6.SS2.SSS1 "6.2.1 Global error over the focal plane / calibration on the sky ‣ 6.2 Results for 𝐸 and 𝐵-mode power spectra ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")) and
relative uncertainties (Sect. [6.2.2](#S6.SS2.SSS2 "6.2.2 Relative Calibration between detectors ‣ 6.2 Results for 𝐸 and 𝐵-mode power spectra ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")). Other
spectra (like $TB$ and $EB$) that are predicted to be null for CMB
signal, can be very useful in revealing “leakage” due to
systematics. However, many systematic effects can produce such
leakage, which will make their separate identification very
complicated when using only these modes.

#### 6.2.1 Global error over the focal plane / calibration on the sky

Absolute calibration of total power is done using the orbital dipole
that has the same electromagnetic spectrum as the CMB and is not
degenerate with the underlying sky signal as its sign changes after 6
months of observation. From Eqs. ([30](#S6.E30 "In 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"))
and ([31](#S6.E31 "In 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")), absolute error on the gain $g$ will not
produce any leakage in polarization signals:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta^{g}\mathbf{s}$ | $\displaystyle=$ | $\displaystyle\left(\begin{array}[]{ccc}\gamma&0&0\\ 0&0&0\\ 0&0&0\end{array}\right)\mathbf{s}\text{\hskip 14.22636pt for gain}.$ |  |

As far as polarization is concerned, we need a polarized source on the
sky. The Crab nebulae, a supernova remnant, is a good candidate as it
shows a large polarization emission in the Planck-HFI frequency
bands. It has been observed in a wide range of frequencies and shown
to have polarization properties stable enough to be a calibrator for
polarization experiments. Dedicated observations of this source were
done by IRAM at 89 GHz ([Aumont et al. 2009](#bib.bib1)). The impact of an
approximate knowledge of the polarization sky calibrator leads to a
uniform error over the focal plane. In this case, the $\omega$ and
$\epsilon$ parameters do not depend on the detector. From
Eqs. [32](#S6.E32 "In 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")-[43](#S6.E43 "In 6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"), we found
that the intensity does not leak into polarization with polarization
efficiency and orientation errors ($\Delta\_{IQ}=\Delta\_{IU}=0$)
and

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta^{\rho}\mathbf{s}$ | $\displaystyle=$ | $\displaystyle\left(\begin{array}[]{ccc}0&0&0\\ 0&\epsilon&0\\ 0&0&\epsilon\end{array}\right)\mathbf{s}\text{\hskip 14.22636pt for polarization efficiency},$ |  |

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta^{\alpha}\mathbf{s}$ | $\displaystyle=$ | $\displaystyle\left(\begin{array}[]{ccc}0&0&0\\ 0&\cos 2\omega&\sin 2\omega\\ 0&-\sin 2\omega&\cos 2\omega\end{array}\right)\mathbf{s}\text{\hskip 14.22636pt for orientation}.$ |  |

In terms of power spectra, an error in polarization efficiencies only
affects the amplitude of the $E$ and $B$ power spectra but does not
result in leakage from $E$ to $B$. On the other hand, an error in
orientations mixes $Q$ and $U$ maps resulting in both a leakage from
$E$ into $B$ (as well as $B$ into $E$) and a modification of $E$ and
$B$ amplitudes. However, as the $E$-mode signal is far above that of
the $B$-mode in amplitude, $\Delta C\_{\ell}$ is dominated by $E$-mode to
second order:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta C^{X}\_{\ell}=2\epsilon C^{X}\_{\ell}+4\omega^{2}C^{E}\_{\ell},$ |  | (56) |

for X either $E$ or $B$-mode.

Consequently, for $E$-mode, the polarization efficiency uncertainty
must be $\epsilon<0.5\%$ and the orientation uncertainty $\omega<2$.${}^{\circ}9$ to obtain less than 1% error on the power spectrum
amplitude. Alternatively, the leakage is kept under 10% of the cosmic
variance if $\epsilon<0.3\%$ and $\omega<2$.${}^{\circ}1$ for $\ell=2-1000$.

To go further and target the $B$-mode signal, we show that the
orientation must be known to better than 1.∘3 (0.∘4) in order to
keep the leakage from $E$ to $B$-mode lower than 10% (1%) of the
expected $C\_{\ell}^{B}$ for a tensor-to-scalar ratio of $r=0.05$ at
large angular scales ($\ell<100$). The error on its amplitude will be
driven by the polarization efficiency uncertainty ($2\epsilon$).

#### 6.2.2 Relative Calibration between detectors

As discussed in Sect. [6.1](#S6.SS1 "6.1 Error on Stokes parameter for HFI ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"), there is no
generic case concerning the *a priori* distribution of errors
for polarization parameters on HFI. We therefore performed $10000$
Monte-Carlo simulations to propagate the errors through to the E
and B polarized angular power spectra. Errors were drawn from a gaussian
distribution with various dispersions $\sigma\_{\gamma}$,
$\sigma\_{\epsilon}$ and $\sigma\_{\omega}$ per detector. We then propagated
those uncertainties through to the $E$ and $B$ angular power spectra.

The results show leakage coming from $TT$, $EE$ and $BB$
depending on the parameter considered. The gain uncertainty induces
leakage from intensity into polarization so $\Delta C\_{\ell}$ show
leakage from $TT$ and $TE$ spectra (dominated by $TT$). For
polarization efficiency and orientation, $\Delta C\_{\ell}$ is a
combination of $EE$ and $BB$ power spectra with relative weights that
depend on the distribution of uncertainties between the four bolometers
considered. Due to second order terms, the distribution of
errors in the angular power spectra is highly non gaussian, as
shown in Figs. [3](#S6.F3 "Figure 3 ‣ 6.2.2 Relative Calibration between detectors ‣ 6.2 Results for 𝐸 and 𝐵-mode power spectra ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"), [4](#S6.F4 "Figure 4 ‣ 6.2.2 Relative Calibration between detectors ‣ 6.2 Results for 𝐸 and 𝐵-mode power spectra ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")
and [5](#S6.F5 "Figure 5 ‣ 6.2.2 Relative Calibration between detectors ‣ 6.2 Results for 𝐸 and 𝐵-mode power spectra ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration").

Figure 3:  Distribution of $\Delta C\_{\ell}^{EE}$
(top) and $\Delta C\_{\ell}^{BB}$ (bottom) for
$\sigma\_{\gamma}=0.2\%$ gain errors for multipoles
$\ell=10$, $\ell=100$, $\ell=500$, normalized to their rms
(red line).

Figure 4:  Distribution of $\Delta C\_{\ell}^{EE}$
(top) and $\Delta C\_{\ell}^{BB}$ (bottom) for
$\sigma\_{\epsilon}=1\%$ polar efficiency errors for multipoles
$\ell=10$, $\ell=100$, $\ell=500$, normalized to their rms
(red line).

Figure 5:  Distribution of $\Delta C\_{\ell}^{EE}$
(top) and $\Delta C\_{\ell}^{BB}$ (bottom) for
$\sigma\_{\omega}=1^{\circ}$ orientation errors for multipoles
$\ell=10$, $\ell=100$, $\ell=500$, normalized to their rms
(red line).

We then compare the rms of those distributions for each multipole to
the cosmic variance of the $E$-mode and to an $r=0.05$ $B$-mode
spectrum with lensing (Figs. [6](#S6.F6 "Figure 6 ‣ 6.2.2 Relative Calibration between detectors ‣ 6.2 Results for 𝐸 and 𝐵-mode power spectra ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"),
[7](#S6.F7 "Figure 7 ‣ 6.2.2 Relative Calibration between detectors ‣ 6.2 Results for 𝐸 and 𝐵-mode power spectra ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration") and [8](#S6.F8 "Figure 8 ‣ 6.2.2 Relative Calibration between detectors ‣ 6.2 Results for 𝐸 and 𝐵-mode power spectra ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")).

Figure 6:  $\Delta C\_{\ell}$ in rms due to
gain errors from 0.01% to 1% for $E$-mode (top) and
$B$-mode (bottom) compared to initial spectrum (solid black lines). Cosmic variance for $E$-mode is
plotted in dashed black line.

Figure 7:  $\Delta C\_{\ell}$ in rms due to
polarization efficiency errors from 0.1% to 4% for
$E$-mode (top) and $B$-mode (bottom) compared to
initial spectrum (solid black lines). Cosmic variance for
$E$-mode is plotted in dashed black line.

Figure 8:  $\Delta C\_{\ell}$ in rms due to
various orientation errors from 0.25 to 2 degrees for
$E$-mode (top) and $B$-mode (bottom) compared to
initial spectrum (solid black lines). Cosmic variance
for $E$-mode is plotted in dashed black line.

Using these results, we can set the requirements for Planck-HFI on the
calibration of gain, polarization efficiency and orientation. More
precisely, we demand that the errors on the temperature and polarization
calibration parameters to be such that the induced leakage into the
$E$ power spectrum is lower than 10% of the cosmic variance over the
multipole range $\ell=2-1000$. This means that gains must be known to
$0.15\%$, polarization efficiencies to $0.5\%$ and detector
orientations to $1^{\circ}$.

According to [Efstathiou & Gratton (2009)](#bib.bib7), an extended Planck mission
should be able to measure gravitational $B$-mode at a level of
$r=0.05$ and put an upper-limit of $r=0.03$ when considering
foreground residuals and noise levels. To achieve such a detection (or
upper-limit), the constraints on the calibration parameters must be
much tighter. For this goal, we set the leakage into $B$ power
spectrum to be 10% of the $B$-mode model we want to target, for a
multipole range from $\ell=2$ to $100$. With such an hypothesis,
we find that the gain precision should be better than 0.05% and the
orientations of the bolometers should be known to better than
0.∘75. The leakage due to polarization efficiency into B-mode is
very small (see bottom plot in Fig. [7](#S6.F7 "Figure 7 ‣ 6.2.2 Relative Calibration between detectors ‣ 6.2 Results for 𝐸 and 𝐵-mode power spectra ‣ 6 Application to Planck-HFI focal plane ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")), thus the
constraint on the polarization efficiency determination is not
relevant in that case (we found 10%).

## 7 Ground measurements

The Planck HFI polarization calibration on ground was divided into two
parts: polarization efficiencies were measured for each detector
separately, before focal plane assembly, at the University of Wales in
Cardiff in 2005, while orientations of the PSBs with respect to the
focal plane were measured during the overall calibration of the Planck
HFI in the Saturne cryostat at Orsay, France, in 2006.

### 7.1 Polarization efficiency ground measurements

Detector-level polarization efficiency measurements were performed in
a 2-stage adiabatic demagnetization refrigerator (ADR) at a base
temperature of 200 mK. The ADR was configured to take six detectors
per cooldown (in most cases all of the same optical band per
cooldown). Thermal blocking filters were used at the 4 K, 77 K and
300 K stages of the testbed. The anti-reflective coating on the
cryostat window was matched to the optical band under test. The
window, of 125 mm diameter, and all the thermal blockers were sized
such that they filled the beams. The polarization source was a
rotating polarizer grid positioned over an extended
temperature-controlled black body source of 75 mm diameter running at
126∘C. The final source aperture was 70 mm in diameter. The
mechanical structure of the source was fully clad with non-rotating
Eccosorb (type AN-72). The source was positioned approximately 690 mm
from the cryostat window, tilted 4.∘8 off the optical axis, and
mechanically chopped at 6 Hz. The experimental setup was fully
surrounded with Eccosorb (type AN-72) while the data were
recorded. Data were recorded in a step and sample fashion over five
full rotations of the polarizer grid with a 4∘ step size and a
4 second integration time.

Detailed results are given in the appendix in Tables [1](#A2.T1 "Table 1 ‣ Appendix B Polarization efficiencies and angles ‣ Planck pre-launch status: High Frequency Instrument polarization calibration")
and [2](#A2.T2 "Table 2 ‣ Appendix B Polarization efficiencies and angles ‣ Planck pre-launch status: High Frequency Instrument polarization calibration") for PSBs and SWBs, respectively. The
polarization efficiency of the SWBs is low, as expected, and range between
1.6% and 8.6%. The statistical error is typically 0.5%, and as much
as 1.8% for one SWB. The polarization efficiency of the PSBs is typically
around 90%, ranging from 84% to 96%, with errors below 0.3%.

### 7.2 Orientation ground measurements

#### 7.2.1 The calibration setup

The orientation calibration was performed within a 1-meter diameter
cryostat cooled to 2 K, to be close to flight conditions ([Pajot et al. 2010](#bib.bib25), for a
more detailed description of the calibration setup and photographs,
see). The detectors were cooled to their nominal
operating temperature, 100 mK. For polarization measurements, the
source (Cold Source 2 or CS2) was a blackbody at 20 K whose radiation
was diluted within a 50 cm diameter sphere in order to illuminate,
after a reflection from mirror, the full focal plane at once. The
source was modulated by a diapason at a fixed frequency of 10 Hz. The
radiation was linearly polarized by an aluminum grid deposited on a
138 mm diameter mylar film. The aluminum strips of the polarizer were
5 $\mu$m wide, 5 $\mu$m thick and spaced 5 $\mu$m apart. The Mylar
film itself was 10 $\mu$m thick, with a transmission coefficient
greater than 0.9; the polarization efficiency of the polarizer was
measured to be better than 99.9%, so it can be assumed equal to unity
at HFI frequencies. The polarizer could rotate freely around its
axis using a stepper motor. There are exactly 32,000 steps in one
rotation, so the precision in relative angle is better than
1′.

#### 7.2.2 Reference for angle measurement

The reference position was defined by a pin fixed to the polarizer,
which was detected by electric contact with a copper strip
with a precision of $\pm 5$ motor steps, i.e. $\pm$0.∘06. We
measured the angle of this reference position with respect to the
focal plane using the light of a laser diffracted by the strips of the
polarizer; the diffraction pattern is formed by points aligned
orthogonally to the strips (i.e. parallel to the transmitted
polarization).

Two different methods were used to determine polarization angles with
respect to the focal plane. In the first method, we measured the
orientation with respect to the platform and used the mechanical position
of the instrument with respect to the platform to get the absolute
angle. In the second method, we measured the angle directly with
respect to the instrument. In both cases, we measured the same
angle and checked it was constant across the polarizer. Both methods
gave similar error estimates on the reference position angle, which
can safely be assumed to be lower than 0.∘3:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left|\Delta\theta^{\mbox{\tiny absolute}}\right|<0^{\circ}\!\!.3.$ |  | (57) |

#### 7.2.3 Data analysis

For this measurement, the polarizer was rotated by 5∘ steps and
signal was inegrated for 20 s at each position. Eight full rotations
of the polarizer were performed.

At each polarizer position, the signal from the source is sinusoidal
with a frequency of 10 Hz. It is demodulated fitting a sine curve over
a few periods, yielding around 60 independent measurements for each
stationary period of 20 seconds. The average and standard deviation of
these 60 measurements give the signal and its error for each 20 second
period, for a fixed position of the polarizer. The statistical error
was found to be typically below 1% of the signal.

We then fit the signal as a function of the polarizer angle to
estimate the polarization efficiency and the orientation of the
detectors. However, despite the good quality of the polarizer, we
found cross-polarization leakage of around 30%, much higher than that
found in Sect. [7.1](#S7.SS1 "7.1 Polarization efficiency ground measurements ‣ 7 Ground measurements ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"), with the Cardiff measurements: it
was probably due to standing waves between the polarizer and the focal
plane and made the detector polarization efficiency unmeasurable with
this setup. The angle that maximizes the signal gives the orientation
of the polarizer; however, the PSB angle must be given in the horn
aperture plane, which is slightly out of parallel with the polarizer
plane. We have performed ray-tracing simulations to estimate and
correct for this geometrical effect. The corrections lie between
-0.∘5 to 0.∘5, and the precision (set by the precision on the
position of the polarizer) is better than 0.∘15.

Figure 9:  Signal of PSB 100-1b with respect to the
angle in the horn aperture plane; each color represents one rotation
of the polarizer (8 turns); the signal is fitted using a standard
sine curve. The difference exhibits a systematic effect that can be
explained by standing waves between the polarizer and the focal
plane (see text).

Figure [9](#S7.F9 "Figure 9 ‣ 7.2.3 Data analysis ‣ 7.2 Orientation ground measurements ‣ 7 Ground measurements ‣ Planck pre-launch status: High Frequency Instrument polarization calibration") shows the curve obtained for a PSB at
100 GHz and the difference with the fitted model. The residuals show
a 90∘-periodic sine curve, which is present in some detectors. Some
detectors also have glitches, reproduced at the same position at each
rotation of the polarizer. These glitches mostly affect the highest
two frequency channels (545 and 857 GHz), i.e., only SWBs. As $\cos 2\theta$ and $\cos 4\theta$ are orthogonal functions over $2\pi$, the
fitted values for the angle and the polarization efficiency are
unchanged when adding such a term in the fitting model. However, we
cannot exclude that they may be contaminated by a systematic effect
like some other modes (mainly in mode $\cos 4\theta$). For example, if
the incoming radiation is the sum of two partially linearly polarized
radiations, one with orientation $\theta$ (rotating with the
polarizer) and one with fixed orientation $\theta\_{0}$, the signal
measured by the detector reads:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle s(\theta)$ | $\displaystyle\propto$ | $\displaystyle 1+\rho\cos 2(\theta-\theta\_{\mbox{\tiny det}})$ |  | (58) |
|  |  |  | $\displaystyle{}+\rho^{\prime}\cos 2(\theta-\theta\_{0})\left[1-\cos 2(\theta-\theta\_{\mbox{\tiny det}})\right]$ |  |

where $\theta\_{\mbox{\tiny det}}$ is the polarization orientation of
the detector. In this model, the angle measured through the phase of
the mode $\cos 2\theta$ will not be the detector polarization angle.

More generally, we can expand the signal as a Fourier series $s(\theta)=\sum\_{n=-N}^{+N}c\_{n}\mbox{e}^{in\theta}$ and fit its coefficients
$c\_{n}$ (which fulfill the condition $c\_{-n}^{\star}=c\_{n}$, as $s$ is a
real quantity). The coefficient $c\_{2}$, giving the dependence in $\cos 2\theta$, contains the information on polarization efficiency and
angle through its modulus and argument, and is independent of the other
modes. To estimate the error on the polarization angle without relying
on a particular model, we assume that the mode $c\_{2}$ is the sum of two
contributions, $c\_{2}=c\_{2}^{\mbox{\tiny pol}}+c\_{2}^{\mbox{\tiny syst}}$ (true polarization signal and induced systematic
effect). The maximum systematic error on the angle is then given by:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\max\left|\Delta\theta^{\mbox{\tiny syst}}\right|=\arctan\left|\frac{c\_{2}^{\mbox{\tiny syst}}}{c\_{2}^{\mbox{\tiny pol}}}\right|.$ |  | (59) |

We draw an upper bound on the systematic error by assuming that
$|c\_{2}^{\mbox{\tiny syst}}/c\_{2}^{\mbox{\tiny pol}}|\lesssim\max\_{n\neq 0,2}|c\_{n}/c\_{2}|$. However, as the systematic error is due to complex
interference between the polarizer, the focal plane and the horns, we
chose a conservative limit by taking for all detectors the maximum of
this estimate among all PSBs. The statistical error on the
coefficients $c\_{n}$ being negligible compared to the systematic error,
we finally find the following upper limit on the total error on the
relative angle of each polarization sensitive detectors:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left|\Delta\theta^{\mbox{\tiny relative}}\right|<0^{\circ}\!\!.9.$ |  | (60) |

As an independent check, we compared the relative angle between PSBs
within each horn (which is close but not exactly equal to 90∘) with
the angles found using the setup described in
Sect. [7.1](#S7.SS1 "7.1 Polarization efficiency ground measurements ‣ 7 Ground measurements ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"). We found an agreement within the systematic
error bars for all horns except one, which is, however, within the
statistical plus systematic error bar (the statistical error coming
from the Cardiff measurements).

The case of SWBs is treated separately, as the statistical error is
not negligible in this case (due to the low polarization
efficiencies). We performed a similar analysis, taking into account
the statistical error. The results are gathered in
table [2](#A2.T2 "Table 2 ‣ Appendix B Polarization efficiencies and angles ‣ Planck pre-launch status: High Frequency Instrument polarization calibration"). Note that the SWBs are not meant to be used
for polarization measurements.

## 8 Discussion and conclusion

This paper focuses on the impact of polarized calibration parameters
(gain, polarization efficiency and detector orientation) on power
spectra in the context of Planck-HFI. We have developed a
semi-analytical method that allows us to compute quickly and easily
the impact of uncertainties on gain, polarization efficiency and
orientation on the $E$ and $B$-mode power spectra, while exactly
accounting for the scanning strategy and the combination of different
detectors. We used this method in the particular case of Planck-HFI
and derived constraints on the gain, polarization efficiency and
detector orientation needed to achieve Planck-HFI’s scientific goals.

Planck will use the orbital dipole to calibrate the total power for
each detector. We find that the relative uncertainty on the gain must
be lower than 0.15% to keep systematic error on $E$-mode power
spectrum below 10% of the cosmic variance in the multipole range
$\ell=2-1000$. Given the 0.2% accuracy on relative gain obtained by
WMAP ([Hinshaw et al. 2009](#bib.bib11)), we expect that HFI can achieve the 0.15%
requirements, thanks to the higher gain stability expected for HFI.

We show that the polarization efficiency uncertainty must be below
0.3% in order to achieve the required sensitivity for the
$E$-mode. The error on the primordial $B$-mode power spectrum will be
kept below 10% of the signal expected from a tensor-to-scalar ratio
$r=0.05$ in the multipole range $\ell=2-100$ if the polarization
efficiency is known to better than 10.3%. In this paper, we have
presented the results of the ground measurements on HFI PSBs
polarization efficiency, which show an accuracy of 0.3% that fulfills
the requirements for both $E$ and $B$-modes.

For the polarization orientation, we have distinguished a global
orientation error of the focal plane (which affects identically all
detectors) from a relative error (different for each detector). For
$E$-modes, we show that the requirement is 2.∘1 on the global
orientation knowledge and 1∘ on the relative orientation to keep
the error below 10% of the cosmic variance in the range
$\ell=2-1000$. Both these requirements are already fulfilled by the
ground measurements, in which we found 0.∘3 and 0.∘9
respectively. In order to measure a $B$-mode signal with a systematic
error lower than 10% for a tensor-to-scalar ratio $r=0.05$, the
global orientation must be known to better than 1.∘2 and the
relative orientation at better than 0.∘75. While the ground
measurements fulfill the requirement on global orientation, the
relative orientation knowledge will need to be improved in flight. For
Planck, we plan to use the Crab nebula as the primary polarization
calibrator ([Aumont et al. 2009](#bib.bib1)), which will also allow the
results presented in this paper to be cross-checked. The accuracy
of the ground measurements of polarization efficiencies and
orientations will allow the $E$-mode power spectrum to be measured,
with systematic errors lower than 10% of the cosmic variance,
provided that the other sources of systematic effects are controlled.

###### Acknowledgements.

Planck *(http://www.esa.int/Planck)* is a
project of the European Space Agency (ESA) with instruments provided
by two scientific Consortia funded by ESA member states (in
particular the lead countries: France and Italy) with contributions
from NASA (USA), and telescope reflectors provided in a
collaboration between ESA and a scientific Consortium led and funded
by Denmark.

## Appendix A Explicit forms of pointing related functions

We write the projection of the signal $\mathbf{m}$ into a sky map $\mathbf{s}$ as

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\hat{{\bf s}}$ | $\displaystyle=$ | $\displaystyle(\tilde{A}^{T}\tilde{A})^{-1}\tilde{A}^{T}{\bf m}$ |  | (61) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  | $\displaystyle=$ | $\displaystyle\left[\sum\_{d}\tilde{A}\_{d}^{T}\tilde{A}\_{d}\right]^{-1}\left[\sum\_{d}\tilde{A}\_{d}^{T}A\_{d}{\bf s}\right]$ |  | (62) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  | $\displaystyle=$ | $\displaystyle\left[\sum\_{d}\tilde{A}\_{d}^{T}\tilde{A}\_{d}\right]^{-1}\left[\sum\_{d}\Lambda\_{d}(\gamma\_{d},\epsilon\_{d},\omega\_{d}){\bf s}\right].$ |  | (63) |

Where $A$ is the pointing matrix. In this expression, $\Lambda\_{d}(\gamma\_{d},\epsilon\_{d},\omega\_{d})$ is an explicit function of $\gamma\_{d}$, $\epsilon\_{d}$ and $\omega\_{d}$. $\tilde{g}$, $\tilde{\rho}$ and $\tilde{\alpha}$ are only parameters.
If we note $t(d)$ the data samples of detector $d$, $\Lambda\_{d}$ reads

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Lambda\_{d}=\sum\_{t(d)}\left(\begin{array}[]{lll}(1+\gamma)&(\tilde{\rho}\_{d}+\epsilon\_{\rho})\cos 2(\tilde{\psi\_{d}}(t)+\omega\_{d})&(\tilde{\rho}\_{d}+\epsilon\_{\rho})\sin 2(\tilde{\psi\_{d}}(t)+\omega\_{d})\\ (1+\gamma)\tilde{\rho\_{d}}\cos 2\tilde{\psi\_{d}}(t)&\tilde{\rho\_{d}}(\tilde{\rho}\_{d}+\epsilon\_{\rho})\cos 2\tilde{\psi\_{d}}(t)\cos 2(\tilde{\psi\_{d}}(t)+\omega\_{d})&\tilde{\rho\_{d}}(\tilde{\rho}\_{d}+\epsilon\_{\rho})\cos 2\tilde{\psi\_{d}}(t)\sin 2(\tilde{\psi\_{d}}(t)+\omega\_{d})\\ (1+\gamma)\tilde{\rho\_{d}}\sin 2\tilde{\psi\_{d}}(t)&\tilde{\rho\_{d}}(\tilde{\rho}\_{d}+\epsilon\_{\rho})\sin 2\tilde{\psi\_{d}}(t)\cos 2(\tilde{\psi\_{d}}(t)+\omega\_{d})&\tilde{\rho\_{d}}(\tilde{\rho}\_{d}+\epsilon\_{\rho})\sin 2\tilde{\psi\_{d}}(t)\sin 2(\tilde{\psi\_{d}}(t)+\omega\_{d})\end{array}\right)$ |  | (64) |

Considering small variations around $\tilde{g}$, $\tilde{\rho}$ and $\tilde{\alpha}$, we can
write the perturbative expansion to first order for both $\gamma\ll 1$, $\epsilon\ll 1$
and $\omega\ll 1$ :

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta{\bf s}$ | $\displaystyle=$ | $\displaystyle\hat{{\bf s}}-{\bf s}$ |  | (65) |
|  |  | $\displaystyle=$ | $\displaystyle\left[\sum\_{d}\tilde{A}\_{d}^{T}\tilde{A}\_{d}\right]^{-1}\left[\sum\_{d}\tilde{A}\_{d}^{T}A\_{d}-\tilde{A}\_{d}^{T}\tilde{A}\_{d}\right]{\bf s}$ |  |
|  |  | $\displaystyle\equiv$ | $\displaystyle\left[\sum\_{d}\tilde{A}\_{d}^{T}\tilde{A}\_{d}\right]^{-1}\left[\sum\_{d}\Lambda\_{d}(\gamma\_{d},\epsilon\_{d},\omega\_{d})-\Lambda\_{d}(0,0,0)\right]{\bf s}$ |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  | $\displaystyle\simeq$ | $\displaystyle\left[\sum\_{d}\tilde{A}\_{d}^{T}\tilde{A}\_{d}\right]^{-1}\sum\_{d}\left[\frac{\partial\Lambda\_{d}}{\partial\gamma\_{d}}\gamma\_{d}+\frac{\partial\Lambda\_{d}}{\partial\epsilon\_{d}}\epsilon\_{d}+\frac{\partial\Lambda\_{d}}{\partial\omega\_{d}}\omega\_{d}\right]{\mathbf{s}}$ |  | (66) |

Straightforward generalization to second order reads:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta{\bf s}=\left[\sum\_{d}\tilde{A}\_{d}^{T}\tilde{A}\_{d}\right]^{-1}\sum\_{d}\left[\sum\_{e\in\{\gamma,\epsilon,\omega\}}\frac{\partial\Lambda\_{d}}{\partial e\_{d}}e\_{d}+\frac{1}{2}\sum\_{(e,e^{\prime})\in\{\gamma,\epsilon,\omega\}}\frac{\partial^{2}\Lambda\_{d}}{\partial e\_{d}\partial e^{\prime}\_{d}}e\_{d}e^{\prime}\_{d}\right]{\bf s}$ |  | (67) |

Derivatives of $\Lambda\_{d}(\gamma\_{d},\epsilon\_{d},\omega\_{d})$ with respect to uncertainties of gain $\gamma$, polarization efficiency $\epsilon$ and detector orientation $\omega$ are given by

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\left.\frac{\partial\Lambda\_{d}}{\partial\gamma\_{d}}\right|\_{(0,0,0)}$ | $\displaystyle=$ | $\displaystyle\sum\_{t(d)}\left(\begin{array}[]{lll}1&0&0\\ \cos 2\tilde{\psi}\_{d}(t)&0&0\\ \sin 2\tilde{\psi}\_{d}(t)&0&0\\ \end{array}\right)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\left.\frac{\partial\Lambda\_{d}}{\partial\epsilon\_{d}}\right|\_{(0,0,0)}$ | $\displaystyle=$ | $\displaystyle\sum\_{t(d)}\left(\begin{array}[]{lll}0&\cos 2\tilde{\psi}\_{d}(t)&\sin 2\tilde{\psi}\_{d}(t)\\ 0&\tilde{\rho\_{d}}\cos^{2}2\tilde{\psi}\_{d}(t)&\tilde{\rho\_{d}}\cos 2\tilde{\psi}\_{d}(t)\sin 2\tilde{\psi}\_{d}(t)\\ 0&\tilde{\rho\_{d}}\cos 2\tilde{\psi}\_{d}(t)\sin 2\tilde{\psi}\_{d}(t)&\tilde{\rho\_{d}}\sin^{2}2\tilde{\psi}\_{d}(t)\end{array}\right)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\left.\frac{\partial\Lambda\_{d}}{\partial\omega\_{d}}\right|\_{(0,0,0)}$ | $\displaystyle=$ | $\displaystyle\sum\_{t(d)}\left(\begin{array}[]{lll}0&-2\tilde{\rho\_{d}}\sin 2\tilde{\psi}\_{d}(t)&2\tilde{\rho\_{d}}\cos 2\tilde{\psi}\_{d}(t)\\ 0&-2\tilde{\rho\_{d}}^{2}\cos 2\tilde{\psi}\_{d}(t)\sin 2\tilde{\psi}\_{d}(t)&2\tilde{\rho\_{d}}^{2}\cos^{2}2\tilde{\psi}\_{d}(t)\\ 0&-2\tilde{\rho\_{d}}^{2}\sin^{2}2\tilde{\psi}\_{d}(t)&2\tilde{\rho\_{d}}^{2}\cos 2\tilde{\psi}\_{d}(t)\sin 2\tilde{\psi}\_{d}(t)\end{array}\right)$ |  |

And second order derivatives reads

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\left.\frac{\partial^{2}\Lambda\_{d}}{\partial\gamma\_{d}^{2}}\right|\_{(0,0,0)}$ | $\displaystyle=$ | $\displaystyle 0$ |  | (80) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\left.\frac{\partial^{2}\Lambda\_{d}}{\partial\epsilon\_{d}^{2}}\right|\_{(0,0,0)}$ | $\displaystyle=$ | $\displaystyle 0$ |  | (81) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\left.\frac{\partial^{2}\Lambda\_{d}}{\partial\omega\_{d}^{2}}\right|\_{(0,0,0)}$ | $\displaystyle=$ | $\displaystyle\sum\_{t(d)}\left(\begin{array}[]{lll}0&-4\tilde{\rho\_{d}}\cos 2\tilde{\psi}\_{d}(t)&-4\tilde{\rho\_{d}}\sin 2\tilde{\psi}\_{d}(t)\\ 0&-4\tilde{\rho\_{d}}^{2}\cos^{2}2\tilde{\psi}\_{d}(t)&-4\tilde{\rho\_{d}}^{2}\cos 2\tilde{\psi}\_{d}(t)\sin 2\tilde{\psi}\_{d}(t)\\ 0&-4\tilde{\rho\_{d}}^{2}\cos 2\tilde{\psi}\_{d}(t)\sin 2\tilde{\psi}\_{d}(t)&-4\tilde{\rho\_{d}}^{2}\sin^{2}2\tilde{\psi}\_{d}(t)\end{array}\right)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\left.\frac{\partial^{2}\Lambda\_{d}}{\partial\epsilon\_{d}\partial\omega\_{d}}\right|\_{(0,0,0)}$ | $\displaystyle=$ | $\displaystyle\sum\_{t(d)}\left(\begin{array}[]{lll}0&-2\sin 2\tilde{\psi}\_{d}(t)&2\cos 2\tilde{\psi}\_{d}(t)\\ 0&-4\tilde{\rho\_{d}}\cos 2\tilde{\psi}\_{d}(t)\sin 2\tilde{\psi}\_{d}(t)&4\tilde{\rho\_{d}}\cos^{2}2\tilde{\psi}\_{d}(t)\\ 0&-4\tilde{\rho\_{d}}\sin^{2}2\tilde{\psi}\_{d}(t)&4\tilde{\rho\_{d}}\cos 2\tilde{\psi}\_{d}(t)\sin 2\tilde{\psi}\_{d}(t)\end{array}\right)$ |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\left.\frac{\partial^{2}\Lambda\_{d}}{\partial\gamma\_{d}\partial\epsilon\_{d}}\right|\_{(0,0,0)}$ | $\displaystyle=$ | $\displaystyle\left.\frac{\partial^{2}\Lambda\_{d}}{\partial\gamma\_{d}\partial\omega\_{d}}\right|\_{(0,0,0)}=0$ |  | (90) |

## Appendix B Polarization efficiencies and angles

Table 1: Polarization efficiencies and orientations for Planck-HFI PSBs22
2
Notes. Ideal PSBs should have a
100% polarization efficiency. The error on polarization efficiency
is only statistical. Error on polarization orientation is due to
systematics: the absolute error is due to the error on the
measurement of the reference position; the relative error is due to
an optical systematic effect in the Saturne cryostat. The
statistical errors are negligible and therefore not shown in this table.

| Bolometer (PSB) | Polarization efficiency [%] | Polarization angle |
| --- | --- | --- |
| 100-1a | 94.7 $\pm$ 0.2 | 21.∘1 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 100-1b | 94.3 $\pm$ 0.3 | 109.∘9 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 100-2a | 96.2 $\pm$ 0.2 | 44.∘3 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 100-2b | 90.2 $\pm$ 0.2 | 133.∘5 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 100-3a | 90.1 $\pm$ 0.3 | 0.∘7 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 100-3b | 93.4 $\pm$ 0.2 | 90.∘6 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 100-4a | 95.7 $\pm$ 0.3 | 158.∘5 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 100-4b | 92.3 $\pm$ 0.2 | 70.∘0 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 143-1a | 83.3 $\pm$ 0.2 | 42.∘9 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 143-1b | 84.6 $\pm$ 0.2 | 135.∘2 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 143-2a | 87.5 $\pm$ 0.3 | 44.∘2 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 143-2b | 89.3 $\pm$ 0.3 | 134.∘0 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 143-3a | 83.9 $\pm$ 0.2 | 0.∘4 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 143-3b | 89.9 $\pm$ 0.2 | 93.∘7 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 143-4a | 93.1 $\pm$ 0.2 | 3.∘1 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 143-4b | 92.8 $\pm$ 0.2 | 91.∘5 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 217-5a | 95.0 $\pm$ 0.1 | 44.∘7 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 217-5b | 95.2 $\pm$ 0.2 | 133.∘9 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 217-6a | 94.9 $\pm$ 0.2 | 45.∘0 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 217-6b | 95.4 $\pm$ 0.2 | 134.∘8 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 217-7a | 94.0 $\pm$ 0.2 | 0.∘3 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 217-7b | 93.7 $\pm$ 0.1 | 91.∘2 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 217-8a | 94.2 $\pm$ 0.1 | 2.∘2 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 217-8b | 94.1 $\pm$ 0.1 | 92.∘5 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 353-3a | 88.7 $\pm$ 0.1 | 44.∘1 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 353-3b | 92.0 $\pm$ 0.1 | 132.∘4 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 353-4a | 87.0 $\pm$ 0.1 | 45.∘3 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 353-4b | 91.4 $\pm$ 0.1 | 135.∘2 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 353-5a | 84.4 $\pm$ 0.1 | 178.∘4 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 353-5b | 87.4 $\pm$ 0.1 | 90.∘3 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 353-6a | 87.3 $\pm$ 0.1 | 1.∘3 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |
| 353-6b | 88.5 $\pm$ 0.1 | 91.∘2 $\pm$ 0.∘9 [rel] $\pm$ 0.∘3 [abs] |

Table 2: Polarization efficiencies and
orientations for Planck-HFI SWBs33
3
Notes. Ideal SWBs should have a null polarization efficiency. Global uncertainty (0.∘3)
is common for all detector and not added.

| Bolometer (SWB) | Polarization efficiency [%] | Polarization angle |
| --- | --- | --- |
| 143-5 | 6.6 $\pm$ 0.3 | 65.∘7 $\pm$ 0.∘1 [stat] $\pm$   0.∘6 [syst] |
| 143-6 | 4.4 $\pm$ 0.3 | 70.∘6 $\pm$ 0.∘2 [stat] $\pm$   4.∘7 [syst] |
| 143-7 | 1.7 $\pm$ 0.4 | 102.∘8 $\pm$ 0.∘2 [stat] $\pm$   1.∘7 [syst] |
| 143-8 | 1.6 $\pm$ 0.5 | 75.∘7 $\pm$ 0.∘3 [stat] $\pm$   4.∘4 [syst] |
| 217-1 | 4.0 $\pm$ 0.2 | 98.∘4 $\pm$ 2.∘3 [stat] $\pm$   5.∘5 [syst] |
| 217-2 | 2.1 $\pm$ 0.1 | 82.∘5 $\pm$ 1.∘5 [stat] $\pm$   4.∘9 [syst] |
| 217-3 | 4.1 $\pm$ 0.2 | 170.∘9 $\pm$ 0.∘9 [stat] $\pm$   2.∘1 [syst] |
| 217-4 | 3.8 $\pm$ 0.6 | 120.∘0 $\pm$ 1.∘2 [stat] $\pm$   2.∘7 [syst] |
| 353-1 | 3.4 $\pm$ 0.2 | 103.∘1 $\pm$ 1.∘2 [stat] $\pm$   3.∘6 [syst] |
| 353-2 | 4.8 $\pm$ 0.1 | 114.∘6 $\pm$ 0.∘5 [stat] $\pm$   2.∘7 [syst] |
| 353-7 | 8.1 $\pm$ 0.1 | 121.∘5 $\pm$ 0.∘8 [stat] $\pm$   4.∘2 [syst] |
| 353-8 | 7.9 $\pm$ 0.1 | 133.∘0 $\pm$ 0.∘3 [stat] $\pm$   1.∘9 [syst] |
| 545-1 | 4.7 $\pm$ 0.1 | 129.∘1 $\pm$ 1.∘0 [stat] $\pm$   2.∘4 [syst] |
| 545-2 | 5.7 $\pm$ 0.1 | 139.∘1 $\pm$ 0.∘7 [stat] $\pm$   1.∘3 [syst] |
| 545-3 | 5.3 $\pm$ 0.1 | 150.∘3 $\pm$ 0.∘8 [stat] $\pm$   2.∘4 [syst] |
| 545-4 | 5.9 $\pm$ 0.1 | 145.∘6 $\pm$ 0.∘8 [stat] $\pm$   1.∘7 [syst] |
| 857-1 | 7.8 $\pm$ 1.8 | 157.∘3 $\pm$ 2.∘1 [stat] $\pm$   5.∘1 [syst] |
| 857-2 | 6.3 $\pm$ 0.1 | 108.∘4 $\pm$ 4.∘0 [stat] $\pm$ 16.∘5 [syst] |
| 857-3 | 8.6 $\pm$ 0.8 | 176.∘8 $\pm$ 1.∘4 [stat] $\pm$   2.∘6 [syst] |
| 857-4 | 6.3 $\pm$ 0.8 | 161.∘9 $\pm$ 2.∘3 [stat] $\pm$   6.∘2 [syst] |
