<!-- fulltext source=arxiv_html slug=arXiv-1109.6322 fetched=2026-09-18T01:06:48+00:00 -->

# Searching for Dark Matter in the CMB: A Compact Parameterization of Energy Injection from New Physics

Douglas P. Finkbeiner
Email: [dfinkbeiner@cfa.harvard.edu](mailto:dfinkbeiner@cfa.harvard.edu)
Affiliation: Harvard-Smithsonian Center for Astrophysics, 60 Garden St., Cambridge, MA 02138, USA
Affiliation: Physics Department, Harvard University, Cambridge, MA 02138, USA
  
Silvia Galli
Email: [galli@apc.univ-paris7.fr](mailto:galli@apc.univ-paris7.fr)
Affiliation: Laboratoire Astroparticule et Cosmologie (APC), Université Paris Diderot, 75205 Paris cedex 13, France
Affiliation: Physics Department and INFN, Universita’ di Roma “La Sapienza”, Ple Aldo Moro 2, 00185, Rome, Italy
  
Tongyan Lin
Email: [tongyan@physics.harvard.edu](mailto:tongyan@physics.harvard.edu)
Affiliation: Physics Department, Harvard University, Cambridge, MA 02138, USA
  
Tracy R. Slatyer
Email: [tslatyer@ias.edu](mailto:tslatyer@ias.edu)
Affiliation: School of Natural Sciences, Institute for Advanced Study, Princeton, NJ 08540, USA

###### Abstract

High-precision measurements of the temperature and polarization
anisotropies of the cosmic microwave background radiation have been
employed to set robust constraints on dark matter annihilation during
recombination. In this work we improve and generalize these
constraints to apply to energy deposition during the recombination era
with arbitrary redshift dependence. Our approach also provides more
rigorous and model-independent bounds on dark matter annihilation and
decay scenarios. We employ principal component analysis to identify a
basis of weighting functions for the energy deposition. The
coefficients of these weighting functions parameterize any energy
deposition model and can be constrained directly by experiment. For
generic energy deposition histories that are currently allowed by WMAP 7 data,
up to 3 principal component coefficients are measurable by Planck and
up to 5 coefficients are measurable by an ideal cosmic variance
limited experiment.
For WIMP dark matter, our analysis demonstrates that the effect on the
CMB is described well by a single (normalization) parameter and a “universal”
redshift dependence for the energy deposition history. We give WMAP 7
constraints on both generic energy deposition histories and the universal WIMP case.

###### pacs

95.35.+d,98.80.Es

## I Introduction

Measurements of the cosmic microwave background (CMB) in the past decade by experiments including WMAP, ACBAR and BOOMERANG [[1](#bib.bib1), [2](#bib.bib2), [3](#bib.bib3)], and more recently SPT, QUaD and ACT [[4](#bib.bib4), [5](#bib.bib5), [6](#bib.bib6)], have provided an unprecedented window onto the universe around redshift 1000. With the advent of the Planck Surveyor [[7](#bib.bib7)], the successor experiment to WMAP, percent-level modifications to recombination will be observable. Planck has already completed three sky surveys and begun a fourth, and cosmological data are expected to be released publicly in 2012-13.

Accurate measurements of the CMB have the potential to probe the physics of dark matter (DM) beyond its gravitational interactions. In the large class of models where the DM is a thermal relic, its cosmological abundance is determined by its annihilation rate in the early universe: the correct relic density ($\sim 22\%$ of the energy density of the universe) is obtained for an $s$-wave annihilation cross section of $\langle\sigma v\rangle\approx 3\times 10^{-26}$ cm3/s during freezeout.

DM annihilation at this rate modifies the ionization history of the universe and has a potentially measurable effect on the CMB. During the epoch of recombination, DM annihilation produces high-energy photons and electrons, which heat and ionize the hydrogen and helium gas as they cool. The result is an increased residual ionization fraction after recombination, giving rise to a low-redshift tail in the last scattering surface. The broader last scattering surface damps correlations between temperature fluctuations, while enhancing low-$\ell$ correlations between polarization fluctuations.

The resulting constraints on the dark matter annihilation rate have been studied by several authors [[8](#bib.bib8), [9](#bib.bib9), [10](#bib.bib10), [11](#bib.bib11), [12](#bib.bib12), [13](#bib.bib13), [14](#bib.bib14)]. These bounds have a notable advantage over other indirect constraints on dark matter annihilation, in that they are independent of the DM distribution in the present day, and do not suffer from uncertainties associated with Galactic astrophysics. They depend only on the cosmological DM density, which is well measured; the DM mass; the annihilation rates to the final states; and the standard physics of recombination. Recombination modeling, while not simple, involves only well-understood conventional physics, and the latest models are thought to be accurate at the sub-percent level required for Planck data [[15](#bib.bib15), [16](#bib.bib16)].

Current limits from WMAP already significantly constrain models of light dark matter with masses of around a few GeV and below, if the annihilation rate at recombination is the thermal relic cross section. Heavier DM is also constrained if the annihilation rate is enhanced at low velocities or for other reasons is much larger than the thermal relic cross section at recombination. Models lying in these general categories are also of significant interest for their possible connection with experimental anomalies.

The DAMA/LIBRA [[17](#bib.bib17)] and CoGeNT [[18](#bib.bib18), [19](#bib.bib19)] direct detection experiments have reported excess events and annual modulation that may have a consistent explanation as originating from scattering of $\mathcal{O}(5-10)$ GeV WIMPs (e.g. [[20](#bib.bib20)]). Results from the XENON10, XENON100 and CDMS experiments are in tension with this interpretation [[21](#bib.bib21), [22](#bib.bib22)], but there is ongoing debate on the sensitivity of these experiments to the very low-energy nuclear recoils in question (see e.g. [[23](#bib.bib23), [24](#bib.bib24)]).

The PAMELA [[25](#bib.bib25)], *Fermi* [[26](#bib.bib26)], PPB-BETS [[27](#bib.bib27)], ATIC [[28](#bib.bib28)] and H.E.S.S [[29](#bib.bib29)] have measured electron and positron cosmic rays in the neighborhood of the Earth, and found results consistent with a new primary source of $e^{\pm}$ in the $10-1000$ GeV energy range. If the signal is attributed to dark matter annihilation then the annihilation rate in the Galactic halo today must be 1-3 orders of magnitude above the canonical thermal relic value [[30](#bib.bib30), [31](#bib.bib31)]. This has motivated models of dark matter with enhanced annihilation at low velocities [[32](#bib.bib32), [33](#bib.bib33)]. While this enhancement would not be significant during freezeout, it would be effective at recombination when the typical velocity of dark matter is $v\sim 10^{-8}c$ [[9](#bib.bib9)].

With the release of data from Planck expected in the next two years, models falling into these categories should either be robustly ruled out, or give rise to a measurable signal [[9](#bib.bib9), [10](#bib.bib10), [13](#bib.bib13)]. If no signal is observed, the sensitivity of Planck will allow us to probe regions of parameter space relevant for supersymmetric models, where the DM is a thermal relic with mass of several tens of GeV. It is timely to explore improvements to these constraints.

The approach of previous studies has been to specify the energy deposition history (redshift dependence) and then calculate the effect on the ionization history and anisotropy spectrum using public codes such as RECFAST and CAMB. A single parameter describing the normalization of the signal is then added to the standard likelihood analysis using CosmoMC, and bounded by WMAP observations. The redshift dependence has been studied in two cases: in the “on-the-spot” case, assuming that the amount of energy deposited to the gas precisely tracks the rate of dark matter annihilation (e.g. [[8](#bib.bib8), [9](#bib.bib9), [14](#bib.bib14)]), or employing detailed energy deposition histories for specific models (e.g. [[10](#bib.bib10), [13](#bib.bib13), [14](#bib.bib14)]). In the first case, model-independent constraints are obtained, but without a precise way to connect the bounds to any particular model. The second case only precisely constrains specific models.

While these analyses have been adequate for simple estimates of whether a model is strongly ruled out, easily allowed, or on the borderline, the upcoming high-precision data from Planck demand a more careful model-independent analysis. Such an analysis can also be applied to more general classes of energy deposition histories during and after recombination: for example, the energy deposited by a late-decaying particle species, decay from an excited state of the dark matter, or dark matter annihilation in models where the redshift dependence of the annihilation rate has an unusual form (as in some models of asymmetric dark matter).

In this work we exploit the fact that the effects of energy deposition at different redshifts are not uncorrelated. Any arbitrary energy deposition history can be decomposed into a linear combination of orthogonal basis vectors, with orthogonal effects on the observed CMB power spectra ($C\_{\ell}$’s). For a broad range of smooth energy deposition histories, the vast majority of the effect on the $C\_{\ell}$’s can be described by a small number of independent parameters, corresponding to the coefficients of the first few vectors in a well-chosen basis. These parameters in turn can be expressed as (orthogonal) weighted averages of the energy deposition history over redshift.

We employ principal component analysis (PCA) to make this statement quantitative and derive the relevant weight functions, and the corresponding perturbations to the $C\_{\ell}$ spectra. Our approach in principle generalizes to all possible energy deposition histories. To investigate the number of observable parameters, we consider generic perturbations about two physically interesting fiducial cases. We focus primarily on the example of dark matter annihilation, or any other scenario where the power deposited per volume scales approximately as $(1+z)^{6}$ (i.e. as density squared), as an energy deposition mechanism, but also show results for the case of dark matter decay, or similar scenarios where the power deposited scales as $(1+z)^{3}$.

Our computation of the effects of energy deposition on the CMB anisotropies, and the approximations we use for estimating the significance of these effects in experimental data, are described in §[II](#S2 "II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"). In §[III](#S3 "III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") we present our principal component analysis for both ‘‘annihilation-like’’ and ‘‘decay-like’’ general energy deposition histories11
1
Files containing the results of these analyses are available online at http://nebel.rc.fas.harvard.edu/epsilon/; see also Appendix [C](#A3 "Appendix C Web files description ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics").. There are significant degeneracies between energy deposition and perturbations to the cosmological parameters, and so we marginalize over the standard cosmological parameters when deriving the principal components22
2
We test the effect of including additional cosmological parameters (running of the scalar spectral index, the number of massless neutrino species, and the primordial He fraction) and find no large degeneracy with energy injection, justifying our neglect of these additional parameters in our main analysis..

We then address the constraints on and detectability of the principal components in current and future experiments. Given a $C\_{\ell}$ spectrum observed by an experiment (e.g. Planck), we can measure the residual with respect to the best-fit standard $\Lambda$CDM model, and then project this residual onto the $C\_{\ell}$-space directions corresponding to the principal components. Given any model for the energy deposition history, we can then ask if the reconstructed coefficients for the various principal components are consistent with the model. Of course, for the later principal components the effect on $C\_{\ell}$’s is so small that very little information on their coefficients can be recovered. In §[IV](#S4 "IV Detectability ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), we make this statement quantitative, and estimate the number of principal components whose coefficients could be detectable in Planck and an ideal cosmic variance limited (CVL) experiment, subject to constraints from WMAP 7. The CVL case presents a hard upper limit on the number of independent parameters describing the energy deposition history that can profitably be retained in the analysis. We also discuss the bias to the standard cosmological parameters, in the case where there is non-zero energy deposition that is neglected in the analysis; in our framework it is straightforward to characterize the biases to the cosmological parameters for an arbitrary energy deposition history.

In §[V](#S5 "V A universal 𝑝_ann⁢(𝑧) for WIMP annihilation ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") we present a separate principal component analysis for the more limited case of conventional GeV-TeV WIMPs annihilating to Standard Model final states. We demonstrate that in this case, all the effect of dark matter annihilation can be captured by one parameter only, i.e. the amplitude of the first principal component.

Finally, in §[VI](#S6 "VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), we estimate the constraints on the principal components obtainable with current (WMAP 7) and future (Planck, CVL) experiments with a full likelihood analysis using the CosmoMC code. We employ here the principal components obtained with the Fisher matrix analysis – which assumes that the effect on the CMB scales linearly with the energy deposition. We illustrate the range of validity of this assumption for the different experiments considered.
We check that the constraints previously obtained with our Fisher matrix analysis – which assumes Gaussian likelihood functions – are compatible with the ones obtained with the CosmoMC analysis.
We check that the constraints on a given energy deposition history can be reconstructed from the constraints on the principal components.

Appendix [A](#A1 "Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") considers the effects on the analysis of changing various assumptions and conventions, including the effect of additional cosmological parameters and using different codes to calculate the ionization histories. We find that the only such choice that non-negligibly modifies the early (detectable) principal components is the treatment of Lyman-$\alpha$ photons, although the inclusion of additional cosmological parameters can change the constraints at the $\sim 10\%$ level.
Appendix [B](#A2 "Appendix B Review of marginalization and biases ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") discusses marginalization over the cosmological parameters. Appendix [C](#A3 "Appendix C Web files description ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") describes the results from this analysis that we have made available online.

## II The Effect of Energy Injection

Figure 1: 
Rate of Hydrogen ionization from energy deposition, relative to the number density of ionized
Hydrogen ($n\_{ion}^{0}$) when there is no energy deposition. The lines
shown are the cases of constant $p\_{\mathrm{ann}}$ and $p\_{\mathrm{dec}}$, corresponding to
on-the-spot energy deposition from dark matter annihilation and dark
matter decay, respectively.

We begin by considering DM annihilation-like or decay-like energy
deposition histories. The energy injection from these sources scales
respectively as density squared and density, so these cases cover the
generic scenarios where energy is injected by two-body or one-body
processes. It is convenient to express the energy injection as a slowly
varying function of $z$ that depends on the source of the energy injection
(e.g. the WIMP model) and a term containing cosmological parameters. We
parameterize the energy deposition histories, respectively, as,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\left(\frac{dE}{dt\,dV}\right)\_{\mathrm{ann}}$ | $\displaystyle=p\_{\mathrm{ann}}(z)c^{2}\Omega\_{\mathrm{DM}}^{2}\rho\_{c}^{2}(1+z)^{6},$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\left(\frac{dE}{dt\,dV}\right)\_{\mathrm{dec}}$ | $\displaystyle=p\_{\mathrm{dec}}(z)c^{2}\Omega\_{\mathrm{DM}}\rho\_{c}(1+z)^{3},$ |  | (1) |

where $p\_{\mathrm{ann}}(z)$ (or $p\_{\mathrm{dec}}(z)$) contains all of the information about the
source of energy injection and the efficiency with which that
energy ionizes the gas. We generically refer to $p\_{\mathrm{ann}}$ and $p\_{\mathrm{dec}}$ as the
“energy deposition yield.”
For consistency with [[14](#bib.bib14)], we express $p\_{\mathrm{ann}}(z)$ in
units of cm3/s/GeV, while the units of $p\_{\mathrm{dec}}(z)$ are s-1. If
the energy injection is due to DM annihilation, $p\_{\mathrm{ann}}=f(z)\langle\sigma v\rangle/m\_{\mathrm{DM}}$ [[14](#bib.bib14)], where $f(z)$ is
an $\mathcal{O}(1)$ dimensionless efficiency factor
[[10](#bib.bib10)]; if the energy injection is due to DM decay,
$p\_{\mathrm{dec}}(z)=f(z)/\tau$, where $\tau$ is the decay lifetime. Other
authors have written $p\_{\mathrm{ann}}$ in units of m3/s/kg
[[9](#bib.bib9)], or parameterized the energy deposition in
eV/s/baryon [[8](#bib.bib8), [10](#bib.bib10), [11](#bib.bib11)].
For calibration, the energy deposition from a 100 GeV thermal relic
WIMP with $f(z)=1$ corresponds to $p\_{\mathrm{ann}}\approx 3\times 10^{-28}\mathrm{cm}^{3}$/s/GeV $\approx 1.7\times 10^{-7}\mathrm{m}^{3}$/s/kg,
or an energy deposition of $2.1\times 10^{-24}$ eV/s/H, assuming the WMAP 7 best-fit cosmology. Throughout this work, we employ the cosmological parameters from [[34](#bib.bib34)] as a baseline: explicitly, $\omega\_{b}=2.258\times 10^{-2}$, $\omega\_{c}=0.1109$, $A\_{s}$($k$=0.002 Mpc-1) $=2.43\times 10^{-9}$, $n\_{s}=0.963$, $\tau=0.088$, $H\_{0}=71.0$ km/s/Mpc.

Energy deposition during recombination primarily affects the CMB through
additional ionizations; the modified ionization history then leads to an
increased width for the surface of last scattering. An alternate approach to
studying generic energy deposition histories might be to study generic
ionization histories [[35](#bib.bib35)], since the former can be directly mapped to the
latter. We frame the problem in terms of energy deposition histories because
this provides direct constraints on physical energy injection models.

Suppose we are interested primarily in a class of energy deposition
histories for which the energy deposition yield $p(z)$ (that is, $p\_{\mathrm{ann}}(z)$ or $p\_{\mathrm{dec}}(z)$, as
appropriate) is not very rapidly varying. Then we can discretize
$p(z)$ as a sum over a basis of $N$ $\delta$-function-like energy
deposition histories, $p(z)=\sum\_{i=1}^{N}\alpha\_{i}G\_{i}(z)$. The basis
functions $G\_{i}(z)$ are (by default) Gaussians with $\sigma=\Delta z/4$, centered on $z\_{i}$ ($i=1..N$), where $\Delta z$ is the spacing
between the $z\_{i}$. They are normalized such that $\int dzG\_{i}(z)=\Delta z$. For example, in the limit of large $N$ an energy deposition history
with constant $p(z)=p\_{0}$ corresponds to $\alpha\_{i}=p\_{0}$ for all $i$.

If the energy deposition is small enough, the effect on the CMB
anisotropy power spectrum is linear in the energy depositions at
different redshifts [$\delta C\_{l}(p(z))=\delta C\_{l}(\sum\_{i=1}^{N}\alpha\_{i}G\_{i}(z))=\sum\_{i=1}^{N}\delta C\_{l}(\alpha\_{i}G\_{i}(z))$], and in the amount of energy deposition at any
redshift [$\delta C\_{l}(\sum\_{i=1}^{N}\alpha\_{i}G\_{i}(z))=\sum\_{i=1}^{N}\alpha\_{i}\delta C\_{l}(G\_{i}(z))$]. Then the effect of an arbitrary energy deposition history can be
determined simply from studying the basis functions $G\_{i}(z)$. We will
assume linearity throughout this work, and justify that assumption in
§[II.4](#S2.SS4 "II.4 Numerical stability of derivatives and linearity ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics").

Of course, given any annihilation-like energy deposition history, it can be rewritten in decay-like form with a strongly redshift-dependent $p(z)$, and vice versa. The basis of $G\_{i}(z)$ functions can describe any energy deposition history, at least in the large-$N$ limit. However, the very different “underlying” redshift dependence in the two cases, and the uncertainties associated with the annihilation rate at low redshift (due to the onset of structure formation), motivate us to study different redshift ranges in the two cases.

For each $G\_{i}$, we can compute the effect on the ionization history
and the anisotropy spectrum in the limit of small energy deposition. We
determine $\partial C^{TT}\_{\ell}/\partial\alpha\_{i},\,\partial C^{EE}\_{\ell}/\partial\alpha\_{i},\,\partial C^{TE}\_{\ell}/\partial\alpha\_{i}$ $\forall i,\ell$. In our default analysis we employ the
CosmoRec and CAMB codes, with the prescription for
including the extra energy deposition laid out in [[36](#bib.bib36), [8](#bib.bib8)]. If there are $N$ basis functions and we take
$n\_{\ell}$ spherical harmonics into account, this yields an $n\_{\ell}\times N$ transfer matrix $T$ whose $(\ell,i)$th element is,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{\partial C\_{\ell}}{\partial\alpha\_{i}}=\left\{\frac{\partial C^{TT}\_{\ell}}{\partial\alpha\_{i}},\,\frac{\partial C^{EE}\_{\ell}}{\partial\alpha\_{i}},\,\frac{\partial C^{TE}\_{\ell}}{\partial\alpha\_{i}}\right\}.$ |  | (2) |

In this work we focus primarily on annihilation-like energy deposition histories,
for which we restrict ourselves to the $80<z<1300$ range; as a
default, we will take 50 redshift bins covering this range. At higher
redshifts the universe is ionized and so the effect of energy
deposition on the ionization history is negligible, while at lower
redshifts the DM number density becomes so small that the energy
injected from annihilation is insignificant, as shown in Figure
[1](#S2.F1 "Figure 1 ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"). This in turn justifies our neglect of DM
structure formation: while for $z\lesssim 100$, DM clumps start to
form and the annihilation rate no longer tracks the square of the
average relic density, the energy injection is already sufficiently
suppressed that the signal remains negligible.

For DM decay, the signal is not nearly so suppressed at low redshifts,
and so we consider the redshift range $10<z<1300$. With this
expanded redshift range, we switch from linear to log binning, with 90
bins covering this redshift range33
3
Log binning can of course
also be employed for the annihilation-like case; there is no clear
best choice there, so we will use linear binning as the default but
show results for both options. See Appendix [A](#A1 "Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") for a
discussion.; we take the basis functions $G\_{i}(\ln(1+z))$ to be
Gaussians in $\ln(1+z)$, normalized so that their integral with
respect to $d\ln(1+z)$ is given by the spacing between the log bins
$\Delta\ln(1+z)$. With these choices, again an energy deposition history with
constant $p(z)=p\_{0}$ corresponds (in the large-$N$ limit) to $p\_{0}\sum\_{i=1}G\_{i}$.

We again ignore structure formation in the decay-like case, where the
total power injected depends only on the average density. The universe
is rather transparent to the products of DM decay and annihilation at
these redshifts, so even a very spatially non-uniform distribution of
energy injection would not be expected to cause ionization or
temperature hot-spots (at least for particles injected at weak-scale
energies; de-excitation of nearly-degenerate states or annihilation of
very light DM might change this conclusion to some degree). Modeling
of reionization may pose a more significant challenge for analyses
relying on low redshifts ($z\sim 10$); note, however, that the
transparency of the universe at these redshifts means that in
realistic scenarios (even decay-like scenarios) the bulk of the effect
on the CMB comes from earlier times.

### II.1 Brief review of the Fisher matrix

The degree to which energy deposition is observable in the CMB can be
captured by the Fisher matrix for energy deposition, denoted $F\_{e}$,
which is obtained by contracting the transfer matrix $T$ (Equation
[2](#S2.E2 "In II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")) with the appropriate covariance matrix for
the $C\_{\ell}$’s (e.g. [[37](#bib.bib37), [38](#bib.bib38), [39](#bib.bib39)]),

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Sigma\_{\ell}$ | $\displaystyle=\frac{2}{2\ell+1}\times$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\left(\begin{array}[]{ccc}\left(C\_{\ell}^{TT}\right)^{2}&\left(C\_{\ell}^{TE}\right)^{2}&C\_{\ell}^{TT}C\_{\ell}^{TE}\\ \left(C\_{\ell}^{TE}\right)^{2}&\left(C\_{\ell}^{EE}\right)^{2}&C\_{\ell}^{EE}C\_{\ell}^{TE}\\ C\_{\ell}^{TT}C\_{\ell}^{TE}&C\_{\ell}^{EE}C\_{\ell}^{TE}&\left[\left(C\_{\ell}^{TE}\right)^{2}+C\_{\ell}^{TT}C\_{\ell}^{EE}\right]\end{array}\right),$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\left(F\_{e}\right)\_{ij}=\sum\_{\ell}\left(\frac{\partial C\_{\ell}}{\partial\alpha\_{i}}\right)^{T}\cdot\Sigma\_{\ell}^{-1}\cdot\frac{\partial C\_{\ell}}{\partial\alpha\_{j}}.$ |  | (6) |

For experiments other than the perfect cosmic variance limited (CVL)
case, noise is included by replacing $C\_{\ell}^{TT,EE}\rightarrow C\_{\ell}^{TT,EE}+N\_{\ell}^{TT,EE}$, where $N\_{\ell}$ is the effective
noise power spectrum and is given by:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $N\_{\ell}=(\omega\_{p})^{-1}e^{\ell(\ell+1)\theta^{2}}$ |  | (7) |

Here $\theta$ describes the beam width (FWHM = $\theta\sqrt{8\ln 2}$), and the raw sensitivity is $(\omega\_{p})^{-1}=(\Delta T\times FWHM)^{2}$, with all angles in radians. The standard deviation of the
parameter $\alpha\_{i}$, marginalized over uncertainties in the other
parameters, is given by
$\sigma\_{\alpha\_{i}}\geq(F\_{e}^{-1})^{1/2}\_{ii}$. The parameter $\alpha\_{i}$
is then detectable at $1\sigma$ if its signal-to-noise
$\alpha\_{i}/\sigma\_{\alpha\_{i}}$ is larger than 1.

So far, we have not taken into account covariance between the standard
cosmological parameters and the energy deposition parameters, but in
fact there are significant degeneracies between them. In particular,
shifting the primordial scalar spectral index $n\_{s}$ can absorb much of
the effect of energy deposition [[8](#bib.bib8), [9](#bib.bib9)]. Therefore we must marginalize over the cosmological
parameters, since the naively most measurable energy deposition history
may be strongly degenerate with them and thus difficult to
constrain. We parameterize the usual six-dimensional cosmological
parameter space by the following set of parameters: the physical
baryon density, $\omega\_{b}\equiv\Omega\_{b}h^{2}$, the physical CDM
density, $\omega\_{c}\equiv\Omega\_{c}h^{2}$, the primordial scalar
spectral index, $n\_{s}$, the normalization, $A\_{s}$(k = 0.002/Mpc), the
optical depth to reionization, $\tau$, and the Hubble parameter $H\_{0}$.

Using exactly the same machinery as described above for the energy
deposition histories, we determine the derivatives of the $C\_{\ell}$’s with
respect to changes in the cosmological parameters, again assuming that
these changes are in the linear regime. Then these $C\_{\ell}$
derivatives are vectors spanning an $n\_{c}$-dimensional subspace of the
space of all $C\_{\ell}$ derivatives (where for the standard parameter
set $n\_{c}=6$); only directions orthogonal to this subspace can be
constrained. We can regard marginalization over the cosmological
parameters as simply projecting out the components of the energy
deposition derivatives orthogonal to this subspace44
4
See
Appendix [B](#A2 "Appendix B Review of marginalization and biases ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") for a detailed explanation of this projection
and how it relates to the standard marginalization prescription..

In analogy with Equation [6](#S2.E6 "In II.1 Brief review of the Fisher matrix ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), we now use the derivatives
with respect to both energy deposition and the cosmological parameters
to construct the full Fisher matrix,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $F\_{0}=\left(\begin{array}[]{cc}F\_{e}&F\_{v}\\ F\_{v}^{T}&F\_{c}\end{array}\right),$ |  | (8) |

where $F\_{e}$ is the Fisher matrix for solely the energy deposition
parameters, $F\_{c}$ is the Fisher matrix of the cosmological parameters,
and $F\_{v}$ contains the cross terms. The usual prescription for
marginalization is to invert the Fisher matrix, remove the rows and
columns corresponding to the cosmological parameters, and invert the
resulting submatrix to obtain the marginalized Fisher matrix $F$
(e.g. [[39](#bib.bib39)]). When the number of energy deposition
parameters is much greater than the number of cosmological parameters,
it is convenient to take advantage of the block-matrix inversion,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $F\_{0}^{-1}=\left(\begin{array}[]{cc}\left(F\_{e}-F\_{v}F\_{c}^{-1}F\_{v}^{T}\right)^{-1}&-\left(F\_{e}-F\_{v}F\_{c}^{-1}F\_{v}^{T}\right)^{-1}F\_{v}F\_{c}^{-1}\\ -F\_{c}^{-1}F\_{v}^{T}\left(F\_{e}-F\_{v}F\_{c}^{-1}F\_{v}^{T}\right)^{-1}&F\_{c}^{-1}\left(1+F\_{v}^{T}\left(F\_{e}-F\_{v}F\_{c}^{-1}F\_{v}^{T}\right)^{-1}F\_{v}F\_{c}^{-1}\right)\end{array}\right).$ |  | (9) |

We can now read off the marginalized Fisher matrix as $F=F\_{e}-F\_{v}F\_{c}^{-1}F\_{v}^{T}$ (note that $F$ has the same units as
$F\_{e}$).

The Fisher matrix approach to estimate detectability is optimistic in
the sense that it assumes the likelihood function is Gaussian about
its maximum; for non-Gaussian likelihoods, the significance of a given
energy deposition history will generally be smaller, and any constraints on the
amount of energy deposition will be weakened [[39](#bib.bib39)]. We
verify that the Fisher matrix method gives results consistent with
previous studies of WMAP limits on constant $p\_{\mathrm{ann}}$ in
§[II.3](#S2.SS3 "II.3 Comparison to previous results ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics").

### II.2 Experimental parameters

For comparison to the existing literature and constraint forecasting,
we consider the WMAP 5, WMAP 7 and Planck experiments, as well as a
theoretical experiment that is CVL up to $\ell=2500$. The beam width
and sensitivity parameters for WMAP and Planck are given in Table
[1](#S2.T1 "Table 1 ‣ II.2 Experimental parameters ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"). We use only the $W$ band for WMAP and the
143 GHz band for Planck, under the conservative assumption that the
other bands will be used to remove systematics. The effect of partial
sky coverage is included by dividing $\Sigma\_{\ell}$ by $f\_{\mathrm{sky}}=0.65$.

| Experiment | Beam | $10^{6}\Delta T/T$ | $10^{6}\Delta T/T$ |
| --- | --- | --- | --- |
|  | FWHM (arcmin) | (I) | (Q,U) |
| WMAP (5 yr, Q band) | 29 | 6.7 | 9.5 |
| WMAP (5 yr, V band) | 20 | 7.9 | 11.1 |
| WMAP (5 yr, W band) | 13 | 7.6 | 10.7 |
| Planck (100 GHz) | 10 | 2.5 | 4.0 |
| Planck (143 GHz) | 7.1 | 2.2 | 4.2 |
| Planck (217 GHz) | 5.0 | 4.8 | 9.8 |

Table 1:  Detector sensitivities and beams
for different CMB temperature and polarization experiments. Results
for WMAP temperature sensitivity are taken from
[[40](#bib.bib40)], with the noise reduced by $\sqrt{5/4}$
($\sqrt{7/4}$ for WMAP 7) to account for the longer integration
time. The polarization noise for WMAP is taken to be $\sqrt{2}\times$ the temperature noise. WMAP beam widths are taken from
[[41](#bib.bib41)]. The sensitivity and beam width for Planck are
taken from the Planck Blue Book, available at
http://www.rssd.esa.int/SA/PLANCK/docs, and assume 14 months
of Planck data.

### II.3 Comparison to previous results

Figure 2: The effect of the number of included $\ell$’s, and the number of included frequency bands, on the constraint on a constant-$p\_{\mathrm{ann}}$ energy deposition history; here we show the value of $p\_{\mathrm{ann}}$ corresponding to a $2\sigma$ signal.

Constraints on energy deposition from WMAP 7 have been studied
previously in the case where $p\_{\mathrm{ann}}(z)=p\_{\mathrm{ann}}$ is constant
[[9](#bib.bib9), [14](#bib.bib14)]. We have obtained
analogous constraints using the estimates for experimental sensitivity
described in §[II.1](#S2.SS1 "II.1 Brief review of the Fisher matrix ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")-[II.2](#S2.SS2 "II.2 Experimental parameters ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), taking the six
standard cosmological parameters and $p\_{\mathrm{ann}}$ as our parameter set, and
marginalizing over the cosmological parameters.

Note that in this simplified scenario there is no need for the Gaussian basis functions described at the start of the section, and rather than describe the effect of an arbitrary energy deposition history by the “transfer matrix” $T$ (Equation [2](#S2.E2 "In II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")) we simply compute the effect on the $C\_{\ell}$’s of each of a range of non-zero $p\_{\mathrm{ann}}$ values using CosmoRec and CAMB. Since no evidence for energy deposition has been found to date, we use the predictions of the best-fit standard cosmological model (as determined by WMAP 7 [[34](#bib.bib34)]) as a proxy for the WMAP data. Using the covariance matrix and prescription for marginalization laid out in §[II.1](#S2.SS1 "II.1 Brief review of the Fisher matrix ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), we compute the $\Delta\chi^{2}$ with the null hypothesis for each $p\_{\mathrm{ann}}$, and by interpolation determine how large a $p\_{\mathrm{ann}}$ would be disfavored at $2\sigma$. Our results are shown in Figure
[2](#S2.F2 "Figure 2 ‣ II.3 Comparison to previous results ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), for both WMAP 5 and WMAP 7 noise parameters, with use of
one or three frequency bands (the former is our standard conservative
approach, the latter is more optimistic), as a function of the maximum $\ell$ included in the analysis ($\ell\_{\mathrm{min}}$ is always 2).

In earlier work, [[9](#bib.bib9)] found a WMAP 5 limit of
$p\_{\mathrm{ann}}<2\times 10^{-6}$ m3/s/kg $=3.6\times 10^{-27}$
cm3/s/GeV, using WMAP 5 data and the CosmoMC code to
perform a full likelihood analysis, in reasonable agreement with our
estimate for the WMAP 5 1-band case. Using WMAP 7 data,
[[14](#bib.bib14)] provided an updated constraint $p\_{\mathrm{ann}}<2.4\times 10^{-27}$ cm3/s/GeV, also in very good agreement with
our estimate. Note that [[9](#bib.bib9), [14](#bib.bib14)] included
Lyman-$\alpha$ photons in their analysis, which we have not done here
and which would strengthen the constraints slightly: the small
differences between our constraints and those in the literature can
probably be ascribed to the combination of this factor, our use of
CosmoRec rather than RECFAST, the fact that we use
the best-fit standard cosmological model as a proxy for the real WMAP data, and the optimism inherent in a Fisher matrix analysis. It is
reassuring that none of these factors seem to give rise to large
discrepancies in the results.

We see that the WMAP limits are essentially
unaffected by $\ell\_{\mathrm{max}}$ for $\ell\_{\mathrm{max}}\gtrsim 1000$, and the projected Planck bound appears stable for
$\ell\_{\mathrm{max}}\gtrsim 1500$. For the CVL case, of course, higher
$\ell$’s will always yield more information, but the rate of
improvement with $\ell\_{\mathrm{max}}$ is quite slow for the $\ell$’s we
are considering.

### II.4 Numerical stability of derivatives and linearity

When dealing with general energy deposition histories, we hope to work in a regime where the effect of deposition on the CMB is *linear*, so that the effect of a general energy deposition history can be described in terms of a linear combination of basis energy deposition histories. This is the idea behind characterizing the effect of new parameters entirely in terms of the transfer matrix of derivatives, $T$, and the Fisher matrix $F$ derived from it. Equivalently, linearity means it is sensible to speak of a single transfer matrix $T$ largely independent of the “fiducial” energy deposition history about which the derivatives $\partial C\_{\ell}/\partial\alpha\_{i}$ are taken (our default assumption is that this “fiducial” energy deposition is zero). If the energy deposition history being studied is too great a perturbation away from the fiducial, the first derivatives will no longer accurately describe its effect on the $C\_{\ell}$’s, and the Fisher matrix estimate of its significance will break down. In this subsection we discuss the numerical stability of the derivatives, and the degree to which they describe the effect of arbitrary energy deposition histories on the $C\_{\ell}$’s.

To obtain derivatives of the $C\_{\ell}$ spectra, we calculate a grid of
$C\_{\ell}$ values for each of the parameters considered in the Fisher
matrix. For each $\ell$ and each parameter, the derivative is
extracted from a polynomial fit to $C\_{\ell}$ as a function of the
parameter values.

We estimate that we have calculated derivatives to a precision of
$\sim 1\%$ for cosmological parameters. For energy deposition, the
error is less than $\sim 2\%$ for the most relevant redshifts of $z<800$ and rises to $\sim 5\%$ for $z<1100$. While the error in the derivatives becomes larger for higher
redshifts, the effect on the PCA is small; the difference in signal-to-noise is at the percent level for WMAP 7 and at the few percent level for Planck and the CVL case. The dominant numerical
error here comes from the numerical accuracy limitations of
CosmoRec and CAMB. We estimate the error by
comparing the derivatives obtained from two different accuracy
settings55
5
The two settings we use are (1) runmode=0
and cosmorecacc=0 and (2) runmode=1 and
cosmorecacc=2. In general, we use CAMB accuracy settings
accuracy\_boost=4, l\_accuracy\_boost=4, l\_sample\_boost=4
for computing derivatives. For the MCMC runs, we set all three
parameters to 1 for speed..

The derivatives used in the Fisher matrix are evaluated at the
fiducial cosmology (with no energy deposition). The assumption of
linearity is that these derivatives are still correct away from the
fiducial. For the standard set of six cosmological parameters, the
biases to the cosmological parameters induced by the maximum permitted
energy deposition from WMAP 5 generally lie well within the linear
regime.

For large energy deposition, the effect on the $C\_{\ell}$’s is
nonlinear, i.e. not directly proportional to the deposited power as
parameterized by the $\alpha\_{i}$; equivalently, the derivatives about a
fiducial large energy deposition are not the same as for zero energy
deposition. Our polynomial fits for the derivatives, described above,
also allow us to check the extent to which nonlinearity may become
important: that is, the extent to which $\mathcal{O}(\alpha\_{i}^{2})$
corrections to the effect on the $C\_{\ell}$’s are non-negligible.

The amount of energy deposition such that nonlinearities become
important depends on redshift $z$. This can be estimated by the
fractional rate of ionization per Hubble time,
$(dn\_{ion}/dt)/(n^{0}\_{ion}H(z))$, arising from the energy deposition
(where $dn\_{ion}/dt$ is related to $dE/dtdV$ according to the
prescription of [[42](#bib.bib42)]). For two fiducial cases
this quantity is shown in Figure [1](#S2.F1 "Figure 1 ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"). Conversely,
the energy deposition at redshift $z$ such that
$(dn\_{ion}/dt)/(n^{0}\_{ion}H(z))=1$ gives a measure of what energy
deposition is required before nonlinearities may become
significant. For each redshift bin, we use the polynomial fits of
$\delta C\_{\ell}(\alpha\_{i})$ to numerically calculate the derivatives at
this level of energy deposition. We then find $1\%$ corrections
(averaged over $\ell$) to the fiducial derivative $(\partial C\_{\ell}/\partial\alpha\_{i})|\_{\alpha\_{i}=0}$.

Figure 3: The degree of nonlinearity in the computed significance of a sample energy deposition history, for $p\_{\mathrm{ann}}$ constant, using WMAP 7 noise parameters. We show the ratio of (1) the S/N estimated by a linear extrapolation from small energy deposition to (2) the “true” S/N (estimated as in §[II.3](#S2.SS3 "II.3 Comparison to previous results ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")), as a function of $p\_{\mathrm{ann}}$. The solid, dashed and dotted lines indicate the WMAP 7 2$\sigma$ upper limit on $p\_{\mathrm{ann}}$, the value of $p\_{\mathrm{ann}}$ for which the nonlinearity is $10\%$, and the value for which the nonlinearity is $1\%$, respectively. The red dot-dashed line indicates the 2$\sigma$ upper limit on $p\_{\mathrm{ann}}$ that would be obtained by linearly extrapolating the significance from small energy deposition, which overestimates the significance and hence leads to a too-strong constraint.

One simple test of the effect of nonlinearity is the degree to which the “true” bound on constant $p\_{\mathrm{ann}}$ from a given experiment, evaluated without assuming linearity as described in §[II.3](#S2.SS3 "II.3 Comparison to previous results ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), differs from the bound we would obtain by taking derivatives $\partial C\_{\ell}/\partial p\_{\mathrm{ann}}$ at $p\_{\mathrm{ann}}=0$, and assuming linearity, i.e. taking the effect on the $C\_{\ell}$’s to be given by $p\_{\mathrm{ann}}\left(\partial C\_{\ell}/\partial p\_{\mathrm{ann}}\right)|\_{p\_{\mathrm{ann}}=0}$. Equivalently, we can compare the signal-to-noise estimate for the two methods, as a function of $p\_{\mathrm{ann}}$.

In Figure [3](#S2.F3 "Figure 3 ‣ II.4 Numerical stability of derivatives and linearity ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") we show an example of this test using WMAP 7 noise parameters. For each value of $p\_{\mathrm{ann}}$, we compute both the S/N of the resulting signal directly (as in §[II.3](#S2.SS3 "II.3 Comparison to previous results ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")), and the significance that would be obtained by a linear extrapolation from small $p\_{\mathrm{ann}}$. The ratio of the extrapolated S/N to the true S/N is $1+\epsilon$, and $\epsilon$ provides a measure of nonlinearity. We see that $\epsilon$ approaches 0.3 close to the $2\sigma$ upper bound from WMAP 7, so the estimated $95\%$ bound from WMAP 7 is roughly $30\%$ weaker than would be expected from a linear extrapolation from small energy deposition, but the degree of nonlinearity falls rapidly at lower energy deposition. We will see later that for the energy deposition probed by Planck, $\epsilon$ is only a few percent. Note that even for WMAP 7, the difference in the bound is almost entirely due to an overall $\ell$-independent normalization factor; the *shape* of the $\delta C\_{\ell}$’s is almost unchanged.

Figure 4: The first three principal components for WMAP 7, Planck and a CVL experiment, both before and after marginalization over the cosmological parameters.

## III Principal Component Analysis

The effects of energy deposition at different redshifts on the $C\_{\ell}$’s are highly correlated, and so the effects of a large class of energy deposition histories can be characterized by a small number of parameters. Principal component analysis provides a convenient basis into which energy deposition histories can be decomposed, with the later terms in the decomposition contributing almost nothing to the effect on the $C\_{\ell}$’s. It thus allows generalization of constraints on energy deposition to a wide range of models (subject to the linearity assumption discussed above).

### III.1 The principal components

Figure 5: The first six principal components for Planck after
marginalization, in the case of (*left*) annihilation-like
redshift dependence with linear binning, (*center*)
annihilation-like redshift dependence with log binning, and
(*right*) decay-like redshift dependence with log binning. Note
that for decay-like energy deposition histories, the redshift range is
extended down to $z=10$ in order to fully capture the effect on the
CMB - see §[II](#S2 "II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"). This larger redshift range makes linear
binning impractical.

Having obtained the marginalized Fisher matrix $F$, diagonalizing $F$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $F=W^{T}\Lambda W,\quad\Lambda=\rm diag(\lambda\_{1},\lambda\_{2},....,\lambda\_{N})$ |  | (10) |

yields a convenient basis of eigenvectors or “principal
components”. $W$ is an orthogonal matrix in which the $i$-th row
contains the eigenvector corresponding to the eigenvalue $\lambda\_{i}$.
If we compute derivatives for $N$ redshift bins, then the $N\times N$
Fisher matrix has $N$ principal components. The eigenvectors are
orthonormal in the space of vectors $\{\alpha\_{i}\}$, $i=1..N$. Let us
label these vectors $e\_{i}$, with corresponding eigenvalues $\lambda\_{i}$,
$i=1..N$. Our convention is to rank the principal components by
decreasing eigenvalue, such that $e\_{1}$ has the largest eigenvalue.

Note that the principal components may be significantly different
from the *unmarginalized* principal components, or the eigenvectors of
$F\_{e}$. Figure [4](#S2.F4 "Figure 4 ‣ II.4 Numerical stability of derivatives and linearity ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") shows the first three principal
components for WMAP 7, Planck and a CVL experiment, both before and
after marginalization, for the annihilation-like case ($dE/dt\propto p\_{\mathrm{ann}}(z)(1+z)^{6}$) with 50 linearly-spaced redshift bins. We
see that while the shapes of the PCs are qualitatively similar,
marginalization produces noticeable changes to the PCs, as does
changing from one set of experiment parameters to another. The
differences become more pronounced for higher PCs.

Note that the shapes of the principal components can be affected by a number of other different factors: choice of binning, choice of ionization history calculator, energy deposition model, fiducial cosmological model considered, etc. We discuss these effects in Appendix [A](#A1 "Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics").

In Figure [5](#S3.F5 "Figure 5 ‣ III.1 The principal components ‣ III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") we show the first six marginalized PCs for
Planck, for annihilation-like ($dE/dt\propto p\_{\mathrm{ann}}(z)(1+z)^{6}$) and
decay-like ($dE/dt\propto p\_{\mathrm{dec}}(z)(1+z)^{3}$) energy
deposition histories. We show the annihilation-like case with both log and linear binning. We note that the first principal component is always
largely or completely non-negative, and (in the annihilating case)
peaked around redshift 600. The first PC can be thought of as a
weighting function, describing the effect of energy deposition on the
CMB (orthogonal to the effect of shifting the cosmological
parameters), as a function of redshift66
6
Note that the shift in the peak position between log and linear binning is to be expected, as one “weighting function” would be integrated over $dz$ and the other over $d\ln(1+z)$; see Appendix [A](#A1 "Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") for further discussion..

In Figure [6](#S3.F6 "Figure 6 ‣ III.1 The principal components ‣ III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") we show the effect on the ionization history for the first three Planck PCs in the annihilation case, with each PC multiplied by an energy deposition coefficient of $\varepsilon=2\times 10^{-27}$ cm3/s/GeV to obtain $p\_{\mathrm{ann}}(z)$. Note that this energy deposition is too large to be strictly in the linear regime; this figure illustrates the shape and size of the effect in the linear regime, the true effect for this value of $\varepsilon$ will be somewhat smaller.

Figure 6: Fractional change to the ionization fraction $x\_{e}$ in the presence of energy deposition, for the first three (marginalized) principal components in Planck. The curve shown is extrapolated from the linear (small energy deposition) regime, with normalization factor $\varepsilon\_{1,2,3}=2\times 10^{-27}$ cm3/s/GeV.

As previously, we have considered “annihilation-like” and “decay-like” energy deposition histories separately. If both analyses were performed over the same redshift range, then while the principal components might appear different, they would span the same space of energy deposition histories. If all principal components were retained, the difference between the two would simply be equivalent to a change of basis, and provided *sufficient* principal components are retained, this will still be approximately true. However, a particular energy deposition history may be described by the early principal components much better in one case than in the other; in particular, energy deposition histories for which the effect on the CMB is dominated by low redshifts will not be well described by the (first few of the) default annihilation-like PCs. Thus we present results for both cases.

### III.2 Mapping into $\delta C\_{\ell}$ space

Figure 7: The mapping of the first three principal components for Planck, after marginalization, into $\delta C\_{\ell}$ space. The PCs are multiplied by $\varepsilon\_{i}(z)=2\times 10^{-27}$ cm3/s/GeV for all $i$, to fix the normalization of the $\delta C\_{\ell}$’s.

Figure 8: The $\perp$ components of the first three principal components for Planck, after marginalization, mapped into $\delta C\_{\ell}$ space. The normalization is the same as for Figure [7](#S3.F7 "Figure 7 ‣ III.2 Mapping into 𝛿⁢𝐶_ℓ space ‣ III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics").

Figure 9: Decomposition of $\delta C\_{\ell}$ from energy deposition with constant $p\_{\mathrm{ann}}(z)$ into parallel ($||$) components which can be absorbed by changes in the cosmological parameters, and perpendicular ($\perp$) components that cannot be absorbed by such changes.
The overall effect of the energy deposition is suppression of high-$\ell$ modes, due to the increased optical depth, and enhancement of low-$\ell$ polarization modes, as discussed in [[8](#bib.bib8)]. The suppression at high $\ell$ is clearly seen in the TT and EE spectra; the effect is also present in the TE spectra, with the peaks of $\delta C\_{\ell}^{TE}$ occurring at the troughs of $C\_{\ell}^{TE}$, and vice versa.
The normalization here is $p\_{\mathrm{ann}}=2\times 10^{-27}$ cm3/s/GeV,
comparable to the latest limits from WMAP 7+ACT [[14](#bib.bib14)]. This decomposition depends on the sensitivity of the experiment; the case shown is WMAP 7 single band.

Let us consider the mapping into $\delta C\_{\ell}$ space of these
marginalized principal components. Applying the transfer matrix $T$ (Equation [2](#S2.E2 "In II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")) to the
eigenvectors yields a set of $N$ vectors in the space of $C\_{\ell}$
perturbations, $\delta C\_{\ell}=Te\_{i}=h\_{i}$. The
$h\_{i}$’s should be understood as $\delta C\_{\ell}$’s per energy
deposition, and have units of $C\_{\ell}/p(z)$.

We can define a dot product on the space of $\delta C\_{\ell}$’s by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $h\_{i}\cdot h\_{j}={\sum\_{\ell}h\_{i\ell}^{T}\Sigma\_{\ell}^{-1}h\_{j\ell}}={e\_{i}^{T}F\_{e}e\_{j}}$ |  | (11) |

We then see that while the PCs are orthogonal, the $h\_{i}$ are in
general not orthogonal to each other, nor to the $\delta C\_{\ell}$’s
from the cosmological parameters. They correspond to actual energy
deposition histories, and in general, there is no such history that is
precisely orthogonal to all the cosmological parameters.

However, we may decompose the $h\_{i}$ into components parallel and
perpendicular to the space spanned by varying the cosmological
parameters, and denote the perpendicular components $h\_{i}^{\perp}$. The
projection operator that implements this decomposition is given in
Appendix [B](#A2 "Appendix B Review of marginalization and biases ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"). The $h\_{i}^{\perp}$ vectors are now
orthogonal amongst themselves, as well as to the cosmological
parameters, and their norms are given by the square root of the
marginalized eigenvalues $\lambda\_{i}$. It is these $h\_{i}^{\perp}$’s which
determine the detectability of the marginalized principal components,
and which form an orthogonal basis for residuals which cannot be
absorbed by varying the cosmological parameters. The addition of the
parallel components, to recover the $h\_{i}$’s from the $h\_{i}^{\perp}$’s,
ensures that the $h\_{i}$’s correspond to energy deposition histories, and
so provide an orthogonal basis in redshift space.

In Figure [7](#S3.F7 "Figure 7 ‣ III.2 Mapping into 𝛿⁢𝐶_ℓ space ‣ III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), we show the mapping of the first three
(marginalized) PCs for Planck into the space of $\delta C\_{\ell}$’s; in
Figure [8](#S3.F8 "Figure 8 ‣ III.2 Mapping into 𝛿⁢𝐶_ℓ space ‣ III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), we show the components of these
$\delta C\_{\ell}$’s which are orthogonal to the space spanned by varying
the cosmological parameters. Figure [9](#S3.F9 "Figure 9 ‣ III.2 Mapping into 𝛿⁢𝐶_ℓ space ‣ III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") demonstrates
this projection for a sample DM annihilation model, summing over
principle components, and decomposing the effect on the $C\_{\ell}$’s
into components perpendicular and parallel to the cosmological
parameters.

The eigenvectors of the Fisher matrix $\{e\_{i}\}$ thus provide an
orthogonal basis in both relevant spaces, and their eigenvalues
precisely describe the measurability of a “unit norm” energy
deposition history with $z$-dependence given by the eigenvector. For an
arbitrary energy deposition history which we now write as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $p(z)=\sum\_{i=1}^{N}\varepsilon\_{i}e\_{i}(z),$ |  | (12) |

the expected $\Delta\chi^{2}$ relative to the
null hypothesis of no energy deposition is $\sum\_{i}\varepsilon\_{i}^{2}\lambda\_{i}$. If the $\varepsilon\_{i}$ coefficients are
comparable, the relative sizes of the eigenvalues describe the
fractional variance attributable to each principal
component (eigenvector).

A brief comment on unit conventions: we take the $\{e\_{i}\}$ and
$\{G\_{i}\}$ to be dimensionless, with the units of $p(z)$ (cm3/s/GeV)
carried by the coefficients $\alpha\_{i},\,\varepsilon\_{i}$. The
derivatives (and transfer matrix) then have units of $C\_{\ell}/p(z)$,
and the Fisher matrix and its eigenvalues have units of $1/p(z)^{2}$
(since the covariance matrix $\Sigma$ has units of $C\_{\ell}^{2}$).
Note also that due to the units of the covariance matrix, the dot
product defined above takes two vectors in $C\_{\ell}$-space to a
dimensionless number (if the vectors have units of $C\_{\ell}$).

## IV Detectability

For a general energy deposition history, the PCs provide a basis in which, by construction, the basis vectors are ranked by the significance of their effect on the $C\_{\ell}$’s. The measurability of a generic (smooth, non-negative) energy deposition history can thus be accurately described by the first few PCs77
7
It is in principle possible for the coefficients $\varepsilon\_{i}$ to be zero for $i<n$ for some $n$, but if $n$ is large this implies a very unphysical energy deposition history that oscillates rapidly between positive and negative values. While “negative energy deposition” might perhaps have a physical interpretation in terms of increased absorption of free electrons, such an interpretation is not at all obvious, and so we focus on smooth, non-negative energy deposition histories.. Equivalently, the coefficients of later principal components have extremely large error bars, and will be challenging to measure or constrain.

We now outline the method for reconstructing and constraining the PC coefficients, or any specific energy deposition history, using the PCA formalism. We investigate the number of PCs that can generically be measured at $\geq 1\sigma$ by Planck and a CVL experiment, for arbitrary energy deposition, and show results for broad classes of example models. We also consider the biases to the cosmological parameters that are induced if energy deposition is present but ignored; we present results for each principal component, so the biases due to an arbitrary energy deposition history can be immediately calculated. Our estimates of detectability and the biases will be verified using CosmoMC in the §[VI](#S6 "VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics").

### IV.1 Estimating limits from the Fisher matrix

As mentioned previously, the perpendicular components of the $\delta C\_{\ell}$’s, $h\_{i}^{\perp}$, are orthogonal with norms
$\sqrt{\lambda\_{i}}$. They are also orthogonal to the space spanned by
varying the cosmological parameters. Given these results and a
measurement of the temperature and polarization anisotropies, it is
straightforward to estimate general constraints on the energy
deposition history from the Fisher matrix formalism. Note that in a careful
study, one would instead use CosmoMC to perform a full
likelihood analysis, using the Fisher matrix results only to determine
the optimal principal components, as we demonstrate in §[VI](#S6 "VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"). We outline this simple method only to help build
intuition and to clarify later comparisons between the Fisher matrix
method and the CosmoMC results.

The first step is to extract any residual between the data and the best-fit model using the standard cosmological parameters; let us denote this residual by $R\_{\ell}^{TT,EE,TE}$. Then we take the dot product (as defined in Equation [11](#S3.E11 "In III.2 Mapping into 𝛿⁢𝐶_ℓ space ‣ III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")) of this residual with the $h\_{i}^{\perp}$ vectors, normalizing by the corresponding eigenvalues (this normalization is required because the $h\_{i}^{\perp}$’s are orthogonal, but not orthonormal; see Appendix [B](#A2 "Appendix B Review of marginalization and biases ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bar{\varepsilon}\_{i}=\frac{R\cdot h\_{i}^{\perp}}{\lambda\_{i}}.$ |  | (13) |

The resulting $\bar{\varepsilon}\_{i}$ are the model-independent reconstructed coefficients for the marginalized principal components. In the absence of energy deposition, we expect them to be zero (within uncertainties).

The individual $1\sigma$ uncertainties on each of these coefficients are $1/\sqrt{\lambda\_{i}}$, in the sense that if a single coefficient is perturbed away from its best-fit value by $1/\sqrt{\lambda\_{i}}$, the corresponding energy deposition history will be disfavored at $1\sigma$. Thus it is possible to set a *very* general model-independent constraint on each of the coefficients, $\varepsilon\_{i}=\bar{\varepsilon}\_{i}\pm\frac{1}{\sqrt{\lambda\_{i}}}$ (at $1\sigma$).

Given an arbitrary energy deposition history, we can decompose it into the principal components, each with its own coefficient, and compare these coefficients $\varepsilon\_{i}$ to the bounds. For any particular model, a stronger constraint can be set by noting that,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta\chi^{2}=\sum\_{i}\lambda\_{i}\left(\varepsilon\_{i}-\bar{\varepsilon}\_{i}\right)^{2}.$ |  | (14) |

This $\Delta\chi^{2}$ is relative to the best-fit model including both energy deposition and the standard cosmological parameters; the $\Delta\chi^{2}$ relative to the best-fit standard cosmological model88
8
Of course, if the best-fit energy deposition history is everywhere zero, i.e $\bar{\varepsilon}\_{i}\approx 0$ for all $i$, these two quantities are identical. is simply $\sum\_{i}\lambda\_{i}\varepsilon\_{i}(\varepsilon\_{i}-2\bar{\varepsilon}\_{i})$.

This method has the usual deficiencies of the Fisher matrix approach: it assumes a Gaussian likelihood and also linearity of the derivatives, and so can only be used for an estimate. In §[VI](#S6 "VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") we will go beyond the Fisher matrix approach and present constraints derived from a likelihood analysis using CosmoMC: in the same way as this estimate, those limits can be expressed as bounds on (a simple combination of) the PC coefficients, and will therefore be immediately applicable to a wide range of models for energy deposition.

### IV.2 Sensitivity of future experiments

(a)

(b)

(c)

Figure 10:  (a) The sensitivity for Planck (single-band), after marginalization, for various models subject to constraints from WMAP 7 single-band at 2$\sigma$. The left figure assumes annihilation-like energy deposition and the right figure assumes decay-like energy deposition. The top panels show: (1) assuming $p(z)\propto e\_{i}(z)$ for each PC, (2) the generic case where all PC coefficients have equal magnitudes $|\varepsilon\_{i}|=\varepsilon=2/\sqrt{\sum\_{i}\lambda\_{i}^{{WMAP}}}$, (3) constant $p(z)$, and (4) taking $p(z)\propto f(z)$, with $f(z)$ from the models in [[10](#bib.bib10)]. For the left figure, the hatched region indicates the range of results from changing the ionization history calculator and including or neglecting the effects of helium and Lyman-$\alpha$ photons, described in §[A.3](#A1.SS3 "A.3 Choice of ionization history calculator and recombination corrections ‣ Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")-[A.4](#A1.SS4 "A.4 Helium and Lyman-𝛼 ‣ Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"). The bottom panels show some sample $z\_{\tau}$ models for asymmetric annihilating dark matter (*left*) and decaying species (*right*), as discussed in §[IV.2](#S4.SS2 "IV.2 Sensitivity of future experiments ‣ IV Detectability ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") (the labels describe the initial particle mass, and the SM final state for annihilation or decay), and an extreme case where $p(z)=0$ for $200<z<900$ and constant outside that range. (b) Same as (a), but for a CVL experiment. (c) The models in (a) and (b) for annihilation-like (left) and decay-like (right).

For an energy deposition history where the sizes of the coefficients, $|\varepsilon\_{i}|$, are all similar, the respective detectability of the PCs are given simply by their eigenvalues. Literally taking all the coefficients to be the same does not give a physical energy deposition history (since the later eigenvectors are highly oscillatory), but it is in some sense a “generic” scenario: none of the PCs have coefficients that are fine-tuned to be small, so slight changes to $p(z)$ or the basis of PCs are unlikely to drastically change the detectability of the different components.

We define detectability of the PCs with respect to this “generic” case; of course, detectability of any particular model depends on the relative sizes of coefficients. We consider a number of physical examples below to illustrate that, in some sense, the generic case is a reasonable average over a wide class of models of interest.

As discussed previously, [[10](#bib.bib10)] derived a set of energy deposition profiles corresponding to a range of DM annihilation models. These models provide a convenient set of example energy deposition histories, although they all have very similar effects on the CMB (see §[V](#S5 "V A universal 𝑝_ann⁢(𝑧) for WIMP annihilation ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")). We adapt the code developed in [[10](#bib.bib10)] and discussed in detail there to obtain similar physical $f(z)$ curves for the case of decaying dark matter with a long lifetime.

While the DM itself must have a lifetime considerably longer than the age of the universe, there could be other metastable species which decay during the redshift range we study ($z\sim 10-1300$), or excited states of the dark matter which decay to the ground state + Standard Model particles (e.g. [[43](#bib.bib43), [44](#bib.bib44), [45](#bib.bib45), [46](#bib.bib46), [47](#bib.bib47)] and references therein). In this case the decay rate would cut off exponentially for $z<z(\tau)$, although heating and ionization of the gas could continue for some time after that: we can again obtain detailed $p(z)$ curves for different decay lifetimes using the methods of [[10](#bib.bib10)].
Models of this type provide a simple class of examples suitable for use with the PCs derived for the case of decaying DM, since the underlying $dE/dt\propto(1+z)^{3}$ redshift dependence is the same (although for models with lifetimes short enough that the energy deposition has ceased shortly after recombination, the PCs derived for the annihilation-like case may work better).

For the annihilating case, asymmetric dark matter scenarios can
furnish a similar set of examples [[48](#bib.bib48), [49](#bib.bib49), [50](#bib.bib50), [51](#bib.bib51), [52](#bib.bib52), [53](#bib.bib53)]. In such scenarios the
DM sector possesses an asymmetry analogous to that in the baryon
sector, and it is this asymmetry which sets the DM relic density
rather than the annihilation cross section. In the minimal case there
is thus no *requirement* for an annihilation signal in the
present day or during the epoch of recombination, but it is
nonetheless possible to have a large late-time annihilation signal, by
repopulation of the depleted component at late times, or by
oscillations from the more-abundant to the less-abundant component
[[49](#bib.bib49), [54](#bib.bib54), [53](#bib.bib53)]. As a simple example, we consider
models where another species decays to repopulate the less-abundant DM
state [[53](#bib.bib53)], thus causing the annihilation to
“switch on” as $1-e^{-t/\tau}$ at a characteristic timescale $\tau$ (with $z\_{\tau}$ being the corresponding redshift). We compute the
$p(z)$ curves for a range of $\tau$. Finally, for both
annihilation and decay we consider the constant $p(z)$ case, studied
in [[36](#bib.bib36)] (for decay) and [[8](#bib.bib8), [9](#bib.bib9)] (for annihilation), to facilitate comparison with the
literature.

Figure [10](#S4.F10 "Figure 10 ‣ IV.2 Sensitivity of future experiments ‣ IV Detectability ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") shows the detectability of the
principal components in Planck and the ideal CVL experiment for these
annihilating and decaying models, with the energy deposition normalized
to lie at the $95\%$ limit from WMAP 7. In the “generic” case, we
set the sizes of the coefficients of the Planck (or CVL) PCs to be
$|\varepsilon\_{i}|=\varepsilon=2/\sqrt{\sum\_{i}\lambda\_{i}^{{WMAP}}}$. The actual WMAP 7 signal-to-noise for the model
is

|  |  |  |
| --- | --- | --- |
|  | $\frac{S}{N}=\left(\sum\_{i}\lambda\_{i}^{WMAP}\left[\sum\_{j}\varepsilon\_{j}e^{Planck}\_{j}\cdot e^{WMAP}\_{i}\right]^{2}\right)^{1/2}$ |  |

and thus depends on the signs of $\varepsilon\_{i}$, but the generic case
is meant to indicate the typical detectability for a class of models,
so we instead use the WMAP 7 constraints to set an overall scale for
$|\varepsilon\_{i}|$.

We also show the detectability for each PC if $p(z)\propto e\_{i}(z)$,
or assuming the energy deposition history has zero overlap with all other
PCs99
9
If the PCs were the same for the different experiments,
this would give an upper bound on the detectability of the $i$th PC,
given WMAP 7 $2\sigma$ constraints. However, the PCs for different
experiments are not orthogonal, $e\_{i}^{Planck}\cdot e\_{j}^{WMAP}\neq\delta\_{ij}$. A strict upper bound for the $S/N$ of the $i$th Planck PC is given by $(S/N)\_{i}^{Planck}\leq 2\sqrt{\lambda\_{i}^{Planck}}\sum\_{j}|e\_{i}^{Planck}\cdot e\_{j}^{WMAP}/\sqrt{\lambda\_{j}^{WMAP}}|$, with
the analogous result for a CVL experiment. However, this quantity is
not very useful as an upper bound; for example, if $p(z)$ is
proportional to a high WMAP PC, the normalization of $p(z)$ is
essentially unconstrained, but the detectability for Planck may be
very significant if there is even a small overlap with the first
Planck PC.. As mentioned previously, this is not a physical
assumption (requiring an “energy deposition” oscillating rapidly
between positive and negative values): in such a case the effect on
the $C\_{\ell}$’s is so small that the normalization of the “energy
deposition” could be very large and still consistent with
WMAP. Consequently, arbitrarily high PCs can be measured *if*
they are the sole contributors to the energy deposition history.

We see that models with decay-like redshift dependence and those with annihilation-like redshift dependence tend to have roughly the same number of measurable parameters.
In both cases, generally 2-3 components are potentially measurable in Planck and up to 5-7 for a CVL experiment.

As a side note, the improvement of these constraints between WMAP 7 and future experiments is in large part due to (anticipated) better measurements of the polarization. In the absence of polarization data (i.e. using the TT spectrum only), we would expect the constraints to weaken by a factor of $\sim 3$ for WMAP 7, $\sim 7$ for Planck , and $\sim 14$ for a CVL experiment. Here we have taken the square root of the eigenvalue of the first principal component as a proxy for sensitivity, which will be approximately true for models with a non-negligible overlap with the first PC.

Figure 11: For the $i$th PC, the contribution to the bias to
cosmological parameters in WMAP 7 (*left panel*) and Planck (*right panel*), relative to the error bars forecast from the
Fisher matrix. The normalization is that of the “generic” case (see
discussion in §[IV.2](#S4.SS2 "IV.2 Sensitivity of future experiments ‣ IV Detectability ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") or Figure
[10](#S4.F10 "Figure 10 ‣ IV.2 Sensitivity of future experiments ‣ IV Detectability ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")), where each PC coefficient has the same
absolute value and the overall normalization is the maximum allowed by
WMAP 7 at 2$\sigma$. The total bias for the parameter $\theta$ is
$\sum\_{i}\delta\theta\_{i}$.

### IV.3 Biases to the cosmological parameters

If energy deposition is present but neglected, it can bias the measurement of
the cosmological parameters by a significant amount. For WMAP, the partial
degeneracy between varying $n\_{s}$ and the effects of energy deposition means
that the dominant bias is a $1\sigma$ negative shift to $n\_{s}$. The improved polarization sensitivity of Planck largely lifts the degeneracy with $n\_{s}$, but due to the smaller error bars of Planck other parameters develop non-negligible biases: at the maximum
energy deposition allowed by WMAP 7 at $2\sigma$, Planck parameter estimates
are generically biased at $>1\sigma$ for $\omega\_{c},H\_{0}$, and $A\_{s}$.

Calculation of the biases is exactly complementary to calculating the marginalized Fisher matrix. While the marginalization can be understood as projecting out the degeneracies with the cosmological parameters, the biases are given precisely by the effect of energy deposition in those degenerate directions. To be precise, suppose that some eigenvector $e\_{j}$ has true coefficient $\varepsilon\_{j}\neq 0$ and we falsely assume $\varepsilon\_{j}$ to be zero: then each of the cosmological parameters $\theta\_{i}$ will be shifted by an amount $\delta\theta\_{i}$. The matrix of derivatives $\partial\theta\_{i}/\partial\varepsilon\_{j}$, $i=1..n\_{c}$, $j=1..N$, is given simply by $\sum\_{k}\left(F\_{c}^{-1}F\_{v}^{T}\right)\_{ik}(e\_{j})\_{k}$.

Thus we can partition the biases into the bias per PC, which is shown in Figure [11](#S4.F11 "Figure 11 ‣ IV.2 Sensitivity of future experiments ‣ IV Detectability ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") for WMAP 7 and Planck. For a generic energy deposition history, the total bias is dominated by the bias from the first few PCs, consistent with the fact that later PCs are undetectable and can essentially be neglected in any fit to the data. As expected from [[12](#bib.bib12)], the largest bias for WMAP 7 is to $n\_{s}$.

## V A universal $p\_{\mathrm{ann}}(z)$ for WIMP annihilation

Figure 12: The universal $e\_{\mathrm{WIMP}}$ curve (solid black line), normalized as discussed in the text. Note that the principal component analysis is only performed in the redshift range between the vertical red solid lines; outside these lines, we still plot the linear combination of the input energy deposition histories that has been identified as the first principal component, to serve as a canonical energy deposition history for WIMP annihilation, but the $C\_{\ell}$’s are not sensitive to the details of this energy deposition. In the PCA region we also plot the second (dashed) and third (dotted) principal components, with arbitrary normalization.

Solutions for the redshift dependence of the efficiency function $f(z)$ (and hence the energy deposition history $p\_{\mathrm{ann}}(z)$), for 41 different combinations of dark matter mass and annihilation channel, were presented in [[10](#bib.bib10)]. We can use these 41 energy deposition histories, rather than $\delta$-functions in $z$, as the input states for a principal component analysis, specialized for the particular case of conventional WIMP annihilation. Even after marginalization over the other cosmological parameters, we find that in this case the first eigenvalue completely dominates the later ones, accounting for $99.97\%$ of the total variance in WMAP 7, Planck and the CVL forecast: thus, to a very good approximation, for any of the DM models studied in [[10](#bib.bib10)] (or any linear combination of the final states studied there), the effect on the $C\_{\ell}$’s is determined entirely by the dot product of $p\_{\mathrm{ann}}(z)$ with the first PC, with the $\ell$-dependence given by mapping the first PC to $C\_{\ell}$-space.

This conclusion agrees with the statements in [[10](#bib.bib10), [13](#bib.bib13)] that the effect of DM annihilation can be captured by a single parameter. To put it another way, given equal coefficients for the first two principal components (which is already rather conservative, since the $f(z)$ curves studied are generally very similar to the first PC), the signal corresponding to the first PC would be roughly $60\times$ larger than the signal corresponding to the second PC: the existence of energy deposition would have to be detected at 60$\sigma$ for even a $1\sigma$ measurement of the second component to be possible. Measurements of the later components would be far more difficult still: the sum of the first two eigenvalues accounts for $1-4.8\times 10^{-7}$, $1-6.0\times 10^{-7}$, and $1-8.3\times 10^{-7}$ the total variance in the WMAP 7, Planck and CVL cases respectively. The effective $f$-value of various WIMP annihilation models is then just given by the dot product of their $f(z)$ curves with this first principal component. We provide effective $f$-values for all models considered in [[10](#bib.bib10)] on our website.

Let us denote this first principal component by $e\_{\mathrm{WIMP}}(z)$. We note that the differences between the $e\_{\mathrm{WIMP}}(z)$ curves corresponding to different experiments (WMAP , Planck and a CVL experiment) are extremely small, at the sub-percent level for all redshifts, and so it is reasonable to speak of a single such curve. We can choose to normalize $e\_{\mathrm{WIMP}}(z)$ so that when it is multiplied by a given (dimensionful) factor $\varepsilon$ to obtain an energy deposition history $p\_{\mathrm{ann}}(z)=\varepsilon e\_{\mathrm{WIMP}}(z)$, the significance of the resulting signal in a particular experiment is the same as that of a constant-$p\_{\mathrm{ann}}$ energy deposition with $p\_{\mathrm{ann}}=\varepsilon$. This normalization simplifies comparisons with the earlier literature, in that the constraint on $\varepsilon$ is precisely the same as the familiar limit on constant $p\_{\mathrm{ann}}$. The choice of experiment affects the normalization at the percent level; as a default, we will use the normalization appropriate for Planck. We plot the resulting $e\_{\mathrm{WIMP}}(z)$ curve in Figure [12](#S5.F12 "Figure 12 ‣ V A universal 𝑝_ann⁢(𝑧) for WIMP annihilation ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"); this curve and the corresponding $C\_{\ell}$ shifts are also available online in tabulated form (see Appendix [C](#A3 "Appendix C Web files description ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")).

We could of course also write $e\_{\mathrm{WIMP}}(z)$ in terms of the previously calculated principal components, just like any other energy deposition history. For example, for the Planck PCs derived above, an energy deposition $\varepsilon\times e\_{\mathrm{WIMP}}(z)=\sum\_{i}\varepsilon\_{i}e\_{i}$ corresponds to $\{\varepsilon\_{1},\varepsilon\_{2},\varepsilon\_{3},...\}=\varepsilon\times\{4.64,-0.396,3.11,...\}$. In particular, this implies that the shapes of the $\delta C\_{\ell}$’s induced by WIMP annihilation are quite close to those shown for the first PC in Figures [7](#S3.F7 "Figure 7 ‣ III.2 Mapping into 𝛿⁢𝐶_ℓ space ‣ III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")-[8](#S3.F8 "Figure 8 ‣ III.2 Mapping into 𝛿⁢𝐶_ℓ space ‣ III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics").

In Figure [13](#S5.F13 "Figure 13 ‣ V A universal 𝑝_ann⁢(𝑧) for WIMP annihilation ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") we show, for reference, the modification to the ionization history associated with the $e\_{\mathrm{WIMP}}$ curve, and the contributions from the first three principal components. We see that the first three PCs provide a good description of the ionization history modifications at $300\lesssim z\lesssim 1000$, and in both cases the ionization fraction is essentially unaffected for $z\gtrsim 1000$; we can infer that the effect on the CMB of the discrepancy at lower redshifts is small.

Figure 13: Fractional change to the ionization fraction $x\_{e}$ in the presence of energy deposition, for the universal $e\_{\mathrm{WIMP}}$ curve (*red, solid*). We also write the $e\_{\mathrm{WIMP}}(z)$ curve as a linear combination of the Planck principal components, and show (in *black*) the effect on the ionization history of the first three principal components individually (weighted by their contribution to $e\_{\mathrm{WIMP}}$), and their (weighted) sum. The curves shown are extrapolated from the linear (small energy deposition) regime, with normalization factor $\varepsilon=2\times 10^{-27}$ cm3/s/GeV for the $e\_{\mathrm{WIMP}}$ curve.

## VI CosmoMC Results

Everything we have done so far assumes both linearity and that the Fisher matrix is an adequate description of the likelihood function. We now present results of a full likelihood analysis using the CosmoMC Markov chain Monte Carlo code, in particular examining the biases to the cosmological parameters and the detectability of the PCs. Throughout this section we use RECFAST 1.5 as our ionization history calculator, since we have established that the PCs are unaffected by this choice (see §[A.3](#A1.SS3 "A.3 Choice of ionization history calculator and recombination corrections ‣ Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")) and the interface to CosmoMC is better established.

We sample the six cosmological parameters $\omega\_{b}$, $\omega\_{c}$, $n\_{s}$, $\ln 10^{10}A\_{s}$(k = 0.002/Mpc), $\tau$ and $H\_{0}$, all with flat priors. We consider purely adiabatic initial conditions. We parameterize the energy deposition due to dark matter annihilation using the marginalized principal components in redshift space $e\_{i}$ presented in §[III](#S3 "III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"). We thus include 0, 1, 3, 5 or 7 additional parameters corresponding to the coefficients of the principal components with highest significance, as determined from the Fisher Matrix analysis1010
10
We use odd numbers of principal components to illustrate the effects of including more PCs because for near-constant $p\_{\mathrm{ann}}$, the even-numbered principal components tend to have very small coefficients, and so including them does not substantially change the results.. We impose flat priors on these parameters. Our treatment of the energy deposition is the same as described in the previous sections; we do *not* include Lyman-$\alpha$ as a default (see §[A.4](#A1.SS4 "A.4 Helium and Lyman-𝛼 ‣ Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")).

The MCMC convergence diagnostic tests are performed on 4 chains using the Gelman and Rubin (variance of chain
mean)/(mean of chain variances) R - 1 statistic for each parameter. Our constraints and the $1-D$ and $2-D$ likelihood contour plots are obtained after marginalization over the remaining nuisance parameters, again using the programs included in the CosmoMC package. We use a cosmic age top-hat prior of 10 Gyr $\leq t\_{0}\leq$ 20 Gyr.

We first determine the constraints on parameters using the seven-year WMAP data [[1](#bib.bib1)] (temperature and polarization) with the routine for computing the likelihood supplied by the WMAP team. For this case only, we also marginalize over a possible contamination from a Sunyaev-Zeldovich component (see e.g. [[34](#bib.bib34)]).

We then generate simulated data for Planck and a CVL experiment using a fiducial cosmological model given by the best fit WMAP7 model. We simulate the data assuming in one case no energy deposition, and in another case an energy deposition history with constant $p\_{\mathrm{ann}}=1.78\times 10^{-27}$ cm3/s/GeV.
We model experimental noise as described in Equation [7](#S2.E7 "In II.1 Brief review of the Fisher matrix ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"). For the Planck experiment, we use the specifications reported in Table [1](#S2.T1 "Table 1 ‣ II.2 Experimental parameters ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") for the 147 GHz channel only. For the CVL experiment, we limit the maximum resolution of the experiment to $\ell\_{max}=2500$. In each case, we use the PCs developed for that particular experiment, as described in §[III](#S3 "III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics").

### VI.1 Constraints and forecasts

|  |  |  |
| --- | --- | --- |
| Number of | PC | WMAP7 |
| PCs used |  | 95%c.l. |
| 1 | PC | $<1.2\times 10^{-26}$cm3/s/GeV |
| 1 | $e\_{\mathrm{WIMP}}(z)$ | $<2.43\times 10^{-27}$cm3/s/GeV |

Table 2: Upper limits on the first principal component amplitude using WMAP 7 data. In the last line we also show the constraints on the $e\_{\mathrm{WIMP}}(z)$ principal component presented in §[V](#S5 "V A universal 𝑝_ann⁢(𝑧) for WIMP annihilation ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"). The uncertainties reported are upper limits at the 95% c.l. We show the constraints obtained when only the first principal component is varied, together with the cosmological parameters. We assume in this case a flat positive prior on the amplitude of the principal component.

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Number of | PC | Planck | | CVL | |
| PCs used |  | $p\_{\mathrm{ann}}=0$ | $p\_{\mathrm{ann}}=1.78\times 10^{-27}$ cm3/s/GeV | $p\_{\mathrm{ann}}=0$ | $p\_{\mathrm{ann}}=1.78\times 10^{-27}$cm3/s/GeV |
| 1 | PC 1 | $(0.2\pm 1.1)\times 10^{-27}$ | $(8.9\pm 1.6)\times 10^{-27}$ | $(0.1\pm 4.9)\times 10^{-28}$ | $(9.04\pm 0.81)\times 10^{-27}$ |
| 3 | PC 1 | $(0.4\pm 1.1)\times 10^{-27}$ | $(8.8\pm 1.5)\times 10^{-27}$ | $(0.6\pm 5.0)\times 10^{-28}$ | $(8.71\pm 0.81)\times 10^{-27}$ |
| 3 | PC 2 | $(0.4\pm 2.4)\times 10^{-27}$ | $(0.7\pm 3.2)\times 10^{-27}$ | $(0.1\pm 1.1)\times 10^{-27}$ | $(0.5\pm 1.5)\times 10^{-27}$ |
| 3 | PC 3 | $(1.7\pm 4.1)\times 10^{-27}$ | $(7.1\pm 5.8)\times 10^{-27}$ | $(-0.3\pm 1.7)\times 10^{-27}$ | $(5.5\pm 2.5)\times 10^{-27}$ |
| 5 | PC 1 | - | - | $(0.9\pm 5.0)\times 10^{-28}$ | $(8.87\pm 0.83)\times 10^{-27}$ |
| 5 | PC 2 | - | - | $(0.1\pm 1.1)\times 10^{-27}$ | $(0.4\pm 1.5)\times 10^{-27}$ |
| 5 | PC 3 | - | - | $(-0.1\pm 1.8)\times 10^{-27}$ | $(5.4\pm 2.7)\times 10^{-27}$ |
| 5 | PC 4 | - | - | $(0.3\pm 2.5)\times 10^{-27}$ | $(1.9\pm 2.8)\times 10^{-27}$ |
| 5 | PC 5 | - | - | $(0.2\pm 3.4)\times 10^{-27}$ | $(3.1\pm 4.1)\times 10^{-27}$ |
| 1 | $e\_{\mathrm{WIMP}}(z)$ | $(0.3\pm 2.2)\times 10^{-28}$ | $(1.84\pm 0.31)\times 10^{-27}$ | $(-0.1\pm 1.0)\times 10^{-28}$ | $(1.81\pm 0.16)\times 10^{-27}$ |

Table 3: Constraints on the principal component amplitudes using simulated data for Planck and for a Cosmic Variance Limited experiment, assuming a fiducial energy deposition history of $p\_{\mathrm{ann}}=1.78\times 10^{-27}$cm3/s/GeV or no energy deposition ($p\_{\mathrm{ann}}=0.$). In the last line we also show the constraints on the $e\_{\mathrm{WIMP}}(z)$ principal component presented in §[V](#S5 "V A universal 𝑝_ann⁢(𝑧) for WIMP annihilation ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"). The uncertainties reported are at the 68% c.l. We show the constraints obtained when different numbers of principal components are varied at the same time, together with the 6 $\Lambda CDM$ cosmological parameters. The results are reported in cm3/s/GeV.

Figure 14: Constraints from the seven-year WMAP data (red), and from simulated data for Planck (blue) and a cosmic variance limited experiment (green). The plot shows marginalized one-dimensional distributions and two-dimensional 68% and 95% limits. The mock data for Planck and the CVL experiment assumed no dark matter annihilation. Three Principal Components were used in each run to model the energy deposition from dark matter annihilation. The units of the PC coefficients here are in m3/s/kg, with $1\times 10^{-6}$m3/s/kg = $1.8\times 10^{-27}$ cm3/s/GeV.

In Table [2](#S6.T2 "Table 2 ‣ VI.1 Constraints and forecasts ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") we give the WMAP 7 upper limit at 95% c.l. obtained on the amplitude of the first principal component (for generic energy deposition histories) and on the amplitude of the principal component $e\_{\mathrm{WIMP}}(z)$ (the universal WIMP energy deposition history described in §[V](#S5 "V A universal 𝑝_ann⁢(𝑧) for WIMP annihilation ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")). For these constraints we imposed a positive flat prior on the amplitude of the principal component. This physical assumption is convenient in order to avoid a region of parameter space where the likelihood function is abruptly cut at some negative value of the principal component amplitude, where the recombination history calculation breaks down.

Figure [14](#S6.F14 "Figure 14 ‣ VI.1 Constraints and forecasts ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") shows the 1-D and 2-D contour plots from WMAP 7 for the first three PCs, and the forecast improvements for Planck and a CVL experiment. The results shown are obtained varying the standard cosmological parameters together with the amplitudes of the first 3 principal components for each experiment.

From these plots, it is evident that the likelihoods for the PC amplitudes obtained from WMAP 7 are highly non-Gaussian. One reason is that the WMAP 7 data allow sets of coefficients for the principal components such that the corresponding energy deposition is negative and unphysical for some redshift. In particular,
if the energy deposition is negative and sufficiently large in magnitude, this can cause the ionization history calculation to break down. If the coefficients of the PCs are all large, the condition that some linear combination of the PCs be non-negative (or where negative, sufficiently small) imposes quite a non-trivial constraint on the coefficients, which is reflected in peculiar-looking boundaries for the favored regions. This effect is clearly visible in the WMAP results in Figure [14](#S6.F14 "Figure 14 ‣ VI.1 Constraints and forecasts ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"); for Planck the energy deposition history is much more constrained, and so this problem does not arise to nearly the same degree.

Another issue is that adding more principal components to the fit does *not* always lead to a better reconstruction of the cosmological parameters and energy deposition history. By construction, higher PCs are less constrained by the data, and so the favored regions for their coefficients extend to much higher values, corresponding to very large energy deposition at particular redshifts. This means both that the previous problem of unphysical energy deposition histories reasserts itself, and that the effects of the energy deposition become nonlinear.

As a consequence, the property of orthogonality between principal components does not hold anymore, and unexpected degeneracies between the PC parameters can arise: Figure [14](#S6.F14 "Figure 14 ‣ VI.1 Constraints and forecasts ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") includes a 2-D contour plot showing the degeneracy between PC 2 and PC 3 for WMAP 7. This problem affects the Planck and CVL cases only when too many PCs that are completely unconstrained by the data are included in the MCMC runs. Thus there is an optimal number of PCs to include in the reconstruction for each experiment: beyond this point, adding further PCs to the reconstruction only obfuscates the results.

Figure 15: Bias on the cosmological parameters using models with $\Lambda CDM$+ $n$ principal components for Planck (*left panel*) and CVL (*right panel*) simulated data. Here, the bias is defined as $(\theta\_{i}-\theta\_{i}^{fid})/\sigma{\theta\_{i}}$, where $\theta\_{i}$ is the value of the mean value of the parameter from CosmoMC, $\theta\_{i}^{fid}$ is the WMAP 7 marginalized value used as fiducial for the mock data, and $\sigma(\theta\_{i})$ is $1-\sigma$ error bound from the runs.
Both sets of mock data assumed a constant-$p\_{\mathrm{ann}}(z)$ energy deposition history with $p\_{\mathrm{ann}}=1\times 10^{-6}$m3/s/kg = $1.8\times 10^{-27}$ cm3/s/GeV. Note that this plot should *not* be directly compared to Figure [11](#S4.F11 "Figure 11 ‣ IV.2 Sensitivity of future experiments ‣ IV Detectability ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") (which shows the bias per unit-normalized PC, rather than the total remaining bias after a certain number of PCs have been reconstructed from the fit).

In Figure [15](#S6.F15 "Figure 15 ‣ VI.1 Constraints and forecasts ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), we show how the bias to the cosmological parameters is reduced with the inclusion of more PCs, for both Planck and a CVL experiment. We find that the best results are obtained when the number of included PCs equals the maximum number of “measurable” PCs (in the sense of §[IV.2](#S4.SS2 "IV.2 Sensitivity of future experiments ‣ IV Detectability ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")), i.e. three PCs for Planck and five for a CVL experiment1111
11
Note that the number of “measurable” PCs may *not* reflect the actual number of PCs with S/N $>1$ for any specific energy deposition history, which depends on the values of the $\varepsilon\_{i}$ coefficients for that history; it is simply an estimate of the number of PCs that could feasibly be reconstructed from the data, from scanning over a range of models, and seems to also well describe the number of PCs with small enough error bars that nonlinearities do not cause problems.. Later PCs cannot be reconstructed from the data and their inclusion does not improve the residual bias.

Table [3](#S6.T3 "Table 3 ‣ VI.1 Constraints and forecasts ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") shows the forecast constraints (with uncertainties at 68% c.l.) on the principal components amplitudes using simulated data for Planck and for the CVL case, assuming a fiducial model with no energy deposition ($p\_{\mathrm{ann}}=0$) or with energy deposition described by constant $p\_{\mathrm{ann}}=1.78\times 10^{-27}$cm3/s/GeV. In these cases we let the amplitudes of the principal components assume both positive and negative values. In the table we report the results obtained when including different numbers of principal components. The uncertainties on the amplitudes of the PCs (e.g. on PC 1) do not substantially change with the number of principal components included in the run. Table [3](#S6.T3 "Table 3 ‣ VI.1 Constraints and forecasts ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") also presents the constraints obtained using the principal component $e\_{\mathrm{WIMP}}(z)$ described in §[V](#S5 "V A universal 𝑝_ann⁢(𝑧) for WIMP annihilation ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics").

Figures [16](#S6.F16 "Figure 16 ‣ VI.1 Constraints and forecasts ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")-[17](#S6.F17 "Figure 17 ‣ VI.1 Constraints and forecasts ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") show the constraints on the various parameters from simulated Planck data with a toy-model energy deposition history corresponding to constant $p\_{\mathrm{ann}}(z)=1.78\times 10^{-27}$ cm3/s/GeV. As mentioned previously, while the coefficients of the early PCs are reconstructed well, we see that including additional PCs beyond the three expected to be measurable degrades the measurement of $n\_{s}$ and to a lesser extend $A\_{s}$.

Figures [18](#S6.F18 "Figure 18 ‣ VI.2 Application of constraints ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")-[19](#S6.F19 "Figure 19 ‣ VI.2 Application of constraints ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") show the constraints on the various parameters from a simulated CVL experiment with the same energy deposition history as in the Planck case. We now see that including at least five PCs is necessary to remove the bias to the cosmological parameters, especially $n\_{s}$ and $A\_{s}$ but going from five to seven PCs neither greatly improves nor degrades the reconstruction, and is only significant at all in the case of $n\_{s}$.

Figure 16: Constraints from simulated data for Planck on $\Lambda CDM$ parameters + 0 principal components (green), $\Lambda CDM$+ 1 PCs (magenta), $\Lambda CDM$+ 3 PCs (blue), $\Lambda CDM$+ 5 PCs (red).
The plot shows marginalized one-dimensional distributions and two-dimensional 68% and 95% limits. The mock data for Planck assumed for the solid lines includes energy deposition with constant $p\_{\mathrm{ann}}=1\times 10^{-6}$m3/s/kg = $1.8\times 10^{-27}$ cm3/s/GeV. The grey area shows the case of a mock data with no energy injection and a model $\Lambda CDM$+ 0 principal components. Only the cosmological parameters are shown.

Figure 17: Constraints from simulated data for Planck on $\Lambda CDM$+ 1 PCs (magenta), $\Lambda CDM$+ 3 PCs (blue), $\Lambda CDM$+ 5 PCs (red).
The plot shows marginalized one-dimensional distributions and two-dimensional 68% and 95% limits. The mock data for Planck assumed for the solid lines includes energy deposition with constant $p\_{\mathrm{ann}}=1\times 10^{-6}$m3/s/kg = $1.8\times 10^{-27}$ cm3/s/GeV, with the PC coefficients shown in units of m3/s/kg. Only the principal components and $n\_{s}$ are shown.

### VI.2 Application of constraints

Once the constraints on the individual principal components are obtained, they can be used to set general bounds.
Given an arbitrary energy deposition history, it can be decomposed into the principal component basis we have supplied online (see Appendix [C](#A3 "Appendix C Web files description ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")), and the coefficients in that basis compared to the limits presented here for WMAP 7.

As a simple example, suppose we wish to set limits on an energy deposition
history with positive constant $p\_{\mathrm{ann}}$, by projecting onto the
constraints obtained for the first principal component using WMAP 7
data. Recall that we
impose a positive prior on the amplitude of the principal component.
The upper limit on the first principal component using WMAP 7 data is then 1212
12
This value depends on the normalization of the principal components used. Here we employ the PCs supplied online (see Appendix [C](#A3 "Appendix C Web files description ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")), which are orthonormal when expressed as a vector sampled at 50 redshifts. $\varepsilon\_{1}<1.2\times 10^{-26}$cm3/s/GeV at 95% confidence. From Equation [12](#S3.E12 "In III.2 Mapping into 𝛿⁢𝐶_ℓ space ‣ III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") and the discussion in §[II](#S2 "II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), we see that for a constant-$p\_{\mathrm{ann}}$ energy deposition history we have
$\varepsilon\_{i}=p\_{\mathrm{ann}}\sum\_{j=1}^{N}e\_{i}(z\_{j})$:
the resulting derived upper limit on an energy deposition history with constant positive $p\_{\mathrm{ann}}$ is $p\_{\mathrm{ann}}<2.8\times 10^{-27}$cm3/s/GeV at 95% confidence. This constraint can be compared with the one obtained directly by sampling the cosmological parameters with a positive constant $p\_{\mathrm{ann}}$, which gives an upper limit of $p\_{\mathrm{ann}}<2.7\times 10^{-27}$cm3/s/GeV at 95% confidence.
In a more general case when more than one principal component is considered in the analysis, the limit on $p\_{\mathrm{ann}}$ can be determined with a $\chi^{2}$ analysis as in Equation [14](#S4.E14 "In IV.1 Estimating limits from the Fisher matrix ‣ IV Detectability ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), writing the theoretically predicted amplitude $\bar{\varepsilon}\_{i}$ as a function of $p\_{\mathrm{ann}}$.

For WIMP models, the WMAP 7 limit for $e\_{\mathrm{WIMP}}(z)$ in Table [2](#S6.T2 "Table 2 ‣ VI.1 Constraints and forecasts ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") can be applied directly given the effective $f$-value; these were described in §[V](#S5 "V A universal 𝑝_ann⁢(𝑧) for WIMP annihilation ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") and are available online for a range of models (see Appendix [C](#A3 "Appendix C Web files description ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")). As another consistency check, we can apply the WMAP 7 limit on the first principal component to the WIMP case, $p\_{\mathrm{ann}}(z)=\varepsilon e\_{\mathrm{WIMP}}(z)$. For WMAP 7, the coefficient $\varepsilon\_{1}$ is given by $4.41\varepsilon$, giving a bound of $\varepsilon<2.7\times 10^{-27}$cm3/s/GeV. The true bound on $\varepsilon$ is roughly 10$\%$ stronger.

Once Planck data are available, the same analysis can be redone with real data, and a very broad range of models can then be confronted with the resulting PC-based limits (the only exceptions being models which have negligible overlaps with the first few PCs and thus evade the constraints in this form; studying limits on such models will still require a separate analysis).

Using mock Planck data, we have confirmed that the constraints on the first three principal components can be used to recover the correct limit on a particular energy deposition history – that is, the limit that we would obtain by directly varying the energy deposition amplitude for that specific model. Again taking the constant-$p\_{\mathrm{ann}}$ case as a simple example, but now using Planck mock data with an energy deposition history with constant $p\_{\mathrm{ann}}=1.78\times 10^{-27}$cm3/s/GeV, the amplitudes for the first 3 principal components are:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\varepsilon\_{1}$ | $\displaystyle=$ | $\displaystyle(8.8\pm{1.5})\times 10^{-27}\mathrm{cm}^{3}\mathrm{/s/GeV}$ |  | (15) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\varepsilon\_{2}$ | $\displaystyle=$ | $\displaystyle(6.8\pm 31.5)\times 10^{-28}\mathrm{cm}^{3}\mathrm{/s/GeV},$ |  | (16) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\varepsilon\_{3}$ | $\displaystyle=$ | $\displaystyle(7.1\pm 5.8)\times 10^{-27}\mathrm{cm}^{3}\mathrm{/s/GeV},$ |  | (17) |

where the errors are at 68% confidence. From a $\chi^{2}$ analysis of these results, the recovered energy deposition is given by $p\_{\mathrm{ann}}=(1.90\pm 0.50)\times 10^{-27}$cm3/s/GeV at 68% c.l.. This constraint can be compared with the one obtained directly by sampling the cosmological parameters with a constant $p\_{\mathrm{ann}}$, which gives an upper limit of $p\_{\mathrm{ann}}=(1.90\pm 0.32)\times 10^{-27}$cm3/s/GeV at 68% c.l.. These checks confirm the validity and usefulness of the principal component decomposition.

Figure 18: Constraints from simulated data for a cosmic variance limited experiment on $\Lambda CDM$+ 0 principal components (green), $\Lambda CDM$+ 1 PCs (magenta), $\Lambda CDM$+ 3 PCs (blue), $\Lambda CDM$+ 5 PCs (red), $\Lambda CDM$+ 7 PCs (black).
The plot shows marginalized one-dimensional distributions and two-dimensional 68% and 95% limits. The mock data for the CVL experiment assumed for the solid lines includes an energy deposition history with constant $p\_{\mathrm{ann}}=1\times 10^{-6}$m3/s/kg = $1.8\times 10^{-27}$ cm3/s/GeV. The grey area shows the case of a mock data with no energy injection and a model $\Lambda CDM$+ 0 principal components. Only the cosmological parameters are shown.

Figure 19: Constraints from simulated data for a cosmic variance limited experiment on $\Lambda CDM$+ 1 PCs (magenta), $\Lambda CDM$+ 3 PCs (blue), $\Lambda CDM$+ 5 PCs (red), $\Lambda CDM$+ 7 PCs (black).
The plot shows marginalized one-dimensional distributions and two-dimensional 68% and 95% limits. The mock data for the CVL experiment assumed for the solid lines includes an energy deposition history with constant $p\_{\mathrm{ann}}=1\times 10^{-6}$m3/s/kg = $1.8\times 10^{-27}$ cm3/s/GeV, with the PC coefficients shown in units of m3/s/kg. Only the principal components and $n\_{s}$ are shown.

### VI.3 Bias on cosmological parameters and agreement with the Fisher matrix

In Figures [20](#S6.F20 "Figure 20 ‣ VI.3 Bias on cosmological parameters and agreement with the Fisher matrix ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")-[21](#S6.F21 "Figure 21 ‣ VI.3 Bias on cosmological parameters and agreement with the Fisher matrix ‣ VI CosmoMC Results ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), we compare the error bars on the cosmological parameters and principal components, and the bias to the cosmological parameters due to assuming no energy deposition, for the Fisher matrix method and CosmoMC. We find in general that the results of the Fisher matrix method are in good agreement with the full likelihood analysis, accurately predicting the error bars on the reconstructed values of the PCs and the cosmological parameters. For example, for the case of the Planck fit with three PCs, the Fisher matrix predictions for the errors on the reconstructed PCs are within $5\%$ of the true values for the first two PCs, and $\sim 15\%$ different for the third PC, if the true energy deposition is small enough to lie in the linear regime. The biases to the cosmological parameters, when no PCs are included in the fit but the “true” energy deposition history is one of constant positive $p\_{\mathrm{ann}}$, are not quite as well matched; the Fisher matrix method adequately captures the directions and approximate sizes of the various biases, but significantly overpredicts the bias to $A\_{s}$ in particular, in the example presented here. To obtain precise measurements of the biases, a CosmoMC analysis like the one we have performed is essential.

Figure 20: Error bars for the cosmological parameters and coefficients of the principal components, in mock Planck data, simulated assuming a constant-$p\_{\mathrm{ann}}(z)$ energy deposition history. The points marked “large $p\_{\mathrm{ann}}$” have $p\_{\mathrm{ann}}=1\times 10^{-6}$m3/s/kg = $1.8\times 10^{-27}$ cm3/s/GeV, while for the points marked “small $p\_{\mathrm{ann}}$” the value is a factor of 10 lower. In the *left panel* the fit to the data is performed using only the standard six cosmological parameters, whereas in the *center panel* and *right panel* three PCs are also included in the fit. For ease of comparison, the green triangles in the center panel reproduce the black asterisks in the left panel. For the PCs, the dimensionless uncertainties plotted here should be multiplied by $p\_{\mathrm{ann}}$ to obtain the uncertainties on the $\varepsilon\_{i}$ coefficients. The uncertainties on the cosmological parameters have been divided by the central values of the respective parameters.

Figure 21: Biases to the cosmological parameters in mock Planck data, simulated assuming a constant-$p\_{\mathrm{ann}}(z)$ energy deposition history with $p\_{\mathrm{ann}}=1\times 10^{-6}$m3/s/kg = $1.8\times 10^{-27}$ cm3/s/GeV. The fit to the data is performed using only the standard six cosmological parameters.

## VII Conclusion

Principal component analysis provides a simple and effective
parameterization for the effect of arbitrary energy deposition histories on
anisotropies in the cosmic microwave background. We find that for DM
annihilation-like energy deposition histories the first principal component,
describing the bulk of the effect, is peaked around $z\sim 500-600$,
at somewhat lower redshift than previously expected; the later
principal components provide corrections to this basic weighting
function.

The principal components, derived from a Fisher matrix approach, are
stable against a wide variety of perturbations to the analysis,
including choice of code calculating the ionization history, additions
to the usual set of cosmological parameters, the inclusion or
exclusion of ionization on helium, the range of included multipoles,
and the choice of binning. (For further discussion, see
Appendix [A](#A1 "Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics").) The one significant potential change
to the PCs arises from how deposited energy is attributed to
additional Lyman-$\alpha$ photons: we have showed the effect of on one
hand neglecting this channel, and on the other of assuming that all
the energy attributed to “excitations” is converted into
Lyman-$\alpha$, which should bracket the true result. We eagerly await
a more careful analysis of this problem.

Within the Fisher matrix formalism, it is straightforward to take into account degeneracies with the standard cosmological parameters. We have presented predictions for the (significant!) biases that would arise in Planck as a result of falsely assuming energy deposition to be zero, for each of the principal components. We have confirmed the previously noted degeneracy between energy deposition and $n\_{s}$, and to a lesser degree with $A\_{s}$, $\omega\_{b}$ and $\omega\_{c}$, in WMAP data; since our analysis decomposes the biases according to the principal components that generate them, it is now trivial to compute the biases to the cosmological parameters for any arbitrary energy deposition history, in WMAP or in mock Planck data.

For a wide range of energy deposition histories, spanning models of dark matter annihilation and decaying species where annihilation or decay can begin or end abruptly on characteristic timescales shorter than the age of the universe, the coefficients of up to *three* principal components are potentially measurable by Planck, for energy deposition histories satisfying $95\%$ confidence limits from WMAP, opening up the exciting possibility of distinguishing different models of energy deposition. For a CVL experiment, up to *five* coefficients are measurable.

For the “standard” WIMP annihilation case, principal component
analysis on a large set of WIMP models yields a single principal
component $e\_{\rm WIMP}(z)$ that describes the effect on the
$C\_{\ell}$’s of all the models very well; any model is then
parameterized simply by the coefficient of $e\_{\rm WIMP}(z)$ (or
equivalently, effective $f$). Our analysis confirms previous
statements in the literature, and we have provided this “universal
$f(z)$” curve for future WIMP annihilation studies.

We performed an accurate MCMC analysis of current WMAP 7 data to impose constraints on the measurable principal component amplitudes, and to forecast constraints for future experiments such as Planck or a CVL experiment. We find good agreement with the Fisher matrix analysis, although the MCMC analysis is required to accurately predict the biases on the cosmological parameters. We have illustrated how it is possible to recover the constraints on an arbitrary energy deposition history from the constraints on the amplitudes of the principal components. The reconstructed constraints are in very good agreement with the constraints obtained by directly sampling a specific energy deposition history, confirming the validity and usefulness of the principal component decomposition.

We wish to acknowledge helpful conversations with Jens Chluba, Joanna Dunkley, Fabio Iocco, Eric Linder, Alessandro Melchiorri, Nikhil Padmanabhan and Joshua Ruderman. We are
grateful to Antony Lewis for his advice on increasing the numerical accuracy
of CAMB. DPF and TL are partially supported by NASA Theory grant NNX10AD85G. TRS is supported by the NSF under grant NSF AST-0807444 and the DOE under grant DE-FG02-90ER40542.
This research made use of the NASA Astrophysics Data System (ADS) and the IDL
Astronomy User’s Library at Goddard 1313
13
Available at
http://idlastro.gsfc.nasa.gov.

## Appendix A Validation of the PCA method

In this appendix we discuss a number of specific issues that might affect the results of the principal component analysis, and motivate our default choices.

### A.1 Choice of binning

Figure 22: An example of the dependence of the principal components on the number of bins and the width of the Gaussians, for the first, third and sixth principal components in Planck, after marginalization over the cosmological parameters (the later principal components are shown as they are more sensitive to small changes in the binning). Black lines indicate the case with 100 linearly spaced bins and $\sigma=$ bin width/2; in the left (right) panel, red and blue dots indicate respectively the case with 15 (50) linearly spaced bins and $\sigma=$ bin width/2, and the case with 15 (50) linearly spaced bins and $\sigma=$ bin width/4.

As discussed previously, to approximate $\delta$-functions in energy deposition, as a default we employ (for the annihilation-like case) 50 linearly-spaced redshift bins covering the redshift range from $z=80$ to $z=1300$. Figure [22](#A1.F22 "Figure 22 ‣ A.1 Choice of binning ‣ Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") shows the effect of changing the Gaussian width and the number of bins for some sample PCs; doubling the number of bins or changing the Gaussian width by a factor of 2 has no effect on the PCs, although reducing the number of bins to 15 does affect the PCs slightly, especially at the lowest and highest redshifts.

In §[II](#S2 "II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") we briefly discussed the choice of log vs linear binning, preferring to use the former for decay-like scenarios and the latter for annihilation-like scenarios. In the annihilation-like case, the choice of linear-spaced bins in redshift was not inevitable; log-spaced bins seem equally natural. The choice of log or linear binning is somewhat subtle, as it affects whether or not two energy deposition histories are considered orthogonal, and how much different redshifts contribute to the norm of a particular energy deposition profile. Consequently, the two choices give rise to different sets of principal components and eigenvalues, and a “generic” energy deposition history is somewhat different between the two cases. However, the eigenvalues of the first several PCs are quite similar, and using log binning instead of linear binning does not significantly affect the results of §[IV.2](#S4.SS2 "IV.2 Sensitivity of future experiments ‣ IV Detectability ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"): in both cases a similar (small) number of PCs are sufficient to describe a very broad class of energy deposition histories, for the purpose of future experiments. For individual models, of course, the number of measurable PCs depends on the choice of basis: a $p(z)$ curve which happens to be very well described as a linear combination of the first two PCs in the log-binned case may not be nearly so well described by the first two PCs in the linear-binned case, or vice versa.

In Figure [5](#S3.F5 "Figure 5 ‣ III.1 The principal components ‣ III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") we showed the Planck PCs for both linear and log binning in the annihilation case. The first PC is peaked at higher redshift in the log-binned case: this is to be expected, since in the log-binned case the amount of energy deposited per bin for a constant $p(z)$ has an extra $(1+z)$ scaling relative to the linear case (simply due to the wider bins at high redshift). It can be shown that this simple rescaling largely (but not completely) describes the difference between log and linear binning for the first PC, but the later PCs shift by a larger amount and in more complex ways, as each must be orthogonal to all previous PCs.

### A.2 The effect of noise and maximum $\ell$

As a default, we include $\ell=2..2500$ in our analysis, for both temperature and polarization. $\ell$’s above 1000 do not noticeably affect the principal components for WMAP, but have significant effects for Planck (and the CVL case), especially in the higher PCs. Figure [23](#A1.F23 "Figure 23 ‣ A.2 The effect of noise and maximum ℓ ‣ Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") shows the effect on a selection of PCs on changing $\ell\_{\mathrm{max}}$. The results also depend on the estimated sensitivity of the experiment.

Figure 23: The dependence of a selection of PCs on the range of $\ell$ included in the analysis, for WMAP 7 (*left*) and Planck (*right*).

### A.3 Choice of ionization history calculator and recombination corrections

Recent improvements in the detailed treatment of recombination have motivated new codes to compute the ionization history, in particular CosmoRec [[15](#bib.bib15)] and HyRec [[16](#bib.bib16)]. The inclusion of these additional recombination corrections can modify the effect of energy deposition on the ionization history and the CMB, thus shifting the derivatives and modifying the principal components. However, comparing the principal components obtained using RECFAST 1.5 to those obtained using CosmoRec, we find that there is essentially no difference. The overall normalization of the effect, for a given energy deposition history, is slightly smaller (by a few percent) in CosmoRec as compared to RECFAST 1.5, but as shown in Figure [24](#A1.F24 "Figure 24 ‣ A.3 Choice of ionization history calculator and recombination corrections ‣ Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") the shapes of the PCs are unaffected. This shift in normalization will not change the detectability of the maximum WMAP -allowed signal in Planck, and will only very slightly modify the amount of energy deposition required to produce such a signal.

Figure 24: The first three principal components for Planck, after marginalization, computed using RECFAST 1.5 and CosmoRec. In the baseline case (as in CosmoRec), ionization of helium is included but injection of Lyman-$\alpha$ photons is not. We also show the effects of including a contribution to Lyman-$\alpha$ photons, and neglecting helium. The effect of helium ionization on the PCs is negligible because it is approximately a redshift-independent effect.

### A.4 Helium and Lyman-$\alpha$

Ionization of helium also contributes to the population of free electrons, and is included automatically in CosmoRec: however, some previous studies have neglected it, focusing only on the H contribution. We include helium by default throughout, but show in Figure [24](#A1.F24 "Figure 24 ‣ A.3 Choice of ionization history calculator and recombination corrections ‣ Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") the (negligible) effect on the PCs of leaving it out. Similarly to the choice of ionization history calculator, including helium increases the total effect of a given energy deposition history, but does not significantly modify the redshift dependence and hence the PCs.

A more difficult question is the effect of additional Lyman-$\alpha$ photons. The energy from dark matter annihilation that is deposited to the gas is partitioned between excitation, ionization and heating. In the analysis of [[8](#bib.bib8)], which we have followed, only the latter two processes are included; excitations are assumed to have no significant effect. However, it was pointed out in [[36](#bib.bib36)] that the increased population of Lyman-$\alpha$ photons from excitations – or equivalently, the higher fraction of H in an excited state – facilitates ionization and thus indirectly increases the ionization fraction.

We studied the effect of including Lyman-$\alpha$ photons, following [[36](#bib.bib36), [55](#bib.bib55)] and assuming all the energy partitioned into excitation produces Lyman-$\alpha$ photons. The true picture is probably more complicated, but its study lies beyond the scope of this work, and this choice and our baseline case with no additional Lyman-$\alpha$ photons should bracket the true solution. Figure [24](#A1.F24 "Figure 24 ‣ A.3 Choice of ionization history calculator and recombination corrections ‣ Appendix A Validation of the PCA method ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics") shows the effect on the PCs of including the Lyman-$\alpha$ contribution. The corresponding effect on the $S/N$ for the various PCs is indicated by the hatched region in Figure [10](#S4.F10 "Figure 10 ‣ IV.2 Sensitivity of future experiments ‣ IV Detectability ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"); the bound on constant $p\_{\mathrm{ann}}$ is strengthened by $\sim 7-10\%$ (depending on the experiment).

### A.5 Additional cosmological parameters

Since the primary effect of dark matter annihilation is an $\ell$-dependent damping of the temperature anisotropies, one might ask if it is degenerate with other cosmological parameters that have a similar effect: for example, including running of the scalar spectral index could better mimic the profile of the damping with respect to $\ell$, increasing the number of massless neutrino species $N\_{\mathrm{eff}}$ also suppresses small-scale anisotropy, and the primordial helium mass fraction $Y\_{P}$ has degeneracies with $N\_{\mathrm{eff}}$ [[56](#bib.bib56)]. Accordingly, we have redone the principal component analysis including each of these parameters separately, as well as all of them simultaneously.

In all cases, we find only negligible shifts to the principal components. The forecast constraint on constant $p\_{\mathrm{ann}}$ from Planck is weakened by $\sim 7\%$ if running of the spectral index is included, and by $\sim 12\%$ if all three parameters are used. For WMAP 7, the Fisher-matrix-estimated limit weakens by $\sim 11\%$ and $\sim 13\%$ in these two cases.

## Appendix B Review of marginalization and biases

### B.1 Marginalization as projection

Marginalization over some parameters in the Fisher matrix is
equivalent to a projection of the vector space spanned by all the
parameter perturbations. Another way of saying this is that given the
transfer matrix (Equation [2](#S2.E2 "In II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")) for the parameters of interest, then the marginalized
Fisher matrix for those parameters is formed by contracting the projected transfer matrix with the covariance matrix $\Sigma^{-1}$.

We illustrate these statements for the situation considered in this
paper. The total vector space consists of the $\delta C\_{\ell}$’s
spanned by energy deposition and cosmological parameter perturbations,
and we wish to marginalize over the cosmological parameters. Recall
that the full Fisher matrix is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left(\begin{array}[]{cc}F\_{e}&F\_{v}\\ F\_{v}^{T}&F\_{c}\end{array}\right)=\left(\begin{array}[]{cc}T\_{e}^{T}\Sigma^{-1}T\_{e}&T\_{e}^{T}\Sigma^{-1}T\_{c}\\ T\_{c}^{T}\Sigma^{-1}T\_{e}&T\_{c}^{T}\Sigma^{-1}T\_{c}\end{array}\right),$ |  | (18) |

where $T\_{e}$ and $T\_{c}$ are transfer matrices mapping energy deposition histories
and cosmological parameter perturbations, respectively, to the space
of $\delta C\_{\ell}$’s. For ease of notation we suppress indices. Using
Equation [9](#S2.E9 "In II.1 Brief review of the Fisher matrix ‣ II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), the marginalized Fisher matrix can
be written as

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle F$ | $\displaystyle=F\_{e}-F\_{v}F\_{c}^{-1}F\_{v}^{T}=\left(PT\_{e}\right)^{T}\Sigma^{-1}\left(PT\_{e}\right)$ |  | (19) |

where $P=\left(1-T\_{c}\left(F\_{c}\right)^{-1}T\_{c}^{T}\Sigma^{-1}\right)$ satisfies $P^{2}=P$ and so is a projection operator. $P$
projects out any component of $\delta C\_{\ell}$ which can be effectively
absorbed by a change in the cosmological parameters. This can also be
seen if we act with $P$ on a generic perturbation in the cosmological
parameters: $PT\_{c}\delta\theta\_{\alpha}=0$. Accordingly, any
perturbation to the fiducial CMB model can be written as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\delta C\_{\ell}=(1-P)\delta C\_{\ell}+P\delta C\_{\ell}=\delta C\_{\ell}^{||}+\delta C\_{\ell}^{\perp}.$ |  | (20) |

where $\perp$ and $||$ mean perpendicular or parallel to the
cosmological parameter perturbations.

Thus $PT\_{\epsilon}$ is a projected transfer matrix, taking energy
deposition histories to the subspace of $\delta C\_{\ell}$’s which are orthogonal to
cosmological parameter perturbations. This projection depends on the
noise parameters in $\Sigma^{-1}$, since the notion of orthogonality
depends on our definition of norm. Intuitively, if an energy deposition
and cosmological parameter perturbation have very similar effects at
low $\ell$ but are different at high $\ell$, then the projection
operator may give a very small $\delta C\_{\ell}^{\perp}$ in the case of
WMAP and a larger $\delta C\_{\ell}^{\perp}$ in the case of Planck.

The eigenvectors ${e\_{i}}$ of $F$ (or principal components) with the
largest eigenvalues are correspondingly those with the largest
measurable $\delta C\_{\ell}^{\perp}$. The $e\_{i}$ also map to an orthogonal
vector space of $\delta C\_{\ell}^{\perp}$’s. The unprojected $h\_{i}=T\_{e}e\_{i}$ are in general not orthogonal because $h\_{i}\cdot h\_{j}=(T\_{e}e\_{i})^{T}\Sigma^{-1}(T\_{e}e\_{j})=e\_{i}^{T}F\_{e}e\_{j}$. However, defining
$h\_{i}^{\perp}=PT\_{e}e\_{i}$, we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $h\_{i}^{\perp}\cdot h\_{j}^{\perp}=(PT\_{e}e\_{i})^{T}\Sigma^{-1}(PT\_{e}e\_{j})=e\_{i}^{T}Fe\_{j}=\delta\_{ij}\lambda\_{i}.$ |  | (21) |

Because the $h\_{i}^{\perp}$ are orthogonal, we can extract the
coefficients of the principal components from a generic $R\_{\ell}\in\{\delta C\_{\ell}\}$:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\varepsilon\_{i}$ | $\displaystyle=\frac{1}{\lambda\_{i}}(PT\_{e}e\_{i})^{T}\Sigma^{-1}R\_{\ell}=\frac{R\cdot h\_{i}^{\perp}}{\lambda\_{i}}.$ |  | (22) |

### B.2 Biases to cosmological parameters

The parallel components from energy deposition, $\delta C\_{\ell}^{||}=(1-P)T\_{e}e\_{i}\varepsilon\_{i}$, correspond to the biases to the cosmological parameters. Suppose there is some energy deposition ($\varepsilon\_{i}\neq 0$), but it is not included in the fit to the data. Then the best fit cosmological parameters will absorb any $\delta C\_{\ell}^{||}$ from the energy deposition, and the measurements of the true cosmological parameters would be biased by the amount it takes to produce $\delta C\_{\ell}^{||}$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\delta C\_{\ell}^{||}=T\_{c}\delta\theta\_{\alpha}=(1-P)T\_{e}e\_{i}\varepsilon\_{i}.$ |  | (23) |

Multiplying both sides by $(F\_{c})^{-1}T\_{c}^{T}\Sigma^{-1}$, we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\delta\theta\_{\alpha}=F\_{c}^{-1}F\_{v}^{T}e\_{i}\varepsilon\_{i}.$ |  | (24) |

## Appendix C Web files description

To facilitate the analysis described above, we provide the PC vectors defined
above on our web page1414
14
http://nebel.rc.fas.harvard.edu/epsilon. The
files are provided in two formats: as a the Flexible Image Transport
System1515
15
http://fits.gsfc.nasa.gov (FITS) binary table, and as ASCII
plain text files. The file formats are described briefly in this appendix,
and in more detail on the web page.

### C.1 FITS files

Each FITS file has the following format:

```
L                 Array[2500]        - multipole index (2..2501)
REDSHIFT          Array[50]          - redshift (z)
PC_EIGENVECTORS   Array[50, 5]       - PC as a function of redshift
EPSILON           2.0000000e-27      - energy deposition, see Section IIIB of paper
EIGENVALUES       Array[5]           - PC eigenvalues
PC_POWSPEC        Array[2500, 3, 5]  - PCs projected into Cl space, TT, EE, TE
PC_POWSPEC_PERP   Array[2500, 3, 5]  - same, but projected onto the space perpendicular to the
                                       cosmological parameters
```

We also provide the universal $e\_{\mathrm{WIMP}}$ curve derived in §[V](#S5 "V A universal 𝑝_ann⁢(𝑧) for WIMP annihilation ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), following the same notation, and a list of efficiency coefficients for the WIMP models studied in [[10](#bib.bib10)].

### C.2 ASCII files

We also provide the mappings of the PCs into $\delta C\_{\ell}$’s in ASCII files, one per principal
component. File names are e.g.

```
epsilon_ann_Planck_PC01.dat
epsilon_ann_Planck_PC01_perp.dat
```

etc., with one file for each PC, choice of binning, and experiment (CVL, Planck and WMAP 7). Each of these ASCII files contains 4 columns: $\ell,PC\_{TT},PC\_{EE},PC\_{TE}$.

For each experiment and choice of binning, one additional ASCII file contains the ordered eigenvalues for the principal components, and another holds the ordered eigenvectors / PCs as functions of redshift. These files are named e.g.

```
epsilon_ann_Planck_PC_eigenvalues.dat
epsilon_ann_Planck_PC_eigenvectors.dat
```

### C.3 Units

The PC vectors PC\_POWSPEC and PC\_POWSPEC\_PERP are the changes in $\ell(\ell+1)C\_{\ell}/2\pi$ (before and after projecting out the cosmological parameters, respectively) corresponding to an energy deposition history given by $\varepsilon\_{i}=\varepsilon$ for all $i$ (where the $\varepsilon\_{i}$ are dimensionful coefficients defined in Equation [12](#S3.E12 "In III.2 Mapping into 𝛿⁢𝐶_ℓ space ‣ III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")). Our convention,
described in §[III.2](#S3.SS2 "III.2 Mapping into 𝛿⁢𝐶_ℓ space ‣ III Principal Component Analysis ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics"), is that the $C\_{\ell}$ have units of $\mu{\rm K}^{2}$, the principal components $e\_{i}$ are dimensionless,
energy deposition from annihilations has
units cm3/s/GeV, and energy deposited by decays has units of s-1 (see Equation [1](#S2.Ex1 "In II The Effect of Energy Injection ‣ Searching for Dark Matter in the CMB:A Compact Parameterization of Energy Injection from New Physics")). The energy deposition parameter $\varepsilon$ (labeled EPSILON in the files) is fixed at $2\times 10^{-27}$ cm3/s/GeV for the annihilation case, and $1\times 10^{-26}{\rm~s}^{-1}$ for
the decay case.
