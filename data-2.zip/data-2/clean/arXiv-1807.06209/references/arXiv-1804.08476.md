<!-- fulltext source=arxiv_html slug=arXiv-1804.08476 fetched=2026-09-18T01:13:50+00:00 -->

# Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories

Marius Millea
Affiliation: Institut Lagrange de Paris (ILP), Sorbonne Universités, 98bis boulevard Arago, F-75014 Paris, France
Affiliation: Institut d’Astrophysique de Paris (IAP), UMR7095, CNRS & Sorbonne Universités, 98bis boulevard Arago, F-75014 Paris, France
  
François Bouchet
Affiliation: Institut d’Astrophysique de Paris (IAP), UMR7095, CNRS & Sorbonne Universités, 98bis boulevard Arago, F-75014 Paris, France

Affiliation: 
Email: [mariusmillea@gmail.com](mailto:mariusmillea@gmail.com)

###### Abstract

Non-parametric reconstruction or marginalization over the history of reionization using cosmic microwave background data necessarily assumes a prior over possible histories. We show that different but reasonable choices of priors can shift current and future constraints on the reionization optical depth, $\tau$, or correlated parameters such as the neutrino mass sum, $\Sigma m\_{\nu}$, at the level of 0.3–0.4 $\sigma$, i.e., that this analysis is somewhat prior dependent. We point out some prior-related problems with the commonly used principal component reconstruction, concluding that the significance of some recent hints of early reionization in Planck 2015 data has been overestimated. We also present the first non-parametric reconstruction applied to newer Planck intermediate (2016) data and find that the hints of early reionization disappear entirely in this more precise dataset. These results limit possible explanations of the EDGES 21cm signal which would have also significantly reionized the universe at $z\,{>}\,15$. Our findings about the dependence on priors motivate the pursuit of improved data or searches for physical reionization models which can reduce the prior volume. The discussion here of priors is of general applicability to other non-parametric reconstructions, for example of the primordial power spectrum, of the recombination history, or of the expansion rate.

###### Key Words.

cosmology — cosmic microwave background — reionization

## 1 Introduction

The exact details of the “epoch of reionization”, during which the universe transitioned from a mostly neutral hydrogen gas into the highly ionized state we see today, are still of considerable uncertainty. This transition left several imprints on the Cosmic Microwave Background (CMB) which can be used to constrain the physics of reionization, but also serve as a “nuisance” uncertainty which must be marginalized over when considering constraints on other parameters.

One of the most widely used methods for reconstructing or marginalizing over the reionization history from CMB data has been based on decomposing the history into eigenmodes ([Hu & Holder 2003](#bib.bib23), hereafter HH03). This has been applied to a number of datasets, for example the WMAP data ([Mortonson & Hu 2008b](#bib.bib38), hereafter MH08), and most recently the Planck 2015 data ([Heinrich et al. 2017](#bib.bib22); [Heinrich & Hu 2018](#bib.bib21); [Obied et al. 2018](#bib.bib39)). The latter works argue that the generic reconstruction reveals a $>\!2\,\sigma$ preference for a high-redshift ($z\gtrsim 15$) contribution to the optical depth, $\tau$. Conversely, other works have used alternate methods and not found such evidence in this same dataset ([Hazra & Smoot 2017](#bib.bib20); [Villanueva-Domingo et al. 2018](#bib.bib52)).

In this work, we will point out two problems with PCA analyses that have to-date been largely or completely overlooked. Correcting these problems will lead to finding reduced evidence of early reionization in the Planck 2015 data, more consistent with the latter results.

The first problem has been mentioned in [Mortonson & Hu (2008b)](#bib.bib38), [Heinrich & Hu (2018)](#bib.bib21), and described in some detail in [Lewis et al. (2006)](#bib.bib29), although not explicitly in relation to the PCA model. The issue is that taking a flat prior on amplitudes of the reionization principal components induces a non-flat prior on $\tau$. [Heinrich & Hu (2018)](#bib.bib21) argue that this effect is unimportant, but do not perform direct or fully conclusive tests. Here we perform the very direct test of simply calculating the effective $\tau$ prior induced by the flat mode priors, finding that it is roughly $\tau\approx 0.20\,{\pm}\,0.07$. Using a maximum entropy procedure, we remove the effects of this prior, finding that it accounts for a significant part of the shift to higher $\tau$ reported by [Heinrich et al. (2017)](#bib.bib22).

Another problem with existing PCA analyses lies in the choice of physicality priors. These priors are necessary to ensure that the reconstructed ionization fraction at any given redshift remains within physical range (i.e., remains positive but less that the maximum corresponding to a fully ionized universe). Due to the nature of the PCA decomposition, the physicality priors necessarily allow some unphysical models (this may seem quite counter-intuitive, but we will give a simple geometric picture of why this is indeed the case). However, existing analyses have used a sub-optimal set of physicality priors which allowed more unphysical models than necessary. We will derive the optimal set of priors, and show that switching to these leads to significant changes in constraints. Together with removing the impact of the informative $\tau$ prior, we find that evidence for early reionization in the Planck 2015 data is reduced from $>\!2\,\sigma$ to $1.4\,\sigma$.

Since the PCA results depend significantly on the details of the physicality priors, which will always be necessarily imperfect, we conclude that the PCA procedure is poorly tailored to the problem of generic reionization history reconstruction. We will seek a better method, in particular one which does not allow unphysical models. To this end, we propose what we will call the FlexKnot model. This model interpolates the history using a varying number of knots, with the exact number of knots determined by the data itself via a Bayesian evidence calculation. The model is somewhat similar to the [Hazra & Smoot (2017)](#bib.bib20) approach, but improves upon it by not requiring an a posteriori and fixed choice of knot positions, which otherwise creates undesired regions of high prior probability at certain redshifts. The FlexKnot model follows almost exactly the same procedure used previously to generically reconstruct the primordial power spectrum from Planck data ([Vázquez et al. 2012](#bib.bib51); [Planck Collaboration
XX 2016](#bib.bib44)), and is particularly well suited to the problem here as well.

Using these reionization models, we calculate new constraints on the history of reionization coming from Planck intermediate data, in particular using the simlow likelihood ([Planck Collaboration Int.
XLVI 2016](#bib.bib45)). We will refer to the combination of Planck 2015 data and the simlow likelihood as the Planck 2016 data. This likelihood has already been used to explore various parametric reionization models ([Planck Collaboration Int.
XLVII 2016](#bib.bib46)); however, a generic reconstruction fully capable of detecting an early component to reionization (should it be there) has not yet been performed. We report results from this particular dataset here.

The Planck 2016 data represents a significant increase in constraining power on reionization as compared to the 2015 data, and we find that the remaining $1.4\,\sigma$ hints of an early reionization component are completely erased. Instead, we tightly constrain the $z\,{>}\,15$ contribution to the optical depth to be $<0.015$ at 95% confidence, and find good agreement with a late and fast transition to a fully ionized universe, consistent with the conclusions of [Planck Collaboration Int.
XLVII (2016)](#bib.bib46).

Even though the simlow data are quite constraining, some dependence on priors remains when performing generic reconstruction. In particular, the difference between a flat prior on $\tau$ and a flat prior on the knot positions leads to an $0.4\,\sigma$ shift in the resulting $\tau$ constraint. Both of these priors are fairly reasonable, and we consider it difficult to argue very strongly for one or the either of these priors in a completely generic setting. We thus consider this indicative of a level of systematic uncertainty stemming from our imperfect knowledge of the model, which we then propagate into shifts on other parameters which are correlated with $\tau$, given both current data and future forecasts.

We specifically focus on the sum of the neutrino masses, $\Sigma m\_{\nu}$, which is expected to be measured extremely precisely by next generation CMB experiments ([Abazajian et al. 2015](#bib.bib2)). Using Fisher forecasts, we show that a possible $0.4\,\sigma$ bias on $\tau$ from switching priors manifests itself as a $0.3\,\sigma$ bias on $\Sigma m\_{\nu}$ given expect constraints from a “Stage 4” CMB experiment ([Abazajian et al. 2016](#bib.bib1), CMB-S4;). We comment on the ability of combining with other probes, such as DESI-BAO, or a cosmic-variance-limited CMB large-scale polarization measurement, to reduce this uncertainty.

Given these biases, we conclude that generic reconstructions of the reionization history are likely not enough to achieve the most accurate bounds on $\Sigma m\_{\nu}$. This motivates work on obtaining constraints with physical models which have free parameters that can realistically account for our lack of exact knowledge about the physics of reionization. Although not directly used throughout the paper, will also comment on the possibility for other probes of reionization to reduce the dependence on priors, specifically measurements of the patchy kinetic Sunyaev-Zeldovich effect ([Gruzinov & Hu 1998](#bib.bib15); [Knox et al. 1998](#bib.bib25)) and direct probes of the ionization state of the inter-galactic medium ([Bouwens et al. 2015](#bib.bib7)).

The paper is outlined as follows. In Sec. [2](#S2 "2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") we discuss the reionization models we consider, and in Sec. [3](#S3 "3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") we focus on the implicit $\tau$ prior induced by these procedures. These sections are a fairly technical description of the methodology used, and those wishing to see the results should skip to Secs. [4](#S4 "4 Hints of early reionization in Planck 2015 data? ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"), [5](#S5 "5 Reionization from Planck intermediate data ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"), and [6](#S6 "6 Impact on Future Data ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") where we discuss constraints from Planck 2015, intermediate, and future data, respectively.

## 2 Reionization models

### 2.1 The TANH model

The reionization history often assumed in CMB analyses because it has a useful parametric form and matches physical expectations somewhat well involves a single smooth step from an almost fully neutral universe11
1
There is a small residual ionization level on the order of $10^{-4}$ remaining after recombination. We ignore this as the data considered here is insensitive to it. to one with hydrogen fully ionized and helium singly ionized. The free electron fraction, in our convention the ratio between the number density of free electrons and hydrogen nuclei, $x\_{\rm e}\equiv n\_{\rm e}/n\_{\rm H}$, is taken to be

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle x\_{\rm e}^{\rm TANH}(z)=\frac{1+f\_{\rm He}}{2}\left\{1+\tanh\left[\frac{y(z^{\*})-y(z)}{\Delta y}\right]\right\},$ |  | (1) |

with $y(z)=(1+z)^{3/2}$ and $\Delta y=3/2(1+z)^{1/2}\Delta z$, giving a transition centered at redshift $z^{\*}$ with width $\Delta z\,{=}\,0.5$. Here the factor $f\_{\rm He}$ is the number density ratio of helium to hydrogen nuclei (we have neglected all other atoms). We will refer to this model as the “TANH” model.

The contribution to the optical depth between any two redshifts $z\_{1}$ and $z\_{2}$ for this (or any) reionization history can be written as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\tau(z\_{1},z\_{2})=\sigma\_{T}\int\_{z\_{1}}^{z\_{2}}dz\,\frac{n\_{\rm H}(z)(1+z)^{2}}{H(z)}x\_{\rm e}(z),$ |  | (2) |

where $\sigma\_{\rm T}$ is the Thompson scattering cross-section. This is often used to parametrize Eq. ([1](#S2.E1 "In 2.1 The TANH model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) in terms of the total optical depth $\tau\equiv\tau(0,z\_{\rm early})$ rather than $z^{\*}$ (where $z\_{\rm early}$ is some redshift before reionization began, but after recombination ended).

Note that in this convention for $x\_{\rm e}$, the maximum ionization fraction can be greater than one, in particular can be as large as $x\_{\rm e}^{\rm max}\equiv 1+f\_{\rm He}$ before the second recombination of helium. We also note that second helium recombination is expected to be a small contribution to $\tau$, on the order of $\approx 0.001$ depending on the exact values of other cosmological parameters. As this is already fairly small, we ignore any model-dependence in helium second reionization and model it as another transition with the same hyperbolic tangent form as in Eq. ([1](#S2.E1 "In 2.1 The TANH model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) but with $z\_{\*}\,{=}\,3.5$ and $\Delta z\,{=}\,0.5$, normalized such that it increases the ionization fraction from $x\_{\rm e}^{\rm max}$ to $1+2f\_{\rm He}$.

### 2.2 The PCA model

The TANH model has some parametric freedom, more-so if $\Delta z$ is also taken as a free parameter. However, we would like a model which can reproduce any arbitrary history, thus allowing us to generically reconstruct $x\_{\rm e}(z)$ from the data.

HH03 proposes a model based on decomposing the free electron fraction history into eigenmodes such that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle x\_{\rm e}^{\rm HH03}(z)=x\_{\rm e}^{\rm fid}(z)+\sum\_{i}m\_{i}S\_{i}(z)$ |  | (3) |

for some fiducial $x\_{\rm e}^{\rm fid}(z)$, eigenmode amplitudes $m\_{i}$, and eigenmode templates $S\_{i}(z)$. These templates have support between some $z\_{\rm min}$ and $z\_{\rm max}$ and are uniquely defined by three properties:

1. 1.

   they form a special orthonormal basis22
   2
   For clarity, we suppress writing the integration limits $z\_{\rm min}$ and $z\_{\rm max}$ for the rest of the paper. The exact normalization is purely a definitional choice. Similarly, the distinction of special orthonormal basis, i.e., that $S$ is purely a rotation, is not usually made, but we choose to do so here for definiteness and for aiding the subsequent geometrical interpretation. for $x\_{\rm e}(z)$, implying that $\int dz\,S\_{i}(z)S\_{j}(z)=\delta\_{ij}$.
2. 2.

   they diagonalize the covariance of the amplitude parameters given cosmic-variance-limited large-scale polarization data, $\langle\Delta m\_{i}\Delta m\_{j}\rangle=\sigma\_{i}^{2}\delta\_{ij}$;
3. 3.

   they are ordered by increasing $\sigma\_{i}$.

The lack of Gunn-Peterson absorption in quasars out to $z\approx 6$ strongly constrains the universe to be very close to fully reionized by this redshift ([Becker et al. 2001](#bib.bib4); [Fan et al. 2002](#bib.bib12)). We implicitly impose these bounds here by setting $z\_{\rm min}\,{=}\,6$. Similarly as in other PCA analyses, we take $z\_{\rm max}\,{=}\,30$.

#### 2.2.1 Geometric View of Physicality Priors

Figure 1: A geometric picture of the PCA physicality priors in two-dimensions, demonstrating why they necessarily allow unphysical regions of parameter space. The solid blue square is the physicality region in terms of the ionization fraction, $x\_{1}$ and $x\_{2}$, at individual redshifts. The solid orange square is the physicality region in terms of the mode amplitudes, $m\_{1}$ and $m\_{2}$. The two types of physicality priors corresponding to Eq. ([4](#S2.E4 "In 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) and Eq. ([5](#S2.E5 "In 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) are shown as the dashed square and dashed circle, respectively. Their intersection, shaded orange, is the full physicality region. The left panel takes a fiducial ionization history, $x^{\rm fid}=0.15$, consistent with [Mortonson & Hu (2008a)](#bib.bib37) and subsequent works. The right panel shows that the undesired but allowed unphysical parameter space can be reduced (but not fully) with a better choice of fiducial model.

The HH03 procedure also calls for a set of “physicality priors” on these mode amplitudes. These are necessary because otherwise nothing prevents the mode amplitudes from taking on values such that the bound $0<x\_{\rm e}(z)<x\_{\rm e}^{\rm max}$ fails to hold for some $z$, and this would have no physical meaning. [Mortonson & Hu (2008a)](#bib.bib37) derive two sets of priors to enforce physicality. The first is an upper and lower bound on each $m\_{i}$ such that $m\_{i}^{-}\,{\leq}\,m\_{i}\,{\leq}\,m\_{i}^{+}$ with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle m\_{i}^{\pm}=\int dz\left\{S\_{i}(z)\left[1-2x\_{\rm e}^{\rm fid}(z)\right]\pm\left|S\_{i}(z)\right|\right\}/2.$ |  | (4) |

The second is an upper bound on the sum of the squares of the mode amplitudes,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\int dz\sum\_{i}m\_{i}^{2}<\int dz\,\big[x\_{\rm e}^{\rm max}-x\_{\rm e}^{\rm fid}(z)\big]^{2}.$ |  | (5) |

These priors may seem a bit abstruse, but they have a quite simple geometric interpretation which has not been highlighted before. We will give this interpretation here, aided by Fig. [1](#S2.F1 "Figure 1 ‣ 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"). This will also aid in spotting some improvements that can be made.

To start, consider the reionization history, $x\_{\rm e}(z)$, evaluated at $N$ redshifts, $z\_{i}$, and stacked into a vector $x\_{i}\equiv x\_{\rm e}(z\_{i})$. The physicality region in the $x\_{i}$ vector space is trivial, each $x\_{i}$ must individually fall between $0$ and $x\_{\rm e}^{\rm max}$. This region is thus an $N$-dimensional hypercube with one vertex at the origin, extending into the positive hyper-quadrant, and with edge length $x\_{\rm e}^{\rm max}$.

The decomposition into mode amplitudes is given by applying the transformation $S$ to the residual between $x\_{i}$ and the fiducial model,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle m\_{i}=\sum\_{j}S\_{ij}(x\_{j}-x^{\rm fid}\_{j}),$ |  | (6) |

where $S\_{ij}\equiv S\_{i}(z\_{j})$, i.e., it is a matrix for which each row is one of the eigenmodes. The physicality region in the $m\_{i}$ vector space is thus a translated and transformed version of the original hypercube. Note that because $S$ is special orthonormal and thus can only contain rotations, the region remains a hypercube.

Let us now visualize this transformation in two dimensions, represented in the left panel of Fig. [1](#S2.F1 "Figure 1 ‣ 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"). The solid blue square is the physicality region in terms of $x\_{i}$, here just $x\_{1}$ and $x\_{2}$. The solid orange square is the same region after transformation by Eq. ([6](#S2.E6 "In 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")), assuming some arbitrary $S$ for demonstration purposes, and taking $x^{\rm fid}\_{j}=0.15$ following [Mortonson & Hu (2008a)](#bib.bib37) and all other subsequent PCA analyses.

If we were simultaneously fitting $m\_{1}$ and $m\_{2}$ in our analysis, the physicality region would be trivial to enforce, and would be given simply by the solid orange square. However, the point of the PCA procedure is that we do not need to simultaneously fit both parameters, as higher order modes like $m\_{2}$ can be effectively marginalized over by just fixing them, since they have no observable impact and are decorrelated with the lower order modes like $m\_{1}$. Usually we fix $m\_{2}\,{=}\,0$, but any other value should work just as well. In designing the physicality prior for $m\_{1}$, we need to ensure that all values that $m\_{1}$ could take are allowed, not just those allowed when $m\_{2}\,{=}\,0$, since this was just an artificial method of marginalization. Put another way, one must consider that a model which appears to be unphysical could be brought back into physicality by adjusting the higher order mode amplitudes which were artificially set to zero. This leads to two priors which can be constructed.

The first prior is simply the bounding box of the solid orange square and is depicted as the dashed orange square. We will refer to this as the ‘‘hyperbox’’ prior33
3
Note that in dimensions higher than the two depicted in Fig. [1](#S2.F1 "Figure 1 ‣ 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"), this region does not necessarily have equal edge length in all directions, and is thus truly a hyperbox as opposed to a hypercube.. This prior just takes a hard bound on each $m\_{i}$ corresponding to the largest and smallest possible value for that $m\_{i}$ anywhere within the physicality region. This is indeed exactly what is calculated by Eq. ([4](#S2.E4 "In 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")). One can see this by noting that the $x\_{j}$ which maximizes $m\_{i}$ in Eq. ([6](#S2.E6 "In 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) is such that $x\_{j}\,{=}\,x^{e}\_{\rm max}$ if $S\_{ij}$ is positive, and zero otherwise, and that Eq. ([4](#S2.E4 "In 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) is the transform of this $x\_{j}$.

The second prior comes from noting that as long as $x^{\rm fid}\,{\leq}\,x\_{\rm e}^{\rm max}/2$, the top right corner of the physicality region in terms of $x$ (i.e. the top right corner of the solid blue square in Fig. [1](#S2.F1 "Figure 1 ‣ 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")), will always be the furthest point from the origin even after transformation. Its distance from the origin will be unaffected by the rotation $S$, only by the translation by $x\_{\rm fid}$, thus we can exclude points further than $\|x\_{\rm e}^{\rm max}-x^{\rm fid}\|$ in the mode parameter space. This leads to the physicality region depicted by the dashed circle, and we will refer to this as the “hypersphere” prior. One can recognize this as the second MH08 prior in Eq. ([5](#S2.E5 "In 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) by noting that integral over $z$ there is analogous to the sum that appears in the vector norm, $\|x\_{\rm e}^{\rm max}-x^{\rm fid}\|$.

The intersection of these two priors is shaded orange, and corresponds to the full MH08 physicality region. Note that although the two priors do remove some of the allowed unphysical regions of parameter space, they can never remove all of them. As we will see in Sec. [5](#S5 "5 Reionization from Planck intermediate data ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"), this unavoidably allowed unphysical region has undesirable consequences.

While the amount of unphysical parameter space allowed by the hyperbox prior does not depend on our choice of $x^{\rm fid}$, this is not the case for the hypersphere prior. Indeed, the geometric picture makes it clear that we could reduce the allowed unphysical regions by picking $x^{\rm fid}\,{=}\,x^{\rm max}/2$, i.e., placing the fiducial model at the center of the original hypercube.44
4
Equivalently, we could modify the hypersphere prior to be centered on the physicality region rather than on the origin, but we choose to discuss this in terms of picking a different $x^{\rm fid}$ simply for convenience so that Eq. ([5](#S2.E5 "In 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) is unchanged. This is depicted in the right panel of Fig. [1](#S2.F1 "Figure 1 ‣ 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"). This choice is optimal in the sense that no other choice of $x^{\rm fid}$ excludes as much of the unphysical region, given the two priors we have constructed. As we will see in Sec. [3](#S3 "3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"), using the optimal physicality region is also useful because the increased symmetries in this case allow an analytic calculation of the induced $\tau$ prior.

The physicality prior obtained by taking $x^{\rm fid}$ to be in the center of the physicality region is objectively better than other choices, and should be used. It does not bias the analysis in any other way, in fact it prevents biases from an over-allowance of unphysical parameters. We will show in Secs. [4](#S4 "4 Hints of early reionization in Planck 2015 data? ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") and [5](#S5 "5 Reionization from Planck intermediate data ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") that the “sub-optimality” of the MH08 prior has a significant impact on constraints from data.

### 2.3 The HS17 model

Figure 2: One thousand reionization histories sampled from their prior distribution given the different models we consider. In the PCA case, the prior over PCA modes is taken to be uniform within the physicality region; in the two knot cases, the prior is uniform on the position and/or amplitude of each knot (thus none of these priors correspond to a flat $\tau$ priors). The left panel shows the extent to which the PCA procedure allows unphysical models, even when using the optimal physicality priors. The middle panel shows that the HS17 prior creates odd features and tighter peaked priors in the regions between the knot locations (which are indicated with arrows). The right panel is the prior for the FlexKnot model and represents our best solution for creating a reasonable and “homogeneous” prior.

As discussed in the previous section and elsewhere ([Mortonson & Hu 2008a](#bib.bib37), e.g.,), one draw-back of the PCA model is the necessary inclusion of unphysical parameter space in the prior. In some sense this is because the PCA procedure rotates the parameters from a space in which the prior is easy to describe to one in which the likelihood is easy to describe. If we are in a regime where the prior is completely uninformative, this is a very beneficial rotation; here, however, this is not quite the case.

One solution is thus to not perform the PCA rotation at all, and keep the values of ionization fraction at some given redshifts (the $x\_{i}$) as the parameters. Then we can always fully and sufficiently enforce physicality by requiring that $0\,{<}\,x\_{i}\,{<}x\_{\rm e}^{\rm max}$ for all $z$. Variations on this avenue have been explored in e.g. [Colombo & Pierpaoli (2009)](#bib.bib9), [Lewis et al. (2006)](#bib.bib29), and [Hazra & Smoot (2017)](#bib.bib20). In this section we consider for definiteness the latter model, which we denote the HS17 model.

The HS17 model takes uniform priors on the values of $x\_{\rm e}(z)$ at $z$ = 6, 7.5, 10, and $20$, with end-points at $x\_{\rm e}(5.5)\,{=}\,x\_{\rm e}^{\rm max}$ and $x\_{\rm e}(30)\,{=}\,0$ fixed, and interpolates everywhere in between these knots using piecewise cubic Hermite interpolating polynomials (PCHIP). Although the choice is ad-hoc and made somewhat a posteriori (which makes judging the statistical evidence for this model difficult), it does likely capture much of the observable features of the reionization history. A larger problem, however, is that it creates an undesired prior distribution, shown in the middle panel of Fig. [2](#S2.F2 "Figure 2 ‣ 2.3 The HS17 model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"). While the prior on $x\_{\rm e}(z)$ at the $z$-values of the knots is uniform, it becomes triangular at the mid-point between knots, leading to the odd patterns seen in this figure. With a simple modification of this model, which we give in the next section, we are able to remove this oddly patterned prior.

### 2.4 FlexKnots

To remedy the non-idealities of both the PCA and HS17 models discussed thus-far, we develop the following model and analysis procedure, inspired by the primordial power spectrum reconstruction in the Planck analysis ([Vázquez et al. 2012](#bib.bib51); [Planck Collaboration
XX 2016](#bib.bib44)).

The model, which we call the FlexKnot model, has knots which can move left and right in addition to up and down. Our parameters are thus a set of $x\_{i}$ and $z\_{i}$, with uniform priors across the ranges

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle 6<z\_{i}<30,$ |  | (7) |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle 0<x\_{i}<x\_{\rm e}^{\rm max}.$ |  | (8) |

Additionally, given any set of $z\_{i}$, we compute the reionization history by first sorting them before interpolating between the knots ([Handley et al. 2015b](#bib.bib19), see also Appendix A2 of). We perform interpolation using the PCHIP scheme, similarly as to what is done in HS17.

Samples from this prior with 5 knots are shown in the right-most panel of Fig. [2](#S2.F2 "Figure 2 ‣ 2.3 The HS17 model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"). We see that the prior distribution is much more uniform than the HS17 prior, with no clustering around any particular redshift or ionization fraction value. This is the effect of the left/right freedom of knots, coupled with the sorting procedure.

A final question for the FlexKnot model remains, mainly how many knots to allow? We follow [Planck Collaboration
XX (2016)](#bib.bib44) in marginalizing over the number of knots by computing the Bayesian evidence for each of $n$ knots,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{Z}\_{n}=\int d\theta\,\mathcal{L}\_{n}(\theta\,|\,d)\mathcal{P}\_{n}(\theta),$ |  | (9) |

where $\mathcal{L}\_{n}$ and $\mathcal{P}\_{n}$ are the likelihood and prior given $n$, and computing the posterior distribution marginalized over $n$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{P}(y)=\sum\_{n=1}^{N}\frac{\pi\_{n}\mathcal{P}\_{n}(y)}{\mathcal{Z}\_{n}}.$ |  | (10) |

Here, $y$ can represent the ionization fraction history, $\tau$, or any other derived quantity of interest. The $\pi\_{n}$ are the prior weights which we give to a model with $n$ knots; we set this equal to one, i.e, we assume that every number of knots is equally probable. The evidence computation is performed in practice with PolyChord ([Handley et al. 2015a](#bib.bib18); [Handley et al. 2015b](#bib.bib19)).

Given the necessity of choosing the $\pi\_{n}$, one should ask: have we really gained anything by this procedure, or have we just swapped the requirement of making one choice of prior for another? To answer this, note that although some choice still remains, we have reduced the problem of picking a functional prior over all possible histories to one of simply picking a prior over which integer number of knots to take. This is a massive reduction in how arbitrary a choice we are required to make, and represents the key strength of this procedure. Additionally, as we will show in the next section, the data themselves largely disfavor the need for anything beyond one or two knots anyways, thus we are not particularly sensitive to the $\pi\_{n}$, as long as a reasonable choice is made.

## 3 Implicit prior on $\tau$

Figure 3: The solid colored lines show the implicit prior on $\tau$ from the PCA model when taking a flat prior on the mode amplitudes, computed via Monte Carlo. The top panel assumes the MH08 physicality region, whereas the bottom panel assumes our optimal physicality region. In the case of the bottom panel, analytic calculation of the prior is possible via Eq. ([15](#S3.E15 "In 3.1 Calculating the prior ‣ 3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) and shown as dotted lines. The top panel also shows the implicit prior for the HS17 model.

### 3.1 Calculating the prior

Although the details of how reionization proceeds are of significant physical interest, it is mostly the total overall integrated optical depth to reionization, $\tau$, that plays an important role in terms of CMB constraints. This is because $\tau$ modulates the amplitude of temperature and polarization power spectra at multipoles greater that a few tens by $e^{-2\tau}$, and is thus a source of degeneracy for the scalar amplitude, $A\_{\rm s}$, which does the same. The parameter $A\_{\rm s}$ itself is then degenerate with a number of other physical quantities of interest via various means ([Planck Collaboration
LI 2017](#bib.bib47)). It is thus important to examine what these different methods of reconstruction have to say in terms of $\tau$.

In particular, what prior over $\tau$ do the different approaches assume? Take, for example, the PCA model. Because the modes contribute linearly to $x\_{\rm e}(z)$ and because $\tau$ is in turn a linear functional of $x\_{\rm e}(z)$, each mode contributes linearly to the total optical depth,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\tau\big(\{m\_{i}\}\big)=\tau\_{\rm fid}+\sum\_{i}\left(\frac{d\tau}{dm\_{i}}\right)m\_{i},$ |  | (11) |

where $\tau\_{\rm fid}$ is the optical depth corresponding to $x\_{\rm e}^{\rm fid}$ and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\frac{d\tau}{dm\_{i}}=\sigma\_{T}\int dz\,\frac{n\_{\rm H}(z)(1+z)^{2}}{H(z)}S\_{i}(z).$ |  | (12) |

In all analyses to-date, the prior taken on the $m\_{i}$ has been uniform inside of the physicality region. We can compute the $\tau$ prior induced by this choice by propagating the $m\_{i}$ prior to $\tau$ via Eq. ([11](#S3.E11 "In 3.1 Calculating the prior ‣ 3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")). If the $m\_{i}$ are uncorrelated in the prior (which is a decent approximation if using the MH08 physicality priors where the hypersphere prior plays a sub-dominant role) the induced $\tau$ prior will be a convolution of a number of “top-hat” functions, which should tends towards some smooth distribution peaking near the $\tau$ corresponding to $m\_{i}\,{=}\,(m\_{i}^{+}+m\_{i}^{-})/2$. The exact solution (including both hyperbox and hypersphere) can be obtained numerically by Monte Carlo sampling from the $m\_{i}$ prior and computing $\tau$ for each sample. This is shown in the top panel of Fig. [3](#S3.F3 "Figure 3 ‣ 3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"). Indeed, we find that the prior is centered on $\tau\approx 0.2$ and has width around $\sigma(\tau)\approx 0.07$, shrinking and smoothing out as more modes are added.

It is important to note the existence of this prior when comparing constraints on $\tau$ from two different models, for example the TANH model (which takes a flat $\tau$ prior) and the PCA model. In such comparisons, we change not only the model but also implicitly change the prior. Given that the prior we see in Fig. [3](#S3.F3 "Figure 3 ‣ 3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") tends towards quite high values of $\tau$, it should not be entirely surprising if we find a higher $\tau$ posterior in the PCA case. In Sec. [4](#S4 "4 Hints of early reionization in Planck 2015 data? ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") we will quantify the impact this has on the [Heinrich et al. (2017)](#bib.bib22) analysis.

What about the induced prior in the case of the optimal physicality prior instead of the MH08 one? Here, the extra symmetries of the problem allow us to derive the following useful analytic solution. First, consider the simplified case of computing the $\tau$ prior induced by only the hypersphere prior. This is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{P}(\tau)=\int\_{\mathbb{S}}\;\displaystyle\prod\_{i=1}^{N}dm\_{i}\;\delta\left[\tau-\tau\big(\{m\_{i}\}\big)\right],$ |  | (13) |

where the region $\mathbb{S}$ is an $N$-dimensional hypersphere with radius $r\equiv x\_{\rm e}^{\rm max}/2$ and centered on the origin, and $\delta$ is the Dirac $\delta$-function. In geometric terms, Eq. ([13](#S3.E13 "In 3.1 Calculating the prior ‣ 3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) calculates the volume of the intersection of the hyperplane defined by $\tau-\tau(\{m\_{i}\})=0$ with the hypersphere $\mathbb{S}$. This intersection is itself an $N-1$ dimensional hypersphere. Its radius, $\rho$, is smaller than $r$ due the hyperplane having sliced through $\mathbb{S}$ at a position displaced from its center. The displacement distance is controlled by $\tau$ and given by $D=|\tau-\tau\_{\rm fid}|/|\mathbf{g}|$, where we have defined a vector normal to the hyperplane, $(\mathbf{g})\_{i}\equiv d\tau/dm\_{i}$. This allows us to compute the smaller radius, $\rho^{2}=r^{2}-D^{2}$, and, using the formula for the volume of a hypersphere, we arrive at the final answer,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{P}(\tau)\propto\frac{\pi^{\frac{N-1}{2}}}{\Gamma(\frac{N}{2}-1)}\rho^{N-1}\propto\left[1-\frac{(\tau-\tau\_{\rm fid})^{2}}{r^{2}|\mathbf{g}|^{2}}\right]^{\frac{N-1}{2}}.$ |  | (14) |

Note that, as written, neither of these forms are a properly normalized probability distribution (however, this is not a requirement for our purposes, and the proper normalization is straightforward to compute if desired).

We now need to include the fact that the hyperbox prior excludes some of the hypersphere prior, as represented in two dimensions in the right panel of Fig. [1](#S2.F1 "Figure 1 ‣ 2.2.1 Geometric View of Physicality Priors ‣ 2.2 The PCA model ‣ 2 Reionization models ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"). In general, this breaks the symmetries which made Eq. ([14](#S3.E14 "In 3.1 Calculating the prior ‣ 3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) so simple. We find, however, that because $d\tau/dm\_{1}$ is much larger than any of the other derivatives, it is predominantly only the exclusion in the $m\_{1}$ direction which needs to be accounted for. This leaves enough symmetry that the resulting solution is simple enough to be useful.

The above calculation needs to be amended in the following way. Define $\mathbb{S}^{\prime}$ to be intersection of the hypersphere with the region defined by $m^{-}\_{1}\,{<}\,m\_{1}\,{<}\,m^{+}\_{1}$; i.e., $\mathbb{S}^{\prime}$ is a hypersphere with two opposite hyper-spherical caps removed. As $\tau$ is increased or decreased from $\tau\_{\rm fid}$, changing where the hyperplane intersects with $\mathbb{S}^{\prime}$, the intersection region initially does not also intersect with the caps, leaving the solution unchanged from before. Once it does intersect with the caps, the intersection region is now no longer an $N-1$ dimensional hypersphere, but rather an $N-1$ dimensional hypersphere with a single hyper-spherical cap removed. Thus, the induced prior will be instead

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{P}(\tau)\propto\frac{\pi^{\frac{N-1}{2}}}{\Gamma(\frac{N}{2}-1)}\rho^{N-1}(1-V),$ |  | (15) |

where V is the volume of the removed hyper-spherical cap relative to the volume of the entire hypersphere. This fraction can be written in terms of the regularized incomplete beta function, $I\_{x}(a,b)$ ([Li 2011](#bib.bib31)), and is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle V=\begin{cases}0&h<0\\ \frac{1}{2}\,I\_{(2\rho h-h^{2})/\rho^{2}}\left(\frac{N}{2},\frac{1}{2}\right)&0<h<\rho\\ 1-\frac{1}{2}\,I\_{(2\rho h-h^{2})/\rho^{2}}\left(\frac{N}{2},\frac{1}{2}\right)&h>\rho,\end{cases}$ |  | (16) |

where $h$ is the height of the cap, $h=\rho-m^{(+)}\csc\theta+D\cot\theta$, and $\theta$ is the angle between the hyperplane and the $\hat{m}\_{1}$ direction, $\cos\theta=\mathbf{g}\_{1}/|\mathbf{g}|$.

The bottom panel of Fig. [3](#S3.F3 "Figure 3 ‣ 3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") shows this analytic result for several values of $N$, alongside the Monte Carlo calculation performed similarly as before. The “kink” near $\tau\,{\sim}\,0.1$ (visible particularly in the $N\,{=}\,2$ curve, although present in all of them) corresponds to when the correction, $V$, turns on; without this, we would not recover the correct shape in the tails of the distribution. With it, however, we find very good agreement between the Monte Carlo simulations and the analytic result, particularly deep in the low-$\tau$ tail which is most important since this is the region picked out by the data. This analytic result will be useful in the next section where we discuss flattening the prior. Note also that the prior volume for $\tau$ shrinks noticeably as compared to the MH08 physicality region; we will show in Sec. [4](#S4 "4 Hints of early reionization in Planck 2015 data? ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") that this smaller and more optimal prior volume is enough to affect constraints from Planck data.

Similarly as to the PCA model, both the HS17 knot model and our FlexKnot model give a non-flat $\tau$ prior if the prior on the knot amplitudes and/or positions is taken as flat. The prior for the HS17 model is shown in the top panel of Fig. [3](#S3.F3 "Figure 3 ‣ 3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"). The FlexKnot prior is not shown, but is qualitatively similar to the others.

### 3.2 Flattening the prior

Having ascertained that all of the generic reconstruction methods we have discussed implicitly place a non-flat prior on $\tau$, we now discuss how to modify these analyses so that any desired $\tau$ prior can be used, in particular a uniform one. This will be useful in performing more consistent comparisons between models by using the same prior on $\tau$ for all models.

Intuitively, if we have an MCMC chain for an analysis that was performed with some particular $\tau$ prior, we can importance sample the chain to give additional weight to samples with a low prior probability for $\tau$, in effect counter-balancing the original prior and forcing it to be flat. More explicitly, we can create a posterior where we have assumed a flat $\tau$ prior by computing

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{P}^{{\rm flat}\text{-}\tau}(\theta\,|\,d)=\frac{\mathcal{P}^{\rm orig}(\theta\,|\,d)}{\mathcal{P}^{\rm orig}(\tau(\theta))}\propto\mathcal{L}(d\,|\,\theta)\underbrace{\left[\frac{\mathcal{P}^{\rm orig}(\theta)}{\mathcal{P}^{\rm orig}(\tau(\theta))}\right]}\_{\mathcal{P}^{{\rm flat}\text{-}\tau}(\theta)},$ |  | (17) |

where the posterior $\mathcal{P}^{\rm orig}(\theta\,|\,d)$ given data $d$ is the original posterior that did not assume a flat $\tau$ prior, $\mathcal{P}^{\rm orig}(\theta)$ and $\mathcal{P}^{\rm orig}(\tau(\theta))$ are the original priors in terms of all parameters $\theta$ and the induced $\tau$ prior, respectively, and $\mathcal{L}(d\,|\,\theta)$ is the likelihood of the data given parameters. In the case of the PCA model with optimal physicality priors, $\mathcal{P}^{\rm orig}(\tau(\theta))$ is conveniently calculable analytically and given in Eq. ([15](#S3.E15 "In 3.1 Calculating the prior ‣ 3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")). For other models, it can be obtained via Monte Carlo simulations and a smooth function can be fit ([Lewis & Xu 2016](#bib.bib30), e.g., here we use kernel density estimates with tools from).

We should note that this procedure is not unique, and many $\mathcal{P}^{{\rm flat}\text{-}\tau}(\theta)$ exist corresponding to a flat prior on $\tau$. However, it can be rigorously shown that the choice we have made in Eq. ([17](#S3.E17 "In 3.2 Flattening the prior ‣ 3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) maximizes the possible entropy in $\mathcal{P}^{{\rm flat}\text{-}\tau}(\theta)$, subject to the condition that the resulting $\tau$ prior is flat ([Handley & Millea 2018](#bib.bib17), we also give a simplified but less general proof of this in Appendix [A](#A1 "Appendix A Maximum entropy prior flattening ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")). This is to say that Eq. ([17](#S3.E17 "In 3.2 Flattening the prior ‣ 3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) is very well motivated because it is the choice that takes the original prior and modifies it in such a way that the induced $\tau$ prior is flat while introducing the minimal amount of new information. We thus make use of this procedure in the following section.

## 4 Hints of early reionization in Planck 2015 data?

Figure 4: Constraints on the total optical depth (top panel), and on the optical depth between $z\,{=}\,15$ and $z\,{=}\,30$ (bottom panel), when using 2015 PlanckTT+lowTEB data. Various reionization models and priors are used (labeled in each plot), in addition to marginalization over other $\Lambda$CDM parameters. The top panel shows that the apparent preference for higher $\tau$ when using the PCA model as reported in [Heinrich et al. (2017)](#bib.bib22) was significantly impacted by the choice of prior. The bottom panel shows that evidence for early reionization was also partly impacted, although some preference remains. We consider the shaded green contour, which corresponds to a flat $\tau$ prior and optimal physicality region, as the most well-motivated constraint from this dataset.

In this section, we consider the impact of the priors discussed thus far on claims in [Heinrich et al. (2017)](#bib.bib22) and [Heinrich & Hu (2018)](#bib.bib21) for evidence of early reionization in the Planck 2015 data.

[Heinrich et al. (2017)](#bib.bib22) show that the value of $\tau$ inferred from the Planck 2015 data is almost $1\,\sigma$ higher under the PCA model than with the TANH model. We reproduce55
5
One small difference is that [Heinrich et al. (2017)](#bib.bib22) use the full TT, TE, and EE data, whereas here we use only the “robust” TT data. We have checked that this makes a very small difference to the conclusions in this section, as expected since the TT data is much more constraining. this result in the top panel of Fig. [4](#S4.F4 "Figure 4 ‣ 4 Hints of early reionization in Planck 2015 data? ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"), where the black and blue lines there correspond to the black and blue lines in Fig. 5 of [Heinrich et al. (2017)](#bib.bib22). When we use a flat prior on the modes and the MH08 physicality region as they have, we find very good consistency with their results. We expect that some of the shift to higher $\tau$ is due to the high $\tau$ prior implicit in the flat mode prior; to quantify the exact effect we flatten the $\tau$ prior using the procedure described in the previous section and show the result in orange. Indeed, the shift to higher $\tau$ is partly reduced. We also switch to the optimal physicality region, and show the final result in shaded green. This further reduces the inferred value of $\tau$, which now agrees much better with the TANH result. We explicitly find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\tau=0.080\pm 0.017\;\;{\scriptstyle(\rm TANH,\;flat\,\tau;\;P15)}$ |  | (18) |

and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\tau=0.085\pm 0.018\;\;{\scriptstyle(\rm PCA,\;flat\,\tau,\;optimal\,phys.;\;P15)}$ |  | (19) |

which is a shift of only $0.3\,\sigma$. We stress that the difference between this and the nearly $1\,\sigma$ shift found by [Heinrich et al. (2017)](#bib.bib22) is due purely to a different choice of priors over reionization histories inherent in the PCA procedure.

Although highlighting the shift in $\tau$, [Heinrich et al. (2017)](#bib.bib22) do not make the claim that one should regard the value of $\tau$ inferred from the PCA procedure as model independent; the results of the previous paragraph should make that point very clear. However, a strong claim is made, further argued in [Heinrich & Hu (2018)](#bib.bib21) and [Obied et al. (2018)](#bib.bib39), that the PCA procedure provides reionization-model-independent proof of early reionization because the value of $\tau(15,30)$ is greater than zero at $2\,\sigma$.

The derived parameter $\tau(15,30)$ is not fundamentally different from the derived parameter $\tau$, and thus its posterior distribution will qualitatively depend on our choice of priors in the same way. In the bottom panel of Fig. [4](#S4.F4 "Figure 4 ‣ 4 Hints of early reionization in Planck 2015 data? ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") we perform a similar set of tests for $\tau(15,30)$ as we just have for $\tau$. The blue line is the PCA result with flat mode prior and the MH08 physicality region. We find it is higher than zero by $2.1\sigma$, again in good agreement with the [Heinrich et al. (2017)](#bib.bib22) result. We switch to the optimal physicality region in purple and additionally to a flat prior on $\tau(15,30)$ in shaded green, yielding,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\tau(15,30)=0.027\pm 0.019$ |  | (20) |
|  |  |  |
| --- | --- | --- |
|  | $\displaystyle{\scriptstyle(\rm PCA,\;flat\,\tau(15,30),\;optimal\,phys.;\;P15)}$ |  |

This represents a decrease in the evidence for non-zero $\tau(15,30)$ from $2.1\,\sigma$ to $1.4\,\sigma$. Thus, similarly as before for $\tau$, we do not find robustness to choice of priors in this detection of early reionization. Evidently, part of the evidence for early reionization found by [Heinrich et al. (2017)](#bib.bib22) is actually due to the choice of prior rather than being driven by the data.

[Heinrich & Hu (2018)](#bib.bib21) make the contrary argument, claiming that the PCA evidence for early reionization is robust to the choice of prior. Here, we point out some problems with the arguments therein. First, they show that increasing the $z\_{\rm max}$ of the reconstruction does not reduce preference for early reionization, arguing that this shows priors are uninformative. In fact, their results actually highlight the opposite. In particular, increasing the $z\_{\rm max}$ of the reconstruction increases the mean value of the prior on $\tau(z,z\_{\rm max})$ for all $z$. As a result, one would expect the mean value of the posterior of this quantity to increase with higher $z\_{\rm max}$, which is exactly what is seen in all cases in Table I of [Heinrich & Hu (2018)](#bib.bib21). Furthermore, they perform a likelihood ratio test (which is, by definition, independent of priors), finding that the $\chi^{2}$ is decreased by 5–6 with a 5-parameter PCA model as compared to the 1-parameter TANH model. Without a quantitative argument as to the effective degrees of freedom of the PCA model that are constrained by the data (which is not made), it is impossible to judge the significance of the decrease in $\chi^{2}$. Conversely, we consider the very direct tests performed here of computing and flattening the prior to be more conclusive as to the impact of these priors on Planck 2015 data.

Of course, some small hints of non-zero $\tau(15,30)$ remain even in the case of the constraints shown in Eq. ([20](#S4.E20 "In 4 Hints of early reionization in Planck 2015 data? ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")). However, we will show in the next section that these hints are consistent with arising from a noise fluctuation, since they disappear almost entirely with the addition of the newest Planck large-scale polarization data.

## 5 Reionization from Planck intermediate data

Figure 5: Constraints on the total optical depth when using the Planck intermediate simlow likelihood alone. Various reionization models and priors are used (labeled in each plot), with other $\Lambda$CDM parameters fixed to their best-fit values from PlanckTT data. In the bottom panel, the height of each FlexKnot model is proportional to its Bayesian evidence, with an overall scaling so that their sum (the black curve) gives a properly normalized probability distribution. This curve corresponds to marginalization over the number of FlexKnot to use.

The Planck polarization likelihood used in the previous section and by [Heinrich et al. (2017)](#bib.bib22) and [Heinrich & Hu (2018)](#bib.bib21) is the most recent public Planck likelihood available and is based on polarization maps from Planck-LFI data ([Planck Collaboration
II 2016](#bib.bib43)). Reionization constraints from lower-noise HFI data were presented in an intermediate release ([Planck Collaboration Int.
XLVI 2016](#bib.bib45)). Additionally, [Planck Collaboration Int.
XLVII (2016)](#bib.bib46) also explored various parametric reionization models extending beyond just the TANH case. In general, good consistency with a near-instantaneous transition was found, and the optical depth constraints tightened and shifted to lower central values of $\tau\,{\approx}\,0.055$–$0.060$, with $\sigma(\tau)\,{\sim}\,0.01$. Although no evidence for early reionization was found, no completely generic reconstruction was performed, and the parametric models considered did not fully accommodate an early component should one have been present ([Heinrich et al. 2017](#bib.bib22)). We thus give here results from a fully generic reconstruction of the reionization history using the simlow likelihood.

So as to most clearly judge the impact of the large-scale polarization data, we compute constaints using only simlow. To do so, we fix non-reionization cosmological parameters to their best-fit values from the high-$\ell$ TT data, in particular holding the quantity $10^{9}A\_{\rm s}e^{-2\tau}$ fixed (which better approximates the impact of the TT data as compared to holding just $A\_{\rm s}$ fixed). The black dashed contour in the top panel of Fig. [5](#S5.F5 "Figure 5 ‣ 5 Reionization from Planck intermediate data ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") shows constraints on $\tau$ from simlow assuming the TANH model, as also presented in [Planck Collaboration Int.
XLVI (2016)](#bib.bib45) and [Planck Collaboration Int.
XLVII (2016)](#bib.bib46). Note that a significant part of the posterior density is cut off by Gunn-Peterson bound requiring full reionization by $z\,{=}\,6$, which for the TANH model translates to $\tau\,{>}\,0.0430$. Due to the finite width of reionization assumed in the TANH case ($\Delta z\,{=}\,0.5$), this is slightly higher than the absolute minimum possible for instantaneous reionization at $z\,{=}\,6$, which is $\tau\,{>}\,0.0385$. The remaining lines show results using the PCA model and various choices of prior. As before, when flattening the $\tau$ prior we see a downward shift in $\tau$. Switching to the optimal physicality priors now mostly has the effect of removing some weight at $\tau\,{<}\,0.0385$, which before was unphysically allowed by the MH08 region. Switching to the optimal physicality region remedies some of this effect and gives

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\tau=0.057\pm 0.009\;\;{\scriptstyle(\rm PCA,\;flat\,\tau,\;optimal\,phys.;\;\mathtt{simlow})}$ |  | (21) |

This is in good agreement with the TANH result, as well as those from the parametric models of [Planck Collaboration Int.
XLVII (2016)](#bib.bib46).

In the bottom panel of Fig. [5](#S5.F5 "Figure 5 ‣ 5 Reionization from Planck intermediate data ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"), we show constraints from the FlexKnot model. In all cases except for the dot-dashed line, we use a flat prior on $\tau$. The posteriors on $\tau$ with varying numbers of knots are shown as the shaded contours. Each posterior has been normalized to unity then multiplied by $\mathcal{Z}^{0}/\mathcal{Z}\_{i}$, where $\mathcal{Z}\_{i}$ is the evidence for that number of knots and $1/\mathcal{Z}^{0}=\sum\_{i}1/\mathcal{Z}\_{i}$.
This means that the height of each curve is proportional to the evidence of that model, and makes it easy to see that the 1-knot model has most evidence, and the evidence decreases for all subsequent models. Summing up these curves produces the posterior on $\tau$ marginalized over the number of knots, which is shown in black, and is properly normalized to unity by the choice of $\mathcal{Z}^{0}$. In this case we find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\tau=0.058\pm 0.009\;\;{\scriptstyle(\rm FlexKnot,\;flat\,\tau;\;\mathtt{simlow})}$ |  | (22) |

This as well is in very good agreement with the results above, demonstrating the lack of evidence in the simlow data for anything other than a single late and near-instantaneous transition to a fully ionized universe.

Even more directly, we show in Fig. [6](#S5.F6 "Figure 6 ‣ 5 Reionization from Planck intermediate data ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") the posterior constraints on the history itself using the FlexKnot model, marginalized over the number of knots. Here we see the tight restriction on any amount of non-zero ionization fraction at high redshifts, independent of exactly which $\tau$ prior we use. Indeed, the posterior on the $z\,{>}\,15$ contribution to the optical depth is bounded to be

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\tau(15,30)<0.015\;(95\%)$ |  | (23) |
|  |  |  |
| --- | --- | --- |
|  | $\displaystyle{\scriptstyle(\rm FlexKnot,\;flat\,\tau(15,30);\;\mathtt{simlow})}$ |  |

Although we consider the FlexKnot result more robust than the PCA one, we also compute the PCA bound on this quantity to stress that the disappearance of the hints of early reionization in the intermediate Planck data is more related to the data rather than the model used. Even in the PCA case, we find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\tau(15,30)<0.028\;(95\%)$ |  | (24) |
|  |  |  |
| --- | --- | --- |
|  | $\displaystyle{\scriptstyle(\rm PCA,\;flat\,\tau(15,30),\;optimal\,phys.;\;\mathtt{simlow})}$ |  |

which is weaker but still largely rules out the central value of even the prior-adjusted results given by Planck 2015 data (Eq. [20](#S4.E20 "In 4 Hints of early reionization in Planck 2015 data? ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")).

Of course, the FlexKnot model is not immune to choice of $\tau$ prior. For comparison, we show as the dot-dashed line in Fig. [5](#S5.F5 "Figure 5 ‣ 5 Reionization from Planck intermediate data ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") the FlexKnot result, marginalized over knots, but with a flat prior on the knot positions and amplitudes instead of a flat prior on $\tau$. We find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\tau=0.062\pm 0.009\;\;{\scriptstyle(\rm FlexKnot,\;flat\,knot;\;\mathtt{simlow})}$ |  | (25) |

which is $0.4\,\sigma$ higher than the result with a flat $\tau$ prior (Eq. [22](#S5.E22 "In 5 Reionization from Planck intermediate data ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")). We regard this difference as quantifying an unavoidable systematic uncertainty in $\tau$ due to imperfect knowledge of the model parameter priors which is inherent in fully generic reconstructions of the reionization history. In the next section, we consider the impact of this uncertainty on other cosmological parameters that are correlated with $\tau$, both from current and future data.

Figure 6: Constraints on the ionization fraction as a function of redshift from simlow-only data, using either a flat prior on the knot positions or a flat prior on $\tau$. The blue and black contours represent the middle 68% and 95% quantile of the posterior at each redshift.

## 6 Impact on Future Data

We now turn to forecasting the impact of reionization uncertainty on future data. There are two question we would like to answer. The first is whether the increased errors bars on $\tau$ when performing a generic reconstruction cause any significant degradation in constraints on other parameters of interest. In the case of Fig. [5](#S5.F5 "Figure 5 ‣ 5 Reionization from Planck intermediate data ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories") we see around a 25% larger error bar in the FlexKnot case as compared to the TANH case66
6
We compute the TANH error bar here by taking the standard deviation the TANH posterior. Despite that this is clearly non-Gaussian as it is cut off by the Gunn-Peterson prior, it gives us a rough estimate to use in combination with Fisher forecasts.. We will check the impact of this degradation, as well as forecasting whether this can be improved upon with better data. Secondly, we will take the shift in the $\tau$ posterior between a flat knot prior and a flat $\tau$ prior and propagate it into shifts on other parameters of interest given future data, to check the extent to which these future constraints are prior-dependent. In our discussion, we focus on the sum of neutrino masses, $\Sigma m\_{\nu}$, as it is the cosmological parameter expected to be most impacted by the details of reionization ([Allison et al. 2015](#bib.bib3)).

The first dataset we consider is a combination of CMB-S4 with existing Planck data (including the intermediate simlow likelihood). We perform a Fisher forecast using the standard procedure ([Dodelson 2003](#bib.bib10)), using a fiducial Planck 2015-like cosmology, with $\tau\,{=}\,0.055$ and $\Sigma m\_{\nu}$ at the minimum value of $60\,\rm meV$. For CMB-S4, we assume a temperature noise level $\Delta\_{T}=\Delta\_{P}/\sqrt{2}=1\,\rm\mu K$-arcmin, a fraction of covered $f\_{\rm sky}=0.5$, and a beam size of $\theta\_{\rm FWHM}=3\,\rm arcmin$. For the noise levels of the reconstructed lensing deflection power spectrum, we use the noise power spectrum calculated by [Pan & Knox (2015)](#bib.bib41)77
7
Provided by the authors upon request. based on an iterative quadratic EB estimator ([Okamoto & Hu 2003](#bib.bib40); [Smith et al. 2012](#bib.bib49)). We assume the largest scales measurable by CMB-S4 are $\ell\_{\rm min}\,{=}\,50$. This is combined with the constraints on $\tau$ from simlow discussed in the previous section, which are treated as independent. In combining with the remaining Planck 2015 data, to take into account correlations between Planck and CMB-S4 due to sky coverage and multipole overlap, we compute a Planck-like Fisher forecast rather than use the real Planck constraints. The temperature and polarization noise levels assumed for Planck are those given by [Planck Collaboration (2005)](#bib.bib42), taking an optimal noise weighting of the 100, 143, and 217 GHz, channels, and a sky coverage of $f\_{\rm sky}\,{=}\,0.75$. These reproduce the uncertainties on parameters from the real Planck data to within around 15%, which should be good enough for our purposes.

For this first dataset, we forecast a $1\,\sigma$ error bar on $\Sigma m\_{\nu}$ of 59.9 meV assuming the TANH model, or 66.0 meV with the 25% looser $\tau$ prior coming from the FlexKnot model. This fairly modest degradation is depicted by the error bars labeled P16+S4 in Fig. [7](#S6.F7 "Figure 7 ‣ 6 Impact on Future Data ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"). What about the impact from the $0.4\,\sigma$ shift in $\tau$ depending on the prior assumed? The Fisher methodology allows us to propagate this into a shift in $\Sigma m\_{\nu}$ via

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\frac{\Delta m\_{\nu}}{\sigma\_{m\_{\nu}}}=\rho\frac{\Delta\tau}{\sigma\_{\tau}},$ |  | (26) |

where $\rho$ is the correlation coefficient between $\tau$ and $\Sigma m\_{\nu}$. For the P16+S4, we find $\rho\,{=}\,0.8$, thus the shift in $\Sigma m\_{\nu}$ is $0.3\,\sigma$. This is depicted by the black arrow in Fig. [7](#S6.F7 "Figure 7 ‣ 6 Impact on Future Data ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"). It is arbitrarily chosen to point to lower $\Sigma m\_{\nu}$, which is the direction of shift we would expect when going from a flat knot prior to a flat $\tau$ prior.

The existence of this shift is a main conclusion from this work, and has not been considered before. To the extent that both flat knot and flat $\tau$ priors are reasonable, this can be considered as an extra source of “model uncertainty” in the future CMB determination of neutrino mass. The magnitude of the effect is not disastrous, but not negligible either. We comment now on a few avenues to reduce its impact.

The first comes from adding in other expected future constrains from measurements of the baryon acoustic oscillations (BAO) feature in the galaxy correlation function by DESI ([Levi et al. 2013](#bib.bib27)). We use the Fisher matrix for DESI calculated by [Pan & Knox (2015)](#bib.bib41), based on the sensitivities presented in [Font-Ribera et al. (2014)](#bib.bib14). The addition of this dataset brings us significantly closer to a guaranteed detection of the neutrino mass. Here we find a $1\,\sigma$ error bar on $\Sigma m\_{\nu}$ of 26.3 meV or 28.8 meV, again depending on the reionization model used88
8
These predictions are slightly less optimistic than the ones presented in the main body of [Pan & Knox (2015)](#bib.bib41), mostly because we use $\ell\_{\rm min}\,{=}\,50$ for CMB-S4 as opposed to $\ell\_{\rm min}\,{=}\,2$ used there. They are in better agreement with [Allison et al. (2015)](#bib.bib3) which take a similar $\ell\_{\rm min}$, but still very slightly wider, due mostly to a lower fiducial value of $\tau$.. Although the error bars shrink, the addition of DESI actually increases the correlation between $\tau$ and $\Sigma m\_{\nu}$ slightly to $\rho\,{=}\,0.9$. This arises because DESI is completely insensitive to the $\tau$-$A\_{\rm s}$ degeneracy responsible for the correlation, but reduces other physical degeneracies impacting the $\Sigma m\_{\nu}$ determination, thus leaving the former degeneracy more prominent. In this case, we find a $0.35\,\sigma$ shift in $\Sigma m\_{\nu}$ depending on the $\tau$ prior used. While this is a larger relative shift, on an absolute scale it is about half the shift as compared to without DESI.

To reduce $\rho$ and thus the impact of reionization uncertainty, we need data which directly constrains $\tau$ and/or $A\_{\rm s}$. This could be provided, for example, by more precise large-scale polarization data. There is room for some improvement as the Planck data is not yet at the cosmic variance limit. We thus consider the limiting case of a full-sky cosmic-variance limited EE measurement across multipoles 2 to 30 (which we will label cvlowEE). This should be the upper bound of what could be achieved with next-generation satellite missions, e.g., LiteBIRD, PIXIE, COrE, or PICO ([Matsumura et al. 2016](#bib.bib33); [Kogut et al. 2011](#bib.bib26); [The COrE Collaboration et al. 2011](#bib.bib50)). To obtain the most accurate forecasts, we run MCMC chains using the exact full-sky $C\_{\ell}$ likelihood ([Hamimeche & Lewis 2008](#bib.bib16), e.g.). This is more accurate than Fisher forecasts, which do not easily deal with the sharp edges of the physicality priors. Using the TANH model, we forecast an error bar of

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\sigma\_{\tau}=0.0020\;\;{\scriptstyle(\rm TANH,\;flat\,\tau;\;\mathtt{cvlowEE})}$ |  | (27) |

and with the FlexKnot model marginalized over the number of knots, we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\sigma\_{\tau}=0.0024\;\;{\scriptstyle(\rm FlexKnot,\;flat\,\tau;\;\mathtt{cvlowEE})}$ |  | (28) |

This leads to a 15% degradation of the error bar in $\Sigma m\_{\nu}$, somewhat better than the 25% degradation we found previously with simlow. Additionally, $\rho$ is reduced to 0.5, meaning the shift in $\Sigma m\_{\nu}$ due to the choice of $\tau$ prior is now only $0.2\,\sigma$. Evidently, these improved large-scale polarization measurements would be quite valuable, not just for reducing the absolute uncertainty on $\tau$, but also for reducing our dependence on its prior.

When we combine all datasets discussed thus far, including both cvlowEE and DESI-BAO, we find an expected constraint of $\sim 15\,\rm meV$, with the $\tau$ prior able to shift things only by $\sim 3\,\rm meV$. This would be enough for a $\sim 4\,\sigma$ guaranteed detection of non-zero neutrino masses even if the true value is at the minimum.

Figure 7: Fisher forecasted $1\,\sigma$ error bars on the sum of neutrino masses, $\Sigma m\_{\nu}$, assuming a fiducial value at the minimum allowed sum of $60\,\rm meV$. Different datasets are labeled on the left, with P16 corresponding to Planck 2015 data combined with the intermediate simlow likelihood, S4 corresponding to CMB-S4, BAO to DESI-BAO, and cvlowEE to a cosmic-variance-limited full-sky EE measurement up to $\ell\,{=}\,30$. Orange error bars use the TANH reionization model, and blue errors bars are slightly degraded due to having marginalized over all possible reionization histories via the FlexKnot model. The black arrows show the expected shift when considering a flat knot prior vs. a flat $\tau$ prior.

## 7 Discussion and Conclusions

In this work we have examined the impact of priors on generic reconstruction of the reionization history. We have pointed out some problems with PCA procedure, mainly that 1 the priors that are usually taken over the mode amplitudes correspond implicitly to a somewhat informative prior on $\tau$ and 2) a sub-optimal set of physicality priors has been used to-date. Ultimately, the dependence of the final posterior on the details of these physicality priors argues that the PCA procedure is not well suited to this problem. This is not to say there are issues with PCA analyses in general, simply that in situations where hard priors exist and are informative (such as here), the PCA method is a sub-optimal tool. Indeed, we have shown the significant extent to which some of these priors have impacted the analysis of [Heinrich et al. (2017)](#bib.bib22) and [Heinrich & Hu (2018)](#bib.bib21), artificially increasing the significance of some hints of a high-redshift reionization component.

Even so, the PCA analysis can still be quite useful in providing a simple and convenient approximate likelihood as described in [Heinrich et al. (2017)](#bib.bib22). One can then easily project different physical models onto the principal components to obtain constraints on the physical model parameters, effectively applying the priors of the physical model and alleviating some of the problems that arise when attempting to interpret the PCA results on their own.

We have also described the FlexKnot model, which we argue is better to use in a completely generic reionization reconstruction setting since physicality can be enforced exactly and the question of how many knots to use can be self-consistently dealt with via a Bayesian evidence computation.

Using these models, we have presented the first generic reconstruction results from the Planck 2016 intermediate simlow likelihood. We find no evidence for early reionization, instead only very tight upper limits on any contribution at $z\,{\gtrsim}\,15$. This is true even when using the as-argued sub-optimal PCA model, thus the qualitative conclusion of preference only for a late and fast reionization is quite robust to modeling choices. These results negate the need for explanations of an early reionization contribution, for example from metal-free stars ([Miranda et al. 2017](#bib.bib36)).

Recently, the EDGES collaboration has detected an absorption feature in the sky-averaged spectrum, presumably due to 21cm absorption by neutral hydrogen during the epoch of reionization ([Bowman et al. 2018](#bib.bib8)). In the standard picture, the upper and lower frequencies of the feature indicate that photons from early stars were numerous enough to equilibrate the gas temperature and 21cm spin temperature near $z\,{=}\,20$, and then raise the spin temperature above the CMB temperature near $z\,{=}\,15$. Due to the amplitude and shape of the detected feature, however, some non-standard explanation is required. The results discussed here can limit such possible explanations, as no modifications to the standard picture must be made which would lead to reionizing the universe to a level large enough to violate the bound on the optical depth at $z\,{>}\,15$ given in Eq. ([23](#S5.E23 "In 5 Reionization from Planck intermediate data ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")). For example, [Ewall-Wice et al. (2018)](#bib.bib11) discuss an explanation of the EDGES signal in which a radio background from accretion onto the black hole remnants of metal-free stars causes the absorption feature to appear deeper against the continuum than in the standard scenario. It is shown that X-rays also produced by the accretion would result in some significant reionization at $z\,{>}\,15$, already in some tension with even the high $\tau(15,30)$ obtained by [Heinrich & Hu (2018)](#bib.bib21); given the tighter upper bounds we find here, this explanation is now heavy disfavored in its simplest form.

Regardless of the generic reconstruction models we consider, we find there is some sensitivity to whether a flat prior on $\tau$ is taken, or one which is flat on PCA mode amplitudes or knot positions and/or amplitudes. Other priors for this problem exist as well, for example Jeffreys priors or reference priors ([Jeffreys 1946](#bib.bib24); [Bernardo 1979](#bib.bib5)), and these would be well worth exploring too. Nevertheless, it is unclear that a very strong argument could be made for which particular prior is the correct one. Thus here we instead take the shifts in $\tau$ we find when switching between the priors we have considered as an unavoidable modeling uncertainty arising from the generic reconstruction.

We showed that this uncertainty can have significant impact on determination of the sum of neutrino masses from future experiments. For example, different priors can cause a shift of $0.35\,\sigma$ on $\Sigma m\_{\nu}$ from future Planck + CMB-S4 + DESI-BAO measurements. One avenue for improvement would be to obtain something approaching a cosmic-variance-limited measurement of large-scale CMB polarization. Some other avenues exist as well.

For example, several direct constraints exist on the ionization state of the universe at various redshifts ([Bouwens et al. 2015](#bib.bib7), summarized, e.g., by). Here we have applied only one of them, mainly the stringent bound on the end of reionization from observations of the Gunn-Peterson optical depth in high-redshift quasars. We have done so in a fairly unsophisticated way by simply requiring that $x\_{\rm e}(6)\,{=}\,x\_{\rm e}^{\rm max}$. A more detailed study of the impact that these direct constraints have is warranted.

Another approach is to use physically motivated models of reionization, rather than the generic unphysical reconstruction methods presented here. These could potentially shrink the prior parameter space further to where priors become unimportant. The challenge here is finding models which have parameters that can be marginalized over to accurately represent uncertainty as to the physics of reionization and the types of sources which can contribute ionization radiation. In addition, with physical models, we may better be able to fold in constraints from other sources, such as measurements of the patchy kinetic Sunyaev-Zeldovich effect which can further constrain reionization ([Gruzinov & Hu 1998](#bib.bib15); [Knox et al. 1998](#bib.bib25); [Zahn et al. 2012](#bib.bib53); [Planck Collaboration Int.
XLVII 2016](#bib.bib46)). We have not applied these bounds here as it is not straightforward how to do so for the generic reionization histories we consider, but in principle these could reduce our dependence on priors. Additionally, using novel analysis methods ([Smith & Ferraro 2016](#bib.bib48); [Ferraro & Smith 2018](#bib.bib13)), experiments like CMB-S4 could potentially measure this effect to high significance. Further down the road, methods described in [Liu et al. (2016)](#bib.bib32) or [Meyers et al. (2017)](#bib.bib34) could also push beyond the CMB cosmic variance limit we have calculated and remove the uncertainty on other cosmological parameters due to $\tau$ entirely. Future prospects are thus optimistic, although work remains to be done.

###### Acknowledgements.

We thank Zhen Pan for his forecasting code which we adapted to use in this work, Torsten Ensslin, Douglas Scott, and Martin White for their helpful comments on the draft of this paper, and Silvia Galli, William Handley, and Wayne Hu for useful discussions. MM was supported by the Labex ILP (reference ANR-10-LABX-63). This work was aided by the use of several software packages, including CAMB ([Lewis et al. 2000](#bib.bib28)), CosmoSlik ([Millea 2017](#bib.bib35)), getdist ([Lewis & Xu 2016](#bib.bib30)), Julia ([Bezanson et al. 2017](#bib.bib6)), and PolyChord ([Handley et al. 2015a](#bib.bib18); [Handley et al. 2015b](#bib.bib19)).

## Appendix A Maximum entropy prior flattening

Here we will show how to construct the maximum entropy prior used in Sect. [3.2](#S3.SS2 "3.2 Flattening the prior ‣ 3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"). This is the maximally uninformative prior on the input parameters of our model, $(\theta\_{1},\theta\_{2},...)$, for which the induced prior on $\tau=\tau(\theta\_{1},\theta\_{2},...)$ is flat. Here, the $\theta\_{i}$ can represent the PCA model amplitudes, the knot positions and/or amplitudes, or any other parameters.

We first begin with a simplified example: what is the maximum entropy prior on two parameters, $a$ and $b$, each with support on $0<a,b<1$, for which the prior on the sum, $a+b$, is flat between $0<a+b<2$? In this analogy, $a$ and $b$ are the $\theta\_{i}$ parameters, $a+b$ is like $\tau$, and the support on [0,1] is the physicality region.

The entropy of the probability distribution $p(a,b)$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle H[p(a,b)]=-\int\_{0}^{1}da\int\_{0}^{1}db\,p(a,b)\ln p(a,b).$ |  | (29) |

We can express the problem of finding the $p(a,b)$ which maximizes $H$, subject to some constraints, as a Lagrange multiplier problem. Our constraint is that the transformed probability distribution for the sum, $p(a+b)$, is flat. We will write this constraint in what may seem as an odd form, but which is conducive to solving the Lagrange multiplier problem. We will require that the moments of $p(a,b)$ with respect to $a+b$ are those of a flat distribution between 0 and 2. This is to say, that $\langle a+b\rangle\,{=}\,1$, $\langle(a+b)^{2}\rangle\,{=}\,8/3$, etc… By specifying an infinite number of moments, we guarantee our target distribution $p(a+b)$ is exactly flat. Our constraints are thus that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\int\_{0}^{1}da\int\_{0}^{1}db\,(a+b)^{n}p(a,b)=c\_{n},$ |  | (30) |

with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle c\_{n}=\frac{1}{2}\int\_{0}^{2}dx\,x^{n}$ |  | (31) |

for all $n\,{=}0...\infty$. Note that for $n\,{=}\,0$ we simply have that the integral over $p(a,b)$ is unity, which guarantees that it is a probability distribution. Higher moments fix $p(a+b)$ to be flat as desired. As a Lagrange multiplier problem, we are maximizing the functional,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle F[p(a,b)]=$ | $\displaystyle\int\_{0}^{1}da\int\_{0}^{1}db\;\Biggl\{-p(a,b)\ln p(a,b)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle+\sum\_{i=0}^{\infty}\lambda\_{i}\left[(a+b)^{n}p(a,b)-c\_{n}\right]\Biggr\},$ |  | (32) |

where the $\lambda\_{i}$ are the Lagrange multipliers.
Setting the variation of $F$ with respect to $p(a,b)$ to zero gives us that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle p(a,b)=\exp\left[-1+\sum\_{i=0}^{\infty}\lambda\_{i}(a+b)^{n}\right].$ |  | (33) |

Substituting this into each of the Eq. ([30](#A1.E30 "In Appendix A Maximum entropy prior flattening ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) could then be used to solve for all of the $\lambda\_{i}$, giving us the unique maximum entropy solution for $p(a,b)$. Rather than preforming this process explicitly, we will postulate the answer and show that it is the solution. Consider the probability distribution

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle p(a,b)=1/q(a+b),$ |  | (34) |

where $q(a+b)$ is the transformed probability distribution for $a+b$ given the initial flat priors on $a$ and $b$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle q(a+b)=\int\_{0}^{1}da^{\prime}\int\_{0}^{1}db^{\prime}\delta((a+b)-(a^{\prime}+b^{\prime})).$ |  | (35) |

It is straightforward to substitute this into Eq. ([34](#A1.E34 "In Appendix A Maximum entropy prior flattening ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) and then show that $p(a+b)$ is indeed flat between 0 and 2. This means it satisfies the infinite number of constraint equations. It remains to check that the variation of $F$ around this function is zero, which is tantamount to showing that it can be written in the form of Eq. ([33](#A1.E33 "In Appendix A Maximum entropy prior flattening ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")). Since Eq. ([33](#A1.E33 "In Appendix A Maximum entropy prior flattening ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) says that the log of our function is a Maclaurin series in $a+b$ and since our $p(a,b)$ is an elementary function of only $a+b$, this is also true. Therefore, we have shown Eq. ([33](#A1.E33 "In Appendix A Maximum entropy prior flattening ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories")) is the unique maximum entropy probability distribution of $a,b$ for which the transformed distribution of $a+b$ is flat.

The above proof trivially generalizes to $N$ variables and to any initial support by simply adding in more integrals and changing the limits to something other than 0 and 1. Similarly, one can easily replace $a+b$ with any desired function for a derived parameter. This proof thus applies to the case of flattening the $\tau$ prior discussed in Sec. [3.2](#S3.SS2 "3.2 Flattening the prior ‣ 3 Implicit prior on 𝜏 ‣ Cosmic Microwave Background Constraints in Light of Priors Over Reionization Histories"). For a more rigorous and general proof, see [Handley & Millea (2018)](#bib.bib17).
