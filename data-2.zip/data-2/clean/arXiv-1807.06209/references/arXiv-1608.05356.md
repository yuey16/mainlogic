<!-- fulltext source=arxiv_html slug=arXiv-1608.05356 fetched=2026-09-18T01:15:09+00:00 -->

# Calibrating the Planck cluster mass scale with CLASH

M. Penna-Lima
Affiliation: Centro Brasileiro de Pesquisas Físicas, Rua Dr. Xavier Sigaud 150, Rio de Janeiro, 22290-180, RJ, Brazil
  
J. G. Bartlett
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, Pasadena, California, USA
  
E. Rozo
Affiliation: Department of Physics, University of Arizona, Tucson, AZ
85721, USA
  
J.-B. Melin
Affiliation: DRF/Irfu/SPP, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
J. Merten
Affiliation: Department of Physics, University of Oxford, Keble Road, Oxford OX1 3RH, UK
  
A. E. Evrard
Affiliation: Deparment of Physics and Michigan Center for Theoretical Physics, University of Michigan, Ann Arbor, MI 48109 USA
Affiliation: Department of Astronomy, University of Michigan, Ann, Arbor, MI 48109 USA
  
M. Postman
Affiliation: Space Telescope Science Institute, 3700 San Martin Drive, Baltimore, MD 21208, USA
  
E. Rykoff
Affiliation: Kavli Institute for Particle Astrophysics & Cosmology, P.O. Box 2450, Stanford University, Stanford, CA 94305, USA
Affiliation: SLAC National Accelerator Laboratory, Menlo Park, CA 94025, USA

Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/Irfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Email: [pennal@apc.in2p3.fr](mailto:pennal@apc.in2p3.fr)

Received 28 October 2016 / Accepted 12 June 2017

###### Abstract

We determine the mass scale of Planck galaxy clusters using gravitational lensing mass measurements from the Cluster Lensing And Supernova survey with Hubble (CLASH). We have compared the lensing masses to the Planck Sunyaev-Zeldovich (SZ) mass proxy for 21 clusters in common, employing a Bayesian analysis to simultaneously fit an idealized CLASH selection function and the distribution between the measured observables and true cluster mass. We used a tiered analysis strategy to explicitly demonstrate the importance of priors on weak lensing mass accuracy. In the case of an assumed constant bias, $b\_{\rm SZ}$, between true cluster mass, $M\_{500}$, and the Planck mass proxy, $M\_{\rm PL}$, our analysis constrains $1-b\_{\rm SZ}=0.73\pm 0.10$ when moderate priors on weak lensing accuracy are used, including a zero-mean Gaussian with standard deviation of 8% to account for possible bias in lensing mass estimations. Our analysis explicitly accounts for possible selection bias effects in this calibration sourced by the CLASH selection function. Our constraint on the cluster mass scale is consistent with recent results from the Weighing the Giants program and the Canadian Cluster Comparison Project. It is also consistent, at 1.34$\sigma$, with the value needed to reconcile the Planck SZ cluster counts with Planck’s base $\Lambda$CDM model fit to the primary cosmic microwave background anisotropies.

###### Key Words.

Galaxies: clusters: general; Cosmology: observations ; cosmological parameters; dark matter

## 1 Introduction

Galaxy cluster mass measurements are the dominant source of systematic uncertainty in cosmological constraints derived from the space-time abundance of galaxy clusters. This was acutely illustrated by the Planck collaboration’s finding of tension between the $\Lambda$CDM cosmology parameters favored by cluster counts and those derived by combining the primary cosmic microwave background (CMB) anisotropies with non-cluster data ([Planck Collaboration et al. 2014b](#bib.bib46); [Planck Collaboration et al. 2016b](#bib.bib49), PXX). While the discrepant findings could reflect a relatively large neutrino mass or more exotic physics, the confidence in such statements is limited by systematic uncertainties in mass measurements ([Rozo et al. 2013](#bib.bib57)).

The fundamental issue is that cluster halo mass is not directly observable. While N-body simulations have calibrated the space density of massive halos to good precision (e.g., [Bhattacharya et al. 2011](#bib.bib7); [Murray et al. 2013](#bib.bib36), and references therein), application to cluster counts on the sky requires the use of scaling relations between halo mass and observable cluster properties, often termed mass proxies. In the case of Planck clusters detected through the Sunyaev-Zeldovich (SZ) effect, the required relation is between SZ signal strength and mass.

In principle, scaling relations can be calibrated with hydrodynamic simulations that properly account for most relevant physical processes. The approach is currently limited, however, by uncertainties in the baryon physics associated with galaxy feedback mechanisms ([Ragone-Figueroa et al. 2013](#bib.bib51); [Dubois et al. 2013](#bib.bib11); [Le Brun et al. 2014](#bib.bib20); [Martizzi et al. 2014](#bib.bib27); [Genel et al. 2014](#bib.bib14)). Nevertheless, the fidelity of the simulations is high enough to provide insights into the general form of the scaling relations and into important sources of systematic error.

In practice, empirical approaches are used to establish scaling relations. The Planck analysis employed X-ray observations from XMM-Newton to derive masses based on the assumption of hydrostatic equilibrium (HSE) of the intra-cluster medium (ICM) ([Arnaud et al. 2010](#bib.bib2)). For decades, hydrodynamic simulations have indicated that HSE is not exact, with expectations that HSE masses underestimate true values by typically tens of percent, depending on scale and the exact modeling of baryon physics ([Evrard 1990](#bib.bib12); [Rasia et al. 2006](#bib.bib52); [Nagai et al. 2007](#bib.bib37); [Piffaretti & Valdarnini 2008](#bib.bib43); [Rasia et al. 2012](#bib.bib53); [Battaglia et al. 2013](#bib.bib3); [Nelson et al. 2014](#bib.bib38), e.g.,). Combining XMM-Newton and Chandra data, [Mahdavi et al. (2013)](#bib.bib24) found a 15% systematic difference in HSE masses. Moreover, the X-ray instrument calibration errors can also affect masses at the ten-percent level ([Donahue et al. 2014](#bib.bib10); [Rozo et al. 2014c](#bib.bib56)).

Gravitational lensing offers a powerful, independent alternative to HSE masses, but individual weak lensing mass estimates are noisy due to the sensitivity of the broad lensing kernel to material along the line-of-sight ([Hoekstra 2003](#bib.bib16)) and to halo triaxiality ([Becker & Kravtsov 2011](#bib.bib6)). Detailed lensing image simulations by [Meneghetti et al. (2010)](#bib.bib31) found that weak lensing mass estimates incur smaller bias than X-ray HSE values, with mean biases of a few percent. Independent work by [Becker & Kravtsov (2011)](#bib.bib6) supports this result, but mean underestimates of up to 10% have also been reported ([Rasia et al. 2012](#bib.bib53)). The bias depends in part on the method of extracting cluster mass from the lensing data, so precise estimates of systematic error require careful modeling of the full data acquisition and analysis workflow.

The Planck cluster cosmology findings motivate deeper investigation into the mass calibration for that sample. Here, we have relied on recent results from the Cluster Lensing and Supernova survey with Hubble ([Postman et al. 2012](#bib.bib50), CLASH, ) collaboration, who have measured lensing masses from imaging data of exquisite depth and wavelength coverage for a sample of 25 X-ray and lensing selected galaxy clusters ([Merten et al. 2015](#bib.bib35); [Umetsu et al. 2014](#bib.bib65); [Zitrin et al. 2015](#bib.bib70)). In particular, we used the reconstruction method presented in ([Merten et al. 2015](#bib.bib35)) to obtain 22 CLASH mass estimates.11
1
There is not enough data for the remaining three CLASH clusters, namely, MACS0647+7015, MACS2129-0741 and Abell1423. For instance, there is no wide-field 3+-band Subaru data available for the cluster Abell1423. After cross-matching the CLASH and Planck cluster catalogs, we measured the SZ signal of 22 CLASH clusters in the publicly available Planck dataset for any CLASH clusters not included in the original Planck cluster catalog. We then used the CLASH cluster sample to place tight constraints on the SZ scaling relation of galaxy clusters, and discuss the import of our results for the cosmological interpretation of the Planck cluster counts.

The layout of the paper is as follows. In Sect. [2](#S2 "2 Masses and mass proxies ‣ Calibrating the Planck cluster mass scale with CLASH") we summarize the methods
used to compute the CLASH and Planck mass estimates for the 21 clusters in common, while in Sect. [3](#S3 "3 Mass comparison ‣ Calibrating the Planck cluster mass scale with CLASH") we compare these estimates. In Sect. [4](#S4 "4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH") we introduce our models for the CLASH selection function and for the measurements, that is, the mass-observable distribution, including both observational uncertainties and intrinsic covariance between lensing and SZ signals. We construct the posterior probability distribution and perform different Bayesian analyses in Sect. [5](#S5 "5 Results ‣ Calibrating the Planck cluster mass scale with CLASH") to constrain the model parameters. In Sects. [6](#S6 "6 Discussion ‣ Calibrating the Planck cluster mass scale with CLASH") and [7](#S7 "7 Conclusion ‣ Calibrating the Planck cluster mass scale with CLASH") we discuss our results and then conclude with final remarks.

Unless otherwise specified, we have adopted a fiducial flat cosmology with $\Omega\_{\rm M}=0.3=1-\Omega\_{\Lambda}$ (see Table [2](#S4.T2 "Table 2 ‣ 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH")), and all masses are given within $R\_{500}$, the radius at which the mean mass density within the cluster reaches 500 times the critical density at the redshift of the cluster: $M=(4\pi/3)R^{3}\_{500}(500\rho\_{\rm c})$, with $\rho\_{\rm c}=3H^{2}(z)/8\pi G$. We refer to the Planck mass proxy (see below) as $M\_{\rm PL}$ and to the CLASH lensing mass as $M\_{\rm CL}$. These measurements are noisy realizations of the true SZ mass proxy, $M\_{\rm SZ}$, and true lensing mass, $M\_{\rm L}$.

## 2 Masses and mass proxies

### 2.1 CLASH lensing masses

The CLASH survey ([Postman et al. 2012](#bib.bib50)) is a Hubble Space Telescope (HST) multi-cycle treasury program targeting 25 massive galaxy clusters in the redshift range $0.18<z<0.89$ and over a mass range $0.5\times 10^{15}\ h^{-1}\mbox{M}\_{\odot}\lesssim M\_{\textrm{vir}}\lesssim 2.0\times 10^{15}\ h^{-1}\mbox{M}\_{\odot}$. The sample of 25 clusters was further subdivided into an X-ray selected sub-sample (20 clusters), and a strong-lensing selected sub-sample (five clusters, also referred to as the high-magnification sub-sample). For a complete definition of the two sub-sets, see [Postman et al. (2012)](#bib.bib50).

Each cluster was observed for 20 HST orbits in 16 broad photometric passbands. These data are supplemented with a three-to-five band Subaru/Suprime-Cam and ESO/WFI optical imaging to enable weak lensing measurements of the cluster profiles out to their virial radii. The combination of HST and ground-based wide-field data allows for a comprehensive weak-and strong-lensing analysis.

We have used a total of 22 CLASH clusters, of which 19 belong to the X-ray selected sub-sample and three
belong to the high-magnification subset. The lensing reconstructions of the X-ray selected clusters
have recently been presented in [Merten et al. (2015)](#bib.bib35) and [Umetsu et al. (2014)](#bib.bib65), while mass estimates for
the high-magnification clusters have in part been presented in [Medezinski et al. (2013)](#bib.bib28) and
[Umetsu et al. (2014)](#bib.bib65). Recently, [Umetsu et al. (2016)](#bib.bib67) and [Zitrin et al. (2015)](#bib.bib70) reconstructed the surface
mass density profiles of 20 and 25
clusters (complete CLASH sample), respectively. In all cases, a combination of weak and strong lensing
was used to derive reliable masses.

A thorough description of the input data and reconstruction techniques used in this work, is given by [Merten et al. (2015)](#bib.bib35). Here, we only provide a brief summary.
Masses were derived with the SaWLens code ([Merten et al. 2009](#bib.bib33)) that consistently combines weak and strong lensing
in a non-parametric fashion on adaptively refined grids. The method was thoroughly tested with realistic lensing scenarios
and numerically simulated clusters ([Meneghetti et al. 2010](#bib.bib31); [Rasia et al. 2012](#bib.bib53)), and has been used multiple times for the reconstruction
of real galaxy clusters ([Merten et al. 2009](#bib.bib33); [Merten et al. 2011](#bib.bib34); [Umetsu et al. 2012](#bib.bib66); [Patel et al. 2014](#bib.bib41)). For the CLASH analysis, SaWLens combines constraints from HST strong lensing, HST weak lensing and wide-field ground-based weak lensing (except for CLJ1226+3332 whose mass was reconstructed using HST data only) into a single reconstruction of the cluster’s gravitational potential from which it derives the surface-mass density. NFW fits to the surface-mass density provide the desired total 3-dimensional mass of the halo at any given radius.

Error bars for the lensing reconstruction were derived from 1000 bootstrap resamplings of the input weak-lensing shear catalogs, including their photometric redshift uncertainties,22
2
During the bootstrap the redshift uncertainty of a given WL galaxy was also sampled. Then the angular distance ratio $D\_{s}/D\_{ls}$ for each individual galaxy was calculated, which was then averaged and used to convert the convergence map into a physical surface-density map.
 and by randomly sampling the allowed redshift range of strong-lensing multiple image systems. Candidate systems are treated by random
inclusion or exclusion in each bootstrap. From the bootstrap realizations, we have derived the covariance matrix of the surface-mass density
bins, which is then taken into account during the NFW profile fitting (see [Merten et al. 2015](#bib.bib35), for details).

In particular, as discussed in [Merten et al. (2015)](#bib.bib35), the mass estimate of the system CLJ1226+3332 shows only a mild tension within the errors with an independent study by [Jee & Tyson (2009)](#bib.bib18). The uncertainties in the source redshift distribution are taken into account by the error estimation of the SaWLens method, which is based on a combination of bootstrapping and a resampling of source redshifts within their uncertainties.

These CLASH mass errors account for a number of systematics in the lensing reconstruction, including shape scatter in the weak lensing catalogs,
redshift uncertainties in the weak lensing background and strong-lensing multiple-image populations, mis-identifications of strong-lensing
features and uncertainty in the central peak position of the mass distribution. Sources of systematic error not covered
by this analysis include correlated and un-correlated structure within the cluster field, effects of tri-axiality and general error stemming from the fact that we fit a simplified 1D analytical form of the density profile to a complex mass distribution. These unaccounted sources of systematic error in CLASH mass
estimates have recently been estimated by [Umetsu et al. (2014)](#bib.bib65) to be $\sim$8%, and a detailed comparison
of the SaWLens mass reconstructions to a set of numerical simulations that mimic the CLASH selection
functions has been presented in [Meneghetti et al. (2014)](#bib.bib32). In Sect. [5](#S5 "5 Results ‣ Calibrating the Planck cluster mass scale with CLASH") we will account for this systematic uncertainty using a Gaussian distribution with standard deviation of 8% [Umetsu et al. (2014)](#bib.bib65), and also the left-skewed distribution for the 3D and true mass ratio found by [Meneghetti et al. (2014)](#bib.bib32), as priors on the lensing mass scale.

Figure 1: Mass comparison and mass bias estimates. On the left, we plot the CLASH lensing masses as a function of the Planck SZ mass proxy. Red points represent clusters found in the PSZ1 (13 objects) and blue those of the remaining objects at lower signal-to-noise (eight clusters); open circles identify the three clusters in the high-magnification subsample. The solid line is the equality line. The strongest outlier in the upper left corner is CLJ1226 at $z=0.89$, the highest redshift object in the sample. The right-hand panel plots $\rho=M\_{\rm PL}/M\_{\rm CL}$ as a function of CLASH mass together with its uncertainty $\Delta\rho$ (see text) in the same color scheme.
The green line and band correspond to the sample mean, $\langle\rho\rangle\_{\rm s}$, and its standard deviation obtained from a bootstrap analysis: $E(\langle\rho\rangle\_{\rm s})=0.72\pm 0.059$, where $E$ indicates a calculation over the bootstrap and $\langle\rho\rangle\_{\rm s}$ is calculated as the inverse-variance weighted mean. Similarly, the magenta line and band represent the bootstrap mean and uncertainty of the unweighted mean: $E(\langle\rho\rangle\_{\rm s})=0.76\pm 0.052$. The dashed line indicates zero mass bias.

### 2.2 Planck SZ mass proxy

We attempted to measure the SZ mass proxy for each of the 22 CLASH clusters. Of these, 13 are found in the Planck Catalog of SZ Sources ([Planck Collaboration et al. 2014a](#bib.bib45), PSZ1,) and an additional eight are detected in the Planck temperature maps, albeit at lower significance than for clusters in
the PSZ1. The remaining system, MACSJ1311-03, lies in a dusty region of the sky and has a negative signal-to-noise ratio in the Planck data. It is unusable, and we remove this system from our analysis, leaving 21 clusters.

The SZ mass proxy for each cluster is extracted following the same procedure as for the PSZ1. Here, we only provide a brief summary of the method.
For each CLASH cluster, we extract $10\deg\times 10\deg$ tangential maps centered on the cluster position for each of the six Planck High Frequency Instrument (HFI) channels. The maps were filtered with the SZ Matched MultiFilter ([Melin et al. 2006](#bib.bib30), MMF3,), varying the characteristic scale, $\theta\_{s}$, of the filter. For each system, the filter provided a degeneracy curve relating the SZ signal strength, $Y\_{500}$, to the characteristic scale, $\theta\_{s}$. We break this degeneracy curve with an X-ray prior on the signal-size relation ([Planck Collaboration et al. 2014b](#bib.bib46), Eq. 20 of), obtaining the cluster signal strength, $Y\_{500}$, and scale, $\theta\_{s}$, independently, and then convert the latter to $M\_{\rm PL}$. The upper and lower values for $M\_{\rm PL}$ are obtained following the same method, but using $Y\_{500}\pm\sigma\_{Y\_{500}}$ versus $\theta\_{s}$ for the degeneracy curve, where $\sigma\_{Y\_{500}}$ is the error on the signal provided by the MMF at each characteristic scale. Details are given in Sect. 7.2.2 of [Planck Collaboration et al. (2014a)](#bib.bib45).

We note that, in this work, the Planck masses were derived when centering the filters on the fiducial CLASH cluster position, irrespective of the PSZ1 location. This reflects the fact that Planck positions are more uncertain than those from the CLASH catalog. Because of this, our new SZ measurements differ slightly from, but remain consistent with, the values published in the PSZ1.
The inverse-variance weighted average of the ratio of the masses inferred from the SZ between the PSZ1 and our CLASH-centered estimates is $0.99\pm 0.03$.

Table 1: Cluster redshifts, Planck and CLASH mass estimates.

| Cluster | $z$ | $M\_{\rm PL}[10^{14}h^{-1}\mbox{M}\_{\odot}]$ | $M\_{\rm CL}[10^{14}h^{-1}\mbox{M}\_{\odot}]$ |
| --- | --- | --- | --- |
| Abell-383 | 0.188 | $2.41\pm 0.49$ | $6.12\pm 0.61$ |
| Abell-2261 | 0.225 | $5.33\pm 0.31$ | $9.48\pm 1.67$ |
| MACSJ1206-08 | 0.439 | $7.09\pm 0.47$ | $6.05\pm 0.94$ |
| RXJ1347-1145 | 0.451 | $7.55\pm 0.52$ | $7.97\pm 1.94$ |
| MACSJ0329-02 | 0.45 | $2.60\pm 0.87$ | $5.05\pm 0.84$ |
| MS2137-2353 | 0.313 | $2.56\pm 0.63$ | $6.79\pm 0.49$ |
| MACSJ0744+39 | 0.686 | $3.86\pm 0.82$ | $4.88\pm 0.39$ |
| MACSJ1115+0129 | 0.352 | $4.55\pm 0.49$ | $5.43\pm 0.87$ |
| Abell-611 | 0.288 | $3.38\pm 0.58$ | $5.70\pm 0.50$ |
| RXJ1532.8+3021 | 0.363 | $2.75\pm 0.71$ | $3.44\pm 0.75$ |
| MACSJ1720+3536 | 0.391 | $3.77\pm 0.55$ | $5.29\pm 0.80$ |
| RXJ2129+0005 | 0.234 | $3.20\pm 0.45$ | $4.30\pm 0.45$ |
| MACSJ1931-26 | 0.352 | $4.56\pm 0.55$ | $4.50\pm 0.44$ |
| Abell-209 | 0.206 | $5.58\pm 0.31$ | $6.27\pm 0.64$ |
| RXCJ2248-4431 | 0.348 | $7.99\pm 0.30$ | $7.66\pm 1.08$ |
| MACSJ0429-02 | 0.399 | $3.23\pm 0.77$ | $5.32\pm 1.35$ |
| MACSJ1423+24 | 0.545 | $4.07\pm 0.73$ | $4.09\pm 0.84$ |
| CLJ1226+3332 | 0.89 | $2.45\pm 1.03$ | $10.81\pm 0.92$ |
| MACSJ0717+37 | 0.548 | $8.49\pm 0.48$ | $9.68\pm 0.77$ |
| MACSJ1149+22 | 0.544 | $6.44\pm 0.53$ | $7.06\pm 0.30$ |
| MACSJ0416-24 | 0.42 | $3.87\pm 0.62$ | $4.33\pm 0.46$ |

## 3 Mass comparison

The left-hand panel of Fig. [1](#S2.F1 "Figure 1 ‣ 2.1 CLASH lensing masses ‣ 2 Masses and mass proxies ‣ Calibrating the Planck cluster mass scale with CLASH") compares the CLASH masses to the Planck SZ mass proxy, with the red points representing clusters in the PSZ1 and blue the additional lower signal-to-noise clusters. The three circled data points identify the CLASH clusters selected for their high lensing magnification. The redshift value and both Planck and CLASH mass estimates of each cluster are summarized in Table [1](#S2.T1 "Table 1 ‣ 2.2 Planck SZ mass proxy ‣ 2 Masses and mass proxies ‣ Calibrating the Planck cluster mass scale with CLASH").

The CLASH lensing masses tend to be larger than the Planck proxy values, and there is a “wall” of clusters at low Planck mass ($M\_{\rm PL}=2\times 10^{14}\ h^{-1}\mbox{M}\_{\odot}$) reaching to high lensing masses and that would appear to be related to the CLASH selection function. Our subsequent analysis indeed finds an effective mass cutoff for CLASH selection around $(4-5)\times 10^{14}\ h^{-1}\mbox{M}\_{\odot}$.
The biggest outlier, in the upper left corner in blue, is CLJ1226 at $z=0.89$, the highest redshift object in the CLASH sample.

Following other work ([von der Linden et al. 2014](#bib.bib69); [Hoekstra et al. 2015](#bib.bib17); [Simet et al. 2017](#bib.bib60), e.g.,), we began by assuming that the sample mean mass ratio, $\langle M\_{\rm PL}/M\_{\rm CL}\rangle\_{s}$, is an unbiased estimator of the mass bias, $(1-b\_{\rm SZ})$, between the Planck mass and true halo mass, $M\_{500}$. The right-hand panel of Fig. [1](#S2.F1 "Figure 1 ‣ 2.1 CLASH lensing masses ‣ 2 Masses and mass proxies ‣ Calibrating the Planck cluster mass scale with CLASH") shows the mass ratio $\rho=M\_{\rm PL}/M\_{\rm CL}$ for each of the clusters. Its uncertainty is calculated as $(\Delta(\ln\rho))^{2}=(\Delta(\ln M\_{\rm PL}))^{2}+(\Delta(\ln M\_{\rm CL}))^{2}$ and no correlation is assumed for the Planck and CLASH mass errors.

We first calculated the inverse-variance weighted mean: $\langle\rho\rangle\_{s}=0.72\pm 0.057$. We also estimate the uncertainty with a bootstrap, using the boot function from the Bootstrap R package ([Canty & Ripley 2015](#bib.bib8)), to obtain $E(\langle\rho\rangle\_{s})=0.72\pm 0.059$, where $E$ indicates a calculation over the bootstrap. The uncertainties on the cluster mass ratios are at best approximate, having been calculated using the measured ratios for each cluster, which tends to overweight (underweight) low (high) valued excursions and pull the inverse-variance weighted mean to smaller values.
An unweighted mean with bootstrap errors, as per [von der Linden et al. (2014)](#bib.bib69), results in a slightly higher value of $E(\langle\rho\rangle\_{s})=0.76\pm 0.052$ (magenta line and band).
These initial results are all in agreement with those obtained by the Canadian Cluster Comparison Project ([Hoekstra et al. 2015](#bib.bib17), CCCP,) and the Weighing the Giants program ([von der Linden et al. 2014](#bib.bib69), WtG,).

We note that three of our CLASH clusters were selected for their previously known high magnification, rather than based on their X-ray properties, as is true for the bulk of the sample; these objects are indicated in Fig. [1](#S2.F1 "Figure 1 ‣ 2.1 CLASH lensing masses ‣ 2 Masses and mass proxies ‣ Calibrating the Planck cluster mass scale with CLASH"). The X-ray selection would more naturally lend itself to our modeling of the selection function. To check for any sensitivity to these objects, we also performed our bootstrap analysis without them (i.e., on the other 18, X-ray selected, clusters). The results do not change significantly. Curiously, when eliminating these high magnification clusters, presumably more likely to have large masses, we find a slight increase in the mass bias, namely, $E(\langle\rho\rangle\_{s})=0.68\pm 0.066$. This can be appreciated by eye from Fig. [1](#S2.F1 "Figure 1 ‣ 2.1 CLASH lensing masses ‣ 2 Masses and mass proxies ‣ Calibrating the Planck cluster mass scale with CLASH"), where these three clusters all lie close to the equality line.

The simple analysis performed above is not completely satisfactory for a variety of reasons. Moreover, it is important to note that the average for this estimator is strictly over an ensemble including both measurement errors and intrinsic, potentially correlated astrophysical scatter at fixed true mass.
[Meneghetti et al. (2014)](#bib.bib32) found that the intrinsic scatter in CLASH lensing-deduced masses is expected to be log-normal with a standard deviation of (10-15)%, although it is potentially larger due to the impact of correlated structure33
3
Recently, [Shirasaki et al. (2016)](#bib.bib59) reported that the scatter of about $20\%$ in the thermal SZ and weak lensing relation, found from observations ([Marrone et al. 2012](#bib.bib26)), is due to projections of correlated structures and the bias in the lensing determined cluster radius., that was not fully accounted for in the [Meneghetti et al. (2014)](#bib.bib32) simulations ([Becker & Kravtsov 2011](#bib.bib6), see also). Intrinsic scatter in the Planck mass proxy is related to the scatter in SZ signal at fixed halo mass, estimated at $\sim 10\%$ according to numerical simulations ([Nagai et al. 2007](#bib.bib37); [Stanek et al. 2010](#bib.bib63), e.g.,). The exact way this propagates to the Planck mass is not quantified.
One would also expect a positive correlation between the lensing and SZ signals because both are a linear projection along the line-of-sight ([Noh & Cohn 2011](#bib.bib39); [Angulo et al. 2012](#bib.bib1)).

Finally, the simple analysis above has no means of
accounting for selection criteria in the cluster sample (especially for a rather small and peculiar
sample like CLASH), which is critical for interpreting the relation between the observed mass ratio and the mass bias of the SZ masses relative to true halo mass.
The Bayesian approach presented in the next section aims to address these shortcomings and thereby provide a more robust result and error analysis.

## 4 Bayesian analysis

The goal of our Bayesian analysis is to constrain models for the distribution of lensing and Planck masses given true halo mass and, simultaneously, an approximate form of the CLASH selection function. Our primary objective is the mass bias parameter, $(1-b\_{\rm SZ})$, quantifying the bias between the Planck mass proxy and true halo mass. With the Bayesian analysis, we can incorporate important astrophysical effects, such as the correlation between SZ and lensing signals, and evaluate their importance. The first task is to construct the posterior probability distribution for the model parameters given the data.

Our data consist of a set of Planck- and CLASH-determined masses and spectroscopic redshifts that we arrange into three data vectors, $\mathbf{M\_{\rm PL}}$, $\mathbf{M\_{\rm CL}}$ and $\mathbf{z\_{\rm spec}}$, respectively. Each vector has as many elements as clusters in our sample, $N\_{\rm clus}=21$. From these data and a model for the distribution of their uncertainties, we wish to determine the true cluster masses, $\mathbf{M\_{500}}$, and the mass bias, $(1-b\_{\rm SZ})$, as defined below.

### 4.1 Model

The observed Planck and CLASH masses are noisy Gaussian realizations of the underlying SZ and lensing masses, denoted $M\_{\rm SZ}$ and $M\_{\rm L}$, respectively. That is, $P(M\_{\rm PL}|M\_{\rm SZ})$ is a Gaussian distribution of mean $M\_{\rm SZ}$ and variance given by the Planck measurement error. The same holds for $P(M\_{\rm CL}|M\_{\rm L})$. The masses $M\_{\rm SZ}$ and $M\_{\rm L}$ are in turn related to the true halo mass $M\_{500}$ via a bivariate log-normal distribution.
We took the mean of these quantities to be

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\langle\ln M\_{\rm SZ}|M\_{500}\rangle$ | $\displaystyle=$ | $\displaystyle\ln(1-b\_{\rm SZ})+\alpha\_{\rm SZ}\ln\left(\frac{M\_{500}}{M\_{0}}\right),$ |  | (1) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\langle\ln M\_{\rm L}|M\_{500}\rangle$ | $\displaystyle=$ | $\displaystyle\ln(1-b\_{\rm L})+\alpha\_{\rm L}\ln\left(\frac{M\_{500}}{M\_{0}}\right).$ |  | (2) |

In these expressions, it is understood that $M\_{\rm SZ}$ and $M\_{\rm L}$ are in units of the pivot mass, $M\_{0}$. The intrinsic scatter in $\ln M\_{\rm SZ}$ ($\ln M\_{\rm L}$) at fixed mass is denoted via $\sigma\_{\rm SZ}$ ($\sigma\_{\rm L}$), the correlation coefficient between the two scatters is $r\_{\rm{SZ,L}|M\_{500}}$ (but for simplicity we denote it by $r$), and we adopt a pivot mass as the median of the CLASH lensing masses, i.e., $M\_{0}=5.7\times 10^{14}\,h^{-1}\mbox{M}\_{\odot}$.

The parameter $(1-b\_{\rm SZ})$ in Eq. ([1](#S4.E1 "In 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH")) is the mass bias we seek to calibrate the mass scale of the Planck clusters. It accounts for any source of bias, instrumental (e.g., X-ray satellite calibration) or astrophysical (e.g., violation of hydrostatic equilibrium in the ICM). Although defined here through a different equation than in the Planck cluster counts analysis ([Planck Collaboration et al. 2014b](#bib.bib46); [Planck Collaboration et al. 2016b](#bib.bib49)), we show in Appendix [A](#A1 "Appendix A Connection to the Planck SZ Cosmology Analysis ‣ Calibrating the Planck cluster mass scale with CLASH") that it is the same mass bias parameter. In fact, we view our parametrization as a formally more correct way of defining the bias parameter $(1-b\_{\rm SZ})$, because it clearly identifies the connection of this parameter to the data within the context of a generative model. Our results will therefore be of direct relevance to the cluster cosmology analysis presented by Planck.

Similarly, the parameter $(1-b\_{\rm L})$ characterizes any potential systematic bias in the CLASH lensing masses. Any such bias would depend on the method used to extract the lensing masses, as well as specifics of the observations themselves, and can only be accurately estimated through survey-specific numerical simulations. Generic simulations ([Meneghetti et al. 2010](#bib.bib31); [Becker & Kravtsov 2011](#bib.bib6)) suggest that lensing masses for rich cluster systems, such as those in our sample, are unbiased at the few percent level, while [Rasia et al. (2012)](#bib.bib53) report underestimates of up to 10%. [Meneghetti et al. (2014)](#bib.bib32) simulated the CLASH sample in detail and concluded that lensing masses are unbiased, with $\sim(10-15)\%$ scatter, although they did not simulate the complete strong+weak lensing measurement analysis. These studies provide a general idea of the level of possible bias and scatter, and we expect that in the near future simulations will improve the determination of these parameters and the slope of the mass dependence.

The probability of a CLASH cluster having data $(M\_{\rm PL},M\_{\rm CL},z\_{\rm spec})$ is

|  |  |  |
| --- | --- | --- |
|  | $P(M\_{\rm PL},M\_{\rm CL}|M\_{500},\mathbf{p})P(z\_{\rm spec}|z)dM\_{\rm PL}dM\_{\rm CL}dz\_{\rm spec},$ |  |

where

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle P(M\_{\rm PL},M\_{\rm CL}|M\_{500},\mathbf{p})$ | $\displaystyle=$ | $\displaystyle\int d\ln M\_{\rm SZ}d\ln M\_{\rm L}\ P(M\_{\rm PL}|M\_{\rm SZ})$ |  | (3) |
|  |  |  | $\displaystyle\hskip-28.45274pt\times P(M\_{\rm CL}|M\_{\rm L})P(\ln M\_{\rm SZ},\ln M\_{\rm L}|M\_{500},\mathbf{p}),$ |  |

$\mathbf{p}$ is the vector of scaling relation parameters ($b\_{\rm SZ},\alpha\_{\rm SZ},\sigma\_{\rm SZ},b\_{\rm L},\alpha\_{\rm L},\sigma\_{\rm L},r$) and $P(z\_{\rm spec}|z)$ is a delta function centered at $z\_{\rm spec}$. We consider the true mass and redshift of a cluster ($M\_{500},z$) as nuisance parameters. The posterior probability distribution of our model parameters is then

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal{L}}(\mathbf{M},\mathbf{z},\mathbf{p}|\mathbf{d})\propto P\_{0}(\mathbf{M},\mathbf{z}|\mathbf{p})\prod\_{i}P(M\_{\rm PL}^{(i)},M\_{\rm CL}^{(i)}|\mu,\mathbf{p})P(z\_{\rm spec}^{(i)}|z),$ |  | (4) |

where the product is over all galaxy clusters, the vector $\mathbf{M}$ comprises the true cluster masses, $\mathbf{d}$ the data ($\mathbf{M\_{\rm PL}},\mathbf{M\_{\rm CL}},\mathbf{z\_{\rm spec}}$), and we have dropped a normalization constant (the marginal probability of the data) that depends only on $\mathbf{d}$. We adopted the priors listed in Table [3](#S4.T3 "Table 3 ‣ 4.2 Priors ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH") on our scaling relation parameters, leaving only $P\_{0}(\mathbf{M},\mathbf{z})$, the prior on the mass and redshift vectors, $\mathbf{M}$ and $\mathbf{z}$, respectively.

The prior $P\_{0}(\mathbf{M},\mathbf{z})$ depends on the expected mass and redshift distribution of CLASH-detected clusters. Let $n\_{\rm det}(M\_{500},z)$ be this distribution. Assuming CLASH selects clusters in the redshift range ${z\_{\rm min}}$ to ${z\_{\rm max}}$, the probability distribution of finding a cluster with mass $M^{(i)}$ and redshift $z^{(i)}\in[{z\_{\rm min}},{z\_{\rm max}}]$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P(M^{(i)},z^{(i)})\ dMdz=\frac{n\_{\rm det}(M^{(i)},z^{(i)})}{\mathcal{N}}\ dMdz,$ |  | (5) |

where $\mathcal{N}$ is the normalization factor defined by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\int\_{{z\_{\rm min}}}^{{z\_{\rm max}}}dz\int\_{0}^{\infty}dM\,P(M,z)=1,$ |  | (6) |

which yields

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{N}=N\_{\rm det}=\int\_{{z\_{\rm min}}}^{{z\_{\rm max}}}dz\int\_{0}^{\infty}dM\,n\_{\rm det}(M,z).$ |  | (7) |

Thus, we obtain that the prior is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P\_{0}(\mathbf{M},\mathbf{z})=\prod\_{i}\frac{n\_{\rm det}(M\_{500}^{(i)},z^{(i)})}{N\_{\text{det}}},$ |  | (8) |

and our posterior becomes

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal{L}}(\mathbf{M},\mathbf{z};\mathbf{p}|\mathbf{d})=\prod\_{i}\frac{n\_{\rm det}(M\_{500},z)}{N\_{\text{det}}}P(M\_{\rm PL}^{(i)},M\_{\rm CL}^{(i)}|M\_{500},\mathbf{p})P(z\_{\rm spec}^{(i)}|z).$ |  | (9) |

We marginalized over our nuisance parameters by integrating over the vectors $\mathbf{M}$ and $\mathbf{z}$ to obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal{L}}(\mathbf{p}|\mathbf{d})=\prod\_{i}{\cal{L}}\_{i}(\mathbf{p}|\mathbf{d}),$ |  | (10) |

where we defined

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle{\cal{L}}\_{i}(\mathbf{p}|\mathbf{d})\equiv$ | $\displaystyle\frac{1}{N\_{\text{det}}}\int\_{{z\_{\rm min}}}^{{z\_{\rm max}}}dz\int\_{0}^{\infty}dM\_{500}\ n\_{\rm det}(M\_{500},z)$ |  |  | (11) |
|  |  | $\displaystyle\times\ P(M\_{\rm PL}^{(i)},M\_{\rm CL}^{(i)}|M\_{500},\mathbf{p})P(z\_{\rm spec}^{(i)}|z).$ |  |  |

Given that the redshift distribution is a delta function, Eq. ([11](#S4.E11 "In 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH")) reduces to

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal{L}}\_{i}\equiv\frac{1}{N\_{\text{det}}}\int\_{-\infty}^{\infty}d\ln M\_{500}\ n\_{\rm det}(M\_{500},z\_{\rm spec}^{(i)})P(M\_{\rm PL}^{(i)},M\_{\rm CL}^{(i)}|M\_{500},\mathbf{p}),$ |  | (12) |

where ${z\_{\rm min}}\leq z\_{\rm spec}^{(i)}\leq{z\_{\rm max}}$. Together with Eq. ([10](#S4.E10 "In 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH")), this is our final expression for the posterior distribution over the parameter space. It is worth noting that this posterior is equivalent to the one built taking into account the Poisson distribution of the missing clusters and then marginalizing over the number of these undetected objects (see, e.g., [Mantz et al. (2010)](#bib.bib25)).

We then modeled the selection function, that is, the mass-redshift distribution of the CLASH sample. Despite the detailed study by [Meneghetti et al. (2014)](#bib.bib32) quantifying the effects of the CLASH selection criteria on the determination of the concentration-mass relation, it is difficult to extract a precise selection function in terms of cluster mass from their simulations. We therefore adopted the following approach.

We assumed that CLASH selection in mass is redshift independent over the range $[{z\_{\rm min}},{z\_{\rm max}}]$, and that the probability of a cluster being included in the sample is a function that goes to zero at low mass and to unity at high mass. We modeled this with an error function:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f(M\_{500})=\frac{1}{2}\left[1+\text{erf}\left(\frac{\ln M\_{500}-\ln M\_{\rm cut}}{\sqrt{2}\sigma\_{\rm cut}}\right)\right],$ |  | (13) |

and treated the low-mass cutoff, $M\_{\rm cut}$, and $\sigma\_{\rm cut}$, ${z\_{\rm min}}$ and ${z\_{\rm max}}$ as free parameters to be determined by the data themselves.

We took the mass-redshift distribution as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n\_{\rm det}(M\_{500},z)=f(M\_{500})\frac{dn(M\_{500},z)}{d\ln M\_{500}}\frac{d^{2}V}{dzd\Omega},$ |  | (14) |

where $dn/d\ln M\_{500}$ is the halo mass function and $d^{2}V/dzd\Omega$ is the comoving volume element per unit solid angle, $d\Omega$. Throughout this paper, we have adopted the [Tinker et al. (2008)](#bib.bib64) multiplicity function with $M\_{500}$ defined in terms of the critical density, and the $\Lambda$CDM cosmological parameters used to estimate both Planck and CLASH masses as listed in Table [2](#S4.T2 "Table 2 ‣ 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH").

Table 2: Fiducial cosmological parameters

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  | | --- | --- | | Parameter | Value | | $H\_{0}$ (km s-1Mpc-1) | $70.0$ | | $\Omega\_{b}$ | $0.049$ | | $\Omega\_{m}$ | $0.3$ | | $\Omega\_{\Lambda}$ | $0.7$ | | $\sigma\_{8}$ | $0.816$ | | $n\_{s}$ | $0.967$ | |  |

Figure 2: Results of the full-parameter MCMC analysis with $1.4\times 10^{6}$ points (Case 1, Sect. [5.1](#S5.SS1 "5.1 Case 1: All parameters free, flat prior on 𝑏_L ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH")). The contours correspond to the two-dimensional $68.3\%$, $95.4\%$, $99.7\%$ confidence regions on parameter pairs after marginalizing over the other parameters and the true mass and redshift [see Eqs. ([12](#S4.E12 "In 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH")), ([13](#S4.E13 "In 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH")) and ([14](#S4.E14 "In 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH"))]. The histograms show the one-dimensional posterior marginal distributions for each parameter.

### 4.2 Priors

Our complete set of model parameters is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{p}=\{\alpha\_{\rm SZ},b\_{\rm SZ},\sigma\_{\rm SZ},\alpha\_{\rm L},b\_{\rm L},\sigma\_{\rm L},r,M\_{\rm cut},\sigma\_{\rm cut},{z\_{\rm min}},{z\_{\rm max}}\},$ |  | (15) |

comprising four scaling relation parameters for the mean mass values ($\alpha\_{\rm SZ},b\_{\rm SZ},\alpha\_{\rm L},b\_{\rm L}$),
three scatter parameters ($\sigma\_{\rm SZ},\sigma\_{\rm L},r$), and four selection function parameters ($M\_{\rm cut},\sigma\_{\rm cut},{z\_{\rm min}},{z\_{\rm max}}$). The primary parameter of interest in this work is the bias, $b\_{\rm SZ}$, of the SZ mass proxy and for which we adopted a flat prior. The parameter $b\_{\rm L}$ is the possible bias in the CLASH lensing masses, for which we adopt the same flat prior as for $b\_{\rm SZ}$ or a Gaussian prior with zero mean and standard deviation equal to 0.08 ([Umetsu et al. 2014](#bib.bib65)); we also performed analyses with fixed values of $\alpha\_{\rm L}=1$, $b\_{\rm L}=0.0$, that is, unbiased lensing masses, and $\alpha\_{\rm SZ}=1$. Table [3](#S4.T3 "Table 3 ‣ 4.2 Priors ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH") summarizes the weak priors adopted on all other parameters.

Table 3: Summary of priors

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  | | --- | --- | --- | | Parameter | Interval (flat) | Gaussian | | $\alpha\_{\rm SZ}$ | $[0.5,1.5]$ | – | | $1-b\_{\rm SZ}$ | $[0.001,2.0]$ | – | | $\sigma\_{\rm SZ}$ | $[0.01,1.0]$ | – | | $\alpha\_{\rm L}$ | $[0.5,1.5]$ | – | | $1-b\_{\rm L}$ | $[0.001,2.0]$ | $\text{G}(1.0,0.08)$ | | $\sigma\_{\rm L}$ | $[0.01,1.0]$ | – | | $r$ | $[-1.0,1.0]$ | – | | $M\_{\rm cut}(h^{-1}\mbox{M}\_{\odot})$ | $[10^{12},10^{16}]$ | – | | $\sigma\_{\rm cut}$ | $[0.01,0.9]$ | – | | ${z\_{\rm min}}$ | $[0.0,0.188]$ | – | | ${z\_{\rm max}}$ | $[0.89,2.188]$ | – | |  |

### 4.3 Algorithm

The posterior function is implemented in the Numerical Cosmology library ([Dias Pinto Vitenti & Penna-Lima 2014](#bib.bib9), NumCosmo,). The model and data objects are named NcClusterPseudoCounts
and NcDataClusterPseudoCounts, respectively. The latter implements the $-2\ln{\cal{L}}$ function and the former comprises, among other functions, $f(M\_{500})$, $n\_{\rm det}$, $N\_{\rm det}$ and the integral of Eq. ([12](#S4.E12 "In 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH")). In order to optimize computation time, we numerically calculate the three-dimensional integral over $\ln M\_{500}$, $\ln M\_{\rm SZ}$ and $\ln M\_{\rm L}$ using the Divonne algorithm from the Cuba library 44
4
http://www.feynarts.de/cuba/.

The Gaussian probability distributions for the Planck and CLASH masses, and the bivariate log-normal distribution for $M\_{\rm SZ}$ and $M\_{\rm L}$ (Eq. [3](#S4.E3 "In 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH")) are written in the NcClusterMassPlCL object. A detailed description of the mass function calculation is presented in [Penna-Lima et al. (2014)](#bib.bib42). The python script (mass\_calibration\_planck\_clash.py) to reproduce the analyses presented in this work is distributed and available with NumCosmo55
5
https://github.com/NumCosmo/NumCosmo. As an illustration, our code takes about 22 hours to carry out a Markov chain Monte Carlo (MCMC) study with $10^{6}$ points, using 100 chains and 40 cores.

Table 4: Results – The mean and $68\%$ CI of the marginal posterior distributions

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| Fixed parameters   Prior on $b\_{\rm L}$ | None Flat | None Gaussian | None (without CLJ1226)     Gaussian | $\alpha\_{\rm L}=1.0$ Gaussian | $\alpha\_{\rm SZ}=\alpha\_{\rm L}=1.0$    Gaussian | $\alpha\_{\rm SZ}=\alpha\_{\rm L}=1.0$, $b\_{\rm L}=0.0$       – |
|  | Mean $\pm 1\sigma$ | Mean $\pm 1\sigma$ | Mean $\pm 1\sigma$ | Median $\pm 1\sigma$ | Mean $\pm 1\sigma$ | Mean $\pm 1\sigma$ |
| $\alpha\_{\rm SZ}$ | $1.03^{+0.29}\_{-0.33}$ | $1.05^{+0.29}\_{-0.37}$ | $1.06^{+0.29}\_{-0.35}$ | $1.04^{+0.31}\_{-0.36}$ | – | – |
| $1-b\_{\rm SZ}$ | $0.71^{+0.45}\_{-0.19}$ | $0.73^{+0.10}\_{-0.09}$ | $0.78^{+0.11}\_{-0.09}$ | $0.73^{+0.10}\_{-0.08}$ | $0.73^{+0.09}\_{-0.08}$ | $0.74\pm 0.07$ |
| $\sigma\_{\rm SZ}$ | $0.29^{+0.11}\_{-0.14}$ | $0.28^{+0.12}\_{-0.16}$ | $0.26^{+0.12}\_{-0.13}$ | $0.31^{+0.11}\_{-0.12}$ | $0.32^{+0.12}\_{-0.09}$ | $0.32^{+0.11}\_{-0.09}$ |
| $\alpha\_{\rm L}$ | $0.91^{+0.36}\_{-0.26}$ | $0.87^{+0.39}\_{-0.25}$ | $0.81^{+0.33}\_{-0.19}$ | – | – | – |
| $1-b\_{\rm L}$ | $0.95^{+0.43}\_{-0.23}$ | $0.996^{+0.076}\_{-0.073}$ | $1.001\pm 0.07$ | $0.993\pm 0.08$ | $0.991^{+0.08}\_{-0.07}$ | – |
| $\sigma\_{\rm L}$ | $0.20^{+0.09}\_{-0.11}$ | $0.20^{+0.08}\_{-0.11}$ | $0.13^{+0.09}\_{-0.07}$ | $0.17\pm 0.10$ | $0.16^{+0.11}\_{-0.09}$ | $0.17^{+0.10}\_{-0.09}$ |
| $r$ | $0.03^{+0.49}\_{-0.63}$ | $0.01^{+0.49}\_{-0.66}$ | $0.16^{+0.51}\_{-0.84}$ | $-0.04^{+0.54}\_{-0.60}$ | $-0.07^{+0.53}\_{-0.61}$ | $-0.05^{+0.47}\_{-0.56}$ |
| $\ln M\_{\rm cut}$ | $34.13^{+0.44}\_{-0.49}$ | $33.95^{+0.25}\_{-0.17}$ | $33.93^{+0.30}\_{-0.18}$ | $33.93^{+0.23}\_{-0.15}$ | $33.94^{+0.23}\_{-0.16}$ | $33.98^{+0.57}\_{-0.15}$ |
| $\sigma\_{\rm cut}$ | $0.19^{+0.20}\_{-0.11}$ | $0.17^{+0.14}\_{-0.10}$ | $0.19^{+0.15}\_{-0.11}$ | $0.15^{+0.12}\_{-0.09}$ | $0.16^{+0.12}\_{-0.10}$ | $0.18^{+0.14}\_{-0.10}$ |
| ${z\_{\rm min}}$ | $0.14^{+0.04}\_{-0.12}$ | $0.13^{+0.04}\_{-0.11}$ | $0.13^{+0.04}\_{-0.11}$ | $0.13^{+0.04}\_{-0.11}$ | $0.13^{+0.04}\_{-0.11}$ | $0.13^{+0.04}\_{-0.11}$ |
| ${z\_{\rm max}}$ | $1.48^{+0.48}\_{-0.41}$ | $1.50^{+0.44}\_{-0.42}$ | $1.08^{+1.11}\_{-0.28}$ | $1.50^{+0.48}\_{-0.42}$ | $1.50^{+0.49}\_{-0.42}$ | $1.48^{+0.46}\_{-0.40}$ |

## 5 Results

We explored six cases with the Bayesian analysis and present the results in Table [4](#S4.T4 "Table 4 ‣ 4.3 Algorithm ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH") and in Figs. [2](#S4.F2 "Figure 2 ‣ 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH") and [3](#S5.F3 "Figure 3 ‣ 5.2 Case 2: All parameters free, Gaussian prior on 𝑏_L ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH"). In the first full-parameter case, we leave all 11 parameters free and consider a flat prior on $b\_{\rm L}$ to understand the degeneracies inherent in the system. As there is nothing to tie-down the overall mass scale of the sample, degeneracies appear between the mass bias parameter, $b\_{\rm SZ}$, the lensing mass calibration, $b\_{\rm L}$, and the mass cut of the selection function. In our second study, we also perform a full-parameter analysis, but now applying the Gaussian prior on $b\_{\rm L}$ in order to evaluate the effect of the lensing systematics on the determination of $b\_{\rm SZ}$. We then examined three other cases by progressively adding strong constraints on the slopes of the lensing and SZ relations and also on $b\_{\rm L}$, namely: (i) $\alpha\_{\rm L}=1.0$, (ii) $\alpha\_{\rm SZ}=\alpha\_{\rm L}=1.0$, (iii) $\alpha\_{\rm SZ}=\alpha\_{\rm L}=1.0$ and $b\_{\rm L}=0.0$. Overall, fixing these parameters changes little on the constraints of the others, as shown in Table [4](#S4.T4 "Table 4 ‣ 4.3 Algorithm ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH").

Finally, we carried out a full-parameter study excluding the cluster CLJ1226 at $z=0.89$. We observe an impact on SZ and lensing biases and scatters, but these results are consistent with the constraints of the other five cases within the $68.3\%$ confidence interval (CI).

### 5.1 Case 1: All parameters free, flat prior on $b\_{\rm L}$

For our first study, we computed the joint posterior distribution for the full parameter set describing the SZ- and lensing-mass distribution and the selection function. We ran 100 chains using the NcmFitESMCMC algorithm, an ensemble sampler with affine invariance for MCMC analysis from NumCosmo, requiring convergence of the variance of the fit parameters and $-2\ln{\cal{L}}$, and of the multivariate potential scale reduction factor (MPSRF). The latter should be at least smaller than $1.2$, and $\text{Var}(-2\ln{\cal{L}})$ should be close to 22, since we are fitting 11 parameters.

We computed a total of $1.5\times 10^{6}$ sampling points and considered a burn-in of $10^{5}$ points, obtaining ${\rm MPSRF}\simeq 1.04$ and $\text{Var}(-2\ln{\cal{L}})\simeq 19.5$. As a consistency check, we also calculated these values for different burn-in sizes, namely 10 equally spaced points between $[10^{4},10^{5}]$, confirming the convergence status of the chains. Figure [2](#S4.F2 "Figure 2 ‣ 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH") shows the $68.3\%$, $95.4\%$ and $99.7\%$ confidence regions for parameter pairs, as well as the one-dimensional marginal distribution for each parameter.

It is worth noting that, in high-dimensional parameter space MCMC does not provide, in general, accurate estimates for the best fit66
6
For instance, consider a n-dimensional unit Gaussian, whose maximum is at the origin. The probability of the number of samples to be close to the maximum is small, since the volume of a high-dimensional sphere is concentrated in a narrow annulus at the surface ([Unpingco 2016](#bib.bib68)). ([Lewis & Bridle 2002](#bib.bib21); [Hobson et al. 2009](#bib.bib15)). Therefore, in Table 4 we quote the mean and the $68.3\%$ CI of the marginal posterior of each parameter. We determined the $68.3\%$ CI of the i-th parameter $p\_{i}$ by finding the points $p\_{i}^{-}$ and $p\_{i}^{+}$ such that the probability $\text{Pr}(p\_{i}^{-}\leqslant p\_{i}\leqslant\bar{p}\_{i})=34.15\%$ (68.27%/2) and $\text{Pr}(\bar{p}\_{i}\leqslant p\_{i}\leqslant p\_{i}^{+})=34.15\%$, respectively, where $\bar{p\_{i}}$ is the mean of $p\_{i}$.

In general, the marginal distributions are highly non-Gaussian. The parameters are very degenerate in this first, unconstrained exploration, most notably the slopes $\alpha\_{\rm SZ}$ and $\alpha\_{\rm L}$, the correlation $r$ and ${z\_{\rm max}}$. We see in Fig. [2](#S4.F2 "Figure 2 ‣ 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH") that their confidence regions cover the entire range of values defined by their flat priors, and that their errors are of the order of $50\%$ and larger (see Table [4](#S4.T4 "Table 4 ‣ 4.3 Algorithm ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH"), column “none, flat”).

The mass bias parameter, $(1-b\_{\rm SZ})$, is strongly correlated with the lensing mass calibration, $(1-b\_{\rm L})$, and both are strongly anti-correlated with $M\_{\rm cut}$. The former correlation is easily understood, because the mass bias is obviously tied to halo mass through the lensing measurements; changing the lensing calibration correspondingly changes the mass bias parameter. The anti-correlation between $b\_{\rm L}$ and $M\_{\rm cut}$ is a result of the lack of any absolute mass tie-down in this full parameter exploration: the system is attempting to calibrate the overall mass scale, and hence the lensing mass bias, through the selection function mass cut-off. This anti-correlation then spills into $b\_{\rm SZ}$ through its correlation with $b\_{\rm L}$.

The SZ and lensing scatters are reasonably well constrained by the data, with large values, $\sigma\_{\rm SZ}\gtrsim 0.6$ and $\sigma\_{\rm L}\gtrsim 0.4$, disfavored. At $0.20$, the mean for $\sigma\_{\rm L}$ is consistent with expectations based on the simulations by [Meneghetti et al. (2014)](#bib.bib32). We also see from Fig. [2](#S4.F2 "Figure 2 ‣ 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH") that $\sigma\_{\rm SZ}$ ($\sigma\_{\rm L}$) is moderately anti-correlated with $\alpha\_{\rm SZ}$ ($\alpha\_{\rm L}$). We note this anti-correlation refers
to the uncertainties in $\sigma\_{\rm SZ}$ and $\sigma\_{\rm L}$, and not to the correlation coefficient between these two, which is unconstrained by the data.

### 5.2 Case 2: All parameters free, Gaussian prior on $b\_{\rm L}$

Similarly to the previous study, we now fit the 11 parameters considering a Gaussian prior on $b\_{\rm L}=0.0\pm 0.08$ ([Umetsu et al. 2014](#bib.bib65); [Meneghetti et al. 2014](#bib.bib32)). We performed an MCMC analysis generating $8.5\times 10^{5}$ sample points. With a burn-in size of $10^{5}$, we obtained ${\rm MPSRF}\simeq 1.03$ and $\text{Var}(-2\ln{\cal{L}})\simeq 15.9$. The marginal distributions and the $68.3\%$, $95.4\%$ and $99.7\%$ confidence regions are shown in Fig. [3](#S5.F3 "Figure 3 ‣ 5.2 Case 2: All parameters free, Gaussian prior on 𝑏_L ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH"). Given the lack of correlation between $\alpha\_{\rm SZ}$, $\sigma\_{\rm SZ}$, $\alpha\_{\rm L}$, $\sigma\_{\rm L}$, $r$, $\sigma\_{\rm cut}$, ${z\_{\rm min}}$ and ${z\_{\rm max}}$ with $b\_{\rm L}$, there is no improvement in their constraints (see third column of Table [4](#S4.T4 "Table 4 ‣ 4.3 Algorithm ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH")).

The main differences concern $b\_{\rm SZ}$ and $M\_{\rm cut}$, which were strongly correlated with $b\_{\rm L}$ in Case 1. We drastically reduce the uncertainty on $(1-b\_{\rm SZ})$, by about $70\%$ with mean $0.73$ and $68.3\%$ CI of $[0.64,0.83]$. Similarly, for $\ln M\_{\rm cut}$ the decrease in the $68.3\%$ CI is $\sim 60\%$. In addition, fixing the mass scale tightens the correlation between $\ln M\_{\rm cut}$ and $\sigma\_{\rm cut}$.

Another effect of the $b\_{\rm L}$ prior is to weaken the correlation between $b\_{\rm SZ}$ and $M\_{\rm cut}$, confirming that their previous strong correlation leaks through from their relation to $b\_{\rm L}$. This means that our constraints on the mass bias, $b\_{\rm SZ}$, are relatively insensitive to the selection function as long as the lensing measurements robustly tie-down the mass scale.

Figure 3: Results of the full-parameter MCMC analysis assuming a Gaussian prior of $b\_{\rm L}=0\pm 0.08$, with $8.5\times 10^{5}$ points (Case 2, Sect. [5.2](#S5.SS2 "5.2 Case 2: All parameters free, Gaussian prior on 𝑏_L ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH")) and following the format of Fig. [2](#S4.F2 "Figure 2 ‣ 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH").

#### 5.2.1 Other cases

We now consider more specific cases by fixing (i) $\alpha\_{\rm L}=1.0$, (ii) $\alpha\_{\rm SZ}=\alpha\_{\rm L}=1.0$, and (iii) $\alpha\_{\rm SZ}=\alpha\_{\rm L}=1.0$ and $b\_{\rm L}=0.0$ in Eqs. ([1](#S4.E1 "In 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH"))–([2](#S4.E2 "In 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH")). This last corresponds the case of calibrating the overall scale of the Planck mass proxy assuming the CLASH masses are unbiased. We ran 100 chains, computing $5\times 10^{5}$ points with a burn-in of $10^{5}$ for each case. The respective results are given in the fifth, sixth and seventh columns of Table [4](#S4.T4 "Table 4 ‣ 4.3 Algorithm ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH").

All three cases indicate that the constraints are limited by the small statistics of the sample. In general, the parameters are not correlated and, therefore, fixing the SZ and lensing slopes of the mass scaling relations do not tighten the constraints on the remaining parameters. The main difference is the reduction in $\sim 30\%$ of the $68.3\%$ CI of $(1-b\_{\rm SZ})$, when considering the extreme case (iii), in which there are no systematics in the lensing masses. In fact, the uncertainty on $(1-b\_{\rm SZ})$ in Case 2 is the quadrature sum of the statistical uncertainty here and the Gaussian uncertainty on $b\_{\rm L}$: $0.1=\sqrt{0.07^{2}+0.08^{2}}$, as could be expected. It is worth mentioning that the regularity of these three $(1-b\_{\rm SZ})$ estimates lends support to the conservative result presented in Sect. [5.2](#S5.SS2 "5.2 Case 2: All parameters free, Gaussian prior on 𝑏_L ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH").

We also fit the 11 parameters removing the outlier CLJ1226 from the cluster catalog. Running also 100 chains, we generated $5\times 10^{5}$ points to reach ${\rm MPSRF}\simeq 1.09$ and $\text{Var}(-2\ln{\cal{L}})\simeq 22.06$. From Fig. [1](#S2.F1 "Figure 1 ‣ 2.1 CLASH lensing masses ‣ 2 Masses and mass proxies ‣ Calibrating the Planck cluster mass scale with CLASH"), we would expect an increase in the correlation, a decrease in the SZ and lensing scatters and in both bias parameters, since the outlier seems to require a spreader distribution to include it. The results, displayed in the fourth column of Table [4](#S4.T4 "Table 4 ‣ 4.3 Algorithm ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH"), confirm these expectancies. For instance, $1-b\_{\rm SZ}=0.78$, $\sigma\_{l}=0.13$ and $r=0.16$, although they are not statistically significant. We note that the results of all six cases are consistent, in part due to the broad constraints on the parameters, and that future applications of our methodology to larger catalogs promise to break the degeneracies.

### 5.3 Non-Gaussian prior

The results presented so far show that the constraints on $b\_{\rm SZ}$ are strongly dependent of $b\_{\rm L}$. In addition to the flat and Gaussian priors on $b\_{\rm L}$, and the unbiased case ($b\_{\rm L}=0.0$), we now consider one last case study with a non-Gaussian prior.

This new prior is based on the result presented in [Meneghetti et al. (2014)](#bib.bib32). The authors obtained the distribution of the 3D lensing-true mass ratio considering the NFW profile (among others). This is a left-skewed distribution in the interval $(1-b\_{L})\in[0.8,1.1]$, which we use as a prior on $b\_{L}$ and show in Fig. [4](#S5.F4 "Figure 4 ‣ 5.3 Non-Gaussian prior ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH") (blue dashed line) labeled as the Meneghetti prior.

In this case we ran 100 chains, computing $6\times 10^{5}$ sampling points (burn-in size of $10^{5}$). The posterior distributions of $(1-b\_{\rm L})$ and $(1-b\_{\rm SZ})$ are shown in Figs. [4](#S5.F4 "Figure 4 ‣ 5.3 Non-Gaussian prior ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH") and [5](#S5.F5 "Figure 5 ‣ 5.3 Non-Gaussian prior ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH"), respectively. We compared them with the posteriors obtained from the MCMC analysis considering the flat prior. Similar to the previous cases, we see the strong effect on $(1-b\_{\rm SZ})$ due to the prior on $(1-b\_{\rm L})$.

Table [5](#S5.T5 "Table 5 ‣ 5.3 Non-Gaussian prior ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH") displays the mean and the 68.3% CI of all 11 parameters for the Gaussian and Meneghetti priors, second and third columns respectively. For instance, as the Meneghetti prior restricts $b\_{\rm L}$ to a narrower interval, naturally its error bar is accordingly reduced in comparison to the flat and Gaussian priors, namely, $(1-b\_{\rm L})=0.964\_{-0.057}^{+0.034}$. As expected, given the form of the Meneghetti prior (blue dashed line in Fig. [4](#S5.F4 "Figure 4 ‣ 5.3 Non-Gaussian prior ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH")), the lensing-mass proxy now presents a small bias. Consequently, the SZ bias increases by 3% to $(1-b\_{\rm SZ})=0.69\_{-0.09}^{+0.08}$, in comparison to the Gaussian prior centered in $b\_{\rm L}=0$, whereas the error bar decreases due to the narrower $b\_{\rm L}$ interval. It is worth mentioning that both results are in accordance within $68.3\%$ CI.

On the other hand, the parameters of the selection function, $M\_{\rm cut}$ and $\sigma\_{\rm cut}$, increase in both their mean values and their uncertainties even when compared to the flat-prior case (see Tables [4](#S4.T4 "Table 4 ‣ 4.3 Algorithm ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH") and [5](#S5.T5 "Table 5 ‣ 5.3 Non-Gaussian prior ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH")). This is due to the anti-correlation between $b\_{\rm L}$ and $M\_{\rm cut}$. The $(1-b\_{\rm L})$ interval, [0.8, 1.1], favors larger values of $M\_{\rm cut}$ and, consequently, $\sigma\_{\rm cut}$. The remaining parameters present no significant modification compared to the previous cases.

Figure 4: Prior distributions for the lensing mass bias parameter, $b\_{\rm L}$. The blue dashed line represents the Meneghetti prior, i.e., the 3D lensing-true mass ratio distribution ([Meneghetti et al. 2014](#bib.bib32)). The other curves give the $1-b\_{\rm L}$ posterior distributions in the case of flat (red line) and Meneguetti (black line) priors obtained from the MCMC analyses of the CLASH-Planck cluster sample (data).

Figure 5: The posterior distribution of $1-b\_{\rm SZ}$ for the flat (red line) and Meneguetti (black line) priors.

Table 5: Results – The mean and $68\%$ CI of the marginal posterior distributions

|  |  |  |
| --- | --- | --- |
| Fixed Parameters   Prior on $b\_{\rm L}$ | None Gaussian | None Meneghetti |
|  | Mean $\pm 1\sigma$ | Mean $\pm 1\sigma$ |
| $\alpha\_{\rm SZ}$ | $1.05^{+0.29}\_{-0.37}$ | $1.03^{+0.29}\_{-0.32}$ |
| $1-b\_{\rm SZ}$ | $0.73^{+0.10}\_{-0.09}$ | $0.69^{+0.08}\_{-0.09}$ |
| $\sigma\_{\rm SZ}$ | $0.28^{+0.12}\_{-0.16}$ | $0.28^{+0.12}\_{-0.15}$ |
| $\alpha\_{\rm L}$ | $0.87^{+0.39}\_{-0.25}$ | $0.83^{+0.41}\_{-0.21}$ |
| $1-b\_{\rm L}$ | $0.996^{+0.076}\_{-0.073}$ | $0.964^{+0.034}\_{-0.057}$ |
| $\sigma\_{\rm L}$ | $0.20^{+0.08}\_{-0.11}$ | $0.20^{+0.09}\_{-0.11}$ |
| $r$ | $0.01^{+0.49}\_{-0.66}$ | $0.04^{+0.48}\_{-0.65}$ |
| $\ln M\_{\rm cut}$ | $33.95^{+0.25}\_{-0.17}$ | $34.14^{+0.97}\_{-0.24}$ |
| $\sigma\_{\rm cut}$ | $0.17^{+0.14}\_{-0.10}$ | $0.22^{+0.21}\_{-0.12}$ |
| ${z\_{\rm min}}$ | $0.13^{+0.04}\_{-0.11}$ | $0.13^{+0.04}\_{-0.11}$ |
| ${z\_{\rm max}}$ | $1.50^{+0.44}\_{-0.42}$ | $1.50^{+0.44}\_{-0.43}$ |

## 6 Discussion

Our basic result is a constraint on the Planck mass bias parameter of $(1-b\_{\rm SZ})=0.73\pm 0.10$ ($0.69\_{-0.09}^{+0.08}$). This value applies at the median mass of our sample, $M\_{0}=5.7\times 10^{14}h^{-1}$, and our fit is consistent with no mass dependence, although with large uncertainty. Obtained by fitting all 11 parameters and assuming the Gaussian (Meneghetti) prior on $b\_{\rm L}$ (Cases 2 and 7, Sects. [5.2](#S5.SS2 "5.2 Case 2: All parameters free, Gaussian prior on 𝑏_L ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH") and [5.3](#S5.SS3 "5.3 Non-Gaussian prior ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH"), second and third columns Table [5](#S5.T5 "Table 5 ‣ 5.3 Non-Gaussian prior ‣ 5 Results ‣ Calibrating the Planck cluster mass scale with CLASH"), respectively), these results agree within the uncertainties with the constraints in the five other case studies, as well as with the sample mean ratio from Sect. [3](#S3 "3 Mass comparison ‣ Calibrating the Planck cluster mass scale with CLASH"). They improve on the latter by folding in astrophysical effects, such as intrinsic, correlated scatter, and the influence of the CLASH selection function.

We have used Planck as a follow-up to the CLASH sample and, as a consequence, are not affected by the selection (Malmquist77
7
Classical Malmquist bias applies to a flux limited sample and refers to the fact that intrinsically more luminous objects are over-represented because they can be seen over larger volumes than less luminous sources. In common practice, Malmquist bias is the term applied generally, but inaccurately, to effects related to sample selection.) bias noted by [Battaglia et al. (2016)](#bib.bib4)88
8
The authors referred to this correction as an Eddington bias correction. Eddington bias is not a sample selection effect, but rather due to dispersion in an observable in the presence of a steep abundance function. While discussing Eddington bias at an earlier point in their paper, the correction made to WtG and CCCP results due to missing clusters is more appropriately referred to as Malmquist bias.. This bias arises in the WtG and CCCP studies because some of their clusters do not have Planck detections99
9
We note, however, that we are unable to use one cluster in our CLASH sample because of its negative signal-to-noise value.. [Battaglia et al. (2016)](#bib.bib4) attempted to correct the WtG and CCCP results for this effect by assigning Planck masses to the undetected clusters. Without knowing which masses to assign, however, this correction is of course uncertain, as they discuss (see also below).

Selection effects in our study would come through the CLASH sample definition. Our Bayesian approach aims to fully account for any such effects by incorporating the sample selection function into the analysis, and will do so to the extent that our model of the selection function is accurate. Ideally, we would like to know the sample selection function a priori. The CLASH sample selection is complex, and [Meneghetti et al. (2014)](#bib.bib32) use detailed numerical simulations to evaluate its impact on determination of the mass-concentration relation for clusters. Unfortunately, it is not straightforward to extract a selection function in terms of true halo mass from this work. We have instead opted to parameterize the CLASH selection function with the expected cosmological mass function and a smooth, but generic cutoff. By studying their relation to the other parameters, we conclude that the exact values for the selection function parameters do not significantly impact our final constraint on the SZ mass bias. This statement, however, is only as good as the generic form that we have employed for the selection function.

Our result improves on previous cluster mass calibrations by explicitly accounting for sample selection and associated uncertainties. Moreover, we consistently account for other statistical effects, such as Eddington bias, related to dispersion in the cluster observables and to their possible correlation. This is clear from our likelihood expression (Eq. [12](#S4.E12 "In 4.1 Model ‣ 4 Bayesian analysis ‣ Calibrating the Planck cluster mass scale with CLASH")), which is a convolution of the steep prior on true mass ($M\_{500}$) with the multivariate cluster observable distribution.

The Bayesian analysis also provides information on the intrinsic dispersion of the SZ proxy and lensing masses, and their correlation. In all seven cases, we find a 13-20% scatter for the lensing mass, in good agreement with expectations ([Meneghetti et al. 2014](#bib.bib32)). The estimates also indicate a 30% scatter for the SZ mass proxy, notwithstanding, it is not well constrained, and remains consistent with the $\sim 10\%$ scatter expected from simulations ([Nagai et al. 2007](#bib.bib37), e.g.,). Unfortunately, we are unable to establish a meaningful constraint on the correlation, $r$. We note that our results for the intrinsic lensing and SZ scatter masses are compatible with, respectively, the lensing and hydrostatic equilibrium scatters obtained by [Sereno & Ettori (2015)](#bib.bib58).

We find a value for the Planck SZ mass bias that is consistent with the constraints $(1-b\_{\rm SZ})=0.688\pm 0.072$ and $(1-b\_{\rm SZ})=0.76\pm 0.05$ (stat) $\pm 0.06$ (syst) reported, respectively, by the WtG and CCCP lensing programs ([von der Linden et al. 2014](#bib.bib69); [Hoekstra et al. 2015](#bib.bib17)).
This agreement holds even after the correction to the WtG and CCCP values proposed by [Battaglia et al. (2016)](#bib.bib4), apart from the most extreme cases. This is satisfying because the samples and the
lensing mass extraction methodologies differ significantly. The wide-field ground-based data for
WtG and CCCP is augmented in CLASH by deep, 16-band HST data for weak -and strong-lensing, which the
SaWLens reconstruction method combines into a single two-dimensional reconstruction. While doing so, it makes no assumption about the underlying mass distribution causing the lensing signal. This method differs to the aforementioned studies, which either rely on parametric fits or an aperture mass applied to the weak-lensing shear data only. The different mass estimates differ thus in both reconstruction methodology and input data.

The LoCuSS collaboration finds $(1-b\_{\rm SZ})=0.95\pm 0.04$, based on their sample of 50 clusters at $0.15<z<0.3$ ([Smith et al. 2016](#bib.bib61)). They show that within the uncertainties their result is consistent with both
CCCP and WtG results discussed above, when the CCCP and WtG samples are restricted to clusters at $z<0.3$. Moreover, the LoCuSS weak-lensing cluster masses for five clusters in the CLASH sample are in excellent agreement with CLASH measurements ([Okabe & Smith 2016](#bib.bib40)). This implies that $1-b\_{\rm SZ}$ may evolve with redshift. Specifically, Smith et al. found $(1-b\_{\rm SZ})=0.6\pm 0.1$ for WtG and $(1-b\_{\rm SZ})=0.7\pm 0.1$ for CCCP, both at $z>0.3$. These measurements at $z>0.3$ are fully consistent with our basic results of $(1-b\_{\rm SZ})=0.73\pm 0.10$ ($0.69\_{-0.09}^{+0.08}$), based on a sample that is dominated by clusters at $z>0.3$.

The primary motivation for all these studies is to quantify the extent of the tension between constraints from the primary CMB and cluster counts found by Planck. The greatest source of uncertainty in this tension is presently the Planck cluster mass calibration. In [Planck Collaboration et al. (2014b)](#bib.bib46); [Planck Collaboration et al. (2016b)](#bib.bib49), the mass bias is defined through the SZ signal - halo mass relation, where no bias ($b\_{\rm SZ}=0$) corresponds to the mass calibration based on XMM-Newton X-ray observations, as detailed in the appendix of [Planck Collaboration et al. (2014b)](#bib.bib46). Our definition here is based on the Planck SZ mass proxy, $M\_{\rm PL}$, described in Sect. [2.2](#S2.SS2 "2.2 Planck SZ mass proxy ‣ 2 Masses and mass proxies ‣ Calibrating the Planck cluster mass scale with CLASH"). While not immediately obvious, Appendix [A](#A1 "Appendix A Connection to the Planck SZ Cosmology Analysis ‣ Calibrating the Planck cluster mass scale with CLASH") demonstrates that the two are equivalent and that the mass bias constrained here is in fact the same as that used in the Planck cluster cosmology analyses.

Figure [6](#S7.F6 "Figure 6 ‣ 7 Conclusion ‣ Calibrating the Planck cluster mass scale with CLASH") summarizes the implications for the Planck cluster cosmology results. In it we assemble a number of recent mass calibration results and compare them to the value of $(1-b\_{\rm SZ})=0.58\pm 0.04$ required (yellow band) by the Planck primary CMB cosmology, as deduced in [Planck Collaboration et al. (2016b)](#bib.bib49) when leaving the mass bias parameter free. Measurements published before the 2013 Planck cosmology results are also included in the figure. These earlier studies do not report results in terms of the mass bias parameter, but rather the normalization of the $Y$-$M$ relation. The mass bias parameter, $(1-b\_{\rm SZ})$, is a parameterization of this amplitude that became standard afterwards when referring to the Planck cluster mass scale.

In the figure, P11 refers to the work by [Planck Collaboration et al. (2011a)](#bib.bib47) that defines the reference point where $b\_{\rm SZ}=0$. The values labeled M10 and V09 are obtained by rewriting the amplitude of the $Y$-$M$ relation of [Rozo et al. (2014b)](#bib.bib55) in terms of the $(1-b\_{\rm SZ})$ parameter. These amplitudes were derived using a self-consistent method of propagating scaling relations that has since been improved upon by [Evrard et al. (2014)](#bib.bib13). The point R09 is the predicted amplitude for $(1-b\_{\rm SZ})$ derived from the combined SZ and weak lensing signals of maxBCG galaxy clusters using the same methods of [Rozo et al. (2014b)](#bib.bib55). The R14 point corresponds to the preferred scaling relation of [Rozo et al. (2014a)](#bib.bib54), which combined the maxBCG and V09 $Y$-$M$ scaling relation, correcting the former downwards in mass by 10%, and the latter upwards in mass by 21%. These two sets of scaling relations were then combined at the likelihood level to arrive at the R14 point. The PXX point corresponds to [Planck Collaboration et al. (2014b)](#bib.bib46), who took $(1-b\_{\rm SZ})=0.8$ as their fiducial value, but adopted a top-hat systematic error budget $(1-b\_{\rm SZ})\in[0.7,1]$, delineated here by the error bars.

The WtG and CCCP points correspond to the work of [von der Linden et al. (2014)](#bib.bib69) and [Hoekstra et al. (2015)](#bib.bib17), who calibrated $(1-b\_{\rm SZ})$ based on a comparison of the SZ masses from Planck with their weak lensing mass estimates using the subsample of Planck clusters with weak lensing follow up from each of these groups. [Battaglia et al. (2016)](#bib.bib4) noted that the incomplete overlap of the cluster samples introduces a bias in the recovered $(1-b\_{\rm SZ})$ parameter (Malmquist bias), and we indicate the suggested corrections from [Battaglia et al. (2016)](#bib.bib4) in Figure [6](#S7.F6 "Figure 6 ‣ 7 Conclusion ‣ Calibrating the Planck cluster mass scale with CLASH"). The uncertainty on this correction increases the error bars. The Simet15 point comes from [Simet et al. (2017)](#bib.bib60), based on a stacked weak lensing analysis of the MCXC cluster catalog. Finally, the LoCUSS point is a $(1-b\_{SZ})$ estimate from the LoCUSS collaboration ([Smith et al. 2016](#bib.bib61)) that compares the Planck and lensing mass estimates.

The two main results from this paper are the points labeled CLASH(G) and CLASH(M), referring to the Gaussian and Meneghetti priors. Their error bars are larger than the comparable studies by WtG and CCCP because, in the Gaussian case, for instance, we have incorporated an 8% uncertainty, centered at zero, on any potential bias in lensing mass estimates. All of the mass calibrations lie above the range favored by the Planck primary CMB cosmology, although almost none of the more recent values does so with notable significance on its own. It is important to reduce the uncertainties in cluster mass calibration to obtain a more clear understanding of the existence of any tension between the cluster counts and the primary CMB constraints.

As a final note, we consider the effect of the lower reionization optical depth, $\tau$, reported by [Planck Collaboration et al. (2016a)](#bib.bib44) in an updated analysis of large angular scale polarization in Planck. The CMB determines the combination $A\_{\rm s}e^{-2\tau}$ to high precision, where $A\_{\rm s}$ is the power spectrum amplitude on large scales and is $\propto\sigma\_{8}^{2}$, assuming all other cosmological parameters are fixed. Lowering the optical depth therefore lowers $\sigma\_{8}$ from the primary CMB and moves the yellow band in Fig. [6](#S7.F6 "Figure 6 ‣ 7 Conclusion ‣ Calibrating the Planck cluster mass scale with CLASH") upwards. Taking the central value of $\tau=0.058$ given by [Planck Collaboration et al. (2016a)](#bib.bib44), we estimate that the center line of the yellow band increases by $\sim 8$% to $(1-b\_{\rm SZ})\approx 0.63$.

## 7 Conclusion

We are in the process of gaining considerable insight into the cluster mass scale thanks to recent samples of tens of clusters with high quality lensing mass determinations, now reaching statistical constraints of $\sim 10\%$. These constraints are fundamental to cluster cosmology. Fig. [6](#S7.F6 "Figure 6 ‣ 7 Conclusion ‣ Calibrating the Planck cluster mass scale with CLASH") summarizes recent determinations of the Planck cluster mass bias parameter and compares them to earlier mass bias estimates and to the value required by the Planck primary CMB cosmology.

The lensing based determinations (R09, R14, WtG, Simet, CCCP, CLASH) mostly display a coherent picture within the statistical uncertainties. While the value for $1-b\_{\rm SZ}$ reported by LoCUSS is inconsistent with ours, LoCUSS sees a strong redshift evolution in $1-b\_{\rm SZ}$, and their final $1-b\_{\rm SZ}$ value is dominated by clusters that are lower redshift than the bulk of the CLASH sample. Our result is consistent with LoCUSS for $z>0.3$, see Fig. [6](#S7.F6 "Figure 6 ‣ 7 Conclusion ‣ Calibrating the Planck cluster mass scale with CLASH"), as discussed in Sect. 3.2 of [Smith et al. (2016)](#bib.bib61). Malmquist and Eddington bias affect some of the points to an uncertain degree. [Battaglia et al. (2016)](#bib.bib4) estimated the Malmquist bias corrections on the WtG and CCCP determinations, which we indicate in the figure. Our constraint fully accounts for these, as well as astrophysical effects.

Other systematic effects may remain, however, at an important level. For example, in our study we adopted a generic form for the CLASH selection function. It would be far better to have a form that is well motivated from simulations, something that continued examination of the [Meneghetti et al. (2014)](#bib.bib32) simulations could afford. Similarly, detailed simulations are needed to evaluate the possible bias in lensing mass measurements (i.e., $b\_{\rm L}$ and $\alpha\_{\rm L}$). They must reproduce both the sample selection and the specific lensing mass extraction methodology. The technique to achieve such comprehensive simulations exists, but the studies have yet to be performed. It is important to emphasize in this light that each cluster cosmology sample must be analyzed in its own specific context.

With these recent advances we have perhaps learned more about how to calibrate the mass scale than we have actually improved understanding of the tension between the Planck primary CMB and cluster cosmology constraints. All mass scale determinations lie high relative to the preferred CMB value, although in each case the significance is low. This is also true of our measurement. In this context, it is important to note that the lower optical depth to reionization recently reported by [Planck Collaboration et al. (2016a)](#bib.bib44) shifts the yellow band in Fig. [6](#S7.F6 "Figure 6 ‣ 7 Conclusion ‣ Calibrating the Planck cluster mass scale with CLASH") upwards from a center line of $(1-b\_{\rm SZ})=0.58$ to $(1-b\_{\rm SZ})\approx 0.63$, according to our approximate calculation.

Progress in understanding is encouraging and emphasizes the importance of improving constraints beyond the current level. With such progress on relatively small samples, the future looks promising with large lensing programs like Euclid ([Laureijs et al. 2011](#bib.bib19)), WFIRST ([Spergel et al. 2013](#bib.bib62)) and the Large Synoptic Survey Telescope ([LSST Science Collaboration et al. 2009](#bib.bib22)) that will produce samples of thousands of objects thanks to their wide-field surveying. In addition, CMB lensing, already observed over large sky areas by Planck, SPT and ACT, adds a powerful and independent method for mass measurements ([Melin & Bartlett 2015](#bib.bib29); [Baxter et al. 2015](#bib.bib5); [Madhavacheril et al. 2015](#bib.bib23)). The Bayesian methodology presented here will be important to extract the full potential of these large datasets.

Figure 6: Mass bias parameter, $(1-b\_{\rm SZ})$, measured in different studies compared to the values preferred by the Planck base $\Lambda$CDM fit to the primary CMB anisotropies ([Planck Collaboration et al. 2016b](#bib.bib49)), shown as the yellow band. For reference, we translate results published before the Planck 2013 cosmological constraints became available to values for $(1-b\_{\rm SZ})$. These are P11 ([Planck Collaboration et al. 2011b](#bib.bib48)), M10, V09, R09 ([Rozo et al. 2014b](#bib.bib55)) and R14 ([Rozo et al. 2014a](#bib.bib54)). PXX is the 2013 SZ cluster cosmology analysis by Planck ([Planck Collaboration et al. 2014b](#bib.bib46)) and represents the top-hat range used as a prior in that analysis. The WtG and CCCP points are, respectively, from [von der Linden et al. (2014)](#bib.bib69) and [Hoekstra et al. (2015)](#bib.bib17), with the red arrows showing the corrections estimated by [Battaglia et al. (2016)](#bib.bib4); the error bars increase to include the uncertainty on this correction. The [Simet et al. (2017)](#bib.bib60), based on lensing stacks of the MCXC catalog, and the LoCUSS ([Smith et al. 2016](#bib.bib61)) results are reproduced as labeled. See text for details.

###### Acknowledgements.

MPL was supported by National Council for Scientific and Technological Development - Brazil (CNPq grant
202131/2014-9 and PCI/MCTIC/CBPF program). MPL and JGB thank Sandro Vitenti for valuable discussions, and Graham Smith for suggestions. ER acknowledges support from DOE grant DE-SC0015975 and from the Sloan Foundation, grant FG-2016-6443. JM has received funding from the People Programme (Marie Curie Actions) of the European Unions Seventh Framework Programme (FP7/2007-2013) under REA grant agreement number 627288.
Part of this research was carried out at the Jet Propulsion Laboratory, California Institute of Technology, under a contract with the National Aeronautics and Space Administration.

## Appendix A Connection to the Planck SZ Cosmology Analysis

The main result of this work is a constraint on the relation between a halo’s true mass $M\_{500}$
and the mass proxy $M\_{\rm SZ}$. It is not necessarily obvious how this result is related to the parameter
$b$ used in PXX, a point that we discuss in some detail here.

Let us then define a parameter $\beta$ such that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\langle\ln M\_{\rm SZ}|M\_{500}\rangle=\ln(1-\beta)+\ln M\_{500}.$ |  | (16) |

We will show that $\beta=b$, where $b$ is defined as in PXX. It is clear that it is the parameter
$\beta$ that we constrain in our analysis.

Now, PXX parameterizes the scaling relation between mass and
$Y\_{\rm SZ}$ — which we hereby denote $Y\_{b}$ for reasons that will be made apparent momentarily —
via

|  |  |  |  |
| --- | --- | --- | --- |
|  | $Y\_{b}=A(z)\left(\frac{(1-b)M\_{500}}{6\times 10^{14}\ \mbox{M}\_{\odot}}\right)^{\alpha}.$ |  | (17) |

The function $A(z)$ is a known function of redshift whose specific form is irrelevant for this work.
Likewise, $\alpha$ is some known constant whose value is irrelevant for this work.
For the discussion below, it will be convenient to define the mass $M\_{b}\equiv(1-b)M\_{500}$, so
that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $Y\_{b}=A\left(\frac{M\_{b}}{6\times 10^{14}\ \mbox{M}\_{\odot}}\right)^{\alpha}.$ |  | (18) |

Now, the detection probability of a halo of mass $M\_{500}$ in PXX is computed as follows: given $b$,
one first computes $M\_{b}$, which is to be thought of as an X-ray hydrostatic mass proxy. Since the mass
dependence of the templates used by Planck are calibrated on X-ray hydrostatic masses, these templates
are defined in terms of $M\_{b}$. That is, the integrated $Y$ profile can be expressed via

|  |  |  |  |
| --- | --- | --- | --- |
|  | $Y(R)=Y\_{b}f(R/R\_{b})$ |  | (19) |

where $f(1)=1$, and $f$ is a known function.

We contrast the above templates to how the observable $M\_{\rm SZ}$ is defined. Given an integrated SZ profile
$Y(R)$, the mass $M\_{\rm SZ}$ is given by the solution to the equation

|  |  |  |  |
| --- | --- | --- | --- |
|  | $Y(R\_{SZ})=A\left(\frac{M\_{\rm SZ}}{6\times 10^{14}\ \mbox{M}\_{\odot}}\right)^{\alpha}$ |  | (20) |

where $R\_{SZ}$ is the radius of a cluster of mass $M\_{SZ}$.

Let us then assume that a cluster of mass $M\_{SZ}$ corresponds to a cluster of mass $M\_{b}$,
so that the profile $Y(R)$ is given by equation [19](#A1.E19 "In Appendix A Connection to the Planck SZ Cosmology Analysis ‣ Calibrating the Planck cluster mass scale with CLASH"). The mass $M\_{SZ}$ is given
by the solution to:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $Y\_{b}f(R\_{SZ}/R\_{b})=A\left(\frac{M\_{\rm SZ}}{6\times 10^{14}\ \mbox{M}\_{\odot}}\right)^{\alpha}.$ |  | (21) |

Setting $M\_{\rm SZ}=M\_{b}$, one has then that $f=1$, while the right hand side reduces to the right
hand side of equation [18](#A1.E18 "In Appendix A Connection to the Planck SZ Cosmology Analysis ‣ Calibrating the Planck cluster mass scale with CLASH"). The equality is valid, and therefore $M\_{\rm SZ}=M\_{b}$ is precisely
the solution we were looking for. Since $M\_{\rm SZ}=M\_{b}$, it follows that $\beta=b$, and therefore
our analysis is directly relevant to the Planck cosmological analysis without the need to introduce
aperture corrections.
