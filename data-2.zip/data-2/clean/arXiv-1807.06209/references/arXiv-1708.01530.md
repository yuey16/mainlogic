<!-- fulltext source=arxiv_html slug=arXiv-1708.01530 fetched=2026-09-18T01:02:47+00:00 -->

# Dark Energy Survey Year 1 Results: Cosmological Constraints from Galaxy Clustering and Weak Lensing

Preprint: DES-2017-0226Preprint: FERMILAB-PUB-17-294-PPD

T. M. C. Abbott
Affiliation: Cerro Tololo Inter-American Observatory, National Optical Astronomy Observatory, Casilla 603, La Serena, Chile
  
F. B. Abdalla
Affiliation: Department of Physics and Electronics, Rhodes University, PO Box 94, Grahamstown, 6140, South Africa
Affiliation: Department of Physics & Astronomy, University College London, Gower Street, London, WC1E 6BT, UK
  
A. Alarcon
Affiliation: Institute of Space Sciences, IEEC-CSIC, Campus UAB, Carrer de Can Magrans, s/n, 08193 Barcelona, Spain
  
J. Aleksić
Affiliation: Institut de Física d’Altes Energies (IFAE), The Barcelona Institute of Science and Technology, Campus UAB, 08193 Bellaterra (Barcelona) Spain
  
S. Allam
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
S. Allen
Affiliation: Department of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305, USA
  
A. Amara
Affiliation: Department of Physics, ETH Zurich, Wolfgang-Pauli-Strasse 16, CH-8093 Zurich, Switzerland
  
J. Annis
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
J. Asorey
Affiliation: School of Mathematics and Physics, University of Queensland, Brisbane, QLD 4072, Australia
Affiliation: ARC Centre of Excellence for All-sky Astrophysics (CAASTRO)
  
S. Avila
Affiliation: Institute of Cosmology & Gravitation, University of Portsmouth, Portsmouth, PO1 3FX, UK
Affiliation: Instituto de Fisica Teorica UAM/CSIC, Universidad Autonoma de Madrid, 28049 Madrid, Spain
  
D. Bacon
Affiliation: Institute of Cosmology & Gravitation, University of Portsmouth, Portsmouth, PO1 3FX, UK
  
E. Balbinot
Affiliation: Department of Physics, University of Surrey, Guildford GU2 7XH, UK
  
M. Banerji
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, UK
Affiliation: Kavli Institute for Cosmology, University of Cambridge, Madingley Road, Cambridge CB3 0HA, UK
  
N. Banik
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
W. Barkhouse
Affiliation: University of North Dakota, Department of Physics and Astrophysics, Witmer Hall, Grand Forks, ND 58202, USA
  
M. Baumer
Affiliation: Department of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305, USA
Affiliation: Kavli Institute for Particle Astrophysics & Cosmology, P. O. Box 2450, Stanford University, Stanford, CA 94305, USA
Affiliation: SLAC National Accelerator Laboratory, Menlo Park, CA 94025, USA
  
E. Baxter
Affiliation: Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
K. Bechtol
Affiliation: LSST, 933 North Cherry Avenue, Tucson, AZ 85721, USA
  
M. R. Becker
Affiliation: Department of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305, USA
Affiliation: Kavli Institute for Particle Astrophysics & Cosmology, P. O. Box 2450, Stanford University, Stanford, CA 94305, USA
  
A. Benoit-Lévy
Affiliation: Department of Physics & Astronomy, University College London, Gower Street, London, WC1E 6BT, UK
Affiliation: CNRS, UMR 7095, Institut d’Astrophysique de Paris, F-75014, Paris, France
Affiliation: Sorbonne Universités, UPMC Univ Paris 06, UMR 7095, Institut d’Astrophysique de Paris, F-75014, Paris, France
  
B. A. Benson
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, Chicago, IL 60637, USA
  
G. M. Bernstein
Affiliation: Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
E. Bertin
Affiliation: Sorbonne Universités, UPMC Univ Paris 06, UMR 7095, Institut d’Astrophysique de Paris, F-75014, Paris, France
Affiliation: CNRS, UMR 7095, Institut d’Astrophysique de Paris, F-75014, Paris, France
  
J. Blazek
Affiliation: Institute of Physics, Laboratory of Astrophysics, École Polytechnique Fédérale de Lausanne (EPFL), Observatoire de Sauverny, 1290 Versoix, Switzerland
Affiliation: Center for Cosmology and Astro-Particle Physics, The Ohio State University, Columbus, OH 43210, USA
  
S. L. Bridle
Affiliation: Jodrell Bank Center for Astrophysics, School of Physics and Astronomy, University of Manchester, Oxford Road, Manchester, M13 9PL, UK
  
D. Brooks
Affiliation: Department of Physics & Astronomy, University College London, Gower Street, London, WC1E 6BT, UK
  
D. Brout
Affiliation: Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
E. Buckley-Geer
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
D. L. Burke
Affiliation: Kavli Institute for Particle Astrophysics & Cosmology, P. O. Box 2450, Stanford University, Stanford, CA 94305, USA
Affiliation: SLAC National Accelerator Laboratory, Menlo Park, CA 94025, USA
  
M. T. Busha
Affiliation: Kavli Institute for Particle Astrophysics & Cosmology, P. O. Box 2450, Stanford University, Stanford, CA 94305, USA
  
A. Campos
Affiliation: ICTP South American Institute for Fundamental Research
  
Instituto de Física Teórica, Universidade Estadual Paulista, São Paulo, Brazil
Affiliation: Laboratório Interinstitucional de e-Astronomia - LIneA, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
  
D. Capozzi
Affiliation: Institute of Cosmology & Gravitation, University of Portsmouth, Portsmouth, PO1 3FX, UK
  
A. Carnero Rosell
Affiliation: Laboratório Interinstitucional de e-Astronomia - LIneA, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
Affiliation: Observatório Nacional, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
  
M. Carrasco Kind
Affiliation: National Center for Supercomputing Applications, 1205 West Clark St., Urbana, IL 61801, USA
Affiliation: Department of Astronomy, University of Illinois, 1002 W. Green Street, Urbana, IL 61801, USA
  
J. Carretero
Affiliation: Institut de Física d’Altes Energies (IFAE), The Barcelona Institute of Science and Technology, Campus UAB, 08193 Bellaterra (Barcelona) Spain
  
F. J. Castander
Affiliation: Institute of Space Sciences, IEEC-CSIC, Campus UAB, Carrer de Can Magrans, s/n, 08193 Barcelona, Spain
  
R. Cawthon
Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, Chicago, IL 60637, USA
  
C. Chang
Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, Chicago, IL 60637, USA
  
N. Chen
Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, Chicago, IL 60637, USA
  
M. Childress
Affiliation: School of Physics and Astronomy, University of Southampton, Southampton, SO17 1BJ, UK
  
A. Choi
Affiliation: Center for Cosmology and Astro-Particle Physics, The Ohio State University, Columbus, OH 43210, USA
  
C. Conselice
Affiliation: University of Nottingham, School of Physics and Astronomy, Nottingham NG7 2RD, UK
  
R. Crittenden
Affiliation: Institute of Cosmology & Gravitation, University of Portsmouth, Portsmouth, PO1 3FX, UK
  
M. Crocce
Affiliation: Institute of Space Sciences, IEEC-CSIC, Campus UAB, Carrer de Can Magrans, s/n, 08193 Barcelona, Spain
  
C. E. Cunha
Affiliation: Kavli Institute for Particle Astrophysics & Cosmology, P. O. Box 2450, Stanford University, Stanford, CA 94305, USA
  
C. B. D’Andrea
Affiliation: Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
L. N. da Costa
Affiliation: Laboratório Interinstitucional de e-Astronomia - LIneA, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
Affiliation: Observatório Nacional, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
  
R. Das
Affiliation: Department of Physics, University of Michigan, Ann Arbor, MI 48109, USA
  
T. M. Davis
Affiliation: School of Mathematics and Physics, University of Queensland, Brisbane, QLD 4072, Australia
Affiliation: ARC Centre of Excellence for All-sky Astrophysics (CAASTRO)
  
C. Davis
Affiliation: Kavli Institute for Particle Astrophysics & Cosmology, P. O. Box 2450, Stanford University, Stanford, CA 94305, USA
  
J. De Vicente
Affiliation: Centro de Investigaciones Energéticas, Medioambientales y Tecnológicas (CIEMAT), Madrid, Spain
  
D. L. DePoy
Affiliation: George P. and Cynthia Woods Mitchell Institute for Fundamental Physics and Astronomy, and Department of Physics and Astronomy, Texas A&M University, College Station, TX 77843, USA
  
J. DeRose
Affiliation: Department of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305, USA
Affiliation: Kavli Institute for Particle Astrophysics & Cosmology, P. O. Box 2450, Stanford University, Stanford, CA 94305, USA
  
S. Desai
Affiliation: Department of Physics, IIT Hyderabad, Kandi, Telangana 502285, India
  
H. T. Diehl
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
J. P. Dietrich
Affiliation: Excellence Cluster Universe, Boltzmannstr. 2, 85748 Garching, Germany
Affiliation: Faculty of Physics, Ludwig-Maximilians-Universität, Scheinerstr. 1, 81679 Munich, Germany
  
S. Dodelson
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
Affiliation: Department of Physics, Carnegie Mellon University, Pittsburgh, PA 15213, USA
  
P. Doel
Affiliation: Department of Physics & Astronomy, University College London, Gower Street, London, WC1E 6BT, UK
  
A. Drlica-Wagner
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
T. F. Eifler
Affiliation: Department of Physics, California Institute of Technology, Pasadena, CA 91125, USA
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Dr., Pasadena, CA 91109, USA
  
A. E. Elliott
Affiliation: Department of Physics, The Ohio State University, Columbus, OH 43210, USA
  
F. Elsner
Affiliation: Department of Physics & Astronomy, University College London, Gower Street, London, WC1E 6BT, UK
  
J. Elvin-Poole
Affiliation: Jodrell Bank Center for Astrophysics, School of Physics and Astronomy, University of Manchester, Oxford Road, Manchester, M13 9PL, UK
  
J. Estrada
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
A. E. Evrard
Affiliation: Department of Astronomy, University of Michigan, Ann Arbor, MI 48109, USA
Affiliation: Department of Physics, University of Michigan, Ann Arbor, MI 48109, USA
  
Y. Fang
Affiliation: Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
E. Fernandez
Affiliation: Institut de Física d’Altes Energies (IFAE), The Barcelona Institute of Science and Technology, Campus UAB, 08193 Bellaterra (Barcelona) Spain
  
A. Ferté
Affiliation: Institute for Astronomy, University of Edinburgh, Edinburgh EH9 3HJ, UK
  
D. A. Finley
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
B. Flaugher
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
P. Fosalba
Affiliation: Institute of Space Sciences, IEEC-CSIC, Campus UAB, Carrer de Can Magrans, s/n, 08193 Barcelona, Spain
  
O. Friedrich
Affiliation: Universitäts-Sternwarte, Fakultät für Physik, Ludwig-Maximilians Universität München, Scheinerstr. 1, 81679 München, Germany
Affiliation: Max Planck Institute for Extraterrestrial Physics, Giessenbachstrasse, 85748 Garching, Germany
  
J. Frieman
Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, Chicago, IL 60637, USA
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
J. García-Bellido
Affiliation: Instituto de Fisica Teorica UAM/CSIC, Universidad Autonoma de Madrid, 28049 Madrid, Spain
  
M. Garcia-Fernandez
Affiliation: Centro de Investigaciones Energéticas, Medioambientales y Tecnológicas (CIEMAT), Madrid, Spain
  
M. Gatti
Affiliation: Institut de Física d’Altes Energies (IFAE), The Barcelona Institute of Science and Technology, Campus UAB, 08193 Bellaterra (Barcelona) Spain
  
E. Gaztanaga
Affiliation: Institute of Space Sciences, IEEC-CSIC, Campus UAB, Carrer de Can Magrans, s/n, 08193 Barcelona, Spain
  
D. W. Gerdes
Affiliation: Department of Physics, University of Michigan, Ann Arbor, MI 48109, USA
Affiliation: Department of Astronomy, University of Michigan, Ann Arbor, MI 48109, USA
  
T. Giannantonio
Affiliation: Universitäts-Sternwarte, Fakultät für Physik, Ludwig-Maximilians Universität München, Scheinerstr. 1, 81679 München, Germany
Affiliation: Kavli Institute for Cosmology, University of Cambridge, Madingley Road, Cambridge CB3 0HA, UK
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, UK
  
M.S.S. Gill
Affiliation: SLAC National Accelerator Laboratory, Menlo Park, CA 94025, USA
  
K. Glazebrook
Affiliation: Centre for Astrophysics & Supercomputing, Swinburne University of Technology, Victoria 3122, Australia
  
D. A. Goldstein
Affiliation: Department of Astronomy, University of California, Berkeley, 501 Campbell Hall, Berkeley, CA 94720, USA
Affiliation: Lawrence Berkeley National Laboratory, 1 Cyclotron Road, Berkeley, CA 94720, USA
  
D. Gruen
Affiliation: Einstein Fellow
Affiliation: Kavli Institute for Particle Astrophysics & Cosmology, P. O. Box 2450, Stanford University, Stanford, CA 94305, USA
Affiliation: SLAC National Accelerator Laboratory, Menlo Park, CA 94025, USA
  
R. A. Gruendl
Affiliation: Department of Astronomy, University of Illinois, 1002 W. Green Street, Urbana, IL 61801, USA
Affiliation: National Center for Supercomputing Applications, 1205 West Clark St., Urbana, IL 61801, USA
  
J. Gschwend
Affiliation: Laboratório Interinstitucional de e-Astronomia - LIneA, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
Affiliation: Observatório Nacional, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
  
G. Gutierrez
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
S. Hamilton
Affiliation: Department of Physics, University of Michigan, Ann Arbor, MI 48109, USA
  
W. G. Hartley
Affiliation: Department of Physics & Astronomy, University College London, Gower Street, London, WC1E 6BT, UK
Affiliation: Department of Physics, ETH Zurich, Wolfgang-Pauli-Strasse 16, CH-8093 Zurich, Switzerland
  
S. R. Hinton
Affiliation: School of Mathematics and Physics, University of Queensland, Brisbane, QLD 4072, Australia
  
K. Honscheid
Affiliation: Center for Cosmology and Astro-Particle Physics, The Ohio State University, Columbus, OH 43210, USA
Affiliation: Department of Physics, The Ohio State University, Columbus, OH 43210, USA
  
B. Hoyle
Affiliation: Universitäts-Sternwarte, Fakultät für Physik, Ludwig-Maximilians Universität München, Scheinerstr. 1, 81679 München, Germany
  
D. Huterer
Affiliation: Department of Physics, University of Michigan, Ann Arbor, MI 48109, USA
  
B. Jain
Affiliation: Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
D. J. James
Affiliation: Astronomy Department, University of Washington, Box 351580, Seattle, WA 98195, USA
  
M. Jarvis
Affiliation: Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
T. Jeltema
Affiliation: Santa Cruz Institute for Particle Physics, Santa Cruz, CA 95064, USA
  
M. D. Johnson
Affiliation: National Center for Supercomputing Applications, 1205 West Clark St., Urbana, IL 61801, USA
  
M. W. G. Johnson
Affiliation: National Center for Supercomputing Applications, 1205 West Clark St., Urbana, IL 61801, USA
  
T. Kacprzak
Affiliation: Department of Physics, ETH Zurich, Wolfgang-Pauli-Strasse 16, CH-8093 Zurich, Switzerland
  
S. Kent
Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, Chicago, IL 60637, USA
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
A. G. Kim
Affiliation: Lawrence Berkeley National Laboratory, 1 Cyclotron Road, Berkeley, CA 94720, USA
  
A. King
Affiliation: School of Mathematics and Physics, University of Queensland, Brisbane, QLD 4072, Australia
  
D. Kirk
Affiliation: Department of Physics & Astronomy, University College London, Gower Street, London, WC1E 6BT, UK
  
N. Kokron
Affiliation: Departamento de Física Matemática, Instituto de Física, Universidade de São Paulo, CP 66318, São Paulo, SP, 05314-970, Brazil
  
A. Kovacs
Affiliation: Institut de Física d’Altes Energies (IFAE), The Barcelona Institute of Science and Technology, Campus UAB, 08193 Bellaterra (Barcelona) Spain
  
E. Krause
Affiliation: Kavli Institute for Particle Astrophysics & Cosmology, P. O. Box 2450, Stanford University, Stanford, CA 94305, USA
  
C. Krawiec
Affiliation: Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
A. Kremin
Affiliation: Department of Physics, University of Michigan, Ann Arbor, MI 48109, USA
  
K. Kuehn
Affiliation: Australian Astronomical Observatory, North Ryde, NSW 2113, Australia
  
S. Kuhlmann
Affiliation: Argonne National Laboratory, 9700 South Cass Avenue, Lemont, IL 60439, USA
  
N. Kuropatkin
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
F. Lacasa
Affiliation: ICTP South American Institute for Fundamental Research
  
Instituto de Física Teórica, Universidade Estadual Paulista, São Paulo, Brazil
  
O. Lahav
Affiliation: Department of Physics & Astronomy, University College London, Gower Street, London, WC1E 6BT, UK
  
T. S. Li
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
A. R. Liddle
Affiliation: Institute for Astronomy, University of Edinburgh, Edinburgh EH9 3HJ, UK
  
C. Lidman
Affiliation: ARC Centre of Excellence for All-sky Astrophysics (CAASTRO)
Affiliation: Australian Astronomical Observatory, North Ryde, NSW 2113, Australia
  
M. Lima
Affiliation: Laboratório Interinstitucional de e-Astronomia - LIneA, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
Affiliation: Departamento de Física Matemática, Instituto de Física, Universidade de São Paulo, CP 66318, São Paulo, SP, 05314-970, Brazil
  
H. Lin
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
N. MacCrann
Affiliation: Department of Physics, The Ohio State University, Columbus, OH 43210, USA
Affiliation: Center for Cosmology and Astro-Particle Physics, The Ohio State University, Columbus, OH 43210, USA
  
M. A. G. Maia
Affiliation: Observatório Nacional, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
Affiliation: Laboratório Interinstitucional de e-Astronomia - LIneA, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
  
M. Makler
Affiliation: ICRA, Centro Brasileiro de Pesquisas Físicas, Rua Dr. Xavier Sigaud 150, CEP 22290-180, Rio de Janeiro, RJ, Brazil
  
M. Manera
Affiliation: Department of Physics & Astronomy, University College London, Gower Street, London, WC1E 6BT, UK
  
M. March
Affiliation: Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
J. L. Marshall
Affiliation: George P. and Cynthia Woods Mitchell Institute for Fundamental Physics and Astronomy, and Department of Physics and Astronomy, Texas A&M University, College Station, TX 77843, USA
  
P. Martini
Affiliation: Department of Astronomy, The Ohio State University, Columbus, OH 43210, USA
Affiliation: Center for Cosmology and Astro-Particle Physics, The Ohio State University, Columbus, OH 43210, USA
  
R. G. McMahon
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, UK
Affiliation: Kavli Institute for Cosmology, University of Cambridge, Madingley Road, Cambridge CB3 0HA, UK
  
P. Melchior
Affiliation: Department of Astrophysical Sciences, Princeton University, Peyton Hall, Princeton, NJ 08544, USA
  
F. Menanteau
Affiliation: National Center for Supercomputing Applications, 1205 West Clark St., Urbana, IL 61801, USA
Affiliation: Department of Astronomy, University of Illinois, 1002 W. Green Street, Urbana, IL 61801, USA
  
R. Miquel
Affiliation: Institut de Física d’Altes Energies (IFAE), The Barcelona Institute of Science and Technology, Campus UAB, 08193 Bellaterra (Barcelona) Spain
Affiliation: Institució Catalana de Recerca i Estudis Avançats, E-08010 Barcelona, Spain
  
V. Miranda
Affiliation: Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
D. Mudd
Affiliation: Department of Astronomy, The Ohio State University, Columbus, OH 43210, USA
  
J. Muir
Affiliation: Department of Physics, University of Michigan, Ann Arbor, MI 48109, USA
  
A. Möller
Affiliation: The Research School of Astronomy and Astrophysics, Australian National University, ACT 2601, Australia
Affiliation: ARC Centre of Excellence for All-sky Astrophysics (CAASTRO)
  
E. Neilsen
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
R. C. Nichol
Affiliation: Institute of Cosmology & Gravitation, University of Portsmouth, Portsmouth, PO1 3FX, UK
  
B. Nord
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
P. Nugent
Affiliation: Lawrence Berkeley National Laboratory, 1 Cyclotron Road, Berkeley, CA 94720, USA
  
R. L. C. Ogando
Affiliation: Observatório Nacional, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
Affiliation: Laboratório Interinstitucional de e-Astronomia - LIneA, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
  
A. Palmese
Affiliation: Department of Physics & Astronomy, University College London, Gower Street, London, WC1E 6BT, UK
  
J. Peacock
Affiliation: Institute for Astronomy, University of Edinburgh, Edinburgh EH9 3HJ, UK
  
H.V. Peiris
Affiliation: Department of Physics & Astronomy, University College London, Gower Street, London, WC1E 6BT, UK
  
J. Peoples
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
W.J. Percival
Affiliation: Institute of Cosmology & Gravitation, University of Portsmouth, Portsmouth, PO1 3FX, UK
  
D. Petravick
Affiliation: National Center for Supercomputing Applications, 1205 West Clark St., Urbana, IL 61801, USA
  
A. A. Plazas
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Dr., Pasadena, CA 91109, USA
  
A. Porredon
Affiliation: Institute of Space Sciences, IEEC-CSIC, Campus UAB, Carrer de Can Magrans, s/n, 08193 Barcelona, Spain
  
J. Prat
Affiliation: Institut de Física d’Altes Energies (IFAE), The Barcelona Institute of Science and Technology, Campus UAB, 08193 Bellaterra (Barcelona) Spain
  
A. Pujol
Affiliation: Institute of Space Sciences, IEEC-CSIC, Campus UAB, Carrer de Can Magrans, s/n, 08193 Barcelona, Spain
  
M. M. Rau
Affiliation: Universitäts-Sternwarte, Fakultät für Physik, Ludwig-Maximilians Universität München, Scheinerstr. 1, 81679 München, Germany
  
A. Refregier
Affiliation: Department of Physics, ETH Zurich, Wolfgang-Pauli-Strasse 16, CH-8093 Zurich, Switzerland
  
P. M. Ricker
Affiliation: Department of Astronomy, University of Illinois, 1002 W. Green Street, Urbana, IL 61801, USA
Affiliation: National Center for Supercomputing Applications, 1205 West Clark St., Urbana, IL 61801, USA
  
N. Roe
Affiliation: Lawrence Berkeley National Laboratory, 1 Cyclotron Road, Berkeley, CA 94720, USA
  
R. P. Rollins
Affiliation: Jodrell Bank Center for Astrophysics, School of Physics and Astronomy, University of Manchester, Oxford Road, Manchester, M13 9PL, UK
  
A. K. Romer
Affiliation: Department of Physics and Astronomy, Pevensey Building, University of Sussex, Brighton, BN1 9QH, UK
  
A. Roodman
Affiliation: Kavli Institute for Particle Astrophysics & Cosmology, P. O. Box 2450, Stanford University, Stanford, CA 94305, USA
Affiliation: SLAC National Accelerator Laboratory, Menlo Park, CA 94025, USA
  
R. Rosenfeld
Affiliation: ICTP South American Institute for Fundamental Research
  
Instituto de Física Teórica, Universidade Estadual Paulista, São Paulo, Brazil
Affiliation: Laboratório Interinstitucional de e-Astronomia - LIneA, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
  
A. J. Ross
Affiliation: Center for Cosmology and Astro-Particle Physics, The Ohio State University, Columbus, OH 43210, USA
  
E. Rozo
Affiliation: Department of Physics, University of Arizona, Tucson, AZ 85721, USA
  
E. S. Rykoff
Affiliation: Kavli Institute for Particle Astrophysics & Cosmology, P. O. Box 2450, Stanford University, Stanford, CA 94305, USA
Affiliation: SLAC National Accelerator Laboratory, Menlo Park, CA 94025, USA
  
M. Sako
Affiliation: Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
A. I. Salvador
Affiliation: Centro de Investigaciones Energéticas, Medioambientales y Tecnológicas (CIEMAT), Madrid, Spain
  
S. Samuroff
Affiliation: Jodrell Bank Center for Astrophysics, School of Physics and Astronomy, University of Manchester, Oxford Road, Manchester, M13 9PL, UK
  
C. Sánchez
Affiliation: Institut de Física d’Altes Energies (IFAE), The Barcelona Institute of Science and Technology, Campus UAB, 08193 Bellaterra (Barcelona) Spain
  
E. Sanchez
Affiliation: Centro de Investigaciones Energéticas, Medioambientales y Tecnológicas (CIEMAT), Madrid, Spain
  
B. Santiago
Affiliation: Instituto de Física, UFRGS, Caixa Postal 15051, Porto Alegre, RS - 91501-970, Brazil
Affiliation: Laboratório Interinstitucional de e-Astronomia - LIneA, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
  
V. Scarpine
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
R. Schindler
Affiliation: SLAC National Accelerator Laboratory, Menlo Park, CA 94025, USA
  
D. Scolnic
Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, Chicago, IL 60637, USA
  
L. F. Secco
Affiliation: Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
S. Serrano
Affiliation: Institute of Space Sciences, IEEC-CSIC, Campus UAB, Carrer de Can Magrans, s/n, 08193 Barcelona, Spain
  
I. Sevilla-Noarbe
Affiliation: Centro de Investigaciones Energéticas, Medioambientales y Tecnológicas (CIEMAT), Madrid, Spain
  
E. Sheldon
Affiliation: Brookhaven National Laboratory, Bldg 510, Upton, NY 11973, USA
  
R. C. Smith
Affiliation: Cerro Tololo Inter-American Observatory, National Optical Astronomy Observatory, Casilla 603, La Serena, Chile
  
M. Smith
Affiliation: School of Physics and Astronomy, University of Southampton, Southampton, SO17 1BJ, UK
  
J. Smith
Affiliation: Austin Peay State University, Dept. Physics-Astronomy, P.O. Box 4608 Clarksville, TN 37044, USA
  
M. Soares-Santos
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
F. Sobreira
Affiliation: Laboratório Interinstitucional de e-Astronomia - LIneA, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
Affiliation: Instituto de Física Gleb Wataghin, Universidade Estadual de Campinas, 13083-859, Campinas, SP, Brazil
  
E. Suchyta
Affiliation: Computer Science and Mathematics Division, Oak Ridge National Laboratory, Oak Ridge, TN 37831
  
G. Tarle
Affiliation: Department of Physics, University of Michigan, Ann Arbor, MI 48109, USA
  
D. Thomas
Affiliation: Institute of Cosmology & Gravitation, University of Portsmouth, Portsmouth, PO1 3FX, UK
  
M. A. Troxel
Affiliation: Department of Physics, The Ohio State University, Columbus, OH 43210, USA
Affiliation: Center for Cosmology and Astro-Particle Physics, The Ohio State University, Columbus, OH 43210, USA
  
D. L. Tucker
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
B. E. Tucker
Affiliation: ARC Centre of Excellence for All-sky Astrophysics (CAASTRO)
Affiliation: The Research School of Astronomy and Astrophysics, Australian National University, ACT 2601, Australia
  
S. A. Uddin
Affiliation: ARC Centre of Excellence for All-sky Astrophysics (CAASTRO)
Affiliation: Purple Mountain Observatory, Chinese Academy of Sciences, Nanjing, Jiangshu 210008, China
  
T. N. Varga
Affiliation: Max Planck Institute for Extraterrestrial Physics, Giessenbachstrasse, 85748 Garching, Germany
Affiliation: Universitäts-Sternwarte, Fakultät für Physik, Ludwig-Maximilians Universität München, Scheinerstr. 1, 81679 München, Germany
  
P. Vielzeuf
Affiliation: Institut de Física d’Altes Energies (IFAE), The Barcelona Institute of Science and Technology, Campus UAB, 08193 Bellaterra (Barcelona) Spain
  
V. Vikram
Affiliation: Argonne National Laboratory, 9700 South Cass Avenue, Lemont, IL 60439, USA
  
A. K. Vivas
Affiliation: Cerro Tololo Inter-American Observatory, National Optical Astronomy Observatory, Casilla 603, La Serena, Chile
  
A. R. Walker
Affiliation: Cerro Tololo Inter-American Observatory, National Optical Astronomy Observatory, Casilla 603, La Serena, Chile
  
M. Wang
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
R. H. Wechsler
Affiliation: SLAC National Accelerator Laboratory, Menlo Park, CA 94025, USA
Affiliation: Kavli Institute for Particle Astrophysics & Cosmology, P. O. Box 2450, Stanford University, Stanford, CA 94305, USA
Affiliation: Department of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305, USA
  
J. Weller
Affiliation: Excellence Cluster Universe, Boltzmannstr. 2, 85748 Garching, Germany
Affiliation: Universitäts-Sternwarte, Fakultät für Physik, Ludwig-Maximilians Universität München, Scheinerstr. 1, 81679 München, Germany
Affiliation: Max Planck Institute for Extraterrestrial Physics, Giessenbachstrasse, 85748 Garching, Germany
  
W. Wester
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
R. C. Wolf
Affiliation: Department of Physics and Astronomy, University of Pennsylvania, Philadelphia, PA 19104, USA
  
B. Yanny
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
F. Yuan
Affiliation: ARC Centre of Excellence for All-sky Astrophysics (CAASTRO)
Affiliation: The Research School of Astronomy and Astrophysics, Australian National University, ACT 2601, Australia
  
A. Zenteno
Affiliation: Cerro Tololo Inter-American Observatory, National Optical Astronomy Observatory, Casilla 603, La Serena, Chile
  
B. Zhang
Affiliation: The Research School of Astronomy and Astrophysics, Australian National University, ACT 2601, Australia
Affiliation: ARC Centre of Excellence for All-sky Astrophysics (CAASTRO)
  
Y. Zhang
Affiliation: Fermi National Accelerator Laboratory, P. O. Box 500, Batavia, IL 60510, USA
  
J. Zuntz
Affiliation: Institute for Astronomy, University of Edinburgh, Edinburgh EH9 3HJ, UK
  
Dark Energy Survey Collaboration
Thanks: For correspondence use des-publication-queries@fnal.gov

August 24, 2026

###### Abstract

We present cosmological results from a combined analysis of galaxy clustering
and weak gravitational lensing, using 1321 deg2 of $griz$ imaging data from
the first year of the Dark Energy Survey (DES Y1). We combine three two-point
functions: (i) the cosmic shear correlation function of 26 million source
galaxies in four redshift bins, (ii) the galaxy angular autocorrelation
function of 650,000 luminous red galaxies in five redshift bins, and (iii) the
galaxy-shear cross-correlation of luminous red galaxy positions and source
galaxy shears. To demonstrate the robustness of these results, we use
independent pairs of galaxy shape, photometric redshift estimation and
validation, and likelihood analysis pipelines. To prevent confirmation bias,
the bulk of the analysis was carried out while “blind” to the true results;
we describe an extensive suite of systematics checks performed and passed
during this blinded phase. The data are modeled in flat $\Lambda$CDM and
$w$CDM cosmologies, marginalizing over 20 nuisance parameters, varying 6 (for
$\Lambda$CDM) or 7 (for $w$CDM) cosmological parameters including the neutrino mass
density and including the 457 $\times$ 457 element analytic covariance matrix.
We find consistent cosmological results from these three two-point functions,
and from their combination obtain $S\_{8}\equiv\sigma\_{8}(\Omega\_{m}/0.3)^{0.5}=0.773^{+0.026}\_{-0.020}$ and $\Omega\_{m}=0.267^{+0.030}\_{-0.017}$ for $\Lambda$CDM;
for $w$CDM, we find $S\_{8}=0.782^{+0.036}\_{-0.024}$, $\Omega\_{m}=0.284^{+0.033}\_{-0.030}$, and $w=-0.82^{+0.21}\_{-0.20}$ at 68% CL. The
precision of these DES Y1 constraints rivals that from the Planck cosmic microwave
background measurements, allowing a comparison of structure in the very early
and late Universe on equal terms. Although the DES Y1 best-fit values for
$S\_{8}$ and $\Omega\_{m}$ are lower than the central values from Planck for both
$\Lambda$CDM and $w$CDM, the Bayes factor indicates that the DES Y1 and Planck data
sets are consistent with each other in the context of $\Lambda$CDM. Combining DES Y1
with Planck, Baryonic Acoustic Oscillation measurements from SDSS, 6dF, and
BOSS, and type Ia supernovae from the Joint Lightcurve Analysis (JLA) dataset,
we derive very tight constraints on cosmological parameters: $S\_{8}=0.802\pm 0.012$ and $\Omega\_{m}=0.298\pm 0.007$ in $\Lambda$CDM,
and $w=-1.00\_{-0.04}^{+0.05}$ in $w$CDM. Upcoming DES analyses will provide
more stringent tests of the $\Lambda$CDM model and extensions such as a time-varying
equation of state of dark energy or modified gravity.

## I Introduction

The discovery of cosmic acceleration [[1](#bib.bib1), [2](#bib.bib2)] established
the Cosmological Constant ($\Lambda$) [[3](#bib.bib3)] + Cold Dark
Matter ($\Lambda$CDM) model as the standard cosmological paradigm that explains a
wide variety of phenomena, from the origin and evolution of large-scale
structure to the current epoch of accelerated expansion
[[4](#bib.bib4), [5](#bib.bib5)]. The successes of $\Lambda$CDM, however, must
be balanced by its apparent implausibility: three new entities beyond the
Standard Model of particle physics — one that drove an early epoch of
inflation; another that serves as dark matter; and a third that is driving
the current epoch of acceleration — are required, none of them easily
connected to the rest of physics [[6](#bib.bib6)]. Ongoing and planned
cosmic surveys are designed to test $\Lambda$CDM and more generally to shed light
on the mechanism driving the current epoch of acceleration, be it the vacuum
energy associated with the cosmological constant, another form of dark
energy, a modification of General Relativity, or something more drastic.

The Dark Energy Survey (DES11
1
<http://www.darkenergysurvey.org/>,
[[7](#bib.bib7)]) is an on-going, five-year survey that, when completed,
will map 300 million galaxies and tens of thousands of galaxy clusters in five
filters ($grizY$) over 5000 deg2, in addition to discovering several
thousand type Ia supernovae in a 27 deg2 time-domain survey. DES will use
several cosmological probes to test $\Lambda$CDM; galaxy clustering and weak
gravitational lensing are two of the most powerful. Jointly, these
complementary probes sample the underlying matter density field through the
galaxy population and the distortion of light due to gravitational lensing.
In this paper, we use data on this combination from the first year (Y1) of DES
to constrain $\Lambda$CDM and its simplest extension—$w$CDM, having a free
parameter for the dark energy equation of state.

The spatial distribution of galaxies in the Universe, and its temporal
evolution, carry important information about the physics of the early
Universe, as well as details of structure evolution in the late Universe,
thereby testing some of the most precise predictions of $\Lambda$CDM. Indeed,
measurements of the galaxy two-point correlation function, the lowest-order
statistic describing the galaxy spatial distribution, provided early evidence
for the $\Lambda$CDM model
 [[8](#bib.bib8), [9](#bib.bib9), [10](#bib.bib10), [11](#bib.bib11), [12](#bib.bib12), [13](#bib.bib13), [14](#bib.bib14), [15](#bib.bib15), [16](#bib.bib16), [17](#bib.bib17), [18](#bib.bib18), [19](#bib.bib19)]. The
data–model comparison in this case depends upon uncertainty in the galaxy
bias  [[20](#bib.bib20)], the relation between the galaxy spatial
distribution and the theoretically predicted matter distribution.

In addition to galaxy clustering, weak gravitational lensing has become one of
the principal probes of cosmology. While the interpretation of galaxy
clustering is complicated by galaxy bias, weak lensing provides direct
measurement of the mass distribution via *cosmic shear*, the correlation
of the apparent shapes of pairs of galaxies induced by foreground large-scale
structure. Further information on the galaxy bias is provided by
*galaxy–galaxy lensing*, the cross-correlation of lens galaxy positions
and source galaxy shapes.

The shape distortions produced by gravitational lensing, while cosmologically
informative, are extremely difficult to measure, since the induced source
galaxy ellipticities are at the percent level, and a number of systematic
effects can obscure the signal. Indeed, the first detections of weak lensing
were made by cross-correlating observed shapes of source galaxies with massive
foreground lenses  [[21](#bib.bib21), [22](#bib.bib22)]. A watershed moment
came in the year 2000 when four research groups nearly simultaneously
announced the first detections of cosmic
shear [[23](#bib.bib23), [24](#bib.bib24), [25](#bib.bib25), [26](#bib.bib26)]. While
these and subsequent weak lensing measurements are also consistent with $\Lambda$CDM,
only recently have they begun to provide competitive constraints on
cosmological parameters
[[27](#bib.bib27), [28](#bib.bib28), [29](#bib.bib29), [30](#bib.bib30), [31](#bib.bib31), [32](#bib.bib32), [33](#bib.bib33), [34](#bib.bib34), [35](#bib.bib35), [36](#bib.bib36)].
Galaxy–galaxy lensing measurements have also matured to the point where their
combination with galaxy clustering breaks degeneracies between the
cosmological parameters and bias, thereby helping to constrain dark energy
[[22](#bib.bib22), [37](#bib.bib37), [38](#bib.bib38), [39](#bib.bib39), [40](#bib.bib40), [41](#bib.bib41), [42](#bib.bib42), [43](#bib.bib43), [44](#bib.bib44), [45](#bib.bib45), [46](#bib.bib46), [47](#bib.bib47), [48](#bib.bib48)].
The combination of galaxy clustering, cosmic shear, and galaxy–galaxy lensing
measurements powerfully constrains structure formation in the late universe.
As for cosmological analyses of samples of galaxy clusters [see [49](#bib.bib49), for a
review], redshift space distortions in the clustering of
galaxies [[50](#bib.bib50), and references therein] and other measurements
of late-time structure, a primary test is whether these are consistent, in the
framework of $\Lambda$CDM, with measurements from cosmic microwave background (CMB)
experiments that are chiefly sensitive to early-universe physics
[[51](#bib.bib51), [52](#bib.bib52), [53](#bib.bib53), [54](#bib.bib54)] as well
as lensing of its photons by the large-scale structures
[[55](#bib.bib55), [56](#bib.bib56), [57](#bib.bib57), e.g.].

The main purpose of this paper is to combine the information from galaxy
clustering and weak lensing, using the galaxy and shear correlation functions
as well as the galaxy-shear cross-correlation. It has been recognized for more
than a decade that such a combination contains a tremendous amount of
complementary information, as it is remarkably resilient to the presence of
nuisance parameters that describe systematic errors and non-cosmological
information
[[58](#bib.bib58), [59](#bib.bib59), [60](#bib.bib60), [61](#bib.bib61)]. It is
perhaps simplest to see that the combined analysis could separately solve for
galaxy bias and the cosmological parameters; however, it can also internally
solve for (or, self-calibrate [[62](#bib.bib62)]) the systematics
associated with photometric redshifts
[[63](#bib.bib63), [64](#bib.bib64), [65](#bib.bib65)], intrinsic alignment
[[66](#bib.bib66)], and a wide variety of other effects
[[60](#bib.bib60)]. Such a combined analysis has recently been executed
by combining the KiDS 450 deg2 weak lensing survey with two different
spectroscopic galaxy surveys [[67](#bib.bib67), [68](#bib.bib68)]. While
these multi-probe analyses still rely heavily on prior information about the
nuisance parameters, obtained through a wide variety of physical tests and
simulations, this approach does significantly mitigate potential biases due to
systematic errors and will likely become even more important as statistical
errors continue to drop. The multi-probe analyses also extract more precise
information about cosmology from the data than any single measurement could.

Previously, the DES collaboration analyzed data from the Science Verification (SV) period, which covered
139 deg2, carrying out several pathfinding analyses of galaxy clustering and
gravitational lensing, along with numerous others [[69](#bib.bib69), [70](#bib.bib70), [71](#bib.bib71), [72](#bib.bib72), [73](#bib.bib73), [74](#bib.bib74), [75](#bib.bib75), [76](#bib.bib76), [77](#bib.bib77), [78](#bib.bib78), [79](#bib.bib79), [80](#bib.bib80), [81](#bib.bib81), [48](#bib.bib48), [46](#bib.bib46), [82](#bib.bib82), [83](#bib.bib83)].
The DES Y1 data set analyzed here covers about ten times more area, albeit shallower, and provides
650,000 lens galaxies and the shapes of 26 million source
galaxies, each of them divided into redshift bins.
The lens sample comprises bright, red-sequence galaxies, which have
secure photometric redshift (photo-$z$) estimates.
We measure
three two-point functions from these data: (i) $w(\theta)$, the angular correlation function
of the lens galaxies; (ii) $\gamma\_{t}(\theta)$, the correlation of the tangential shear of sources with lens galaxy positions; and (iii)
$\xi\_{\pm}(\theta)$, the correlation functions of different components of the
ellipticities of the source galaxies. We use these measurements only on large angular scales, for
which we have verified that a relatively simple model describes the data, although
even with this restriction we must introduce twenty parameters to capture
astrophysical and measurement-related systematic uncertainties.

This paper is built upon, and uses tools and results from, eleven other papers:

* •

  Ref. [[84](#bib.bib84)], which describes the theory and parameter-fitting methodologies, including the binning and modeling of all the two point functions, the marginalization of astrophysical and measurement related uncertainties, and the ways in which we calculate the covariance matrix and obtain the ensuing parameter constraints;
* •

  Ref. [[85](#bib.bib85)], which applies this methodology to image simulations generated to mimic many aspects of the Y1 data sets;
* •

  a description of the process by which the value-added galaxy catalog (Y1 Gold) is created from the data and the tests on it
  to ensure its robustness [[86](#bib.bib86)];
* •

  a shape catalog paper, which presents the two shape catalogs
  generated using two independent techniques and the many tests
  carried out to ensure that residual systematic errors in the inferred shear estimates are sufficiently small
  for Y1 analyses [[87](#bib.bib87)];
* •

  Ref. [[88](#bib.bib88)], which describes how the redshift distributions of galaxies in these shape catalogs are estimated from their photometry, including a validation of these estimates by means of COSMOS multi-band photometry;
* •

  three papers [[89](#bib.bib89), [90](#bib.bib90), [91](#bib.bib91)] that describe the use of angular cross-correlation with samples of secure redshifts to independently validate the photometric redshift distributions of lens and source galaxies;
* •

  Ref. [[92](#bib.bib92)], which measures and derives cosmological constraints from the cosmic shear signal in the DES Y1 data and also addresses the question of whether DES lensing data are consistent with lensing results from other surveys;
* •

  Ref. [[93](#bib.bib93)], which describes galaxy–galaxy lensing results, including a wide variety of tests for systematic contamination and a cross-check on the redshift distributions of source galaxies using the scaling of the lensing signal with redshift;
* •

  Ref. [[94](#bib.bib94)], which describes the galaxy clustering statistics, including a series of tests for systematic contamination. This paper also describes updates to the redMaGiC algorithm used to select our lens galaxies and to estimate their photometric redshifts.

Armed with the above results, this paper presents the most stringent cosmological constraints from a galaxy imaging survey to date and, combined with external data, the most stringent constraints overall.

One of the guiding principles of the methods developed in these papers is *redundancy*: we use two independent shape measurement methods that are independently calibrated, several photometric redshift estimation and validation techniques, and two independent codes for predicting our signals and performing a likelihood analysis. Comparison of these, as described in the above papers, has been an important part of the verification of each step of our analysis.

The plan of the paper is as follows. §[II](#S2 "II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") gives an overview of
the data used in the analysis, while §[III](#S3 "III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") presents the
two-point statistics that contain the relevant information about cosmological
parameters. §[IV](#S4 "IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") describes the methodology used to compare these
statistics to theory, thereby extracting cosmological results. We validated
our methodology while remaining blinded to the results of the analyses; this
process is described in §[V](#S5 "V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), and some of the tests that
convinced us to unblind are recounted in
Appendix [A](#A1 "Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). §[VI](#S6 "VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") presents the cosmological results
from these three probes as measured by DES in the context of two models,
$\Lambda$CDM and $w$CDM, while §[VII](#S7 "VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") compares DES results with those from
other experiments, offering one of the most powerful tests to date of
$\Lambda$CDM. Then, we combine DES with external data sets with which it is
consistent to produce the tightest constraints yet on cosmological
parameters. Finally, we conclude in
§[VIII](#S8 "VIII Conclusions ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). Appendix [B](#A2 "Appendix B Robustness of Results ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") presents further evidence of
the robustness of our results. And Appendix [C](#A3 "Appendix C Changes to fiducial covariance ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") describes
updates in the covariance matrix calculation carried out after the first
version of this paper had been posted.

## II Data

DES uses the 570-megapixel Dark Energy Camera (DECam [[95](#bib.bib95)]), built by
the collaboration and deployed on the Cerro Tololo Inter-American Observatory
(CTIO) 4m Blanco telescope in Chile, to image the South Galactic Cap in the
$grizY$ filters. In this paper, we analyze DECam images taken from August 31,
2013 to February 9, 2014 (“DES Year 1” or Y1), covering 1786 square degrees
in griz after coaddition and before masking [[86](#bib.bib86)]. The data were processed
through the DES Data Management (DESDM) system
[[96](#bib.bib96), [97](#bib.bib97), [98](#bib.bib98), [99](#bib.bib99)], which detrends and calibrates
the raw DES images, combines individual exposures to create coadded images,
and detects and catalogs astrophysical objects. Further vetting and
subselection of the DESDM data products was performed by [[86](#bib.bib86)] to produce a
high-quality object catalog (Y1 Gold) augmented by several ancillary data
products including a star/galaxy separator. With up to 4 exposures per filter
per field in Y1, and individual $griz$ exposures of 90 sec and $Y$ exposures
of 45 sec, the characteristic 10$\sigma$ limiting magnitude for galaxies is
$g=23.4$, $r=23.2$, $i=22.5$, $z=21.8$, and $Y=20.1$ [[86](#bib.bib86)]. Additional
analyses produced catalogs of red galaxies, photometric-redshift estimates,
and galaxy shape estimates, as described below.

As noted in §[I](#S1 "I Introduction ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), we use
two samples of galaxies in the current analysis: lens
galaxies, for the angular clustering measurement, and source
galaxies, whose shapes we estimate and correlate with each other
(“cosmic shear”). The tangential shear is measured for the source galaxies about the positions
of the lens galaxies (galaxy–galaxy lensing).

### II.1 Lens Galaxies

We rely on redMaGiC galaxies for all galaxy clustering
measurements [[94](#bib.bib94)] and as the lens population for the galaxy–galaxy
lensing analysis [[93](#bib.bib93)]. They have the advantage of being easily identifiable,
relatively strongly clustered, and of having relatively small
photometric-redshift errors; they are selected using a simple
algorithm [[100](#bib.bib100)]:

1. 1.

   Fit every galaxy in the survey to a red-sequence template and
   compute the corresponding best-fit redshift $z\_{\rm red}$.
2. 2.

   Evaluate the goodness-of-fit $\chi^{2}$ of the red-sequence template and
   the galaxy luminosity, using the assigned photometric redshift.
3. 3.

   Include the galaxy in the redMaGiC catalog if and only if it is bright
   $(L\geq L\_{\rm min})$ and the red-sequence template is a good fit $(\chi^{2}\leq\chi^{2}\_{\rm max})$.

In practice, we do not specify $\chi^{2}\_{\rm max}$ but instead demand that the
resulting galaxy sample have a constant comoving density as a function of
redshift. Consequently, redMaGiC galaxy selection depends upon only two
parameters: the selected luminosity threshold, $L\_{\rm min}$, and the comoving
density, $\bar{n}$, of the sample. Of course, not all combinations of
parameters are possible: brighter galaxy samples must necessarily be less
dense.

Three separate redMaGiC samples were generated from the Y1 data, referred to
as the high-density, high-luminosity, and higher-luminosity samples. The
corresponding luminosity thresholds22
2
Here and throughout, whenever a cosmology is required, we use $\Lambda$CDM with the parameters given in Table 1 of [[84](#bib.bib84)]. and comoving densities for these samples
are, respectively, $L\_{\rm min}=0.5L\_{\*}$, $L\_{\*}$, and $1.5L\_{\*}$, and $\bar{n}=10^{-3}$,
$4\times 10^{-4}$, and $10^{-4}\ {\rm galaxies}/(h^{-1}{\rm Mpc})^{3}$, where $h\equiv H\_{0}/(100\,{\rm km}\,{\rm sec}^{-1}\,{\rm Mpc}^{-1}$) parametrizes the Hubble constant. Naturally, brighter galaxies are easier to map at higher redshifts than are the dimmer galaxies. These galaxies are placed in five nominally disjoint redshift bins. The lowest three bins $z=[(0.15-0.3),(0.3-0.45),(0.45-0.6)]$ are high-density, while the galaxies in the two highest redshift bins ($(0.6-0.75)$ and $(0.75-0.9)$) are high-luminosity and higher-luminosity, respectively. The estimated redshift distributions of these five binned lens galaxy samples are shown in the upper panel of Figure [1](#S2.F1 "Figure 1 ‣ II.2.2 Photometric redshifts ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing").

The clustering properties of these galaxies are an essential part of this
combined analysis, so great care is taken in [[94](#bib.bib94)] to ensure that the
galaxy maps are not contaminated by systematic effects. This requires the
shallowest or otherwise irregular or patchy regions of the total 1786 deg2
Y1 area to be masked, leaving a contiguous 1321 deg2 as the area for the
analysis, the region called “SPT” in [[86](#bib.bib86)]. The mask derived for
the lens sample is also applied to the source sample.

### II.2 Source Galaxies

#### II.2.1 Shapes

Gravitational lensing shear is estimated from the statistical alignment of
shapes of source galaxies, which are selected from the Y1 Gold catalog
[[86](#bib.bib86)]. In DES Y1, we measure galaxy shapes and calibrate those measurements
by two independent and different algorithms, metacalibration and im3shape, as
described in [[87](#bib.bib87)].

metacalibration [[101](#bib.bib101), [102](#bib.bib102)] measures shapes by simultaneously fitting
a 2D Gaussian model for each galaxy to the pixel data for all available $r$-, $i$-, and $z$-band exposures, convolving
with the point-spread functions (PSF) appropriate to each exposure.
This procedure is repeated on versions of these images that are artificially
sheared, i.e. de-convolved, distorted by a shear operator, and re-convolved by
a symmetrized version of the PSF. By means of these, the *response* of
the shape measurement to gravitational shear is measured from the images
themselves, an approach encoded in metacalibration.

metacalibration also includes an algorithm for calibration of shear-dependent
selection effects of galaxies, which could bias shear statistics at the few
percent level otherwise, by measuring on both unsheared and sheared images all
those galaxy properties that are used to select, bin and weight galaxies in
the catalog. Details of the practical application of these corrections to our
lensing estimators are given in
[[102](#bib.bib102), [87](#bib.bib87), [92](#bib.bib92), [93](#bib.bib93)].

im3shape estimates a galaxy shape by determining the maximum likelihood set
of parameters from fitting either a bulge or a disc model to each object’s
$r$-band observations [[103](#bib.bib103)]. The maximum likelihood fit, like
the Gaussian fit with metacalibration, provides only a biased estimator of shear. For
im3shape, this bias is calibrated using a large suite of image simulations
that resemble the DES Y1 data set closely [[87](#bib.bib87), [104](#bib.bib104)].

Potential biases in the inferred shears are quantified by multiplicative
shear-calibration parameters $m^{i}$ in each source redshift bin $i$, such that
the measured shear $\gamma^{\rm meas}=(1+m^{i})\gamma^{\rm true}$. The $m^{i}$
are free parameters in the cosmological inferences, using prior constraints on
each as determined from the extensive systematic-error analyses in [[87](#bib.bib87)].
These shear-calibration priors are listed in Table [1](#S2.T1 "Table 1 ‣ II.2.1 Shapes ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). The
overall metacalibration calibration is accurate at the level of $1.3$ percent. This
uncertainty is dominated by the impact of neighboring galaxies on shape
estimates. For tomographic measurements, the widths of the overall $m^{i}$
prior is increased to yield a per-bin uncertainty in $m^{i}$, to account
conservatively for possible correlations of $m^{i}$ between bins [[87](#bib.bib87), [88](#bib.bib88), see
appendices of]. This yields the 2.3 percent prior per
redshift bin shown in Table [1](#S2.T1 "Table 1 ‣ II.2.1 Shapes ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). The im3shape prior is
determined with 2.5 percent uncertainty for the overall sample (increased to a
3.5 percent prior per redshift bin), introduced mostly by imperfections in the
image simulations.

In both catalogs, we have applied conservative cuts, for instance on
signal-to-noise ratio and size, that reduce the number of galaxies with shape
estimates relative to the Y1 Gold input catalog significantly. For metacalibration,
we obtain 35 million galaxy shape estimates down to an $r$-band magnitude of
$\approx 23$. Of these, 26 million are inside the restricted area and redshift
bins of this analysis. Since its calibration is more secure, and its number
density is higher than that of im3shape  (see [[87](#bib.bib87)] for details on
the catalog cuts and methodology details that lead to this difference in
number density), we use the metacalibration catalog for our fiducial analysis.

Table 1: Parameters and priors44
4
The lens photo-$z$ priors changed
slightly after unblinding due to changes in the cross-correlation
analysis, as described in [[90](#bib.bib90)]; we checked that these changes did
not impact our results. used to describe the measured two-point
functions. Flat denotes a flat prior in the range given while Gauss($\mu,\sigma$) is a Gaussian prior with mean $\mu$ and width
$\sigma$. Priors for the tomographic nuisance parameters $m^{i}$ and $\Delta z^{i}$ have been widened to account for the correlation of calibration errors
between bins [[88](#bib.bib88), their appendix A]. The $\Delta z^{i}$ priors
listed are for metacalibration galaxies and BPZ photo-$z$ estimates (see
[[88](#bib.bib88)] for other combinations). The parameter $w$ is fixed to $-1$ in
the $\Lambda$CDM runs.

|  |  |
| --- | --- |
| Parameter | Prior |
| Cosmology | |
| $\Omega\_{m}$ | flat (0.1, 0.9) |
| $A\_{s}$ | flat ($5\times 10^{-10},5\times 10^{-9}$) |
| $n\_{s}$ | flat (0.87, 1.07) |
| $\Omega\_{b}$ | flat (0.03, 0.07) |
| $h$ | flat (0.55, 0.91) |
| $\Omega\_{\nu}h^{2}$ | flat($5\times 10^{-4}$,$10^{-2}$) |
| $w$ | flat ($-2$,$-0.33$) |
| Lens Galaxy Bias | |
| $b\_{i}(i=1,5)$ | flat (0.8, 3.0) |
| Intrinsic Alignment | |
| $A\_{\rm IA}(z)=A\_{\rm IA}[(1+z)/1.62]^{\eta\_{\rm IA}}$ | |
| $A\_{\rm IA}$ | flat ($-5,5$) |
| ${\eta\_{\rm IA}}$ | flat ($-5,5$) |
| Lens photo-$z$ shift (red sequence) | |
| $\Delta z^{1}\_{\rm l}$ | Gauss ($0.008,0.007$) |
| $\Delta z^{2}\_{\rm l}$ | Gauss ($-0.005,0.007$) |
| $\Delta z^{3}\_{\rm l}$ | Gauss ($0.006,0.006$) |
| $\Delta z^{4}\_{\rm l}$ | Gauss ($0.000,0.010$) |
| $\Delta z^{5}\_{\rm l}$ | Gauss ($0.000,0.010$) |
| Source photo-$z$ shift | |
| $\Delta z^{1}\_{\rm s}$ | Gauss ($-0.001,0.016$) |
| $\Delta z^{2}\_{\rm s}$ | Gauss ($-0.019,0.013$) |
| $\Delta z^{3}\_{\rm s}$ | Gauss ($+0.009,0.011$) |
| $\Delta z^{4}\_{\rm s}$ | Gauss ($-0.018,0.022$) |
| Shear calibration | |
| $m^{i}\_{{\textsc{metacalibration}}}(i=1,4)$ | Gauss ($0.012,0.023$) |
| $m^{i}\_{{\textsc{im3shape}}}(i=1,4)$ | Gauss ($0.0,0.035$) |

#### II.2.2 Photometric redshifts

Redshift probability distributions are also required for source galaxies in
cosmological inferences. For each source galaxy, the probability density that
it is at redshift $z$, $p\_{\rm BPZ}(z)$, is obtained using a modified version
of the BPZ algorithm [[105](#bib.bib105)], as detailed in [[88](#bib.bib88)].
Source galaxies are placed in one of four redshift bins, $z=[(0.2-0.43),(0.43-0.63),(0.63-0.9),(0.9-1.3)]$, based upon the mean of their $p\_{\rm BPZ}(z)$ distributions. As described in [[88](#bib.bib88)], [[92](#bib.bib92)] and [[93](#bib.bib93)],
in the case of metacalibration these bin assignments are based upon photo-$z$
estimates derived using photometric measurements made by the
metacalibration pipeline in order to allow for correction of selection effects.

We denote by $n^{i}\_{\rm PZ}(z)$ an initial estimate of the redshift
distribution of the $N^{i}$ galaxies in bin $i$ produced by randomly drawing a
redshift $z$ from the probability distribution $p\_{\rm BPZ}(z)$ of each galaxy
assigned to the bin, and then bin all these $N^{i}$ redshifts into a
histogram. For this step, we use a BPZ estimate based on the optimal flux
measurements from the multi-epoch multi-object fitting procedure (MOF)
described in [[86](#bib.bib86)].

For both the source and the lens galaxies, uncertainties in the redshift distribution are quantified by assuming that the
true redshift distribution $n^{i}(z)$ in bin $i$ is a shifted version of the photometrically derived distribution:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n^{i}(z)=n^{i}\_{\rm PZ}(z-\Delta z^{i}),$ |  | (II.1) |

with the $\Delta z^{i}$ being free
parameters in the cosmological analyses. Prior constraints on these shift parameters are derived in two ways.

First, we constrain $\Delta z^{i}$ from a matched sample of galaxies in the
COSMOS field, as detailed in [[88](#bib.bib88)]. Reliable redshift estimates for
nearly all DES-selectable galaxies in the COSMOS field are available from
30-band imaging [[106](#bib.bib106)]. We select and weight a sample of
COSMOS galaxies representative of the DES sample with successful shape
measurements based on their color, magnitude, and pre-seeing size. The mean
redshift of this COSMOS sample is our estimate of the true mean redshift of
the DES source sample, with statistical and systematic uncertainties detailed
in [[88](#bib.bib88)]. The sample variance in the best-fit $\Delta z^{i}$ from the
small COSMOS field is reduced, but not eliminated, by reweighting the COSMOS
galaxies to match the multiband flux distribution of the DES source sample.

Second, the $\Delta z^{i}$ of both lens and source samples are further
constrained by the angular cross-correlation of each with a distinct sample of
galaxies with well-determined redshifts. The $\Delta z^{i}\_{\rm l}$ for the
three lowest-redshift lens galaxy samples are constrained by cross-correlation
of redMaGiC with spectroscopic redshifts [[90](#bib.bib90)] obtained in the overlap
of DES Y1 with Stripe 82 of the Sloan Digital Sky Survey. The $\Delta z^{i}\_{\rm s}$ for the three lowest-redshift source galaxy bins are constrained by
cross-correlating the sources with the redMaGiC sample, since the redMaGiC
photometric redshifts are much more accurate and precise than those of the
sources [[89](#bib.bib89)][[91](#bib.bib91)]. The $z<0.85$ limit of the redMaGiC sample
precludes use of cross-correlation to constrain $\Delta z^{4}\_{\rm s}$, so its
prior is determined solely by the reweighted COSMOS galaxies.

For the first three source bins, both methods yield an estimate of $\Delta z^{i}\_{\rm s}$, and the two estimates are compatible, so we combine them to
obtain a joint constraint. The priors derived for both lens and source
redshifts are listed in Table [1](#S2.T1 "Table 1 ‣ II.2.1 Shapes ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). The resulting estimated
redshift distributions are shown in Figure [1](#S2.F1 "Figure 1 ‣ II.2.2 Photometric redshifts ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing").

Ref. [[88](#bib.bib88)] and Figure [20](#A2.F20 "Figure 20 ‣ Appendix B Robustness of Results ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") in Appendix [B](#A2 "Appendix B Robustness of Results ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")
demonstrate that, at the accuracy attainable in DES Y1, the precise shapes of
the $n^{i}(z)$ functions have negligible impact on the inferred cosmology as
long as the mean redshifts of every bin, parametrized by the $\Delta z^{i}$, are
allowed to vary. As a consequence, the cosmological inferences are
insensitive to the choice of photometric redshift algorithm used to establish
the initial $n^{i}\_{\rm PZ}(z)$ of the bins.

Figure 1: Estimated redshift distributions of the lens and source
galaxies used in the Y1 analysis. The shaded vertical regions define the
bins: galaxies are placed in the bin spanning their mean
photo-$z$ estimate. We show both the redshift distributions of galaxies in
each bin (colored lines) and their overall redshift distributions (black
lines). Note that source galaxies are chosen via two different pipelines
im3shape and metacalibration, so their redshift distributions and total numbers differ
(solid vs. dashed lines).

## III Two-point Measurements

We measure three sets of two-point statistics: the auto-correlation of the
positions of the redMaGiC lens galaxies, the cross-correlation of the lens
positions with the shear of the source galaxies, and the two-point correlation
of the source galaxy shear field. Each of the three classes of statistics is
measured using treecorr [[107](#bib.bib107)] in all pairs of redshift
bins of the galaxy samples and in 20 log-spaced bins of angular separation
$2.5^{\prime}<\theta<250^{\prime},$ although we exclude some of the scales and
cross-correlations from our fiducial data vector (see
[section IV](#S4 "IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")). Figures [2](#S3.F2 "Figure 2 ‣ III.2 Galaxy–galaxy lensing: 𝛾_𝑡⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") and [3](#S3.F3 "Figure 3 ‣ III.3 Cosmic shear: 𝜉_±⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") show these measurements
and our best-fit $\Lambda$CDM model.

### III.1 Galaxy Clustering: $w(\theta)$

The inhomogeneous distribution of matter in the Universe is traced by
galaxies. The overabundance of pairs at angular separation $\theta$ above that
expected in a random distribution, $w(\theta)$, is one of the simplest
measurements of galaxy clustering. It quantifies the strength and scale
dependence of the clustering of galaxies, which in turn reflects the
clustering of matter.

The upper panel of Figure [2](#S3.F2 "Figure 2 ‣ III.2 Galaxy–galaxy lensing: 𝛾_𝑡⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows the angular correlation function of
the redMaGiC galaxies in the five lens redshift bins described above. As
described in [[94](#bib.bib94)], these correlation functions were computed after
quantifying and correcting for spurious clustering induced by each of multiple
observational variables. Figure [2](#S3.F2 "Figure 2 ‣ III.2 Galaxy–galaxy lensing: 𝛾_𝑡⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows the data with the error bars
set equal to the square root of the diagonal elements of the covariance
matrix, but we note that data points in nearby angular bins are highly
correlated. Indeed, as can be seen in Figure 5 of [[84](#bib.bib84)], in the lowest
redshift bins the correlation coefficient between almost all angular bins is
close to unity; at higher redshift, the measurements are highly correlated
only over the adjacent few angular bins. The solid curve in Figure [2](#S3.F2 "Figure 2 ‣ III.2 Galaxy–galaxy lensing: 𝛾_𝑡⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")
shows the best-fit prediction from $\Lambda$CDM after fitting to all three two-point
functions. In principle, we could also use the angular cross-correlations
between galaxies in different redshift bins in the analysis, but the amount of
information in these cross-bin two-point functions is quite small and would
require substantially enlarging the covariance matrix, so we use only the
auto-correlations.

### III.2 Galaxy–galaxy lensing: $\gamma\_{t}(\theta)$

The shapes of background source galaxies are distorted by the mass associated
with foreground lenses. The characteristic distortion is a tangential
shear, with the source galaxy ellipticities oriented perpendicular to the
line connecting the foreground and background galaxies. This shear,
$\gamma\_{t}(\theta)$, is sensitive to the mass associated with the foreground
galaxies. On scales much larger than the sizes of parent halos of the
galaxies, it is proportional to the lens galaxy bias parameters $b^{i}$ in each
lens bin which quantifies the relative clumping of matter and galaxies. The
lower panels of Figure [2](#S3.F2 "Figure 2 ‣ III.2 Galaxy–galaxy lensing: 𝛾_𝑡⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") show the measurements of galaxy–galaxy
lensing in all pairs of lens-source tomographic bins, including the model
prediction for our best-fit parameters. The plots include bin pairs for which
the lenses are nominally behind the sources (those towards the upper right),
so might be expected to have zero signal. Although the signals for these bins
are expected to be small, they can still be useful in constraining the
intrinsic alignment parameters in our model (see, e.g.,
[[108](#bib.bib108)]).

Figure 2: Top panels: scaled angular correlation function, $\theta w(\theta)$, of redMaGiC galaxies in the five redshift bins in the top
panel of Figure [1](#S2.F1 "Figure 1 ‣ II.2.2 Photometric redshifts ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), from lowest (left) to highest redshift
(right) [[94](#bib.bib94)]. The solid lines are predictions from the $\Lambda$CDM model
that provides the best fit to the combined three two-point functions
presented in this paper. Bottom panels: scaled galaxy–galaxy lensing
signal, $\theta\gamma\_{t}$ (galaxy-shear correlation), measured in DES Y1 in
four source redshift bins induced by lens galaxies in five redMaGiC bins
[[93](#bib.bib93)]. Columns represent different lens redshift bins while rows represent
different source redshift bins, so e.g., bin labeled 12 is the signal from
the galaxies in the second source bin lensed by those in the first lens
bin. The solid curves are again our best-fit $\Lambda$CDM prediction. In all
panels, shaded areas display the angular scales that have been excluded from
our cosmological analysis (see §[IV](#S4 "IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")).

In [[93](#bib.bib93)], we carried out a number of null tests to ensure the robustness of
these measurements, none of which showed evidence for significant systematic
uncertainties besides the ones characterized by the nuisance parameters in
this analysis. The model fits the data well. Even the fits that appear quite
bad are misleading because of the highly off-diagonal covariance matrix. For
the nine data points in the 3–1 bin, for example, $\chi^{2}=14,$ while $\chi^{2}$
would be 30 if the off-diagonal elements were ignored.

### III.3 Cosmic shear: $\xi\_{\pm}(\theta)$

The two-point statistics that quantify correlations between the shapes of
galaxies are more complex, because they are the products of the components of
a spin-2 tensor. Therefore, a pair of two-point functions are used to capture the
relevant information: $\xi\_{+}(\theta)$ and $\xi\_{-}(\theta)$ are the sum and
difference of the products of the tangential and cross components of the
shear, measured with respect to the line connecting each
galaxy pair. For more details, see [[92](#bib.bib92)] or earlier work in
Refs [[109](#bib.bib109), [110](#bib.bib110), [111](#bib.bib111), [112](#bib.bib112), [113](#bib.bib113), [114](#bib.bib114), [115](#bib.bib115), [116](#bib.bib116)]. Figure [3](#S3.F3 "Figure 3 ‣ III.3 Cosmic shear: 𝜉_±⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")
shows these functions for different pairs of tomographic bins.

Figure 3: The cosmic shear correlation functions $\xi\_{+}$ (top
panel) and $\xi\_{-}$ (bottom panel) in DES Y1 in four source redshift
bins, including cross correlations, measured from the metacalibration shear pipeline (see [[92](#bib.bib92)] for the corresponding plot with
im3shape); pairs of numbers in the upper left of each panel indicate the redshift bins. The solid lines show predictions from our best-fit $\Lambda$CDM model from the analysis of all three two-point functions, and the shaded areas display the angular scales that are not used in our cosmological analysis (see §[IV](#S4 "IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")).

As in Figure [2](#S3.F2 "Figure 2 ‣ III.2 Galaxy–galaxy lensing: 𝛾_𝑡⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), the best-fit model prediction here includes the impact
of intrinsic alignment; the best-fit shifts in the photometric redshift
distributions; and the best-fit values of shear calibration. The
one-dimensional posteriors on all of these parameters are shown in
Figure [19](#A1.F19 "Figure 19 ‣ Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") in Appendix [A](#A1 "Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing").

## IV Analysis

### IV.1 Model

To extract cosmological information from these two-point functions, we construct a model that depends upon both cosmological parameters and astrophysical and observational nuisance parameters. The cosmological parameters govern the expansion history as well as the evolution and scale dependence of the matter clustering amplitude (as quantified, e.g., by the power spectrum). The nuisance parameters account for uncertainties in photometric redshifts, shear calibration, the bias between galaxies and mass, and the contribution of intrinsic alignment to the shear spectra. §[IV.2](#S4.SS2 "IV.2 Parameterization and Priors ‣ IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") will enumerate these parameters, and our priors on them are listed in Table [1](#S2.T1 "Table 1 ‣ II.2.1 Shapes ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). Here, we describe how the two-point functions presented in §[III](#S3 "III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") are computed in the model.

#### IV.1.1 Galaxy Clustering: $w(\theta)$

Following [[84](#bib.bib84)], we express the projected (angular) density contrast of redMaGiC galaxies in redshift bin $i$ by $\delta\_{\mathrm{g}}^{i}$, the convergence field of source tomography bin $j$ as $\kappa^{j}$, the redshift distribution of the redMaGiC/source galaxy sample in tomography bin $i$ as $n\_{\mathrm{g}/\kappa}^{i}(z)$, and the angular number densities of galaxies in this redshift bin as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bar{n}\_{\mathrm{g}/\kappa}^{i}=\int dz\;n\_{\mathrm{g}/\kappa}^{i}(z)\,.$ |  | (IV.1) |

The radial weight function for clustering in terms of the comoving radial distance $\chi$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $q\_{\delta\_{\mathrm{g}}}^{i}(k,\chi)=b^{i}\left(k,z(\chi)\right)\frac{n\_{\mathrm{g}}^{i}(z(\chi))}{\bar{n}\_{\mathrm{g}}^{i}}\frac{dz}{d\chi}\,,$ |  | (IV.2) |

with $b^{i}(k,z(\chi))$ the galaxy bias of the redMaGiC galaxies in tomographic bin $i$,
and the lensing efficiency

|  |  |  |  |
| --- | --- | --- | --- |
|  | $q\_{\kappa}^{i}(\chi)=\frac{3H\_{0}^{2}\Omega\_{m}}{2\mathrm{c}^{2}}\frac{\chi}{a(\chi)}\int\_{\chi}^{\chi\_{\mathrm{h}}}\mathrm{d}\chi^{\prime}\frac{n\_{\kappa}^{i}(z(\chi^{\prime}))dz/d\chi^{\prime}}{\bar{n}\_{\kappa}^{i}}\frac{\chi^{\prime}-\chi}{\chi^{\prime}}\,,$ |  | (IV.3) |

with $H\_{0}$ the Hubble constant, $c$ the speed of light, and $a$ the scale factor.
Under the Limber approximation [[117](#bib.bib117), [118](#bib.bib118), [119](#bib.bib119), [120](#bib.bib120)], the angular correlation function for galaxy clustering can be written as

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle w^{i}(\theta)$ | $\displaystyle=$ | $\displaystyle\int\frac{dl\,l}{2\pi}J\_{0}(l\theta)\int d\chi\,\frac{q\_{\delta\_{\mathrm{g}}}^{i}\!\!\left(\!\frac{l+1/2}{\chi},\chi\right)q\_{\delta\_{\mathrm{g}}}^{j}\!\left(\frac{l+1/2}{\chi},\chi\right)}{\chi^{2}}$ |  | (IV.4) |
|  |  |  | $\displaystyle\times P\_{\mathrm{NL}}\!\!\left(\frac{l+1/2}{\chi},z(\chi)\!\!\right)$ |  |

with $P\_{\mathrm{NL}}(k,z)$ the non-linear matter power spectrum at wave vector $k$ and redshift $z$.

The expression in Eq. ([IV.4](#S4.E4 "In IV.1.1 Galaxy Clustering: 𝑤(𝜃) ‣ IV.1 Model ‣ IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")) and the ones in Eqs. ([IV.5](#S4.E5 "In IV.1.2 Galaxy–galaxy lensing: 𝛾_𝑡⁢(𝜃) ‣ IV.1 Model ‣ IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")) and ([IV.6](#S4.E6 "In IV.1.3 Cosmic shear 𝜉_±⁢(𝜃) ‣ IV.1 Model ‣ IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"))
use the “flat-sky” approximation, which was tested against a curved sky
implementation in [[84](#bib.bib84)] for the case of galaxy clustering. Ref. [[84](#bib.bib84)] uses
the more accurate expression that sums over Legendre polynomials, and we
find that these two expressions show negligible differences over the scales
of interest.

The model power spectrum here is the fully nonlinear power spectrum in
$\Lambda$CDM or $w$CDM, which we estimate on a grid of $(k,z)$ by first running CAMB [[121](#bib.bib121)] or CLASS [[122](#bib.bib122)] to
obtain the linear spectrum and then HALOFIT [[123](#bib.bib123), [124](#bib.bib124), [125](#bib.bib125)] for the nonlinear
spectrum. The smallest angular separations for which the galaxy two-point
function measurements are used in the cosmological inference, indicated by the
boundaries of the shaded regions in the upper panels of Figure [2](#S3.F2 "Figure 2 ‣ III.2 Galaxy–galaxy lensing: 𝛾_𝑡⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"),
correspond to a comoving scale of 8$h^{-1}$ Mpc; this scale is chosen such
that modeling uncertainties in the non-linear regime cause negligible impact
on the cosmological parameters relative to their statistical errors, as shown
in [[84](#bib.bib84)] and [[92](#bib.bib92)].

As described in §VI of [[84](#bib.bib84)], we include the impact of neutrino
bias [[126](#bib.bib126), [127](#bib.bib127), [128](#bib.bib128)] when computing the angular correlation function of
galaxies. For Y1 data, this effect is below statistical uncertainties, but it
is computationally simple to implement and will be relevant for upcoming
analyses.

#### IV.1.2 Galaxy–galaxy lensing: $\gamma\_{t}(\theta)$

We model the tangential shear similarly to how we modeled the angular correlation
function. Consider the correlation of lens
galaxy positions in bin $i$ with source galaxy shear in bin $j$; on large
scales, it can be expressed as an integral over the power spectrum,

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\gamma\_{\mathrm{t}}^{ij}(\theta)$ | $\displaystyle=$ | $\displaystyle(1+m^{j})\int\frac{dl\,l}{2\pi}\,J\_{2}(l\theta)\,\int\!\!d\chi\!\frac{q\_{\delta\_{\mathrm{g}}}^{i}\!\!\left(\frac{l+1/2}{\chi},\chi\right)q\_{\kappa}^{j}(\chi)}{\chi^{2}}$ |  | (IV.5) |
|  |  |  | $\displaystyle\,\times P\_{\mathrm{NL}}\!\left(\frac{l+1/2}{\chi},z(\chi)\right)$ |  |

where $m^{j}$ is the multiplicative shear bias, and $J\_{2}$ is the 2nd-order Bessel
function. The shift parameters characterizing the photo-z uncertainties
$\Delta z^{j}\_{\rm s}$ and $\Delta z^{i}\_{\rm l}$ enter the radial weight
functions in Eqs. ([IV.2](#S4.E2 "In IV.1.1 Galaxy Clustering: 𝑤(𝜃) ‣ IV.1 Model ‣ IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")) and ([IV.3](#S4.E3 "In IV.1.1 Galaxy Clustering: 𝑤(𝜃) ‣ IV.1 Model ‣ IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")) via Eqs. ([IV.1](#S4.E1 "In IV.1.1 Galaxy Clustering: 𝑤(𝜃) ‣ IV.1 Model ‣ IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")) and
([II.1](#S2.E1 "In II.2.2 Photometric redshifts ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")). The shear signal also depends upon intrinsic alignments of the
source shapes with the tidal fields surrounding the lens galaxies; details of
our model for this effect (along with an examination of more complex models)
are given in [[84](#bib.bib84)] and in [[92](#bib.bib92)]. The smallest angular separations for
which the galaxy–galaxy lensing measurements are used in the cosmological
inference, indicated by the boundaries of the shaded regions in the lower
panels of Figure [2](#S3.F2 "Figure 2 ‣ III.2 Galaxy–galaxy lensing: 𝛾_𝑡⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), correspond to a comoving scale of 12$h^{-1}$ Mpc;
as above, this scale is chosen such that the model uncertainties in the
non-linear regime cause insignificant changes to the cosmological parameters
relative to the statistical uncertainties, as derived in  [[84](#bib.bib84)] and
verified in [[85](#bib.bib85)].

#### IV.1.3 Cosmic shear $\xi\_{\pm}(\theta)$

The cosmic shear signal is independent of galaxy bias but shares the same general form as the other sets of two-point functions.
The theoretical predictions for these shear-shear two-point functions are

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\xi\_{+/-}^{ij}(\theta)$ | $\displaystyle=$ | $\displaystyle(1+m^{i})(1+m^{j})\int\frac{dl\,l}{2\pi}\,J\_{0/4}(l\theta)$ |  | (IV.6) |
|  |  |  | $\displaystyle\hskip-14.22636pt\int d\chi\frac{q\_{\kappa}^{i}(\chi)q\_{\kappa}^{j}(\chi)}{\chi^{2}}P\_{\mathrm{NL}}\left(\frac{l+1/2}{\chi},z(\chi)\right)$ |  |

where the efficiency functions are defined above, and $J\_{0}$ and $J\_{4}$ are the
Bessel functions for $\xi\_{+}$ and $\xi\_{-}$.
Intrinsic alignment affects the cosmic shear signal, especially the low-redshift bins, and are modeled as in [[84](#bib.bib84)]. Baryons affect the matter power spectrum on small scales, and the cosmic shear signal is potentially sensitive to these uncertain baryonic effects; we restrict our analysis to the unshaded, large-scale regions shown in Figure [3](#S3.F3 "Figure 3 ‣ III.3 Cosmic shear: 𝜉_±⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") to reduce uncertainty in these effects below our measurement errors, following the analysis in [[92](#bib.bib92)].

### IV.2 Parameterization and Priors

We use these measurements from the DES Y1 data to estimate cosmological
parameters in the context of two cosmological models, $\Lambda$CDM and
$w$CDM. $\Lambda$CDM contains three energy densities in units of the critical
density: the matter, baryon, and massive neutrino energy densities, $\Omega\_{m},\Omega\_{b},$ and $\Omega\_{\nu}$. The energy density in massive neutrinos is a free
parameter but is often fixed in cosmological analyses to either zero or to a
value corresponding to the minimum allowed neutrino mass of 0.06 eV from
oscillation experiments [[129](#bib.bib129)]. We think it is more appropriate to vary
this unknown parameter, and we do so throughout the paper (except in
§[VII.4](#S7.SS4 "VII.4 Neutrino Mass ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), where we show that this does not affect our qualitative
conclusions). We split the mass equally among the three eigenstates,
hence assuming a degenerate mass hierarchy for the neutrinos. Since most other survey
analyses have fixed $\Omega\_{\nu}$, our results for the remaining parameters
will differ slightly from theirs, even when using their data.

$\Lambda$CDM has three additional free parameters: the Hubble parameter, $H\_{0}$, and
the amplitude and spectral index of the primordial scalar density
perturbations, $A\_{s}$ and $n\_{s}$. This model is based on inflation, which fairly
generically predicts a flat universe. Further when curvature is allowed to
vary in $\Lambda$CDM, it is constrained by a number of experiments to be very close
to zero. Therefore, although we plan to study the impact of curvature in
future work, in this paper we assume the universe is spatially flat, with
$\Omega\_{\Lambda}=1-\Omega\_{m}$. It is common to replace $A\_{s}$ with the RMS
amplitude of mass fluctuations on 8 $h^{-1}$ Mpc scale in linear theory,
$\sigma\_{8}$, which can be derived from the aforementioned parameters. Instead
of $\sigma\_{8}$, in this work we will focus primarily on the related parameter

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S\_{8}\equiv\sigma\_{8}\left(\frac{\Omega\_{m}}{0.3}\right)^{0.5}$ |  | (IV.7) |

since $S\_{8}$ is better constrained than $\sigma\_{8}$ and is
largely uncorrelated with $\Omega\_{m}$ in the DES parameter posterior.

We also consider the possibility that the dark energy is not a cosmological
constant. Within this $w$CDM model, the dark energy equation of state
parameter, $w$ (not to be confused with the angular correlation function
$w(\theta)$), is taken as an additional free parameter instead of being fixed
at $w=-1$ as in $\Lambda$CDM. $w$CDM thus contains 7 cosmological parameters. In
future analyses of larger DES data sets, we anticipate constraining more
extended cosmological models, e.g., those in which $w$ is allowed to vary in
time.

In addition to the cosmological parameters, our model for the data contains 20
nuisance parameters, as indicated in the lower portions of
Table [1](#S2.T1 "Table 1 ‣ II.2.1 Shapes ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). These are the nine shift parameters, $\Delta z^{i}$, for
the source and lens redshift bins, the five redMaGiC bias parameters, $b^{i}$,
the four multiplicative shear biases, $m^{i}$, and two parameters, $A\_{\rm IA}$
and ${\eta\_{\rm IA}}$, that parametrize the intrinsic alignment model.

Table [1](#S2.T1 "Table 1 ‣ II.2.1 Shapes ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") presents the priors we impose on the cosmological and
nuisance parameters in the analysis. For the cosmological parameters, we
generally adopt flat priors that span the range of values
well beyond the uncertainties reported by recent experiments. As an example,
although there are currently potentially conflicting measurements of $h$, we
choose the lower end of the prior to be 10$\sigma$ below the lower central
value from the Planck cosmic microwave background
measurement [[53](#bib.bib53)] and the upper end to be 10$\sigma$ above the
higher central value from local measurements [[130](#bib.bib130)]. In the case
of $w$CDM, we impose a physical upper bound of $w<-0.33$, as that is required
to obtain cosmic acceleration. As another example, the lower bound of the
prior on the massive neutrino density, $\Omega\_{\nu}h^{2}$, in
Table [1](#S2.T1 "Table 1 ‣ II.2.1 Shapes ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") corresponds to the experimental lower limit on the sum
of neutrino masses from oscillation experiments.

For the astrophysical parameters $b^{i}$, $A\_{\rm IA}$, and ${\eta\_{\rm IA}}$ that are
not well constrained by other analyses, we also adopt conservatively wide,
flat priors. For all of these relatively uninformative priors, the guiding
principle is that they should not impact our final results, and in particular
that the tails of the posterior parameter distributions should not lie close
to the edges of the priors55
5
The sole exception is the
intrinsic-alignment parameter ${\eta\_{\rm IA}}$ for which the posterior does hit
the edge of the (conservatively selected, given feasible IA evolution) prior; see Figure [19](#A1.F19 "Figure 19 ‣ Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")
in the Appendix [A](#A1 "Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing").. For the remaining nuisance parameters, $\Delta z^{i}$
and $m^{i}$, we adopt Gaussian priors that result from the comprehensive
analyses described in
Refs. [[88](#bib.bib88), [90](#bib.bib90), [87](#bib.bib87), [89](#bib.bib89), [91](#bib.bib91)]. The prior and
posterior distributions of these parameters are plotted in
Appendix [A](#A1 "Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") in Figure [19](#A1.F19 "Figure 19 ‣ Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing").

In evaluating the likelihood function (§[IV.3](#S4.SS3 "IV.3 Likelihood Analysis ‣ IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")), the parameters
with Gaussian priors are allowed to vary over a range roughly five times wider
than the prior; for example, the parameter that accounts for a possible shift
in the furthest lens redshift bin, $\Delta z\_{\rm l}^{5}$, has a 1-$\sigma$
uncertainty of 0.01, so it is allowed to vary over $|\Delta z\_{\rm l}^{5}|<0.05$. These sampling ranges conservatively cover the parameter
values of interest while avoiding computational problems associated with
exploring parameter ranges that are overly broad. Furthermore, overly broad
parameter ranges would distort the computation of the Bayesian evidence, which
would be problematic as we will use Bayes factors to assess the consistency of
the different two-point function measurements, consistency with external data
sets, and the need to introduce additional parameters (such as $w$) into the
analysis. We have verified that our results below are insensitive to the
prior ranges chosen.

### IV.3 Likelihood Analysis

For each data set, we sample the likelihood, assumed to be Gaussian, in the
many-dimensional parameter space:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\ln\mathcal{L}(\vec{p})=-\frac{1}{2}\sum\_{ij}\left[D\_{i}-T\_{i}(\vec{p})\right]C^{-1}{}\_{ij}\left[D\_{j}-T\_{j}(\vec{p})\right],$ |  | (IV.8) |

where $\vec{p}$ is the full set of parameters, $D\_{i}$ are the measured two-point
function data presented in Figures [2](#S3.F2 "Figure 2 ‣ III.2 Galaxy–galaxy lensing: 𝛾_𝑡⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") and [3](#S3.F3 "Figure 3 ‣ III.3 Cosmic shear: 𝜉_±⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), and $T\_{i}(\vec{p})$
are the theoretical predictions as given in Eqs. ([IV.4](#S4.E4 "In IV.1.1 Galaxy Clustering: 𝑤(𝜃) ‣ IV.1 Model ‣ IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), [IV.5](#S4.E5 "In IV.1.2 Galaxy–galaxy lensing: 𝛾_𝑡⁢(𝜃) ‣ IV.1 Model ‣ IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), [IV.6](#S4.E6 "In IV.1.3 Cosmic shear 𝜉_±⁢(𝜃) ‣ IV.1 Model ‣ IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")). The
likelihood depends upon the covariance matrix $C$ that describes how the
measurement in each angular and redshift bin is correlated with every other
measurement. Since the DES data vector contains $457$ elements, the covariance
is a symmetric $457\times 457$ matrix. We generate the covariance matrices
using CosmoLike [[131](#bib.bib131)], which computes the relevant
four-point functions in the halo model, as described in [[84](#bib.bib84)]. We also
describe there how the CosmoLike-generated covariance matrix is tested
with simulations.

Eq. ([IV.8](#S4.E8 "In IV.3 Likelihood Analysis ‣ IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")) leaves out the $\ln(\det(C))$ in the prefactor66
6
However,
this factor is important for the Bayesian evidence calculations discussed
below so is included in those calculations. and more generally neglects the
cosmological dependence of the covariance matrix. Previous
work [[132](#bib.bib132)] has shown that this dependence is likely to have a
small impact on the central value; our rough estimates of the impact of
neglecting the determinant confirm this; and — as we will show below — our
results did not change when we replaced the covariance matrix with an updated
version based on the best-fit parameters. However, as we will see, the
uncertainty in the covariance matrix leads to some lingering uncertainty in
the error bars. To form the posterior, we multiply the likelihood by the
priors, $\mathcal{P}(\vec{p})$, as given in Table [1](#S2.T1 "Table 1 ‣ II.2.1 Shapes ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing").

Parallel pipelines, CosmoSIS77
7
https://bitbucket.org/joezuntz/cosmosis/ [[133](#bib.bib133)] and CosmoLike, are used to compute the theoretical predictions and to generate
the Monte Carlo Markov Chain (MCMC) samples that map out the posterior space
leading to parameter constraints. The two sets of software use the publicly
available samplers MultiNest [[134](#bib.bib134)] and emcee [[135](#bib.bib135)]. The former provides a powerful way to
compute the Bayesian evidence described below so most of the results shown
here use CosmoSIS running MultiNest.

### IV.4 Tests on Simulations

The collaboration has produced a number of realistic mock catalogs for the DES
Y1 data set, based upon two different cosmological $N$-body simulations
(Buzzard [[136](#bib.bib136)], MICE [[137](#bib.bib137)]), which were analyzed as
described in [[85](#bib.bib85)]. We applied all the steps of the analysis on the
simulations, from measuring the relevant two-point functions to extracting
cosmological parameters. In the case of simulations, the true cosmology is
known, and [[85](#bib.bib85)] demonstrates that the analysis pipelines we use here do
indeed recover the correct cosmological parameters.

## V Blinding and Validation

The small statistical uncertainties afforded by the Y1 data set present an
opportunity to obtain improved precision on cosmological parameters, but also
a challenge to avoid confirmation biases. To preclude such biases, we followed
the guiding principle that decisions on whether the data analysis has been
successful should not be based upon whether the inferred cosmological
parameters agreed with our previous expectations. We remained blind to the
cosmological parameters implied by the data until after the analysis procedure
and estimates of uncertainties on various measurement and astrophysical
nuisance parameters were frozen.

To implement this principle, we first transformed the ellipticities $e$ in the
shear catalogs according to $\arctanh|e|\rightarrow\lambda\arctanh|e|,$ where $\lambda$ is a fixed blind random number between
0.9 and 1.1. Second, we avoided plotting the measured values and theoretical
predictions in the same figure (including simulation outputs as
“theory”). Third, when running codes that derived cosmological parameter
constraints from observed statistics, we shifted the resulting parameter
values to obscure the best-fit values and/or omitted axis labels on any plots.

These measures were all kept in place until the following criteria were satisfied:

1. 1.

   All non-cosmological systematics tests of the shear measurements were
   passed, as described in [[87](#bib.bib87)], and the priors on the multiplicative biases
   were finalized.
2. 2.

   Photo-$z$ catalogs were finalized and passed internal tests, as
   described in [[88](#bib.bib88), [89](#bib.bib89), [90](#bib.bib90), [91](#bib.bib91)].
3. 3.

   Our analysis pipelines and covariance matrices, as described in
   [[85](#bib.bib85), [84](#bib.bib84)], passed all tests, including robustness to
   intrinsic alignment and bias model assumptions.
4. 4.

   We checked that the $\Lambda$CDM constraints (on, e.g., $\Omega\_{m},\sigma\_{8}$)
   from the two different cosmic shear pipelines im3shape and metacalibration agreed. The
   pipelines were *not* tuned in any way to force agreement.
5. 5.

   $\Lambda$CDM constraints were stable when dropping the smallest angular bins
   for metacalibration cosmic shear data.
6. 6.

   Small-scale metacalibration galaxy–galaxy lensing data were consistent
   between source bins (shear-ratio test, as described in §6 of [[93](#bib.bib93)]). We
   note that while this test is performed in the nominal $\Lambda$CDM model, it is
   close to insensitive to cosmological parameters, and therefore does not
   introduce confirmation bias.

Once the above tests were satisfied, we unblinded the shear catalogs but kept
cosmological parameter values blinded while carrying out the following checks,
details of which can be found in Appendix [A](#A1 "Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"):

1. 7.

   Consistent results were obtained from the two theory/inference
   pipelines, CosmoSIS and CosmoLike.
2. 8.

   Consistent results on all cosmological parameters were obtained with the
   two shear measurement pipelines, metacalibration and im3shape.
3. 9.

   Consistent results on the cosmological parameters were obtained when we
   dropped the smallest-angular-scale components of the data vector, reducing
   our susceptibility to baryonic effects and departures from linear galaxy
   biasing. This test uses the combination of the three two-point functions
   (as opposed to from shear only as in test [5](#S5.I1.i5 "item 5 ‣ V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")).
4. 10.

   An acceptable goodness-of-fit value ($\chi^{2}$) was found between the
   data and the model produced by the best-fitting parameters. This assured us
   that the data were consistent with *some* point in the model space that
   we are constraining, while not yet revealing which part of parameter space
   that is.
5. 11.

   Parameters inferred from cosmic shear ($\xi\_{\pm}$) were consistent with
   those inferred from the combination of galaxy–galaxy lensing ($\gamma\_{t}$)
   and galaxy clustering ($w(\theta)$).

Once these tests were satisfied, we unblinded the parameter inferences. The
following minor changes to the analysis procedures or priors were made after
the unblinding: as planned before unblinding, we re-ran the MCMC chains with a
new covariance matrix calculated at the best-fit parameters of the original
analysis. This did not noticeably change the constraints (see
Figure [21](#A2.F21 "Figure 21 ‣ Appendix B Robustness of Results ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") in Appendix [B](#A2 "Appendix B Robustness of Results ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")), as expected from our
earlier tests on simulated data [[84](#bib.bib84)]. We also agreed before
unblinding that we would implement two changes after unblinding: small changes
to the photo-$z$ priors referred to in the footnote to Table [1](#S2.T1 "Table 1 ‣ II.2.1 Shapes ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"),
and fixing a bug in im3shape object blacklisting that affected $\approx 1\%$
of the footprint.

All of the above tests passed, most with reassuringly unremarkable results;
more details are given in Appendix [A](#A1 "Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing").

For test [10](#S5.I2.i10 "item 10 ‣ V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), we calculated the $\chi^{2}$ ($=-2\log L$) value of the
457 data points used in the analysis using the full covariance matrix. In
$\Lambda$CDM, the model used to fit the data has 26 free parameters, so the number of
degrees of freedom is $\nu=431$. The model is calculated at the best-fit
parameter values of the posterior distribution (i.e. the point from the
posterior sample with lowest $\chi^{2}$). Given the uncertainty on the estimates
of the covariance matrix, the formal probabilities of a $\chi^{2}$ distribution
are not applicable. We agreed to unblind as long as $\chi^{2}$ was less than 605
($\chi^{2}/\nu<1.4$). The best-fit value $\chi^{2}=497$ passes this test
88
8
In our original analysis (submitted to the arXiv in August
2017), we originally found $\chi^{2}=572$, which passed the aforementioned
criterion ($\chi^{2}<605$) with proceeding in the analysis. We have since
identified a couple of missing ingredients in our computation of the
covariance matrix, leading to the present, lower, value
$\chi^{2}=497$. While the chi squared has significantly decreased, the
cosmological constraints are nearly unchanged. Please see Appendix
[C](#A3 "Appendix C Changes to fiducial covariance ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") for more details., with $\chi^{2}/\nu=1.16.$
Considering the fact that 13 of the free parameters are nuisance parameters
with tight Gaussian priors, we will use $\nu=444,$ giving
$\chi^{2}/\nu=1.12.$

The best-fit models for the three two-point functions are over-plotted on the
data in Figures [2](#S3.F2 "Figure 2 ‣ III.2 Galaxy–galaxy lensing: 𝛾_𝑡⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") and [3](#S3.F3 "Figure 3 ‣ III.3 Cosmic shear: 𝜉_±⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), from which it is apparent that the
$\chi^{2}$ is not dominated by conspicuous outliers. Figure [4](#S5.F4 "Figure 4 ‣ V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") offers
confirmation of this, in the form of a histogram of the differences between
the best-fit theory and the data in units of the standard deviation of
individual data points. The three probes show similar values of $\chi^{2}/\nu$:
for $\xi\_{\pm}(\theta),$ $\chi^{2}=230$ for 227 data points; for
$\gamma\_{t}(\theta),$ $\chi^{2}=185$ for 176 data points;
and for $w(\theta),$ $\chi^{2}=68$ for 54 data points. A finer
division into each of the 45 individual 2-point functions shows no significant
concentration of $\chi^{2}$ in particular bin pairs. We also find that removing
all data at scales $\theta>100^{\prime}$ yields $\chi^{2}=278$ for 277 data
points ($\chi^{2}/\nu=1.05$), not a significant reduction, and also yields
no significant shift in best-fit parameters. Thus, we find that no particular
piece of our data vector dominates our $\chi^{2}$ result.

Figure 4: Histogram of the differences between the best-fit $\Lambda$CDM model
predictions and the 457 data points shown in Figures [2](#S3.F2 "Figure 2 ‣ III.2 Galaxy–galaxy lensing: 𝛾_𝑡⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") and [3](#S3.F3 "Figure 3 ‣ III.3 Cosmic shear: 𝜉_±⁢(𝜃) ‣ III Two-point Measurements ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"),
in units of the standard deviation of the individual data points. Although
the covariance matrix is not diagonal, and thus the diagonal error bars do
not tell the whole story, it is clear that there are no large outliers that
drive the fits.

Finally, for step number [11](#S5.I2.i11 "item 11 ‣ V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") in the test list near the
beginning of this Section, we examined several measures of consistency
between (i) cosmic shear and (ii) $\gamma\_{t}(\theta)+w(\theta)$ in $\Lambda$CDM. As
an initial test, we computed the mean of the 1D posterior distribution of each
of the cosmological parameters and measured the shift between (i) and (ii).
We then divided this difference by the expected standard deviation of this
difference (taking into account the estimated correlation between the
$\xi\_{\pm}$ and $\gamma\_{t}+w$ inferences), $\sigma\_{\rm diff}=[\sigma\_{\xi\_{\pm}}^{2}+\sigma\_{\gamma\_{t}w}^{2}-2\mathrm{Cov}(\xi\_{\pm},\gamma\_{t}+w)]^{1/2}$. For all parameters, these differences had absolute
value $<0.4$, indicating consistency well within measurement error.

As a second consistency check, we compared the posteriors for the nuisance
parameters from cosmic shear to those from clustering plus galaxy–galaxy
lensing, and they agreed well. We found no evidence that any of the nuisance
parameters pushes against the edge of its prior or that the nuisance
parameters for cosmic shear and $w+\gamma\_{t}$ are pushed to significantly
different values. The only mild exceptions are modest shifts in the intrinsic
alignment parameters, $A\_{\rm IA}$ and ${\eta\_{\rm IA}}$, as well as in the
second source redshift bin, $\Delta z\_{s}^{2}$. The full set of posteriors on all
20 nuisance parameters for metacalibration is shown in Figure [19](#A1.F19 "Figure 19 ‣ Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") in
Appendix [A](#A1 "Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing").

As a final test of consistency between the two sets of two-point-function
measurements, we use the Bayes factor (also called the “evidence ratio”).
The Bayes factor is used for discriminating between two hypotheses, and is the
ratio of the Bayesian evidences, $P(\vec{D}|H)$ (the probability of observing
dataset, $\vec{D}$, given hypothesis $H$) for each hypothesis. An example of
such a hypothesis is that dataset $\vec{D}$ can be described by a model $M$, in
which case the Bayesian evidence is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P(\vec{D}|H)=\int d^{N}\theta P(\vec{D}|\vec{\theta},M)P(\vec{\theta}|M)$ |  | (V.1) |

where $P(\vec{D}|\vec{\theta},M)$ is the likelihood of the data given the
model $M$ parametrized by its $N$ parameters $\vec{\theta}$, and $P(\vec{\theta}|M)$ is the prior probability distribution of those model parameters.

For two hypotheses $H\_{0}$ and $H\_{1}$, the Bayes factor is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $R=\frac{P(\vec{D}|H\_{0})}{P(\vec{D}|H\_{1})}=\frac{P(H\_{0}|\vec{D})P(H\_{1})}{P(H\_{1}|\vec{D})P(H\_{0})}$ |  | (V.2) |

where the second equality follows from Bayes’ theorem and clarifies the
meaning of the Bayes factor: if we have equal a priori belief in $H\_{0}$
and $H\_{1}$ (i.e., $P(H\_{0})=P(H\_{1})$), the Bayes factor is the ratio of the
posterior probability of $H\_{0}$ to the posterior probability of $H\_{1}$. The
Bayes factor can be interpreted in terms of odds, i.e., it implies $H\_{0}$ is
favored over $H\_{1}$ with $R:1$ odds (or disfavored if $R<1$). We will adopt
the widely used Jeffreys scale [[138](#bib.bib138)] for interpreting Bayes
factors: $3.2<R<10$ and $R>10$ are respectively considered *substantial*
and *strong* evidence for $H\_{0}$ over $H\_{1}$. Conversely, $H\_{1}$ is strongly
favored over $H\_{0}$ if $R<0.1$, and there is substantial evidence for $H\_{1}$ if
$0.1<R<0.31$.

We follow [[139](#bib.bib139)] by applying this formalism as a test for consistency
between cosmological probes. In this case, the null hypothesis, $H\_{0}$, is that the two datasets were
measured from the same universe and therefore share the same model parameters. Two probes would be judged discrepant if they strongly favor the alternative hypothesis, $H\_{1}$,
that they are measured from two different universes with different model parameters.
So the appropriate Bayes factor for judging consistency of two datasets, $D\_{1}$ and $D\_{2}$, is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $R=\frac{P\left(\vec{D}\_{1},\vec{D}\_{2}|M\right)}{P\left(\vec{D}\_{1}|M\right)P\left(\vec{D}\_{2}|M\right)}$ |  | (V.3) |

where $M$ is the model, e.g., $\Lambda$CDM or $w$CDM.
The numerator is the evidence for both datasets when model $M$ is fit to both datasets simultaneously. The denominator is the evidence for both datasets when model M is fit to both datasets individually, and therefore each dataset determines its own parameter posteriors.

Before the data were unblinded, we decided that we would combine results from
these two sets of two-point functions if the Bayes factor defined in
Eq. ([V.3](#S5.E3 "In V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")) did not suggest strong evidence for inconsistency. According to
the Jeffreys scale, our condition to combine is therefore that $R>0.1$ (since
$R<0.1$ would imply strong evidence for inconsistency). We find a Bayes
factor of $R=583$, an indication that DES Y1 cosmic shear and galaxy
clustering plus galaxy–galaxy lensing are consistent with one another in the
context of $\Lambda$CDM.

The DES Y1 data were thus validated as internally consistent and robust to our
assumptions before we gained any knowledge of the cosmological parameter
values that they imply. Any comparisons to external data were, of course,
made after the data were unblinded.

## VI DES Y1 Results: Parameter Constraints

### VI.1 $\Lambda$CDM

We first consider the $\Lambda$CDM model with six cosmological parameters. The DES data are most sensitive to two cosmological parameters, $\Omega\_{m}$ and $S\_{8}$ as defined in Eq. ([IV.7](#S4.E7 "In IV.2 Parameterization and Priors ‣ IV Analysis ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")), so for the most part we focus on constraints on these parameters.

Figure 5: $\Lambda$CDM constraints from DES Y1 on $\Omega\_{m},\sigma\_{8}$, and $S\_{8}$
from cosmic shear (green), redMaGiC galaxy clustering plus galaxy–galaxy
lensing (red), and their combination (blue). Here, and in all such 2D plots
below, the two sets of contours depict the 68% and 95% confidence levels.

Given the demonstrated consistency of cosmic shear with clustering plus
galaxy–galaxy lensing in the context of $\Lambda$CDM as noted above, we proceed to
combine the constraints from all three probes. Figure [5](#S6.F5 "Figure 5 ‣ VI.1 ΛCDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows the
constraints on $\Omega\_{m}$ and $\sigma\_{8}$ (bottom panel), and on $\Omega\_{m}$ and
the less degenerate parameter $S\_{8}$ (top panel). Constraints from cosmic
shear, galaxy clustering + galaxy–galaxy lensing, and their combination are
shown in these two-dimensional subspaces after marginalizing over the 24 other
parameters. The combined results lead to constraints

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Omega\_{m}$ | $\displaystyle=$ | $\displaystyle 0.267^{+0.030}\_{-0.017}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle S\_{8}$ | $\displaystyle=$ | $\displaystyle 0.773^{+0.026}\_{-0.020}$ |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\sigma\_{8}$ | $\displaystyle=$ | $\displaystyle 0.817\_{-0.056}^{+0.045}.$ |  | (VI.1) |

The value of $\Omega\_{m}$ is consistent with the value inferred from
either cosmic shear or clustering plus galaxy–galaxy lensing separately. We
present the resulting marginalized constraints on the cosmological parameters
in the top rows of Table [2](#S6.T2 "Table 2 ‣ VI.1 ΛCDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing").

Table 2:  68%CL marginalized cosmological constraints in
$\Lambda$CDM and $w$CDM using a variety of datasets. “DES Y1 3x2” refers to
results from combining all 3 two-point functions in DES Y1. Cells with no
entries correspond to posteriors not significantly narrower than the prior
widths. The only exception is in $w$CDM for Planck only, where the
posteriors on $h$ are shown to indicate the large values inferred in the
model without any data to break the $w-h$ degeneracy.

|  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Model | Data Sets | $\Omega\_{m}$ | $S\_{8}$ | $n\_{s}$ | $\Omega\_{b}$ | $h$ | $\sum m\_{\nu}$ (eV) (95% CL) | $w$ |
| $\Lambda$CDM | DES Y1 $\xi\_{\pm}(\theta)$ | $0.260\_{-0.037}^{+0.065}$ | $0.782\_{-0.027}^{+0.027}$ | $\ldots$ | $\ldots$ | $\ldots$ | $\ldots$ | $\ldots$ |
| $\Lambda$CDM | DES Y1 $w(\theta)+\gamma\_{t}$ | $0.288\_{-0.026}^{+0.045}$ | $0.760\_{-0.030}^{+0.033}$ | $\ldots$ | $\ldots$ | $\ldots$ | $\ldots$ | $\ldots$ |
| $\Lambda$CDM | DES Y1 3x2 | $0.267\_{-0.017}^{+0.030}$ | $0.773\_{-0.020}^{+0.026}$ | $\ldots$ | $\ldots$ | $\ldots$ | $\ldots$ | $\ldots$ |
| $\Lambda$CDM | Planck (No Lensing) | $0.334\_{-0.026}^{+0.037}$ | $0.841\_{-0.025}^{+0.027}$ | $0.958\_{-0.005}^{+0.008}$ | $0.0503\_{-0.0019}^{+0.0046}$ | $0.658\_{-0.027}^{+0.019}$ | $\ldots$ | $\ldots$ |
| $\Lambda$CDM | DES Y1 + Planck (No Lensing) | $0.297\_{-0.012}^{+0.016}$ | $0.795\_{-0.013}^{+0.020}$ | $0.972\_{-0.004}^{+0.006}$ | $0.0477\_{-0.0012}^{+0.0016}$ | $0.686\_{-0.014}^{+0.009}$ | $<0.47$ | $\ldots$ |
| $\Lambda$CDM | DES Y1 + JLA + BAO | $0.295\_{-0.014}^{+0.018}$ | $0.768\_{-0.023}^{+0.018}$ | $1.044\_{-0.087}^{+0.019}$ | $0.0516\_{-0.0080}^{+0.0050}$ | $0.672\_{-0.034}^{+0.049}$ | $\ldots$ | $\ldots$ |
| $\Lambda$CDM | Planck + JLA + BAO | $0.306\_{-0.007}^{+0.007}$ | $0.815\_{-0.013}^{+0.015}$ | $0.969\_{-0.005}^{+0.004}$ | $0.0483\_{-0.0006}^{+0.0008}$ | $0.678\_{-0.005}^{+0.007}$ | $<0.22$ | $\ldots$ |
| $\Lambda$CDM | DES Y1 + Planck + JLA + BAO | $0.298\_{-0.007}^{+0.007}$ | $0.802\_{-0.012}^{+0.012}$ | $0.973\_{-0.004}^{+0.005}$ | $0.0479\_{-0.0008}^{+0.0007}$ | $0.685\_{-0.007}^{+0.005}$ | $<0.26$ | $\ldots$ |
| $w$CDM | DES Y1 $\xi\_{\pm}(\theta)$ | $0.274\_{-0.042}^{+0.073}$ | $0.777\_{-0.038}^{+0.036}$ | $\ldots$ | $\ldots$ | $\ldots$ | $\ldots$ | $-0.99\_{-0.39}^{+0.33}$ |
| $w$CDM | DES Y1 $w(\theta)+\gamma\_{t}$ | $0.310\_{-0.036}^{+0.049}$ | $0.785\_{-0.072}^{+0.040}$ | $\ldots$ | $\ldots$ | $\ldots$ | $\ldots$ | $-0.79\_{-0.39}^{+0.22}$ |
| $w$CDM | DES Y1 3x2 | $0.284\_{-0.030}^{+0.033}$ | $0.782\_{-0.024}^{+0.036}$ | $\ldots$ | $\ldots$ | $\ldots$ | $\ldots$ | $-0.82\_{-0.20}^{+0.21}$ |
| $w$CDM | Planck (No Lensing) | $0.222\_{-0.024}^{+0.069}$ | $0.810\_{-0.036}^{+0.029}$ | $0.960\_{-0.007}^{+0.005}$ | $0.0334\_{-0.0032}^{+0.0099}$ | $0.801\_{-0.097}^{+0.045}$ | $\ldots$ | $-1.47\_{-0.22}^{+0.31}$ |
| $w$CDM | DES Y1 + Planck (No Lensing) | $0.233\_{-0.033}^{+0.025}$ | $0.775\_{-0.021}^{+0.021}$ | $0.971\_{-0.006}^{+0.004}$ | $0.0355\_{-0.0039}^{+0.0050}$ | $0.775\_{-0.040}^{+0.056}$ | $<0.65$ | $-1.35\_{-0.17}^{+0.16}$ |
| $w$CDM | Planck + JLA + BAO | $0.303\_{-0.008}^{+0.010}$ | $0.816\_{-0.013}^{+0.014}$ | $0.968\_{-0.006}^{+0.004}$ | $0.0479\_{-0.0014}^{+0.0016}$ | $0.679\_{-0.008}^{+0.013}$ | $<0.27$ | $-1.02\_{-0.05}^{+0.05}$ |
| $w$CDM | DES Y1 + Planck + JLA + BAO | $0.301\_{-0.010}^{+0.007}$ | $0.801\_{-0.012}^{+0.011}$ | $0.974\_{-0.005}^{+0.005}$ | $0.0483\_{-0.0016}^{+0.0014}$ | $0.680\_{-0.008}^{+0.013}$ | $<0.31$ | $-1.00\_{-0.04}^{+0.05}$ |

Figure 6: 68% confidence levels for $\Lambda$CDM on $S\_{8}$ and $\Omega\_{m}$
from DES Y1 (different subsets considered in the top group, black); DES Y1
with all three probes combined with other experiments (middle group, green);
and results from previous experiments (bottom group, purple). Note that
neutrino mass has been varied so, e.g., results shown for KiDS-450 were
obtained by re-analyzing their data with the neutrino mass left free. The
table includes only data sets that are publicly available so that we could
re-analyze those using the same assumptions (e.g., free neutrino mass) as
are used in our analysis of DES Y1 data.

The results shown in Figure [5](#S6.F5 "Figure 5 ‣ VI.1 ΛCDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), along with previous analyses such as
that using KiDS + GAMA data [[67](#bib.bib67)], are an important step
forward in the capability of combined probes from optical surveys to constrain
cosmological parameters. These combined constraints transform what has, for
the past decade, been a one-dimensional constraint on $S\_{8}$ (which appears
banana-shaped in the $\Omega\_{m}-\sigma\_{8}$ plane) into tight constraints on both
of these important cosmological parameters. Figure [6](#S6.F6 "Figure 6 ‣ VI.1 ΛCDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows the
DES Y1 constraints on $S\_{8}$ and $\Omega\_{m}$ along with some previous results
and in combination with external data sets, as will be discussed below. The
sizes of these parameter error bars from the combined DES Y1 probes are
comparable to those from the CMB obtained by Planck.

In addition to the cosmological parameters, these probes constrain important
astrophysical parameters. The intrinsic alignment (IA) signal is modeled to
scale as $A\_{\rm IA}(1+z)^{\eta\_{\rm IA}}$; while the data do not constrain the power
law well ($\eta\_{\rm IA}=-0.7\pm 2.2$), they are sensitive to the amplitude of the signal:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $A\_{\rm IA}=0.44^{+0.38}\_{-0.28}\qquad(95\%\ {\rm CL}).$ |  | (VI.2) |

Further strengthening evidence from the recent combined probes analysis of
KiDS [[67](#bib.bib67), [68](#bib.bib68)], this result is the strongest
evidence to date of IA in a broadly inclusive galaxy sample; previously,
significant IA measurements have come from selections of massive elliptical
galaxies, usually with spectroscopic redshifts (e.g. [[140](#bib.bib140)]). The
ability of DES data to produce such a result without spectroscopic redshifts
demonstrates the power of this combined analysis and emphasizes the importance
of modeling IA in the pursuit of accurate cosmology from weak lensing. We are
able to rule out $A\_{\rm IA}=0$ at 99.76% CL with DES alone and at
99.90% CL with the full combination of DES and external data sets. The
mean value of $A\_{\rm IA}$ is nearly the same when combining with external
data sets, suggesting that IA self-calibration has been
effective. Interestingly, the measured amplitude agrees well with a prediction
made by assuming that only red galaxies contribute to the IA signal, and then
extrapolating the IA amplitude measured from spectroscopic samples of luminous
galaxies using a realistic luminosity function and red galaxy fraction
[[84](#bib.bib84)]. Our measurement extends the diversity of galaxies with evidence of
IA, allowing more precise predictions for the behavior of the expected IA
signal.

The biases of the redMaGiC galaxy samples in the five lens bins are shown in
Figure [7](#S6.F7 "Figure 7 ‣ VI.1 ΛCDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") along with the results with fixed cosmology obtained in
[[93](#bib.bib93)] and [[94](#bib.bib94)]. The biases are measured to be
$b\_{1}=1.42^{+0.13}\_{-0.08}$,
$b\_{2}=1.65^{+0.08}\_{-0.12}$,
$b\_{3}=1.60^{+0.11}\_{-0.08}$,
$b\_{4}=1.92^{+0.14}\_{-0.10}$,
$b\_{5}=2.00^{+0.13}\_{-0.14}$.
Even when
varying a full set of cosmological parameters (including $\sigma\_{8}$, which is
quite degenerate with bias when using galaxy clustering only) and 15 other
nuisance parameters, the combined probes in DES Y1 therefore constrain bias at the ten
percent level.

Figure 7: The bias of the redMaGiC galaxy samples in the five lens bins
from three separate DES Y1 analyses. The two labeled “fixed cosmology”
use the galaxy angular correlation function $w(\theta)$ and galaxy–galaxy
lensing $\gamma\_{t}$ respectively, with cosmological parameters fixed at
best-fit values from the 3x2 analysis, as described in [[93](#bib.bib93)] and
[[94](#bib.bib94)]. The results labeled “DES Y1 - all” vary all 26 parameters
while fitting to all three two-point functions.

### VI.2 $w$CDM

A variety of theoretical alternatives to the cosmological constant have been
proposed [[6](#bib.bib6)]. For example, it could be that the cosmological
constant vanishes and that another degree of freedom, e.g., a very light
scalar field, is driving the current epoch of accelerated expansion. Here we
restrict our analysis to the simplest class of phenomenological alternatives,
models in which the dark energy density is not constant, but rather evolves
over cosmic history with a constant equation of state parameter, $w$. We
constrain $w$ by adding it as a seventh cosmological parameter. Here, too, DES
obtains interesting constraints on only a subset of the seven cosmological
parameters, so we show the constraints on the three-dimensional subspace
spanned by $\Omega\_{m}$, $S\_{8}$, and $w$. Figure [8](#S6.F8 "Figure 8 ‣ VI.2 𝑤CDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows the
constraints in this 3D space from cosmic shear and from galaxy–galaxy lensing
+ galaxy clustering. These two sets of probes agree with one another. The
consistency in the three-dimensional subspace shown in Figure [8](#S6.F8 "Figure 8 ‣ VI.2 𝑤CDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"),
along with the tests in the previous subsection, is sufficient to combine the
two sets of probes. The Bayes factor in this case was equal to 1878.
The combined constraint from all three two-point functions is also shown in
Figure [8](#S6.F8 "Figure 8 ‣ VI.2 𝑤CDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing").

Figure 8: Constraints on the three cosmological parameters $\sigma\_{8}$,
$\Omega\_{m}$, and $w$ in $w$CDM from DES Y1 after marginalizing over four other
cosmological parameters and ten (cosmic shear only) or 20 (other sets of
probes) nuisance parameters. The constraints from cosmic shear only (green);
$w(\theta)+\gamma\_{t}(\theta)$ (red); and all three two-point functions (blue) are
shown. Here and below, outlying panels show the marginalized 1D posteriors and the corresponding 68% confidence regions.

The marginalized 68% CL constraints on $w$ and on the other two cosmological parameters tightly
constrained by DES, $S\_{8}$ and $\Omega\_{M}$, are shown in
Figure [9](#S6.F9 "Figure 9 ‣ VI.2 𝑤CDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") and given numerically in Table [2](#S6.T2 "Table 2 ‣ VI.1 ΛCDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). In the next section, we revisit the question of how
consistent the DES Y1 results are with other experiments. The marginalized
constraint on $w$ from all three DES Y1 probes is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $w=-0.82^{+0.21}\_{-0.20}.$ |  | (VI.3) |

Figure 9: 68% confidence levels on three cosmological parameters
from the joint DES Y1 probes and other experiments for $w$CDM.

Finally, if one ignores any intuition or prejudice about the mechanism driving
cosmic acceleration, studying $w$CDM translates into adding an additional
parameter to describe the data. From a Bayesian point of view, the question
of whether $w$CDM is more likely than $\Lambda$CDM can again be addressed by
computing the Bayes factor.
Here the two models being compared are simpler: $\Lambda$CDM and $w$CDM. The Bayes
factor is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $R\_{w}=\frac{P(\vec{D}|w{\rm CDM})}{P(\vec{D}|\Lambda{\rm CDM})}$ |  | (VI.4) |

Values of $R\_{w}$ less than unity would imply $\Lambda$CDM is favored, while those greater than one argue that the introduction of the
additional parameter $w$ is warranted. The Bayes factor is $R\_{w}=0.39$ for
DES Y1, so although $\Lambda$CDM is slightly favored, there is no compelling evidence to favor or disfavor an additional
parameter $w$.

It is important to note that, although our result in Eq. ([VI.3](#S6.E3 "In VI.2 𝑤CDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")) is compatible with $\Lambda$CDM, the most stringent test of the model from DES Y1 is not this parameter, but rather the constraints on the parameters in the model shown in Figure [5](#S6.F5 "Figure 5 ‣ VI.1 ΛCDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") as compared with constraints on those parameters from the CMB measurements of the universe at high redshift. We turn next to that comparison.

## VII Comparison with external data

We next explore the cosmological implications of comparison and combination of
DES Y1 results with other experiments’ constraints. For the CMB, we take
constraints from Planck [[53](#bib.bib53)]. In the first subsection below, we
use only the temperature and polarization auto- and cross-spectra from Planck,
omitting the information due to lensing of the CMB that is contained in the
four-point function. The latter depends on structure and distances at late
times, and we wish in this subsection to segregate late-time information from
early-Universe observables. We use the joint TT, EE, BB and TE likelihood for
multipoles $\ell$ between 2 and 29 and the TT likelihood for $\ell$ between 30
and 2508 (commonly referred to as TT+lowP), provided by
Planck.99
9
Late-universe lensing does smooth the CMB power spectra
slightly, so these data sets are not completely independent of low
redshift information. In all cases that we have checked, use of WMAP
[[141](#bib.bib141)] data yields constraints consistent with, but weaker
than, those obtained with Planck. Recent results from the South Pole
Telescope  [[142](#bib.bib142)] favor a value of $\sigma\_{8}$ that is
2.6-$\sigma$ lower than Planck, but we have not yet tried to incorporate these
results.

We use measured angular diameter distances
from the Baryon Acoustic Oscillation (BAO) feature
by the 6dF Galaxy Survey [[143](#bib.bib143)],
the SDSS Data Release 7 Main Galaxy Sample [[144](#bib.bib144)], and BOSS Data
Release 12 [[50](#bib.bib50)], in each case extracting only the BAO
constraints. These BAO distances are all measured relative to the physical BAO
scale corresponding to the sound horizon distance $r\_{\rm d}$; therefore, dependence
of $r\_{\rm d}$ on cosmological parameters
must be included
when determining the likelihood of any cosmological model (see
[[50](#bib.bib50)] for details).
We also use measures of luminosity distances from observations of distant Type
Ia supernovae (SNe) via the Joint Lightcurve Analysis (JLA) data from
[[145](#bib.bib145)].

This set of BAO and SNe experiments has been
shown to be consistent with the $\Lambda$CDM and $w$CDM constraints from the CMB
[[51](#bib.bib51), [53](#bib.bib53)], so we can therefore sensibly merge this
suite of experiments—BAO, SNe, and Planck—with the DES Y1 results to
obtain unprecedented precision on the cosmological parameters. We do not
include information about direct measurements of the Hubble constant because
those are in tension with this bundle of experiments [[146](#bib.bib146)].

### VII.1 High redshift vs. low redshift in $\Lambda$CDM

The CMB measures the state of the Universe when it was 380,000 years old,
while DES measures the matter distribution in the Universe roughly ten billion
years later. Therefore, one obvious question that we can address is: Is the
$\Lambda$CDM prediction for clustering today, with all cosmological parameters
determined by Planck, consistent with what DES observes? This question, which
has of course been addressed by previous surveys (e.g.,
[[31](#bib.bib31), [35](#bib.bib35), [67](#bib.bib67), [68](#bib.bib68)]), is
so compelling because (i) of the vast differences in the epochs and conditions
measured; (ii) the predictions for the DES Y1 values of $S\_{8}$ and $\Omega\_{m}$
have no free parameters in $\Lambda$CDM once the recombination-era parameters are
fixed; and (iii) those predictions for what DES should observe are very
precise, with $S\_{8}$ and $\Omega\_{m}$ determined by the CMB to within a few
percent. We saw above that $S\_{8}$ and $\Omega\_{m}$ are constrained by DES Y1 at
the few-percent level, so the stage is set for the most stringent test yet of
$\Lambda$CDM growth predictions. Tension between these two sets of constraints
might imply the breakdown of $\Lambda$CDM.

Figure [10](#S7.F10 "Figure 10 ‣ VII.1 High redshift vs. low redshift in ΛCDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") compares the low-$z$ constraints for $\Lambda$CDM from all three
DES Y1 probes with the $z=1100$ constraints from the Planck anisotropy
data. Note that the Planck contours are shifted slightly and widened
significantly from those in Figure 18 of [[53](#bib.bib53)], because we are
marginalizing over the unknown sum of the neutrino masses. We have verified
that when the sum of the neutrino masses is fixed as [[53](#bib.bib53)]
assumed in their fiducial analysis, we recover the constraints shown in their
Figure 18.

Figure 10: $\Lambda$CDM constraints from the three combined probes in DES Y1
(blue), Planck with no lensing (green), and their combination (red). The
agreement between DES and Planck can be quantified via the Bayes factor,
which indicates that in the full, multi-dimensional parameter space, the two
data sets are consistent (see text).

The two-dimensional constraints shown in Figure [10](#S7.F10 "Figure 10 ‣ VII.1 High redshift vs. low redshift in ΛCDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") visually hint at
tension between the Planck $\Lambda$CDM prediction for RMS mass fluctuations and the
matter density of the present-day Universe and the direct determination by
DES. The 1D marginal constraints differ by more than 1$\sigma$ in both $S\_{8}$
and $\Omega\_{m}$, as shown in Figure [6](#S6.F6 "Figure 6 ‣ VI.1 ΛCDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). The KiDS
survey [[35](#bib.bib35), [147](#bib.bib147), [67](#bib.bib67), [68](#bib.bib68)]
and, earlier, Canada-France Hawaii Telescope Lensing Survey (CHFTLenS;
[[31](#bib.bib31), [148](#bib.bib148)]) also report lower $S\_{8}$ than Planck at
marginal significance.

However, a more quantitative measure of consistency in the full 26-parameter
space is the Bayes factor defined in Eq. ([V.3](#S5.E3 "In V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")). As mentioned above, a
Bayes factor below 0.1 suggests strong inconsistency and one above 10 suggests
strong evidence for consistency. The Bayes factor for combining DES and
Planck (no lensing) in the $\Lambda$CDM model is $R=6.6$,
indicating “substantial” evidence for consistency on the Jeffreys scale, so
any inconsistency apparent in Figure [10](#S7.F10 "Figure 10 ‣ VII.1 High redshift vs. low redshift in ΛCDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") is not statistically
significant according to this metric. In order to test the sensitivity of this
conclusion to the priors used in our analysis, we halve the width of the prior
ranges on all cosmological parameters (the parameters in the first section of
Table [1](#S2.T1 "Table 1 ‣ II.2.1 Shapes ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")). For this case we find $R=0.75$; despite
dropping by nearly a factor of 10, $R$ it is still above 0.1 and therefore we are
still passing the consistency test. The Bayes factor in Eq. ([V.3](#S5.E3 "In V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")) compares
the hypothesis that two datasets can be fit by the same set of $N$ model
parameters (the null hypothesis), to the hypothesis that they are each allowed
an independent set of the $N$ model parameters (the alternative
hypothesis). The alternative hypothesis is naturally penalized in the Bayes
factor since the model requires an extra $N$ parameters. We also test an
alternative hypothesis where only $\Omega\_{m}$ and $A\_{s}$ are allowed to be
constrained independently by the two datasets; in this case we are introducing
only two extra parameters with respect to the null hypothesis. For this case,
we find $R=0.47$, which again indicates that there is no evidence for
inconsistency between the datasets.

We therefore combine the two data sets, resulting in the red contours in
Figure [10](#S7.F10 "Figure 10 ‣ VII.1 High redshift vs. low redshift in ΛCDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). This quantitative conclusion that the high– and low–
redshift data sets are consistent can even be gleaned by viewing
Figure  [10](#S7.F10 "Figure 10 ‣ VII.1 High redshift vs. low redshift in ΛCDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") in a slightly different way: if the true parameters lie
within the red contours, it is not unlikely for two independent experiments to
return the blue and green contour regions.

Figure 11: $\Lambda$CDM constraints from high redshift (Planck, without lensing)
and multiple low redshift experiments (DES Y1+BAO+JLA), see text for
references.

Figure [11](#S7.F11 "Figure 11 ‣ VII.1 High redshift vs. low redshift in ΛCDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") takes the high-$z$ vs. low-$z$ comparison a step further by
combining DES Y1 with results from BAO experiments and Type Ia supernovae. While these
even tighter low-redshift constraints continue to
favor slightly lower values of $\Omega\_{m}$ and $S\_{8}$ than Planck, the Bayes
factor
is 0.6, which neither favors nor disfavors the hypothesis that the two
sets of data, DES Y1+BAO+JLA on one hand and Planck on the other, are
described by the same set of cosmological parameters.

Figure 12: $\Lambda$CDM constraints from Planck with no lensing (green), DES Y1
(blue) and the two combined (red) in the $\Omega\_{m},h$ plane. The positions
of the acoustic peaks in the CMB constrain $\Omega\_{m}h^{3}$ extremely well, and
the DES determination of $\Omega\_{m}$ breaks the degeneracy, leading to a
larger value of $h$ than inferred from Planck only (see
Table [2](#S6.T2 "Table 2 ‣ VI.1 ΛCDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")).

The goal of this subsection is to test the $\Lambda$CDM prediction for clustering in
DES, so we defer the issue of parameter determination to the next
subsections. However, there is one aspect of the CMB measurements combined
with DES that is worth mentioning here. DES data do not constrain the Hubble
constant directly. However, as shown in Figure [12](#S7.F12 "Figure 12 ‣ VII.1 High redshift vs. low redshift in ΛCDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), the DES
$\Lambda$CDM constraint on $\Omega\_{m}$ combined with Planck’s measurement of
$\Omega\_{m}h^{3}$ leads to a shift in the inference of the Hubble constant (in the
direction of local measurements [[130](#bib.bib130)]). Since $\Omega\_{m}$ is
lower in DES, the inferred value of $h$ moves up. As shown in the figure and
quantitatively in Table [2](#S6.T2 "Table 2 ‣ VI.1 ΛCDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), the shift is greater than
$1\sigma$. As shown in Table [2](#S6.T2 "Table 2 ‣ VI.1 ΛCDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), this shift in the value of $h$
persists as more data sets are added in.

### VII.2 Cosmological Parameters in $\Lambda$CDM

To obtain the most stringent cosmological constraints, we now compare DES Y1
with the bundle of BAO, Planck, and JLA that have been shown to be consistent
with one another [[53](#bib.bib53)]. Here “Planck” includes the data from
the four-point function of the CMB, which captures the effect of lensing due
to large-scale structure at late times. Figure [13](#S7.F13 "Figure 13 ‣ VII.2 Cosmological Parameters in ΛCDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows the
constraints in the $\Omega\_{m}$–$S\_{8}$ plane from this bundle of data sets and
from DES Y1, in the $\Lambda$CDM model. Here the apparent consistency of the data
sets is borne out by the Bayes factor for dataset consistency
(Eq. [V.3](#S5.E3 "In V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{P({\rm JLA+Planck+BAO+DES\ Y1})}{P({\rm JLA+BAO+Planck})P({\rm DES\ Y1})}=35.$ |  | (VII.1) |

Figure 13: $\Lambda$CDM constraints from all three two-point functions within DES
and BAO, JLA, and Planck (with lensing) in the $\Omega\_{m}$-$S\_{8}$ plane.

Combining all of these leads to the tightest constraints yet on
$\Lambda$CDM parameters, shown in Table  [2](#S6.T2 "Table 2 ‣ VI.1 ΛCDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). Highlighting some of these:
at 68% C.L., the combination of DES with these external data sets yields

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Omega\_{m}=0.298\pm 0.007.$ |  | (VII.2) |

This value is about 1$\sigma$ lower than the value without DES Y1, with comparable error bars. The clustering amplitude is also constrained at the percent level:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\sigma\_{8}$ | $\displaystyle=$ | $\displaystyle 0.808^{+0.009}\_{-0.017}$ |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle S\_{8}$ | $\displaystyle=$ | $\displaystyle 0.802\pm 0.012.$ |  | (VII.3) |

Note that fortuitously, because $\Omega\_{m}$ is so close to $0.3$, the difference in the central values of $\sigma\_{8}$ and $S\_{8}$ is negligible. The combined result is about 1$\sigma$ lower than the inference without DES, and the constraints are tighter by about 20%.

As mentioned above, the lower value of $\Omega\_{m}$ leads to a higher value of the Hubble constant:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle h$ | $\displaystyle=$ | $\displaystyle 0.658^{+0.019}\_{-0.027}\qquad({\rm Planck:No\ Lensing})$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle h$ | $\displaystyle=$ | $\displaystyle 0.685^{+0.005}\_{-0.007}\qquad({\rm DES\ Y1+JLA+BAO+Planck})$ |  |

with neutrino mass varied.

### VII.3 $w$CDM

Figure 14: $w$CDM constraints from
the three combined probes in DES Y1 and Planck with no lensing in the
$\Omega\_{m}$-$w$-$S\_{8}$-$h$ subspace. Note the strong degeneracy between $h$
and $w$ from Planck data.

Figure [14](#S7.F14 "Figure 14 ‣ VII.3 𝑤CDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows the results in the extended $w$CDM parameter space
using Planck alone, DES alone, the two combined, and the two with the addition
of BAO+SNe. As discussed in [[53](#bib.bib53)], the constraints on the dark
energy equation of state from Planck alone are misleading. They stem from the
measurement of the distance to the last scattering surface, and that distance
(in a flat universe) depends upon the Hubble constant as well, so there is a
strong $w-h$ degeneracy. The low values of $w$ seen in Figure [14](#S7.F14 "Figure 14 ‣ VII.3 𝑤CDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")
from Planck alone correspond to very large values of $h$.
Since DES is not sensitive to the Hubble constant, it
does not break this degeneracy. Additionally, the Bayes factor in Eq. ([VI.4](#S6.E4 "In VI.2 𝑤CDM ‣ VI DES Y1 Results: Parameter Constraints ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"))
that quantifies whether adding the extra parameter $w$ is warranted is
$R\_{w}=0.7$. Therefore, opening up the dark energy equation of state is
not favored on a formal level for the DES+Planck combination. Finally, the
Bayes factor for combining DES and Planck (no lensing) in $w$CDM is equal to
10.3, indicating “strong” evidence that the two
datasets are consistent. DES Y1 and Planck
jointly constraint the equation of state to $w=-1.35\_{-0.17}^{+0.16}$, which
is about 2-sigma away from the cosmological-constant value.

The addition of BAO, SNe, and Planck lensing data to the DES+Planck
combination yields the red contours in Figure [14](#S7.F14 "Figure 14 ‣ VII.3 𝑤CDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), shifting the
solution substantially along the Planck degeneracy direction, demonstrating
(i) the problems mentioned above with the DES+Planck (no lensing) combination
and (ii) that these problems are resolved when other data sets are introduced
that restrict the Hubble parameter to reasonable values. The Bayes factor for
combination of Planck (no lensing) with the low-$z$ suite of DES+BAO+SNe in
the $w$CDM model is $R=89$ substantially more supportive of the
combination of experiments than the case for Planck and DES alone. The
DES+Planck+BAO+SNe solution shows good consistency in the
$\Omega\_{m}$–$w$–$S\_{8}$ subspace and yields our final constraint on the dark
energy equation of state:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $w=-1.00\_{-0.04}^{+0.05}.$ |  | (VII.5) |

DES Y1 reduces the width of the allowed 68% region by ten percent. The
evidence ratio $R\_{w}=0.1$ for this full combination of data sets,
disfavoring the introduction of $w$ as a free parameter.

### VII.4 Neutrino Mass

Figure 15: $\Lambda$CDM constraints on the sum of the neutrino masses from DES and
other experiments. The lower power observed in DES can be accommodated
either by lowering $\Omega\_{,}$ or $\sigma\_{8}$ or by increasing the sum of the
neutrino masses.

The lower power observed in DES (relative to Planck) has implications for the
constraint on the sum of the neutrino masses, as shown in
Figure [15](#S7.F15 "Figure 15 ‣ VII.4 Neutrino Mass ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). The current most stringent constraint comes from the cosmic
microwave background and Lyman-alpha forest [[149](#bib.bib149)]. The
experiments considered here (DES, JLA, BAO) represent an independent set so
offer an alternative method for measuring the clustering of matter as a
function of scale and redshift, which is one of the key drivers of the
neutrino constraints. The 95% C.L. upper limit on the sum of the neutrino
masses in $\Lambda$CDM becomes less constraining:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sum m\_{\nu}<0.26\,{\rm eV}.$ |  | (VII.6) |

Adding in DES Y1 loosens the constraint by close to
20% (from 0.22 eV). This is consistent with our finding that the
clustering amplitude in DES Y1 is slightly lower than expected in
$\Lambda$CDM informed by Planck. The three ways of reducing the clustering amplitude
are to reduce $\Omega\_{m}$, reduce $\sigma\_{8}$, or increase the sum of the
neutrino masses. The best fit cosmology moves all three of these parameters
slightly in the direction of less clustering in the present day Universe.

Figure 16: $\Lambda$CDM constraints on $\Omega\_{m}$ and $\sigma\_{8}$ from
Planck without lensing and all three probes in DES. In contrast to all
other plots in this paper, the dark contours here show the results when
the sum of the neutrino masses was held fixed at its minimum allowed value
of 0.06 eV.

We may, conversely, be concerned about the effect of priors on $\Omega\_{\nu}h^{2}$ on the cosmological inferences in this paper. The results for DES Y1 and
Planck depicted in Figure [10](#S7.F10 "Figure 10 ‣ VII.1 High redshift vs. low redshift in ΛCDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") in $\Lambda$CDM were obtained when varying the
sum of the neutrino masses. Neutrinos have mass [[150](#bib.bib150)] and the sum
of the masses of the three light neutrinos is indeed unknown, so this
parameter does need to be varied. However, many previous analyses have either
set the sum to zero or to the minimum value allowed by oscillation experiments
($\sum m\_{\nu}=0.06$ eV), so it is of interest to see if fixing neutrino mass
alters any of our conclusions. In particular: does this alter the level of
agreement between low- and high-redshift probes in $\Lambda$CDM?
Figure [16](#S7.F16 "Figure 16 ‣ VII.4 Neutrino Mass ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows the extreme case of fixing the neutrino masses
to the lowest value allowed by oscillation data: both the DES and Planck
constraints in the $\Omega\_{m}-S\_{8}$ plane change. The Planck contours shrink
toward the low-$\Omega\_{m}$ side of their contours, while the DES constraints
shift slightly to lower $\Omega\_{m}$ and higher $S\_{8}$. The Bayes factor for the
combination of DES and Planck in the $\Lambda$CDM space changes from $R=6.6$ to
$R=3.4$ when the minimal neutrino mass is enforced. DES and Planck
therefore continue to agree, as seen in Figure [16](#S7.F16 "Figure 16 ‣ VII.4 Neutrino Mass ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"): when the
neutrino mass is fixed, the area in the $\Omega\_{m}-S\_{8}$ plane allowed by
Planck is much smaller than when $\Omega\_{\nu}h^{2}$ varies, but there remains
a substantial overlap between the Planck and DES contours.

Finally, fixing the neutrino mass allows us to compare directly to previous
analyses that did the same. Although there are other differences in the
analyses, such as the widths of the priors, treatments of systematics, and
covariance matrix generation, fixing the neutrino mass facilitates a more
accurate comparison. On the main parameter $S\_{8}$ within $\Lambda$CDM, again with
neutrino mass fixed, the comparison is:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle S\_{8}$ | $\displaystyle=$ | $\displaystyle 0.793^{+0.019}\_{-0.026}\qquad\text{DES\ Y1}$ |  |
|  |  | $\displaystyle=$ | $\displaystyle 0.801\pm 0.032\qquad\text{KiDS+GAMA \cite[cite]{[\@@bibref{Number}{vanUitert:2017ieu}{}{}]}}$ |  |
|  |  | $\displaystyle=$ | $\displaystyle 0.742\pm 0.035\qquad\text{KiDS+2dFLenS+BOSS \cite[cite]{[\@@bibref{Number}{Joudaki:2017}{}{}]}},$ |  |

so we agree with KiDS+GAMA, and differ from KiDS+2dFLenS+BOSS by only about 1.2$\sigma$, indicating good
statistical agreement.

## VIII Conclusions

We have presented cosmological results from a combined analysis of galaxy
clustering and weak gravitational lensing, using imaging data from the first
year of DES. These combined probes demonstrate that cosmic surveys using
clustering measurements have now attained constraining power comparable to the
cosmic microwave background in the $\Omega\_{m}$–$S\_{8}$ plane, heralding a new
era in cosmology. The combined constraints on several cosmological parameters
are the most precise to date.

The constraints on $\Omega\_{m}$ from the CMB stem from the impact of the matter
density on the relative heights of the acoustic peaks in the cosmic plasma
when the universe was only 380,000 years old and from the distance between us
today and the CMB last scattering surface. The CMB constraints on $S\_{8}$ are an
expression of both the very small RMS fluctuations in the density at that
early time and the model’s prediction for how rapidly they would grow over
billions of years due to gravitational instability. The measurements
themselves are of course in microwave bands and probe the universe when it was
extremely smooth. DES is different in every way: it probes in optical bands
billions of years later when the universe had evolved to be highly
inhomogeneous. Instead of using the radiation as a tracer, DES uses galaxies
and shear. It is truly extraordinary that a simple model makes consistent
predictions for these vastly different sets of measurements.

The results presented here enable precise tests of the $\Lambda$CDM and $w$CDM models, as shown in Figures [10](#S7.F10 "Figure 10 ‣ VII.1 High redshift vs. low redshift in ΛCDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") and [14](#S7.F14 "Figure 14 ‣ VII.3 𝑤CDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). Our main findings are:

* •

  DES Y1 constraints on $\Omega\_{m}$ and $S\_{8}$ in $\Lambda$CDM are competitive (in
  terms of their uncertainties) and compatible (according to tests of the
  Bayesian evidence) with constraints derived from Planck observations of the
  CMB. This is true even though the visual comparison (Figure [10](#S7.F10 "Figure 10 ‣ VII.1 High redshift vs. low redshift in ΛCDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")) of
  DES Y1 and Planck shows differences at the 1 to 2-$\sigma$ level, in the
  direction of offsets that other recent lensing studies have reported.
* •

  The statistical consistency allows us to combine DES Y1 results with
  Planck, and, in addition, with BAO and supernova data sets. This yields $S\_{8}=0.802\pm 0.012$ and $\Omega\_{m}=0.298\pm 0.007$ in
  $\Lambda$CDM, the tightest such constraints to date (Figure [13](#S7.F13 "Figure 13 ‣ VII.2 Cosmological Parameters in ΛCDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")).
* •

  The $w$CDM likelihoods from DES and Planck each constrain $w$ poorly;
  moreover, allowing $w$ as a free parameter maintains the consistency of
  the two data sets. DES is also consistent with the bundle of
  Planck, BAO, and supernova data, and this combination tightly constrains the
  equation-of-state parameter, $w=-1.00\_{-0.04}^{+0.05}$
  (Figure [14](#S7.F14 "Figure 14 ‣ VII.3 𝑤CDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")).
* •

  The two-point functions measured in DES Y1 contain some information on
  two other open questions in cosmological physics: the combination of DES and
  Planck shifts the Planck constraints on the Hubble constant by more than
  $1\sigma$ in the direction of local measurements (Figure [12](#S7.F12 "Figure 12 ‣ VII.1 High redshift vs. low redshift in ΛCDM ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")), and
  the joint constraints on neutrino mass slightly loosens the bound from
  external experiments to $\sum m\_{\nu}<0.26\,$eV (95% C.L.)
  (Figure [15](#S7.F15 "Figure 15 ‣ VII.4 Neutrino Mass ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")).
* •

  All results are based on redundant implementations and tests of the most
  critical components. They are robust to a comprehensive set of checks that
  we defined a priori and made while blind to the resulting cosmological
  parameters (see Section [V](#S5 "V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") and Appendix [A](#A1 "Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")). All
  related analyses, unless explicitly noted otherwise, marginalize over the
  relevant measurement systematics and neutrino mass.
* •

  Joint analyses of the three two-point functions of weak lensing and
  galaxy density fields have also been executed recently by the combination of
  the KiDS weak lensing data with the GAMA [[67](#bib.bib67)] and
  2dfLenS [[68](#bib.bib68)] spectroscopic galaxy surveys, yielding
  $\Lambda$CDM bounds on $S\_{8}$ that are in statistical agreement with ours; see Eq. ([VII.4](#S7.Ex6 "VII.4 Neutrino Mass ‣ VII Comparison with external data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")).
  DES Y1 uncertainties are roughly $\sqrt{2}$ narrower than
  those from KiDS-450; while one might have expected a greater improvement
  considering the $\sim$3$\times$ increase in survey area, we caution against
  any detailed comparison of values or uncertainties until the analyses are
  homogenized to similar choices of scales, priors on neutrino masses, and
  treatments of observational systematic uncertainties.

The next round of cosmological analyses of DES data will include data from the
first three years of the survey (DES Y3), which cover more than three times as
much area to greater depth than Y1, and will incorporate constraints from
clusters, supernovae, and cross-correlation with CMB lensing, shedding more
light on dark energy and cosmic acceleration.

## Acknowledgments

Funding for the DES Projects has been provided by the U.S. Department of Energy, the U.S. National Science Foundation, the Ministry of Science and Education of Spain,
the Science and Technology Facilities Council of the United Kingdom, the Higher Education Funding Council for England, the National Center for Supercomputing
Applications at the University of Illinois at Urbana-Champaign, the Kavli Institute of Cosmological Physics at the University of Chicago,
the Center for Cosmology and Astro-Particle Physics at the Ohio State University,
the Mitchell Institute for Fundamental Physics and Astronomy at Texas A&M University, Financiadora de Estudos e Projetos,
Fundação Carlos Chagas Filho de Amparo à Pesquisa do Estado do Rio de Janeiro, Conselho Nacional de Desenvolvimento Científico e Tecnológico and
the Ministério da Ciência, Tecnologia e Inovação, the Deutsche Forschungsgemeinschaft and the Collaborating Institutions in the Dark Energy Survey.

The Collaborating Institutions are Argonne National Laboratory, the University of California at Santa Cruz, the University of Cambridge, Centro de Investigaciones Energéticas,
Medioambientales y Tecnológicas-Madrid, the University of Chicago, University College London, the DES-Brazil Consortium, the University of Edinburgh,
the Eidgenössische Technische Hochschule (ETH) Zürich,
Fermi National Accelerator Laboratory, the University of Illinois at Urbana-Champaign, the Institut de Ciències de l’Espai (IEEC/CSIC),
the Institut de Física d’Altes Energies, Lawrence Berkeley National Laboratory, the Ludwig-Maximilians Universität München and the associated Excellence Cluster Universe,
the University of Michigan, the National Optical Astronomy Observatory, the University of Nottingham, The Ohio State University, the University of Pennsylvania, the University of Portsmouth,
SLAC National Accelerator Laboratory, Stanford University, the University of Sussex, Texas A&M University, and the OzDES Membership Consortium.

Based in part on observations at Cerro Tololo Inter-American Observatory, National Optical Astronomy Observatory, which is operated by the Association of
Universities for Research in Astronomy (AURA) under a cooperative agreement with the National Science Foundation.

The DES data management system is supported by the National Science Foundation under Grant Numbers AST-1138766 and AST-1536171.
The DES participants from Spanish institutions are partially supported by MINECO under grants AYA2015-71825, ESP2015-88861, FPA2015-68048, SEV-2012-0234, SEV-2016-0597, and MDM-2015-0509,
some of which include ERDF funds from the European Union. IFAE is partially funded by the CERCA program of the Generalitat de Catalunya.
Research leading to these results has received funding from the European Research
Council under the European Union’s Seventh Framework Program (FP7/2007-2013) including ERC grant agreements 240672, 291329, and 306478.
We acknowledge support from the Australian Research Council Centre of Excellence for All-sky Astrophysics (CAASTRO), through project number CE110001020.

This manuscript has been authored by Fermi Research Alliance, LLC under Contract No. DE-AC02-07CH11359 with the
U.S. Department of Energy, Office of Science, Office of High Energy Physics.
The United States Government retains and the publisher, by accepting the article for publication,
acknowledges that the United States Government retains a non-exclusive, paid-up, irrevocable,
world-wide license to publish or reproduce the published form of this manuscript, or allow
others to do so, for United States Government purposes.

We are grateful to Anže Slosar for helpful communications. Many of the figures
in this paper were produced with chainconsumer [[151](#bib.bib151)]. This
research used resources of the National Energy Research Scientific Computing
Center, a DOE Office of Science User Facility supported by the Office of
Science of the U.S. Department of Energy under Contract No. DE-AC02-05CH11231.

## Appendix A Unblinding Tests

Here we describe some of the results of the tests enumerated in
§[V](#S5 "V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). The most relevant metrics are the values of the
cosmological parameters best constrained by DES Y1, namely $\Omega\_{m}$ and
$S\_{8}$. We report here on the few instances in which the robustness tests
yielded shifts in either the values or the uncertainties on $S\_{8}$ or
$\Omega\_{m}$ exceeding 10% of their 68% CL intervals.

Fig, [17](#A1.F17 "Figure 17 ‣ Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows the result of test [7](#S5.I2.i7 "item 7 ‣ V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"). As CosmoSIS
and CosmoLike use the same data and models, there should in principle be
no difference between them except for the sampling noise of their finite MCMC
chains. CosmoSIS yields error bars on $\Omega\_{m}$ slightly smaller than
those obtained from CosmoLike, with $<0.2\sigma$ change in central
value. The $S\_{8}$ constraints agree to better than a percent and the error
bars to within 3%. These numbers and the contours shown in Figure [17](#A1.F17 "Figure 17 ‣ Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")
improved over the results obtained before unblinding, when the difference in
the error bars was larger. Longer emcee chains account for the
improvement, so it is conceivable that these small differences — which do
not affect our conclusions — go away with even longer chains.

Figure 17: Blinded constraints on $\Omega\_{m}$ and $S\_{8}$ from all three
2-point functions in DES Y1 using two separate analysis pipelines on the
data. Both contours are shifted by the means of the posteriors obtained from
CosmoSIS, so that the CosmoLike contours could in principle be
centered away from the origin. This figure was made prior to unblinding,
thus without the update to the covariance described in
Appendix [C](#A3 "Appendix C Changes to fiducial covariance ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing").

When carrying out test [7](#S5.I2.i7 "item 7 ‣ V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), we found that for both
metacalibration and im3shape, almost all of the parameters were tightly constrained to
lie well within their sampling ranges. The lone exception was the power law of
the intrinsic alignment signal, ${\eta\_{\rm IA}}$, which had an error that is large
relative to the prior, but this was entirely expected, as our simulations
indicated that the Y1 data have little constraining power on ${\eta\_{\rm IA}}$. For
those parameters with more informative priors, the posteriors typically fell
close to the priors, indicating that the data were consistent with the
calibrations described in [[87](#bib.bib87)] and [[88](#bib.bib88)]. One exception was the
im3shape value $\Delta z\_{s}^{4}$, the shift in the mean value of the redshift in
the 4th source bin, where the posterior and prior differed by close to
1$\sigma$.

We next compare the metacalibration and im3shape constraints in the
$\Omega\_{m}$-$S\_{\*}$ plane, noting that Figure 12 of [[92](#bib.bib92)] already shows
good agreement between the two pipelines on inferences purely with cosmic
shear. Figure [18](#A1.F18 "Figure 18 ‣ Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows that when all $3\times 2$-point data are
combined, metacalibration and im3shape are in good
agreement. Note also that their corresponding data vectors are not directly
comparable, since they bin and weight the source galaxies differently and thus
have distinct redshift distributions—they can be properly compared only in
cosmological-parameter tests such as this.

Figure 18: Blinded constraints from DES Y1 on $\Omega\_{m}$ and $S\_{8}$ from all
three combined probes, using the two independent shape pipelines
metacalibration and im3shape.

For test [9](#S5.I2.i9 "item 9 ‣ V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing"), we deleted from the data vector
angular scales
$<20$ arcmin from $\xi\_{+}$, $<150$ arcmin from $\xi\_{-}$, $<65$ arcmin from $\gamma\_{t}$,
and $<50$ arcmin from $w(\theta)$. The cosmological parameter constraints expanded slightly,
as expected, but shifted by much less than $1\sigma.$

Finally, although we looked at these blinded, Figure [19](#A1.F19 "Figure 19 ‣ Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows
the posteriors of all 20 nuisance parameters used to model the data. Note the
agreement of the two sets of probes with each other and with the priors on the
parameters.

Figure 19: The posteriors from cosmic shear; from
$w(\theta)+\gamma\_{t}(\theta)$; and for all three probes using the
metacalibration pipeline for all 20 nuisance parameters used in the
$\Lambda$CDM analysis. The priors are also shown. There are no priors for the
bias and intrinsic alignment parameters, the biases and the lens shifts are
not constrained by $\xi\_{\pm}$. Therefore, the bottom panels have only two
curves: posteriors from $w(\theta)+\gamma\_{t}(\theta)$ and from all three
probes. Similarly, there are only three curves for the two intrinsic
alignment parameters.

Before unblinding, we listed several additional robustness tests that would be
carried out after unblinding. These are described in
Appendix [B](#A2 "Appendix B Robustness of Results ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing").

## Appendix B Robustness of Results

Here we test the impact on the final results of some of the choices made during analysis. These tests, conducted while unblinded but identified beforehand, supplement those described in §[V](#S5 "V Blinding and Validation ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing").

All of our inferences require assumptions about the redshift distributions for the source and lens galaxies. We have quantified the uncertainties in the redshift distributions with a shift parameter, as described in and around Eq. ([II.1](#S2.E1 "In II.2.2 Photometric redshifts ‣ II.2 Source Galaxies ‣ II Data ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")). This allows for the means of the distributions to change but does not allow for any flexibility in the shapes. We now check that the uncertainty in the photometric distributions in the source bins is adequately captured by using the BPZ redshift distribution accompanied by the free shift parameter in each bin. Instead of redshift distributions obtained via BPZ, we use those obtained directly from the COSMOS data, as described in [[88](#bib.bib88)]. As shown in Figure 4 there, the shapes of the redshift distributions are quite different from one another, so if we obtain the same cosmological results using these different shape $n(z)$’s, we will have demonstrated that the detailed shapes do not drive the constraints. Again we allow for a free shift in each of the source distributions. Figure [20](#A2.F20 "Figure 20 ‣ Appendix B Robustness of Results ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows that the ensuing constraints are virtually identical to those that use the BPZ $n(z)$’s for the source galaxies, suggesting that our results are indeed sensitive only to the means of the redshift distributions in each bin, and not to the detailed shapes.

Figure 20: Constraints on $\Omega\_{m}$ and $S\_{8}$ when using the
shifted BPZ redshift distributions as the default for $n^{i}\_{s}(z),$ compared with
those obtained when using the COSMOS redshift distribution, which
have different shape, as seen in Figure 4 of [[88](#bib.bib88)].

We also considered the impact of the choices made while computing the
covariance matrix. These choices require assumptions about all 26 parameters
that are varied. We generated an initial covariance matrix assuming fiducial
values for these parameters, but then after unblinding, recomputed it using
the means of the posteriors of all the parameters as input. How much did this
(small) change in the covariance matrix affect our final results?
Figure [21](#A2.F21 "Figure 21 ‣ Appendix B Robustness of Results ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows that the updated covariance matrix had essentially no
impact on our final parameter determination.

Figure 21: Constraints on $\Omega\_{m}$ and $S\_{8}$ using the fiducial covariance
matrix, and using the covariance based on the cosmological model centered
on the means of the posteriors (’Bestfit’) obtained after unblinding. The two agree
very well, indicating little dependence on the fiducial model assumed for
the covariance.

There are no redMaGiC galaxies in our catalog at redshifts overlapping the
fourth source bin, so the only way to verify the mean redshift of the galaxies
in that bin is to use the COSMOS galaxies. All the other source bins benefit
from the two-fold validation scheme. We therefore checked to see if removing
the highest redshift bin affected our constraints. Figure [22](#A2.F22 "Figure 22 ‣ Appendix B Robustness of Results ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing") shows
that our fiducial constraints are completely consistent with the looser ones
obtained when the highest redshift bin is removed.

Figure 22: Constraints from all three probes using all four source bins (“Fiducial”) and with the 4th source bin removed.

## Appendix C Changes to fiducial covariance

In the first public version of this paper, the value we reported for
$\chi^{2}$ between our fiducial data vector and our best fit model was $\chi^{2}=572$. This has to be compared to the degrees of freedom of our fit; note
that $N\_{\mathrm{dof}}=N\_{\mathrm{data}}-N\_{\mathrm{param}}$ is not
entirely applicable in our situation since we have strong priors on several
of our parameters. We account for this by assuming an effective number of
parameters $N\_{\mathrm{param,eff.}}=13$, which is the number of parameters
that are not tightly constrained by our priors. This resulted in
$N\_{\mathrm{dof,eff}}\approx 457-13=444$. The reduced $\chi^{2}$ in the
first version of the analysis was hence $\approx 1.29$ which, while clearly
high, was below the threshold of $1.4$ which had been set as a requirement before
unblinding the analysis.

Following referee comments to the first version of this paper, we were
fortunately able track down the cause of this elevated $\chi^{2}$ to two
inaccuracies of our model covariance:

1. 1.

   We had analytically calculated the number of galaxy pairs falling into a
   particular angular bin using simple geometric approximations. These
   approximations can fail for several reasons. First, the finite size of our
   footprint leads to a decrease in the observed density of galaxy pairs found
   on scales comparable to the footprint diameter. Second, the mask pattern on
   scales smaller than the angular scales used in our data vector decreases the
   number of pairs found in each angular bin by a factor that is almost uniform
   across angular scales. And third, clustering of galaxies increases the
   number of galaxy pairs found on small scales.
2. 2.

   When estimating the dispersion of intrinsic galaxy shapes
   $\sigma\_{\epsilon}$, we measured the variance of galaxy shape within our
   entire source sample. This ignored propagating the effect of significant differences
   in shape dispersion between different source redshift bins to the covariance
   matrix.

Both of these analysis improvements affect the noise contribution (shot-noise
and shape-noise) to the diagonal of our covariance matrix. With these changes
identified, we recomputed the shape-noise and shot-noise terms using the
actual numbers of galaxy pairs found in the data and estimating the shape
dispersion separately for each source redshift bin. In addition, we recomputed the
cosmic variance terms in the covariance using our best-fit cosmology.

These changes in our covariance improve the value of $\chi^{2}$ obtained
for our best-fit model in the 3x2 $\Lambda$CDM analysis to $497$
($\chi^{2}/{\rm dof}\approx 1.12$). Note that a change in covariance affects
both the width and the location of parameter constraints, but both of these
changed very little after the covariance update; by far the dominant effect
was the improvement in overall $\chi^{2}$. As an added bonus, the two shear pipelines,
metacalibration and im3shape, are now in a better mutual agreement than before
(see Fig. [18](#A1.F18 "Figure 18 ‣ Appendix A Unblinding Tests ‣ Dark Energy Survey Year 1 Results:Cosmological Constraints from Galaxy Clustering and Weak Lensing")).
