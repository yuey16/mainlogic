<!-- fulltext source=arxiv_html slug=arXiv-1411.1042 fetched=2026-09-18T01:01:49+00:00 -->

# MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA

A.T. Crites,
J. W. Henning,
P. A. R. Ade,
K. A. Aird,
J. E. Austermann,
J. A. Beall ,
A. N. Bender,
B. A. Benson,
L. E. Bleem,
J. E. Carlstrom,
C. L. Chang,
H. C. Chiang,
H-M. Cho,
R. Citron,
T. M. Crawford,
T. de Haan,
M. A. Dobbs,
W. Everett,
J. Gallicchio,
J. Gao,
E. M. George,
A. Gilbert,
N. W. Halverson,
D. Hanson,
N. Harrington,
G. C. Hilton,
G. P. Holder,
W. L. Holzapfel,
S. Hoover,
Z. Hou,
J. D. Hrubes,
N. Huang,
J. Hubmayr,
K. D. Irwin,
R. Keisler,
L. Knox,
A. T. Lee,
E. M. Leitch,
D. Li,
C. Liang,
D. Luong-Van,
J. J. McMahon,
J. Mehl,
S. S. Meyer,
L. Mocanu,
T. E. Montroy,
T. Natoli,
J. P. Nibarger,
V. Novosad,
S. Padin,
C. Pryke,
C. L. Reichardt,
J. E. Ruhl,
B. R. Saliwanchik,
J.T. Sayre,
K. K. Schaffer,
G. Smecher,
A. A. Stark,
K.T. Story,
C. Tucker,
K. Vanderlinde,
J. D. Vieira,
G. Wang,
N. Whitehorn,
V. Yefremenko,
and
O. Zahn
Email: [acrites@caltech.edu](mailto:acrites@caltech.edu)

Alternate Affiliation: Department of Astronomy and Astrophysics, University of Chicago, 5640 South Ellis Avenue, Chicago, IL, USA 60637
Alternate Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, 5640 South Ellis Avenue, Chicago, IL, USA 60637
Alternate Affiliation: California Institute of Technology, MS 249-17, 1216 E. California Blvd., Pasadena, CA, USA 91125
Alternate Affiliation: Department of Astrophysical and Planetary Sciences, University of Colorado, Boulder, CO, USA 80309
Alternate Affiliation: Cardiff University, Cardiff CF10 3XQ, United Kingdom
Alternate Affiliation: University of Chicago, 5640 South Ellis Avenue, Chicago, IL, USA 60637
Alternate Affiliation: NIST Quantum Devices Group, 325 Broadway Mailcode 817.03, Boulder, CO, USA 80305
Alternate Affiliation: Department of Physics, McGill University, 3600 Rue University, Montreal, Quebec H3A 2T8, Canada
Alternate Affiliation: High Energy Physics Division, Argonne National Laboratory,9700 S. Cass Avenue, Argonne, IL, USA 60439
Alternate Affiliation: Fermi National Accelerator Laboratory, MS209, P.O. Box 500, Batavia, IL 60510
Alternate Affiliation: Department of Physics, University of Chicago, 5640 South Ellis Avenue, Chicago, IL, USA 60637
Alternate Affiliation: Enrico Fermi Institute, University of Chicago, 5640 South Ellis Avenue, Chicago, IL, USA 60637
Alternate Affiliation: School of Mathematics, Statistics & Computer Science, University of KwaZulu-Natal, Durban, South Africa
Alternate Affiliation: SLAC National Accelerator Laboratory, 2575 Sand Hill Road, Menlo Park, CA 94025
Alternate Affiliation: Canadian Institute for Advanced Research, CIFAR Program in Cosmology and Gravity, Toronto, ON, M5G 1Z8, Canada
Alternate Affiliation: Department of Physics, University of California, Berkeley, CA, USA 94720
Alternate Affiliation: Department of Physics, University of Colorado, Boulder, CO, USA 80309
Alternate Affiliation: Dept. of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305
Alternate Affiliation: Kavli Institute for Particle Astrophysics and Cosmology, Stanford University, 452 Lomita Mall, Stanford, CA 94305
Alternate Affiliation: Department of Physics, University of California, One Shields Avenue, Davis, CA, USA 95616
Alternate Affiliation: Physics Division, Lawrence Berkeley National Laboratory, Berkeley, CA, USA 94720
Alternate Affiliation: Department of Physics, University of Michigan, 450 Church Street, Ann Arbor, MI, USA 48109
Alternate Affiliation: Physics Department, Center for Education and Research in Cosmology and Astrophysics, Case Western Reserve University,Cleveland, OH, USA 44106
Alternate Affiliation: Materials Sciences Division, Argonne National Laboratory,9700 S. Cass Avenue, Argonne, IL, USA 60439
Alternate Affiliation: School of Physics and Astronomy, University of Minnesota, 116 Church Street S.E. Minneapolis, MN, USA 55455
Alternate Affiliation: School of Physics, University of Melbourne, Parkville, VIC 3010, Australia
Alternate Affiliation: Liberal Arts Department, School of the Art Institute of Chicago, 112 S Michigan Ave, Chicago, IL, USA 60603
Alternate Affiliation: Three-Speed Logic, Inc., Vancouver, B.C., V6A 2J8, Canada
Alternate Affiliation: Harvard-Smithsonian Center for Astrophysics, 60 Garden Street, Cambridge, MA, USA 02138
Alternate Affiliation: Dunlap Institute for Astronomy & Astrophysics, University of Toronto, 50 St George St, Toronto, ON, M5S 3H4, Canada
Alternate Affiliation: Department of Astronomy & Astrophysics, University of Toronto, 50 St George St, Toronto, ON, M5S 3H4, Canada
Alternate Affiliation: Berkeley Center for Cosmological Physics, Department of Physics, University of California, and Lawrence Berkeley National Laboratory, Berkeley, CA, USA 94720
Alternate Affiliation: Astronomy Department, University of Illinois at Urbana-Champaign, 1002 W. Green Street, Urbana, IL 61801, USA
Alternate Affiliation: Department of Physics, University of Illinois Urbana-Champaign, 1110 W. Green Street, Urbana, IL 61801, USA

###### Abstract

We present measurements of $E$-mode polarization
and temperature-$E$-mode correlation in the cosmic microwave background (CMB)
using data from the first season of observations with SPTpol, the polarization-sensitive
receiver currently installed on the South Pole Telescope (SPT).
The observations used in this work cover 100 $\mathrm{deg}^{2}$ of sky with arcminute resolution at $150\,$GHz.
We report the $E$-mode angular auto-power spectrum ($EE$)
and the temperature-$E$-mode angular cross-power spectrum ($TE$)
over the multipole range $500<\ell\leq 5000$.
These power spectra improve on previous measurements in the
high-$\ell$ (small-scale) regime.
We fit the combination of the SPTpol power spectra, data from Planck 
and previous SPT measurements with a six-parameter $\Lambda$CDM cosmological model.
We find that the best-fit parameters are consistent with previous results.
The improvement in high-$\ell$ sensitivity over previous measurements
leads to a significant improvement in the limit on polarized
point-source power:
after masking sources brighter than 50 mJy in unpolarized flux at 150 GHz, we find
a 95% confidence upper limit on unclustered point-source power in the $EE$ spectrum of
$D\_{\ell}=\ell(\ell+1)C\_{\ell}/2\pi<0.40\ \mu{\mbox{K}}^{2}$
at $\ell=3000$, indicating that future $EE$ measurements will not be limited by
power from unclustered point sources in the multipole range $\ell<3600$, and
possibly much higher in $\ell.$

###### Subject headings

cosmic background radiation – cosmology: observations

## I. Introduction

Measurements of the cosmic microwave background (CMB) are a cornerstone of our understanding of cosmology.
The angular power spectrum of the CMB temperature anisotropy has now been measured to high precision at
scales of tens of degrees
down to arcminutes with, e.g., the Wilkinson Microwave Anisotropy Probe (WMAP) and
Planck satellites [[3](#bib.bib3), [38](#bib.bib38)] and the ground-based
Atacama Cosmology Telescope (ACT) and South Pole Telescope (SPT) experiments
[[9](#bib.bib9), [50](#bib.bib50)]. These measurements yield tight constraints on cosmology [[21](#bib.bib21), [39](#bib.bib39), [48](#bib.bib48), [23](#bib.bib23), e.g.].

The CMB is also partially polarized. The largest contribution to the polarization was
imprinted during the epoch of recombination, when local
quadrupole intensity fluctuations, incident on free electrons, created linear polarization via Thomson scattering
[[24](#bib.bib24), e.g.,]. The observed linear polarization pattern in the CMB
can be decomposed into even-parity ($E$-mode) and odd-parity ($B$-mode) components,
with a key feature being that scalar (density) perturbations during recombination generate $E$-mode polarization patterns only. By contrast, the local quadrupoles induced by gravitational waves generally produce both $E$ and $B$ modes. Gravitational lensing will also generate $B$ modes by distorting the scalar-induced $E$-mode pattern and converting a small fraction into $B$. The total $B$-mode contribution from
these two mechanisms is measured/limited to be at least an order of magnitude smaller
in amplitude (two orders of magnitude smaller in power) than the $E$ modes
[[19](#bib.bib19), [40](#bib.bib40), [4](#bib.bib4)].

Measurements of the $E$-mode polarization of the CMB are complementary to intensity measurements in a number of ways. Particularly relevant to this paper is an expected advantage in CMB signal-to-foreground contamination ratio at small angular scales,
due to the low level of expected polarization in emission from extragalactic point sources.
We expect that, as experiments reach lower noise levels, polarization measurements
will extend to angular scales that are smaller than those limited by
point source contamination in temperature.

The $E$-mode polarization of the CMB and the temperature-$E$-mode correlation were first detected
in data from the Degree Angular Scale Interferometer (DASI; [[28](#bib.bib28)]).
Many experiments have since reported measurements of the angular auto-power spectrum of
the $E$ modes (the $EE$ spectrum)
and the angular cross-power spectrum between the temperature and the $E$ modes (the $TE$ spectrum).
The best measurements of the $EE$ and $TE$ spectra to date
come from WMAP [[3](#bib.bib3)] and BICEP2 [[4](#bib.bib4)]
on scales of a degree and larger
and from ACTpol on sub-degree scales [[36](#bib.bib36)].
At the precision of these current measurements, the $EE$ and $TE$ power
spectra are consistent with the predictions from cosmological models
that are highly constrained by the temperature power spectrum ($TT$).

In this work, we present estimates of the $EE$ and $TE$ angular power spectra
using 100 $\mathrm{deg}^{2}$ of data from the first season of observations with SPTpol,
a polarization-sensitive receiver installed on the SPT. We report measurements
in the multipole range $500<\ell\leq 5000$, with high signal-to-noise on the
primary anisotropy power
spectra out to $\ell\simeq 3000$.

This paper is structured as follows:
Section 2 describes the instrument and the observations.
Section 3 describes the low-level data processing and calibration.
Section 4 outlines the steps used to transform time-ordered data into maps and power spectra.
Section 5 describes our calibration procedures.
Section 6 discusses the calculation of the bandpower covariance matrix.
Section 7 describes the results of jackknife and other systematic tests.
Section 8 presents our $EE$ and $TE$ spectra.
Section 9 describes cosmological constraints.
Finally, Section 10 states our conclusions.

## II. The SPTpol Instrument

SPTpol is a polarization-sensitive receiver installed in early 2012 on the SPT [[6](#bib.bib6)]. The receiver was designed to make precision measurements
of the polarization of the CMB over a wide range of angular scales. It replaced the original instrument installed on the telescope, the SPT-SZ receiver, which was sensitive only to intensity fluctuations.

The SPT is a 10-meter off-axis Gregorian design with a one-square-degree
field of view and arcminute resolution at 150 GHz [[37](#bib.bib37)].
The field of view and resolution make
the SPT an ideal telescope for surveying large areas and
measuring the anisotropy of the CMB from degree scales
out to arcminute scales. The Gregorian focus allows for an
optical design with nearly zero cross-polarization at the center of
the focal plane [[33](#bib.bib33), [13](#bib.bib13)].
The optical design of the SPT and
the SPTpol receiver are described in detail in [Padin et al. [37]](#bib.bib37) and [George et al. [17]](#bib.bib17), respectively.

The SPTpol focal plane contains 1536 polarization-sensitive
transition edge sensor (TES) bolometers, with
1176 detectors at 150 GHz and 360 detectors at 95 GHz.
The detectors are operated at $\sim 500$ mK and are read out with a digital frequency-domain multiplexing readout [[11](#bib.bib11), [12](#bib.bib12), [10](#bib.bib10)].
The detectors in the two bands were designed and fabricated
independently and are described in detail in [Henning et al. [20]](#bib.bib20) (150 GHz) and
[Sayre et al. [44]](#bib.bib44) (90 GHz). This work focuses on data from the 150 GHz array.

The 150 GHz array is composed of seven detector modules,
each containing 84 pixels.
The modules were fabricated at the National Institute for Standards and Technology.
Each consists of a 2.3 inch-wide hexagonal detector array behind a monolithic feedhorn array. Incoming
power is coupled through the feedhorns to an
orthomode transducer (OMT),
which splits the light into two orthogonal polarization states.
The signal from each polarization state is coupled via microstrip to a thermally isolated detector island.
Changes in island temperature are read out by an aluminum manganese TES
with a transition temperature of $\sim 500$ mK
connected to an array of superconducting quantum interference device (SQUID) amplifiers.
For additional details on the SPTpol instrument design,
characterization, and operation also see
[George et al. [17]](#bib.bib17), [Austermann et al. [1]](#bib.bib1), [Story et al. [49]](#bib.bib49).

## III. Observations and Data Reduction

### III.1. Observing Strategy

The first year of observations with the SPTpol camera in 2012
focused on a 100 $\mathrm{deg}^{2}$ patch of sky centered at right ascension 23h30m and declination $-55$ degrees.
We refer to this field as the SPTpol “100d” field to distinguish it from the full 500 $\mathrm{deg}^{2}$ survey field
which we began observing in 2013. All observations of the SPTpol 100d field were made using an azimuthal “lead-trail” observing strategy.
In this observing strategy the field is split into two equal halves in right ascension, a “lead” half-field and a “trail” half-field.
The lead half-field is observed first, followed immediately by a trail half-field observation, with the timing adjusted such
that the lead and trail observations cover the same azimuth range. Each half-field is observed
by scanning the telescope in azimuth back and forth across the field and then stepping up in elevation.
We refer to one pass of the telescope, either from left to right or from right to left across the field, as a “scan,”
and to a half-hour set of scans that cover an entire half-field as an “observation.”
In the 2012 observing season, the full field was observed roughly 2500 times. The azimuthal
scanning speed used in all observations was 0.48 degrees per second, corresponding to 0.28
degrees per second on the sky at the mean elevation of the field.

This observing strategy enables removal of ground pickup via the differencing of pairs of lead and trail observations [[42](#bib.bib42), e.g.,].
Tests for ground pickup in the 2012 SPTpol data (including the jackknife null tests described in
Section [VII.1](#S7.SS1 "VII.1. Null Tests ‣ VII. Tests for Systematic Errors ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA")) show no sign of significant ground contamination, so we do not
use a field-differencing analysis in this work. There is a small overlap region between the lead
and trail half-fields, leading to a region of deeper coverage (lower noise) in the middle of the full
coadded field. To simplify the analysis, we ignore this and use a uniform weight over the field in
the power spectrum calculation described in Section [IV](#S4 "IV. Power Spectrum ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA").

### III.2. Map-Making: Time-Ordered Data to Maps

The treatment of the time-ordered data (TOD) and the map-making process
is similar to that in analyses of data from SPT-SZ [[31](#bib.bib31), e.g.,], with the added complexity of
calculating all three Stokes parameters $I$, $Q$, and $U$
in each map pixel. We will refer to the Stokes $I$
parameter as $T$ (temperature) for the rest of this paper and express $Q$
and $U$ in temperature units. The procedure for polarized map-making follows the methodology described in [Couchot et al. [8]](#bib.bib8), [Montroy et al. [35]](#bib.bib35), [Jones et al. [27]](#bib.bib27), and [Chiang et al. [7]](#bib.bib7).

The TOD are bandpass-filtered by applying a low-pass filter
and subtracting a fourth-order polynomial from each scan (effectively a high-pass filter). The cutoff frequencies for these two filters correspond to angular frequencies in the scan
direction of $\ell\simeq 10000$ and $\ell\simeq 150$ at the mean elevation of the field.11
1
Throughout
this work, we use the flat-sky approximation to equate multipole number $\boldsymbol{\ell}$ with $2\pi|\mathbf{u}|$, where
$\mathbf{u}$ is the Fourier conjugate of Cartesian angle on an asymptotically flat patch of sky.
The data from each detector are calibrated relative to each other
using the method described in Section [V.1](#S5.SS1 "V.1. Relative Calibration ‣ V. Calibration ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"),
and then combined into $T$, $Q$, and $U$ maps
using the pointing information, polarization angle, and weight for each detector.
Weights are calculated for each observation based on detector polarization efficiency and
noise power between 1 Hz and 3 Hz,
which corresponds to the angular scales of the signals of interest.
The noise power is calculated by taking the difference between left-going and right-going scans.
A 3-by-3 matrix representing the $T$, $Q$, and $U$ weights and the correlations between the three
measurements is created for each map pixel using this same information.

We make maps using the oblique Lambert azimuthal equal-area projection with 0.5-arcminute pixels.
This sky projection introduces small angle distortions, which we account for by rotating the
$Q$ and $U$ Stokes components across the map to maintain a consistent angular coordinate system in this projection.
We combine $Q$ and $U$ maps in Fourier space to create $E$ maps using the standard convention [[55](#bib.bib55)]

|  |  |  |  |
| --- | --- | --- | --- |
|  | $E\_{\boldsymbol{\ell}}=Q\_{\boldsymbol{\ell}}\cos{2\phi\_{\ell}}+U\_{\boldsymbol{\ell}}\sin{2\phi\_{\ell}},$ |  | (1) |

where $\phi\_{\ell}$ is the azimuthal angle of $\boldsymbol{\ell}$.

#### III.2.1 Cuts and Flagged Data

Data are included in the analysis if they pass several quality checks.
We perform checks at several different levels:
individual-bolometer TOD of a single scan,
individual-bolometer data over full observations,
and full observations which include all bolometers’ TOD that have passed cuts.

Data from individual bolometers are flagged on a per-scan basis
based on the presence of
various types of
discontinuities in the data, and on the noise in the TOD. Scans are flagged for a particular bolometer if either a sharp spike (presumably caused by
a cosmic ray) or a sharp change in DC level (attributed generally to changes in SQUID bias point)
is detected above a given significance threshold. After removing flagged scans,
the root mean square (rms) of each bolometer’s data on each scan is calculated.
The median rms for bolometers within the same module for an entire observation is calculated, and
scans with an rms greater than 3.5 times this median or less than 0.25 times this median are flagged.
This last flagging step is done after the polynomial subtraction described in the previous section.
Data from scans that are flagged for any of these reasons are not included in maps, removing 5 percent of the data.

Data from individual bolometers are
flagged in full observations based on their response and noise properties.
Detectors with low signal-to-noise response to either of two regularly performed calibration
observations (two-degree elevation dips and observations of an internal blackbody source) are flagged for the entire subsequent CMB field observation.
We similarly flag bolometers with abnormally high or low noise in the $1-3$ Hz frequency band.

Single-observation maps (using data from all bolometers and scans not already flagged)
are flagged based on the values of the following (often coincident) criteria:
rms noise in the map, median pixel weight,
the product of median weight and map noise squared,
and the sum of the weights over the full map.
For these cuts, we remove outliers both above and below the median value for each field.
We do not use observations that are flagged by one or more of these cuts.
The cut levels are set to exclude data where the values of the above
criteria are in the tails of the distributions.
Such outliers typically correspond to observations in which a significant fraction of the array was improperly voltage-biased (often caused by bad or variable weather) and would be equally identified by any of the above cuts. Due to very conservative cut values (described above) for this first analysis, of the roughly 5000 lead and trail observations of the SPTpol 100d during the 2012 season, 3416 are used in this analysis.

#### III.2.2 Coadded Maps

For this analysis we choose to combine multiple observations of the
CMB field so that the fundamental unit for the power spectrum analysis is a coadd of 28 observations,
which we refer to as a “map bundle”.
We combine individual-observation
maps into bundles such that every bundle has nearly uniform coverage on the field.
After cuts, there are 122 map bundles for the 2012 data.

The power spectrum analysis described in the next section is performed on the map bundles; we
make full-season coadded maps for display purposes.
Full-season coadds of temperature $T$ and Stokes $Q$ and $U$ maps are shown in the left column of
Figure [1](#S3.F1 "Figure 1 ‣ III.2.2 Coadded Maps ‣ III.2. Map-Making: Time-Ordered Data to Maps ‣ III. Observations and Data Reduction ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"). In the right column, we show maps of one half-season of data subtracted from
the other half-season (divided by two) to demonstrate the noise level expected in the maps on the left.
Analogous signal and noise maps for $E$-mode polarization are shown in Figure [2](#S3.F2 "Figure 2 ‣ III.2.2 Coadded Maps ‣ III.2. Map-Making: Time-Ordered Data to Maps ‣ III. Observations and Data Reduction ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"). All maps are displayed in units of $\mu$KCMB, which are the equivalent fluctuations of a 2.73 K blackbody that would produce the measured deviations in intensity.

Figure 1.— SPTpol 2012 100d signal (Left) and noise (Right) maps.
The noise maps are obtained by subtracting data from the first half of the season from data from the second half and dividing by two.
(Top) $T$ maps, $\pm 250$ $\mu$KCMB. (Middle) Stokes $Q$ maps, $\pm 20$ $\mu$KCMB.
(Bottom) Stokes $U$ maps, $\pm 20$ $\mu$KCMB.
The clear vertical stripes in $Q$ and $\pm 45^{\circ}$ stripes in $U$ are indicative of high signal-to-noise $E$ modes. Lack of horizontal stripes in $Q$ is the result of polynomial subtraction along the scan direction, which is mostly horizontal in this projection.
$Q$ and $U$ maps have been smoothed by a 4.0 arcminute FWHM Gaussian.

Figure 2.— SPTpol 2012 100d $E$-mode signal (Top) and noise (Bottom) maps.
These maps are created from the $Q$ and $U$ signal and noise maps shown
in Figure [1](#S3.F1 "Figure 1 ‣ III.2.2 Coadded Maps ‣ III.2. Map-Making: Time-Ordered Data to Maps ‣ III. Observations and Data Reduction ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"), using Equation [1](#S3.E1 "In III.2. Map-Making: Time-Ordered Data to Maps ‣ III. Observations and Data Reduction ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA").
The color scale is $\pm 20$ $\mu$KCMB, and both maps have been smoothed by a 4.0 arcminute FWHM Gaussian.

## IV. Power Spectrum

In this section, we describe the analysis used to calculate the $EE$ and $TE$ power spectra
from the maps described in the previous section.

Figure 3.— The source and apodization mask used to mask the SPTpol 100d maps before calculating power spectra. It is generated using the procedure described in Section [IV.1](#S4.SS1 "IV.1. Source and Apodization Mask ‣ IV. Power Spectrum ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"). All point sources in the field with unpolarized flux $>$ 50 mJy at 150 GHz have been masked.

### IV.1. Source and Apodization Mask

The temperature and polarization maps are multiplied in real space by a two-dimensional array prior to computing the Fourier transform of these maps.
We refer to this array as the source and apodization mask.
This mask downweights high-noise regions near the border of the map and effectively removes the flux from a number of bright point sources located in this field.
The list of masked bright point sources consists of all point sources in the field with 150 GHz flux $>$ 50 mJy as measured by SPT-SZ (see [Story et al. 50](#bib.bib50)).
There are 19 sources that are masked using this flux limit in our survey area.
Each point source is masked with a $5^{\prime}$-radius disk.
The disk is tapered to zero using a $15^{\prime}$ cosine taper.
We then smooth the mask with an edge taper of $30^{\prime}$.
The final mask, which is the product of the apodization and point source masks, is shown in Figure [3](#S4.F3 "Figure 3 ‣ IV. Power Spectrum ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA").

### IV.2. Cross-Spectra

A pseudo-$C\_{\ell}$ method is used to estimate the binned power spectrum following the MASTER method described in [Hivon et al. [22]](#bib.bib22).
To avoid noise bias we use a cross-spectrum analysis [[41](#bib.bib41), [52](#bib.bib52)] in which we
take the cross-spectrum of the subsets of data (bundles) described in the previous section.
These bundles have independent realizations of the atmospheric and detector noise.
We follow the procedure developed in [Lueker et al. [31]](#bib.bib31)
and used in subsequent SPT power spectrum analyses.

To calculate the power spectrum, we cross-correlate the bundled CMB maps in Fourier space.
The relatively small size of the maps (10 degrees on a side) and the fact that
our analysis only extends to a minimum multipole number of $\ell=500$ means
that we can use the flat-sky approximation and substitute two-dimensional Fourier transforms
for spherical harmonic transforms in calculating $C\_{\ell}$.
Each map is multiplied by the source and apodization mask, zero-padded to 1728 by 1728 pixels,
and the Fourier transform of the map, $\tilde{m}^{A}$, is calculated.
The resulting Fourier-space maps have pixels of size $\delta\_{\ell}=25$ on a side.
We calculate the average cross-spectrum between the maps of two observations $A$ and $B$ within an $\ell$-bin $b$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\widehat{D}^{AB}\_{b}\equiv\left<\frac{\ell(\ell+1)}{2\pi}Re[\tilde{m}^{A}\_{\boldsymbol{\ell}}\tilde{m}^{B\*}\_{\boldsymbol{\ell}}]\right>\_{\ell\in b},$ |  | (2) |

where $\boldsymbol{\ell}$ is a vector in two-dimensional $\ell$-space and $\ell=|\boldsymbol{\ell}|$.
There are 122 bundle maps in the input set (see Section [III.2.2](#S3.SS2.SSS2 "III.2.2 Coadded Maps ‣ III.2. Map-Making: Time-Ordered Data to Maps ‣ III. Observations and Data Reduction ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA")), resulting in $\sim 10000$ cross-spectra.
We average all cross-spectra $\widehat{D}^{AB}\_{b}$ with $A\neq B$ to calculate a binned power spectrum $\widehat{D}\_{b}$. We refer to these one-dimensional binned power spectrum measurements as “bandpowers.”

### IV.3. Unbiased Spectra

The bandpowers $\widehat{D}\_{b}$ are a biased estimate of the true binned sky power, $D\_{b^{\prime}}$, due to effects such as TOD filtering, beam smoothing, finite sky coverage, and mode-mode mixing from the source and apodization mask.
The biased and unbiased estimates are related by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\widehat{D}\_{b}\equiv K\_{bb^{\prime}}D\_{b^{\prime}}\,,$ |  | (3) |

where the $K$ matrix accounts for the effects of the instrumental beam ($B\_{\ell}$), TOD filtering
($F\_{\ell}$), and applying the apodization mask (W).
$K$ can be expanded as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $K\_{bb^{\prime}}=P\_{b\ell}\left(M\_{\ell\ell^{\prime}}[\textbf{W}]\,F\_{\ell^{\prime}}B^{2}\_{\ell^{\prime}}\right)Q\_{\ell^{\prime}b^{\prime}}.$ |  | (4) |

$P\_{b\ell}$ is the binning operator and $Q\_{\ell^{\prime}b^{\prime}}$ its reciprocal [[22](#bib.bib22)].
The mode coupling kernel $M\_{\ell\ell^{\prime}}[\textbf{W}]$ accounts for the mixing of power between bins due to the
real-space mask applied to the data before Fourier transforming.
The mode coupling kernel is calculated analytically, as described in the Appendix.

### IV.4. Bandpower Window Functions

Bandpower window functions are necessary to compare the measured bandpowers to a theoretical power spectrum.
The window functions, ${\mathcal{W}}^{b}\_{\ell}/\ell$, are defined through the relation

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{b}=({\mathcal{W}}^{b}\_{\ell}/\ell)C\_{\ell}.$ |  | (5) |

Following the formalism described in Section [IV.3](#S4.SS3 "IV.3. Unbiased Spectra ‣ IV. Power Spectrum ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"), we can write this as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{b}=(K^{-1})\_{bb^{\prime}}P\_{b^{\prime}\ell^{\prime}}M\_{\ell^{\prime}\ell}F\_{\ell}B\_{\ell}^{2}C\_{\ell},$ |  | (6) |

which implies that

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\mathcal{W}}^{b}\_{\ell}/\ell=(K^{-1})\_{bb^{\prime}}P\_{b^{\prime}\ell^{\prime}}M\_{\ell^{\prime}\ell}F\_{\ell}B\_{\ell}^{2}.$ |  | (7) |

#### IV.4.1 Simulations and the Transfer Function

We compute the filter transfer function, $F\_{\ell}$, with simulated observations using the iterative method described in [Hivon et al. [22]](#bib.bib22).
We start by generating 782 realizations of the CMB sky.
The input cosmology to the simulations is computed using CAMB, a Boltzmann code for calculating CMB power spectra [[30](#bib.bib30)].
Input parameter values to CAMB are from the Planck+lensing+WP+highL best-fit model in Table 5 of [[39](#bib.bib39)].
These maps are then “observed” using the actual detector pointing
information to create simulated, noise-free timestreams for each
bolometer.
The simulated timestreams include the same pointing information,
weights, and data cuts as the real data for each observation.
For each scan in each observation, we filter the simulated data in the same way the real data are filtered.
We then make a map for each observation from the filtered data.
The final output of the simulation is 782 realizations for each of the 122 map bundles.

For each of the 782 realizations of the CMB, we combine all of the simulated observations over the full season of data and compute the power spectrum of this coadded map.
The resulting transfer function $F\_{\ell}$ is the output power spectrum divided by the input power spectrum, after
correcting the output spectrum for mode-mode coupling (see the Appendix). The $TE$ transfer function is particularly sensitive to locations of zero-crossings in the $TE$ power spectrum, which can cause sharp features in the transfer function unrelated to the effects of filtering on the data. To avoid these spurious features, we instead define the $TE$ transfer function as the geometric mean of the $TT$ and $EE$ transfer functions. In the multipole range considered in this analysis, both the $EE$ and $TE$ transfer functions are always greater than 0.7.

#### IV.4.2 Beam Functions

A measurement of the SPT beam – the optical response as a function of angle – is needed to calibrate the angular power spectrum as a function of multipole.
The beam response, $B\_{\ell}$, for the 2012 instrument is measured from the combination of dedicated observations of Mars and the brightest point sources in the CMB field.

The effective beam for observations of the 100d CMB field is the convolution of the instantaneous response function of the
system and the effect of random, uncorrected pointing variations between observations of the field.
The instantaneous beam is measured using eight dedicated observations of Mars from the fall of 2012.
These observations are short enough that any pointing variation over an observation is negligible, and the results from
the eight observations are registered to one another with high precision before they are combined.
This instantaneous beam is compared to the beam measured from bright
point sources in the coadded CMB field to estimate the additional beam width
contributed by pointing variation, or jitter.
In the 2012 data, we measure $12^{\prime\prime}$ rms jitter. (Recent updates to our pointing reconstruction should reduce the jitter in future analyses). The convolution of the
Mars-derived beam with a Gaussian of this width provides a good fit
to the profile derived from sources in the field.

We use the jitter-convolved Mars beam map to calculate the beam function $B\_{\ell}$, the azimuthally averaged Fourier transform of the beam map.
The uncertainty on the beam measurements is calculated from the standard deviation between individual Mars observations. Fractional beam uncertainties are less than 1% over the multipole range reported here. The FWHM of the 150 GHz jitter-convolved beam is 1.18 arcminutes.

Electrical cross-talk between detectors affects the measured beam and can potentially result in a
different effective beam for temperature and polarization measurements. These effects and the
method by which we account for them are described in Section [VII.2.2](#S7.SS2.SSS2 "VII.2.2 Detector Non-Idealities ‣ VII.2. Other Potential Systematic Effects ‣ VII. Tests for Systematic Errors ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA").

## V. Calibration

We next describe our map calibration procedures. First, we discuss the relative calibration between detector TOD amplitudes. Second, we describe how SPTpol maps are absolutely calibrated to those from SPT-SZ and Planck. Finally, we describe our measurements of detector polarization angles and polarization efficiencies, which impact our $Q$ and $U$ map calibrations.

### V.1. Relative Calibration

Calibration of the detector response amplitude, or gain, across the array is particularly important
for polarization-sensitive bolometric
receivers. Because such instruments measure linear polarization by comparing the
intensity recorded on detectors with orthogonal polarization sensitivity, a difference in gain
between orthogonal detectors will cause unpolarized radiation to appear polarized. We monitor the relative gain among detectors—as well as changes in detector gain over
time—through a combination of regular observations
of the galactic HII region RCW38 and regular observations of an internal chopped blackbody source.
The schedule of calibration observations and the analysis of the resulting data
are nearly identical to those used for SPT-SZ and
described in detail in [Schaffer et al. [45]](#bib.bib45); we summarize the salient features here.

A 45-minute observation of RCW38 (in which all detectors are scanned across the source multiple
times) is taken approximately every 20 hours, while one-minute observations of the internal source
are taken at least once per hour. Different detectors see the internal source with different illumination,
so the first step in the relative calibration pipeline is to assign a value for the effective temperature
of the internal source for each detector. This value is based on the season average
of the ratio of that detector’s response to the internal source and that detector’s response to
RCW38. Up to corrections for temperature drift of the source and atmospheric opacity, each detector’s
gain in a given CMB field observation is then
set by the combination of this effective temperature and the detector’s response to the internal source
observation nearest the CMB field observation. We correct for any drifts in the internal source temperature
using the ratio of response to an individual observation of the internal source to the season average of
that response, averaged over a detector module. Similarly, we correct for
changes in atmospheric opacity using the ratio of response to an individual observation of RCW38
to the season average, again averaged over detector module.

### V.2. Absolute Calibration

For our absolute calibration, we compare temperature maps of the 100 $\mathrm{deg}^{2}$ field made with SPTpol
data to maps of the same field made with SPT-SZ data.
The SPT-SZ data has itself been calibrated by comparing the temperature power spectrum of the full 2500 $\mathrm{deg}^{2}$ SPT-SZ
survey to the published Planck power spectrum [[50](#bib.bib50), [39](#bib.bib39)].
The uncertainty on this SPT-SZ-to-Planck calibration is estimated to be $1.2\%$ in temperature.

We compare the two sets of maps by creating cross-power spectra.
Specifically, we construct many sets of two half-depth maps of SPT-SZ data by splitting all single observations of the
field into many sets of two halves and coadding.
We also create one set of two half-depth SPTpol maps and a full-depth SPTpol map.
We calculate the cross-spectrum between the two half-depth SPTpol maps using a procedure similar to that described in Section [IV.2](#S4.SS2 "IV.2. Cross-Spectra ‣ IV. Power Spectrum ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA").
For each semi-independent half-depth SPT-SZ map, we calculate the cross-spectrum between the half-depth SPT-SZ map and the full-depth SPTpol map, and we calculate the cross-spectrum ratio

|  |  |  |  |
| --- | --- | --- | --- |
|  | $r\_{b,i}=\frac{\widehat{D}^{\mathrm{\tiny{SPTSZ\ SPTpol}}}\_{b,i}}{\widehat{D}^{\mathrm{\tiny{SPTpol\ SPTpol}}}\_{b}}\ \frac{B^{\mathrm{SPTpol}}\_{b}}{B^{\mathrm{SPTSZ}}\_{b}},$ |  | (8) |

where $\widehat{D}^{AB}\_{b}$ is the binned cross-spectrum between maps $A$ and $B$ (details in Section [IV.2](#S4.SS2 "IV.2. Cross-Spectra ‣ IV. Power Spectrum ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA")),
$B^{\mathrm{SPTpol}}\_{b}$ is the SPTpol beam averaged over an $\ell$-space bin
(and similar for SPT-SZ), the index $i$ runs over the different half-depth SPT-SZ maps used,
and the bins $b$ span the range $200\leq\ell\leq 2200$ and have width $\Delta\ell=50$.
All maps from both experiments used in this procedure have been created with identical observation strategy and filtering, so the filter transfer function effectively divides out of this ratio.
For each bin, we calculate the mean and variance of $r\_{b,i}$ across all SPT-SZ half-depth maps.
We check that the distribution of $r\_{b}$ across all bins is consistent with a single underlying value,
and we calculate the final ratio as the inverse variance-weighted mean ratio over all bins.
In the power spectrum pipeline described in Section [IV](#S4 "IV. Power Spectrum ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"), we multiply all SPTpol maps by this final ratio before calculating cross-spectra.

The statistical uncertainty on the final SPT-SZ/SPTpol calibration ratio is given by the inverse of the square root of the total weight in all bins and is calculated to be $0.5\%$.
In the procedure described above, we have treated the SPTpol maps as noiseless,
because we expect the uncertainty in the ratio to be dominated by the noise in the SPT-SZ maps,
which is roughly three times the noise level of the SPTpol data on this field.22
2
We only use data from the 2008 SPT-SZ observations of this field.
Data were taken on this field in 2010 as well, but with an observation strategy that makes it more difficult to match the filter transfer function to SPTpol.
We have repeated the calculation using many sets of SPTpol half maps, and the change in the final uncertainty is minimal.
The $1.3\%$ temperature calibration uncertainty used in the cosmological fits described in Section [IX.1](#S9.SS1 "IX.1. Estimating Cosmological Parameters ‣ IX. Cosmological Constraints ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") is the quadrature sum of the uncertainties of the SPTpol-to-SPT-SZ and SPT-SZ-to-Planck calibrations.

### V.3. Polarization Calibration

Accurate reconstructions of $T$, $Q$, and $U$ maps require precisely measured polarization angles and polarization efficiencies for each detector.
SPTpol detectors operating at 150 GHz are arranged on the focal plane with nominal orientations
from 0∘ to 180∘ in steps of 15∘.
To measure the true detector polarization angles (including potential effects from telescope optics)
and to measure polarization efficiency, we perform a series of dedicated observations of a polarized calibration source located three km away from the telescope.
The polarization calibrator consists of a chopped thermal source located behind two wire grid polarizers. The grid closest to the thermal source is stationary and is used to establish a known polarization, while the second grid is rotated to modulate the polarization signal.
In order to avoid saturating detectors with the low-elevation atmosphere,
the source is placed in the middle of a 7 m $\times$ 7 m reflecting panel that redirects beams to the sky at an elevation of 60∘.
A 2 m-high wooden fence is installed half way between the source and the telescope to block reflections off the ground.

For each pair of detectors in a pixel, the telescope is pointed such that the source lies at the center of that pixel’s beam.
The rotating polarizer is then stepped back and forth from 0∘ to 165∘ in 15∘ steps,
and the detector response to the chopped signal as a function of the angle of the rotating grid is measured.
We fit the response as a function of rotating grid angle to a model that has the detector polarization angle and polarization efficiency as free parameters.
This procedure is repeated for all detectors on the focal plane, with multiple measurements per detector where possible.
We use these observations to establish distributions of measured angles for each grouping of detectors in a given module with a particular nominal angle.
For detectors without a direct angle measurement that pass data quality cuts ($\sim 40\%$ of the array), we assign the median value from the appropriate distribution. The same process is employed for deriving the polarization efficiencies.

Only observations with a statistical uncertainty of $<2^{\circ}$ on the alignment angle and $<5\%$ on the polarization efficiency are used for the polarization calibration analysis. Additional cuts are made on the goodness-of-fit of the best-fit model and detector linearity, both of which cut a small fraction of observations relative to the parameter uncertainty cuts. For the observations remaining after these cuts, the median statistical error on the fits to the polarization angle and efficiency are 0.46∘ and 0.8%, respectively, per detector. The mean difference between the measured and nominal alignment angles for all observations passing data quality cuts is $-1.0^{\circ}$. The mean polarization efficiency is $97\%$.

To estimate the systematic uncertainty on our alignment angles, we repeat the measurements for a subset of approximately 10 well-behaved detectors in several different experimental configurations.
First, to test for any sensitivity to the beam shape and our ability to focus on the external calibration source, we repeat the measurements with the telescope intentionally de-focused. Second, to test for sensitivity to reflections of the calibration signal off the ground, we repeat the measurements after removing the wooden fence located half way to the source.
Third, to test for our sensitivity to in-pixel crosstalk, we perform observations with only a single bolometer in each pixel biased in the superconducting transition. Finally, to check that our measurements are robust to a different function of source output power versus rotating polarizer angle, we remove the fixed polarizing grid inside the calibration source. For this last test, observations are repeated for all detectors rather than the subset of well-behaved detectors. We compare the measured angles from each of the above tests to those from observations in the standard configuration and find that resulting mean differences are consistent with zero, using an error on the mean calculated with a conservative per-detector, per-observation angle uncertainty of 1.5∘.
Using this same conservative value for the per-observation uncertainty, we estimate the total systematic error for each detector’s alignment angle to be 1∘. This systematic uncertainty is negligibly small for the $TE$ and $EE$ power spectrum measurements presented here, as it would result in a $\lesssim 0.1\%$ change in the amplitude of these spectra. The impact of the yet smaller statistical uncertainty was assessed using simulations, as described in Section [VII.2.2](#S7.SS2.SSS2 "VII.2.2 Detector Non-Idealities ‣ VII.2. Other Potential Systematic Effects ‣ VII. Tests for Systematic Errors ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"), and was also found to be negligibly small. Any error in the measured polarization efficiencies will leak temperature anisotropy into polarization anisotropy, and we address this effect in Section [VII.2.1](#S7.SS2.SSS1 "VII.2.1 Temperature to Polarization Leakage ‣ VII.2. Other Potential Systematic Effects ‣ VII. Tests for Systematic Errors ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA").

## VI. Bandpower Covariance Matrix

The bandpower covariance matrix quantifies the uncertainties in individual bandpowers and the correlations between bandpowers. We include covariance between $EE$ and $TE$ bandpowers,
giving the covariance matrix a $2\times 2$ block structure. The “on-diagonal” blocks are auto-covariances ($TE\times TE$ and $EE\times EE$), while the two “off-diagonal” blocks contain the cross-covariance ($TE\times EE$).
The covariance matrix includes contributions from noise variance, sample variance due to the finite number of modes measured in any given $\ell$-space bin, uncertainties in the instrument beam, and calibration uncertainty.

Sample variance for the auto-covariance blocks is estimated directly from the variance in the set of 782 simulated realizations of the SPTpol observations.
As described in [Lueker et al. [31]](#bib.bib31), the noise term is calculated from the variance in the measured cross-spectra $\widehat{D}^{AB}\_{b}$. The initial estimates of the sample and noise covariances $\widehat{\textbf{C}}\_{s}$ and $\widehat{\textbf{C}}\_{n}$ are biased, and we de-bias them using

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textbf{C}^{x,AB\times AB}\_{bb^{\prime}}=\left(K^{-1}\right)\_{bd}\widehat{\textbf{C}}^{x,AB\times AB}\_{dd^{\prime}}\left(K^{-1}\right)\_{d^{\prime}b^{\prime}},$ |  | (9) |

where $AB\in\{TE,\,EE\}$, $x\in\{\mathrm{s},\,\mathrm{n}\}$ for sample and noise covariance, respectively, and recall the $K$ matrix was defined in Section [IV.3](#S4.SS3 "IV.3. Unbiased Spectra ‣ IV. Power Spectrum ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA").

For reasons detailed in [Lueker et al. [31]](#bib.bib31), the signal-to-noise on off-diagonal elements is low. Thus, we condition the off-diagonal elements of each block in the covariance matrix. We first calculate the correlation matrix $\boldsymbol{\rho}\_{ii^{\prime}}$ for each auto-covariance block, and set all elements $\ell>400$ from the diagonal to zero. The shape of the correlation matrix is determined by mode-mode coupling, and is therefore only a function of distance from the diagonal. Thus, all remaining off-diagonal elements are replaced with the average of those elements at a fixed distance from the diagonal,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\boldsymbol{\rho}^{\prime}\_{ii^{\prime}}=\frac{\sum\_{i\_{1}-i\_{2}=i-i^{\prime}}\boldsymbol{\rho}\_{i\_{1}i\_{2}}}{\sum\_{i\_{1}-i\_{2}=i-i^{\prime}}1}.$ |  | (10) |

The conditioned correlation matrix is then transformed back into the corresponding auto-covariance block.

The $TE\times EE$ cross-covariance block is challenging to calculate.
Since off-diagonal correlations between spectra are inherently small, and we generate a limited number of map bundles with which to estimate noise variance, calculating this block as described above yields low signal-to-noise matrix elements.
Instead, we construct the $TE\times EE$ block from the pre-conditioned and de-biased auto-covariance matrices. Assuming covariances between different spectra are related by the theoretical expectations given by [Zaldarriaga & Seljak [56]](#bib.bib56), we define the $TE\times EE$ diagonal elements as an algebraic combination of the auto-covariance diagonals calculated above. The signs of the diagonal elements match those of the measured $TE$ bandpowers. The off-diagonal shape of the matrix is defined by its correlation matrix, which we set as the mean of the $TE\times TE$ and $EE\times EE$ correlation matrices. To determine the signs of off-diagonal matrix elements, we studied the covariances between $TE$ and $EE$ spectra generated from simulated maps with a simple cosine apodization mask applied. We found that signs in the simulated $TE\times EE$ cross-covariance propagated perpendicularly away from the diagonal. Off-diagonal elements between two diagonal elements received the sign of the averaged diagonal elements. Changing apodization masks in the simulations did not alter this behavior. Therefore, we apply the same off-diagonal sign propagation to the constructed $TE\times EE$ matrix.

Additional bin-to-bin covariance is generated due to uncertainties in the measurement of the beam function $B\_{\ell}$.
A “beam correlation matrix” is first constructed,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\boldsymbol{\rho}^{beam}\_{ij}=\left(\frac{\delta D\_{i}}{D\_{i}}\right)\left(\frac{\delta D\_{j}}{D\_{j}}\right)$ |  | (11) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{\delta D\_{i}}{D\_{i}}=1-\left(1+\frac{\delta B\_{i}}{B\_{i}}\right)^{-2},$ |  | (12) |

and $\frac{\delta B\_{i}}{B\_{i}}$ comes from the uncertainty in our measurements of Mars. The beam correlation matrix is then converted to a covariance matrix via

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textbf{C}^{beam}\_{ij}=\boldsymbol{\rho}^{beam}\_{ij}D\_{i}D\_{j}.$ |  | (13) |

Here $D\_{i}$ and $D\_{j}$ are drawn from the set of $TE$ or $EE$ bandpowers.

Finally, we may add covariance from uncertainty in our map calibration. Both temperature and polarization maps get multiplied by a temperature calibration factor, $T\_{\mathrm{cal}}$, while polarization maps are also multiplied by a polarization calibration factor, $P\_{\mathrm{cal}}$. In practice, we choose to keep these parameters free during cosmological fitting, as discussed in Section [IX.1](#S9.SS1 "IX.1. Estimating Cosmological Parameters ‣ IX. Cosmological Constraints ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") below, so we do not include covariance from calibration uncertainty by default. However, we can generate a total calibration uncertainty $\boldsymbol{\epsilon}\_{XY}$ from the uncertainties on $T\_{\mathrm{cal}}$ and $P\_{\mathrm{cal}}$ for each block in the covariance matrix, where $X$ and $Y$ are either $TE$ or $EE$.
The calibration covariance is then defined as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\textbf{C}^{cal}\_{ij}=\boldsymbol{\epsilon}\_{XY}D\_{i}D\_{j},$ |  | (14) |

where again $D\_{i}$ and $D\_{j}$ are $TE$ or $EE$ bandpowers corresponding to $X$ and $Y$.

## VII. Tests for Systematic Errors

### VII.1. Null Tests

We perform a suite of null, or jackknife, tests to check the internal consistency of our measurement.
A jackknife test entails dividing the data into two sets using a metric that might be associated with a systematic effect.
We pair each map bundle in the first set with a map bundle in the second set then difference the pairs of bundles to remove the common CMB signal. We perform the cross-spectrum analysis on the resulting sets of null maps with the same procedure we use to determine the power spectra of the data. Due to small changes in weights and filtering from observation to observation, the “expectation spectra” for each null test are in general non-zero. We calculate these expectation spectra by applying null tests to simulated maps. For each null test, the measured power spectra should be consistent with the expectation spectra if the particular systematic effect being probed is not present above our noise level. We test this by calculating the $\chi^{2}$ of the residual power relative to the expectation spectra in nine bins with $\Delta\ell=500$, from $\ell$ of 500 to 5000. We calculate the probability to exceed (PTE) of this value of $\chi^{2}$ with nine degrees of freedom.

We present four map-based jackknife tests.

1. -

   Left/Right: Difference maps are made by subtracting data in left-going scans from data in right-going scans.
   Power that is different in left and right-going scans could be induced by asymmetric telescope scanning and elevation steps.
2. -

   1st half/2nd half: Difference maps are made by subtracting data from the first half of the observing season from data from the second half of the observing season.
   This tests for systematic effects with a temporal dependence.
   Temporal variations in power could be caused by a calibration drift, time dependence of systematic signals, or the sun being above the horizon at the end of the season.
3. -

   Ground: Difference maps are made by dividing the maps based on potential ground contamination
   (using the same azimuthal range metric used in SPT-SZ power spectrum analyses, e.g., [Shirokoff et al. 47](#bib.bib47))
   and subtracting the worst half of maps from the best half.
   Power from ground contamination could be caused by features on the horizon such as buildings near the telescope.
4. -

   Moon:
   Difference maps are made by subtracting data taken when the moon was above the horizon from data
   taken when the moon was below the horizon.
   Power from the moon might be picked up via sidelobes when the moon is above the horizon.

The results of the tests are summarized in Table [1](#S7.T1 "Table 1 ‣ VII.1. Null Tests ‣ VII. Tests for Systematic Errors ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA").
The resulting PTE values for both the $TE$ and $EE$ spectra are roughly uniformly distributed between zero and one. We conclude that there is no evidence for systematic bias from this suite of null tests.

Table 1Jackknife Tests

| Test | $TE$ | $EE$ |
| --- | --- | --- |
| Left/Right | 0.58 | 0.06 |
| 1st half/2nd half | 0.43 | 0.64 |
| Ground | 0.74 | 0.44 |
| Moon | 0.12 | 0.58 |

### VII.2. Other Potential Systematic Effects

#### VII.2.1 Temperature to Polarization Leakage

A variety of systematic effects can cause filtered versions of the sky temperature, $T$, to contaminate our estimates of the Stokes $Q$ and $U$ polarization.
In the simplest case, the contamination is a scaled version of the temperature map.
For example, the contaminated portion of the $Q$ map would be $Q^{\rm{contam}}=\epsilon^{Q}T$.
As the fractional polarization of the CMB is small, even a small amount of leakage from $T$ can contaminate the $Q$ and $U$ signals; thus it is important to ensure that we correct for any such leakage.

We estimate the leakage parameters, $\epsilon^{P}$, where $P=\{Q,U\}$, using the cross-correlation between the temperature and polarization maps:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{\epsilon}^{P}=\frac{\sum\_{\ell,\phi\_{\ell}}C^{TP}\_{\ell,\phi\_{\ell}}}{\sum\_{\ell,\phi\_{\ell}}C^{TT}\_{\ell,\phi\_{\ell}}}.$ |  | (15) |

Here, the subscripts $(\ell,\phi\_{\ell})$ denote the radius and azimuthal angle, respectively, of the spectra in 2-D Fourier space.

We measure the cross-spectra, $C^{TP}\_{\ell}$ and $C^{TT}\_{\ell}$, using two maps,
each of which contains half of the full set of data analyzed here,
and we evaluate the sums across the multipole range $500<\ell<2500$.
We find $\hat{\epsilon}^{Q}=0.0105$ and $\hat{\epsilon}^{U}=-0.0152$. To correct for this leakage we subtract the appropriately scaled temperature map from each polarization map. We find that the $TE$ and $EE$ bandpowers shift by an amount that is small compared to their
uncertainties when these corrections are applied, and conclude that any
additional uncertainty caused by the $\pm 0.0015$ uncertainty in the
leakage parameters can be ignored.
We also find that performing the same procedure on maps made using leakage-free,
simulated observations introduces a negligible bias in the reconstructed $C^{TE}\_{\ell}$ and $C^{EE}\_{\ell}$ spectra.

The temperature-to-polarization contamination described above is the so-called “monopole” leakage,
in which the contamination is simply a scaled version of the temperature map.
However, more complicated forms of leakage could exist.
For example, uncorrected pointing offsets introduce dipole temperature leakage,
while differential beam ellipticity introduces quadrupole temperature leakage. These higher-order leakage terms form a $TE$ “leakage beam,” $G\_{\ell}^{TE}$.
We estimate the leakage beam by calculating the cross-correlation between $T$ and $E$-mode polarization maps of Venus observations:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $G\_{\ell}^{TE}=\frac{\sum\_{\phi\_{\ell}}\left(C^{TE}\_{\ell,\phi\_{\ell}}\right)\_{\mathrm{Venus}}}{\sum\_{\phi\_{\ell}}\left(C^{TT}\_{\ell,\phi\_{\ell}}\right)\_{\mathrm{Venus}}}.$ |  | (16) |

Observations of Venus, which is effectively a point source given the measured beam FWHM, have high signal-to-noise out to a radial distance of $\sim 10$
arcminutes, so this procedure captures the features of the leakage beam out to this angular scale.
To remove leaked systematic power in our $TE$ spectrum we subtract a copy of our measured $TT$ spectrum scaled by the leakage beam,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{\ell,\mathrm{corrected}}^{TE}=C\_{\ell,\mathrm{uncorrected}}^{TE}-G\_{\ell}^{TE}C\_{\ell}^{TT}.$ |  | (17) |

Before applying this correction we find significant ($\sim 4\sigma$) evidence for roughly constant-in-$C\_{\ell}$ power
beyond that expected from $\Lambda$CDM in our $TE$ spectrum (see Section [IX.1](#S9.SS1 "IX.1. Estimating Cosmological Parameters ‣ IX. Cosmological Constraints ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") for details). After applying the $TE$ leakage beam correction the significance drops to $1.4\sigma$.
We conclude that, after the $TE$ leakage beam correction, our $TE$ spectrum is free of statistically significant leakage power.
Since the leakage power enters into the $EE$ spectrum in a quadratic sense (i.e., with a prefactor of $[G\_{\ell}^{TE}]^{2}$), we also conclude that the higher-order (non-monopole) temperature-to-polarization leakage in our $EE$ spectrum is negligible in this analysis.

#### VII.2.2 Detector Non-Idealities

Our map-making procedure assumes that our detectors behave ideally
and have been perfectly characterized.
We know of several ways in which the true behavior of the detectors, or our knowledge of
that behavior,
violates this assumption.
We estimate the effects on the $EE$ and $TE$ power spectra from each of these non-idealities
individually through simulations. If necessary, we correct our power spectrum estimates using
the results of these simulations.

The response of the detectors to sky signals depends slightly on the amount of optical power on the detector. The column depth of atmosphere seen by the detectors changes with observing elevation,
resulting in an elevation-dependent detector responsivity.
By taking measurements with an internal calibration source at many elevations, we determine
the change in responsivity as a function of elevation for each detector individually.

There is also some low-level electrical crosstalk between detectors.
The observations of RCW38 discussed in Section [V.1](#S5.SS1 "V.1. Relative Calibration ‣ V. Calibration ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") are used to characterize the crosstalk.
Crosstalk manifests itself in these observations as duplicate copies of RCW38 in
a single detector’s map of the source. A model profile is constructed for each detector with one copy of
RCW38 at the center of the map and duplicates at the relative locations of all other detectors,
with the amplitudes of the duplicates as free parameters.
This model profile is fit to each detector’s map to determine the crosstalk matrix $X\_{ab}$, which encodes how
signal from detector $b$ leaks into the TOD of detector $a$.

The other detector non-ideality we investigate through simulations is imperfect knowledge of the detector polarization
angles. The uncertanties in the angle measurements are estimated as described in Section [V.3](#S5.SS3 "V.3. Polarization Calibration ‣ V. Calibration ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA").

Once these non-idealities are characterized, their effect on the output power spectrum is investigated using the
simulation pipeline described in Section [IV.4.1](#S4.SS4.SSS1 "IV.4.1 Simulations and the Transfer Function ‣ IV.4. Bandpower Window Functions ‣ IV. Power Spectrum ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"). The power spectra with these non-idealities included in the simulations are compared against the power spectra from simulations assuming ideal detector operation.
The power spectrum errors introduced by elevation-dependent responsivity and detector angle uncertainty are below one tenth of a sigma for each $\ell$-space bin and are randomly scattered.
Their total effect on our cosmological fits are negligible, so we ignore these two non-idealities.

The effect of electrical crosstalk, while still smaller than our bandpower uncertainties, is strongly correlated between $\ell$-space bins, and we correct our final bandpower estimates for this effect. The bulk of
the effect is due to the fact that the beam estimate we use to relate our biased power spectrum estimates
to the true power spectrum (Equation [4](#S4.E4 "In IV.3. Unbiased Spectra ‣ IV. Power Spectrum ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA")) is measured in temperature-only maps. The
electrical crosstalk in SPTpol is predominantly negative, and the effect of crosstalk on the composite
beam measured in temperature-only maps made from the data of many detectors
is to impart negative lobes at a distance
away from the main lobe equal to the mean crosstalk partner separation. (For SPTpol, this distance is
roughly two arcminutes.) This will be the correct effective beam for any temperature-only maps made
with the same detectors and weighting. For polarization maps, however, the mean effect of crosstalk
is zero, unless the amplitude of the crosstalk is correlated with detector polarization angle, which we
see no evidence of in SPTpol data. This means
that when we use the beam measured from temperature maps with cross-talk in the
polarized power spectrum estimation, we are incurring a multiplicative
bias related to the ratio of this beam to the true, non-cross-talk-biased beam.

We estimate the exact form of this bias in simulations and find that the bias imparts a roughly linear tilt on both spectra. The tilt ranges from $+2\%$ to $-4\%$ for $\ell=500-5000$ in the $EE$ spectrum and from $+1\%$ to $-2\%$ in the $TE$ spectrum across the same multipole range. After we correct for this bias, $\Lambda$CDM parameter values shift by less than $0.1\,\sigma$ and the limit on residual Poisson power in our $EE$ spectrum moves by $0.4\,\sigma$ (see Section [IX.4](#S9.SS4 "IX.4. Constraints on Polarized Power from Extragalactic Sources ‣ IX. Cosmological Constraints ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") for details). The uncertainty on our simulation-based estimate of this multiplicative bias is roughly 30%. The effect of this bias uncertainty on parameter estimates is far below our statistical uncertainties on all parameters, so we ignore it in our final cosmological fits.

#### VII.2.3 Sensitivity of the Analysis to Cosmological Model

We test the sensitivity of our analysis to differences between the model we assume for
sky power and the actual sky power we measure. To accomplish this, we create simulated maps with an input spectrum shifted by $\Delta\ell=10$ from the $\Lambda$CDM model spectrum assumed in the calculation of the transfer function in Section [IV.4.1](#S4.SS4.SSS1 "IV.4.1 Simulations and the Transfer Function ‣ IV.4. Bandpower Window Functions ‣ IV. Power Spectrum ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"). This approximates shifting the angular scale of the sound horizon at matter-radiation decoupling $\theta\_{\mathrm{s}}$. With the detection of several acoustic peaks in both the $TE$ and $EE$ spectra, $\theta\_{\mathrm{s}}$ is one of the parameters to which the SPTpol dataset is most sensitive. Using our standard pipeline and transfer function, we then calculate the power spectra of these simulated maps and compare them with the input spectra.
From this test we recover the $\ell$-shifted input spectra to well within the stated statistical uncertainty.

Figure 4.— The SPTpol $TE$ (Left) and $EE$ (Right) power spectra.
The solid gray lines are the Planck+SPT-SZ+SPTpol best-fit $\Lambda$CDM model described in Section [IX.2](#S9.SS2 "IX.2. Consistency with ΛCDM ‣ IX. Cosmological Constraints ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"). The x-axis is scaled to $l^{0.5}$. Residuals, $\Delta D\_{\ell}$, to the best-fit model are plotted in the sub-panels. Bandpower error bars include sample and noise variance.

Figure 5.— $TE$ (top) and $EE$ (bottom) power spectrum measurements.
In addition to SPTpol, we plot data from BICEP2 [[4](#bib.bib4)], WMAP9 [[21](#bib.bib21)], QUIET W-band [[43](#bib.bib43)], QUaD [[5](#bib.bib5)], and ACTpol [[36](#bib.bib36)].
The solid gray lines are the Planck+SPT-SZ+SPTpol best-fit $\Lambda$CDM model described in Section [IX.2](#S9.SS2 "IX.2. Consistency with ΛCDM ‣ IX. Cosmological Constraints ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"). The x-axis is scaled to $l^{0.5}$.

## VIII. Bandpowers

We present bandpowers and uncertainties for the $TE$ and $EE$ spectra at 150 GHz in Figure [4](#S7.F4 "Figure 4 ‣ VII.2.3 Sensitivity of the Analysis to Cosmological Model ‣ VII.2. Other Potential Systematic Effects ‣ VII. Tests for Systematic Errors ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") and Table [2](#S8.T2 "Table 2 ‣ VIII. Bandpowers ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"). The SPTpol bandpowers span the range $500<\ell\leq 5000$. In Figure [5](#S7.F5 "Figure 5 ‣ VII.2.3 Sensitivity of the Analysis to Cosmological Model ‣ VII.2. Other Potential Systematic Effects ‣ VII. Tests for Systematic Errors ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"), we plot the SPTpol bandpowers with recent measurements by other experiments. In both plots the solid gray lines are the Planck+SPT-SZ+SPTpol best-fit $\Lambda$CDM model described in Section [IX.2](#S9.SS2 "IX.2. Consistency with ΛCDM ‣ IX. Cosmological Constraints ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") below. The plotted SPTpol errors are the square root of the diagonal elements of the relevant auto-covariance block and do not include beam or calibration uncertainties.
As described in the next section, temperature and polarization absolute calibration are free parameters in the cosmological fits, and the bandpowers are corrected by the best-fit values for these parameters
and for the mean effect of crosstalk (Section [VII.2.2](#S7.SS2.SSS2 "VII.2.2 Detector Non-Idealities ‣ VII.2. Other Potential Systematic Effects ‣ VII. Tests for Systematic Errors ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA")).
The $TE$ bandpowers have also been corrected for temperature-to-polarization leakage as described in Section [VII.2.1](#S7.SS2.SSS1 "VII.2.1 Temperature to Polarization Leakage ‣ VII.2. Other Potential Systematic Effects ‣ VII. Tests for Systematic Errors ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"). The bandpowers are available at the SPT website33
3
http://pole.uchicago.edu/public/data/crites14/ along with the covariance matrix and bandpower window functions.

The $\ell$-space bins used to calculate SPTpol bandpowers have three widths:
$\delta\ell$ = 50 from 501 $\leq$ $\ell$ $\leq$ 2000, $\delta\ell$ = 100 from 2001 $\leq$ $\ell$ $\leq$ 2500,
and $\delta\ell$ = 500 from 2501 $\leq$ $\ell$ $\leq$ 5000.
The third through eighth peaks of the $EE$ power spectrum are measured with high signal-to-noise.
To date, this is the highest-fidelity measurement of the photon-diffusion-damped region of the $EE$ and $TE$ power spectra.

Table 2SPTpol $TE$ and $EE$ Bandpowers and Bandpower Errors

| $\ell$ range | $\ell\_{\rm eff}$ | $D\_{\ell}^{TE}$ | $\sigma^{TE}$ | $D\_{\ell}^{EE}$ | $\sigma^{EE}$ |
| --- | --- | --- | --- | --- | --- |
| 501 - 550 | 521 | -60.2 | 20.5 | 8.8 | 1.7 |
| 551 - 600 | 572 | 8.1 | 22.8 | 7.4 | 2.6 |
| 601 - 650 | 622 | -23.3 | 27.6 | 41.0 | 4.4 |
| 651 - 700 | 672 | -42.3 | 28.9 | 42.4 | 5.3 |
| 701 - 750 | 722 | -110.7 | 30.1 | 33.0 | 4.9 |
| 751 - 800 | 772 | -101.1 | 25.8 | 12.2 | 3.3 |
| 801 - 850 | 822 | -71.4 | 20.2 | 15.1 | 2.3 |
| 851 - 900 | 872 | 1.9 | 20.6 | 14.4 | 2.9 |
| 901 - 950 | 923 | 61.2 | 20.8 | 37.5 | 4.2 |
| 951 - 1000 | 973 | -24.6 | 20.4 | 31.2 | 5.0 |
| 1001 - 1050 | 1023 | -56.2 | 18.9 | 30.4 | 4.9 |
| 1051 - 1100 | 1073 | -100.5 | 16.8 | 29.3 | 3.6 |
| 1101 - 1150 | 1123 | -62.2 | 13.7 | 14.8 | 2.3 |
| 1151 - 1200 | 1173 | -19.1 | 11.8 | 11.5 | 2.2 |
| 1201 - 1250 | 1223 | 18.7 | 12.2 | 20.1 | 2.7 |
| 1251 - 1300 | 1273 | -23.5 | 12.8 | 31.9 | 3.3 |
| 1301 - 1350 | 1323 | -57.3 | 12.1 | 31.8 | 3.4 |
| 1351 - 1400 | 1373 | -38.8 | 10.9 | 16.9 | 2.7 |
| 1401 - 1450 | 1423 | -45.7 | 9.2 | 14.9 | 1.9 |
| 1451 - 1500 | 1473 | -6.2 | 8.1 | 8.2 | 1.6 |
| 1501 - 1550 | 1523 | -2.4 | 7.9 | 14.6 | 2.0 |
| 1551 - 1600 | 1573 | 8.9 | 7.7 | 20.3 | 2.3 |
| 1601 - 1650 | 1623 | -12.3 | 6.9 | 22.0 | 2.3 |
| 1651 - 1700 | 1673 | -33.5 | 6.6 | 15.5 | 2.1 |
| 1701 - 1750 | 1723 | -23.3 | 5.9 | 8.8 | 1.6 |
| 1751 - 1800 | 1773 | -16.0 | 4.9 | 8.6 | 1.5 |
| 1801 - 1850 | 1823 | -4.2 | 4.8 | 7.7 | 1.5 |
| 1851 - 1900 | 1873 | -0 | 4.5 | 8.6 | 1.5 |
| 1901 - 1950 | 1923 | -10.6 | 4.2 | 9.9 | 1.5 |
| 1951 - 2000 | 1973 | -14.5 | 4.0 | 10.6 | 1.5 |
| 2001 - 2100 | 2047 | -15.4 | 2.4 | 6.5 | 0.9 |
| 2101 - 2200 | 2147 | -2.7 | 2.0 | 5.6 | 0.8 |
| 2201 - 2300 | 2247 | -4.6 | 1.9 | 6.1 | 0.8 |
| 2301 - 2400 | 2348 | -8.6 | 1.7 | 4.3 | 1.0 |
| 2401 - 2500 | 2448 | -1.1 | 1.5 | 1.8 | 0.8 |
| 2501 - 3000 | 2745 | -3.07 | 0.55 | 1.81 | 0.40 |
| 3001 - 3500 | 3246 | -0.53 | 0.48 | 1.03 | 0.51 |
| 3501 - 4000 | 3746 | -0.13 | 0.55 | 0.11 | 0.64 |
| 4001 - 4500 | 4246 | 1.05 | 0.69 | 0.05 | 0.74 |
| 4501 - 5000 | 4747 | -0.07 | 0.83 | 1.34 | 1.05 |

## IX. Cosmological Constraints

### IX.1. Estimating Cosmological Parameters

We obtain constraints on cosmological parameters with CosmoMC, a Markov Chain Monte Carlo (MCMC) package [[29](#bib.bib29)]. As in past SPT analyses [[23](#bib.bib23), e.g., ], we have configured CosmoMC to use PICO44
4
https://sites.google.com/a/ucdavis.edu/pico/ [[14](#bib.bib14), [15](#bib.bib15)] trained with CAMB. To calculate the likelihood for the SPTpol bandpowers, we have written a new SPTpol-specific module for CosmoMC, which is also available on the SPT website.

The SPTpol likelihood introduces four nuisance parameters that are marginalized over when obtaining constraints on the six standard $\Lambda$CDM parameters. The first and second nuisance parameters are temperature and polarization calibration, $T\_{\mathrm{cal}}$ and $P\_{\mathrm{cal}}$, discussed above. After correcting the calibration of the maps as discussed in Sections [V.2](#S5.SS2 "V.2. Absolute Calibration ‣ V. Calibration ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") and [V.3](#S5.SS3 "V.3. Polarization Calibration ‣ V. Calibration ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") we apply a Gaussian prior to $T\_{\mathrm{cal}}$ centered on unity with a standard deviation of 0.013 and a uniform prior on $P\_{\mathrm{cal}}$ between 0.95 and 1.15. Expanding either limit of the prior does not alter our cosmological results. In this calibration scheme, $P\_{\mathrm{cal}}$ is degenerate with multiplicative biases that affect polarization but not temperature data. The combination of $T\_{\mathrm{cal}}$ and $P\_{\mathrm{cal}}$ can simultaneously account for calibration uncertainty and any constant-in-multipole multiplicative bias in either temperature-plus-polarization or polarization data alone. When fitting for and marginalizing over $T\_{\mathrm{cal}}$ and $P\_{\mathrm{cal}}$ we do not include calibration uncertainty in the bandpower covariance matrix. However, a version of the covariance matrix that includes calibration uncertainty calculated using the 68% limits for $T\_{\mathrm{cal}}$ and $P\_{\mathrm{cal}}$ in Table [3](#S9.T3 "Table 3 ‣ IX.3. ΛCDM Constraints ‣ IX. Cosmological Constraints ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") is available on the SPT website.

The third nuisance variable is a foreground term, $D^{\mathrm{PS\_{EE}}}\_{3000}$, parameterizing the level of residual polarized power from unclustered (or “Poisson”) point sources at $\ell=3000$ in the $EE$ spectrum after masking
all sources above 50 mJy in unpolarized flux.
The $\ell$ dependence of this signal is $D\_{\ell}\propto\ell^{2}.$

The final SPTpol nuisance parameter is $\kappa$, the mean lensing convergence in the field. As discussed in [Manzotti et al. [32]](#bib.bib32), a small patch of sky is lensed by modes larger than the patch itself such that the scale of anisotropies is dilated by lensing across the entire patch. For surveys with relatively small sky coverage such as the SPTpol 100d field, ignoring this effect can potentially lead to a non-negligible bias on the angular scale of the sound horizon at recombination, $\theta\_{\mathrm{s}}$. To account for this effect, we alter the theoretical spectra entering our likelihood calculation, which are functions of parameters p, to have dependence on $\kappa$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{C}\_{\ell}^{XY}\left(\mathbf{p};\kappa\right)=C\_{\ell}^{XY}\left(\mathbf{p}\right)-\frac{\partial\ell^{2}C\_{\ell}^{XY}\left(\mathbf{p}\right)}{\partial\ln\ell}\frac{\kappa}{\ell^{2}},$ |  | (18) |

as suggested by [Manzotti et al. [32]](#bib.bib32). We apply a Gaussian prior to $\kappa$ centered on zero with a standard deviation of $\sigma\_{\kappa}=2.45\times 10^{-3}$, which is the rms fluctuation in $\kappa$ across a 100 deg2 circular field for the flat $\Lambda$CDM Planck cosmology considered in [Manzotti et al. [32]](#bib.bib32).

To quantify the level of residual temperature-to-polarization leakage after correcting for monopole
and higher-order leakage terms (see Section [VII.2.1](#S7.SS2.SSS1 "VII.2.1 Temperature to Polarization Leakage ‣ VII.2. Other Potential Systematic Effects ‣ VII. Tests for Systematic Errors ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA")),
we include an extra nuisance parameter, $D^{\mathrm{PS\_{TE}}}\_{3000}$, which is defined analogously to the $EE$ foreground parameter above.
Note that the expectation value for $TE$ from point sources is zero, even for a single source
[[53](#bib.bib53), e.g.,], so this parameter is only used to quantify residual $T$ to $P$ leakage.
For all of the cosmological fits discussed below, $D^{\mathrm{PS\_{TE}}}\_{3000}$ is fixed at zero.

When fitting a cosmological model to the SPTpol bandpowers we also include two external datasets.
In particular, we consider measurements of the CMB $TT$ spectrum from Planck [[39](#bib.bib39)] as well as the 2500 deg2 SPT-SZ survey [[50](#bib.bib50)]. We note that the Planck, SPT-SZ, and SPTpol likelihoods treat foregrounds independently. Given that the 100d SPTpol field is only a small fraction of the area surveyed by SPT-SZ, and both the SPTpol and SPT-SZ regions are small compared to the full sky surveyed by Planck,
we also ignore any correlations between experimental results due to shared sky.

### IX.2. Consistency with $\Lambda$CDM

We check that the SPTpol dataset is consistent with the $\Lambda$CDM model. To quantify the goodness of fit, we calculate the $\chi^{2}$ between the Planck+SPT-SZ+SPTpol best-fit $\Lambda$CDM model and the SPTpol $TE$ and $EE$ bandpowers and errors scaled by the best-fit calibration parameters ($T\_{\mathrm{cal}}=0.992$ ; $P\_{\mathrm{cal}}=1.047$). (SPTpol bandpowers re-scaled by these calibration parameters are plotted in Figure [4](#S7.F4 "Figure 4 ‣ VII.2.3 Sensitivity of the Analysis to Cosmological Model ‣ VII.2. Other Potential Systematic Effects ‣ VII. Tests for Systematic Errors ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") along with their residuals to the Planck+SPT-SZ+SPTpol best-fit model). The resulting $\chi^{2}$ is 95.1 with 80 total bandpowers. While there are ten free parameters in the fit (six for $\Lambda$CDM + four SPTpol nuisance parameters), the Planck and SPT-SZ datasets effectively fix the $\Lambda$CDM parameters; with an observing area of only 100 deg2, the SPTpol bandpowers have large sample variance over the range of multipoles that best constrain the standard $\Lambda$CDM parameters. Consequently, there are effectively only four free parameters and therefore 76 degrees of freedom. This translates to a PTE of 0.07. If instead we fix the $\Lambda$CDM parameters to the best-fit values mentioned above and only fit for the SPTpol nuisance parameters, there are exactly four free parameters. In this case the $\chi^{2}$ and PTE are unchanged. We conclude the SPTpol bandpowers are adequately fit by the standard $\Lambda$CDM model and proceed to consider joint cosmological constraints.

### IX.3. $\Lambda$CDM Constraints

Table [3](#S9.T3 "Table 3 ‣ IX.3. ΛCDM Constraints ‣ IX. Cosmological Constraints ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") summarizes the results of parameter fits to the standard flat $\Lambda$CDM model with and without the inclusion of SPTpol data. As in [Planck Collaboration XVI [39]](#bib.bib39), our parameterization of $\Lambda$CDM uses the approximate angular size of the sound horizon $\theta\_{\mathrm{MC}}$ as calculated by CosmoMC instead of the true angular size $\theta\_{\mathrm{s}}$. We quote the amplitude of the spectrum $\ln(10^{10}A\_{\mathrm{s}})$ at a pivot scale of $k\_{0}=0.05$ Mpc-1. Constraints improve slightly when combining SPTpol with Planck+SPT-SZ and median parameter values move no more than $0.3\,\sigma$.

Table 3$\Lambda$CDM constraints

|  |  |  |
| --- | --- | --- |
| Parameter | Dataset | |
|  | Planck+SPT-SZ | Planck+SPT-SZ |
|  |  | +SPTpol |
| Free | |  |
| $\Omega\_{\mathrm{b}}h^{2}$ | $0.02207\pm 0.00027$ | $0.02203\pm 0.00026$ |
| $\Omega\_{\mathrm{c}}h^{2}$ | $0.1189\pm 0.0025$ | $0.1185\pm 0.0024$ |
| $100\theta\_{\mathrm{s}}$ | $1.04168\pm 0.00058$ | $1.04164\pm 0.00056$ |
| $n\_{\mathrm{s}}$ | $0.9597\pm 0.0068$ | $0.9593\pm 0.0067$ |
| $\ln(10^{10}A\_{\mathrm{s}})$ | $3.077\pm 0.024$ | $3.070\pm 0.024$ |
| $\tau$ | $0.084\pm 0.013$ | $0.081\pm 0.012$ |
| Derived | |  |
| $\Omega\_{\mathrm{\Lambda}}$ | $0.692\pm 0.015$ | $0.693\pm 0.015$ |
| $\sigma\_{8}$ | $0.820\pm 0.012$ | $0.816\pm 0.012$ |
| $H\_{0}$ | $67.8\pm 1.1$ | $67.9\pm 1.1$ |
| Nuisance | |  |
| $T\_{\mathrm{cal}}$ | — | $0.992\pm 0.012$ |
| $P\_{\mathrm{cal}}$ | — | $1.048\pm 0.017$ |
| $D^{\mathrm{PS\_{EE}}}\_{3000}$ | — | $<\,0.40\,\mu$K2 at 95$\%$ |
| $100\kappa$ | — | $0.047\pm 0.168$ |

### IX.4. Constraints on Polarized Power from Extragalactic Sources

The lack of significant high-$\ell$ power in the $EE$ spectrum shown in Figure [4](#S7.F4 "Figure 4 ‣ VII.2.3 Sensitivity of the Analysis to Cosmological Model ‣ VII.2. Other Potential Systematic Effects ‣ VII. Tests for Systematic Errors ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") indicates
that, at the level of point-source masking used in this analysis (all sources above 50 mJy in unpolarized flux
masked), polarized point sources do not contribute a significant residual to the $EE$ spectrum. As a confirmation of this, we find that the nuisance variable that describes this residual, $D^{\mathrm{PS\_{EE}}}\_{3000}$, has a best-fit amplitude of $D^{\mathrm{PS\_{EE}}}\_{3000}=0.07\pm 0.18\ \mu{\mbox{K}}^{2}$. When we interpret this
signal as coming from actual sources on the sky, we impose a $D^{\mathrm{PS\_{EE}}}\_{3000}>0$ prior; the
resulting posterior probability distribution for $D^{\mathrm{PS\_{EE}}}$ is shown in Figure [6](#S9.F6 "Figure 6 ‣ IX.4. Constraints on Polarized Power from Extragalactic Sources ‣ IX. Cosmological Constraints ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA").
There is clearly no detection of $D^{\mathrm{PS\_{EE}}}\_{3000}$ from our data, so we compute the $95\%$
confidence upper limit to this parameter and find $D^{\mathrm{PS\_{EE}}}\_{3000}<0.40\ \mu{\mbox{K}}^{2}$.
This corresponds to an upper limit on a constant-in-$\ell$ value of $C^{\mathrm{PS\_{EE}}}\_{\ell}<2.8\times 10^{-7}\ \mu{\mbox{K}}^{2}$, or $<1.8\ \mu{\mbox{K}}$-arcmin
rms fluctuations in the $E$-mode map contributed by Poisson sources.

The recent $EE$ spectrum
measurement from the ACTPol collaboration placed an upper limit of
$D^{\mathrm{PS\_{EE}}}\_{3000}<2.4\ \mu{\mbox{K}}^{2}$ at $95\%$ confidence with no sources masked [[36](#bib.bib36)].
The limit reported here
improves upon this by a factor of six, partially due to the source masking, but
mostly through higher sensitivity at high $\ell$. (This can be inferred from the fact that
neither experiment has detected the Poisson signal at high significance.)

Using this upper limit as the
amplitude of an $\ell^{2}$ term, we find that this signal crosses our best-fit $EE$ spectrum at
$\ell\simeq 3300$. In a future survey with higher signal-to-noise, this limit could be extended to higher $\ell$ with a more aggressive point source masking. We note that the 50 mJy threshold used in this work was not limited by source detection; in principle sources could have been masked down to at least 5 mJy in unpolarized flux, and future experiments could mask even more aggressively. The point-source power in $TT$ is reduced by at least $50\%$ when the source cut is lowered from 50 mJy to 6 mJy [[34](#bib.bib34), [18](#bib.bib18)]; if we assume the $EE$ power is similarly reduced, the resulting $95\%$ upper limit to polarized source power with a 6 mJy cut would cross our best-fit $EE$ spectrum at $\ell\simeq 3600$.

Under the assumption that the polarization angles of extragalactic sources are randomly distributed
(such that polarized point sources contribute equal $E$-mode and $B$-mode signal),
the anisotropy power contributed by point sources to the $EE$ spectrum is
equal to the product of the point-source anisotropy power in the $TT$ spectrum and the
flux-weighted, mean-squared polarization fraction of those sources.
Thus, using previous measurements of the $TT$ point-source anisotropy power,
our limit on polarized point-source power can be translated into an upper limit on the mean-squared
polarization of sources.
With a 50 mJy cut, point-source power in the $TT$ spectrum is expected to be
roughly equally distributed between synchrotron-dominated and dust-dominated sources, with
$D^{\mathrm{PS\_{TT}}}\_{3000}\simeq 9\ \mu{\mbox{K}}^{2}$ from each component [[34](#bib.bib34), [18](#bib.bib18)].
If we assume roughly equal contribution to $EE$ from each type of source, we find a $95\%$ upper limit
to the mean-squared polarization of sources of $0.021$, or an upper limit to rms polarization
fraction of $14\%$. If we instead assume that the polarization is dominated by the
synchrotron sources, we find an upper limit to the mean-squared polarization of those sources of
$0.041$, or an upper limit to rms polarization
fraction of $20\%$. These limits are significantly higher than estimates in the literature of the polarization
fraction of either type of source [[46](#bib.bib46), [2](#bib.bib2), e.g.,]; we therefore expect the contamination
from point sources to future $EE$ measurements to be even smaller than the limits considered above.

Figure 6.— 1-D marginalized posterior probability for $D^{\mathrm{PS\_{EE}}}\_{3000}$, the amplitude of residual $EE$ Poisson power in the SPTpol data.

## X. Conclusion

We have presented measurements of the $TE$ and $EE$ CMB polarization power spectra using
data from the first season of observations with SPTpol.
The third through eighth acoustic peaks in the $EE$ spectrum are measured with high signal-to-noise,
and the measurements of both spectra above $\ell\simeq 1500$ are the most sensitive to date. We have shown that the SPTpol dataset is consistent with the $\Lambda$CDM cosmological model preferred by previously published $TT$ spectra from the Planck and SPT-SZ instruments. The inclusion of SPTpol 100d data in cosmological fits marginally improves cosmological parameter
uncertainties, but due to the small map area and consequently large sample variance, this initial data set has limited cosmological constraining power.
However, the high-$\ell$ sensitivity leads to a significant improvement in the upper limits on the polarized
point-source power: the constraint on Poisson point-source power in the $EE$ spectrum at $\ell=3000$ is
$D^{\mathrm{PS\_{EE}}}\_{3000}<0.40\ \mu{\mbox{K}}^{2}$ at $95\%$ confidence, when masking sources with unpolarized flux $>50\,$mJy. This represents an improvement of a factor of six over previous limits and indicates that
power from uncorrelated point sources will not be a limiting factor to future $EE$ measurements in
the multipole range $\ell<3600$, and possibly much higher in $\ell.$

High-fidelity measurements of the $TT$, $TE$, and $EE$ power spectra now span a wide range of scales, from several arcminutes to tens of degrees. Current small-angular-scale CMB polarization measurements, including the SPTpol data presented here, mainly serve to provide another precision test of the base $\Lambda$CDM model. More precise measurements of the photon-diffusion-damped region of the polarized power spectra have the potential to place tight constraints on physics that alters the photon diffusion scale, such as the amount of primordial helium, $Y\_{\mathrm{p}}$, and the effective number of relativistic species, $N\_{\mathrm{eff}}$. Such measurements will be available in the very near future with data from the completed SPTpol 500 deg2 survey and from other instruments, such as ACTPol, Planck, and POLARBEAR.
With these upcoming datasets, we will begin to probe the physics revealed by the polarized CMB anisotropy on fine angular scales which will complement previous studies of CMB temperature anisotropy.

The contribution to high-$\ell$ power from residual point-source power and secondary anisotropies like the
thermal and kinetic SZ effects to the $TE$ and $EE$ spectra are expected to be far smaller than in the $TT$ power spectrum.
This is confirmed for point-source power by the limit presented above, which is a factor of $\sim 50$
below the measured $TT$ point-source power with the same source cut. Recent forecasts even suggest that the polarization power spectra can constrain the base $\Lambda$CDM cosmological parameters better than the temperature power spectrum, given sufficient sky coverage and sensitivity [[16](#bib.bib16)]. The measurements of the high-$\ell$ $TE$ and $EE$ spectra presented here represent an important step towards exploiting the cosmological power of measurements of the polarized damping tails.

We thank Joshua Schiffrin for help with the mode-mode coupling kernel calculation. We also thank Wayne Hu and Aurlien Benoit-Lévy for help implementing the super-sample lensing covariance. The McGill authors acknowledge funding from the Natural Sciences and Engineering Research Council of Canada, Canadian Institute for Advanced Research, and Canada Research Chairs program.
The South Pole Telescope program is supported by the National Science Foundation through grant PLR-1248097. Partial support is also provided by the NSF Physics Frontier Center grant PHY-0114422 to the Kavli Institute of Cosmological Physics at the University of Chicago, the Kavli Foundation, and the Gordon and Betty Moore Foundation through Grant GBMF#947 to the University of Chicago.
JWH is supported by the National Science Foundation under Award No. AST-1402161.
BB is supported by the Fermi Research Alliance, LLC under Contract No. De-AC02-07CH11359 with the U.S. Department of Energy.
The CU Boulder group acknowledges support from NSF AST-0956135.
This work is also supported by the U.S. Department of Energy.
Work at Argonne National Lab is supported by UChicago Argonne, LLC, Operator of Argonne National Laboratory (Argonne).
Argonne, a U.S. Department of Energy Office of Science Laboratory, is operated under Contract No. DE-AC02-06CH11357.
We also acknowledge support from the Argonne Center for Nanoscale Materials.
The data analysis pipeline uses the scientific python stack [[25](#bib.bib25), [26](#bib.bib26), [54](#bib.bib54)] and the HDF5 file format [[51](#bib.bib51)].

In this appendix, we calculate the mode-mode coupling kernel for the $EE$ and $TE$ power spectra.
This calculation closely follows the flat-sky calculation in Appendix A of [[22](#bib.bib22)],
but includes polarization as well as temperature

To remove point sources and taper the edges of our finite-sky coverage,
we multiply our $T$, $Q$, and $U$ maps by the mask in Figure [3](#S4.F3 "Figure 3 ‣ IV. Power Spectrum ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA").
This multiplication in 2-D real space is a convolution in Fourier space.
This has the effect of mixing 2-D Fourier modes of different $\boldsymbol{\ell}$.
The pseudo power spectrum $\tilde{C}\_{\ell}$ is the azimuthal average
of this altered 2-D spectrum.
The mode-mode coupling kernel is an analytical expression of how the mask
alters the underlying Gaussian spectrum.

For temperature, the mode-mixing kernel accounts for this convolution and azimuthal averaging.
For polarization, the mask is applied to the $Q$ and $U$ maps,
but there is an additional step to rotate into $E$ and $B$ before azimuthally averaging.
This rotation changes the form of the coupling kernel and also introduces $E/B$ mixing.
The effect that this has on the $TE$ and $EE$ power spectra is calculated here,
under the assumption that the underlying $BB$ power is negligible.

We write a field $X(\mathbf{r})$ on the plane with Fourier conjugate $X(\mathbf{k})$ as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $X(\mathbf{r})=\int{d\mathbf{k}\,\,X(\mathbf{k})e^{2i\pi\mathbf{k}\cdot\mathbf{r}}}\leftrightarrow X(\mathbf{k})=\int{d\mathbf{r}\,X(\mathbf{r})e^{-2i\pi\mathbf{k}\cdot\mathbf{r}}}\,,$ |  | (19) |

for $X\in[T,Q,U]$ and $\mathbf{k}\propto\boldsymbol{\ell}$.
We transform $Q$,$U$ to $E$,$B$ as shown in Eq. [1](#S3.E1 "In III.2. Map-Making: Time-Ordered Data to Maps ‣ III. Observations and Data Reduction ‣ MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") of the main text, using the conventions defined in [[55](#bib.bib55)], where
a particular 2-D Fourier component of $Q$ and $U$ is a simple linear combination (a rotation) of $E$ and $B$ for that same $\mathbf{k}$:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle Q(\mathbf{k\_{1}})$ | $\displaystyle=[E(\mathbf{k\_{1}})\cos(2\phi\_{k\_{1}})-\,B(\mathbf{k\_{1}})\sin(2\phi\_{k\_{1}})]$ | $\displaystyle=[E\_{1}C\_{1}-\,B\_{1}S\_{1}]$ |  | (20) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle U(\mathbf{k\_{1}})$ | $\displaystyle=[E(\mathbf{k\_{1}})\sin(2\phi\_{k\_{1}})+\,B(\mathbf{k\_{1}})\cos(2\phi\_{k\_{1}})]$ | $\displaystyle=[E\_{1}S\_{1}+\,B\_{1}C\_{1}]\ ,$ |  |

where we have used the following abbreviations to indicate the dependence on the first of many $\mathbf{k}$’s:
  
$C\_{1}\equiv\cos(2\phi\_{k\_{1}}),S\_{1}\equiv\sin(2\phi\_{k\_{1}})\hbox{ and }X\_{1}\equiv\,X(\mathbf{k\_{1}})$.
Solving these equations for $E$, $B$ (reversing the rotation), we find

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle E\_{1}$ | $\displaystyle=$ | $\displaystyle[Q\_{1}C\_{1}+\,U\_{1}S\_{1}]$ |  | (21) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle B\_{1}$ | $\displaystyle=$ | $\displaystyle[U\_{1}C\_{1}-\,Q\_{1}S\_{1}]\ .$ |  |

The altered “pseudo-” Fourier components on a plane that has been masked or weighted by $W(\mathbf{r})$ can be written as a convolution

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\tilde{X}(\mathbf{k\_{1}})$ | $\displaystyle=$ | $\displaystyle\int{d\mathbf{r}\,X(\mathbf{r})W(\mathbf{r})e^{-2i\pi\mathbf{k\_{1}}\cdot\mathbf{r}}}$ |  | (22) |
|  |  | $\displaystyle=$ | $\displaystyle\int{d\mathbf{k\_{2}}\,X(\mathbf{k\_{2}})W(\mathbf{k\_{1}}-\mathbf{k\_{2}})}$ |  |
|  |  | $\displaystyle=$ | $\displaystyle\int{d\mathbf{k\_{2}}\,X(\mathbf{k\_{2}})K\_{\mathbf{k\_{2},k\_{1}}}}.$ |  |

Here, $K\_{\mathbf{k\_{2},k\_{1}}}\equiv\int{d\mathbf{k^{\prime}}\,W(\mathbf{k^{\prime}})\delta(-\mathbf{k\_{1}}+\mathbf{k\_{2}}+\mathbf{k^{\prime}})}$ is the same as the scalar case, eqn (A7, A8) from [[22](#bib.bib22)].

Now calculate the pseudo power spectrum $\langle\,\_{EE}\tilde{C}\_{k\_{1}}\rangle$ by azimuthally averaging. For each Forier magnitude $k\_{1}$,

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\langle\,\_{EE}\tilde{C}\_{k\_{1}}\rangle$ | $\displaystyle\equiv$ | $\displaystyle\frac{1}{2\pi}\int{d\phi\_{1}\,\langle\,\tilde{E}\_{1}\,\tilde{E}\_{1}^{\*}\rangle}$ |  | (23) |
|  |  | $\displaystyle=$ | $\displaystyle\frac{1}{2\pi}\int{d\phi\_{1}\,\left[\langle\,\tilde{Q}\_{1}\,\tilde{Q}\_{1}^{\*}\rangle C\_{1}^{2}+\langle\,\tilde{U}\_{1}\,\tilde{U}\_{1}^{\*}\rangle S\_{1}^{2}+\langle\,\tilde{Q}\_{1}\,\tilde{U}\_{1}^{\*}\rangle C\_{1}S\_{1}+\langle\,\tilde{Q}\_{1}^{\*}\,\tilde{U}\_{1}\rangle C\_{1}S\_{1}\right]}\ .$ |  |

Consider the first term and write the pseudo-$\tilde{Q}$ in terms of a convolution of the unmasked-$Q$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{1}{2\pi}\int{d\phi\_{1}\,\langle\,\tilde{Q}\_{1}\,\tilde{Q}\_{1}^{\*}\rangle C\_{1}^{2}}=\frac{1}{2\pi}\int{d\phi\_{1}\,\int{\int{d\mathbf{k\_{2}}\,d\mathbf{k\_{3}}\,\langle\,Q\_{2}\,Q\_{3}^{\*}\rangle K\_{\mathbf{k\_{2},k\_{1}}}K\_{\mathbf{k\_{3},k\_{1}}}^{\*}C\_{1}^{2}}}}.$ |  | (24) |

Now write $Q$ in terms of $E$ and $B$.
Assuming that $E$ and $B$ are homogeneous, isotropic, Gaussian-distributed fields,
we can use $\langle\,E\_{k\_{2}}\,E\_{k\_{3}}^{\*}\rangle=\langle\,\_{EE}C\_{k\_{2}}\rangle\delta(\mathbf{k\_{2}-k\_{3}})$ to write this term as:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  | $\displaystyle=$ | $\displaystyle\frac{1}{2\pi}\int{d\phi\_{1}\,\int{\int{d\mathbf{k\_{2}}\,d\mathbf{k\_{3}}\,\left[\langle\,\_{EE}C\_{k\_{2}}\rangle C\_{2}C\_{3}+\langle\,\_{BB}C\_{k\_{2}}\rangle S\_{2}S\_{3}\right.}}}$ |  | (25) |
|  |  |  | $\displaystyle\qquad\qquad\qquad\qquad\qquad\qquad\left.-\langle\,\_{EB}C\_{k\_{2}}\rangle C\_{2}S\_{3}-\langle\,\_{EB}C\_{k\_{2}}\rangle S\_{2}C\_{3}\right]\delta(\mathbf{k\_{2}-k\_{3}})K\_{\mathbf{k\_{2},k\_{1}}}K\_{\mathbf{k\_{3},k\_{1}}}^{\*}C\_{1}^{2}.$ |  |

Integrate over $\mathbf{k\_{3}}$ using $\delta(\mathbf{k\_{2}-k\_{3}})$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $=\frac{1}{2\pi}\int{d\phi\_{1}\,\int{d\mathbf{k\_{2}}\,\left[+\langle\,\_{EE}C\_{k\_{2}}\rangle C\_{2}^{2}+\langle\,\_{BB}C\_{k\_{2}}\rangle S\_{2}^{2}-2\langle\,\_{EB}C\_{k\_{2}}\rangle C\_{2}S\_{2}\right]C\_{1}^{2}\,\left|K\_{\mathbf{k\_{2},k\_{1}}}\right|^{2}}}.$ |  | (26) |

Working out all four terms in Eq. [23](#A0.Ex5 "In MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA") yields

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\langle\,\_{EE}\tilde{C}\_{k\_{1}}\rangle$ | $\displaystyle=\,\frac{1}{2\pi}\int{d\phi\_{1}\,\int{d\mathbf{k\_{2}}\,}}[$ | $\displaystyle\langle\_{EE}C\_{k\_{2}}\rangle(C\_{2}C\_{1}+S\_{2}S\_{1})^{2}+$ |  | (27) |
|  |  |  | $\displaystyle\langle\_{BB}C\_{k\_{2}}\rangle(S\_{2}C\_{1}-C\_{2}S\_{1})^{2}+$ |  |
|  |  |  | $\displaystyle\langle\_{EB}C\_{k\_{2}}\rangle 2(S\_{1}C\_{1}(C\_{2}^{2}-S\_{2}^{2})-S\_{2}C\_{2}(C\_{1}^{2}-S\_{1}^{2}))]\,\left|K\_{\mathbf{k\_{2},k\_{1}}}\right|^{2}$ |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\int{dk\_{2}\,k\_{2}}[$ | $\displaystyle\!\!\!\!\!\!\!\!\!\mathbf{M}^{EE}\_{k\_{1}\,k\_{2}}\langle\_{EE}C\_{k\_{2}}\rangle+\mathbf{M}^{BB}\_{k\_{1}\,k\_{2}}\langle\_{BB}C\_{k\_{2}}\rangle+\mathbf{M}^{EB}\_{k\_{1}\,k\_{2}}\langle\_{EB}C\_{k\_{2}}\rangle]\ .$ |  | (28) |

The coupling kernel $\mathbf{M}^{XY}\_{k\_{1}\,k\_{2}}$, where $X,Y\in\{E,B\}$, depends only on the magnitude of $\mathbf{k\_{1}}$ and $\mathbf{k\_{2}}$ and is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{M}^{XY}\_{k\_{1}\,k\_{2}}\equiv\int{dk^{\prime}\,k^{\prime}\,\mathcal{W}(k^{\prime})\int{\!\!\int{d\phi\_{1}\,d\phi\_{2}\,\ A^{XY}\_{1,2}\,\delta(-\mathbf{k\_{1}}+\mathbf{k\_{2}}+\mathbf{k^{\prime}})}}},$ |  | (29) |

where $2\pi\mathcal{W}(k)=\int{d\phi\,W(\mathbf{k})W(\mathbf{k})^{\*}}$ is the azimuthally-integrated power spectrum of the mask.
Here, the coefficients $A^{XY}\_{1,2}$ correspond to the trigonometric coefficients in Eq. [27](#A0.Ex8 "In MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA").
Specifically, $A^{EE}\_{1,2}=(C\_{2}C\_{1}+S\_{2}S\_{1})^{2}$.
In this paper, we assume that $\langle\_{EE}C\_{k\_{2}}\rangle$ is much bigger than either $\langle\_{EB}C\_{k\_{2}}\rangle$ or $\langle\_{BB}C\_{k\_{2}}\rangle$, and consequently ignore the contributions to $\langle\,\_{EE}\tilde{C}\_{k\_{1}}\rangle$ from those terms in Eq. [27](#A0.Ex8 "In MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA").

We want to evaluate the integrals over $\phi\_{1}$ and $\phi\_{2}$ in Eq. [29](#A0.E29 "In MEASUREMENTS OF E-MODE POLARIZATION AND TEMPERATURE-E-MODE CORRELATION IN THE COSMIC MICROWAVE BACKGROUND FROM 100 SQUARE DEGREES OF SPTPOL DATA"); to accomplish this we need to evaluate expressions of the form $\iint\limits d\phi\_{1}\,d\phi\_{2}\,\delta(-\mathbf{k\_{1}}+\mathbf{k\_{2}}+\mathbf{k^{\prime}})G(\phi\_{1},\phi\_{2})$.
Make the variable substitution $\mathbf{k\_{4}}\equiv(\mathbf{k\_{2}+k^{\prime}})$ and use the relations $\delta(\mathbf{r}-\mathbf{r^{\prime}})=\frac{1}{r}\delta(r-r^{\prime})\delta(\phi-\phi^{\prime})$ and

|  |  |  |
| --- | --- | --- |
|  | $\delta\left(g(\phi\_{2})\right)=\sum\_{i}\frac{\delta\left(\phi\_{2}-\phi\_{2}^{(i)}\right)}{\left|g^{\prime}(\phi\_{2}^{(i)})\right|},$ |  |

where $\phi\_{2}^{(i)}$ are the $i$ roots of $g(\phi\_{2}^{(i)})=0$ between 0 and $2\pi$.
If $G(\phi\_{1},\phi\_{2})=1$, as in the $\mathbf{M}^{TT}$ case where $A^{TT}\_{1,2}=1$, then

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\iint\limits d\phi\_{1}\,d\phi\_{2}\,\delta(-\mathbf{k\_{1}}+\mathbf{k\_{2}}+\mathbf{k^{\prime}})$ | $\displaystyle=\frac{1}{k\_{1}}\int{d\phi\_{2}\delta\left(g(\phi\_{2})\right)}$ |  |  | (30) |
|  |  | $\displaystyle=\frac{1}{k\_{1}}\sum\_{i}\frac{1}{\left|g^{\prime}(\phi\_{2}^{(i)})\right|}$ |  |  |
|  |  | $\displaystyle=2\pi J(k\_{1},k\_{2},k^{\prime}),$ |  |  |

where $g(\phi\_{2})\equiv k\_{1}-\sqrt{k\_{2}^{2}+k^{\prime 2}+2k\_{2}k^{\prime}\cos(\phi^{\prime}-\phi\_{2})}$,
and $J(k\_{1},k\_{2},k^{\prime})\equiv(\frac{2}{\pi})\left[2k\_{1}^{2}k\_{2}^{2}+2k\_{1}^{2}k^{\prime 2}+2k\_{2}^{2}\,k^{\prime 2}-k\_{1}^{4}-k\_{2}^{4}-k^{\prime 4}\right]^{-1/2}$
for $|k\_{2}-k^{\prime}|<k\_{1}<k\_{2}+k^{\prime}$, and $J=0$ otherwise.
This is the result derived in Eq. (A10) from [[22](#bib.bib22)].

In the calculation of $\mathbf{M}^{EE}$, $G(\phi\_{1},\phi\_{2})=(C\_{2}C\_{1}+S\_{2}S\_{1})^{2}=\cos^{2}[2(\phi\_{2}-\phi\_{1})]$.
We derive an expression for $G(\phi\_{1},\phi\_{2})$ as follows: we define $\mathbf{k\_{4}}\equiv(\mathbf{k\_{2}+k^{\prime}})$ and without loss of generality set $\phi^{\prime}=0$; from this we derive the useful relation

|  |  |  |
| --- | --- | --- |
|  | $\cos(\phi\_{4})=\frac{k\_{2}\cos(\phi\_{2})+k^{\prime}}{\sqrt{k\_{2}^{2}+k^{\prime 2}+2k\_{2}k^{\prime}\cos(\phi\_{2})}}.$ |  |

We take advantage of the fact that $\cos(\phi\_{4})$ is only a function of $\phi\_{2}$ in order to write

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle G(\phi\_{1},\phi\_{2})$ | $\displaystyle=\cos^{2}[2(\phi\_{2}-\phi\_{4})]$ |  | (31) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\left(2\cos^{2}(\phi\_{2}-\phi\_{4})-1\right)^{2}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\left[2\left[\cos(\phi\_{4})\cos(\phi\_{2})+\sqrt{(1-\cos^{2}(\phi\_{4}))\cdot(1-\cos^{2}(\phi\_{2}))}\right]^{2}-1\right]^{2}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\equiv G(\cos(\phi\_{2})).$ |  |

Using this form we can write

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\iint\limits d\phi\_{1}\,d\phi\_{2}\,\delta(-\mathbf{k\_{1}}+\mathbf{k\_{2}}+\mathbf{k^{\prime}})G(\phi\_{1},\phi\_{2})$ | $\displaystyle=\frac{1}{k\_{1}}\int{d\phi\_{2}\,\delta(g(\phi\_{2}))\,G(\cos(\phi\_{2}))}$ |  | (32) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\frac{1}{k\_{1}}\sum\_{(+,-)}\frac{G(\cos(\phi\_{2}^{(+,-)}))}{\left|g^{\prime}(\phi\_{2}^{(+,-)})\right|}.$ |  |

Here, $g(\phi\_{2})=k\_{1}-\sqrt{k\_{2}^{2}+k^{\prime 2}+2k\_{2}k^{\prime}\cos(\phi^{\prime}-\phi\_{2})}=k\_{1}-\left|\mathbf{k\_{2}}+\mathbf{k^{\prime}}\right|$.
  
$g(\phi\_{2})$ has the same two roots, $\phi\_{2}^{(i)}=\phi\_{2}^{(+,-)}$, as in the TT calculation.
Specifically,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\phi\_{2}^{i}=\phi\_{2}^{(+,-)}=\pm\cos^{-1}\left(\frac{k\_{1}^{2}-(k\_{2}^{2}+k^{\prime 2})}{2k\_{2}\,k^{\prime}}\right).$ |  | (33) |

We find $\cos(\phi\_{2}^{+})=\cos(\phi\_{2}^{-})$, and evaluate the expression for $G(\phi\_{1},\phi\_{2})$ at these roots:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $G(\cos(\phi\_{2}^{(+)}))=\left[1-\frac{(k\_{1}^{2}+k\_{2}^{2}-k^{\prime 2})^{2}}{2k\_{1}^{2}k\_{2}^{2}}\right]^{2}\,.$ |  | (34) |

Thus the $EE$ coupling kernel is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{M}^{EE}\_{k\_{1}\,k\_{2}}=\int{dk^{\prime}\,k^{\prime}\,\mathcal{W}(k^{\prime})}2\pi J(k\_{1},k\_{2},k^{\prime})\cdot\left[1-\frac{(k\_{1}^{2}+k\_{2}^{2}-k^{\prime 2})^{2}}{2k\_{1}^{2}k\_{2}^{2}}\right]^{2}.$ |  | (35) |

The calculation of the mode-coupling kernel for $\langle\,\_{TE}\tilde{C}\_{k\_{1}}\rangle$ proceeds similarly.
We summarize this calculation as follows:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\langle\,\_{TE}\tilde{C}\_{k\_{1}}\rangle=\int{dk\_{2}\,k\_{2}\left[\mathbf{M}^{TE}\_{k\_{1}\,k\_{2}}\langle\_{TE}C\_{k\_{2}}\rangle+\mathbf{M}^{TB}\_{k\_{1}\,k\_{2}}\langle\_{TB}C\_{k\_{2}}\rangle\right]},$ |  | (36) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{M}^{TE}\_{k\_{1}\,k\_{2}}\equiv\int{dk\_{3}\,k\_{3}\,\mathcal{W}(k\_{3})\int{\int{d\phi\_{1}\,d\phi\_{2}\,\cos(2(\phi\_{k\_{2}}-\phi\_{k\_{1}}))\,\delta(-\mathbf{k\_{1}}+\mathbf{k\_{2}}+\mathbf{k\_{3}})}}}\,.$ |  | (37) |

We assume that $\langle\,\_{TE}\tilde{C}\_{k\_{1}}\rangle$ is much larger than $\langle\,\_{TB}\tilde{C}\_{k\_{1}}\rangle$, and thus only consider $\mathbf{M}^{TE}\_{k\_{1}\,k\_{2}}$.
The final expression for the $TE$ coupling kernel is:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{M}^{TE}\_{k\_{1}\,k\_{2}}=\int{dk^{\prime}\,k^{\prime}\,\mathcal{W}(k^{\prime})}2\pi J(k\_{1},k\_{2},k^{\prime})\*\left[1-\frac{(k\_{1}^{2}+k\_{2}^{2}-k^{\prime 2})^{2}}{2k\_{1}^{2}k\_{2}^{2}}\right]\,.$ |  | (38) |
