<!-- fulltext source=arxiv_html slug=arXiv-1502.02114 fetched=2026-09-18T01:16:52+00:00 -->

# Planck 2015 results. XX. Constraints on inflation

Planck Collaboration: P. A. R. Ade
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
N. Aghanim
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
M. Arnaud
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
F. Arroja
Affiliation: Istituto Nazionale di Fisica Nucleare, Sezione di Padova, via Marzolo 8, I-35131 Padova, Italy
Affiliation: Leung Center for Cosmology and Particle Astrophysics, National Taiwan University, Taipei 10617, Taiwan
  
M. Ashdown
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
J. Aumont
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
C. Baccigalupi
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
M. Ballardini
Affiliation: Dipartimento di Fisica e Astronomia, ALMA MATER STUDIORUM, Università degli Studi di Bologna, Viale Berti Pichat 6/2, I-40127, Bologna, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: INFN, Sezione di Bologna, Via Irnerio 46, I-40126, Bologna, Italy
  
A. J. Banday
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
R. B. Barreiro
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
N. Bartolo
Affiliation: Dipartimento di Fisica e Astronomia G. Galilei, Università degli Studi di Padova, via Marzolo 8, 35131 Padova, Italy
Affiliation: Istituto Nazionale di Fisica Nucleare, Sezione di Padova, via Marzolo 8, I-35131 Padova, Italy
  
E. Battaner
Affiliation: University of Granada, Departamento de Física Teórica y del Cosmos, Facultad de Ciencias, Granada, Spain
Affiliation: University of Granada, Instituto Carlos I de Física Teórica y Computacional, Granada, Spain
  
K. Benabed
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
A. Benoît
Affiliation: Institut Néel, CNRS, Université Joseph Fourier Grenoble I, 25 rue des Martyrs, Grenoble, France
  
A. Benoit-Lévy
Affiliation: Department of Physics and Astronomy, University College London, London WC1E 6BT, U.K.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
J.-P. Bernard
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
M. Bersanelli
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
P. Bielewicz
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Nicolaus Copernicus Astronomical Center, Bartycka 18, 00-716 Warsaw, Poland
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
J. J. Bock
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
A. Bonaldi
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
L. Bonavera
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
J. R. Bond
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
  
J. Borrill
Affiliation: Computational Cosmology Center, Lawrence Berkeley National Laboratory, Berkeley, California, U.S.A.
Affiliation: Space Sciences Laboratory, University of California, Berkeley, California, U.S.A.
  
F. R. Bouchet
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: Sorbonne Université-UPMC, UMR7095, Institut d’Astrophysique de Paris, 98 bis Boulevard Arago, F-75014, Paris, France
  
F. Boulanger
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
M. Bucher
††thanks: Corresponding authors: Martin Bucher, bucher@apc.univ-paris7.fr; Fabio Finelli, finelli@iasfbo.inaf.it
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
C. Burigana
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: INFN, Sezione di Bologna, Via Irnerio 46, I-40126, Bologna, Italy
  
R. C. Butler
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
E. Calabrese
Affiliation: Sub-Department of Astrophysics, University of Oxford, Keble Road, Oxford OX1 3RH, U.K.
  
J.-F. Cardoso
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: Laboratoire Traitement et Communication de l’Information, CNRS (UMR 5141) and Télécom ParisTech, 46 rue Barrault F-75634 Paris Cedex 13, France
  
A. Catalano
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
A. Challinor
Affiliation: Centre for Theoretical Cosmology, DAMTP, University of Cambridge, Wilberforce Road, Cambridge CB3 0WA, U.K.
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
A. Chamballu
Affiliation: DSM/Irfu/SPP, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
R.-R. Chary
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
H. C. Chiang
Affiliation: Astrophysics & Cosmology Research Unit, School of Mathematics, Statistics & Computer Science, University of KwaZulu-Natal, Westville Campus, Private Bag X54001, Durban 4000, South Africa
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
P. R. Christensen
Affiliation: Discovery Center, Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
Affiliation: Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
  
S. Church
Affiliation: Stanford University, Dept of Physics, Varian Physics Bldg, 382 Via Pueblo Mall, Stanford, California, U.S.A.
  
D. L. Clements
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
S. Colombi
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
L. P. L. Colombo
Affiliation: Department of Physics and Astronomy, Dana and David Dornsife College of Letter, Arts and Sciences, University of Southern California, Los Angeles, CA 90089, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
C. Combet
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
D. Contreras
Affiliation: Department of Physics & Astronomy, University of British Columbia, 6224 Agricultural Road, Vancouver, British Columbia, Canada
  
F. Couchot
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
A. Coulais
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
B. P. Crill
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
A. Curto
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
F. Cuttaia
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
L. Danese
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
R. D. Davies
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
R. J. Davis
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
P. de Bernardis
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
A. de Rosa
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
G. de Zotti
Affiliation: INAF - Osservatorio Astronomico di Padova, Vicolo dell’Osservatorio 5, Padova, Italy
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
J. Delabrouille
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
F.-X. Désert
Affiliation: IPAG: Institut de Planétologie et d’Astrophysique de Grenoble, Université Grenoble Alpes, IPAG, F-38000 Grenoble, France, CNRS, IPAG, F-38000 Grenoble, France
  
J. M. Diego
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
H. Dole
Affiliation: Institut Universitaire de France, 103, bd Saint-Michel, 75005, Paris, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
S. Donzelli
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
O. Doré
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
M. Douspis
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
A. Ducout
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
  
X. Dupac
Affiliation: European Space Agency, ESAC, Planck Science Office, Camino bajo del Castillo, s/n, Urbanización Villafranca del Castillo, Villanueva de la Cañada, Madrid, Spain
  
G. Efstathiou
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
  
F. Elsner
Affiliation: Department of Physics and Astronomy, University College London, London WC1E 6BT, U.K.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
T. A. Enßlin
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
H. K. Eriksen
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
J. Fergusson
Affiliation: Centre for Theoretical Cosmology, DAMTP, University of Cambridge, Wilberforce Road, Cambridge CB3 0WA, U.K.
  
F. Finelli$\;\!{}^{\*}$
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: INFN, Sezione di Bologna, Via Irnerio 46, I-40126, Bologna, Italy
  
O. Forni
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
M. Frailis
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
A. A. Fraisse
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
E. Franceschi
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
A. Frejsel
Affiliation: Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
  
A. Frolov
Affiliation: Simon Fraser University, Department of Physics, 8888 University Drive, Burnaby BC, Canada
  
S. Galeotta
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
S. Galli
Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, Chicago, IL 60637, USA
  
K. Ganga
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
C. Gauthier
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Affiliation: Leung Center for Cosmology and Particle Astrophysics, National Taiwan University, Taipei 10617, Taiwan
  
M. Giard
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
Y. Giraud-Héraud
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
E. Gjerløw
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
J. González-Nuevo
Affiliation: Departamento de Física, Universidad de Oviedo, Avda. Calvo Sotelo s/n, Oviedo, Spain
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
K. M. Górski
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
Affiliation: Warsaw University Observatory, Aleje Ujazdowskie 4, 00-478 Warszawa, Poland
  
S. Gratton
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
A. Gregorio
Affiliation: Dipartimento di Fisica, Università degli Studi di Trieste, via A. Valerio 2, Trieste, Italy
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
Affiliation: INFN/National Institute for Nuclear Physics, Via Valerio 2, I-34127 Trieste, Italy
  
A. Gruppuso
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
J. E. Gudmundsson
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
Affiliation: Nordita (Nordic Institute for Theoretical Physics), Roslagstullsbacken 23, SE-106 91 Stockholm, Sweden
Affiliation: The Oskar Klein Centre for Cosmoparticle Physics, Department of Physics,Stockholm University, AlbaNova, SE-106 91 Stockholm, Sweden
  
J. Hamann
Affiliation: Sydney Institute for Astronomy, School of Physics A28, University of Sydney, NSW 2006, Australia
Affiliation: Theory Division, PH-TH, CERN, CH-1211, Geneva 23, Switzerland
  
W. Handley
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
F. K. Hansen
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
D. Hanson
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
Affiliation: McGill Physics, Ernest Rutherford Physics Building, McGill University, 3600 rue University, Montréal, QC, H3A 2T8, Canada
  
D. L. Harrison
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
S. Henrot-Versillé
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
C. Hernández-Monteagudo
Affiliation: Centro de Estudios de Física del Cosmos de Aragón (CEFCA), Plaza San Juan, 1, planta 2, E-44001, Teruel, Spain
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
D. Herranz
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
S. R. Hildebrandt
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
E. Hivon
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
M. Hobson
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
  
W. A. Holmes
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
A. Hornstrup
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
W. Hovest
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
Z. Huang
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
  
K. M. Huffenberger
Affiliation: Department of Physics, Florida State University, Keen Physics Building, 77 Chieftan Way, Tallahassee, Florida, U.S.A.
  
G. Hurier
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
A. H. Jaffe
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
T. R. Jaffe
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
W. C. Jones
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
M. Juvela
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
  
E. Keihänen
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
  
R. Keskitalo
Affiliation: Computational Cosmology Center, Lawrence Berkeley National Laboratory, Berkeley, California, U.S.A.
  
J. Kim
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
T. S. Kisner
Affiliation: Lawrence Berkeley National Laboratory, Berkeley, California, U.S.A.
  
R. Kneissl
Affiliation: Atacama Large Millimeter/submillimeter Array, ALMA Santiago Central Offices, Alonso de Cordova 3107, Vitacura, Casilla 763 0355, Santiago, Chile
Affiliation: European Southern Observatory, ESO Vitacura, Alonso de Cordova 3107, Vitacura, Casilla 19001, Santiago, Chile
  
J. Knoche
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
M. Kunz
Affiliation: African Institute for Mathematical Sciences, 6-8 Melrose Road, Muizenberg, Cape Town, South Africa
Affiliation: Département de Physique Théorique, Université de Genève, 24, Quai E. Ansermet,1211 Genève 4, Switzerland
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
H. Kurki-Suonio
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
G. Lagache
Affiliation: Aix Marseille Université, CNRS, LAM (Laboratoire d’Astrophysique de Marseille) UMR 7326, 13388, Marseille, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
A. Lähteenmäki
Affiliation: Aalto University Metsähovi Radio Observatory and Dept of Radio Science and Engineering, P.O. Box 13000, FI-00076 AALTO, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
J.-M. Lamarre
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
A. Lasenby
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
M. Lattanzi
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
  
C. R. Lawrence
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
R. Leonardi
Affiliation: CGEE, SCS Qd 9, Lote C, Torre C, 4∘ andar, Ed. Parque Cidade Corporate, CEP 70308-200, Brasília, DF, Brazil
  
J. Lesgourgues
Affiliation: Institut für Theoretische Teilchenphysik und Kosmologie, RWTH Aachen University, D-52056 Aachen, Germany
Affiliation: Theory Division, PH-TH, CERN, CH-1211, Geneva 23, Switzerland
  
F. Levrier
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
A. Lewis
Affiliation: Department of Physics and Astronomy, University of Sussex, Brighton BN1 9QH, U.K.
  
M. Liguori
Affiliation: Dipartimento di Fisica e Astronomia G. Galilei, Università degli Studi di Padova, via Marzolo 8, 35131 Padova, Italy
Affiliation: Istituto Nazionale di Fisica Nucleare, Sezione di Padova, via Marzolo 8, I-35131 Padova, Italy
  
P. B. Lilje
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
M. Linden-Vørnle
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
M. López-Caniego
Affiliation: European Space Agency, ESAC, Planck Science Office, Camino bajo del Castillo, s/n, Urbanización Villafranca del Castillo, Villanueva de la Cañada, Madrid, Spain
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
P. M. Lubin
Affiliation: Department of Physics, University of California, Santa Barbara, California, U.S.A.
  
Y.-Z. Ma
Affiliation: Department of Physics & Astronomy, University of British Columbia, 6224 Agricultural Road, Vancouver, British Columbia, Canada
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
J. F. Macías-Pérez
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
G. Maggio
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
D. Maino
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
N. Mandolesi
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
A. Mangilli
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
M. Maris
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
P. G. Martin
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
  
E. Martínez-González
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
S. Masi
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
S. Matarrese
Affiliation: Dipartimento di Fisica e Astronomia G. Galilei, Università degli Studi di Padova, via Marzolo 8, 35131 Padova, Italy
Affiliation: Gran Sasso Science Institute, INFN, viale F. Crispi 7, 67100 L’Aquila, Italy
Affiliation: Istituto Nazionale di Fisica Nucleare, Sezione di Padova, via Marzolo 8, I-35131 Padova, Italy
  
P. McGehee
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
P. R. Meinhold
Affiliation: Department of Physics, University of California, Santa Barbara, California, U.S.A.
  
A. Melchiorri
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
Affiliation: INFN, Sezione di Roma 1, Università di Roma Sapienza, Piazzale Aldo Moro 2, 00185, Roma, Italy
  
L. Mendes
Affiliation: European Space Agency, ESAC, Planck Science Office, Camino bajo del Castillo, s/n, Urbanización Villafranca del Castillo, Villanueva de la Cañada, Madrid, Spain
  
A. Mennella
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
M. Migliaccio
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
S. Mitra
Affiliation: IUCAA, Post Bag 4, Ganeshkhind, Pune University Campus, Pune 411 007, India
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
M.-A. Miville-Deschênes
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
D. Molinari
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
A. Moneti
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
  
L. Montier
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
G. Morgante
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
D. Mortlock
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
A. Moss
Affiliation: School of Physics and Astronomy, University of Nottingham, Nottingham NG7 2RD, U.K.
  
M. Münchmeyer
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
  
D. Munshi
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
J. A. Murphy
Affiliation: National University of Ireland, Department of Experimental Physics, Maynooth, Co. Kildare, Ireland
  
P. Naselsky
Affiliation: Discovery Center, Niels Bohr Institute, Copenhagen University, Blegdamsvej 17, Copenhagen, Denmark
Affiliation: Niels Bohr Institute, Copenhagen University, Blegdamsvej 17, Copenhagen, Denmark
  
F. Nati
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
P. Natoli
Affiliation: Agenzia Spaziale Italiana Science Data Center, Via del Politecnico snc, 00133, Roma, Italy
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
C. B. Netterfield
Affiliation: Department of Astronomy and Astrophysics, University of Toronto, 50 Saint George Street, Toronto, Ontario, Canada
  
H. U. Nørgaard-Nielsen
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
F. Noviello
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
D. Novikov
Affiliation: Lebedev Physical Institute of the Russian Academy of Sciences, Astro Space Centre, 84/32 Profsoyuznaya st., Moscow, GSP-7, 117997, Russia
  
I. Novikov
Affiliation: Lebedev Physical Institute of the Russian Academy of Sciences, Astro Space Centre, 84/32 Profsoyuznaya st., Moscow, GSP-7, 117997, Russia
Affiliation: Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
  
C. A. Oxborrow
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
F. Paci
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
L. Pagano
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
Affiliation: INFN, Sezione di Roma 1, Università di Roma Sapienza, Piazzale Aldo Moro 2, 00185, Roma, Italy
  
F. Pajot
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
R. Paladini
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
S. Pandolfi
Affiliation: Dark Cosmology Centre, Niels Bohr Institute, University of Copenhagen, Juliane Maries Vej 30, 2100 Copenhagen, Denmark
  
D. Paoletti
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: INFN, Sezione di Bologna, Via Irnerio 46, I-40126, Bologna, Italy
  
F. Pasian
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
G. Patanchon
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
T. J. Pearson
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
H. V. Peiris
Affiliation: Department of Physics and Astronomy, University College London, London WC1E 6BT, U.K.
  
O. Perdereau
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
L. Perotto
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
F. Perrotta
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
V. Pettorino
Affiliation: HGSFP and University of Heidelberg, Theoretical Physics Department, Philosophenweg 16, 69120, Heidelberg, Germany
  
F. Piacentini
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
M. Piat
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
E. Pierpaoli
Affiliation: Department of Physics and Astronomy, Dana and David Dornsife College of Letter, Arts and Sciences, University of Southern California, Los Angeles, CA 90089, U.S.A.
  
D. Pietrobon
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
S. Plaszczynski
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
E. Pointecouteau
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
G. Polenta
Affiliation: Agenzia Spaziale Italiana Science Data Center, Via del Politecnico snc, 00133, Roma, Italy
Affiliation: INAF - Osservatorio Astronomico di Roma, via di Frascati 33, Monte Porzio Catone, Italy
  
L. Popa
Affiliation: Institute for Space Sciences, Bucharest-Magurale, Romania
  
G. W. Pratt
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
G. Prézeau
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
S. Prunet
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
J.-L. Puget
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
J. P. Rachen
Affiliation: Department of Astrophysics/IMAPP, Radboud University Nijmegen, P.O. Box 9010, 6500 GL Nijmegen, The Netherlands
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
W. T. Reach
Affiliation: Universities Space Research Association, Stratospheric Observatory for Infrared Astronomy, MS 232-11, Moffett Field, CA 94035, U.S.A.
  
R. Rebolo
Affiliation: Consejo Superior de Investigaciones Científicas (CSIC), Madrid, Spain
Affiliation: Departamento de Astrofísica, Universidad de La Laguna (ULL), E-38206 La Laguna, Tenerife, Spain
Affiliation: Instituto de Astrofísica de Canarias, C/Vía Láctea s/n, La Laguna, Tenerife, Spain
  
M. Reinecke
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
M. Remazeilles
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
C. Renault
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
A. Renzi
Affiliation: Dipartimento di Matematica, Università di Roma Tor Vergata, Via della Ricerca Scientifica, 1, Roma, Italy
Affiliation: INFN, Sezione di Roma 2, Università di Roma Tor Vergata, Via della Ricerca Scientifica, 1, Roma, Italy
  
I. Ristorcelli
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
G. Rocha
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
C. Rosset
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
M. Rossetti
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
G. Roudier
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
M. Rowan-Robinson
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
J. A. Rubiño-Martín
Affiliation: Departamento de Astrofísica, Universidad de La Laguna (ULL), E-38206 La Laguna, Tenerife, Spain
Affiliation: Instituto de Astrofísica de Canarias, C/Vía Láctea s/n, La Laguna, Tenerife, Spain
  
B. Rusholme
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
M. Sandri
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
D. Santos
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
M. Savelainen
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
G. Savini
Affiliation: Optical Science Laboratory, University College London, Gower Street, London, U.K.
  
D. Scott
Affiliation: Department of Physics & Astronomy, University of British Columbia, 6224 Agricultural Road, Vancouver, British Columbia, Canada
  
M. D. Seiffert
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
E. P. S. Shellard
Affiliation: Centre for Theoretical Cosmology, DAMTP, University of Cambridge, Wilberforce Road, Cambridge CB3 0WA, U.K.
  
M. Shiraishi
Affiliation: Dipartimento di Fisica e Astronomia G. Galilei, Università degli Studi di Padova, via Marzolo 8, 35131 Padova, Italy
Affiliation: Istituto Nazionale di Fisica Nucleare, Sezione di Padova, via Marzolo 8, I-35131 Padova, Italy
  
L. D. Spencer
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
V. Stolyarov
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Kazan Federal University, 18 Kremlyovskaya St., Kazan, 420008, Russia
Affiliation: Special Astrophysical Observatory, Russian Academy of Sciences, Nizhnij Arkhyz, Zelenchukskiy region, Karachai-Cherkessian Republic, 369167, Russia
  
R. Stompor
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
R. Sudiwala
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
R. Sunyaev
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
Affiliation: Space Research Institute (IKI), Russian Academy of Sciences, Profsoyuznaya Str, 84/32, Moscow, 117997, Russia
  
D. Sutton
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
A.-S. Suur-Uski
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
J.-F. Sygnet
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
  
J. A. Tauber
Affiliation: European Space Agency, ESTEC, Keplerlaan 1, 2201 AZ Noordwijk, The Netherlands
  
L. Terenzi
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: SMARTEST Research Centre, Università degli Studi e-Campus, Via Isimbardi 10, Novedrate (CO), 22060, Italy
  
L. Toffolatti
Affiliation: Departamento de Física, Universidad de Oviedo, Avda. Calvo Sotelo s/n, Oviedo, Spain
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
M. Tomasi
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
M. Tristram
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
T. Trombetti
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
M. Tucci
Affiliation: Département de Physique Théorique, Université de Genève, 24, Quai E. Ansermet,1211 Genève 4, Switzerland
  
J. Tuovinen
Affiliation: CRANN, Trinity College, Dublin, Ireland
  
L. Valenziano
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
J. Valiviita
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
B. Van Tent
Affiliation: Laboratoire de Physique Théorique, Université Paris-Sud 11 & CNRS, Bâtiment 210, 91405 Orsay, France
  
P. Vielva
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
F. Villa
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
L. A. Wade
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
B. D. Wandelt
Affiliation: Department of Physics, University of Illinois at Urbana-Champaign, 1110 West Green Street, Urbana, Illinois, U.S.A.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
I. K. Wehus
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
M. White
Affiliation: Department of Physics, University of California, Berkeley, California, U.S.A.
  
D. Yvon
Affiliation: DSM/Irfu/SPP, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
A. Zacchei
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
J. P. Zibin
Affiliation: Department of Physics & Astronomy, University of British Columbia, 6224 Agricultural Road, Vancouver, British Columbia, Canada
  
A. Zonca
Affiliation: Department of Physics, University of California, Santa Barbara, California, U.S.A.

###### Abstract

We present the implications for cosmic inflation of the Planck measurements of the
cosmic microwave background (CMB) anisotropies in both temperature and polarization based
on the full Planck survey, which includes more than twice the integration time
of the nominal survey used for the 2013 Release papers.
The Planck full mission temperature data and a first release of polarization data on
large angular scales measure the spectral index of curvature perturbations to be
$n\_{\mathrm{s}}=0.968\pm 0.006$ and tightly constrain its scale
dependence to $dn\_{\mathrm{s}}/d\ln k=-0.003\pm 0.007$ when combined with the Planck lensing likelihood.
When the Planck high-$\ell$ polarization data is included, the results
are consistent and uncertainties are further reduced.
The upper bound on the tensor-to-scalar ratio
is $r\_{0.002}<0.11$ (95 % CL).
This upper limit is consistent with the B-mode polarization constraint
$r<0.12$ (95 % CL)
obtained from a joint
analysis of the BICEP2/Keck Array and Planck data.
These results imply that
$V(\phi)\propto\phi^{2}$ and natural inflation are now
disfavoured compared to models predicting a smaller tensor-to-scalar ratio, such as $R^{2}$ inflation.
We search for several physically motivated deviations from a simple power-law spectrum
of curvature perturbations, including those motivated by a reconstruction of the
inflaton potential not relying on the slow-roll approximation. We find
that such models are not preferred, either according to a Bayesian model comparison
or according to a frequentist
simulation-based analysis.
Three independent methods reconstructing the primordial power spectrum
consistently recover a featureless and smooth ${\mathcal{P}}\_{\mathcal{R}}(k)$ over the range of scales $0.008\thinspace\mathrm{Mpc}^{-1}\lesssim k\lesssim 0.1\thinspace\mathrm{Mpc}^{-1}$.
At large scales, each method finds deviations from a power law, connected to a deficit at
multipoles $\ell\approx 20$–$40$ in the temperature power spectrum, but at
an uncompelling statistical significance owing to the large cosmic variance present at these multipoles.
By combining power spectrum and
non-Gaussianity bounds, we constrain models with generalized Lagrangians,
including Galileon models and axion monodromy models. The Planck data are
consistent with adiabatic primordial perturbations, and the estimated values for the
parameters of the base $\Lambda$CDM model are not significantly altered when
more general initial conditions are admitted. In correlated mixed adiabatic and isocurvature
models, the 95 % CL upper bound for the non-adiabatic contribution to the observed CMB
temperature variance is $|\alpha\_{\text{non-adi}}|<$ 1.9 %,
4.0 %, and 2.9 % for cold dark matter (CDM), neutrino density, and neutrino velocity isocurvature
modes, respectively. We have tested inflationary models producing an anisotropic
modulation of the primordial curvature power spectrum finding that the dipolar
modulation in the CMB temperature field induced by a CDM isocurvature perturbation is
not preferred at a statistically significant
level. We also establish tight constraints on a possible
quadrupolar modulation of the curvature perturbation. These results are consistent
with the Planck 2013 analysis based on the nominal mission data and further
constrain slow-roll single-field inflationary models, as expected from the increased precision
of Planck data using the full set of observations.

###### Key Words.

Cosmology: theory – early Universe – inflation

## 1 Introduction

The precise measurements by Planck11
1
Planck (<http://www.esa.int/Planck>) is a project of the European Space Agency
(ESA) with instruments provided by two scientific consortia funded by ESA member states and led by
Principal Investigators from France and Italy, telescope reflectors provided through a collaboration between
ESA and a scientific consortium led and funded by Denmark, and additional contributions from NASA (USA).
of the cosmic microwave background (CMB) anisotropies covering the entire sky and
over a broad range of scales, from the largest visible down to a resolution of approximately $5^{\prime}$, provide
a powerful probe of cosmic inflation, as detailed in the Planck 2013 inflation paper
([Planck Collaboration
XXII, 2014](#bib.bib205), hereafter [205](#bib.bib205)).
In the 2013 results, the robust detection of the departure of the scalar spectral
index from exact scale invariance, i.e., $n\_{\mathrm{s}}<1$, at more than $5\thinspace\sigma$
confidence, as well as the lack of the observation of any statistically significant
running of the spectral index, were found to be consistent with simple slow-roll models of inflation.
Single-field inflationary models with a standard kinetic term were also found to be compatible with
the new tight upper bounds on the
primordial non-Gaussianity parameters $f\_{\mathrm{NL}}$ reported in [Planck Collaboration
XXVI (2014)](#bib.bib209).
No evidence of isocurvature perturbations as generated in multi-field inflationary models
([205](#bib.bib205)) or by cosmic strings or topological defects was found ([Planck Collaboration
XXV, 2014](#bib.bib208)).
The Planck 2013 results overall favoured the simplest inflationary models. However, we noted
an amplitude deficit for multipoles $\ell\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}40$ whose statistical significance relative
to the six-parameter
base $\Lambda$ cold dark matter ($\Lambda$CDM) model is only about $2\thinspace\sigma$,
as well as other anomalies on large angular scales but also without compelling statistical significance
([Planck Collaboration
XXIII, 2014](#bib.bib206)). The constraint on the tensor-to-scalar ratio, $r<0.12$ at 95 % CL,
inferred from the temperature power spectrum alone, combined with the determination
of $n\_{\mathrm{s}}$,
suggested models with concave potentials.

This paper updates the implications
for inflation in the light of the Planck full mission temperature and polarization data.
The Planck 2013 cosmology results included only the nominal mission,
comprising the first 14 months of the data taken, and used only the temperature data.
However, the full mission includes the full 29 months of scientific data taken by the
cryogenically cooled high frequency instrument (HFI) (which ended when
the 3He/4He supply for the final stage of the cooling chain ran out) and the approximately
four years of data taken by the low frequency instrument (LFI), which covered a longer
period than the HFI because the LFI did not rely
on cooling down to 100 mK for its operation.
For a detailed discussion of the new likelihood and a comparison with the 2013 likelihood,
we refer the reader to [Planck Collaboration
XI (2016)](#bib.bib216) and [Planck Collaboration
XIII (2016)](#bib.bib218), but we mention here some
highlights of the differences between the 2013 and 2015 data processing and likelihoods:
(1) Improvements in the data processing such as beam characterization and absolute calibration at each frequency
result in a better removal of systematic effects and (2) the 2015 temperature high-$\ell$ likelihood uses half-mission cross-power spectra
over more of the sky, owing to less aggressive Galactic cuts.
The use of polarization information in the 2015 likelihood release contributes to the constraining
power of Planck in two principal ways: (1) The measurement of the $E$-mode polarization at large angular
scales (presently based on the 70 GHz channel) constrains the reionization
optical depth, $\tau,$ independently
of other estimates using ancillary data; and (2) the measurement
of the $TE$ and $EE$ spectra at $\ell\geq 30$ at the same frequencies used for the
$TT$ spectra (100, 143, and 217 GHz) helps break parameter degeneracies,
particularly for extended cosmological models (beyond the baseline six-parameter model).
A full analysis of the Planck low-$\ell$ polarization is still in progress and will be the
subject of another forthcoming set of Planck publications.

The Planck 2013 results have sparked a revival of interest in several aspects of
inflationary models. We mention here a few examples without the ambition to be exhaustive.
A lively debate arose on the conceptual problems of some of the inflationary models favoured
by the Planck 2013 data
([Ijjas et al., 2013](#bib.bib115); [Guth et al., 2014](#bib.bib107); [Linde, 2014](#bib.bib149); [Ijjas et al., 2014](#bib.bib116)).
The interest in the $R^{2}$ inflationary model originally proposed by
[Starobinsky (1980)](#bib.bib244) increased, since its predictions for cosmological
fluctuations ([Mukhanov & Chibisov, 1981](#bib.bib184); [Starobinsky, 1983](#bib.bib243))
are compatible with the Planck 2013 results ([205](#bib.bib205)).
It has been shown that supergravity motivates a potential similar to
the Einstein gravity conformal representation of the $R^{2}$ inflationary model in different contexts
([Ellis et al., 2013a](#bib.bib75); [Ellis et al., 2013b](#bib.bib76); [Buchmüller et al., 2013](#bib.bib44); [Farakos et al., 2013](#bib.bib80); [Ferrara et al., 2013b](#bib.bib85)).
A similar potential can also be generated by spontaneous breaking of
conformal symmetry ([Kallosh & Linde, 2013b](#bib.bib122)).

The constraining power of Planck also motivated a comparison between large numbers
of inflationary models ([Martin et al., 2014](#bib.bib165)) and stimulated different perspectives on how best to compare
theoretical inflationary predictions with observations based on the parameterized
dependence of the Hubble parameter on the scale factor during inflation ([Mukhanov, 2013](#bib.bib183); [Binétruy et al., 2014](#bib.bib35); [Garcia-Bellido & Roest, 2014](#bib.bib94)).
The interpretation of the asymmetries on large angular scales ([Planck Collaboration
XXIII, 2014](#bib.bib206))
also prompted a reanalysis of the primordial dipole modulation
([Lyth, 2013](#bib.bib156); [Liddle & Cortês, 2013](#bib.bib147); [Kanno et al., 2013](#bib.bib126)) of curvature perturbations during inflation.

Another recent development has been the renewed interest in possible tensor modes generated during inflation,
sparked by the BICEP2 results ([BICEP2 Collaboration, 2014a](#bib.bib32); [BICEP2 Collaboration, 2014b](#bib.bib33)).
The BICEP2 team suggested that the $B$-mode polarization signal detected
at $50<\ell<150$ at a single frequency
(150 GHz) might be of primordial origin. However, a crucial step in this possible
interpretation was excluding
an explanation based on polarized thermal dust emission from our Galaxy.
The BICEP2 team put forward a number of
models to estimate the likely contribution from dust, but at the time relevant observational data were
lacking, and this modelling involved a high degree of extrapolation.
If dust polarization were negligible in the observed patch of 380 deg2,
this interpretation would lead to a tensor-to-scalar ratio of $r=0.2^{+0.07}\_{-0.05}$ for a
scale-invariant spectrum.
A value of $r\approx 0.2$, as suggested by [BICEP2 Collaboration (2014b)](#bib.bib33),
would have obviously changed the Planck 2013 perspective according to which slow-roll inflationary models
are favoured, and such a high value of $r$ would also have required a strong running of the
scalar spectral index, or some other modification from a simple power-law spectrum,
to reconcile the contribution of gravitational waves to temperature anisotropies at low multipoles
with the observed $TT$ spectrum.

The interpretation of the $B$-mode signal in terms of gravitational waves alone presented in
[BICEP2 Collaboration (2014b)](#bib.bib33) was later cast in
doubt by Planck measurements of dust polarization at 353 GHz ([Planck Collaboration Int.
XIX, 2015](#bib.bib222); [Planck Collaboration Int.
XX, 2015](#bib.bib223); [Planck Collaboration Int.
XXI, 2015](#bib.bib224); [Planck Collaboration Int.
XXII, 2015](#bib.bib225)).
The Planck measurements characterized the frequency dependence
of intensity and polarization of the Galactic dust emission, and moreover showed that
the polarization fraction is higher than expected in regions of low dust emission.
With the help of the Planck measurements of Galactic dust properties ([Planck Collaboration Int.
XIX, 2015](#bib.bib222)),
it was shown that the interpretation of the $B$-mode polarization signal in terms of a
primordial tensor signal plus a lensing contribution
was not statistically preferred to an explanation
based on the expected dust signal at 150 GHz plus a lensing
contribution ([Flauger et al., 2014a](#bib.bib88); [Mortonson & Seljak, 2014](#bib.bib181), see also).
Subsequently, [Planck Collaboration Int.
XXX (2016)](#bib.bib226) extrapolated the Planck $B$-mode power
spectrum of dust polarization at 353 GHz over the multipole range $40<\ell<120$ to 150 GHz,
showing that the $B$-mode polarization signal detected by BICEP2 could be entirely due to dust.

More recently, a BICEP2/Keck Array-Planck (BKP) joint analysis
([BICEP2/Keck Array and Planck Collaborations, 2015](#bib.bib34), herafter [34](#bib.bib34)) combined
the high-sensitivity $B$-mode maps from BICEP2 and Keck Array
with the Planck maps at higher frequencies where dust emission dominates.
A study of the cross-correlations of all these maps
in the BICEP2 field found the absence
of any statistically significant evidence for primordial
gravitational waves, setting an upper limit of $r<0.12$ at 95 % CL ([34](#bib.bib34)).
Although this upper limit is numerically almost identical to the Planck 2013 result obtained combining
the nominal mission temperature data with WMAP polarization to remove parameter degeneracies
([Planck Collaboration
XVI, 2014](#bib.bib203); [Planck Collaboration
XXII, 2014](#bib.bib205)),
the BKP upper bound is much more robust against modifications of the inflationary model, since $B$ modes are
insensitive to the shape of the predicted scalar anisotropy pattern.
In Sect. [13](#S13 "13 Combination with BICEP2/Keck Array-Planck cross-correlation ‣ Planck 2015 results. XX. Constraints on inflation") we explore how the recent BKP analysis
constrains inflationary models.

This paper is organized as follows.
Section [2](#S2 "2 What new information does polarization provide? ‣ Planck 2015 results. XX. Constraints on inflation") briefly reviews the additional information on the primordial cosmological fluctuations
encoded in the polarization angular power spectrum.
Section [3](#S3 "3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation") describes the statistical methodology as well as the Planck and other likelihoods
used throughout the paper. Sections [4](#S4 "4 Constraints on the primordial spectrum of curvature perturbations ‣ Planck 2015 results. XX. Constraints on inflation") and [5](#S5 "5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation")
discuss the Planck 2015 constraints on scalar and tensor fluctuations,
respectively. Section [6](#S6 "6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation") is dedicated to constraints on the slow-roll parameters and
provides a Bayesian comparison of selected
slow-roll inflationary models. In Sect. [7](#S7 "7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") we reconstruct the inflaton potential and the Hubble parameter
as a Taylor expansion of the inflaton in the observable range without relying on the slow-roll approximation.
The reconstruction of the curvature perturbation power spectrum is presented in Sect. [8](#S8 "8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation").
The search for parameterized features is presented in Sect. [9](#S9 "9 Search for parameterized features ‣ Planck 2015 results. XX. Constraints on inflation"), and
combined constraints from the Planck 2015 power spectrum and primordial non-Gaussianity derived in
[Planck Collaboration
XVII (2016)](#bib.bib221) are presented in Sect. [10](#S10 "10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation").
The analysis of isocurvature perturbations combined and correlated with curvature perturbations
is presented in Sect. [11](#S11 "11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation").
In Sect. [12](#S12 "12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation") we study the implications of relaxing
the assumption of statistical isotropy of the primordial fluctuations.
We discuss two examples
of anisotropic inflation in light of the tests of isotropy performed in
[Planck Collaboration
XVI (2016)](#bib.bib220).
Section [14](#S14 "14 Conclusions ‣ Planck 2015 results. XX. Constraints on inflation") presents some concluding remarks.

## 2 What new information does polarization provide?

Figure 1: Comparison of transfer functions for the scalar and tensor modes.
The CMB transfer functions
$\Delta\_{\ell,\mathcal{A}}^{\mathrm{s}}(k)$
and
$\Delta\_{\ell,\mathcal{A}}^{\mathrm{t}}(k)$,
where $\mathcal{A}=T,E,B$, define the linear transformations mapping
the primordial scalar and tensor cosmological perturbations to the CMB
anisotropies as seen by us on the sky today. These functions are plotted
for two representative values of the multipole number:
$\ell=2$ (in black) and $\ell=65$ (in red).

This section provides a short theoretical overview
of the extra information provided by polarization data over that of
temperature alone. (More details can be found in [White et al. (1994)](#bib.bib259); [Ma & Bertschinger (1995)](#bib.bib159); [Bucher (2014)](#bib.bib41),
and references therein.)
In Sect. 2
of the Planck 2013 inflation paper ([205](#bib.bib205)), we gave an overview of the relation
between the inflationary potential and the three-dimensional
primordial scalar and tensor power spectra, denoted as
${\mathcal{P}}\_{\mathcal{R}}(k)$
and ${\mathcal{P}}\_{\mathrm{t}}(k),$
respectively. (The scalar variable $\mathcal{R}$ is defined precisely in
Sect. [3](#S3 "3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation")). We shall not repeat the discussion
there, instead referring the reader to [205](#bib.bib205) and references therein.

Under the assumption of statistical isotropy, which is predicted in all simple models of
inflation, the two-point correlations of the CMB anisotropies
are described by the angular power spectra
$C^{TT}\_{\ell},$
$C^{TE}\_{\ell},$
$C^{EE}\_{\ell},$
and
$C^{BB}\_{\ell},$
where $\ell$ is the multipole number. (See
[Kamionkowski et al. (1997)](#bib.bib125); [Zaldarriaga & Seljak (1997)](#bib.bib260); [Seljak & Zaldarriaga (1997)](#bib.bib237); [Hu & White (1997)](#bib.bib114); [Hu et al. (1998)](#bib.bib113) and references therein
for early discussions elucidating the role of polarization.)
In principle, one could also envisage
measuring $C^{BT}\_{\ell}$ and $C^{BE}\_{\ell}$, but in theories where parity
symmetry is not explicitly or spontaneously broken, the expectation values for these cross
spectra (i.e., the theoretical cross spectra) vanish, although the observed realizations of the cross spectra
are not exactly zero because of cosmic variance.

The CMB angular power spectra are related to the three-dimensional scalar and tensor
power spectra via the transfer functions
$\Delta\_{\ell,\mathcal{A}}^{\mathrm{s}}(k)$
and
$\Delta\_{\ell,\mathcal{A}}^{\mathrm{t}}(k),$
so that the contributions from scalar and tensor perturbations are

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C^{\mathcal{AB},\mathrm{s}}\_{\ell}=\int\_{0}^{\infty}\frac{\mathrm{d}k}{k}\penalty\ \Delta\_{\ell,\mathcal{A}}^{\mathrm{s}}(k)\penalty\ \Delta\_{\ell,\mathcal{B}}^{\mathrm{s}}(k)\penalty\ {\mathcal{P}}\_{\mathcal{R}}(k)$ |  | (1) |

and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C^{\mathcal{AB},\mathrm{t}}\_{\ell}=\int\_{0}^{\infty}\frac{\mathrm{d}k}{k}\penalty\ \Delta\_{\ell,\mathcal{A}}^{\mathrm{t}}(k)\penalty\ \Delta\_{\ell,\mathcal{B}}^{\mathrm{t}}(k)\penalty\ {\mathcal{P}}\_{\mathrm{t}}(k),$ |  | (2) |

respectively, where $\mathcal{A,B}=T,E,B.$ The scalar and tensor primordial
perturbations are uncorrelated in the simplest models, so
the scalar and tensor power spectra add in quadrature, meaning that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C^{\mathcal{AB},\mathrm{tot}}\_{\ell}=C^{\mathcal{AB},\mathrm{s}}\_{\ell}+C^{\mathcal{AB},\mathrm{t}}\_{\ell}.$ |  | (3) |

Roughly speaking, the form of the linear transformations encapsulated in the transfer functions
$\Delta\_{\ell,\mathcal{A}}^{\mathrm{s}}(k)$ and $\Delta\_{\ell,\mathcal{A}}^{\mathrm{t}}(k)$
probe the late time physics,
whereas
the primordial power spectra
${\mathcal{P}}\_{\mathcal{R}}(k)$
and
${\mathcal{P}}\_{\mathrm{t}}(k)$
are solely determined by the primordial Universe,
perhaps not so far below the Planck scale if large-field inflation turns out to be correct.

To better understand this connection, it is useful to plot and compare the shapes of the
transfer functions for
representative values of $\ell$ and characterize their qualitative behavior.
Referring to Fig. [1](#S2.F1 "Figure 1 ‣ 2 What new information does polarization provide? ‣ Planck 2015 results. XX. Constraints on inflation"), we emphasize the following qualitative features:

1. 1.

   For the scalar mode transfer functions, of
   which only
   $\Delta\_{\ell,T}^{\mathrm{s}}(k)$
   and
   $\Delta\_{\ell,E}^{\mathrm{s}}(k)$
   are non-vanishing (because
   to linear order, a three-dimensional scalar mode
   cannot contribute to the $B$ mode of the
   polarization), both transfer functions start to rise
   at more or less the same
   small values of $k$ (due to the centrifugal barrier
   in the Bessel differential equation), but
   $\Delta\_{\ell,E}^{\mathrm{s}}(k)$
   falls off much faster
   at large $k$ and thus smooths sharp features in
   $\mathcal{P}\_{\mathcal{R}}(k)$ to a lesser extent than
   $\Delta\_{\ell,T}^{\mathrm{s}}(k).$ This means that polarization
   is more powerful than temperature for reconstructing possible sharp
   features in the scalar primordial power spectrum
   provided that the required signal-to-noise is available.
2. 2.

   For the tensor modes,
   $\Delta\_{\ell,T}^{\mathrm{t}}(k)$ starts rising
   at about the same small $k$ as $\Delta\_{\ell,T}^{\mathrm{s}}(k)$ and $\Delta\_{\ell,E}^{\mathrm{s}}(k)$
   but falls off faster with increasing $k$ than
   $\Delta\_{\ell,T}^{\mathrm{s}}(k).$
   On the other hand, the polarization components,
   $\Delta\_{\ell,E}^{\mathrm{t}}(k)$ and $\Delta\_{\ell,B}^{\mathrm{t}}(k),$ have a shape
   completely different from any of the other transfer functions. The shape of
   $\Delta\_{\ell,E}^{\mathrm{t}}(k)$ and $\Delta\_{\ell,B}^{\mathrm{t}}(k)$ is much wider in $\ln(k)$
   than the scalar polarization transfer function, with
   a variance ranging from 0.5 to 1.0 decades. These functions exhibit
   several oscillations with a period smaller than that for scalar transfer functions,
   due to the difference between the sound velocity for scalar fluctuations and the light velocity
   for gravitational waves ([Polarski & Starobinsky, 1996](#bib.bib227); [Lesgourgues et al., 2000](#bib.bib142)).

Regarding the scalar primordial cosmological perturbations, the power spectrum
of the $E$-mode polarization provides an important consistency check. As we explore
in Sects. [8](#S8 "8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") and [9](#S9 "9 Search for parameterized features ‣ Planck 2015 results. XX. Constraints on inflation"), to some extent
the fit of the temperature power spectrum can be improved by allowing a complicated
form for the primordial power spectrum (relative to a simple power law), but
the $C^{TE}\_{\ell}$ and $C^{EE}\_{\ell}$ power spectra provide independent information. Moreover,
in multi-field inflationary models, in which isocurvature modes may have been excited
(possibly correlated amongst themselves as well as with the adiabatic mode),
polarization information provides a powerful way to break degeneracies
([Bucher et al., 2001](#bib.bib43), see, e.g.,).

The inability of scalar modes to generate $B$-mode polarization (apart from
the effects of lensing) has an important consequence. For the primordial tensor
modes, polarization information, especially
information concerning the $B$-mode polarization, offers powerful potential for discovery or
for establishing upper bounds. Planck 2013 and
WMAP established upper bounds on a possible tensor mode contribution using
$C^{TT}\_{\ell}$ alone, but
these bounds crucially relied on assuming a simple form for the scalar primordial power
spectrum. For example, as reported in [205](#bib.bib205),
when a simple power law was generalized to allow for running, the bound on the
tensor contribution degraded by approximately a factor of two. The new joint
BICEP2/Keck Array-Planck upper bound (see Sect. [13](#S13 "13 Combination with BICEP2/Keck Array-Planck cross-correlation ‣ Planck 2015 results. XX. Constraints on inflation")), however, is much more robust and cannot be
avoided by postulating baroque models that alter the scale dependence of the scalar power
spectrum.

## 3 Methodology

This section describes updates to the
formalism used to describe cosmological models and the likelihoods used
with respect to
the Planck 2013 inflation paper ([205](#bib.bib205)).

### 3.1 Cosmological model

The cosmological models that predict observables such as the CMB anisotropies
rely on inputs specifying the conditions
and physics at play during different epochs of the history of the Universe. The
primordial inputs describe the power spectrum of the cosmological
perturbations at a time when all the observable modes were situated outside
the Hubble radius. The inputs from this epoch consist of the primordial power spectra,
which may include scalar curvature perturbations, tensor perturbations, and
possibly also isocurvature modes and their correlations.
The late time (i.e., $z\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}10^{4}$)
cosmological inputs include parameters such as $\omega\_{\mathrm{b}},$ $\omega\_{\mathrm{c}},$
$\Omega\_{\Lambda},$ and $\tau$, which determine the conditions when the primordial
perturbations become imprinted on the CMB and also the evolution of the Universe
between last scattering and today, affecting primarily the angular diameter
distance. Finally, there is a so-called “nuisance” component, consisting of parameters
that determine how the measured CMB spectra are contaminated by unsubtracted
Galactic and extragalactic foreground contamination.
The focus of this paper is on the primordial inputs and how they are constrained by
the observed CMB anisotropy, but we cannot completely ignore the other
non-primordial parameters because their presence and uncertainties
must be dealt with in order to correctly extract the primordial
information of interest here.

As in [205](#bib.bib205), we adopt the minimal six-parameter
spatially flat base $\Lambda$CDM cosmological model as our baseline
for the late time cosmology, mainly altering the primordial inputs,
i.e., the simple power-law spectrum parameterized by the scalar amplitude and
spectral index
for the adiabatic growing mode, which in this minimal model is the only
late time mode excited.
This model has
four free non-primordial cosmological parameters $(\omega\_{\mathrm{b}},\omega\_{\mathrm{c}},\theta\_{\mathrm{MC}},\tau)$ ([Planck Collaboration
XIII, 2016](#bib.bib218), for a more detailed account of this
model, we refer the reader to).
On occasion, this assumption will be relaxed in order to consider the impact of
more complex alternative late time cosmologies on our conclusions about inflation.
Some of the commonly used cosmological parameters are defined in
Table [1](#S3.T1 "Table 1 ‣ 3.1 Cosmological model ‣ 3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation").

Table 1: Primordial, baseline, and optional late-time cosmological parameters.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  | | --- | --- | | Parameter | Definition | | $A\_{\mathrm{s}}$. | Scalar power spectrum amplitude (at $k\_{\*}=0.05\thinspace{\mathrm{Mpc}}^{-1}$) | | $n\_{\mathrm{s}}$. | Scalar spectral index (at $k\_{\*}=0.05\thinspace{\mathrm{Mpc}}^{-1}$ unless otherwise stated) | | $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$. | Running of scalar spectral index (at $k\_{\*}=0.05\thinspace{\mathrm{Mpc}}^{-1}$ unless otherwise stated) | | $\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}$. | Running of running of scalar spectral index (at $k\_{\*}=0.05\thinspace{\mathrm{Mpc}}^{-1}$) | | $r$. | Tensor-to-scalar power ratio (at $k\_{\*}=0.05\thinspace{\mathrm{Mpc}}^{-1}$ unless otherwise stated) | | $n\_{\mathrm{t}}$. | Tensor spectrum spectral index (at $k\_{\*}=0.05\thinspace{\mathrm{Mpc}}^{-1}$) | |  |  | | $\omega\_{\mathrm{b}}\equiv\Omega\_{\mathrm{b}}\thinspace h^{2}$. | Baryon density today | | $\omega\_{\mathrm{c}}\equiv\Omega\_{\mathrm{c}}\thinspace h^{2}$. | Cold dark matter density today | | $\theta\_{\mathrm{MC}}$. | Approximation to the angular size of sound horizon at last scattering | | $\tau$. | Thomson scattering optical depth of reionized intergalactic medium | |  |  | | $N\_{\mathrm{eff}}$. | Effective number of massive and massless neutrinos | | $\Sigma m\_{\nu}$. | Sum of neutrino masses | | $Y\_{\mathrm{P}}$. | Fraction of baryonic mass in primordial helium | | $\Omega\_{K}$. | Spatial curvature parameter | | $w\_{\mathrm{de}}$. | Dark energy equation of state parameter (i.e., $p\_{\mathrm{de}}/\rho\_{\mathrm{de}}$) (assumed constant) | |  |

### 3.2 Primordial spectra of cosmological fluctuations

In inflationary models, comoving curvature (${\mathcal{R}}$) and tensor ($h$)
fluctuations are amplified by the nearly exponential expansion from quantum vacuum fluctuations to become
highly squeezed states resembling classical states. Formally, this quantum mechanical phenomenon is most simply
described by
the evolution in conformal time, $\eta$, of the mode functions for the gauge-invariant inflaton fluctuation,
$\delta\phi$, and for the tensor fluctuation, $h$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $(ay\_{k})^{\prime\prime}+\left(k^{2}-\frac{x^{\prime\prime}}{x}\right)ay\_{k}=0,$ |  | (4) |

with $(x\thinspace,y)=(a\dot{\phi}/H\thinspace,\delta\phi)$ for scalars and $(x\thinspace,y)=(a\thinspace,h)$ for tensors.
Here $a$ is the scale factor, primes indicate
derivatives with respect to $\eta$, and
$\dot{\phi}$ and $H=\dot{a}/a$ are the proper time derivative of the inflaton and the Hubble parameter,
respectively. The curvature fluctuation, ${\mathcal{R}}$, and the
inflaton fluctuation, $\delta\phi$, are related via ${\mathcal{R}}=H\delta\phi/\dot{\phi}$.
Analytic and numerical calculations of the
predictions for the primordial spectra of cosmological fluctuations generated during inflation
have reached high standards of precision, which are more than adequate for our purposes, and the largest uncertainty
in testing specific inflationary models arises from our lack of
knowledge of the history of the Universe between the end of inflation and
the present time, during the so-called “epoch of entropy generation.”

This paper uses three different methods to compare inflationary
predictions with Planck data. The first method consists of a phenomenological parameterization
of the primordial spectra of scalar and tensor
perturbations according to:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathcal{P}\_{\mathcal{R}}(k)$ | $\displaystyle=\frac{k^{3}}{2\pi^{2}}|{\mathcal{R}}\_{k}|^{2}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=A\_{\mathrm{s}}\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{s}}-1+\frac{1}{2}\thinspace\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k\ln(k/k\_{\*})+\frac{1}{6}\thinspace\frac{\mathrm{d}^{2}n\_{\mathrm{s}}}{\mathrm{d}\ln k^{2}}\left(\ln(k/k\_{\*})\right)^{2}+...},$ |  | (5) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{P}\_{\mathrm{t}}(k)$ | $\displaystyle=\frac{k^{3}}{2\pi^{2}}\left(|h^{+}\_{k}|^{2}+|h^{\times}\_{k}|^{2}\right)=A\_{\mathrm{t}}\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{t}}+\frac{1}{2}\thinspace\mathrm{d}n\_{\mathrm{t}}/\mathrm{d}\ln k\ln(k/k\_{\*})+...},$ |  | (6) |

where $A\_{\mathrm{s}}\thinspace(A\_{\mathrm{t}})$ is the scalar (tensor) amplitude and $n\_{\mathrm{s}}\thinspace(n\_{\mathrm{t}})$, $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k\thinspace(\mathrm{d}n\_{\mathrm{t}}/\mathrm{d}\ln k)$,
and $\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}$ are the scalar (tensor) spectral index,
the running of the scalar (tensor) spectral index, and the running of the running of the scalar spectral index,
respectively.
$h^{+,\times}$ denotes the amplitude of
the two polarization states ($+,\times$) of gravitational waves and $k\_{\*}$ is the
pivot scale.
Unless otherwise stated, the tensor-to-scalar ratio,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $r=\frac{\mathcal{P}\_{\mathrm{t}}(k\_{\*})}{\mathcal{P}\_{\mathcal{R}}(k\_{\*})},$ |  | (7) |

is fixed to $-8n\_{\mathrm{t}}$,22
2
When running is considered, we fix
$n\_{\mathrm{t}}=-r(2-r/8-n\_{\mathrm{s}})/8$ and
$\mathrm{d}n\_{\mathrm{t}}/\mathrm{d}\ln k=r(r/8+n\_{\mathrm{s}}-1)/8$.
which is the relation that holds when inflation is driven by a single slow-rolling scalar field
with a standard kinetic term.
We will use a parameterization analogous to Eq. ([5](#S3.E5 "In 3.2 Primordial spectra of cosmological fluctuations ‣ 3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation")) with no running for the power spectra of
isocurvature modes and their correlations
in Sect. [11](#S11 "11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation").

The second method exploits the analytic dependence of the slow-roll power
spectra of primordial perturbations in Eqs. ([5](#S3.E5 "In 3.2 Primordial spectra of cosmological fluctuations ‣ 3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation")) and ([6](#S3.E6 "In 3.2 Primordial spectra of cosmological fluctuations ‣ 3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation")) on the values of the Hubble
parameter and the hierarchy of its time derivatives, known as the Hubble flow functions (HFF):
$\epsilon\_{1}=-\dot{H}/H^{2}$,
$\epsilon\_{i+1}\equiv\dot{\epsilon}\_{i}/(H\epsilon\_{i})$, with $i\geq 1$.
We will use the analytic power spectra calculated up to second order
using the Green’s function method ([Gong & Stewart, 2001](#bib.bib101); [Leach et al., 2002](#bib.bib140))
(see [Habib et al. 2002](#bib.bib108), [Martin & Schwarz 2003](#bib.bib166), and [Casadio et al. 2006](#bib.bib48) for alternative derivations).
The spectral indices and the relative scale dependence
in Eqs. ([5](#S3.E5 "In 3.2 Primordial spectra of cosmological fluctuations ‣ 3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation")) and ([6](#S3.E6 "In 3.2 Primordial spectra of cosmological fluctuations ‣ 3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation")) are given in terms of the HFFs by:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle n\_{\mathrm{s}}-1=$ | $\displaystyle-2\epsilon\_{1}-\epsilon\_{2}-2\epsilon\_{1}^{2}-\left(2\thinspace C+3\right)\thinspace\epsilon\_{1}\thinspace\epsilon\_{2}-C\epsilon\_{2}\epsilon\_{3},$ |  | (8) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k=$ | $\displaystyle-2\epsilon\_{1}\epsilon\_{2}-\epsilon\_{2}\epsilon\_{3},$ |  | (9) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle n\_{\mathrm{t}}=$ | $\displaystyle-2\epsilon\_{1}-2\epsilon\_{1}^{2}-2\thinspace\left(C+1\right)\thinspace\epsilon\_{1}\thinspace\epsilon\_{2},$ |  | (10) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathrm{d}n\_{\mathrm{t}}/\mathrm{d}\ln k=$ | $\displaystyle-2\epsilon\_{1}\epsilon\_{2}\thinspace,$ |  | (11) |

where $C\equiv\ln 2+\gamma\_{\mathrm{E}}-2\approx-0.7296$ ($\gamma\_{\mathrm{E}}$
is the Euler-Mascheroni constant). See the Appendix of
[205](#bib.bib205) for more details. Primordial spectra as functions of the $\epsilon\_{i}$ will be employed in
Sect. [6](#S6 "6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation"), and the expressions generalizing Eqs. ([8](#S3.E8 "In 3.2 Primordial spectra of cosmological fluctuations ‣ 3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation"))
to ([11](#S3.E11 "In 3.2 Primordial spectra of cosmological fluctuations ‣ 3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation"))
for a general Lagrangian $p(\phi,X)$,
where $X\equiv-g^{\mu\nu}\partial\_{\mu}\phi\partial\_{\nu}\phi/2$,
will be used in Sect. [10](#S10 "10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation"). The good agreement between the first and second
method as well as with alternative
approximations of slow-roll spectra is illustrated in the Appendix of
[205](#bib.bib205).

The third method is fully numerical, suitable for models where the slow-roll conditions are not well
satisfied and analytical approximations for the primordial fluctuations are not available.
Two different numerical codes, the inflation module of [Lesgourgues & Valkenburg (2007)](#bib.bib144)
as implemented in CLASS ([Lesgourgues, 2011](#bib.bib141); [Blas et al., 2011](#bib.bib36)) and
ModeCode ([Adams et al., 2001](#bib.bib4); [Peiris et al., 2003](#bib.bib200); [Mortonson et al., 2009](#bib.bib178); [Easther & Peiris, 2012](#bib.bib73)),
are used in Sects. [7](#S7 "7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") and [10](#S10 "10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation"),
respectively. 33
3
<http://class-code.net>,<http://modecode.org>.

Conventions for the functions and symbols used to describe inflationary
physics are defined in Table [2](#S3.T2 "Table 2 ‣ 3.2 Primordial spectra of cosmological fluctuations ‣ 3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation").

Table 2: Conventions and definitions for inflation physics.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  | | --- | --- | | Parameter | Definition | | $\phi$. | Inflaton | | $V(\phi)$. | Inflaton potential | | $a$. | Scale factor | | $t$. | Cosmic (proper) time | | $\delta X$. | Fluctuation of $X$ | | $\dot{X}=dX/dt$. | Derivative with respect to proper time | | $X^{\prime}=dX/d\eta$. | Derivative with respect to conformal time | | $X\_{\phi}=\partial X/\partial\phi$. | Partial derivative with respect to $\phi$ | | $M\_{\mathrm{pl}}$. | Reduced Planck mass ($=2.435\times 10^{18}$ GeV) | | $\mathcal{R}$. | Comoving curvature perturbation | | $h^{+,\times}$. | Gravitational wave amplitude of $(+,\times)$-polarization component | | $X\_{\*}$. | $X$ evaluated at Hubble exit during inflation of mode with wavenumber $k\_{\*}$ | | $X\_{\mathrm{e}}$. | $X$ evaluated at end of inflation | | $\epsilon\_{V}={M\_{\mathrm{pl}}^{2}V\_{\phi}^{2}}/(2V^{2})$. | First slow-roll parameter for $V(\phi)$ | | $\eta\_{V}={M\_{\mathrm{pl}}^{2}V\_{\phi\phi}}/V$. | Second slow-roll parameter for $V(\phi)$ | | $\xi^{2}\_{V}={M\_{\mathrm{pl}}^{4}V\_{\phi}V\_{\phi\phi\phi}}/{V^{2}}$. | Third slow-roll parameter for $V(\phi)$ | | $\varpi^{3}\_{V}={M\_{\mathrm{pl}}^{6}V\_{\phi}^{2}V\_{\phi\phi\phi\phi}}/{V^{3}}$. | Fourth slow-roll parameter for $V(\phi)$ | | $\epsilon\_{1}=-{\dot{H}}/{H^{2}}$. | First Hubble hierarchy parameter | | $\epsilon\_{n+1}={\dot{\epsilon}\_{n}}/(H\epsilon\_{n})$. | $(n+1)$st Hubble hierarchy parameter (where $n\geq 1$) | | $N(t)=\int\_{t}^{t\_{\mathrm{e}}}\!\mathrm{d}t\;H$. | Number of $e$-folds to end of inflation | |  |

### 3.3 Planck data

The Planck data processing proceeding
from time-ordered data to maps has been improved for this 2015 release in various aspects
([Planck Collaboration
II, 2016](#bib.bib213); [Planck Collaboration
VII, 2016](#bib.bib214)).
We refer the interested reader to [Planck Collaboration
II (2016)](#bib.bib213) and [Planck Collaboration
VII (2016)](#bib.bib214)
for details, and we describe here two of these improvements.
The absolute calibration has been improved using the orbital dipole and more accurate characterization of the Planck beams.
The calibration discrepancy between Planck and WMAP described in
[Planck Collaboration
XXXI (2014)](#bib.bib212) for the 2013 release has now been greatly reduced.
At the time of that release, a blind analysis for
primordial power spectrum reconstruction described a broad feature at $\ell\approx 1800$
in the temperature power spectrum, which was most prominent in the 217$\times$217 GHz auto-spectra ([205](#bib.bib205)).
In work done after the Planck 2013 data release, this feature was shown to be associated with imperfectly subtracted
systematic effects associated with the 4 K cooler lines, which were particularly strong in the first survey.
This systematic effect was shown to potentially lead to $0.5\thinspace\sigma$
shifts in the cosmological parameters, slightly increasing $n\_{\mathrm{s}}$ and $H\_{0}$,
similarly to the case in which the 217$\times$217 channel was excised
from the likelihood ([Planck Collaboration
XV, 2014](#bib.bib202); [Planck Collaboration
XVI, 2014](#bib.bib203)).
The Planck likelihood ([Planck Collaboration
XI, 2016](#bib.bib216)) is based on the
full mission data and comprises temperature and polarization data (see Fig. [2](#S3.F2 "Figure 2 ‣ 3.3 Planck data ‣ 3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation")).

Figure 2: Planck $TT$ (top), high-$\ell$ $TE$ (centre), and high-$\ell$ $EE$ (bottom) angular power spectra.
Here ${\mathcal{D}}\_{\ell}\equiv\ell(\ell+1)C\_{\ell}/(2\pi)$.

#### Planck low-$\ell$ likelihood

The Planck low-$\ell$ temperature-polarization likelihood uses
foreground-cleaned LFI $70$ GHz polarization maps
together with the temperature map obtained from the Planck 30 to 353 GHz channels
by the Commander component separation
algorithm over 94 % of the sky (see [Planck Collaboration
IX (2016)](#bib.bib215) for further details).
The Planck polarization map uses the LFI $70$ GHz (excluding Surveys 2 and 4)
low-resolution maps of $Q$ and $U$ polarization from which polarized synchrotron and thermal
dust emission components have been removed using
the LFI $30$ GHz and HFI
$353$ GHz maps as templates, respectively. (See
[Planck Collaboration
XI (2016)](#bib.bib216) for more details.)
The polarization map covers the 46 % of the sky outside the
lowP polarization mask.

The low-$\ell$ likelihood
is pixel-based and treats the temperature and polarization at the
same resolution of $3$.${}^{\circ}6$, or HEALpix ([Górski et al., 2005](#bib.bib105)) $N\_{\mathrm{side}}=16$. Its multipole range extends from
$\ell=2$ to $\ell=29$ in $TT$, $TE$, $EE$, and $BB$.
In the 2015 Planck papers the polarization part of this likelihood is denoted as ‘‘lowP.’’44
4
In this paper we use the conventions introduced in [Planck Collaboration
XIII (2016)](#bib.bib218).
We adopt the following labels for likelihoods:
(i) Planck TT denotes the combination of the $TT$ likelihood at multipoles
$\ell\geq 30$ and a low-$\ell$ temperature-only likelihood based on the CMB map
recovered with Commander; (ii) Planck TT–lowT denotes the $TT$ likelihood at multipoles
$\ell\geq 30$; (iii) Planck TT+lowP further includes the Planck polarization
data in the low-$\ell$ likelihood, as described in the main text;
(iv) Planck TE denotes the likelihood at $\ell\geq 30$ using the $TE$ spectrum;
and (v) Planck TT,TE,EE+lowP denotes the combination of the likelihood at $\ell\geq 30$ using
$TT$, $TE$, and $EE$ spectra and the low-$\ell$ multipole likelihood.
The label “$\tau$ prior” denotes the use of a Gaussian prior $\tau=0.07\pm 0.02$.
The labels “lowT,P” and “lowEB” denote the low-$\ell$ multipole likelihood and the $Q,U$ pixel likelihood only, respectively.
This Planck low-$\ell$ likelihood replaces the Planck temperature low-$\ell$ Gibbs module
combined with the WMAP 9-year low-$\ell$ polarization module used in the Planck 2013 cosmology papers
(denoted by WP), which used lower resolution polarization maps at $N\_{\mathrm{side}}=8$ (about $7$.${}^{\circ}3$).
With this Planck-only low-$\ell$ likelihood module, the basic Planck results presented in
this release are completely independent of external information.

The Planck low-multipole likelihood alone implies $\tau=0.067\pm 0.022$ ([Planck Collaboration
XI, 2016](#bib.bib216)),
a value smaller than the value inferred using the WP polarization likelihood,
$\tau=0.089\pm 0.013$, used in the Planck 2013 papers ([Planck Collaboration
XV, 2014](#bib.bib202)).
See [Planck Collaboration
XIII (2016)](#bib.bib218) for the important implications of this decrease in $\tau$ for reionization.
However, the LFI $70$ GHz and WMAP polarization maps are in very good agreement when both
are foreground-cleaned using the HFI $353$ GHz map as a polarized dust template (see
[Planck Collaboration
XI (2016)](#bib.bib216) for further details).
Therefore, it is useful to construct a noise-weighted combination to obtain a joint
Planck/WMAP low resolution polarization data set, also
described in [Planck Collaboration
XI (2016)](#bib.bib216), using as a polarization mask the union of
the WMAP P06 and Planck lowP polarization
masks and keeping 74 % of the sky.
The polarization part of the combined low multipole likelihood is called lowP+WP.
This combined low multipole likelihood gives $\tau=0.071^{+0.011}\_{-0.013}$ ([Planck Collaboration
XI, 2016](#bib.bib216)).

#### Planck high-$\ell$ likelihood

Following [Planck Collaboration
XV (2014)](#bib.bib202), and [Planck Collaboration
XI (2016)](#bib.bib216) for polarization,
we use a Gaussian approximation for
the high-$\ell$ part of the likelihood ($30<\ell<2500$), so that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $-\mathrm{log}{\mathcal{L}}\Bigl(\hat{C}|C(\boldsymbol{\theta})\Bigr)=\frac{1}{2}\Bigl(\hat{C}-C(\boldsymbol{\theta})\Bigr)^{T}{\mathcal{M}}^{-1}\Bigl(\hat{C}-C(\boldsymbol{\theta})\Bigr),$ |  | (12) |

where a constant offset has been discarded. Here
$\hat{C}$ is the data vector,
$C(\boldsymbol{\theta})$ is the model prediction
for the parameter value vector $\boldsymbol{\theta}$, and $\mathcal{M}$
is the covariance matrix.
For the data vector, we use 100 GHz, 143 GHz, and 217 GHz half-mission cross-power spectra,
avoiding the Galactic plane as well as the brightest point sources and
the regions where the CO emission is the strongest.
We retain 66 %
of the sky for 100 GHz, 57 % for 143 GHz, and 47 % for 217 GHz for the $T$ masks, and respectively
70 %, 50 %, and 41 % for the
$Q$, $U$ masks. Following [Planck Collaboration
XXX (2014)](#bib.bib211), we do not mask for any other
Galactic polarized emission. All the spectra are corrected for the beam and pixel window functions
using the same beam for temperature and polarization.
(For details see [Planck Collaboration
XI (2016)](#bib.bib216).)

The model for the cross-spectra can be written as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{\mu,\nu}(\theta)=\frac{C^{\mathrm{cmb}}(\theta)+C^{\mathrm{fg}}\_{\mu,\nu}(\theta)}{\sqrt{\mathrm{c}\_{\mu}\mathrm{c}\_{\nu}}},$ |  | (13) |

where $C^{\mathrm{cmb}}(\theta)$ is the CMB power spectrum, which is independent
of the frequency, $C^{\mathrm{f}g}\_{\mu,\nu}(\theta)$ is the foreground
model contribution for the cross-frequency spectrum $\mu\times\nu$, and
$\mathrm{c}\_{\mu}$ is the calibration factor for the $\mu\times\mu$ spectrum.
The model for the foreground residuals includes the following components:
Galactic dust, clustered cosmic infrared background (CIB), thermal and kinetic
Sunyaev-Zeldovich (tSZ and kSZ) effect, tSZ correlations with CIB, and point
sources, for the $TT$ foreground modeling; and for polarization, only
dust is included. All the components are modelled by smooth $C\_{\ell}$
templates with free amplitudes, which are determined along with the cosmological
parameters as the likelihood is explored. The tSZ and kSZ
models are the same as in 2013 ([Planck Collaboration
XV, 2014](#bib.bib202), see),
although with different priors ([Planck Collaboration
XI, 2016](#bib.bib216); [Planck Collaboration
XIII, 2016](#bib.bib218)),
while the CIB and tSZ-CIB correlation models use the updated CIB models described in [Planck Collaboration
XXX (2014)](#bib.bib211).
The point source contamination is modelled as Poisson noise with an independent
amplitude for each frequency pair. Finally, the dust contribution uses an effective
smooth model measured from high frequency maps. Details of our dust and noise
modelling can be found in [Planck Collaboration
XI (2016)](#bib.bib216).
The dust is the dominant foreground component for $TT$ at $\ell<500$, while the point source component,
and for 217$\times$217 also the CIB component, dominate at high $\ell$. The other foreground components
are poorly determined by Planck. Finally, our treatment of the calibration
factors and beam uncertainties and mismatch are described in [Planck Collaboration
XI (2016)](#bib.bib216).

The covariance matrix accounts for the correlation due to the mask and is computed following the equations
in [Planck Collaboration
XV (2014)](#bib.bib202), extended to polarization in [Planck Collaboration
XI (2016)](#bib.bib216) and references therein.
The fiducial model used to compute the covariance is based on a joint fit of base $\Lambda$CDM and
nuisance parameters obtained with a previous
version of the matrix. We iterate the process until the parameters stop changing.
For more details, see [Planck Collaboration
XI (2016)](#bib.bib216).

The joint unbinned covariance matrix is approximately of size 23 000$\thinspace\times\thinspace$23 000. The memory and speed requirements for
dealing with such a huge matrix are significant, so to reduce its size, we bin the data and the
covariance matrix to compress the data vector size by a factor of 10. The binning uses varying bin width
with $\Delta\ell=5$ for $29<\ell<100$,
$\Delta\ell=9$ for $99<\ell<1504$, $\Delta\ell=17$ for $1503<\ell<2014$, and $\Delta\ell=33$ for $2013<\ell<2509$, and
a weighting in $\ell(\ell+1)$ to flatten the spectrum.
Where a higher resolution is desirable, we also use a more finely binned
version (“bin3", unbinned up to $\ell=80$ and $\Delta\ell=3$ beyond that) as well as
a completely unbinned version (“bin1"). We use odd bin sizes, since for an azimuthally symmetric
mask, the correlation between a multipole and its neighbours is symmetric, oscillating between positive and negative values.
Using the base $\Lambda$CDM model and single-parameter classical extensions,
we confirmed that the cosmological and nuisance parameter fits with or without binning are indistinguishable.

As discussed in [Planck Collaboration
XI (2016)](#bib.bib216) and [Planck Collaboration
XIII (2016)](#bib.bib218),
the $TE$ and $EE$ high-$\ell$ data are not free of small systematic effects,
such as leakage from temperature to polarization.
Although the propagated effects of these residual systematics on
cosmological parameters are small and do not alter the conclusions
of this paper, we mainly refer to Planck TT+lowP in combination with the Planck lensing or additional data
sets as the most reliable results for this release.

#### Planck CMB bispectrum

We use measurements of the non-Gaussianity
amplitude $f\_{\mathrm{NL}}$ from the CMB bispectrum presented in [Planck Collaboration
XVII (2016)](#bib.bib221).
Non-Gaussianity constraints have been obtained using three optimal bispectrum estimators: separable
template fitting (also known as “KSW”), binned, and modal. The maps analysed are the Planck 2015 full mission sky
maps, both in
temperature and in $E$ polarization, as cleaned with the four component separation
methods SMICA,
SEVEM, NILC, and Commander. The map is masked to remove the brightest parts of the
Galaxy as well as the brightest point sources and covers approximately $70\thinspace\%$ of the sky.
In this paper we mainly exploit the joint constraints on equilateral and
orthogonal non-Gaussianity (after removing the integrated Sachs-Wolfe effect-lensing bias),
$f\_{\mathrm{NL}}^{\mathrm{equil}}=-16\pm 70$, $f\_{\mathrm{NL}}^{\mathrm{ortho}}=-34\pm 33$ from $T$ only,
and $f\_{\mathrm{NL}}^{\mathrm{equil}}=-3.7\pm 43$, $f\_{\mathrm{NL}}^{\mathrm{ortho}}=-26\pm 21$ from $T$ and $E$ (68$\thinspace\%$ CL). For reference, the constraints on local
non-Gaussianity are
$f\_{\mathrm{NL}}^{\mathrm{local}}=2.5\pm 5.7$ from $T$ only, and
$f\_{\mathrm{NL}}^{\mathrm{local}}=0.8\pm 5.0$ from $T$ and $E$ (68$\thinspace\%$ CL).
Starting from a Gaussian $f\_{\mathrm{NL}}$-likelihood, which is an accurate
assumption in the regime of small primordial non-Gaussianity, we use these constraints
to derive limits on the sound speed of the inflaton fluctuations (or other
microscopic parameters
of inflationary models) ([Planck Collaboration
XXIV, 2014](#bib.bib207)). The bounds on the sound speed for various models are
then used in combination with Planck power spectrum data.

#### Planck CMB lensing data

Some of our analysis includes the Planck 2015 lensing likelihood, presented in
[Planck Collaboration
XV (2016)](#bib.bib219), which utilizes the non-Gaussian trispectrum induced by
lensing to estimate the power spectrum of the lensing potential, $C\_{\ell}^{\phi\phi}$.
This signal is extracted using a full set of temperature- and polarization-based
quadratic lensing estimators ([Okamoto & Hu, 2003](#bib.bib190)) applied to the SMICA CMB
map over approximately $70\thinspace\%$ of the sky, as described in [Planck Collaboration
IX (2016)](#bib.bib215).
We
have used the conservative bandpower likelihood, covering multipoles $40\leq\ell\leq 400$. This provides a measurement of the lensing potential power at the
$40\thinspace\sigma$ level, giving a $2.5\thinspace\%$-accurate constraint on the overall lensing power in this
multipole range. The measurement of the lensing power spectrum used here is
approximately twice as powerful as the measurement used in our previous 2013 analysis
([Planck Collaboration
XXII, 2014](#bib.bib205); [Planck Collaboration
XVII, 2014](#bib.bib204)), which used temperature-only data from the
Planck nominal mission data set.

### 3.4 Non-Planck data

#### BAO data

Baryon acoustic oscillations (BAO) are the counterpart in the late time matter power
spectrum of the acoustic oscillations seen in the CMB multipole spectrum ([Eisenstein et al., 2005](#bib.bib74)).
Both originate from coherent oscillations of the photon-baryon plasma before these two
components become decoupled at recombination. Measuring the position
of these oscillations in the matter power spectra at different redshifts
constrains the expansion history of the universe after decoupling, thus
removing degeneracies in the interpretation of the CMB anisotropies.

In this paper, we combine
constraints on $D\_{V}(\bar{z})/r\_{\mathrm{s}}$ (the ratio between the spherically-averaged
distance scale $D\_{V}$ to the effective survey redshift, $\bar{z}$, and the sound
horizon, $r\_{\mathrm{s}}$) inferred from 6dFGRS data ([Beutler et al., 2011](#bib.bib29))
at $\bar{z}=0.106$, the SDSS-MGS data ([Ross et al., 2014](#bib.bib232)) at $\bar{z}=0.15$,
and the SDSS-DR11 CMASS and LOWZ data ([Anderson et al., 2014](#bib.bib9)) at
redshifts $\bar{z}=0.57$ and $0.32$. For details see [Planck Collaboration
XIII (2016)](#bib.bib218).

#### Joint BICEP2/Keck Array and Planck constraint on $r$

Since the Planck temperature constraints on the
tensor-to-scalar ratio are close to the cosmic variance limit, the
inclusion of data sets sensitive to the expected $B$-mode signal of primordial
gravitational waves is particularly useful. In this paper, we provide
results including the joint analysis cross-correlating BICEP2/Keck Array observations
and Planck ([34](#bib.bib34)). Combining
the more sensitive BICEP2/Keck Array $B$-mode polarization maps in
the approximately 400 deg2 BICEP2 field with the Planck maps at higher frequencies where dust dominates allows a statistical
analysis taking into account foreground contamination.
Using $BB$ auto- and
cross-frequency spectra between BICEP2/Keck Array (150 GHz) and Planck (217 and 353 GHz), [34](#bib.bib34) find a 95 % upper limit of
$r\_{0.05}<0.12$.

### 3.5 Parameter estimation and model comparison

Much of this paper uses a Bayesian approach to parameter
estimation, and unless otherwise specified, we assign broad top-hat prior
probability distributions to the cosmological parameters listed in
Table [1](#S3.T1 "Table 1 ‣ 3.1 Cosmological model ‣ 3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation"). We generate posterior probability
distributions for the parameters using either the Metropolis-Hastings
algorithm implemented in CosmoMC ([Lewis & Bridle, 2002](#bib.bib145)) or
MontePython ([Audren et al., 2013](#bib.bib12)), the nested sampling
algorithm MultiNest ([Feroz & Hobson, 2008](#bib.bib81); [Feroz et al., 2009](#bib.bib82); [Feroz et al., 2013](#bib.bib83)),
or PolyChord, which combines nested sampling with slice
sampling ([Handley et al., 2015](#bib.bib111)). The latter two also compute the Bayesian evidence
needed for model comparison. Nevertheless, $\chi^{2}$ values are often
provided as well (using CosmoMC’s implementation of the BOBYQA
algorithm ([Powell, 2009](#bib.bib230)) for maximizing the likelihood),
and other parts of the paper employ frequentist methods when appropriate.

## 4 Constraints on the primordial spectrum of curvature perturbations

One of the most important results of the Planck nominal mission was the determination of the departure
from scale invariance for the spectrum of scalar perturbations at high statistical significance
([Planck Collaboration
XVI, 2014](#bib.bib203); [Planck Collaboration
XXII, 2014](#bib.bib205)).
We now update these measurements with the Planck full mission data in temperature and polarization.

### 4.1 Tilt of the curvature power spectrum

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |
|  |  |  |  |  |
| Parameter | TT+lowP | TT+lowP+lensing | TT+lowP+BAO | TT,TE,EE+lowP |
| $\Omega\_{\mathrm{b}}h^{2}$ | $0.02222\pm 0.00023$ | $0.02226\pm 0.00023$ | $0.02226\pm 0.00020$ | $0.02225\pm 0.00016$ |
| $\Omega\_{\mathrm{c}}h^{2}$ | $0.1197\pm 0.0022$ | $0.1186\pm 0.0020$ | $0.1190\pm 0.0013$ | $0.1198\pm 0.0015$ |
| $100\theta\_{\mathrm{MC}}$ | $1.04085\pm 0.00047$ | $1.04103\pm 0.00046$ | $1.04095\pm 0.00041$ | $1.04077\pm 0.00032$ |
| $\tau$ | $0.078\pm 0.019$ | $0.066\pm 0.016$ | $0.080\pm 0.017$ | $0.079\pm 0.017$ |
| $\ln(10^{10}A\_{\mathrm{s}})$ | $3.089\pm 0.036$ | $3.062\pm 0.029$ | $3.093\pm 0.034$ | $3.094\pm 0.034$ |
| $n\_{\mathrm{s}}$ | $0.9655\pm 0.0062$ | $0.9677\pm 0.0060$ | $0.9673\pm 0.0045$ | $0.9645\pm 0.0049$ |
| $H\_{0}$ | $67.31\pm 0.96\phantom{0}$ | $67.81\pm 0.92\phantom{0}$ | $67.63\pm 0.57\phantom{0}$ | $67.27\pm 0.66\phantom{0}$ |
| $\Omega\_{\mathrm{m}}$ | $0.315\pm 0.013$ | $0.308\pm 0.012$ | $0.3104\pm 0.0076$ | $0.3156\pm 0.0091$ |

Table 3: Confidence limits on the parameters of the base $\Lambda$CDM model, for various combinations of Planck 2015 data, at the 68 % confidence level.

For the base $\Lambda$CDM model with a power-law power spectrum of curvature perturbations, the constraint on
the scalar spectral index, $n\_{\mathrm{s}}$, with
the Planck full mission temperature data is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n\_{\mathrm{s}}=0.9655\pm 0.0062\thinspace\thinspace(68\thinspace\%\ \text{CL, {Planck}\ TT+lowP})\thinspace.$ |  | (14) |

This result is compatible with the Planck 2013 constraint,
$n\_{\mathrm{s}}=0.9603\pm 0.0073$ ([Planck Collaboration
XV, 2014](#bib.bib202); [Planck Collaboration
XVI, 2014](#bib.bib203)).
See Fig. [3](#S4.F3 "Figure 3 ‣ 4.1 Tilt of the curvature power spectrum ‣ 4 Constraints on the primordial spectrum of curvature perturbations ‣ Planck 2015 results. XX. Constraints on inflation") for the accompanying changes in $\tau$, $\Omega\_{\mathrm{b}}h^{2}$, and $\theta\_{\mathrm{MC}}.$
The shift towards higher values for $n\_{\mathrm{s}}$ with respect to the nominal mission results
is due to several improvements in the data processing and likelihood which are discussed in Sect. [3](#S3 "3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation"), including the removal
of the 4 K cooler systematics.
For the values of other cosmological parameters in the base $\Lambda$CDM model,
see Table [3](#S4.T3 "Table 3 ‣ 4.1 Tilt of the curvature power spectrum ‣ 4 Constraints on the primordial spectrum of curvature perturbations ‣ Planck 2015 results. XX. Constraints on inflation"). We also provide the results for the base $\Lambda$CDM model
and extended models online.55
5
<http://www.cosmos.esa.int/web/planck/pla>

When the Planck high-$\ell$ polarization is combined with temperature, we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n\_{\mathrm{s}}=0.9645\pm 0.0049\thinspace\thinspace(68\thinspace\%\ \text{CL, {Planck}\ TT,TE,EE+lowP}),$ |  | (15) |

together with $\tau=0.079\pm 0.017$ (68 % CL), which is consistent with the TT+lowP results.
The Planck high-$\ell$ polarization pulls $\tau$ up to a slightly higher value.
When the Planck lensing measurement is added to the temperature data, we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n\_{\mathrm{s}}=0.9677\pm 0.0060\thinspace\thinspace(68\thinspace\%\ \text{CL, {Planck}\ TT+lowP+lensing}),$ |  | (16) |

with $\tau=0.066\pm 0.016$ (68 % CL). The shift towards slightly smaller values of the
optical depth is driven by a marginal preference for a smaller primordial amplitude,
$A\_{\mathrm{s}}$, in the Planck lensing data ([Planck Collaboration
XV, 2016](#bib.bib219)). Given that the
temperature data provide a sharp constraint on the combination $e^{-2\tau}A\_{\mathrm{s}}$,
a slightly lower $A\_{\mathrm{s}}$ requires a smaller optical depth to reionization.

Figure 3: Comparison of the marginalized joint 68 % and 95 % CL constraints on
$(n\_{\mathrm{s}}\thinspace,\tau)$ (left panel), $(n\_{\mathrm{s}}\thinspace,\Omega\_{\mathrm{b}}h^{2})$ (middle panel), and
$(n\_{\mathrm{s}}\thinspace,\theta\_{\mathrm{MC}})$ (right panel),
for Planck 2013 (grey contours), Planck TT+lowP (red contours), Planck TT+lowP+lensing (green contours),
and Planck TT,TE,EE+lowP (blue contours).

### 4.2 Viability of the Harrison-Zeldovich spectrum

Even though the estimated scalar spectral index has
risen slightly with respect to the Planck 2013 release,
the assumption of a Harrison-Zeldovich (HZ) scale-invariant
spectrum ([Harrison, 1970](#bib.bib112); [Peebles & Yu, 1970](#bib.bib194); [Zeldovich, 1972](#bib.bib261)) continues to be
disfavoured (with a modest increase in significance, from $5.1\thinspace\sigma$ in 2013
to $5.6\thinspace\sigma$ today), because the error bar on $n\_{\mathrm{s}}$ has decreased. The value of $n\_{\mathrm{s}}$ inferred from the Planck 2015 temperature plus large-scale polarization data lies 5.6 standard deviations
away from unity (with a corresponding $\Delta\chi^{2}=29.9$),
if one assumes the base $\Lambda$CDM late-time cosmological model. If we consider
more general reionization models, parameterized by a principal component analysis
([Mortonson & Hu, 2008](#bib.bib179)) instead of $\tau$
(where reionization is assumed to have occurred instantaneously),
we find $\Delta\chi^{2}=14.9$ for
$n\_{\mathrm{s}}=1$. Previously, simple one-parameter extensions of the base model, such as $\Lambda$CDM+$N\_{\mathrm{eff}}$
(where $N\_{\mathrm{eff}}$ is the effective number of neutrino flavours)
or
$\Lambda$CDM+$Y\_{\mathrm{P}}$
(where $Y\_{\mathrm{P}}$ is the primordial value of the helium mass fraction),
could nearly reconcile the Planck temperature data with $n\_{\mathrm{s}}=1$. They now lead to $\Delta\chi^{2}=7.6$ and $9.3$, respectively.
For any of the cosmological models that we have considered, the $\Delta\chi^{2}$ by which the HZ model
is penalized with respect to the tilted model has increased since the 2013 analysis ([205](#bib.bib205))
thanks to the constraining power of the full mission temperature data.
Adding Planck high-$\ell$ polarization data further disfavours the HZ model:
in $\Lambda$CDM, the $\chi^{2}$ increases by $57.8$, for general reionization we obtain $\Delta\chi^{2}=41.3$,
and for $\Lambda$CDM+$N\_{\mathrm{eff}}$
and $\Lambda$CDM+$Y\_{\mathrm{P}}$ we find $\Delta\chi^{2}=22.5$ and $24.0$, respectively.

### 4.3 Running of the spectral index

The running of the scalar spectral index is constrained by the Planck 2015 full mission temperature data to

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{dn\_{\mathrm{s}}}{d\ln k}=-0.0084\pm 0.0082\thinspace\thinspace(68\thinspace\%\ \text{CL, {Planck}\ TT+lowP})\thinspace.$ |  | (17) |

The combined constraint including high-$\ell$ polarization is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{dn\_{\mathrm{s}}}{d\ln k}=-0.0057\pm 0.0071\thinspace\thinspace(68\thinspace\%\ \text{CL, {Planck}\ TT,TE,EE+lowP})\thinspace.$ |  | (18) |

Adding the Planck CMB lensing data to the temperature data further reduces the central value for the running,
i.e., $dn\_{\mathrm{s}}/d\ln k=-0.0033\pm 0.0074$ ($68\thinspace\%$ CL, Planck TT+lowP+lensing).

The central value for the running has decreased in magnitude with respect to the Planck 2013 nominal
mission ([Planck Collaboration
XVI (2014)](#bib.bib203) found $dn\_{\mathrm{s}}/d\ln k=-0.013\pm 0.009$; see Fig. [4](#S4.F4 "Figure 4 ‣ 4.3 Running of the spectral index ‣ 4 Constraints on the primordial spectrum of curvature perturbations ‣ Planck 2015 results. XX. Constraints on inflation")),
and the improvement of the maximum likelihood with respect
to a power-law spectrum is smaller, $\Delta\chi^{2}\approx-0.8$.
Among the different effects contributing to the decrease in
the central value of the running with respect to the Planck 2013 result, we mention a change in HFI beams at
$\ell\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}200$ ([Planck Collaboration
XIII, 2016](#bib.bib218)).
Nevertheless, the deficit of power at low multipoles in the Planck 2015 temperature power spectrum contributes to
a preference for slightly negative values of the running, but with low statistical significance.

Figure 4: Marginalized joint 68 % and 95 % CL for
$(n\_{\mathrm{s}}\thinspace,\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k)$
using Planck TT+lowP and Planck TT,TE,EE+lowP. Constraints from the Planck 2013 data release are also shown for comparison.
For comparison, the thin black stripe shows the
prediction for single-field monomial chaotic inflationary
models with $50<N\_{\*}<60$.

The Planck constraints on $n\_{\mathrm{s}}$ and $dn\_{\mathrm{s}}/d\ln k$
are remarkably stable against the addition of the BAO likelihood. The combination with BAO shifts $n\_{\mathrm{s}}$ to slighly higher values and
shrinks its uncertainty by about $30$ % when only high-$\ell$ temperature is considered,
and by only about $15$ % when high-$\ell$ temperature and polarization are combined.
In slow-roll inflation, the running of the scalar spectral index is
connected to the third derivative of the potential ([Kosowsky & Turner, 1995](#bib.bib137)).
As was the case for the nominal mission results, values of the
running compatible with the Planck 2015 constraints can be obtained in viable inflationary
models ([Kobayashi & Takahashi, 2011](#bib.bib133)).

When the running of the running is allowed to float,
the Planck TT+lowP (Planck TT,TE,EE+lowP) data give:

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle n\_{\mathrm{s}}=0.9569\pm 0.0077\penalty\ \penalty\ (0.9586\pm 0.0056)\penalty\ ,$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle dn\_{\mathrm{s}}/d\ln k=0.011^{+0.014}\_{-0.013}\penalty\ \penalty\ (0.009\pm 0.010)\penalty\ ,\penalty\ \penalty\ \penalty\ \penalty\ \penalty\ \penalty\ (68\thinspace\%\penalty\ \mathrm{CL})$ |  | (19) |
|  |  |  |
| --- | --- | --- |
|  | $\displaystyle d^{2}n\_{\mathrm{s}}/d\ln k^{2}=0.029^{+0.015}\_{-0.016}\penalty\ \penalty\ (0.025\pm 0.013)\penalty\ ,$ |  |

at the pivot scale $k\_{\*}=0.05$ Mpc-1.
Allowing for running of the running provides a better fit to the temperature spectrum at low multipoles, such that
$\Delta\chi^{2}\approx-4.8$ ($-4.9$) for TT+lowP (TT,TE,EE+lowP), but is not statistically preferred over the simplest
$\Lambda$CDM model.

Note that the inclusion of small-scale data such as Ly$\alpha$ might further constrain the running of the spectral index and its derivative. The recent analysis of the BOSS one-dimensional Ly$\alpha$ flux power spectrum presented in [Palanque-Delabrouille et al. (2014)](#bib.bib193) and [Rossi et al. (2014)](#bib.bib233) was optimized for measuring the neutrino mass. It does not include constraints on the spectral index running, which would require new dedicated $N$-body simulations. Hence we do not include Ly$\alpha$ constraints here.

In Sect. [7](#S7 "7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") on inflaton potential reconstruction we will show that the data cannot accomodate a significant running but are compatible
with a larger running of the running.

### 4.4 Suppression of power on the largest scales

Although not statistically significant, the trend for a negative running or positive running of the running observed
in the last subsection was driven by the lack of power in the Planck temperature power spectrum at low multipoles,
already mentioned in the Planck 2013 release. This deficit could potentially be explained by a primordial
spectrum featuring a depletion of power only at large wavelengths. Here we investigate two examples of such models.

We first update the analysis (already presented in [205](#bib.bib205))
of a power-law spectrum multiplied by an exponential cutoff:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P\_{R}}(k)=\mathcal{P}\_{0}(k)\left\{1-\exp\left[-\left(\frac{k}{k\_{\mathrm{c}}}\right)^{\lambda\_{\mathrm{c}}}\right]\right\}.$ |  | (20) |

This simple parameterization is motivated by models with
a short inflationary stage in which the onset of the slow-roll phase coincides with the time when the
largest observable scales exited the Hubble radius during inflation.
The curvature spectrum is then strongly suppressed on those scales.
We apply top-hat priors on the parameter $\lambda\_{\mathrm{c}}$, controlling the steepness of the cutoff,
and on the logarithm of the cutoff scale, $k\_{\mathrm{c}}$. We choose prior ranges
$\lambda\_{\mathrm{c}}\in[0,10]$ and $\ln(k\_{\mathrm{c}}/\mathrm{Mpc}^{-1})\in[-12\thinspace,-3]$.
For Planck TT+lowP (Planck TT,TE,EE+lowP),
the best-fit model has $\lambda\_{\mathrm{c}}=0.50$ ($0.53$),
$\ln(k\_{\mathrm{c}}/\mathrm{Mpc}^{-1})=-7.98$ ($-7.98$), $n\_{\mathrm{s}}=0.9647$ ($0.9649$),
and improves the effective $\chi^{2}$ by a modest amount, $\Delta\chi^{2}\approx-3.4$ ($-3.4$).

As a second model, we consider a broken power-law spectrum for curvature perturbations:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P\_{R}}(k)=\begin{cases}\penalty\ \penalty\ A\_{\mathrm{low}}\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{s}}-1+\delta}&\text{if }k\leq k\_{\mathrm{b}},\\ \penalty\ \penalty\ A\_{\mathrm{s}}\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{s}}-1}&\text{if }k\geq k\_{\mathrm{b}},\end{cases}$ |  | (21) |

with $A\_{\mathrm{low}}=A\_{\mathrm{s}}(k\_{\mathrm{b}}/k\_{\*})^{-\delta}$ to ensure continuity at $k=k\_{\mathrm{b}}$. Hence
this model, like the previous one, has two parameters, and also suppresses power at large wavelengths when $\delta>0$.
We assume top-hat priors $\delta\in[0,2]$ and
$\ln(k\_{\mathrm{b}}/\mathrm{Mpc}^{-1})\in[-12\thinspace,-3]$, and standard uniform priors for $\ln(10^{10}A\_{\mathrm{s}})$ and $n\_{\mathrm{s}}$.
The best fit to Planck TT+lowP (Planck TT,TE,EE+lowP) is found for
$n\_{\mathrm{s}}=0.9658$ ($0.9647$), $\delta=1.14$ ($1.14$), and
$\ln(k\_{\mathrm{b}}/\mathrm{Mpc}^{-1})=-7.55$ ($-7.57$), with a very small
$\chi^{2}$ improvement of $\Delta\chi^{2}\approx-1.9$ ($-1.6$).

We conclude that neither of these two models with two extra parameters is preferred over the base $\Lambda$CDM model.
(See also the discussion of a step inflationary potential in Sect. [9.1.1](#S9.SS1.SSS1 "9.1.1 Step in the inflaton potential ‣ 9.1 Models ‣ 9 Search for parameterized features ‣ Planck 2015 results. XX. Constraints on inflation").)

## 5 Constraints on tensor modes

In this section, we focus on the Planck 2015 constraints on tensor perturbations.
Unless otherwise stated, we consider that the tensor spectral index satisfies the
standard inflationary consistency condition to lowest order in slow roll, $n\_{\mathrm{t}}=-r/8$.
We recall that $r$ is defined at the pivot scale $k\_{\*}=0.05\thinspace$Mpc-1. However, for
comparison with other studies, we also report our bounds in terms of the tensor-to-scalar ratio $r\_{0.002}$ at $k\_{\*}=0.002\thinspace$Mpc-1.

### 5.1 Planck 2015 upper bound on $r$

The constraints on the tensor-to-scalar ratio inferred from the
Planck full mission data for the $\Lambda$CDM+$r$ model are:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\quad r\_{0.002}$ | $\displaystyle<$ | $\displaystyle 0.10\quad\text{(95\thinspace\% CL, {Planck}\ TT+lowP)}\thinspace,$ |  | (22) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\quad r\_{0.002}$ | $\displaystyle<$ | $\displaystyle 0.11\quad\text{(95\thinspace\% CL, {Planck}\ TT+lowP+lensing)}\thinspace,$ |  | (23) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\quad r\_{0.002}$ | $\displaystyle<$ | $\displaystyle 0.11\quad\text{(95\thinspace\% CL, {Planck}\ TT+lowP+BAO)}\thinspace,$ |  | (24) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\quad r\_{0.002}$ | $\displaystyle<$ | $\displaystyle 0.10\quad\text{(95\thinspace\% CL, {Planck}\ TT,TE,EE+lowP)}\thinspace.$ |  | (25) |

Table [4](#S5.T4 "Table 4 ‣ 5.1 Planck 2015 upper bound on 𝑟 ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation") also shows the bounds on $n\_{\mathrm{s}}$ in each of these cases.

These results slightly improve over the constraint $r\_{0.002}<0.12$
(95 % CL) derived from the Planck 2013 temperature data in combination
with WMAP large-scale polarization data
([Planck Collaboration
XVI, 2014](#bib.bib203); [Planck Collaboration
XXII, 2014](#bib.bib205)).
The constraint obtained by Planck temperature and
polarization on large scales is tighter than the Planck $B$-mode 95 % CL upper limit from the 100 and 143 GHz HFI
channels, $r<0.27$ ([Planck Collaboration
XI, 2016](#bib.bib216)).
The constraints on $r$ reported
in Table [4](#S5.T4 "Table 4 ‣ 5.1 Planck 2015 upper bound on 𝑟 ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation") can be translated into upper bounds on the
energy scale of inflation at the time when the pivot scale exits the
Hubble radius using

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V\_{\*}=\frac{3\pi^{2}A\_{\mathrm{s}}}{2}\thinspace r\thinspace M\_{\mathrm{pl}}^{4}=(1.88\times 10^{16}\penalty\ {\mathrm{GeV}})^{4}\frac{r}{0.10}\penalty\ .$ |  | (26) |

This gives an upper bound on the Hubble parameter during inflation of
$H\_{\*}/M\_{\mathrm{pl}}<3.6\times 10^{-5}$ (95 % CL) for Planck TT+lowP.

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
| Model | Parameter | Planck TT+lowP | Planck TT+lowP+lensing | Planck TT+lowP+BAO | Planck TT,TE,EE+lowP |
|  | $n\_{\mathrm{s}}$ | $0.9666\pm 0.0062$ | $0.9688\pm 0.0061$ | $0.9680\pm 0.0045$ | $0.9652\pm 0.0047$ |
| $\Lambda$CDM+$r$ | $r\_{0.002}$ | $<0.103$ | $<0.114$ | $<0.113$ | $<0.099$ |
|  | $-2\Delta\ln{\mathcal{L}}\_{\mathrm{max}}$ | 0 | 0 | 0 | 0 |
| +$\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ | $n\_{\mathrm{s}}$ | $0.9667\pm 0.0066$ | $0.9690\pm 0.0063$ | $0.9673\pm 0.0043$ | $0.9644\pm 0.0049$ |
| $\Lambda$CDM+$r$ | $r\_{0.002}$ | $<0.180$ | $<0.186$ | $<0.176$ | $<0.152$ |
| $r$ | $<0.168$ | $<0.176$ | $<0.166$ | $<0.149$ |
|  | $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ | $-0.0126^{+0.0098}\_{-0.0087}$ | $-0.0076^{+0.0092}\_{-0.0080}$ | $-0.0125\pm 0.0091$ | $-0.0085\pm 0.0076$ |
|  | $-2\Delta\ln{\mathcal{L}}\_{\mathrm{max}}$ | $-0.81$ | $-0.08$ | $-0.87$ | $-0.38$ |

Table 4: 
Constraints on the primordial perturbation parameters for
$\Lambda$CDM+$r$ and
$\Lambda$CDM+$r$+$\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ models from Planck.
Constraints on the spectral index and its dependence on the wavelength are given at the pivot scale of $k\_{\*}=0.05$ Mpc-1.

These bounds are relaxed when allowing for a scale dependence of the
scalar and tensor spectral indices. In that case, we assume that the
tensor spectral index and its running are fixed by the standard
inflationary consistency condition at second order in slow roll. We
obtain

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle r\_{0.002}$ | $\displaystyle<\thinspace 0.18$ | (95 % CL, Planck TT+lowP), |  | (27) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{dn\_{\mathrm{s}}}{d\ln k}$ | $\displaystyle=\thinspace-0.013^{+0.010}\_{-0.009}$ | (68 % CL, Planck TT+lowP), |  | (28) |

with $n\_{\mathrm{s}}=0.9667\pm 0.0066$ (68 % CL).
At the standard pivot scale, $k\_{\*}=0.05\thinspace$Mpc-1, the bound is
stronger ($r<0.17$ at 95 % CL), because $k\_{\*}$ is closer to the scale
at which $n\_{\mathrm{s}}$ and $r$ decorrelate. The constraint on $r\_{0.002}$
in Eq. ([27](#S5.E27 "In 5.1 Planck 2015 upper bound on 𝑟 ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation")) is 21 % tighter than the corresponding Planck 2013 constraint.
The mean value of the running in Eq. ([28](#S5.E28 "In 5.1 Planck 2015 upper bound on 𝑟 ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation")) is
higher (lower in absolute value) than with Planck 2013 by 45 %.
Figures [5](#S5.F5 "Figure 5 ‣ 5.1 Planck 2015 upper bound on 𝑟 ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation") and [6](#S5.F6 "Figure 6 ‣ 5.1 Planck 2015 upper bound on 𝑟 ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation") clearly illustrate this
significant improvement with respect to the previous Planck data release.
Table [4](#S5.T4 "Table 4 ‣ 5.1 Planck 2015 upper bound on 𝑟 ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation") shows how bounds on
$(r,\thinspace n\_{\mathrm{s}},\thinspace{dn\_{\mathrm{s}}}/{d\ln k})$ are affected by
the lensing reconstruction, BAO, or high-$\ell$ polarization data.
The tightest bounds are obtained in combination with polarization:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle r\_{0.002}$ | $\displaystyle<$ | $\displaystyle 0.15$ |  | (29) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  |  | (95 % CL, Planck TT,TE,EE+lowP), |  | (30) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{dn\_{\mathrm{s}}}{d\ln k}$ | $\displaystyle=$ | $\displaystyle-0.009\pm 0.008$ |  | (31) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  |  | (68 % CL, Planck TT,TE,EE+lowP), |  | (32) |

with $n\_{\mathrm{s}}=0.9644\pm 0.0049$ (68 % CL).

Figure 5: Marginalized joint confidence contours for
$(n\_{\mathrm{s}}\thinspace,\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k)$, at the
68 % and 95 % CL, in the presence of a non-zero tensor contribution, and using
Planck TT+lowP or Planck TT,TE,EE+lowP. Constraints from the
Planck 2013 data release are also shown for comparison. The thin black
stripe shows the prediction of single-field monomial inflation models
with $50<N\_{\*}<60$.

Figure 6: Marginalized joint confidence contours for $(n\_{\mathrm{s}}\thinspace,r)$,
at the 68 % and 95 % CL, in the presence of running of the spectral indices,
and for the same data combinations as in the previous figure.

Neither the Planck full mission constraints in
Eqs. ([22](#S5.E22 "In 5.1 Planck 2015 upper bound on 𝑟 ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation"))–([25](#S5.E25 "In 5.1 Planck 2015 upper bound on 𝑟 ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation")) nor those including a running in
Eqs. ([27](#S5.E27 "In 5.1 Planck 2015 upper bound on 𝑟 ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation")) and ([30](#S5.E30 "In 5.1 Planck 2015 upper bound on 𝑟 ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation")) are compatible with
the interpretation of the BICEP2 $B$-mode polarization data in terms
of primordial gravitational waves ([BICEP2 Collaboration, 2014b](#bib.bib33)). Instead they
are in excellent agreement with the results of the BICEP2/Keck Array-Planck cross-correlation analysis, as discussed in Sect. [13](#S13 "13 Combination with BICEP2/Keck Array-Planck cross-correlation ‣ Planck 2015 results. XX. Constraints on inflation").

### 5.2 Dependence of the $r$ constraints on the low-$\ell$ likelihood

The constraints on $r$ discussed above are further tightened by adding
WMAP polarization information on large angular scales. The Planck measurement of
CMB polarization on large angular scales at 70 GHz is consistent with
the WMAP 9-year one, based on the K, Q, and V bands (at 30, 40, and 60 GHz, respectively),
once the Planck 353 GHz channel is used to remove the dust contamination,
instead of the theoretical dust model used by the WMAP team ([Page et al., 2007](#bib.bib191)).
(For a detailed discussion, see [Planck Collaboration
XI (2016)](#bib.bib216).)
By combining Planck $TT$ data with LFI 70 GHz and WMAP polarization data
on large angular scales, we obtain a $35\thinspace\%$ reduction of uncertainty, giving
$\tau=0.074\pm 0.012$ (68 % CL) and $n\_{\mathrm{s}}=0.9660\pm 0.060$
(68 % CL) for the base $\Lambda$CDM model. When tensors are added, the bounds
become

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle r\_{0.002}<$ | $\displaystyle 0.09\thinspace\thinspace\quad\quad\quad\quad$ | (95 % CL, Planck TT+lowP+WP), |  | (33) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle n\_{\mathrm{s}}=$ | $\displaystyle 0.9655\pm 0.058$ | (68 % CL, Planck TT+lowP+WP), |  | (34) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\tau=$ | $\displaystyle 0.073^{+0.011}\_{-0.013}\thinspace\thinspace\thinspace\thinspace\quad$ | (68 % CL, Planck TT+lowP+WP). |  | (35) |

When tensors and running are both varied, we obtain $r\_{0.002}<0.14$
(95 % CL) and $dn\_{\mathrm{s}}/d\ln k=-0.010\pm 0.008$ (68 % CL)
for Planck TT+lowP+WP. These constraints are all tighter
than those based on Planck TT+lowP only.

### 5.3 The tensor-to-scalar ratio and the low-$\ell$ deficit in temperature

As noted previously ([Planck Collaboration
XV, 2014](#bib.bib202); [Planck Collaboration
XVI, 2014](#bib.bib203); [Planck Collaboration
XXII, 2014](#bib.bib205)), the low-$\ell$ temperature data display a slight lack of
power compared to the expectation of the best-fit tensor-free base $\Lambda$CDM model.
Since tensor fluctuations add power on small scales, the effect will be exacerbated in models
allowing $r>0$.

In order to quantify this tension, we compare the observed constraint on $r$
to that inferred from simulated Planck data. In the simulations, we assume the underlying
fiducial model to be tensor-free, with parameters close to the base $\Lambda$CDM
best-fit values. We limit the simulations to mock temperature power spectra
only and fit these spectra with an exact low-$\ell$ likelihood for
$2\leq\ell\leq 29$ ([Perotto et al., 2006](#bib.bib201), see), and a high-$\ell$ Gaussian
likelihood for $30\leq\ell\leq 2508$ based on the frequency-combined,
foreground-marginalized, unbinned Planck temperature power spectrum
covariance matrix. Additionally, we impose a Gaussian prior of
$\tau=0.07\pm 0.02$.

Based on 100 simulated data sets, we find a
95 % CL upper limit on the tensor-to-scalar ratio of $\bar{r}\_{2\sigma}\approx 0.260$.
The corresponding constraint from real data (using low-$\ell$
Commander temperature data, the frequency-combined,
foreground-marginalized, unbinned Planck high-$\ell$ $TT$ power spectrum, and the
same prior on $\tau$ as above) reads $r<0.123$, confirming that the
actual constraint is tighter than what one would have expected.
However, the actual constraint is not excessively unusual: out of the 100
simulations, 4 lead to an even tighter bound, corresponding to a significance
of about 2$\thinspace\sigma$. Thus, under the hypothesis of the base $\Lambda$CDM cosmology,
the upper limit on $r$ that we get from the data is not implausible as a chance
fluctuation of the low multipole power.

To illustrate the contribution of the low-$\ell$ temperature power deficit
to the estimates of cosmological parameters, we show as an example in Fig. [7](#S5.F7 "Figure 7 ‣ 5.3 The tensor-to-scalar ratio and the low-ℓ deficit in temperature ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation")
how $n\_{\mathrm{s}}$ shifts towards lower values when the $\ell<30$ temperature information
is discarded (we will refer to this case as “Planck TT$-$lowT"). The shift in $n\_{\mathrm{s}}$
is approximately $-0.005$ (or $-0.003$ when the lowP likelihood is replaced by a Gaussian prior
$\tau=0.07\pm 0.02$). These shifts exceed those found in Sect. [4.4](#S4.SS4 "4.4 Suppression of power on the largest scales ‣ 4 Constraints on the primordial spectrum of curvature perturbations ‣ Planck 2015 results. XX. Constraints on inflation"), where
a primordial power spectrum suppressed on large scales was fitted to the data.

Figure 7: One-dimensional posterior probabilities for $n\_{\mathrm{s}}$ for the
base $\Lambda$CDM model obtained by excluding temperature multipoles
for $\ell<30$ (“TT$-$lowT”), while either keeping low-$\ell$ polarization data,
or in addition replacing them with a Gaussian prior on $\tau$.

Figure [8](#S5.F8 "Figure 8 ‣ 5.3 The tensor-to-scalar ratio and the low-ℓ deficit in temperature ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation") displays the posterior probability for $r$ for
various combinations of data sets, some of which exclude the $\ell<30$
$TT$ data. This leads to the very conservative bounds $r\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}0.24$
and $r\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}0.23$ at 95 % CL when combined with the lowP likelihood
or with the Gaussian prior $\tau=0.07\pm 0.020$, respectively.

Figure 8: One-dimensional posterior probabilities for $r$ for various
data combinations, either including or not including temperature multipoles for $\ell<30$,
and compared with the baseline choice (Planck TT+lowP, black curve).

### 5.4 Relaxing assumptions on the late-time cosmological evolution

Figure 9: Marginalized joint 68 % and 95 % CL for
$(n\_{\mathrm{s}}\thinspace,r\_{0.002})$
using Planck TT+lowP+BAO (upper panel) and Planck TT,TE,EE+lowP (lower panel).

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |
|  |  |  |  |  |
| Extended model, | Parameter | Planck TT+lowP | Planck TT+lowP | Planck TT,TE,EE |
| $\Lambda$CDM+$r$+ |  | +lensing | +BAO | +lowP |
|  |  |  |  |  |
| +general reionization | $r$ | $<0.11$ | $<0.10$ | $<0.10$ |
| $n\_{\mathrm{s}}$ | $0.975\pm 0.006$ | $0.971\pm 0.005$ | $0.968\pm 0.005$ |
|  |  |  |  |  |
|  | $r$ | $<0.14$ | $<0.12$ | $<0.11$ |
| +$N\_{\mathrm{eff}}$ | $n\_{\mathrm{s}}$ | $0.977^{+0.016}\_{-0.017}$ | $0.972\pm 0.009$ | $0.964\pm 0.010$ |
|  | $N\_{\mathrm{eff}}$ | $3.24^{+0.30}\_{-0.35}$ | $3.19\pm 0.24$ | $3.02^{+0.20}\_{-0.21}$ |
|  |  |  |  |  |
|  | $r$ | $<0.14$ | $<0.12$ | $<0.12$ |
| +$Y\_{\mathrm{He}}$ | $n\_{\mathrm{s}}$ | $0.975\pm 0.007$ | $0.973\pm 0.009$ | $0.969\pm 0.008$ |
|  | $Y\_{\mathrm{He}}$ | $0.258\pm 0.022$ | $0.257\pm 0.022$ | $0.252\pm 0.014$ |
|  |  |  |  |  |
|  | $r$ | $<0.11$ | $<0.11$ | $<0.11$ |
| +$\sum m\_{\nu}$ | $n\_{\mathrm{s}}$ | $0.963\pm 0.007$ | $0.967\pm 0.005$ | $0.962\pm 0.005$ |
|  | $\sum m\_{\nu}$ [eV] | $<0.67$ | $<0.21$ | $<0.58$ |
|  |  |  |  |  |
|  | $r$ | $<0.15$ | $<0.11$ | $<0.15$ |
| +$\Omega\_{K}$ | $n\_{\mathrm{s}}$ | $0.971\pm 0.007$ | $0.971\pm 0.007$ | $0.969\pm 0.005$ |
|  | $\Omega\_{K}$ | $-0.008^{+0.010}\_{-0.008}$ | $-0.001\pm 0.003$ | $-0.045^{+0.016}\_{-0.020}$ |
|  |  |  |  |  |
|  | $r$ | $<0.14$ | $<0.11$ | $<0.12$ |
| +$w$ | $n\_{\mathrm{s}}$ | $0.969\pm 0.006$ | $0.967\pm 0.006$ | $0.966\pm 0.005$ |
|  | $w$ | $-1.46^{+0.20}\_{-0.40}$ | $-1.02^{+0.08}\_{-0.07}$ | $-1.57^{+0.17}\_{-0.37}$ |
|  |  |  |  |  |
| +$\Omega\_{K}$+$dn\_{\mathrm{s}}/d\ln k$ | $r$ | $<0.20$ | $<0.18$ | $<0.19$ |
| $n\_{\mathrm{s}}$ | $0.971\pm 0.007$ | $0.969\pm 0.007$ | $0.969\pm 0.005$ |
| $dn\_{\mathrm{s}}/d\ln k$ | $-0.006\pm 0.009$ | $-0.013\pm 0.009$ | $-0.004\pm 0.008$ |
| $\Omega\_{K}$ | $-0.006^{+0.010}\_{-0.009}$ | $-0.001\pm 0.003$ | $-0.043^{+0.011}\_{-0.020}$ |
|  |  |  |  |  |
| +$N\_{\mathrm{eff}}$+$m^{\mathrm{eff}}\_{\nu\thinspace,\mathrm{sterile}}$ | $r$ | $<0.14$ | $<0.13$ | $<0.12$ |
| $n\_{\mathrm{s}}$ | $0.980^{+0.010}\_{-0.014}$ | $0.978^{+0.008}\_{-0.011}$ | $0.968^{+0.006}\_{-0.008}$ |
| $m^{\mathrm{eff}}\_{\nu\thinspace,\mathrm{sterile}}$ [eV] | $<0.59$ | $<0.55$ | $<0.83$ |
| $N\_{\mathrm{eff}}$ | $<3.80$ | $<3.73$ | $<3.47$ |

Table 5: Constraints on extensions of the $\Lambda$CDM+$r$ cosmological
model for Planck TT+lowP+lensing, Planck TT+lowP+BAO, and Planck TT,TE,EE+lowP.
For each model we quote 68 % CL, unless 95 % CL upper bounds are reported.

As in the Planck 2013 release ([205](#bib.bib205)), we now ask how
robust the Planck results on the tensor-to-scalar ratio are against
assumptions on the late-time cosmological evolution. The results are
summarized in Table [5](#S5.T5 "Table 5 ‣ 5.4 Relaxing assumptions on the late-time cosmological evolution ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation"), and some particular cases are
illustrated in Fig. [9](#S5.F9 "Figure 9 ‣ 5.4 Relaxing assumptions on the late-time cosmological evolution ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation"). Constraints on $r$ turn out to
be remarkably stable for one-parameter extensions of the $\Lambda$CDM+$r$
model, with the only exception the $\Lambda$CDM+$r$+$\Omega\_{K}$
case in the absence of the late time information from Planck lensing or BAO
data. The weak trend towards $\Omega\_{K}<0$, i.e., towards a positively curved
(closed) universe
from the temperature and polarization data alone, and the well-known
degeneracy between $\Omega\_{K}$ and $H\_{0}$/$\Omega\_{\mathrm{m}}$ lead to a
slight suppression of the Sachs-Wolfe plateau in the scalar temperature
spectrum. This leaves more room for a tensor component.

This further degeneracy when $r$ is added builds on the negative values for the curvature
allowed by Planck TT+lowP, $\Omega\_{K}=-0.052^{+0.049}\_{-0.055}$ at 95 % CL ([Planck Collaboration
XIII, 2016](#bib.bib218)).
The exploitation of the information contained in the Planck lensing likelihood
leads to a tighter constraint, $\Omega\_{K}=-0.005^{+0.016}\_{-0.017}$ at 95 % CL,
which improves on the Planck 2013 results ($\Omega\_{K}=-0.007^{+0.018}\_{-0.019}$ at 95 % CL).
However, due to the remaining degeneracies left by the
uncertainties in polarization on large angular scales, a full appreciation
of the improvement
due to the full mission temperature and lensing data can be obtained by using lowP+WP, which leads to
$\Omega\_{K}=-0.003^{+0.012}\_{-0.014}$ at 95 % CL.
Note that the negative values allowed
for the curvature are decreased in magnitude when the running is allowed, suggesting that
the low-$\ell$ temperature deficit is contributing to the estimate of the spatial curvature.

The trend found for $\Lambda$CDM+$r$+$\Omega\_{K}$ is even clearer when spatial curvature and the running of
the spectral index are varied at the same time.
In this case, the Planck temperature plus polarization data are compatible with $r$
values as large as 0.19 (95 % CL), at the cost of
an almost 4 $\sigma$ deviation from spatial flatness (which, however,
disappears as soon as lensing or BAO data are considered).

## 6 Implications for single-field slow-roll inflation

In this section we study the implications of Planck 2015 constraints on standard slow-roll single-field inflationary
models.

### 6.1 Constraints on slow-roll parameters

We first present the Planck 2015 constraints on slow-roll parameters obtained through the
analytic perturbative expansion in terms of the HFFs $\epsilon\_{i}$
for the primordial spectra of cosmological fluctuations during slow-roll inflation ([Stewart & Lyth, 1993](#bib.bib248); [Gong & Stewart, 2001](#bib.bib101); [Leach et al., 2002](#bib.bib140)).
When restricting to first order in $\epsilon\_{i}$, we obtain

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\epsilon\_{1}$ | $\displaystyle<\thinspace 0.0068$ | $\displaystyle\text{(95\thinspace\% CL, {Planck}\ TT+lowP)}\thinspace,$ |  | (36) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\epsilon\_{2}$ | $\displaystyle=\thinspace 0.029^{+0.008}\_{-0.007}$ | $\displaystyle\text{(68\thinspace\% CL, {Planck}\ TT+lowP)}\thinspace.$ |  | (37) |

When high-$\ell$ polarization
is included we obtain $\epsilon\_{1}<0.0066$ at 95 % CL and
$\epsilon\_{2}=0.030^{+0.007}\_{-0.006}$ at 68 % CL.
When second-order contributions in the HFFs are included, we obtain

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\epsilon\_{1}<$ | $\displaystyle 0.012\thinspace\thinspace\thinspace\quad\quad$ | $\displaystyle\text{(95\thinspace\% CL, {Planck}\ TT+lowP)}\thinspace,$ |  | (38) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\epsilon\_{2}=$ | $\displaystyle 0.031^{+0.013}\_{-0.011}\thinspace\thinspace\thinspace$ | $\displaystyle\text{(68\thinspace\% CL, {Planck}\ TT+lowP)}\thinspace,$ |  | (39) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle-0.41<\epsilon\_{3}<$ | $\displaystyle 1.38\quad\quad\quad$ | $\displaystyle\text{(95\thinspace\% CL, {Planck}\ TT+lowP)}\thinspace.$ |  | (40) |

When high-$\ell$ polarization
is included we obtain $\epsilon\_{1}<0.011$ at 95 % CL,
$\epsilon\_{2}=0.032^{+0.011}\_{-0.009}$ at 68 % CL, and $-0.32<\epsilon\_{3}<0.89$ at 95 % CL.

Figure 10: Marginalized joint 68 % and 95 % CL regions for
$(\epsilon\_{1}\thinspace,\epsilon\_{2})$ (top panel)
and $(\epsilon\_{V}\thinspace,\eta\_{V})$ (bottom panel) for Planck TT+lowP (red contours), Planck TT,TE,EE+lowP
(blue contours), and compared with the Planck 2013 results (grey contours).

The potential slow-roll parameters are obtained as derived parameters by using their exact expressions
as function of $\epsilon\_{i}$ ([Leach et al., 2002](#bib.bib140); [Finelli et al., 2010](#bib.bib87)):

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\epsilon\_{V}$ | $\displaystyle=\thinspace\frac{V\_{\phi}^{2}M\_{\mathrm{pl}}^{2}}{2V^{2}}=\epsilon\_{1}\frac{\left(1-\frac{\epsilon\_{1}}{3}+\frac{\epsilon\_{2}}{6}\right)^{2}}{\left(1-\frac{\epsilon\_{1}}{3}\right)^{2}}\thinspace,$ |  | (41) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\eta\_{V}$ | $\displaystyle=\thinspace\frac{V\_{\phi\phi}M\_{\mathrm{pl}}^{2}}{V}=\frac{2\epsilon\_{1}-\frac{\epsilon\_{2}}{2}-\frac{2\epsilon\_{1}^{2}}{3}+\frac{5\epsilon\_{1}\epsilon\_{2}}{6}-\frac{\epsilon\_{2}^{2}}{12}-\frac{\epsilon\_{2}\epsilon\_{3}}{6}}{1-\frac{\epsilon\_{1}}{3}}\thinspace,$ |  | (42) |

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\xi\_{V}^{2}$ | $\displaystyle=$ | $\displaystyle\frac{V\_{\phi\phi\phi}V\_{\phi}M\_{\mathrm{pl}}^{4}}{V^{2}}=\frac{1-\frac{\epsilon\_{1}}{3}+\frac{\epsilon\_{2}}{6}}{\left(1-\frac{\epsilon\_{1}}{3}\right)^{2}}\left(4\epsilon\_{1}^{2}-3\epsilon\_{1}\epsilon\_{2}+\frac{\epsilon\_{2}^{\phantom{2}}\epsilon\_{3}}{2}-\epsilon\_{1}\epsilon\_{2}^{2}\right.$ |  | (43) |
|  |  | $\displaystyle+$ | $\displaystyle\left.3\epsilon\_{1}^{2}\epsilon\_{2}-\frac{4}{3}\epsilon\_{1}^{3}-\frac{7}{6}\epsilon\_{1}\epsilon\_{2}\epsilon\_{3}+\frac{\epsilon\_{2}^{2}\epsilon\_{3}}{6}+\frac{\epsilon\_{2}\epsilon\_{3}^{2}}{6}+\frac{\epsilon\_{2}\epsilon\_{3}\epsilon\_{4}}{6}\right)\thinspace,$ |  |

where $V(\phi)$ is the inflaton potential, the subscript $\phi$ denotes the derivative with respect
to $\phi$, and $M\_{\mathrm{pl}}=(8\pi G)^{-1/2}$ is the reduced Planck mass (see also Table [2](#S3.T2 "Table 2 ‣ 3.2 Primordial spectra of cosmological fluctuations ‣ 3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation")).

By using Eqs. ([41](#S6.E41 "In 6.1 Constraints on slow-roll parameters ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation")) and ([42](#S6.E42 "In 6.1 Constraints on slow-roll parameters ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation")) with $\epsilon\_{3}=0$ and the primordial power spectra to lowest
order in the HFFs, the derived constraints for the first two slow-roll potential parameters are:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\epsilon\_{V}$ | $\displaystyle<\thinspace 0.0068$ | $\displaystyle\text{(95\thinspace\% CL, {Planck}\ TT+lowP)}\thinspace,$ |  | (44) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\eta\_{V}^{2}$ | $\displaystyle=\thinspace-0.010^{+0.005}\_{-0.009}$ | $\displaystyle\text{(68\thinspace\% CL, {Planck}\ TT+lowP)}\thinspace.$ |  | (45) |

When high-$\ell$ polarization
is included we obtain $\epsilon\_{V}<0.0067$ at 95 % CL and
$\eta\_{V}=-0.010^{+0.004}\_{-0.009}$ at 68 % CL. By using Eqs. ([41](#S6.E41 "In 6.1 Constraints on slow-roll parameters ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation")), ([42](#S6.E42 "In 6.1 Constraints on slow-roll parameters ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation")), and ([43](#S6.E43 "In 6.1 Constraints on slow-roll parameters ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation"))
with $\epsilon\_{4}=0$ and the primordial power spectra to second order in the HFFs,
the derived constraints for the slow-roll potential parameters are:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\epsilon\_{V}$ | $\displaystyle<\thinspace 0.012$ | $\displaystyle\text{(95\thinspace\% CL, {Planck}\ TT+lowP)}\thinspace,$ |  | (46) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\eta\_{V}$ | $\displaystyle=\thinspace-0.0080^{+0.0088}\_{-0.0146}$ | $\displaystyle\text{(68\thinspace\% CL, {Planck}\ TT+lowP)}\thinspace,$ |  | (47) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\xi\_{V}^{2}$ | $\displaystyle=\thinspace 0.0070^{+0.0045}\_{-0.0069}$ | $\displaystyle\text{(68\thinspace\% CL, {Planck}\ TT+lowP)}\thinspace.$ |  | (48) |

When high-$\ell$ polarization is included we obtain $\epsilon\_{V}<0.011$ at 95 % CL, and
$\eta\_{V}=-0.0092^{+0.0074}\_{-0.0127}$ and $\xi^{2}\_{V}=0.0044^{+0.0037}\_{-0.0050}$, both at 68 % CL.

In Figs. [10](#S6.F10 "Figure 10 ‣ 6.1 Constraints on slow-roll parameters ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation") and [11](#S6.F11 "Figure 11 ‣ 6.1 Constraints on slow-roll parameters ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation") we show the 68 % CL and 95 % CL of the HFFs
and the derived potential slow-roll parameters with and without the high-$\ell$ polarization
and compare these values with the Planck 2013 results.

Figure 11: Marginalized joint 68 % and 95 % CL regions for
$(\epsilon\_{1}\thinspace,\epsilon\_{2}\thinspace,\epsilon\_{3})$ (top panels)
and $(\epsilon\_{V}\thinspace,\eta\_{V}\thinspace,\xi\_{V}^{2})$ (bottom panels) for Planck TT+lowP (red contours), Planck TT,TE,EE+lowP
(blue contours), and compared with the Planck 2013 results (grey contours).

Figure 12: Marginalized joint 68 % and 95 % CL regions for $n\_{\mathrm{s}}$ and $r$ at $k=0.002$ Mpc-1 from Planck compared to the theoretical predictions
of selected inflationary models. Note that the marginalized
joint 68 % and 95 % CL regions have been obtained by assuming $dn\_{\mathrm{s}}/d\ln k=0$.

### 6.2 Implications for selected inflationary models

The predictions to lowest order in the slow-roll approximation
for $(n\_{\mathrm{s}},r)$ at $k=0.002$ Mpc-1 of a few inflationary models with a representative uncertainty for the entropy generation stage
($50<N\_{\*}<60$) are shown in Fig. [12](#S6.F12 "Figure 12 ‣ 6.1 Constraints on slow-roll parameters ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation"). Fig. [12](#S6.F12 "Figure 12 ‣ 6.1 Constraints on slow-roll parameters ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation") updates Fig. 1 of [205](#bib.bib205)
with the same notation.

In the following we discuss the implications of Planck TT+lowP+BAO data
for selected slow-roll inflationary models by taking into account the uncertainties in the
entropy generation stage. We model these uncertainties by two parameters, as in [205](#bib.bib205):
the energy scale $\rho\_{\mathrm{th}}$ by which the Universe has thermalized, and the parameter $w\_{\mathrm{int}}$ which characterizes
the effective equation of state between the end of inflation and the energy scale specified by $\rho\_{\mathrm{th}}$.
We use the primordial power spectra of cosmological fluctuations generated during slow-roll inflation
parameterized by the HFFs, $\epsilon\_{i}$, to second order, which can be expressed in
terms of the number of $e$-folds to the end of inflation, $N\_{\*}$, and
the parameters of the considered inflationary model, using modified routines of
the public code ASPIC66
6
<http://cp3.irmp.ucl.ac.be/~ringeval/aspic.html> ([Martin et al., 2014](#bib.bib165)).
For the number of $e$-folds to the end of inflation ([Liddle & Leach, 2003](#bib.bib148); [Martin & Ringeval, 2010](#bib.bib164))
we use the expression ([205](#bib.bib205))

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle N\_{\*}\approx$ | $\displaystyle 67-\ln\left(\frac{k\_{\*}}{a\_{0}H\_{0}}\right)+\frac{1}{4}\ln{\left(\frac{V\_{\*}^{2}}{M\_{\mathrm{pl}}^{4}\rho\_{\mathrm{end}}}\right)}$ |  | (49) |
|  |  | $\displaystyle+\frac{1-3w\_{\mathrm{int}}}{12(1+w\_{\mathrm{int}})}\ln{\left(\frac{\rho\_{\mathrm{th}}}{\rho\_{\mathrm{end}}}\right)}-\frac{1}{12}\ln(g\_{\mathrm{th}})\;,$ |  |

where $\rho\_{\mathrm{end}}$ is the energy density at the end of inflation,
$a\_{0}H\_{0}$ is the present Hubble scale,
$V\_{\*}$ is the potential energy when $k\_{\*}$ left the Hubble radius during inflation,
$w\_{\mathrm{int}}$ characterizes the effective equation of state between the end of inflation
and the thermalization energy scale $\rho\_{\mathrm{th}}$,
and $g\_{\mathrm{th}}$ is the number of effective bosonic
degrees of freedom at the energy scale $\rho\_{\mathrm{th}}$.
We consider the pivot scale
$k\_{\*}=0.002$ Mpc-1, $g\_{\mathrm{th}}=10^{3}$, and $\epsilon\_{\mathrm{end}}=1$. We consider the
uniform priors for the cosmological
parameters listed in Table [6](#S6.T6 "Table 6 ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation").
We also consider a logarithmic prior on $10^{10}A\_{\mathrm{s}}$
(over the interval $[(e^{2.5},e^{3.7}]$) and
$\rho\_{\mathrm{th}}$ (over the interval $[(1\thinspace\mathrm{TeV})^{4},\rho\_{\mathrm{end}}]$). We consider both the case
in which $w\_{\mathrm{int}}$ is kept fixed at zero and the case in which it is allowed to vary with a uniform prior in the range
$-1/3<w\_{\mathrm{int}}<1/3$.

|  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  | | --- | --- | | Parameter range | Prior type | | $0.019<\Omega\_{\mathrm{b}}h^{2}<0.025$ | uniform | | $0.095<\Omega\_{\mathrm{c}}h^{2}<0.145$ | uniform | | $1.03<100\theta\_{\mathrm{MC}}<1.05$ | uniform | | $0.01<\tau<0.4$ | uniform | |  |

Table 6: Priors for cosmological parameters used in the Bayesian comparison of inflationary models.

We have validated the slow-roll approach by cross-checking
the Bayes factor computations against the fully numerical inflationary mode equation
solver ModeCode coupled to the PolyChord sampler. For each inflationary model we provide in Table [7](#S6.T7 "Table 7 ‣ Non-minimally coupled inflaton ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation") and in the
main text the $\Delta\chi^{2}$ value with respect to the base $\Lambda$CDM model, computed
with the CosmoMC implementation of the BOBYQA
algorithm for maximizing the likelihood,
and the Bayesian evidence with respect to the $R^{2}$ inflationary model ([Starobinsky, 1980](#bib.bib244)),
computed by CosmoMC connected to CAMB, using MultiNest as the sampler.

#### Power law potentials

We first investigate the class of inflationary models with a single monomial potential ([Linde, 1983](#bib.bib151)):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\lambda M\_{\mathrm{pl}}^{4}\left(\frac{\phi}{M\_{\mathrm{pl}}}\right)^{n}\thinspace,$ |  | (50) |

in which inflation occurs for large values of the inflaton, $\phi>M\_{\mathrm{pl}}$.
The predictions for the scalar spectral index and the tensor-to-scalar ratio at first order in the slow-roll
approximation are $n\_{\mathrm{s}}-1\approx-2(n+2)/(4N\_{\*}+n)$ and
$r\approx 16n/(4N\_{\*}+n)$, respectively.
By assuming a dust equation of state (i.e., $w\_{\mathrm{int}}=0$) prior to thermalization,
the cubic and quartic potentials are strongly disfavoured by
$\ln B=-11.6$ and $\ln B=-23.3$, respectively. The quadratic potential
is moderately disfavoured by $\ln B=-4.7$.
Other values, such as $n=4/3$, $1$, and $2/3$, motivated
by axion monodromy ([Silverstein & Westphal, 2008](#bib.bib240); [McAllister et al., 2010](#bib.bib167)), are compatible with Planck data with $w\_{\mathrm{int}}=0$.

Small modifications occur when considering the effective equation
of state parameter, $w\_{\mathrm{int}}=(n-2)/(n+2)$, defined by averaging over the
coherent oscillation regime which follows inflation ([Turner, 1983](#bib.bib251)).
The Bayes factors are slightly modified when
$w\_{\mathrm{int}}$ is allowed to float, as shown in Table [7](#S6.T7 "Table 7 ‣ Non-minimally coupled inflaton ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation").

#### Hilltop models

In hilltop models ([Boubekeur & Lyth, 2005](#bib.bib37)), with potential

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)\approx\Lambda^{4}\left(1-\frac{\phi^{{p}}}{\mu^{{p}}}+...\right)\thinspace,$ |  | (51) |

the inflaton rolls away from an unstable equilibrium.
The predictions to first order in the slow-roll approximation are
$r\approx 8p^{2}(M\_{\mathrm{pl}}/\mu)^{2}x^{2p-2}/(1-x^{p})^{2}$ and
$n\_{s}-1\approx-2p(p-1)(M\_{\mathrm{pl}}/\mu)^{2}x^{p-2}/(1-x^{p})-3r/8$, where $x=\phi\_{\*}/\mu$.
As in [205](#bib.bib205), the ellipsis in Eq. ([51](#S6.E51 "In Hilltop models ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation")) and in what follows
indicates higher-order terms that are negligible during inflation but
ensure positiveness of the potential.

By sampling $\log\_{10}(\mu/M\_{\mathrm{pl}})$ within the prior $[0.30,4.85]$ for $p=2$, we obtain
$\log\_{10}(\mu/M\_{\mathrm{pl}})>1.02$ ($1.05$) at 95 % CL and $\ln B=-2.6$ ($-2.4$) for $w\_{\mathrm{int}}=0$
(allowing $w\_{\mathrm{int}}$ to float).

An exact potential which could also apply after inflation, instead of the approximated one in Eq. ([51](#S6.E51 "In Hilltop models ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation")),
might be needed for a better comparison among different models.
For $\mu/M\_{\mathrm{pl}}\gg 1$, hilltop models as defined in Eq. ([51](#S6.E51 "In Hilltop models ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation")) by neglecting the
additional terms denoted by the ellipsis
lead to $n\_{\mathrm{s}}-1\approx-3r/8$, the same prediction as for
the previously discussed linear potential, $V(\phi)\propto\phi.$ By considering a double well potential,
$V(\phi)=\Lambda^{4}[1-\phi^{2}/(2\mu^{2})]^{2}$, instead,
we obtain a slightly worse Bayes factor than the hilltop $p=2$ model, $\ln B=-3.1$ ($-2.3$) for $w\_{\mathrm{int}}=0$
($w\_{\mathrm{int}}$ allowed to vary). This different result can be easily understood.
Although the double well potential is equal to the hilltop model for $\phi\ll\mu$,
it approximates $V(\phi)\propto\phi^{2}$ for $\mu/M\_{\mathrm{pl}}\gg 1$. Since a linear potential
is a better fit to Planck than $\phi^{2}$,
the fit of the double well potential is therefore worse than the hilltop $p=2$ case for $\mu/M\_{\mathrm{pl}}\gg 1$,
and this partially explains the slightly different Bayes factors obtained.

In the $p=4$ case, we obtain
$\log\_{10}(\mu/M\_{\mathrm{pl}})>1.05$ ($1.02$) at 95 % CL and $\ln B=-2.8$ ($-2.6$) for $w\_{\mathrm{int}}=0$
(allowing $w\_{\mathrm{int}}$ to float), assuming a prior range $[-2,2]$ for $\log\_{10}(\mu/M\_{\mathrm{pl}})$.

#### Natural inflation

In natural inflation ([Freese et al., 1990](#bib.bib91); [Adams et al., 1993](#bib.bib3)) a nonperturbative shift symmetry is invoked to
suppress radiative corrections leading to the periodic potential

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\Lambda^{4}\left[1+\cos\left(\frac{\phi}{f}\right)\right],$ |  | (52) |

where $f$ is the scale which determines the curvature of the potential.
We sample $\log\_{10}(f/M\_{\mathrm{pl}})$ within the prior $[0.3,2.5]$ as in [205](#bib.bib205).
We obtain $\log\_{10}(f/M\_{\mathrm{pl}})>0.84$ ($>0.83$) at 95 % CL
and $\ln B=-2.4$ ($-2.3$) for
$w\_{\mathrm{int}}=0$ (allowing $w\_{\mathrm{int}}$ to vary).

Note that the super-Planckian value for $f$ required by observations is not necessarily a problem for
this class of models.
When several fields $\phi\_{i}$ with a cosine potential as in Eq. ([52](#S6.E52 "In Natural inflation ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation")) and scales $f\_{i}$ appear in the Lagrangian,
an effective single-field inflationary trajectory can be found for a suitable choice of parameters ([Kim et al., 2005](#bib.bib130)).
In such a setting, the super-Planckian value of the effective scale $f$
required by observations can be obtained even if the original scales satisfy $f\_{i}\ll M\_{\mathrm{pl}}$ ([Kim et al., 2005](#bib.bib130)).

#### D-brane inflation

Inflation can arise from physics involving extra dimensions.
If the standard model of particle physics is confined to our 3-dimensional brane,
the distance between our brane and anti-brane can drive inflation.
We consider the following parameterization for the
effective potential driving inflation:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\Lambda^{4}\left(1-\frac{\mu^{p}}{\phi^{p}}+...\right)\thinspace.$ |  | (53) |

Sampling $\log\_{10}(\mu/M\_{\mathrm{pl}})$ using a uniform prior over $[-6,0.3],$ we consider $p=4$
([Kachru et al., 2003](#bib.bib119); [Dvali et al., 2001](#bib.bib67)) and $p=2$ ([Garcia-Bellido et al., 2002](#bib.bib93)).
The predictions for $r$ and $n\_{\mathrm{s}}$ can be obtained from the hilltop case with the substitution $p\rightarrow-p$.
These models agree with the Planck data with a Bayes factor of $\ln B=-0.4$ ($-0.6$) and $\ln B=-0.7$ ($-0.9$)
for $p=4$ and $p=2$, respectively, for $w\_{\mathrm{int}}=0$ (allowing $w\_{\mathrm{int}}$ to vary).

#### Potentials with exponential tails

Exponential potentials are ubiquitous in inflationary models
motivated by supergravity and string theory
([Goncharov & Linde, 1984](#bib.bib100); [Stewart, 1995](#bib.bib247); [Dvali & Tye, 1999](#bib.bib68); [Burgess et al., 2002](#bib.bib45); [Cicoli et al., 2009](#bib.bib56)).
We restrict ourselves to analysing the following class of potentials:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\Lambda^{4}\left(1-e^{-q\phi/M\_{\mathrm{pl}}}+...\right)\thinspace.$ |  | (54) |

As for the hilltop models described earlier, the ellipsis indicates possible
higher-order terms that are negligible during inflation but
ensure positiveness of the potential.
These models predict $r\approx 8q^{2}e^{-2q\phi/M\_{\mathrm{pl}}}/(1-e^{-q\phi/M\_{\mathrm{pl}}})^{2}$ and
$n\_{s}-1\approx-q^{2}e^{-q\phi/M\_{\mathrm{pl}}}(2+e^{-q\phi/M\_{\mathrm{pl}}})/(1-e^{-q\phi/M\_{\mathrm{pl}}})^{2}$ with
a slow-roll trajectory characterized by $N\approx f(\phi/M\_{\mathrm{pl}})-f(\phi\_{\mathrm{end}}/M\_{\mathrm{pl}})$, with $f(x)=(e^{qx}-qx)/q^{2}$.
By sampling $\log\_{10}(q/M\_{\mathrm{pl}})$ with a uniform prior over $[-3,3]$, we obtain
a Bayes factor of $-0.6$ for $w\_{\mathrm{int}}=0$ ($-0.9$ when $w\_{\mathrm{int}}$ is allowed to vary).

#### Spontaneously broken SUSY

Hybrid models ([Copeland et al., 1994](#bib.bib58); [Linde, 1994](#bib.bib152))
predicting $n\_{\mathrm{s}}>1$ are strongly disfavoured by the Planck data, as for the first cosmological
release ([205](#bib.bib205)).
An example of a hybrid model predicting $n\_{\mathrm{s}}<1$ is the case in which slow-roll inflation is driven by
loop corrections in spontaneously broken supersymmetric (SUSY) grand unified theories ([Dvali et al., 1994](#bib.bib69))
described by the potential

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\Lambda^{4}\left[1+\alpha\_{h}\log\left(\phi/M\_{\mathrm{pl}}\right)\right],$ |  | (55) |

where $\alpha\_{h}>0$ is a dimensionless parameter.
Note that for $\alpha\_{h}\ll 1$, this model leads to
the same predictions as the power-law potential for $p\ll 1$ to lowest order in the slow-roll approximation.
By sampling $\log\_{10}(\alpha\_{h})$ on a flat prior $[-2.5,1]$,
we obtain a Bayes factor of $-2.2$ for $w\_{\mathrm{int}}=0$ ($-1.7$ when $w\_{\mathrm{int}}$ is allowed to vary).

#### $R^{2}$ inflation

The first inflationary model proposed ([Starobinsky, 1980](#bib.bib244)), with action

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S=\int\mathrm{d}^{4}x\sqrt{-g}\frac{M^{2}\_{\mathrm{pl}}}{2}\left(R+\frac{R^{2}}{6M^{2}}\right)\thinspace,$ |  | (56) |

still lies within the Planck 68 % CL constraints, as for the Planck 2013
release ([205](#bib.bib205)). This model corresponds to the potential

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\Lambda^{4}\left(1-e^{-\sqrt{2/3}\phi/M\_{\mathrm{pl}}}\right)^{2}$ |  | (57) |

in the Einstein frame,
which leads to the slow-roll predictions $n\_{\mathrm{s}}-1\approx-2/N$ and $r\approx 12/N^{2}$
([Mukhanov & Chibisov, 1981](#bib.bib184); [Starobinsky, 1983](#bib.bib243)).

After the Planck 2013 release, several theoretical developments supported the model in Eq. ([56](#S6.E56 "In 𝑅^2 inflation ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation")) beyond
the original motivation of including quantum effects at one-loop ([Starobinsky, 1980](#bib.bib244)).
No-scale supergravity ([Ellis et al., 2013a](#bib.bib75)), the
large-field regime of superconformal $D$-term inflation ([Buchmüller et al., 2013](#bib.bib44)), or recent developments in
minimal supergravity ([Farakos et al., 2013](#bib.bib80); [Ferrara et al., 2013b](#bib.bib85)) can lead to a
generalization of the potential in Eq. ([57](#S6.E57 "In 𝑅^2 inflation ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation"))
(see [Ketov & Starobinsky (2011)](#bib.bib128) for a previous embedding of $R^{2}$ inflation in $F({\mathcal{R}})$ supergravity).
The potential in Eq. ([57](#S6.E57 "In 𝑅^2 inflation ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation")) can also be generated by spontaneous breaking of
conformal symmetry ([Kallosh & Linde, 2013b](#bib.bib122)).
This inflationary model has $\Delta\chi^{2}\approx 0.8$ ($0.3$) larger than the base $\Lambda$CDM model
with no tensors for $w\_{\mathrm{int}}=0$ (for $w\_{\mathrm{int}}$ allowed to vary).
We obtain $54<N\_{\*}<62$ ($53<N\_{\*}<64$) at 95 % CL for $w\_{\mathrm{int}}=0$
(for $w\_{\mathrm{int}}$ allowed to vary), compatible with the theoretical prediction,
$N\_{\*}=54$ ([Starobinsky, 1980](#bib.bib244); [Vilenkin, 1985](#bib.bib256); [Gorbunov & Panin, 2011](#bib.bib102)).

#### $\alpha$ attractors

We now study two classes of inflationary models motivated by recent developments in conformal symmetry and supergravity
([Kallosh et al., 2013](#bib.bib123)). The first class has been motivated by considering a vector rather than a
chiral multiplet for the inflaton in supergravity ([Ferrara et al., 2013a](#bib.bib84))
and corresponds to the potential ([Kallosh et al., 2013](#bib.bib123))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\Lambda^{4}\left(1-e^{-\sqrt{2}\phi/\left(\sqrt{3\alpha}M\_{\mathrm{pl}}\right)}\right)^{2}\thinspace.$ |  | (58) |

To lowest order in the slow-roll approximation,
these models predict $r\approx 64/[3\alpha(1-e^{\sqrt{2}\phi/(\sqrt{3\alpha}M\_{\mathrm{pl}})})^{2}]$ and
$n\_{\mathrm{s}}-1\approx-8(1+e^{\sqrt{2}\phi/(\sqrt{3\alpha}M\_{\mathrm{pl}})})/[3\alpha(1-e^{\sqrt{2}\phi/(\sqrt{3\alpha}M\_{\mathrm{pl}})})^{2}]$ based on
an inflationary trajectory characterized by $N\approx g(\phi/M\_{\mathrm{pl}})-g(\phi\_{\mathrm{end}}/M\_{\mathrm{pl}})$ with $g(x)=(3\alpha^{4}e^{\sqrt{2}x/\sqrt{3\alpha}}-\sqrt{6\alpha}x)/4$. The relation between $N$ and $\phi$ can be inverted through the use of the
Lambert functions, as carried out for other potentials ([Martin et al., 2014](#bib.bib165)). By sampling
$\log\_{10}(\alpha^{2})$ with a flat prior over $[0,4]$,
we obtain $\log\_{10}(\alpha^{2})<1.7$ ($2.0$) at 95 % CL and
a Bayes factor of $-1.8$ ($-2$) for $w\_{\mathrm{int}}=0$ (for $w\_{\mathrm{int}}$ allowed to vary).

The second class of models has been called super-conformal $\alpha$
attractors ([Kallosh et al., 2013](#bib.bib123)) and can be understood
as originating from a different generating function with respect
to the first class. This second class is described by
the following potential ([Kallosh et al., 2013](#bib.bib123)):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\Lambda^{4}\tanh^{2m}\left(\frac{\phi}{\sqrt{6\alpha}M\_{\mathrm{pl}}}\right)\thinspace.$ |  | (59) |

This is the simplest class of models with spontaneous breaking of conformal symmetry, and
for $\alpha=m=1$ reduces to the original model introduced by [Kallosh & Linde (2013b)](#bib.bib122).
The potential in Eq. ([59](#S6.E59 "In 𝛼 attractors ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation"))
leads to the following slow-roll predictions ([Kallosh et al., 2013](#bib.bib123)):

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle r$ | $\displaystyle\approx{48\alpha m\over 4mN^{2}+2Ng(\alpha,m)+3\alpha m}\thinspace,$ |  | (60) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle n\_{s}-1$ | $\displaystyle\approx-\frac{8mN+6\alpha m+2g(\alpha,m)}{4mN^{2}+2Ng(\alpha,m)+3\alpha m}\thinspace,$ |  | (61) |

where $g(\alpha,m)=\sqrt{3\alpha(4m^{2}+3\alpha)}$.
The predictions of this second class of models interpolate between those of a large-field chaotic model,
$V(\phi)\propto\phi^{2m}$, for $\alpha\gg 1$ and the $R^{2}$ model for $\alpha\ll 1$.

For $\alpha$ we adopt the same priors as for the previous class in Eq. ([58](#S6.E58 "In 𝛼 attractors ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation")).
By fixing $m=1$, we obtain $\log\_{10}(\alpha^{2})<2.3$ ($2.5$) at 95 % CL and
a Bayes factor of $-2.3$ ($-2.2$) for $w\_{\mathrm{int}}=0$ (when $w\_{\mathrm{int}}$ is allowed to vary).
When $m$ is allowed to vary as well with a flat prior in the range $[0,2]$, we obtain $0.02<m<1$
($m<1$) at 95 % CL for $w\_{\mathrm{int}}=0$ (when $w\_{\mathrm{int}}$ is allowed to vary).

#### Non-minimally coupled inflaton

Inflationary predictions are quite sensitive to a non-minimal coupling $\xi R\phi^{2}$
of the inflaton to the Ricci scalar.
One of the most interesting effects due to $\xi\neq 0$ is
to reconcile the quartic potential $V(\phi)=\lambda\phi^{4}/4$ with Planck observations,
even for $\xi\ll 1$. Non-minimal coupling leads as well to attractor behaviour
towards predictions similar to those in $R^{2}$ inflation ([Kaiser & Sfakianakis, 2014](#bib.bib120); [Kallosh & Linde, 2013a](#bib.bib121)).

The Higgs inflation model ([Bezrukov & Shaposhnikov, 2008](#bib.bib30)), in which inflation occurs with
$V(\phi)=\lambda(\phi^{2}-\phi\_{0}^{2})^{2}/4$ and $\xi\gg 1$ for $\phi\gg\phi\_{0}$,
leads to the same predictions as the $R^{2}$ model to lowest order in the slow-roll approximation at tree level
(see [Barvinsky et al. (2008)](#bib.bib22) and [Bezrukov & Shaposhnikov (2009)](#bib.bib31) for the inclusion of loop corrections).
It is therefore in agreement with the Planck constraints,
as for the first cosmological data release ([205](#bib.bib205)).

We summarize below our findings for Planck lowP+BAO.

* •

  Monomial potentials with integral $n>2$ are strongly disfavoured with respect to $R^{2}$.
* •

  The Bayes factor prefers $R^{2}$ over chaotic inflation with monomial quadratic potential by odds of 110:1
  under the assumption of a dust equation of state during the entropy generation stage.
* •

  $R^{2}$ inflation has the strongest evidence (i.e., the greatest Bayes factor)
  among the models considered here.
  However, care must be taken not to overinterpret small differences in likelihood lacking statistical significance.
* •

  The models closest to $R^{2}$ in terms of evidence are brane inflation and exponential
  inflation, which have one more parameter than $R^{2}$. Both brane inflation considered
  in Eq. ([53](#S6.E53 "In D-brane inflation ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation")) and exponential inflation in Eq. ([54](#S6.E54 "In Potentials with exponential tails ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation"))
  approximate the linear potential for a large portion of parameter space
  (for $\mu/M\_{\mathrm{pl}}\gg 1$ and $q\gg 1$, respectively). For this reason these models have a higher
  Bayesian evidence (although not at a statistically significant level) than those that approximate a quadratic potential, as
  do $\alpha$-attractors, for instance.
* •

  In the models considered here,
  the $\Delta\chi^{2}$ obtained by allowing $w$ to vary is modest (i.e., less than approximately $1.6$
  with respect to $w\_{\mathrm{int}}=0$).
  The gain in the logarithm of the Bayesian evidence is even smaller, since an extra parameter is added.

Table 7: Results of the inflationary model comparison. We provide $\Delta\chi^{2}$
with respect to base $\Lambda$CDM and Bayes factors with respect to $R^{2}$ inflation.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  |  |  | | --- | --- | --- | --- | --- | | Inflationary model | $\Delta\chi^{2}$ | | $\ln B$ | | |  | $w\_{\mathrm{int}}=0\$ | $w\_{\mathrm{int}}\neq 0$ | $w\_{\mathrm{int}}=0$ | $w\_{\mathrm{int}}\neq 0$ | | $R+R^{2}/(6M^{2})$ | $+0.8$ | $+0.3$ | $\ldots$ | $+0.7$ | | $n=2/3$ | $+6.5$ | $+3.5$ | $-2.4$ | $-2.3$ | | $n=1$ | $+6.2$ | $+5.5$ | $-2.1$ | $-1.9$ | | $n=4/3$ | $+6.4$ | $+5.5$ | $-2.6$ | $-2.4$ | | $n=2$ | $+8.6$ | $+8.1$ | $-4.7$ | $-4.6$ | | $n=3$ | $+22.8$ | $+21.7$ | $-11.6$ | $-11.4$ | | $n=4$ | $+43.3$ | $+41.7$ | $-23.3$ | $-22.7$ | | Natural | $+7.2$ | $+6.5$ | $-2.4$ | $-2.3$ | | Hilltop ($p=2$) | $+4.4$ | $+3.9$ | $-2.6$ | $-2.4$ | | Hilltop ($p=4$) | $+3.7$ | $+3.3$ | $-2.8$ | $-2.6$ | | Double well | $+5.5$ | $+5.3$ | $-3.1$ | $-2.3$ | | Brane inflation ($p=2$) | $+3.0$ | $+2.3$ | $-0.7$ | $-0.9$ | | Brane inflation ($p=4$) | $+2.8$ | $+2.3$ | $-0.4$ | $-0.6$ | | Exponential tails | $+0.8$ | $+0.3$ | $-0.7$ | $-0.9$ | | SB SUSY | $+0.7$ | $+0.4$ | $-2.2$ | $-1.7$ | | Supersymmetric $\alpha$-model | $+0.7$ | $+0.1$ | $-1.8$ | $-2.0$ | | Superconformal ($m=1$) | $+0.9$ | $+0.8$ | $-2.3$ | $-2.2$ | | Superconformal ($m\neq 1$) | $+0.7$ | $+0.5$ | $-2.4$ | $-2.6$ | |  |

## 7 Reconstruction of the potential and analysis beyond slow-roll approximation

### 7.1 Introdution

In the previous section, we derived constraints on several types of inflationary potentials assumed to account for the inflaton dynamics between the time at which the largest observable scales crossed the Hubble radius during inflation and the end of inflation. The full shape of the potential was used in order to identify when inflation ends, and thus the field value $\phi\_{\*}$ when the pivot scale crosses the Hubble radius.

In section 6 of [205](#bib.bib205), we explored another approach, consisting of reconstructing the inflationary potential within its observable
range without making any assumptions concerning the inflationary dynamics outside that range. Indeed,
given that the number of $e$-folds between the observable range and the end of inflation can always be adjusted to take a realistic value,
any potential shape giving a primordial spectrum of scalar and tensor perturbations in agreement with observations is a valid candidate.
Inflation can end abruptly by a phase transition,
or can last a long time if the potential becomes very flat after the observable region has been crossed. Moreover, there could be a short inflationary stage
responsible for the origin of observable cosmological perturbations, and another inflationary stage later on (but before
nucleosynthesis), thus contributing to the total $N\_{\*}$.

In section 6 of [205](#bib.bib205), we performed this analysis with a full integration of the inflaton and metric perturbation modes, so that no
slow-roll approximation was made. The only assumption was that primordial scalar perturbations are generated by the fluctuations of a single inflaton
field with a canonical kinetic term. Since in this approach one is only interested in the potential over a narrow range of observable scales (centred around the field value $\phi\_{\*}$ when the pivot scale crosses the Hubble radius), it is reasonable to test relatively simple potential shapes described by a small number of free parameters.

This approach gave very similar results to calculations based on the standard slow-roll analysis.
This agreement can be explained by the fact that
the Planck 2013 data already preferred a primordial spectrum very close to a power law, at least over most of the observable range. Hence
the 2013 data excluded strong deviations from slow-roll inflation, which would either produce a large running of the spectral index or imprint
more complicated features on the primordial spectrum. However, this conclusion did not apply to the largest scales observable by Planck, for
which cosmic variance and slightly anomalous data points remained compatible with significant deviations from a simple power law spectrum.
The most striking result in section 6 of [205](#bib.bib205) was that a less restricted functional form for the inflaton
potential gave results compatible with a rather steep potential at the beginning of the observable window, leading to a “not-so-slow” roll
stage during the first few observable $e$-folds.
This explains the shape of the potential in figure 14 of [205](#bib.bib205) for a Taylor
expansion at order $n=4$ and in the region where $\phi-\phi\_{\*}\leq-0.2$. However, such features were only partially explored because the
method used for potential reconstruction did not allow for an arbitrary value of the inflation velocity $\dot{\phi}$ at the beginning of the
observable window. Instead, our code imposed that the inflaton already tracked the inflationary attractor solution when the largest observable
modes crossed the Hubble scale.

Given that the Planck 2015 data establish even stronger constraints on the primordial power
spectrum than the 2013 results, it is of interest to revisit the reconstruction of the
potential $V(\phi)$. Section [7.2](#S7.SS2 "7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") presents some new results following the same approach as in [205](#bib.bib205)
(explained previously in [Lesgourgues & Valkenburg (2007)](#bib.bib144) and [Mortonson et al. (2011)](#bib.bib180)). But in the present work, we also present some more general results,
independent of any assumption concerning the initial field velocity $\dot{\phi}$ when the inflaton enters the observable window. Following
previous studies ([Kinney, 2002](#bib.bib131); [Kinney et al., 2006](#bib.bib132); [Peiris & Easther, 2006a](#bib.bib196); [Easther & Peiris, 2006](#bib.bib72); [Peiris & Easther, 2006b](#bib.bib197); [Peiris & Easther, 2008](#bib.bib199); [Lesgourgues et al., 2008](#bib.bib143); [Powell & Kinney, 2007](#bib.bib228); [Hamann et al., 2008](#bib.bib109); [Norena et al., 2012](#bib.bib187)),
we reconstruct the Hubble
function $H(\phi),$ which determines both the potential $V(\phi)$ through

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=3M\_{\mathrm{Pl}}^{2}\thinspace H^{2}(\phi)-2M\_{\mathrm{Pl}}^{4}\left[H^{\prime}(\phi)\right]^{2}\penalty\ ,$ |  | (62) |

and the solution $\phi(t)$ through

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\dot{\phi}=-2M\_{\mathrm{Pl}}^{2}H^{\prime}(\phi)\penalty\ ,$ |  | (63) |

with $H^{\prime}(\phi)={\partial H}/{\partial\phi}.$ Note that these two relations are exact. In Sect. [7.3](#S7.SS3 "7.3 Reconstruction of a smooth Hubble function ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation"), we fit $H(\phi)$
directly to the data, implicitly including all canonical single-field models in which the inflaton is rolling not very slowly ($\epsilon$
not much smaller than unity) just before entering the observable window, and the issue of having to start sufficiently early in order to allow the
initial transient to decay is avoided. The only drawback in reconstructing $H(\phi)$ is that one cannot systematically test the simplest
analytic forms for $V(\phi)$ in the observable range (for instance, polynomials of order $n=1,3,5,\ldots$ in $(\phi-\phi\_{\*})$). But our goal in this
section is to explore how much one can deviate from slow-roll inflation in general, independently of the shape of the underlying inflaton
potential.

Figure 13: Posterior distributions for the first four potential slow-roll parameters when the potential is Taylor
expanded to $n$th order using
Planck TT+lowP+BAO (filled contours) or TT,TE,EE+lowP (dashed contours). The primordial spectra are computed beyond the
slow-roll
approximation.

|  |  |  |  |
| --- | --- | --- | --- |
|  |  |  |  |
|  |  |  |  |
| $n$ | 2 | 3 | 4 |
| $\epsilon\_{V}$ | $<0.0074$ | $<0.010$ | $0.0072\_{-0.0069}^{+0.0093}$ |
| $\eta\_{V}$ | $-0.007\_{-0.012}^{+0.014}$ | $-0.020\_{-0.018}^{+0.021}$ | $0.021\_{-0.042}^{+0.044}$ |
| $\xi\_{V}^{2}$ | $\ldots$ | $0.006\_{-0.010}^{+0.010}$ | $-0.018\_{-0.027}^{+0.028}$ |
| $\varpi\_{V}^{3}$ | $\ldots$ | $\ldots$ | $0.015\_{-0.017}^{+0.016}$ |
| $\tau$ | $0.083\_{-0.036}^{+0.036}$ | $0.096\_{-0.044}^{+0.046}$ | $0.102\_{-0.045}^{+0.046}$ |
| $n\_{\mathrm{s}}$ | $0.9692\_{-0.0093}^{+0.0094}$ | $0.9689\_{-0.0097}^{+0.0097}$ | $0.964\_{-0.011}^{+0.011}$ |
| $dn\_{\mathrm{s}}/d\ln k$ | $-0.00034\_{-0.00059}^{+0.00055}$ | $-0.013\_{-0.019}^{+0.019}$ | $0.003\_{-0.026}^{+0.026}$ |
| $r\_{0.002}$ | $<0.11$ | $<0.16$ | $0.11\_{-0.11}^{+0.16}$ |
| $\Delta\chi^{2}$ | $\ldots$ | $\Delta\chi^{2}\_{3/2}=-1.2$ | $\Delta\chi^{2}\_{4/3}=-2.1$ |
| $\Delta\ln B$ | $\ldots$ | $\Delta\ln B\_{3/2}=-4.3$ | $\Delta\ln B\_{4/3}=-2.9$ |

Table 8: Numerical reconstruction of the potential slow-roll parameters beyond any slow-roll approximation when the potential is
Taylor expanded to $n$th order, using Planck TT+lowP+BAO. We also show the corresponding bounds on the derived parameters (here
$n\_{\mathrm{s}}$, $dn\_{\mathrm{s}}/d\ln k$, and $r\_{0.002}$ are derived from the numerically computed primordial spectra). All error bars are at the 95 %
CL. The effective $\chi^{2}$ value and Bayesian evidence logarithm $(\ln B)$ of model $n$ are given relative to the model
of next lowest order $(n-1)$ (assuming flat priors
for $\xi\_{V}^{2}$ and $\varpi\_{V}^{3}$ in the range $[-1,1]$).

### 7.2 Reconstruction of a smooth inflaton potential

Following the approach of [205](#bib.bib205), we Taylor expand the inflaton potential around $\phi=\phi\_{\*}$ to order $n=2,3,4$. To
obtain faster-converging Markov chains, instead of imposing flat priors on the Taylor coefficients $\{V,V\_{\phi},\ldots,V\_{\phi\phi\phi\phi}\}$,
we sample the potential slow-roll (PSR) parameters $\{\epsilon\_{V},\eta\_{V},\xi\_{V}^{2},\varpi\_{V}^{3}\}$ related to the former as indicated in
Table [2](#S3.T2 "Table 2 ‣ 3.2 Primordial spectra of cosmological fluctuations ‣ 3 Methodology ‣ Planck 2015 results. XX. Constraints on inflation"). We stress that this is just a choice of prior and does not imply
any kind of slow-roll
approximation in the calculation of the primordial spectra.

The results are given in Table [8](#S7.T8 "Table 8 ‣ 7.1 Introdution ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") (for Planck TT+lowP+BAO) and Fig. [13](#S7.F13 "Figure 13 ‣ 7.1 Introdution ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") (for the same data set
and also for Planck TT,TE,EE+lowP). The second part of Table [8](#S7.T8 "Table 8 ‣ 7.1 Introdution ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") shows the corresponding values of the spectral parameters $n\_{\mathrm{s}}$,
$dn\_{\mathrm{s}}/d\ln k$, and $r\_{0.002}$ as measured for each numerical primordial spectrum (at the pivot scales $k=0.05\thinspace\mathrm{Mpc}^{-1}$ for the scalar and $0.002\thinspace\mathrm{Mpc}^{-1}$ for the tensor spectra), as well as the reionization optical depth. We also show in Fig. [14](#S7.F14 "Figure 14 ‣ 7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") the derived
distribution of each coefficient $V\_{i}$ (with a non-flat prior) and in Fig. [15](#S7.F15 "Figure 15 ‣ 7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") the reconstructed shape of the best-fit inflation
potentials in the observable window.
Finally, the posterior distribution of the derived parameters $r\_{0.002}$ and $dn\_{\mathrm{s}}/d\ln k$ is displayed in
Fig. [16](#S7.F16 "Figure 16 ‣ 7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation").

Figure 14: Posterior distributions for the coefficients of the inflation potential Taylor expanded to $n$th order
(in natural units where $\sqrt{8\pi}M\_{\mathrm{pl}}=1$) reconstructed beyond the slow-roll approximation
using Planck TT+lowP+BAO (filled contours) or TT,TE,EE+lowP
(dashed contours). The plot shows only half of the results; the other half is symmetric, with opposite signs for $V\_{\phi}$ and
$V\_{\phi\phi\phi}$. Note that, unlike Fig. [13](#S7.F13 "Figure 13 ‣ 7.1 Introdution ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation"), the parameters shown here do not have flat priors, since they
are mapped from the slow-roll parameters.

Figure 15: Observable range of the best-fit inflaton potentials, when $V(\phi)$ is Taylor expanded to the $n$th order around the pivot value
$\phi\_{\*}$ in natural units (where $\sqrt{8\pi}M\_{\mathrm{pl}}=1)$
assuming a flat prior on $\epsilon\_{V}$, $\eta\_{V}$, $\xi^{2}\_{V}$, and $\varpi\_{V}^{3}$
and using Planck TT+lowP+BAO. Potentials obtained under the transformation $(\phi-\phi\_{\*})\rightarrow(\phi\_{\*}-\phi)$ leave the same
observable signature and are also allowed. The sparsity of potentials with a small $V\_{0}=V(\phi\_{\*})$ is due to our use of a flat prior on $\epsilon\_{V}$
rather than on $\ln(V\_{0})$; in fact, $V\_{0}$ is unbounded from below in the $n=2$ and $3$ results. The axis ranges are identical to those in Fig. [20](#S7.F20 "Figure 20 ‣ 7.3 Reconstruction of a smooth Hubble function ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation"), to make the comparison easier.

Figure 16: Posterior distribution for the tensor-to-scalar ratio (at $k=0.002\thinspace\mathrm{Mpc}^{-1}$) and for the running parameter $dn\_{\mathrm{s}}/d\ln k$ (at $k=0.05\thinspace\mathrm{Mpc}^{-1}$), for the potential reconstructions in Sects. [7.2](#S7.SS2 "7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") and [7.3](#S7.SS3 "7.3 Reconstruction of a smooth Hubble function ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation"). The $V(\phi)$ reconstruction gives the solid curves for Planck TT+lowP+BAO, or dashed for TT,TE,EE+lowP. The $H(\phi)$ reconstruction gives the dotted curves for Planck TT+lowP+BAO, or dashed-dotted for TT,TE,EE+lowP. The tensor-to-scalar ratio appears as a derived parameter, but by taking a flat prior on either $\epsilon\_{V}$ or $\epsilon\_{H}$, we implicitly also take a nearly flat prior on $r$. The same applies to $dn\_{\mathrm{s}}/d\ln k$.

Figure [13](#S7.F13 "Figure 13 ‣ 7.1 Introdution ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") shows that bounds are very similar when temperature data are combined with either high-$\ell$ polarization data or BAO data. This gives a hint of the robustness of these results. For both data sets, the error bars on the PSR parameters are typically
smaller by a factor of $1.5$ than in [205](#bib.bib205).

Since potentials with $n=2$ cannot generate a significant running, the bounds on the scalar spectral index and the tensor-to-scalar
ratio
and the best-fit
models are very similar to those obtained with the $\Lambda$CDM+$r$ model in Sect. [5](#S5 "5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation") and Table [4](#S5.T4 "Table 4 ‣ 5.1 Planck 2015 upper bound on 𝑟 ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation"). On the other hand, in
the $n=3$ model, results follow the trend of the previous $\Lambda$CDM+$r$+$dn\_{\mathrm{s}}/d\ln k$ analysis.
The data prefer potentials with
$V\_{\phi}$ and $V\_{\phi\phi\phi}$ of the same sign, generating a significant negative running (as can be seen in Fig. [16](#S7.F16 "Figure 16 ‣ 7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation")).
This trend for $V\_{\phi\phi\phi}$ occurs because a scalar spectrum with negative running reduces the power on large scales, and provides a
better fit to low-$\ell$ temperature multipoles.
However, such a running also suppresses power on small scales, so $\xi\_{V}^{2}$ cannot be too large.

Figure 17: Primordial spectra (scalar and tensor) of the best-fit $V(\phi)$ model with $n=4$, for the Planck TT,TE,EE+lowP data set, compared to
the primordial spectrum (scalar only) of the best-fit base $\Lambda$CDM model. The best-fit potential is initially very steep, as can be seen in
Fig. [15](#S7.F15 "Figure 15 ‣ 7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") (note the typical shape of the green curves). The transition from “marginal slow roll” ($\epsilon\_{V}(\phi)$ between 0.01 and 1) to “full
slow roll” ($\epsilon\_{V}(\phi)$ of order 0.01 or smaller) is responsible for the suppression of the large-scale scalar spectrum.

Figure 18: Temperature and polarization spectra (total, scalar contribution, tensor contribution) of the best-fit $V(\phi)$ model with $n=4$, for the Planck TT,TE,EE+lowP data set, compared to the spectra (scalar contribution only) of the best-fit base model. We also show the Planck low-$\ell$ temperature data, which is
driving the small differences between the two best-fit models.

The $n=4$ case possesses a new feature. The potential has more freedom to generate complicated shapes which would roughly correspond to a running of
the running of the tilt (as studied in Sect. [4](#S4 "4 Constraints on the primordial spectrum of curvature perturbations ‣ Planck 2015 results. XX. Constraints on inflation")). The best-fit models now have $V\_{\phi}$ and $V\_{\phi\phi\phi}$ of opposite
sign, and a large positive $V\_{\phi\phi\phi\phi}$. The preferred combination of these parameters allows for even more suppression of power on
large scales, while leaving small scales nearly unchanged. This can be seen clearly
from the shape of the scalar primordial spectrum
corresponding to the best-fit models, for both data sets Planck TT+lowP+BAO and Planck TT,TE,EE+lowP. These two best-fit models are very
similar, but in Fig. [17](#S7.F17 "Figure 17 ‣ 7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") we show the one for Planck TT,TE,EE+lowP, for which the trend is even more pronounced. Interestingly,
the preferred models are such that power on large scales is suppressed in the scalar spectrum and balanced by a small tensor contribution, of
roughly $r\_{0.002}\sim 0.05$. This particular combination gives the best fit to the low-$\ell$ data, shown in Fig. [18](#S7.F18 "Figure 18 ‣ 7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation"), while
leaving the high-$\ell$ temperature spectrum identical to the best fit base $\Lambda$CDM model. Inflation produces such primordial perturbations with the
family of green potentials displayed in Fig. [15](#S7.F15 "Figure 15 ‣ 7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation"). At the beginning of the observable range, the potential is very steep
[$\epsilon\_{V}(\phi)$
decreases from $O(1)$ to $O(10^{-2})$], and produces a low amplitude of curvature perturbations (allowing a rather large tensor contribution, up
to $r\_{0.002}\sim 0.3$). Then there is a transition towards a second region with a much smaller slope, leading to a nearly power-law
curvature spectrum with the usual tilt value $n\_{\mathrm{s}}\approx 0.96$. In Fig. [15](#S7.F15 "Figure 15 ‣ 7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation"), one can check that the height of the $n=4$ potentials
varies in a definite range, while the $n=2$ and $3$ potentials can have arbitrarily small amplitude at the pivot scale, reflecting the posteriors on
$\epsilon\_{V}$ or $r$.

However, the improvement in $\chi^{2}$ between the base $\Lambda$CDM and $n=4$ models is only 2.2 (for Planck TT+lowP+BAO) or 4.3 (for Planck TT,TE,EE+lowP). This is marginal and
offers no statistically significant evidence in favour of these complicated models. This
conclusion is also supported by the calculation of the Bayesian evidence ratios, shown in the last line of Table [8](#S7.T8 "Table 8 ‣ 7.1 Introdution ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") (under the
assumption of flat priors in the range [$-1$,1] for $\xi\_{V}^{2}$ and $\varpi\_{V}^{3}$): the evidence decreases each time that a new free parameter is
added to the potential. At the 95 % CL, $r\_{0.002}$ is still compatible with zero, and so are the higher order PSR parameters $\xi\_{V}^{2}$ and
$\varpi\_{V}^{3}$. More freedom in the inflaton potential allows fitting the data better, but under the
assumption of a smooth potential in the observable range, a simple quadratic form provides the best explanation of the Planck observations.

With the Planck TT+lowP+BAO and TT,TE,EE+lowP data sets, models with a large running or running of the running can be compatible with an unusually large value of the optical depth, as can be seen in Table [8](#S7.T8 "Table 8 ‣ 7.1 Introdution ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation"). Including lensing information helps to break the degeneracy between the optical depth and the primordial amplitude of scalar perturbations. Hence the Planck lensing data could be used to strengthen the conclusions of this section.

Since in the $n=4$ model, slow roll is marginally satisfied at the beginning of observable inflation, the reconstruction is very sensitive to the
condition that there is an attractor solution at that time. Hence this case can in principle be investigated in a more conservative way using the
$H(\phi)$ reconstruction method of the next section.

### 7.3 Reconstruction of a smooth Hubble function

In this section, we assume that the shape of the function $H(\phi)$ is well captured within the observable window by a polynomial of order $n$ (corresponding
to a polynomial inflaton potential of order $2n$):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $H(\phi)=\sum\_{i=0}^{n}H\_{i}\frac{\phi^{i}}{i!}\penalty\ .$ |  | (64) |

We vary $n$ between 2 and 4.
To avoid parameter degeneracies, as in the previous section we assume flat priors
not on the Taylor coefficient
$H\_{i}$, but
on the Hubble slow-roll (HSR) parameters, which are related according to

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\epsilon\_{H}$ | $\displaystyle=2M\_{\mathrm{pl}}^{2}\left(\frac{H\_{1}}{H\_{0}}\right)^{2}\penalty\ ,$ | $\displaystyle\eta\_{H}$ | $\displaystyle=2M\_{\mathrm{pl}}^{2}\frac{H\_{2}}{H\_{0}}\penalty\ ,$ |  | (65) |
|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\xi\_{H}^{2}$ | $\displaystyle=\left(2M\_{\mathrm{pl}}^{2}\right)^{2}\frac{H\_{1}H\_{3}}{H\_{0}^{2}}\penalty\ ,$ | $\displaystyle\varpi\_{H}^{3}$ | $\displaystyle=\left(2M\_{\mathrm{pl}}^{2}\right)^{3}\frac{H\_{1}^{2}H\_{4}}{H\_{0}^{3}}\penalty\ .$ |  | (66) |

This is just a choice of prior. This analysis does not rely on the slow-roll approximation.

|  |  |  |  |
| --- | --- | --- | --- |
|  |  |  |  |
|  |  |  |  |
| $n$ | 2 | 3 | 4 |
| $\epsilon\_{H}$ | $<0.0073$ | $<0.011$ | $<0.020$ |
| $\eta\_{H}$ | $-0.010\_{-0.009}^{+0.011}$ | $-0.012\_{-0.013}^{+0.015}$ | $-0.001\_{-0.027}^{+0.033}$ |
| $\xi\_{H}^{2}$ | $\ldots$ | $0.08\_{-0.12}^{+0.12}$ | $-0.01\_{-0.19}^{+0.19}$ |
| $\varpi\_{H}^{3}$ | $\ldots$ | $\ldots$ | $1.0\_{-1.8}^{+2.3}$ |
| $\tau$ | $0.082\_{-0.036}^{+0.038}$ | $0.096\_{-0.043}^{+0.042}$ | $0.096\_{-0.042}^{+0.042}$ |
| $n\_{\mathrm{s}}$ | $0.9693\_{-0.0093}^{+0.0094}$ | $0.9680\_{-0.0096}^{+0.0096}$ | $0.967\_{-0.010}^{+0.010}$ |
| $10^{3}dn\_{\mathrm{s}}/d\ln k$ | $-0.251\_{-0.41}^{+0.41}$ | $-13\_{-19}^{+18}$ | $-8\_{-21}^{+21}$ |
| $r\_{0.002}$ | $<0.11$ | $<0.16$ | $<0.32$ |
| $\Delta\chi^{2}$ | $\ldots$ | $\Delta\chi^{2}\_{3/2}=-0.6$ | $\Delta\chi^{2}\_{4/3}=-2.3$ |

Table 9: Numerical reconstruction of the Hubble slow-roll parameters beyond the slow-roll approximation, using Planck TT+lowP+BAO. We
also show the corresponding bounds on some related parameters (here $n\_{\mathrm{s}}$, $dn\_{\mathrm{s}}/d\ln k$, and $r\_{0.002}$ are derived from the
numerically computed primordial spectra). All error bars are at the 95 % CL. The effective $\chi^{2}$ value of model $n$ is given relative to model
$n-1$.

Figure 19: Posterior distributions for the first four Hubble slow-roll parameters, when $H(\phi)$ is Taylor expanded to $n$th order, using Planck TT+lowP+BAO (filled contours) or TT,TE,EE+lowP (dashed contours). The primordial spectra are computed beyond the slow-roll approximation.

Figure 20: Same as Fig. [15](#S7.F15 "Figure 15 ‣ 7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation"), when the Taylor expansion to $n$th order is performed on $H(\phi)$ instead of $V(\phi)$, and the
potential is inferred from Eq. ([62](#S7.E62 "In 7.1 Introdution ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation")).

Table [9](#S7.T9 "Table 9 ‣ 7.3 Reconstruction of a smooth Hubble function ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") and Fig. [19](#S7.F19 "Figure 19 ‣ 7.3 Reconstruction of a smooth Hubble function ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") show our results for the reconstructed HSR parameters. Figure [20](#S7.F20 "Figure 20 ‣ 7.3 Reconstruction of a smooth Hubble function ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") shows a
representative sample of potential shapes $V(\phi-\phi\_{\*})$ derived using Eq. ([62](#S7.E62 "In 7.1 Introdution ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation")), for a sample of models drawn randomly from
the chains, for the three cases $n=2,3,4$.

Most of the discussion of Sect. [7.2](#S7.SS2 "7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") also applies to this section, and so will not be repeated. Results for Planck TT+lowP+BAO and TT,TE,EE+lowP are still very similar. The $n=2$ case still gives results close to $\Lambda$CDM+$r$, and the $n=3$ case to
$\Lambda$CDM+$r$+$dn\_{\mathrm{s}}/d\ln k$.
The type of potential preferred in the $n=4$ case is very similar to the $n=4$ analysis of the previous
section, for the reasons explained in Sect. [7.2](#S7.SS2 "7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation"). There are, however, small differences, because the
range of parametric forms for the potential explored by the two analyses differ. In the $H(\phi)$ reconstruction, the underlying potentials $V(\phi)$
are not polynomials. In the first approximation, they are close to polynomials of order $2n$, but with constraints between the various coefficients.
The main two differences with respect to the results of Sect. [7.2](#S7.SS2 "7.2 Reconstruction of a smooth inflaton potential ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") are as follows:

* •

  The reconstructed potential shapes for $n=4$ at the beginning of the observable window differ.
  Figure [20](#S7.F20 "Figure 20 ‣ 7.3 Reconstruction of a smooth Hubble function ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") shows that even steeper potentials are allowed than for the
  $V(\phi)$ method, with
  an even greater excursion of the inflaton field between Hubble crossing for the largest observable wavelengths and the pivot scale. This
  is because the $H(\phi)$ reconstruction does not rely on attractor solutions and automatically
  explores all valid potentials regardless of their initial field velocity.
* •

  The best-fit models are different, since they do not explore the same
  parametric families of potentials. In particular, for $n=4$, the best-fit models have a negligible tensor contribution, but the distributions still have
  thick tails towards large tensor-to-scalar ratios, so that the upper bound on $r\_{0.002}$ is as high as in the previous $n=4$
  models, $r\_{0.002}<0.32$.

Note that $\varpi\_{H}^{3}$ can be significantly larger than unity for $n=4.$ This does not imply
violation of slow roll within the observable range. By assumption, for all accepted models, $\epsilon\_{H}$ must remain smaller than unity over that
range. In fact, for most of the green potentials visible in Fig. [20](#S7.F20 "Figure 20 ‣ 7.3 Reconstruction of a smooth Hubble function ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation"), we checked that $\epsilon\_{H}$ either has a maximum very
close to unity near the beginning of the observable range or starts from unity. So the best-fit models (maximizing the power
suppression at
low multipoles) correspond either to inflation of short duration, or to models nearly violating slow roll just
before the observable window.
However, such peculiar models are not necessary for a good fit. Table [9](#S7.T9 "Table 9 ‣ 7.3 Reconstruction of a smooth Hubble function ‣ 7 Reconstruction of the potential and analysis beyond slow-roll approximation ‣ Planck 2015 results. XX. Constraints on inflation") shows that the improvement
in $\chi^{2}$ as $n$ increases is negligible.

In summary, this section further establishes the robustness of our potential reconstruction and two main conclusions.
Firstly, under the assumption that the inflaton potential is smooth over the observable range, we showed that the simplest parametric forms
(involving only three free parameters including the amplitude $V(\phi\_{\*})$, no deviation from slow roll, and nearly power law primordial spectra)
are sufficient to explain the data. No high-order derivatives or deviations from slow roll are required. Secondly, if one allows
more freedom in the potential—typically, two more parameters—it is easy to decrease the large-scale primordial spectrum amplitude
with an initial stage of “marginal slow roll” along a steep branch of the potential followed by a transition to a less steep branch.
This type of model can accommodate a large tensor-to-scalar ratio, as high as $r\_{0.002}\approx 0.3.$

## 8 $\mathcal{P}(k)$ reconstruction

In [205](#bib.bib205) (section 7) we presented the results of a penalized likelihood
reconstruction, seeking to detect any possible deviations from a homogeneous power-law form (i.e., ${\mathcal{P}}\_{\mathcal{R}}(k)\propto k^{n\_{\mathrm{s}}-1}$) for the primordial power spectrum (PPS) for various values of a smoothing
parameter, $\lambda.$ (For an extensive set of
references to the prior literature concerning
the methodology for reconstructing the power spectrum,
see [205](#bib.bib205).) In the initial March 2013 preprint version of that paper, we reported evidence for
a feature at
moderate statistical significance around $k\approx 0.15$ Mpc-1. However, in the November 2013 revision
we retracted this finding, because subsequent tests indicated that the feature was no longer statistically
significant when more aggressive cuts were made to exclude sky survey rings where contamination from
electromagnetic interference from the 4 K cooler was largest, as indicated in the November 2013 “Note Added.”

In this section we report on results using the 2015 $C^{TT}\_{\ell}$ likelihood (Sect. [8.1](#S8.SS1 "8.1 Method I: penalized likelihood ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation")) using
essentially the same methodology as described in [205](#bib.bib205).
(See [Gauthier & Bucher (2012)](#bib.bib98) and references therein for more technical details.) This
method is also extended to include the $EE$ and $TE$ likelihoods
in Sect. [8.1.2](#S8.SS1.SSS2 "8.1.2 Penalized likelihood results with polarization ‣ 8.1 Method I: penalized likelihood ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation").
As part of this 2015 release, we include the results of two other methods
(see Sects. [8.2](#S8.SS2 "8.2 Method II: Bayesian model comparison ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") and [8.3](#S8.SS3 "8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation"))
to search for features. We
find that all three methods yield broadly consistent reconstructions and reach the following
main conclusion: there is no statistically significant evidence for any features departing from a
simple power-law (i.e., $\mathcal{P}\_{\mathcal{R}}(k)\propto k^{n\_{\mathrm{s}}-1}$) PPS. Given the
substantial differences between these methods, it is satisfying to observe this convergence.

### 8.1 Method I: penalized likelihood

#### 8.1.1 Update with 2015 temperature likelihood

We repeated the same maximum likelihood analysis used to reconstruct the PPS in
[205](#bib.bib205) using the updated Planck TT+lowP likelihood.
Since we are interested in deviations
from the nearly scale-invariant model currently favoured by the parametric approach, we replaced the true
PPS $\mathcal{P}\_{\mathcal{R}}(k)$ by a fiducial power-law spectrum $\mathcal{P}\_{\mathcal{R}}^{(0)}(k)=A\_{\mathrm{s}}(k/k\_{\ast})^{n\_{\mathrm{s}}-1}$, modulated by
a small deviation function $f(k)$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}\_{\mathcal{R}}(k)=\mathcal{P}\_{\mathcal{R}}^{(0)}(k)\exp\left[f(k)\right].$ |  | (67) |

The deviation function $f(k)$77
7
The definition of $f(k)$ used here differs from
that of [205](#bib.bib205)
in that $\exp(f)$ is used in place of $1+f$
to ensure that the reconstructed primordial power spectrum is always
non-negative. was represented by $B$-spline basis functions parameterized by $n\_{\mathrm{knot}}$ control points
$\mathbf{f}=\{f\_{i}\}\_{i=1}^{n\_{\mathrm{knot}}}$, which are the values of $f(k)$ along a grid of knot points
$\kappa\_{i}=\ln k\_{i}$.

Naively maximizing the Planck TT+lowP likelihood with respect to $\mathbf{f}$ results in over-fitting to cosmic
variance and noise in the data. Furthermore, due to the limited range of scales over which Planck measures
the anisotropy power spectrum, the likelihood is very weakly dependent on $f(k)$ at extremely small and large scales. To
address these issues, the following two penalty functions were added to the Planck likelihood:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\mathbf{f}^{\mathrm{T}}\mathbf{R}(\lambda,\alpha)\mathbf{f}\equiv\lambda\int\mathrm{d}\kappa\penalty\ \left(\frac{\partial^{2}f(\kappa)}{\partial\kappa^{2}}\right)^{2}$ |  | (68) |
|  |  | $\displaystyle+\alpha\int\_{-\infty}^{\kappa\_{\mathrm{min}}}\mathrm{d}\kappa\penalty\ f^{2}(\kappa)+\alpha\int^{+\infty}\_{\kappa\_{\mathrm{max}}}\mathrm{d}\kappa\penalty\ f^{2}(\kappa).$ |  |

The first term on the right-hand side of Eq. ([68](#S8.E68 "In 8.1.1 Update with 2015 temperature likelihood ‣ 8.1 Method I: penalized likelihood ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation")) is a roughness penalty, which disfavours
$f(\kappa)$ that “wiggle” too much. The last two terms drive $f(\kappa)$ to zero
for scales below $\kappa\_{\mathrm{min}}$ and above $\kappa\_{\mathrm{max}}$. The values of $\lambda$ and $\alpha$
represent the strengths of the respective penalties. The exact value of $\alpha$ is unimportant as
long as it is large enough to drive $f(\kappa)$ close to zero on scales outside $[\kappa\_{\mathrm{min}},\kappa\_{\mathrm{max}}]$.
However, the magnitude of the roughness penalty $\lambda$ controls the smoothness of the reconstruction.

Since the anisotropy spectrum depends linearly on the PPS, the Newton-Raphson method is well suited
to optimizing with respect to $\mathbf{f}$. However, a maximum likelihood analysis
also has to take into account the cosmological parameters, $\boldsymbol{\Theta}\equiv\{H\_{0},\Omega\_{\mathrm{b}}h^{2},\Omega\_{\mathrm{c}}h^{2}\}.$88
8
Due to the high
correlation between $\tau$ and $A\_{\mathrm{s}}$, $\tau$ is not included as a free
parameter. Any change in $\tau$ can be almost exactly compensated for by a change in $A\_{\mathrm{s}}$. We
fix $\tau$ to its best-fit fiducial model value. These additional parameters are not easy to
include in the Newton-Raphson method since it is difficult to evaluate the derivatives
${\partial C\_{\ell}}/{\partial\boldsymbol{\Theta}}$,
${\partial^{2}C\_{\ell}}/{\partial\boldsymbol{\Theta}^{2}}$,
etc., to the accuracy required by the method. Therefore a non-derivative method, such as
the downhill simplex algorithm, is best suited to optimization over these parameters.
Unfortunately the downhill simplex method is inefficient given the large number of control points in
our parameter space. Since each method has its drawbacks, we combined the two methods to draw on
their respective strengths. We define the function $\mathcal{M}$ as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{M}(\boldsymbol{\Theta})=\underset{f\_{i}\in[-1,1]}{\textrm{min}}\left\{-2\ln\mathcal{L}(\boldsymbol{\Theta},\mathbf{f})+\mathbf{f}^{T}\mathbf{R}(\lambda,\alpha)\mathbf{f}\right\}.$ |  | (69) |

Given a set of non-PPS cosmological parameters $\boldsymbol{\Theta}$, $\mathcal{M}$ is the value of the penalized log
likelihood, minimized with respect to $\mathbf{f}$ using the Newton-Raphson method. The function $\mathcal{M}$ is
in turn minimized with respect to $\boldsymbol{\Theta}$ using the downhill simplex method. In contrast to the
analysis done in [205](#bib.bib205), the Planck low-$\ell$ likelihood has been modified so that it
can be included in the Newton-Raphson minimization. Thus the reconstructions presented here extend to
larger scales than were considered in 2013.

Figure 21: 
Planck TT+lowP likelihood primordial power spectrum (PPS) reconstruction results. Top four panels:
Reconstruction of the deviation $f(k)$ using four different roughness penalties. The red curves
represent the best-fit deviation $f(k)$ using the Planck TT+lowP likelihood. $f(k)=0$ would represent a
perfectly featureless spectrum with respect to the fiducial PPS model, which is obtained from the
best-fit base $\Lambda$CDM model with a power-law PPS. The vertical extent of the dark and light green
error bars indicates the $\pm 1\thinspace\sigma$ and $\pm 2\thinspace\sigma$ errors, respectively. The width of the error bars represents the
minimum reconstructible width (the minimum width for a Gaussian feature so that the mean square
deviation of the reconstruction is less than 10 %). The grey regions
indicate where the minimum reconstructible width is undefined, indicating that the reconstruction in
these regions is untrustworthy. The hatched region in the $\lambda=10^{6}$ plot shows where the fixing
penalty has been applied. These hashed regions are not visible in the other three reconstructions,
for which $\kappa\_{\mathrm{min}}$ lies outside the range shown in the plots. For all
values of the roughness penalty, all data points are within 2 $\sigma$ of the fiducial PPS except for the
deviations around $k\approx 0.002$ Mpc-1 in the $\lambda=10^{3}$ and $\lambda=10^{4}$
reconstructions.
Lower three panels: $\pm 1\thinspace\sigma$ error bars of the
three non-PPS cosmological parameters included in the maximum likelihood reconstruction. All values
are consistent with their respective best-fit fiducial model values indicated by the dashed
lines.

Figure 22: 
Planck TT,TE,EE+lowP likelihood primordial power spectrum reconstruction results. Top
four panels: Reconstruction of the deviation $f(k)$ using four different roughness penalties. As in
Fig. [21](#S8.F21 "Figure 21 ‣ 8.1.1 Update with 2015 temperature likelihood ‣ 8.1 Method I: penalized likelihood ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation"), the red curves represent the best-fit deviation $f(k)$ and the height and
width of the green error bars represent the error and minimum reconstructible width, respectively. For all
values of the roughness penalty, the deviations are consistent with a featureless spectrum.
Lower three panels: $\pm 1\thinspace\sigma$ error bars of the three non-PPS cosmological
parameters included in the maximum likelihood reconstruction. All values are consistent with their
respective best-fit fiducial model values (indicated by the dashed lines).

Figure [21](#S8.F21 "Figure 21 ‣ 8.1.1 Update with 2015 temperature likelihood ‣ 8.1 Method I: penalized likelihood ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") shows the best-fit PPS reconstruction using
the Planck TT+lowP likelihood. The penalties in Eq. ([68](#S8.E68 "In 8.1.1 Update with 2015 temperature likelihood ‣ 8.1 Method I: penalized likelihood ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation")) introduce a
bias in the reconstruction by smoothing and otherwise
deforming potential features in the power spectrum. To assess this bias,
we define the “minimum reconstructible width” (MRW) to be the minimum width of a
Gaussian feature needed so that the integrated squared difference between the feature
and its reconstruction is less than 1 %
of the integrated square of the input Gaussian,
which is equivalent to 10 % rms. Due to the
combination of the roughness and fixing penalties, it is impossible to satisfy the MRW
criterion too close to $\kappa\_{\mathrm{min}}$ and $\kappa\_{\mathrm{max}}$. Wherever the MRW is
undefined, the reconstruction is substantially biased and therefore
suspect.
An MRW cannot be defined too close to the endpoints $\kappa\_{\mathrm{min}}$ and $\kappa\_{\mathrm{max}}$ for two reasons:
(1) lack of data; and (2) if a feature is too close to where the fixing penalty has been applied,
the fixing penalty distorts the reconstruction. Consequently a larger roughness penalty decreases
the range over which an MRW is well defined. The grey shaded areas in Fig. [21](#S8.F21 "Figure 21 ‣ 8.1.1 Update with 2015 temperature likelihood ‣ 8.1 Method I: penalized likelihood ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation")
show where the MRW is undefined and thus the reconstruction cannot be trusted.
The cutoffs $\kappa\_{\mathrm{min}}$ and $\kappa\_{\mathrm{max}}$ have been chosen to maximize the range
over which an MRW is defined for a given value of $\lambda.$
The 1 $\sigma$ and 2 $\sigma$ error bars in Fig. [21](#S8.F21 "Figure 21 ‣ 8.1.1 Update with 2015 temperature likelihood ‣ 8.1 Method I: penalized likelihood ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") are estimated using the Hessian of the
log-likelihood evaluated at the best-fit PPS reconstruction. More detailed MC investigations suggest that
the nonlinear corrections to these error bars are small.

For the $\lambda=10^{5}$ and $10^{6}$ cases of the $TT$ reconstruction,
no deviation exceeds $2\thinspace\sigma,$ so we do not comment on the probability of obtaining a
worse fit. For the other cases, we use the maximum of the deviation, expressed
in $\sigma$, of the plotted points as a metric of the quality of fit. Then using Monte Carlo
simulations we compute the $p$-value, or the probability to obtain a worse fit, according
to this metric. For $\lambda=10^{3}$ and $10^{4},$
we obtain $p$-values
of $0.304$ and $0.142,$ respectively, corresponding to $1.03$
and $1.47\thinspace\sigma$. We thus conclude that the observed deviations are not
statistically significant.

#### 8.1.2 Penalized likelihood results with polarization

In Fig. [22](#S8.F22 "Figure 22 ‣ 8.1.1 Update with 2015 temperature likelihood ‣ 8.1 Method I: penalized likelihood ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") the best-fit reconstruction of the PPS from the Planck TT,TE,EE+lowP likelihood is shown.
We observe that the reconstruction including polarization broadly agrees with the reconstruction
obtained using temperature only.
For the Planck TT,TE,EE+lowP likelihood, we
obtain for $\lambda=10^{3}$, $10^{4}$, and $10^{5}$ the $p$-values
$0.166,$ $0.107,$ and $0.045,$ respectively, corresponding to
$1.38,$ $1.61,$ and $2.00\thinspace\sigma,$
and likewise conclude the
absence of any statistically significant evidence for deviations
from a simple power-law scalar primordial power spectrum.

### 8.2 Method II: Bayesian model comparison

$\log\mathcal{P}\_{\mathcal{R}}(k)$$\log k$$(k\_{1},\mathcal{P}\_{1})$$(k\_{2},\mathcal{P}\_{2})$$(k\_{3},\mathcal{P}\_{3})$$(k\_{4},\mathcal{P}\_{4})$$(k\_{N\_{\mathrm{knots}}},\mathcal{P}\_{{N\_{\mathrm{knots}}}})$

Figure 23: Linear spline reconstruction. The primordial power spectrum is reconstructed using $N\_{\mathrm{knots}}$ interpolation points
${\{(k\_{i},\mathcal{P}\_{i}):i=1,2,\ldots{N\_{\mathrm{knots}}}\}}$. The end knots are fixed in $k$ but allowed to
vary in ${\mathcal{P}}$, whereas the internal knots can vary subject to the constraint that ${k\_{1}<k\_{2}<\cdots<k\_{N\_{\mathrm{knots}}}}$.
The function $\mathcal{P}\_{\mathcal{R}}(k)$ is constructed within the range $[k\_{1},k\_{N\_{\mathrm{knots}}}]$
by interpolating logarithmically between adjacent knots (i.e., linearly in $\log$-$\log$ space). Outside this range the function is extrapolated logarithmically.
The function $\mathcal{P}\_{\mathcal{R}}(k;\{k\_{i},\mathcal{P}\_{i}\})$ thus has $2N\_{\mathrm{knots}}-2$ parameters.

In this section we model the PPS $\mathcal{P}\_{\mathcal{R}}(k)$ using a nested
family of models where $\mathcal{P}\_{\mathcal{R}}(k)$ is piecewise linear
in the $\ln(\mathcal{P})$-$\ln(k)$ plane
between a number of knots, $N\_{\mathrm{knots}}$,
that is allowed to vary. The question arises as to how many knots one should use,
and we address this question using Bayesian model comparison.
A family of priors
is chosen where both the horizontal and vertical positions of the knots are allowed
to vary. We examine the “Bayes factor” or “Bayesian evidence” as a function of
$N\_{\mathrm{knots}}$ to decide how many knots are statistically justified.
A similar analysis has been performed by [Vázquez et al. (2012)](#bib.bib255) and [Aslanyan et al. (2014)](#bib.bib11).
In addition, we marginalize over all possible numbers of knots to obtain
an averaged reconstruction weighted according to the Bayesian evidence.

The generic prescription is illustrated in Fig. [23](#S8.F23 "Figure 23 ‣ 8.2 Method II: Bayesian model comparison ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation"). $N\_{\mathrm{knots}}$ knots
$\{(k\_{i},\mathcal{P}\_{i})\thinspace$: $i=1,\ldots,N\_{\mathrm{knots}}\}$ are placed in the $(k,\mathcal{P}\_{\mathcal{R}})$ plane and the function $\mathcal{P}\_{\mathcal{R}}(k)$ is
constructed by logarithmic interpolation (a linear interpolation in $\log$-$\log$ space) between adjacent points.
Outside the horizontal range $[k\_{1},k\_{N}]$ the function is extrapolated using the outermost interval.

Within this framework, base $\Lambda$CDM arises when ${N\_{\mathrm{knots}}=2}$—in other words, when there are two boundary knots
and no internal knots, and the parameters $\mathcal{P}\_{1}$ and $\mathcal{P}\_{2}$ (in place of $A\_{\mathrm{s}}$ and $n\_{\mathrm{s}}$) parameterize
the simple power-law PPS. There are also, of course,
the four standard cosmological parameters $(\Omega\_{\mathrm{b}}h^{2}$, $\Omega\_{\mathrm{c}}h^{2}$, $100\theta\_{\mathrm{MC}}$, and
$\tau$), as well as the numerous foreground parameters associated with the Planck high-$\ell$ likelihood, all of which are unrelated to the PPS.
This simplest model can be extended iteratively by successively inserting an additional internal knot, thus requiring with each iteration
two more variables to parameterize the new knot position.

|  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  | | --- | --- | | Parameter range | Prior type | | $10^{-4}\thinspace\mathrm{Mpc}^{-1}=k\_{1}<k\_{2}<\ldots<k\_{N\_{\mathrm{knots}}}=0.3\thinspace\mathrm{Mpc}^{-1}$ | log uniform (sorted) | | $2<\ln\left(10^{10}\mathcal{P}\_{1}\right),\ldots,\ln\left(10^{10}\mathcal{P}\_{{N\_{\mathrm{knots}}}}\right)<4$ | log uniform | | $2\leq N\_{\mathrm{knots}}\leq 10$ | integer uniform | |  |

Table 10: Prior for moveable knot positions.
The $\mathcal{P}\_{\mathcal{R}}$ positions are distributed in a log-uniform manner across a wide range.
The $k$ positions are also log-uniformly distributed
across the entire range needed by CosmoMC and are sorted so that ${k\_{1}<\ldots<k\_{N\_{\mathrm{knots}}}}$.
When we marginalize over the number of knots, $N\_{\mathrm{knots}}$, we assume a uniform prior between 2 and 10.

We run models for a variety of numbers of internal knots, $N\_{\mathrm{int}}=N\_{\mathrm{knots}}-2$, evaluating the evidence for $N\_{\mathrm{int}}$.
Under the assumption that the prior is justified, the most likely, or preferred, model is the one with the highest
evidence. Evidences are evaluated using the PolyChord sampler ([Handley et al., 2015](#bib.bib111))
in CAMB and CosmoMC. The use of PolyChord is
essential, as the posteriors in this parameterization are often multi-modal. Also, the ordered log-uniform priors on
the $k\_{i}$ are easy to implement within the PolyChord framework. All runs were performed with $1000$ live points,
oversampling the semi-slow and fast parameters by a factor of $5$ and $100$, respectively.

Figure 24: Bayesian movable knot reconstructions of the primordial power spectrum $\mathcal{P}\_{\mathcal{R}}(k)$ using Planck TT data.
The plots indicate our knowledge of the PPS $P(\mathcal{P}\_{\mathcal{R}}(k)|k,N\_{\mathrm{int}})$ for a given number of knots.
The number of internal knots $N\_{\mathrm{int}}$ increases (left to right and top to bottom) from $0$ to $8$.
For each $k$-slice, equal colours have equal probabilities. The colour scale is chosen so that darker regions
correspond to lower-$\sigma$ confidence intervals.
$1\thinspace\sigma$ and $2\thinspace\sigma$ confidence intervals are also indicated (black curves).
The upper horizontal axes give the approximate corresponding multipoles via $\ell\approx kD\_{\mathrm{rec}}$,
where $D\_{\mathrm{rec}}$ is the comoving distance to recombination.

Figure 25: 
Bayes factor (relative to the base $\Lambda$CDM model) as a function of the number of knots
for three separate runs. Solid line: Planck TT. Dashed line: Planck TT,TE,EE. Dotted line:
Planck TT, with priors on the $\mathcal{P}\_{i}$ parameters reduced in width by a factor of 2 ($2.5<\ln(10^{10}\mathcal{P}\_{i})<3.5$).

Figure 26: 
Bayesian reconstruction of the primordial power spectrum averaged over different values of $N\_{\mathrm{int}}$
(as shown in Fig. [24](#S8.F24 "Figure 24 ‣ 8.2 Method II: Bayesian model comparison ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation")), weighted according to the Bayesian evidence.
The region ${30<\ell<2300}$ is highly constrained, but the resolution is lacking to say anything precise
about higher $\ell$. At lower $\ell$, cosmic variance reduces our knowledge of $\mathcal{P}\_{\mathcal{R}}(k).$
The weights assigned to the lower $N\_{\mathrm{int}}$ models outweigh those of the higher models, so no oscillatory
features are visible here.

Priors for the reconstruction parameters are detailed in Table [10](#S8.T10 "Table 10 ‣ 8.2 Method II: Bayesian model comparison ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation").
We report evidence ratios with respect to the base $\Lambda$CDM case. The cosmological priors remain the
same for all models, and this part of the prior has almost no impact on the evidence ratios.
The choice of prior on the reconstruction parameters
$\{\mathcal{P}\_{i}\}$ does affect the Bayes factor. CosmoMC, however, puts an implicit prior on all models by excluding
parameter choices that render the internal computational approximations in CAMB invalid.
The baseline prior for the vertical position of the knots includes all
of the range allowed by CosmoMC, so slighly increasing this prior range will not affect the evidence ratios. If
one were to reduce the prior widths significantly, the evidence ratios would be increased.
The allowed horizontal range includes all $k$-scales accessible to Planck. Thus, altering this
width would be unphysical.

After completion of an evidence calculation, PolyChord generates a representative set of samples of the posterior for each model,
$P(\Theta)\equiv P(\Theta|\mathrm{data},N\_{\mathrm{int}})$. We may use this to calculate a marginalized probability distribution
for the PPS:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P(\log\mathcal{P}\_{\mathcal{R}}|k,N\_{\mathrm{int}})=\int\delta\left(\log\mathcal{P}\_{\mathcal{R}}-\log\mathcal{P}\_{\mathcal{R}}(k;\Theta)\right)P(\Theta)\>d\Theta.$ |  | (70) |

This expression encapsulates our knowledge of $\mathcal{P}\_{\mathcal{R}}$ at each value of $k$ for a given number of knots.
Plots of this PPS posterior are shown in Fig. [24](#S8.F24 "Figure 24 ‣ 8.2 Method II: Bayesian model comparison ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") using Planck TT data.

If one considers the Bayesian evidence of each model, Fig. [25](#S8.F25 "Figure 25 ‣ 8.2 Method II: Bayesian model comparison ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") shows that although no model is
preferred over base $\Lambda$CDM, the case $N\_{\mathrm{int}}=1$
is competitive. This model is analogous to the broken-power-law spectrum of
Sect. [4.4](#S4.SS4 "4.4 Suppression of power on the largest scales ‣ 4 Constraints on the primordial spectrum of curvature perturbations ‣ Planck 2015 results. XX. Constraints on inflation"),
although the models differ significantly in terms of the priors used. In this case, the
additional freedom of one knot allows a reconstruction of the suppression of power at low $\ell$. Adding polarization data does not alter
the evidences significantly, although $N\_{\mathrm{int}}=1$ is strengthened. We also plot a Planck TT run,
but with the reduced vertical priors ${2.5<\ln\left(10^{10}\mathcal{P}\_{i}\right)<3.5}$.
As expected, this increases the evidence ratios, but does not alter the above conclusion.

For increasing numbers of internal knots, the Bayesian evidence monotonically decreases. Occam’s razor dictates,
therefore, that these models should not be preferred, due to their higher complexity. However, there is an
intriguing stable oscillatory feature, at $20\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}\ell\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}50$, that appears once there are enough knots to reconstruct it.
This is a qualitative feature predicted by several inflationary models (discussed in Sect. [9](#S9 "9 Search for parameterized features ‣ Planck 2015 results. XX. Constraints on inflation")),
and a possible hint of new physics, although
its statistical significance is not compelling.

A full Bayesian analysis marginalizes over all models weighted according to the normalized evidence $Z\_{N\_{\mathrm{int}}},$
so that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P(\log\mathcal{P}\_{\mathcal{R}}|k)=\sum\limits\_{N\_{\mathrm{int}}}P(\log\mathcal{P}\_{\mathcal{R}}|k,N\_{\mathrm{int}})Z\_{N\_{\mathrm{int}}},$ |  | (71) |

as indicated in Fig. [26](#S8.F26 "Figure 26 ‣ 8.2 Method II: Bayesian model comparison ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation").
This reconstruction is sensitive to how model complexity is penalized in the prior distribution.

### 8.3 Method III: cubic spline reconstruction

In this section we investigate another reconstruction algorithm based on cubic splines
in the $\ln(k)$-$\ln\mathcal{P}\_{\mathcal{R}}$ plane, where (unlike for the approach of the previous subsection)
the horizontal positions of the knots are uniformly spaced in $\ln(k)$ and fixed.
A prior on the vertical positions (described in detail
below) is chosen and the reconstructed power spectrum is calculated using CosmoMC for various numbers of knots.
This method differs from the method in Sect. [8.1](#S8.SS1 "8.1 Method I: penalized likelihood ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation")
in that the smoothness is controlled by the number of discrete knots rather than by a continuous parameter of a
statistical model having a well-defined continuum limit.
With respect to the Bayesian model comparison of Sect. [8.2](#S8.SS2 "8.2 Method II: Bayesian model comparison ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation"),
the assessment of model complexity differs because here the knots are not movable.

Figure 27: Reconstructed power spectra applied to the Planck 2015 data using 12 knots
(with positions marked as $\Delta$ at the bottom of each panel) with cubic spline interpolation.
Mean spectra as well as sample trajectories are shown for scalars and tensors, and
$\pm 1\thinspace\sigma$ and $\pm 2\thinspace\sigma$ limits are shown for the scalars.
The fiducial tensor spectrum corresponds, arbitrarily, to $r=0.13$.
*Top:* uniform prior, $0\leq r\leq 1$. *Middle:* fixed, $r=0.1$. *Bottom:* fixed, $r=0.01$.
Data sets: Planck TT+lowP+BAO+SN+HST+$z\_{\mathrm{re}}$$>$6 prior.
$D\_{\mathrm{rec}}$ is the comoving distance to recombination.

Figure 28:  Reconstructed 12-knot power spectra with polarization included. Data sets in common:
lowT+lowP+BAO+SN+HST+$z\_{\mathrm{re}}$$>$6 prior.

Let the horizontal positions of the $n$ knots be given by $k\_{b}$, where $b=1,\ldots,n$, spaced
so that $k\_{b+1}/k\_{b}$ is independent of $b.$ We single out a “pivot knot” $b\!=\!p$, so that
$k\_{p}=k\_{\*}=0.05\thinspace\mathrm{Mpc}^{-1},$ which is the standard scalar power spectrum pivot scale.
For a given number of knots $n$ we choose $k\_{1}$ and $k\_{n}$ so that the interval of relevant cosmological scales, taken to
extend from $10^{-4}$ Mpc-1 to $O(1)$ Mpc${}^{-1},$ is included.
We now define the prior on the vertical knot coordinates. For the pivot point,
we define $\ln A\_{\mathrm{s}}=\ln\mathcal{P}\_{\mathcal{R}}(k\_{\*})$, where $\ln A\_{\mathrm{s}}$ has
a uniformly distributed prior, and for the other points with $b\neq p,$
we define the derived variable

|  |  |  |  |
| --- | --- | --- | --- |
|  | $q\_{b}\equiv\ln\left(\frac{\mathcal{P}\_{\mathcal{R}}(k\_{b})}{\mathcal{P}\_{\mathrm{{\mathcal{R}},fid}}(k\_{b})}\right),$ |  | (72) |

where
$\mathcal{P}\_{{\mathcal{R}},\mathrm{fid}}(k)\equiv A\_{\mathrm{s}}(k/k\_{\*})^{n\_{\mathrm{s},\mathrm{fid}}-1}.$ Here
the spectral index $n\_{\mathrm{s},\mathrm{fid}}$ is fixed. A uniform prior is imposed on each variable $q\_{b}$ $(b\neq p)$
and the constraint $-1\leq q\_{b}\leq 1$ is also imposed to force the reconstruction to behave reasonably
near the endpoints, where
it is hardly constrained by the data. The quantity $\ln\mathcal{P}\_{\mathcal{R}}(k)$ is interpolated between the knots using
cubic splines with natural boundary conditions (i.e., the second derivatives vanish at the first and the last knots).
Outside $[k\_{1},k\_{n}]$ we set
$\mathcal{P}\_{\mathcal{R}}(k)=e^{q\_{1}}\mathcal{P}\_{{\mathcal{R}},\mathrm{fid}}(k)$ (for $k<k\_{1}$) and
$\mathcal{P}\_{\mathcal{R}}(k)=e^{q\_{n}}\mathcal{P}\_{{\mathcal{R}},\mathrm{fid}}(k)$ (for $k>k\_{n}$).
For most knots, we found that the
upper and lower bounds of the $q\_{b}$ prior hardly affect the reconstruction,
since the data sharpen the allowed range significantly.
However, for super-Hubble scales (i.e., $k\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}10^{-4}$ Mpc-1) and very small scales
(i.e., $k\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$>$\hss}\lower 5.16663pt\hbox{$\sim$}}}0.2$ Mpc-1), which are only weakly constrained by the cosmological data, the prior dominates the
reconstruction.
For the results here, a fiducial spectral index $n\_{\mathrm{s},\mathrm{fid}}=0.967$ for
$\mathcal{P}\_{{\mathcal{R}},\mathrm{fid}}$ was chosen, which is close to the estimate from
Planck TT+lowP+BAO.
A different choice of $n\_{\mathrm{s},\mathrm{fid}}$ leads to a trivial linear shift in the
$q\_{b}.$

The possible presence of tensor modes (see Sect. [5](#S5 "5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation")) has the potential to bias and introduce
additional uncertainty in the reconstruction of the primordial scalar power spectrum as parameterized
above. Obviously, in the absence of a detection of tensors at high statistical significance, it is not
sensible to model a possible tensor contribution with more than a few degrees of freedom. A complicated
model would lead to prior dominated results. We therefore use the power law parameterization,
$\mathcal{P}\_{\mathrm{t}}(k)=rA\_{\mathrm{s}}(k/k\_{\*})^{n\_{\mathrm{t}}}$, where the consistency relation $n\_{\mathrm{t}}=-r/8$ is
enforced as a constraint.

Figure 29: Reconstructed $\mathcal{D}\_{\ell}^{TT}$ power spectra with the base $\Lambda$CDM best fit subtracted.
The mean spectra shown are for the floating $r$ and the two fixed $r$ cases with 12 cubic spline knots. These
should be contrasted with the running best-fit mean (green) and the similar looking uniform $n\_{\mathrm{s}}$ case
in which $\tau$ has been lowered from its best-fit base $\Lambda$CDM value to 0.04.
Data points are the Planck 2015 Commander ($\ell<30$) and Plik ($\ell\geq 30$)
temperature power spectrum.

Primordial tensor fluctuations contribute to CMB temperature and polarization angular power spectra, in particular
at spatial scales larger than the recombination Hubble length, $k\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}(aH)\_{\mathrm{rec}}\approx 0.005\thinspace\mathrm{Mpc}^{-1}.$
If a large number of knots in $\ln\mathcal{P}\_{\mathcal{R}}(k)$
is included over that range, then a modified $\mathcal{P}\_{\mathcal{R}}$ can mimic a tensor contribution, leading to a
near-degeneracy. This can lead to large uncertainty in the tensor amplitude, $r.$ Once $r$ is
measured or tightly constrained in $B$-mode experiments, this near degeneracy will be broken. As examples here, we do allow
$r$ to float, but also show what happens when $r$ is constrained to take the values $r=0.1$ and $r=0.01$
in the reconstruction.

Figure [27](#S8.F27 "Figure 27 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") shows the reconstruction obtained using the 2015 Planck TT+lowP
likelihood, BAO, SNIa, HST, and a $z\_{\mathrm{re}}>6$ prior.
Including these ancillary likelihoods improves the constraint on the PPS by
helping to fix the cosmological parameters (e.g., $H\_{0}$, $\tau$, and the late-time expansion history),
which in this context may be regarded as nuisance parameters.
These results were obtained by modifying
CosmoMC to
incorporate the $n$-knot parameterization of the PPS.
Here 12 knots were used and the mean reconstruction as well as the $1\thinspace\sigma$ and $2\thinspace\sigma$ limits are shown.
Some $1\thinspace\sigma$ sample trajectories (dashed curves) are also shown to illustrate the degree of correlation or smoothing of the reconstruction.
The tensor trajectories are also shown, but, as explained above, have been constrained to be straight lines.
In the top panel $r$ is allowed to freely float, and
a wide range of $r$ is allowed because of the near-degeneracy with the low-$k$ scalar power. Two illustrative
values of fixed $r$ (i.e., $r=0.1$ and $r=0.01$) are also shown to give an idea of how much the reconstruction
is sensitive to variations in $r$ within the range of presently plausible values.

The reconstructions using the 2013 Planck likelihood in place of the 2015 likelihood are broadly
consistent with the reconstruction shown in Fig. [27](#S8.F27 "Figure 27 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation"). To demonstrate robustness with respect
to the interpolation scheme we tried using linear interpolation instead of cubic splines and found that the reconstruction
was consistent provided enough knots (i.e., $n\_{\mathrm{knot}}\approx 14$) were used.
At intermediate $k$ the reconstruction is consistent with a simple power law, corresponding to a straight line in Fig. [27](#S8.F27 "Figure 27 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation").
We observe that once $k$ drops, so that the effective multipole being probed is below about $60$, deviations from a power law appear, but the dispersion in
allowed trajectories also rises as a consequence of cosmic variance. The power deficit at
$k\approx 0.002\thinspace\mathrm{Mpc}^{-1}$ (i.e., $\ell\_{k}\equiv kD\_{\mathrm{rec}}\approx 30$,
where $D\_{\mathrm{rec}}$ is the comoving distance to recombination) is largely driven by the power spectrum
anomaly in the $\ell\approx 20$–$30$ range that has been evident since the early spectra from WMAP ([Bennett et al., 2011](#bib.bib27)), and verified by Planck.

We also explore the impact of including the Planck polarization likelihood in the reconstruction.
Figure [28](#S8.F28 "Figure 28 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") shows the reconstructed power spectra using various combinations of the polarization
and temperature data. The $\ell<30$ treatments are the same in all cases, so this is mainly a test
of the higher $k$ region. What is seen is that, except at high $k$, the $EE$ polarization data also enforce a nearly
uniform $n\_{\mathrm{s}}$, consistent with that from $TT$, over a broad $k$-range. When $TE$ is used alone, or $TE$ and $EE$ are used in
combination, the result is also very similar. The upper right panel shows the constraints from all three spectra together, and the errors on the
reconstruction are now better than those from $TT$ alone.

It is interesting to examine how the $TT$ power spectrum obtained
using the above reconstructions compares to the CMB data, in particular around
the range $\ell\approx 20$–$30$, corresponding roughly to
$k\_{4}\approx 1.5\times 10^{-3}\thinspace\textrm{Mpc}^{-1}.$ In Fig. [29](#S8.F29 "Figure 29 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation")
the differences in ${\mathcal{D}}\_{\ell}^{TT}$ from the best-fit simple power-law model
are plotted for various assumptions concerning $r$. We see that a better
fit than the power-law model can apparently be obtained around $\ell\approx 20$–$30$.
We quantify this improvement below.

Figure 30: The degeneracy between $\tau$ and the knot variables $q\_{3}$ and $q\_{4}$ in the 12-knot case shown in Fig. [27](#S8.F27 "Figure 27 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation").

Due to the degeneracy of scalar and tensor contributions to ${\mathcal{D}}\_{\ell}^{TT}$, the
significance of the low-$\ell$ anomaly depends on the tensor prior and whether polarization data are used.
For $k<10^{-3}\thinspace\textrm{Mpc}^{-1}$, once more degeneracy appears: the shape of ${\mathcal{D}}^{TT}\_{\ell}$ also depends
on the reionization optical depth, $\tau$. In Fig. [29](#S8.F29 "Figure 29 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") we also show
the effect of replacing the best-fit $\tau$ for tilted base $\Lambda$CDM with a low value,
while keeping $A\_{\mathrm{s}}e^{-2\tau}$ unchanged. A low $\tau$ bends
${\mathcal{D}}\_{\ell}^{TT}$ downward at $\ell\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}10$. For the 12-knot (or similar) runs, if $\tau$ is allowed to run into the
(nonphysically) small values $\tau\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}0.04,$
a slight rise in $\mathcal{P}\_{\mathcal{R}}(k)$ at $k\approx 3\times 10^{-4}\thinspace\textrm{Mpc}^{-1}$ is
preferred to compensate the low-$\tau$ effect.
This degeneracy can be broken to a certain extent using low-redshift data: $z\_{\mathrm{re}}>6$ from quasar observations
([Becker et al., 2001](#bib.bib25)), BAO (SDSS), Supernova (JLA), and HST.

It is evident that allowing $n\_{\mathrm{s}}$ to run is not what the ${\mathcal{D}}\_{\ell}^{TT}$ data prefer. The best-fit running is also shown
in Fig. [29](#S8.F29 "Figure 29 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation").
The $k$-space $\mathcal{P}\_{\mathcal{R}}(k)$-response in Fig. [27](#S8.F27 "Figure 27 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") shows that running does not capture the
shape of the low-$\ell$ residuals.

Figure 31: Slow-roll parameter $\epsilon$ for reconstructed trajectories using 12 knots (marked as $\Delta$ at the bottom of the figure)
with cubic spline interpolation. The mean values are shown for floating $r$ and $r$ fixed to be 0.1 and 0.01.
Sample $1\thinspace\sigma$ trajectories shown for the floating $r$ case show wide variability, which is significantly
diminished if $r$ is fixed to $r=0.1$, as shown.

Figure 32:  Reconstructed single-field inflaton potentials from the cubic spline power spectra mode expansion using
12 knots.

Table 11: Reduced $\chi^{2}$ and $p$-values for low-$k$ knots (5 knots) and high-$k$ knots (6 knots, pivot knot excluded), with
the null hypothesis being the best-fit power law spectrum.
Low-$z$ data refers to BAO+SN+HST+$z\_{\mathrm{re}}$$>$6 prior. In all cases lowP data are used.

|  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |
| $r$ prior | low-$z$ data | Planck data | low-$k$ $\chi^{2}\_{\mathrm{reduced}}$ | low-$k$ $p$-value | high-$k$ $\chi^{2}\_{\mathrm{reduced}}$ | high-$k$ $p$-value | $q\_{3}$ constraint | $q\_{4}$ constraint |
| $0\leq r\leq 1$ | used | TT | 0.95 | 0.45 | 0.17 | 0.98 | $-0.07\pm 0.28$ | $-0.39\pm 0.20$ |
| $r=0.01$ | used | TT | 1.13 | 0.34 | 0.09 | 0.997 | $\phantom{-}0.01\pm 0.24$ | $-0.23\pm 0.12$ |
| $r=0.01$ | not used | TT | 0.89 | 0.49 | 0.36 | 0.90 | $\phantom{-}0.10\pm 0.24$ | $-0.23\pm 0.12$ |
| $r=0.1$ | used | TT | 1.70 | 0.13 | 0.12 | 0.994 | $-0.04\pm 0.26$ | $-0.28\pm 0.13$ |
| $r=0.1$ | not used | TT | 1.46 | 0.20 | 0.38 | 0.89 | $\phantom{-}0.05\pm 0.27$ | $-0.28\pm 0.13$ |
| $r=0.1$ | used | TT,TE,EE | 1.71 | 0.13 | 0.17 | 0.985 | $-0.02\pm 0.25$ | $-0.30\pm 0.12$ |
| $r=0.1$ | used | TE,EE | 1.72 | 0.13 | 0.38 | 0.89 | $\phantom{-}0.06\pm 0.25$ | $-0.32\pm 0.15$ |
| $r=0.1$ | used | TE | 1.80 | 0.11 | 0.26 | 0.95 | $-0.02\pm 0.27$ | $-0.17\pm 0.16$ |
| $r=0.1$ | used | EE | 1.78 | 0.11 | 0.18 | 0.98 | $\phantom{-}0.09\pm 0.25$ | $-0.39\pm 0.16$ |
| $r=0.1$ | used | TT+lensing | 1.54 | 0.17 | 0.05 | 0.9995 | $\phantom{-}0.05\pm 0.25$ | $-0.27\pm 0.13$ |

We have shown that the cubic spline reconstruction studied in this section consistently
produces a dip in $q\_{4},$ corresponding to $k\approx 1.5\times 10^{-3}\thinspace\textrm{Mpc}^{-1}.$
We now turn to the question of whether this result is real or simply the result of cosmic variance.
To assess the statistical significance of the departures of the mean reconstruction
from a simple power law, we calculate the low-$k$ and high-$k$ reduced $\chi^{2}$
for the five $q\_{b}$ values for scales below and six $q\_{b}$ values ($b\neq p$) for scales above $50/D\_{\mathrm{rec}}$, respectively, indicating
the corresponding $p$-values (i.e., probability to exceed), for various data combinations,
in Table [11](#S8.T11 "Table 11 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation").
The high-$k$ fit is better than expected for reasons that we
do not understand, but we attribute this situation to chance.
The low-$k$ region shows
a poor fit, but in no case does the $p$-value fall below 10 %. Therefore, even though
the low-$k$ dip is robust against the various choices made for the reconstruction, we
conclude that it is not statistically significant. The plot for the knot position of
the dip (corresponding to $q\_{4}$) in Fig. [30](#S8.F30 "Figure 30 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") does not contradict this conclusion.

Because of the $r$ degeneracy associated with the scalar power, it is best when quoting statistics to use the fixed
$r$ cases, although for completeness we show the floating $r$ case as well. There is also a smaller effect
associated with the $\tau$ degeneracy, and the values quoted have restricted the redshift of
reionization to exceed 6. The value $z\_{\mathrm{re}}=6.5$ was used in [Planck Collaboration
XIII (2016)](#bib.bib218). The significance of the
low-$k$ anomaly is meaningful only if an explicit $r$ prior and low-redshift constraint on $\tau$
have been applied.

Finally, we relate the reconstructed ${\mathcal{P}}\_{\mathcal{R}}(k)$ calculated above to the
trajectories of the slow-roll parameter $\epsilon=-\dot{H}/H^{2}|\_{k=aH}$
plotted as a function of $k$ (see Fig. [31](#S8.F31 "Figure 31 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation")).
We also plot in Fig. [32](#S8.F32 "Figure 32 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") the reconstructed inflationary potential in the region
over which the inflationary potential is constrained by the data.
Here canonical single-field inflation is assumed, and the value of $r$ enters
solely to fix the height of the potential at the pivot scale. This is not
entirely self-consistent, but justified by the lack of constraining power on
the tensors at present.

### 8.4 Power spectrum reconstruction summary

The three non-parametric methods for reconstructing the primordial
power spectrum explored here support the following two conclusions:

1. 1.

   Except possibly at low $k,$ over the range of $k$
   where the CMB data best constrain the form
   of the primordial power spectrum, none of
   the three methods finds any
   statistically significant evidence for
   deviations from a simple power-law form.
   The fluctuations seen in this regime are entirely
   consistent with the expectations from cosmic variance and noise.
2. 2.

   At low $k$, all three methods reconstruct
   a power deficit at $k\approx 1.5$–$2.0\times 10^{-3}\thinspace\textrm{Mpc}^{-1},$
   which can be linked to the dip in the ${TT}$
   angular power spectrum
   at $\ell\approx 20$–$30.$ This agreement
   suggests that the reconstruction of this
   “anomaly” is not an artefact of any of the methods,
   but rather inherent in the CMB data themselves.
   However, the evidence for this feature is marginal since it is in
   a region of the spectrum where the fluctuations from cosmic variance are large.
3. 3.

   We have verified that the power deficit at $\ell=20$–30 is not
   substantially modified (a) by removing from the CMB pattern the hottest and
   coldest peaks selected by the Kolmogorov-Smirnov test studied in
   Sects. 4.5.3 and 4.5.4 of [Planck Collaboration
   XVI (2016)](#bib.bib220) or (b) by substituting the anomalously
   cold region around the Cold Spot with Gaussian constrained realizations.

## 9 Search for parameterized features

In this section, we explore the possibility of a radical departure from the near-scale-invariant power-law spectrum
$\mathcal{P}\_{\mathcal{R}}^{0}(k)=A\_{\mathrm{s}}(k/k\_{\*})^{n\_{\mathrm{s}}-1}$ of the standard slow-roll
scenario for a selection of theoretically motivated parameterizations of the spectrum
(see [Chluba et al. (2015)](#bib.bib54) for a recent review).

### 9.1 Models

#### 9.1.1 Step in the inflaton potential

A sudden, step-like feature in the inflaton potential ([Adams et al., 2001](#bib.bib4)) or the sound speed ([Achúcarro et al., 2011](#bib.bib1))
leads to a localized oscillatory burst in the scalar primordial power spectrum.
A general parameterization describing both a $\tanh$-step in the potential and in the warp term of a DBI model
was proposed in [Miranda & Hu (2014)](#bib.bib174):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\ln\mathcal{P}\_{\mathcal{R}}^{\mathrm{s}}(k)=\exp\left[\ln\mathcal{P}\_{\mathcal{R}}^{0}(k)+\mathcal{I}\_{0}(k)+\ln\left(1+\mathcal{I}\_{1}^{2}(k)\right)\right],$ |  | (73) |

where the first- and second-order terms are given by

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{I}\_{0}$ | $\displaystyle=\left[\mathcal{A}\_{\mathrm{s}}\thinspace\mathcal{W}\_{1}^{(0)}(k/k\_{\mathrm{s}})+\mathcal{A}\_{2}\thinspace\mathcal{W}\_{2}^{(0)}(k/k\_{\mathrm{s}})\right.$ |  | (74) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\left.+\;\mathcal{A}\_{3}\thinspace\mathcal{W}\_{3}^{(0)}(k/k\_{\mathrm{s}})\right]\thinspace\mathcal{D}\left(\frac{k/k\_{\mathrm{s}}}{x\_{\mathrm{s}}}\right),$ |  | (75) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{I}\_{1}$ | $\displaystyle=\frac{1}{\sqrt{2}}\left\{\frac{\pi}{2}(1-n\_{\mathrm{s}})+\left[\mathcal{A}\_{\mathrm{s}}\thinspace\mathcal{W}\_{1}^{(1)}(k/k\_{\mathrm{s}})\right.\vphantom{\mathcal{D}\left(\frac{k/k\_{\mathrm{s}}}{x\_{\mathrm{s}}}\right)}\right.$ |  | (76) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\left.\left.+\;\mathcal{A}\_{2}\thinspace\mathcal{W}\_{2}^{(1)}(k/k\_{\mathrm{s}})+\mathcal{A}\_{3}\thinspace\mathcal{W}\_{3}^{(1)}(k/k\_{\mathrm{s}})\right]\thinspace\mathcal{D}\left(\frac{k/k\_{\mathrm{s}}}{x\_{\mathrm{s}}}\right)\right\},$ |  | (77) |

with window functions

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{W}\_{1}^{(0)}(x)$ | $\displaystyle=\frac{1}{2x^{3}}\left[\left(18x-6x^{3}\right)\cos 2x+\left(15x^{2}-9\right)\sin 2x\right],$ |  | (78) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{W}\_{2}^{(0)}(x)$ | $\displaystyle=\frac{3}{2x^{3}}\left[\sin(2x)-2x\cos(2x)-x^{2}\sin(2x)\right],$ |  | (79) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{W}\_{3}^{(0)}(x)$ | $\displaystyle=\frac{1}{x^{3}}\left[6x\cos(2x)+(4x^{2}-3)\sin(2x)\right],$ |  | (80) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{W}\_{1}^{(1)}(x)$ | $\displaystyle=-\frac{1}{x^{3}}\left\{3(x\cos x-\sin x)\left[3x\cos x+\left(2x^{2}-3\right)\sin x\right]\right\},$ |  | (81) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{W}\_{2}^{(1)}(x)$ | $\displaystyle=\frac{3}{x^{3}}\left(\sin x-x\cos x\right)^{2},$ |  | (82) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{W}\_{3}^{(1)}(x)$ | $\displaystyle=-\frac{1}{x^{3}}\left[3+2x^{2}-\left(3-4x^{2}\right)\cos(2x)-6x\sin(2x)\right],$ |  | (83) |

and damping function

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{D}(x)=\frac{x}{\sinh x}.$ |  | (84) |

Due to the high complexity of this model, we focus on the limiting case of a step in the potential
($\mathcal{A}\_{2}=\mathcal{A}\_{3}=0$).

#### 9.1.2 Logarithmic oscillations

Logarithmic modulations of the primordial power spectrum generically appear, for example, in models with non-Bunch-Davies
initial conditions ([Martin & Brandenberger, 2001](#bib.bib163); [Danielsson, 2002](#bib.bib60); [Bozza et al., 2003](#bib.bib39)), or, approximately, in the axion monodromy model,
explored in more detail in Sect. [10](#S10 "10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation"). We assume a constant modulation amplitude and use

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}\_{\mathcal{R}}^{\mathrm{log}}(k)=\mathcal{P}\_{\mathcal{R}}^{0}(k)\left\{1+\mathcal{A}\_{\mathrm{log}}\cos\left[\omega\_{\mathrm{log}}\ln\left(\frac{k}{k\_{\*}}\right)+\varphi\_{\mathrm{log}}\right]\right\}.$ |  | (85) |

#### 9.1.3 Linear oscillations

A modulation linear in $k$ can be obtained, for example, in boundary effective field theory models ([Jackson & Shiu, 2013](#bib.bib117)),
and is typically accompanied by a scale-dependent modulation amplitude. We adopt the parameterization used in
[Meerburg & Spergel (2014)](#bib.bib171), which allows for a strong scale dependence of the modulation amplitude:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}\_{\mathcal{R}}^{\mathrm{lin}}(k)=\mathcal{P}\_{\mathcal{R}}^{0}(k)\left[1+\mathcal{A}\_{\mathrm{lin}}\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{lin}}}\cos\left(\omega\_{\mathrm{lin}}\frac{k}{k\_{\*}}+\varphi\_{\mathrm{lin}}\right)\right].$ |  | (86) |

#### 9.1.4 Cutoff model

If today’s largest observable scales exited the Hubble radius before the inflaton field reached the slow-roll attractor, the amplitude
of the primordial power spectrum is typically strongly suppressed at low $k$.
As an example of such a model, we consider a scenario in which
slow roll is preceded by a stage of kinetic energy domination. The resulting power spectrum was derived by [Contaldi et al. (2003)](#bib.bib57) and can
be expressed as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\ln\mathcal{P}\_{\mathcal{R}}^{\mathrm{c}}(k)=\ln\mathcal{P}\_{\mathcal{R}}^{0}(k)+\ln\left(\frac{\pi}{16}\thinspace\frac{k}{k\_{\mathrm{c}}}\left|C\_{\mathrm{c}}-D\_{\mathrm{c}}\right|^{2}\right),$ |  | (87) |

with

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle C\_{\mathrm{c}}$ | $\displaystyle=\exp\left(\frac{-ik}{k\_{\mathrm{c}}}\right)\left[H\_{0}^{(2)}\left(\frac{k}{2k\_{\mathrm{c}}}\right)-\left(\frac{k\_{\mathrm{c}}}{k}+i\right)H\_{1}^{(2)}\left(\frac{k}{2k\_{\mathrm{c}}}\right)\right],$ |  | (88) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle D\_{\mathrm{c}}$ | $\displaystyle=\exp\left(\frac{ik}{k\_{\mathrm{c}}}\right)\left[H\_{0}^{(2)}\left(\frac{k}{2k\_{\mathrm{c}}}\right)-\left(\frac{k\_{\mathrm{c}}}{k}-i\right)H\_{1}^{(2)}\left(\frac{k}{2k\_{\mathrm{c}}}\right)\right],$ |  | (89) |

where $H\_{n}^{(2)}$ denotes the Hankel function of the second kind. The power spectrum in this model is
exponentially suppressed for wavenumbers smaller than the cutoff scale $k\_{\mathrm{c}}$ and converges to a standard power-law spectrum for
$k\gg k\_{\mathrm{c}}$, with an oscillatory transition region for $k\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$>$\hss}\lower 5.16663pt\hbox{$\sim$}}}k\_{\mathrm{c}}$.

|  |  |  |
| --- | --- | --- |
|  |  |  |
|  |  |  |
| Model | Parameter | Prior range |
| Step | $\mathcal{A}\_{\mathrm{s}}$ | $[0,2]$ |
| $\log\_{10}\left(k\_{\mathrm{s}}/\mathrm{Mpc}^{-1}\right)$ | $[-5,0]$ |
| $\ln x\_{\mathrm{s}}$ | $[-1,5]$ |
| Log osc. | $\mathcal{A}\_{\mathrm{log}}$ | $[0,0.5]$ |
| $\log\_{10}\omega\_{\mathrm{log}}$ | $[0,2.1]$ |
| $\varphi\_{\mathrm{log}}$ | $[0,2\pi]$ |
| Linear osc. | $\mathcal{A}\_{\mathrm{lin}}$ | $[0,0.5]$ |
| $\log\_{10}\omega\_{\mathrm{lin}}$ | $[0,2]$ |
| $n\_{\mathrm{lin}}$ | $[-1,1]$ |
| $\varphi\_{\mathrm{lin}}$ | $[0,2\pi]$ |
| Cutoff | $\log\_{10}\left(k\_{\mathrm{c}}/\mathrm{Mpc}^{-1}\right)$ | $[-5,-2]$ |

Table 12:  Parameters and prior ranges.

### 9.2 Analysis and results

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
| Model | Planck TT+lowP | | Planck TT,TE,EE+lowP | | PTE |
| $\Delta\chi^{2}$ | $\ln B$ | $\Delta\chi^{2}$ | $\ln B$ |
| Step | 0$-8.6$ | $-0.3$ | 0$-7.3$ | $-0.6$ | 0.09 |
| Log osc. | $-10.6$ | $-1.9$ | $-10.1$ | $-1.5$ | 0.24 |
| Linear osc. | 0$-8.9$ | $-1.9$ | $-10.9$ | $-1.3$ | 0.50 |
| Cutoff | 0$-2.0$ | $-0.4$ | 0$-2.2$ | $-0.6$ | 0.12 |

Table 13:  Improvement in fit and Bayes factors with respect to power-law base $\Lambda$CDM for
Planck TT+lowP and Planck TT,TE,EE+lowP data, as well as approximate probability to exceed the observed
$\Delta\chi^{2}$ ($p$-value), constructed from simulated Planck TT+lowP data.
Negative Bayes factors indicate a preference for the power-law model.

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
| Parameter | Step | Log osc. | Linear osc. | Cutoff | Power law |
|  |  |  |  |  |  |
| $100\thinspace\omega\_{\mathrm{b}}$ | $2.23\pm 0.02$ | $2.22\pm 0.02$ | $2.23\pm 0.02$ | $2.23\pm 0.02$ | $2.23\pm 0.02$ |
| $10\thinspace\omega\_{\mathrm{c}}$ | $1.20\pm 0.02$ | $1.20\pm 0.02$ | $1.20\pm 0.02$ | $1.19\pm 0.02$ | $1.19\pm 0.02$ |
| $100\thinspace\theta\_{\mathrm{MC}}$ | $1.0409\pm 0.0004$ | $1.0409\pm 0.0004$ | $1.0409\pm 0.0004$ | $1.0410\pm 0.0005$ | $1.0409\pm 0.0005$ |
| $\tau$ | $0.083\pm 0.015$ | $0.082\pm 0.015$ | $0.084\pm 0.014$ | $0.086\pm 0.017$ | $0.085\pm 0.016$ |
| $\ln\left(10^{10}A\_{\mathrm{s}}\right)$ | $3.10\pm 0.03$ | $3.10\pm 0.03$ | $3.10\pm 0.03$ | $3.11\pm 0.03$ | $3.10\pm 0.03$ |
| $n\_{\mathrm{s}}$ | $0.966\pm 0.005$ | $0.970\pm 0.007$ | $0.967\pm 0.004$ | $0.968\pm 0.005$ | $0.968\pm 0.005$ |
|  |  |  |  |  |  |
| $\mathcal{A}\_{\mathrm{s}}$ | 0.374 | $\ldots$ | $\ldots$ | $\ldots$ | $\ldots$ |
| $\log\_{10}\left(k\_{\mathrm{s}}/\mathrm{Mpc}^{-1}\right)$ | $-3.10$ | $\ldots$ | $\ldots$ | $\ldots$ | $\ldots$ |
| $\ln x\_{\mathrm{s}}$ | 0.342 | $\ldots$ | $\ldots$ | $\ldots$ | $\ldots$ |
|  |  |  |  |  |  |
| $\mathcal{A}\_{\mathrm{log}}$ | $\ldots$ | 0.0278 | $\ldots$ | $\ldots$ | $\ldots$ |
| $\log\_{10}\omega\_{\mathrm{log}}$ | $\ldots$ | 1.51 | $\ldots$ | $\ldots$ | $\ldots$ |
| $\varphi\_{\mathrm{log}}/2\pi$ | $\ldots$ | 0.634 | $\ldots$ | $\ldots$ | $\ldots$ |
|  |  |  |  |  |  |
| $\mathcal{A}\_{\mathrm{lin}}$ | $\ldots$ | $\ldots$ | 0.0292 | $\ldots$ | $\ldots$ |
| $\log\_{10}\omega\_{\mathrm{lin}}$ | $\ldots$ | $\ldots$ | 1.73 | $\ldots$ | $\ldots$ |
| $n\_{\mathrm{lin}}$ | $\ldots$ | $\ldots$ | 0.662 | $\ldots$ | $\ldots$ |
| $\varphi\_{\mathrm{lin}}/2\pi$ | $\ldots$ | $\ldots$ | 0.554 | $\ldots$ | $\ldots$ |
|  |  |  |  |  |  |
| $\log\_{10}\left(k\_{\mathrm{c}}/\mathrm{Mpc}^{-1}\right)$ | $\ldots$ | $\ldots$ | $\ldots$ | $-3.44$ | $\ldots$ |

Table 14: 
Best-fit features parameters
and parameter constraints on the remaining cosmological parameters for the four features models for Planck TT+lowP data.
Note that the foreground parameters have been fixed to their power-law base $\Lambda$CDM best-fit values.

Figure 33: Best-fit power spectra for the power-law (black curve), step (green), logarithmic oscillation (blue),
linear oscillation (orange), and cutoff (red) models using Planck TT+lowP data.
The brown curve is the best fit for a model with a step in the warp and potential (Eqs. [73](#S9.E73 "In 9.1.1 Step in the inflaton potential ‣ 9.1 Models ‣ 9 Search for parameterized features ‣ Planck 2015 results. XX. Constraints on inflation")–[84](#S9.E84 "In 9.1.1 Step in the inflaton potential ‣ 9.1 Models ‣ 9 Search for parameterized features ‣ Planck 2015 results. XX. Constraints on inflation")).

Figure 34: Distribution of $\Delta\chi^{2}$ from 400 simulated Planck TT+lowP data sets.

We use MultiNest to evaluate the Bayesian
evidence for the models, establish parameter constraints, and roughly identify the global maximum likelihood
region of parameter space. The features model best-fit parameters and $\ln\mathcal{L}$ are then obtained
with the help of the CosmoMC minimization algorithm
taking narrow priors around the MultiNest best fit.
We assign flat prior probabilities to the parameters of the features models with prior ranges
listed in Table [12](#S9.T12 "Table 12 ‣ 9.1.4 Cutoff model ‣ 9.1 Models ‣ 9 Search for parameterized features ‣ Planck 2015 results. XX. Constraints on inflation").
Note that throughout this section for the sake of maximizing sensitivity to very sharp features,
the unbinned (“bin1") versions of the
high-$\ell$ TT and TT,TE,EE likelihoods are used instead of the standard binned versions.

Since the features considered here can lead to broad distortions of the CMB angular power spectrum degenerate
with the late time cosmological parameters ([Miranda & Hu, 2014](#bib.bib174)),
in all cases we simultaneously vary primordial parameters and all the $\Lambda$CDM parameters,
but keep the foreground parameters fixed to their
best-fit values for the power-law base $\Lambda$CDM model.

We present the Bayes factors with respect to the power-law base $\Lambda$CDM model
and the improvement in the effective $\chi^{2}$ over the power-law model
in Table [13](#S9.T13 "Table 13 ‣ 9.2 Analysis and results ‣ 9 Search for parameterized features ‣ Planck 2015 results. XX. Constraints on inflation"). For our choice of priors, none of the features models is
preferred over a power-law spectrum.
The best-fit power spectra are plotted in Fig. [33](#S9.F33 "Figure 33 ‣ 9.2 Analysis and results ‣ 9 Search for parameterized features ‣ Planck 2015 results. XX. Constraints on inflation"). While the cutoff and step model best fits reproduce the
large-scale suppression at $\ell\approx 20$–30 also obtained by direct power spectrum reconstruction in Sect. [8](#S8 "8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation"),
the oscillation models prefer relatively high frequencies beyond the resolution of the reconstruction methods.

In addition to the four features models we also show in Fig. [33](#S9.F33 "Figure 33 ‣ 9.2 Analysis and results ‣ 9 Search for parameterized features ‣ Planck 2015 results. XX. Constraints on inflation")
the best fit of a model allowing for steps in both inflaton potential and warp (brown line).
Note the strong resemblance to the reconstructed features of the previous section.
The effective $\Delta\chi^{2}$ for this model is $-12.1$ ($-11.5$) for Planck TT+lowP (Planck TT,TE,EE+lowP) data at the cost
of adding five new parameters, resulting in a ln-Bayes factor of $-0.8$ ($-0.4$).
A similar phenomenology can be also be found for a model with a sudden change in the slope of the inflaton potential
([Starobinsky, 1992](#bib.bib245); [Choe et al., 2004](#bib.bib55)), which yields a best-fit $\Delta\chi^{2}=-4.5$ ($-4.9$) for two extra parameters.

As shown in Table [14](#S9.T14 "Table 14 ‣ 9.2 Analysis and results ‣ 9 Search for parameterized features ‣ Planck 2015 results. XX. Constraints on inflation"), constraints on the remaining cosmological parameters are not
significantly affected when allowing for the presence of features.

For the cutoff and step models, the inclusion of Planck small-scale polarization data does not add much in
terms of direct sensitivity. The best fits lie in the same
parameter region as for Planck TT+lowP data, and the $\Delta\chi^{2}$ and Bayes factors
are not subject to major changes. The two oscillation models’ Planck TT+lowP best fits,
on the other hand, also predict a non-negligible
signature in the polarization spectra at high $\ell$. Therefore, if the features were real, one would
expect an additional improvement in
$\Delta\chi^{2}$ for Planck TT,TE,EE+lowP. This is not the case here.
Though the linear oscillation model’s maximum $\Delta\chi^{2}$ does
increase, the local $\Delta\chi^{2}$ in the Planck TT+lowP best-fit regions is in fact reduced for both models, and the global likelihood maxima
occur at different frequencies ($\log\_{10}\omega\_{\mathrm{log}}=1.25$ and $\log\_{10}\omega\_{\mathrm{lin}}=1.02$) compared to their Planck TT+lowP
counterparts.

In addition to the Bayesian model comparison analysis, we also approach the matter of the statistical relevance of the features
models from a frequentist statistics perspective in order to give the
$\Delta\chi^{2}$ numbers a quantitative interpretation. Assuming that the underlying
$\mathcal{P\_{R}}(k)$ was actually a featureless power law, we can ask how large an improvement to $\ln\mathcal{L}$
the different features models would yield on average just by overfitting scatter from cosmic variance and noise. For this purpose, we simulate
Planck power spectrum data sets consisting of temperature and polarization up to $\ell=29$ and unbinned temperature for
$30\leq\ell\leq 2508$, taking as input fiducial spectra the power-law base $\Lambda$CDM model’s best-fit spectra.

For each of these simulated Planck data sets, we perform the following procedure:
(i) find the power-law $\Lambda$CDM model’s best-fit parameters with CosmoMC’s minimization algorithm,
(ii) fix the non-primordial parameters ($\omega\_{\mathrm{b}},\omega\_{\mathrm{c}},\theta\_{\mathrm{MC}},\tau$) to their respective best-fit values,
(iii) using MultiNest, find the best fit of the features
models,99
9
Due to the multimodal nature of the posterior, usual minimization routines perform poorly here.
and (iv) extract the effective $\Delta\chi^{2}$ between power-law and features models.

The resulting distributions are shown in Fig. [34](#S9.F34 "Figure 34 ‣ 9.2 Analysis and results ‣ 9 Search for parameterized features ‣ Planck 2015 results. XX. Constraints on inflation"). Compared to the real data $\Delta\chi^{2}$ values
from Table [13](#S9.T13 "Table 13 ‣ 9.2 Analysis and results ‣ 9 Search for parameterized features ‣ Planck 2015 results. XX. Constraints on inflation"), they are biased towards lower values, since we do not vary the late-time
cosmological parameters in the analysis of the simulated data. Nonetheless, the observed improvements in the fit do not appear to be
extraordinarily large, with the respective (conservative) $p$-values ranging between 0.09 and 0.50.

These observations lead to the conclusion that even though some of the peculiarities seen in the
residuals of the Planck data with respect to a power-law primordial spectrum may be explained in terms
of primordial features, none of the simple model templates considered here is required by Planck data.
The simplicity of the power-law spectrum continues to give it an edge over more complicated initial spectra and the
most plausible explanation for the apparent features in the data remains that we are just observing
fluctuations due to cosmic variance at large scales and noise at small scales.

## 10 Implications of Planck bispectral constraints on inflationary models

The combination of power spectrum constraints and primordial non-Gaussianity (NG) constraints, such as the
Planck upper bound on the NG amplitude $f\_{\mathrm{NL}}$ ([Planck Collaboration
XVII, 2016](#bib.bib221)), can be exploited to limit
extensions to the simplest standard single-field models of slow-roll inflation. The next subsection considers
inflationary models with a non-standard kinetic term ([Garriga & Mukhanov, 1999](#bib.bib96)), where the inflaton Lagrangian is
a general function of the scalar inflaton field and its first derivative, i.e., $\mathfrak{L}=P(\phi,X)$, where $X=-g^{\mu\nu}\partial\_{\mu}\phi\partial\_{\nu}\phi/2$ ([Garriga & Mukhanov, 1999](#bib.bib96); [Chen et al., 2007](#bib.bib53)).
Sect. [10.2](#S10.SS2 "10.2 Galileon inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation") focuses on a specific example of a single-field model of inflation with more general
higher-derivative operators, the so-called “Galileon inflation.” Sect. [10.3](#S10.SS3 "10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation") presents constraints on axion
monodromy inflation. See [Planck Collaboration
XVII (2016)](#bib.bib221) for the analysis of other interesting non-standard inflationary
models, including warm inflation ([Berera, 1995](#bib.bib28)), whose $f\_{\mathrm{NL}}$ predictions can be constrained by
Planck.

### 10.1 Inflation with a non-standard kinetic term

This class of models includes $k$-inflation ([Armendáriz-Picón et al., 1999](#bib.bib10); [Garriga & Mukhanov, 1999](#bib.bib96)) and Dirac-Born-Infield
(DBI) models introduced in the context of brane inflation
([Silverstein & Tong, 2004](#bib.bib239); [Alishahiha et al., 2004](#bib.bib6); [Chen, 2005b](#bib.bib50); [Chen, 2005a](#bib.bib49)). In these models inflation
can take place despite a steep potential or may be driven by the kinetic term.

Moreover, one of the main predictions of inflationary models with a non-standard kinetic term is that the inflaton
perturbations can propagate with a sound speed $c\_{\mathrm{s}}<1$. We show how the Planck combined measurement of
the power spectrum and the nonlinearity parameter $f\_{\mathrm{NL}}$ ([Planck Collaboration
XVII, 2016](#bib.bib221)) improves constraints on
this class of models by breaking degeneracies between the parameters determining the observable power spectra.
Such degeneracies (see, e.g., [Peiris et al. (2007)](#bib.bib195), [Powell et al. (2009)](#bib.bib229),
[Lorenz et al. (2008)](#bib.bib155), [Agarwal & Bean (2009)](#bib.bib5), and [Baumann et al. (2015)](#bib.bib23)) are evident from the
expressions for the power spectra. We adopt the same notation as [Planck Collaboration
XXIV (2014)](#bib.bib207). At leading order in the
slow-roll parameters the scalar power spectrum depends additionally on the sound speed $c\_{\mathrm{s}}$ via
([Garriga & Mukhanov, 1999](#bib.bib96))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $A\_{\mathrm{s}}\approx\frac{1}{8\pi^{2}M^{2}\_{\mathrm{pl}}}\frac{H^{2}}{c\_{\mathrm{s}}\epsilon\_{1}}\thinspace,$ |  | (90) |

which is evaluated at $kc\_{\mathrm{s}}=aH$. Correspondingly, the scalar spectral index

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n\_{\mathrm{s}}-1=-2\epsilon\_{1}-\epsilon\_{2}-s\thinspace$ |  | (91) |

depends on an additional slow-roll parameter $s=\dot{c\_{\mathrm{s}}}/(c\_{\mathrm{s}}H)$, which describes the
running of the sound speed. The usual consistency relation holding for the standard single-field models of
slow-roll inflation ($r=-8n\_{\mathrm{t}}$) is modified to $r\approx-8n\_{\mathrm{t}}c\_{\mathrm{s}}$, with
$n\_{\mathrm{t}}=-2\epsilon\_{1}$ as usual ([Garriga & Mukhanov, 1999](#bib.bib96)), potentially allowing models which otherwise would predict a large
tensor-to-scalar ratio for the Klein-Gordon case ([Unnikrishnan et al., 2012](#bib.bib252)).1010
10
We use the more accurate
relation

$r=16\epsilon\_{1}c\_{\mathrm{s}}^{(1+\epsilon\_{1})/(1-\epsilon\_{1})}\thinspace,$

(92)
accounting for different epochs of freeze-out for the scalar fluctuations (at sound
horizon crossing,
$kc\_{\mathrm{s}}=aH$) and tensor perturbations (at Hubble radius crossing, $k=aH$)
([Peiris et al., 2007](#bib.bib195); [Powell et al., 2009](#bib.bib229); [Lorenz et al., 2008](#bib.bib155); [Agarwal & Bean, 2009](#bib.bib5); [Baumann et al., 2015](#bib.bib23)).

At lowest order in the slow-roll parameters, there are strong degeneracies between the parameters
($A\_{\mathrm{s}},c\_{\mathrm{s}},\epsilon\_{1},\epsilon\_{2},s$). This makes the constraints on these parameters from the
power spectrum alone not very stringent, and for parameters like $\epsilon\_{1}$ and $\epsilon\_{2}$ less stringent
compared with the standard case. However, combining the constraints on the power spectra observables with those on
$f\_{\mathrm{NL}}$ can also result in a stringent test for this class of inflationary models. Models where the
inflaton field has a non-standard kinetic term predict a high level of primordial NG of the scalar perturbations
for $c\_{\mathrm{s}}\ll 1$, ([Chen et al., 2007](#bib.bib53), see, e.g.,). Primordial NG is generated by the
higher-derivative interaction terms arising from the expansion of the kinetic part of the Lagrangian, $P(\phi,X)$.
There are two main contributions to the amplitude of the NG (i.e., to the nonlinearity parameter
$f\_{\mathrm{NL}}$), coming from the inflaton field interaction terms $\dot{\delta\phi}\thinspace(\nabla\delta\phi)^{2}$
and $(\dot{\delta\phi})^{3}$ ([Chen et al., 2007](#bib.bib53); [Senatore et al., 2010](#bib.bib238)). The NG from the first term scales as
$c\_{\mathrm{s}}^{-2}$, while the NG arising from the other term is determined by a second parameter, $\tilde{c}\_{3}$
([Senatore et al., 2010](#bib.bib238), following the notation of). Each of these two interactions produces bispectrum shapes
similar to the so-called equilateral shape ([Babich et al. 2004](#bib.bib13)) for which the signal peaks for
equilateral triangles with $k\_{1}=k\_{2}=k\_{3}.$ ([Planck Collaboration
XVII, 2016](#bib.bib221), These two shapes are called, respectively, “EFT1” and “EFT2” in). However, the difference between the two shapes is such that the total signal is a linear
combination of the two, leading to an “orthogonal” bispectral template ([Senatore et al., 2010](#bib.bib238)).

The equilateral and orthogonal NG amplitudes can be expressed in terms of the two “microscopic” parameters,
$c\_{\mathrm{s}}$ and $\tilde{c}\_{3}$ (for more details see [Planck Collaboration
XVII (2016)](#bib.bib221)), according to

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle f^{\mathrm{equil}}\_{\mathrm{NL}}$ | $\displaystyle=$ | $\displaystyle\frac{1-c\_{\mathrm{s}}^{2}}{c\_{\mathrm{s}}^{2}}\left[-0.275-0.0780c\_{s}^{2}-(2/3)\times 0.780\thinspace\tilde{c}\_{3}\right],$ |  | (93) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle f^{\mathrm{ortho}}\_{\mathrm{NL}}$ | $\displaystyle=$ | $\displaystyle\frac{1-c\_{\mathrm{s}}^{2}}{c\_{\mathrm{s}}^{2}}\left[0.0159-0.0167c\_{s}^{2}-(2/3)\times 0.0167\thinspace\tilde{c}\_{3}\right]\thinspace.$ |  | (94) |

Thus the measurements of $f^{\mathrm{equil}}\_{\mathrm{NL}}$ and $f^{\mathrm{ortho}}\_{\mathrm{NL}}$ obtained in the
companion paper ([Planck Collaboration
XVII, 2016](#bib.bib221)) provide a constraint on the sound speed, $c\_{\mathrm{s}}$, of the inflaton
field. Such constraints allow us to combine the NG information with the analyses of the power spectra, since the
sound speed is the NG parameter also affecting the power spectra.

In this subsection we consider three cases. In the first case we perform a general analysis as described above
(focusing on the simplest case of a constant sound speed, $s=0$), improving on [205](#bib.bib205)
and [Planck Collaboration
XXIV (2014)](#bib.bib207) by exploiting the full mission temperature and polarization data. The Planck constraints on primordial NG in general single-field models of inflation provide the most stringent bound on the
inflaton sound speed ([Planck Collaboration
XVII, 2016](#bib.bib221)):1111
11
This section uses results based on $f\_{\mathrm{NL}}$
constraints from $T$ and $E$ ([Planck Collaboration
XVII, 2016](#bib.bib221)). In [Planck Collaboration
XVII (2016)](#bib.bib221) it is shown that, although conservatively
considered as preliminary, the $f\_{\mathrm{NL}}$ constraints from $T$ and $E$ are robust, since they pass an extensive
battery of validation tests and are in full agreement with $T$-only constraints.

|  |  |  |  |
| --- | --- | --- | --- |
|  | $c\_{\mathrm{s}}\geq 0.024\quad(95\thinspace\%\penalty\ \mathrm{CL}).$ |  | (95) |

We then use this information on $c\_{\mathrm{s}}$ as a uniform prior $0.024\leq c\_{\mathrm{s}}\leq 1$ in
Eq. ([92](#S10.E92 "In footnote 10 ‣ 10.1 Inflation with a non-standard kinetic term ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")) within the HFF formalism, as in [205](#bib.bib205). Fig. [35](#S10.F35 "Figure 35 ‣ 10.1 Inflation with a non-standard kinetic term ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation") shows the joint
constraints on $\epsilon\_{1}$ and $\epsilon\_{2}.$ Planck TT+lowP yields $\epsilon\_{1}<0.031$ at 95 % CL. No
improvement in the upper bound on $\epsilon\_{1}$ results when using Planck TT,TE,EE+lowP. This constraint improves
the previous analysis in [205](#bib.bib205) and can be compared with the restricted case of
$c\_{\mathrm{s}}=1$, also shown in Fig. [35](#S10.F35 "Figure 35 ‣ 10.1 Inflation with a non-standard kinetic term ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation"), with $\epsilon\_{1}<0.0068$ at 95 % CL. The limits on the
sound speed from the constraints on primordial NG are crucial for deriving an upper limit on $\epsilon\_{1}$, because
the relation between the tensor-to-scalar ratio and $\epsilon\_{1}$ also involves the sound speed (see, e.g.,
Eq. [92](#S10.E92 "In footnote 10 ‣ 10.1 Inflation with a non-standard kinetic term ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")). This breaks the degeneracy in the scalar spectral index.

The other two cases analysed involve DBI models. The degeneracy between the different slow-roll parameters can be
broken for $s=0$ or in the case where $s\propto\epsilon\_{2}$. We first consider models defined by an action of the
DBI form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P(\phi,X)=-f(\phi)^{-1}\sqrt{1-2f(\phi)X}+f(\phi)^{-1}-V(\phi)\thinspace,$ |  | (96) |

where $V(\phi)$ is the potential and $f(\phi)$ describes the warp factor determined by the geometry of the extra
dimensions. We follow an analogous procedure to exploit the NG limits derived in [Planck Collaboration
XVII (2016)](#bib.bib221) on
$c\_{\mathrm{s}}$ in the case of DBI models: $c\_{\mathrm{s}}\geq 0.087$ (at 95 % CL). Assuming a uniform prior,
$0.087\leq c\_{\mathrm{s}}\leq 1$, and $s=0$, Planck TT+lowP gives $\epsilon\_{1}<0.024$ at 95 % CL, a $43\thinspace\%$
improvement with respect to [205](#bib.bib205). The addition of high-$\ell$ $TE$ and $EE$ does not
improve the upper bound on $\epsilon\_{1}$ for this DBI case.

Figure 35: 
$(\epsilon\_{1}\thinspace,\epsilon\_{2})$ 68 % and 95 % CL constraints
for Planck data comparing the canonical Lagrangian case with $c\_{\mathrm{s}}=1$ to the
case of varying $c\_{\mathrm{s}}$ with a uniform prior $0.024<c\_{\mathrm{s}}<1$ derived from the
Planck NG measurements.

Next we update the constraints on the particularly interesting case of infrared DBI models
([Chen 2005b](#bib.bib50); [Chen 2005a](#bib.bib49)), where $f(\phi)\approx\lambda/\phi^{4}.$ (For details, see
[Silverstein & Tong (2004)](#bib.bib239), [Alishahiha et al. (2004)](#bib.bib6), [Chen et al. (2007)](#bib.bib53), and references therein). In
these models the inflaton field moves from the IR to the UV side with an inflaton potential

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=V\_{0}-\frac{1}{2}\beta H^{2}\phi^{2}\thinspace.$ |  | (97) |

From a theoretical point of view a wide range of values for $\beta$ is allowed: $0.1<\beta<10^{9}$
([Bean et al., 2008](#bib.bib24)). [205](#bib.bib205) dramatically restricted the allowed parameter space of
these models in the limit where stringy effects can be neglected and the usual field theory computation of the
primordial curvature perturbation holds (see [Chen (2005a)](#bib.bib49); [Chen (2005c)](#bib.bib51) and
[Bean et al. (2008)](#bib.bib24) for more details). In this limit of the IR DBI model, one finds
([Chen, 2005c](#bib.bib51); [Chen et al., 2007](#bib.bib53)) $c\_{\mathrm{s}}\approx(\beta N\_{\*}/3)^{-1}$,
$n\_{\mathrm{s}}-1=-4/N\_{\*}$, and $dn\_{\mathrm{s}}/d\ln k=-4/N\_{\*}^{2}.$ (In this model one can verify that $s\approx 1/N\_{\*}\approx\epsilon\_{2}/3$.) Combining the uniform prior on $c\_{\mathrm{s}}$ with Planck TT+lowP, we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\beta\leq 0.31\quad(95\thinspace\%\penalty\ \mathrm{CL}),$ |  | (98) |

and a preference for a high number of $e$-folds: $78<N\_{\*}<157$ at 95 % CL.

We now constrain the general case of the IR DBI model, including the “stringy” regime, which occurs when the
inflaton extends back in time towards the IR side ([Bean et al., 2008](#bib.bib24)). The stringy phase transition is
characterized by an interesting phenomenology altering the predictions for cosmological perturbations. A
parameterization of the power spectrum of curvature perturbations interpolating between the two regimes
is ([Bean et al. (2008)](#bib.bib24); see also [Ma et al. (2013)](#bib.bib161))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}\_{\mathcal{R}}(k)=\frac{A\_{\mathrm{s}}}{\left(N\_{e}^{\mathrm{DBI}}\right)^{4}}\left[1-\frac{1}{(1+x)^{2}}\right],$ |  | (99) |

where $A\_{\mathrm{s}}=324\pi^{2}/(n\_{\mathrm{B}}\thinspace\beta^{4})$
is the amplitude of the perturbations which depends on various
microscopic parameters ($n\_{\mathrm{B}}$ is the number of branes at the B-throat;
see [Bean et al. (2008)](#bib.bib24) for more details), while $x=(N\_{e}^{\mathrm{DBI}}/N\_{c})^{8}$
sets the stringy phase transition taking place at the critical
$e$-fold $N\_{c}.$ (Here $N\_{e}^{\mathrm{DBI}}$ is the number of $e$-folds to the end of IR DBI inflation.)
The spectral index and its running are

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle n\_{\mathrm{s}}-1$ | $\displaystyle=\frac{4}{N\_{e}^{\mathrm{DBI}}}\frac{x^{2}+3x-2}{(x+1)(x+2)}\thinspace,$ |  | (100) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{dn\_{\mathrm{s}}}{d\ln k}$ | $\displaystyle=\frac{4}{{\left(N\_{e}^{\mathrm{DBI}}\right)^{2}}}\frac{x^{4}+6x^{3}-55x^{2}-96x-4}{(x+1)^{2}(x+2)^{2}}\thinspace.$ |  | (101) |

A prediction for the primordial NG in the stringy regime is not available. We assume the standard field-theoretic
result for a primordial bispectrum of the equilateral type with an amplitude
$f^{\mathrm{DBI}}\_{\mathrm{NL}}=-(35/108)\thinspace[(\beta^{2}\thinspace(N\_{e}^{\mathrm{DBI}})^{2}/9)-1]$. By considering the same uniform
prior on $c\_{\mathrm{s}}$, we obtain $\beta<0.77$, $66<N\_{e}^{\mathrm{DBI}}<72$, and $x<0.41$ at 95 % CL,
which severely limits the general IR DBI model and strongly restricts the allowed parameter space.

### 10.2 Galileon inflation

As a further example of the implications of the NG constraints on (non-standard) inflationary models we consider
Galileon inflation ([Burrage et al., 2011](#bib.bib46)) (see also [Kobayashi et al. (2010)](#bib.bib134), [Mizuno & Koyama (2010)](#bib.bib175), and
[Ohashi & Tsujikawa (2012)](#bib.bib189)). This represents a well-defined and well-motivated model of inflation with more
general higher derivatives of the inflaton field compared to the non-standard kinetic term case analysed above.
The Galileon models of inflation are based on the so-called “Galilean symmetry” ([Nicolis et al., 2009](#bib.bib186)), and
enjoy some well understood stability properties (absence of ghost instabilities and protection from large quantum
corrections). This makes the theory also very predictive, since observable quantities (scalar and tensor power
spectra and higher-order correlators) depend on a finite number of parameters. From this point of view this class
of models shares some of the same properties as the DBI inflationary models
([Silverstein & Tong, 2004](#bib.bib239); [Alishahiha et al., 2004](#bib.bib6)). The Galileon field arises naturally within fundamental physics
constructions (e.g., [de Rham & Gabadadze 2010b](#bib.bib63); [de Rham & Gabadadze 2010a](#bib.bib62)). These models also offer an interesting
example of large-scale modifications to Einstein gravity.

The Galileon model is based on the action ([Deffayet et al., 2009a](#bib.bib64); [Deffayet et al., 2009b](#bib.bib65))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S=\int d^{4}x\sqrt{-g}\left(\frac{M\_{\mathrm{pl}}^{2}}{2}R+\sum\_{n=0}^{3}\mathcal{L}\_{n}\right),$ |  | (102) |

where

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{L}\_{0}$ | $\displaystyle=$ | $\displaystyle c\_{2}X,$ |  | (103) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{L}\_{1}$ | $\displaystyle=$ | $\displaystyle-2\left(c\_{3}/\Lambda^{3}\right)X\Box\phi,$ |  | (104) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{L}\_{2}$ | $\displaystyle=$ | $\displaystyle 2\left(c\_{4}/\Lambda^{6}\right)X\left[\left(\Box\phi\right)^{2}-\left(\nabla\_{\mu}\nabla\_{\nu}\phi\right)^{2}\right]+\left(c\_{4}/\Lambda^{6}\right)X^{2}\thinspace R,$ |  | (105) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{L}\_{3}$ | $\displaystyle=$ | $\displaystyle-2\left(c\_{5}/\Lambda^{9}\right)X\left[\left(\Box\phi\right)^{3}-3\Box\phi\left(\nabla\_{\mu}\nabla\_{\nu}\phi\right)^{2}+2\left(\nabla\_{\mu}\nabla\_{\nu}\phi\right)^{3}\right]$ |  | (106) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  | $\displaystyle+$ | $\displaystyle 6\left(c\_{5}/\Lambda^{9}\right)X^{2}G\_{\mu\nu}\nabla^{\mu}\nabla^{\nu}\phi\thinspace\thinspace.$ |  | (107) |

Here $X=-\nabla\_{\mu}\phi\nabla^{\mu}\phi/2$, $(\nabla\_{\mu}\nabla\_{\nu}\phi)^{2}=\nabla\_{\mu}\nabla\_{\nu}\phi\nabla^{\mu}\nabla^{\nu}\phi$, and $(\nabla\_{\mu}\nabla\_{\nu}\phi)^{3}=\nabla\_{\mu}\nabla\_{\nu}\phi\nabla^{\mu}\nabla^{\rho}\phi\nabla^{\nu}\nabla\_{\rho}\phi$.
The coupling coefficients $c\_{i}$ are dimensionless and $\Lambda$ is the cutoff of the theory.
The case of interest includes a potential term $V(\phi)=V\_{0}+\lambda\phi+(1/2)m^{2}\phi^{2}+\ldots$ to drive inflation.

The predicted scalar power spectrum at leading order is ([Ohashi & Tsujikawa (2012)](#bib.bib189); [Burrage et al. (2011)](#bib.bib46); [Tsujikawa et al. (2013)](#bib.bib250); see also [Kobayashi et al. (2011a)](#bib.bib135) and [Gao & Steer (2011)](#bib.bib92))1212
12
For
the following expressions it is convenient to define the quantities

$A=c\_{2}/2+6\bar{c}\_{3}+27\bar{c}\_{4}+60\bar{c}\_{5},\quad B=-c\_{2}/2-4\bar{c}\_{3}-13\bar{c}\_{4}-24\bar{c}\_{5},\quad$

(108)
where $\bar{c}\_{i}=c\_{i}Z^{i-2}$ for $i=2$ to $5$, with $Z=H\dot{\phi}\_{0}/\Lambda^{3}$.
In order to have a viable model we require $A>0$ (no ghosts) and $B<0$ (no gradient instabilities).

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}\_{\mathcal{R}}=\frac{H^{2}}{8\pi^{2}M\_{\mathrm{Pl}}^{2}\epsilon\_{\mathrm{s}}Fc\_{\mathrm{s}}}\Bigg|\_{c\_{\mathrm{s}}k=aH}=\frac{H^{4}}{8\pi^{2}A(\dot{\phi\_{0}})^{2}c\_{\mathrm{s}}^{3}},$ |  | (109) |

where $F=1+\bar{c}\_{4}(\dot{\phi}\_{0})^{2}/(2H^{2}M\_{\mathrm{Pl}}^{2})$ and $c\_{\mathrm{s}}^{2}=-B/A$ is the sound speed of the Galileon field.
$\epsilon\_{\mathrm{s}}$ is different from the usual slow-roll parameter $\epsilon\_{1}$ and at leading order related according to
$\epsilon\_{\mathrm{s}}=-2B/(1+6\bar{c}\_{3}+18\bar{c}\_{4}+30\bar{c}\_{5})\epsilon\_{1}.$
The scalar spectral index

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n\_{\mathrm{s}}-1=-2\epsilon\_{1}-\eta\_{\mathrm{s}}-s$ |  | (110) |

depends on the slow-roll parameters $\epsilon\_{1}$, $\eta\_{\mathrm{s}}=\dot{\epsilon}\_{\mathrm{s}}/(H\epsilon\_{\mathrm{s}})$,
and $s=\dot{c}\_{\mathrm{s}}/(Hc\_{\mathrm{s}})$. As usual the slow-roll parameter $s$ describes the running of the sound speed.
In the following we restrict ourselves to the case of a constant sound speed with $s=0$.
The tensor-to-scalar ratio is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $r=16\epsilon\_{s}c\_{\mathrm{s}}=16\epsilon\_{1}\bar{c}\_{\mathrm{s}}\thinspace,$ |  | (111) |

where we have introduced the parameter $\bar{c}\_{\mathrm{s}}=-[2B/(1+6\bar{c}\_{3}+18\bar{c}\_{4}+30\bar{c}\_{5})]c\_{\mathrm{s}}$,
which is related to the Galileon sound speed. The parameter $\bar{c}\_{\mathrm{s}}$ can be either positive or negative.
In the negative branch a blue spectral tilt for the primordial gravitational waves is allowed, contrary to the situation for standard slow-roll models
of inflation.
We introduce such a quantity so that the consistency relation takes the form
$r\approx-8n\_{\mathrm{t}}\bar{c}\_{\mathrm{s}}$, with $n\_{\mathrm{t}}=-2\epsilon\_{1}$,
analogous to Eq. ([92](#S10.E92 "In footnote 10 ‣ 10.1 Inflation with a non-standard kinetic term ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")). The measurements of primordial NG constrain $\bar{c}\_{\mathrm{s}},$ which in turn
constrains $\epsilon\_{1}$ and $\eta\_{\mathrm{s}}$ in Eq. ([110](#S10.E110 "In 10.2 Galileon inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")). This is analogous to the constraints on
$\epsilon\_{1}$ and $\eta$ of Eq. ([91](#S10.E91 "In 10.1 Inflation with a non-standard kinetic term ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")) in the previous subsection.

Galileon models of inflation predict interesting NG signatures
([Burrage et al., 2011](#bib.bib46); [Tsujikawa et al., 2013](#bib.bib250)).1313
13
See also [Mizuno & Koyama (2010)](#bib.bib175), [Gao & Steer (2011)](#bib.bib92),
[Kobayashi et al. (2011b)](#bib.bib136), [De Felice & Tsujikawa (2013)](#bib.bib61), and [Regan et al. (2014)](#bib.bib231).
We have verified ([Creminelli et al., 2011](#bib.bib59), see also) that bispectra can be generated with the
same shapes as the “EFT1” and “EFT2” ([Senatore et al., 2010](#bib.bib238); [Chen et al., 2007](#bib.bib53)) constrained
in the companion paper ([Planck Collaboration
XVII, 2016](#bib.bib221)), which usually arise in models of inflation with non-standard kinetic terms, with

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle f\_{\mathrm{NL}}^{\mathrm{EFT1}}$ | $\displaystyle=$ | $\displaystyle\frac{17}{972}\left(-\frac{5}{c\_{\mathrm{s}}^{4}}+\frac{30}{c\_{\mathrm{s}}^{2}}-\frac{40}{c\_{\mathrm{s}}\bar{c}\_{\mathrm{s}}}+15\right),$ |  | (112) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle f\_{\mathrm{NL}}^{\mathrm{EFT2}}$ | $\displaystyle=$ | $\displaystyle\frac{1}{243}\left(\frac{5}{c\_{\mathrm{s}}^{4}}+\frac{30/A-55}{c\_{\mathrm{s}}^{2}}+\frac{40}{c\_{\mathrm{s}}\bar{c}\_{\mathrm{s}}}-320\frac{c\_{\mathrm{s}}}{\bar{c}\_{\mathrm{s}}}-\frac{30}{A}+275\right.$ |  | (113) |
|  |  | $\displaystyle-$ | $\displaystyle\left.225c\_{\mathrm{s}}^{2}+280\frac{{c\_{\mathrm{s}}^{3}}}{\bar{c}\_{\mathrm{s}}}\right)\thinspace.$ |  |

As explained in the previous subsection, the linear combinations of these two bispectra produce both equilateral and orthogonal bispectrum templates.
Given Eqs. ([109](#S10.E109 "In 10.2 Galileon inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation"))–([113](#S10.E113 "In 10.2 Galileon inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")), we can proceed as in the previous section to exploit
the limits on primordial NG in a combined analysis with the power spectra analysis.
In [Planck Collaboration
XVII (2016)](#bib.bib221) the constraint $c\_{\mathrm{s}}\geq 0.23$ ($95\thinspace\%$ CL) is obtained based on
the constraints on $f^{\mathrm{equil}}\_{\mathrm{NL}}$ and $f^{\mathrm{ortho}}\_{\mathrm{NL}}$.
One can proceed as described in [Planck Collaboration
XVII (2016)](#bib.bib221) to constrain the parameter
$\bar{c}\_{\mathrm{s}}$ modifying the consistency relation, Eq. ([111](#S10.E111 "In 10.2 Galileon inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")). Adopting a log-uniform prior
on $A$ in the interval $10^{-4}\leq A\leq 10^{4}$ and a uniform prior $10^{-4}\leq c\_{\mathrm{s}}\leq 1$,
the Planck measurements on $f^{\mathrm{equil}}\_{\mathrm{NL}}$ and $f^{\mathrm{ortho}}\_{\mathrm{NL}}$
constrain $\bar{c}\_{\mathrm{s}}$ to be $0.038\leq\bar{c}\_{\mathrm{s}}\leq 100$ ($95\thinspace\%$ CL) ([Planck Collaboration
XVII, 2016](#bib.bib221)).
We also explore the possibility of the negative branch (corresponding to a blue tensor spectral index),
finding $-100\leq\bar{c}\_{\mathrm{s}}\leq-0.034$ ($95\thinspace\%$ CL) ([Planck Collaboration
XVII, 2016](#bib.bib221)).
By allowing a logarithmic prior on $\bar{c}\_{\mathrm{s}}$ based on the $f\_{\mathrm{NL}}$ measurements,
Fig. [36](#S10.F36 "Figure 36 ‣ 10.2 Galileon inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation") shows the joint constraints on $\epsilon\_{1}$ and
$\eta\_{\mathrm{s}}$ for the $n\_{\mathrm{t}}<0$ branch and for the $n\_{\mathrm{t}}>0$ branch.
Planck TT+lowP+BAO and the NG bounds on $\bar{c}\_{\mathrm{s}}$ constrain $\epsilon\_{1}<0.036$
at $95\thinspace\%$ CL for $n\_{\mathrm{t}}<0$ (and $|\epsilon\_{1}|<0.041$ for $n\_{\mathrm{t}}>0$).

Figure 36: Marginalized joint 68 % and 95 % CL for
the Galileon parameters $(\epsilon\_{1}\thinspace,\eta\_{s})$ for $n\_{\mathrm{t}}<0$ (left panel) and $n\_{\mathrm{t}}>0$ (right panel).

### 10.3 Axion monodromy inflation

#### 10.3.1 Introduction

The mechanism of monodromy inflation ([Silverstein & Westphal, 2008](#bib.bib240); [McAllister et al., 2010](#bib.bib167); [Kaloper et al., 2011](#bib.bib124); [Flauger et al., 2014b](#bib.bib89)) in string theory motivates
a broad class of inflationary potentials of the form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\mu^{4-p}\phi^{p}+\Lambda\_{0}^{4}\thinspace e^{-C\_{0}\left(\frac{\phi}{\phi\_{0}}\right)^{p\_{\Lambda}}}\cos\left[\gamma\_{0}+\frac{\phi\_{0}}{f\_{0}}\left(\frac{\phi}{\phi\_{0}}\right)^{p\_{f}+1}\right]\thinspace.$ |  | (114) |

Here $\mu$, $\Lambda\_{0}$, $f\_{0}$, and $\phi\_{0}$ are constants with the dimension of mass and
$C\_{0}$, $p$, $p\_{\Lambda}$, $p\_{f}$, and $\gamma\_{0}$ are dimensionless.

In simpler parameterizations used in prior analyses of oscillations from axion monodromy inflation
([Peiris et al., 2013](#bib.bib198); [Planck Collaboration
XXII, 2014](#bib.bib205); [Easther & Flauger, 2014](#bib.bib70); [Jackson et al., 2014](#bib.bib118); [Meerburg et al., 2014b](#bib.bib173); [Meerburg & Spergel, 2014](#bib.bib171); [Meerburg et al., 2014a](#bib.bib172); [Meerburg, 2014](#bib.bib169)), one assumes $p\_{\Lambda}=p\_{f}=0$, corresponding
to a sinusoidal term with constant amplitude throughout inflation taken to be a periodic function of the
canonically-normalized inflaton $\phi$. Taking $p\_{\Lambda}\neq 0$ and $p\_{f}\neq 0$ allows the magnitude and
frequency, respectively, of the modulation to depend on $\phi$. For example, the frequency is always a
periodic function of an underlying angular axion field, but its relation to the canonically normalized inflaton
field is model-dependent.

The microphysical motivation for $p\_{\Lambda}\neq 0$ and $p\_{f}\neq 0$ is that in string theory additional scalar
fields, known as “moduli,” evolve during inflation. The inflationary potential depends on a subset of these
fields. Because the magnitude and frequency of modulations are determined by the vacuum expectation values of
moduli, both quantities are then naturally functions of $\phi$. The case $p\_{\Lambda}=p\_{f}=0$ corresponds to when
these fields are approximately fixed, stabilized strongly by additional terms in the scalar potential. But in
other cases, the axion potential that drives inflation also provides a leading term stabilizing the moduli. The
exponential dependence of the magnitude in the potential of Eq. ([114](#S10.E114 "In 10.3.1 Introduction ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")) arises because the modulations
are generated non-perturbatively, e.g., by instantons. For this reason, the modulations can be undetectably small
in this framework, although there are interesting regimes where they could be visible.

Specific examples studied thus far yield exponents $p$, $p\_{\Lambda}$, and $p\_{f}$ that are rational numbers of modest
size. For example, models with $p=3$, $2$, $4/3$, $1$, and $2/3$ have been constructed
([Silverstein & Westphal, 2008](#bib.bib240); [McAllister et al., 2010](#bib.bib167); [McAllister et al., 2014](#bib.bib168)), or in another case $p=4/3$, $p\_{\Lambda}=-1/3$, and $p\_{f}=-1/3$. Following
[Flauger et al. (2014b)](#bib.bib89), we investigate the effect of a drift in frequency arising from $p\_{f}$, neglecting a
possible drift in the modulation amplitude by setting $p\_{\Lambda}=C\_{0}=0$. Even in this restricted model, a
parameter exploration using a fully numerical computation of the primordial power spectrum following the
methodology of [Peiris et al. (2013)](#bib.bib198) is prohibitive, so we follow [Flauger et al. (2014b)](#bib.bib89) to study two templates
capturing the features of the primordial spectra generated by this potential.

The first template, which we call the “semi-analytic” template, is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\mathcal{P}}\_{\mathcal{R}}(k)={\mathcal{P}}\_{\mathcal{R}}(k\_{\*})\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{s}}-1}\left\{1+\delta n\_{\mathrm{s}}\cos\left[\frac{\phi\_{0}}{f}\left(\frac{\phi\_{k}}{\phi\_{0}}\right)^{p\_{f}+1}+\Delta\phi\right]\right\}.$ |  | (115) |

The parameter $f$ is higher than
the underlying axion decay constant
$f\_{0}$
of the potential
by a few percent, but this difference will be neglected in this analysis. The quantity $\phi\_{0}$ is some
fiducial value for the scalar field, and $\phi\_{k}$ is the value of the scalar field at the
time when the mode with comoving momentum $k$ exits the Hubble radius. At leading order in the
slow-roll expansion, in units where the reduced Planck mass $M\_{\mathrm{Pl}}=1$,
$\phi\_{k}=\sqrt{2p\thinspace(N\_{0}-\ln(k/k\_{\*}))}$, where $N\_{0}=N\_{\*}+\phi\_{\mathrm{end}}^{2}/(2p)$,
and $\phi\_{\mathrm{end}}$ is the value of the scalar field at the end of inflation.

The second “analytic” template was derived by [Flauger et al. (2014b)](#bib.bib89) by expanding
the argument of the trigonometric function in Eq. ([115](#S10.E115 "In 10.3.1 Introduction ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")) in $\ln(k/k\_{\*})$, leading to

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  |  | $\displaystyle{\mathcal{P}}\_{\mathcal{R}}(k)={\mathcal{P}}\_{\mathcal{R}}(k\_{\*})\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{s}}-1}$ |  | (116) |
|  |  | $\displaystyle\times$ | $\displaystyle\left\{1+\delta n\_{\mathrm{s}}\cos\left[\Delta\phi+\alpha\left(\ln\left(\frac{k}{k\_{\*}}\right)+\sum\_{n=1}^{2}\frac{c\_{n}}{N\_{\*}^{n}}\ln^{n+1}\left(\frac{k}{k\_{\*}}\right)\right)\right]\right\}.$ |  |

The relation between the empirical parameters in the templates
and the potential parameters are approximated by $\delta n\_{\mathrm{s}}=3b\sqrt{2\pi/\alpha}$, where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\alpha=(1+p\_{f})\frac{\phi\_{0}}{2fN\_{0}}\left(\frac{\sqrt{2pN\_{0}}}{\phi\_{0}}\right)^{1+p\_{f}},$ |  | (117) |

and $b$ is the monotonicity parameter defined in [Flauger et al. (2014b)](#bib.bib89),
providing relations converting
bounds on $c\_{n}$ into bounds on the microphysical parameters of the potential.
However, the analytic template can describe more general shapes of primordial spectra than just axion monodromy.

As discussed by [Flauger et al. (2014b)](#bib.bib89), there is a degeneracy between $p$
(or alternatively $n\_{\mathrm{s}}$) and $f$. For both templates we fix $p=4/3$ and also fix
the tensor power spectrum to its form in the absence of oscillations.
This is an excellent approximation because tensor oscillations are suppressed relative to the scalar oscillations by a
factor $\alpha(f/M\_{\mathrm{Pl}})^{2}\ll 1$. A uniform prior $-\pi<\Delta\phi<\pi$ is adopted for the
phase parameter of both templates as well as a prior $0<\delta n\_{\mathrm{s}}<0.7$ for the modulation amplitude parameter.

Figure 37: Constraints on the parameters of the analytic template, showing joint 68 % and 95 % CL. The dotted lines correspond to the frequencies showing the highest-likelihood improvements (see text).

Figure 38: Constraints on the parameters of the semi-analytic template
showing joint 68 % and 95 % CL. The solid lines on the left-hand panel
mark the frequencies showing the highest-likelihood improvements (see text).

In order to specify the semi-analytic template,
we assume instantaneous reheating, which for $p=4/3$ corresponds to
$N\_{\*}\approx 57.5$ for $k\_{\*}=0.05$ Mpc-1.
We set $\phi\_{0}=12.38M\_{\mathrm{Pl}}$ with $\phi\_{\mathrm{end}}=0.59M\_{\mathrm{Pl}}$. We adopt uniform priors
$-4<\log\_{10}(f/M\_{\mathrm{Pl}})<-1$ and $-0.75<p\_{f}<1$ for the remaining parameters. The priors $0<\ln(\alpha)<6.9$ and $-2<c\_{1,2}<2$ specify the analytic template. The single-field effective field theory becomes strongly coupled for $\alpha>200$. However, in principle the string construction
remains valid in this regime.

#### 10.3.2 Power spectrum constraints on monodromy inflation

We carry out a Bayesian analysis of axion monodromy inflation using a high-resolution version of CAMB
coupled to the PolyChord sampler (see Sect. [8.2](#S8.SS2 "8.2 Method II: Bayesian model comparison ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation")). For our baseline analysis we conservatively
adopt Planck TT+lowP, using the “bin1” high-$\ell$ $TT$ likelihood.
In addition to the primordial template priors specified above, we marginalize over the standard priors for the cosmological
parameters, the primordial amplitude, and foreground parameters.

Figure 39: Frequency residuals for the $\ln(\alpha)\approx 3.5$ likelihood peak, binned at $\Delta\ell=30$. The $\pm 1\thinspace\sigma$ errors are given by the square root of the diagonal elements of the covariance matrix.

The marginalized joint posterior constraints on pairs of primordial parameters for the analytic and semi-analytic
templates are shown in Figs. [37](#S10.F37 "Figure 37 ‣ 10.3.1 Introduction ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation") and [38](#S10.F38 "Figure 38 ‣ 10.3.1 Introduction ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation"), respectively.

The complex structures seen in these plots arise due to degeneracies in the likelihood frequency “beating”
between underlying modulations in the data and the model ([Easther et al., 2005](#bib.bib71)). Parameter combinations where
“beating” occurs over the largest $k$ ranges lead to discrete local maxima in the likelihood. Fortuitous
correlations in the observed realization of the $C\_{\ell}$ can give the same effect.

The four frequencies picked out by these structures, $\ln(\alpha)\approx\left\{3.5,5.4,6.0,6.8\right\}$,
show improvements of $\Delta\chi^{2}\approx\left\{-9.7,-7.1,-12.2,-12.5\right\}$ relative to
$\Lambda$CDM, respectively. These frequencies are marked by dotted lines in Fig. [37](#S10.F37 "Figure 37 ‣ 10.3.1 Introduction ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation"), and by
solid lines in Fig. [38](#S10.F38 "Figure 38 ‣ 10.3.1 Introduction ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation") using Eq. ([117](#S10.E117 "In 10.3.1 Introduction ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")). The semi-analytic and analytic
templates lead to self-consistent results as expected, with analogous structures being picked out by the
likelihood in each template. There is no evidence for a drifting frequency, $p\_{f}\neq 0$ or $c\_{n}\neq 0$. Thus,
these parameters serve to smooth out structures in the marginalized posterior.

The improvement in $\chi^{2}$ is not compelling enough to suggest a primordial origin. Fitting a modulated model to
simulations with a smooth spectrum can give rise to $\Delta\chi^{2}\sim-10$ improvements
([Flauger et al., 2014b](#bib.bib89)). Furthermore, as the monodromy model contains only a single frequency, at least three of
these structures must correspond to spurious fits to the noise. Considering the two models defined by the two
templates and the parameter priors specified above, the Bayes factors calculated using PolyChord favours
base $\Lambda$CDM over both templates by odds of roughly 8:1.

Compared to previous analyses of the linear ($p=1$) axion monodromy model for WMAP9 ([Peiris et al., 2013](#bib.bib198)) and the
2013 Planck data ([Planck Collaboration
XXII, 2014](#bib.bib205); [Easther & Flauger, 2014](#bib.bib70)) the common frequencies are shifted slightly upward. The
lower frequency in common appears shifted by a factor of order $\sqrt{p}$ from $\alpha\approx 28.9$ to $31.8$ and
the higher frequency in common from $\alpha\approx 210$ to $223$. [Flauger et al. (2014b)](#bib.bib89) suggest that the lower
frequency (which had $\Delta\chi^{2}=-9$ in [205](#bib.bib205)) was associated with the 4 K
cooler line systematic effects in the 2013 Planck likelihood. However, its presence at similar significance in
the 2015 likelihood with improved handling of the cooler line systematics suggests that this explanation is not
correct. The second frequency, which appeared with $\Delta\chi^{2}\approx-20$ in WMAP9
([Peiris et al., 2013](#bib.bib198)) is still present but with much reduced significance, suggesting that the high multipoles do
not give evidence for this frequency. Additionally, two higher frequencies are present, which if interpreted as
being of primordial origin, correspond to a regime well beyond the validity of the single-field effective field
theory. If one of these frequencies were to be confirmed as primordial, a significantly improved understanding of
the underlying string construction would need to be undertaken.

In order to check whether the improvement in fit at these four modulation frequencies is responding to residual
foregrounds or other systematics, we examine the frequency residuals. Figure [39](#S10.F39 "Figure 39 ‣ 10.3.2 Power spectrum constraints on monodromy inflation ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation") shows the
residuals of the data minus the model (including the best-fit foreground model) for the four PLIK frequency
combinations binned at $\Delta\ell=30$ for the lowest modulation frequency, $\ln(\alpha)\approx 3.5$. This
plot shows no significant frequency dependence, and thus there is no indication that the fit is responding to
frequency dependent systematics. Furthermore, the plot does not show evidence that the improvement for this
modulation frequency comes from the feature at $\ell\approx 800$, as suggested by [Easther & Flauger (2014)](#bib.bib70). This
feature and another at $\ell\approx 1500$ are apparent at all frequency combinations. Similar plots for the three
other modulation frequencies also do not show indications of frequency dependence.

In order to confirm whether any of the frequencies picked out here is of primordial origin, one can exploit
independent information in the polarization data to perform a cross-check of the temperature prediction, thus
minimizing the “look-elsewhere” effect ([Mortonson et al., 2009](#bib.bib178)). Leaving a complete analysis of the
independent information in the polarization for future work, we now check whether the temperature-only result
remains stable when high-$\ell$ polarization is added in the likelihood. In Fig. [40](#S10.F40 "Figure 40 ‣ 10.3.2 Power spectrum constraints on monodromy inflation ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation") we show a
preliminary analysis using the PLIK temperature and polarization ($TT$, $TE$, and $EE$) “bin1” likelihood plus
low-$\ell$ polarization data. A comparison with the left-hand panels of Figs. [37](#S10.F37 "Figure 37 ‣ 10.3.1 Introduction ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation") and
[38](#S10.F38 "Figure 38 ‣ 10.3.1 Introduction ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation") indicates slight differences from the $T$-only analysis.
However, all the four frequencies identified in the temperature are present when high-$\ell$ polarization is added. There is a maximum
$\Delta\chi^{2}\approx-8.0$ improvement over $\Lambda$CDM. We also repeat the analysis using only
the $EE$ polarization “bin1” likelihood plus low-$\ell$ temperature and polarization data. These results
are presented in Fig. [41](#S10.F41 "Figure 41 ‣ 10.3.2 Power spectrum constraints on monodromy inflation ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation"). The $EE$-only frequencies are offset with respect to the
temperature-only frequencies: the best-fit $EE$-only frequencies are at $\ln(\alpha)\approx\left\{3.8,5.0,5.4,5.8,6.2\right\}$. The maximum improvement over $\Lambda$CDM for this case is $\Delta\chi^{2}\approx-12.5$.

Figure 40: Constraints on the parameters of the analytic (top)
and semi-analytic (bottom) templates with the addition of high-$\ell$
polarization data in the likelihood, showing joint 68 % and 95 % CL.
The lines mark the frequencies showing the highest-likelihood improvements identified in the baseline
temperature-only analysis.

Figure 41: Constraints on the parameters of the analytic (top) and semi-analytic
(bottom) templates with $EE$-only high-$\ell$ polarization data plus low-$\ell$
temperature and polarization data, showing joint 68 % and 95 % CL. The lines
mark the frequencies showing the highest-likelihood improvements identified in the
baseline temperature-only analysis.

#### 10.3.3 Predictions for resonant non-Gaussianity

The left-hand panel of Fig. [42](#S10.F42 "Figure 42 ‣ 10.3.3 Predictions for resonant non-Gaussianity ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation") presents derived constraints on the
parameters of the potential in Eq. ([114](#S10.E114 "In 10.3.1 Introduction ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation"))
calculated using the analytic template. Another cross-check of primordial origin is available since the monodromy model predicts
resonant NG, generating a bispectrum whose properties would be strongly correlated with that of the power spectrum
([Chen et al., 2008](#bib.bib52); [Flauger & Pajer, 2011](#bib.bib90)). Using the mapping

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\_{\mathrm{NL}}^{\mathrm{res}}=\frac{\delta n\_{\mathrm{s}}}{8}\alpha^{2},$ |  | (118) |

we use the analytic template to derive the posterior probability for the resonant NG signal predicted by constraints from the power
spectrum, presented in the middle and right panels of Fig. [42](#S10.F42 "Figure 42 ‣ 10.3.3 Predictions for resonant non-Gaussianity ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation").

[Planck Collaboration
XVII (2016)](#bib.bib221) use an improved modal estimator to scan for resonant NG. The resolution of this
scan is currently limited to $\ln(\alpha)<3.9$, which potentially can probe the lowest frequency picked out
in the power spectrum search. However, the modal estimator’s sensitivity (imposed by cosmic variance) of $\Delta f\_{\mathrm{NL}}^{\mathrm{res}}\approx 80$ is significantly greater than the predicted value for this frequency from
fits to the power spectrum, $f\_{\mathrm{NL}}^{\mathrm{res}}\sim 10$. Efforts to increase the resolution of the modal
estimator are ongoing and may allow consistency tests of the significantly higher levels of resonant
NG predicted by the higher frequencies in the future.

Figure 42: Derived constraints on the parameters of the potential, Eq. ([114](#S10.E114 "In 10.3.1 Introduction ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")), as well as the predicted resonant NG, $f\_{\mathrm{NL}}^{\mathrm{res}}$, using the analytic template, showing joint 68 % and 95 % CL. The dotted lines mark the frequencies showing the highest-likelihood improvements (see text).

#### 10.3.4 Power spectrum and bispectrum constraints on axion inflation with a gauge field coupling

We now consider the case where the axion field is coupled to a gauge field. Such a scenario is physically well
motivated. From an effective field theory point of view the derivative coupling is natural and must be included
since it respects the same shift symmetry that leads to axion models of inflation
([Anber & Sorbo, 2010](#bib.bib8); [Barnaby & Peloso, 2011](#bib.bib16); [Pajer & Peloso, 2013](#bib.bib192)). This type of coupling is also ubiquitous in
string theory (see, e.g., [Barnaby et al. (2012)](#bib.bib15) and [Linde et al. (2013)](#bib.bib150)). The coupling term in the
action is ([Anber & Sorbo, 2010](#bib.bib8); [Barnaby & Peloso, 2011](#bib.bib16); [Barnaby et al., 2011](#bib.bib14))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S\supset\int d^{4}x\sqrt{-g}\left(-\frac{\alpha}{4f}\phi F^{\mu\nu}\tilde{F}\_{\mu\nu}\right),$ |  | (119) |

where $F\_{\mu\nu}=\partial\_{\mu}A\_{\nu}-\partial\_{\nu}A\_{\mu}$, its dual is $\tilde{F}^{\mu\nu}=\epsilon^{\mu\nu\alpha\beta}F\_{\alpha\beta}/2$, and $\alpha$ is a dimensionless constant which, from
an effective field theory perspective, is expected to be of order one. For the potential of the axion field, we
will not investigate further the consequences of the oscillatory part of the potential, focusing on the coupling
of the axion field to the U(1) gauge field (effectively setting $\Lambda\_{0}=0$).

The coupling of a pseudo-scalar axion with the gauge field has interesting phenomenological consequences, both for
density perturbations and primordial gravitational waves
([Barnaby & Peloso, 2011](#bib.bib16); [Sorbo, 2011](#bib.bib242); [Barnaby et al., 2011](#bib.bib14); [Barnaby et al., 2012](#bib.bib15); [Meerburg & Pajer, 2013](#bib.bib170); [Ferreira & Sloth, 2014](#bib.bib86)).
Gauge field quanta source the axion field via an inverse decay process $\delta A+\delta A\rightarrow\delta\varphi$, modifying the usual predictions already at the power spectrum level. Additionally, the inverse decay can
generate a high level of primordial NG.

The parameter

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\xi=\frac{\alpha|\dot{\phi}|}{2fH}$ |  | (120) |

characterizes the strength of the
inverse decay effects. If $\xi<1$ the coupling is too small to produce any modifications to the usual
predictions of the uncoupled model. For previous constraints on $\xi$ see
[Barnaby et al. (2011)](#bib.bib14); [Barnaby et al. (2012)](#bib.bib15) and [Meerburg & Pajer (2013)](#bib.bib170). Using the slow-roll approximation
and neglecting the small oscillatory part of the potential, one can express

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\xi=M\_{\mathrm{Pl}}\frac{\alpha}{f}\sqrt{\frac{p}{8N+2p}},$ |  | (121) |

where $N$ is, as usual, the number of $e$-folds to the end of inflation. The scalar power spectrum of curvature
perturbations is given by

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\mathcal{P}\_{\mathcal{R}}(k)=\mathcal{P}\_{\*}\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{s}}-1}\left[1+\mathcal{P}\_{\*}\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{s}}-1}f\_{2}(\xi(k))\thinspace e^{4\pi\xi\_{\*}}\left(\frac{k}{k\_{\*}}\right)^{2\pi\xi\_{\*}\epsilon\_{2}}\right]\thinspace,$ |  |

where ([Meerburg & Pajer, 2013](#bib.bib170))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\xi(k)=\xi\_{\*}\left[1+\frac{\epsilon\_{2}}{2}\ln\left(\frac{k}{k\_{\*}}\right)\right]\thinspace.$ |  | (123) |

Here an asterisk indicates evaluation at the pivot scale, $k\_{\*}=0.05$ Mpc-1, and $\mathcal{P}\_{\*}=H\_{\*}^{4}/(4\pi^{2}\dot{\phi}\_{\*}^{2})$ and $n\_{\mathrm{s}}-1=-2\epsilon\_{1}-\epsilon\_{2}$ are the amplitude and spectral index, respectively, of the standard
slow-roll power spectrum of vacuum-mode curvature perturbations (the usual power spectrum in the absence of the
gauge-coupling). By numerically evaluating the function $f\_{2}(\xi)$ ([Barnaby et al., 2011](#bib.bib14), defined in equation (3.27) of), we created an analytical fit to this function accurate to better than $2\thinspace\%$ for
$0.1<\xi\_{\*}<7$.1414
14
The fitting function used is $\exp\{-a-b\thinspace\ln(\xi)-c\thinspace[\ln(\xi)]^{2}+d\thinspace[\ln(\xi)]^{3}+e\thinspace[\ln(\xi)]^{4}\}$, where the coefficients are $a=10.8$, $b=4.58$, $c=0.51$, $d=0.01$, and $e=0.02$. In the
following, unless stated otherwise, we fix $p=4/3$ as in the previous subsection and assume instantaneous
reheating so that $N\_{\*}\approx 57.5$ and the slow-roll parameters $\epsilon\_{1}$ and $\epsilon\_{2}$ are fixed. For
the tensor power spectrum we adopt the approximation ([Barnaby et al., 2011](#bib.bib14))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}\_{\mathrm{t}}(k)=\mathcal{P}\_{\mathrm{t}}\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{t}}}\left[1+\frac{\pi^{2}}{2}\mathcal{P}\_{\mathrm{t}}f\_{\mathrm{t},L}(\xi(k))e^{4\pi\xi\_{\*}}\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{t}}+2\pi\epsilon\_{2}\xi\_{\*}}\right]\thinspace,$ |  | (124) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\_{\mathrm{t},L}(\xi(k))=2.6\times 10^{-7}\xi^{-5.7}(k)\thinspace.$ |  | (125) |

Here $\mathcal{P}\_{\mathrm{t}}=2H\_{\*}^{2}/(\pi^{2}M\_{\mathrm{Pl}}^{2})$ and $n\_{\mathrm{t}}=-2\epsilon\_{1}$ are the “usual”
expressions for the tensor amplitude and tensor tilt in standard slow-roll inflation.

The total bispectrum is ([Barnaby et al., 2012](#bib.bib15))

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | | | | |
|  | $\displaystyle B(k\_{i})$ | $\displaystyle=B\_{\text{inv.dec.}}(k\_{i})+B\_{\mathrm{res}}(k\_{i})$ |  | (126a) |
|  |  | $\displaystyle=f\_{\mathrm{NL}}^{\text{inv.dec.}}(\xi)\thinspace F\_{\mathrm{\text{inv.dec.}}}(k\_{i})+B\_{\mathrm{res}}(k\_{i}),$ |  | (126b) |

where the explicit expression for $F\_{\mathrm{inv.dec.}}(k\_{i})$ ([Barnaby et al. (2011)](#bib.bib14); see also
[Meerburg & Pajer (2013)](#bib.bib170)) is reported in [Planck Collaboration
XVII (2016)](#bib.bib221). This shows that the inverse decay effects and
the resonant effects (which arise from the oscillatory part of the potential) simply “add up" in the bispectrum.
The nonlinearity parameter is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\_{\mathrm{NL}}^{\mathrm{inv.dec.}}=\frac{f\_{3}(\xi\_{\*})\mathcal{P}\_{\*}^{3}e^{6\pi\xi\_{\*}}}{\mathcal{P}\_{\mathcal{R}}^{2}(k\_{\*})}\thinspace.$ |  | (127) |

The function $f\_{3}(\xi\_{\*})$ corresponds to the quantity $f\_{3}(\xi\_{\*};1,1)$ defined in equation (3.29) of
[Barnaby et al. (2011)](#bib.bib14). We have computed $f\_{3}(\xi\_{\*})$ numerically and used a fit with an accuracy of better
than $2\thinspace\%$.1515
15
The fit has the same expression as the one for $f\_{2}(\xi)$ with coefficients $a=17.0048$,
$b=6.6578$, $c=0.96479$, $d=0.0506098$, and $e=0.039139$. We use the observational constraint
$f\_{\mathrm{NL}}^{\mathrm{inv.dec.}}=22.7\pm 25.5$ ($68\thinspace\%$ CL) obtained in [Planck Collaboration
XVII (2016)](#bib.bib221) from an analysis
where only the inverse decay type NG is assumed present. We omit the explicit expression for the
resonant bispectrum $B\_{\mathrm{res}}$, since it will not be used here.

We carried out an MCMC analysis of constraints on the (scalar and tensor) power spectra predicted by this model
with the Planck TT+lowP likelihood,
marginalizing over standard
priors for the cosmological parameters and foreground parameters with the uniform priors $2.5\leq\ln[10^{10}\mathcal{P}\_{\*}]\leq 3.7$ and $0.1\leq\xi\_{\*}\leq 7.0$.

The power spectrum constraint gives

|  |  |  |  |
| --- | --- | --- | --- |
|  | $0.1\leq\xi\_{\*}\leq 2.3\quad(95\thinspace\%\penalty\ \mathrm{CL}).$ |  | (128) |

Given that $f\_{\mathrm{NL}}^{\mathrm{inv.dec.}}$ is exponentially sensitive to $\xi$, this translates into the
prediction (using Eq. [127](#S10.E127 "In 10.3.4 Power spectrum and bispectrum constraints on axion inflation with a gauge field coupling ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")) $f\_{\mathrm{NL}}^{\mathrm{inv.dec.}}\leq 1.2$, which is significantly
tighter than the current bispectrum constraint from [Planck Collaboration
XVII (2016)](#bib.bib221). Indeed, importance sampling with the
likelihood for $f\_{\mathrm{NL}}^{\mathrm{inv.dec.}}$, taken to be a Gaussian centred on the NG estimate
$f\_{\mathrm{NL}}^{\mathrm{inv.dec.}}=22.7\pm 25.5$ ($68\thinspace\%$ CL) ([Planck Collaboration
XVII, 2016](#bib.bib221)), changes the limit on $\xi\_{\*}$
only at the second decimal place.

We now derive constraints on model parameters using only the observational constraint on
$f\_{\mathrm{NL}}^{\mathrm{inv.dec}}.$ The constraints thus derived are applicable for generic $p$ and also to the
axion monodromy model discussed in Sect. [10.3](#S10.SS3 "10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation"), even in the case $\Lambda\_{0}\neq 0$. We follow the procedure
described in section 11 of [Planck Collaboration
XVII (2016)](#bib.bib221). The likelihood for $f\_{\mathrm{NL}}^{\mathrm{inv.dec.}}$ is taken
to be a Gaussian centred on the NG estimate $f\_{\mathrm{NL}}^{\mathrm{inv.dec.}}=22.7\pm 25.5$ ($68\thinspace\%$ CL)
([Planck Collaboration
XVII, 2016](#bib.bib221)). We use the expression of Eq. ([127](#S10.E127 "In 10.3.4 Power spectrum and bispectrum constraints on axion inflation with a gauge field coupling ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")), where $f\_{3}(\xi\_{\*})$ is numerically
evaluated. To find the posterior distribution for the parameter $\xi\_{\*}$ we choose uniform priors in the intervals
$1.5\times 10^{-9}\leq\mathcal{P}\_{\*}\leq 3.0\times 10^{-9}$ and $0.1\leq\xi\_{\*}\leq 7.0$. This yields $95\thinspace\%$ CL
constraints for $\xi\_{\*}$ (for any value of $p$) of

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\xi\_{\*}\leq 2.5\quad(95\thinspace\%\penalty\ \mathrm{CL}).$ |  | (129) |

If we choose a log-constant prior on $\xi\_{\*}$ we find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\xi\_{\*}\leq 2.2\quad(95\thinspace\%\penalty\ \mathrm{CL}).$ |  | (130) |

For both cases the results are insensitive to the upper limit chosen for the prior on $\xi\_{\*}$ since the likelihood
quickly goes to zero for $\xi\_{\*}>3$. As the likelihood for $\xi\_{\*}$ is fairly flat, the tighter constraint seen for
the log-constant case is mildly prior driven. The constraints from the bispectrum are consistent with, and slightly
worse than, the result from the power spectrum alone.

Using a similar procedure and Eq. ([121](#S10.E121 "In 10.3.4 Power spectrum and bispectrum constraints on axion inflation with a gauge field coupling ‣ 10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation")) one can also obtain a constraint on $\alpha/f$. Adopting a
log-constant prior $2\leq\alpha/f\leq 100$1616
16
We give only the results for a log-constant prior on
$\alpha/f$, which is well-motivated since it corresponds to a log-constant prior on the axion decay constant for
some fixed $\alpha$. and uniform priors $50\leq N\_{\*}\leq 70$ and $1.5\times 10^{-9}\leq\mathcal{P}\_{\*}\leq 3.0\times 10^{-9}$ we obtain the $95\thinspace\%$ CL constraints

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\alpha/f\leq 48M^{-1}\_{\mathrm{Pl}}\thinspace\thinspace\thinspace\mathrm{for}\thinspace\thinspace\thinspace p=1,\qquad\alpha/f\leq 35M^{-1}\_{\mathrm{Pl}}\thinspace\thinspace\thinspace\mathrm{for}\thinspace\thinspace\thinspace p=2,$ |  | (131) |

and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\alpha/f\leq 42M^{-1}\_{\mathrm{Pl}}\thinspace\thinspace\thinspace\mathrm{for}\thinspace\thinspace\thinspace p=4/3\thinspace.$ |  | (132) |

For example, for a linear potential, $p=1$, if $\alpha\sim 1$ as suggested by effective field theory,
then the axion decay constant $f$ is constrained to be

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\geq 0.020M\_{\mathrm{Pl}}\quad(95\thinspace\%\penalty\ \mathrm{CL})\thinspace,$ |  | (133) |

while for a potential with $p=4/3$ we find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\geq 0.023M\_{\mathrm{Pl}}\quad(95\thinspace\%\penalty\ \mathrm{CL}).$ |  | (134) |

These limits are complementary to those derived in Sect. [10.3](#S10.SS3 "10.3 Axion monodromy inflation ‣ 10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation").

## 11 Constraints on isocurvature modes

Figure 43: Angular power spectra for the scale-invariant (i.e., $n\_{\mathcal{R}\mathcal{R}}=1$)
pure adiabatic mode (ADI, green
dashed curves) and for the scale invariant ($n\_{\mathcal{I}\mathcal{I}}=1$)
pure isocurvature (CDI, NDI, or NVI) modes, with
equal primordial perturbation amplitudes. The thick lines represent the temperature auto-correlation ($TT$) and the
thin lines the $E$-mode polarization auto-correlation ($EE$).

In [205](#bib.bib205), we presented constraints on a number of simple models featuring a mixture of the
adiabatic (ADI) mode and one type of isocurvature mode. We covered the cases of CDM density isocurvature (CDI),
neutrino density isocurvature (NDI), and neutrino velocity isocurvature (NVI) modes
([Bucher et al., 2000](#bib.bib42)),
with different assumptions
concerning the correlation
([Langlois, 1999](#bib.bib138); [Amendola et al., 2002](#bib.bib7))
between the primordial adiabatic and isocurvature perturbations.
Isocurvature modes, possibly correlated among themselves and with the adiabatic mode, can be generated in multi-field
models of inflation; however, at present a mechanism for exciting the neutrino velocity isocurvature mode
is lacking.
Section [11.2](#S11.SS2 "11.2 Results for generally-correlated adiabatic and one isocurvature mode (CDI, NDI, or NVI) ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") shows how these constraints have evolved with the new Planck TT+lowP likelihoods, how
much including the Planck lensing likelihood changes the results, and what extra information the Planck high-$\ell$
polarization contributes. A pure isocurvature mode as a sole source of perturbations has been ruled out
([Enqvist et al., 2002](#bib.bib77)), since, as can be seen from Fig. [43](#S11.F43 "Figure 43 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"), any of the isocurvature modes
leads to an
acoustic peak structure for the temperature angular power
very different from
the adiabatic mode, which
fits the data very well. The different phases and tilts of the various modes also occur in the polarization spectra, as shown in
Fig. [43](#S11.F43 "Figure 43 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") for the $E$ mode.1717
17
The transfer function mapping the
primordial CDI mode to $C\_{\ell}^{TT}$ is suppressed by a factor $(k/k\_{\mathrm{eq}})^{-2}\sim(\ell/\ell\_{\mathrm{eq}})^{-2}$ relative to the ADI mode, where $k\_{\mathrm{eq}}$ is the
wavenumber of matter-radiation equality.
As seen in Fig. [43](#S11.F43 "Figure 43 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"), there is a similar damping for the $E$ mode in the CDI
versus the ADI case. Therefore, to be observable at high $\ell$, a CDI mode should be (highly) blue tilted. So, if
the data favoured as small as possible a disturbance by CDI over all scales, then the CDI should have a spectral
index, $n\_{\mathcal{I}\mathcal{I}}$, of roughly three. In practice, the lowest-$\ell$ part of the data has very little
weight due to cosmic variance, and thus we expect that the data should favour $n\_{\mathcal{I}\mathcal{I}}$ less than three,
but significantly larger than one. This should be kept in mind when interpreting the results in the CDI case,
i.e., one cannot expect strong constraints on the *primordial* CDI fraction at small scales, even if the data
are purely adiabatic. The imprint of the baryon density isocurvature (BDI) mode in the CMB, at least at linear order,
is indistinguishable
from the CDI case, and hence we do not consider it separately as it can be described by
${\mathcal{I}}\_{{\mathrm{CDI}}}^{\mathrm{effective}}={\mathcal{I}}\_{{\mathrm{CDI}}}+(\Omega\_{\mathrm{b}}/\Omega\_{{\mathrm{c}}}){\mathcal{I}}\_{{\mathrm{BDI}}}$. The trispectrum, however, can in principle be used to
distinguish the BDI and CDI modes ([Grin et al., 2014](#bib.bib106)).

In Sect. [11.4](#S11.SS4 "11.4 CDI and primordial tensor perturbations ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") we add one extra degree of freedom to the generally-correlated ADI+CDI model by
allowing primordial tensor perturbations (assuming the inflationary consistency relation for the tilt of the
tensor power spectrum and its running). Our main goal is to explore a possible degeneracy between tensor modes and
negatively-correlated CDI modes, tending to tilt the large-scale temperature spectrum in opposite directions. In
Sect. [11.5](#S11.SS5 "11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"), we update the constraints on three special cases motivated by axion or curvaton
scenarios.

The goal of this analysis is to test the hypothesis of adiabaticity and establish the robustness of the base
$\Lambda$CDM model against different assumptions concerning initial conditions (Sect. [11.3](#S11.SS3 "11.3 Robustness of the determination of standard cosmological parameters ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")).
Adiabaticity is also an important probe of the inflationary paradigm, since any significant detection of
isocurvature modes would exclude the possibility that all perturbations in the Universe emerged from quantum
fluctuations of a single inflaton field, which can excite only one degree of freedom, the curvature (i.e.,
adiabatic) perturbation.1818
18
However, conversely, if no isocurvature was detected, the fluctuations could
have been seeded either by single- or multi-field inflation, since later processes easily wash out inflationary
isocurvature perturbations ([Mollerach, 1990](#bib.bib176); [Weinberg, 2004](#bib.bib258); [Beltrán et al., 2005](#bib.bib26)). An example is the curvaton
model, in which perturbations can be purely isocurvature at Hubble exit during inflation, but are later converted
to ADI if the curvaton or curvaton particles ([Linde & Mukhanov, 2006](#bib.bib153)) dominate the energy density at the curvaton’s
decay. For a summary of various curvaton scenarios, see, e.g., [Gordon & Lewis (2003)](#bib.bib103).

In this section, theoretical predictions were obtained with a modified version of the CAMB code (version
Jul14) while parameter exploration was performed with the MultiNest nested sampling algorithm.

(a)

(b)

(c)

Figure 44: 68 % and 95 % CL constraints on the primordial perturbation power in general mixed ADI+CDI (a),
ADI+NDI (b), and ADI+NVI (c) models at two scales, $k\_{1}=0.002\thinspace\mathrm{Mpc}^{-1}$ (1) and
$k\_{2}=0.100\thinspace\mathrm{Mpc}^{-1}$ (2), for Planck TT+lowP (grey regions highlighted by dotted contours), Planck TT+lowP+lensing (blue), and Planck TT,TE,EE+lowP (red). In the first panels, we also show contours for the pure
adiabatic base $\Lambda$CDM model with the corresponding colours of solid lines.

Figure 45: Constraints on the primordial isocurvature fraction, $\beta\_{\mathrm{iso}}$, at
$k\_{\mathrm{low}}=0.002\thinspace\mathrm{Mpc}^{-1}$ and $k\_{\mathrm{high}}=0.100\thinspace\mathrm{Mpc}^{-1}$, the primordial
correlation fraction, $\cos\Delta$, the adiabatic spectral index, $n\_{\mathcal{R}\mathcal{R}}$, the isocurvature spectral
index, $n\_{\mathcal{I}\mathcal{I}}$, and the correlation spectral index, $n\_{\mathcal{R}\mathcal{I}}=(n\_{\mathcal{R}\mathcal{R}}+n\_{\mathcal{I}\mathcal{I}})/2$, with Planck TT+lowP data (dashed curves) and TT,TE,EE+lowP data (solid curves), for the
generally-correlated mixed ADI+CDI (black), ADI+NDI (red), and ADI+NVI (blue) models. All these parameters are
derived, and the distributions shown here result from a uniform prior on the primary
parameters, as detailed in Eqs. ([137](#S11.E137 "In 11.1 Parameterization and notation ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"))–([139](#S11.E139 "In 11.1 Parameterization and notation ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")). However, the effect of the non-flat
derived-parameter priors is negligible for all parameters except for $n\_{\mathcal{I}\mathcal{I}}$ (and $n\_{\mathcal{R}\mathcal{I}}$)
where the prior biases the distribution toward one. With TT+lowP, the flatness of
$\beta\_{\mathrm{iso}}(k\_{\mathrm{high}})$ in the CDI case up to a “threshold” value of about 0.5 is a
consequence of the $(k/k\_{\mathrm{eq}})^{-2}$ damping of its transfer function as explained in
Footnote [17](#footnote17 "footnote 17 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation").

Figure 46: Constraints on the fractional contribution of the adiabatic ($\mathcal{R}\mathcal{R}$), isocurvature ($\mathcal{I}\mathcal{I}$), and correlation ($\mathcal{R}\mathcal{I}$) components to the CMB temperature variance in various multipole ranges,
as defined in Eq. ([144](#S11.E144 "In 11.1 Parameterization and notation ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")), with Planck TT+lowP data (dashed curves) and with Planck TT,TE,EE+lowP data (solid
curves). These are shown for the generally-correlated mixed ADI+CDI (black), ADI+NDI (red), or ADI+NVI (blue) models.

### 11.1 Parameterization and notation

A general mixture of the adiabatic mode and one isocurvature mode
is described by the
three functions
${\mathcal{P}}\_{\mathcal{R}\mathcal{R}}(k),$
${\mathcal{P}}\_{\mathcal{I}\mathcal{I}}(k),$
and ${\mathcal{P}}\_{\mathcal{R}\mathcal{I}}(k)$
describing the curvature, isocurvature, and cross-correlation power spectra, respectively. Our sign conventions are
such that positive values for ${\mathcal{P}}\_{\mathcal{R}I}$ correspond to a positive contribution of the cross-correlation
term to the Sachs-Wolfe component of the total temperature spectrum.

As in [205](#bib.bib205), we specify the amplitudes at two
scales $k\_{1}<k\_{2}$ and assume power-law behaviour, so that

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\begin{split}{\mathcal{P}}\_{\mathrm{ab}}(k)=&\exp\Biggl[\left(\frac{\ln(k)-\ln(k\_{2})}{\ln(k\_{1})-\ln(k\_{2})}\right)\ln\left({\mathcal{P}}^{(1)}\_{\mathrm{ab}}\right)\\ &\qquad+\left(\frac{\ln(k)-\ln(k\_{1})}{\ln(k\_{2})-\ln(k\_{1})}\right)\ln\left({\mathcal{P}}^{(2)}\_{\mathrm{ab}}\right)\Biggr],\end{split}$ | |  | (135) |

where ${\mathrm{a,b}}={\mathcal{I}},{\mathcal{R}}$ and
${\mathcal{I}}={\mathcal{I}}\_{{\mathrm{CDI}}}$, ${\mathcal{I}}\_{{\mathrm{NDI}}},$ or ${\mathcal{I}}\_{{\mathrm{NVI}}}$.
We set $k\_{1}=0.002\thinspace\textrm{Mpc}^{-1}$
and $k\_{2}=0.100\thinspace\textrm{Mpc}^{-1},$ so that
$[k\_{1},k\_{2}]$ spans most of the range constrained by the Planck data.
The positive definiteness of the initial condition matrix imposes a constraint on its elements at
any value of $k$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left[\mathcal{P}\_{\mathrm{ab}}(k)\right]^{2}\leq\mathcal{P}\_{\mathrm{aa}}(k)\mathcal{P}\_{\mathrm{bb}}(k)\thinspace.$ |  | (136) |

We take uniform priors on the positive amplitudes,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(1)},\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(2)}$ | $\displaystyle\in(10^{-9},\thinspace 10^{-8})\thinspace,$ |  | (137) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)},\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(2)}$ | $\displaystyle\in(0,\thinspace 10^{-8})\thinspace.$ |  | (138) |

The correlation spectrum can be positive or negative. For $\mathrm{a}\neq\mathrm{b}$ we apply a uniform
prior at large scales (at $k\_{1}$):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}\_{\mathrm{ab}}^{(1)}\in(-10^{-8},\thinspace 10^{-8})\thinspace,$ |  | (139) |

but reject all parameter combinations violating the constraint in Eq. ([136](#S11.E136 "In 11.1 Parameterization and notation ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")).
To ensure that Eq. ([136](#S11.E136 "In 11.1 Parameterization and notation ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")) holds for all $k$, we restrict ourselves to a
scale-independent correlation fraction:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\cos\Delta\_{\mathrm{ab}}\equiv\frac{\mathcal{P}\_{\mathrm{ab}}}{\left(\mathcal{P}\_{\mathrm{aa}}\mathcal{P}\_{\mathrm{bb}}\right)^{1/2}}\in(-1,1)\thinspace.$ |  | (140) |

Thus ${\mathcal{P}}\_{\mathrm{ab}}^{(2)}$ is a derived parameter1919
19
Given our ansatz of power-law primordial spectra,
if we treated $\mathcal{P}\_{\mathrm{ab}}^{(2)}$ as an independent parameter as we do with $\mathcal{P}\_{\mathrm{ab}}^{(1)}$,
Eq. ([136](#S11.E136 "In 11.1 Parameterization and notation ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")) would always be violated somewhere outside $[k\_{1},k\_{2}]$. In [205](#bib.bib205), we dealt with this by assuming that when maximal (anti-)correlation is reached at some scale, the correlation remains at ($-$)100 % beyond this scale. This introduced a kink in the cross-correlation spectrum, located at a different wavenumber for each model.
Even though the range $[k\_{1},k\_{2}]$ was chosen to span most of the observable scales, this kink tended to impact
the smallest (or largest) multipole values used in the analysis.
In particular, the kink helped fit the dip in the temperature angular power in the multipole range $\ell\approx 10$–$40$.
given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}\_{\mathrm{ab}}^{(2)}=\mathcal{P}\_{\mathrm{ab}}^{(1)}\frac{\left(\mathcal{P}\_{\mathrm{aa}}^{(2)}\mathcal{P}\_{\mathrm{bb}}^{(2)}\right)^{1/2}}{\left(\mathcal{P}\_{\mathrm{aa}}^{(1)}\mathcal{P}\_{\mathrm{bb}}^{(1)}\right)^{1/2}},$ |  | (141) |

which in terms of spectral indices is equivalent to

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n\_{\mathrm{ab}}=\frac{1}{2}(n\_{\mathrm{aa}}+n\_{\mathrm{bb}})\thinspace.$ |  | (142) |

The conservative baseline likelihood is Planck TT+lowP. The results
obtained with Planck TT,TE,EE+lowP should be interpreted with caution
because the data used in the 2015 release are known to contain some low
level systematics, in particular arising from $T$-to-$E$ leakage, and it is possible
that such systematics may be fit by the isocurvature auto-correlation and
cross-correlation templates. (See [Planck Collaboration
XIII (2016)](#bib.bib218) for a detailed discussion.)

In what follows, we quote our results in terms of derived parameters identical to those in
[205](#bib.bib205). We define the primordial isocurvature fraction as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\beta\_{\mathrm{iso}}(k)=\frac{\mathcal{P}\_{\mathcal{II}}(k)}{\mathcal{P}\_{\mathcal{RR}}(k)+\mathcal{P}\_{\mathcal{II}}(k)}\thinspace.$ |  | (143) |

Unlike the primordial correlation fraction $\cos\Delta$ defined in Eq. ([140](#S11.E140 "In 11.1 Parameterization and notation ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")), $\beta\_{\mathrm{iso}}$ is scale-dependent in the general case. We present bounds on this quantity at $k\_{\mathrm{low}}=k\_{1}$, $k\_{\mathrm{mid}}=0.050\thinspace\mathrm{Mpc}^{-1}$, and $k\_{\mathrm{high}}=k\_{2}$.

We report constraints on the relative adiabatic ($\mathrm{ab}=\mathcal{R}\mathcal{R}$),
isocurvature ($\mathrm{ab}=\mathcal{I}\mathcal{I}$), and correlation ($\mathrm{ab}=\mathcal{R}\mathcal{I}$)
components according to their contribution to the
observed CMB temperature variance in various multipole ranges:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\alpha\_{\mathrm{ab}}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})\equiv$ | $\displaystyle\frac{(\Delta T)^{2}\_{\mathrm{ab}}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})}{(\Delta T)^{2}\_{\mathrm{tot}}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})},$ |  | (144) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${(\Delta T)^{2}\_{\mathrm{ab}}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})}=\sum\_{\ell=\ell\_{\mathrm{min}}}^{\ell\_{\mathrm{max}}}(2\ell+1)C\_{\mathrm{ab},\ell}^{TT}.$ |  | (145) |

The ranges considered are $(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})=(2,20)$, $(21,200),$ $(201,2500)$, and
$(2,2500)$, where the last range describes the total contribution to the observed CMB temperature variance.
Here $\alpha\_{\mathcal{RR}}$ measures the adiabaticity of the temperature angular power
spectrum, a value of unity meaning “fully adiabatic initial conditions.” Values less than unity mean that some of
the observed power comes from the isocurvature or correlation spectrum, while values larger than unity mean that
some of the power is “cancelled” by a negatively-correlated isocurvature contribution. The relative non-adiabatic
contribution can be expressed as $\alpha\_{\text{non-adi}}\equiv 1-\alpha\_{\mathcal{RR}}=\alpha\_{\mathcal{II}}+\alpha\_{\mathcal{RI}}$.

Figure 47: Constraints on the primordial correlation fraction, $\cos\Delta$, in the mixed ADI+CDI model with Planck TT+lowP data (dashed black curve) compared to the case where Planck lowP data are not used, but replaced by a
Gaussian prior $\tau=0.078\pm 0.019$ (dashed red curve). The same exercise is repeated with Planck TT,TE,EE data
(solid curves) demonstrating that to a great extent the preferred value of $\cos\Delta$ is driven by the
high-$\ell$ data.

### 11.2 Results for generally-correlated adiabatic and one isocurvature mode (CDI, NDI, or NVI)

Results are reported as 2D and 1D marginalized posterior probability
distributions. Numerical 95 % CL intervals or upper bounds are tabulated
in
Table [16](#S11.T16 "Table 16 ‣ 11.5.3 Fully anticorrelated ADI+CDI (“Curvaton II”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation").

Figure [44](#S11.F44 "Figure 44 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") shows the Planck 68 % and 95 % CL contours for various 2D combinations
of the primordial adiabatic and isocurvature amplitude parameters at large scales ($k\_{1}=0.002\thinspace\textrm{Mpc}^{-1}$) and small scales ($k\_{2}=0.100\thinspace\textrm{Mpc}^{-1}$) for (a) the generally-correlated
ADI+CDI, (b) ADI+NDI, and (c) ADI+NVI models. Overall, the results using Planck TT+lowP are consistent with the
nominal mission results in [205](#bib.bib205), but slightly tighter. In the first panels of
Figs. [44](#S11.F44 "Figure 44 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") (a), (b), and (c) we also show the constraints on the curvature perturbation
power in the pure adiabatic case. Comparing the generally-correlated isocurvature case to the pure adiabatic case
with the same data combination summarizes neatly what the data tell us about the initial conditions. If the
contours in the $\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(1)}$-$\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(2)}$ plane were shifted
significantly relative to the pure adiabatic case, the missing power could come either from the isocurvature
and postive correlation contributions, or the extra adiabatic power could be cancelled by a negative correlation
contribution. We can see that these shifts are small. The low-$\ell$ temperature data continue to mildly
favour a negative correlation (see in particular the bottom middle panel for each of the three models), since
compared to the prediction of the best-fit adiabatic base $\Lambda$CDM model, the $TT$ angular power at multipoles
$\ell\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}40$ is somewhat low. But the dotted grey shaded contours in the three middle top panels show that
for Planck TT+lowP, the posterior peaks at values ($\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)}$,$\thinspace\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(2)}$) entirely consistent with $(0,\thinspace 0)$, i.e., the pure adiabatic case is preferred. The best-fit values of
($\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)}$,$\thinspace\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(2)}$) are
($1.4\times 10^{-11}$,$\thinspace 4.7\times 10^{-13}$) for CDI, ($1.2\times 10^{-12}$,$\thinspace 4.6\times 10^{-10}$) for NDI, and
($1.6\times 10^{-12}$,$\thinspace 2.3\times 10^{-10}$) for NVI, while ($\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(1)}$,$\thinspace\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(2)}$) $\approx$ ($2.4\times 10^{-9}$,$\thinspace 2.1\times 10^{-9}$). It
may appear from the bottom-centre panels of Fig. [44](#S11.F44 "Figure 44 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") that there is nonzero posterior
probability for $\mathcal{P}\_{\mathcal{R}\mathcal{I}}^{(1)}\neq 0$ when $\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)}=0$, which would
violate the positivity constraint, Eq. ([136](#S11.E136 "In 11.1 Parameterization and notation ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")). However, the leftmost pixels of the plots are
actually evaluated at values of $\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)}$ large enough
that the constraint is satisfied.

Including the Planck lensing likelihood does not significantly affect the
non-adiabatic primordial powers, except for tightening the constraints on the adiabatic
power (see the blue versus black contours in the first panels of Figs. [44](#S11.F44 "Figure 44 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") (a), (b),
and (c)). Including the lensing ($C\_{\ell}^{\phi\phi}$) likelihood constrains the optical depth $\tau$ more tightly
than the high-$\ell$ temperature and low-$\ell$ polarization alone ([Planck Collaboration
XIII, 2016](#bib.bib218)). As there is a strong
degeneracy between $\tau$ and the primordial (adiabatic) perturbation power $\mathcal{P}\_{\mathcal{R}\mathcal{R}}$ (denoted
in the other sections of this paper by $A\_{\mathrm{s}}$), it is natural that adding the lensing data leads to
stronger constraints on $\mathcal{P}\_{\mathcal{R}\mathcal{R}}$. Moreover, replacing the low-$\ell$ likelihood Planck lowP by
Planck lowP+WP constrains $\tau$ better ([Planck Collaboration
XIII, 2016](#bib.bib218)). In the ADI+CDI case the effect of
this replacement was very similar to adding the Planck lensing data (see also
Table [16](#S11.T16 "Table 16 ‣ 11.5.3 Fully anticorrelated ADI+CDI (“Curvaton II”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")). Although the Planck lensing data do not directly constrain the isocurvature
contribution,2020
20
This is expected, since already with Planck TT+lowP, the allowed
isocurvature fraction is so small that it hardly affects the lensing potential spectrum, $C\_{\ell}^{\phi\phi}$. they can
shift and tighten the constraints on some derived isocurvature parameters by affecting the favoured values of the
standard parameters (present even in the pure adiabatic model). However this effect is small as confirmed in
Table [16](#S11.T16 "Table 16 ‣ 11.5.3 Fully anticorrelated ADI+CDI (“Curvaton II”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"). Therefore, in the figures we do not show 1D posteriors of the derived isocurvature
parameters for Planck TT+lowP+lensing, since they would be (almost) indistinguishable from Planck TT+lowP, as
we see in Fig. [44](#S11.F44 "Figure 44 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") for the primary non-adiabatic parameters.

In contrast, the high-$\ell$ *polarization* data significantly tighten the bounds on isocurvature and
cross-correlation parameters, as seen by comparing the dotted grey and red contours in
Fig. [44](#S11.F44 "Figure 44 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"). The significant negative correlation previously allowed by the temperature data
in the ADI+CDI and ADI+NDI models is now disfavoured. This is also clearly visible in the 1D posteriors of
primordial and observable isocurvature and cross-correlation fractions shown, respectively, in
Fig. [45](#S11.F45 "Figure 45 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") and [46](#S11.F46 "Figure 46 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"). Note how the $\cos\Delta$ and
$\alpha\_{\mathcal{R}\mathcal{I}}$ parameters are driven towards zero by the inclusion of the high-$\ell$ TE,EE data (from
the dashed to the solid lines) in the ADI+CDI and ADI+NDI cases. We also observed
that when the lowP data are
replaced by a simple Gaussian prior on the reionization optical depth ($\tau=0.078\pm 0.019$), the trend is
similar. The high-$\ell$ ($\ell\geq 30$) Planck TT data allow a large negative correlation, while the high-$\ell$
Planck TE,EE data prefer positive correlation. This is clearly seen in Fig. [47](#S11.F47 "Figure 47 ‣ 11.1 Parameterization and notation ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") for the
ADI+CDI case. The best-fit values show an even more dramatic effect. We find $\cos\Delta=-0.55$ with TT+lowP,
and $+0.15$ with TT,TE,EE+lowP.

Hence there is a competition between the temperature and polarization data that balances out and yields almost
symmetric results about zero correlation (except in the ADI+NVI case). The isocurvature auto-correlation amplitude
is also strongly reduced, especially in the ADI+CDI case. The best-fit values are slightly offset from
$(\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)},\thinspace\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(2)})=(0,0)$, but the pure adiabatic model
still lies inside the 68 % CL (for ADI+CDI and ADI+NDI) or 95 % CL (for ADI+NVI) regions. In summary, the
high-$\ell$ polarization data exhibit a strong preference for adiabaticity, although one should keep in mind the
possibility of unaccounted systematic effects in the polarization data, possibly leading to artificially
strong constraints. For example, the tendency for polarization to shift the constraints towards positive
correlation may be due to particular systematic effects that mimic modified acoustic peak structure, as we
discussed in Sect. [11.1](#S11.SS1 "11.1 Parameterization and notation ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation").

Figure 48: Constraints on selected “standard” cosmological parameters with Planck TT+lowP data
for the generally-correlated ADI+CDI (black), ADI+NDI (red), and ADI+NVI (blue) models compared to the pure
adiabatic case (ADI, green dashed curves).

Figure 49: Dependence of the determination of the adiabatic spectral index $n\_{\mathcal{R}\mathcal{R}}$ (called $n\_{\mathrm{s}}$ in the other sections of this paper) on the primordial isocurvature fraction $\beta\_{\mathrm{iso}}$ and correlation fraction $\cos\Delta$, with Planck TT+lowP data (dashed contours) and with Planck TT,TE,EE+lowP data (shaded regions).

We also performed a parameter extraction with the Planck TT,TE,EE+lowP+lensing data, but this combination did
not provide interesting new constraints. We found
only a tightening of bounds on the standard adiabatic parameters as in
the Planck TT+lowP+lensing case.

We provide 95 % CL upper limits or ranges for $\beta\_{\mathrm{iso}}$, $\cos\Delta$, and $\alpha\_{\mathcal{R}\mathcal{R}}$
in Table [16](#S11.T16 "Table 16 ‣ 11.5.3 Fully anticorrelated ADI+CDI (“Curvaton II”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"). With Planck TT+lowP, the constraints on the non-adiabatic contribution to the
temperature variance, $1-\alpha\_{\mathcal{R}\mathcal{R}}(2,2500)$, are ($-1.5$ %, 1.9 %), ($-4.0$ %, 1.4 %),
and ($-2.3$ %, 2.4 %) in the ADI+CDI, ADI+NDI, and ADI+NVI cases, respectively.2121
21
These numbers
can be positive even if the correlation contribution is negative. This happens whenever
$\alpha\_{\mathcal{I}\mathcal{I}}>|\alpha\_{\mathcal{R}\mathcal{I}}|$. Thus in the observational non-adiabaticity estimator $1-\alpha\_{\mathcal{R}\mathcal{R}}(2,2500)$, the negative numbers are not as pronounced as in the primordial correlation
fraction $\cos\Delta$. With Planck TT,TE,EE+lowP these tighten to (0.1 %, 1.5 %), ($-0.1$ %, 2.2 %),
and ($-2.0$ %, 0.8 %). In the ADI+CDI case, zero is not in the 95 % CL interval, but this should not be
considered a detection of non-adiabaticity. For example, as mentioned above, $(\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)},\thinspace\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(2)})=(0,0)$ is in the 68 % CL region, and the best-fit values are
($\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)}$,$\thinspace\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(2)}$) =
($1.0\times 10^{-13}$,$\thinspace 3.5\times 10^{-9}$). Moreover, the improvement in $\chi^{2}$ with respect to the adiabatic
model is only 5.3 with 3 extra parameters, so this is not a significant improvement of fit. Indeed, for all
generally-correlated mixed models the improvement in $\chi^{2}$ is very small. In particular, with Planck TT+lowP
it does not even exceed the number of extra degrees of freedom, which is three (see Table [16](#S11.T16 "Table 16 ‣ 11.5.3 Fully anticorrelated ADI+CDI (“Curvaton II”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")).

Finally, we checked whether there is any Bayesian evidence for the presence of generally-correlated adiabatic and
isocurvature modes. In all cases and with all data combinations studied, the Bayesian model comparison supports
the null hypothesis, i.e., adiabaticity. Indeed, the logarithm of the evidence ratio is $\ln B=\ln(P\_{\mathrm{ISO}}/P\_{\mathrm{ADI}})<-5$ (i.e., odds of much greater than 150:1 in
favour of pure adiabaticity within Planck’s accuracy and given the parameterization and prior ranges used in our
analysis), except for ADI+NDI with Planck TT+lowP+lensing, for which the evidence ratio is slightly larger,
$-4.6$, corresponding to odds of 1:100 for the ADI+NDI model compared to the pure adiabatic model.

### 11.3 Robustness of the determination of standard cosmological parameters

Another outcome of our analysis is the robustness of the determination of the standard cosmological
parameters against assumptions on initial conditions. Figure [48](#S11.F48 "Figure 48 ‣ 11.2 Results for generally-correlated adiabatic and one isocurvature mode (CDI, NDI, or NVI) ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") shows the 1D marginalized
posteriors for several cosmological parameters (not all independent of each other) with the Planck TT+lowP data
alone. For the first time, we observe that in the presence of one generally-correlated isocurvature mode (CDI,
NDI, or NVI), predictions for these parameters remain very stable with respect to the pure adiabatic case. Except
for the ADI+NDI case, the posteriors neither broaden nor shift significantly. A small broadening is only observed
in the sound horizon angle $\theta\_{\mathrm{MC}}$, which is naturally the most sensitive parameter to
tiny disturbances of the acoustic peak structure. In the ADI+NDI case, the peak of the posterior distribution for
some parameters shifts slightly, but the largest shift (for $\Omega\_{\mathrm{c}}h^{2}$) is less than 1 $\sigma$.

It is striking that a scale-invariant adiabatic spectrum ($n\_{\mathcal{R}\mathcal{R}}=1$) is
excluded at many $\sigma$ even when isocurvature modes are allowed: at 4.7$\thinspace\sigma$ (ADI+CDI), 5.0$\thinspace\sigma$
(ADI+NDI), and 5.4$\thinspace\sigma$ (ADI+NVI). This illustrates how much the
constraining power of the CMB has improved. With WMAP data, there was still a strong degeneracy between,
for example, the
primordial isocurvature fraction and the adiabatic spectral index ([Valiviita & Giannantonio, 2009](#bib.bib253); [Savelainen et al., 2013](#bib.bib235)).
This degeneracy nearly disappears with Planck TT+lowP, and even more so with Planck TT,TE,EE+lowP, as shown in
the upper panel of Fig. [49](#S11.F49 "Figure 49 ‣ 11.2 Results for generally-correlated adiabatic and one isocurvature mode (CDI, NDI, or NVI) ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"). Contours in the ($n\_{\mathcal{R}\mathcal{R}}$, $\cos\Delta$) space also
shrink considerably, with some correlation remaining between these parameters in the ADI+CDI and ADI+NVI cases
(Fig. [49](#S11.F49 "Figure 49 ‣ 11.2 Results for generally-correlated adiabatic and one isocurvature mode (CDI, NDI, or NVI) ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"), lower panel).

### 11.4 CDI and primordial tensor perturbations

A primordial tensor contribution adds extra temperature angular power at low multipoles, where the adiabatic base
$\Lambda$CDM model predicts slightly more power than seen in the data. Hence allowing for a nonzero
tensor-to-scalar ratio $r$ might tighten the constraints on positively-correlated isocurvature, but degrade them
in negatively-correlated models. We test how treating $r$ as a free parameter affects the constraints on
isocurvature and how allowing for the generally-correlated CDI mode affects the constraints
on $r$. These cases are denoted as “CDI+$r$.” For comparison, we examine the pure adiabatic case in the same
parameterization, and call it “ADI+$r$.” We also consider another approach where we fix $r=0.1$. These cases are
named “CDI+$r$$=$0.1” and “ADI+$r$$=$0.1.”

In the pure adiabatic case (where the curvature and tensor perturbations stay constant on super-Hubble scales), the
primordial $r$ is the same as the tensor-to-scalar ratio at the Hubble radius exit of perturbations during
inflation, which we call $\tilde{r}$. However, in the presence of an isocurvature component, ${\mathcal{P}}\_{\mathcal{R}\mathcal{R}}$ is not constant in time even on super-Hubble scales ([García-Bellido & Wands, 1996](#bib.bib95)). Instead, the isocurvature component may source ${\mathcal{P}}\_{\mathcal{R}\mathcal{R}}$, for example if the background trajectory in the field space is curved between Hubble exit
and the end of inflation
([Langlois, 1999](#bib.bib138); [Langlois & Riazuelo, 2000](#bib.bib139); [Gordon et al., 2001](#bib.bib104); [Amendola et al., 2002](#bib.bib7)).
As a result, we will have at the primordial time ${\mathcal{P}}\_{\mathcal{R}\mathcal{R}}=\tilde{\mathcal{P}}\_{\mathcal{R}\mathcal{R}}/(1-\cos^{2}\Delta)$, where $\tilde{\mathcal{P}}\_{\mathcal{R}\mathcal{R}}$ is the curvature power
at Hubble exit. That is, by the primordial time the curvature perturbation power is larger than at the Hubble
radius exit time ([Bartolo et al., 2001](#bib.bib19); [Wands et al., 2002](#bib.bib257); [Byrnes & Wands, 2006](#bib.bib47)). Thus we find a relation
([Savelainen et al., 2013](#bib.bib235); [Valiviita et al., 2012](#bib.bib254); [Kawasaki & Sekiguchi, 2008](#bib.bib127)):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $r=\left(1-\cos^{2}\!\Delta\right)\tilde{r}\thinspace,$ |  | (146) |

i.e., the tensor-to-scalar ratio at the primordial time ($r$) is smaller than the ratio at the Hubble radius exit
time ($\tilde{r}$).

The derivation of Eq. ([146](#S11.E146 "In 11.4 CDI and primordial tensor perturbations ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")) assumes that the adiabatic and isocurvature perturbations are
uncorrelated at Hubble radius exit ($\cos\tilde{\Delta}=0$), and that all the possible primordial correlation
($\cos\Delta\neq 0$) appears from the evolution of super-Hubble perturbations between Hubble exit and the
primordial time. This is true to leading order in the slow-roll parameters, but inflationary models that break
slow roll might produce perturbations that are strongly correlated already at the Hubble radius exit time.
In these cases the correlation would depend on the details of the particular model, such as the detailed shape of
the potential and the interactions of the fields. However, a generic prediction of slow-roll inflation is that, at
Hubble radius exit, the cross-correlation $\tilde{\mathcal{P}}\_{\mathcal{R}\mathcal{I}}$ is very weak, and indeed is of the
order of the slow-roll parameters compared to the auto-correlations $\tilde{\mathcal{P}}\_{\mathcal{R}\mathcal{R}}$ and
$\tilde{\mathcal{P}}\_{\mathcal{I}\mathcal{I}}$ ([Byrnes & Wands, 2006](#bib.bib47), see, e.g.,). Thus, for slow-roll models,
$|\cos\tilde{\Delta}|={\mathcal{O}}\mbox{(slow-roll parameters)}\ll 1$.

In our analysis, we fix the tensor spectral index by the leading-order inflationary consistency relation, which
now reads ([Wands et al., 2002](#bib.bib257))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n\_{\mathrm{t}}=-\frac{\tilde{r}}{8}=-\frac{r}{8\left(1-\cos^{2}\Delta\right)}\thinspace.$ |  | (147) |

Assuming a uniform prior for $r$ would lead to huge negative $n\_{\mathrm{t}}$ whenever $\cos^{2}\Delta$ was close to one.
Therefore, when studying the CDI+$r$ case we assume a uniform prior on $\tilde{r}$ at $k=0.05\thinspace$Mpc-1 ([Savelainen et al., 2013](#bib.bib235), for
details, see).

Surprisingly, allowing for a generally-correlated CDI mode (i.e., three extra parameters) hardly changes the
constraints on $r$ from those obtained in the pure adiabatic model. In Fig. [50](#S11.F50 "Figure 50 ‣ 11.4 CDI and primordial tensor perturbations ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") we demonstrate this
in a “standard” plot of $r\_{0.002}$ versus adiabatic spectral index.

From Table [16](#S11.T16 "Table 16 ‣ 11.5.3 Fully anticorrelated ADI+CDI (“Curvaton II”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") we notice that, with Planck TT+lowP and TT,TE,EE+lowP, fixing $r$ to 0.1
tightens constraints on the primordial isocurvature fraction at large scales. This is as we expected, since both
tensor and isocurvature perturbations add power at low $\ell$, and the data do not prefer this.
However, the shapes
of the tensor spectrum and correlation spectrum are such that negative correlation cannot efficiently cancel the
unwanted extra power over all scales produced by tensor perturbations (at $\ell\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}70$). Therefore, the
correlation fraction $\cos\Delta$ is almost unaffected. However, when we allow $r$ to vary, the cancelation
mechanism works to some degree when using Planck TT+lowP data, leading to more negative $\cos\Delta$ than
without $r$: with varying $r$ we have $\cos\Delta$ in the range ($-0.43$, 0.20), while without $r$ it is in
($-0.30$, 0.20), at 95 % CL. As there is now some cancellation of power at large scales, the constraint on
$\beta\_{\mathrm{iso}}(k\_{\mathrm{low}})$ weakens slightly from 0.041 without $r$ to 0.043 with $r$. On the other
hand, the high-$\ell$ polarization data constrain the correlation to be so close to zero that with Planck TT,TE,EE+lowP the results for $\cos\Delta$ with and without $r$ are almost identical.

The mean value of $\cos\Delta$ in the CDI+$r$ cases is $-0.071$ (TT+lowP) and $-0.076$ (TT,TE,EE+lowP). Therefore,
$1-\cos^{2}\Delta\approx 0.99$, and so we do not expect a large difference between the primordial $r$ and the
Hubble radius exit value $\tilde{r}$. The smallness of the difference is evident in Table [15](#S11.T15 "Table 15 ‣ 11.4 CDI and primordial tensor perturbations ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"). To
summarize, CDI hardly affects the determination of $r$ from the Planck data, and allowing for tensor
perturbations hardly affects the determination of the non-adiabaticity parameters.

Figure 50:  68 % and 95 % CL constraints on the primordial adiabatic spectral index $n\_{\mathcal{R}\mathcal{R}}$ and the primordial tensor-to-scalar ratio $r$ (more accurately, in the CDI+$r$ model, the primordial tensor-to-curvature power ratio) at $k=0.002\thinspace$Mpc-1. Filled contours are for generally-correlated ADI+CDI and solid contours for the pure adiabatic model.

|  |  |  |  |
| --- | --- | --- | --- |
|  |  |  |  |
|  |  |  |  |
| Model (and data) | $r\_{0.05}$ | $\tilde{r}\_{0.05}$ | $C\_{10}^{\mathrm{tens}}/C\_{10}^{\mathrm{scal}}$ |
| CDI+$r$ (TT+lowP) | 0.086 | 0.089 | 0.041 |
| ADI+$r$ (TT+lowP) | 0.101 | 0.101 | 0.048 |
| CDI+$r$ (TT,TE,EE+lowP) | 0.092 | 0.092 | 0.043 |
| ADI+$r$ (TT,TE,EE+lowP) | 0.094 | 0.094 | 0.044 |

Table 15: 95 % CL upper bounds on the tensor-to-scalar ratio (actually
the tensor-to-curvature power ratio) at the primordial time, $r$, and
earlier, at the Hubble radius exit time during inflation, $\tilde{r}$, at
$k=0.05\thinspace$Mpc-1. (In the pure adiabatic case $r$ and $\tilde{r}$
are equal.) In the last column $C\_{10}^{\mathrm{tens}}/C\_{10}^{\mathrm{scal}}$ indicates the tensor contribution to the
temperature angular power at $\ell=10$ relative to the temperature
power from scalar perturbations ($C\_{10}^{\mathrm{scal}}=C\_{10}^{\mathcal{R}\mathcal{R}}+C\_{10}^{\mathcal{R}\mathcal{I}}+C\_{10}^{\mathcal{I}\mathcal{R}}+C\_{10}^{\mathcal{I}\mathcal{I}}$).

### 11.5 Special CDI cases

Figure 51:  Uncorrelated ADI+CDI with $n\_{\mathcal{I}\mathcal{I}}=1$ (“axion”).

Next we study three one-parameter CDI extensions to the adiabatic model. In all these extensions the isocurvature
mode modifies only the largest angular scales, since we either fix $n\_{\mathcal{I}\mathcal{I}}$ to unity (“axion”) or to
the adiabatic spectral index (“curvaton I/II”). As can be seen from Fig. [43](#S11.F43 "Figure 43 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"), the
polarization $E$ mode at multipoles $\ell\gtrsim 200$ will not be significantly affected by this type of CDI
mode. Therefore, these models are much less sensitive to residual systematic effects in the high-$\ell$
polarization data than the generally correlated models.

#### 11.5.1 Uncorrelated ADI+CDI (“Axion”)

We start with an uncorrelated mixture of adiabatic and CDI modes ($\mathcal{P}\_{\mathcal{R}\mathcal{I}}=0$), and make the
additional assumption that $\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(2)}=\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)}$, i.e., we assume
unit isocurvature spectral index, $n\_{\mathcal{I}\mathcal{I}}=1$. Constraints in the ($n\_{\mathcal{R}\mathcal{R}}$,$\thinspace\beta\_{\mathrm{iso}}$) plane are presented in Fig. [51](#S11.F51 "Figure 51 ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"). This model is the only case for which
our new results do not improve over bounds from [205](#bib.bib205). At
$k\_{\mathrm{mid}}=0.050\thinspace\mathrm{Mpc}^{-1}$, we find $\beta\_{\mathrm{iso}}<0.038$ (95 % CL, TT,TE,EE+lowP; see
Table [16](#S11.T16 "Table 16 ‣ 11.5.3 Fully anticorrelated ADI+CDI (“Curvaton II”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")), compared with $\beta\_{\mathrm{iso}}<0.039$ using Planck 2013 and low-$\ell$ WMAP
data. This is not surprising, since fixing $n\_{\mathcal{I}\mathcal{I}}$ to unity implies that bounds are dominated by
measurements on very large angular scales, $\ell\lesssim 30$, as can easily be understood from
Fig. [43](#S11.F43 "Figure 43 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"). Hence the results are insensitive to the addition of better high-$\ell$
temperature data, or new high-$\ell$ polarization data.

We summarized in [205](#bib.bib205) why an uncorrelated CDI mode with $n\_{\mathcal{I}\mathcal{I}}\approx 1$ can
be produced in axion models, under a number of restrictive assumptions: the Peccei-Quinn symmetry should be broken
before inflation; it should not be restored by quantum fluctuations of the inflaton or by thermal fluctuations
when the Universe reheats; and axions produced through the misalignement angle should contribute to a sizable
fraction (or all) of the dark matter. Under all of these assumptions, limits on $\beta\_{\mathrm{iso}}$ can be used
to infer a bound on the energy scale of inflation, using equation (73) of [205](#bib.bib205). This bound is
strongest when all the dark matter is assumed to be in the form of axions. In that case, the limit on
$\beta\_{\mathrm{iso}}(k\_{\mathrm{mid}})$ for Planck TT,TE,EE+lowP gives

|  |  |  |  |
| --- | --- | --- | --- |
|  | $H\_{\mathrm{inf}}<0.86\times 10^{7}\thinspace\mathrm{GeV}\left(\frac{f\_{a}}{10^{11}\thinspace\mathrm{GeV}}\right)^{0.408}\quad\mbox{ (95\thinspace\% CL)}\thinspace,$ |  | (148) |

where $H\_{\mathrm{inf}}$ is the expansion rate at Hubble radius exit of the scale corresponding to
$k\_{\mathrm{mid}}=0.050\thinspace\mathrm{Mpc}^{-1}$ and $f\_{a}$ is the Peccei-Quinn symmetry breaking energy scale.

#### 11.5.2 Fully correlated ADI+CDI (“Curvaton I”)

Another interesting special case of mixed adiabatic and CDI (or BDI) perturbations is a model where these
perturbations are primordially fully correlated and their power spectra have the same shape. These cases are
obtained by setting $\mathcal{P}\_{\mathcal{R}\mathcal{I}}^{(1)}=(\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(1)}\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)})^{1/2}$, which, by condition ([141](#S11.E141 "In 11.1 Parameterization and notation ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")), implies that the corresponding statement holds at scale
$k\_{2}$ and indeed at any scale. In addition, we set $\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(2)}=(\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(2)}/\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(1)})\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)}$, i.e., $n\_{\mathcal{I}\mathcal{I}}=n\_{\mathcal{R}\mathcal{R}}$. From this it follows that $\beta\_{\mathrm{iso}}$ is scale independent. Therefore, this model
has only one primary non-adiabaticity parameter, $\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)}$.

A physically motivated example of this type of model is the curvaton model
([Mollerach, 1990](#bib.bib176); [Linde & Mukhanov, 1997](#bib.bib154); [Enqvist & Sloth, 2002](#bib.bib78); [Moroi & Takahashi, 2001](#bib.bib177); [Lyth & Wands, 2002](#bib.bib158); [Lyth et al., 2003](#bib.bib157)) with the following assumptions. (1)
The average curvaton field value, $\bar{\chi}\_{\ast}$, is sufficiently below the Planck mass when
cosmologically interesting scales exit the Hubble radius during
inflation. (2) At Hubble radius exit, the curvature perturbation from the
inflaton is negligible compared to the perturbation caused by the curvaton. (3) The same is true
for any inflaton decay products after reheating. This means that, after reheating, the Universe is homogeneous,
except for the spatially varying entropy (i.e., isocurvature perturbation) due to the curvaton field
perturbations. (4) Later, CDM is created from the curvaton decay and baryon number after curvaton decay. This
corresponds to case 4 presented in [Gordon & Lewis (2003)](#bib.bib103). (5) The curvaton contributes a significant amount to the energy density of the
Universe at the time of the curvaton’s decay to CDM, i.e., the curvaton decays late enough. (6) The energy density of
curvaton particles possibly produced during reheating should be sufficiently low
([Bartolo & Liddle, 2002](#bib.bib17); [Linde & Mukhanov, 2006](#bib.bib153)). (7) The small-scale variance of curvaton perturbations, $\Delta\_{s}^{2}=\langle\delta\chi^{2}\rangle\_{s}/\bar{\chi}^{2}$, is negligible, so that it does not significantly contribute to the average energy density
on CMB scales; see equation (102) in [Sasaki et al. (2006)](#bib.bib234). The last two conditions are necessary in order to have an almost-Gaussian curvature
perturbation, as required by the Planck observations. Namely, if they are not valid, a large $f\_{\mathrm{NL}}^{\mathrm{local}}$ follows, as discussed below.
Indeed, the conditions (6) and (7) are related, since curvaton particles would add a homogeneous component to
the average energy density on large scales, and hence we can describe their effect by $\Delta\_{s}^{2}=\rho\_{\chi,\thinspace\mathrm{particles}}/\rho\_{\bar{\chi},\thinspace\mathrm{field}}$, where
$\rho\_{\bar{\chi},\thinspace\mathrm{field}}$ is the average energy density of the classical curvaton field on large scales; see equation (98) in [Sasaki et al. (2006)](#bib.bib234).
Then the total energy density carried by the curvaton will be $\bar{\rho}\_{\chi}=\rho\_{\bar{\chi},\thinspace\mathrm{field}}+\rho\_{\chi,\thinspace\mathrm{particles}}$.

The amount of isocurvature and non-Gaussianity present after curvaton decay depends on the “curvaton decay fraction”,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $r\_{D}=\frac{3\bar{\rho}\_{\chi}}{3\bar{\rho}\_{\chi}+4\bar{\rho}\_{\mathrm{radiation}}},$ |  | (149) |

evaluated at curvaton decay time. If conditions (6) and (7) do not hold, then the isocurvature perturbation
disappears.2222
22
Indeed, if curvaton particles are produced during reheating,
they can be expected to survive and outweigh other particles
at the moment of curvaton decay, but by how much depends on the details of the model.
As the curvaton field (during its oscillations) and the curvaton particles have the same equation of
state and they decay simultaneously, no isocurvature perturbations are produced.

Figure 52:  Fully correlated ADI+CDI with $n\_{\mathcal{I}\mathcal{I}}=n\_{\mathcal{R}\mathcal{R}}$ (“curvaton I”). Since the spectral
indices are equal, the primordial isocurvature fraction $\beta\_{\mathrm{iso}}$ is scale independent.

Figure 53:  Fully anticorrelated ADI+CDI with $n\_{\mathcal{I}\mathcal{I}}=n\_{\mathcal{R}\mathcal{R}}$ (“curvaton II”).

The curvaton scenario presented here is one of the simplest to test against observations. It should be noted that
at least the conditions (1)–(5) listed at the beginning of this subsection should be satisfied simultaneously.
Indeed, if we relax some of these conditions, almost any type of correlation can be produced. For example, the
relative correlation fraction can be written as
$\cos\Delta=\sqrt{\lambda/(1+\lambda)}$,
where $\lambda=(8/9)r\_{D}^{2}\epsilon\_{\ast}(M\_{\mathrm{Pl}}/\bar{\chi}\_{\ast})^{2}$. Therefore, the model is fully correlated only if $\lambda\gg 1$. If the slow-roll parameter
$\epsilon\_{\ast}$ is very close to zero or the curvaton field value $\bar{\chi}\_{\ast}$ is large compared to the Planck
mass, this model leads to almost uncorrelated perturbations.

As seen in Fig. [52](#S11.F52 "Figure 52 ‣ 11.5.2 Fully correlated ADI+CDI (“Curvaton I”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") and Table [16](#S11.T16 "Table 16 ‣ 11.5.3 Fully anticorrelated ADI+CDI (“Curvaton II”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"), the upper bound on the primordial
isocurvature fraction in the fully correlated ADI+CDI model weakens slightly when we add the Planck lensing data
to Planck TT+lowP, whereas adding high-$\ell$ TE,EE tightens the upper bound moderately. With all of these three
data combinations, the pure adiabatic model gives an equally good best-fit $\chi^{2}$ as the fully-correlated
ADI+CDI model. Bayesian model comparison strengthens the conclusion that the data disfavour this model with
respect to the pure adiabatic model.

The isocurvature fraction is connected to the curvaton decay fraction, Eq. ([149](#S11.E149 "In 11.5.2 Fully correlated ADI+CDI (“Curvaton I”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")), by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\beta\_{\mathrm{iso}}\approx\frac{9(1-r\_{D})^{2}}{r\_{D}^{2}+9(1-r\_{D})^{2}}$ |  | (150) |

([Gordon & Lewis, 2003](#bib.bib103), see case 4 in).
Reading the constraints on $\beta\_{\mathrm{iso}}$ from Table [16](#S11.T16 "Table 16 ‣ 11.5.3 Fully anticorrelated ADI+CDI (“Curvaton II”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"), we can convert them into
constraints on $r\_{D}$ and further into the non-Gaussianity parameter assuming a quadratic potential for the
curvaton and instantaneous decay2323
23
It should be noted that, in particular, in the older curvaton literature
a formula $f\_{\mathrm{NL}}^{\mathrm{local}}=\frac{5}{4r\_{D}}$ is often quoted or utilized. This result, which follows from considering only squares of first order perturbations, is valid when $r\_{D}$ is close to zero, i.e., when $f\_{\mathrm{NL}}^{\mathrm{local}}$ is very large. However, when $r\_{D}$ is close to unity or $f\_{\mathrm{NL}}^{\mathrm{local}}\lesssim 10$, which is the case with the Planck measurements, the second and third terms in Eq. ([151](#S11.E151 "In 11.5.2 Fully correlated ADI+CDI (“Curvaton I”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")) are vitally important. These follow from genuine second order perturbation theory calculations. Coincidentally, if one erroneously uses the expression
$\frac{5}{4r\_{D}}$ in the limit $r\_{D}\rightarrow 1$, one obtains a result $+5/4$, whereas the correct formula ([151](#S11.E151 "In 11.5.2 Fully correlated ADI+CDI (“Curvaton I”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")), with $\Delta\_{s}^{2}=0$, leads to $-5/4$, when $r\_{D}\rightarrow 1$.
([Sasaki et al., 2006](#bib.bib234)):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\_{\mathrm{NL}}^{\mathrm{local}}=(1+\Delta\_{s}^{2})\frac{5}{4r\_{D}}-\frac{5}{3}-\frac{5r\_{D}}{6}.$ |  | (151) |

If conditions (6) and (7) hold, i.e., $\Delta\_{s}^{2}=0$, as implicitly assumed, e.g., in [Bartolo et al. (2004a)](#bib.bib20); [Bartolo et al. (2004b)](#bib.bib21), then the smallest possible value of
$f\_{\mathrm{NL}}^{\mathrm{local}}$ is $-5/4$, which is obtained when $r\_{D}=1$, and
Eqs. ([150](#S11.E150 "In 11.5.2 Fully correlated ADI+CDI (“Curvaton I”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")) and ([151](#S11.E151 "In 11.5.2 Fully correlated ADI+CDI (“Curvaton I”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")) yield for the various
Planck data sets (at 95 % CL):2424
24
However, if $\Delta\_{s}^{2}$ was non-negligible, then all the
constraints on $f\_{\mathrm{NL}}^{\mathrm{local}}$ would shift upward. For example, with $\Delta\_{s}^{2}=1$,
our constraints on $\beta\_{\mathrm{iso}}$ would translate to $0\leq f\_{\mathrm{NL}}^{\mathrm{local}}\lesssim 0.03$.
On the other hand, the Planck constraint of $f\_{\mathrm{NL}}^{\mathrm{local}}$ can be converted to an upper bound
$\Delta\_{s}^{2}=\rho\_{\chi,\thinspace\mathrm{particles}}/\rho\_{\bar{\chi},\thinspace\mathrm{field}}<8.5$ (95 % CL from $T$ only) as shown in [Planck Collaboration
XVII (2016)](#bib.bib221).

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | TT+lowP: | $\displaystyle\beta\_{\mathrm{iso}}<0.0018\Rightarrow 0.9860<r\_{D}\leq 1$ |  |  | (152) |
|  |  | $\displaystyle\Rightarrow-1.250\leq f\_{\mathrm{NL}}^{\mathrm{local}}<-1.220\thinspace,$ |  |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | TT+lowP+lensing: | $\displaystyle\beta\_{\mathrm{iso}}<0.0022\Rightarrow 0.9845<r\_{D}\leq 1$ |  |  | (153) |
|  |  | $\displaystyle\Rightarrow-1.250\leq f\_{\mathrm{NL}}^{\mathrm{local}}<-1.217\thinspace,$ |  |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | TT,TE,EE+lowP: | $\displaystyle\beta\_{\mathrm{iso}}<0.0013\Rightarrow 0.9882<r\_{D}\leq 1$ |  |  | (154) |
|  |  | $\displaystyle\Rightarrow-1.250\leq f\_{\mathrm{NL}}^{\mathrm{local}}<-1.225\thinspace.$ |  |  |

Thus the results for the simplest curvaton model remain unchanged from those presented
in [205](#bib.bib205), i.e., in order to produce almost purely adiabatic perturbations, the
curvaton should decay when it dominates the energy density of the Universe ($r\_{D}>0.98$), and the
non-Gaussianity parameter is constrained to close to its smallest possible value
($-5/4<f\_{\mathrm{NL}}^{\mathrm{local}}<-1.21$), which is consistent with the result
$f\_{\mathrm{NL}}^{\mathrm{local}}=2.5\pm 5.7$ (68 % CL, from $T$ only) found in [Planck Collaboration
XVII (2016)](#bib.bib221).

#### 11.5.3 Fully anticorrelated ADI+CDI (“Curvaton II”)

The curvaton scenario or some other mechanism could also produce 100 % anticorrelated perturbations, with
$n\_{\mathcal{I}\mathcal{I}}=n\_{\mathcal{R}\mathcal{R}}$. The constraints in the ($n\_{\mathcal{R}\mathcal{R}},\beta\_{\mathrm{iso}}$) plane
are presented in Fig. [53](#S11.F53 "Figure 53 ‣ 11.5.2 Fully correlated ADI+CDI (“Curvaton I”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"). Examples of this kind of model are provided by cases 2, 3, and 6 in
[Gordon & Lewis (2003)](#bib.bib103). These lead to a fixed, large amount of isocurvature, e.g., in case 2 to
$\beta\_{\mathrm{iso}}=9/10$, and are hence excluded by the data at very high significance. However, case 9 in
[Gordon & Lewis (2003)](#bib.bib103), with a suitable $r\_{D}$ (i.e., $r\_{D}>R\_{\mathrm{c}}$, where $R\_{\mathrm{c}}=\rho\_{\mathrm{c}}/(\rho\_{\mathrm{c}}+\rho\_{\mathrm{b}})$), leads to fully anticorrelated perturbations and might provide a good fit to
the data. In this case CDM is produced by curvaton decay while baryons are created earlier from inflaton decay products
and do not carry a curvature perturbation. We obtain a very
similar expression to Eq. ([150](#S11.E150 "In 11.5.2 Fully correlated ADI+CDI (“Curvaton I”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")), namely

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\beta\_{\mathrm{iso}}\approx\frac{9(1-r\_{D}/R\_{\mathrm{c}})^{2}}{r\_{D}^{2}+9(1-r\_{D}/R\_{\mathrm{c}})^{2}}\thinspace.$ |  | (155) |

We convert this approximately to a constraint on $r\_{D}$ by fixing $R\_{\mathrm{c}}$ to its best-fit value, $R\_{\mathrm{c}}=0.8437$ (Planck TT+lowP), within this model. The results for the various Planck data sets are:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | TT+lowP: | $\displaystyle\beta\_{\mathrm{iso}}<0.0064\Rightarrow 0.8437<r\_{D}<0.8632$ |  |  | (156) |
|  |  | $\displaystyle\Rightarrow-0.9379<f\_{\mathrm{NL}}^{\mathrm{local}}<-0.8882\thinspace,$ |  |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | TT+lowP+lensing: | $\displaystyle\beta\_{\mathrm{iso}}<0.0052\Rightarrow 0.8437<r\_{D}<0.8612$ |  |  | (157) |
|  |  | $\displaystyle\Rightarrow-0.9329<f\_{\mathrm{NL}}^{\mathrm{local}}<-0.8882\thinspace,$ |  |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | TT,TE,EE+lowP: | $\displaystyle\beta\_{\mathrm{iso}}<0.0008\Rightarrow 0.8437<r\_{D}<0.8505$ |  |  | (158) |
|  |  | $\displaystyle\Rightarrow-0.9056<f\_{\mathrm{NL}}^{\mathrm{local}}<-0.8882\thinspace.$ |  |  |

After all the tests conducted in this section, both for the generally correlated CDI, NDI, and NVI cases as well
as for the special CDI cases, we conclude that, within the spatially flat base $\Lambda$CDM model, the initial
conditions of perturbations are consistent with the hypothesis of pure adiabaticity, a conclusion that is also
overwhelmingly supported by the Bayesian model comparison. Moreover, [Planck Collaboration
XVII (2016)](#bib.bib221) report a null
detection of *isocurvature non-Gaussianity*, with polarization improving constraints significantly.

|  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Model (and data) | $100\beta\_{\mathrm{iso}}(k\_{\mathrm{low}})$ | $100\beta\_{\mathrm{iso}}(k\_{\mathrm{mid}})$ | $100\beta\_{\mathrm{iso}}(k\_{\mathrm{high}})$ | $100\cos\Delta$ | $100\alpha\_{\mathcal{R}\mathcal{R}}{(2,2500)}$ | $\Delta n$ | $\Delta\chi^{2}$ | $\ln B$ |
|  |  |  |  |  |  |  |  |  |
| General models: |  |  |  |  |  |  |  |  |
| CDI (TT+lowP) | 04.1 | 35.4 | 56.9 | [$-30$:20] | [98.1:101.5] | 3 | $-2.1$ | $-8.8$ |
| CDI (TT+lowP+WP) | 04.2 | 35.5 | 57.2 | [$-31$:23] | [97.9:101.4] | 3 | $-1.8$ | $-9.1$ |
| CDI (TT,TE,EE+lowP) | 02.0 | [3.4:28.1] | [3.1:51.8] | [0$-6$:20] | [98.5:099.9] | 3 | $-5.3$ | $-8.8$ |
| CDI (TT,TE,EE+lowP+WP) | 02.1 | [2.3:28.4] | [2.6:52.1] | [0$-7$:21] | [98.5:099.9] | 3 | $-5.5$ | $-8.2$ |
| CDI (TT+lowP+lensing) | 04.5 | 37.9 | 59.4 | [$-28$:17] | [98.1:101.1] | 3 | $-1.2$ | $-8.8$ |
|  |  |  |  |  |  |  |  |  |
| NDI (TT+lowP) | 14.3 | 22.4 | 27.4 | [$-33$:01] | [98.6:104.0] | 3 | $-2.0$ | $-5.3$ |
| NDI (TT,TE,EE+lowP) | 07.3 | [3.4:19.3] | [3.5:26.7] | [0$-9$:10] | [97.8:100.1] | 3 | $-5.5$ | $-5.5$ |
| NDI (TT+lowP+lensing) | 15.8 | [1.4:24.1] | [0.3:28.4] | [$-32$:00] | [98.6:104.0] | 3 | $-2.8$ | $-4.6$ |
|  |  |  |  |  |  |  |  |  |
| NVI (TT+lowP) | 08.3 | [0.1:10.2] | 11.9 | [$-26$:$\phantom{-}6$] | [97.6:102.3] | 3 | $-2.8$ | $-6.3$ |
| NVI (TT,TE,EE+lowP) | 07.4 | [0.9:07.4] | [0.4:08.8] | [$-22$:$-4$] | [99.2:102.0] | 3 | $-6.2$ | $-6.5$ |
| NVI (TT+lowP+lensing) | 09.7 | [0.4:11.6] | 13.1 | [$-23$:$\phantom{-}7$] | [97.1:102.0] | 3 | $-2.5$ | $-6.5$ |
|  |  |  |  |  |  |  |  |  |
| General models + $r$: |  |  |  |  |  |  |  |  |
| CDI+r=0.1 (TT+lowP) | 03.4 | 38.7 | 63.9 | [$-33$:24] | [98.1:101.4] | 3 | $-5.4$ | $-8.9$ |
| CDI+r=0.1 (TT,TE,EE+lowP) | 01.6 | [4.4:31.7] | [6.9:59.2] | [0$-6$:22] | [98.6:099.9] | 3 | $-6.3$ | $-8.1$ |
| CDI+r (TT+lowP) | 04.3 | 34.9 | 56.2 | [$-43$:20] | [97.9:102.4] | 3 | $-3.3$ | $-7.7$ |
| CDI+r (TT,TE,EE+lowP) | 01.7 | [3.9:29.0] | [5.8:53.8] | [0$-5$:21] | [98.6:099.9] | 3 | $-5.1$ | $-7.2$ |
|  |  |  |  |  |  |  |  |  |
| Special CDI cases: |  |  |  |  |  |  |  |  |
| Uncorrelated, $n\_{\mathcal{II}}=1$ |  |  |  |  |  |  |  |  |
| “axion” (TT+lowP) | 03.3 | 3.7 | 3.8 | $\phantom{-}\phantom{00}0$ | [98.5:100] | 1 | $\phantom{-}0.0$ | $-5.2$ |
| “axion” (TT,TE,EE+lowP) | 03.5 | 3.8 | 3.9 | $\phantom{-}\phantom{00}0$ | [98.4:100] | 1 | $-0.2$ | $-4.9$ |
| “axion” (TT+lowP+lensing) | 03.9 | 4.3 | 4.4 | $\phantom{-}\phantom{00}0$ | [98.3:100] | 1 | $\phantom{-}0.0$ | $-5.0$ |
| Fully correlated, $n\_{\mathcal{II}}=n\_{\mathcal{RR}}$ |  |  |  |  |  |  |  |  |
| “curvaton I” (TT+lowP) | 00.18 | 0.18 | 0.18 | $\phantom{-}100$ | [97.5:100.0] | 1 | $-0.1$ | $-8.1$ |
| “curvaton I” (TT,TE,EE+lowP) | 00.13 | 0.13 | 0.13 | $\phantom{-}100$ | [97.8:099.9] | 1 | $\phantom{-}0.0$ | $-7.8$ |
| “curvaton I” (TT+lowP+lensing) | 00.22 | 0.22 | 0.22 | $\phantom{-}100$ | [97.3:099.7] | 1 | $\phantom{-}0.0$ | $-8.5$ |
| Fully anti-correlated, $n\_{\mathcal{II}}=n\_{\mathcal{RR}}$ |  |  |  |  |  |  |  |  |
| “curvaton II” (TT+lowP) | 00.64 | 0.64 | 0.64 | $-100$ | [100.5:105.1] | 1 | $-1.1$ | $-5.4$ |
| “curvaton II” (TT,TE,EE+lowP) | 00.08 | 0.08 | 0.08 | $-100$ | [100.1:101.8] | 1 | $\phantom{-}0.0$ | $-8.9$ |
| “curvaton II” (TT+lowP+lensing) | 00.52 | 0.52 | 0.52 | $-100$ | [100.4:104.4] | 1 | $-0.6$ | $-6.3$ |

Table 16:  Constraints on mixed adiabatic
and isocurvature models. For each mixed model,
we report 95% CL bounds on the fractional primordial contribution of
isocurvature modes at three comoving wavenumbers ($k\_{\mathrm{low}}=0.002\penalty\$Mpc-1,
$k\_{\mathrm{mid}}=0.050\penalty\$Mpc${}^{-1},$ and $k\_{\mathrm{high}}=0.100\penalty\$Mpc-1), as well as the scale-independent primordial
correlation fraction, $\cos\Delta$.
The fractional adiabatic contribution to the observed temperature
variance is denoted by $\alpha\_{\mathcal{R}\mathcal{R}}(2,2500)$, and from this
the nonadiabatic contribution can be calculated as
$\alpha\_{\text{non-adi}}=1-\alpha\_{\mathcal{R}\mathcal{R}}(2,2500)$. The number of
extra parameters compared with the
corresponding pure adiabatic model is denoted by $\Delta n$, and
$\Delta\chi^{2}$ is the difference between the $\chi^{2}$ of the
best-fitting mixed and pure adiabatic models. (A negative $\Delta\chi^{2}$
means that the mixed model is a better fit to the data.) In the last
column we give the difference between the logarithm of Bayesian
evidences. (A negative $\ln B=\ln(P\_{\mathrm{ISO}}/P\_{\mathrm{ADI}})$
means that Bayesian model comparison disfavours the mixed model.
With our settings of MultiNest the uncertainty in these numbers is about $\pm$0.5.)

## 12 Statistical anisotropy and inflation

A key prediction of standard inflation, which in the present context includes
all single field models of inflation as well as many multi-field models, is that
the stochastic process generating the primordial cosmological
perturbations is completely characterized
by its power spectrum, constrained by statistical isotropy to depend only
on the multipole number $\ell.$ This statement applies at least to the accuracy
that can be probed using the CMB given the limitations imposed by cosmic
variance, since all models exhibit some level of non-Gaussianity.
Nevertheless, more general
Gaussian stochastic processes can be envisaged for which one or more special
directions on the sky are singled out, so that the expectation values for the
temperature multipoles take the form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left<a\_{\ell m}^{T}\penalty\ \left({a\_{\ell^{\prime}m^{\prime}}^{T}}\right)^{\*}\right>=C\_{\ell m;\ell^{\prime}m^{\prime}}^{TT},$ |  | (159) |

rather than the very special form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left<a\_{\ell m}^{T}\penalty\ \left(a\_{\ell^{\prime}m^{\prime}}^{T}\right)^{\*}\right>=C\_{\ell}^{TT}\thinspace\delta\_{\ell,\ell^{\prime}}\thinspace\delta\_{m,m^{\prime}},$ |  | (160) |

which is the only possibility consistent with statistical isotropy.

The most general form for a Gaussian stochastic process on the sphere violating
the hypothesis of statistical isotropy in Eq. ([159](#S12.E159 "In 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation")) is too broad
to be useful, given that we have only one sky to analyse. For $\ell<\ell\_{\mathrm{max}},$
there are $O(\ell\_{\mathrm{max}}^{2})$ multipole expansion coefficients,
compared with $O(\ell\_{\mathrm{max}}^{4})$
model parameters. Therefore, in order to make some progress on testing the hypothesis
of statistical isotropy, we must restrict ourselves to examining only the simplest
models violating statistical isotropy, for which the available data can establish
meaningful constraints and for
which one can hope to find a simple theoretical motivation.

### 12.1 Asymmetry: observations versus model building

In one simple class of statistically anisotropic models, we start with
a map produced by a process respecting statistical isotropy, which becomes modulated by another
field in the following manner to produce the observed sky map:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\delta T\_{\mathrm{sky}}(\mathbf{\hat{\Omega}})=\Bigl(1+M(\mathbf{\hat{\Omega}})\Bigr)\penalty\ \delta T\_{\text{s-i}}(\mathbf{\hat{\Omega}}),$ |  | (161) |

where $\mathbf{\hat{\Omega}}$ denotes a position on the celestial sphere and
$\delta T\_{\text{s-i}}(\mathbf{\hat{\Omega}})$ is the outcome of the
underlying statistically isotropic process before
modulation. Roughly speaking, where the modulating field $M(\mathbf{\hat{\Omega}})$ is positive,
power on scales smaller than the scale of variation of $M(\mathbf{\hat{\Omega}})$ is
enhanced, whereas where $M(\mathbf{\hat{\Omega}})$ is negative, power is suppressed.
We refer to this as a “power asymmetry.” If $M(\mathbf{\hat{\Omega}})=A\mathbf{\hat{d}}\cdot\mathbf{\hat{\Omega}}$, we have a model of dipolar
modulation with amplitude $A$ and direction $\mathbf{\hat{d}}$, but higher-order or mixed
modulation may also be considered, such as a quadrupole modulation or modulation by a
scale-invariant field
$M(\mathbf{\hat{\Omega}})$, to name just a few special cases.
Alternatively, and more closely tied to physical models, we can consider
modulations of the position- or $k$-space fluctuations.

In [Planck Collaboration
XXIII (2014)](#bib.bib206) and [Planck Collaboration
XVI (2016)](#bib.bib220), the details of constructing
efficient estimators for statistical anisotropy, in particular in the presence
of realistic data involving sky cuts and possibly incompletely removed foreground
contamination, are considered in depth. In addition, the question of the
statistical significance of any detected “anomalies” from the expectations of
base $\Lambda$CDM is examined in detail. Importantly, in the absence of a particular
inflationary model for such an observed anomaly, the significance should be corrected
for the “multiplicity of tests” that could have resulted in
similarly-significant detections (i.e., for the “look elsewhere effect”), although applying
such corrections can be ambiguous. In this paper, however, we consider only forms
of statistical anisotropy that are predicted by specific inflationary models, and
hence such corrections will not be necessary.

Several important questions can be posed regarding the link between statistical isotropy
and inflation. In particular, we can ask the following questions. (1) Does
a statistically significant finding
of a violation of statistical isotropy falsify inflation? (2) If not, what sort of non-standard
inflation could produce the required departure from statistical isotropy? (3) What other perhaps
non-inflationary models could also account for the violation of statistical isotropy?
In this section, we begin to address these questions by assessing the viability of an
inflationary model for dipolar asymmetry, as well as by placing new limits on the
presence of quadrupolar power asymmetry.

For the case of the observed dipolar asymmetry examined in detail in [Planck Collaboration
XVI (2016)](#bib.bib220), there
are two aspects that make inflationary model building difficult. First is the problem of
obtaining a significant amplitude of dipole modulation. In [Planck Collaboration
XVI (2016)](#bib.bib220)
the asymmetry was found to have amplitude $A\approx 6$–7 % on scales
$2\leq\ell\leq 64$. This compares with the expected value of $A=2.9\thinspace\%$ on
these scales due to cosmic variance in statistically isotropic skies. One basic
strategy for incorporating the violation of statistical isotropy into inflation is to
consider some form of multi-field inflation and use one of the directions orthogonal to
the direction of slow roll as the field responsible for the modulation. Obtaining
the required modulation is problematic because most extra fields in multi-field
inflation become disordered in a nearly scale-invariant
way, just like the fluctuations in the field parallel to the direction of slow roll. What is
needed resembles a pure gradient with no fluctuations of shorter wavelength. In
[Liddle & Cortês (2013)](#bib.bib147) it was
proposed that such a field could be produced using the supercurvature mode of open inflation.
(See, however, the discussion in [Kanno et al. (2013)](#bib.bib126).) Also,
in order to respect the $f\_{\mathrm{NL}}$ constraints, one must avoid that the
modulating field leave a direct imprint on the temperature anisotropy.

The second aspect which makes model building difficult for dipolar asymmetry is
that the measured amplitude is strongly scale dependent, and on scales
$\ell\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$>$\hss}\lower 5.16663pt\hbox{$\sim$}}}100$ no significant detection of a dipolar modulation amplitude is
made ([Planck Collaboration
XVI, 2016](#bib.bib220)), once our proper motion has been taken into account
([Planck Collaboration
XXVII, 2014](#bib.bib210)). On the other hand, the simplest models are
scale-free and produce statistical anisotropy of the type described by the ansatz
in Eq. ([161](#S12.E161 "In 12.1 Asymmetry: observations versus model building ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation")), for which the bulk of the statistical weight
should be detected at the resolution of the survey. To resolve this difficulty,
[Erickcek et al. (2009)](#bib.bib79) proposed modulating CDI fluctuations generated within the
framework of a curvaton scenario, because, unlike adiabatic
perturbations, CDI perturbations entering the Hubble radius before last scattering
contribute negligibly to the CMB fluctuations (recall Fig. [43](#S11.F43 "Figure 43 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")).

The situation for the quadrupolar power asymmetry is different from the dipolar
case in that no detection is currently claimed. Model building is easier than
the dipolar case since no pure gradient modes are required, but also more
difficult in that anisotropy during inflation is needed.
While the isotropy of the recent expansion of the Universe (i.e., since the CMB fluctuations
were first imprinted) is tightly constrained, bounds on a possible anisotropic expansion
at early times are much weaker.
[Ackerman et al. (2007)](#bib.bib2) proposed
using constraints on the quadrupolar statistical anisotropy of the CMB to probe the isotropy
of the expansion during inflation—that is, during the epoch when the perturbations
now seen in the CMB first exited the Hubble radius.
Assuming an anisotropic expansion during inflation, [Ackerman et al. (2007)](#bib.bib2) computed its
impact on the three-dimensional power spectrum on super-Hubble scales
by integrating the mode functions for the perturbations
during inflation and beyond. Several sources of such anisotropy have been proposed, such as vector fields
during inflation
([Dimastrogiovanni et al., 2010](#bib.bib66); [Soda, 2012](#bib.bib241); [Maleknejad et al., 2013](#bib.bib162); [Schmidt & Hui, 2013](#bib.bib236); [Bartolo et al., 2013](#bib.bib18); [Naruko et al., 2014](#bib.bib185)),
or an inflating solid or elastic medium ([Bartolo et al., 2013](#bib.bib18)).

### 12.2 Scale-dependent modulation and idealized estimators

The ansatz in Eq. ([161](#S12.E161 "In 12.1 Asymmetry: observations versus model building ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation")) expressed in angular space
may be rewritten in terms of the multipole expansion and generalized to
include scale-dependent modulation by means of Wigner $3j$
symbols:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left<a\_{\ell m}^{T}\penalty\ a\_{\ell^{\prime}m^{\prime}}^{T}\right>=\sum\_{L=0}^{\infty}\sum\_{M=-L}^{+L}C\_{\ell;\ell^{\prime};L,M}^{TT}\left(\begin{matrix}\ell&\ell^{\prime}&L\cr m&m^{\prime}&M\end{matrix}\right).$ |  | (162) |

Because of the symmetry of the left-hand side, the coefficients $C\_{\ell;\ell^{\prime};L,M}^{TT}$
acquire a phase $(-1)^{\ell+\ell^{\prime}+L}$ under interchange of $\ell$ and $\ell^{\prime}.$
This is the most general form consistent with the hypothesis of Gaussianity.
The usual isotropic power spectrum, which is the generic prediction
of simple models of inflation, includes only the $L=0$ term, where
$C\_{\ell;\ell^{\prime};0,0}^{TT}=C\_{\ell}^{TT}$ and the Wigner $3j$ symbol provides the
$\delta\_{\ell,\ell^{\prime}}\delta\_{m,m^{\prime}}$ factor. The coefficients $C\_{\ell;\ell^{\prime};L,M}^{TT}$
with $L>0$ introduce statistical anisotropy.

If we assume that there is a common vector (corresponding to $L=1$
on the celestial sphere) that defines the direction of the anisotropy of the
power spectrum for all the terms of $L=1$, we may adopt a more restricted
ansatz for the bipolar modulation, so that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{\ell;\ell^{\prime};1,M}^{TT}=C^{1}\_{\ell,\ell^{\prime}}X\_{M}^{(1)},$ |  | (163) |

where we assume that $X\_{M}$ is normalized (i.e., $\sum\_{M}{X\_{M}}{X\_{M}}^{\*}=1)$. In such a model, supposing that
$C^{1}\_{\ell,\ell^{\prime}}$ is theoretically determined, but the orientation of the unit vector
$X\_{M}$ is random and isotropically distributed on the celestial sphere, we may
construct the following quadratic estimator for the direction:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle X\_{M}^{(L)}=$ | $\displaystyle\sum\_{\ell,m}\sum\_{\ell^{\prime},m^{\prime}}\frac{w\_{\ell,\ell^{\prime};L}}{(2L+1)(C\_{\ell})^{1/2}\penalty\ (C\_{\ell^{\prime}})^{1/2}}$ |  | (164) |
|  | $\displaystyle\times$ | $\displaystyle\left(\begin{matrix}\ell&\ell^{\prime}&L\cr m&m^{\prime}&M\end{matrix}\right)\penalty\ \penalty\ a\_{\ell m}^{T}\penalty\ a\_{\ell^{\prime}m^{\prime}}^{T},$ |  |

where the weights for the unbiased minimum variance estimator are given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $w\_{\ell,\ell^{\prime};L}=C\_{\ell,\ell^{\prime}}^{L}\left(\sum\_{\ell,\ell^{\prime}}C\_{\ell,\ell^{\prime}}^{L}\right)^{-1}.$ |  | (165) |

This construction, which for the $L=1$ case may be found in
[Moss et al. (2011)](#bib.bib182) and [Planck Collaboration
XVI (2016)](#bib.bib220),
may be readily generalized to $L>1$ in the above way.

### 12.3 Constraining inflationary models for dipolar asymmetry

In this section, we confront with Planck data the modulated curvaton
model of [Erickcek et al. (2009)](#bib.bib79), which attempts to explain the observed large-scale
power asymmetry via a gradient in the background curvaton field. In this model,
the curvaton decays after CDM freeze out, which results in a
nearly-scale-invariant isocurvature component between CDM and radiation.
In the viable version of this scenario, the curvaton contributes
negligibly to the CDM density. A long-wavelength fluctuation in the
curvaton field initial value $\sigma\_{\*}$ is assumed, with amplitude
$\Delta\sigma\_{\*}$ across our observable volume. This modulates the curvaton
isocurvature fluctuations according to $S\_{\sigma\gamma}\approx 2\delta\sigma\_{\*}/\sigma\_{\*}$. The curvaton produces all of the final
CDI fluctuations, which are nearly scale invariant, as well as a component of the
final adiabatic fluctuations. Hence both of these components will be modulated,
and the parameter space of the model will be constrained by observations of
the power asymmetry on large and small scales, as well as the full-sky
CDI fraction. In practice, the very tight constraints on
small scale power asymmetry obtained in [Planck Collaboration
XVI (2016)](#bib.bib220) imply a small
curvaton adiabatic component, which implies that the CDI and adiabatic
fluctuations are only weakly correlated. This model easily satisfies
constraints due to the CMB dipole, quadrupole, and non-Gaussianity
([Erickcek et al., 2009](#bib.bib79)).

There are two main parameters that we constrain for this model.
First, the fraction of adiabatic fluctuations due to the curvaton $\xi$
is defined as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\xi\equiv\frac{\Sigma\_{\sigma}^{2}{\mathcal{P}}\_{\sigma}}{{\mathcal{P}}\_{{\mathcal{R}}\_{\mathrm{inf}}}+\Sigma\_{\sigma}^{2}{\mathcal{P}}\_{\sigma}}.$ |  | (166) |

Here, ${\mathcal{P}}\_{{\mathcal{R}}\_{\mathrm{inf}}}$ and ${\mathcal{P}}\_{\sigma}$ are the
inflaton and curvaton primordial power spectra, respectively, and $\Sigma\_{\sigma}$
is the coupling from curvaton isocurvature to adiabatic fluctuations.
(Up to a sign, $\xi$ is equal to the correlation parameter.) Next, the
coupling of curvaton to CDI,
$M\_{{\mathrm{CDI}}\sigma}$, is determined by the constant $\kappa\equiv M\_{{\mathrm{CDI}}\sigma}/R\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$>$\hss}\lower 5.16663pt\hbox{$\sim$}}}-1$, where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $R\equiv\frac{3\Omega\_{\sigma}}{4\Omega\_{\gamma}+3\Omega\_{\sigma}+3\Omega\_{\mathrm{CDM}}}$ |  | (167) |

and all density parameters are evaluated just prior to curvaton decay.
The isocurvature fraction can be written in terms of these two parameters by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\beta\_{\mathrm{iso}}=\frac{9\kappa^{2}\xi}{1+9\kappa^{2}\xi}.$ |  | (168) |

These parameters determine the modulation of the CMB temperature fluctuations
via $\Delta C\_{\ell}/C\_{\ell}=2K\_{\ell}\Delta\sigma\_{\*}/\sigma\_{\*}$, where
([Erickcek et al., 2009](#bib.bib79))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $K\_{\ell}\equiv\xi\frac{C\_{\ell}^{\mathrm{ad}}+9\kappa^{2}C\_{\ell}^{\mathrm{iso}}+3\kappa C\_{\ell}^{\mathrm{cor}}}{C\_{\ell}^{\mathrm{ad}}+\xi\left(9\kappa^{2}C\_{\ell}^{\mathrm{iso}}+3\kappa C\_{\ell}^{\mathrm{cor}}\right)}.$ |  | (169) |

Here $C\_{\ell}^{\mathrm{ad}}$, $C\_{\ell}^{\mathrm{iso}}$, and $C\_{\ell}^{\mathrm{cor}}$
are the adiabatic, CDI, and correlated power spectra calculated for unity
primordial spectra.

Note that this modulated curvaton model contains some simple special
cases. For $\kappa=0$, we have a purely adiabatic (i.e., scale-invariant)
modulation. This is equivalent to a modulation of the scalar amplitude,
$A\_{\mathrm{s}}$. On the other hand, if we take the limit $\kappa\to\infty$,
with fixed $\kappa^{2}\xi$ (i.e., with fixed isocurvature fraction
$\beta\_{\mathrm{iso}}$), we obtain a pure CDI modulation. For $\kappa=\xi=0$ we have no modulation, i.e., we recover base $\Lambda$CDM. Therefore this
model is particularly useful for examining a range of possible modulations
within the context of a concrete framework.

In order to constrain this model, we use a formalism which was developed
to determine the signatures of potential gradients in physical parameters in
the CMB ([Moss et al., 2011](#bib.bib182)), and which is used to examine dipolar modulation and
described in detail in [Planck Collaboration
XVI (2016)](#bib.bib220). This approach is well-suited
to testing the modulated curvaton model since it can accommodate
scale-dependent modulations. Briefly, we write the temperature anisotropy
covariance given a gradient $\Delta X\_{M}$ in a parameter $X$ as

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\quad C\_{\ell m\ell^{\prime}m^{\prime}}$ | $\displaystyle=$ | $\displaystyle C\_{\ell}\delta\_{\ell\ell^{\prime}}\delta\_{mm^{\prime}}+(-1)^{m}\frac{\delta C\_{\ell\ell^{\prime}}}{2}\left[(2\ell+1)(2\ell^{\prime}+1)\right]^{1/2}$ |  | (170) |
|  |  | $\displaystyle\times$ | $\displaystyle\left(\begin{matrix}\ell&\ell^{\prime}&1\cr 0&0&0\end{matrix}\right)\sum\_{M}\Delta X\_{M}\left(\begin{matrix}\ell&\ell^{\prime}&1\cr-m&m^{\prime}&M\end{matrix}\right),$ |  |

where $\delta C\_{\ell\ell^{\prime}}\equiv dC\_{\ell}/dX+dC\_{\ell^{\prime}}/dX$. Note that
this covariance takes the form of Eqs. ([162](#S12.E162 "In 12.2 Scale-dependent modulation and idealized estimators ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation")) and
([163](#S12.E163 "In 12.2 Scale-dependent modulation and idealized estimators ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation")), with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C^{1}\_{\ell;\ell^{\prime}}=\frac{\delta C\_{\ell\ell^{\prime}}}{2}\left[(2\ell+1)(2\ell^{\prime}+1)\right]^{1/2}\left(\begin{matrix}\ell&\ell^{\prime}&1\cr 0&0&0\end{matrix}\right).$ |  | (171) |

We then construct a maximum likelihood estimator for the gradient
components. We use $C^{-1}$ filtered data ([Planck Collaboration
XV, 2016](#bib.bib219)) and perform
a mean-field subtraction, giving

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\quad\Delta\hat{X}\_{M}$ | $\displaystyle=$ | $\displaystyle\frac{3}{f\_{1M}}\sum\_{\ell m\ell^{\prime}m^{\prime}}(-1)^{m}C^{1}\_{\ell;\ell^{\prime}}\left(\begin{matrix}\ell&\ell^{\prime}&1\cr-m&m^{\prime}&M\end{matrix}\right)$ |  | (172) |
|  |  | $\displaystyle\times$ | $\displaystyle\left(T\_{\ell m}T^{\*}\_{\ell^{\prime}m^{\prime}}-\left<T\_{\ell m}T^{\*}\_{\ell^{\prime}m^{\prime}}\right>\right)\left[\sum\_{\ell\ell^{\prime}}\left(C^{1}\_{\ell;\ell^{\prime}}\right)^{2}F\_{\ell}F\_{\ell^{\prime}}\right]^{-1}.$ |  |

Here $f\_{1M}$ is a normalization correction due to the applied mask,
$M(\Omega)$, and is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\_{1M}\equiv\int d\Omega\thinspace Y^{\*}\_{1M}(\Omega)M(\Omega).$ |  | (173) |

The $T\_{\ell m}$ are the filtered data and $F\_{\ell}\equiv\left<T\_{\ell m}T^{\*}\_{\ell m}\right>$. Note that the lack of aberration in the
Planck Full Focal Plane simulations ([Planck Collaboration
XII, 2016](#bib.bib217)) is expected to have negligible
effect on this analysis and on that of the quadrupolar modulation in the
next subsection, since the CDI modulation is heavily suppressed for
$\ell\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$>$\hss}\lower 5.16663pt\hbox{$\sim$}}}500$, whereas the effect of aberration has a very different
$\ell$ dependence and will bias the modulation signal
for $\ell\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}1000$ at an insignificant level.

In practice, exploring the parameter space of the
model is sped up dramatically by binning the estimator defined in
Eq. ([172](#S12.E172 "In 12.3 Constraining inflationary models for dipolar asymmetry ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation")) into bins of width $\Delta\ell=1$, which means
that the estimators only need to be calculated once ([Planck Collaboration
XVI, 2016](#bib.bib220)).
Finally, for the modulated curvaton model we identify

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{dC\_{\ell}}{dX}=2K\_{\ell}C\_{\ell}.$ |  | (174) |

Note that for our constraints we fix the curvaton gradient to its maximum
value, $\Delta\sigma\_{\*}/\sigma\_{\*}=1$. Therefore, our constraints are
conservative, since smaller $\Delta\sigma\_{\*}/\sigma\_{\*}$ would only reduce the
modulation that this model could produce.

The temperature anisotropies measured by Planck constrain the modulated
curvaton parameters $\kappa$ and $\xi$ via Eqs. ([169](#S12.E169 "In 12.3 Constraining inflationary models for dipolar asymmetry ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation")) and
([172](#S12.E172 "In 12.3 Constraining inflationary models for dipolar asymmetry ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation")). Figure [54](#S12.F54 "Figure 54 ‣ 12.3 Constraining inflationary models for dipolar asymmetry ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation") shows the constraints in
this parameter space evaluating the estimator to $\ell\_{\mathrm{max}}=1000$. The maximum likelihood region corresponds to a band at $\kappa\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$>$\hss}\lower 5.16663pt\hbox{$\sim$}}}3$. For parameters in this region, the model produces a large-scale
asymmetry via a mainly-CDI modulation. However, the amplitude of this
large-scale asymmetry is lower than the 6–$7\thinspace\%$ actually
observed ([Planck Collaboration
XVI, 2016](#bib.bib220)). The reason is that, had a CDI modulation
produced all of the large-scale asymmetry, the consequent small-scale
asymmetry (due to the shape of the scale-invariant CDI spectrum) would be
larger than the Planck observations allow. The allowed CDI modulation is
further reduced by the Planck 95 % upper limit on an uncorrelated,
scale-invariant (“axion”-type) isocurvature component,
$\beta\_{\mathrm{iso}}<0.033$, from Sect. [11](#S11 "11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"). Imposing this
constraint reduces the available parameter space in the $\kappa$–$\xi$
plane via Eq. ([168](#S12.E168 "In 12.3 Constraining inflationary models for dipolar asymmetry ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation")), as illustrated in Fig. [54](#S12.F54 "Figure 54 ‣ 12.3 Constraining inflationary models for dipolar asymmetry ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation").

Figure 54: 68 % and 95 % CL regions in the modulated isocurvature model
parameter space using the Planck temperature data up to $\ell\_{\mathrm{max}}=1000$ (contours). The region above the dashed curve is ruled out by
the Planck constraint on an uncorrelated, scale-invariant isocurvature
component.

The best fit in Fig. [54](#S12.F54 "Figure 54 ‣ 12.3 Constraining inflationary models for dipolar asymmetry ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation") corresponds to
$\Delta\chi^{2}=-6.8$ relative to base $\Lambda$CDM, for two extra
parameters. In order to assess how likely such an improvement would be in
statistically isotropic skies, we note that the best-fit CDI modulation
amplitude is very close to the mean amplitude expected due to cosmic
variance, as calculated directly from Eq. ([172](#S12.E172 "In 12.3 Constraining inflationary models for dipolar asymmetry ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation")). More
precisely, since the amplitude is $\chi^{2}$ distributed with three degrees
of freedom, i.e., Maxwell-Boltzmann distributed, we conclude that about
44 % of statistically isotropic skies will exhibit a measured [via
Eq. ([172](#S12.E172 "In 12.3 Constraining inflationary models for dipolar asymmetry ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation"))] isocurvature modulation larger than that of
the actual sky.

To summarize, the modulated curvaton model can only produce a small part
of the observed large-scale asymmetry, and what it can produce is entirely
consistent with cosmic variance in a statistically isotropic sky. Hence
we must favour the base $\Lambda$CDM model
over this model. Finally, note that further generalizing the
model (e.g., to allow non-scale-invariant CDI spectra) may allow more
large-scale asymmetry to be produced and hence result in an improved
$\Delta\chi^{2}$, at the expense of more parameters. On the
other hand, the neutrino isocurvature modes are not expected to fit the
observed asymmetry well due to their approximate scale invariance (see
Fig. [43](#S11.F43 "Figure 43 ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation")).

### 12.4 Constraints on quadrupolar asymmetry generated during inflation

In this section we assume a quadrupolar directional dependence of the
primordial scalar power spectrum about some axis $\pm\mathbf{\hat{d}}$ and having a
scale-dependent amplitude $g(k).$ More specifically, we assume

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}\_{\mathcal{R}}({\mathbf{k}})=\mathcal{P}\_{\mathcal{R}}^{0}(k)\left\{1+g(k)\left[\left(\mathbf{\hat{k}}\cdot\mathbf{\hat{d}}\right)^{2}-\frac{1}{3}\right]\right\},$ |  | (175) |

which can be rewritten as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}\_{\mathcal{R}}({\mathbf{k}})=\mathcal{P}\_{\mathcal{R}}^{0}(k)\left[1+\sum\_{M}g\_{2M}(k)\thinspace Y\_{2M}(\mathbf{\hat{k}})\right],$ |  | (176) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $g\_{2M}(k)\equiv\frac{8\pi}{15}g(k)\thinspace Y\_{2M}^{\*}(\mathbf{\hat{d}}),$ |  | (177) |

with $g\_{2M}(k)$ satisfying $g\_{2,-M}(k)=(-1)^{M}\thinspace g^{\*}\_{2M}(k)$.
In this analysis, we will treat the modulation scale dependence as a power
law, $g(k)=g\_{\*}(k/k\_{\*})^{q}$, and consider five values of the spectral index,
namely $q=-2$, $-1$, $0$, $1$, and $2$. Importantly, for $q\neq 0$ our
constraints on $g\_{\*}$ will depend on the pivot scale, chosen as
$k\_{\*}=0.05\thinspace\mathrm{Mpc}^{-1}$ as elsewhere in this paper.
Models have been proposed predicting
both positive and negative $g\_{\*}$
([Tsujikawa, 2014](#bib.bib249), see, e.g.), so we keep the sign of $g\_{\*}$ free.

Often in the literature the term $-g(k)/3$ is not included in the modulated
power spectrum, Eq. ([175](#S12.E175 "In 12.4 Constraints on quadrupolar asymmetry generated during inflation ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation")). Our form sets the modulation monopole to
zero, so that there is no correction to the isotropic power spectrum dependent
on $g(k)$. We do this because for large $|q|$ the correction would require
a joint analysis with the isotropic power spectrum likelihood. Inflationary
models have been proposed which predict both forms. For example, the model in
[Ohashi et al. (2013)](#bib.bib188) includes the modulation monopole, while the model in [Libanov & Rubakov (2010)](#bib.bib146)
does not. For $q=0$ our results apply
to both forms due to the degeneracy of a scale-independent
correction to $\mathcal{P}\_{\mathcal{R}}^{0}(k)$ with the scalar amplitude,
$A\_{\mathrm{s}}.$ However, for nonzero
tilt a joint analysis would yield tighter constraints on $g\_{\*}$ when the
monopole correction is present, in which case our results will be conservative.

Given the anisotropic power spectrum of Eq. ([176](#S12.E176 "In 12.4 Constraints on quadrupolar asymmetry generated during inflation ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation")), the statistically
anisotropic part of the CMB temperature fluctuations has the following expectation
value ([Ma et al., 2011](#bib.bib160)):

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle C\_{\ell,\ell^{\prime};2,M}$ | $\displaystyle=i^{\ell-\ell^{\prime}}D\_{\ell\ell^{\prime}}g\_{2M}(k)\thinspace\left[\frac{5(2\ell+1)(2\ell^{\prime}+1)}{4\pi}\right]^{\frac{1}{2}}$ |  | (178) |
|  |  | $\displaystyle\times\left(\begin{array}[]{ccc}2&\ell&\ell^{\prime}\\ 0&0&0\end{array}\right),$ |  |

where $D\_{\ell\ell^{\prime}}\equiv 4\pi\int d\ln k\thinspace\Delta^{\mathrm{s}}\_{\ell,T}(k)\thinspace\Delta^{\mathrm{s}}\_{\ell^{\prime},T}(k)\thinspace\mathcal{P}\_{\mathcal{R}}^{0}(k)(k/k\_{\*})^{q}$ and $\Delta^{\mathrm{s}}\_{\ell,T}(k)$
denotes the temperature radiation transfer function.

The analysis is carried out using the foreground-cleaned CMB temperature maps
Commander, NILC,
SEVEM, and SMICA, where we apply the extended common mask UT76.
The implementation details of the optimal estimator can be found in Sect. 5.3
of [Planck Collaboration
XVI (2016)](#bib.bib220). However, here we apply an inverse variance weighted filter
that assumes a simple white noise component, but optimally accounts for the
mask in the same manner as [Planck Collaboration
XVII (2014)](#bib.bib204) and Sects. 6.3 and 6.6 of
[Planck Collaboration
XVI (2016)](#bib.bib220).
We estimate $g\_{2M}$ from the data at multipoles $2\leq\ell\leq 1200$. The
range of multipoles is chosen such that the impact of foreground residuals on
the conclusions is insignificant.
Neglecting
very small scales, however, sacrifices little constraining power
because those scales are noise dominated.
This conclusion was based on
realistic simulations containing residual foregrounds.
Moreover, we estimate the statistical uncertainty in $g\_{2M}$ with
various $\ell\_{\mathrm{max}}$ values using simulations.

Once we have obtained estimates for the five $g\_{2M}$ coefficients, we must
determine values for the model parameters of interest, namely $g\_{\*}$ and
$\mathbf{\hat{d}}$. We assume the $g\_{2M}$
coefficients to be Gaussian distributed due to cosmic variance. We have
explicitly checked this hypothesis with simulations. Hence the likelihood
function is

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle{\mathcal{L}}$ | $\displaystyle\propto$ | $\displaystyle|G|^{-1/2}$ |  | (179) |
|  |  | $\displaystyle\times$ | $\displaystyle\exp\left[-\frac{1}{2}\left(\hat{g}\_{2M}-g\_{2M}(g\_{\*},\mathbf{\hat{d}})\right)^{\textsf{T}}G^{-1}\left(\hat{g}\_{2M}-g\_{2M}(g\_{\*},\mathbf{\hat{d}})\right)\right],$ |  |

where $G$ is the $g\_{2M}$ covariance matrix, which is estimated using isotropic
simulations. One approach to determining the model parameters would be to
use this likelihood to calculate marginalized posterior
distributions for $g\_{\*}$, from which mean values and errors could be
determined. However, we find that $g\_{\*}$ is so poorly constrained that the
means and widths thus calculated strongly depend on the prior
for $g\_{\*}$. Two sensible priors are uniform in $g\_{\*}$ or proportional
to $g\_{\*}^{2}$ [i.e., uniform in the Cartesian components of
$(g\_{\*},\mathbf{\hat{d}})$]. In addition, we find that the posterior means are
much closer to zero then the widths, which is due to the approximate
degeneracy between a modulation $(g\_{\*},\mathbf{\hat{d}})$ and modulation
$(-g\_{\*},\mathbf{\hat{d}}^{\prime})$, where $\mathbf{\hat{d}}^{\prime}$ is orthogonal to
$\mathbf{\hat{d}}$. In such a situation the degree of consistency between
the measured value of $g\_{\*}$ and the expectations of cosmic variance in
statistically isotropic skies is unclear.

Instead we determine best-fit values for $g\_{\*}$ and $\mathbf{\hat{d}}$
by maximizing the likelihood over the three parameters using a grid approach.
To characterize how unexpected our best-fit values are in statistically
isotropic skies, we repeat the procedure replacing our estimates for $g\_{2M}$
from the data with estimates from $1000$ isotropic simulations. We finally
calculate $p$-values, which give the fraction of simulations with a larger
value of $|g\_{\*}|$ than the actual data.
Note that from the Bayesian perspective the maximum-likelihood values amount
to maximizing the posterior for $g\_{\*}$ given a uniform prior on $g\_{\*}$, so that
these values will change with a different prior. However, we have checked
that the $p$-values depend only very weakly on the choice of prior.

Table 17: 
Minimum-$\chi^{2}$ $g\_{\*}$ values for quadrupolar modulation,
determined from the Commander, NILC, SEVEM, and
SMICA foreground-cleaned maps. Also given are $p$-values, defined as
the fraction of simulations with larger $|g\_{\*}|$ than the data. These results
demonstrate that the data are consistent with cosmic variance in statistically
isotropic skies.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | |  | Commander | | NILC | | SEVEM | | SMICA | | |  |  | | | | | | | | | $q$ | $g\_{\*}$ | $p$-value [%] | $g\_{\*}$ | $p$-value [%] | $g\_{\*}$ | $p$-value [%] | $g\_{\*}$ | $p$-value [%] | | $-2$ . | $-7.39\times 10^{-5}$ | 79.2 | $-7.66\times 10^{-5}$ | 79.8 | $-7.43\times 10^{-5}$ | 80.6 | $-7.52\times 10^{-5}$ | 80.2 | | $-1$ . | $5.99\times 10^{-3}$ | 97.3 | $6.65\times 10^{-3}$ | 95.8 | $6.27\times 10^{-3}$ | 97.2 | $6.22\times 10^{-3}$ | 96.9 | | $\kern 6.6112pt0$ . | $-2.79\times 10^{-2}$ | 12.5 | $-2.38\times 10^{-2}$ | 26.9 | $-2.56\times 10^{-2}$ | 20.7 | $-2.56\times 10^{-2}$ | 20.0 | | $\kern 6.6112pt1$ . | $-2.15\times 10^{-2}$ | 8.2 | $-1.79\times 10^{-2}$ | 23.7 | $-1.93\times 10^{-2}$ | 17.8 | $-1.93\times 10^{-2}$ | 16.7 | | $\kern 6.6112pt2$ . | $-1.28\times 10^{-2}$ | 9.7 | $-1.07\times 10^{-2}$ | 23.7 | $-1.13\times 10^{-2}$ | 20.4 | $-1.15\times 10^{-2}$ | 18.1 | |  |

Table [17](#S12.T17 "Table 17 ‣ 12.4 Constraints on quadrupolar asymmetry generated during inflation ‣ 12 Statistical anisotropy and inflation ‣ Planck 2015 results. XX. Constraints on inflation") shows the $g\_{\*}$ values obtained by minimizing
$\chi^{2}$ as well as
the $p$-values for the data compared to statistically isotropic simulations.
Note that the constraints on $g\_{\*}$ are strongest for the most negative
values of the exponent $q$. This is because for fixed $g\_{\*}$
the largest asymmetry over the
range of observable scales occurs for $q=-2$, at the largest scales, due
to the location of the pivot scale, $k\_{\*}$.
Our limits provide a stringent test of rotational symmetry during inflation.
We find
no sign of deviation from statistical isotropy.2525
25
The constraints
from the Planck 2013 data by [Kim & Komatsu (2013)](#bib.bib129) should be multiplied by a factor
of $\sqrt{2}$ in our normalization.

## 13 Combination with BICEP2/Keck Array-Planck cross-correlation

In this section we discuss the implications of the recent constraints on the primordial
$B$-mode polarization from the cross-correlation
of the BICEP2 and Keck Array data at 150 GHz with the Planck maps at higher
frequencies to characterize and remove the contribution
from polarized thermal dust emission from our Galaxy
([34](#bib.bib34)).
On its own, the BKP likelihood leads to a 95 % CL upper
limit of $r<0.12$, compatible with and independent of the constraints obtained using the
2015 Planck temperature and large angular scale polarization in Sect. [5](#S5 "5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation"). (Note, however, that
the BKP likelihood uses the Hamimeche-Lewis approximation ([Hamimeche & Lewis, 2008](#bib.bib110)), which requires
the assumption of a fiducial model.)
The BKP results are also compatible with the Planck 2013 Results ([Planck Collaboration
XVI, 2014](#bib.bib203); [Planck Collaboration
XXII, 2014](#bib.bib205)). The
posterior probability distribution for $r$ obtained by BKP
peaks away from zero at $r\approx 0.05$, but the region of large posterior probability includes $r=0$.

Figure 55: Marginalized joint 68 % and 95 % CL regions for $n\_{\mathrm{s}}$ and $r$ at $k=0.002$ Mpc-1
from Planck alone and in combination with its cross-correlation with BICEP2/Keck Array and/or BAO data
compared with the theoretical predictions of selected inflationary models. Note that the marginalized
joint 68 % and 95 % CL regions have been obtained by assuming $dn\_{\mathrm{s}}/d\ln k=0$.

Here we combine the baseline two-parameter BKP likelihood
using the lowest five $B$-mode bandpowers with the Planck 2015 likelihoods.
The two BKP nuisance parameters are the
$B$-mode amplitude and frequency spectral index of the polarized thermal dust emission.
The combined analysis yields the following constraint on the tensor-to-scalar ratio:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $r\_{0.002}<0.08\quad\text{(95\thinspace\% CL, {Planck}\ TT+lowP+BKP)}\thinspace,$ |  | (180) |

further improving on the upper limits obtained from the different data combinations presented
in Sect. [5](#S5 "5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation").

By directly constraining the tensor mode, the BKP likelihood
removes degeneracies between the tensor-to-scalar ratio and other parameters.
Adding tensors and running, we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $r\_{0.002}<0.10\quad\text{(95\thinspace\% CL, {Planck}\ TT+lowP+BKP)}\thinspace,$ |  | (181) |

which constitutes almost a 50 % improvement over the Planck TT+lowP constraint quoted in
Eq. ([27](#S5.E27 "In 5.1 Planck 2015 upper bound on 𝑟 ‣ 5 Constraints on tensor modes ‣ Planck 2015 results. XX. Constraints on inflation")). These limits on tensor modes are more robust than the limits using the
shape of the $C\_{\ell}^{TT}$ spectrum alone because scalar perturbations cannot generate $B$ modes irrespective
of the shape of the scalar spectrum.

### 13.1 Implications of BKP on selected inflationary models

Using the BKP likelihood further strengthens the constraints
on the inflationary parameters and models discussed in Sect. [6](#S6 "6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation"), as seen in
Fig. [55](#S13.F55 "Figure 55 ‣ 13 Combination with BICEP2/Keck Array-Planck cross-correlation ‣ Planck 2015 results. XX. Constraints on inflation"). If we set $\epsilon\_{3}=0$,
the first slow-roll parameter is constrained to $\epsilon\_{1}<0.0055$ at 95 % CL by Planck TT+lowP+BKP.
With the same data combination, concave potentials are preferred over convex potentials
with $\ln B=3.8$, which improves on the $\ln B=2$ result obtained from the Planck data alone.

Table 18: Results of inflationary model comparison using the cross-correlation
between BICEP2/Keck Array and Planck. This table is similar
to Table [7](#S6.T7 "Table 7 ‣ Non-minimally coupled inflaton ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation"), which did not use the BKP likelihood.
Note, however, that the $\Delta\chi^{2}$ are computed with respect to the best fit of
baseline + tensors, unlike in Table [7](#S6.T7 "Table 7 ‣ Non-minimally coupled inflaton ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation").

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  | | --- | --- | --- | | Inflationary model | $\ln B\_{0X}$ | | |  | $w\_{\mathrm{int}}=0$ | $w\_{\mathrm{int}}\neq 0$ | | $R+R^{2}/(6M^{2})$ | $\ldots$ | $+0.3$ | | $n=2/3$ | $-1.9$ | $-1.2$ | | $n=1$ | $-1.6$ | $-1.8$ | | $n=4/3$ | $-2.1$ | $-2.5$ | | $n=2$ | $-6.0$ | $-5.6$ | | $n=3$ | $-16.0$ | $-15.6$ | | $n=4$ | $-30.1$ | $-29.9$ | | Natural | $-5.6$ | $-5.0$ | | Hilltop ($p=2$) | $-0.7$ | $-0.4$ | | Hilltop ($p=4$) | $-0.6$ | $-0.9$ | | Double well | $-4.3$ | $-4.2$ | | Brane inflation ($p=2$) | $+0.2$ | $\phantom{-}0.0$ | | Brane inflation ($p=4$) | $+0.1$ | $-0.1$ | | Exponential tails | $-0.1$ | $\phantom{-}0.0$ | | SB SUSY | $-1.8$ | $-1.5$ | | Supersymmetric $\alpha$-model | $-1.1$ | $+0.1$ | | Superconformal ($m=1$) | $-1.9$ | $-1.4$ | | Superconformal ($m\neq 1$) | $-2.5$ | $-2.2$ | |  |

Combining with the BKP likelihood strengthens the constraints on the
selected inflationary models studied in Sect. [6](#S6 "6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation").
Using the same methodology as in Sect. [6](#S6 "6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation") and
adding the BKP likelihood gives a Bayes factor preferring $R^{2}$ over chaotic inflation
with monomial quadratic potential and natural inflation by odds of 403:1 and 270:1, respectively,
under the assumption of a dust equation of state during the entropy generation stage.
The combination with the BKP likelihood further penalizes the double-well model compared to $R^{2}$ inflation.
However, adding BKP reduces
the Bayes factor of the hilltop models compared to $R^{2}$, because these models can predict a value of the
tensor-to-scalar ratio that better fits the statistically insignificant peak at $r\approx 0.05$.
See Table [18](#S13.T18 "Table 18 ‣ 13.1 Implications of BKP on selected inflationary models ‣ 13 Combination with BICEP2/Keck Array-Planck cross-correlation ‣ Planck 2015 results. XX. Constraints on inflation") for the $\Delta\chi^{2}$ and the Bayes factors of inflationary
models with the same two cases of post-inflationary evolution studied in Sect. [6](#S6 "6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation").
Note, however, that the $\Delta\chi^{2}$ are computed with respect to the best fit of
baseline + tensors, unlike in Table [7](#S6.T7 "Table 7 ‣ Non-minimally coupled inflaton ‣ 6.2 Implications for selected inflationary models ‣ 6 Implications for single-field slow-roll inflation ‣ Planck 2015 results. XX. Constraints on inflation").

### 13.2 Implications of BKP on scalar power spectrum

Figure 56: Impact of BKP likelihood on scalar primordial power spectrum reconstruction.
We show how including the BKP likelihood affects
the reconstruction in Sect. [8.3](#S8.SS3 "8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation"). The top panel is to be
compared with the reconstructions in Fig. [27](#S8.F27 "Figure 27 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation"), and we observe that
including BKP has a minimal impact given the uncertainty in the
reconstruction. The middle panel is to be compared with Fig. [31](#S8.F31 "Figure 31 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation"), and
here we notice that including BKP excludes the trajectories with large values of $\epsilon.$
The bottom panel shows how the inflationary potential reconstructions are modified by BKP
(to be compared with Fig. [32](#S8.F32 "Figure 32 ‣ 8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation")).

The presence of tensors would, at least to some degree, require an enhanced
suppression of the scalar power spectrum on large scales to account for the low-$\ell$
deficit in the $C\_{\ell}^{TT}$ spectrum.
We therefore repeat the analysis of an exponential cutoff studied in Sect. [4.4](#S4.SS4 "4.4 Suppression of power on the largest scales ‣ 4 Constraints on the primordial spectrum of curvature perturbations ‣ Planck 2015 results. XX. Constraints on inflation") with
tensor perturbations included and the standard tensor tilt (i.e., $n\_{\mathrm{t}}=-r/8$).
Allowing tensors does not significantly degrade the
$\Delta\chi^{2}$ improvement found in Sect. [4.4](#S4.SS4 "4.4 Suppression of power on the largest scales ‣ 4 Constraints on the primordial spectrum of curvature perturbations ‣ Planck 2015 results. XX. Constraints on inflation") for Planck TT+lowP with a best fit at $r\approx 0$.
When the BKP likelihood is combined, we obtain $\Delta\chi^{2}=-4$ with respect to the base
$\Lambda$CDM model with a best fit at $r\approx 0.04$. However,
since this model contains 3 additional parameters, it is not preferred over base $\Lambda$CDM.

In Fig. [56](#S13.F56 "Figure 56 ‣ 13.2 Implications of BKP on scalar power spectrum ‣ 13 Combination with BICEP2/Keck Array-Planck cross-correlation ‣ Planck 2015 results. XX. Constraints on inflation") we show how the scalar primordial power spectrum reconstruction
discussed in Sect. [8.3](#S8.SS3 "8.3 Method III: cubic spline reconstruction ‣ 8 𝒫(𝑘) reconstruction ‣ Planck 2015 results. XX. Constraints on inflation") is modified when the BKP likelihood is also included.
While the power spectrum reconstruction hardly varies given the uncertainties in the method, the trajectories
of the slow-roll parameters are significantly closer to slow roll.
When the 12-knot reconstruction is carried out, the upper bound on the tensor-to-scalar ratio is
$r<0.11$ at 95 % CL.
The $\chi^{2}$ per degree of freedom
for the 5 low-$k$ and 6 high-$k$ knots are
1.14 and 0.22, respectively, corresponding to $p$-values of $0.33$ and $0.97.$

### 13.3 Relaxing the standard single-field consistency condition

We now relax the consistency condition (i.e., $n\_{\mathrm{t}}=-r/8$)
and allow the tensor tilt to be independent of the tensor-to-scalar ratio.
This fully phenomenological analysis with the BKP likelihood is complementary
to the study of inflationary models with generalized Lagrangians in Sect. [10](#S10 "10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation"), which
also predict modifications to the consistency condition $n\_{\mathrm{t}}=-r/8$ for a nearly scale-invariant
spectrum of tensor modes. In this subsection we adopt a phenomenological approach,
thereby including radical departures from $n\_{\mathrm{t}}\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}0$, including values which are
predicted in alternative models to inflation ([Gasperini & Veneziano, 1993](#bib.bib97); [Boyle et al., 2004](#bib.bib38); [Brandenberger et al., 2007](#bib.bib40)).
In Sect. [10](#S10 "10 Implications of Planck bispectral constraints on inflationary models ‣ Planck 2015 results. XX. Constraints on inflation") we folded in the Planck $f\_{\mathrm{NL}}$
constraints ([Planck Collaboration
XVII, 2016](#bib.bib221)), whereas here we consider Planck and BKP likelihoods only.
Complementary probes such as pulsar timing, direct detection of gravitational waves,
and nucleosynthesis bounds could be used to constrain blue values for the tensor spectral index
([Stewart & Brandenberger, 2008](#bib.bib246)), but here we are primarily interested in what CMB data can tell us.

We caution the reader that in the absence of a clear detection of a tensor
component, joint constraints on $r$ and $n\_{\mathrm{t}}$ depend strongly
on priors, or equivalently on the choice of parameterization.
Nevertheless, the BKP likelihood has some constraining power
over a range of scales more than a decade wide around
$k\approx 0.01$ Mpc-1, so the results are not entirely prior driven.

Figure 57: Posterior probability density of the tensor-to-scalar ratio at two
different scales. The inflationary consistency relation is relaxed and $r\_{0.002}$
and $r\_{0.020}$ are used as sampling parameters,
assuming a power-law spectrum for primordial tensor perturbations. When the
BKP likelihood is included in the analysis, the results
with Planck TT+lowP+BAO and Planck TT,TE,EE+lowP coincide
(dashed and solid red curves, respectively).

Figure 58: 68 % and 95 % CL constraints on tensors when the
inflationary consistency relation is relaxed, with Planck TT+lowP+BAO (blue dashed
contours) and TT,TE,EE+lowP (blue shaded regions). The red colours are for the same
data plus the BKP joint likelihood. The upper panel shows our
independent primary parameters $r\_{0.002}$ and $r\_{0.020}$.
The lower panel shows the derived parameters $n\_{t}$
and $r\_{0.01}$. The scale $k=0.01\thinspace$Mpc-1 is near the
decorrelation scale of ($n\_{t}$, $r$) for the Planck+BKP data.

The commonly used ($r$, $n\_{\mathrm{t}}$) parameterization suffers
from pathological behaviour around $r=0,$ which could be problematic for statistical sampling.
We therefore use a parameterization
specifying $r$ at two different scales, ($r\_{k\_{1}},r\_{k\_{2}}$)
(analogous to the treatment of primordial isocurvature in Sect. [11](#S11 "11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation"))
as well as the more familiar
($r$, $n\_{\mathrm{t}}$) parameterization.
We present results based on
$k\_{1}=0.002$ Mpc-1 and $k\_{2}=0.02$ Mpc${}^{-1},$
also quoting the amplitude at $k=0.01$ Mpc-1 for both parameterizations.
This scale is close to the decorrelation scale for ($r$, $n\_{\mathrm{t}}$) for the
Planck+BKP joint constraints.
We obtain $r\_{0.002}<0.07$ ($0.06$) and $r\_{0.02}<0.29$ ($0.31$) at 95 % CL from the two-scale parameterization
with Planck TT+lowP+BAO+BKP (TT,TE,EE+lowP+BKP). Figure [57](#S13.F57 "Figure 57 ‣ 13.3 Relaxing the standard single-field consistency condition ‣ 13 Combination with BICEP2/Keck Array-Planck cross-correlation ‣ Planck 2015 results. XX. Constraints on inflation") illustrates the
impact of the BKP likelihood on the one-dimensional posterior probabilities for these two parameters.
The derived constraint at $k=0.01$ Mpc-1 is $r\_{0.01}<0.12$ ($0.12$) at 95 % CL with
Planck TT+lowP+BAO+BKP (TT,TE,EE+lowP+BKP).
The upper panel of Fig. [58](#S13.F58 "Figure 58 ‣ 13.3 Relaxing the standard single-field consistency condition ‣ 13 Combination with BICEP2/Keck Array-Planck cross-correlation ‣ Planck 2015 results. XX. Constraints on inflation") shows the relevant 2D contours
for the tensor-to-scalar ratios at the two scales and the improvement due
to the combination with the BKP likelihood.
The lower panel shows the 2D contours in ($r\_{0.01},n\_{\mathrm{t}}$) obtained by sampling with the two-scale
parameterization.
Figure [59](#S13.F59 "Figure 59 ‣ 13.3 Relaxing the standard single-field consistency condition ‣ 13 Combination with BICEP2/Keck Array-Planck cross-correlation ‣ Planck 2015 results. XX. Constraints on inflation") shows the 2D contours in ($r\_{0.01},n\_{\mathrm{t}}$)
obtained by the ($r\_{0.002},n\_{\mathrm{t}}$) parameterization.

We conclude that positive values of the tensor tilt, $n\_{\mathrm{t}}$, are not statistically significantly
preferred by the BKP joint measurement of $B$-mode polarization in combination with Planck data,
a conclusion at variance with results reported using the BICEP2 data ([Gerbino et al., 2014](#bib.bib99)).
However, the now firmly established contamination by polarized dust emission easily explains the discrepancy.
Values of tensor tilt consistent with the standard single-field inflationary consistency relation
are compatible with the Planck+BKP constraints.

Figure 59: The same as Fig. [58](#S13.F58 "Figure 58 ‣ 13.3 Relaxing the standard single-field consistency condition ‣ 13 Combination with BICEP2/Keck Array-Planck cross-correlation ‣ Planck 2015 results. XX. Constraints on inflation") lower panel, but using $n\_{t}$ and $r\_{0.002}$ as
primary parameters.

## 14 Conclusions

The Planck full mission temperature and polarization data are consistent
with the spatially flat base $\Lambda$CDM model, whose perturbations are Gaussian and adiabatic
with a spectrum described by a simple power law, as predicted by the simplest inflationary models.
For this release, the basic Planck results do not rely on external data. The first Planck polarization release at large angular scales from the LFI 70 GHz channel determines an optical depth of $\tau=0.067\pm 0.022$ (68 % CL, Planck low multipole likelihood), a value smaller than the previous Planck 2013 result
based on the WMAP9 polarization likelihood as delivered by the WMAP team. This Planck value of $\tau$
is consistent with an analysis of WMAP9 polarization data cleaned for polarized dust emission using the
Planck 353 GHz data ([Planck Collaboration
XV, 2014](#bib.bib202); [Planck Collaboration
XI, 2016](#bib.bib216)).
The estimates of cosmological parameters from the full mission
temperature data and polarization on large angular scales are consistent with those of the
Planck 2013 release. The $TE$ and $EE$ spectra at $\ell\geq 30$ together with the lensing power spectra lead to
cosmological constraints in agreement with those obtained from temperature.

The Planck full mission temperature and large angular scale polarization data rule out an exactly
scale-invariant spectrum of curvature perturbations at 5.6 $\sigma.$ For the base $\Lambda$CDM
model, the spectral index is measured to be $n\_{\mathrm{s}}=0.965\pm 0.006$ (68 % CL, Planck TT+lowP).
No evidence for a running of the spectral index is found, with $dn\_{\mathrm{s}}/{d\ln k}=-0.008\pm 0.008$
(68 % CL, Planck TT+lowP).

The Planck full mission data improve the upper bound on the tensor-to-scalar ratio to $r\_{0.002}<0.10$
(95 % CL, Planck TT+lowP), a bound that changes only slightly when including the Planck lensing likelihood, the high-$\ell$
polarization likelihood, or the likelihood from the WMAP large angular scale polarization map
(dust-cleaned with the Planck 353 GHz map). We
showed how the low-$\ell$ deficit in temperature contributes to the Planck upper bound on $r\_{0.002}$, but
this deficit is not a statistically significant anomaly within the base $\Lambda$CDM cosmology.
Using the full mission Planck data, we find the upper bound on
$r\_{0.002}$ stable, even when extended cosmological models or models with CDM isocurvature are considered.
The Planck bound on $r\_{0.002}$ is consistent with the recent result $r\_{0.002}<0.12$ at 95 % CL
obtained by the BKP cross-correlation analysis
which accounts for contamination
by polarized dust emission ([Planck Collaboration
XXX, 2014](#bib.bib211)).
By combining Planck TT+lowP with the BKP cross-correlation likelihood, we obtain $r\_{0.002}<0.08$ at 95 % CL.

The increased precision of the Planck full mission data reduces the area enclosed by the 95 % confidence
contour in the $(n\_{\mathrm{s}},r)$-plane by 29 %.
We performed a Bayesian model comparison with the same methodology as in
[205](#bib.bib205), taking into account reheating uncertainties by marginalizing over two extra
parameters: the energy scale at thermalization, $\rho\_{\mathrm{th}}$, and the parameter
$w\_{\mathrm{int}}$ characterizing the average equation of state between the end of inflation and thermalization.
Among the models considered using this approach, the $R^{2}$ inflationary
model proposed by [Starobinsky (1980)](#bib.bib244) is the most preferred.
Due to its high tensor-to-scalar ratio, the quadratic model is now strongly disfavoured with
respect to $R^{2}$ inflation for Planck TT+lowP in combination with BAO data. By combining wth the BKP likelihood,
this trend is confirmed, and natural inflation is also disfavoured.

We reconstructed the inflaton potential and the Hubble parameter evolution during the observable part of
inflation using a Taylor expansion of the inflaton potential or $H(\phi).$ This analysis did not rely on the slow-roll
approximation, nor on any assumption about the end of inflation.
When higher-order terms were allowed, both reconstructions led to a change in the slope of the potential at the beginning of the
observable range, thus better fitting the low-$\ell$ temperature deficit by turning on a non-zero running of
running and accommodating $r\_{0.002}\approx 0.2$. These models, however, are not significantly favoured compared
to lower order parameterizations that lead to slow-roll evolution at all times.

Three distinct methods were used to reconstruct the primordial power
spectrum. All three methods strongly constrain deviations from a featureless power spectrum over the range of
scales $0.008\thinspace\mathrm{Mpc}^{-1}\mathrel{\raise 1.29167pt\hbox{$<$}\mkern-14.0mu\lower 2.58334pt\hbox{$\sim$}}k\mathrel{\raise 1.29167pt\hbox{$<$}\mkern-14.0mu\lower 2.58334pt\hbox{$\sim$}}0.1\thinspace\mathrm{Mpc}^{-1}$. More interestingly, they also independently
find common patterns in the primordial power spectrum of curvature perturbations
$\mathcal{P}\_{\mathcal{R}}(k)$ at $k\mathrel{\raise 1.29167pt\hbox{$<$}\mkern-14.0mu\lower 2.58334pt\hbox{$\sim$}}0.008\thinspace\mathrm{Mpc}^{-1}$. These patterns are related to the
dip at $\ell\approx 20$–$40$ in the temperature power spectrum.
This deviation from a simple power-law spectrum has weak statistical significance due to the large cosmic variance
at low $\ell.$

This direct reconstruction of the power spectrum is complemented by a search for parameterized
features in physically motivated models. The models considered range from the minimal case of a
kinetic energy dominated phase preceding a short inflationary stage (with just one extra parameter), to a
model with a step-like feature in the potential and in the sound speed (with five extra parameters).
As with the Planck 2013 nominal mission data, these templates lead to an improved fit, up to
$\Delta\chi^{2}\approx 12$. However, neither the Bayesian evidence nor a frequentist simulation-based analysis
shows any statistically significant preference over a simple power law.

We have updated the analysis that combines power spectrum constraints with those derived from the
$f\_{\mathrm{NL}}$ parameters ([Planck Collaboration
XVII, 2016](#bib.bib221)). New limits on the sound speed inferred from the full
mission temperature and polarization data further constrain the slow-roll parameters for generalized models,
including DBI inflation. For the first time, we derived combined constraints on Galileon inflation, including
the region of parameter space in which the predicted spectrum of gravitational waves has a blue spectral
index.

Several models motivated by the axion monodromy mechanism in string theory predict oscillatory modulations
and corresponding non-Gaussianities, potentially detectable by Planck. A $TT$-only analysis picks up four
possible modulation frequencies, which remain present when the high-$\ell$ polarization likelihood is included.
An inspection of frequency residuals in the high-$\ell$ $TT$ likelihood does not reveal evidence of
foreground-related systematics at similar frequencies.
However, a Bayesian evidence comparison prefers the
smooth base $\Lambda$CDM model over modulated models, suggesting that the latter could simply be fitting the
noise in the data. The monodromy model predicts resonant non-Gaussian features correlated to power spectrum
features. A partial analysis beyond the power spectrum was presented.
We also constrained a
possible pseudo-coupling of the axion to gauge fields by requiring that non-Gaussianities induced by inverse
decay satisfy the Planck bounds on $f\_{\mathrm{NL}}$.

Section [11](#S11 "11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation") reports on a search for possible deviations from purely adiabatic initial
conditions by studying a range of models including isocurvature modes as well as possible
correlations with the adiabatic mode.
The Planck full mission temperature data are consistent with adiabaticity. The Planck $TT$ data place tight constraints on three-parameter extensions to the flat adiabatic base $\Lambda$CDM
model, allowing arbitrarily correlated mixtures of the adiabatic mode with one isocurvature mode (of either
the CDM, baryon, neutrino density, or neutrino velocity type). Adding the high-$\ell$ $TE$ and $EE$
polarization data further squeezes the constraints, since polarization spectra contain additional shape and
phase information on acoustic oscillations. The likelihood with polarization included is in
agreement with adiabatic initial conditions. However, the tightening of the constraints after including polarization must be
interpreted with caution because of possible systematic effects. For this reason we emphasize
the more conservative Planck TT+lowP bounds in Table [16](#S11.T16 "Table 16 ‣ 11.5.3 Fully anticorrelated ADI+CDI (“Curvaton II”) ‣ 11.5 Special CDI cases ‣ 11 Constraints on isocurvature modes ‣ Planck 2015 results. XX. Constraints on inflation").
The constraints on the six base-$\Lambda$CDM cosmological model parameters remain stable when correlated
isocurvature modes are allowed. The largest shifts occur for the neutrino density mode, but these shifts
are not significant (i.e., $<1\thinspace\sigma$). The constraints on the
tensor-to-scalar ratio also remain stable when isocurvature modes are allowed.

Finally we examined the connection between inflation and statistical isotropy, a key
prediction of the simplest inflationary models. We tested separately the two lowest moments of an
anisotropic modulation of the primordial curvature power spectrum. We found that a modulated curvaton
model proposed to explain the observed large-scale dipolar power asymmetry cannot account for
all of the asymmetry, and hence is not preferred over statistically isotropic base $\Lambda$CDM.
The full mission temperature data place the tightest constraints to date on a quadrupolar modulation of curvature
perturbations.

###### Acknowledgements.

The Planck Collaboration acknowledges the support of: ESA; CNES and CNRS/INSU-IN2P3-INP (France);
ASI, CNR, and INAF (Italy); NASA and DoE (USA); STFC and UKSA (UK); CSIC, MINECO, JA, and RES (Spain);
Tekes, AoF, and CSC (Finland); DLR and MPG (Germany); CSA (Canada); DTU Space (Denmark); SER/SSO
(Switzerland); RCN (Norway); SFI (Ireland); FCT/MCTES (Portugal); ERC and PRACE (EU). A description of
the Planck Collaboration and a list of its members, indicating which technical or scientific activities they
have been involved in, can be found at <http://www.cosmos.esa.int/web/planck/planck-collaboration>.
This research used resources of the National Energy Research Scientific Computing Center,
a DOE Office of Science User Facility supported by the Office of Science of the U.S. Department
of Energy under Contract No. DE-AC02-05CH11231.
Part of this work was undertaken at the STFC DiRAC HPC Facilities at the University of Cambridge, funded by UK BIS National E-infrastructure capital grants.
We gratefully acknowledge
the IN2P3 Computer Center
(<http://cc.in2p3.fr>) for providing a significant
amount of the computing resources and services needed for this work.
