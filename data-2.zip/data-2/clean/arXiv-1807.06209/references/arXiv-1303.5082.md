<!-- fulltext source=arxiv_html slug=arXiv-1303.5082 fetched=2026-09-18T01:16:23+00:00 -->

# Planck 2013 results. XXII. Constraints on inflation

Planck Collaboration:
P. A. R. Ade
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
N. Aghanim
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
C. Armitage-Caplan
Affiliation: Sub-Department of Astrophysics, University of Oxford, Keble Road, Oxford OX1 3RH, U.K.
  
M. Arnaud
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
M. Ashdown
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
F. Atrio-Barandela
Affiliation: Departamento de Física Fundamental, Facultad de Ciencias, Universidad de Salamanca, 37008 Salamanca, Spain
  
J. Aumont
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
C. Baccigalupi
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
A. J. Banday
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
R. B. Barreiro
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
J. G. Bartlett
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
N. Bartolo
Affiliation: Dipartimento di Fisica e Astronomia G. Galilei, Università degli Studi di Padova, via Marzolo 8, 35131 Padova, Italy
  
E. Battaner
Affiliation: University of Granada, Departamento de Física Teórica y del Cosmos, Facultad de Ciencias, Granada, Spain
  
K. Benabed
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
A. Benoît
Affiliation: Institut Néel, CNRS, Université Joseph Fourier Grenoble I, 25 rue des Martyrs, Grenoble, France
  
A. Benoit-Lévy
Affiliation: Department of Physics and Astronomy, University College London, London WC1E 6BT, U.K.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
J.-P. Bernard
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
M. Bersanelli
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
P. Bielewicz
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
J. Bobin
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
J. J. Bock
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
A. Bonaldi
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
J. R. Bond
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
  
J. Borrill
Affiliation: Computational Cosmology Center, Lawrence Berkeley National Laboratory, Berkeley, California, U.S.A.
Affiliation: Space Sciences Laboratory, University of California, Berkeley, California, U.S.A.
  
F. R. Bouchet
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
M. Bridges
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
M. Bucher
††thanks: Corresponding authors: Martin Bucher [bucher@apc.univ-paris7.fr](mailto:bucher@apc.univ-paris7.fr),
Fabio Finelli [finelli@iasfbo.inaf.it](mailto:finelli@iasfbo.inaf.it)
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
  
C. Burigana
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
R. C. Butler
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
E. Calabrese
Affiliation: Sub-Department of Astrophysics, University of Oxford, Keble Road, Oxford OX1 3RH, U.K.
  
J.-F. Cardoso
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: Laboratoire Traitement et Communication de l’Information, CNRS (UMR 5141) and Télécom ParisTech, 46 rue Barrault F-75634 Paris Cedex 13, France
  
A. Catalano
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
Affiliation: Laboratoire de Physique Subatomique et de Cosmologie, Université Joseph Fourier Grenoble I, CNRS/IN2P3, Institut National Polytechnique de Grenoble, 53 rue des Martyrs, 38026 Grenoble cedex, France
  
A. Challinor
Affiliation: Centre for Theoretical Cosmology, DAMTP, University of Cambridge, Wilberforce Road, Cambridge CB3 0WA, U.K.
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
A. Chamballu
Affiliation: DSM/Irfu/SPP, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
H. C. Chiang
Affiliation: Astrophysics & Cosmology Research Unit, School of Mathematics, Statistics & Computer Science, University of KwaZulu-Natal, Westville Campus, Private Bag X54001, Durban 4000, South Africa
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
L.-Y Chiang
Affiliation: Institute of Astronomy and Astrophysics, Academia Sinica, Taipei, Taiwan
  
P. R. Christensen
Affiliation: Discovery Center, Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
Affiliation: Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
  
S. Church
Affiliation: Stanford University, Dept of Physics, Varian Physics Bldg, 382 Via Pueblo Mall, Stanford, California, U.S.A.
  
D. L. Clements
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
S. Colombi
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
L. P. L. Colombo
Affiliation: Department of Physics and Astronomy, Dana and David Dornsife College of Letter, Arts and Sciences, University of Southern California, Los Angeles, CA 90089, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
F. Couchot
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
A. Coulais
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
B. P. Crill
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
Affiliation: Observational Cosmology, Mail Stop 367-17, California Institute of Technology, Pasadena, CA, 91125, U.S.A.
  
A. Curto
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
F. Cuttaia
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
L. Danese
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
R. D. Davies
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
R. J. Davis
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
P. de Bernardis
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
A. de Rosa
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
G. de Zotti
Affiliation: INAF - Osservatorio Astronomico di Padova, Vicolo dell’Osservatorio 5, Padova, Italy
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
J. Delabrouille
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
  
J.-M. Delouis
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
F.-X. Désert
Affiliation: IPAG: Institut de Planétologie et d’Astrophysique de Grenoble, Université Joseph Fourier, Grenoble 1 / CNRS-INSU, UMR 5274, Grenoble, F-38041, France
  
C. Dickinson
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
J. M. Diego
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
H. Dole
Affiliation: Institut Universitaire de France, 103, bd Saint-Michel, 75005, Paris, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
S. Donzelli
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
O. Doré
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
M. Douspis
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
J. Dunkley
Affiliation: Sub-Department of Astrophysics, University of Oxford, Keble Road, Oxford OX1 3RH, U.K.
  
X. Dupac
Affiliation: European Space Agency, ESAC, Planck Science Office, Camino bajo del Castillo, s/n, Urbanización Villafranca del Castillo, Villanueva de la Cañada, Madrid, Spain
  
G. Efstathiou
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
  
T. A. Enßlin
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
H. K. Eriksen
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
F. Finelli⋆
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: INFN, Sezione di Bologna, Via Irnerio 46, I-40126, Bologna, Italy
  
O. Forni
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
M. Frailis
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
E. Franceschi
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
S. Galeotta
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
K. Ganga
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
  
C. Gauthier
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
Affiliation: Leung Center for Cosmology and Particle Astrophysics, National Taiwan University, Taipei 10617, Taiwan
  
M. Giard
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
G. Giardino
Affiliation: European Space Agency, ESTEC, Keplerlaan 1, 2201 AZ Noordwijk, The Netherlands
  
Y. Giraud-Héraud
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
  
J. González-Nuevo
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
K. M. Górski
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
Affiliation: Warsaw University Observatory, Aleje Ujazdowskie 4, 00-478 Warszawa, Poland
  
S. Gratton
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
A. Gregorio
Affiliation: Dipartimento di Fisica, Università degli Studi di Trieste, via A. Valerio 2, Trieste, Italy
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
A. Gruppuso
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
J. Hamann
Affiliation: Theory Division, PH-TH, CERN, CH-1211, Geneva 23, Switzerland
  
F. K. Hansen
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
D. Hanson
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
Affiliation: McGill Physics, Ernest Rutherford Physics Building, McGill University, 3600 rue University, Montréal, QC, H3A 2T8, Canada
  
D. Harrison
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
S. Henrot-Versillé
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
C. Hernández-Monteagudo
Affiliation: Centro de Estudios de Física del Cosmos de Aragón (CEFCA), Plaza San Juan, 1, planta 2, E-44001, Teruel, Spain
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
D. Herranz
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
S. R. Hildebrandt
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
  
E. Hivon
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
M. Hobson
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
  
W. A. Holmes
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
A. Hornstrup
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
W. Hovest
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
K. M. Huffenberger
Affiliation: Department of Physics, Florida State University, Keen Physics Building, 77 Chieftan Way, Tallahassee, Florida, U.S.A.
  
A. H. Jaffe
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
T. R. Jaffe
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
W. C. Jones
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
M. Juvela
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
  
E. Keihänen
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
  
R. Keskitalo
Affiliation: Computational Cosmology Center, Lawrence Berkeley National Laboratory, Berkeley, California, U.S.A.
Affiliation: Department of Electrical Engineering and Computer Sciences, University of California, Berkeley, California, U.S.A.
  
T. S. Kisner
Affiliation: Lawrence Berkeley National Laboratory, Berkeley, California, U.S.A.
  
R. Kneissl
Affiliation: Atacama Large Millimeter/submillimeter Array, ALMA Santiago Central Offices, Alonso de Cordova 3107, Vitacura, Casilla 763 0355, Santiago, Chile
Affiliation: European Southern Observatory, ESO Vitacura, Alonso de Cordova 3107, Vitacura, Casilla 19001, Santiago, Chile
  
J. Knoche
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
L. Knox
Affiliation: Department of Physics, University of California, One Shields Avenue, Davis, California, U.S.A.
  
M. Kunz
Affiliation: African Institute for Mathematical Sciences, 6-8 Melrose Road, Muizenberg, Cape Town, South Africa
Affiliation: Département de Physique Théorique, Université de Genève, 24, Quai E. Ansermet,1211 Genève 4, Switzerland
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
H. Kurki-Suonio
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
G. Lagache
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
A. Lähteenmäki
Affiliation: Aalto University Metsähovi Radio Observatory, Metsähovintie 114, FIN-02540 Kylmälä, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
J.-M. Lamarre
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
A. Lasenby
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
R. J. Laureijs
Affiliation: European Space Agency, ESTEC, Keplerlaan 1, 2201 AZ Noordwijk, The Netherlands
  
C. R. Lawrence
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
S. Leach
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
J. P. Leahy
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
R. Leonardi
Affiliation: European Space Agency, ESAC, Planck Science Office, Camino bajo del Castillo, s/n, Urbanización Villafranca del Castillo, Villanueva de la Cañada, Madrid, Spain
  
J. Lesgourgues
Affiliation: SB-ITP-LPPC, EPFL, CH-1015, Lausanne, Switzerland
Affiliation: Theory Division, PH-TH, CERN, CH-1211, Geneva 23, Switzerland
  
A. Lewis
Affiliation: Department of Physics and Astronomy, University of Sussex, Brighton BN1 9QH, U.K.
  
M. Liguori
Affiliation: Dipartimento di Fisica e Astronomia G. Galilei, Università degli Studi di Padova, via Marzolo 8, 35131 Padova, Italy
  
P. B. Lilje
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
M. Linden-Vørnle
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
M. López-Caniego
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
P. M. Lubin
Affiliation: Department of Physics, University of California, Santa Barbara, California, U.S.A.
  
J. F. Macías-Pérez
Affiliation: Laboratoire de Physique Subatomique et de Cosmologie, Université Joseph Fourier Grenoble I, CNRS/IN2P3, Institut National Polytechnique de Grenoble, 53 rue des Martyrs, 38026 Grenoble cedex, France
  
B. Maffei
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
D. Maino
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
N. Mandolesi
Affiliation: Agenzia Spaziale Italiana, Viale Liegi 26, Roma, Italy
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
M. Maris
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
D. J. Marshall
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
P. G. Martin
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
  
E. Martínez-González
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
S. Masi
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
M. Massardi
Affiliation: INAF Istituto di Radioastronomia, Via P. Gobetti 101, 40129 Bologna, Italy
  
S. Matarrese
Affiliation: Dipartimento di Fisica e Astronomia G. Galilei, Università degli Studi di Padova, via Marzolo 8, 35131 Padova, Italy
  
F. Matthai
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
P. Mazzotta
Affiliation: Dipartimento di Fisica, Università di Roma Tor Vergata, Via della Ricerca Scientifica, 1, Roma, Italy
  
P. R. Meinhold
Affiliation: Department of Physics, University of California, Santa Barbara, California, U.S.A.
  
A. Melchiorri
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
Affiliation: INFN, Sezione di Roma 1, Università di Roma Sapienza, Piazzale Aldo Moro 2, 00185, Roma, Italy
  
L. Mendes
Affiliation: European Space Agency, ESAC, Planck Science Office, Camino bajo del Castillo, s/n, Urbanización Villafranca del Castillo, Villanueva de la Cañada, Madrid, Spain
  
A. Mennella
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
M. Migliaccio
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
S. Mitra
Affiliation: IUCAA, Post Bag 4, Ganeshkhind, Pune University Campus, Pune 411 007, India
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
M.-A. Miville-Deschênes
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
A. Moneti
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
  
L. Montier
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
G. Morgante
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
D. Mortlock
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
A. Moss
Affiliation: School of Physics and Astronomy, University of Nottingham, Nottingham NG7 2RD, U.K.
  
D. Munshi
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
J. A. Murphy
Affiliation: National University of Ireland, Department of Experimental Physics, Maynooth, Co. Kildare, Ireland
  
P. Naselsky
Affiliation: Discovery Center, Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
Affiliation: Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
  
F. Nati
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
P. Natoli
Affiliation: Agenzia Spaziale Italiana Science Data Center, Via del Politecnico snc, 00133, Roma, Italy
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
C. B. Netterfield
Affiliation: Department of Astronomy and Astrophysics, University of Toronto, 50 Saint George Street, Toronto, Ontario, Canada
  
H. U. Nørgaard-Nielsen
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
F. Noviello
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
D. Novikov
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
I. Novikov
Affiliation: Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
  
I. J. O’Dwyer
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
S. Osborne
Affiliation: Stanford University, Dept of Physics, Varian Physics Bldg, 382 Via Pueblo Mall, Stanford, California, U.S.A.
  
C. A. Oxborrow
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
F. Paci
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
L. Pagano
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
Affiliation: INFN, Sezione di Roma 1, Università di Roma Sapienza, Piazzale Aldo Moro 2, 00185, Roma, Italy
  
F. Pajot
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
R. Paladini
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
S. Pandolfi
Affiliation: Dipartimento di Fisica, Università di Roma Tor Vergata, Via della Ricerca Scientifica, 1, Roma, Italy
  
D. Paoletti
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: INFN, Sezione di Bologna, Via Irnerio 46, I-40126, Bologna, Italy
  
B. Partridge
Affiliation: Haverford College Astronomy Department, 370 Lancaster Avenue, Haverford, Pennsylvania, U.S.A.
  
F. Pasian
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
G. Patanchon
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
  
H. V. Peiris
Affiliation: Department of Physics and Astronomy, University College London, London WC1E 6BT, U.K.
  
O. Perdereau
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
L. Perotto
Affiliation: Laboratoire de Physique Subatomique et de Cosmologie, Université Joseph Fourier Grenoble I, CNRS/IN2P3, Institut National Polytechnique de Grenoble, 53 rue des Martyrs, 38026 Grenoble cedex, France
  
F. Perrotta
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
F. Piacentini
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
M. Piat
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
  
E. Pierpaoli
Affiliation: Department of Physics and Astronomy, Dana and David Dornsife College of Letter, Arts and Sciences, University of Southern California, Los Angeles, CA 90089, U.S.A.
  
D. Pietrobon
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
S. Plaszczynski
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
E. Pointecouteau
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
G. Polenta
Affiliation: Agenzia Spaziale Italiana Science Data Center, Via del Politecnico snc, 00133, Roma, Italy
Affiliation: INAF - Osservatorio Astronomico di Roma, via di Frascati 33, Monte Porzio Catone, Italy
  
N. Ponthieu
Affiliation: IPAG: Institut de Planétologie et d’Astrophysique de Grenoble, Université Joseph Fourier, Grenoble 1 / CNRS-INSU, UMR 5274, Grenoble, F-38041, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
L. Popa
Affiliation: Institute for Space Sciences, Bucharest-Magurale, Romania
  
T. Poutanen
Affiliation: Aalto University Metsähovi Radio Observatory, Metsähovintie 114, FIN-02540 Kylmälä, Finland
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
G. W. Pratt
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
G. Prézeau
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
S. Prunet
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
J.-L. Puget
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
J. P. Rachen
Affiliation: Department of Astrophysics/IMAPP, Radboud University Nijmegen, P.O. Box 9010, 6500 GL Nijmegen, The Netherlands
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
R. Rebolo
Affiliation: Consejo Superior de Investigaciones Científicas (CSIC), Madrid, Spain
Affiliation: Dpto. Astrofísica, Universidad de La Laguna (ULL), E-38206 La Laguna, Tenerife, Spain
Affiliation: Instituto de Astrofísica de Canarias, C/Vía Láctea s/n, La Laguna, Tenerife, Spain
  
M. Reinecke
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
M. Remazeilles
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
C. Renault
Affiliation: Laboratoire de Physique Subatomique et de Cosmologie, Université Joseph Fourier Grenoble I, CNRS/IN2P3, Institut National Polytechnique de Grenoble, 53 rue des Martyrs, 38026 Grenoble cedex, France
  
S. Ricciardi
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
T. Riller
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
I. Ristorcelli
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
G. Rocha
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
C. Rosset
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
  
G. Roudier
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
M. Rowan-Robinson
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
J. A. Rubiño-Martín
Affiliation: Dpto. Astrofísica, Universidad de La Laguna (ULL), E-38206 La Laguna, Tenerife, Spain
Affiliation: Instituto de Astrofísica de Canarias, C/Vía Láctea s/n, La Laguna, Tenerife, Spain
  
B. Rusholme
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
M. Sandri
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
D. Santos
Affiliation: Laboratoire de Physique Subatomique et de Cosmologie, Université Joseph Fourier Grenoble I, CNRS/IN2P3, Institut National Polytechnique de Grenoble, 53 rue des Martyrs, 38026 Grenoble cedex, France
  
M. Savelainen
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
G. Savini
Affiliation: Optical Science Laboratory, University College London, Gower Street, London, U.K.
  
D. Scott
Affiliation: Department of Physics & Astronomy, University of British Columbia, 6224 Agricultural Road, Vancouver, British Columbia, Canada
  
M. D. Seiffert
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
E. P. S. Shellard
Affiliation: Centre for Theoretical Cosmology, DAMTP, University of Cambridge, Wilberforce Road, Cambridge CB3 0WA, U.K.
  
L. D. Spencer
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
J.-L. Starck
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
V. Stolyarov
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
Affiliation: Special Astrophysical Observatory, Russian Academy of Sciences, Nizhnij Arkhyz, Zelenchukskiy region, Karachai-Cherkessian Republic, 369167, Russia
  
R. Stompor
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
  
R. Sudiwala
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
R. Sunyaev
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
Affiliation: Space Research Institute (IKI), Russian Academy of Sciences, Profsoyuznaya Str, 84/32, Moscow, 117997, Russia
  
F. Sureau
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
D. Sutton
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
A.-S. Suur-Uski
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
J.-F. Sygnet
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
  
J. A. Tauber
Affiliation: European Space Agency, ESTEC, Keplerlaan 1, 2201 AZ Noordwijk, The Netherlands
  
D. Tavagnacco
Affiliation: Dipartimento di Fisica, Università degli Studi di Trieste, via A. Valerio 2, Trieste, Italy
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
L. Terenzi
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
L. Toffolatti
Affiliation: Departamento de Física, Universidad de Oviedo, Avda. Calvo Sotelo s/n, Oviedo, Spain
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
M. Tomasi
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
J. Tréguer-Goudineau
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
  
M. Tristram
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
M. Tucci
Affiliation: Département de Physique Théorique, Université de Genève, 24, Quai E. Ansermet,1211 Genève 4, Switzerland
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
J. Tuovinen
Affiliation: MilliLab, VTT Technical Research Centre of Finland, Tietotie 3, Espoo, Finland
  
L. Valenziano
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
J. Valiviita
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
B. Van Tent
Affiliation: Laboratoire de Physique Théorique, Université Paris-Sud 11 & CNRS, Bâtiment 210, 91405 Orsay, France
  
J. Varis
Affiliation: MilliLab, VTT Technical Research Centre of Finland, Tietotie 3, Espoo, Finland
  
P. Vielva
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
F. Villa
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
N. Vittorio
Affiliation: Dipartimento di Fisica, Università di Roma Tor Vergata, Via della Ricerca Scientifica, 1, Roma, Italy
  
L. A. Wade
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
B. D. Wandelt
Affiliation: Department of Physics, University of Illinois at Urbana-Champaign, 1110 West Green Street, Urbana, Illinois, U.S.A.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
M. White
Affiliation: Department of Physics, University of California, Berkeley, California, U.S.A.
  
A. Wilkinson
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
D. Yvon
Affiliation: DSM/Irfu/SPP, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
A. Zacchei
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
J. P. Zibin
Affiliation: Department of Physics & Astronomy, University of British Columbia, 6224 Agricultural Road, Vancouver, British Columbia, Canada
  
A. Zonca
Affiliation: Department of Physics, University of California, Santa Barbara, California, U.S.A.

###### Abstract

We analyse the implications of the Planck data for cosmic
inflation. The Planck nominal mission temperature anisotropy measurements,
combined with the WMAP large-angle polarization, constrain
the scalar spectral index to be $n\_{\mathrm{s}}=0.9603\pm 0.0073$,
ruling out exact scale invariance at over 5$\sigma.$
Planck establishes an upper bound on
the tensor-to-scalar ratio of $r<0.11$ (95% CL).
The Planck data thus shrink the space of allowed standard inflationary models,
preferring potentials with $V^{\prime\prime}<0$.
Exponential potential models, the simplest hybrid inflationary models,
and monomial potential models of degree $n\geq 2$ do not provide a good fit to the data.
Planck does not find statistically significant running of the scalar spectral index, obtaining
$\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k=-0.0134\pm 0.0090$.
We verify these conclusions through a numerical analysis, which makes no slow-roll approximation,
and carry out a Bayesian parameter estimation and model-selection analysis for a number of inflationary models
including monomial, natural, and hilltop potentials.
For each model, we present the
Planck constraints on the parameters of the potential and explore several possibilities for the
post-inflationary entropy generation epoch,
thus obtaining nontrivial data-driven constraints. We also present a direct reconstruction of the observable
range of the inflaton potential. Unless a quartic term is allowed in the potential,
we find results consistent with second-order slow-roll predictions.
We also investigate whether the primordial power spectrum
contains any features.
We find that models with a parameterized oscillatory feature improve the fit by
$\Delta\chi^{2}\_{\mathrm{eff}}\approx 10$; however, Bayesian evidence does not prefer these models.
We constrain several single-field inflation models with generalized Lagrangians by combining power spectrum data with Planck bounds
on $f\_{\mathrm{NL}}$.
Planck constrains with unprecedented accuracy the amplitude and possible
correlation (with the adiabatic mode) of non-decaying isocurvature fluctuations.
The fractional primordial contributions of cold dark matter (CDM)
isocurvature modes of the types expected in the curvaton and axion scenarios have
upper bounds of 0.25% and 3.9% (95% CL), respectively.
In models with arbitrarily correlated CDM or neutrino isocurvature modes, an
anticorrelated isocurvature component can improve the $\chi^{2}\_{\mathrm{eff}}$ by approximately $4$
as a result of slightly lowering the theoretical prediction for the $\ell\mathrel{\raise 1.29167pt\hbox{$<$}\mkern-14.0mu\lower 2.58334pt\hbox{$\sim$}}40$ multipoles relative to the higher
multipoles. Nonetheless, the data are consistent with adiabatic initial conditions.

###### Key Words.

Cosmology: theory – early Universe – inflation

## 1 Introduction

This paper, one of a set associated with the 2013 release
of data from the Planck11
1
Planck (<http://www.esa.int/Planck>) is a project of the European Space
Agency (ESA) with instruments provided by two scientific consortia funded by ESA member
states (in particular the lead countries France and Italy), with contributions from NASA
(USA) and telescope reflectors provided by a collaboration between ESA and a scientific
consortium led and funded by Denmark. mission
([Planck Collaboration
I (2014)](#bib.bib241)–[Planck Collaboration
XXXI (2014)](#bib.bib271)),
describes the implications of the
Planck measurement of cosmic microwave background (CMB) anisotropies for cosmic inflation.
In this first release only the Planck temperature data resulting from the nominal mission are used,
which includes $2.6$ full surveys of the sky.
The interpretation of the CMB polarization as seen by Planck will be presented in a later series of publications.
This paper exploits the data presented in
[Planck Collaboration
II (2014)](#bib.bib242),
[Planck Collaboration
XII (2014)](#bib.bib252),
[Planck Collaboration
XV (2014)](#bib.bib255), and
[Planck Collaboration
XVII (2014)](#bib.bib257).
Other closely related papers discuss the estimates of cosmological parameters in [Planck Collaboration
XVI (2014)](#bib.bib256)
and investigations of non-Gaussianity in [Planck Collaboration
XXIV (2014)](#bib.bib264).

In the early 1980s inflationary cosmology, which postulates an
epoch of nearly exponential expansion, was proposed in order to
resolve a number of puzzles of standard big bang cosmology
such as the entropy, flatness, horizon, smoothness, and monopole problems
([Brout et al., 1978](#bib.bib51); [Starobinsky, 1980](#bib.bib306); [Kazanas, 1980](#bib.bib144); [Sato, 1981](#bib.bib288); [Guth, 1981](#bib.bib121); [Linde, 1982](#bib.bib177); [Albrecht & Steinhardt, 1982](#bib.bib11); [Linde, 1983](#bib.bib178)).
During inflation,
cosmological fluctuations resulting from quantum fluctuations
are generated and can be calculated using the semiclassical
theory of quantum fields in curved spacetime
([Mukhanov & Chibisov, 1981](#bib.bib217); [Mukhanov & Chibisov, 1982](#bib.bib218); [Hawking, 1982](#bib.bib133); [Guth & Pi, 1982](#bib.bib123); [Starobinsky, 1982](#bib.bib307); [Bardeen et al., 1983](#bib.bib24); [Mukhanov, 1985](#bib.bib215)).

Cosmological observations prior to Planck are consistent with
the simplest models of inflation within the slow-roll paradigm.
Recent observations of the CMB anisotropies
([Story et al., 2013](#bib.bib316); [Bennett et al., 2013](#bib.bib40); [Hinshaw et al., 2013](#bib.bib136); [Hou et al., 2012](#bib.bib138); [Das et al., 2013](#bib.bib77))
and of large-scale structure ([Beutler et al., 2011](#bib.bib41); [Padmanabhan et al., 2012](#bib.bib227); [Anderson et al., 2012](#bib.bib16))
indicate that our Universe is very close to spatially flat and has
primordial density fluctuations that are nearly Gaussian and adiabatic and are described
by a nearly scale-invariant power spectrum.
Pre-Planck CMB observations also
established that the amplitude of primordial gravitational waves, with a nearly scale-invariant spectrum
([Starobinsky, 1979](#bib.bib305); [Rubakov et al., 1982](#bib.bib282); [Fabbri & Pollock, 1983](#bib.bib94)), is at most small.

Most of the results in this paper are based on the two-point statistics of the CMB as
measured by Planck,
exploiting the data presented in [Planck Collaboration
XV (2014)](#bib.bib255), [Planck Collaboration
XVI (2014)](#bib.bib256), and [Planck Collaboration
XVII (2014)](#bib.bib257).
The Planck results testing the Gaussianity
of the primordial CMB component are described in the companion papers
[Planck Collaboration
XXIII (2014)](#bib.bib263),
[Planck Collaboration
XXIV (2014)](#bib.bib264), and [Planck Collaboration
XXV (2014)](#bib.bib265).
Planck finds values for
the non-Gaussian $f\_{\mathrm{NL}}$ parameter of the CMB bispectrum consistent with the Gaussian hypothesis
([Planck Collaboration
XXIV, 2014](#bib.bib264)).
This result has important implications for inflation.
The simplest slow-roll inflationary models
predict a level of
$f\_{\mathrm{NL}}$ of the same order as the slow-roll parameters and therefore too small to be detected by Planck.

The paper is organized as follows. Section [2](#S2 "2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") reviews
inflationary theory, emphasizing in particular those aspects used later in the paper.
In Sect. [3](#S3 "3 Methodology ‣ Planck 2013 results. XXII. Constraints on inflation") the statistical methodology
and the Planck likelihood as well as the likelihoods
from the other astrophysical data sets used here are described. Section [4](#S4 "4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation")
presents constraints on slow-roll inflation
and studies their robustness
under generalizations of the minimal
assumptions of our baseline cosmological model.
In Sect. [5](#S5 "5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation") Bayesian model comparison of several inflationary models is carried out taking into account
the uncertainty from the end of inflation to the beginning of the radiation dominated era.
Section [6](#S6 "6 Observable window of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") reconstructs the inflationary potential over the range corresponding to the scales observable in the CMB. In
Sect. [7](#S7 "7 Primordial power spectrum reconstruction ‣ Planck 2013 results. XXII. Constraints on inflation") a penalized likelihood reconstruction of the primordial perturbation spectrum is performed. Section
[8](#S8 "8 Parametric searches for primordial power spectrum features ‣ Planck 2013 results. XXII. Constraints on inflation") reports on a parametric search for oscillations and features in the primordial
scalar power spectrum. Section [9](#S9 "9 Combined analysis with Planck 𝑓_NL constraints for single field inflation ‣ Planck 2013 results. XXII. Constraints on inflation") examines constraints on non-canonical single-field models
of inflation including the $f\_{\mathrm{NL}}$ measurements from [Planck Collaboration
XXIV (2014)](#bib.bib264).
In Sect. [10](#S10 "10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation")
constraints on isocurvature modes are established, thus
testing the hypothesis that initial conditions were solely
adiabatic. We summarize our conclusions in Sect. [11](#S11 "11 Conclusions ‣ Planck 2013 results. XXII. Constraints on inflation").
Appendix A is dedicated to the constraints on slow-roll inflation derived by
sampling the Hubble flow functions (HFF) in the analytic expressions for the scalar
and tensor power spectra. Definitions of the most relevant symbols used in this paper
can be found in Tables [1](#S2.T1 "Table 1 ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") and [2](#S2.T2 "Table 2 ‣ 2.1 Cosmic inflation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation").

## 2 Lightning review of inflation

Table 1: Cosmological parameter definitions

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  | | --- | --- | | Parameter | Definition | | $\Omega\_{\mathrm{b}}$. | Baryon fraction today (compared to critical density) | | $\Omega\_{\mathrm{c}}$. | Cold dark matter fraction today (compared to critical density) | | $h$. | Current expansion rate (as fraction of 100 km s-1 Mpc-1) | | $\theta\_{\mathrm{M}C}$. | Approximation to the angular size of sound horizon at last scattering | | $\tau$. | Thomson scattering optical depth of reionized intergalactic medium | | $N\_{\mathrm{eff}}$. | Effective number of massive and massless neutrinos | | $\Sigma m\_{\nu}$. | Sum of neutrino masses | | $Y\_{\mathrm{P}}$. | Fraction of baryonic mass in primordial helium | | $\Omega\_{K}$. | Spatial curvature parameter | | $w\_{\mathrm{de}}$. | Dark energy equation of state parameter (i.e., $p/\rho$) (assumed constant) | | ${\mathcal{R}}$. | Curvature perturbation | | ${\mathcal{I}}$. | Isocurvature perturbation | | $\mathcal{P}\_{X}={k^{3}|X\_{k}|^{2}}/{2\pi^{2}}$. | Power spectrum of $X$ | | $A\_{X}$. | $X$ power spectrum amplitude (at $k\_{\*}=0.05$ Mpc-1) | | $n\_{\mathrm{s}}$. | Scalar spectrum spectral index (at $k\_{\*}=0.05$ Mpc-1, unless otherwise stated) | | $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$. | Running of scalar spectral index (at $k\_{\*}=0.05$ Mpc-1, unless otherwise stated) | | $\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}$. | Running of running of scalar spectral index (at $k\_{\*}=0.05$ Mpc-1) | | $r$. | Tensor-to-scalar power ratio (at $k\_{\*}=0.05$ Mpc-1, unless otherwise stated) | | $n\_{\mathrm{t}}$. | Tensor spectrum spectral index (at $k\_{\*}=0.05$ Mpc-1) | | $\mathrm{d}n\_{\mathrm{t}}/\mathrm{d}\ln k$. | Running of tensor spectral index (at $k\_{\*}=0.05$ Mpc-1) | |  |

Before describing cosmic inflation, which was developed in the early 1980s, it
is useful to review the state of theory prior to its introduction. [Lifshitz (1946)](#bib.bib174) (see also
[Lifshitz & Khalatnikov (1963)](#bib.bib175)) first wrote down and solved the equations for the evolution of linearized
perturbations about a
homogeneous and isotropic Friedmann-Lemaître-Robertson-Walker spacetime within the
framework of general relativity.
The general framework adopted was based on two assumptions:

1. (i)

   The cosmological perturbations can be described by a single-component fluid,
   at very early times.
2. (ii)

   The initial cosmological perturbations were statistically
   homogeneous and isotropic, and Gaussian.

These are the simplest—but by no means unique—assumptions for defining a stochastic
process for the initial conditions. Assumption (i), where only a single
adiabatic mode is excited, is just the simplest possibility.
In Sect. [10](#S10 "10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation") we shall describe isocurvature perturbations,
where other available modes are excited,
and report on the constraints established by Planck.
Assumption (ii) is a priori more questionable given the understanding
at the time. An appeal can be made to the fact that any physics at weak coupling
could explain (ii), but at the time these assumptions were somewhat ad hoc.

Even with the strong assumptions (i) and (ii), comparisons with observations cannot be made
without further restrictions on the functional form of the primordial power spectrum of large-scale
spatial curvature inhomogeneities $\mathcal{R}$,
$\mathcal{P\_{R}}(k)\propto k^{n\_{\mathrm{s}}-1}$, where $n\_{\mathrm{s}}$ is the (scalar) spectral index.
The notion of a scale-invariant (i.e., $n\_{\mathrm{s}}=1$) primordial power spectrum
was introduced by [Harrison (1970)](#bib.bib132), [Zeldovich (1972)](#bib.bib336), and [Peebles & Yu (1970)](#bib.bib233) to address
this problem.
These authors showed that a scale-invariant
power law was consistent with the crude constraints on large- and small-scale perturbations available
at the time. However, other than its mathematical simplicity,
no compelling theoretical explanation for this Ansatz was put forth. An important current
question, addressed in Sect. [4](#S4 "4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation"), is whether $n\_{\mathrm{s}}=1$ (i.e., exact scale
invariance) is consistent with
the data, or whether there is convincing evidence for small deviations from exact scale invariance.
Although the inflationary potential can be tuned to obtain $n\_{\mathrm{s}}=1$, inflationary models
generically predict
deviations from $n\_{\mathrm{s}}=1$, usually on the red side (i.e, $n\_{\mathrm{s}}<1$).

### 2.1 Cosmic inflation

Inflation was developed in a series of papers by
[Brout et al. (1978)](#bib.bib51),
[Starobinsky (1980)](#bib.bib306),
[Kazanas (1980)](#bib.bib144),
[Sato (1981)](#bib.bib288),
[Guth (1981)](#bib.bib121),
[Linde (1982)](#bib.bib177); [Linde (1983)](#bib.bib178),
and
[Albrecht & Steinhardt (1982)](#bib.bib11).
By generating an equation of state with a significant negative pressure
(i.e., $w=p/\rho\approx-1$) before the radiation epoch, inflation solves a number of
cosmological conundrums (the monopole, horizon, smoothness, and entropy
problems), which had plagued all cosmological models extrapolating
a matter-radiation equation of state all the way back to the singularity.
Such an equation of state ($p\approx-\rho$) and the resulting nearly exponential expansion
are obtained from a scalar field, the *inflaton*, with a
canonical kinetic term (i.e., $\frac{1}{2}(\partial\phi)^{2}$), slowly rolling
in the framework of Einstein gravity.

The homogeneous evolution of the inflaton field $\phi$ is governed by the equation of motion

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\ddot{\phi}(t)+3H(t)\dot{\phi}(t)+V\_{\phi}=0,$ |  | (1) |

and the Friedmann equation

|  |  |  |  |
| --- | --- | --- | --- |
|  | $H^{2}=\frac{1}{3{M\_{\mathrm{pl}}}^{2}}\left(\frac{1}{2}\dot{\phi}^{2}+V(\phi)\right).$ |  | (2) |

Here $H=\dot{a}/a$ is the Hubble parameter, the subscript ${\phi}$ denotes
the derivative with respect to $\phi,$
$M\_{\mathrm{pl}}=(8\pi G)^{-1/2}$ is the reduced Planck mass, and $V$ is the potential.
(We use units where $c=\hbar=1.$)
The evolution during the stage of quasi-exponential expansion, when
the scalar field rolls slowly down the potential,
can be approximated by neglecting the second time derivative in
Eq. [1](#S2.E1 "In 2.1 Cosmic inflation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") and the kinetic energy term in Eq. [2](#S2.E2 "In 2.1 Cosmic inflation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), so that

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle 3H(t)\dot{\phi}(t)$ | $\displaystyle\approx-V\_{\phi}\thinspace,$ |  | (3) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle H^{2}$ | $\displaystyle\approx\frac{V(\phi)}{3{M\_{\mathrm{pl}}}^{2}}\thinspace.$ |  | (4) |

Necessary conditions for the slow-roll described above are
$\epsilon\_{V}\ll 1$ and $|\eta\_{V}|\ll 1$, where
the slow-roll parameters $\epsilon\_{V}$ and $\eta\_{V}$ are defined as

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\epsilon\_{V}$ | $\displaystyle=\frac{M\_{\mathrm{pl}}^{2}V\_{\phi}^{2}}{2V^{2}}\thinspace,$ |  | (5) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\eta\_{V}$ | $\displaystyle=\frac{M\_{\mathrm{pl}}^{2}V\_{\phi\phi}}{V}\thinspace.$ |  | (6) |

The analogous hierarchy of HFF slow-roll parameters measures instead the deviation
from an exact exponential expansion.
This hierarchy is defined as $\epsilon\_{1}=-\dot{H}/H^{2}$,
$\epsilon\_{i+1}\equiv\dot{\epsilon}\_{i}/(H\epsilon\_{i})$, with $i\geq 1$. By using
Eqs. [3](#S2.E3 "In 2.1 Cosmic inflation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") and [4](#S2.E4 "In 2.1 Cosmic inflation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"),
we have that
$\epsilon\_{1}\approx\epsilon\_{V}$, $\epsilon\_{2}\approx-2\eta\_{V}+4\epsilon\_{V}$.

Table 2: Conventions and definitions for inflation physics

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  | | --- | --- | | Parameter | Definition | | $\phi$. | Inflaton | | $V(\phi)$. | Inflaton potential | | $a$. | Scale factor | | $t$. | Cosmic (proper) time | | $\delta X$. | Fluctuation of $X$ | | $\dot{X}=\mathrm{d}X/\mathrm{d}t$. | Derivative with respect to proper time | | $X^{\prime}=\mathrm{d}X/\mathrm{d}\eta$. | Derivative with respect to conformal time | | $X\_{\phi}=\partial X/\partial\phi$. | Partial derivative with respect to $\phi$ | | $M\_{\mathrm{pl}}$. | Reduced Planck mass ($=2.435\times 10^{18}$ GeV) | | $Q$. | Scalar perturbation variable | | $h^{+,\times}$. | Gravitational wave amplitude of $(+,\times)$-polarization component | | $X\_{\*}$. | $X$ evaluated at Hubble exit during inflation of mode with wavenumber $k\_{\*}$ | | $X\_{\mathrm{e}}$. | $X$ evaluated at end of inflation | | $\epsilon\_{V}={M\_{\mathrm{pl}}^{2}V\_{\phi}^{2}}/{2V^{2}}$. | First slow-roll parameter for $V(\phi)$ | | $\eta\_{V}={M\_{\mathrm{pl}}^{2}V\_{\phi\phi}}/{V}$. | Second slow-roll parameter for $V(\phi)$ | | $\xi^{2}\_{V}={M\_{\mathrm{pl}}^{4}V\_{\phi}V\_{\phi\phi\phi}}/{V^{2}}$. | Third slow-roll parameter for $V(\phi)$ | | $\varpi^{3}\_{V}={M\_{\mathrm{pl}}^{6}V\_{\phi}^{2}V\_{\phi\phi\phi\phi}}/{V^{3}}$. | Fourth slow-roll parameter for $V(\phi)$ | | $\epsilon\_{1}=-{\dot{H}}/{H^{2}}$. | First Hubble hierarchy parameter | | $\epsilon\_{n+1}={\dot{\epsilon}\_{n}}/{H\epsilon\_{n}}$. | $(n+1)$th Hubble hierarchy parameter (where $n\geq 1$) | | $N(t)=\int\_{t}^{t\_{\mathrm{e}}}\!\mathrm{d}t\;H$. | Number of $e$-folds to end of inflation | | $\delta\sigma$. | Curvature field perturbation | | $\delta s$. | Isocurvature field perturbation | |  |

### 2.2 Quantum generation of fluctuations

Without quantum fluctuations, inflationary theory would fail.
Classically,
any initial spatial curvature or gradients in the scalar field, as well as any inhomogeneities
in other fields, would rapidly decay away during the quasi-exponential
expansion. The resulting universe would be too homogeneous and
isotropic compared with observations. Quantum fluctuations must exist in order to satisfy the uncertainty relations that follow
from the canonical commutation relations of quantum field theory. The quantum fluctuations in the inflaton and in
the transverse and traceless parts of the metric are amplified by the nearly exponential expansion yielding
the scalar and tensor primordial power spectra, respectively.

Many essentially equivalent approaches to quantizing the linearized cosmological fluctuations can be found in
the original literature ([Mukhanov & Chibisov, 1981](#bib.bib217); [Hawking, 1982](#bib.bib133); [Guth & Pi, 1982](#bib.bib123); [Starobinsky, 1982](#bib.bib307); [Bardeen et al., 1983](#bib.bib24), see, e.g.,).
A simple formalism, which we shall follow here, was introduced by [Mukhanov (1988)](#bib.bib216), [Mukhanov et al. (1992)](#bib.bib219),
and [Sasaki (1986)](#bib.bib284). In this approach a gauge-invariant inflaton fluctuation $Q$ is constructed and canonically quantized.
This gauge-invariant variable $Q$ is the inflaton fluctuation $\delta\phi(t,x)$ in the uniform curvature gauge.
The mode function of the inflaton fluctuations $\delta\phi(t,x)$ obeys the evolution equation

|  |  |  |  |
| --- | --- | --- | --- |
|  | $(a\delta\phi\_{k})^{\prime\prime}+\left(k^{2}-\frac{z^{\prime\prime}}{z}\right)(a\delta\phi\_{k})=0,$ |  | (7) |

where $z=a\dot{\phi}/H$.
The gauge-invariant field fluctuation is directly related to the comoving curvature
perturbation22
2
Another important quantity is the curvature perturbation on uniform density hypersurfaces
$\zeta$ (in the Newtonian gauge, $\zeta=-\psi-H\delta\rho/\dot{\rho}$, where $\psi$ is the generalized gravitational potential),
which is related to the perturbed spatial curvature according to ${}^{(3)}R=-4\nabla^{2}\zeta/a^{2}$. On large
scales $\zeta\approx{\mathcal{R}}$.

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\mathcal{R}}=-H\frac{\delta\phi}{\dot{\phi}}\thinspace.$ |  | (8) |

Analogously, gravitational waves are described by the two polarization states ($+,\times$)
of the transverse traceless parts of the metric fluctuations and are amplified by the expansion of the universe as
well ([Grishchuk, 1975](#bib.bib118)).
The evolution equation for their mode function is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $(ah^{+,\times}\_{k})^{\prime\prime}+\left(k^{2}-\frac{a^{\prime\prime}}{a}\right)(ah^{+,\times}\_{k})=0.$ |  | (9) |

Early discussions of the generation of gravitational waves during
inflation include
[Starobinsky (1979)](#bib.bib305), [Rubakov et al. (1982)](#bib.bib282),
[Fabbri & Pollock (1983)](#bib.bib94), [Abbott & Wise (1984)](#bib.bib1), and [Starobinsky (1985a)](#bib.bib309).

Because the primordial perturbations are small, of order $10^{-5}$, the linearized
Eqs. [7](#S2.E7 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") and
[9](#S2.E9 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") provide an accurate description for the generation
and subsequent evolution of the cosmological perturbations during inflation.
In this paper we use two approaches for solving for the cosmological
perturbations. Firstly, we use an approximate treatment based on the slow-roll
approximation described below. Secondly, we use an almost exact approach based
on numerical integration of the ordinary differential equations [7](#S2.E7 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") and
[9](#S2.E9 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") for each value of the comoving wavenumber $k.$ For fixed $k$
the evolution may be divided into three epochs: (i) sub-Hubble evolution, (ii) Hubble crossing evolution,
and (iii) super-Hubble evolution. During (i) the wavelength is much smaller than the Hubble length,
and the mode oscillates as it would in a non-expanding universe (i.e., Minkowski space). Therefore
we can proceed with quantization as we would in Minkowski space. We
quantize by singling out the positive frequency solution, as in the Bunch-Davies vacuum ([Bunch & Davies, 1978](#bib.bib57)).
This epoch is the oscillating regime in the WKB approximation. In epoch (iii), by contrast,
there are two solutions, a growing and a decaying mode, and the evolution becomes independent
of $k.$ We care only about the growing mode.
On scales much larger than the Hubble radius (i.e., $k\ll aH$), both curvature and tensor fluctuations admit
solutions constant in time.33
3
On
large scales, the curvature fluctuation is constant in time when non-adiabatic pressure terms are negligible. This
condition is typically violated in multi-field inflationary models.
All the interesting, or nontrivial, evolution
takes place between epochs (i) and (iii)—that is, during (ii), a few $e$-folds before and after Hubble
crossing, and this is the interval where the numerical integration is most useful since the asymptotic expansions
are not valid in this transition region. Two numerical codes are used in this paper,
ModeCode ([Adams et al., 2001](#bib.bib5); [Peiris et al., 2003](#bib.bib239); [Mortonson et al., 2009](#bib.bib211); [Easther & Peiris, 2012](#bib.bib88)),
and the inflation module of [Lesgourgues & Valkenburg (2007)](#bib.bib167)
as implemented in CLASS ([Lesgourgues, 2011](#bib.bib165); [Blas et al., 2011](#bib.bib46)).44
4
http://zuserver2.star.ucl.ac.uk/~ hiranya/ModeCode/, http://class-code.net

It is convenient to expand the power spectra of curvature and tensor perturbations on super-Hubble scales as

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{P}\_{\mathcal{R}}(k)$ | $\displaystyle=A\_{\mathrm{s}}\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{s}}-1+\frac{1}{2}\thinspace\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k\ln(k/k\_{\*})+\frac{1}{6}\thinspace\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}\left(\ln(k/k\_{\*})\right)^{2}+...},$ |  | (10) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathcal{P}\_{\mathrm{t}}(k)$ | $\displaystyle=A\_{\mathrm{t}}\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{t}}+\frac{1}{2}\thinspace\mathrm{d}n\_{\mathrm{t}}/\mathrm{d}\ln k\ln(k/k\_{\*})+...},$ |  | (11) |

where $A\_{\mathrm{s}}\thinspace(A\_{\mathrm{t}})$ is the scalar (tensor) amplitude and $n\_{\mathrm{s}}\thinspace(n\_{\mathrm{t}})$, $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k\thinspace(\mathrm{d}n\_{\mathrm{t}}/\mathrm{d}\ln k)$
and $\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}$ are the scalar (tensor) spectral index,
the running of the scalar (tensor) spectral index, and the running of the running of the scalar spectral index, respectively.

The parameters of the scalar and tensor power spectra may be calculated approximately in the framework
of the slow-roll approximation
by evaluating the following equations at the value of the inflation field $\phi\_{\*}$ where the mode
$k\_{\*}=a\_{\*}H\_{\*}$ crosses the Hubble radius for the first time. (For
a nice review of the slow-roll approximation, see for example [Liddle & Lyth (1993)](#bib.bib172)). The number of $e$-folds before the end of
inflation, $N\_{\*}$, at which the
pivot scale $k\_{\*}$ exits from the Hubble radius, is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $N\_{\*}=\int\_{t\_{\*}}^{t\_{\mathrm{e}}}\!\mathrm{d}t\;H\approx\frac{1}{M\_{\mathrm{pl}}^{2}}\int\_{\phi\_{\*}}^{\phi\_{\mathrm{e}}}\!\mathrm{d}\phi\;\frac{V}{V\_{\phi}},$ |  | (12) |

where the equality holds in the slow-roll approximation, and subscript $\mathrm{e}$ denotes the end of inflation.

The coefficients of Eqs. [10](#S2.E10 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") and [11](#S2.E11 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") at
their respective leading orders in the slow-roll parameters are given by

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle A\_{\mathrm{s}}$ | $\displaystyle\approx\frac{V}{24\pi^{2}M\_{\mathrm{pl}}^{4}\epsilon\_{V}},$ |  | (13) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle A\_{\mathrm{t}}$ | $\displaystyle\approx\frac{2V}{3\pi^{2}M\_{\mathrm{pl}}^{4}},$ |  | (14) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle n\_{\mathrm{s}}-1$ | $\displaystyle\approx 2\eta\_{V}-6\epsilon\_{V},$ |  | (15) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle n\_{\mathrm{t}}$ | $\displaystyle\approx-2\epsilon\_{V},$ |  | (16) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ | $\displaystyle\approx+16\epsilon\_{V}\eta\_{V}-24\epsilon^{2}\_{V}-2\xi^{2}\_{V},$ |  | (17) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathrm{d}n\_{\mathrm{t}}/\mathrm{d}\ln k$ | $\displaystyle\approx+4\epsilon\_{V}\eta\_{V}-8\epsilon^{2}\_{V},$ |  | (18) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\begin{split}\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}&\approx-192\epsilon^{3}\_{V}+192\epsilon^{2}\_{V}\eta\_{V}-32\epsilon\_{V}\eta^{2}\_{V}\\ &\quad-24\epsilon\_{V}\xi^{2}\_{V}+2\eta\_{V}\xi^{2}\_{V}+2\varpi^{3}\_{V},\end{split}$ | |  | (19) |

where the slow-roll parameters $\epsilon\_{V}$ and $\eta\_{V}$ are defined in Eqs. [5](#S2.E5 "In 2.1 Cosmic inflation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") and [6](#S2.E6 "In 2.1 Cosmic inflation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"),
and the higher order parameters are defined as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\xi^{2}\_{V}=\frac{M\_{\mathrm{pl}}^{4}V\_{\phi}V\_{\phi\phi\phi}}{V^{2}}$ |  | (20) |

and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\varpi^{3}\_{V}=\frac{M\_{\mathrm{pl}}^{6}V\_{\phi}^{2}V\_{\phi\phi\phi\phi}}{V^{3}}.$ |  | (21) |

In single-field inflation with a standard kinetic term, as discussed here, the tensor
spectrum shape is not independent from the other parameters.
The slow-roll paradigm implies a tensor-to-scalar
ratio at the pivot scale of

|  |  |  |  |
| --- | --- | --- | --- |
|  | $r=\frac{\mathcal{P}\_{\mathrm{t}}(k\_{\*})}{\mathcal{P}\_{\mathcal{R}}(k\_{\*})}\approx 16\epsilon\_{V}\approx-8n\_{\mathrm{t}}\thinspace,$ |  | (22) |

referred to as the consistency relation.
This consistency relation is also useful to help understand how $r$ is connected to the evolution of the inflaton:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{\Delta\phi}{M\_{\mathrm{pl}}}\approx\frac{1}{\sqrt{8}}\int^{N}\_{0}\mathrm{d}N\sqrt{r}\thinspace.$ |  | (23) |

The above relation, called the Lyth bound ([Lyth, 1997](#bib.bib192)),
implies that an inflaton variation of the order of the Planck mass is needed to produce
$r\gtrsim 0.01$. Such a threshold is useful to classify large- and small-field inflationary models with respect to the Lyth bound.

### 2.3 Ending inflation and the epoch of entropy generation

The greatest uncertainty in calculating the perturbation spectrum predicted
from a particular inflationary potential arises
in establishing the correspondence between the comoving wavenumber
today and the inflaton energy density when the mode of that
wavenumber crossed the Hubble radius during inflation ([Kinney & Riotto, 2006](#bib.bib149)).
This correspondence depends both on the inflationary model and
on the cosmological evolution from the end of inflation to the present.

After the slow-roll stage, $\ddot{\phi}$ becomes
as important as the cosmological damping term $3H\dot{\phi}$.
Inflation ends gradually as the inflaton picks up kinetic energy
so that $w$ is no longer slightly above $-1$, but rather far from that
value. We may arbitrarily deem that inflation ends when $w=-1/3$
(the value dividing the cases of
an expanding and a contracting comoving Hubble radius), or,
equivalently, at $\epsilon\_{V}\approx 1,$
after which the epoch of entropy generation starts.
Because of couplings to other fields, the energy initially in the form
of scalar field vacuum energy is transferred to the other fields by
perturbative decay (reheating), possibly
preceded by a non-perturbative stage
(preheating). There is considerable uncertainty about the mechanisms of
entropy generation, or thermalization, which subsequently lead to a standard $w=1/3$ equation of state for radiation.

On the other hand, if we want to identify some $k\_{\*}$ today with the value of
the inflaton field at the time this scale left the Hubble radius, Eq. [12](#S2.E12 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation")
needs to be matched to an expression that
quantifies how much $k\_{\*}$ has shrunk relative to the size of the Hubble radius between
the end of inflation and the time when that mode re-enters the Hubble radius. This quantity depends both
on the inflationary potential and the details of the entropy
generation process and is given by

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle N\_{\*}\approx$ | $\displaystyle 67-\ln\left(\frac{k\_{\*}}{a\_{0}H\_{0}}\right)+\frac{1}{4}\ln\left(\frac{V\_{\*}}{M\_{\mathrm{pl}}^{4}}\right)+\frac{1}{4}\ln\left(\frac{V\_{\*}}{\rho\_{\mathrm{end}}}\right)$ |  | (24) |
|  |  | $\displaystyle+\frac{1-3w\_{\mathrm{int}}}{12(1+w\_{\mathrm{int}})}\ln{\left(\frac{\rho\_{\mathrm{th}}}{\rho\_{\mathrm{end}}}\right)}-\frac{1}{12}\ln(g\_{\mathrm{th}})\;,$ |  |

where $\rho\_{\mathrm{end}}$ is the energy density at the end of inflation,
$\rho\_{\mathrm{th}}$ is an energy scale by which the universe has thermalized,
$a\_{0}H\_{0}$ is the present Hubble radius,
$V\_{\*}$ is the potential energy when $k\_{\*}$ left the Hubble radius
during inflation, $w\_{\mathrm{int}}$ characterizes the effective equation of state
between the end of inflation and the energy scale specified by $\rho\_{\mathrm{th}}$,
and $g\_{\mathrm{th}}$ is the number of effective bosonic degrees of freedom at the energy scale $\rho\_{\mathrm{th}}$.
In predicting the primordial power spectra at observable scales for a specific inflaton potential,
this uncertainty in the reheating history of the universe becomes relevant and can be taken into
account by allowing $N\_{\*}$ to vary over a range of values. Note that $w\_{\mathrm{int}}$ is not intended to
provide a detailed model for entropy generation, but rather to parameterize the uncertainty
regarding the expansion rate of the universe during this intermediate era. Nevertheless,
constraints on $w\_{\mathrm{int}}$ provide observational limits on the uncertain physics during this period.

The first two terms of Eq. [24](#S2.E24 "In 2.3 Ending inflation and the epoch of entropy generation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") are model independent, with the second
term being roughly $5$ for $k\_{\*}=0.05\penalty\ \mathrm{Mpc}^{-1}$. If thermalization occurs
rapidly, or if the reheating stage is close to radiation-like, the magnitude of the
last term in Eq. [24](#S2.E24 "In 2.3 Ending inflation and the epoch of entropy generation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") is less than roughly unity.
The magnitude of the $\ln(g\_{th})/12$ term is negligible, giving a shift
of only 0.58 for the extreme value $g\_{th}=10^{3}.$
For most reasonable inflation models, the fourth term is $\mathcal{O}(1)$ and the third
term is approximately $-10$, motivating the commonly assumed range
$50<N\_{\*}<60$. Nonetheless, more extreme values at both ends are in principle
possible ([Liddle & Leach, 2003](#bib.bib171)).
In the figures of Sect. [4](#S4 "4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation") we will mark the range
$50<N\_{\*}<60$ as a general guide.

### 2.4 Perturbations from cosmic inflation at higher order

To calculate the quantum fluctuations generated during cosmic inflation,
a linearized quantum field theory in a time-dependent background
can be used.
The leading order is the
two-point correlation function

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left<{\mathcal{R}}(\mathbf{k}\_{1})\penalty\ {\mathcal{R}}(\mathbf{k}\_{2})\right>=(2\pi)^{3}\penalty\ \frac{2\pi^{2}}{k^{3}}\mathcal{P}\_{\mathcal{R}}(k)\penalty\ \delta^{3}({\mathbf{k\_{1}}}+{\mathbf{k\_{2}}}),$ |  | (25) |

but the inflaton self-interactions and the nonlinearity of Einstein gravity give small higher-order
corrections, of which the next-to-leading order is the three point function

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left<{\mathcal{R}}(\mathbf{k\_{1}})\penalty\ {\mathcal{R}}(\mathbf{k}\_{2})\penalty\ {\mathcal{R}}(\mathbf{k}\_{3})\right>=(2\pi)^{3}B\_{{\mathcal{R}}}(k\_{1},k\_{2},k\_{3})\delta^{3}({\mathbf{k\_{1}}}+{\mathbf{k\_{2}}}+{\mathbf{k\_{3}}})\thinspace,$ |  | (26) |

which is in general non-zero.

For single-field inflation with a standard kinetic term in a smooth potential
(with initial fluctuations in the Bunch-Davies vacuum), the non-Gaussian
contribution to the curvature perturbation during inflation is ${\mathcal{O}}(\epsilon\_{V}\thinspace,\eta\_{V})$
([Acquaviva et al., 2003](#bib.bib3); [Maldacena, 2003](#bib.bib199)), i.e.,
at an undetectable level smaller than
other general relativistic contributions, such as the cross-correlation between the integrated Sachs-Wolfe effect and
weak gravitational lensing of the CMB. For a general scalar field
Lagrangian, the non-Gaussian contribution can be large enough to be accessible to Planck with $f\_{\mathrm{NL}}$ of order $c\_{\mathrm{s}}^{-2}$ ([Chen et al., 2007](#bib.bib65)),
where $c\_{\mathrm{s}}$ is the sound speed of inflaton fluctuations
(see Sect. [9](#S9 "9 Combined analysis with Planck 𝑓_NL constraints for single field inflation ‣ Planck 2013 results. XXII. Constraints on inflation")). Other higher order
kinetic and spatial derivative
terms contribute to larger non-Gaussianities.
For a review of non-Gaussianity generated during inflation,
see, for example, [Bartolo et al. (2004a)](#bib.bib27) and [Chen (2010)](#bib.bib64) as well as the companion paper [Planck Collaboration
XXIV (2014)](#bib.bib264).

### 2.5 Multi-field models of cosmic inflation

Inflation as described so far assumes a single scalar field that drives and terminates
the quasi-exponential expansion and also
generates the large-scale curvature perturbations.
When there is more than one field with an effective mass smaller than $H$,
isocurvature perturbations are also generated during inflation by the same mechanism of
amplification due to the stretching of the spacetime geometry
([Axenides et al., 1983](#bib.bib20); [Linde, 1985](#bib.bib180)).
Cosmological perturbations in models with an
$M$-component inflaton $\phi\_{i}$ can be analysed by considering
perturbations parallel and perpendicular
to the classical trajectory, as treated for example in [Gordon et al. (2001)](#bib.bib112).
The definition of
curvature perturbation generalizing Eq. [8](#S2.E8 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") to the multi-field case is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{R}=-H\frac{\sum\_{i=1}^{M}\dot{\phi}\_{i}Q\_{i}}{\dot{\sigma}^{2}}\thinspace,$ |  | (27) |

where $Q\_{i}$ is the gauge-invariant field fluctuation associated with $\phi\_{i}$
and $\dot{\sigma}^{2}\equiv\sum\_{i=1}^{M}\dot{\phi}^{2}\_{i}$.
The above formula for the
curvature perturbation can also be obtained through the
$\delta N$ formalism, i.e.,
$\mathcal{R}=\sum\_{i=1}^{M}(\partial N/\partial\phi\_{i})Q\_{i}$,
where the number of $e$-folds to the end of inflation $N$ is generalized to
the multi-field case ([Starobinsky, 1985b](#bib.bib310); [Sasaki & Stewart, 1996](#bib.bib285)).
The $M-1$ normal directions are connected to $M-1$
isocurvature perturbations $\delta s\_{ij}$
according to

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\delta s\_{ij}=\frac{\dot{\phi}\_{i}Q\_{j}-\dot{\phi}\_{j}Q\_{i}}{\dot{\sigma}}.$ |  | (28) |

If the trajectory of the average field is curved in field space,
then during inflation both curvature and isocurvature fluctuations are
generated with non-vanishing correlations ([Langlois, 1999](#bib.bib161)).

Isocurvature perturbations can be converted into curvature perturbations
on large scales, but the opposite does not hold ([Mollerach, 1990](#bib.bib208)).
If such isocurvature perturbations are not totally converted into
curvature perturbations,
they can have observable effects on CMB
anisotropies and on structure formation. In Sect. [10](#S10 "10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation"),
we present the Planck constraints on
a combination of curvature and isocurvature initial conditions and the
implications for important two-field scenarios, such as the curvaton ([Lyth & Wands, 2002](#bib.bib197)) and axion ([Lyth, 1990](#bib.bib191))
models.

Isocurvature perturbations may lead to a higher level of non-Gaussianity
compared to a single inflaton with a standard kinetic term
([Groot Nibbelink & van Tent, 2000](#bib.bib119)).
There is no reason to expect
the inflaton to be a single-component field. The scalar sector of the
Standard Model, as well as its extensions, contains
more than one scalar field.

## 3 Methodology

### 3.1 Cosmological model and parameters

The parameters of the models to be estimated in this paper fall
into three categories:
(i) parameters describing the initial perturbations, i.e., characterizing the particular inflationary
scenario in question;
(ii) parameters determining cosmological evolution at late times ($z\lesssim 10^{4}$);
and (iii) parameters that
quantify our uncertainty about the instrument and foreground
contributions to the angular power spectrum.
These will be described in Sect. [3.2.1](#S3.SS2.SSS1 "3.2.1 Planck CMB temperature data ‣ 3.2 Data ‣ 3 Methodology ‣ Planck 2013 results. XXII. Constraints on inflation").

Unless specified otherwise, we assume that the late time cosmology is
the standard flat six-parameter $\Lambda$CDM model whose energy content
consists of photons, baryons, cold dark matter, neutrinos (assuming
$N\_{\mathrm{eff}}=3.046$ effective species, one of which is taken to be massive,
with a mass of $m\_{\nu}=0.06$ eV), and a cosmological constant. The primordial helium fraction,
$Y\_{\mathrm{P}}$, is set as a function of $\Omega\_{\mathrm{b}}h^{2}$ and $N\_{\mathrm{eff}}$
according to the big bang nucleosynthesis consistency condition
([Ichikawa & Takahashi, 2006](#bib.bib140); [Hamann et al., 2008b](#bib.bib127)), and we fix the CMB mean temperature to $T\_{0}=2.7255$ K
([Fixsen, 2009](#bib.bib100)).
Reionization is modelled to occur instantaneously at a redshift
$z\_{\mathrm{re}}$, and the optical depth $\tau$ is calculated as a function of $z\_{\mathrm{re}}.$
This model can be characterized by four free cosmological
parameters: $\Omega\_{\mathrm{b}}h^{2},\Omega\_{\mathrm{c}}h^{2},\theta\_{\mathrm{MC}},$ and $\tau,$ defined in Table [1](#S2.T1 "Table 1 ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), in addition to the
parameters describing the initial perturbations.

### 3.2 Data

The primary CMB data used for this paper consist of the Planck CMB temperature likelihood
supplemented by
the Wilkinson Microwave Anisotropy Probe (WMAP henceforth)
large-scale polarization likelihood (henceforth Planck+WP), as described in
Sect. [3.2.1](#S3.SS2.SSS1 "3.2.1 Planck CMB temperature data ‣ 3.2 Data ‣ 3 Methodology ‣ Planck 2013 results. XXII. Constraints on inflation"). The large-angle $E$-mode polarization spectrum is important for
constraining reionization because it breaks the degeneracy in the temperature
data between the primordial power spectrum amplitude and the optical depth to reionization.
In the analysis constraining cosmic inflation, we restrict ourselves to combining the Planck
temperature data with various combinations of the following additional data sets: the Planck
lensing power spectrum, other CMB data extending the Planck data to higher $\ell,$ and BAO data.
For the higher-resolution CMB data we use measurements
from the Atacama Cosmology Telescope (ACT) and the South Pole Telescope (SPT).
These
complementary data sets are among the most useful to break degeneracies in parameters.
The consequences of including other data sets such as Supernovae Type Ia (SN Ia)
or the local measurement of the Hubble constant $H\_{0}$ on some of the cosmological models
discussed here can be found in the compilation of cosmological parameters for numerous models
included in the on-line Planck Legacy archive.55
5
Available at:
http://www.sciops.esa.int/index.php
  
?project=planck&page=Planck\_Legacy\_Archive
Combining Planck+WP with various SN Ia data compilations ([Conley et al., 2011](#bib.bib70); [Suzuki et al., 2012](#bib.bib317)) or with
a direct measurement of $H\_{0}$ ([Riess et al., 2011](#bib.bib281)) does not significantly alter the conclusions for
the simplest slow-roll inflationary models presented below.
The approach adopted here is the same as in the parameters paper
[Planck Collaboration
XVI (2014)](#bib.bib256).

#### 3.2.1 Planck CMB temperature data

The Planck CMB likelihood is based on a hybrid approach, which combines a Gaussian
likelihood approximation derived from temperature pseudo cross-spectra
at high multipoles
([Hamimeche & Lewis, 2008](#bib.bib130)), with a pixel-based temperature and polarization likelihood at low multipoles.
We summarize the likelihood here. For a detailed description the reader is referred to [Planck Collaboration
XV (2014)](#bib.bib255).

The small-scale Planck temperature likelihood is based on pseudo
cross-spectra between pairs of maps at 100, 143,
and 217 GHz, masked to retain 49%, 31%, and 31% of the sky,
respectively. This results in angular auto- and
cross-correlation power spectra covering
multipole ranges of $50\leq\ell\leq 1200$ at 100 GHz, $50\leq\ell\leq 2000$ at 143 GHz, and $500\leq\ell\leq 2500$ at 217 GHz as well as
for the $143\times 217$ GHz cross-spectrum. In
addition to instrumental uncertainties, mitigated here by using only
cross-spectra among different detectors,
small-scale foreground and CMB
secondary anisotropies need to be accounted for.
The foreground model used in the Planck high-$\ell$ likelihood is
described in detail
in [Planck Collaboration
XV (2014)](#bib.bib255) and [Planck Collaboration
XVI (2014)](#bib.bib256), and
includes contributions to the cross-frequency power spectra from unresolved radio point sources, the cosmic
infrared background (CIB), and the thermal and kinetic Sunyaev-Zeldovich
effects. There are
eleven adjustable nuisance
parameters: ($A^{\mathrm{PS}}\_{100},A^{\mathrm{PS}}\_{143},A^{\mathrm{PS}}\_{217},r^{\mathrm{PS}}\_{143\times 217}$,
$A^{\mathrm{CIB}}\_{143},A^{\mathrm{CIB}}\_{217},r^{\mathrm{CIB}}\_{143\times 217},\gamma^{\mathrm{CIB}}$, $A^{\mathrm{tSZ}}\_{143},A^{\mathrm{kSZ}},\xi^{\mathrm{tSZ-CIB}}$).
In addition, the calibration
parameters for the 100 and 217 GHz channels, $c\_{100}$ and $c\_{217}$, relative
to the 143 GHz channel, and the dominant beam uncertainty eigenmode
amplitude $B^{1}\_{1}$ are left free in the analysis, with other beam uncertainties marginalized analytically.
The Planck high-$\ell$ likelihood therefore includes 14 nuisance parameters.66
6
After the Planck March 2013 release, a minor error was found in the ordering of the beam
transfer functions applied to the $217\times 217$
cross-spectra in the Planck high-$\ell$ likelihood. An extensive analysis of the corresponding
revised Planck high-$\ell$ likelihood showed that this error has a negligible impact on cosmological parameters and
is absorbed by small shifts in the foreground parameters. See [Planck Collaboration
XVI (2014)](#bib.bib256) for more details.

The low-$\ell$ Planck likelihood combines the Planck temperature data
with the large scale 9-year WMAP polarization data for this release.
The procedure introduced in [Page et al. (2007)](#bib.bib228) separates the temperature and
polarization likelihood under the assumption of negligible noise in the temperature map.
The temperature likelihood uses Gibbs
sampling ([Eriksen et al., 2007](#bib.bib93)), mapping out the distribution
of the $\ell<50$ CMB temperature multipoles from a foreground-cleaned combination of the $30-353$ GHz
maps ([Planck Collaboration
XII, 2014](#bib.bib252)). The polarization likelihood is pixel-based using the WMAP 9-year
polarization maps at 33, 41, and 61 GHz and includes the temperature-polarization
cross-correlation ([Page et al., 2007](#bib.bib228)). Its angular range is $\ell\leq 23$ for $TE$, $EE$, and $BB$.

#### 3.2.2 Planck lensing data

The primary CMB anisotropies are distorted by the gravitational
potential induced by intervening matter. Such lensing, which broadens and
smooths out the acoustic oscillations, is taken into account as a correction
to the observed temperature power spectrum. The lensing power spectrum can also
be recovered by measuring higher-order correlation functions.

Some of our analysis includes the Planck lensing likelihood,
derived in [Planck Collaboration
XVII (2014)](#bib.bib257), which measures the non-Gaussian trispectrum
of the CMB and is proportional to the power spectrum of the
lensing potential.
As described in [Planck Collaboration
XVII (2014)](#bib.bib257), this potential is reconstructed using quadratic estimators
([Okamoto & Hu, 2003](#bib.bib225)), and its power spectrum is used to estimate the lensing
deflection power spectrum.
The spectrum is estimated from the 143 and 217 GHz maps, using
multipoles in the range $40<\ell<400$. The theoretical predictions for the
lensing potential power spectrum are calculated at linear order.

#### 3.2.3 ACT and SPT temperature data

We include data from ACT and SPT to extend the multipole range of our CMB likelihood.
ACT measures the power spectra and cross spectrum
of the 148 and 218 GHz channels
([Das et al., 2013](#bib.bib77)), and covers angular scales $500<\ell<10\thinspace 000$ at 148 GHz
and $1500<\ell<10\thinspace 000$ at 218 GHz. We use these data in the range $\ell>1000$ in combination with Planck.
SPT measures the power spectrum for angular scales $2000<\ell<10\thinspace 000$ at 95, 150, and 220 GHz ([Reichardt et al., 2012](#bib.bib279)).
The spectrum at larger scales is also measured at 150 GHz ([Story et al., 2013](#bib.bib316)), but we do not include this data
in our analysis. To model the foregrounds for ACT and SPT we follow a similar approach to the likelihood described in
[Dunkley et al. (2013)](#bib.bib81), extending the model used for the Planck high-$\ell$ likelihood. Additional nuisance
parameters are included to model the Poisson source amplitude, the residual Galactic dust contribution,
and the inter-frequency calibration parameters. More details are provided in [Planck Collaboration
XV (2014)](#bib.bib255) and
[Planck Collaboration
XVI (2014)](#bib.bib256).

#### 3.2.4 BAO data

The BAO (Baryon Acoustic Oscillation) angular scale serves
as a standard ruler and allows us to map out the expansion
history of the Universe after last scattering.
The BAO scale, extracted from galaxy redshift
surveys, provides a constraint on the late-time geometry
and breaks degeneracies with other cosmological parameters.
Galaxy surveys constrain the ratio
$D\_{V}(\bar{z})/r\_{\mathrm{s}}$, where $D\_{V}(\bar{z})$ is the spherically
averaged distance scale to the effective survey redshift $\bar{z}$ and
$r\_{\mathrm{s}}$ is the sound horizon ([Mehta et al., 2012](#bib.bib207)).

In this analysis we
consider a combination of the measurements by the 6dFGRS
([Beutler et al. (2011)](#bib.bib41), $\bar{z}=0.106$),
SDSS-II ([Padmanabhan et al. 2012](#bib.bib227), $\bar{z}=0.35$), and
BOSS CMASS ([Anderson et al. 2012](#bib.bib16), $\bar{z}=0.57$) surveys, assuming no
correlation between the three data points. This likelihood is described
further in [Planck Collaboration
XVI (2014)](#bib.bib256).

### 3.3 Parameter estimation

Given a model $\mathcal{M}$ with free parameters $\mathbf{x}\equiv\{x\_{1},\cdots,x\_{k}\}$ and a likelihood function of the data
$\mathcal{L}(\text{data}|\mathbf{x})$, the (posterior) probability
density $\mathcal{P}$ as a function of the parameters can be expressed as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}({\mathbf{x}}|\text{data},\mathcal{M})\propto\mathcal{L}(\text{data}|\mathbf{x})\cdot P(\mathbf{x}|\mathcal{M}),$ |  | (29) |

where $P(\mathbf{x}|\mathcal{M})$ represents the data-independent prior
probability density. Unless specified otherwise, we choose wide top-hat
prior distributions for all cosmological parameters.

We construct the posterior parameter probabilities using the
Markov Chain Monte Carlo (MCMC) sampler as implemented in the
CosmoMC ([Lewis & Bridle, 2002](#bib.bib169)) or MontePython ([Audren et al., 2012](#bib.bib18))
packages. In some cases, when the calculation of the Bayesian evidence
(see below) is desired or when the likelihood function deviates
strongly from a multivariate Gaussian, we use the nested sampling
algorithm provided by the MultiNest add-on module
([Feroz & Hobson, 2008](#bib.bib96); [Feroz et al., 2009](#bib.bib97)) instead of
the Metropolis-Hastings algorithm.

Joint two-dimensional and one-dimensional posterior
distributions are obtained by marginalization. Numerical values and
constraints on parameters are quoted in terms of the mean and 68% central
Bayesian interval of the respective one-dimensional marginalized posterior
distribution.

### 3.4 Model selection

Two approaches to model selection are commonly used in statistics.
The first approach examines the logarithm of the likelihood ratio,
or effective $\chi^{2},$

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta\chi^{2}\_{\text{eff}}\equiv 2\left[\ln\mathcal{L}\_{\text{max}}(\mathcal{M}\_{1})-\ln\mathcal{L}\_{\text{max}}(\mathcal{M}\_{2})\right],$ |  | (30) |

between models $\mathcal{M}\_{1}$ and $\mathcal{M}\_{2}$, corrected for the fact that models with more parameters provide a
better fit due to fitting away noise, even when the more complicated
model is not correct. Various information
criteria have been proposed based on this idea
([Akaike, 1974](#bib.bib10); [Schwarz, 1978](#bib.bib290)); see also
[Liddle (2007)](#bib.bib170). These quantities have the advantage of
being independent of prior choice and fairly easy to calculate.
The second approach is
Bayesian ([Cox, 1946](#bib.bib75); [Jeffreys, 1998](#bib.bib143); [Jaynes & Bretthorst, 2003](#bib.bib142)), and is based
on evaluating ratios of the model averaged likelihood, or Bayesian
evidence, defined by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{E}\_{i}=\int\text{d}^{k}x\penalty\ P(\mathbf{x}|\mathcal{M}\_{i})\mathcal{L}(\text{data}|\mathbf{x}).$ |  | (31) |

Evidence ratios, also known as Bayes factors, $B\_{12}\equiv\mathcal{E}\_{1}/\mathcal{E}\_{2}$,
are naturally interpreted as betting odds
between models.77
7
Note that since
the average is performed over the entire support of the prior
probability density, the evidence depends strongly on
the probability range for the adjustable parameters.
Whereas in parametric inference,
the exact extent of the prior ranges often becomes irrelevant as long as
they are “wide enough” (i.e., containing the bulk of the high-likelihood
region in parameter space), the value of the evidence will generally
depend on precisely how wide the prior range was chosen.
Nested sampling algorithms allow rapid
numerical evaluation of $\mathcal{E}.$ In this paper we will consider both the effective $\chi^{2}$
and the Bayesian
evidence.88
8
After the submission of the
first version of this paper, uncertainties arising from
the minimization
algorithm in the best fit cosmological parameters and the best fit
likelihood were studied. The uncertainties
found were $\mathcal{O}(10^{-1})$ and therefore do not alter our conclusions. The
values for $\Delta\chi^{2}$ reported
have not been updated.

## 4 Constraints on slow-roll inflationary models

In this section we describe constraints on slow-roll inflation using Planck+WP
data in combination with the likelihoods described in Sects. [3.2.2](#S3.SS2.SSS2 "3.2.2 Planck lensing data ‣ 3.2 Data ‣ 3 Methodology ‣ Planck 2013 results. XXII. Constraints on inflation")–[3.2.4](#S3.SS2.SSS4 "3.2.4 BAO data ‣ 3.2 Data ‣ 3 Methodology ‣ Planck 2013 results. XXII. Constraints on inflation").
First we concentrate on characterizing the primordial power spectrum using
Planck and other data. We start by showing that the empirical pre-inflationary Harrison-Zeldovich (HZ)
spectrum with $n\_{\mathrm{s}}=1$ does not fit the Planck measurements.
We further examine whether generalizing the cosmological model, for example by allowing the number
of neutrino species to vary, allowing the helium fraction to vary, or admitting a non-standard reionization
scenario could reconcile the data with $n\_{\mathrm{s}}=1$. We conclude that $n\_{\mathrm{s}}\neq 1$ is robust.

We then investigate the Planck constraints on slow-roll inflation, allowing a tilt for the spectral index and
the presence of tensor modes, and discuss the implications for the simplest standard inflationary models.
In this section the question is studied using the slow-roll approximation, but later sections move beyond
the slow-roll approximation. We show that compared to previous experiments,
Planck significantly narrows the space of allowed inflationary models. Next we consider evidence for a running
of $n\_{\mathrm{s}}$ and constrain it to be small,
although we find a preference for negative running at modest statistical significance.
Finally, we comment on the implications for inflation of the
Planck constraints on possible deviations from spatial flatness.

### 4.1 Ruling out exact scale invariance

The simplest Ansatz for characterizing the statistical properties
of the primordial cosmological perturbations is the so-called HZ model
proposed by [Harrison (1970)](#bib.bib132), [Zeldovich (1972)](#bib.bib336), and
[Peebles & Yu (1970)](#bib.bib233).
These authors pointed out that a power spectrum with exact scale invariance
for the Newtonian gravitation potential fitted the data available at the time, but without giving
any theoretical
justification for this form of the spectrum.
Under exact scale invariance, which would constitute an
unexplained
new symmetry, the primordial perturbations
in the Newtonian gravitational potential look statistically
the same whether they are magnified
or demagnified.
In this simple model, vector and tensor perturbations are absent
and the spectrum of curvature perturbations
is characterized by a single parameter, the amplitude $A\_{\mathrm{s}}$.
Inflation, on the other hand, generically breaks this rescaling symmetry.
Although under inflation scale invariance still holds approximately,
inflation must end. Therefore as different scales are imprinted, the physical conditions must evolve.

Although a detection of a violation of scale invariance would not definitively prove that inflation is responsible for the
generation of the primordial perturbations, ruling out the HZ model would
confirm the expectation of small deviations from scale invariance,
almost always on the red side, which are generic
to all inflationary models without fine tuning.
We examine in detail the viability of the HZ model
using statistics to compare to the more general model where the spectral index is
allowed to vary, as motivated by slow-roll inflation.

When the cosmological model with $n\_{\mathrm{s}}=1$ is compared with a model in which $n\_{\mathrm{s}}$ is allowed to vary,
we find that allowing $n\_{\mathrm{s}}$ to deviate from one
decreases the best fit effective $\chi^{2}$ by $27.9$ with respect to the HZ model. Thus
the significance of the finding that $n\_{\mathrm{s}}\neq 1$ is in excess of 5$\sigma$.
The parameters and maximum likelihood of this comparison are reported in Table [3](#S4.T3 "Table 3 ‣ 4.1 Ruling out exact scale invariance ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation").

One might wonder whether $n\_{\mathrm{s}}=1$ could be reconciled with the data by relaxing some
of the assumptions of the underlying cosmological model. Of particular interest is
exploring those parameters almost degenerate with the spectral index
such as the effective number of neutrino species
$N\_{\mathrm{eff}}$ and the primordial helium fraction $Y\_{\mathrm{P}}$,
which both alter the damping tail of the temperature
spectrum ([Trotta & Hansen, 2004](#bib.bib323); [Hou et al., 2013](#bib.bib137)),
somewhat mimicking a spectral tilt.
Assuming a Harrison-Zeldovich spectrum and allowing
$N\_{\mathrm{eff}}$ or $Y\_{\mathrm{P}}$ to float, and thus deviate
from their standard values,
gives almost as good a fit to Planck+WP data as the $\Lambda$CDM
model with a varying spectral index, with
$\Delta\chi\_{\mathrm{eff}}^{2}=2.8$ and $2.2$, respectively.
However, as
shown in Table [3](#S4.T3 "Table 3 ‣ 4.1 Ruling out exact scale invariance ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation"), the HZ, HZ+$N\_{\mathrm{eff}}$, and
HZ+$Y\_{\mathrm{P}}$ models require significantly higher baryon densities
and reionization optical depths compared to $\Lambda$CDM. In the HZ+$Y\_{\mathrm{P}}$
model, one obtains a helium fraction of $Y\_{\mathrm{P}}=0.3194\pm 0.013$. This value is incompatible both with direct
measurements of the primordial helium abundance ([Aver et al., 2012](#bib.bib19)) and with
standard big bang nucleosynthesis ([Hamann et al., 2008b](#bib.bib127)).
(For comparison, we note that the value $Y\_{P}=0.2477$ was obtained
as best fit for the $\Lambda$CDM model.)
The HZ+$N\_{\mathrm{eff}}$ model, on the other hand, would imply the presence
of $\Delta N\_{\mathrm{eff}}\approx 1$ new effective neutrino species
beyond the three known species.
When BAO measurements are included in the likelihood,
$\Delta\chi\_{\mathrm{eff}}^{2}$ increases to 39.2 (HZ),
4.6 (HZ+$Y\_{\mathrm{P}}$), and 8.0 (HZ+$N\_{\mathrm{eff}}$), respectively,
for the three models. The significance of this detection is also discussed in [Planck Collaboration
XVI (2014)](#bib.bib256).

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | HZ | HZ + $Y\_{\mathrm{P}}$ | HZ + $N\_{\mathrm{eff}}$ | $\Lambda$CDM |
| $10^{5}\Omega\_{\mathrm{b}}h^{2}$ | $2296\pm 24$ | $2296\pm 23$ | $2285\pm 23$ | $2205\pm 28$ |
| $10^{4}\Omega\_{\mathrm{c}}h^{2}$ | $1088\pm 13$ | $1158\pm 20$ | $1298\pm 43$ | $1199\pm 27$ |
| $100\thinspace\theta\_{\mathrm{MC}}$ | $\int$ $1.04292\pm 0.00054$ | $1.04439\pm 0.00063$ | $1.04052\pm 0.00067$ | $1.04131\pm 0.00063$ |
| $\tau$ | $0.125^{+0.016}\_{-0.014}$ | $0.109^{+0.013}\_{-0.014}$ | $0.105^{+0.014}\_{-0.013}$ | $0.089^{+0.012}\_{-0.014}$ |
| $\ln\left(10^{10}A\_{\mathrm{s}}\right)$ | $3.133^{+0.032}\_{-0.028}$ | $3.137^{+0.027}\_{-0.028}$ | $3.143^{+0.027}\_{-0.026}$ | $3.089^{+0.024}\_{-0.027}$ |
| $n\_{\mathrm{s}}$ | — | — | — | $0.9603\pm 0.0073$ |
| $N\_{\mathrm{eff}}$ | — | — | $3.98\pm 0.19$ | — |
| $Y\_{\mathrm{P}}$ | — | $0.3194\pm 0.013$ | — | — |
| $-2\Delta\ln({\mathcal{L}}\_{\mathrm{max}})$ | 27.9 | 2.2 | 2.8 | 0 |

Table 3: 
Constraints on cosmological parameters and best fit $-2\Delta\ln({\mathcal{L}})$ with respect to the standard $\Lambda$CDM model,
using Planck+WP data, testing the significance of the deviation from the HZ model.

### 4.2 Constraining inflationary models using the slow-roll approximation

We now consider all inflationary models that can be described by the
primordial power spectrum
parameters consisting of the scalar amplitude, $A\_{\mathrm{s}}$, the
spectral index, $n\_{\mathrm{s}}$, and the tensor-to-scalar
ratio $r$, all defined at the pivot scale $k\_{\*}$.
We assume that the spectral index is independent of the wavenumber $k$.
Negligible running of the spectral index
is expected if the slow-roll condition is satisfied
and higher order corrections in the slow-roll approximations can be neglected.
In the next subsection we relax this assumption.

Sampling the power spectrum parameters $A\_{\mathrm{s}}$, $n\_{\mathrm{s}}$, and $r$
is not the only method for constraining slow-roll inflation.
Another possibility is to sample the Hubble flow functions
in the analytic expressions for the scalar and tensor power spectra ([Stewart & Lyth, 1993](#bib.bib314); [Gong & Stewart, 2001](#bib.bib109); [Leach et al., 2002](#bib.bib164)).
In the Appendix, we compare the slow-roll inflationary predictions by sampling the HFF with Planck data
and show that the results obtained in this way agree with those derived by
sampling the power spectrum parameters.
This confirms similar studies based on previous data ([Hamann et al., 2008c](#bib.bib128); [Finelli et al., 2010](#bib.bib99)).

The spectral index estimated from Planck+WP data is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n\_{\mathrm{s}}=0.9603\pm 0.0073.$ |  | (32) |

This tight bound on $n\_{\mathrm{s}}$ is crucial for constraining inflation. The Planck
constraint on $r$ depends slightly on the pivot scales;
we adopt $k\_{\*}=0.002$ Mpc-1 to quote our results, with $r\_{0.002}<0.12$ at 95% CL.
This bound improves on the most recent results, including the
WMAP 9-year constraint of $r<0.38$ ([Hinshaw et al., 2013](#bib.bib136)), the WMAP 7-year + ACT limit of
$r<0.28$ ([Sievers et al., 2013](#bib.bib296)), and the WMAP 7-year + SPT limit of $r<0.18$
([Story et al., 2013](#bib.bib316)).
The new bound from Planck is consistent with the theoretical limit from temperature anisotropies
alone ([Knox & Turner, 1994](#bib.bib151)).
When a possible tensor component is included, the spectral index from Planck+WP does
not significantly change, with
$n\_{\mathrm{s}}=0.9624\pm 0.0075$.

The Planck constraint on $r$ corresponds to an upper bound on the energy scale of inflation

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V\_{\*}=\frac{3\pi^{2}A\_{\mathrm{s}}}{2}\thinspace r\thinspace M\_{\mathrm{pl}}^{4}=(1.94\times 10^{16}\penalty\ {\mathrm{GeV}})^{4}\frac{r\_{\*}}{0.12}$ |  | (33) |

at 95% CL. This is equivalent to an upper bound on the Hubble parameter during inflation of
$H\_{\*}/M\_{\mathrm{pl}}<3.7\times 10^{-5}$.
In terms of slow-roll parameters, Planck+WP constraints imply $\epsilon\_{V}<0.008$ at 95% CL, and $\eta\_{V}=-0.010^{+0.005}\_{-0.011}$.

| Model | Parameter | Planck+WP | Planck+WP+lensing | Planck + WP+high-$\ell$ | Planck+WP+BAO |
| --- | --- | --- | --- | --- | --- |
| $\Lambda$CDM + tensor | $n\_{\mathrm{s}}$ | $0.9624\pm 0.0075$ | $0.9653\pm 0.0069$ | $0.9600\pm 0.0071$ | $0.9643+0.0059$ |
| $r\_{0.002}$ | $<0.12$ | $<0.13$ | $<0.11$ | $<0.12$ |
|  | $-2\Delta\ln{\mathcal{L}}\_{\mathrm{max}}$ | 0 | 0 | 0 | -0.31 |

Table 4: 
Constraints on the primordial perturbation parameters in the $\Lambda$CDM+tensor model from Planck combined with other data sets.
The constraints are given at the pivot scale $k\_{\*}=0.002$ Mpc-1.

The Planck results on $n\_{\mathrm{s}}$ and $r$ are robust to the addition of external data sets (see Table [4](#S4.T4 "Table 4 ‣ 4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation")).
When the high-$\ell$ CMB ACT + SPT data are added, we obtain $n\_{\mathrm{s}}=0.9600\pm 0.0071$ and $r\_{0.002}<0.11$
at 95% CL. Including the Planck lensing likelihood we obtain $n\_{\mathrm{s}}=0.9653\pm 0.0069$ and $r\_{0.002}<0.13$,
and adding BAO data gives $n\_{\mathrm{s}}=0.9643\pm 0.0059$ and $r\_{0.002}<0.12$.

The above bounds are robust to small changes in the
polarization likelihood at low multipoles. To test this robustness,
instead of using the WMAP polarization likelihood, we impose a Gaussian
prior $\tau=0.07\pm 0.013$ to take into account small shifts
due to uncertainties in residual foreground contamination or instrument
systematic effects in the evaluation of $\tau$, as performed in Appendix B of
[Planck Collaboration
XVI (2014)](#bib.bib256). We find at most a reduction of 8% for the upper bound on $r$.

It is useful to plot the inflationary potentials in the $n\_{\mathrm{s}}\textrm{-}r$ plane using
the first two slow-roll parameters evaluated at the pivot
scale $k\_{\*}=0.002$ Mpc-1 ([Dodelson et al., 1997](#bib.bib79)).
Given our ignorance of the details of the epoch of entropy generation,
we assume that the number of e-folds $N\_{\*}$ to the end of inflation
lies in the interval $[50,60]$.
This uncertainty is plotted for those potentials
predicting an exit from inflation without changing the potential.

Figure [1](#S4.F1 "Figure 1 ‣ 4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation") shows the Planck constraints in the
$n\_{\mathrm{s}}\textrm{-}r$ plane
and indicates the predictions of a number of
representative inflationary potentials (see [Lyth & Riotto (1999)](#bib.bib193) for a review
of particle physics models of inflation).
The sensitivity of Planck data to high multipoles removes the
degeneracy between $n\_{\mathrm{s}}$ and $r$ found
using the WMAP data.
Planck data favour models with a concave potential.
As shown in Fig. [1](#S4.F1 "Figure 1 ‣ 4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation"),
most of the joint 95% allowed region lies below the convex
potential limit, and concave models with a red tilt in the range
[0.945-0.98] are allowed by Planck at 95% CL.
In the following we consider the status of several illustrative and commonly
discussed inflationary potentials in light of the Planck observations.

Figure 1: Marginalized joint 68% and 95% CL regions for $n\_{\mathrm{s}}$ and $r\_{0.002}$
from Planck in combination with other data sets
compared to the theoretical predictions
of selected inflationary models.

#### Power law potential and chaotic inflation

The simplest class of inflationary models is characterized by a single monomial potential of the form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\lambda M\_{\mathrm{pl}}^{4}\left(\frac{\phi}{M\_{\mathrm{pl}}}\right)^{n}\thinspace.$ |  | (34) |

This class of potentials includes the simplest chaotic models, in which inflation starts from
large values for the inflaton,
$\phi>M\_{\mathrm{pl}}$.
Inflation ends when slow-roll is no longer valid, and we assume this to occur at $\epsilon\_{V}=1$.
According to Eqs. [5](#S2.E5 "In 2.1 Cosmic inflation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), [6](#S2.E6 "In 2.1 Cosmic inflation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), and [15](#S2.E15 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), this class of potentials
predicts to lowest order in
slow-roll parameters $n\_{\mathrm{s}}-1\approx-n(n+2)M\_{\mathrm{pl}}^{2}/\phi\_{\*}^{2}$, $r\approx 8n^{2}M\_{\mathrm{pl}}^{2}/\phi\_{\*}^{2}$,
$\phi\_{\*}^{2}\approx nM\_{\mathrm{pl}}^{2}(4N\_{\*}+n)/2$.
The $\lambda\phi^{4}$ model lies well outside the joint 99.7% CL region in the $n\_{\mathrm{s}}\textrm{-}r$ plane.
This result confirms previous findings from, for example, [Hinshaw et al. (2013)](#bib.bib136), in which this model lies outside
the 95% CL for the WMAP 9-year data and is further excluded by CMB data at smaller scales.

The model with a quadratic potential, $n=2$ ([Linde, 1983](#bib.bib178)), often considered the simplest example
for inflation, now lies outside the joint 95% CL for the Planck+WP+high-$\ell$ data for $N\_{\*}\lesssim 60$ $e$-folds,
as shown in Fig. [1](#S4.F1 "Figure 1 ‣ 4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation").

A linear potential with $n=1$ ([McAllister et al., 2010](#bib.bib205)),
motivated by axion monodromy, has $\eta\_{V}=0$ and
lies within the 95% CL region.
Inflation with $n=2/3$ ([Silverstein & Westphal, 2008](#bib.bib299)), however, also motivated by axion monodromy,
now lies on the boundary of the joint 95% CL region.
More permissive entropy generation priors allowing $N\_{\*}<50$ could reconcile this model with
the Planck data.

#### Exponential potential and power law inflation

Inflation with an exponential potential

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\Lambda^{4}\exp\left(-\lambda\frac{\phi}{M\_{\mathrm{pl}}}\right)$ |  | (35) |

is called power law inflation ([Lucchin & Matarrese, 1985](#bib.bib187)),
because the exact solution for the scale factor is given by $a(t)\propto t^{2/\lambda^{2}}$.
This model is incomplete since inflation would not end without an additional mechanism to stop it. Under the assumption
that such a
mechanism exists and leaves predictions for
cosmological perturbations unmodified, this class of models predicts $r=-8(n\_{\mathrm{s}}-1)$ and now lies outside the joint 99.7% CL contour.

#### Inverse power law potential

Intermediate inflationary models ([Barrow, 1990](#bib.bib25); [Muslimov, 1990](#bib.bib220)) with inverse power law potentials

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\Lambda^{4}\left(\frac{\phi}{M\_{\mathrm{pl}}}\right)^{-\beta}$ |  | (36) |

lead to inflation with $a(t)\propto\exp(At^{f})$, with $A>0$ and $0<f<1$, where $f=4/(4+\beta)$ and $\beta>0$.
In intermediate inflation there is no natural end to inflation, but if the exit mechanism leaves the inflationary
predictions for the cosmological perturbations unmodified, this class of models predicts
$n\_{\mathrm{s}}-1\approx-\beta(\beta-2)/\phi\_{\*}^{2}$ and
$r\approx-8\beta(n\_{\mathrm{s}}-1)/(\beta-2)$ at lowest order in the slow-roll approximation
([Barrow & Liddle, 1993](#bib.bib26)).99
9
See [Starobinsky (2005)](#bib.bib312) for the inflationary model producing
an exactly scale-invariant power spectrum with $r\neq 0$ beyond the slow-roll approximation.
Intermediate inflationary models lie outside the joint 95% CL contour for any $\beta$.

#### Hilltop models

In another interesting class of potentials,
the inflaton rolls away from an unstable equilibrium as in the
first new inflationary models ([Albrecht & Steinhardt, 1982](#bib.bib11); [Linde, 1982](#bib.bib177)).
We consider

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)\approx\Lambda^{4}\left(1-\frac{\phi^{{p}}}{\mu^{{p}}}+...\right)\thinspace,$ |  | (37) |

where the ellipsis indicates higher order terms that are negligible during inflation but
ensure positiveness of the potential later on.
An exponent of $p=2$ is allowed only as a
large field inflationary model, predicting
$n\_{\mathrm{s}}-1\approx-4M^{2}\_{\mathrm{pl}}/\mu^{2}+3r/8$
and $r\approx 32\phi^{2}\_{\*}M^{2}\_{\mathrm{pl}}/\mu^{4}$.
This potential leads to predictions in agreement
with Planck+WP+BAO joint 95% CL contours for super Planckian values of
$\mu$, i.e., $\mu\gtrsim 9\penalty\ M\_{\mathrm{pl}}$.

Models with $p\geq 3$ predict $n\_{\mathrm{s}}-1\approx-(2/N)(p-1)/(p-2)$ when $r\ll 1$.
The hilltop potential with $p=3$ lies outside the joint 95% CL region for Planck+WP+BAO data.
The case with $p=4$ is also in tension with Planck+WP+BAO, but allowed within the joint 95% CL
region for $N\_{\*}\gtrsim 50$ when $r\ll 1$.
For larger values of $r$ these models provide a better fit to the Planck+WP+BAO data.
The $p=4$ hilltop model—without extra terms denoted by the ellipsis in
Eq. (37)—is displayed in Fig. 1 in the standard range $50<N\_{\*}<60$ at different values
of $\mu$ (this model
approximates the linear potential for large $\mu/M\_{\mathrm{pl}}$).

#### A simple symmetry breaking potential

The symmetry breaking potential ([Olive, 1990](#bib.bib226))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\Lambda^{4}\left(1-\frac{\phi^{2}}{\mu^{2}}\right)^{2}$ |  | (38) |

can be considered as a self-consistent completion of the hilltop model with $p=2$ (although it has a different
limiting large-field branch for non-zero $r$). This potential leads to predictions in agreement
with Planck + WP + BAO joint 95% CL contours for super Planckian values of $\mu$ (i.e. $\mu\gtrsim 13\penalty\ M\_{\mathrm{pl}})$.

#### Natural inflation

Another interesting class of potentials is natural inflation ([Freese et al., 1990](#bib.bib102); [Adams et al., 1993](#bib.bib4)),
initially motivated by its origin in symmetry breaking in an attempt
to naturally give rise to the extremely flat potentials required
for inflationary cosmology.
In natural inflation the effective
one-dimensional potential takes the form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\Lambda^{4}\left[1+\cos\left(\frac{\phi}{f}\right)\right],$ |  | (39) |

where $f$ is a scale which determines the slope of the potential (see
also [Binétruy & Gaillard (1986)](#bib.bib45) for an earlier motivation of a cosine potential for the inflaton
in the context of superstring theory).
Depending on the value of $f$, the model falls into the large field
($f\gtrsim 1.5\penalty\ M\_{\mathrm{pl}}$) or small field ($f\lesssim 1.5\penalty\ M\_{\mathrm{pl}}$)
categories. Therefore,
$n\_{\mathrm{s}}\approx 1-M^{2}\_{\mathrm{pl}}/f^{2}$ holds for small $f,$ while
$n\_{\mathrm{s}}\approx 1-2/N$, $r\approx 8/N$ holds for large $f$, approximating the
$m^{2}\phi^{2}$ potential in the latter case
(with $N\_{\*}\approx(2f^{2}/M^{2}\_{\mathrm{pl}})\ln[\sin(\phi\_{\mathrm{e}}/f)/\sin(\phi\_{\*}/f)]$).
This model agrees with Planck+WP data for $f\gtrsim 5\penalty\ M\_{\mathrm{pl}}$.

#### Hybrid inflation

In hybrid inflationary models a second field, $\chi$, coupled to the inflaton,
undergoes symmetry breaking. The simplest example of this class is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi,\chi)=\Lambda^{4}\left(1-\frac{\chi^{2}}{\mu^{2}}\right)^{2}+U(\phi)+\frac{g^{2}}{2}\phi^{2}\chi^{2}\thinspace.$ |  | (40) |

Over most of their parameter space, these models
behave effectively as single-field models for the inflaton $\phi.$
The second field $\chi$ is close to the origin
during the slow-roll regime for $\phi$, and
inflation ends either by breakdown of slow roll for the inflaton at $\epsilon\_{\phi}\approx M\_{\mathrm{pl}}^{2}(\mathrm{d}U/\mathrm{d}\phi)^{2}/(\Lambda^{4}+U(\phi))^{2}\approx 1$ or by the waterfall transition of $\chi$.
The simplest models with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $U(\phi)=\frac{m^{2}}{2}\phi^{2}$ |  | (41) |

are disfavoured for most of the parameter space ([Cortês & Liddle, 2009](#bib.bib72)).
Models with $m^{2}\phi^{2}/2\sim\Lambda^{4}$ are disfavoured due to a high tensor-to-scalar ratio, and models with
$U(\phi)\ll\Lambda^{4}$ predict a spectral index $n\_{\mathrm{s}}>1$, also disfavoured by the Planck data.

We discuss hybrid inflationary models predicting $n\_{\mathrm{s}}<1$ separately.
As an example, the spontaneously broken SUSY model ([Dvali et al., 1994](#bib.bib84))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $U(\phi)=\alpha\_{\mathrm{h}}\Lambda^{4}\ln\left(\frac{\phi}{\mu}\right)$ |  | (42) |

predicts
$n\_{\mathrm{s}}-1\approx-(1+3\alpha\_{\mathrm{h}}/2)/N\_{\*}$ and $r\approx 8\alpha\_{\mathrm{h}}/N\_{\*}$.
For $\alpha\_{\mathrm{h}}\ll 1$ and $N\_{\*}\approx 50$, $n\_{\mathrm{s}}\approx 0.98$ is disfavoured by Planck+WP+BAO data at more than 95$\%$ CL.
However, more permissive
entropy generation priors allowing $N\_{\*}<50$ or a non-negligible $\alpha\_{\mathrm{h}}$
give models consistent with the Planck data.

#### $R^{2}$ inflation

Inflationary models can also be accommodated within extended theories of gravity.
These theories can be analysed either in the original (Jordan) frame or in the conformally-related Einstein frame with a Klein-Gordon
scalar field. Due to the invariance of curvature and tensor perturbation power spectra with respect to this conformal transformation,
we can use the same methodology described earlier.

The first inflationary model proposed was of this type and was based on higher order
gravitational terms in the action ([Starobinsky, 1980](#bib.bib306))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S=\int\mathrm{d}^{4}x\sqrt{-g}\frac{M^{2}\_{\mathrm{pl}}}{2}\left(R+\frac{R^{2}}{6M^{2}}\right)\thinspace,$ |  | (43) |

with the motivation to include semi-classical quantum effects.
The predictions for $R^{2}$ inflation were first studied in [Mukhanov & Chibisov (1981)](#bib.bib217) and [Starobinsky (1983)](#bib.bib308),
and can be summarized as $n\_{\mathrm{s}}-1\approx-8(4N\_{\*}+9)/(4N\_{\*}+3)^{2}$ and $r\approx 192/(4N\_{\*}+3)^{2}$.
Since $r$ is suppressed by another $1/N\_{\*}$ with respect to the scalar tilt, this model
predicts a tiny amount of gravitational waves.
This model predicts $n\_{\mathrm{s}}=0.963$ for $N\_{\*}=55$ and is fully consistent with the Planck constraints.

#### Non-minimally coupled inflaton

A non-minimal coupling of the inflaton to gravity with the action

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S=\int\mathrm{d}^{4}x\sqrt{-g}\left[\frac{M^{2}\_{\mathrm{pl}}+\xi\phi^{2}}{2}R-\frac{1}{2}g^{\mu\nu}\partial\_{\mu}\phi\partial\_{\nu}\phi-\frac{\lambda}{4}\left(\phi^{2}-\phi\_{0}^{2}\right)^{2}\right]$ |  | (44) |

leads to several interesting consequences, such as a lowering of the tensor-to-scalar ratio.

The case of a massless self-interacting inflaton ($\phi\_{0}=0$) agrees with the Planck+WP data for $\xi\neq 0$.
Within the range $50<N\_{\*}<60$, this model is within the Planck+WP joint 95% CL region for $\xi>0.0019$, improving
on previous bounds ([Tsujikawa & Gumjudpai, 2004](#bib.bib324); [Okada et al., 2010](#bib.bib224)).

The amplitude of scalar perturbations is proportional to $\lambda/\xi^{2}$ for $\xi\gg 1$, and therefore
the problem of tiny values for the inflaton self-coupling $\lambda$ can be alleviated
([Spokoiny, 1984](#bib.bib303); [Lucchin et al., 1986](#bib.bib188); [Salopek et al., 1989](#bib.bib283); [Fakir & Unruh, 1990](#bib.bib95)).
The regime $\phi\_{0}\ll M\_{\mathrm{pl}}$ is allowed and $\phi$ could be the Standard Model Higgs as proposed
in [Bezrukov & Shaposhnikov (2008)](#bib.bib43) at the tree level (see [Barvinsky et al. (2008)](#bib.bib31); [Bezrukov & Shaposhnikov (2009)](#bib.bib44) for the inclusion of loop corrections).
The Higgs case with $\xi\gg 1$ has the same predictions as the $R^{2}$ model in terms
of $n\_{\mathrm{s}}$ and $r$ as a function of $N\_{\*}$.
The entropy generation mechanism in the Higgs case can be more efficient than in the $R^{2}$ case
and therefore predicts a slightly larger $n\_{\mathrm{s}}$ ([Bezrukov & Gorbunov, 2012](#bib.bib42)).
This model is fully consistent with the Planck constraints.

The case with $\xi<0$ and $|\xi|\phi\_{0}^{2}/M^{2}\_{\mathrm{pl}}\sim 1$ was also recently emphasized in [Linde et al. (2011)](#bib.bib176).
With the symmetry breaking potential in Eq. [44](#S4.E44 "In Non-minimally coupled inflaton ‣ 4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation"), the
large field case with $\phi>\phi\_{0}$ is disfavoured by Planck data, whereas the small field case $\phi<\phi\_{0}$ is
in agreement with the data.

### 4.3 Running spectral index

We have shown that the single parameter Harrison-Zeldovich spectrum does not fit
the data and that at least the first two terms $A\_{\mathrm{s}}$ and $n\_{\mathrm{s}}$ in the expansion of the primordial
power spectrum in powers of $\ln(k)$ given in Eq. [10](#S2.E10 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") are needed. Here we consider
whether the data require the next term known as
the running of the spectral index ([Kosowsky & Turner, 1995](#bib.bib159)), defined as
the derivative of the spectral index with respect to $\ln k$,
$\mathrm{d}n\_{\mathrm{s\thinspace,t}}/\mathrm{d}\ln k$ for scalar or tensor fluctuations.
If the slow-roll approximation holds and the inflaton has reached its attractor
solution, $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ and $\mathrm{d}n\_{\mathrm{t}}/\mathrm{d}\ln k$ are
related to the potential slow-roll parameters, as in Eqs. [17](#S2.E17 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") and [18](#S2.E18 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation").
In slow-roll single-field inflation, the running is second order in the
Hubble slow-roll parameters, for scalar and for tensor perturbations
([Kosowsky & Turner, 1995](#bib.bib159); [Leach et al., 2002](#bib.bib164)),
and thus is typically suppressed with respect to $n\_{\mathrm{s}}-1$ and $n\_{\mathrm{t}}$,
which are first order.
Given the tight constraints on the first two slow-roll parameters $\epsilon\_{V}$ and $\eta\_{V}$ ($\epsilon\_{1}$ and $\epsilon\_{2}$)
from the present data, typical values of the running to which Planck is sensitive ([Pahud et al., 2007](#bib.bib229))
would generically be dominated by the contribution from the third derivative of the potential, encoded
in $\xi\_{V}^{2}$ (or $\epsilon\_{3}$).

While it is easy to see
that the running is invariant under a change in pivot scale, the same does not
hold for the spectral index and the amplitude of the primordial power
spectrum. It is convenient to choose $k\_{\*}$ such that $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$
and $n\_{\mathrm{s}}$ are uncorrelated ([Cortês et al., 2007](#bib.bib73)).
This approach minimizes the inferred variance of $n\_{\mathrm{s}}$ and
facilitates comparison with constraints on $n\_{\mathrm{s}}$ in the
power law models. Note, however, that the decorrelation pivot scale
$k\_{\*}^{\mathrm{dec}}$ depends on both the model and the data set used.

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Model | Parameter | Planck+WP | Planck+WP+lensing | Planck+WP+high-$\ell$ | Planck+WP+BAO |
| $\Lambda$CDM + $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ | $n\_{\mathrm{s}}$ | $0.9561\pm 0.0080$ | $0.9615\pm 0.0072$ | $0.9548\pm 0.0073$ | $0.9596\pm 0.0063$ |
| $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ | $-0.0134\pm 0.0090$ | $-0.0094\pm 0.0085$ | $-0.0149\pm 0.0085$ | $-0.0130\pm 0.0090$ |
| $-2\Delta\ln{\mathcal{L}}\_{\mathrm{max}}$ | -1.50 | -0.77 | -2.95 | -1.45 |
| $\Bigg|$+ $\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}$ | $\Big|$ $n\_{\mathrm{s}}$ | $0.9514^{+0.087}\_{-0.090}$ | $0.9573^{+0.077}\_{-0.079}$ | $0.9476^{+0.086}\_{-0.088}$ | $0.9568^{+0.068}\_{-0.063}$ |
| $\Lambda$CDM + $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ | $\Big|$ $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ | $0.001^{+0.016}\_{-0.014}$ | $0.006^{+0.015}\_{-0.014}$ | $0.001^{+0.013}\_{-0.014}$ | $0.000^{+0.016}\_{-0.013}$ |
|  | $\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}$ | $0.020^{+0.016}\_{-0.015}$ | $0.019^{+0.018}\_{-0.014}$ | $0.022^{+0.016}\_{-0.013}$ | $0.017^{+0.016}\_{-0.014}$ |
|  | $-2\Delta\ln{\mathcal{L}}\_{\mathrm{max}}$ | -2.65 | -2.14 | -5.42 | -2.40 |
| $\Lambda$CDM + $r$ + $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ | $n\_{\mathrm{s}}$ | $0.9583\pm 0.0081$ | $0.9633\pm 0.0072$ | $0.9570\pm 0.0075$ | $0.9607\pm 0.0063$ |
| $r$ | $<0.25$ | $<0.26$ | $<0.23$ | $<0.25$ |
| $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ | $-0.021\pm 0.012$ | $-0.017\pm 0.012$ | $-0.022^{+0.011}\_{-0.010}$ | $-0.021^{+0.012}\_{-0.010}$ |
| $-2\Delta\ln{\mathcal{L}}\_{\mathrm{max}}$ | -1.53 | -0.26 | -3.25 | -1.5 |

Table 5: 
Constraints on the primordial perturbation parameters for
$\Lambda$CDM+$\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$, $\Lambda$CDM+$\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$+$r,$ and
$\Lambda$CDM+$\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$+$\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}$ models from Planck combined with other data sets.
Constraints on the spectral index and its dependence on the wavelength are given at the pivot scale of $k\_{\*}=0.05$ Mpc-1.

We consider a model parameterizing the power spectrum using
$A\_{\mathrm{s}}(k\_{\*})\thinspace,n\_{\mathrm{s}}(k\_{\*}),$
and
$\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$,
where $k\_{\*}=0.05\penalty\ \mathrm{Mpc}^{-1}$.
The joint constraints on $n\_{\mathrm{s}}$ and $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ at the decorrelation scale
of $k\_{\*}^{\mathrm{dec}}=0.038$ Mpc-1 are shown in
Fig. [2](#S4.F2 "Figure 2 ‣ 4.3 Running spectral index ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation").
The Planck+WP constraints on the running do not change significantly
when complementary data sets such as Planck lensing, CMB high-$\ell,$ and BAO data are included.
We find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k=-0.013\pm 0.009\quad\mbox{(68\% CL, {Planck}+WP)}\thinspace,$ |  | (45) |

which is negative at the 1.5$\sigma$ level. This reduces the
uncertainty compared to previous CMB
results. Error bars are reduced by 60% compared to the WMAP 9-year
results ([Hinshaw et al., 2013](#bib.bib136)), and by 20–30% compared to WMAP supplemented by
SPT and ACT data
([Hou et al., 2012](#bib.bib138); [Sievers et al., 2013](#bib.bib296)). Planck finds a smaller scalar running than
SPT + WMAP7 ([Hou et al., 2012](#bib.bib138)), and larger than ACT + WMAP7 ([Sievers et al., 2013](#bib.bib296)).
The best fit likelihood improves by only
$\Delta\chi^{2}\_{\mathrm{eff}}\approx 1.5$ ($3$ when high-$\ell$ data are included)
with respect to the minimal case in which $n\_{\mathrm{s}}$
is scale independent, indicating that the deviation from scale independence is not very significant.
The constraint for the spectral index in this case is $0.9630\pm 0.0065$ at 68% CL
at the decorrelation pivot scale
$k\_{\*}=0.038$ Mpc-1. This result implies that the third derivative of the potential
is small, i.e., $|\xi^{2}\_{V}|\sim 0.007$, but compatible with zero at 95% CL, for inflation
at low energy (i.e., with $\epsilon\_{V}\approx 0$).

Figure 2: Marginalized joint 68% and 95% CL for
$(\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k\thinspace,n\_{\mathrm{s}})$
using Planck+WP+BAO, either marginalizing over $r$ or fixing $r=0$ at
$k\_{\*}=0.038$ Mpc-1.
The purple strip shows the prediction for single monomial chaotic inflationary
models with $50<N\_{\*}<60$ for comparison.

We also test the possibility that the running depends on the wavelength so that
$\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}$
is nonzero.
With Planck+WP data, we find $\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}=0.020^{+0.016}\_{-0.015}$.
This result is stable with respect to the addition of complementary data sets, as can be seen from
Table [5](#S4.T5 "Table 5 ‣ 4.3 Running spectral index ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation") and Fig. [3](#S4.F3 "Figure 3 ‣ 4.3 Running spectral index ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation").
When $\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}$ is allowed in the fit, we find a value for the running $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$
consistent with zero.

Finally we allow a
non-zero primordial gravitational wave spectrum together with the running. The tensor
spectral index and its running are set by the slow-roll consistency relations to second order, with
$n\_{\mathrm{t}}=-r(2-r/8-n\_{\mathrm{s}})/8$ and $\mathrm{d}n\_{\mathrm{t}}/\mathrm{d}\ln k=r(r/8+n\_{\mathrm{s}}-1)/8$.
Planck measures the running to be $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k=-0.016\pm 0.010$ when tensors are included (see
Table [5](#S4.T5 "Table 5 ‣ 4.3 Running spectral index ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation") and Fig. [4](#S4.F4 "Figure 4 ‣ 4.3 Running spectral index ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation")).
The constraints on the
tensor-to-scalar ratio are relaxed compared to the case with no running, due to an anti-correlation between $r$
and $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$, as shown in Fig. [4](#S4.F4 "Figure 4 ‣ 4.3 Running spectral index ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation") for Planck+WP+BAO.

Varying both tensors and running, Planck+WP implications for slow-roll parameters are $\epsilon\_{V}<0.015$ at 95% CL,
$\eta\_{V}=-0.014\_{-0.011}^{+0.015}$, and $|\xi^{2}\_{V}|=0.009\pm 0.006$.

In summary, the Planck data prefer a negative running for the scalar spectral index
of order $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k\approx-0.015,$ but
at only the 1.5$\sigma$ significance level. This is for Planck
alone and in combination with other astrophysical data sets.
Weak statistical evidence for negative values of
$\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ has been claimed in several
previous investigations with the WMAP data and smaller scale CMB data
([Spergel et al., 2003](#bib.bib302); [Peiris et al., 2003](#bib.bib239); [Dunkley et al., 2011](#bib.bib82); [Hinshaw et al., 2013](#bib.bib136); [Hou et al., 2012](#bib.bib138), e.g.,).

If primordial, negative values for $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ of order $10^{-2}$ would be interesting for the
physics of inflation.
The running of the scalar spectral index is a key prediction for inflationary models. It is strictly zero for power law inflation,
whose fit to Planck was shown to be quite poor in the previous section. Chaotic monomial models with $V(\phi)\propto\phi^{n}$
predict
$\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k\approx-8(n+2)/(4N+n)^{2}\approx(n\_{\mathrm{s}}-1)^{2}$,
and the same order of magnitude $(10^{-3})$ is quite typical for many slow-roll
inflationary models, such as natural inflation ([Adams et al., 1993](#bib.bib4)) or
hilltop inflation ([Boubekeur & Lyth, 2005](#bib.bib47)). It was pointed out that
a large negative running of $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k\lesssim-10^{-2}$
would make it difficult to support the $N\_{\*}\approx 50$ $e$-foldings
required from inflation ([Easther & Peiris, 2006](#bib.bib87)), but this holds only without nonzero
derivatives higher than the third order in the inflationary potential.
Designing inflationary models that predict a negative running of ${\mathcal{O}}(10^{-2})$ with an acceptable $n\_{\mathrm{s}}$ and number
of $e$-folds is not impossible, as the case with modulated oscillations in the inflationary potential demonstrates ([Kobayashi & Takahashi, 2011](#bib.bib152)).
This occurs, for instance,
in the axion monodromy model when the instanton contribution is taken into account ([McAllister et al., 2010](#bib.bib205)), giving the potential

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=\mu^{3}\phi+\Lambda^{4}\cos\left(\frac{\phi}{f}\right)\thinspace.$ |  | (46) |

Figure 3: Marginalized joint 68% and 95% CL regions for
$(\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}\thinspace,\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k)$ using Planck+WP+BAO.

Figure 4: Marginalized joint 68% and 95% CL regions for
$(r\thinspace,n\_{\mathrm{s}})$, using Planck+WP+BAO with and without a running spectral index.

### 4.4 Open inflation

Most models of inflation predict a nearly flat spatial geometry with small deviations from
perfect spatial flatness of $|\Omega\_{K}|\sim 10^{-5}$. Curvature fluctuations may
be regarded as local fluctuations in
the spatial curvature, and even in models of inflation where the perturbations are calculated
about a spatially flat background, the spatial curvature on the largest scales accessible
to observation now are subject to fluctuations from perfect spatial flatness (i.e., $\Omega\_{K}=0$).
This prediction for this fluctuation
is calculated by simply extrapolating the power law spectrum
to the largest scale accessible today, so that $\Omega\_{K}$ as probed by the CMB roughly represents
the local curvature fluctuation averaged over our (causal) horizon volume. Although it has sometimes been claimed that spatial
flatness is a firm prediction of inflation, it was realized early on that spatial flatness
is not an inexorable consequence of inflation and large amounts of spatial curvature
(i.e., large compared to the above prediction) can be introduced in a precise way while
retaining all the advantages of inflation ([Gott, 1982](#bib.bib113); [Gott & Statler, 1984](#bib.bib114)) through bubble nucleation
by false vacuum decay ([Coleman & De Luccia, 1980](#bib.bib69)).
This proposal gained credence when it was shown how to calculate the perturbations in this model
around and beyond the curvature scale
([Bucher et al., 1995](#bib.bib54); [Bucher & Turok, 1995](#bib.bib56); [Yamamoto et al., 1995](#bib.bib335); [Tanaka & Sasaki, 1994](#bib.bib318)).
See also [Ratra & Peebles (1995)](#bib.bib278); [Ratra & Peebles (1994)](#bib.bib277) and [Lyth & Stewart (1990)](#bib.bib194). For more refined later calculations see for example
[Garriga et al. (1998)](#bib.bib105); [Garriga et al. (1999)](#bib.bib106), [Gratton & Turok (1999)](#bib.bib117),
and references therein. For predictions
of the tensor perturbations see for example [Bucher & Cohn (1997)](#bib.bib52),
[Sasaki et al. (1997)](#bib.bib286), and
[Hertog & Turok (2000)](#bib.bib135).

An interesting proposal using singular instantons and not requiring a false vacuum
may be found in [Hawking & Turok (1998)](#bib.bib134),
and for calculations of the resulting perturbation spectra see
[Hertog & Turok (2000)](#bib.bib135) and [Gratton et al. (2000)](#bib.bib115).
Models of this sort have been studied more recently in the context of the string
landscape. (See, for example, [Vilenkin (2007)](#bib.bib333) for a nice review.)
Although some proposals for universes with positive curvature within the framework
of inflation have been put forth ([Gratton et al., 2002](#bib.bib116)), it is much harder to obtain
a closed universe with a spatial geometry of positive spatial curvature (i.e., $\Omega\_{K}<0$)
([Linde, 2003](#bib.bib183)).

Theoretically, it is of interest to measure $\Omega\_{K}$ to an accuracy of approximately $10^{-4}$
or slightly better to test the prediction of simple flat inflation for this observable.
A statistically significant positive value would suggest that open inflation, perhaps
in the context of the landscape, was at play. A statistically significant negative value could
pose difficulties for the inflationary paradigm. For a recent discussion of
these questions, see for example [Freivogel et al. (2006)](#bib.bib103), [Kleban & Schillo (2012)](#bib.bib150), and [Guth & Nomura (2012)](#bib.bib122).

Figure 5: Joint posterior for tensors and running of the scalar spectral index marginalizing over other
parameters. The contours are set at 68% and 95%. The red contours apply for Planck+WP+high-$\ell$ data. The colour of the scattered
points indicates the distribution of $\Omega\_{K}$. The blue contours apply when BAO data is also included. ($\Omega\_{K}$ is then
found to be well constrained close to zero.) The dashed vertical line shows
the no-running solution.

In order to see how much spatial curvature is allowed, we
consider a rather general model including the parameters
$r,$ $n\_{\mathrm{s}},$ and $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ as well as $\Omega\_{K}$.
We find that
$\Omega\_{K}=-0.058^{+0.046}\_{-0.026}$
with Planck+WP, and
$\Omega\_{K}=-0.004\pm 0.0036$ with Planck+WP+BAO.
More details can be found by consulting the parameter tables available
online.1010
10
Available at: http://www.sciops.esa.int/index.php
  
?project=planck&page=Planck\_Legacy\_Archive
Figure [5](#S4.F5 "Figure 5 ‣ 4.4 Open inflation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation") shows
$r$ and $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ for this family of models.
We conclude that any possible spatial curvature is small in magnitude
even within this general model and that the spatial curvature scale is
constrained to lie far beyond the horizon today.
Open models predict a tensor spectrum enhanced at small wavenumber $k\mathrel{\raise 1.29167pt\hbox{$<$}\mkern-14.0mu\lower 2.58334pt\hbox{$\sim$}}1$, where $k=1$ corresponds to the curvature scale, but
our constraint on $\Omega\_{K}$ and cosmic variance imply that
this aspect is likely unobservable.

### 4.5 Relaxing the assumption of the late-time cosmological concordance model

The joint constraints on $n\_{\mathrm{s}}$ and $r$ shown in Fig. [1](#S4.F1 "Figure 1 ‣ 4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation") are one of the central
results of this paper. However, they are derived assuming the standard $\Lambda$CDM cosmology
at late times (i.e., $z\lesssim 10^{4}$). It is therefore natural to ask how
robust our conclusions are to
changes of the late time cosmological model. We discuss two classes of models:
firstly, changes to the $\Lambda$CDM energy content; and secondly, a more general
reionization model. These extensions can lead to degeneracies of the additional
parameters with $n\_{\mathrm{s}}$ or $r$.1111
11
We considered a further generalization, which also causes the joint
constraints on $n\_{s}$ and $r$ to change slightly. We allowed
the amplitude of the lensing contribution to the temperature power
spectrum $A\_{\mathrm{L}}$
to vary as a free parameter. In this case we find the following
Planck+WP+BAO constraints:
$n\_{s}=0.972\pm 0.006$, $A\_{\mathrm{L}}=1.24^{+0.10}\_{-0.11},$ $r<0.15$ at 95% CL.

#### 4.5.1 Extensions to the energy content

We consider the $\Lambda$CDM+$r$+$N\_{\mathrm{eff}}$, $\Lambda$CDM+$r$+$Y\_{\mathrm{P}}$,
$\Lambda$CDM+$r$+$\sum m\_{\nu},$ and $\Lambda$CDM+$r$+$w$ extensions of the standard model.
This selection is motivated by the impact on the CMB damping tail of the first two and the effect on the
Sachs-Wolfe plateau at low multipoles for the latter two. The resulting contours are shown in
Fig. [6](#S4.F6 "Figure 6 ‣ 4.5.1 Extensions to the energy content ‣ 4.5 Relaxing the assumption of the late-time cosmological concordance model ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation").
While the lower limit on $n\_{\mathrm{s}}$ is stable under all extensions considered here, the models that
alter the high-$\ell$ part of the spectrum permit significantly bluer spectral tilts, and accordingly also
lead to a weaker bound on the tensor-to-scalar ratio.
By allowing $N\_{\mathrm{eff}}$ to float, we obtain $n\_{\mathrm{s}}=0.9764\pm 0.0106$ and
$r\_{0.002}<0.15$ at 95% CL.1212
12
Selected non-standard values for $N\_{\mathrm{eff}}$ deserve further
investigation. For the additional fractional contribution motivated by
a Goldstone boson $\Delta N\_{\mathrm{eff}}=0.39$ ([Weinberg, 2013](#bib.bib334)),
we obtain $n\_{\mathrm{s}}=0.9726\pm 0.0057$ and
$r\_{0.002}<0.14$ at 95% CL for Planck+WP+BAO+high-$\ell$. For an additional species of neutrinos, we obtain
$n\_{\mathrm{s}}=0.9947\pm 0.0056$ and $r\_{0.002}<0.17$ at 95% CL for Planck+WP+BAO+high-$\ell$.
For $\Lambda$CDM+$r$+$Y\_{\mathrm{P}}$ we obtain
$n\_{\mathrm{s}}=0.9810\pm 0.0111$ and $r\_{0.002}<0.18$ at 95% CL.
The models modifying the large-scale part of the power spectrum, on the other hand, do not lead to a
notable degradation of constraints on either $n\_{\mathrm{s}}$ or $r$ ($n\_{\mathrm{s}}=0.9648\pm 0.0061$ and $r\_{0.002}<0.13$ at 95% CL for $\Lambda$CDM+$r$+$\sum m\_{\nu}$, and $n\_{\mathrm{s}}=0.9601\pm 0.0070$ and $r\_{0.002}<0.11$ at 95% CL for $\Lambda$CDM+$r$+$w$).

Figure 6: Marginalized joint 68% and 95% CL regions for Planck+WP+BAO data for $\Lambda$CDM+$r$+$N\_{\mathrm{eff}}$
and $\Lambda$CDM+$r$+$Y\_{\mathrm{P}}$ (top); and $\Lambda$CDM+$r$+$\sum m\_{\nu}$ and $\Lambda$CDM+$r$+$w$ (bottom).
Shown for comparison are the corresponding contours for the $\Lambda$CDM+$r$ model.

#### 4.5.2 General reionization scenario

In the standard rapid reionization scenario typically used
in CMB analysis, the Universe is assumed to be completely transparent after recombination,
but the ionization fraction increases from zero to one over a duration $\Delta z\approx 1$ at a certain redshift $z\_{\mathrm{reion}},$ which is
the only unknown parameter of the reionization model. This model is obviously
simplistic, but for CMB analysis it works quite well because the CMB has little
sensitivity to the details of how the ionization fraction changes from 0 to 1.
In this section we study to what extent allowing more general reionization scenarios
may alter some of the conclusions concerning the constraints on $n\_{\mathrm{s}}$ and $r$
as well as on $\tau$.
As discussed in [Mortonson & Hu (2008a)](#bib.bib212) and [Mortonson & Hu (2008b)](#bib.bib213), CMB anisotropies
constrain reionization almost entirely by using the
shape of the large-scale EE power spectrum, and the power is redistributed from larger to smaller
scales for reionization processes which take place
during a non-negligible redshift interval, since they start at an earlier epoch.

We use the method developed by [Mortonson & Hu (2008a)](#bib.bib212)
to describe and constrain the reionization history.
A complete principal component basis serves to describe the effect
of reionization on the large-scale $E$-mode polarization power spectrum.
Following [Mortonson & Hu (2008a)](#bib.bib212) we bin the ionization history $x\_{\mathrm{e}}(z\_{i})$ using $95$ equal width bins with $\Delta z=0.25$
ranging from $z\_{\mathrm{min}}=6$ to $z\_{\mathrm{max}}=30$.
For the redshifts $z<z\_{\mathrm{min}}$ we assume values for $x\_{\mathrm{e}}$
which take into account first (and possibly second) helium ionization and
complete hydrogen ionization ($x\_{\mathrm{e}}=1.16$ for $z<3$ and $x\_{\mathrm{e}}=1.08$ for $3<z<6$).
For $z>30$
we fix $x\_{\mathrm{e}}=2\times 10^{-4}$ as the value of $x\_{\mathrm{e}}$
expected before reionization (and after primordial recombination).
Any reionization history can be parameterized as a free function of redshift by decomposing
the ionization fraction as $x\_{\mathrm{e}}(z)=x\_{\mathrm{e}}^{\mathrm{f}}(z)+\sum\_{\mu}m\_{\mu}S\_{\mu}(z)$,
where the principal
components, $S\_{\mu}(z)$, are the eigenfunctions of the
Fisher matrix computed by taking the derivatives of the EE polarization power spectrum with
respect to $x\_{\mathrm{e}}(z)$ and $x\_{\mathrm{e}}^{\mathrm{f}}(z)$ is a fiducial ionization fraction.
Following [Mortonson & Hu (2008a)](#bib.bib212) we consider here the first five eigenfunctions,
$S\_{\mu}(z)$ with $\mu=1,...,5$,
which will be varied with the other cosmological parameters.

In Fig. [7](#S4.F7 "Figure 7 ‣ 4.5.2 General reionization scenario ‣ 4.5 Relaxing the assumption of the late-time cosmological concordance model ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation") we plot the 68% and 95% CL regions for $n\_{\mathrm{s}}$ and $r.$
The constraint on the tensor-to-scalar ratio is not significantly affected by this additional marginalization, increasing
to $r\_{0.002}<0.13$ at 95% CL.
The scalar spectral index is increased to $n\_{\mathrm{s}}=0.9650\pm 0.0080$,
compared with $n\_{\mathrm{s}}=0.9603\pm 0.0073$ obtained with the rapid reionization scheme.
This is the same trend as noted in [Pandolfi et al. (2010)](#bib.bib231) using WMAP data, but the effect is less significant due to the improved measurement of the temperature spectrum by Planck.
The larger freedom in the reionization history
increases the width of the posterior on the derived optical depth,
which is still partially degenerate with the scalar spectral index of primordial perturbations.
The $n\_{\mathrm{s}}=1$ model is still excluded at high significance; however,
we find $\Delta\chi\_{\mathrm{eff}}^{2}=12.5$ compared to the $\Lambda$CDM model.

Figure 7: Marginalized joint 68% and 95% CL regions for Planck+WP data for
$\Lambda$CDM+$r$ for instantaneous and general reionization.

## 5 Inflationary model comparison

In Sect. [4.2](#S4.SS2 "4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation")
several representative families of parameterized models
for the inflationary potential were analysed within the
slow-roll approximation in the neighbourhood of the pivot scale
$k\_{\*}$. Approximate constraints were
applied to reject models for which there is no plausible scenario
for entropy generation. In this
section we revisit some of the parametric models defined
in Sect. [4.2](#S4.SS2 "4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation").
Here, however, the modes for the first order
perturbations, as described in Sect. [2.2](#S2.SS2 "2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), are integrated
numerically. Thus there is no slow-roll approximation, and the issue of the
existence of a plausible scenario for entropy generation
is examined more carefully. We perform a statistical
model comparison between the competing parameterized
potentials, both within the framework of
Bayesian model comparison and in terms of the relative
likelihoods of the best fit models from each parameterized
family.

As noted in Sect. [2.3](#S2.SS3 "2.3 Ending inflation and the epoch of entropy generation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), considerable uncertainty
surrounds what occurred during the epoch of entropy generation,
particularly with respect to the energy scale at which
entropy generation ends and the average
equation of state between that epoch and the end of inflation.
For this reason, we explore a number of scenarios for this intermediate era
during which entropy generation takes place.
The models compared in this section include
inflation with power law potentials, defined in Eq. [34](#S4.E34 "In Power law potential and chaotic inflation ‣ 4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation"),
with several representative values for $n$;
natural inflation, in Eq. [39](#S4.E39 "In Natural inflation ‣ 4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation"); and hilltop inflation, with
$p=4$ and $\lambda=4\Lambda^{4}/\mu^{4}$ in Eq. [37](#S4.E37 "In Hilltop models ‣ 4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation").

The free parameters in these inflationary potentials may vary over several orders of
magnitude corresponding to unknown scales in high energy particle physics. Consequently a
logarithmic prior is a sensible choice for these parameters. However, there is no
theoretical guidance on how to truncate these model priors. We therefore adopt broad priors initially
and then truncate them as follows in order to compare all the models
on an equal footing.

The strongest constraint on the inflationary parameter space comes from the amplitude of the
primordial power spectrum. This is a free parameter in most models, and successful structure
formation in a universe dominated by cold dark matter has long been known to require primordial
fluctuations with $\mathcal{R}\approx 10^{-5}$, or $A\_{\mathrm{s}}\approx 10^{-10}$ ([Zeldovich, 1972](#bib.bib336); [Linde, 1990](#bib.bib181), see
e.g.,). We can therefore immediately reject models for which
$A\_{\mathrm{s}}$ is far from this value, so regions of parameter space which do not yield
$10^{-11}\leq A\_{\mathrm{s}}\leq 10^{-7}$ are a priori excluded. This range is generous
relative to estimates of $A\_{\mathrm{s}}$ prior to Planck ([Komatsu et al., 2011](#bib.bib158), e.g.,), but
the results do not depend strongly on the range chosen. This effectively truncates the
logarithmic priors on the model parameters, leaving a parameter subspace compatible with basic
structure formation requirements.

For the single parameter models this requirement defines the range of $\lambda$ in
Eq. [34](#S4.E34 "In Power law potential and chaotic inflation ‣ 4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation"). However, for generic multi-parameter models, an $A\_{\mathrm{s}}$-based
cut may select a nontrival region of parameter space, as happens for the two cases considered
here (see e.g., Fig. 1 in [Easther & Peiris (2012)](#bib.bib88)). Without the $A\_{\mathrm{s}}$-based cut in
the prior, the parameter volume for both natural and hilltop inflation would be rectangular, and
the corresponding Bayesian evidence values computed for these models would be lowered.

| Model | Priors |
| --- | --- |
| $n=2/3$ | $-13<\log\_{10}(\lambda)<-7$ |
| $n=1$ | $-13<\log\_{10}(\lambda)<-7$ |
| $n=2$ | $-13.5<\log\_{10}(m^{2})<-8$ |
| $n=4$ | $-16<\log\_{10}(\lambda)<-10$ |
| Natural | $-5<\log\_{10}(\Lambda)<0$ |
|  | $0<\log\_{10}(f)<2.5$ |
| Hilltop | $-8<\log\_{10}(\Lambda)<-1$ |
| $p=4$ | $-17<\log\_{10}(\lambda)<-10$ |
| $\Lambda$CDM | $0.9<n\_{\mathrm{s}}<1.02$ |
|  | $3.0<\ln\left[10^{10}A\_{s}\right]<3.2$ |

|  |  |
| --- | --- |
| Matching | Prior |
| $N\_{\*}$ | $20\leq N^{\*}\leq 90$ |

Table 6: Model priors. Dimensionful quantities are expressed in units with
$M\_{\mathrm{pl}}$ set to unity.
The matching parameter $N\_{\*}$, computed at $k\_{\*}=0.05$ Mpc-1,
allows us to marginalize over the uncertainty in connecting the
inflationary era to astrophysical scales. Additional cuts are
made in these parameter ranges to select out physically relevant subspaces
compatible with basic structure formation requirements and different
entropy generation scenarios, as described in the text, resulting in non-rectangular model
priors in some cases. We also marginalize over the concordance cosmological parameters and
foreground parameters of the Planck likelihood, as described in the text.

As discussed in Sect. [2.3](#S2.SS3 "2.3 Ending inflation and the epoch of entropy generation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), specifying an inflationary
potential does not enable us to predict the late time CMB angular power spectra. The subsequent
expansion history and
details of the epoch of entropy generation are required to relate the value of
the inflaton field at Hubble radius crossing to comoving wavenumbers in today’s
Universe, through Eq. [24](#S2.E24 "In 2.3 Ending inflation and the epoch of entropy generation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"). Physically, the fundamental parameter that
sets the observable perturbation spectrum is the value of the field $\phi\_{\*}$
at which the pivot mode leaves the Hubble radius.
It can be rescaled by a shift $\phi\_{\*}\rightarrow\phi\_{\*}+\phi\_{0}$, and the
range over which $\phi$ changes during inflation varies greatly between models.
Consequently we treat the remaining number of $e$-folds, $N\_{\*}$, after the pivot
scale leaves the Hubble radius as a free parameter with a wide uniform prior, since
this quantity has a consistent interpretation across models. The pivot scale
used to compute $N\_{\*}$ is $k\_{\*}=0.05$ Mpc-1.
However, given our ignorance
concerning the epoch of entropy generation, a multitude of entropy generation
scenarios for each inflationary potential can occur. Some possibilities are as follows, with
parameters referring to Eq. [24](#S2.E24 "In 2.3 Ending inflation and the epoch of entropy generation ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation").

1. 1.

   Instantaneous entropy generation scenario.
   At the end of inflation, all the energy in the inflaton field is instantaneously
   converted into radiation.
2. 2.

   Restrictive entropy generation scenario (narrow range for $w\_{\mathrm{int}}$).
   $\rho\_{\mathrm{th}}^{1/4}=10^{9}$ GeV, and $w\_{\mathrm{int}}\in[-1/3,1/3].$
3. 3.

   Permissive entropy generation scenario (wide range for $w\_{\mathrm{int}}$).
   $\rho\_{\mathrm{th}}^{1/4}=10^{3}$ GeV, and $w\_{\mathrm{int}}\in[-1/3,1].$

The equations of state with $w\_{\mathrm{int}}$ in the range $[1/3,1]$ appear less
plausible, but models with these values have been put forward ([Pallis, 2006](#bib.bib230)), so this
possibility cannot be completely excluded.
Moreover the $w\_{\mathrm{int}}$ parameterization captures a variety of scenarios in which the
post-inflationary Universe is thermalized, but not radiation dominated,
including phases of coherent oscillations ([Martin & Ringeval, 2010](#bib.bib202); [Easther et al., 2011](#bib.bib85)),
resonance ([Traschen & Brandenberger, 1990](#bib.bib321); [Kofman et al., 1994](#bib.bib155); [Kofman et al., 1997](#bib.bib156); [Allahverdi et al., 2010](#bib.bib13)), kination
([Spokoiny, 1993](#bib.bib304); [Chung et al., 2007](#bib.bib67)), secondary or thermal inflation
([Lyth & Stewart, 1996](#bib.bib195)), moduli domination ([Banks et al., 1994](#bib.bib23); [de Carlos et al., 1993](#bib.bib78)),
primordial black hole domination ([Anantua et al., 2009](#bib.bib15)), or a frustrated cosmic
string network ([Burgess et al., 2005](#bib.bib58)), all of which lead to an expansion rate
differing from that of a radiation dominated universe.

| Model | Instantaneous | | Restrictive | | Permissive | |
| --- | --- | --- | --- | --- | --- | --- |
|  | entropy generation | | entropy generation | | entropy generation | |
|  | $\ln[{\mathcal{E}}/{\mathcal{E}\_{0}}]$ | $\Delta\chi^{2}\_{\mathrm{eff}}$ | $\ln[{\mathcal{E}}/{\mathcal{E}\_{0}}]$ | $\Delta\chi^{2}\_{\mathrm{eff}}$ | $\ln[{\mathcal{E}}/{\mathcal{E}\_{0}}]$ | $\Delta\chi^{2}\_{\mathrm{eff}}$ |
| $n=4$ | $-14.9$ | $25.9$ | $-18.8$ | $27.2$ | $-13.2$ | $17.4$ |
| $n=2$ | $-4.7$ | $5.4$ | $-7.3$ | $6.3$ | $-6.2$ | $5.0$ |
| $n=1$ | $-4.1$ | $3.3$ | $-5.4$ | $2.8$ | $-4.9$ | $2.1$ |
| $n=2/3$ | $-4.7$ | $5.1$ | $-5.2$ | $3.1$ | $-5.2$ | $2.3$ |
| Natural | $-6.6$ | $5.2$ | $-8.9$ | $5.5$ | $-8.2$ | $5.0$ |
| Hilltop | $-7.1$ | $6.1$ | $-9.1$ | $7.1$ | $-6.6$ | $2.4$ |
| $\Lambda$CDM | $-4940.7$ | $9808.4$ | $...$ | $...$ | $...$ | $...$ |

Table 7: Inflationary model comparison results.
For each model and set of assumptions concerning entropy generation [(1), (2), (3)], the
natural logarithm of the Bayesian evidence ratio as well as $\Delta\chi^{2}\_{\mathrm{eff}}$ for the
best fit model in each category are indicated, relative to the $\Lambda$CDM concordance
model (denoted by subscript “0”). $\ln{\mathcal{E}}\_{0}$ and $-2\ln{\mathcal{L}\_{0}}$ are
given for the reference model.

At the other extreme, the decision to exclude $w\_{\mathrm{int}}<-1/3,$ as done here, is
not completely justifiable. We cannot, for example, rule out a first order phase
transition at a lower energy scale that would drive $w\_{\mathrm{int}}$ below $-1/3$, but
here we neglect this possibility. Our analysis does not preclude a
secondary period of inflation, but does require that the
average expansion
during the post-inflationary regime parameterized by $w\_{\mathrm{int}}$ should not be
inflationary. This caveat should be kept in mind.

For some of the parameterized models, tighter constraints can, in principle, be
placed on $w\_{\mathrm{int}}$. It has been argued ([Liddle & Leach, 2003](#bib.bib171), see e.g.,) that
for the $\lambda\phi^{4}$ potential, the uncertainties concerning
entropy generation
contribute almost no uncertainty in the determination of $\phi\_{\*}$. This is because
according to the virial theorem, a field sloshing about $\phi=0$ in a quartic
potential has the same average $w$, namely $w=1/3$, as the radiation equation of
state. More generally, for a potential of the form $\phi^{n}$ around the minimum,
$w\_{\mathrm{vir}}=\langle w\rangle=(n-2)/(n+2)$ ([Turner, 1983](#bib.bib325));
therefore, one may argue that $w\_{\mathrm{int}}$ should be restricted to the interval
whose endpoints are $1/3$ and $w\_{\mathrm{vir}}$. This approach was taken by
[Martin & Ringeval (2010)](#bib.bib202) in obtaining Bayesian constraints on the reheating
temperature for monomial potentials from the CMB. However this scenario
requires a carefully tuned potential that has approximately a $\phi^{n}$ shape, both at
large field values and near the origin far below the inflationary scale.
Typically, potentials for which $V(\phi)\sim\phi^{n}$ at large field values can
have very different shapes near the origin. Thus, following
[Easther & Peiris (2012)](#bib.bib88), in this paper we explore a broader range
of $w\_{\mathrm{int}}$ for these models (including the cases above as subsets) in order to
obtain data-driven constraints on $w\_{\mathrm{int}}$.

In this paper we focus on the three representative scenarios itemized above,
referred to hereafter as scenarios (1), (2), and (3). Our algorithm draws a
value of $N\_{\*}$ and then given the value of $\rho\_{\mathrm{th}}$, computes
$w\_{\mathrm{int}}$, which is a derived parameter. Models for which $w\_{\mathrm{int}}$ lies outside
the specified range of each scenario under consideration are excluded.

The full set of priors for the inflationary physics is given in
Table [6](#S5.T6 "Table 6 ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation"). Dimensionful quantities are expressed in units with
reduced Planck mass $M\_{\mathrm{pl}}$ set to unity.

Due to the nontrivial likelihood surfaces and the large dimensionality of the parameter spaces
explored in this section, we use ModeCode coupled to MultiNest v3.01313
13
Made
available ahead of public release to the Planck Collaboration by Farhan Feroz and Mike
Hobson ([Feroz et al., 2013](#bib.bib98)). to map out the parameter space. In addition to the standard nested sampling (NS)
algorithm, MultiNest v3.0 enables nested importance sampling (NIS), resulting in
substantial speed gains1414
14
We have carried out
extensive tests of NIS versus NS, and chosen the
following settings for the computations presented here: NIS on, constant efficiency mode on,
$300$ live points, tolerance and efficiency parameters set to $0.5$ and $0.02$, respectively.
and significant enhancements in the accuracy of the Bayesian evidence computation compared
to NS alone for
the same computational setup.

### 5.1 Results

Table [7](#S5.T7 "Table 7 ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation") presents model comparison results for the ensemble of
parameterized potential families described above. We report the Bayesian evidence (model averaged likelihood) ratio, which provides a self-consistent framework for calculating
the betting odds between models (see Sect. [3.4](#S3.SS4 "3.4 Model selection ‣ 3 Methodology ‣ Planck 2013 results. XXII. Constraints on inflation")). The uncertainty in these
logarithmic evidence values is approximately $0.2$.
We also report the $\Delta\chi^{2}\_{\mathrm{eff}}$ values computed from the $2\ln{\mathcal{L}}\_{\mathrm{max}}$ values found by the sampler.

The monomial models have a single parameter potential, and the natural and hilltop inflation
models have two parameters each. All entropy generation scenarios except case (1) contribute one
additional parameter to the inflationary sector. The evidence ratios and $\Delta\chi^{2}\_{\mathrm{eff}}$ values are
presented with respect to the $\Lambda$CDM cosmological model.

None of the inflationary models tested here fit the data as well as the $\Lambda$CDM model.
This mostly reflects that there is no evidence in the data for $r$ different from zero.
Furthermore, the priors listed in Table [6](#S5.T6 "Table 6 ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation") for the $\Lambda$CDM primordial sector
are purely phenomenological, roughly corresponding to ranges somewhat broader than WMAP
constraints. Narrowing them around the best fit model arbitrarily increases the evidence in its
favour. Instead it is instructive to compare the relative evidence for the inflationary models
presented.

Table [7](#S5.T7 "Table 7 ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation") shows that the $\lambda\phi^{4}$ model is decisively ruled
out by Planck, confirming previous analyses by the WMAP team
([Peiris et al., 2003](#bib.bib239); [Spergel et al., 2007](#bib.bib301); [Dunkley et al., 2009](#bib.bib83); [Komatsu et al., 2011](#bib.bib158)) based on the model track plotted
on the $n\_{\mathrm{s}}\textrm{-}r$ plane. Recent model selection analyses ([Martin et al., 2011](#bib.bib203); [Easther & Peiris, 2012](#bib.bib88)) with WMAP 7-year data found that the model was already
disfavoured by odds of about $400$:$1$ against. With Planck, the odds against this model are
at least $500\thinspace 000$:$1$ compared to $\Lambda$CDM for a broad range of entropy generation
scenarios. The same conclusion is confirmed by the extremely poor $\Delta\chi^{2}\_{\mathrm{eff}}$ values for the model.
Given the strength of our results, in the flexible setting of the permissive entropy generation
scenario, it is possible not just to rule out models where the potential is of the quartic form
in the full range from the origin to the inflationary scales, but also a general class where the
potential is of the $n=4$ form in the $\phi$-range where the cosmological perturbations are
generated, but exhibits a different shape near the origin.

Two other large field models, the quadratic potential and natural inflation, are somewhat
disfavoured by the Planck data, especially when broader entropy generation scenarios are
considered. Compared with the $\Lambda$CDM model, these models are disfavoured by $\Delta\chi^{2}\_{\mathrm{eff}}\sim 5$–$6$ depending on the entropy generation scenario. This reflects the analysis of
Sect. [4](#S4 "4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation"), where the overlap of the model predictions and the data constraints
on the $n\_{\mathrm{s}}\textrm{-}r$ plane is seen to be mostly outside the joint $68$% CL contour.
However, from the Bayesian evidence point of view, it is too early to declare these models
incompatible with the data. To make this judgement, it is more prudent to compare these
models to the $n=1$ case, which has the best evidence with respect to $\Lambda$CDM, rather
than to $\Lambda$CDM itself, which provides our reference point for the evidence calculation,
but has arbitrary prior ranges. In their simplest forms—instantaneous entropy generation—the
$n=2$ and natural inflation models are only disfavoured by odds of about $1$–$12$:$1$ against,
which does not rise to a high level of significance.1515
15
In comparison, odds of $\penalty\ 150$:$1$
are considered highly significant in this context.

Figure 8: Constraints on $n\_{\mathrm{s}}$ vs. $r$ at $k\_{\*}=0.002$ Mpc-1 for the inflationary
models considered (i.e., power law potentials with $n=2/3,1,2$, and $4$, natural
inflation, and hilltop inflation), showing joint 68% and 95% CL. Blue and grey
distributions correspond to the restrictive and permissive entropy generation scenarios,
respectively. The instantaneous entropy generation case corresponds to the thin (red)
contours in the natural and hilltop panels; for the single parameter models,
this case corresponds to the lowest-$r$ extremity of the restrictive case. The difference between the
natural inflation region in Fig. [1](#S4.F1 "Figure 1 ‣ 4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation") and the natural inflation constraints
shown here is due to the strong projection effect described in the text.

Figure 9: Constraints on $n\_{\mathrm{s}}$ vs. $w\_{\mathrm{int}}$ at $k\_{\*}=0.002$ Mpc-1 for the
inflationary models considered, as in Fig. [8](#S5.F8 "Figure 8 ‣ 5.1 Results ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation"). The instantaneous entropy generation
case
(1) corresponds to $w\_{\mathrm{int}}=1/3$.

Figure 10: Constraints on $\log\_{10}(\lambda)$ vs. $w\_{\mathrm{int}}$ for the inflationary models
considered, as in Figs. [8](#S5.F8 "Figure 8 ‣ 5.1 Results ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation") and [9](#S5.F9 "Figure 9 ‣ 5.1 Results ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation").

Figure 11: Potential parameters for natural inflation and hilltop
inflation, as in Figs. [8](#S5.F8 "Figure 8 ‣ 5.1 Results ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation"), [9](#S5.F9 "Figure 9 ‣ 5.1 Results ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation"), and
[10](#S5.F10 "Figure 10 ‣ 5.1 Results ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation"). On the
natural inflation panel, instantaneous entropy generation corresponds to a thin diagonal along
the top edge of entropy generation case (3).

The models most compatible with the Planck data in the set considered here are the two
interesting axion monodromy potentials, $n=1$ ([McAllister et al., 2010](#bib.bib205)) and $n=2/3$
([Silverstein & Westphal, 2008](#bib.bib299)), which are motivated by inflationary model building in the context of
string theory. The $p=4$ hilltop model presents an interesting case. This model was previously
found to be compatible with WMAP 7-year data, performing almost as well as the monodromy
potentials ([Easther & Peiris, 2012](#bib.bib88)). However it exhibits significant tension with the
Planck data, both in terms of evidence ratios and the maximum likelihood. The only exception
is the entropy generation scenario (3) which has odds of greater than $1000$:$1$ against compared to
$\Lambda$CDM, and yet the maximum likelihood is not significantly different from the $n=1$ case.
This indicates that while the extra freedom allowed by the least restrictive
entropy generation scenario
improves the best fit, this prior is not very predictive of the data. However, the result seems
counterintuitive and merits further comment; we will consider this question further at the end of this
section when parameter estimation results are discussed.

We now turn to parameter constraints. Figure [8](#S5.F8 "Figure 8 ‣ 5.1 Results ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation") presents marginalized joint
constraints from Planck+WP alone on the derived parameters $n\_{{\mathrm{s}},0.002}$ and
$r\_{0.002}.$ Figure [9](#S5.F9 "Figure 9 ‣ 5.1 Results ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation") shows the corresponding joint constraints on
$n\_{{\mathrm{s}},0.002}$ and $w\_{\mathrm{int}}$, again a derived parameter.
Figure [10](#S5.F10 "Figure 10 ‣ 5.1 Results ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation") shows joint constraints on $w\_{\mathrm{int}}$ and the potential parameter
$\log\_{10}(\lambda)$ ($\log\_{10}(\Lambda)$ in the case of natural inflation). It is instructive to
consider the three sets of figures together. The restrictive and permissive entropy generation
scenarios are shown on all panels; the instantaneous entropy generation
case is shown for the two parameter
models, natural inflation and hilltop, in Fig. [8](#S5.F8 "Figure 8 ‣ 5.1 Results ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation")—for the monomial
potentials this case corresponds to the lowest-$r$ extremity of the restrictive case
constraints, and to $w\_{\mathrm{int}}=1/3$ in the other two figures.

The quartic potential conflicts with the data because it predicts a high tensor-to-scalar ratio.
Hence the model maximizes its likelihood by pushing towards the lower-$r$, bluer-$n\_{\mathrm{s}}$
limits of its parameter space, which corresponds to increasing $w\_{\mathrm{int}}$ as much as allowed by the
entropy generation prior. The contours terminate at the lowest-$r$ limit when each entropy
generation case hits
its $w\_{\mathrm{int}}$ prior upper limit (i.e., $w\_{\mathrm{int}}=1/3$ and $w\_{\mathrm{int}}=1$ for restrictive and
permissive entropy generation, respectively). For each case, the lower limit on $w\_{\mathrm{int}}$,
corresponding to the reddest-$n\_{\mathrm{s}}$ extremity of the confidence contours, is
data-driven. The quadratic potential encounters the same difficulty but at a less extreme level.

The two axion monodromy potentials are compatible with a wide range of entropy generation
scenarios. The instantaneous entropy generation scenario is
compatible with the data for both models. For
restrictive entropy generation in the $n=1$ model, we obtain a data-driven upper limit on
$w\_{\mathrm{int}}$, which just touches the $w\_{\mathrm{int}}=1/3$ case at the 95% CL. At the lower limit, the
$w\_{\mathrm{int}}$ posterior is truncated by the prior, as for the $n=2/3$ case. For the latter, there is a
data-driven upper limit on $w\_{\mathrm{int}}$ which is controlled by the upper limit on $n\_{\mathrm{s}}$.
For permissive entropy generation, the upper and lower limits on $w\_{\mathrm{int}}$ for both models are
data-driven, corresponding to the upper and lower limits on $n\_{\mathrm{s}},$ respectively.

The constraints on natural inflation require some interpretation. The relationship between the
empirical $n\_{\mathrm{s}}$ and $r$ parameters and the potential parameters for natural inflation
is discussed in detail by [Savage et al. (2006)](#bib.bib289) and [Mortonson et al. (2011)](#bib.bib214) along with parameter
constraints derived from WMAP 3-year ([Spergel et al., 2007](#bib.bib301)) and WMAP 7-year ([Larson et al., 2011](#bib.bib163)),
respectively. In this model, there is a degeneracy between $f$ and $\Lambda$ in the limit where
these parameters are large so that natural inflation resembles the quadratic model. The priors
are chosen to exclude most of this region. The priors on $\log\_{10}(f)$ and $\log\_{10}(\Lambda)$
still allow a region of nearly degenerate models that contribute to a ridge seen in the natural
inflation panel of Fig. [8](#S5.F8 "Figure 8 ‣ 5.1 Results ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation"). These models closely match the values of
$n\_{\mathrm{s}}$ and $r$ seen in the quadratic potential constraints. The marginalized
constraints on $n\_{\mathrm{s}}$ and $r$ depend strongly on the prior on $\log\_{10}(f)$ due to the
projection of a large number of degenerate models onto this ridge. Therefore the apparent
preference for this region of parameter space over models with lower values of $r$ is largely
due to this effect and is not driven by the data. This highly nonlinear mapping between the
logarithmic priors on the potential parameters and the power law parameters (which are derived
parameters in this analysis) leads to a strong projection effect, which accounts for the
difference in visual appearance between these contours and the region labelled natural
inflation in Fig. [1](#S4.F1 "Figure 1 ‣ 4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation").

Generally, for fixed $N\_{\*}$, decreasing $\Lambda$ and $f$ reduces both $n\_{\mathrm{s}}$ and $r$.
Thus natural inflation models can have lower values of $r$ than the quadratic potential without
increasing $n\_{\mathrm{s}}$ and $N\_{\*}$. This feature means that the potential parameters for this
model are relatively uncorrelated with $w\_{\mathrm{int}}$, in contrast with the other models considered
here, as illustrated in the Fig. [10](#S5.F10 "Figure 10 ‣ 5.1 Results ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation"). Nevertheless we obtain data-driven
bounds on $w\_{\mathrm{int}}$ in the permissive entropy generation case as well as a lower bound in the restrictive
entropy generation case. Both bounds overlap with the instantaneous generation limit.

The upper panel of Fig. [11](#S5.F11 "Figure 11 ‣ 5.1 Results ‣ 5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation") shows our lower limit of $f\gtrsim 10.0$
$M\_{\mathrm{pl}}$ (95% CL), compared with the WMAP7 limit $f\gtrsim 5.0$ $M\_{\mathrm{pl}}$
(95% CL) reported by [Mortonson et al. (2011)](#bib.bib214). Indeed, the Planck limit is in agreement with
the Planck prediction presented in that work. There is a hint of an upper limit on $f$ as
well, driven by the fact that this corresponds to the quadratic inflation limit, which is in
tension with the data. However this is only a $1\sigma$ effect.

The $p=4$ hilltop model has two distinct branches: a small-field scenario, where
$r\lesssim 0.001$ and $n\_{\mathrm{s}}<0.95$; and a large-field limit in which $V(\phi)\sim\phi$ ([Adshead et al., 2011](#bib.bib8)). Physically, the small-field limit is consistent with the Lyth
bound, and we can select it by fixing $\log\_{10}(\Lambda)<-2.5$ in the prior. We observe that the
data select out this small field branch, which requires explanation given that we know that the
$n=1$ model (the limit of the large field branch) is perfectly compatible with the data. In
fact, this can be tested by restricting the $\log\_{10}(\Lambda)$ prior by hand to the large-field
branch. The hilltop model constitutes a difficult sampling problem, as is apparent from Fig. 4
in [Easther & Peiris (2012)](#bib.bib88). An examination of the progress
of the nested sampler for the case of
the full hilltop prior reveals the reason for the small-field branch being selected out. In
this case, the posterior for the large-field branch is extremely thin compared to the model
prior in this regime—much thinner than the posterior for the small-field branch in comparison
to its respective prior. Therefore this region occupies very little probability mass, and is
dropped in preference to the more predictive small-field branch. This high likelihood but
extremely thin ridge is also responsible for the counterintuitive result reported in the
model selection analysis, where the model was found to have a good $\Delta\chi^{2}\_{\mathrm{eff}}$ with respect to
$\Lambda$CDM, and yet be highly disfavoured by the Bayesian evidence. In summary, confirming the
results of Sect. [4](#S4 "4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation"), this model is in agreement with the data in the limit
where it overlaps the linear $n=1$ model. But since this region of high likelihood occupies a
very small fraction of the prior, this model is heavily penalized by the Bayesian evidence for
failing to predict the data over most of its prior space.

## 6 Observable window of inflation

Section [4.2](#S4.SS2 "4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation")
presented an analysis of several representative inflationary
potentials within the framework of the slow-roll approximation and their
compatibility with the Planck data.
The results are summarized in Fig. [1](#S4.F1 "Figure 1 ‣ 4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation"). In that case
the full potential is considered in order
to identify a plausible range for the location
of $\phi\_{\*}$ on the potential $V(\phi).$ This requires
a complete story. In other words, the potential must be specified
starting above the point where the largest observable scales
first exited the Hubble radius, and extending
to the minimum of the potential.

In this section we explore another approach. We adopt the
point of view that we are interested in reconstructing
the inflationary potential only over the observable range—that is,
the interval of $\phi$ corresponding to the scales
observable today in the CMB. We constrain the potential over the range where
these scales
exited the Hubble radius during inflation as well as a few $e$-folds before and after.
The cosmological perturbations are not imprinted
instantaneously at the moment of Hubble radius crossing, but rather gradually
over a few $e$-folds. We expand around $\phi\_{\*}$, taking the view that
a plausible extension of the potential outside this observable range is
always possible, so that one has precisely the number of $e$-folds
of inflation needed for $\phi\_{\*}$ to correspond to $k\_{\*}$ today.

The argument is that one can always end inflation abruptly by
imposing a sharp waterfall feature where needed, or prolong inflation
by inserting a sufficiently long
plateau into the potential by hand, for example, for models with a large tilt.
A foreseeable objection
to this approach is that the extensions of the potential required
outside the observable window may render the potential unnatural.
This possibility should be kept in mind, although
naturalness is an elusive and uncomfortably subjective concept.
The analysis in this section does not rely on the slow-roll
approximation. Instead each $k$ mode is integrated exactly by
numerical integration, as described in Sect. [2.2](#S2.SS2 "2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), under the
assumption of a canonical kinetic term.

Figure 12: Posterior distribution for the first three slow-roll potential parameters using Planck+WP data.
In the $n=2-4$ cases, the inflaton potential is expanded to $n$th order,
and the spectrum is obtained by fitting the numerically computed power spectrum to the data, with no slow-roll approximation
and no assumption about the extrapolation of the potential outside
the observable window.

Figure 13: Posterior distribution for
the Taylor expansion coefficients, $V\_{i}$, of the inflaton potential. The potential is expanded
to $n$th order, assuming a flat prior on $\epsilon\_{V}$, $\eta\_{V}$, $\xi^{2}\_{V}$, and $\varpi\_{V}^{3}$.
The coefficients $V\_{i}$ are expressed in natural units
(where $\sqrt{8\pi}M\_{\mathrm{pl}}=1).$
The contours show only half of the allowed regions for potential parameters: the other half is symmetric, with
opposite signs for $V\_{1}$ and $V\_{3}$.

Figure 14: Observable range of the best fitting inflaton potentials, when $V(\phi)$ is Taylor expanded to
$n$th order around the pivot value $\phi\_{\*}$, in natural units (where $\sqrt{8\pi}M\_{\mathrm{pl}}=1),$ assuming
a flat prior on $\epsilon\_{V}$, $\eta\_{V}$, $\xi^{2}\_{V}$, and $\varpi\_{V}^{3}$, and using Planck+WP data. Potentials obtained
under the transformation $(\phi-\phi\_{\*})\rightarrow(\phi\_{\*}-\phi)$ leave the same observable signature and are
also allowed. The sparsity of potentials with a small $V\_{0}=V(\phi\_{\*})$ is explained by the flat prior on $\epsilon\_{V}$ rather
than on $\ln(V\_{0}).$ In fact, $V\_{0}$ is unbounded from below.

Two complementary approaches
to reconstruct the potential
have been explored in the literature.
The first approach, followed in this paper, expands the potential $V(\phi)$ directly in powers
of $(\phi-\phi\_{\*}).$ In this case the numerical integration
of the slow-roll solution must start sufficiently early so that any
initial transient has had a chance to decay, and one is in the
attractor solution when the dynamics of the largest observable modes
in the Universe today start to have an interesting evolution. This is
the approach followed, e.g., by
[Lesgourgues & Valkenburg (2007)](#bib.bib167) and [Mortonson et al. (2011)](#bib.bib214) using
publicly available
codes.1616
16
http://wwwlapp.in2p3.fr/valkenbu/inflationH/,
http://zuserver2.star.ucl.ac.uk/~ hiranya/ModeCode/.

A second approach expands $H(\phi)$ as a Taylor series
in $(\phi-\phi\_{\*}).$ As discussed in Sect. [2.2](#S2.SS2 "2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), this has the advantage that $H(\phi)$
determines both the potential
$V(\phi)$ and the solution $\phi(t),$ so the issue of having
to start sufficiently early in order to allow the initial transient to decay
is avoided. This method was used, for example, in
[Kinney (2002)](#bib.bib147), [Kinney et al. (2006)](#bib.bib148), [Peiris & Easther (2006a)](#bib.bib235), [Easther & Peiris (2006)](#bib.bib87), [Peiris & Easther (2006b)](#bib.bib236), and [Peiris & Easther (2008)](#bib.bib238)
using analytic and semi-analytic approximations,
and in
[Lesgourgues et al. (2008)](#bib.bib166), [Powell & Kinney (2007)](#bib.bib273), [Hamann et al. (2008c)](#bib.bib128), and [Norena et al. (2012)](#bib.bib223)
using a fully numerical approach.

These approaches could lead to results that differ from those in
Sect. [4.2](#S4.SS2 "4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation").
Firstly, if the running of the index is large, the slow-roll approximation
taken to second order is not necessarily accurate for all models
allowed by the data. The relation between the spectral
parameters ($\ln A\_{\mathrm{s}}$, $n\_{\mathrm{s}}$,
$\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$, $r$) and the underlying
inflationary potential $V(\phi)$ is therefore
uncertain. Secondly, for spectra with a large running,
there is no guarantee that an inflationary model giving
such a spectrum exists. All allowed
models have $r\ll 1$, so these models are consistent with
$\epsilon\_{V}(k\_{\*})\ll 1$ at the pivot scale. However, towards the
edge of the observable range, the potential
may become incompatible with $\epsilon\_{V}(k)<1$
(i.e., with the requirement of inflationary expansion). These possible
pitfalls are avoided using the methods in this section, since the data have been fit directly by the candidate
$V(\phi)$ or $H(\phi)$, computed numerically without any slow
roll assumptions over the entire observable range.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | from $V(\phi)$ | | | from |
| $n$ | 2 | 3 | 4 | slow-roll |
| $\epsilon\_{V}$ | $<0.0078$ | $<0.015$ | $<0.021$ | $<0.015$ |
| $\eta\_{V}$ | $-0.011\_{-0.015}^{+0.018}$ | $-0.016\_{-0.025}^{+0.028}$ | $0.022\_{-0.047}^{+0.052}$ | $-0.014\_{-0.022}^{+0.030}$ |
| $\xi^{2}\_{V}$ | – | $0.011\_{-0.011}^{+0.012}$ | $-0.015\_{-0.032}^{+0.031}$ | $0.009\_{-0.011}^{+0.011}$ |
| $\varpi^{3}\_{V}$ | – | – | $0.016\_{-0.019}^{+0.018}$ | – |
| $\Delta\chi\_{\mathrm{eff}}^{2}$ | 0 | $-0.7$ | $-3.7$ | $-0.9$ |

Table 8: Numerical reconstruction of potential parameters, compared to results with the slow-roll
approximation, when tensors and running are
included (Planck+WP 95% CL, with $k\_{\*}=0.05\penalty\$Mpc-1). The effective $\chi^{2}$
value is given relative to the model with a quadratic potential.

|  | from $V(\phi)$ | | |
| --- | --- | --- | --- |
| $n$ | 2 | 3 | 4 |
| $\ln[10^{10}A\_{\mathrm{s}}]$ | $3.087\_{-0.050}^{+0.050}$ | $3.115\_{-0.063}^{+0.066}$ | $3.130\_{-0.066}^{+0.071}$ |
| $n\_{\mathrm{s}}$ | $0.961\_{-0.015}^{+0.015}$ | $0.958\_{-0.016}^{+0.017}$ | $0.954\_{-0.018}^{+0.018}$ |
| $100\thinspace\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ | $-0.05\_{-0.14}^{+0.13}$ | $-2.2\_{-2.3}^{+2.2}$ | $-0.61\_{-3.1}^{+3.1}$ |
| $100\thinspace\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}$ | $-0.01\_{-0.75}^{+0.73}$ | $-0.3\_{-1.2}^{+1.0}$ | $6.3\_{-7.8}^{+8.6}$ |
| $r$ | $<0.12$ | $<0.22$ | $<0.35$ |

Table 9: The scalar amplitude, tilt, running, running of the running, and tensor-to-scalar
ratio inferred from a numerical reconstruction of the inflaton potential (Planck+WP 95% CL, with $k\_{\*}=0.05\penalty\$Mpc-1).

We define a class of models over the observable range based on
the expectation that the potential should be smooth.
$V(\phi)$ is approximated by a Taylor expansion up to order $n,$
and we explore the cases $n=2,$ $3,$ and $4.$
For each $V(\phi)$, we integrate over inflationary fluctuations
using the inflation module implemented in CLASS1717
17
http://class-code.net ([Lesgourgues, 2011](#bib.bib165); [Blas et al., 2011](#bib.bib46))
as described in [Lesgourgues & Valkenburg (2007)](#bib.bib167).
Potentials are rejected for which the attractor solution cannot be reached
when the largest observable scales cross the Hubble radius.
The parameters sampled are the potential
and its derivatives at the pivot scale when
$k\_{\*}$ crosses the Hubble radius during inflation.

To avoid parameter degeneracies, we impose uniform priors on $\epsilon\_{V},\eta\_{V},\xi^{2}\_{V},$ and
$\varpi^{3}\_{V}$ at the pivot field value $\phi\_{\*}.$
The advantage of uniform priors on these parameters is that—to the extent that the slow-roll conditions are
satisfied—these coefficients relate linearly to observable quantities such as
$n\_{\mathrm{s}}$, $r$, $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k,$ and $\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}$.
Figure [12](#S6.F12 "Figure 12 ‣ 6 Observable window of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") and Table [8](#S6.T8 "Table 8 ‣ 6 Observable window of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") show the posterior
probability for these coefficients, and Fig. [13](#S6.F13 "Figure 13 ‣ 6 Observable window of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") shows the
posterior probability for the Taylor series coefficients $V\_{i}$. In
Fig. [14](#S6.F14 "Figure 14 ‣ 6 Observable window of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), we show the observable range of the
best fitting inflaton potentials (for a sample extracted randomly from the converged Markov chains).
The edges of the observable range correspond to Hubble crossing for the minimum and maximum
values of $k$ used in the Boltzmann code.
We stress here that the Planck data suggest
a flat potential when the lowest order slow-roll primordial
spectra are considered, as analysed in Sect. [4.2](#S4.SS2 "4.2 Constraining inflationary models using the slow-roll approximation ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation").
However, when the restrictions
to lowest order in the slow-roll approximation
are relaxed, the inflaton potential can differ markedly from a plateau-like potential,
as the green curves in Fig. [14](#S6.F14 "Figure 14 ‣ 6 Observable window of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") show.

When fitting $V(\phi)$ for each model in parameter space, we compute
($n\_{\mathrm{s}}$, $dn\_{\mathrm{s}}/d\ln k$, $d^{2}n\_{\mathrm{s}}/d\ln k^{2}$, and $r$) at the pivot scale a
posteriori directly from the numerical primordial spectra. The results are shown in
Table [9](#S6.T9 "Table 9 ‣ 6 Observable window of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") and can be compared to those of Table [5](#S4.T5 "Table 5 ‣ 4.3 Running spectral index ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation") in Sect. [4](#S4 "4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation").
We can also use the results of
Sect. [4](#S4 "4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation") for the $\Lambda$CDM+$r$+$\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ model to infer the potential parameters ($\epsilon\_{V}$,
$\eta\_{V}$, and $\xi\_{V}^{2}$) using the second-order slow-roll expressions, and
compare different approaches in the space of potential parameters
(see Fig. [12](#S6.F12 "Figure 12 ‣ 6 Observable window of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") and the last column in Table [8](#S6.T8 "Table 8 ‣ 6 Observable window of inflation ‣ Planck 2013 results. XXII. Constraints on inflation")).

The model with a quadratic potential in the observable window ($n=2$) leads
to bounds on $\epsilon\_{V}$, $\eta\_{V}$, $n\_{\mathrm{s}}$, and $r$ very close to the $\Lambda$CDM+$r$ case. This is
not a surprise since such potentials cannot give values of $n\_{\mathrm{s}}$ and $r$
compatible with the data and at the same time
a large running. A significant $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ can be generated
only in the presence of a large $\xi\_{V}^{3}$ (i.e., with a significant $V^{\prime\prime\prime}$).
Since quadratic potentials produce little running, they are faithfully described by
the slow-roll approximation.

The model with a cubic term ($n=3$) has the freedom to generate a large running, $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$.
Indeed one can check that the results for the $n=3$ model are close to those of the
$\Lambda$CDM+$r$+$\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ model presented in Sect. [4](#S4 "4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation"). The agreement between these two models
remains very good, despite the fact that in the presence of a large running, the slow-roll approximation
can become inaccurate. The running in a potential with $n=3$ is not exactly scale invariant;
this is not captured by the $\Lambda$CDM+$r$+$\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ parameterization.

The $n=4$ model has even more freedom, allowing a considerable running
of the running $\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}$ (to the extent that inflation holds during
the observable $e$-folds). In that case, the spectrum is better fitted
when the two parameters $r$ and $\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}$ are non-zero. In
Fig. [14](#S6.F14 "Figure 14 ‣ 6 Observable window of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), we see that most $n=4$ potentials have a long
and steep tail for $\phi<\phi\_{\*}$, with a kink around $\phi\_{\*}-0.4$ (in
natural units). This shape generates a significant running on the
largest observable scales, while preserving a smaller running on
smaller scales. With such a feature in the scalar
primordial spectrum at large scales combined with a non-zero contribution from tensor
fluctuations, the best fit model for $n=4$ has a temperature spectrum
very close to that of the minimal $\Lambda$CDM model for $\ell>40$, but not for
smaller multipoles. The amplitude of the Sachs-Wolfe plateau is
smaller. This allows the large-scale data points from Planck to be fitted
slightly better. However, the case $r=\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k=0$ still lies at
the edge of the 95% CL, and the minimum effective $\chi^{2}$ of this model is smaller than in the $n=2$ case by only 3.7.

A comparison of the $n=3$ and $n=4$ results clearly shows that the process of
expanding the inflaton potential to various orders and fitting it to the data does
not converge (at least not by $n=4$). Given the $1$–$2\sigma$ preference of Planck data
for a nonzero running and running of the running, we find that a model-independent reconstruction
of the inflaton potential is not possible under the assumptions of this section.
In other words, as long as we assume that $V(\phi)$ can be described during and after observable
inflation by a polynomial of order 2 or 3, we can put strong bounds on $\epsilon\_{V}$ and $\eta\_{V}$.
But if we introduce more derivatives to describe the observable part of the potential
and allow complete freedom to extrapolate $V(\phi)$ outside this region,
the constraints can be easily evaded.

## 7 Primordial power spectrum reconstruction

Figure 15: 
Planck primordial power spectrum feature search results.
Top four panels: The reconstructed power spectrum at four values for
the smoothing parameter $\lambda$. The red curves indicate the maximum
likelihood configuration for the fractional deviation
$f(k)$ of the power
spectrum relative to a power law fiducial model (with $A\_{\mathrm{s}}=2.20\times 10^{-9}$ and $n\_{\mathrm{s}}=0.9603$) for the penalized
likelihood. The error bars have a width corresponding to the minimum reconstructible width
(the minimum width for a Gaussian feature so that the mean square deviation
of the expectation value of the reconstruction differs by less than 10%) and a vertical extent showing the $1\sigma$ and
$2\sigma$ limits for the fractional deviation averaged over the box. The grey hashed regions
at the far left and right show where
the fixing prior (i.e., $\alpha$) sets $f(k)=0.$
The inner grey regions show where the reconstruction bias is so great that the
minimum reconstructible width is undefined. Mock features in this region produce reverberations
over the entire interval.
With $\lambda=10^{3}$ and $\lambda=10^{4}$, we find
statistically significant fluctuations around $k\sim 0.1\penalty\$Mpc-1. Lower panels: The
$1\sigma$ error bars for three combinations of cosmological parameters at the four values of $\lambda$.
The maximum likelihood value for the fiducial model is indicated by
the dashed line for comparison.

In this section we report on a search for features in the primordial
power spectrum. In the basic six parameter model studied in the companion Planck paper [Planck Collaboration
XVI (2014)](#bib.bib256), the primordial power spectrum $\mathcal{P\_{R}}(k)$, which
includes only the adiabatic
mode, is modelled using the power law $\mathcal{P\_{R}}(k)=A\_{\mathrm{s}}\penalty\ (k/k\_{\*})^{n\_{\mathrm{s}}-1}$, for which
the best fit values are $A\_{\mathrm{s}}=2.20\times 10^{-9}$ and $n\_{\mathrm{s}}=0.9603$ for a
pivot scale $k\_{\*}=0.05\penalty\ \textrm{Mpc}^{-1}$. An extension of this parameterization
is also considered allowing for a running of
the spectral index ($\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k=-0.013\pm 0.009$). But in
all cases considered it was assumed that the power spectrum is smooth and without
bumps, sharp features, or wiggles. In this section we investigate
whether any statistically significant evidence for features is present in the
data when these assumptions are relaxed. Allowing an arbitrary function for the input
power spectrum is not an option because in this case the recovered primordial
power spectrum is dominated by small-scale noise. Instead we consider here
a penalized likelihood approach where a preference for smooth power spectra
is imposed. Section [8](#S8 "8 Parametric searches for primordial power spectrum features ‣ Planck 2013 results. XXII. Constraints on inflation")
of this paper pursues a complementary
approach where several parametric models for wiggles and features are explored
to see whether a statistically significantly better fit can be obtained.

An extensive literature exists on how to search for features in the power spectrum
using a wide range of methods. The following papers and the references therein
provide a sampling of the literature on non-parametric reconstruction:
Richardson-Lucy deconvolution
([Lucy, 1974](#bib.bib189); [Richardson, 1972](#bib.bib280); [Hamann et al., 2010](#bib.bib129); [Shafieloo & Souradeep, 2004](#bib.bib294); [Shafieloo & Souradeep, 2008](#bib.bib295)),
deconvolution ([Tocchini-Valentini et al., 2005](#bib.bib319); [Tocchini-Valentini et al., 2006](#bib.bib320); [Ichiki & Nagata, 2009](#bib.bib141); [Nagata & Yokoyama, 2008](#bib.bib221); [Nagata & Yokoyama, 2009](#bib.bib222)),
smoothing splines ([Verde & Peiris, 2008](#bib.bib332); [Peiris & Verde, 2010](#bib.bib240); [Sealfon et al., 2005](#bib.bib291); [Gauthier & Bucher, 2012](#bib.bib108)), linear
interpolation ([Hannestad, 2004](#bib.bib131); [Bridle et al., 2003](#bib.bib50)), and Bayesian model selection
([Bridges et al., 2009](#bib.bib49); [Vázquez et al., 2012](#bib.bib331)). The approach pursued here follows [Tocchini-Valentini et al. (2006)](#bib.bib320)
and [Gauthier & Bucher (2012)](#bib.bib108) most closely.
More technical details and extensive tests validating the method
can be found in the latter reference.

Let $\mathcal{P}\_{0}(k)=A\_{\mathrm{s}}(k/k\_{\*})^{n\_{\mathrm{s}}-1}$ be the best fit power spectrum
of the six parameter model. We define a general Ansatz for the power spectrum in terms
of a fractional variation, $f(k)$, relative to this fiducial model, so that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P\_{R}}(k)=\mathcal{P}\_{0}(k)\Bigl[1+f(k)\Bigr].$ |  | (47) |

Any features are then described in terms of $f(k)$.

In this analysis we use the Planck+WP likelihood supplemented by the following roughness penalty or
prior, which is
added to $-2\ln\mathcal{L}$:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\mathbf{f}^{T}\mathbf{R}(\lambda,\alpha)\mathbf{f}=\lambda\int\mathrm{d}\kappa\penalty\ \left(\frac{\partial^{2}f(\kappa)}{\partial\kappa^{2}}\right)^{2}$ |  | (48) |
|  |  | $\displaystyle+\alpha\int\_{-\infty}^{\kappa\_{\mathrm{min}}}\mathrm{d}\kappa\penalty\ f^{2}(\kappa)+\alpha\int^{+\infty}\_{\kappa\_{\mathrm{max}}}\mathrm{d}\kappa\penalty\ f^{2}(\kappa)\thinspace,$ |  |

where $\kappa=\ln k$
and $\kappa\_{\mathrm{min}}$
and
$\kappa\_{\mathrm{max}}$
delimit the scales probed by the data.
The first regularization term penalizes any deviation from a straight
line of the function $f(\kappa)$. The second and third terms drive the
$f(\kappa)$ to zero where there are effectively no constraints from the data. The
value of $\lambda$ controls the smoothness of the reconstruction, but the precise
value of $\alpha$ is less important. It must be large enough to force $f(k)$ towards
zero when $\kappa<\kappa\_{\mathrm{min}}$ and $\kappa>\kappa\_{\mathrm{max}}$ but not so large as to
render the matrices ill-conditioned. We use $\alpha=10^{4}.$

We represent $f(k)$ using a cubic
B-spline on a grid of points in $k$-space uniformly spaced in $\kappa$ with step size
$\Delta\kappa=0.025$ and extended from $\kappa=-12.5$ to $\kappa=-0.3$
giving us a total of 485 knots so that $\mathbf{f}=\{f\_{i}\}\_{i=1}^{485}$. The density of grid points
is sufficiently large so that artefacts near the scale of the knot spacing are suppressed
for the values of $\lambda$ used here.
Given the large number of dimensions, it is not practical to explore the likelihood using MCMC methods.
However, for the power spectrum parameters, the predicted
$C\_{\ell}$s are related by a linear transformation given fixed
cosmological parameters, allowing us (for fixed cosmological and nuisance
parameters) to find the maximum likelihood solution using the
Newton-Raphson method.1818
18
Since the Planck likelihood
uses a quadratic approximation, the maximum likelihood solution can be found by
solving a linear system. The Newton-Raphson method, however, is needed for other CMB
likelihoods which include terms beyond quadratic order.
We define

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{M}(\boldsymbol{\Theta})=\underset{f\_{i}\in[-1,1]}{\textrm{min}}\left\{-2\ln\mathcal{L}(\boldsymbol{\Theta},\mathbf{f})+\mathbf{f}^{T}\mathbf{R}(\lambda,\alpha)\mathbf{f}\right\},$ |  | (49) |

where the vector $\boldsymbol{\Theta}$ represents the cosmological
parameters unrelated to the power spectrum and the foreground nuisance parameters.
We first minimize over $f\_{i}$ using Newton-Raphson iteration and then
in an outer loop minimize over $\boldsymbol{\Theta}$ using the downhill simplex algorithm.
To carry out this procedure, the Planck likelihood code was modified to compute the gradient
and Hessian of the likelihood with respect to the $C\_{\ell}$s.

The cosmological Boltzmann solver CAMB
was modified to accept the vector of primordial power spectrum knots ${\textbf{f}}.$
By default CAMB calculates
the $C\_{\ell}$s for a subset of $\ell$ and interpolates
to obtain the full multipole power
spectrum. Instead we calculate the $C\_{\ell}$s at each $\ell$ explicitly.

The boundaries $\kappa\_{\mathrm{min}}$ and $\kappa\_{\mathrm{max}}$ defining where $f(\kappa)$
is allowed to differ from zero are chosen to match the range of $\ell$ constrained by
the high-$\ell$ likelihood. The likelihood
includes $C\_{\ell}$s between $\ell=50$ and $\ell=2500$, which roughly
corresponds to $k\in[0.003,0.2]\penalty\$Mpc-1. The low-$\ell$ likelihood covers
$\ell=2$ to $\ell=49$, which roughly corresponds to
$k\in[10^{-4},0.003]\penalty\ \textrm{Mpc}^{-1}$. In this range of $\ell$, cosmic variance is
large, making feature detection difficult. Calculating the gradient and
Hessian of a pixel-based low-$\ell$ likelihood is computationally time consuming.
We therefore use the low-$\ell$ likelihood only to constrain the cosmological
parameters. We choose $k\_{\mathrm{min}}=0.005\penalty\ \textrm{Mpc}^{-1}$ and $k\_{\mathrm{max}}=0.3\penalty\ \textrm{Mpc}^{-1}.$
Within this $k$ range, variations in
the $C\_{\ell}$s due to the $f\_{i}$ are too small to affect
the overall likelihood through the low-$\ell$ likelihood.
We observed that the difference in the
low-$\ell$ likelihood between the reconstructed $f(k)$ and $f(k)=0$ is small
($<1\%$) compared to the difference in the high-$\ell$ likelihood.

The cosmological parameters $\tau$ and $A\_{\mathrm{s}}$ are almost completely
degenerate for the temperature anisotropy except at very low $\ell$, so we
fix $\tau$ to its best fit value for the fiducial model.
The likelihood contains additional nuisance parameters that
model foreground components and beam shapes, as discussed in [Planck Collaboration
XV (2014)](#bib.bib255).
Many of the nuisance parameters, it can be argued, are unlikely
to introduce spurious small-scale structure because they represent foreground models with a power
law and thus smooth angular power spectrum.
However some nuisance parameters, in particular those describing
beam uncertainties, could conceivably introduce artefacts into the
reconstruction. Unfortunately, converging to the correct
maximum likelihood reconstruction with all
the beam shape parameters included is prohibitively time consuming. Therefore we fix the
nuisance parameters to their fiducial best fit values, leaving a more detailed
examination of this issue to future work.

Figure 16: 
CMB multipole spectrum residuals for best fit primordial power spectrum reconstruction with
smoothing parameter
$\lambda=10^{3}$. The panels show the $C\_{\ell}$ spectrum residuals (compared to the best fit
power law fiducial model represented by the horizontal straight dashed line) for the four auto- and
cross-spectra included in the high-$\ell$ likelihood. Here
$\mathcal{\mathcal{}}{D}\_{\ell}=\ell(\ell+1)C\_{\ell}/(2\pi).$
The data points have been binned with $\Delta\ell=31$ and foregrounds subtracted
according to the best fit foreground parameters. The solid black line shows the CMB spectrum
residual for the maximum likelihood primordial power spectrum reconstruction with
$\lambda=10^{3}.$

Figure 17: 
CMB multipole spectrum residual for the primordial power spectrum test feature. The test feature (top) is
set to the anomalously large deviation of the primordial power spectrum reconstruction
for $\lambda=10^{3}$ in the interval $0.1\textrm{ Mpc}^{-1}<k<0.15\textrm{ Mpc}^{-1}$, and is zero
elsewhere. Bottom: The angular spectrum corresponding to this feature. We observe a large dip at $\ell\approx 1800$.

We found that simultaneously allowing extra degrees of freedom for small-scale structure and variations
in the cosmological parameters changes the best fit fiducial model—that is, $A\_{\mathrm{s}}$ and
$n\_{\mathrm{s}}$—so that the variations with respect to the fiducial model no longer visibly gave the best straight line fit.
Therefore we allow $A\_{\mathrm{s}}$ and $n\_{\mathrm{s}}$ to vary, so that the fiducial model is indeed the best straight
line fit through the plotted data points. Detailed investigation showed that neither the priors, nor
low-$\ell,$ nor high-$\ell$ data play a significant role in determining the best fit fiducial model.
This effect is small and within the error bars for $A\_{\mathrm{s}}$ and $n\_{\mathrm{s}}$
established assuming the fiducial model. To summarize, we maximize the likelihood with
respect to the control points $f\_{i}$ and the three cosmological parameters
$h$, $\Omega\_{\mathrm{c}}h^{2}$, and $\Omega\_{\mathrm{b}}h^{2}$. We
then update the fiducial model ($A\_{\mathrm{s}}$ and $n\_{\mathrm{s}}$)
at each iteration by finding the best fit power law through the current best fit reconstruction.

Once the maximum likelihood solution has been found, the second derivatives about this solution are
readily calculated by extracting the relevant matrices for most of the components, and
estimating the remaining components using finite differences. The second derivative matrix is used to
estimate the error on the reconstructed $f\_{i}$ and the three cosmological parameters $h$, $\Omega\_{\mathrm{c}}h^{2}$, and $\Omega\_{\mathrm{b}}h^{2}$. Monte Carlo simulations of a fiducial data set with a simplified
CMB likelihood including some of the non-Gaussianities1919
19
The simplified likelihood
$-2\ln\mathcal{L}\_{\mathrm{toy}}=\sum\_{\ell=2}^{\ell\_{\mathrm{max}}}(2\ell+1)\biggl(\frac{C\_{\ell}^{\mathrm{obs}}}{C\_{\ell}+N\_{\ell}}-\ln\frac{C\_{\ell}^{\mathrm{obs}}}{C\_{\ell}+N\_{\ell}}-1\biggr)$
assumes full sky coverage and isotropic instrument noise. suggest that this approximation of the error
is accurate for $\lambda\mathrel{\raise 1.29167pt\hbox{$>$}\mkern-14.0mu\lower 2.58334pt\hbox{$\sim$}}10^{3}$.

Figure [15](#S7.F15 "Figure 15 ‣ 7 Primordial power spectrum reconstruction ‣ Planck 2013 results. XXII. Constraints on inflation") summarizes our results, showing the estimated $f(k)$ in bins
and the corresponding 1$\sigma$ and 2$\sigma$ errors. Errors in $k$ are also shown to represent the
minimum reconstructible width evaluated at the middle of each bin. This is the minimum
width that a Gaussian feature must have to be reconstructed
with a small enough bias such that the mean reconstruction differs by less than
10% rms. The minimum
reconstructible width is closely related to the correlation length, so that the errors
between adjacent bins are weakly correlated and the total
number of bins represents roughly the effective number of independent degrees
of freedom.

While the plots with a significant roughness penalty—that is, with $\lambda=10^{6}$ and $\lambda=10^{5}$—do
not show any statistically significant evidence for features standing out above
the noise of the reconstruction,
for a smaller roughness penalty—that is, for $\lambda=10^{4}$ and $\lambda=10^{3}$—a nominally statistically
significant feature is clearly visible around $k\approx 0.13\penalty\ \textrm{Mpc}^{-1}.$
We do not understand the origin of this feature, which may be primordial or may arise as a foreground or other
systematic error in the high-$\ell$ portion of
the likelihood. It should be noted that most of the robustness tests described in the likelihood
paper assume smooth power spectra.
The maximum excursions are locally at 3.2$\sigma$ and 3.9$\sigma$ for
$\lambda=10^{4}$ and $\lambda=10^{3},$ respectively. In each of these two cases
we correct for the look elsewhere effect by calculating the probability that one
of the plotted error bars deviates by the same number of or more standard deviations. This calculation
is carried out using the covariance matrix of the plotted error bars. We obtain $p=1.74\%$
and $p=0.21\%$, which corresponds to 2.4$\sigma$ and
3.1$\sigma$, respectively. Additional simulations were
carried out to validate the method by generating mock data according to the fiducial
model and measuring the errors of the reconstruction obtained. These investigations
confirm the error model. These tests were carried out both with and without test features.
It can be argued that foregrounds are unlikely to explain
the observed feature because all the foreground models involve smooth power law templates,
whereas this feature is localized in multipole number.
It is important to assess by means of a more extensive set
of simulations whether the statistical significance assigned
to this result is accurate.

We investigate which CMB angular multipoles correspond to this
apparent feature. Figure [16](#S7.F16 "Figure 16 ‣ 7 Primordial power spectrum reconstruction ‣ Planck 2013 results. XXII. Constraints on inflation") shows the $C\_{\ell}$ residual from the
reconstructed power spectrum with the best fit power law power spectrum subtracted
together with the data for each of the frequency map correlation combinations used in the
CamSpec likelihood. We observe a smooth dip around $\ell\approx 1800,$ which is
significant compared to the error bars, in particular for the 217 GHz map. To determine whether
this dip is in fact responsible for large deviation in the reconstruction,
we take the $\lambda=10^{3}$ best fit
reconstruction and set $f(k)=0$ everywhere except for $0.1\textrm{ Mpc}^{-1}<k<0.15\textrm{ Mpc}^{-1}$—the region where the large deviation is located—and
calculate the corresponding $C\_{\ell}$ spectrum. Figure [17](#S7.F17 "Figure 17 ‣ 7 Primordial power spectrum reconstruction ‣ Planck 2013 results. XXII. Constraints on inflation") plots
the $C\_{\ell}$ residuals of this test feature, which
show a large dip at around $\ell\approx 1800$, thus demonstrating
that the dip in the $C\_{\ell}$ residual of the data centred at $\ell\approx 1800$ is responsible
for the large excursions in the primordial power spectrum reconstructions.

Note added: The broad dip around $\ell=1800$ in the
temperature power spectrum, seen in the 217 GHz channel,
has been shown to result from residuals that were
strongest in the first survey. In work done
after submission of this paper, this feature was shown to be associated
with imperfectly subtracted electromagnetic interference
generated by the drive electronics of the 4 K cooler and picked
up by the detector read-out electronics. In a recent study, more aggressive
measures were applied to remove 4 K contaminated
data. When this censured data was propagated all
the way to the maps and the power spectrum, the amplitude of
the feature was lowered to below the noise for the first survey.
A more complete account and analysis will
appear in the next round of Planck cosmology papers.

## 8 Parametric searches for primordial power spectrum features

In this section we continue to investigate deviations
of the primordial power spectrum from a smooth, featureless function, in this case
by testing a set of theoretically motivated models.

### 8.1 Models and priors

We consider three models describing features in the primordial power spectrum:
adding a global oscillation, a localized oscillation, or a cutoff to the large-scale power spectrum.

#### 8.1.1 Wiggles model

Due to the exponential growth of the scale factor during inflation, a
periodically recurring event in proper time which affects the amplitude of curvature
perturbations would produce features that are periodic in $\ln k$.
This occurs, for instance, for non Bunch-Davies initial
conditions ([Easther et al., 2001](#bib.bib86); [Danielsson, 2002](#bib.bib76); [Martin & Brandenberger, 2003](#bib.bib200); [Bozza et al., 2003](#bib.bib48)), or,
e.g., in the axion monodromy model ([Silverstein & Westphal, 2008](#bib.bib299)), as a
consequence of instanton induced corrections to the
potential ([Flauger et al., 2010](#bib.bib101)). In these scenarios the
primordial spectrum has an oscillation superimposed on an underlying smooth spectrum.

Here we consider the following parameterization of the primordial
spectrum (referred to as the wiggles model):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P\_{R}}(k)=\mathcal{P}\_{0}(k)\;\left\{1+\alpha\_{\mathrm{w}}\thinspace\sin\left[\omega\ln\left(\frac{k}{k\_{\*}}\right)+\varphi\right]\right\},$ |  | (50) |

with amplitude $\alpha\_{\mathrm{w}}$, frequency $\omega$,
and phase $\varphi$ to quantify the superimposed oscillations. The
underlying smooth spectrum has the standard power law form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}\_{0}(k)=A\_{\mathrm{s}}\thinspace\left(\frac{k}{k\_{\*}}\right)^{n\_{\mathrm{s}}-1}.$ |  | (51) |

The prior ranges for the wiggles model parameters are given in
Table [10](#S8.T10 "Table 10 ‣ 8.1.3 Cutoff model ‣ 8.1 Models and priors ‣ 8 Parametric searches for primordial power spectrum features ‣ Planck 2013 results. XXII. Constraints on inflation"). The obvious prior for the phase $\varphi$ is uniform over
the interval $(0,2\pi).$ We also choose a uniform prior
on $\alpha\_{\mathrm{w}}$ (a logarithmic prior on $\alpha\_{\mathrm{w}}$ introduces considerable
dependence of the resulting marginalized posteriors on the lower limit
and does not contain the smooth spectrum as a limiting case).
The sensitivity to primordial wiggles is limited at high frequencies
by the width of the transfer function ([Hamann et al., 2008a](#bib.bib126))
and at low frequencies by the requirement of at least one full
oscillation in the observable part of the power spectrum.
Since Planck data are sensitive to wavenumbers over a range of
roughly four orders of magnitude, this condition implies $\omega\gtrsim 0.5$.
Here we restrict the analysis to $\omega<100$ and assume a uniform prior.
Larger values of the frequency are theoretically possible, e.g., in axion
monodromy models ([Flauger et al., 2010](#bib.bib101)), but the amplitude of the oscillations
in the $C\_{\ell}$s will be suppressed with respect to the primordial one.
A comprehensive search for higher frequency oscillations is currently underway.

#### 8.1.2 Step inflation model

If the slow roll of inflation is briefly interrupted, for instance by a phase transition
([Starobinsky, 1992](#bib.bib311); [Hunt & Sarkar, 2004](#bib.bib139)),
a burst of resonant particle production ([Chung et al., 2000](#bib.bib68)),
or a step in the inflaton potential ([Adams et al., 2001](#bib.bib6)),
or if the speed of sound changes suddenly ([Achúcarro et al., 2011](#bib.bib2)),
a localized oscillatory
feature is superimposed on the scalar primordial power spectrum.
We adopt the approximate parameterization for such a feature from a
step in the potential, introduced by [Adshead et al. (2012)](#bib.bib7), with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P\_{R}}(k)=\exp\left[\ln\mathcal{P}\_{0}(k)+\frac{\mathcal{A}\_{\mathrm{f}}}{3}\thinspace\sqrt{\eta\_{\mathrm{f}}/\mathrm{Gpc}}\frac{k\eta\_{\mathrm{f}}/x\_{d}}{\sinh(k\eta\_{\mathrm{f}}/x\_{\mathrm{d}})}W^{\prime}(k\eta\_{\mathrm{f}})\right],$ |  | (52) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $W^{\prime}(x)=\left(-3+\frac{9}{x^{2}}\right)\cos 2x+\left(15-\frac{9}{x^{2}}\right)\frac{\sin 2x}{2x}.$ |  | (53) |

As in the wiggles model, we choose a uniform prior on the amplitude parameter
$\mathcal{A}\_{\mathrm{f}}$ (see Table [10](#S8.T10 "Table 10 ‣ 8.1.3 Cutoff model ‣ 8.1 Models and priors ‣ 8 Parametric searches for primordial power spectrum features ‣ Planck 2013 results. XXII. Constraints on inflation")).
The parameter $\eta\_{\mathrm{f}}$ determines both the frequency of the feature and its location,
which is required to lie in the observable range. The damping envelope of the feature is set
by the ratio $\eta\_{\mathrm{f}}/x\_{\mathrm{d}}$. We impose uniform priors on the logarithms of
$\eta\_{\mathrm{f}}$ and $x\_{\mathrm{d}}$.

#### 8.1.3 Cutoff model

A number of models have been suggested to explain the apparent lack of power in the quadrupole
and octupole of the WMAP temperature power spectrum. Typically in these models, the onset
of a slow-roll phase coincides with the time when the largest observable scales exited the Hubble radius
during inflation. This naturally suppresses the primordial power spectrum at large scales ([Sinha & Souradeep, 2006](#bib.bib300), see, e.g.,).
We consider a phenomenological parameterization of a cutoff proposed in [Contaldi et al. (2003)](#bib.bib71), given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P\_{R}}(k)=\mathcal{P}\_{0}(k)\left\{1-\exp\left[-\left(\frac{k}{k\_{\mathrm{c}}}\right)^{\lambda\_{\mathrm{c}}}\right]\right\}.$ |  | (54) |

We apply uniform priors on $\lambda\_{\mathrm{c}}$, which determines the steepness of the cutoff,
and on the logarithm of the cutoff scale $k\_{\mathrm{c}}$.

| Model | Parameter | Prior range |
| --- | --- | --- |
| Wiggles | $\alpha\_{\mathrm{w}}$ | [0, 0.2] |
| $\omega$ | [0.5, 100] |
| $\varphi$ | [0,$2\pi$] |
| Step inflation | $\mathcal{A}\_{\mathrm{f}}$ | [0, 0.2] |
| $\ln\left(\eta\_{\mathrm{f}}/\mathrm{Mpc}\right)$ | [0, 12] |
| $\ln x\_{\mathrm{d}}$ | [-1, 5] |
| Cutoff | $\ln\left(k\_{\mathrm{c}}/\mathrm{Mpc}^{-1}\right)$ | [-12, -4] |
| $\lambda\_{\mathrm{c}}$ | [0, 15] |

Table 10:  Prior ranges imposed for the
wiggles, step inflation, and cutoff model parameters.

### 8.2 Method

To achieve the necessary numerical precision for models with features in the primordial spectra,
we modify the standard settings of the CAMB numerical code in order to calculate
$C\_{\ell}$ at each $\ell$ rather than interpolating and refine
the grid in wavenumber for the numerical integration.
These changes significantly slow down the computation.
In the models considered here, the likelihood function has
characteristics that make sampling difficult, such as extended plateaus and multiple isolated maxima,
which render the Metropolis-Hastings algorithm inefficient.
We therefore use the nested sampling algorithm implemented in the
MultiNest add-on ([Feroz & Hobson, 2008](#bib.bib96); [Feroz et al., 2009](#bib.bib97)) to CosmoMC ([Lewis & Bridle, 2002](#bib.bib169)),
which can also calculate the Bayesian evidence and the likelihood profiles.

The signatures of the feature models considered here are unique and cannot be mimicked
by varying other parameters, which lead to smooth variations of the power spectrum (with the exception of
highly tuned very low frequency oscillations that can change the acoustic peak structure). We thus
restrict ourselves to varying only the parameters describing the features and keep all remaining
cosmological and nuisance parameters fixed to their $\Lambda$CDM best fit values.2020
20
An a posteriori
maximization of the likelihood in a narrow parameter range around the best fit feature model parameters, including
a variation of all remaining cosmological and nuisance parameters, shows that the change in the best fit
$\chi^{2}\_{\mathrm{eff}}$ is merely $\mathcal{O}(1)$ and hence does not affect our conclusions.

### 8.3 Results

For all three models we find that including these additional features improves the quality of the fit
with respect to a pure power law spectrum.
For the Planck+WP data, we show the best fit primordial curvature power spectra and
temperature angular power spectrum residuals
in Fig. [18](#S8.F18 "Figure 18 ‣ 8.3 Results ‣ 8 Parametric searches for primordial power spectrum features ‣ Planck 2013 results. XXII. Constraints on inflation"), and report the best fit parameter values in Table [11](#S8.T11 "Table 11 ‣ 8.3 Results ‣ 8 Parametric searches for primordial power spectrum features ‣ Planck 2013 results. XXII. Constraints on inflation").
Since in all three cases the likelihood functions do not tend to zero in all directions of the
respective parameter spaces, the Bayesian quantities (i.e., posterior distributions and Bayes factors)
depend strongly on the choice of prior. For this reason, we also quote two prior-independent
quantities, the effective $\chi^{2}$ (i.e., $-2\Delta\ln\mathcal{L}\_{\mathrm{max}}=2\ln\mathcal{L}\_{\mathrm{max}}-2\ln\mathcal{L}\_{\mathrm{max}}^{\Lambda\mathrm{CDM}})$ and the profile $-2\Delta\ln\mathcal{L}\_{\mathrm{max}}$
as a function of selected model parameters plotted alongside the marginalized posteriors in
Fig. [19](#S8.F19 "Figure 19 ‣ 8.3 Results ‣ 8 Parametric searches for primordial power spectrum features ‣ Planck 2013 results. XXII. Constraints on inflation"), which illustrates the unconventional shape of the likelihood functions.

Figure 18: 
Top: Best fit primordial spectrum of curvature perturbations for the power law (black),
wiggles (red), step inflation (green), and cutoff (blue)
models. Centre: Residuals of the temperature angular power spectrum. Note that the scale of the
vertical axis changes at $\ell=50$.
Bottom: Zoom of region around the first acoustic peak.

For the wiggles model, oscillations around the first acoustic peak and in the $700<\ell<900$ range improve the fit to the data,
whereas for the best fit step inflation model the spectrum between the Sachs-Wolfe plateau and the first acoustic peak is fit better.
Quantitatively, the cutoff model improves the fit only modestly, with $\Delta\chi\_{\mathrm{eff}}^{2}\approx 3$, but both the wiggles
and step inflation models lead to a larger improvement, with $\Delta\chi\_{\mathrm{eff}}^{2}\approx 10$, at the cost of three new parameters.
Already for pre-Planck data, improvements of $\Delta\chi\_{\mathrm{eff}}^{2}\approx 10$ have
been reported in related analyses (e.g., [Peiris et al. 2003](#bib.bib239); [Martin & Ringeval 2004](#bib.bib201); [Elgarøy et al. 2003](#bib.bib91); [Covi et al. 2006](#bib.bib74); [Meerburg et al. 2012](#bib.bib206); [Benetti et al. 2013](#bib.bib38); [Peiris et al. 2013](#bib.bib237)).
Note that in the step inflation model, the best fit does not coincide with the maximum of the marginalized posterior probability,
indicating that some degree of fine tuning is necessary to reach the maximum of the likelihood. The maximum of the marginalized
posterior at $\ln\left(\eta\_{\mathrm{f}}/\mathrm{Mpc}\right)\approx 7.2$ actually reproduces the feature at $\ell\approx 20-40$ found
previously in WMAP data ([Peiris et al., 2003](#bib.bib239)). The secondary peak at
$\ln\left(\eta\_{\mathrm{f}}/\mathrm{Mpc}\right)\approx 4$ corresponds to a feature at multipoles $\ell\approx 1800,$ where the
analysis of Sect. [7](#S7 "7 Primordial power spectrum reconstruction ‣ Planck 2013 results. XXII. Constraints on inflation") found a feature. However the model does not
account for this feature well, yielding an
improvement of only $\Delta\chi^{2}\_{\mathrm{eff}}\approx 3$.

Whether or not these findings can be considered statistically significant or arise simply from overfitting noisy data
is not a trivial question (see, for instance, the discussion in [Bennett et al. (2011)](#bib.bib39)). From a frequentist statistics point of view,
an answer would require the rather involved procedure of repeating the analysis on a large set of simulations. In
designing the test statistic, special care would need to be taken in making sure to take into account the
look elsewhere effect (i.e., the fact that a particular observed anomaly may be very unlikely, whereas the probability of
observing some anomaly may be much larger). From a Bayesian statistics point of view, it is the Bayesian evidence
that can tell us how probable the extended models are, compared to the baseline power law primordial power spectrum.

For the models and the choice of prior probabilities considered here, the Bayesian evidence in fact favours, albeit
weakly, the simple power law spectrum over the more complex models. The reason is that the Bayesian evidence punishes
a lack of predictivity in these models. Most of the parameter space volume is not compatible
with the data. A good match to observations is obtained within only a small subregion. Nonetheless, the observed features
remain interesting since if they are real, they will also leave traces in other observabless, most notably, in the
$E$-mode polarization spectrum, where the signatures of features in the primordial spectrum are actually less washed
out than in the temperature spectrum ([Mortonson et al., 2009](#bib.bib211)). The forthcoming Planck polarization data will
prove very useful in this regard. Additionally, since strong deviations from power law
behaviour typically indicate nonlinear
physics, these models generically also predict a non-Gaussian signal potentially observable in the bispectrum ([Planck Collaboration
XXIV, 2014](#bib.bib264)).
However, the best fit wiggles and step inflation models
have oscillations with a frequency too high to be accessible to bispectrum analysis at present.

| Model | $-2\Delta\ln\mathcal{L}\_{\mathrm{max}}$ | $\ln B\_{0X}$ | Parameter | Best fit value |
| --- | --- | --- | --- | --- |
| Wiggles | $-9.0$ | 1.5 | $\alpha\_{\mathrm{w}}$ | $0.0294$ |
| $\omega$ | $28.90$ |
| $\varphi$ | $0.075\;\cdot 2\pi$ |
| Step inflation | $-11.7$ | 0.3 | $\mathcal{A}\_{\mathrm{f}}$ | $0.102$ |
| $\ln\left(\eta\_{\mathrm{f}}/\mathrm{Mpc}\right)$ | $8.214$ |
| $\ln x\_{\mathrm{d}}$ | $4.47$ |
| Cutoff | $-2.9$ | 0.3 | $\ln\left(k\_{\mathrm{c}}/\mathrm{Mpc}^{-1}\right)$ | $-8.493$ |
| $\lambda\_{\mathrm{c}}$ | $0.474$ |

Table 11:  Improvement in fit and logarithm of the Bayes factor
$B\_{0X}$ with respect to power law
$\Lambda$CDM and best fit parameter values for the wiggles, step inflation, and cutoff models.
The larger $\ln B\_{0X}$, the greater the preference for a featureless power law spectrum.

Figure 19: 
Marginalized posterior
probability (red) and profile $-2\Delta\ln\mathcal{L}\_{\mathrm{max}}$
(black) for selected parameters of the wiggles (top), step inflation (middle),
and cutoff model (bottom).

## 9 Combined analysis with Planck $f\_{\mathrm{NL}}$ constraints for single field inflation

In the previous sections we have analysed inflationary models with a canonical kinetic term. This
led to the tensor-to-scalar consistency condition requiring $n\_{\mathrm{t}}=-r/8$. It is
interesting to consider more general classes of inflationary models characterized by a non-standard
kinetic term ([Garriga & Mukhanov, 1999](#bib.bib107))
or more general higher-derivative operators ([Kobayashi et al., 2010](#bib.bib153)).
An interesting subclass of these models
are those in which the Lagrangian is a general function of the scalar inflaton field and its first
derivative: $\mathfrak{L}=P(\phi,X)$, where $X=-g^{\mu\nu}\partial\_{\mu}\phi\partial\_{\nu}\phi/2$.
A more general extension is provided by the so-called effective field theory of inflation
([Cheung et al., 2008](#bib.bib66)), which has a richer phenomenology.

We restrict our analysis to the first class of
models ([Garriga & Mukhanov, 1999](#bib.bib107); [Chen et al., 2007](#bib.bib65)), which includes $k$-inflation
models ([Armendáriz-Picón et al., 1999](#bib.bib17); [Garriga & Mukhanov, 1999](#bib.bib107)), and Dirac-Born-Infield (DBI) models
introduced in the context of brane inflation ([Silverstein & Tong, 2004](#bib.bib298); [Alishahiha et al., 2004](#bib.bib12)).
In this class of models inflation can take place with a steep potential or can be driven by the
kinetic term. One of the main features of inflationary models with a non-standard kinetic term is
that the inflaton fluctuations can propagate at a sound speed $c\_{\mathrm{s}}<1$. As shown in
previous analyses ([Peiris et al., 2007](#bib.bib234); [Powell et al., 2009](#bib.bib274); [Lorenz et al., 2008](#bib.bib186); [Agarwal & Bean, 2009](#bib.bib9), e.g.,)
there are strong degeneracies between the parameters determining the observable power spectra.
Constraints on primordial non-Gaussianity can help break this degeneracy, and we show how Planck’s
combined measurement of the power spectrum and the nonlinearity parameter
$f\_{\mathrm{NL}}$ ([Planck Collaboration
XXIV, 2014](#bib.bib264)) improves constraints on this class of models.

In models with a non-standard kinetic term the sound speed of the inflaton is given by
$c\_{\mathrm{s}}^{2}=P\_{,X}/(P\_{,X}+2XP\_{,XX})$ ([Garriga & Mukhanov, 1999](#bib.bib107)), so that in the canonical
models, where $P(\phi,X)=V(\phi)-X$, one finds $c\_{\mathrm{s}}=1$, while in general a non-trivial
$c\_{\mathrm{s}}<1$ corresponds to deviations from this standard case. Therefore, in these models, new
parameters, such as the sound speed and its running, appear in the expressions for the inflationary
observables. For the running of the sound speed it is useful to define an additional slow-roll
parameter

|  |  |  |  |
| --- | --- | --- | --- |
|  | $s\equiv\frac{\dot{c\_{\mathrm{s}}}}{c\_{\mathrm{s}}H}\thinspace.$ |  | (55) |

For values of the slow-roll parameters much less than unity, the leading order scalar power spectrum
is modified
([Garriga & Mukhanov, 1999](#bib.bib107)) to

|  |  |  |  |
| --- | --- | --- | --- |
|  | $A\_{\mathrm{s}}\approx\frac{1}{8\pi^{2}M^{2}\_{\mathrm{pl}}}\frac{H^{2}}{c\_{\mathrm{s}}\epsilon\_{1}}\thinspace,$ |  | (56) |

which is evaluated at $kc\_{\mathrm{s}}=aH$. The scalar spectral index gets an
additional contribution from the running of the sound speed,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n\_{\mathrm{s}}-1=-2\epsilon\_{1}-\epsilon\_{2}-s\thinspace.$ |  | (57) |

The gravitational sector remains unaltered by the non-trivial inflaton sound speed, retaining the
same form as for the standard slow-roll models. Therefore the usual consistency relation is
modified to $r\approx-8n\_{\mathrm{t}}c\_{\mathrm{s}}$ with $n\_{\mathrm{t}}=-2\epsilon\_{1}$ as usual
([Garriga & Mukhanov, 1999](#bib.bib107)). The more accurate relation employed in this analysis is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $r=16\epsilon\_{1}c\_{\mathrm{s}}^{(1+\epsilon\_{1})/(1-\epsilon\_{1})}.$ |  | (58) |

This accounts for the difference in freeze-out between the scalar and tensor perturbations
([Peiris et al., 2007](#bib.bib234); [Powell et al., 2009](#bib.bib274); [Lorenz et al., 2008](#bib.bib186); [Agarwal & Bean, 2009](#bib.bib9)) taking place
at $kc\_{\mathrm{s}}=aH$ for the scalar fluctuations, and at $k=aH$ for the tensor modes.

Limiting ourselves to the predictions at lowest order in the slow-roll parameters, there are
clearly degeneracies between the parameters ($A\_{\mathrm{s}},c\_{\mathrm{s}},\epsilon\_{1},\epsilon\_{2},s$),
which make the constraints on the inflationary power spectra observables less stringent in terms of
these microscopic parameters. However, for models where the inflaton field has a
non-standard kinetic term with $c\_{\mathrm{s}}\ll 1$, a high level of primordial non-Gaussianity of
the scalar perturbations is generated ([Chen et al., 2007](#bib.bib65), see, e.g.,). In these models
primordial non-Gaussianity is produced by the higher-derivative interaction terms that arise when
expanding the kinetic part of the Lagrangian, $P(\phi,X)$. The amplitude of the non-Gaussianity,
defined by the nonlinearity parameter $f\_{\mathrm{NL}}$, receives two dominant contributions, arising
from the inflaton interaction terms $(\dot{\delta\phi})^{3}$ and $\dot{\delta\phi}(\nabla\delta\phi)^{2}$. Each of them produces non-Gaussianity shapes similar to the so-called
equilateral type ([Babich et al. 2004](#bib.bib21)), i.e., a signal that peaks for equilateral
triangles $k\_{1}=k\_{2}=k\_{3}$. However, they are sufficiently distinct that the total signal can be very
different from the equilateral one ([Senatore et al., 2010](#bib.bib293)). The nonlinearity parameter of the
second interaction term is $f\_{\mathrm{NL}}=(85/324)(1-c\_{\mathrm{s}}^{-2})$, while the other is
determined by a second independent amplitude ([Chen et al., 2007](#bib.bib65); [Senatore et al., 2010](#bib.bib293)).
Constraints on the primordial non-Gaussianity, presented in the companion paper
[Planck Collaboration
XXIV (2014)](#bib.bib264), thus allow us to construct a lower limit for the sound speed
$c\_{\mathrm{s}}$. This helps reduce degeneracies in the parameter space of inflationary models with
non-standard kinetic terms. In particular, without the limits on the sound speed coming from the
constraints on primordial non-Gaussianity, it is not possible to derive an upper limit on the
parameter $\epsilon\_{1}$, because the relation between the tensor-to-scalar ratio and $\epsilon\_{1}$
also involves the sound speed (see, e.g., Eq. [58](#S9.E58 "In 9 Combined analysis with Planck 𝑓_NL constraints for single field inflation ‣ Planck 2013 results. XXII. Constraints on inflation")).

In this paper, we consider three cases. One is a general analysis as described above, where we
focus on the simplest case of a constant speed of sound with $s=0$. From the Planck limits on
primordial non-Gaussianity in general single field models of inflation ([Planck Collaboration
XXIV, 2014](#bib.bib264)), the
most conservative constraint on the sound speed is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $c\_{\mathrm{s}}\geq 0.02\quad(95\%\penalty\ \mathrm{CL})\thinspace.$ |  | (59) |

In this large parameter space, we assume a uniform prior $0.02\leq c\_{\mathrm{s}}\leq 1$ in
Eq. [58](#S9.E58 "In 9 Combined analysis with Planck 𝑓_NL constraints for single field inflation ‣ Planck 2013 results. XXII. Constraints on inflation") within the HFF formalism described in the Appendix. We show the joint constraints on
$\epsilon\_{1}$ and $\epsilon\_{2}$ in Fig. [20](#S9.F20 "Figure 20 ‣ 9 Combined analysis with Planck 𝑓_NL constraints for single field inflation ‣ Planck 2013 results. XXII. Constraints on inflation"). By including the 95$\%$ CL constraint on
$c\_{\mathrm{s}}$ from Eq. [59](#S9.E59 "In 9 Combined analysis with Planck 𝑓_NL constraints for single field inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), Planck+WP constrain $\epsilon\_{1}<0.053$. Such
constraints can be compared with the restricted case of $c\_{\mathrm{s}}=1$, also shown in
Fig. [20](#S9.F20 "Figure 20 ‣ 9 Combined analysis with Planck 𝑓_NL constraints for single field inflation ‣ Planck 2013 results. XXII. Constraints on inflation"), with $\epsilon\_{1}<0.008$ at 95% CL.

Figure 20: Marginalized joint 68% and 95% CL for $(\epsilon\_{1}\thinspace,\epsilon\_{2})$
for Planck+WP data comparing the canonical Lagrangian case with $c\_{\mathrm{s}}=1$ to the
case of varying $c\_{\mathrm{s}}$ with a uniform prior $0.02<c\_{\mathrm{s}}<1$ derived from the Planck non-Gaussianity measurements.

The other two cases analysed correspond to specific models where the inflaton has a
non-standard kinetic term. The degeneracy between the different slow-roll parameters is broken
because these models specifically predict that $s=0$, or $s\propto\epsilon\_{2}$.
As an example, we first consider the case where the action takes the Dirac-Born-Infield (DBI) form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P(\phi,X)=-f(\phi)^{-1}\sqrt{1-2f(\phi)X}+f(\phi)^{-1}-V(\phi)\thinspace.$ |  | (60) |

Here $V(\phi)$ is the potential and $f(\phi)$ is the warp factor determined by the geometry of the
extra dimensions. For DBI models a stronger bound on $c\_{\mathrm{s}}$ is derived
([Planck Collaboration
XXIV, 2014](#bib.bib264)): $c\_{\mathrm{s}}>0.07$ at 95% CL. With the uniform prior $0.07<c\_{\mathrm{s}}<1$ and $s=0$, Planck + WP constrain $\epsilon\_{1}<0.042$ at 95% CL.

An important case is $f(\phi)\approx\lambda/\phi^{4}$ (for details, see [Silverstein & Tong (2004)](#bib.bib298),
[Alishahiha et al. (2004)](#bib.bib12), [Chen et al. (2007)](#bib.bib65), and references therein). There are two
possibilities. First, in ultraviolet (UV) DBI models, the inflaton field moves under a
quadratic potential $V(\phi)\approx m^{2}\phi^{2}/2$ from the UV side of the warped space to the
infrared side, with $m\gg M\_{\mathrm{pl}}/\sqrt{\lambda}$. It is known that this case is already
at odds with observations if theoretical internal consistency of the model and constraints on
power spectra and primordial non-Gaussianity are taken into account
([Baumann & McAllister, 2007](#bib.bib32); [Lidsey & Huston, 2007](#bib.bib173); [Bean et al., 2007](#bib.bib35); [Peiris et al., 2007](#bib.bib234); [Bean et al., 2008](#bib.bib33)).
It is therefore interesting to look at the other case, namely infrared DBI
models ([Chen 2005b](#bib.bib62); [Chen 2005a](#bib.bib61)) where the inflaton field moves from the
IR to the UV side, and the inflaton potential is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V(\phi)=V\_{0}-\frac{1}{2}\beta H^{2}\phi^{2}\thinspace,$ |  | (61) |

with a wide range of values allowed for $\beta$ in principle, $0.1<\beta<10^{9}$ ([Bean et al., 2008](#bib.bib33)). Here we focus on a minimal version of the IR DBI models where
string effects are neglected, so that the usual field theory computation of the primordial
curvature perturbation holds. For IR DBI models accounting for such effects and a more involved
treatment of the dynamics, see [Chen (2005a)](#bib.bib61), [Chen (2005c)](#bib.bib63), and [Bean et al. (2008)](#bib.bib33).
In this minimal IR DBI model, one finds ([Chen, 2005c](#bib.bib63); [Chen et al., 2007](#bib.bib65))
$c\_{\mathrm{s}}\approx(\beta N\_{\*}/3)^{-1}$, $n\_{\mathrm{s}}-1=-4/N\_{\*}$, and $dn\_{\mathrm{s}}/d\ln k=-4/N\_{\*}^{2}$
(in this model one can verify that $s\approx 1/N\_{\*}\approx\epsilon\_{2}/3$). Here primordial
non-Gaussianity of the equilateral type is generated with an amplitude
$f^{\mathrm{DBI}}\_{\mathrm{NL}}=-(35/108)\thinspace[(\beta^{2}\thinspace N\_{\*}^{2}/9)-1]$.

If we consider $60\leq N\_{\*}\leq 90$, then the predicted spectral index lies within the range $0.93\leq n\_{\mathrm{s}}\leq 0.96$, which is consistent with the Planck measurement of the
spectral index at the 3$\sigma$ level, for $N\_{\*}\geq 60$. The
constraints on non-Gaussianity give $f^{\mathrm{DBI}}\_{\mathrm{NL}}=11\pm 69$
at $68\%$ CL ([Planck Collaboration
XXIV, 2014](#bib.bib264)). Combining these constraints with
the power spectrum constraints, marginalizing over $60\leq N\_{\*}\leq 90$, we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\beta\leq 0.7\quad(95\%\penalty\ \mathrm{CL}).$ |  | (62) |

This strongly limits the allowed parameter space of these models.

As a final example, we consider a class of power-law $k$-inflation models characterized by the
Lagrangian ([Armendáriz-Picón et al., 1999](#bib.bib17))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P(\phi,X)=\frac{4}{9}\frac{4-3\gamma}{\gamma^{2}}\frac{1}{\phi^{2}}(-X+X^{2}).\thinspace$ |  | (63) |

In this case, for small values of
$\gamma$ one finds: $c\_{\mathrm{s}}^{2}\approx\gamma/8$, ${\mathcal{P}\_{R}}=2H^{2}/(3\gamma c\_{\mathrm{s}}8\pi^{2}M^{2}\_{\mathrm{pl}})(k/k\_{0})^{-3\gamma}$, $n\_{\mathrm{s}}-1=-3\gamma$. The
sound speed is a constant ($s=0$), with constant $\gamma$. The primordial non-Gaussianity in this
model has an amplitude $f^{\mathrm{equil}}\_{\mathrm{NL}}=-170/(81\gamma)$. Therefore, all the
inflationary observables depend essentially on a single parameter $\gamma$. Imposing a prior of $0<\gamma<2/3$ from the non-Gaussianity constraint $f^{\mathrm{equil}}\_{\mathrm{NL}}=-42\pm 75$ at $68\%$ CL
([Planck Collaboration
XXIV, 2014](#bib.bib264)), we obtain $\gamma\geq 0.05$ at $95\%$ CL. At the same time, our
measurement of the spectral index constrains $0.01\leq\gamma\leq 0.02$ at $95\%$ CL. This
class of $k$-inflation models is therefore excluded by the combined constraints on primordial
non-Gaussianity and the power spectrum.

## 10 Isocurvature modes

### 10.1 Theoretical background

In this section we explore the constraints
imposed by Planck on scenarios where the primordial cosmological
perturbations were not entirely adiabatic. These scenarios
also include isocurvature modes, possibly correlated
among themselves as well as with the adiabatic mode. The adiabatic
mode is characterized by the property that at very early
times the universe obeyed a common, spatially uniform equation
of state and all components initially shared a common velocity field.
For the adiabatic mode the density perturbations in the various
components (i.e., baryons, CDM, photons, and neutrinos) are locked
together. Here baryons include their accompanying leptons,
assumed tightly coupled to maintain charge neutrality.

Isocurvature modes arise from spatial variations in the equation of state
or from relative velocities between the components.
To analyse how the CMB perturbations were imprinted, it is most convenient to
define isocurvature modes at a sufficiently late time, such that the
relevant components, according to our present best understanding,
consisted of baryons, photons, CDM, and neutrinos. Under this hypothesis,
in addition to the adiabatic mode there are four possible non-decaying
isocurvature modes: the baryon, CDM, and neutrino density isocurvature modes,
and the neutrino velocity isocurvature mode (see, e.g., [Bucher et al. (2000)](#bib.bib55) for a discussion and further references).

The impact of isocurvature modes on the CMB was first studied in detail
by [Peebles & Yu (1970)](#bib.bib233) and [Efstathiou & Bond (1986)](#bib.bib89); [Efstathiou & Bond (1987)](#bib.bib90), who contemplated the
possibility that isocurvature perturbations rather than adiabatic
perturbations were the sole source of cosmological perturbations.
[Linde (1985)](#bib.bib180), [Polarski & Starobinsky (1994)](#bib.bib272), [Linde & Mukhanov (1997)](#bib.bib185),
and [García-Bellido & Wands (1996)](#bib.bib104) pointed out various scenarios in which isocurvature
perturbations could be generated within the context of inflation.
[Bucher et al. (2000)](#bib.bib55) carried out a systematic study of isocurvature modes
from a phenomenological perspective, pointing out the relevance of two
additional modes: the neutrino density and velocity modes.
[Lyth & Wands (2002)](#bib.bib197), [Moroi & Takahashi (2001)](#bib.bib210), and [Bartolo & Liddle (2002)](#bib.bib28) studied
an interesting so-called curvaton scenario, in which adiabatic fluctuations
from inflation contribute negligibly, but quantum fluctuations in a transverse
direction modulate the density of decaying particles, leading to isocurvature
perturbations correlated with the adiabatic mode.

Several authors have studied the constraints on isocurvature modes
imposed by previous microwave background experiments, including [Stompor et al. (1996)](#bib.bib315),
[Langlois & Riazuelo (2000)](#bib.bib162), [Amendola et al. (2002)](#bib.bib14), [Peiris et al. (2003)](#bib.bib239), [Valiviita & Muhonen (2003)](#bib.bib329),
[Bucher et al. (2004)](#bib.bib53), [Moodley et al. (2004)](#bib.bib209), [Beltran et al. (2004)](#bib.bib37), [Kurki-Suonio et al. (2005)](#bib.bib160),
[Dunkley et al. (2005)](#bib.bib80), [Bean et al. (2006)](#bib.bib34), [Trotta (2007)](#bib.bib322), [Keskitalo et al. (2007)](#bib.bib145),
and [Komatsu et al. (2009)](#bib.bib157). A more complete set of references may be found in [Valiviita et al. (2012)](#bib.bib330).

Before proceeding we must define precisely how to characterize
these isocurvature modes on super-Hubble scales during
the epoch after entropy generation, during which we assume that the stress-energy
content of the universe can be modelled as a multi-component fluid
composed of baryons, CDM particles, photons, and neutrinos.
If we assume that the evolution of the universe during this epoch
was adiabatic (used here in the sense of thermodynamically reversible), then
the entropy per unit comoving volume is conserved and serves as
a useful reference with respect to which the abundances of the other
components can be expressed.

The baryon isocurvature mode may be expressed in terms of fractional fluctuations in the baryon-to-entropy
ratio, which is conserved on super-Hubble scales during this epoch.
The CDM and neutrino density isocurvature (NDI) modes may be defined analogously.
The neutrino velocity isocurvature (NVI) mode refers to fluctuations in the neutrino velocity relative
to the average bulk velocity of the cosmic fluid.
For the CMB, the baryon and CDM isocurvature modes yield
almost identical angular spectra because the deficit of one is balanced by an excess of the other, so we do not consider them separately here.
In this way the primordial isocurvature modes may be defined
as dimensionless stochastic variables ${\mathcal{I}}\_{\mathrm{CDI}}$, ${\mathcal{I}}\_{\mathrm{NDI}}$,
${\mathcal{I}}\_{\mathrm{NVI}}$, like the variable ${\mathcal{R}}$ describing the adiabatic
mode.2121
21
The symbol ${\mathcal{S}}$ is sometimes used in the literature
to denote the isocurvature modes, also known as entropy perturbations.
To prevent confusion we avoid this terminology
because isocurvature modes are unrelated
to any notion of thermodynamic entropy.
In this basis, the CDI mode can be seen as an effective isocurvature mode, encoding both CDM and baryon isocurvature
fluctuations through
${\mathcal{I}}\_{{\mathrm{CDI}}}^{\mathrm{effective}}={\mathcal{I}}\_{{\mathrm{CDI}}}+(\Omega\_{\mathrm{b}}/\Omega\_{{\mathrm{c}}}){\mathcal{I}}\_{{\mathrm{BI}}}$ ([Gordon & Lewis, 2003](#bib.bib110)).

Within this framework, Gaussian fluctuations for the most general cosmological
perturbation are described by a $4\times 4$ positive definite matrix-valued power
spectrum of the form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\boldsymbol{\mathcal{P}}(k)=\begin{pmatrix}{\mathcal{P}}\_{{\mathcal{R}}\penalty\ \penalty\ \penalty\ {\mathcal{R}}}(k)&{\mathcal{P}}\_{{\mathcal{R}}\penalty\ \penalty\ \penalty\ {\mathcal{I}}\_{{\mathrm{CDI}}}}(k)&{\mathcal{P}}\_{{\mathcal{R}}\penalty\ \penalty\ \penalty\ {\mathcal{I}}\_{{\mathrm{NDI}}}}(k)&{\mathcal{P}}\_{{\mathcal{R}}\penalty\ \penalty\ \penalty\ {\mathcal{I}}\_{{\mathrm{NVI}}}}(k)\\ {\mathcal{P}}\_{{\mathcal{I}}\_{{\mathrm{CDI}}}{\mathcal{R}}}(k)&{\mathcal{P}}\_{{\mathcal{I}}\_{{\mathrm{CDI}}}{\mathcal{I}}\_{{\mathrm{CDI}}}}(k)&{\mathcal{P}}\_{{\mathcal{I}}\_{{\mathrm{CDI}}}{\mathcal{I}}\_{{\mathrm{NDI}}}}(k)&{\mathcal{P}}\_{{\mathcal{I}}\_{{\mathrm{CDI}}}{\mathcal{I}}\_{{\mathrm{NVI}}}}(k)\\ {\mathcal{P}}\_{{\mathcal{I}}\_{{\mathrm{NDI}}}{\mathcal{R}}}(k)&{\mathcal{P}}\_{{\mathcal{I}}\_{{\mathrm{NDI}}}{\mathcal{I}}\_{{\mathrm{CDI}}}}(k)&{\mathcal{P}}\_{{\mathcal{I}}\_{{\mathrm{NDI}}}{\mathcal{I}}\_{{\mathrm{NDI}}}}(k)&{\mathcal{P}}\_{{\mathcal{I}}\_{{\mathrm{NDI}}}{\mathcal{I}}\_{{\mathrm{NVI}}}}(k)\\ {\mathcal{P}}\_{{\mathcal{I}}\_{{\mathrm{NVI}}}{\mathcal{R}}}(k)&{\mathcal{P}}\_{{\mathcal{I}}\_{{\mathrm{NVI}}}{\mathcal{I}}\_{{\mathrm{CDI}}}}(k)&{\mathcal{P}}\_{{\mathcal{I}}\_{{\mathrm{NVI}}}{\mathcal{I}}\_{{\mathrm{NDI}}}}(k)&{\mathcal{P}}\_{{\mathcal{I}}\_{{\mathrm{NVI}}}{\mathcal{I}}\_{{\mathrm{NVI}}}}(k)\\ \end{pmatrix}.$ |  | (64) |

Following the conventions used in CAMB ([Lewis & Bridle, 2002](#bib.bib169); [Lewis, 2011](#bib.bib168))
and CLASS ([Lesgourgues, 2011](#bib.bib165); [Blas et al., 2011](#bib.bib46)),
the primordial isocurvature modes are normalized as follows in the synchronous gauge: for the CDI mode,
${\mathcal{P}}\_{{\mathcal{I}}{\mathcal{I}}}(k)$ is the primordial power spectrum of the density contrast
$\delta\rho\_{{\mathrm{CDM}}}/\rho\_{\mathrm{CDM}};$ for the NDI mode it is that of
$\delta\rho\_{\nu}/\rho\_{\nu};$ and for the NVI mode, that of the neutrino velocity $v\_{\nu}$
times 4/3.
2222
22
In other words, of the neutrino perturbation dipole, $F\_{\nu 1}=4\theta\_{v}/(3k)$
in the notation of [Ma & Bertschinger (1995)](#bib.bib198).

If isocurvature modes are present, the most plausible mechanism
for exciting them involves inflation with a multi-component
inflaton field. To have an interesting spectrum on the large scales
probed by the CMB, isocurvature modes require long-range
correlations. Inflation with a multi-component
inflaton provides a well motivated scenario for establishing
such correlations. Inflation with a single-component scalar field
can excite only the adiabatic mode. In models of inflation
with light (compared to the Hubble expansion rate)
transverse directions, the scalar field along these transverse
directions becomes disordered in a way described by an approximately
scale-invariant spectrum. If the inflaton has $M$ light components,
there are $(M-1)$ potential isocurvature modes during inflation.
Whether or not the fluctuations along these transverse directions are
subsequently transformed into the late-time isocurvature modes
described above depends on the details of what happens after inflation,
as described more formally below.

Figure 21: $C\_{TT}$ anisotropy shapes for the three isocurvature modes.
Top: The shapes of the CDM isocurvature mode, neutrino density isocurvature mode, and neutrino velocity isocurvature mode
are shown together with the adiabatic mode.
The modes have the same amplitude parameters ($\mathcal{P}\_{\mathcal{R}\mathcal{R}}$ for the adiabatic mode and $\mathcal{P}\_{\mathcal{I}\mathcal{I}}$ for each isocurvature mode).
Bottom: The narrower multipole range illustrates the relative phases of the acoustic oscillations for these modes.

As explained for example in [Langlois (1999)](#bib.bib161), [Gordon et al. (2001)](#bib.bib112), [Groot Nibbelink & van Tent (2000)](#bib.bib119); [Groot Nibbelink & van Tent (2002)](#bib.bib120), and [Byrnes & Wands (2006)](#bib.bib59), for inflationary models
where the inflaton follows a curved trajectory, correlations
are generically established between the isocurvature and
curvature degrees of freedom. To lowest order in the
slow-roll approximation, this leads to a situation where
the adiabatic perturbation is the sum of several components
each of differing spectral index.

The post-inflationary evolution determines
how the isocurvature fluctuations generated during inflation
transmute into the three specific isocurvature modes studied here.
Little is known about the details of what
happens during the epoch of entropy generation, but to linear
order we may express how the fields ${\mathcal{R}}\_{\mathrm{inf}}$ (i.e.,
the curvature perturbation at the end of inflation) and
the transverse components of the inflaton field
$\sigma\_{1},\ldots,\sigma\_{M-1}$ (i.e., the components
orthogonal to the slow-roll direction) transform
into curvature perturbations and late-time isocurvature modes
at the end of the epoch of entropy generation as the
linear transformation

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{pmatrix}{\mathcal{R}}\_{\mathrm{out}}\\ {\mathcal{I}}\_{a}\\ \end{pmatrix}=\begin{pmatrix}1&\Sigma\_{A}\\ \textbf{0}&M\_{aA}\\ \end{pmatrix}\begin{pmatrix}{\mathcal{R}}\_{\mathrm{inf}}\\ \sigma\_{A}\\ \end{pmatrix},$ |  | (65) |

where $a=$ BI, CDI, NDI, NVI, while $A=1,\ldots,(M-1)$
labels the transverse components of the $N$ component inflaton field.
Physically, the fluctuations along the transverse directions modulate particle production
during the epoch of entropy generation.

The neutrino density isocurvature can be excited in much the same way
as the CDM and baryon isocurvature mode because at least within
the standard electroweak model, in which there are no leptonic
flavour changing processes, $L\_{e},$ $L\_{\mu},$ and $L\_{\tau}$ are
separately conserved. Known non-perturbative processes such as
the sphaleron can trade lepton and baryon asymmetries with
each other and alter flavour asymmetries, but they cannot erase
such asymmetries altogether. Plausible models
generating the neutrino density mode are therefore possible ([Bucher et al., 2000](#bib.bib55); [Gordon & Malik, 2004](#bib.bib111)), but
as for the neutrino velocity isocurvature mode, to date
no plausible generation mechanism has been put forth.

This extension of the adiabatic $\Lambda$CDM
model to non-adiabatic initial conditions represents an important test of inflation.
Single-field inflation can produce only adiabatic perturbations,
since exciting isocurvature perturbations
requires additional degrees of freedom during inflation.
Therefore a detection of primordial isocurvature perturbations
would point to more complicated models of inflation.

### 10.2 Adiabatic with one isocurvature mode and free spectral indices

In this paper we investigate three of the four possible isocurvature
modes of the $\Lambda$CDM scenario, since the baryon and CDM
isocurvature perturbations are indistinguishable in the CMB angular
power spectra. The CDM, neutrino density, and neutrino velocity isocurvature
perturbations lead to different power spectra for CMB anisotropies, as
shown in Fig. [21](#S10.F21 "Figure 21 ‣ 10.1 Theoretical background ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation"). We limit ourselves
to studying one isocurvature mode at a time, in the presence of a
curvature perturbation. More general combinations with
two or three isocurvature modes may be contemplated, but without
the Planck high frequency polarization likelihood, it is difficult
to constrain such scenarios, so we postpone a discussion of this case
to the next release.

Theoretically, one expects the power spectra of
the isocurvature modes and their correlations to exhibit
near but not necessarily exact scale invariance.
As a general test of adiabaticity, it is nevertheless interesting to compare a more general
model to the Planck data, assuming that the adiabatic, isocurvature,
and cross-correlation spectra obey power laws with
free spectral indices. Blue values of the spectral indices are
particularly interesting from the point of view of testing
adiabaticity, because the acoustic peaks arising
from two of the isocurvature modes are out
of phase with the adiabatic peaks by roughly $\pi/2$
near the first acoustic peak. This is not true for the neutrino velocity isocurvature mode however.

In the literature,
models with one isocurvature as well as the adiabatic mode (possibly correlated)
are often parameterized by specifying the $2\times 2$ correlation matrix at a certain
pivot scale $k\_{0}$ wth components
${\mathcal{P}}\_{\mathcal{R}\mathcal{R}},$
${\mathcal{P}}\_{\mathcal{R}\mathcal{I}},$
${\mathcal{P}}\_{\mathcal{I}\mathcal{I}}$
along with their respective spectral indices
$n\_{\mathcal{R}\mathcal{R}},$
$n\_{\mathcal{R}\mathcal{I}},$
$n\_{\mathcal{I}\mathcal{I}}$
([Amendola et al., 2002](#bib.bib14); [Beltran et al., 2004](#bib.bib37), e.g.,).
We do not follow this approach because in the absence
of a statistically significant detection, the posterior
distributions for the spectral indices are difficult
to interpret and sensitive to how the prior is chosen.
We instead adopt a parameterization where
${\mathcal{P}}\_{\mathrm{ab}}$ is specified at two scales $k=k\_{1}$ and $k=k\_{2}$
and interpolated geometrically according to2323
23
Although the
models spanned by the one-scale and two-scale parameterizations
are the same, the priors for these parameterizations are related
by a non-constant Jacobian and therefore do not coincide.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\begin{split}{\mathcal{P}}\_{\mathrm{ab}}(k)=&\exp\Biggl[\left(\frac{\ln(k)-\ln(k\_{2})}{\ln(k\_{1})-\ln(k\_{2})}\right)\ln({\mathcal{P}}^{(1)}\_{\mathrm{ab}})\\ &\qquad+\left(\frac{\ln(k)-\ln(k\_{1})}{\ln(k\_{2})-\ln(k\_{1})}\right)\ln({\mathcal{P}}^{(2)}\_{\mathrm{ab}})\Biggr],\end{split}$ | |  | (66) |

where ${\mathrm{a,b}}={\mathcal{I}},{\mathcal{R}}$ and
${\mathcal{I}}={\mathcal{I}}\_{{\mathrm{CDI}}}$, ${\mathcal{I}}\_{{\mathrm{NDI}}},$ or ${\mathcal{I}}\_{{\mathrm{NVI}}}$.
We set $k\_{1}=2\times 10^{-3}\textrm{ Mpc}^{-1}$
and $k\_{2}=0.1\textrm{ Mpc}^{-1},$ so that
$[k\_{1},k\_{2}]$ spans most of the range in $k$ constrained by Planck data.
A uniform prior for the components
$\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(1)},$
$\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)},$
$\mathcal{P}\_{\mathcal{R}\mathcal{I}}^{(1)},$
$\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(2)},$
$\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(2)},$
$\mathcal{P}\_{\mathcal{R}\mathcal{I}}^{(2)}$ is assumed, where
auto-correlation amplitudes
$\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(1)},$
$\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)},$
$\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(2)},$
$\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(2)}$
are positive, although the cross-correlation amplitudes
$\mathcal{P}\_{\mathcal{R}\mathcal{I}}^{(1)},$
$\mathcal{P}\_{\mathcal{R}\mathcal{I}}^{(2)}$
may take both signs subject to the constraints

|  |  |  |  |
| --- | --- | --- | --- |
|  | $(\mathcal{P}\_{\mathcal{R}\mathcal{I}}^{(1)})^{2}<\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(1)}\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(1)},\quad(\mathcal{P}\_{\mathcal{R}\mathcal{I}}^{(2)})^{2}<\mathcal{P}\_{\mathcal{R}\mathcal{R}}^{(2)}\mathcal{P}\_{\mathcal{I}\mathcal{I}}^{(2)}$ |  | (67) |

to ensure positive definiteness. For the logarithm of the
off-diagonal elements in Eq. [66](#S10.E66 "In 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation") to be real, we must have
${\mathcal{P}}\_{\mathcal{R}\mathcal{I}}^{(1)},{\mathcal{P}}\_{\mathcal{R}\mathcal{I}}^{(2)}>0$. This Ansatz can be trivially modified to admit the case
${\mathcal{P}}\_{\mathcal{R}\mathcal{I}}^{(1)},{\mathcal{P}}\_{\mathcal{R}\mathcal{I}}^{(2)}<0$ by
inserting appropriate minus signs, but this parameterization does not
allow the case where the sign of the correlation changes. In practice
we deal with this by assuming a uniform prior not on ${\mathcal{P}}\_{\mathcal{R}I}^{(2)}$, but on its absolute value, and then we impose ${\mathcal{P}}\_{\mathcal{R}I}^{(2)}=\mathrm{sign}({\mathcal{P}}\_{\mathcal{R}I}^{(1)})\times|{\mathcal{P}}\_{\mathcal{R}I}^{(2)}|$. The constraints in
Eq. [67](#S10.E67 "In 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation") ensure that
$\det\left({\mathcal{P}}\_{\mathrm{ab}}(k)\right)$
is positive definite within the interval
$[k\_{1},k\_{2}],$ but generically positive definiteness is violated
sufficiently far outside this interval, either for very small or very
large $k.$ Where this happens we reduce the magnitude of
${\mathcal{P}}\_{\mathcal{R}\mathcal{I}}$ so that there is either total correlation or
anti-correlation. The kinks thus introduced lie
outside the range $[k\_{1},k\_{2}].$ Within
this range, the
spectral indices
$n\_{\mathcal{R}\mathcal{R}},$
$n\_{\mathcal{R}\mathcal{I}},$
$n\_{\mathcal{I}\mathcal{I}}$
are scale-independent.
Finally, our
sign conventions are such that positive values for ${\mathcal{P}}\_{\mathcal{R}I}^{(1,2)}$ correspond to a positive contribution of the
cross-correlation term to the Sachs-Wolfe component of the total temperature spectrum.

When the constraining power of the data is weak, a crucial question
is to what extent the posterior distribution results from the data
rather than from the prior distribution.
The parameterization above is not the only
one that could have been adopted, and other
possible priors are typically
related by a non-constant Jacobian.
For each model, we indicate the log-likelihood for the best fit model, in order
to allow model comparison.

The Planck+WP results for the three isocurvature modes
using this two-scale parameterization
are shown in Fig. [22](#S10.F22 "Figure 22 ‣ 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation")
and included in the summary Table [12](#S10.T12 "Table 12 ‣ 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation").
The power spectra ${\mathcal{P}}\_{\mathcal{RR}}(k),$ ${\mathcal{P}}\_{\mathcal{RI}}(k),$
and ${\mathcal{P}}\_{\mathcal{II}}(k)$ are normalized according
to the primordial values of the fields
${\mathcal{R}}({\textbf{x}})$ and ${\mathcal{I}}({\textbf{x}})$
defined above. It is
interesting to consider how much isocurvature power is allowed
expressed as a fraction of the power in three bands
spanning the CMB temperature spectrum observed by Planck. To this end,
we define the following derived quantities

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\alpha\_{\mathcal{RR}}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})=$ | $\displaystyle\frac{(\Delta T)^{2}\_{\mathcal{RR}}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})}{(\Delta T)^{2}\_{\mathrm{tot}}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})},$ |  | (68) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\alpha\_{\mathcal{II}}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})=$ | $\displaystyle\frac{(\Delta T)^{2}\_{\mathcal{II}}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})}{(\Delta T)^{2}\_{\mathrm{tot}}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})},$ |  | (69) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\alpha\_{\mathcal{RI}}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})=$ | $\displaystyle\frac{(\Delta T)^{2}\_{\mathcal{RI}}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})}{(\Delta T)^{2}\_{\mathrm{tot}}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})},$ |  | (70) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${(\Delta T)^{2}\_{X}(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})}=\sum\_{\ell=\ell\_{\mathrm{min}}}^{\ell\_{\mathrm{max}}}(2\ell+1)C\_{X,\ell}^{TT}.$ |  | (71) |

The 95% confidence limits from the one-dimensional posterior
distributions for these fractional contributions in the full range
$(\ell\_{\mathrm{min}},\ell\_{\mathrm{max}})=(2,2500)$ are shown in
Table [12](#S10.T12 "Table 12 ‣ 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation"). The
range of allowed values for $\alpha\_{\mathcal{RR}}(2,2500)$ is a measure
of the adiabaticity of fluctuations in the CMB.
The posterior distributions of the fractions $\alpha\_{\mathcal{II}},$ $\alpha\_{\mathcal{RI}}$ in three
multipole ranges are shown in Fig. [23](#S10.F23 "Figure 23 ‣ 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation").
We also report the primordial isocurvature fraction, defined as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\beta\_{\mathrm{iso}}(k)=\frac{\mathcal{P}\_{\mathcal{II}}(k)}{\mathcal{P}\_{\mathcal{RR}}(k)+\mathcal{P}\_{\mathcal{II}}(k)}$ |  | (72) |

at three values of $k$.
Table [12](#S10.T12 "Table 12 ‣ 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation")
also shows the effective $\chi^{2}=-2\ln{\mathcal{L}}\_{\mathrm{max}}$ for all models, compared to
the minimal six-parameter $\Lambda$CDM model.
In Fig. [24](#S10.F24 "Figure 24 ‣ 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation") we show the ratio of temperature spectra for the best fit mixed model to the adiabatic model.

Figure 22: 
Two dimensional distributions for power in isocurvature modes using Planck+WP data.

Figure 23: 
Fractional contribution of isocurvature modes to the power spectrum. We show the distributions
$\alpha\_{\mathcal{II}}(2,20)$, $\alpha\_{\mathcal{RI}}(2,20)$,
$\alpha\_{\mathcal{II}}(21,200)$, $\alpha\_{\mathcal{RI}}(21,200)$,
$\alpha\_{\mathcal{II}}(201,2500)$, and $\alpha\_{\mathcal{RI}}(201,2500),$
defined in Eq. [70](#S10.E70 "In 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation"), for the CDI, NDI, and NVI modes as constrained by the
Planck+WP data.

Figure 24: 
Temperature spectrum of best fit models with a mixture of adiabatic and isocurvature modes.
Top: Spectrum of the best fit mixed models relative to that of the pure adiabatic model. Bottom:
Zoom of the Sachs-Wolfe plateau of the best fit temperature spectrum $D\_{\ell}=[\ell(\ell+1)/2\pi]C\_{\ell}^{TT}$ for
each of the three cases plus the pure adiabatic model, shown together with Planck low-$\ell$ data points.

| Model | $\beta\_{\mathrm{iso}}(k\_{\mathrm{low}})$ | $\beta\_{\mathrm{iso}}(k\_{\mathrm{mid}})$ | $\beta\_{\mathrm{iso}}(k\_{\mathrm{high}})$ | $\alpha\_{\mathcal{R}\mathcal{R}}^{(2,2500)}$ | $\alpha\_{\mathcal{I}\mathcal{I}}^{(2,2500)}$ | $\alpha\_{\mathcal{R}\mathcal{I}}^{(2,2500)}$ | $\Delta n$ | $-2\Delta\ln\mathcal{L}\_{\mathrm{max}}$ |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| General model: |  |  |  |  |  |  |  |  |
| CDM isocurvature | 0.075 | 0.39 | 0.60 | [0.98:1.07] | 0.039 | [-0.093:0.014] | 4 | -4.6 |
| ND isocurvature | 0.27 | 0.27 | 0.32 | [0.99:1.09] | 0.093 | [-0.18:0] | 4 | -4.2 |
| NV isocurvature | 0.18 | 0.14 | 0.17 | [0.96:1.05] | 0.068 | [-0.090:0.026] | 4 | -2.5 |
| Special CDM isocurvature cases: |  |  |  |  |  |  |  |  |
| Uncorrelated, $n\_{\mathcal{II}}=1$ (“axion”) | 0.036 | 0.039 | 0.040 | [0.98:1] | 0.016 | – | 1 | 0 |
| Fully correlated, $n\_{\mathcal{II}}=n\_{\mathcal{RR}}$ (“curvaton”) | 0.0025 | 0.0025 | 0.0025 | [0.97:1] | 0.0011 | [0:0.028] | 1 | 0 |
| Fully anti-correlated, $n\_{\mathcal{II}}=n\_{\mathcal{RR}}$ | 0.0087 | 0.0087 | 0.0087 | [1:1.06] | 0.0046 | [-0.067:0] | 1 | -1.3 |

Table 12:  Isocurvature mode constraints
from Planck+WP data. For each model,
we report the 95% CL upper bound on the fractional primordial contribution of
isocurvature modes at three comoving wavenumbers ($k\_{\mathrm{low}}=0.002\penalty\$Mpc-1,
$k\_{\mathrm{mid}}=0.05\penalty\$Mpc${}^{-1},$ and $k\_{\mathrm{high}}=0.10\penalty\$Mpc-1),
and the 95% CL bounds on the fractional contribution
$\alpha\_{\mathcal{RR}},$
$\alpha\_{\mathcal{II}},$
and $\alpha\_{\mathcal{RI}}$ to the total CMB temperature anisotropy in the range
$2\leq\ell\leq 2500$. We also report $-2\Delta\ln\mathcal{L}\_{\mathrm{max}}$ for the
best fitting model in each case, relative to the best fit 6-parameter $\Lambda$CDM model,
with the number of additional parameters $\Delta n$. In the Gaussian approximation,
$-2\Delta\ln\mathcal{L}\_{\mathrm{max}}$ corresponds to $\Delta\chi^{2}$.
The general models have six parameters that specify the primordial correlation matrix at
two scales $k\_{1}$ and $k\_{2}$, thus allowing all spectral indices to vary (so, four parameters more than the pure adiabatic model).

The results for $\alpha\_{\mathcal{RR}}(2,2500)$ show that the
nonadiabatic contribution to the temperature variance can
be as large as 7% (9%, 5%) in the CDI (NDI, NVI) model (at 95% CL).
These results are driven by the fact that on large scales, for $\ell\leq 40$, the Planck data points on average have a slightly smaller
amplitude than the best fitting $\Lambda$CDM model. Hence the data prefer a
significant amount of anticorrelated isocurvature modes, leading to a
reduction of amplitude of the Sachs-Wolfe plateau and to a decrease of the effective
$\chi^{2}$ by up to 4.6.2424
24
For the three general models, the posterior
distribution is actually multimodal. Here we are referring to models contributing to
the main peak in the posterior, with the highest maximum likelihood. There is another peak
with a smaller maximum likelihood, appearing in Fig. [23](#S10.F23 "Figure 23 ‣ 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation")
as a small bump for positive values of the cross-correlation amplitude. In this paper,
we do not carry out a separate investigation for models contributing to
this secondary peak. This situation explains the rather loose bounds
on the derived parameter $\alpha\_{\mathcal{II}}(2,20)$, as shown in
Fig. [23](#S10.F23 "Figure 23 ‣ 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation").

A comparison of $\mathcal{P}\_{\mathcal{II}}^{(1)}$ and $\mathcal{P}\_{\mathcal{II}}^{(2)}$
shows that best fitting models have an isocurvature spectral index $n\_{\mathcal{II}}$
close to 1.7 for CDI, 1.1 for NDI, and 1.0 for NVI modes.

For CDI and NDI, the amplitude of acoustic peaks quickly decreases
with increasing $\ell$, so that the constraints are entirely driven by
small $\ell$s. Since the same value of the primordial amplitude
$\mathcal{P}\_{\mathcal{II}}^{(1)}$ leads to different plateau amplitudes for the
two isocurvature models (see Fig. [21](#S10.F21 "Figure 21 ‣ 10.1 Theoretical background ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation")), the bounds
on $\mathcal{P}\_{\mathcal{II}}^{(1)}$ and $\mathcal{P}\_{\mathcal{RI}}^{(1)}$ are consistently
stronger for CDI than for NDI. For NVI, the acoustic peak amplitude is
larger than the plateau amplitude. In NVI models, the data cannot
allow for a too large amplitude of correlated isocurvature modes
at small $\ell$, because the total spectrum would be distorted at
larger $\ell$. This possibility is strongly disfavoured by the data,
which are consistent with the peak location predicted by a pure
adiabatic model. Hence in the NVI case we obtain slightly stronger bounds and a smaller reduction of the effective $\chi^{2}$.

The fact that the data prefer models with a significant contribution
from CDI or NDI modes should be interpreted with care. The detection
of a shift in the phase of acoustic oscillations would bring
unambigous evidence in favour of isocurvature modes. With
Planck data, we are not in this situation. The evidence is driven by
a small deficit of amplitude in the Sachs-Wolfe plateau, which could
have several different possible explanations (such as a deficit in the
large-scale primordial power spectrum, as already seen in the previous
sections).
However, multi-field inflationary scenarios can produce the mixture of
curvature and isocurvature fluctuations which
we have found to provide a good fit to the Planck data.

### 10.3 Special cases

The six-parameter models of the previous subsection including
one isocurvature mode and the adiabatic mode make no
assumptions about the spectral indices of each mode or
the degree of correlation between the isocurvature mode and the
adiabatic mode. This leads to a large number of additional degrees
of freedom. There are both theoretical and phenomenological motivations
for choosing special values for some of the parameters,
leading to special cases with just one more degree of freedom with
respect to the adiabatic case.
The results are reported in Table [12](#S10.T12 "Table 12 ‣ 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation"),
for uncorrelated perturbations with $n\_{\mathcal{II}}=1$, and
fully correlated or anti-correlated perturbations with $n\_{\mathcal{II}}=n\_{\mathcal{RR}}$.
In the general case, anti-correlated
isocurvature perturbations slightly improve the fit to the Planck data.
We consider below the implications of our results for two
important cases: the axion and curvaton scenarios.

#### 10.3.1 Constraints on axion isocurvature

The axion field was proposed to solve the strong CP problem and
constitutes a well-motivated dark matter candidate.
(See for example [Preskill et al. (1983)](#bib.bib275), [Turner (1990)](#bib.bib326),
[Peccei (2008)](#bib.bib232), [Sikivie (2008)](#bib.bib297), [Raffelt (2008)](#bib.bib276), and [Kim & Carosi (2010)](#bib.bib146)).
The axion is the psuedo-Goldstone boson of the broken Peccei-Quinn (PQ) symmetry. Under certain
assumptions, the axion field may induce
significant isocurvature perturbations ([Turner et al., 1983](#bib.bib328); [Axenides et al., 1983](#bib.bib20); [Steinhardt & Turner, 1983](#bib.bib313); [Linde, 1984](#bib.bib179); [Linde, 1985](#bib.bib180); [Seckel & Turner, 1985](#bib.bib292); [Kofman, 1986](#bib.bib154); [Lyth, 1990](#bib.bib191); [Linde & Lyth, 1990](#bib.bib184); [Turner & Wilczek, 1991](#bib.bib327); [Linde, 1991](#bib.bib182); [Lyth, 1992](#bib.bib190)).
If inflation takes place after PQ symmetry breaking, the quantum fluctuations of the inflaton are responsible for primordial
curvature perturbations, while those of the axion field generate primordial entropy
perturbations. After the QCD transition, when one of the vacua
becomes preferred giving the axion field a mass, the axions
behave as cold dark matter. This way of producing axionic dark matter is called the misalignment angle mechanism.
In such a scenario, the CMB anisotropy may include significant power from
CDM isocurvature fluctuations. In that case, the fraction
$\beta\_{\mathrm{iso}}\equiv\mathcal{P\_{II}}/(\mathcal{P\_{RR}}+\mathcal{P\_{II}})$
of CDM isocurvature modes is related to the energy scale of inflation, $H\_{\mathrm{inf}}$,
through ([Lyth, 1990](#bib.bib191); [Beltran et al., 2007](#bib.bib36); [Bae et al., 2008](#bib.bib22); [Hamann et al., 2009](#bib.bib125))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $H\_{\mathrm{inf}}=\frac{0.96\times 10^{7}\penalty\ \mathrm{GeV}}{R\_{\mathrm{a}}}\left(\frac{\beta\_{\mathrm{iso}}}{0.04}\right)^{1/2}\left(\frac{\Omega\_{\mathrm{a}}}{0.120}\right)^{1/2}\left(\frac{f\_{\mathrm{a}}}{10^{11}\penalty\ \mathrm{GeV}}\right)^{0.408},$ |  | (73) |

where $\Omega\_{\mathrm{a}}$ is the relic axion density, $R\_{\mathrm{a}}$ the fraction of CDM consisting
of axions, and $f\_{\mathrm{a}}$ the PQ symmetry breaking scale.
In this model, CDM isocurvature perturbations should be totally uncorrelated
with adiabatic perturbations and have a spectral index $n\_{\mathcal{II}}$ very close to one
since in the first-order slow-roll approximation the index reads $(1-2\epsilon\_{V})$.
Since the sensitivity of the data to $n\_{\mathcal{II}}$ is very limited ([Beltran et al., 2007](#bib.bib36)), we assume for simplicity that $n\_{\mathcal{II}}=1$.

Within the general parametrization presented in Eq. [66](#S10.E66 "In 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation"),
we can select the axion case by imposing $\mathcal{P}\_{\mathcal{RI}}^{(1,2)}=0$, as well as the condition

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}\_{\mathcal{II}}^{(2)}=\mathcal{P}\_{\mathcal{II}}^{(1)},$ |  | (74) |

corresponding to $n\_{\mathcal{II}}=1$. We therefore have
three independent parameters,
$\mathcal{P}\_{\mathcal{RR}}^{(1)},$
$\mathcal{P}\_{\mathcal{RR}}^{(2)},$ and
$\mathcal{P}\_{\mathcal{II}}^{(1)}$, and we sample these parameters with uniform prior distributions. The fraction $\beta\_{\mathrm{iso}}(k\_{\*})$ with $k\_{\*}=0.05$ Mpc-1
is then a derived parameter. Since the data constrain $\beta\_{\mathrm{iso}}\ll 1$,
the relation between $\beta\_{\mathrm{iso}}$ and $\mathcal{P}\_{\mathcal{II}}^{(1)}$ is nearly linear,
so the primordial isocurvature fraction is sampled with a close to uniform prior.

Constraints on this model are shown in Table [12](#S10.T12 "Table 12 ‣ 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation"). We find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\beta\_{\mathrm{iso}}<0.039\quad(95\%\penalty\ \mathrm{CL},\mathit{Planck}\mathrm{+WP}),$ |  | (75) |

at the scale $k\_{\mathrm{mid}}=0.05\thinspace\mathrm{Mpc}^{-1}$,
with a best fit value of zero. Hence there is no evidence for axion generated
isocurvature perturbations. This limit significantly improves the previous CMB bounds.
At the scale $k=0.002$ Mpc-1, our result reads $\beta\_{\mathrm{iso}}<0.036$, to be compared to
$\beta\_{\mathrm{iso}}<0.15$ for WMAP 9-year alone, or $\beta\_{\mathrm{iso}}<0.061$ for WMAP+ACT+SPT at
95% CL ([Hinshaw et al., 2013](#bib.bib136)). This bound can be used to exclude
regions of parameter space composed of $f\_{\mathrm{a}}$, $R\_{\mathrm{a}}$, and the energy scale
of inflation, but cannot be used to obtain a
model-independent bound on $f\_{\mathrm{a}}$. However, if we assume (i) that the PQ symmetry is
broken during inflation,
(ii) that it is not restored by the quantum fluctuations of the inflaton
(which imposes $H\_{\mathrm{inf}}/(2\pi)<f\_{\mathrm{a}}$), nor by thermal fluctuations
in case of a very efficient reheating stage, and (iii) that all the CDM
consists of axions produced by the misalignment angle, then we can derive an
upper bound on the energy scale of inflation as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $H\_{\mathrm{inf}}\leq 0.87\times 10^{7}\penalty\ \mathrm{GeV}\left(\frac{f\_{\mathrm{a}}}{10^{11}\penalty\ \mathrm{GeV}}\right)^{0.408}\thinspace(95\%\penalty\ \mathrm{CL})\penalty\ .$ |  | (76) |

#### 10.3.2 Constraints on the curvaton scenario

In the simplest one-field inflationary models curvature
perturbations arise from quantum fluctuations in the inflaton field,
but this is not the only way to generate curvature perturbations.
Isocurvature perturbations may seed curvature perturbations outside the Hubble
radius ([Polarski & Starobinsky, 1994](#bib.bib272); [Langlois, 1999](#bib.bib161); [Gordon et al., 2001](#bib.bib112)), so it is possible that
a significant component of the observed adiabatic mode could be
strongly correlated with an isocurvature mode. This happens for
instance in the curvaton
scenario ([Mollerach, 1990](#bib.bib208); [Enqvist & Sloth, 2002](#bib.bib92); [Moroi & Takahashi, 2001](#bib.bib210); [Lyth & Wands, 2002](#bib.bib197); [Lyth et al., 2003](#bib.bib196); [Gordon & Lewis, 2003](#bib.bib110)).
The curvaton is an extra light scalar field acquiring a spectrum of
fluctuations on cosmological scales during inflation. Depending on its
density evolution and decay history, this field could be responsible
for part of the observed adiabatic perturbations, or all of them, or
for a mixture of correlated adiabatic and isocurvature perturbations.

We focus here on the simplest viable version of this scenario
in which the curvaton decays into CDM particles while contributing a non-negligible fraction

|  |  |  |  |
| --- | --- | --- | --- |
|  | $r\_{D}=\frac{3\rho\_{\mathrm{curvaton}}}{3\rho\_{\mathrm{curvaton}}+4\rho\_{\mathrm{radiation}}}$ |  | (77) |

to the total energy density of the universe. If the curvaton dominates at decay time
($r\_{D}=1$), its primordial fluctuations seed curvature perturbations equivalent to a pure
adiabatic mode. If $r\_{D}<1$, curvaton fluctuations are only partially converted into adiabatic
perturbations, while CDM particles carry CDI perturbations, which are fully correlated with the
adiabatic perturbations since they share a common origin. We recall that with our conventions,
“fully correlated” means that the cross-correlation term contributes constructively
to the Sachs-Wolfe component of the total temperature spectrum. Some authors define the
correlation with the opposite sign and call this case “fully anti-correlated”
([Komatsu et al., 2011](#bib.bib158); [Hinshaw et al., 2013](#bib.bib136), e.g.,). In this model, the CDI fraction is related to $r\_{D}$ by ([Gordon & Lewis, 2003](#bib.bib110))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{{\mathcal{I}}\_{\mathrm{CDI}}}{\mathcal{R}}=\frac{3(1-r\_{D})}{r\_{D}}.$ |  | (78) |

In our notation this is equivalent to

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\beta\_{\mathrm{iso}}=\frac{9(1-r\_{D})^{2}}{r\_{D}^{2}+9(1-r\_{D})^{2}}.$ |  | (79) |

Within the general parametrization presented in
Eq. [66](#S10.E66 "In 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation"), we can satisfy this case by imposing

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{\mathcal{P}\_{\mathcal{RI}}^{(1)}}{\sqrt{\mathcal{P}\_{\mathcal{RR}}^{(1)}\mathcal{P}\_{\mathcal{II}}^{(1)}}}=\frac{\mathcal{P}\_{\mathcal{RI}}^{(2)}}{\sqrt{\mathcal{P}\_{\mathcal{RR}}^{(2)}\mathcal{P}\_{\mathcal{II}}^{(2)}}}=1,$ |  | (80) |

together with the condition

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{P}\_{\mathcal{II}}^{(2)}=\frac{\mathcal{P}\_{\mathcal{II}}^{(1)}\mathcal{P}\_{\mathcal{RR}}^{(2)}}{\mathcal{P}\_{\mathcal{RR}}^{(1)}},$ |  | (81) |

corresponding to $n\_{\mathcal{II}}=n\_{\mathcal{RR}}$.
As in the axion case, this results in three independent parameters
$\mathcal{P}\_{\mathcal{RR}}^{(1,2)}$ and $\mathcal{P}\_{\mathcal{II}}^{(1)},$ which we sample with uniform priors.
The constraints for this model are shown in Table [12](#S10.T12 "Table 12 ‣ 10.2 Adiabatic with one isocurvature mode and free spectral indices ‣ 10 Isocurvature modes ‣ Planck 2013 results. XXII. Constraints on inflation").
The best fit model is still the pure adiabatic case, and the upper bound

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\beta\_{\mathrm{iso}}<0.0025\quad(95\%\penalty\ \mathrm{CL},\mathit{Planck}\mathrm{+WP})$ |  | (82) |

is scale independent, since the adiabatic and
isocurvature tilts are assumed to be equal.
This is a significant improvement over the WMAP
9-year bounds, $\beta\_{\mathrm{iso}}<0.012$ for WMAP alone,
or $\beta\_{\mathrm{iso}}<0.0076$ for WMAP+ACT+SPT at 95% CL ([Hinshaw et al., 2013](#bib.bib136)).
We conclude that in this scenario, the curvaton should decay when it dominates the energy density of the universe, with $r\_{D}>0.983$.

The nonlinearity parameter in the curvaton model studied here is
([Bartolo et al., 2004c](#bib.bib30); [Bartolo et al., 2004b](#bib.bib29))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\_{\mathrm{NL}}^{\mathrm{local}}=\frac{5}{4r\_{D}}-\frac{5}{3}-\frac{5r\_{D}}{6},$ |  | (83) |

assuming a quadratic potential for the curvaton field ([Sasaki et al., 2006](#bib.bib287)). In
the pure adiabatic case ($r\_{D}=1$) this leads to $f\_{\mathrm{NL}}^{\mathrm{local}}=-5/4$.
The constraint $0.98<r\_{D}<1$ then corresponds to $-1.25<f\_{\mathrm{NL}}^{\mathrm{local}}<-1.21$. Taking into account the Planck result $f\_{\mathrm{NL}}^{\mathrm{local}}=2.7\pm 5.8$ ([Planck Collaboration
XXIV, 2014](#bib.bib264)), we conclude
that the Planck data are consistent with the scenario where the
curvaton decays into CDM when it dominates the energy density of the
universe, and its fluctuations are almost entirely converted into adiabatic
ones.

## 11 Conclusions

This paper establishes the status of cosmic inflation in the context of the
first release of the Planck cosmological results,
which includes the temperature data from the first $2.6$ sky surveys.
CMB polarization as measured by Planck will be the subject of a future release.
We find that standard slow-roll single-field inflation is compatible with the Planck data.
This result is confirmed by other papers of this series.
Planck in combination with WMAP 9-year
large angular scale polarization (WP) yields $\Omega\_{K}=-0.006\pm 0.018$ at 95% CL by combining temperature and
lensing information ([Planck Collaboration
XVI, 2014](#bib.bib256); [Planck Collaboration
XVII, 2014](#bib.bib257)).
The bispectral non-Gaussianity parameter $f\_{\mathrm{NL}}$ measured by Planck is consistent with zero ([Planck Collaboration
XXIV, 2014](#bib.bib264)).
These results are compatible with zero spatial curvature and a small value of $f\_{\mathrm{NL}},$
as predicted in the simplest slow-roll inflationary models.

A key Planck result is the measurement of the scalar perturbation spectral index.
Planck+WP data give $n\_{\mathrm{s}}=0.9603\pm 0.0073$ (and $n\_{\mathrm{s}}=0.9629\pm 0.0057$
when combined with BAO).
This result disfavours the Harrison-Zeldovich (HZ) $n\_{\mathrm{s}}=1$ model at more than 5$\sigma$.
Even in extended cosmological models, the HZ spectrum cannot be reconciled with the data.
Allowing a general reionization scenario yields $\Delta\chi\_{\mathrm{eff}}^{2}=12.5$ with respect to
$\Lambda$CDM for Planck+WP data.
When the primordial helium abundance or the effective number of
neutrino species are allowed to vary, the best fit of the HZ model to a combination of Planck+WP and BAO data
is still worse by $\Delta\chi\_{\mathrm{eff}}^{2}=4.6$ and $8.0$, respectively.

We find no evidence for Planck data preferring a generalization of a simple power law spectrum to include
a running of the spectral index ($\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k=-0.0134\pm 0.0090$)
or a running of the running
($\mathrm{d}^{2}n\_{\mathrm{s}}/\mathrm{d}\ln k^{2}=0.020^{+0.016}\_{+0.015}$ with Planck+WP).
In a model admitting tensor fluctuations,
the $95\%$ CL bound on the tensor-to-scalar ratio is
$r\_{0.002}<0.12$ ($<0.11$) using Planck+WP (plus high-$\ell$
CMB data). This bound on $r$ implies an upper limit for the inflation
energy scale of $1.9\times 10^{16}\penalty\$GeV, or equivalently, for the Hubble parameter $H\_{\*}<3.7\times 10^{-5}\penalty\ M\_{\mathrm{pl}}$, at $95\%$ CL.

The degeneracy between $n\_{\mathrm{s}}$ and $r,$ which plagued previous CMB measurements,
is now removed by the Planck precision in the determination of the highest acoustic peaks. Inflaton potentials with a concave
shape are favoured and occupy most of the 95% confidence region allowed by
Planck+WP in the $n\_{\mathrm{s}}\textrm{-}r$ plane. Models with an exponential potential, a monomial potential with a power larger than two, or
hybrid models driven by a quadratic term are disfavoured at more than 95% confidence.
The quadratic large-field model, in the past often cited as the simplest inflationary model,
now lies at the edge of the 95% CL contours allowed by Planck+WP+high-$\ell$ CMB data.

A Bayesian parameter estimation and model comparison analysis of a representative
sample of single-field slow-roll models shows that Planck is able to discriminate
between these models with results that are robust even when a broad set of entropy generation
scenarios are allowed. In addition to confirming the exclusion of the $\phi^{4}$ potential,
the Bayesian evidence computed from the Planck data provides significant odds (logarithms of the Bayes factor of about
$-5$ or lower relative to $\Lambda$CDM)
against large-field models compatible with previous cosmological data, such as the $\phi^{2}$ potential, and two-parameter potentials
such as natural inflation and the hilltop potential. As presented in Sect. [5](#S5 "5 Inflationary model comparison ‣ Planck 2013 results. XXII. Constraints on inflation"),
Planck establishes strong constraints on the parameter values
of specific inflationary scenarios. For example, the scale parameter of the natural inflation potential
is constrained to be $\log(f/M\_{\mathrm{pl}})\gtrsim 1.1$ (95% CL), improving upon the WMAP 7-year
limit on $f$ by a factor of two. The Planck data
limit the possibilities for the unexplored physics between the end of inflation and
the beginning of the radiation dominated era. Data-driven constraints are obtained on $w\_{\mathrm{int}}$, the effective
equation of state in the post-inflationary era. Particularly for the disfavoured models listed above,
their parameters are pushed to unnatural values ($w\_{\mathrm{int}}\gtrsim 1/3$) in order to become more compatible with the data.

Using an essentially exact numerical calculation of the predicted
primordial spectrum, we
reconstruct the observable window of the inflaton potential,
expanding the potential as a Taylor series up to a fixed order. For
an observable potential
described by a polynomial of order three, the
reconstruction agrees well with the slow-roll predictions. If a quartic term
is allowed, the result deviates from the slow-roll prediction because
the Planck data favour a slightly smaller amplitude for the
Sachs-Wolfe plateau relative to the $\ell>40$ part of the power
spectrum than the best fitting minimal $\Lambda$CDM model with a power law
primordial spectrum. A potential with a fourth-order polynomial can
fit this feature, thus reducing the effective $\chi\_{\mathrm{eff}}^{2}$ by approximately four.

A penalized likelihood reconstruction of the primordial power spectrum
shows hints of structure at modest
statistical significance. However, recent work after submission suggests that this
feature can be explained by electromagnetic interference.
Parameterized models producing superimposed oscillations (possibly motivated by deviations
from the Bunch-Davies vacuum state, axion monodromy, or a sharp step in the inflaton potential) improve
the $\chi\_{\mathrm{eff}}^{2}$ by roughly $10$, where three extra parameters have been added.
However, a Bayesian model comparison analysis does not strongly favour the model with oscillations over
the standard featureless power spectrum. With Planck polarization data, a more
conclusive result on superimposed oscillations is expected.

We combine power spectrum constraints
with those on the nonlinearity parameter
$f\_{\mathrm{NL}}$ ([Planck Collaboration
XXIV, 2014](#bib.bib264)) to constrain single-field
inflation with generalized Lagrangians, in which
non-Gaussianities are larger than those predicted by the simplest
slow-roll inflationary models. We show how the limits on the
inflation sound speed derived in [Planck Collaboration
XXIV (2014)](#bib.bib264) are crucial
to constrain slow-roll parameters for generalized Lagrangians.
We also show how particular examples of DBI Inflation and $k$-inflation can be constrained by this combination of Planck data.

We test the hypothesis that the primordial cosmological perturbations were exclusively
adiabatic. We analyse all nonsingular (i.e., nondecaying)
isocurvature modes arbitrarily correlated to the adiabatic mode,
using a parameterization where the isocurvature contributions are specified at two scales.
The oscillatory pattern in the Planck temperature spectrum is
compatible with purely adiabatic perturbations, and therefore constrains any isocurvature contribution to be small at those multipoles.
As a consequence, axion and curvaton scenarios, in which the CDM isocurvature mode is
uncorrelated or fully correlated with the adiabatic
mode, are not favoured by Planck. The upper bounds on the isocurvature fraction at
$k=0.05$ Mpc-1 are $0.039$ for the axion, and $0.0025$ for the curvaton, at 95% CL.
However general models with an arbitrarily correlated mixture of
adiabatic and (CDM or neutrino) isocurvature modes have the freedom to
lower the Sachs-Wolfe plateau relative to the high-$\ell$ spectrum,
and reduce the effective $\chi\_{\mathrm{eff}}^{2}$ by more than four.

The simplest inflationary models have passed an exacting test with the Planck data.
The full mission data including Planck’s polarization measurements will help answer further fundamental questions,
helping to probe nonsmooth power spectra and the energy scale of inflation as well as extensions to more complex models.

###### Acknowledgements.

The development of Planck has been supported by: ESA; CNES and CNRS/INSU-IN2P3-INP (France); ASI, CNR, and INAF (Italy);
NASA and DoE (USA); STFC and UKSA (UK); CSIC, MICINN, JA and RES (Spain); Tekes, AoF and CSC (Finland); DLR and MPG (Germany);
CSA (Canada); DTU Space (Denmark); SER/SSO (Switzerland); RCN (Norway); SFI (Ireland); FCT/MCTES (Portugal); and PRACE (EU).
A description of the Planck Collaboration and a list of its members, including the technical or scientific activities in which
they have been involved, can be found at <http://www.sciops.esa.int/index.php?project=planck&page=Planck_Collaboration>.
We gratefully acknowledge CINECA (http://www.cineca.it/)
under the agreement LFI/CINECA and IN2P3 Computer Center
(http://cc.in2p3.fr) for providing a significant
amount of the computing resources and services needed for this work.

## Appendix A Sampling the Hubble flow functions

In this Appendix we briefly review how to constrain slow-roll inflation by sampling the Hubble flow functions (HFFs)
and discuss how well the results agree with those derived by sampling directly
the parameters $\ln A\_{\mathrm{s}}$, $n\_{\mathrm{s}}$, $r$, and $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$.
This method fully exploits an analytic perturbative expansion in terms of the HFFs
for the primordial spectra of cosmological fluctuations during slow-roll inflation
([Stewart & Lyth, 1993](#bib.bib314); [Gong & Stewart, 2001](#bib.bib109); [Leach et al., 2002](#bib.bib164)), which self-consistently extends to highest order the first terms presented in
Eqs. [13](#S2.E13 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation")-[19](#S2.E19 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation"). Since $z^{\prime\prime}/z$ in Eq. [7](#S2.E7 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") and $a^{\prime\prime}/a$ in Eq. [9](#S2.E9 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation")
can be rewritten exactly in terms of the Hubble flow functions,
the HFF hierarchy, rather than the potential hierarchy, is best suited for this purpose.
The slow-roll analytic power spectra have been calculated up to second order
using the Green’s function method ([Gong & Stewart, 2001](#bib.bib109); [Leach et al., 2002](#bib.bib164)).
Other approximations are available in the literature, including WKB ([Martin & Schwarz, 2003](#bib.bib204)), the uniform approximation
([Habib et al., 2002](#bib.bib124)), or the
method of comparison equations ([Casadio et al., 2006](#bib.bib60)).

The dependence of the amplitudes in Eqs. [13](#S2.E13 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") and [14](#S2.E14 "In 2.2 Quantum generation of fluctuations ‣ 2 Lightning review of inflation ‣ Planck 2013 results. XXII. Constraints on inflation") in terms of HFF is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $A\_{X}=A\_{X\thinspace 0}e^{b\_{X\thinspace 0}},$ |  | (84) |

where $X={\mathrm{s},\mathrm{t}}$, and $b\_{\mathrm{s}0}\thinspace,b\_{\mathrm{t}0}$ are

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle b\_{\mathrm{s}0}=$ | $\displaystyle-2\left(C+1\right)\epsilon\_{1}-C\epsilon\_{2}+\left(-2C+{\textstyle\frac{\pi^{2}}{2}}-7\right)\epsilon\_{1}^{2}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle+\left({\textstyle\frac{\pi^{2}}{8}}-1\right)\epsilon\_{2}^{2}+\left(-X^{2}-3X+{\textstyle\frac{7\pi^{2}}{12}}-7+\Delta\_{\mathrm{s}0}\right)\epsilon\_{1}\epsilon\_{2}$ |  | (85) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle+\left(-{\textstyle\frac{1}{2}}X^{2}+{\textstyle\frac{\pi^{2}}{24}}+\Delta\_{\mathrm{s}0}\right)\epsilon\_{2}\epsilon\_{3},$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\begin{split}b\_{\mathrm{t}0}=&-2\left(C+1\right)\epsilon\_{1}+\left(-2C+{\textstyle\frac{\pi^{2}}{2}}-7\right)\epsilon\_{1}^{2}\\ &+\left(-C^{2}-2C+{\textstyle\frac{\pi^{2}}{12}}-2+\Delta\_{\mathrm{t}0}\right)\epsilon\_{1}\epsilon\_{2},\end{split}$ | |  | (86) |

with $C\equiv\ln 2+\gamma\_{\mathrm{E}}-2\approx-0.7296$ ($\gamma\_{\mathrm{E}}$
is the Euler-Mascheroni constant). At second order the coefficients of the expansion depend
on the particular approximation scheme:
$X=C$ and $\Delta\_{\mathrm{s}0}=\Delta\_{\mathrm{t}0}=0$ apply for
the Green’s function method (GFM, [Gong & Stewart (2001)](#bib.bib109); [Leach et al. (2002)](#bib.bib164)),
and $X=D=1/3-\ln 3$, $\Delta\_{\mathrm{s}0}=(D-C)(D+\ln 2)-1/18$, $\Delta\_{\mathrm{t}0}=2D(D-C)-1/9$ apply for
the method of comparison equations (MCE, [Casadio et al. (2006)](#bib.bib60)). As predicted by the consistency relation,
$A\_{h\thinspace 0}=16\epsilon\_{1}A\_{\mathcal{R}\thinspace 0}$.

The full perturbative expressions up to second order in HFF for the spectral indices and the running of the indices are

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle n\_{\mathrm{s}}-1$ | $\displaystyle=$ | $\displaystyle-2\epsilon\_{1}-\epsilon\_{2}-2\epsilon\_{1}^{2}-\left(2\thinspace C+3\right)\thinspace\epsilon\_{1}\thinspace\epsilon\_{2}-C\epsilon\_{2}\epsilon\_{3},$ |  | (87) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$ | $\displaystyle=$ | $\displaystyle-2\epsilon\_{1}\epsilon\_{2}-\epsilon\_{2}\epsilon\_{3},$ |  | (88) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle n\_{\mathrm{t}}$ | $\displaystyle=$ | $\displaystyle-2\epsilon\_{1}-2\epsilon\_{1}^{2}-2\thinspace\left(C+1\right)\thinspace\epsilon\_{1}\thinspace\epsilon\_{2},$ |  | (89) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\mathrm{d}n\_{\mathrm{t}}/\mathrm{d}\ln k$ | $\displaystyle=$ | $\displaystyle-2\epsilon\_{1}\epsilon\_{2}.$ |  | (90) |

We now constrain these parameters using the Planck+WP data. If we restrict ourselves to first order, we obtain $\epsilon\_{1}<0.0074$ at 95% CL and $\epsilon\_{2}=0.030^{+0.010}\_{-0.009}$ at 68% CL.
At second order with GFM,
we obtain $\epsilon\_{1}<0.013$ at 95% CL, $\epsilon\_{2}=0.043^{+0.013}\_{-0.014},$ and
$\epsilon\_{3}=0.36^{+0.19}\_{-0.22}$ at 68% CL. The comparison of results at first
and second order is shown in Fig. [25](#A1.F25 "Figure 25 ‣ Appendix A Sampling the Hubble flow functions ‣ Planck 2013 results. XXII. Constraints on inflation").
Different approximation schemes lead to small differences, as Fig. [26](#A1.F26 "Figure 26 ‣ Appendix A Sampling the Hubble flow functions ‣ Planck 2013 results. XXII. Constraints on inflation") shows
for the GFM versus the MCE.
Figure [27](#A1.F27 "Figure 27 ‣ Appendix A Sampling the Hubble flow functions ‣ Planck 2013 results. XXII. Constraints on inflation") shows the agreement between the physical parameters reconstructed from the
HFF method and those directly sampled as in Sect. [4.3](#S4.SS3 "4.3 Running spectral index ‣ 4 Constraints on slow-roll inflationary models ‣ Planck 2013 results. XXII. Constraints on inflation").

Figure 25: Planck constraints on the
HFFs $(\epsilon\_{1},\epsilon\_{2},\epsilon\_{3})$
assuming either $\epsilon\_{3}=0$ and
the first-order slow-roll approximation for the computation of the
primordial spectra, or $\epsilon\_{3}\neq 0$ and the
second-order slow-roll approximation (HFF GFM).

Figure 26: Comparison of the Planck constraints on the
HFFs $(\epsilon\_{1},\epsilon\_{2},\epsilon\_{3})$ using
the GFM and the MCE.

Figure 27: Planck constraints on the
spectral parameters $n\_{\mathrm{s}},\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k,$ and $r$.
We compare constraints computed with the second-order slow-roll approximation,
starting from flat priors on the HFF parameters at the pivot scale
$(\epsilon\_{1},\epsilon\_{2},\epsilon\_{3})$, with those obtained directly from
$n\_{\mathrm{s}}\thinspace,\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k,$ and $r$.
In the latter case we enforce the second-order consistency conditions for the
tensor-to-scalar ratio and for the running of the tensor spectral
index.

[241](#bib.bib241), [242](#bib.bib242), [243](#bib.bib243), [244](#bib.bib244), [245](#bib.bib245), [246](#bib.bib246), [247](#bib.bib247), [248](#bib.bib248), [249](#bib.bib249), [250](#bib.bib250), [271](#bib.bib271), [252](#bib.bib252), [253](#bib.bib253), [254](#bib.bib254), [255](#bib.bib255), [256](#bib.bib256), [257](#bib.bib257), [258](#bib.bib258), [259](#bib.bib259), [260](#bib.bib260), [261](#bib.bib261), [262](#bib.bib262), [263](#bib.bib263), [264](#bib.bib264), [265](#bib.bib265), [266](#bib.bib266), [267](#bib.bib267), [268](#bib.bib268), [269](#bib.bib269), [270](#bib.bib270), [251](#bib.bib251)
