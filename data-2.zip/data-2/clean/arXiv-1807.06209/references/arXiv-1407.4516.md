<!-- fulltext source=arxiv_html slug=arXiv-1407.4516 fetched=2026-09-18T01:13:27+00:00 -->

# Weighing the Giants IV: Cosmology and Neutrino Mass

Weighing the Giants IV: Cosmology and Neutrino Mass–[C](#A3 "Appendix C The ISW Effect in Free Growth-Index Models ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")2014

Adam B. Mantz
  
Anja von der Linden
††thanks: Corresponding author e-mail: [amantz@kicp.uchicago.edu](mailto:amantz@kicp.uchicago.edu)
Affiliation: Department of Astronomy and Astrophysics, University of Chicago, 5640 South Ellis Avenue, Chicago, IL 60637, USA
Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, 5640 South Ellis Avenue, Chicago, IL 60637, USA
  
Steven W. Allen
Affiliation: Kavli Institute for Particle Astrophysics and Cosmology, Stanford University, 452 Lomita Mall, Stanford, CA 94305, USA
Affiliation: Department of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305, USA
Affiliation: Dark Cosmology Centre, Niels Bohr Institute, University of Copenhagen, Juliane Maries Vej 30, 2100 Copenhagen, Denmark
  
Douglas E. Applegate
Affiliation: Kavli Institute for Particle Astrophysics and Cosmology, Stanford University, 452 Lomita Mall, Stanford, CA 94305, USA
Affiliation: Department of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305, USA
Affiliation: SLAC National Accelerator Laboratory, 2575 Sand Hill Road, Menlo Park, CA 94025, USA
  
Patrick L. Kelly
Affiliation: Argelander-Institute for Astronomy, Auf dem Hügel 71, D-53121 Bonn, Germany
  
R. Glenn Morris
Affiliation: Department of Astronomy, University of California, Berkeley, CA 94720, USA
  
David A. Rapetti
Affiliation: Kavli Institute for Particle Astrophysics and Cosmology, Stanford University, 452 Lomita Mall, Stanford, CA 94305, USA
Affiliation: SLAC National Accelerator Laboratory, 2575 Sand Hill Road, Menlo Park, CA 94025, USA
  
Robert W. Schmidt
Affiliation: Dark Cosmology Centre, Niels Bohr Institute, University of Copenhagen, Juliane Maries Vej 30, 2100 Copenhagen, Denmark
  
Saroj Adhikari
Affiliation: Astronomisches Rechen-Institut, Zentrum für Astronomie der Universität Heidelberg, Mönchhofstrasse 12-14, D-69120 Heidelberg, Germany
  
Mark T. Allen
Affiliation: Institute for Gravitation and the Cosmos, Pennsylvania State University, University Park, PA 16802, USA
  
Patricia R. Burchat
Affiliation: Kavli Institute for Particle Astrophysics and Cosmology, Stanford University, 452 Lomita Mall, Stanford, CA 94305, USA
Affiliation: Department of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305, USA
  
David L. Burke
Affiliation: Kavli Institute for Particle Astrophysics and Cosmology, Stanford University, 452 Lomita Mall, Stanford, CA 94305, USA
Affiliation: Department of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305, USA
  
Matteo Cataneo
Affiliation: Kavli Institute for Particle Astrophysics and Cosmology, Stanford University, 452 Lomita Mall, Stanford, CA 94305, USA
Affiliation: SLAC National Accelerator Laboratory, 2575 Sand Hill Road, Menlo Park, CA 94025, USA
  
David Donovan
Affiliation: Dark Cosmology Centre, Niels Bohr Institute, University of Copenhagen, Juliane Maries Vej 30, 2100 Copenhagen, Denmark
  
Harald Ebeling
Affiliation: Institute for Astronomy, 2680 Woodlawn Drive, Honolulu, HI 96822, USA
  
Sarah Shandera
Affiliation: Institute for Astronomy, 2680 Woodlawn Drive, Honolulu, HI 96822, USA
  
Adam Wright
Affiliation: Kavli Institute for Particle Astrophysics and Cosmology, Stanford University, 452 Lomita Mall, Stanford, CA 94305, USA
Affiliation: Department of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305, USA
Affiliation: SLAC National Accelerator Laboratory, 2575 Sand Hill Road, Menlo Park, CA 94025, USA
Affiliation: Institute for Gravitation and the Cosmos, Pennsylvania State University, University Park, PA 16802, USA

Submitted 16 July 2014. Accepted 7 October 2014.

###### Abstract

We employ robust weak gravitational lensing measurements to improve cosmological constraints from measurements of the galaxy cluster mass function and its evolution, using X-ray selected clusters detected in the ROSAT All-Sky Survey. Our lensing analysis constrains the absolute mass scale of such clusters at the 8 per cent level, including both statistical and systematic uncertainties. Combining it with the survey data and X-ray follow-up observations, we find a tight constraint on a combination of the mean matter density and late-time normalization of the matter power spectrum, $\sigma\_{8}(\Omega\_{\mathrm{m}}/0.3)^{0.17}=0.81\pm 0.03$, with marginalized, one-dimensional constraints of $\Omega\_{\mathrm{m}}=0.26\pm 0.03$ and $\sigma\_{8}=0.83\pm 0.04$. For these two parameters, this represents a factor of two improvement in precision with respect to previous work, primarily due to the reduced systematic uncertainty in the absolute mass calibration provided by the lensing analysis. Our new results are in good agreement with constraints from cosmic microwave background (CMB) data, both WMAP and Planck (plus WMAP polarization), under the assumption of a flat $\Lambda$CDM cosmology with minimal neutrino mass. Consequently, we find no evidence for non-minimal neutrino mass from the combination of cluster data with CMB, supernova and baryon acoustic oscillation measurements, regardless of which all-sky CMB data set is used (and independent of the recent claimed detection of B-modes on degree scales). We also present improved constraints on models of dark energy (both constant and evolving), modifications of gravity, and primordial non-Gaussianity. Assuming flatness, the constraints for a constant dark energy equation of state from the cluster data alone are at the 15 per cent level, improving to $\sim 6$ per cent when the cluster data are combined with other leading probes.

###### Keywords:

cosmological parameters – cosmology: observations – large-scale structure of the Universe – X-rays: galaxies: clusters

## 1 Introduction

Great strides have been made in recent years in the use of galaxy cluster surveys as probes of the halo mass function, and thereby of cosmology and fundamental physics (for a review, see [Allen, Evrard & Mantz 2011](#bib.bib3)). Cluster surveys covering the entire extragalactic sky, or a significant fraction of it, now exist at X-ray ([Trümper, 1993](#bib.bib125); [Ebeling
et al., 1998](#bib.bib40); [Ebeling
et al., 2010](#bib.bib41); [Böhringer
et al., 2004](#bib.bib25)), optical/IR (e.g. [Koester
et al. 2007](#bib.bib60); [Rykoff
et al. 2014](#bib.bib106)) and millimeter ([Reichardt
et al., 2013](#bib.bib99); [Hasselfield
et al., 2013](#bib.bib48); [Planck
Collaboration, 2013a](#bib.bib87)) wavelengths, and a number of independent groups have published cosmological constraints in broad agreement with one another based on these data (e.g. [Eke et al. 1998](#bib.bib42); [Donahue &
Voit 1999](#bib.bib38); [Henry 2000](#bib.bib49); [Henry 2004](#bib.bib50); [Borgani
et al. 2001](#bib.bib26); [Reiprich &
Böhringer 2002](#bib.bib102); [Seljak 2002](#bib.bib114); [Viana
et al. 2002](#bib.bib126); [Allen
et al. 2003](#bib.bib8); [Pierpaoli
et al. 2003](#bib.bib86); [Schuecker
et al. 2003](#bib.bib112); [Vikhlinin
et al. 2003](#bib.bib128); [Vikhlinin
et al. 2009](#bib.bib127); [Voevodkin &
Vikhlinin 2004](#bib.bib129); [Dahle 2006](#bib.bib35); [Mantz
et al. 2008](#bib.bib73); [Mantz
et al. 2010a](#bib.bib74); [Henry
et al. 2009](#bib.bib51); [Rozo
et al. 2010](#bib.bib105); [Sehgal
et al. 2011](#bib.bib113); [Benson
et al. 2013](#bib.bib17); [Planck
Collaboration 2013d](#bib.bib90)).

These cluster survey data have provided highly competitive constraints on dark energy and modifications of gravity (e.g. [Vikhlinin
et al. 2009](#bib.bib127); [Mantz
et al. 2010a](#bib.bib74); [Schmidt
et al. 2009](#bib.bib110); [Rapetti
et al. 2013](#bib.bib97)), as well as measurements of the late-time normalization of the matter power spectrum ($\sigma\_{8}$, defined by Equation [2](#S3.E2 "In 3.1 Cosmological Model ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), below). Constraints on $\sigma\_{8}$ are a key complement to measurements of the amplitude of the power spectrum at high redshift from the CMB in many cosmological models of interest, particularly those where the dark energy equation of state or neutrino masses are free parameters. Since cosmological data currently provide our best limits on the species-summed neutrino mass ([Mantz, Allen & Rapetti 2010](#bib.bib76); [Reid
et al. 2010](#bib.bib101)), improving constraints on $\sigma\_{8}$ is a priority.

Previous constraints on $\sigma\_{8}$ from clusters have been systematically limited due to fundamental uncertainties regarding the absolute calibration of cluster mass measurements (for a discussion, see [von der Linden
et al. 2014b](#bib.bib131)). The most widespread observational techniques used to estimate masses, based on X-ray data or optical spectroscopy, assume that the measured thermal/kinetic energies accurately reflect the underlying gravitating mass, and are thus subject to a theoretically uncertain bias. Recently, measurements of the gravitational lensing of background galaxies due to clusters have emerged as a potential avenue for providing a more accurate absolute mass calibration, since weak-lensing mass measurements are expected to be nearly unbiased when the analysis is restricted to the appropriate radial range (e.g. [Becker &
Kravtsov 2011](#bib.bib15)) and systematic effects in the shear measurements and photometric redshifts can be accounted for ([Applegate
et al., 2014](#bib.bib10)). Thanks to the availability of wide field-of-view imagers with superb image quality, such as SuprimeCam at the Subaru telescope and MegaCam/MegaPrime at the Canada-France-Hawaii Telescope (CFHT), unbiased weak lensing measurements for large samples of clusters are now within reach.

The Weighing the Giants project was conceived in order to provide just such an accurate and precise calibration of cluster masses for studies of cosmology, and for the closely related analysis of cluster scaling relations. The project involves 51 massive clusters that have previously been used in cosmological studies ([Allen
et al. 2008](#bib.bib5); [Mantz
et al. 2010a](#bib.bib74); [Mantz
et al. 2010b](#bib.bib75), hereafter [74](#bib.bib74),[b](#MtenBht "In References ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")). Details of the lensing data and their analysis appear in Papers I–III of this series ([von der Linden
et al., 2014a](#bib.bib130); [Kelly
et al., 2014](#bib.bib58); [Applegate
et al., 2014](#bib.bib10)), which we collectively refer to as [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) below. The [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) lensing analysis has already been used to calibrate mass estimates based on X-ray observations that assume hydrostatic equilibrium ([von der Linden
et al. 2014b](#bib.bib131); Applegate et al., in prep.), particularly in the context of the cosmological constraints available from gas mass fraction ($f\_{\mathrm{gas}}$) measurements in relaxed clusters ([Mantz
et al., 2014](#bib.bib77)). Here we apply the lensing data to cosmological tests based on the cluster mass function (also referred to as cluster counts), specifically by incorporating the [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) data into the [74](#bib.bib74),[b](#MtenBht "In References ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") analysis of X-ray cluster survey and follow-up data. A companion paper (WtG V, in prep.) explores the astrophysical consequences of our mass calibration for cluster scaling relations, which are necessarily constrained simultaneously with cosmological parameters in our analysis.

Given both the widespread expectation that the “correct” answers for cosmological parameters will be consistent with those determined from CMB data for a spatially flat, cosmological-constant model, and the potential of galaxy cluster surveys to provide high-precision cosmological constraints, minimizing the possibility of observer bias is paramount in such work. The [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) lensing analysis employed a procedure whereby those working on it were blind in all comparisons to independent mass estimates, in particular (but not limited to) those from X-ray observations and from lensing results in the literature, until the lensing analysis was finalized (see [Applegate
et al. 2014](#bib.bib10) for a full discussion). This entire lensing analysis was completed before the cosmological analysis presented here had begun. Although we did not explicitly blind cosmological parameter results in this work, the constraints reported here are simply those that follow from incorporating the [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) lensing data into an already mature analysis pipeline ([74](#bib.bib74)), which is a simple and straightforward addition (Section [3.3](#S3.SS3 "3.3 Likelihood Function ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")).

This paper is organized as follows. Section [2](#S2 "2 Data ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") describes our cluster data and the external cosmological probes with which we combine them, while Section [3](#S3 "3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") outlines the analysis procedure and the models fitted to the data. Our results are presented in Section [4](#S4 "4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). Section [5](#S5 "5 Discussion ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") considers the importance of the lensing and X-ray follow-up data to the analysis, and the potential gains from obtaining an expanded lensing data set and combining surveys at different wavelengths. We conclude in Section [6](#S6 "6 Conclusions ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). Best-fitting parameter values reported here always correspond to modes of the marginalized posterior distributions, and uncertainties correspond to 68.3 per cent confidence maximum-likelihood intervals, unless otherwise specified. We make occasional use of a reference cosmological model, which has Hubble parameter $h=H\_{0}/100\mathrm{\,km}\mathrm{\,s}^{-1}\mathrm{\,Mpc}^{-1}=0.7$, mean matter density in units of the critical density $\Omega\_{\mathrm{m}}=0.3$, and cosmological constant energy density $\Omega\_{\mathrm{\Lambda}}=0.7$. We use the standard definition of cluster masses and characteristic radii in terms of a spherical overdensity, $\Delta$, with respect to the critical density at the cluster’s redshift: $M\_{\Delta}=(4\pi/3)\Delta\rho\_{\mathrm{cr}}(z)r\_{\Delta}^{3}$.

## 2 Data

The data set employed here consists of three X-ray flux-limited samples of clusters (i.e. redshifts and fluxes, along with the associated selection functions), as well as deeper follow-up X-ray data and/or high-quality optical imaging for a subset of the detected clusters. As in [74](#bib.bib74),[b](#MtenBht "In References ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), the cluster samples used here are based on the BCS ([Ebeling
et al., 1998](#bib.bib40)), REFLEX ([Böhringer
et al., 2004](#bib.bib25)), and Bright MACS ([Ebeling
et al., 2010](#bib.bib41)) catalogs, themselves compiled from the ROSAT All-Sky Survey (RASS; [Trümper 1993](#bib.bib125)). In the cases of BCS and REFLEX (covering redshifts $z<0.3$), we use only clusters with 0.1–2.4$\mathrm{\,keV}$ luminosities $>2.5\times 10^{44}\mathrm{\,erg}\mathrm{\,s}^{-1}$ (as estimated for our reference cosmology) to eliminate low-mass clusters and groups; this cut has no impact on the Bright MACS sample ($0.3<z<0.5$). We depart slightly from [74](#bib.bib74),[b](#MtenBht "In References ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") by using a higher flux limit of $5\times 10^{-12}\mathrm{\,erg}\mathrm{\,s}^{-1}\mathrm{\,cm}^{-2}$ in the 0.1–2.4$\mathrm{\,keV}$ band when selecting clusters from the BCS in order to avoid incompleteness that affects the lowest fluxes in BCS at all redshifts (see [Ebeling
et al. 1998](#bib.bib40)).11
1
For the REFLEX and Bright MACS catalogs, we respectively use flux limits of $3$ and $2\times 10^{-12}\mathrm{\,erg}\mathrm{\,s}^{-1}\mathrm{\,cm}^{-2}$, as in [74](#bib.bib74),[b](#MtenBht "In References ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). We have also expanded the allowance for overall incompleteness/impurity for Bright MACS to $\pm 10$ per cent from the $\pm 5$ per cent previously assumed for MACS and other surveys in [74](#bib.bib74), reflecting the greater challenges affecting the MACS survey construction. Finally, we have removed Abell 2318, RX J0250.2$-$2129 and RX J1050.6$-$2405 from the data set, as these appear consistent with their X-ray emission being dominated by active galactic nuclei (AGN) rather than the intracluster medium (A. Edge, private communication; other deletions from the published catalogs are listed in [75](#bib.bib75)). However, these changes to the data set are not significant enough to affect any of our cosmological results, as we have verified by explicitly comparing constraints using the old and new samples. The new sample contains a total of 224 clusters.

X-ray luminosities and gas masses were derived from ROSAT and/or Chandra data for 94 clusters in [75](#bib.bib75). We employ these measurements again in the present work, in addition to the survey data, to improve constraints on the cluster scaling relations and refine the mass information available for individual clusters (see Sections [3.2](#S3.SS2 "3.2 Cluster Scaling Relations ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") and [5.1](#S5.SS1 "5.1 The Role of Follow-up Data ‣ 5 Discussion ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")).22
2
Since the analysis of [75](#bib.bib75), the model for the contaminant affecting the Chandra ACIS detectors (including its time dependence) has been modified slightly. An overall bias in gas masses or luminosities from follow-up observations would have no effect on the cosmological analysis in this work, since gas mass is used only as an empirically calibrated mass proxy, and luminosities from follow-up data are cross-calibrated to the ROSAT survey luminosities (see [74](#bib.bib74)). Nevertheless, we note that directly comparing luminosities and gas mass profiles for 59 clusters in common between the [75](#bib.bib75) and [Mantz
et al. (2014)](#bib.bib77) generations of analysis (not all of which were published in each paper), shows agreement at the per cent level.

The new data that are central to this work are the measurements of weak gravitational lensing for 50 massive clusters,33
3
While the full [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) analysis employs 51 clusters, we omit Abell 370 from this work, since it has fundamentally different selection properties from our data set (i.e. it is not X-ray selected). which are used to calibrate the absolute cluster mass scale. These data and their analysis are described in [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10). Specifically, we use the shear profiles derived from the simpler “color-cut” method of that work, which are available for the entire data set, rather than those from the “$p(z)$’’ method, which are available for just over half of the sample.44
4
The more robust $p(z)$ masses have been used to characterize the bias and scatter of the color-cut method ([Applegate
et al., 2014](#bib.bib10)), and this information is fed into the analysis presented here (specifically it factors into the width of the lensing-to-true mass normalization; see Section [3.2](#S3.SS2 "3.2 Cluster Scaling Relations ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")). The larger number of clusters for which we can do a color-cut analysis makes this cross-calibration approach preferable to relying exclusively on $p(z)$ clusters. Of the 50 [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) clusters, 27 belong to the flux-limited sample identified above, and are straightforward to incorporate into the likelihood function for cosmology and scaling relations described in [74](#bib.bib74) and reviewed in Section [3.3](#S3.SS3 "3.3 Likelihood Function ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). The remaining 23 cannot be used to constrain the X-ray luminosity–mass relation because, even though they are X-ray selected, we do not have a robustly quantified selection function for them with which to account for selection biases. However, they can still be used to calibrate the relation linking gas and total mass, to the extent that the correlation of intrinsic scatters in luminosity and gas mass at fixed total mass is small (e.g. [Allen
et al. 2011](#bib.bib3)). We have verified empirically that including these additional lensing data in this way (see Section [3.3](#S3.SS3 "3.3 Likelihood Function ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")) does not bias our cosmological results.

In addition to the measurements of redshift, X-ray luminosity, gas mass and total mass (integrated over radii $\ {\raise-3.22916pt\hbox{$\mathrel{\mathop{\kern 0.0pt\sim}\limits^{<}}$}}\ r\_{500}$), we take advantage of the cosmological information available from X-ray measurements of the gas mass fraction, $f\_{\mathrm{gas}}$, at $\sim r\_{2500}$ for relaxed clusters ([Mantz
et al. 2014](#bib.bib77), hereafter [77](#bib.bib77)).55
5
We use the term $f\_{\mathrm{gas}}$ generically to refer to the [77](#bib.bib77) data set in this paper, or $f\_{\mathrm{gas}}($0.8–1.2$\,r\_{2500})$ when necessary for clarity. The integrated gas mass fraction that is constrained at radii $\sim r\_{500}$ from the X-ray and lensing follow-up observations that form part of the cluster counts data set will be referred to as $f\_{\mathrm{gas}}(r\_{500})$. More precisely, these $f\_{\mathrm{gas}}$ measurements are made in a spherical shell spanning 0.8–1.2 $r\_{2500}$, where theoretical and observational uncertainties due to various astrophysical effects (e.g. AGN feedback, gas cooling and clumping, etc.) are minimized and where X-ray spectroscopy permits precise total mass estimates. These data provide additional constraints on dark energy parameters and, when combined with external priors on the cosmic mean baryon density ($\Omega\_{\mathrm{b}}$), produce tight constraints on $\Omega\_{\mathrm{m}}$. These $f\_{\mathrm{gas}}($0.8–1.2$\,r\_{2500})$ data do not constrain $\sigma\_{8}$, although their constraint on $\Omega\_{\mathrm{m}}$ is useful for breaking the degeneracy between the two parameters in cluster counts data.

Our baseline cluster analysis uses all the data described above, the RASS cluster catalogs, mass proxies from X-ray follow-up data, lensing data and $f\_{\mathrm{gas}}$ measurements (but see Section [4.1](#S4.SS1 "4.1 Cluster Constraints on Ω_m and 𝜎_8 ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")), and also incorporates Gaussian priors on the Hubble parameter ($h=0.738\pm 0.024$; [Riess
et al. 2011](#bib.bib104)) and the cosmic baryon density ($100\,\Omega\_{\mathrm{b}}h^{2}=2.202\pm 0.045$; [Cooke
et al. 2014](#bib.bib33)). (Note that these external priors are not required or used when the cluster data are combined with CMB data.) In Section [4](#S4 "4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), we present results from these cluster data, and compare and combine our results with those from independent cosmological probes. Specifically, we use all-sky CMB data from the Wilkinson Microwave Anisotropy Probe (WMAP 9-year release; [Bennett
et al. 2013](#bib.bib16); [Hinshaw
et al. 2013](#bib.bib53)) and the Planck satellite (1-year release, including WMAP polarization data, called Planck+WP below; [Planck
Collaboration 2013c](#bib.bib89)), as well as high-multipole data from the Atacama Cosmology Telescope (ACT; [Das
et al. 2014](#bib.bib36)) and the South Pole Telescope (SPT; [Keisler
et al. 2011](#bib.bib57); [Reichardt
et al. 2012](#bib.bib98); [Story
et al. 2013](#bib.bib119)). We also include the Union 2.1 compilation of type Ia supernovae ([Suzuki
et al., 2012](#bib.bib120)) and baryon acoustic oscillation (BAO) data from the combination of results from the 6-degree Field Galaxy Survey (6dF; $z=0.106$; [Beutler
et al. 2011](#bib.bib18)) and the Sloan Digital Sky Survey (SDSS, $z=0.35$ and $0.57$; [Padmanabhan
et al. 2012](#bib.bib84); [Anderson
et al. 2014](#bib.bib9)). Technical details of our use of these non-cluster data can be found in [77](#bib.bib77).

## 3 Model and Analysis Methods

[74](#bib.bib74) provide a detailed description of the analysis procedure for the cluster survey and X-ray follow-up data, including models for the cosmological background, halo abundance and measurement process employed in this work. Here we review the most relevant aspects of the analysis and describe the additions necessary to include the new gravitational lensing data. For details of the analysis of the $f\_{\mathrm{gas}}$ data, see [77](#bib.bib77).

### 3.1 Cosmological Model

As in [74](#bib.bib74) and [77](#bib.bib77), we consider cosmological models with a Friedmann-Robertson-Walker metric, containing radiation, baryons, neutrinos, cold dark matter (CDM), and dark energy. For the cluster data, the key parameters describing the average universe are the Hubble parameter ($h$), the cosmic densities of baryons ($\Omega\_{\mathrm{b}}$), neutrinos (parametrized by their species-summed mass, $\sum m\_{\nu}$), matter (in total, $\Omega\_{\mathrm{m}}$) and dark energy ($\Omega\_{\mathrm{DE}}$, or $\Omega\_{\mathrm{\Lambda}}$ in the case of a cosmological constant), and the global curvature density ($\Omega\_{k}$). We adopt an evolving parametrization of the dark energy equation of state ([Rapetti
et al., 2005](#bib.bib96)),

|  |  |  |  |
| --- | --- | --- | --- |
|  | $w=w\_{0}+w\_{a}\left(\frac{z}{z+z\_{\mathrm{tr}}}\right)=w\_{0}+w\_{a}\left(\frac{a^{-1}-1}{a^{-1}+a\_{\mathrm{tr}}^{-1}-2}\right),$ |  | (1) |

where $a=(1+z)^{-1}$ is the scale factor. In this model, $w$ takes the value $w\_{0}$ at the present day and $w\_{\mathrm{et}}=w\_{0}+w\_{a}$ in the high-redshift limit (i.e. at “early times”), with the timing of the transition between the two determined by $a\_{\mathrm{tr}}$. Equation [1](#S3.E1 "In 3.1 Cosmological Model ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") contains as special cases the cosmological constant model ($\Lambda$CDM; $w\_{0}=-1$ and $w\_{a}=0$), constant-$w$ models ($w\_{a}=0$), and the simpler evolving-$w$ model adopted by [Chevallier &
Polarski (2001)](#bib.bib31) and [Linder (2003)](#bib.bib64) ($a\_{\mathrm{tr}}=0.5$). [Allen
et al. (2008)](#bib.bib5) and [77](#bib.bib77) provide more details regarding calculations using this model. Note that, as in [74](#bib.bib74), we propagate the effect of dark energy density and velocity perturbations (when $w\neq-1$) on linear scales when evaluating the matter power spectrum.

The variance of the linearly evolved density field, smoothed by a spherical top-hat window of comoving radius $R$, enclosing mass $M=4\pi\rho R^{3}/3$, is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma^{2}(R,z)=\frac{1}{2\pi^{2}}\int\_{0}^{\infty}k^{2}P(k,z)|W\_{R}(k)|^{2}dk,$ |  | (2) |

where $P(k,z)$ is the linear power spectrum evolved to redshift $z$ and $W\_{R}(k)$ is the Fourier transform of the window function. The matter power spectrum is parametrized by an amplitude, conventionally $\sigma\_{8}=\sigma(R=8h^{-1}\mathrm{\,Mpc},z=0)$, and the scalar spectral index, $n\_{\mathrm{s}}$. We express the halo mass function, the expected number density as a function of redshift and mass, in the standard way:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left\langle\frac{dn(M,z)}{dM}\right\rangle=\frac{\rho}{M}\frac{d\ln\sigma^{-1}}{dM}f(\sigma,z).$ |  | (3) |

As in [74](#bib.bib74), we use the [Tinker
et al. (2008)](#bib.bib124) parametrization of $f(\sigma,z)$, including its explicit redshift dependence. To account for systematic uncertainties in the mass function, including for models other than $\Lambda$CDM, the effects of baryons, etc., we marginalize over priors at the 10 per cent level both in the baseline function, $f(\sigma,z=0)$, and in the redshift dependent terms from [Tinker
et al. (2008, see details in
M10a
)](#bib.bib124).

In Equation [3](#S3.E3 "In 3.1 Cosmological Model ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), as well as in the correspondence of mass and scale (i.e. $M\propto\rho R^{3}$) entering $W\_{R}(k)$, $\rho$ refers to the sum of baryon and CDM densities, i.e. matter *not* including neutrinos. Similarly, neutrinos are not included in the power spectrum used in Equation [2](#S3.E2 "In 3.1 Cosmological Model ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). [Costanzi
et al. (2013)](#bib.bib34) have shown that this choice results in the [Tinker
et al. (2008)](#bib.bib124) fitting formula providing a more accurate approximation to the mass function in $N$-body simulations with massive neutrinos than the analogous calculations including the neutrino density everywhere (see also [LoVerde 2014](#bib.bib67)). For our baseline model with $\sum m\_{\nu}=0.056\mathrm{\,eV}$ (the minimum value allowed by neutrino oscillation data), this distinction is completely negligible, but it has a small impact on our constraints (tightening them) at values $\sum m\_{\nu}\ {\raise-3.22916pt\hbox{$\mathrel{\mathop{\kern 0.0pt\sim}\limits^{>}}$}}\ 0.3\mathrm{\,eV}$, consistent with estimates of the magnitude of the effect by [Costanzi
et al. (2013)](#bib.bib34) and the level of systematic uncertainty adopted in our analysis.

Note that Sections [4.4](#S4.SS4 "4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") and [4.5](#S4.SS5 "4.5 Constraints on Non-Gaussianity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") introduce modifications to the evolution of the power spectrum and the mass function in order to investigate departures from General Relativity (GR) and non-Gaussianities in the primordial perturbation field. These are outlined in the respective sections.

### 3.2 Cluster Scaling Relations

Connecting the predicted mass function to a flux-limited survey requires a scaling relation – a stochastic function consisting of a mean relation and a model for intrinsic scatter – linking mass and X-ray luminosity. Additional observables that have a smaller intrinsic scatter at fixed mass (i.e. better mass proxies, namely gas mass and temperature in the case of X-ray follow-up observations) can improve cosmological constraints by refining the information available for individual clusters (e.g. [Wu, Rozo & Wechsler 2010](#bib.bib136); see also Section [5.1](#S5.SS1 "5.1 The Role of Follow-up Data ‣ 5 Discussion ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")). It is therefore advantageous to define joint scaling relations, describing the trends and joint scatter of several observables as a function of mass, as we do below. Due to the ubiquity of selection biases in cosmological samples and the steepness of the mass function, accurate constraints on scaling relations (and cosmology) can only be obtained from a simultaneous cosmology+scaling relation analysis that properly accounts for the influence of the mass function and the survey selection function on the observed data (see Section [3.3](#S3.SS3 "3.3 Likelihood Function ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), [74](#bib.bib74),[b](#MtenBht "In References ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") and [Allen
et al. 2011](#bib.bib3)).

Our model for the cluster scaling relations is that of [74](#bib.bib74),[b](#MtenBht "In References ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), expanded to include the new weak lensing observations. We describe the scaling of each observable cluster property with mass as a power law, and the joint intrinsic scatter as a multi-dimensional log-normal distribution. For this purpose, we define the logarithmic total mass within $r\_{500}$ as66
6
To simplify interpretation of the intrinsic scatter terms, we use natural logarithms in the scaling relation model, a change of notation with respect to [74](#bib.bib74),[b](#MtenBht "In References ‣ Weighing the Giants IV: Cosmology and Neutrino Mass").

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle m$ | $\displaystyle=$ | $\displaystyle\ln\left(\frac{E(z)M\_{500}}{10^{15}\,M\_{\odot}}\right),$ |  | (4) |

with $E(z)=H(z)/H\_{0}$. The corresponding definitions for observables – luminosity (0.1–2.4 keV band), center-excised temperature, gas mass and lensing mass – are

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\ell$ | $\displaystyle=$ | $\displaystyle\ln\left(\frac{L\_{500}}{E(z)10^{44}\mathrm{\,erg}\mathrm{\,s}^{-1}}\right),$ |  | (5) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle t$ | $\displaystyle=$ | $\displaystyle\ln\left(\frac{kT\_{500}}{\mathrm{\,keV}}\right),$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle m\_{\mathrm{gas}}$ | $\displaystyle=$ | $\displaystyle\ln\left(\frac{E(z)M\_{\mathrm{gas}}{}\_{,500}}{10^{15}\,M\_{\odot}}\right),$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle m\_{\mathrm{lens}}$ | $\displaystyle=$ | $\displaystyle\ln\left(\frac{E(z)M\_{\mathrm{lens}}{}\_{,500}}{10^{15}\,M\_{\odot}}\right).$ |  |

The quantities in Equation [5](#S3.E5 "In 3.2 Cluster Scaling Relations ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") represent intrinsic properties of a given cluster, as distinct from measured values (to which they are related by a model for measurement scatter); along with $m$, they are free parameters of the model.77
7
Note that, while $m$ represents true mass, the quantities in Equation [5](#S3.E5 "In 3.2 Cluster Scaling Relations ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") need not be identically the true luminosity, average temperature, etc. for a cluster (although they do correspond to the measured quantities generally described as such). For example, asphericity might result in a departure of $m\_{\mathrm{gas}}$ from the true gas mass within $r\_{500}$, an effect that contributes to the intrinsic scatter of the $m\_{\mathrm{gas}}$–$m$ relation. Similarly, $m\_{\mathrm{lens}}$ refers to the spherical mass that would be reconstructed from an ideal shear profile (i.e. without statistical error), which is in general different from the true mass due to projected structure. With these definitions, power-law scaling relations become linear relations between $\mn@boldsymbol{y}\equiv(\ell,t,m\_{\mathrm{gas}},m\_{\mathrm{lens}})$ and $m$. For a given cluster, the expectation value of $\mn@boldsymbol{y}$ is $\mn@boldsymbol{\beta\_{0}}+\mn@boldsymbol{\beta\_{1}}m$, and we assume a multivariate Gaussian intrinsic scatter in $\mn@boldsymbol{y}$ at fixed $m$; i.e.

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P(\mn@boldsymbol{y}|m)\propto|\mathbf{\Sigma}|^{-1/2}\exp\left(-\frac{1}{2}\mn@boldsymbol{\eta}^{\mathrm{t}}\mathbf{\Sigma}^{-1}\mn@boldsymbol{\eta}\right),$ |  | (6) |

where $\mathbf{\Sigma}$ is a covariance matrix and $\mn@boldsymbol{\eta}=\mn@boldsymbol{y}-(\mn@boldsymbol{\beta\_{0}}+\mn@boldsymbol{\beta\_{1}}m)$. The normalizations ($\mn@boldsymbol{\beta\_{0}}$), slopes ($\mn@boldsymbol{\beta\_{1}}$) and diagonal elements of $\mathbf{\Sigma}$ are in general free parameters that we allow the data to fit (though see below). Following [75](#bib.bib75), we also fit the off-diagonal covariance between $\ell$ and $t$ (which turns out to be consistent with zero; [75](#bib.bib75)). For simplicity, and because there is no particular expectation for a non-zero covariance, we fix the off-diagonal covariance terms involving $m\_{\mathrm{lens}}$ and $m\_{\mathrm{gas}}$ to zero (see discussion in Appendix [A](#A1 "Appendix A Constraints on Scaling Relations ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")).

For the $m\_{\mathrm{lens}}$–$m$ relation, we assume a slope of unity and place priors on the normalization and intrinsic scatter. Specifically, we adopt a Gaussian prior on the normalization, $\beta\_{0,m\_{\mathrm{lens}}}=0.99\pm 0.07$, encoding the expected bias (and its uncertainty) of weak lensing masses due to triaxiality, line-of-sight structure, the assumption of a [Navarro, Frenk & White (1997, hereafter
NFW
)](#bib.bib79) mass profile, systematic biases affecting shear measurements, photometric redshift errors, and the statistical uncertainty accrued in cross-calibrating $p(z)$ (5-filter) and color-cut (3-filter) lensing data. (Full details can be found in [Applegate
et al. 2014](#bib.bib10).) We constrain the scatter between $m\_{\mathrm{lens}}$ and $m$ with a wide Gaussian prior, $20\pm 10$ per cent, where the central value is motivated by the simulations of [Becker &
Kravtsov (2011)](#bib.bib15).88
8
Comparing the scatter in two mass bins, both lower in mass than the clusters in our lensing sample, these simulations imply that the intrinsic scatter decreases as a function of mass. We have tested whether a power-law dependence of the scatter on mass would change our results, marginalizing over indices in the range $\pm 0.35$, and find that this has a negligible effect on our cosmological constraints. This is due to the small range in mass covered by our lensing data, and the fact that, when X-ray mass proxy information is also included in the analysis, the data are able to directly constrain the intrinsic scatter at the pivot mass of the lensing sample (Appendix [A](#A1 "Appendix A Constraints on Scaling Relations ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")). Note that the width of our prior on the intrinsic scatter, significantly greater than the uncertainties reported by [Becker &
Kravtsov (2011)](#bib.bib15), partly reflects differences between their analysis and ours, such as our use of a fixed [79](#bib.bib79) concentration parameter (Section [3.3](#S3.SS3 "3.3 Likelihood Function ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")).

The $m\_{\mathrm{gas}}$–$m$ relation deserves some additional consideration, since the value and evolution of its normalization, $\beta\_{0,m\_{\mathrm{gas}}}=\ln f\_{\mathrm{gas}}(r\_{500})$, carry additional cosmological information ([Sasaki 1996](#bib.bib109); [Pen 1997](#bib.bib85); [Allen
et al. 2002](#bib.bib2); [Allen
et al. 2004](#bib.bib7); [Allen
et al. 2008](#bib.bib5); [Allen
et al. 2011](#bib.bib3); [Ettori
et al. 2003](#bib.bib44); [Ettori
et al. 2009](#bib.bib43); [Battaglia
et al. 2013](#bib.bib14); [Planelles
et al. 2013](#bib.bib92); [77](#bib.bib77)). In principle, this information could be used in tandem with the more precise $f\_{\mathrm{gas}}($0.8–1.2 $r\_{2500})$ measurements of [77](#bib.bib77), given a suitable model for their covariance. In practice, the low precision of our mass constraints at $r\_{500}$ for individual clusters (due to the scatter in $m\_{\mathrm{lens}}|m$) significantly limits the information available from the $m\_{\mathrm{gas}}$–$m$ relation. In addition, the measurement correlation between the two $f\_{\mathrm{gas}}$ values is negligible, since the total masses are estimated independently from different data (lensing vs. X-ray) and the gas mass measured in the 0.8–1.2 $r\_{2500}$ shell is a small fraction of that integrated within $r\_{500}$. We therefore simplify the analysis by keeping the model for $f\_{\mathrm{gas}}($0.8–1.2 $r\_{2500})$, used for the [77](#bib.bib77) data, independent of the parameters of the $m\_{\mathrm{gas}}$–$m$ relation. In addition to allowing the normalization, mass dependence and intrinsic scatter of the $m\_{\mathrm{gas}}$–$m$ relation to vary, we marginalize over a $\pm 5$ per cent uniform prior on the evolution of the normalization, of the form $f\_{\mathrm{gas}}(r\_{500},z)=f\_{\mathrm{gas}}(r\_{500},z=0)(1+\alpha\_{f}z)$. This form, and the prior itself, are identical to those used to describe the evolution in $f\_{\mathrm{gas}}($0.8–1.2 $r\_{2500})$ in [77](#bib.bib77), but $\alpha\_{f}$ is varied independently of the corresponding parameter at $r\_{2500}$. We constrain the intrinsic scatter in $m\_{\mathrm{gas}}|m$ with a uniform prior spanning 0.0–0.10, where 0.10 corresponds to the high end of the confidence interval for the fractional intrinsic scatter of $f\_{\mathrm{gas}}(r\_{500})$, measured from the [77](#bib.bib77) data (Mantz et al., in preparation).

### 3.3 Likelihood Function

The complete likelihood of the X-ray and lensing data set takes the same form as in [74](#bib.bib74),

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{L}\propto e^{-\left\langle N\_{\mathrm{det}}\right\rangle}\prod\_{i=1}^{N\_{\mathrm{det}}}\left\langle\tilde{n}\_{\mathrm{det}}{}\_{,i}\right\rangle.$ |  | (7) |

Here $\left\langle N\_{\mathrm{det}}\right\rangle$ is the expected number of cluster detections in the survey data for a given set of model parameters, accounting for the selection function. The product runs over the $N\_{\mathrm{det}}$ detected clusters, and accounts for their redshifts, survey fluxes and any follow-up measurements. Following [74](#bib.bib74), we use an abbreviated notation where $\mn@boldsymbol{x}$ stands for the true values of $z$ and $m$; $\mn@boldsymbol{y}$ stands for the intrinsic values of $\ell$, $t$, $m\_{\mathrm{gas}}$ and $m\_{\mathrm{lens}}$ (as above); and $\mn@boldsymbol{\hat{y}}$ stands for the measured values of $\mn@boldsymbol{y}$, plus the X-ray survey flux, $\hat{F}$. Similarly, $\mn@boldsymbol{\hat{x}}$ indicates measured values of $\mn@boldsymbol{x}$, although in practice we model any mass estimates as response variables of the scaling relations (i.e. components of $\mn@boldsymbol{\hat{y}}$). The per-cluster likelihood term can then be expressed as

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\left\langle\tilde{n}\_{\mathrm{det}}{}\_{,i}\right\rangle$ | $\displaystyle=$ | $\displaystyle\int d\mn@boldsymbol{x}\int d\mn@boldsymbol{y}\left\langle\frac{dN}{d\mn@boldsymbol{x}}\right\rangle\,P(\mn@boldsymbol{y}|\mn@boldsymbol{x})\,P(\mn@boldsymbol{\hat{x}\_{i}},\mn@boldsymbol{\hat{y}\_{i}}|\mn@boldsymbol{x},\mn@boldsymbol{y})$ |  | (8) |
|  |  |  | $\displaystyle\times P(I|\mn@boldsymbol{x},\mn@boldsymbol{y},\mn@boldsymbol{\hat{x}\_{i}},\mn@boldsymbol{\hat{y}\_{i}}).$ |  |

Here, $\left\langle dN/d\mn@boldsymbol{x}\right\rangle=\left\langle d^{2}N/dzdm\right\rangle$ can be calculated from the mass function and cosmic expansion history,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\left\langle\frac{d^{2}N}{dzdm}\right\rangle=M\,\frac{dV}{dz}\left\langle\frac{dn(M,z)}{dM}\right\rangle,$ |  | (9) |

where $V$ is the comoving volume as a function of redshift. The likelihood associated with the scaling relations is simply the function $P(\mn@boldsymbol{y}|\mn@boldsymbol{x})$ given in Equation [6](#S3.E6 "In 3.2 Cluster Scaling Relations ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). The remaining factors are respectively the likelihoods associated with the measurements, $P(\mn@boldsymbol{\hat{x}\_{i}},\mn@boldsymbol{\hat{y}\_{i}}|\mn@boldsymbol{x},\mn@boldsymbol{y})$, and selection function (the probability to be $I$ncluded in the data set), $P(I|\mn@boldsymbol{x},\mn@boldsymbol{y},\mn@boldsymbol{\hat{x}\_{i}},\mn@boldsymbol{\hat{y}\_{i}})$, for a particular cluster. These are written in a general form in Equation [8](#S3.E8 "In 3.3 Likelihood Function ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") and can be simplified for our purposes, as we detail below.

In the case of a cluster with a precisely determined redshift (i.e. measured spectroscopically, which is the case for all our clusters), the integral $d\mn@boldsymbol{x}=dz\,dm$ can be replaced by an integral over mass only ($dm$) at fixed $z$.99
9
This is equivalent to factoring the term associated with the redshift measurement, $P(\hat{z}\_{i}|z)$, out of $P(\mn@boldsymbol{\hat{x}\_{i}},\mn@boldsymbol{\hat{y}\_{i}}|\mn@boldsymbol{x},\mn@boldsymbol{y})$, and approximating it as a delta function. For a given parent cluster sample, our selection function is simply a function of redshift and detected X-ray survey flux; hence, the final term reduces to $P(I|z,\hat{F})$, a function that is tabulated for each of the BCS, REFLEX and Bright MACS samples ([Ebeling
et al., 1998](#bib.bib40); [Ebeling
et al., 2010](#bib.bib41); [Böhringer
et al., 2004](#bib.bib25)). Note that, as in [74](#bib.bib74), we marginalize over separate allowances for the overall completeness/purity of each cluster sample. The measurement term can be factored into survey, X-ray follow-up and lensing parts, since these three observations are independent; to be explicit,

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle P(\mn@boldsymbol{\hat{x}\_{i}},\mn@boldsymbol{\hat{y}\_{i}}|\mn@boldsymbol{x},\mn@boldsymbol{y})$ | $\displaystyle=$ | $\displaystyle P(\hat{F}|z,\ell,t)\,P(\hat{\ell},\hat{t},\hat{m}\_{\mathrm{gas}}|z,m,\ell,t,m\_{\mathrm{gas}})$ |  | (10) |
|  |  |  | $\displaystyle\times P(\hat{m}\_{\mathrm{lens}}|z,m\_{\mathrm{lens}}).$ |  |

The X-ray measurement models we employ are identical to those in [74](#bib.bib74), and we refer the interested reader there for full details. In brief, the survey flux model straightforwardly follows from the intrinsic cluster luminosity, temperature and redshift, with the appropriate K-correction, and accounts for Poisson scaling of the measurement uncertainties with true flux. The model for X-ray follow-up measurements of mass proxies accounts not only for the straightforward statistical uncertainties in each measurement and their covariance (due to being measured from the same data), but also for their aperture dependence (i.e. the difference between the aperture used in the measurement and the true value of $r\_{500}$ according to $m$ and the cosmological model).

To evaluate the likelihood associated with the lensing data for a cluster, we compare the shear profile measured by [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10)1010
10
Hence, the term $\hat{m}\_{\mathrm{lens}}$ in our equations should be interpreted as shorthand for the measured shear profile of a cluster. (specifically, using the color-cut method) to the shear profile predicted from an [79](#bib.bib79) profile with mass given by $m\_{\mathrm{lens}}$ and concentration parameter $c=4$ (consistent with the mean concentration measured in [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) and the mean population concentration in $N$-body simulations; [Neto
et al. 2007](#bib.bib81)). The profiles are measured in annuli about the X-ray center in the radial range 750 kpc to 3 Mpc (in our reference cosmological model),1111
11
This radial range is chosen to minimize sensitivity to the assumed concentration, avoid high values of shear and cluster galaxy contamination in cluster centers, and reduce the effect of possible mis-centering, as discussed in detail by [Applegate
et al. (2014)](#bib.bib10). where the annuli are chosen to contain approximately equal numbers of galaxies (at least 300). We write

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\ln P(\hat{m}\_{\mathrm{lens}}|z,m\_{\mathrm{lens}})=-\frac{1}{2}\sum\_{j}\left[\frac{\hat{g}\_{j}-g\_{j}(z,m\_{\mathrm{lens}},c=4)}{\sigma\_{g,j}}\right]^{2},$ |  | (11) |

where $\hat{g}\_{j}$ is the azimuthally averaged tangential shear measured in annulus $j$, and $\sigma\_{g,j}$ is its uncertainty, determined by bootstrapping the galaxy population in each annulus.1212
12
As described in [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10), corrections for shear calibration are applied on a per-galaxy basis, whereas corrections for contamination by cluster member galaxies are applied to the average shear measured in each annulus. The predicted shear at projected radius $\theta\_{j}$ is evaluated as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $g\_{j}(z,m\_{\mathrm{lens}},c)=\frac{\left\langle\beta\_{\mathrm{s}}\right\rangle\gamma\_{\mathrm{t}}{}\_{,\infty}(\theta\_{j};m\_{\mathrm{lens}},c)}{1-\frac{\left\langle\beta\_{\mathrm{s}}^{2}\right\rangle}{\left\langle\beta\_{\mathrm{s}}\right\rangle}\kappa\_{\infty}(\theta\_{j};m\_{\mathrm{lens}},c)},$ |  | (12) |

where $\gamma\_{\mathrm{t}}{}\_{,\infty}$ and $\kappa\_{\infty}$ are respectively the tangential shear and convergence of a source at infinite redshift due to a lens at redshift $z$ with an [79](#bib.bib79) mass distribution given by $m\_{\mathrm{lens}}$ and $c$ ([Wright &
Brainerd, 2000](#bib.bib135)). $\beta\_{\mathrm{s}}$ encodes the dependence on the redshift of the cluster and the lensed sources,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\beta\_{\mathrm{s}}=\frac{D\_{\mathrm{LS}}D\_{\mathrm{O}\infty}}{D\_{\mathrm{OS}}D\_{\mathrm{L}\infty}},$ |  | (13) |

where the terms on the right hand side are variously the angular diameter distances separating the lens (L), source (S), observer (O), and a fictitious source at infinite redshift ($\infty$). Note that these terms introduce a cosmology dependence to the predicted shear. The averages of $\beta\_{\mathrm{s}}$ and $\beta\_{\mathrm{s}}^{2}$ that appear in Equation [12](#S3.E12 "In 3.3 Likelihood Function ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") are evaluated using the distribution of galaxy redshifts in the COSMOS field, after replicating the same catalog selection cuts applied to each cluster field, such as the removal of the cluster red sequence. More details can be found in [Applegate
et al. (2014)](#bib.bib10).

## 4 Cosmological Results

Our results are produced using cosmomc1313
13
<http://cosmologist.info/cosmomc/> ([Lewis &
Bridle 2002](#bib.bib62); October 2013 version), appropriately modified to evaluate the likelihoods of the $f\_{\mathrm{gas}}$1414
14
<http://www.slac.stanford.edu/~amantz/work/fgas14/> and cluster counts data. Cosmological calculations were performed using the camb1515
15
<http://www.camb.info/> package of [Lewis, Challinor & Lasenby (2000)](#bib.bib63), suitably modified to implement the evolving-$w$ model of [Rapetti
et al. (2005)](#bib.bib96), including the corresponding dark energy density perturbations (see also [77](#bib.bib77)).

When analyzing cluster data alone, we incorporate Gaussian priors on the Hubble parameter, $h=0.738\pm 0.024$ ([Riess
et al., 2011](#bib.bib104)), and mean baryon density, $100\,\Omega\_{\mathrm{b}}h^{2}=2.202\pm 0.045$ ([Cooke
et al., 2014](#bib.bib33)); we additionally fix the scalar spectral index of density perturbations to $n\_{\mathrm{s}}=0.95$ in this case.1616
16
Since the cluster data probe the amplitude of the power spectrum over a very limited range of scales, there is a degeneracy between $n\_{\mathrm{s}}$ and $\sigma\_{8}$ constraints from clusters alone. However, varying $n\_{\mathrm{s}}$ within the range allowed by CMB data ($\Delta n\_{\mathrm{s}}\sim 0.03$) would result in a sub-per-cent shift in our clusters-only value of $\sigma\_{8}$ ([74](#bib.bib74)). When CMB data are included in the fit, these three parameters are allowed to vary freely, along with the optical depth to reionization. With the exception of Sections [4.2](#S4.SS2 "4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") and [4.4](#S4.SS4 "4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), we assume a minimal value of the species-summed neutrino mass, $\sum m\_{\nu}=0.056\mathrm{\,eV}$,1717
17
For this mass, our results are not sensitive to the distinction between, e.g., models with a single massive neutrino species and those with three degenerate neutrinos. and the standard effective number of relativistic species, $N\_{\mathrm{eff}}=3.046$.

In Section [4.1](#S4.SS1 "4.1 Cluster Constraints on Ω_m and 𝜎_8 ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), we begin by discussing our constraints on $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$, two parameters on which clusters with accurately calibrated masses can provide powerful and largely model-independent constraints, and compare these with results from independent work. Section [4.2](#S4.SS2 "4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") examines the implications of these results for cosmological constraints on neutrino masses, which depend sensitively on the accuracy of $\sigma\_{8}$ measurements. Our constraints on dark energy parameters are presented in Section [4.3](#S4.SS3 "4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). Sections [4.4](#S4.SS4 "4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") and [4.5](#S4.SS5 "4.5 Constraints on Non-Gaussianity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") respectively investigate constraints on departures from GR and non-Gaussianities in the initial perturbation field.

### 4.1 Cluster Constraints on $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$

Within the standard class of cosmological models, constraints on $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ from cluster counts data at low redshifts are largely independent of the dark energy model assumed (e.g. [Vikhlinin
et al. 2009](#bib.bib127), [74](#bib.bib74)). Constraints on these two parameters are typically degenerate, although data that probe the shape of the mass function or (more pertinently for this study) the growth of structure with time can break the degeneracy. Alternatively, or in addition, the gas mass fraction for relaxed clusters can be used to break the degeneracy by independently constraining $\Omega\_{\mathrm{m}}$. Throughout this section, we use the $f\_{\mathrm{gas}}$ data of [77](#bib.bib77) in conjunction with the cluster counts and follow-up data (henceforth referring to their combination simply as “clusters”); Section [5.1](#S5.SS1 "5.1 The Role of Follow-up Data ‣ 5 Discussion ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") discusses the role of these individual components in more detail.

In the context of combining multiple cosmological probes, $\Omega\_{\mathrm{m}}$ is generally tightly constrained in any case. For this reason cluster-counts results are often reported in the form of a power law corresponding to the minor axis of the $\Omega\_{\mathrm{m}}$–$\sigma\_{8}$ confidence region, i.e. on the combination $\sigma\_{8}\,\Omega\_{\mathrm{m}}^{\alpha}$, where $\alpha$ encodes the slope of the degeneracy. From the cluster data, we find $\sigma\_{8}(\Omega\_{\mathrm{m}}/0.3)^{0.17}=0.81\pm 0.03$;1818
18
Our approach to choosing the exponent of this expression is to minimize the correlation between $\ln(\sigma\_{8}\Omega\_{\mathrm{m}}^{-\alpha})$ and $\ln(\sigma\_{8}\Omega\_{\mathrm{m}}^{1/\alpha})$ in the Markov chains from our analysis. Strictly speaking, the resulting value, $\alpha\sim 0.17$, does not describe the minor axis of the confidence region (this would correspond to a slightly steeper value, $\alpha\sim 0.23$), but rather generates the curves describing the best-fitting value and uncertainty of $\sigma\_{8}$ as a function of $\Omega\_{\mathrm{m}}$. Note that these values of $\alpha$ do not correspond simply to effective redshift and mass limits of the data set (e.g. [Weinberg
et al. 2013](#bib.bib132)) because we perform this analysis after marginalizing over systematic uncertainties, which limit the constraints on both $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$. In addition, the cosmological dependences that enter into the measurement of cluster masses from real data, whether from X-ray or lensing observations, generally preclude such a simple interpretation. the one-dimensional, marginalized constraints are $\Omega\_{\mathrm{m}}=0.26\pm 0.03$ and $\sigma\_{8}=0.83\pm 0.04$. These results are identical for $\Lambda$CDM (with and without curvature) and flat constant-$w$ models. Even for models with free neutrino mass (Section [4.2](#S4.SS2 "4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")), as well as for flat evolving-$w$ models (Section [4.3](#S4.SS3 "4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")), the cluster constraint on the width of the $\Omega\_{\mathrm{m}}$–$\sigma\_{8}$ ellipse remains equivalent to our result for the flat $\Lambda$CDM case (although the slope of the degeneracy changes slightly). As expected, we find that the cluster constraints on $\sigma\_{8}$ are limited by the precision of our overall mass calibration, parametrized by our prior on the normalization of the $m\_{\mathrm{lens}}$–$m$ relation (Section [3.2](#S3.SS2 "3.2 Cluster Scaling Relations ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")). The a posteriori correlation of these parameters is such that a 10 per cent shift in the mass calibration implies a nearly 20 per cent shift in $\sigma\_{8}$ at fixed $\Omega\_{\mathrm{m}}$.

Figure 1: 
Constraints on $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ from this work (purple shading) and earlier works by these authors (yellow and green shading; [Mantz
et al. 2008](#bib.bib73), [74](#bib.bib74)), accounting for systematic uncertainties. Dark and light shading respectively indicate the 68.3 and 95.4 per cent confidence regions. The underlying cluster survey data set is nearly identical across all three generations of results, but the approaches to calibrating cluster masses and the associated scaling relations have incorporated progressively better control of systematic uncertainties, leading to significantly tighter and more robust constraints. Contemporaneous priors on $h$ and $\Omega\_{\mathrm{b}}h^{2}$ are included in each case (the improvement in these priors has negligible effect compared to the mass calibration). These results are essentially identical for flat and non-flat $\Lambda$CDM models, and flat constant-$w$ dark energy models. In evolving-$w$ models and models with the neutrino mass free, the shape of the confidence region changes slightly, but its width ($\sigma\_{8}$ at fixed $\Omega\_{\mathrm{m}}$) remains the same.

Figure [1](#S4.F1 "Figure 1 ‣ 4.1 Cluster Constraints on Ω_m and 𝜎_8 ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") shows the joint constraints on $\sigma\_{8}$ and $\Omega\_{\mathrm{m}}$ from clusters in the present analysis (purple shading) along with previous results from these authors, namely [Mantz
et al. (2008, yellow banana)](#bib.bib73) and [74](#bib.bib74) (green shading), to emphasize the extent to which systematic uncertainties in mass calibration have decreased over time. In the first case, [Mantz
et al. (2008)](#bib.bib73) directly used hydrostatic mass estimates from the X-ray analysis of [Reiprich &
Böhringer (2002)](#bib.bib102), regardless of the clusters’ dynamical states, marginalizing over generous allowances for the bias and scatter of these estimates with respect to the true masses (20 per cent uncertainties in each). [74](#bib.bib74) instead employed gas mass as a proxy for total mass, calibrating this relation using a hydrostatic X-ray analysis of relatively relaxed clusters by [Allen
et al. (2008)](#bib.bib5), and marginalizing over systematic allowances for non-thermal support and instrument calibration at the $\sim 15$ per cent level. As discussed above, the present work is calibrated to a gravitational lensing data set, providing $\sim 8$ per cent precision on the mass calibration ([130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10)). With only minor differences, these three results rest on the same underlying X-ray cluster catalogs. However, given their very different mass calibration strategies, the level of agreement between them, particularly considering the blind nature of the [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) analysis, is encouraging.

Comparing our current results with [74](#bib.bib74), we note that in both cases the $\Omega\_{\mathrm{m}}$ constraint is largely dictated by $f\_{\mathrm{gas}}$ data. The inclusion of a robust mass calibration in both the cluster counts and $f\_{\mathrm{gas}}$ analyses has led to significant improvement in the constraints on both parameters shown here,1919
19
Improvements in the modeling of the gas depletion in clusters also contribute to the improved $\Omega\_{\mathrm{m}}$ constraint from $f\_{\mathrm{gas}}$ data; see [77](#bib.bib77). nearly a factor of two reduction in the area of the 95.4 per cent confidence region.

Figure 2: 
Left: Constraints from our cluster data (with standard priors on $h$ and $\Omega\_{\mathrm{b}}h^{2}$) are compared with results from WMAP and Planck+WP CMB data, assuming a flat $\Lambda$CDM cosmology with minimal neutrino mass (assuming the normal mass hierarchy). Dark and light shading respectively indicate the 68.3 and 95.4 per cent confidence regions, including systematic uncertainties. The three sets of constraints are mutually consistent.
Right: A number of marginalized constraints on $\sigma\_{8}$ from the literature are compared at a common, concordance value of $\Omega\_{\mathrm{m}}=0.3$. Results from clusters are shown by circles (X-ray surveys), squares (optical surveys) or triangles (SZ surveys), with crosses showing CMB constraints. The error bars include each author’s estimate of the systematic uncertainties whenever possible (see text for details and references). The shaded, horizontal band reflects the 68.3 per cent confidence interval for our new result (filled circle), $\sigma\_{8}(\Omega\_{\mathrm{m}}/0.3)^{0.17}=0.81\pm 0.03$. The mass calibration provided by the (blinded) [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) lensing analysis (reflected by our $\sigma\_{8}$ value) is in agreement with previous work by the same group ([Mantz
et al. 2008](#bib.bib73); [74](#bib.bib74)), within the quoted statistical plus systematic uncertainties, and provides good agreement in $\sigma\_{8}$ with CMB measurements, but is offset from some other cluster analyses.

The left panel of Figure [2](#S4.F2 "Figure 2 ‣ 4.1 Cluster Constraints on Ω_m and 𝜎_8 ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") compares the new cluster constraints to results from WMAP (blue shading) and Planck+WP (gray shading) CMB data for flat $\Lambda$CDM models. Our results are consistent with either CMB data set. In particular, there is no tension between our cluster constraints and the 1-year Planck+WP CMB results, in contrast to the Planck analysis of cluster counts based on their own Sunyaev-Zel’dovich (SZ) effect cluster detections ([Planck
Collaboration 2013d](#bib.bib90); see also [von der Linden
et al. 2014b](#bib.bib131)).

Our result for $\sigma\_{8}$ is compared to those of a selection of other galaxy cluster studies in the right panel of Figure [2](#S4.F2 "Figure 2 ‣ 4.1 Cluster Constraints on Ω_m and 𝜎_8 ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). Given the parameter degeneracy, it is instructive to compare $\sigma\_{8}$ constraints for a fixed, canonical value of $\Omega\_{\mathrm{m}}$, in this case 0.3.2020
20
This choice is motivated by the tight constraints on $\Omega\_{\mathrm{m}}\approx 0.3$ obtained from the combination of available cosmological data, essentially independent of the model assumed (see Table [2](#S4.T2 "Table 2 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")). In most cases (exceptions are noted below), the uncertainties on $\sigma\_{8}$ at fixed $\Omega\_{\mathrm{m}}$ are reported to be limited by the absolute cluster mass calibration.2121
21
Where the authors provide an estimate of systematic uncertainty in their results, we include it in the figure, even if their “baseline” reported results include only statistical errors (e.g. [Vikhlinin
et al. 2009](#bib.bib127); [Planck
Collaboration 2013d](#bib.bib90)). When systematic allowances are included in the baseline results, but more conservative allowances are also considered (e.g. in a discussion section), we show the baseline results (e.g. [Rozo
et al. 2010](#bib.bib105); [Benson
et al. 2013](#bib.bib17)). The exception is [Henry
et al. (2009)](#bib.bib51), who do not explicitly account for systematic uncertainty in the mass calibration (the precision of constraints on the scaling relations limits the $\sigma\_{8}$ measurement in this case). The values and error bars in the figure thus primarily reflect the mass calibration used in each study and the adopted uncertainty in that calibration, rather than, e.g., differences in the analysis methods used. Note that the present work (shaded region) is the first to self-consistently incorporate a mass calibration from weak lensing mass estimates, including a rigorous quantification of all systematic uncertainties.2222
22
A common practice has been to estimate rough systematic uncertainties by comparing hydrostatic mass estimates to lensing estimates, using a small number of clusters and assuming a fixed cosmology. Note that the X-ray/lensing mass ratio inferred from data in reality does depend on cosmological parameters (Applegate et al., in prep.). Note also that in several cases hydrostatic mass calibrations have been implemented as priors on scaling relations, rather than by directly incorporating mass estimates and simultaneously fitting the cosmology and scaling relation models. This approach makes it virtually impossible to properly account for all covariances among the parameters.

Also shown in the right panel of Figure [2](#S4.F2 "Figure 2 ‣ 4.1 Cluster Constraints on Ω_m and 𝜎_8 ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") are the constraints from CMB anisotropy power spectra measured from WMAP and Planck+WP data. For comparison to the similar figure in [Planck
Collaboration (2013d, their Figure 10)](#bib.bib90), note that here we show constraints on $\sigma\_{8}$ at a fixed value of $\Omega\_{\mathrm{m}}=0.3$, *not* constraints on the combination $\sigma\_{8}(\Omega\_{\mathrm{m}}/0.27)^{0.3}$. The difference is negligible for cluster data but significant in the case of CMB data, for which that particular power-law approximately corresponds to the long axis of the parameter degeneracy (i.e. the least constrained direction). Given that the combination of available cosmological probes currently constrains $\Omega\_{\mathrm{m}}$ to be $\approx 0.3$ to a precision of $\sim 0.015$, essentially independent of the cosmological model assumed (see Table [2](#S4.T2 "Table 2 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")), taking a fixed value of $\Omega\_{\mathrm{m}}$ is arguably a more sensible choice for evaluating the tension, or lack thereof, among the cluster and CMB results.

The first three points shown in the figure are those of [Mantz
et al. (2008)](#bib.bib73), [74](#bib.bib74) and this work, discussed above. Turning to the other results shown based on X-ray selected clusters, [Henry
et al. (2009)](#bib.bib51) analyzed a subset of the HIFLUGCS sample of [Reiprich &
Böhringer (2002)](#bib.bib102), calibrating the mass scaling relations by jointly fitting early weak lensing measurements, Chandra X-ray hydrostatic masses and simulated clusters, with the results dominated by the X-ray mass estimates and simulations. The claimed precision on the mass calibration from this procedure is $<4$ per cent with no additional systematic uncertainty accounted for; the reported $\sigma\_{8}$ constraints are instead limited by uncertainty in the slope and scatter of the mass–temperature relation. The analysis of [Vikhlinin
et al. (2009)](#bib.bib127) employs a combination of low-redshift RASS clusters and clusters at $0.35<z<0.9$ from the 400 square degree ROSAT catalog ([Burenin
et al., 2007](#bib.bib29)). Their mass calibration was based on hydrostatic estimates from Chandra data, with a systematic uncertainty of $\sim 9$ per cent estimated by comparing to the lensing data available at the time ([Hoekstra, 2007](#bib.bib54); [Zhang
et al., 2008](#bib.bib137)), assuming a fixed cosmology.

The results of [Rozo
et al. (2010)](#bib.bib105) are based on the optically selected MaxBCG catalog, derived from SDSS. Their mass calibration is from a stacked lensing analysis of the SDSS data, with a 6 per cent systematic allowance assigned based on the level of agreement between two analyses of the lensing data (systematics common to both analyses are not accounted for2323
23
Moreover, the 6 per cent agreement between the two lensing studies was reached only after correcting one of the methods by 18 per cent. While the motivation for the correction is ultimately well justified, it is difficult to completely dismiss the possibility of confirmation bias in such a case.). Due to the steepness of the mass function and the nature of stacked analysis, this adopted calibration uncertainty applies most directly to the low-richness end of the cluster sample. The $\sigma\_{8}$ constraints from this analysis are most dependent on the masses of high-richness clusters, where the statistical uncertainty is greater. The error budget for $\sigma\_{8}$ is predominantly determined by this statistical component (see [Rozo
et al. 2010](#bib.bib105)).

The SZ cluster constraints shown include those from the SPT, ACT and Planck cluster surveys. The SPT analysis of [Benson
et al. (2013)](#bib.bib17) ultimately uses the same X-ray mass calibration as that of [Vikhlinin
et al. (2009)](#bib.bib127), and indeed the agreement between the two results is very close; the SPT constraints are slightly less tight due to an allowance for evolution in the mass calibration between the low-redshift calibration sample of [Vikhlinin
et al. (2009)](#bib.bib127) and the typical redshifts of SPT clusters. The ACT results shown in Figure [2](#S4.F2 "Figure 2 ‣ 4.1 Cluster Constraints on Ω_m and 𝜎_8 ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") use a mass calibration derived from galaxy velocity dispersion measurements, with an adopted systematic uncertainty of 15 per cent in mass ([Hasselfield
et al., 2013](#bib.bib48); [Sifón
et al., 2013](#bib.bib117)). In this case, the particularly large uncertainties in $\sigma\_{8}$ are most likely dominated by the small size of the data set used to constrain the SZ scaling relation (7 clusters with dynamical masses) rather than the 15 per cent prior on the mass calibration itself. The Planck cluster results are marginalized over a uniform prior of ${}^{+20}\_{-10}$ per cent in the mass calibration (for comparison to the Gaussian priors used elsewhere, this has a standard deviation of $\sim 8.7$ per cent). For their main analysis, which does not account for this systematic uncertainty, the error bar is approximately half as large. The mass calibration in this case is tied to hydrostatic estimates based on XMM-Newton X-ray data.

Since the systematic uncertainties associated with the cluster mass scale have been only rough estimates in previous works, the right panel of Figure [2](#S4.F2 "Figure 2 ‣ 4.1 Cluster Constraints on Ω_m and 𝜎_8 ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") is in some sense more illustrative than informative. We would argue that earlier analyses based on X-ray masses for relaxed clusters should have included systematic uncertainties in their mass calibrations no smaller than the $\sim 15$ per cent allowance included in [74](#bib.bib74), and thus have comparable uncertainty in $\sigma\_{8}$, and those that used hydrostatic masses for even unrelaxed clusters should include even larger uncertainties. Note that this does not necessarily imply better agreement among the cluster results themselves, given the considerable overlap in the clusters used for these hydrostatic mass calibrations (generally X-ray bright ROSAT clusters at redshifts $<0.3$). This only underscores the utility of mass estimates that are independent of X-ray detector calibrations and cluster dynamical state.

Apart from this work, the other major result based on a weak lensing calibration, and the only other result (excepting [Hasselfield
et al. 2013](#bib.bib48)) not ultimately based on X-ray hydrostatic mass estimates, is that of [Rozo
et al. (2010)](#bib.bib105). While their adopted 6 per cent uncertainty in the mass calibration is arguably likely to be underestimated, it is interesting that their $\sigma\_{8}$ measurement is the closest to ours of all the independent cluster results considered here.

We note that our value of $\sigma\_{8}$ is marginally larger than some recent results from ground- and space-based cosmic shear and weak lensing tomography. For example, [Kilbinger
et al. (2013)](#bib.bib59) find $\sigma\_{8}=0.74\pm 0.03$ (again at fixed $\Omega\_{\mathrm{m}}=0.3$) from a 2-dimensional cosmic shear analysis of CFHTLenS data.2424
24
[Heymans
et al. (2013)](#bib.bib52) obtained a nearly identical constraint, $0.74\_{-0.04}^{+0.03}$, from a tomographic analysis of the CFHTLenS data. The tomographic lensing analysis of HST COSMOS data by [Schrabback
et al. (2010)](#bib.bib111) yields a value of $0.75\pm 0.08$, which is nominally lower than our constraints, but consistent within the uncertainties.

### 4.2 Constraints on Neutrino Mass

For a given amplitude of the matter power spectrum at the surface of last scattering, the predicted amplitude at low redshifts depends on the species-summed mass of neutrinos, $\sum m\_{\nu}$, with larger values of $\sum m\_{\nu}$ corresponding to smaller values of $\sigma\_{8}$ (for a review, see [Lesgourgues &
Pastor 2006](#bib.bib61)). Exploiting this degeneracy, constraints on $\sigma\_{8}$ from clusters can be used in conjunction with CMB data (and other cosmological probes) to place limits on $\sum m\_{\nu}$ that are considerably stronger than current laboratory experiments (e.g. [Allen
et al. 2011](#bib.bib3)). However, accurate constraints can only be obtained to the extent that the cluster and CMB measurements of the power spectrum amplitude are unbiased. Over the years, the combination of different data sets has led to gradually tightening upper limits on $\sum m\_{\nu}$, including occasional claims of a preference for $\sum m\_{\nu}>0$ (e.g. [Allen
et al. 2003](#bib.bib6); [Tegmark
et al. 2004](#bib.bib121); [Tereno
et al. 2009](#bib.bib122); [Vikhlinin
et al. 2009](#bib.bib127); [Mantz
et al. 2010](#bib.bib76); [Reid
et al. 2010](#bib.bib101); [Thomas
et al. 2010](#bib.bib123); [Riemer-Sorensen
et al. 2012](#bib.bib103); [Benson
et al. 2013](#bib.bib17); [Burenin 2013](#bib.bib28); [Reichardt
et al. 2013](#bib.bib99); [Planck
Collaboration 2013d](#bib.bib90); [Beutler
et al. 2014a](#bib.bib20); [Dvorkin
et al. 2014](#bib.bib39)).

Table 1: 
Posterior modes and 95.4 per cent confidence upper limits on $\sum m\_{\nu}$ (in eV) from the combination of cluster, CMB, supernova and BAO data. The combined data sets include either WMAP (CombWM) or Planck+WP (CombPl) all-sky CMB data; ACT and SPT CMB data are included in both cases. In addition to models with $r$ free, we show results employing a prior, $r=0.20^{+0.07}\_{-0.05}$, based on results from the [BICEP2
Collaboration (2014)](#bib.bib22).

| Model | CombWM | | CombPl | |
| --- | --- | --- | --- | --- |
|  | Mode | 95.4% lim. | Mode | 95.4% lim. |
| flat $\Lambda$CDM | 0.11 | 0.33 | 0.00 | 0.22 |
| $\Omega\_{k}$ free | 0.02 | 0.41 | 0.00 | 0.29 |
| $w\_{0}$ free | 0.00 | 0.46 | 0.08 | 0.38 |
| $N\_{\mathrm{eff}}$ free | 0.05 | 0.31 | 0.06 | 0.29 |
| $r$ free | 0.08 | 0.32 | 0.00 | 0.24 |
| $r$ prior | 0.19 | 0.41 | 0.02 | 0.25 |

Figure 3: 
Left: Marginalized posterior distributions for $\sum m\_{\nu}$, assuming a flat $\Lambda$CDM background and standard value of $N\_{\mathrm{eff}}$, from the combination of cluster, CMB, supernova and BAO data. The combined data include either Planck+WP (solid line) or WMAP (dashed line) all-sky CMB data; ACT and SPT CMB data are included in both cases. Vertical, dotted lines indicate the minimum values of $\sum m\_{\nu}$ implied by flavor oscillation measurements for the normal and inverted hierarchies (0.056 and 0.095$\mathrm{\,eV}$, respectively). Both data combinations are consistent with $\sum m\_{\nu}=0$.
Right: For the combination using WMAP CMB data (see Appendix [B](#A2 "Appendix B Figures Using Planck Data ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") for the equivalent Planck+WP figure), we show 68.3 and 95.4 per cent confidence regions on $\sum m\_{\nu}$ and $\sigma\_{8}$ for the flat $\Lambda$CDM+$\sum m\_{\nu}$ (“vanilla”) model (yellow/orange shading). The other regions correspond to 95.4 confidence (only) for models with an additional degree of freedom: spatial curvature (blue), the dark energy equation of state (red), the effective number of relativistic species (purple), or the amplitude of primordial tensor perturbations (green). In the latter case, we include the prior $r=0.20^{+0.07}\_{-0.05}$, based on measurements by the [BICEP2
Collaboration (2014)](#bib.bib22). The constraints when not including this additional prior are somewhat tighter (Table [1](#S4.T1 "Table 1 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")).

The [Planck
Collaboration (2013d)](#bib.bib90) recently published constraints on $\sigma\_{8}$ from their SZ-detected clusters which, when combined with Planck+WP CMB data and BAO, imply a $>2\sigma$ rejection of $\sum m\_{\nu}=0$. However, [von der Linden
et al. (2014b)](#bib.bib131) have shown that the mass calibration used by the Planck team is biased low compared with the [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) lensing measurements. Our analysis of X-ray selected clusters, using the [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) mass calibration, produces a $\sigma\_{8}$ value that is consistent with both Planck+WP and WMAP CMB measurements when assuming a minimal neutrino mass. We therefore expect that the combination of our data with either CMB data set will be fully consistent with minimal neutrino mass.

To quantify this, we first consider the simple case of a flat $\Lambda$CDM model with the standard effective number of relativistic species ($N\_{\mathrm{eff}}=3.046$) and with $\sum m\_{\nu}$ as a free parameter. Throughout this section, we model the three standard model neutrinos as being degenerate in mass. The posterior distributions for $\sum m\_{\nu}$, marginalizing over a flat $\Lambda$CDM background, are shown in the left panel of Figure [3](#S4.F3 "Figure 3 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") for the combinations of cluster, CMB, supernova and BAO data, where either WMAP (dashed line) or Planck+WP (solid line) data are included in the combination (ACT and SPT CMB data are always included). Both results are consistent with the minimum summed neutrino mass implied by flavor oscillation data for either the normal or inverted hierarchies (vertical, dotted lines), or indeed with $\sum m\_{\nu}=0$. For the data combination including WMAP, the 68.3 and 95.4 per cent confidence intervals are $\sum m\_{\nu}=0.11\pm 0.10\mathrm{\,eV}$ and $0.11\_{-0.11}^{+0.22}\mathrm{\,eV}$; the corresponding limits for the combination including Planck+WP data are $\sum m\_{\nu}=0\_{-0.00}^{+0.12}\mathrm{\,eV}$ and $0\_{-0.00}^{+0.22}\mathrm{\,eV}$. Using our gravitational lensing cluster mass calibration, there is thus no evidence for non-minimal or even non-zero neutrino mass in the best current cosmological data.

Table [1](#S4.T1 "Table 1 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") shows the posterior modes and 95.4 per cent upper limits on $\sum m\_{\nu}$ when additional cosmological parameters are free to vary: either global curvature ($\Omega\_{k}$), the dark energy equation of state (constant-$w$), the effective number of relativistic species ($N\_{\mathrm{eff}}$), or the amplitude of the primordial tensor perturbation spectrum ($r$, the tensor-to-scalar ratio). In the latter case, we list constraints with $r$ completely free as well as results including the recent constraint from BICEP2, $r=0.20^{+0.07}\_{-0.05}$, as an additional prior,2525
25
To be precise, we adopt a Gaussian prior of $-1.55\pm 0.28$ on $\ln(r)$, which provides a good approximation to the posterior distribution for $r$ presented by the [BICEP2
Collaboration (2014)](#bib.bib22). Forgoing the prior while leaving $r$ free actually tightens the limits on $\sum m\_{\nu}$ somewhat, because the remaining data prefer a smaller value of $r$ than BICEP2 measures (e.g. [Story
et al. 2013](#bib.bib119); see also e.g. [Flauger
et al. 2014](#bib.bib45); [Mortonson &
Seljak 2014](#bib.bib78) and references therein). fixing the tensor spectral index to zero as in the BICEP2 analysis ([BICEP2
Collaboration, 2014](#bib.bib22)). Figure [3](#S4.F3 "Figure 3 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") shows the 95.4 per cent confidence regions for each case, from the full combination of data (including WMAP CMB data; see Appendix [B](#A2 "Appendix B Figures Using Planck Data ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") for the equivalent Planck+WP figure). The constraints are weaker in the more general models, particularly when $w$ is allowed to vary. Even in this case, however, there remains a degeneracy between $\sum m\_{\nu}$ and $\sigma\_{8}$. We comment on the prospects for improving neutrino mass limits further through tighter $\sigma\_{8}$ measurements in Section [5.2](#S5.SS2 "5.2 The Benefits of Improved Weak Lensing Data ‣ 5 Discussion ‣ Weighing the Giants IV: Cosmology and Neutrino Mass").

Of all the scenarios that we consider, the only ones that show even a marginal preference ($\ {\raise-3.22916pt\hbox{$\mathrel{\mathop{\kern 0.0pt\sim}\limits^{>}}$}}\ 1\sigma$) for non-zero neutrino mass are the basic flat $\Lambda$CDM+$\sum m\_{\nu}$ model ($1.1\sigma$ significance) and the model including tensor modes and a BICEP2 prior ($1.5\sigma$ significance), both when using WMAP CMB data. Keeping in mind that the tightest limits on $\sum m\_{\nu}$ come from the combination of a cluster $\sigma\_{8}$ measurement with CMB data, our null result stands in stark contrast to works that have adopted lower cluster mass calibrations (i.e. smaller values of $\sigma\_{8}$) and subsequently claimed detections of neutrino mass from cosmological data (e.g., recently, [Burenin 2013](#bib.bib28); [Planck
Collaboration 2013d](#bib.bib90); [Beutler
et al. 2014a](#bib.bib20); [Dvorkin
et al. 2014](#bib.bib39)).

Figure 4: 
Constraints on constant-$w$ dark energy models with minimal neutrino mass from our cluster data (with standard priors on $h$ and $\Omega\_{\mathrm{b}}h^{2}$) are compared with results from CMB (WMAP, ACT and SPT), supernova and BAO (also including priors on $h$ and $\Omega\_{\mathrm{b}}h^{2}$) data, and their combination. The priors on $h$ and $\Omega\_{\mathrm{b}}h^{2}$ are not included in the combined constraints. Dark and light shading respectively indicate the 68.3 and 95.4 per cent confidence regions, accounting for systematic uncertainties.

### 4.3 Constraints on Dark Energy Models

Figure 5: 
Constraints on $\Lambda$CDM models (including curvature) with minimal neutrino mass from our cluster data (with standard priors on $h$ and $\Omega\_{\mathrm{b}}h^{2}$) are compared with results from CMB (WMAP, ACT and SPT), supernova and BAO (also including priors on $h$ and $\Omega\_{\mathrm{b}}h^{2}$) data, and their combination. The priors on $h$ and $\Omega\_{\mathrm{b}}h^{2}$ are not included in the combined constraints. Dark and light shading respectively indicate the 68.3 and 95.4 per cent confidence regions, accounting for systematic uncertainties. The dotted line denotes spatially flat models.

We next investigate the constraints on dark energy models afforded by the cluster data alone, and their combination with other cosmological probes. The results appear in Table [2](#S4.T2 "Table 2 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). For spatially flat, constant-$w$ models, our cluster data alone provide identical constraints on $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ to the flat $\Lambda$CDM case, and additionally constrain the equation of state: $w=-0.98\pm 0.15$. Note that the precision of the $w$ constraint is identical to what was obtained from the combination of cluster counts and $f\_{\mathrm{gas}}$ data by [74](#bib.bib74) (i.e. without lensing data) as we would expect; the addition of weak lensing data for 50 clusters significantly enhances constraints on $\sigma\_{8}$, but (due to the relatively low precision of lensing masses for individual clusters) has not tightened constraints on the redshift-dependent signal that determines $w$. Even so, the constraints on $w$ are impressive and competitive with the best other cosmological probes (below), as well as independent results from X-ray ([Vikhlinin
et al. 2009](#bib.bib127); see also [Burenin &
Vikhlinin 2012](#bib.bib30)) and SZ-selected clusters ([Benson
et al., 2013](#bib.bib17)).

The left panel of Figure [4](#S4.F4 "Figure 4 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") shows the constraints in the $\sigma\_{8}$–$w$ plane from clusters alone, CMB data alone, and the combination of clusters, CMB, supernova and BAO data for constant-$w$ models. (For figures in this section, “CMB” refers to the combination of WMAP data with ACT and SPT power spectra. Figures obtained using Planck+WP data instead of WMAP are qualitatively and quantitatively similar, and appear in Appendix [B](#A2 "Appendix B Figures Using Planck Data ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") for completeness; see also Table [2](#S4.T2 "Table 2 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass").) The joint constraints on $\Omega\_{\mathrm{m}}$ and $w$ from the various data sets are shown in the right panel of Figure [4](#S4.F4 "Figure 4 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). From the combination of data, we obtain $w=-0.99\pm 0.06$ ($-1.03\pm 0.06$ for the combination using Planck+WP data).

Table 2: 
Marginalized (one-dimensional) best-fitting values and 68.3 per cent maximum-likelihood confidence intervals for the parameters of various dark energy models, including systematic uncertainties. The parametrization of the equation of state is defined in Section [3.1](#S3.SS1 "3.1 Cosmological Model ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). The “Clusters” data incorporates X-ray survey data, X-ray follow-up observations (providing mass proxies in general and $f\_{\mathrm{gas}}$ measurements for relaxed clusters), and weak lensing data ([130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10)). The “CombWM” combination of data refers to the union of our cluster data set with CMB power spectra from WMAP ([Hinshaw
et al., 2013](#bib.bib53)), ACT ([Das
et al., 2014](#bib.bib36)) and SPT ([Keisler
et al., 2011](#bib.bib57); [Reichardt
et al., 2012](#bib.bib98); [Story
et al., 2013](#bib.bib119)), the Union 2.1 compilation of type Ia supernovae ([Suzuki
et al., 2012](#bib.bib120)), and baryon acoustic oscillation measurements at $z=0.106$ ([Beutler
et al., 2011](#bib.bib18)), $z=0.35$ ([Padmanabhan
et al., 2012](#bib.bib84)) and $z=0.57$ ([Anderson
et al., 2014](#bib.bib9)). “CombPl” is identical, with the exception that 1-year Planck data (plus WMAP polarization; [Planck
Collaboration 2013c](#bib.bib89)) are used in place of the complete 9-year WMAP data. The clusters-only constraints incorporate standard priors on $h$ and $\Omega\_{\mathrm{b}}h^{2}$ (Section [2](#S2 "2 Data ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"); [Riess
et al. 2011](#bib.bib104); [Cooke
et al. 2014](#bib.bib33)). Parameters listed with no error bars for a given model are fixed. Parameters with no value listed are not relevant, given the other parameters that are fixed in that model. For the models in which $w\_{a}$ is a free parameter (bottom section of table), there is no sensitivity to the transition time parameterized by $a\_{\mathrm{tr}}$; therefore, $a\_{\mathrm{tr}}$ is either fixed (to 0.5) or is marginalized over the range 0.5 to 0.95 (indicated by the “—” symbol in the $a\_{\mathrm{tr}}$ column). The last column indicates in which figure, if any, the corresponding results are displayed.

| Data | $\sigma\_{8}$ | $\Omega\_{\mathrm{m}}$ | $\Omega\_{\mathrm{DE}}$ | $10^{3}\Omega\_{k}$ | $w\_{0}$ | $w\_{a}$ | $w\_{\mathrm{et}}$ | $a\_{\mathrm{tr}}$ | Fig. |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Clusters | $0.830\pm 0.035$ | $0.259\pm 0.030$ |  | 0 | $-1$ | 0 |  |  | [1](#S4.F1 "Figure 1 ‣ 4.1 Cluster Constraints on Ω_m and 𝜎_8 ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") |
| Clusters | $0.830\pm 0.035$ | $0.261\pm 0.032$ | $0.728\pm 0.115$ | $8\pm 110$ | $-1$ | 0 |  |  | [5](#S4.F5 "Figure 5 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") |
| CombWM | $0.814\pm 0.019$ | $0.294\pm 0.010$ | $0.709\pm 0.011$ | $-3\pm 4$ | $-1$ | 0 |  |  | [5](#S4.F5 "Figure 5 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") |
| CombPl | $0.823\pm 0.013$ | $0.302\pm 0.009$ | $0.698\pm 0.009$ | $0\pm 4$ | $-1$ | 0 |  |  | [10](#A2.F10 "Figure 10 ‣ Appendix B Figures Using Planck Data ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") |
| Clusters | $0.831\pm 0.036$ | $0.261\pm 0.031$ |  | 0 | $-0.98\pm 0.15$ | 0 |  |  | [4](#S4.F4 "Figure 4 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") |
| CombWM | $0.819\pm 0.026$ | $0.295\pm 0.013$ |  | 0 | $-0.99\pm 0.06$ | 0 |  |  | [4](#S4.F4 "Figure 4 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") |
| CombPl | $0.833\pm 0.021$ | $0.297\pm 0.013$ |  | 0 | $-1.03\pm 0.06$ | 0 |  |  | [10](#A2.F10 "Figure 10 ‣ Appendix B Figures Using Planck Data ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") |
| CombWM | $0.818\pm 0.023$ | $0.289\pm 0.014$ | $0.715\pm 0.016$ | $-5\pm 5$ | $-1.03\pm 0.07$ | 0 |  |  |  |
| CombPl | $0.836\pm 0.021$ | $0.292\pm 0.014$ | $0.713\pm 0.015$ | $-4\pm 4$ | $-1.08\pm 0.07$ | 0 |  |  |  |
| Clusters | $0.829\pm 0.036$ | $0.261\pm 0.026$ |  | 0 | $-0.69^{+0.32}\_{-0.36}$ | $-1.6^{+1.9}\_{-1.3}$ | $-2.3^{+1.6}\_{-1.0}$ | 0.5 | [6](#S4.F6 "Figure 6 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")a |
| CombWM | $0.816\pm 0.027$ | $0.292\pm 0.015$ |  | 0 | $-1.04^{+0.13}\_{-0.18}$ | $0.3^{+0.4}\_{-0.6}$ | $-0.8^{+0.3}\_{-0.4}$ | 0.5 | [6](#S4.F6 "Figure 6 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")a |
| CombPl | $0.835\pm 0.021$ | $0.298\pm 0.015$ |  | 0 | $-0.96^{+0.15}\_{-0.18}$ | $-0.3^{+0.6}\_{-0.5}$ | $-1.2^{+0.4}\_{-0.4}$ | 0.5 | [10](#A2.F10 "Figure 10 ‣ Appendix B Figures Using Planck Data ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") |
| Clusters | $0.827\pm 0.036$ | $0.262\pm 0.023$ |  | 0 | $-0.71^{+0.62}\_{-0.42}$ | $-1.0^{+1.5}\_{-1.4}$ | $-1.4^{+0.8}\_{-1.1}$ | — |  |
| CombWM | $0.818\pm 0.025$ | $0.291\pm 0.015$ |  | 0 | $-1.09^{+0.23}\_{-0.22}$ | $0.2^{+0.5}\_{-0.5}$ | $-0.9^{+0.2}\_{-0.2}$ | — |  |
| CombPl | $0.834\pm 0.02$1 | $0.300\pm 0.015$ |  | 0 | $-0.97^{+0.24}\_{-0.20}$ | $-0.2^{+0.5}\_{-0.5}$ | $-1.1^{+0.2}\_{-0.3}$ | — |  |
| CombWM | $0.822\pm 0.026$ | $0.294\pm 0.015$ | $0.713\pm 0.016$ | $-8\pm 6$ | $-0.93^{+0.24}\_{-0.20}$ | $-0.4^{+1.0}\_{-1.1}$ | $-1.3^{+0.8}\_{-0.9}$ | 0.5 | [6](#S4.F6 "Figure 6 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")b |
| CombPl | $0.840\pm 0.022$ | $0.302\pm 0.015$ | $0.705\pm 0.016$ | $-8\pm 5$ | $-0.87^{+0.26}\_{-0.20}$ | $-0.8^{+0.9}\_{-1.4}$ | $-1.6^{+0.7}\_{-1.1}$ | 0.5 | [10](#A2.F10 "Figure 10 ‣ Appendix B Figures Using Planck Data ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") |
| CombWM | $0.822\pm 0.025$ | $0.295\pm 0.016$ | $0.712\pm 0.016$ | $-7\pm 7$ | $-0.97^{+0.40}\_{-0.22}$ | $-0.1^{+0.6}\_{-1.2}$ | $-1.1^{+0.5}\_{-0.7}$ | — | [6](#S4.F6 "Figure 6 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")b |
| CombPl | $0.838\pm 0.021$ | $0.304\pm 0.016$ | $0.703\pm 0.016$ | $-7\pm 5$ | $-0.71^{+0.24}\_{-0.36}$ | $-1.1^{+1.1}\_{-0.7}$ | $-1.3^{+0.3}\_{-0.8}$ | — | [10](#A2.F10 "Figure 10 ‣ Appendix B Figures Using Planck Data ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") |

Figure [5](#S4.F5 "Figure 5 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") presents the analogous results for $\Lambda$CDM models including global curvature. Here the cluster data constrain the dark energy density to be $\Omega\_{\mathrm{\Lambda}}=0.73\pm 0.12$, a 60 per cent improvement relative to the constraints from the $f\_{\mathrm{gas}}$ data alone ([77](#bib.bib77)). The combination of all data strongly prefers spatial flatness, with $10^{3}\Omega\_{k}=-3\pm 4$ and $0\pm 4$ from the combinations using WMAP and Planck+WP data, respectively.

Turning to models with an evolving equation of state, we first consider the simplest case without spatial curvature. With this assumption, the cluster data alone are able to constrain the $w\_{0}$ and $w\_{a}$ parameters of the evolving dark energy model (see Equation [1](#S3.E1 "In 3.1 Cosmological Model ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")), even when $a\_{\mathrm{tr}}$ is free (marginalized over $0.5<a\_{\mathrm{tr}}<0.95$). Individual constraints from cluster, CMB, supernova and BAO data are shown in the left panel of Figure [6](#S4.F6 "Figure 6 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), along with constraints from the combination of data, when $a\_{\mathrm{tr}}$ is fixed to 0.5. Regardless of which all-sky CMB data set is used and whether or not $a\_{\mathrm{tr}}$ is fixed, we find consistency with the cosmological-constant model.

Table [2](#S4.T2 "Table 2 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") also shows constraints for models including both free curvature ($\Omega\_{k}$) and an evolving equation of state. In all cases, the cluster data, and the combinations of cluster and other leading data sets, remain consistent with spatial flatness and a cosmological constant (see the right panel of Figure [6](#S4.F6 "Figure 6 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") for models including free curvature). Comparing to [77](#bib.bib77), who use identical $f\_{\mathrm{gas}}$, CMB, supernova and BAO data but not cluster counts, we generally find improvement in the constraints on $w\_{0}$, and less so for $\Omega\_{k}$ and $w\_{a}$. In the most general model we consider, the constraint on $w\_{0}$ shrinks from $-0.99\pm 0.34$ to $-0.97^{+0.40}\_{-0.22}$ for the combination using WMAP CMB data (from $-0.75\pm 0.34$ to $-0.71^{+0.24}\_{-0.36}$ for the combination using Planck+WP data).

Figure 6: 
Left: Constraints on evolving-$w$ dark energy models with minimal neutrino mass and without global curvature from our cluster data (with standard priors on $h$ and $\Omega\_{\mathrm{b}}h^{2}$) are compared with results from CMB (WMAP, ACT and SPT), supernova and BAO (also including priors on $h$ and $\Omega\_{\mathrm{b}}h^{2}$) data, and their combination. The priors on $h$ and $\Omega\_{\mathrm{b}}h^{2}$ are not included in the combined constraints. Dark and light shading respectively indicate the 68.3 and 95.4 per cent confidence regions, accounting for systematic uncertainties. The cross indicates the $\Lambda$CDM model ($w\_{0}=-1$, $w\_{a}=0$).
Right: Constraints on evolving-$w$ models with global curvature as a free parameter from the combination of cluster, CMB, supernova and BAO data. For the model with $a\_{\mathrm{tr}}$ free, this parameter is marginalized over the range $0.5<a\_{\mathrm{tr}}<0.95$ (see Equation [1](#S3.E1 "In 3.1 Cosmological Model ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")). In all cases, we find consistency with the standard cosmological-constant model.

### 4.4 Constraints on Modifications of Gravity

While dark energy (in the form of a cosmological constant) has been a mainstay of the standard cosmological model since the discovery that the expansion of the Universe is accelerating, other explanations for acceleration are possible. In particular, various modifications to GR in the large-scale/weak-field limit have been proposed (for recent
reviews see, e.g., [Frieman
et al. 2008](#bib.bib46); [Clifton
et al. 2012](#bib.bib32); [Joyce
et al. 2014](#bib.bib56)). Being sensitive to the action of gravity in this regime, the growth of cosmic structure has the potential to distinguish between dark energy and modified gravity theories that predict identical expansion histories.

Figure 7: 
Constraints on models where the growth index of cosmic structure formation, $\gamma$, is a free parameter. Dark and light shading respectively indicate the 68.3 and 95.4 per cent confidence regions, accounting for systematic uncertainties. Left: Constraints from clusters, the CMB, and galaxy survey data individually, marginalizing over the standard flat $\Lambda$CDM parametrization of the cosmic expansion history. Note that the treatment of the galaxy survey data uses a multivariate Gaussian approximation to constraints from RSD and the AP effect (see also [Rapetti
et al. 2013](#bib.bib97)). GR corresponds approximately to $\gamma=0.55$ (dashed line). Right: Constraints from clusters and the combination of clusters and the CMB for models where $w$ is allowed to be free in the parametrization of the expansion history (this parameter does not directly affect the growth history in this model). Here the horizontal and vertical dashed lines respectively correspond to the standard models for the growth of cosmic structure (GR) and the expansion of the Universe ($\Lambda$CDM). In these figures, ‘CMB’ refers to the combination of ACT, SPT and WMAP data; see Appendix [B](#A2 "Appendix B Figures Using Planck Data ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") for the corresponding figures using Planck+WP instead of WMAP data.

A simple and entirely phenomenological approach involves modifying the growth rate of density perturbations at late times, when the growth is approximately scale-independent. We adopt the simple parametrization in terms of the growth index, $\gamma$ (e.g. [Linder 2005](#bib.bib65)),

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f(a)=\frac{d\ln\,\delta}{d\ln\,a}=\Omega\_{\mathrm{m}}(a)^{\gamma},$ |  | (14) |

where $\delta$ is the linear density contrast in synchronous gauge (at any scale), and where $\gamma=0.55$ approximately corresponds to GR for a wide range of expansion histories compatible with current data ([Polarski &
Gannouji, 2008](#bib.bib93)). Note that constraints on the growth index serve only as a useful consistency check of GR, rather than directly testing GR against alternative models of gravity. Constraints on $\gamma$ from earlier versions of our cluster analysis (in conjunction with contemporaneous cosmological data) are presented by [Rapetti
et al. (2009)](#bib.bib94); [Rapetti
et al. (2010)](#bib.bib95); [Rapetti
et al. (2013)](#bib.bib97). Independent constraints from other data sets have been obtained by, e.g., [Nesseris
& Perivolaropoulos (2008)](#bib.bib80), [di Porto &
Amendola (2008)](#bib.bib37), [Samushia
et al. (2013)](#bib.bib107); [Samushia
et al. (2014)](#bib.bib108) and [Beutler
et al. (2014a)](#bib.bib20).

Table 3: 
Marginalized best-fitting values and 68.3 per cent maximum-likelihood confidence intervals for the growth index ($\gamma$), $\sigma\_{8}$, and $w$ from clusters (Cl), the CMB and galaxy survey data (gal). Here $\gamma$ determines the late-time growth of cosmic structure, and $w$ should be interpreted purely as a modification to the $\Lambda$CDM expansion model (but not directly to the growth). Subscripts ‘WM’ and ‘$Pl$’ denote the use of WMAP or Planck+WP data in combination with ACT and SPT. Note: athe combinations with galaxy survey data should be treated with caution due to the caveats noted in the text.

| Data | $\gamma$ | $\sigma\_{8}$ | $w$ |
| --- | --- | --- | --- |
| Cl | $0.48\pm 0.19$ | $0.833\pm 0.048$ | $-1$ |
| Cl+CMBWM | $0.56\pm 0.13$ | $0.824\pm 0.037$ | $-1$ |
| Cl+CMBWM+gala | $0.66\pm 0.06$ | $0.802\pm 0.016$ | $-1$ |
| Cl+CMBPl | $0.58\pm 0.12$ | $0.824\pm 0.037$ | $-1$ |
| Cl+CMBPl+gal | $0.67\pm 0.06$ | $0.799\pm 0.015$ | $-1$ |
| Cl | $0.39\pm 0.24$ | $0.850\pm 0.055$ | $-0.90\pm 0.19$ |
| Cl+CMBWM | $0.52\pm 0.14$ | $0.817\pm 0.040$ | $-0.94\pm 0.13$ |
| Cl+CMBWM+gal | $0.60\pm 0.08$ | $0.792\pm 0.020$ | $-0.91\pm 0.08$ |
| Cl+CMBPl | $0.57\pm 0.14$ | $0.828\pm 0.040$ | $-1.01\pm 0.13$ |
| Cl+CMBPl+gal | $0.63\pm 0.07$ | $0.799\pm 0.015$ | $-0.96\pm 0.07$ |

We follow [Rapetti
et al. (2013)](#bib.bib97), investigating the constraints on $\gamma$ from our cluster data, the integrated Sachs-Wolfe (ISW) effect on the CMB,2626
26
Cosmic growth also leaves an imprint at high multipoles through CMB lensing, but currently the CMB constraints on $\gamma$ primarily come from the ISW effect. and measurements of redshift-space distortions (RSD) and the Alcock-Paczynski (AP) effect from galaxy survey data. In practice, we use camb to calculate and tabulate $P(k,z)$ assuming GR, then modify these values from $z=30$ (well into the matter-dominated regime, where $f\rightarrow 1$ independent of $\gamma$) onward to be consistent with the growth given by Equation [14](#S4.E14 "In 4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). This modified power spectrum is then integrated when evaluating the cluster mass function (Equations [2](#S3.E2 "In 3.1 Cosmological Model ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")–[3](#S3.E3 "In 3.1 Cosmological Model ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")). For details of the calculation of the ISW effect in this model, see Appendix [C](#A3 "Appendix C The ISW Effect in Free Growth-Index Models ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"); as in earlier sections, we use CMB data from ACT, SPT, and either Planck+WP or WMAP. The galaxy survey data include results from 6dF ([Beutler
et al., 2012](#bib.bib19)), SDSS ([Reid
et al., 2012](#bib.bib100)) and the WiggleZ Dark Energy Survey ([Blake
et al., 2011](#bib.bib23)). Their likelihood is approximated by a multivariate Gaussian, encoding measurements of $f\sigma\_{8}(z)$ and $F(z)=(1+z)D(z)H(z)/c$ at several redshifts, assuming zero neutrino mass; here $D$ is the angular diameter distance, and $c$ is the speed of light. For consistency, we fix $\sum m\_{\nu}=0$ in this section for all data sets, rather than using the baseline value of $0.056\mathrm{\,eV}$ employed elsewhere in this paper. Due to the approximate nature of the galaxy survey likelihood used here, compared with the analysis of cluster and CMB data, we urge caution in interpreting the results that combine all three data sets. However, the level of precision that is in principle available from this combination (Table [3](#S4.T3 "Table 3 ‣ 4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")) motivates a more complete analysis of the galaxy survey data, i.e. accounting for all parameter covariances, in future work.

The left panel of Figure [7](#S4.F7 "Figure 7 ‣ 4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") shows the constraints on $\gamma$ and $\sigma\_{8}$ from clusters, the CMB and galaxy survey data individually. In addition to the parameters shown, we marginalize over the standard set of free parameters of the flat $\Lambda$CDM model. In the case of CMB or galaxy survey data alone, there are strong but complementary degeneracies (as discussed by [Rapetti
et al. 2013](#bib.bib97)), whereas the cluster data (with standard priors) constrain the entire model; the marginalized constraints from clusters are $\gamma=0.48\pm 0.19$ and $\sigma\_{8}=0.83\pm 0.05$.

All three data sets shown are individually consistent with $\gamma=0.55$. Their combination has a marginal ($<2\sigma$) preference for higher values of $\gamma$ (Table [3](#S4.T3 "Table 3 ‣ 4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")), though this should be viewed with caution in light of the caveats mentioned above (see also [Beutler
et al. 2014b](#bib.bib21)). The combination of clusters and the CMB (without galaxy survey data) is fully consistent with GR.

In the right panel of Figure [7](#S4.F7 "Figure 7 ‣ 4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), we present constraints on models when additional freedom is introduced into the model for the cosmic expansion in the form of the $w$ parameter. In this model, $w$ should not be interpreted as the dark energy equation of state, but simply as a phenomenological departure from the cosmic expansion model given by $\Lambda$CDM, in the same way that $\gamma$ parametrizes departures of the growth history from that given by GR. (In particular, dark energy perturbations associated with values of $w$ different from $-1$ are not included in the growth equations, which instead depend on $\gamma$ through Equation [14](#S4.E14 "In 4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass").) The figure shows constraints from clusters alone, and the combination of cluster and CMB data. Here again, the clusters and clusters+CMB data are fully consistent with the standard $w=-1$, $\gamma=0.55$ model, although the full combination, including the galaxy survey data, exhibits mild ($<2\sigma$) tension (Table [3](#S4.T3 "Table 3 ‣ 4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")).

### 4.5 Constraints on Non-Gaussianity

Figure 8: 
Constraints on hierarchical-type and feeder-type inflation models, in which the level of primordial non-Gaussianity is parameterized by $\mathcal{M}\_{3}$ (see text), from clusters and the combination of cluster and CMB data. (Note that feeder models generate more non-Gaussianity for a given value of $\mathcal{M}\_{3}$, hence the difference in scale between the two panels.) Dark and light shading respectively indicate the 68.3 and 95.4 per cent confidence regions, accounting for systematic uncertainties. When combining cluster and CMB data, we use only the CMB power spectra (PS) here (not bi- or trispectra).

In the standard cosmological model, the primordial density perturbations sourced by inflation are assumed to be Gaussian, in which case their statistical properties are completely described by the power spectrum (i.e. two-point correlation function). However, many viable inflation models produce non-Gaussianity, which results in non-vanishing higher-order correlations (see, e.g., [Bartolo
et al. 2004](#bib.bib13)). CMB and galaxy survey studies of non-Gaussianity typically focus on constraining the amplitude of the bispectrum (three-point function), parametrized by $f\_{\mathrm{NL}}$, for a given “triangle” template configuration of momentum vectors (e.g. [Bennett
et al. 2013](#bib.bib16); [Planck
Collaboration 2013e](#bib.bib91)).

Table 4: 
Best-fitting values and 68.3 per cent confidence intervals for $\sigma\_{8}$ and the non-Gaussian parameter $\mathcal{M}\_{3}$ from the cluster data set and its combination with CMB data for hierarchical-type (H) and feeder-type (F) inflation models. Note that we use only the CMB power spectra here (not bi- or trispectra). Hence, the CMB data refine our results by improving the constraints on $\sigma\_{8}$ (and, to a lesser extent, other cosmological parameters), but do not directly constrain the non-Gaussian model. We also list the equivalent constraints on the level of non-Gaussianity in the bispectrum, $f\_{\mathrm{NL}}$, for the three canonical triangle configurations (local, equilateral and orthogonal; see [Shandera
et al. 2013b](#bib.bib116) and [Adhikari
et al. 2014](#bib.bib1) for details of this conversion).

| Model | Data | $\sigma\_{8}$ | $10^{3}\mathcal{M}\_{3}$ | $f\_{\mathrm{NL}}^{\mathrm{local}}$ | $f\_{\mathrm{NL}}^{\mathrm{equil}}$ | $f\_{\mathrm{NL}}^{\mathrm{orthog}}$ |
| --- | --- | --- | --- | --- | --- | --- |
| H | Clusters | $0.835\pm 0.053$ | $8^{+40}\_{-65}$ | $24^{+129}\_{-210}$ | $88^{+471}\_{-765}$ | $-123^{+1066}\_{-656}$ |
| H | Clusters+WMAP | $0.808\pm 0.019$ | $-1^{+42}\_{-36}$ | $-3^{+135}\_{-116}$ | $-12^{+494}\_{-424}$ | $16^{+590}\_{-689}$ |
| H | Clusters+Planck+WP | $0.823\pm 0.011$ | $-29^{+46}\_{-24}$ | $-94^{+148}\_{-77}$ | $-341^{+541}\_{-282}$ | $475^{+393}\_{-754}$ |
| F | Clusters | $0.830\pm 0.041$ | $4^{+8}\_{-21}$ | $11^{+26}\_{-68}$ | $41^{+94}\_{-247}$ | $-57^{+344}\_{-131}$ |
| F | Clusters+WMAP | $0.810\pm 0.017$ | $-7^{+16}\_{-9}$ | $-23^{+50}\_{-27}$ | $-85^{+182}\_{-100}$ | $119^{+139}\_{-254}$ |
| F | Clusters+Planck+WP | $0.823\pm 0.011$ | $-15^{+19}\_{-4}$ | $-48^{+60}\_{-11}$ | $-174^{+218}\_{-41}$ | $242^{+57}\_{-303}$ |

For clusters, non-Gaussianity manifests itself in an enhancement or suppression of the mass function at the highest masses, and respectively a corresponding suppression or enhancement at low masses, relative to the Gaussian case. Importantly, the cluster signal is influenced by the entire series of $n$-point correlation functions ([Lo Verde
et al., 2008](#bib.bib66); [Shandera
et al., 2013a](#bib.bib115)), and therefore has the potential to distinguish competing models of inflation that have identical bispectra but a different scaling of higher-order moments (e.g. [Barnaby &
Shandera 2012](#bib.bib12)).

[Shandera
et al. (2013b)](#bib.bib116) present constraints on two such inflation models, referred to as hierarchical-type (single-field inflation) and feeder-type (including interactions with a spectator field), based on the [74](#bib.bib74),[b](#MtenBht "In References ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") data set. In this work, the free parameter describing the overall level of non-Gaussianity is the dimensionless third moment of the density perturbation field, smoothed on scales of $8h^{-1}\mathrm{\,Mpc}$, $\mathcal{M}\_{3}$; the two models above differ in the scaling of higher-order moments relative to $\mathcal{M}\_{3}$, and in the form of the modified, non-Gaussian mass function. In particular, the feeder scaling generates greater non-Gaussianity overall for a given value of $\mathcal{M}\_{3}$ than the hierarchical scaling.

More recently, [Adhikari
et al. (2014)](#bib.bib1) have performed $N$-body simulations of structure formation from non-Gaussian initial conditions. Their results for non-Gaussian mass functions broadly vindicate the analytic approach of [Shandera
et al. (2013b)](#bib.bib116), but motivate several refinements of the model, detailed in [Adhikari
et al. (2014)](#bib.bib1), which we adopt here. We do not recapitulate these refinements here, but note that their net effect is to reduce the modification to the mass function for a given value of $\mathcal{M}\_{3}$ compared with the [Shandera
et al. (2013b)](#bib.bib116) model, for both hierarchical- and feeder-type scalings. Consequently, our constraints on non-Gaussianity are weaker than those reported by [Shandera
et al. (2013b)](#bib.bib116), despite our addition of lensing data to the data set used in that work.2727
27
Empirically, and on a very technical note, we find that the most significant change to the model is due to the lower value of $\delta\_{\mathrm{c}}$, a parameter whose value was assumed by [Shandera
et al. (2013b)](#bib.bib116), but which was fit to simulations by [Adhikari
et al. (2014)](#bib.bib1); this directly impacts the non-Gaussian modification of the mass function, which depends on the ratio $\nu\_{\mathrm{c}}=\delta\_{\mathrm{c}}/\sigma(M)$. In detail, the [Adhikari
et al. (2014)](#bib.bib1) results are not precisely applicable to our analysis because the spherical overdensity they adopt to construct the mass function is different from the overdensity we use. However, a partial re-analysis of the simulation data indicates that the particular choice of overdensity has a small effect compared with the overall update due to $\delta\_{\mathrm{c}}$, and that, if anything, the appropriate $\delta\_{\mathrm{c}}$ for our mass function may be slightly larger than the Adhikari value. We therefore adopt the [Adhikari
et al. (2014)](#bib.bib1) prescription for the non-Gaussian mass function here, while noting that our new constraints may err on the conservative side. Future work in this area will benefit from more simulations, covering a more extensive selection of models, and investigating the dependence of the results on the halo finder employed. Apart from primordial non-Gaussianity, we adopt a standard flat $\Lambda$CDM model in this section.

Joint constraints on $\mathcal{M}\_{3}$ and $\sigma\_{8}$ from our cluster analysis are shown in Figure [8](#S4.F8 "Figure 8 ‣ 4.5 Constraints on Non-Gaussianity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). As noted by [Shandera
et al. (2013b)](#bib.bib116), these two parameters are degenerate, particularly for hierarchical scaling. Improved constraints can therefore be obtained by incorporating additional data, namely the CMB power spectrum, to better constrain $\sigma\_{8}$. Note that we do not use the CMB bispectrum or trispectrum to constrain $\mathcal{M}\_{3}$ here; the improvement in the figure comes entirely from breaking degeneracies between $\mathcal{M}\_{3}$ and other model parameters. Table [4](#S4.T4 "Table 4 ‣ 4.5 Constraints on Non-Gaussianity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") lists the constraints on these parameters for both non-Gaussian models, as well as the equivalent constraints on the amplitude of the bispectrum ($f\_{\mathrm{NL}}$) for the canonical local, equilateral and orthogonal momentum-space configurations (see [Shandera
et al. 2013b](#bib.bib116) and [Adhikari
et al. 2014](#bib.bib1) for details of this conversion). In all cases, our results are consistent with Gaussianity.

In addition to [Shandera
et al. (2013b)](#bib.bib116), previous constraints on non-Gaussianity have been obtained by, e.g., [Williamson
et al. (2011)](#bib.bib134) and [Benson
et al. (2013)](#bib.bib17) from the SPT cluster sample and [Mana
et al. (2013)](#bib.bib71) based on the MaxBCG sample. A direct comparison of the constraints is not completely straightforward, since these authors model the effects of non-Gaussianity on the mass function differently, but broadly speaking all these cluster constraints are consistent (see discussion in [Shandera
et al. 2013b](#bib.bib116)), and all are consistent with Gaussianity. In the long term, combining the redshift coverage at high masses of X-ray and SZ surveys with the large mass range (and spatial clustering; e.g. [Mana
et al. 2013](#bib.bib71)) probed by optical surveys has the potential to significantly tighten cluster constraints on non-Gaussianity.

## 5 Discussion

### 5.1 The Role of Follow-up Data

Although a cosmological test can be carried out using only cluster survey data, given a survey of sufficient area and depth (in both mass and redshift), this approach requires relatively strong assumptions regarding the form and scatter of the scaling relations. A straightforward benefit of incorporating additional measurements of masses or mass proxies for even a subset of discovered clusters is that these aspects of the model can be constrained rather than assumed, expanding the scope of cosmological models that can be investigated (e.g. [Majumdar &
Mohr 2004](#bib.bib70)). In the context of the Dark Energy Survey (DES), [Wu
et al. (2010)](#bib.bib136) have shown that significant gains in dark energy constraints can be obtained by incorporating X-ray or SZ mass proxy information, for example.

The present work uses three forms of follow-up data (in addition to spectroscopic redshift measurements): weak gravitational lensing observations, X-ray measurements of mass proxies (X-ray luminosity, temperature and gas mass within $r\_{500}$), and X-ray measurements of $f\_{\mathrm{gas}}$ at $r\_{2500}$ for relaxed clusters. To a large extent, the X-ray $f\_{\mathrm{gas}}$ analysis can be considered independent (Section [3.2](#S3.SS2 "3.2 Cluster Scaling Relations ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")), providing additional constraints on $\Omega\_{\mathrm{m}}$ and dark energy parameters. As for the former two types of data, their complementarity goes beyond the fact that X-ray observations are currently more numerous than lensing observations for the clusters in our data set. Namely, as we have emphasized, weak lensing provides nearly unbiased masses on average, but with a significant, irreducible intrinsic scatter on a cluster-by-cluster basis. In contrast, some X-ray (and SZ) mass proxies have a much smaller intrinsic scatter with mass, but the normalization of their scaling relations must be calibrated. The combination of the two types of observations thus provides a robust constraint on the cluster mass scale (from lensing), as well as more precise constraints on the slope and intrinsic scatter of scaling relations (and potentially on the shape of the mass function) than lensing alone can provide.

Figure 9: 
Constraints on $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ from subsets of our data. Dark and light shading respectively indicate the 68.3 and 95.4 per cent confidence regions, including systematic uncertainties and using standard priors on $h$ and $\Omega\_{\mathrm{b}}h^{2}$. Red shading corresponds to the use of only the list of survey fluxes and redshifts for detected clusters (RASS) and the [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) lensing observations. Blue shading adds X-ray measurements of $f\_{\mathrm{gas}}$ for relaxed clusters, which constrain $\Omega\_{\mathrm{m}}$ but not $\sigma\_{8}$, and purple regions also include X-ray mass proxies ($kT$ and $M\_{\mathrm{gas}}$) from X-ray follow-up data.

A cost/benefit analysis of these types of data in the spirit of [Wu
et al. (2010)](#bib.bib136) is beyond the scope of this paper. However, it is straightforward to ask how each contributes to our current results. Section [4.1](#S4.SS1 "4.1 Cluster Constraints on Ω_m and 𝜎_8 ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") has shown the importance of the lensing data for tightening constraints on $\sigma\_{8}$ as well as $\Omega\_{\mathrm{m}}$ (see also [77](#bib.bib77)) by straightforwardly comparing with the [74](#bib.bib74) results. Figure [9](#S5.F9 "Figure 9 ‣ 5.1 The Role of Follow-up Data ‣ 5 Discussion ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") shows how constraints on these two parameters respond to the addition of follow-up X-ray data, given a lensing mass calibration to start with. Red shading in the figure shows the constraints available from only the combination of the survey detections plus redshifts (RASS) and WtG lensing data. The classic $\sigma\_{8}$–$\Omega\_{\mathrm{m}}$ degeneracy is apparent, but the redshift leverage of the data (which span $0<z<0.5$) is sufficient to break it. The width of the confidence region in this case is constrained to be $\sigma\_{8}(\Omega\_{\mathrm{m}}/0.3)^{0.17}=0.81\pm 0.04$. The degeneracy can be broken further by incorporating X-ray $f\_{\mathrm{gas}}$ data for relaxed clusters, which robustly measure $\Omega\_{\mathrm{m}}$ but do not constrain $\sigma\_{8}$; the width of the confidence region therefore remains the same, $\sigma\_{8}(\Omega\_{\mathrm{m}}/0.3)^{0.21}=0.81\pm 0.04$. Adding X-ray mass proxies from Chandra or ROSAT follow-up (XMP) refines constraints on the key X-ray luminosity–mass relation and its scatter and provides more precise mass estimates for individual clusters, shrinking the constraints to $\sigma\_{8}(\Omega\_{\mathrm{m}}/0.3)^{0.17}=0.81\pm 0.03$.

As we discuss in the next section, significant further improvements in cosmological constraints can be obtained by improving the mass calibration through additional lensing data. Nevertheless, the ability of X-ray and SZ mass proxies to provide more precise mass estimates for individual clusters, and their availability at the highest and lowest redshifts, where lensing observations are very challenging/expensive, underscore their utility for cosmology.

### 5.2 The Benefits of Improved Weak Lensing Data

Figures [3](#S4.F3 "Figure 3 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") and [4](#S4.F4 "Figure 4 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") emphasize that, in the context of non-minimal cosmological models, the cluster constraint on $\sigma\_{8}$ can often break key parameter degeneracies (even when many cosmological probes are combined). With relatively modest improvements in lensing systematics (see [Applegate
et al. 2014](#bib.bib10)) and larger samples of clusters with high-quality weak lensing data, constraints on the cluster mass scale at the 5 per cent level are plausible in the near term. Given also a factor of $\sim 2$ improvement in predictions of the halo mass function (compared with the 10 per cent uncertainty adopted here), doubling of the number of clusters with weak lensing data would then translate to a reduction in the uncertainty on $\sigma\_{8}$ (at fixed $\Omega\_{\mathrm{m}}$) from 4 per cent currently to $\sim 2$ per cent from clusters alone.2828
28
The size of the lensing sample could be straightforwardly increased (approximately doubled) by incorporating data already present in the archives of SuprimeCam and MegaPrime/MegaCam, such as those gathered for the Local Cluster Substructure Survey ([Okabe
et al., 2010](#bib.bib83); [Okabe
et al., 2013](#bib.bib82)) and the Canadian Cluster Comparison Project ([Hoekstra, 2007](#bib.bib54); [Hoekstra
et al., 2012](#bib.bib55)). However, this would require the application of a consistent, rigorously tested reduction and analysis pipeline across the entire data set, and likely the gathering of additional data to ensure that a significant fraction of the clusters are observed in at least five well chosen bands (enabling robust estimates of photometric redshifts for individual lensed galaxies; [Applegate
et al. 2014](#bib.bib10)). The lack of such 5-band observations is currently the most serious limitation to exploiting these archival data. At the same time, the new data could provide a $\sim 5$ per cent precision constraint on $\Omega\_{\mathrm{m}}$ through the $f\_{\mathrm{gas}}$ test ([Allen
et al. 2013](#bib.bib4); [77](#bib.bib77)), leading to a factor of four improvement in the joint $\Omega\_{\mathrm{m}}$–$\sigma\_{8}$ constraint.

We have importance sampled our results from Section [4](#S4 "4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") to simulate the effect that such an improved $\sigma\_{8}$ constraint would have, all other things being equal. For concreteness, we assume that the more precise cluster constraint is centered on the current best-fitting value from the combination of cosmological probes (keeping the WMAP and Planck+WP cases separate) for constant-$w$ models with minimal neutrino mass (Section [4.3](#S4.SS3 "4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")). For constant-$w$ models, we find that, due to the degeneracy breaking shown in Figure [4](#S4.F4 "Figure 4 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), constraints on $w$ would improve by 28 (25) per cent for the combination using WMAP (Planck+WP) data. Applying the same procedure to the $\Lambda$CDM+$\sum m\_{\nu}$ model, we would expect 95.4 per cent confidence intervals of $\sum m\_{\nu}=0.09^{+0.14}\_{-0.09}$ ($0^{+0.15}\_{-0.00}$) eV from the WMAP (Planck+WP) combination ($\sim 60$ and 30 percent reductions in the upper limits). With $\sum m\_{\nu}$ and $w$ both free, the upper limits on $\sum m\_{\nu}$ would be reduced by 15–20 per cent. These estimates likely underestimate the true impact of additional lensing data, which may improve the cluster constraints on $w$, depending on the redshift range spanned by the expanded data set. Note also that the full Planck data set (including polarization) should be significantly more powerful than the 1-year Planck data, supplemented by WMAP polarization measurements, used here.

In the particular case of $\sum m\_{\nu}$, accurate and precise constraints on $\sigma\_{8}$ are clearly an important step towards obtaining a robust cosmological detection of non-zero neutrino mass. However, breaking the $\sigma\_{8}$–$\sum m\_{\nu}$ degeneracy can only achieve so much, as Figure [3](#S4.F3 "Figure 3 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") makes clear. Tight constraints on other cosmological parameters, especially dark energy parameters, will also be required to fully exploit the power of a precise $\sigma\_{8}$ determination to measure neutrino mass. Farther ahead, direct detection of the time-dependent effects of neutrino mass on the growth of structure may be possible, although such a measurement will be challenging.

### 5.3 The Route to Improved Dark Energy Constraints

While the addition of further high-quality weak lensing data for X-ray selected clusters at low-to-intermediate redshifts should lead to significant near-term benefits in the constraints on $\Omega\_{\mathrm{m}}$, $\sigma\_{8}$ and the neutrino mass, the route to obtaining improved knowledge of dark energy, gravity and non-Gaussianity from clusters lies primarily in extending the redshift range of the analysis. In this regard, the combination of X-ray and SZ-selected cluster surveys holds significant potential. Using simple Fisher matrix-based projections ([Wu
et al., 2010](#bib.bib136)),2929
29
<http://risa.stanford.edu/cluster/> we estimate that extending the redshift lever arm of our cluster growth measurements out to $z\approx 1.5$ by combining the RASS X-ray survey with an SZ survey with similar area and depth to the 2500 square degree SPT survey ([Bleem
et al., 2014](#bib.bib24)), and including available X-ray and lensing follow-up data, should improve the dark energy constraints shown in Figure [6](#S4.F6 "Figure 6 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") by a factor of two or more, placing cluster measurements firmly in the vanguard of dark energy studies. Similar improvements can be expected for the constraints on modified gravity models, enabling us to move beyond the simple $\gamma$-parameterization shown in Figure [7](#S4.F7 "Figure 7 ‣ 4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), while even larger improvements are expected for inflation studies, which are exponentially sensitive to the presence of unusually massive clusters at high redshifts (relative to the evolved baseline population measured at low-$z$). As the field progresses, there will also be a need for increasingly sophisticated theoretical predictions – for example mass functions calibrated to a few per cent precision spanning the full range of interest in mass and redshift, and an appropriate range of baryonic physics, dark energy and fundamental physics models.

## 6 Conclusions

Earlier papers in the [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) series have focussed on providing the most well characterized and unbiased constraints on the absolute cluster mass calibration possible, using measurements of weak gravitational lensing. Here we incorporate those data into a cosmological analysis that uses the number density of massive clusters as a function of time to probe the growth of cosmic structure. In addition to the [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) lensing data, our analysis uses an X-ray selected cluster sample culled from the ROSAT All-Sky Survey, spanning redshifts $0<z<0.5$, along with follow-up X-ray data to supply additional mass proxies. We additionally take advantage of cluster gas mass fraction data, which also benefit substantially from the lensing mass calibration, to provide an independent measurement of the cosmic expansion and tight constraints on $\Omega\_{\mathrm{m}}$, breaking the main degeneracy (with $\sigma\_{8}$) present in the analysis of cluster-counts data.

Our data provide marginalized constraints on the mean matter density and the amplitude of matter fluctuations, $\Omega\_{\mathrm{m}}=0.26\pm 0.03$ and $\sigma\_{8}=0.83\pm 0.04$. These constraints are essentially identical for $\Lambda$CDM models with and without curvature, as well as constant- and evolving-$w$ models of dark energy, and models with a free neutrino mass. The width of the confidence region in the $\Omega\_{\mathrm{m}}$–$\sigma\_{8}$ plane, which retains some degeneracy, is given by $\sigma\_{8}(\Omega\_{\mathrm{m}}/0.3)^{0.17}=0.81\pm 0.03$ (including all systematic uncertainties). These results are in good agreement with constraints from both WMAP and Planck+WP CMB data, even under the restrictive assumption of a spatially flat $\Lambda$CDM model, and also with our previous results using the same cluster catalogs (but without the lensing data). Our constraints are broadly similar to other recent results from clusters, although the agreement is not formally good within the quoted uncertainties, especially considering that the cluster samples used to provide the mass calibration often overlap to a large degree. This serves to underline the need for an unbiased mass calibration, as well as a robust characterization of the uncertainties in that calibration (as performed in the [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) analysis).

Combining our cluster data with CMB, supernova and BAO data, we find no preference for non-zero neutrino mass, in contrast to some recent work. As measurements of $\sigma\_{8}$ become even more precise, it will be critical to maintain good accuracy and control of systematic uncertainties affecting the cluster mass calibration, to obtain the most accurate constraints on neutrino properties.

The dark energy constraints available from cluster data remain highly competitive with the best available cosmological probes. From cluster data alone (including the survey, follow-up lensing and X-ray observations and $f\_{\mathrm{gas}}$ data), we find $w=-0.98\pm 0.15$ for flat, constant-$w$ models. The cluster data also constrain evolving-$w$ models: we find $w\_{0}=-1.0^{+1.5}\_{-1.4}$ and $w\_{\mathrm{et}}=-1.4^{+0.8}\_{-1.1}$ for a flat, evolving model, marginalizing over the transition redshift of $w(z)$. Combining with CMB, supernova and BAO data, we continue to find consistency with flat $\Lambda$CDM, even when global curvature and evolving dark energy are simultaneously included in the model.

The prospects for further improvements in the constraints on cosmology and fundamental physics from observations of galaxy clusters are substantial. A suite of major new surveys across the electromagnetic spectrum have or will soon come on line (e.g. DES, SPT-3G, Advanced ACT-Pol, eROSITA, LSST, WFIRST-AFTA, Euclid). Optimally leveraging the data from these surveys, as well as follow-up facilities, to produce robust cluster catalogs (with well understood purity and completeness), accurate absolute mass calibration (from weak lensing) and sufficient, low-scatter mass proxy information (from X-ray and SZ follow-up) will be critical to obtaining the tightest and most robust constraints possible.

In the near term, the path toward further reducing systematic uncertainties in the absolute mass calibration of low-redshift cluster samples using weak lensing methods seems clear (e.g. [Applegate
et al. 2014](#bib.bib10)), with important work already underway within the [LSST Dark Energy Science
Collaboration (2012)](#bib.bib68) and elsewhere. The most immediate and straightforward aspect of this would be an expansion of the weak lensing data set to $2$–$4\times$ more clusters, maintaining comparable data quality to the [130](#bib.bib130)[58](#bib.bib58)[10](#bib.bib10) study. With this, the prospects for, e.g., quickly halving the statistical-plus-systematic uncertainty on $\sigma\_{8}$ from clusters, and determining (in combination with new CMB measurements) improved constraints on neutrino properties, are strong. Likewise, for dark energy studies, the prospects for improved constraints by utilizing optimally the full mass and redshift lever arm of new and existing X-ray, optical and SZ-selected cluster samples are excellent.

## Acknowledgments

We thank Alastair Edge for sharing his list of likely AGN-dominated BCS and REFLEX clusters, as well as Risa Wechsler and Sam Skillman for insightful discussions. We thank the Dark Cosmology Centre for hosting collaboration meetings during the development of this paper. We also thank the referee for providing prompt, thorough, and very useful comments. Calculations for this work utilized the Coma, Orange and Bullet compute clusters at the SLAC National Accelerator Laboratory, and the HPC facility at the University of Copenhagen. AM was supported by National Science Foundation grants AST-0838187 and AST-1140019. DA acknowledges funding from the German Federal Ministry of Economics and Technology (BMWi) under project 50 OR 1210. S. Adhikari and S. Shandera are supported by the National Aeronautics and Space Administration (NASA) under Grant No. NNX12AC99G issued through the Astrophysics Theory Program. We acknowledge support from the U.S. Department of Energy under contract number DE-AC02-76SF00515; from NASA through Chandra Award Numbers GO8-9118X and TM1-12010X, issued by the Chandra X-ray Observatory Center, which is operated by the Smithsonian Astrophysical Observatory for and on behalf of NASA under contract NAS8-03060; as well as through program HST-AR-12654.01-A, provided by NASA through a grant from the Space Telescope Science Institute, which is operated by the Association of Universities for Research in Astronomy, Inc., under NASA contract NAS 5-26555. The Dark Cosmology Centre is funded by the Danish National Research Foundation.

Based in part on data collected at Subaru Telescope (University of Tokyo) and obtained from the SMOKA, which is operated by the Astronomy Data Center, National Astronomical Observatory of Japan. Based on observations obtained with MegaPrime/MegaCam, a joint project of CFHT and CEA/DAPNIA, at the Canada-France-Hawaii Telescope (CFHT) which is operated by the National Research Council (NRC) of Canada, the Institute National des Sciences de l’Univers of the Centre National de la Recherche Scientifique of France, and the University of Hawaii.

## Appendix A Constraints on Scaling Relations

Obtaining cosmological constraints from the mass function of clusters necessarily involves simultaneously constraining the scaling of cluster observables with mass (Section [3](#S3 "3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")). In this work, the X-ray follow-up observables we use are those derived in [75](#bib.bib75). For the cosmological results reported here, the impact of more recent updates to the Chandra calibration is expected to be very small. As noted in Section [2](#S2 "2 Data ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), luminosity and gas mass measurements agree between [75](#bib.bib75) and measurements using recent calibration updates at the per cent level (and luminosity is in any case cross-calibrated to the ROSAT standard in the cosmological analysis). Temperature measurements do differ; however, the primary impact that measured temperatures have on the present cosmological analysis is through the conversion of X-ray luminosity to flux (the K-correction), which is an exceedingly weak dependence for massive clusters at the relevant redshifts. In [74](#bib.bib74),[b](#MtenBht "In References ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), we explicitly tested the effect of assuming a fixed temperature of 5 keV for every cluster and found this to produce identical cosmological constraints to fitting for the temperature–mass relation, a result which still applies to the current analysis. Thus, the temperature–mass relation can be considered a pure output of the combined cosmology/scaling analysis for our data set.

On the other hand, any astrophysical interpretation of the X-ray scaling relations should ideally be based on the latest Chandra calibration. For this reason, we defer such discussion to an upcoming paper, WtG V, which will employ updated X-ray measurements. For completeness, the scaling relation constraints obtained from the current analysis (using the same X-ray calibration as [74](#bib.bib74),[b](#MtenBht "In References ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")) are provided below.

In implementing the general scaling model introduced in Section [3.2](#S3.SS2 "3.2 Cluster Scaling Relations ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), we have assumed several of the off-diagonal terms of the intrinsic covariance matrix to be zero, specifically the terms linking X-ray luminosity or temperature to gas mass or lensing mass. (The luminosity–temperature correlation is free in our analysis.) While this simplification is required for computational reasons, it is also well motivated according to our best understanding of the observables involved. The marginal scatter in X-ray luminosity at fixed mass is dominated by the presence or absence of compact, bright cores found at the centers of some clusters ([75](#bib.bib75)). Since our temperature measurements exclude cluster centers ($r<0.15\,r\_{500}$; see [75](#bib.bib75)), and because X-ray luminosity in the 0.1–2.4 keV band is approximately temperature-independent for the $kT\ {\raise-3.22916pt\hbox{$\mathrel{\mathop{\kern 0.0pt\sim}\limits^{>}}$}}\ 4\mathrm{\,keV}$ clusters in our sample, the $\ell$–$t$ covariance is expected (and measured) to be small. The marginal luminosity scatter is both large ($\sim 40$ per cent) and physically different in origin from the scatters in $M\_{\mathrm{gas}}$ and $M\_{\mathrm{lens}}$, both of which are most sensitive to larger spatial scales ($\sim r\_{500}$ compared with $\ {\raise-3.22916pt\hbox{$\mathrel{\mathop{\kern 0.0pt\sim}\limits^{<}}$}}\ 0.05\,r\_{500}$; [Mantz 2009](#bib.bib72)). Covariances among the temperature, gas mass and lensing mass measured for a given cluster, due to e.g. asphericity or dynamical state, are similarly thought to be small (see e.g. calculations by [Gavazzi 2005](#bib.bib47) and [Buote &
Humphrey 2012](#bib.bib27), hydrodynamical simulations by [Stanek
et al. 2010](#bib.bib118), and further discussion in WtG V). We therefore expect the impact of neglecting these cross-terms to be small compared with the overall level of systematic allowances in our analysis (e.g. [Allen
et al. 2011](#bib.bib3)).

The constraints on scaling relations from the present work appear in Table [5](#A1.T5 "Table 5 ‣ Appendix A Constraints on Scaling Relations ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"). The constraints on the luminosity–mass and temperature–mass relations are similar to those of [75](#bib.bib75), though note the change from base-10 to natural logarithms in the definition of the scaling relations (relevant to the normalizations and scatters). The largest shift, though still within errors, is in the $\ell$–$m$ normalization, which has degeneracies with cosmological parameters due to its role in the sample selection. Astrophysical interpretation of the scaling relation constraints, using an up-to-date Chandra calibration, will be presented in WtG V. In the context of cosmological constraints, however, it is interesting to note that the constraint on intrinsic scatter in the $m\_{\mathrm{lens}}$–$m$ relation, $0.18\pm 0.05$, is considerably tighter than the prior ($0.2\pm 0.1$) and in good agreement with simulation predictions ([Becker &
Kravtsov, 2011](#bib.bib15)). This exemplifies the complementary nature of lensing and other mass-proxy follow-up data. Namely, while lensing excels at providing an unbiased mean mass, the intrinsic scatter is relatively large. Mass proxies with smaller scatter, once calibrated in the mean by lensing data, can provide more precise mass estimates for individual clusters, as well as directly calibrate the size of the lensing intrinsic scatter.

Table 5: 
Best-fitting values and 68.3 per cent confidence intervals for scaling relation parameters. The scaling relation model is introduced in Section [3.2](#S3.SS2 "3.2 Cluster Scaling Relations ‣ 3 Model and Analysis Methods ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"); for comparing normalizations and scatters to [75](#bib.bib75), note the change from base-10 to natural logarithms in our definition of the scaling relation parameters. This set of constraints results from an analysis of the cluster data alone, marginalizing over flat $\Lambda$CDM cosmological models. Parameters which are only constrained by the prior, namely the $m\_{\mathrm{gas}}$–$m$ scatter and $m\_{\mathrm{lens}}$–$m$ normalization, are not listed.

| Parameter | Constraint |
| --- | --- |
| $\ell$–$m$ normalization | $1.71\pm 0.17$ |
| $\ell$–$m$ slope | $1.34\pm 0.07$ |
| $\ell$–$m$ scatter | $0.42\pm 0.05$ |
| $t$–$m$ normalization | $2.04\pm 0.06$ |
| $t$–$m$ slope | $0.47\pm 0.04$ |
| $t$–$m$ scatter | $0.13\pm 0.02$ |
| $\ell$,$t$ correlation | $0.11\pm 0.19$ |
| $m\_{\mathrm{gas}}$–$m$ normalization | $-2.18\pm 0.08$ |
| $m\_{\mathrm{gas}}$–$m$ slope | $0.99\pm 0.01$ |
| $m\_{\mathrm{lens}}$–$m$ scatter | $0.18\pm 0.05$ |

## Appendix B Figures Using Planck Data

Figure [10](#A2.F10 "Figure 10 ‣ Appendix B Figures Using Planck Data ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") shows results equivalent to Figures [3](#S4.F3 "Figure 3 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")b and [4](#S4.F4 "Figure 4 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")–[7](#S4.F7 "Figure 7 ‣ 4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), with the substitution of Planck 1-year data (plus WMAP polarization; [Planck
Collaboration 2013b](#bib.bib88)) for WMAP 9-year data ([Hinshaw
et al., 2013](#bib.bib53)).

Figure 10: 
Constraints on cosmological models from the cluster data set, CMB data from Planck+WP, ACT and SPT ([Keisler
et al. 2011](#bib.bib57); [Reichardt
et al. 2012](#bib.bib98); [Story
et al. 2013](#bib.bib119); [Das
et al. 2014](#bib.bib36); [Planck
Collaboration 2013b](#bib.bib88)), type Ia supernovae ([Suzuki
et al. 2012](#bib.bib120)), baryon acoustic oscillations ([Beutler
et al. 2011](#bib.bib18); [Padmanabhan
et al. 2012](#bib.bib84); [Anderson
et al. 2014](#bib.bib9)), and their combination. These figures are identical to the equivalent ones in Section [4](#S4 "4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") apart from the substitution of Planck 1-year data (plus WMAP polarization) for WMAP 9-year data. Left to right and top to bottom, the panels correspond to Figures [3](#S4.F3 "Figure 3 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")b, [4](#S4.F4 "Figure 4 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")a, [4](#S4.F4 "Figure 4 ‣ 4.2 Constraints on Neutrino Mass ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")b, [5](#S4.F5 "Figure 5 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass"), [6](#S4.F6 "Figure 6 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")a and [6](#S4.F6 "Figure 6 ‣ 4.3 Constraints on Dark Energy Models ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")b (this page) and [7](#S4.F7 "Figure 7 ‣ 4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass") (second page).

Figure 11: continued

## Appendix C The ISW Effect in Free Growth-Index Models

In our study of the growth index of cosmic structure (Section [4.4](#S4.SS4 "4.4 Constraints on Modifications of Gravity ‣ 4 Cosmological Results ‣ Weighing the Giants IV: Cosmology and Neutrino Mass")), as in our previous analyses, we obtain the contribution of the ISW effect to the anisotropy power spectrum of the CMB temperature fluctuations through an integral over time of the variation of the gravitational potential with respect to conformal time, $\dot{\phi}$ ([Weller &
Lewis, 2003](#bib.bib133)). For the latter, we take the derivative of the gauge invariant Poisson equation

|  |  |  |  |
| --- | --- | --- | --- |
|  | $k^{2}\phi=-4\pi Ga^{2}\rho\Delta,$ |  | (15) |

where $\rho\Delta\equiv\sum\_{i}\rho\_{i}\delta\_{i}+3\mathcal{H}\sum\_{i}(\rho\_{i}+P\_{i})\theta\_{i}$, with $\mathcal{H}$ being the Hubble parameter in conformal time, $\rho\_{i}$ and $P\_{i}$ the densities and pressures for each species $i$, and each of the sums the mass-averaged density contrast, $\delta\_{i}$, and velocity divergence, $\theta\_{i}$, for a given gauge ([Bardeen, 1980](#bib.bib11)). In synchronous gauge, we have $\rho\_{\mathrm{c}}\Delta\_{\mathrm{c}}\equiv\rho\_{\mathrm{c}}\delta\_{\mathrm{c}}$, $\rho\_{\mathrm{b}}\Delta\_{\mathrm{b}}\equiv\rho\_{\mathrm{b}}\delta\_{\mathrm{b}}+3\mathcal{H}\rho\_{\mathrm{b}}\theta\_{\mathrm{b}}k^{-2}$, and $\rho\_{\mathrm{r}}\Delta\_{\mathrm{r}}\equiv\rho\_{\mathrm{r}}\delta\_{\mathrm{r}}+4\mathcal{H}\rho\_{\mathrm{r}}\theta\_{\mathrm{r}}k^{-2}$ for CDM (c), baryons (b), and radiation (r, including massless neutrinos and photons), respectively ([Ma &
Bertschinger, 1995](#bib.bib69)). Note that after recombination the baryon velocity fluctuations evolve as $\dot{\theta}\_{\mathrm{b}}=-\mathcal{H}\theta\_{\mathrm{b}}+c\_{\mathrm{s}}^{2}k^{2}\delta\_{\mathrm{b}}$, where $c\_{\mathrm{s}}$ is the baryonic sound speed, which after baryon-photon decoupling is rapidly driven to zero by adiabatic cooling. This implies that at late times baryonic perturbations will, like those for CDM, follow mainly metric perturbations, $\dot{\delta}\_{\mathrm{b}}\approx\dot{\delta}\_{\mathrm{c}}=-\dot{h}/2$. For radiation, we have $\dot{\delta}\_{\mathrm{r}}=-4\theta\_{\mathrm{r}}/3-2\dot{h}/3$ and $\dot{\theta}\_{\mathrm{r}}=k^{2}(\delta\_{\mathrm{r}}/4-\sigma\_{\mathrm{r}})$, where the anisotropic stress perturbation is defined as $(\rho+P)\sigma\equiv-(\hat{k}\_{i}\hat{k}\_{j}-\delta\_{ij}/3)\Sigma\_{i}^{j}$, with $i$ and $j$ denoting the indexes for the spatial components, and $\Sigma\_{i}^{j}$ the shear stress, which is negligible after recombination. Therefore, in the matter-dominated era we have oscillating solutions for both $\delta\_{\mathrm{r}}$ and $\theta\_{\mathrm{r}}$, and both terms of $\rho\_{\mathrm{r}}\Delta\_{\mathrm{r}}$ (see above) become strongly suppressed by $\rho\_{\mathrm{r}}\propto a^{-4}$. We finally obtain $k^{2}\phi\approx-4\pi Ga^{2}\delta\rho\_{\mathrm{m}}$, and thus

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\dot{\phi}\approx 4\pi G(a^{2}/k^{2})\mathcal{H}\delta\rho\_{\mathrm{m}}\left[1-\Omega\_{\mathrm{m}}(a)^{\gamma}\right].$ |  | (16) |

More discussion can be found in [Rapetti
et al. (2009)](#bib.bib94); [Rapetti
et al. (2010)](#bib.bib95); [Rapetti
et al. (2013)](#bib.bib97).
