<!-- fulltext source=arxiv_html slug=arXiv-0710.4560 fetched=2026-09-18T01:02:01+00:00 -->

# The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects

Neal Dalal
Affiliation: 
Canadian Institute for Theoretical Astrophysics, 60 St. George St,
University of Toronto, Toronto, ON, Canada M5S3H8
  
Olivier Doré
Affiliation: 
Canadian Institute for Theoretical Astrophysics, 60 St. George St,
University of Toronto, Toronto, ON, Canada M5S3H8
  
Dragan Huterer
Affiliation: 
Kavli Institute for Cosmological Physics and Department of Astronomy
and Astrophysics, University of Chicago, Chicago, IL 60637
Affiliation: 
Department of Physics, University of Michigan, 450 Church St,
Ann Arbor, MI 48109
  
Alexander Shirokov
Affiliation: 
Canadian Institute for Theoretical Astrophysics, 60 St. George St,
University of Toronto, Toronto, ON, Canada M5S3H8

Received  August 24, 2026

###### Abstract

We study the effect of primordial nongaussianity on large-scale
structure, focusing upon the most massive virialized objects. Using
analytic arguments and N-body simulations, we calculate the mass
function and clustering of dark matter halos across a range of
redshifts and levels of nongaussianity. We propose a simple fitting
function for the mass function valid across the entire range of our
simulations. We find pronounced effects of nongaussianity on the
clustering of dark matter halos, leading to strongly scale-dependent
bias. This suggests that the large-scale clustering of rare objects
may provide a sensitive probe of primordial nongaussianity. We very
roughly estimate that upcoming surveys can constrain nongaussianity at
the level $|f\_{\rm NL}|\lesssim 10$, competitive with forecasted constraints
from the microwave background.

## I Introduction

One of the fundamental predictions of standard (single-field, slow-roll)
inflationary cosmology is that
the density fluctuations in the early universe that seeded large-scale
structure formation were nearly gaussian random (e.g. [[1](#bib.bib1), [2](#bib.bib2), [3](#bib.bib3), [4](#bib.bib4), [5](#bib.bib5)]).
Constraining or detecting non-gaussianity (NG) is therefore an important and
basic test of the cosmological model. To the extent that it can be measured,
gaussianity has so far been confirmed; the tightest existing
constraints have been obtained from observations of the cosmic
microwave background [[6](#bib.bib6), [7](#bib.bib7)]. Recently, several
inflationary models have been proposed which predict a potentially
observable level of nongaussianity, see e.g. [[8](#bib.bib8), [9](#bib.bib9), [10](#bib.bib10), [11](#bib.bib11), [12](#bib.bib12), [13](#bib.bib13), [14](#bib.bib14), [15](#bib.bib15), [16](#bib.bib16), [17](#bib.bib17), [18](#bib.bib18), [19](#bib.bib19), [20](#bib.bib20), [21](#bib.bib21), [22](#bib.bib22), [23](#bib.bib23)]
and [[24](#bib.bib24)] for a review.
Improved limits on NG would rule out some of these models; conversely, a robust
detection of primordial nongaussianity would dramatically overturn standard
inflationary cosmology and provide invaluable information about the nature of
physical processes in the early universe. In this regard, there has been a
resurgence in studying increasingly more sophisticated methods and algorithms
to constrain (or, if we are lucky, detect) nongaussianity
[[25](#bib.bib25), [26](#bib.bib26), [27](#bib.bib27), [28](#bib.bib28), [29](#bib.bib29)].

Nongaussianity manifests itself not only in the cosmic microwave background
[[30](#bib.bib30), [31](#bib.bib31), [32](#bib.bib32), [33](#bib.bib33)], but also in the late-time
evolution of large-scale structure. For example, detailed measurements of
higher order correlations like the bispectrum or trispectrum of galaxy
clustering could provide a handle on primordial nongaussianity
[[34](#bib.bib34), [35](#bib.bib35), [36](#bib.bib36)]. The abundance of
galaxy clusters, the largest virialized objects in the universe, has also long
been recognized as a sensitive probe of primordial NG
[[37](#bib.bib37), [38](#bib.bib38), [39](#bib.bib39), [40](#bib.bib40), [42](#bib.bib42), [35](#bib.bib35), [41](#bib.bib41)]. Because clusters are rare objects which form from the
largest fluctuations on the tails of the density probability distribution,
their abundance is keenly sensitive to changes in the shape of the PDF such as
those caused by nongaussianity. Large statistical samples of massive clusters
have already been compiled from wide-area optical imaging and spectroscopic
surveys such as the Sloan Digital Sky Survey [[43](#bib.bib43), [44](#bib.bib44)], the
Two-Degree Survey [[45](#bib.bib45)], and from the Red Sequence Survey
[[46](#bib.bib46)] and from X-ray surveys using the Chandra and XMM-Newton
observatories [[47](#bib.bib47), [48](#bib.bib48)]. Future missions, such as
the Dark Energy Survey, Supernova/Acceleration Probe and Large Synoptic Survey
Telescope, will detect and study tens of thousands of clusters, revolutionizing
our understanding of cluster physics as well as providing important constraints
on cosmology [[49](#bib.bib49), [50](#bib.bib50), [51](#bib.bib51), [52](#bib.bib52), [53](#bib.bib53), [54](#bib.bib54), [55](#bib.bib55)].

To exploit the potential of these upcoming surveys as probes of
primordial nongaussianity, it is important to calibrate the effects of
NG on the abundance and clustering of virialized objects. While no
previous work has attempted to quantify the effects of NG on halo
clustering, several groups over the past decade have constructed
fitting formulae for the halo mass function
[[56](#bib.bib56), [57](#bib.bib57), [58](#bib.bib58)]. All of this work,
however, was analytic and relied on the validity of the Press-Schechter
[[59](#bib.bib59)] formalism, plus various further approximations.
The resulting analytic estimates are, in general, rather cumbersome to
compute and have questionable accuracy. As discussed below, the
Press-Schechter model provides only a qualitative description of halo
abundance, and fails to reproduce the halo mass function to within an
order of magnitude over the mass and redshift range accessible to
current and future cluster surveys. Therefore, analytic models for NG
cluster abundance based on the Press-Schechter ansatz may not be
sufficiently accurate. Given the high-quality data soon to be
available, a much more precise calculation of cluster statistics will
be required. Quite recently, two groups have attempted to
quantify the mass function of clusters in NG models using N-body
simulations [[60](#bib.bib60), [61](#bib.bib61)], reaching contradictory conclusions.

In this paper, we use analytic arguments and
numerical simulations to estimate the effect of
NG on the abundance and clustering of virialized objects.
Because N-body simulations can be expensive and there is a wide NG parameter
space, we also strive to make our results useful to a cosmologist who
is not necessarily equipped with the machinery or patience to run simulations or
evaluate difficult analytic expressions. To this end, we provide a simple,
physically motivated fitting formula for the halo mass function and
halo bias, which we calibrate to our N-body simulations.

Our main results are that the mass function and correlation function
of massive halos can be significantly modified by primordial
nongaussianity. We find a somewhat weaker effect of NG on the mass
function than previous analytic estimates. We also show analytically
and numerically that NG strongly affects the clustering of rare
objects on large scales, implying that measurements of the large-scale
power spectrum can place stringent bounds on NG.

The plan of the paper is as follows. In Section [II](#S2 "II Analytic estimates ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects") we derive
analytic expressions for the abundance and clustering of rare peaks.
In Section [III](#S3 "III Numerical simulations ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects") we describe our N-body simulations, followed
in Section [IV](#S4 "IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects") by a discussion of our measured halo mass
function, and our fitting formula for the mass function. In Section
[V](#S5 "V Halo clustering ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects") we present measurements of halo clustering within our
simulations, and in Section [VI](#S6 "VI Cosmological consequences ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects") we discuss cosmological
implications of our findings.

## II Analytic estimates

In this section, we derive analytic expressions for the abundance and
clustering of dark matter halos. As mentioned above,
such analytic approaches provide a useful qualitative framework for
understanding gravitational collapse, however they
cannot be used to describe quantitatively either the mass function or
the clustering amplitude of collapsed objects. The expressions
derived here are meant solely to motivate the more precise fitting
formulae described in subsequent sections.

We will focus on local NG of the form [[58](#bib.bib58), [62](#bib.bib62), [1](#bib.bib1)]

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Phi\_{\rm NG}({\bm{x}})=\phi({\bm{x}})+f\_{\rm NL}(\phi^{2}({\bm{x}})-\langle\phi^{2}\rangle).$ |  | (1) |

In our notation, $\Phi=-\Psi$, where $\Psi$ is the usual Newtonian
potential. On subhorizon scales, this choice of Newtonian gauge is
valid, and the potentials $\Phi$ and $\Psi$ satisfy the Poisson
equation relating them to the overdensity $\delta$. On superhorizon
scales, the Bardeen potential $\Phi$ and overdensity $\delta$ are
proportional, and not related by a Poisson
equation, so our analysis will be valid only on subhorizon scales.
With this choice of convention, positive $f\_{\rm NL}$ corresponds to
positive skewness of the density probability distribution, and hence
an increased number of massive objects.

For simplicity, we neglect the effect of the CDM transfer functions,
which modify the shape of the $\Phi$ power spectrum after
nongaussianity is generated. Then the
probability distribution for $\Phi\_{\rm NG}$ is easy to write
down, however the probability distribution for the density
$\delta\_{\rm NG}$ cannot be expressed analytically. Nevertheless, we
can make progress by assuming that the NG correction is small, and by
focusing only on high peaks of the density.
The Laplacian of $\Phi\_{\rm NG}$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\nabla^{2}\Phi\_{\rm NG}=\nabla^{2}\phi+2f\_{\rm NL}[\phi\nabla^{2}\phi+|\nabla\phi|^{2}].$ |  | (2) |

Because $\phi$, $\nabla\phi$, and $\nabla^{2}\phi$ are all Gaussian
fields whose statistics are fully specified by their power
spectra, then Eqn. ([2](#S2.E2 "In II Analytic estimates ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")) above, relating
$\delta\_{\rm NG}=-(3\Omega\_{m}/2ar\_{H}^{2})\nabla^{2}\Phi\_{\rm NG}$ to the
Gaussian fields, allows us to determine fully the statistics of the
nongaussian density $\delta\_{\rm NG}$. For example, the skewness of
$\delta\_{\rm NG}$ becomes, to lowest order in $f\_{\rm NL}$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S\_{3}=\frac{\langle\delta\_{\rm NG}^{3}\rangle}{\langle\delta\_{\rm NG}^{2}\rangle^{2}}=6f\_{\rm NL}\frac{\langle\phi\delta\rangle}{\sigma\_{\delta}^{2}}.$ |  | (3) |

On the average, the two terms $\phi\nabla^{2}\phi$ and $|\nabla\phi|^{2}$
in Eqn. ([2](#S2.E2 "In II Analytic estimates ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")) are of the same order; the fact that they
have equal but opposite expectation value is why
$\langle\delta\_{\rm NG}\rangle=\langle\delta\rangle=0$.
However we are mainly interested in high peaks, where
$\delta\propto-\nabla^{2}\phi$ is large. Because $|\nabla\phi|^{2}$ is
uncorrelated with $\nabla^{2}\phi$, and because at the peak of $\phi$
its derivative vanishes, we assume that $|\nabla\phi|^{2}$ may be neglected
compared to $\phi\nabla^{2}\phi$ in the vicinity of rare, high peaks.
Then applying the Poisson equation near the peak gives
$\delta\_{\rm NG}\approx\delta[1+2f\_{\rm NL}\phi]$. This expression
applies for the primordial density and potential fields at early
times. At late times, $\delta\_{\rm NG}$ subsequently grows according
to the linear growth factor $D(a)$, while the potential decays like
$g(a)\propto D(a)/a$. Therefore, rewriting this expression in terms of
the late-time fields, we find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\delta\_{\rm NG}\approx\delta[1+2f\_{\rm NL}\phi/g(a)].$ |  | (4) |

We see that the peak height is enhanced by a factor proportional to
the primordial potential $\phi\_{p}=\phi/g(a)$, rather than the evolved
potential.11
1
An earlier version of this paper neglected to
distinguish between the primordial and late-time potential, and
hence omitted the $g(a)$ factor. We are grateful to N. Afshordi
for pointing this out to us.

Equation ([4](#S2.E4 "In II Analytic estimates ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")) will be the basis for the rest of our discussion.
We emphasize that this is only valid in the vicinity of peaks, and so
we focus on peaks for the remainder of this
discussion. Because the fields $\delta$
and $\phi$ are Gaussian distributed, we can immediately derive
properties of the distribution of $\delta\_{\rm NG}$.
For example, consider the mean shift in peak height for a peak
of Gaussian density $\delta$:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\langle\delta\_{\rm NG}|\delta\rangle$ | $\displaystyle=$ | $\displaystyle\delta\,(1+2f\_{\rm NL}\langle\phi\_{p}|\delta\rangle)$ |  | (5) |
|  |  | $\displaystyle=$ | $\displaystyle\delta\,\left(1+2f\_{\rm NL}\frac{\langle\phi\delta\rangle}{g\sigma\_{\delta}^{2}}\delta\right)\;.$ |  |

If the peak height $\delta$ and background potential $\phi$ were
uncorrelated, then there would be no systematic shift in peak height,
and hence no change in the abundance of massive halos. However,
$\delta$ and $\phi$ are correlated, implying that rare peaks are
systematically raised or lowered, depending upon the sign of $f\_{\rm NL}$.
Therefore, we expect changes in the mass function and the correlation
function.

In the appendix, we derive expressions for the abundance and
clustering of regions above a given threshold, which then give the
clustering and mass function of halos in the Press-Schechter model.
However, we can derive the form of the halo correlation function using
a very simple argument. The halo correlation function is usually
parameterized in terms of the halo bias $b$, which is the rate of
change of the halo abundance as the background density is varied.
Writing the matter overdensity as $\delta$ and the halo overdensity as
$\delta\_{h}$, we can define the halo bias as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\delta\_{h}=b\,\delta.$ |  | (6) |

It is normally assumed that $b\to$ const on large scales, but we will
not make this assumption here. Consider a long-wavelength mode,
providing a background density perturbation $\delta$ and corresponding
potential fluctuation $\phi$. In the absence on nongaussianity, this
perturbation raises subthreshold peaks above threshold, and thereby
enhances the abundance of super-threshold peaks by $b\_{L}\delta$, where
$b\_{L}$ is the usual (Gaussian) Lagrangian bias. For nonzero $f\_{\rm NL}$,
the long-wavelength mode also enhances the peak height by
$2f\_{\rm NL}\phi\_{p}\delta\_{\rm pk}$, and we will focus on peaks near
threshold, such that $\delta\_{\rm pk}\simeq\delta\_{c}$. This
provides an additional enhancement factor, giving a total

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\delta\_{h}=b\_{L}(\delta+2f\_{\rm NL}\phi\_{p}\delta\_{c}).$ |  | (7) |

In Fourier space, the potential and density modes are related by
$\phi=(3\Omega\_{m}/2ar\_{H}^{2}k^{2})\delta$, and so we see that the
nongaussian bias acquires a correction

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta b(k)=2b\_{L}f\_{\rm NL}\delta\_{c}\frac{3\Omega\_{m}}{2ag(a)\,r\_{H}^{2}k^{2}}\;,$ |  | (8) |

where again $b\_{L}$ refers to the usual Lagrangian bias for halos of
this mass with Gaussian fluctuations. The total Lagrangian bias is
then $b\_{L}(k)=b\_{L}+\Delta b(k)$.

Since we have been working with the clustering of peaks in the initial
density distribution, the
above expression for the bias applies only to the early-time,
Lagrangian bias. Translating these results to
late-time, Eulerian bias is straightforward, however. The bias of
Eulerian halos is simply $b=1+b\_{L}$ : the excess of halos in some
Eulerian volume with overdensity $\delta$ is $b\delta=b\_{L}\delta+\delta$. The first term corresponds to the excess of peaks in the
initial Lagrangian volume, which are advected into the Eulerian
volume. The second term arises because an Eulerian volume with
overdensity $\delta$ has $\delta$ times more mass than an average
volume, and therefore $\delta$ times more peaks.

In summary, local NG generates a scale-dependent correction to the
bias of galaxies and halos, of the form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta b(k)=2(b-1)f\_{\rm NL}\delta\_{c}\frac{3\Omega\_{m}}{2a\,g(a)r\_{H}^{2}k^{2}}$ |  | (9) |

where $b$ here now refers to the Eulerian bias of the tracer
population. In subsequent sections, we show that this simple
expression, despite the underlying assumptions and
approximations in its derivation,
matches surprisingly well the halo clustering measured in our
numerical simulations.

## III Numerical simulations

Figure 1: Slice through simulation outputs at $z=$ $0$ generated with the
same Fourier phases but with $f\_{\rm NL}=$$-5000,$ $-500,$ $0,$ $+500,$ $+5000$
respectively from top to bottom. Each slice is 375 $h^{-1}\,{\rm Mpc}$ wide, and 80 $h^{-1}\,{\rm Mpc}$ high
and deep. We can easily match by eye much of the large scale
structure; for example, an overdense region sits on the left, while
an underdense region (void) falls on the right, in all panels.
Note that for positive $f\_{\rm NL}$, overdense regions are more evolved
and produce more clusters than their Gaussian counterparts, while
underdense regions are less evolved (e.g. grid lines are still
visible). For negative $f\_{\rm NL}$, underdense regions are more evolved,
producing deeper voids, while overdense regions are less evolved, as
illustrated by the grid lines apparent in the left of the top panel.

We numerically simulate the growth of structure in nongaussian
cosmologies using the adaptive P3M parallel N-body code
GRACOS22
2
http://www.gracos.org
[[63](#bib.bib63), [64](#bib.bib64)]. Non-gaussian initial conditions were
generated using
the following procedure. First, we generated a Gaussian random
potential field $\phi({\bf x})$ using a power-law power spectrum with
a scalar (density) index $n\_{s}=0.96$, and normalized so that
$\sigma\_{8}=0.76$ [[6](#bib.bib6)] when multiplied by the matter transfer
function. Following Refs. [[58](#bib.bib58), [62](#bib.bib62), [1](#bib.bib1)], we then
computed the nongaussian potential $\Phi$ by adding a quadratic
correction in configuration space,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Phi({\bm{x}})=\phi({\bm{x}})+f\_{\rm NL}(\phi^{2}-\langle\phi^{2}\rangle).$ |  | (10) |

We then multiplied $\Phi$ by matter transfer functions in Fourier
space for $\Omega\_{m}=0.24$, $\Omega\_{\Lambda}=0.76$, and computed
particle displacements and velocities using the Zeldovich
approximation [[65](#bib.bib65)].

One immediate drawback to this approach is that, due to the strong
Fourier mode coupling generated by the $f\_{\rm NL}$ term, our results may be
affected by the absence of modes below the fundamental frequency or
above the Nyquist frequency of our simulation volume. All N-body
simulations can cover only a finite dynamic range, and therefore have
zero power outside of their $k$-space volumes. For Gaussian
simulations, this is believed not to be a serious defect, because mode
coupling is unimportant on linear scales, and on nonlinear scales, the
mode coupling generally transfers power to small scales. In our case,
however, the $f\_{\rm NL}$ term couples all the modes sampled in our
simulation to all the modes absent in our simulation. We have
performed rudimentary estimates of the magnitude of this effect, by
running simulations in which we high-pass or low-pass filter the
$f\_{\rm NL}$ correction, and do not observe significant changes in the
overall behavior. Strictly speaking, however, it
must be borne in mind that our results apply only for power spectra
that are non-vanishing only over the finite range covered by our
simulation volume.

We have performed several simulations using both Gaussian and
nongaussian initial conditions. For each
Gaussian realization, we construct non-Gaussian realizations using the
same Fourier phases, with various $f\_{\rm NL}$, e.g. $f\_{\rm NL}=\pm 500$, $\pm 50$,
and $\pm 5$. We ran simulations from a starting
expansion factor $a=0.02$ until the present time, $a=1$, using $512^{3}$
particles in a box of sidelength $L=800h^{-1}$ Mpc. For these parameters,
each particle has a mass $m\_{p}=2.52\times 10^{11}h^{-1}M\_{\odot}$, so that
clusters with masses exceeding $M>10^{14}h^{-1}M\_{\odot}$ are resolved with
$N\gtrsim 400$ particles. Since we are interested mainly in the masses and
positions of cluster-sized halos, and not their internal structure, we have not
used high force resolution: we employ a Plummer softening length $l$ of 0.2
times the mean interparticle spacing. We have checked that using higher force
resolution ($l$ half as large) does not appreciably change the mass function.
All simulations were performed at the Sunnyvale cluster at CITA; depending upon
the value of $f\_{\rm NL}$, the simulations completed in 2-3 hours each on
typically 8-10 nodes. As a consistency check, we have also run a
small number of $1024^{3}$ particle simulations with the same particle
mass and force softening as above, but with twice the box size. These
larger runs typically completed in 18-20 hours on 64 nodes. In
Figure [1](#S3.F1 "Figure 1 ‣ III Numerical simulations ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects"), we plot slices through our simulation volume at
redshift $z=0$, and the effects of varying $f\_{\rm NL}$ are readily apparent. Large
positive $f\_{\rm NL}$ accelerates the evolution of overdense regions and retards the
evolution of underdense regions, while large negative $f\_{\rm NL}$ has precisely the
opposite effect.

## IV The halo mass function

Figure 2: Mass functions measured from simulations with various $f\_{\rm NL}$
and identical phases (3 sets of initial conditions were used for
each $f\_{\rm NL}$).
The top panel shows the mass function as well as the Gaussian
fitting formula (dashed yellow line) from [Warren et al. [66]](#bib.bib66).
The bottom panel shows the ratio between the measured $f\_{\rm NL}=0$
Gaussian mass functions and the respective non-Gaussian ones.

We constructed late-time halo catalogues at redshifts $z=1$, 0.5, and
0 using the friends-of-friends group finder [[67](#bib.bib67)], with linking
length $b=0.2$. For Gaussian simulations, the halo mass function
constructed this way has been extensively calibrated
[[68](#bib.bib68), [66](#bib.bib66)]. Resulting mass functions are plotted in
Figure [2](#S4.F2 "Figure 2 ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects").

### IV.1 A new fitting formula

Having measured the halo mass function, we next would like to construct a
fitting function along the lines of those used for Gaussian simulations
[[68](#bib.bib68), [66](#bib.bib66)]. As mentioned above, previous techniques for estimating
the nongaussian mass function have been based upon the Press-Schechter
[[59](#bib.bib59)] ansatz. Given that the Press-Schechter mass function
fails to match the halo mass function to within an order of magnitude over the
mass and redshift ranges of interest to us [[66](#bib.bib66)], and given the lack of
any physical basis to the Press-Schechter ansatz [[69](#bib.bib69), [70](#bib.bib70)], we have
instead adopted an alternative approach which we describe next.

We start by noting that the halo mass function $dn/dM$ has been
precisely calibrated for Gaussian cosmologies. Consider a Gaussian
realization of the density field, which at late times evolves to
produce halos with mass function $dn/dM\_{0}$. As we slowly vary
$f\_{\rm NL}$ away from zero, the structures forming at late times also
slowly vary (c.f. Figure [1](#S3.F1 "Figure 1 ‣ III Numerical simulations ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")),
producing a different mass spectrum $dn/dM\_{f}$.
If we vary $f\_{\rm NL}$ slowly enough, we can track the change in mass and
position for individual halos: i.e., for each halo of mass $M\_{0}$ for
$f\_{\rm NL}=0$, we can uniquely identify a corresponding halo of mass $M\_{f}$
for $f\_{\rm NL}\neq 0$, as long as $|f\_{\rm NL}|$ is sufficiently small. Since we
know precisely the number of halos as a function of $M\_{0}$, if we
can determine the mapping $M\_{0}\rightarrow M\_{f}$, we will then have an
estimate of the non-Gaussian mass function $dn/dM\_{f}$ via

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{dn}{dM\_{f}}=\int dM\_{0}\frac{dn}{dM\_{0}}\frac{dP}{dM\_{f}}(M\_{0}),$ |  | (11) |

where $dP/dM\_{f}(M\_{0})$ is the probability distribution that a Gaussian
halo of mass $M\_{0}$ maps to a non-Gaussian halo of mass $M\_{f}$. Note
that the probability distribution function $dP/dM\_{f}$ need not
integrate to unity, $\int dM\_{f}\,dP/dM\_{f}\neq 1$ in general, since the
total number of halos is not conserved: halos can merge or split as
$f\_{\rm NL}$ is varied.

The next step is to determine the probability distribution
$dP/dM\_{f}(M\_{0})$, by matching halos between Gaussian and non-Gaussian
simulations. We match halos by requiring that matching pairs have
significantly overlapping Lagrangian volumes; i.e. by requiring that
halos have many particles in common, where particles are labeled by
their Lagrangian coordinates in the initial conditions. For each halo
$M\_{f}$ in a non-Gaussian run, we loop over the halo’s particles and
identify which Gaussian halos own those particles in the run with
$f\_{\rm NL}=0$. The Gaussian halo owning the largest fraction (exceeding
1/3) of the particles is then identified as the match for non-Gaussian
halo $M\_{f}$. Each Gaussian halo $M\_{0}$ can have one, several, or zero
matching non-Gaussian halos, depending on $f\_{\rm NL}$. By stacking
Gaussian halos of similar mass $M\_{0}$, we can determine
$dP/dM\_{f}(M\_{0})$.

Figure 3: Distribution of $M\_{f}$ as a function of $M\_{0}$ for one
$f\_{\rm NL}=+500$ simulation. The average shift towards higher masses
is clearly visible.

Examples of the probability distribution are shown in Figure [4](#S4.F4 "Figure 4 ‣ IV.1 A new fitting formula ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects"), and
the mean and variance of the PDF are plotted in Figure [5](#S4.F5 "Figure 5 ‣ IV.1 A new fitting formula ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects"). The
behavior of the mean $\langle M\_{f}\rangle$ and variance are quite regular,
and appear consistent with simple power laws:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\left\langle\frac{M\_{f}}{M\_{0}}\right\rangle-1$ | $\displaystyle=$ | $\displaystyle 1.3\ 10^{-4}\,f\_{\rm NL}\sigma\_{8}\,\sigma(M\_{0},z)^{-2}$ |  | (12) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle{\rm var}\left(\frac{M\_{f}}{M\_{0}}\right)$ | $\displaystyle=$ | $\displaystyle 1.4\ 10^{-4}\,(f\_{\rm NL}\sigma\_{8})^{0.8}\sigma(M\_{0},z)^{-1},$ |  | (13) |

where the rms overdensity dispersion $\sigma(M,z)$ is defined as usual by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma^{2}=\int\frac{k^{3}}{2\pi^{2}}P(k)\,W^{2}(kR)\frac{dk}{k},$ |  | (14) |

where we use a top-hat window $W(x)=3j\_{1}(x)/x$ for
$R=(3M/4\pi\bar{\rho}\_{m})^{1/3}$, and $P(k)$ and $\bar{\rho}\_{m}$ are the matter
power spectrum and energy density respectively.

Because we desire a simple fitting formula, we assume that we can approximate
the PDF as a normalized Gaussian whose mean and variance are given above, even
though the PDF shape is quite clearly nongaussian (c.f. Figure [4](#S4.F4 "Figure 4 ‣ IV.1 A new fitting formula ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")). As we show below, however, even this crude
approximation is sufficient to achieve the $\sim 10\%$ precision in the halo
mass function provided by standard fitting formulae for Gaussian simulations
[[71](#bib.bib71)]. Then Eq. ([11](#S4.E11 "In IV.1 A new fitting formula ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")), together with $dP/dM\_{f}(M\_{0})$ which is
assumed to be a Gaussian with the mean and variance given in
Eqs. ([12](#S4.E12 "In IV.1 A new fitting formula ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")) and ([13](#S4.E13 "In IV.1 A new fitting formula ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")), fully specify our fitting
function. Essentially, we have written the NG mass function as a convolution
of the Gaussian mass function with a Gaussian kernel.

Figure 4: The probability distribution that a Gaussian
halo of mass $M\_{0}$ maps to a non-Gaussian halo of mass $M\_{f}$, i.e. $dP/dM\_{f}(M\_{0})$. This plot can be understood as a (binned)
slice through Fig. [3](#S4.F3 "Figure 3 ‣ IV.1 A new fitting formula ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects").
Here we show the measured $dP/dM\_{f}(M\_{0})$ (solid lines)
and Gaussian fit (dashed line) for various $f\_{\rm NL}$ in the mass bin
$1<M\_{0}/10^{14}M\_{\hbox{$\odot$}}<3$. The left panel corresponds to $f\_{\rm NL}>0$ and
the right panel corresponds to $f\_{\rm NL}<0$. Note that both the width and
mean value of the PDF vary with $f\_{\rm NL}$. The probability distribution
is clearly poorly fit by a Gaussian, however as discussed in the text,
it provides an adequate fit given the precision with which we can
determine the halo mass function from N-body
simulations. Whereas the high mass tail for $f\_{\rm NL}>0$ (left
panel) indicates that many $f\_{\rm NL}=0$ halos will merge into more massive
ones, the low mass tail for $f\_{\rm NL}<0$ (right panel) accounts for the
disruption of $f\_{\rm NL}=0$ halos into lighter ones.

Figure 5: Measured mean (left) and rms dispersion (right) of the mass
shift, $M\_{f}/M\_{0}-1$, as a function of $\sigma(M\_{0},z)$. Note
that measurements at various redshift outputs ($z=0,0.5,1$) have been
combined in this plot, and that the $f\_{\rm NL}$ scaling has been
divided out. The dashed lines shows our fits to these moments,
c.f. Eqs. ([12](#S4.E12 "In IV.1 A new fitting formula ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")) and ([13](#S4.E13 "In IV.1 A new fitting formula ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")).

### IV.2 Review of previous fitting formulae

Before showing a comparison of the simulated mass function
to our proposed fitting formula, we first describe
alternative fitting formulae previously suggested in the literature:
the Extended Press-Schechter (EPS) formalism [[72](#bib.bib72)], and
the model of [Matarrese et al. [58, hereafter MVJ]](#bib.bib58).

#### IV.2.1 Extended Press-Schechter

The EPS formalism generalizes the widely used Press-Schechter
[[59](#bib.bib59)] model, which posits that the fraction of mass
in collapsed objects is equal to twice the fraction of the
volume occupied by density peaks exceeding some critical
overdensity $\delta\_{c}$. (The factor of two arises from the so-called
‘cloud-in-cloud’ problem [[69](#bib.bib69)].) Therefore the collapsed
fraction becomes

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle F(>M)$ | $\displaystyle\equiv$ | $\displaystyle 2\int\_{\delta\_{c}}^{\infty}P(\delta;M)d\delta$ |  | (15) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  | $\displaystyle=$ | $\displaystyle 2\,\int\_{\delta\_{c}/\sigma(M)}^{\infty}P\_{\rm G}(\nu)d\nu$ |  | (16) |

where the probability distribution $P(\delta;M)$ that the density
smoothed on mass scale $M$ equals $\delta$ is simply $P\_{\rm G}(\nu)$,
the Gaussian distribution with zero mean and unit variance for
$\nu=\delta\_{c}/\sigma$, with $\sigma(M)$ given by Eq. ([14](#S4.E14 "In IV.1 A new fitting formula ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")).
Note that $F(0)=1$ for hierarchical cosmologies where $\sigma(M)$
diverges as $M\rightarrow 0$; that is, all matter is assumed to
be in virialized objects of some mass.

The differential mass function may then be readily computed:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $M\frac{dn}{dM}={\bar{\rho}}\_{m}\left|{dF\over dM}\right|.$ |  | (17) |

For a Gaussian PDF, the mass $M$ enters the right-hand side of this
expression only via the lower bound of the integral,
$\delta\_{c}/\sigma(M)$, so we immediately obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left({dn\over d\ln M}\right)\_{\rm PS}=2\,{{\bar{\rho}}\_{m}\over M}{\delta\_{c}\over\sigma}\left|{d\ln\sigma\over d\ln M}\right|P\_{\rm G}(\delta/\sigma).$ |  | (18) |

This gives the well-known Press-Schechter mass function.

Figure 6: Ratios of the NG to Gaussian mass functions as a function of mass and
at redshifts $z=0$ (black), $z=0.5$ (blue) and $z=1$ (red). Points with error
bars denote results from our simulations. Solid lines represent our fitting
formula. Dashed and dotted lines denote the EPS
and MVJ fitting functions respectively. Note that the EPS and MVJ agree
mutually, but both significantly overestimate the effects of nongaussianity.
(The discontinuity of EPS and MVJ fitting functions at $M\sim 2\cdot 10^{14}\,M\_{\odot}$ is due to transition from a smaller simulation box to the larger one.)

A class of fitting formulae based on this approach, and loosely called
‘Extended Press-Schechter’ (though apparently unrelated to the work of Refs. [[73](#bib.bib73), [74](#bib.bib74)]) attempt to generalize this argument using nongaussian
PDFs. The most obvious way of making this generalization, i.e. inserting the
nongaussian PDF $P(\delta;M)$ into Eq. ([17](#S4.E17 "In IV.2.1 Extended Press-Schechter ‣ IV.2 Review of previous fitting formulae ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")), faces several
immediate difficulties, however. First, the Press-Schechter factor of 2 is no
longer valid; rather the cloud-in-cloud correction will depend upon the
specific form of nongaussianity. Second, the shape of the PDF $P(\delta;M)$
now depends upon $M$ and so we cannot simply replace the derivative of the
integral in Eq. ([17](#S4.E17 "In IV.2.1 Extended Press-Schechter ‣ IV.2 Review of previous fitting formulae ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")) by the integrand. Lastly, and
prosaically, the Press-Schechter mass function does not, in fact, fit the halo
mass function in N-body simulations well, and so starting from PS is guaranteed
to fail in fitting the nongaussian mass function.

The approach adopted by many previous workers (e.g. [[72](#bib.bib72)])
has instead been to assume that, although Press-Schechter cannot be
used to derive the Gaussian mass function, it may be used to compute
the departure of the mass function from its Gaussian value, i.e.

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{n\_{\rm NG}(M,z)}{n\_{\rm G}(M,z)}={{\displaystyle d\over dM}\,F\_{\rm NG}(>M)\over{\displaystyle d\over dM}\,F\_{\rm G}(>M)}$ |  | (19) |

where $F$ is given by Eq. ([15](#S4.E15 "In IV.2.1 Extended Press-Schechter ‣ IV.2 Review of previous fitting formulae ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")). In this approach, the
nongaussian mass function is computed by multiplying the Gaussian mass
function (not Press-Schechter, but [Jenkins et al. [68]](#bib.bib68) or [Warren et al. [66]](#bib.bib66))
by the above ratio.

The EPS prediction for the halo mass function is therefore given by the
derivatives of the PDF tails given in Eq. ([19](#S4.E19 "In IV.2.1 Extended Press-Schechter ‣ IV.2 Review of previous fitting formulae ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")) above. To implement
this prescription, we compute the PDF tails directly from the initial
conditions of our simulations: at each redshift we are interested in, we
integrate the linearly evolved PDF to compute $F\_{\rm NG}(M)$ at masses ranging
from about $10^{12}$ to $10^{16}M\_{\odot}$. Then we compute the mean value of
$F\_{\rm NG}(M)$ averaged over 10 independent N-body simulations. Finally, we
fit a cubic spline through the (computed mean of) $F\_{\rm NG}(\ln M)$ and
differentiate with respect to mass. Evaluation of this formula
becomes extremely difficult at high masses, simply because the
statistics of peaks at these high masses becomes too noisy.

#### IV.2.2 MVJ

The MVJ [[58](#bib.bib58)] mass function is a further approximation to the EPS
model described above. Instead of numerically computing the PDF and
its tails for each $f\_{\rm NL}$, it is assumed that the ratio in
Eq. ([19](#S4.E19 "In IV.2.1 Extended Press-Schechter ‣ IV.2 Review of previous fitting formulae ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")) may be determined from the skewness of the PDF.
The expression for the mass function becomes [[61](#bib.bib61)]

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\left({dn\over d\ln M}\right)\_{\rm MVJ}$ | $\displaystyle=$ | $\displaystyle 2{\bar{\rho}\_{M}\over M}P\_{G}\left({\delta\_{\*}\over\sigma\_{M}}\right)\times$ |  | (20) |
|  |  |  | $\displaystyle\left[{1\over 6}{\delta\_{\*}^{3}\over\delta\_{c}}\left|{dS\_{3,M}\over d\ln M}\right|+\delta\_{\*}\left|{d\sigma\_{M}\over d\ln M}\right|\right]$ |  |

where

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\delta\_{\*}$ | $\displaystyle\equiv$ | $\displaystyle{\delta\_{c}\over\sqrt{1-S\_{3,M}\delta\_{c}/3}}$ |  | (21) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle S\_{3,M}$ | $\displaystyle\equiv$ | $\displaystyle{\langle\delta^{3}\rangle\_{M}\over\langle\delta^{2}\rangle\_{M}^{2}}$ |  | (22) |

where $\langle\delta^{n}\rangle\_{M}$ is $n$th moment of the density field
evaluated on the characteristic mass scale $M$, and $S\_{3,M}$ is the
skewness on that mass scale.

The advantage of the MVJ formula is that it does not require
specification of the PDF of the density field — however, it does
require knowledge of the skewness $S\_{3,M}$. In this work, we compute the
moments of the density field directly from our simulations at the
starting epoch $a=0.02$, then scale them with the linear growth
function to the desired epoch. We can then evaluate the MVJ expression
in Eq. ([20](#S4.Ex2 "In IV.2.2 MVJ ‣ IV.2 Review of previous fitting formulae ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")). Unlike the EPS approach described above, the
formula does not become intractable at high masses. On the other
hand, MVJ becomes onerously expensive to calculate at
low levels of nongaussianity (e.g. $|f\_{\rm NL}|\lesssim 100$), simply
because the scatter in the measured skewness from run to run becomes
comparable to that generated by primordial nongaussianity. To see
this, note that the scatter in $\langle\delta^{3}\rangle\_{M}$ is roughly
$\sigma\_{3}\simeq\sigma\_{M}^{3}\sqrt{15/N}$ for $N=M\_{\rm box}/M$ samples.
Approximating $\langle\delta^{3}\rangle\_{M}\sim 6f\_{\rm NL}\sigma\_{M}^{3}\sigma\_{\phi}$,
then for a $512^{3}$ grid and mass scale of 200 cells, and taking
$\sigma\_{\phi}=4\times 10^{-5}$, requiring
$\langle\delta^{3}\rangle\_{M}/\sigma\_{3}>5$ translates into $|f\_{\rm NL}|\gtrsim 100$.

### IV.3 Results and comparison to previous work

Figure [6](#S4.F6 "Figure 6 ‣ IV.2.1 Extended Press-Schechter ‣ IV.2 Review of previous fitting formulae ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects") shows the ratios $n\_{\rm NG}/n\_{\rm G}$ for
$f\_{\rm NL}=500$ (left panel) and $-500$ (right panel). Simulation values are denoted
with error bars, colored black ($z=0$), blue ($z=0.5$) and red ($z=1$). To
compute the error bars in the ratios, and taking account of the fact that
$n\_{\rm NG}$ and $n\_{\rm G}$ measurements are correlated, we have adopted the
larger error of the two alone (rather than adding them in quadrature), which is
the error in $n\_{\rm G}$ ($n\_{\rm NG}$) for $f\_{\rm NL}>0$ ($f\_{\rm NL}<0$). The solid
lines denote our fits explained in Sec. [III](#S3 "III Numerical simulations ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects"). Dashed lines refer to
the EPS results, while the dotted lines represent the MVJ fitting function.
The results clearly indicate that, while the EPS and the MVJ functions mutually
agree33
3
The agreement between the EPS and MVJ is even better when an
alternative expression is used in for $f\_{\rm NL}>0$, as pointed out
[Grossi et al. [61]](#bib.bib61); see their Eq. (4). We have not used this correction in
our
Fig. [6](#S4.F6 "Figure 6 ‣ IV.2.1 Extended Press-Schechter ‣ IV.2 Review of previous fitting formulae ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")., they both overestimate the effects of
nongaussianity as found by our simulations, at a level typically $\lesssim 100\%$ although dependent upon mass and redshift.

This result appears to disagree with the work of [Kang et al. [60]](#bib.bib60), who find a large
discrepancy between EPS/MVJ and their simulations’ mass function, in the sense
that their simulations show a much larger effect of nongaussianity than
predicted by the EPS type formalism. However, as noted by these authors, their
simulations used a rather small number of particles ($\sim 128^{3}$) in a volume
nearly 20$\times$ smaller than ours, so it is unclear how well they probe the
statistics of the rare objects of interest to us. In contrast, [Grossi et al. [61]](#bib.bib61)
have found very good agreement between the MVJ formula and their simulations’
results. While our fitting function is in mild disagreement with the MVJ
fitting formula, it is unclear whether our simulations are in disagreement with
the simulations of [Grossi et al. [61]](#bib.bib61). Their simulations used a somewhat different
cosmological model (higher $\sigma\_{8}$) than ours, they have plotted cumulative
rather than differential mass functions, and of course the error bars in both
their plots and ours are considerable.

In summary, we conclude that our simple fitting function appears consistent
with the measured mass function from our simulations to within $\sim 10\%$ over
the entire range of masses and redshifts that we consider. Since this is the
level of precision that various N-body codes agree with each other in the mass
function [[71](#bib.bib71)], we have not attempted to achieve better agreement.
EPS-like fitting formulae, such as the model of MVJ [[58](#bib.bib58)], appear to
overestimate the effects of nongaussianity. The level of discrepancy increases
with increasing mass and redshift.

## V Halo clustering

Figure 7: Cross-power spectra for various $f\_{\rm NL}$. The upper panel
displays $P\_{h\delta}(k)$, measured in our simulations at $z=1$ for
halos of mass $1.6\times 10^{13}M\_{\odot}<M<3.2\times 10^{13}M\_{\odot}$. The solid line corresponds to the theoretical prediction
for $P\_{\delta\delta}$ with a fitted bias $b\_{0}$=3.25. We see a
strongly scale-dependant correction to the bias for $f\_{\rm NL}\neq 0$,
increasing towards small $k$ (large scales). The bottom panel
displays the ratio $b(k,f\_{\rm NL})/b(k,f\_{\rm NL}=0)$. The errors are computed
from the scatter amongst our simulations and within the
bins. Triangles correspond to our large ($1024^{3}$ particle)
simulations whereas diamonds correspond to our smaller ($512^{3}$
particle) simulations. The dotted lines correspond to our expression for
the bias dependence on $f\_{\rm NL}$ defined in Eq. ([9](#S2.E9 "In II Analytic estimates ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")).

Beyond one-point statistics like the halo mass function, N-body
simulations also allow us to compute higher order statistics like the
correlation function or its Fourier transform, the power spectrum.
As shown in Sec. [A.2](#A1.SS2 "A.2 Nongaussianity ‣ Appendix A The abundance and clustering of high peaks ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects"), we expect nongaussianity to
produce pronounced effects on the halo power spectrum, specifically in
the form of scale-dependent halo bias on large scales. This may seem
somewhat surprising, due to very general arguments previously given in
the literature that galaxy bias is expected to be independent of scale
in the linear regime [[75](#bib.bib75), [76](#bib.bib76), [77](#bib.bib77)]. We can summarize
the argument as follows. Suppose that the halo overdensity is some
deterministic function of the local matter overdensity, $\delta\_{h}=F(\delta)$. On large scales, where $|\delta|\ll 1$, we can Taylor
expand this function, $\delta\_{h}=a+b\,\delta+\ldots$. Keeping
only the lowest order terms and requiring that
$\langle\delta\_{h}\rangle=0$ then gives $\delta\_{h}=b\,\delta$, which is
linear deterministic bias. The key assumption in this argument was
locality; i.e. that the halo abundance is determined entirely by the
local matter density. N-body simulations with Gaussian initial
conditions have confirmed that halo bias tends to a constant on large
scales well in the linear regime.

Once we allow for primordial nongaussianity, however, the above
argument need not hold. For example, in this paper we have considered
NG of the form $f\_{\rm NL}\Phi^{2}$, and note that the gravitational potential
is a nonlocal quantity. Hence the locality-based argument above does
not apply for this form of nongaussianity, and our derived
scale-dependence of the bias is not surprising. The specific form we
have derived is particular to the quadratic, local form of NG that we
have assumed, however we expect any NG that couples density modes with
potential modes will in general lead to scale-dependent bias. On the
other hand, nongaussianity of the form $f\_{\rm NL}\delta^{2}$ does not
lead to scale-dependent bias.

In order to test our prediction for the scale dependence of bias,
we have computed halo bias in our N-body simulations by taking the
ratio of the matter power spectrum $P\_{\delta\delta}$ and the
halo-matter cross spectrum $P\_{h\delta}=\langle\delta\_{h}^{\*}\delta\rangle$.
We have used the cross spectrum
rather than the halo auto spectrum because the former should be less
sensitive to shot noise from the small number of halos compared to DM
particles. We have checked, however, that using the halo auto-spectra
to compute bias gives consistent results as the cross-spectra; i.e. we find no evidence for stochasticity. Examples of the various power
spectra and resulting bias factors are plotted in figure
Fig. [7](#S5.F7 "Figure 7 ‣ V Halo clustering ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects").

Figure 8: Ratio of the bias shift $\Delta b$ measured from our
simulations to that predicted by Eqn. ([9](#S2.E9 "In II Analytic estimates ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")), using
$\delta\_{c}=1.686$. Biases were computed from cross-spectra
measured on 28 simulations with 5 various $f\_{\rm NL}$ (-500, -100, 100,
500), 3 various redshifts ($z=0,0.5,1$) and 5 halo mass bins. Note
that at higher $k$, nonlinear evolution also
generates scale dependence in the bias [[78](#bib.bib78)].

As can be seen, we numerically confirm the form of the predicted scale
dependence. Because we focus on the statistics of rare objects, the
errors on bias from individual simulations plotted in
Fig. [8](#S5.F8 "Figure 8 ‣ V Halo clustering ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects") is large. We therefore attempt to
improve the statistics on the comparison by combining the bias
measurements from multiple simulations. Figure
[8](#S5.F8 "Figure 8 ‣ V Halo clustering ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects") plots the average ratio between the bias
measured in our simulations and our analytic prediction
Eqn. ([9](#S2.E9 "In II Analytic estimates ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")), using $\delta\_{c}=1.686$ as predicted from the
spherical collapse model [[79](#bib.bib79)]. In computing the average
plotted in this figure, we used a uniform weighting across the
different simulations, redshifts, and mass bins. Alternative
weightings can shift the results by $\sim 10\%$, so we conservatively
estimate the systematic error in our comparison to be 20%.
The agreement between our numerical
simulation results and our predicted bias scale-dependence,
Eqn. ([9](#S2.E9 "In II Analytic estimates ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")), is excellent and perhaps surprising. Naively,
we might expect a somewhat larger collapse threshold $\delta\_{c}$ to
apply, considering the ellipsoidal rather than spherical nature of the
collapse of halos in this mass range [[70](#bib.bib70)].

## VI Cosmological consequences

Having derived fitting formulae for the abundance and clustering of
halos in NG models, we now investigate how well upcoming surveys may
constrain $f\_{\rm NL}$, and whether NG could possibly affect the constraints
derived on other cosmological parameters. We focus on galaxy cluster
surveys and redshift surveys. Cluster surveys aim to constrain
cosmological parameters, in particular dark energy parameters, by
exploiting the exponential sensitivity of the galaxy cluster abundance
on cosmology. Similarly, a major goal for upcoming redshift surveys
is to constrain dark energy by localizing baryonic acoustic
oscillation (BAO) features in the galaxy power spectrum at multiple
redshifts. Examples of upcoming surveys include the
Atacama Cosmology Telescope44
4
http://wwwphy.princeton.edu/act/,
South Pole Telescope55
5
http://spt.uchicago.edu,
Dark Energy Survey66
6
http://www.darkenergysurvey.org,
WiggleZ77
7
http://astronomy.swin.edu.au/wigglez/WiggleZ/Welcome.html,
Planck88
8
http://www.rssd.esa.int/Planck,
SuperNova/Acceleration Probe99
9
http://snap.lbl.gov,
and the Large Synoptic Survey Telescope1010
10
http://www.lsst.org.

Because primordial nongaussianity affects both the abundance and power
spectra of massive halos, both of these types of surveys will be
well-suited for constraining NG. On the other hand, potential NG
could in principle degrade the expected constraints on dark energy
parameters, due to possible degeneracies. We use the Fisher matrix
formalism to extract errors on seven cosmological parameters as well
as $f\_{\rm NL}$. Our estimates are only illustrative; accurate forecasts for
specific surveys will require a more sophisticated analysis.

### VI.1 Constraints from $P(k)$: Galaxy surveys, BAO and ISW

We can (crudely) estimate constraints on parameters $\{p\_{i}\}$ derived
from measurements of the power spectrum by assuming that bandpowers
are measured with errors $\delta P=(P+n^{-1})/\sqrt{m}$, where $P$
is the power in a band of width $dk$ centered at wavenumber $k$, $n$
is the number density of galaxies, and $m$ is the number of
independent Fourier modes sampled by the survey, roughly given by
$m=(2\pi^{2})^{-1}V\,k^{2}dk$ [[80](#bib.bib80)].
Then the Fisher matrix can be written as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $F\_{ij}=\int\_{k\_{\rm min}}^{k\_{\rm max}}\frac{\partial P}{\partial p\_{i}}\frac{\partial P}{\partial p\_{j}}\left(P+\frac{1}{n}\right)^{-2}\frac{V\,k^{3}}{2\pi^{2}}d\ln k.$ |  | (23) |

For simplicity, in Eq. ([23](#S6.E23 "In VI.1 Constraints from 𝑃(𝑘):Galaxy surveys, BAO and ISW ‣ VI Cosmological consequences ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")) we use the linear theory power
spectrum and
number density corresponding to $z=0.5$, and assume an all-sky,
volume-limited survey extending to $z=0.7$. We integrate over
wavenumbers between $k\_{\rm min}=10^{-3}h/$Mpc and $k\_{\rm max}=0.1h/$Mpc. The results are insensitive to $k\_{\rm max}$ but depend
strongly on $k\_{\rm min}$. We believe the $k\_{\rm min}$ used here is
optimistic but reasonable. At high $k$ (small scales), late-time
nonlinear evolution can also generate scale-dependent bias
[[78](#bib.bib78)], however the redshift and scale dependence of this
effect is quite distinctive from NG and we ignore it here.

We assume that the target galaxies have properties similar to luminous
red galaxies (LRGs) [[81](#bib.bib81)], with comoving number density
$n=4\times 10^{-4}(h^{-1}{\rm Mpc})^{-3}$ and bias $b\_{0}=2$.
Equation ([23](#S6.E23 "In VI.1 Constraints from 𝑃(𝑘):Galaxy surveys, BAO and ISW ‣ VI Cosmological consequences ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")) then gives estimated errors on $f\_{\rm NL}$ of
$\sigma(f\_{\rm NL})\approx 7$, which compares well with forecasted
constraints on nongaussianity for Planck.

Unsurprisingly, we find little degeneracy between $f\_{\rm NL}$ and other
cosmological parameters, given its distinctive effect on the shape of the power
spectrum. Accordingly, there is little reason to believe that BAO
determinations of dark energy parameters will be biased by nongaussianity,
especially since the scale dependence is small over the wavenumbers of interest
for the BAO wiggles. To quantify this effect we determine the acoustic
peak position by looking at extrema of the ratio of the power spectra
with baryons and the power spectrum with zero baryons
[[82](#bib.bib82)]. When multiplying the matter power spectrum with
baryons by our scale dependant bias, we find that $f\_{\rm NL}=100$ would shift
the first BAO peak at $k\simeq 0.07h/$Mpc by 0.4% at $z=1$, and has
a considerably smaller effect at the higher BAO peaks. The magnitude
of this effect is comparable to the effect of non-linear corrections
to the power spectrum [[83](#bib.bib83), [84](#bib.bib84)], although the NG effect is
primarily important on large scales while nonlinearities are most
important on small scales. In principle, NG and nonlinearities could
conspire to lead to a $\sim 1-2\%$ bias in the dark energy equation of
state parameter $w$ inferred from BAO observations
[[83](#bib.bib83)], and so a careful joint analysis allowing both
for NG and nonlinear corrections will be required, which should not be difficult.

Another probe of $P\_{h\delta}$ on large scales is the cross-correlation
between cosmic microwave background (CMB) temperature anisotropies and
large scale structure, due to the integrated Sachs-Wolfe (ISW) effect
[[85](#bib.bib85), [86](#bib.bib86), [87](#bib.bib87)]. First detections of the ISW
effect from cross-correlations of WMAP with various large scale surveys have
been obtained with reported detections at the 2-4$\sigma$ level
[[88](#bib.bib88), [89](#bib.bib89), [90](#bib.bib90), [91](#bib.bib91), [92](#bib.bib92), [93](#bib.bib93), [94](#bib.bib94), [95](#bib.bib95)].
A combined analysis yields a $\simeq 5\sigma$ detection
[[96](#bib.bib96)], whereas a cosmic variance limited measurement would
allow a $\simeq 7.5\sigma$ detection for the currently favored
$\Lambda$CDM cosmology, and a somewhat more
significant detection if the dark energy equation of state parameter
is smaller [[97](#bib.bib97), [98](#bib.bib98)]. The cross-correlation
between large-scale structure and CMB is directly proportional to a weighted
projection of the scale-dependant bias. Since the $z$ and $k$ dependence of our
bias is very specific, we do not expect it to be severely degenerate with other
parameters affecting the amplitude of the ISW effect (mostly $w$ and $\Omega\_{m}$
for a flat universe). We can thus translate the ISW detection level into
constraints on $f\_{\rm NL}$. For the sake of simplicity, we assume that the ISW
signal comes from $z\simeq 1$ and is dominated by the angular multipole
$\ell\simeq 20$, corresponding to a wavenumber $k\simeq 6.66\times 10^{-3}h/$Mpc at $z=1.$
[[97](#bib.bib97)]. According to Eq. ([9](#S2.E9 "In II Analytic estimates ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")) the current
$3\sigma$ ($5\sigma$) detections of ISW translate into upper limits on $|f\_{\rm NL}|$
of 123 (61) (1$\sigma$) assuming a bias $b\_{0}=2$, as appropriate for LRGs
[[93](#bib.bib93)]. A prospective 7.5 $\sigma$ detection would translate
into $|f\_{\rm NL}|\lesssim 38$ (1$\sigma$). These estimates are clearly very crude, but
are likely correct at the order of magnitude level. In comparison,
the current limit from CMB bispectrum measurements from WMAP give
-54 $<f\_{\rm NL}<$ 114 (95% CL) [[6](#bib.bib6)] whereas Planck is expected to
constrain $|f\_{\rm NL}|<10$ (1 $\sigma$) [[99](#bib.bib99)].

In summary, the large-scale galaxy power spectrum appears capable of
constraining local NG quite stringently for surveys reaching $\sim$Gpc
scales: $|f\_{\rm NL}|\lesssim 10$. ISW or BAO observations could
provide somewhat weaker bounds on $f\_{\rm NL}$, though of course any
constraints they can provide would be independent of the CMB
bispectrum and therefore worthwhile. Our estimates of forecasted
bounds on $f\_{\rm NL}$ were rather crude, but given the encouraging results,
a more sophisticated treatment for specific survey parameters appears
warranted.

### VI.2 Constraints from cluster counts

We next consider how well upcoming cluster surveys can constrain
$f\_{\rm NL}$ by measurements of the cluster mass function $dn/dM$. Other
forms of nongaussianity may also be constrained by these surveys
[[100](#bib.bib100)], but we focus on the $f\_{\rm NL}$ form. For our
fiducial survey parameters, we consider a fixed, redshift-independent lower
mass limit of $M\_{\rm lim}=2\times 10^{14}M\_{\hbox{$\odot$}}$ and assume redshift bins
of width $\Delta z=0.1$ uniformly distributed between $z=0.1$ and $z=z\_{\rm max}\leq 2.0$.
We simultaneously vary seven cosmological parameters besides $f\_{\rm NL}$:
$A$, the normalization of the primordial power spectrum at
$k\_{\rm fid}=0.002h\,{\rm Mpc}^{-1}$; physical matter and baryon densities
$\Omega\_{m}h^{2}$ and $\Omega\_{b}h^{2}$, spectral index $n\_{s}$, the sum
of the neutrino masses $m\_{\nu}$, the matter energy density today relative to
critical $\Omega\_{m}$, and the equation of state parameter of dark energy $w$.
We assume no mass information
(which would improve our parameter constraints) but also no systematic errors
(which would degrade the constraints). We further assume 5000
square degrees on the sky, roughly consistent with expectations for the Dark
Energy Survey or the South Pole Telescope. The fiducial survey has about 7000
clusters (for $\sigma\_{8}=0.76$ cosmology) and about 23,000 for $\sigma\_{8}=0.9$).
We use WMAP3 [[6](#bib.bib6)] cosmological parameters in determining error
forecasts. The mass power spectrum $\Delta^{2}(k,a)\equiv k^{3}P(k,a)/(2\pi^{2})$ is written as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta^{2}(k,a)=\frac{4A}{25\Omega\_{M}^{2}}\left({k\over k\_{\rm fid}}\right)^{n\_{s}-1}\left({k\over H\_{0}}\right)^{4}g^{2}(a)\,T^{2}(k)$ |  | (24) |

where $T(k)$ is the transfer function adopted from [Eisenstein and Hu [82]](#bib.bib82),
and the growth function $g(a)$ is computed exactly by
integrating the well known second order differential equation for growth (e.g. Eq. (1) in [[101](#bib.bib101)]).

Following the results of section [IV.1](#S4.SS1 "IV.1 A new fitting formula ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects"), we assume that
the mass function may be written as

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${dn\over dM}(z,M)=\left({dn\over dM}\right)\_{\hskip-2.84544pt\rm Jenk}\hskip-5.69046pt(z,M)\times\left[n\_{\rm NG}(z,M)\over n\_{\rm G}(z,M)\right]$ |  | (25) |

where the nongaussian correction is computed using either our fitting
formula, or EPS for comparison. For a
given mass function, the total number of objects in a redshift interval of
width $\Delta z$ and centered at $z$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $N(z,\Delta z)=\Omega\_{\rm survey}\int\_{z-\Delta z/2}^{z+\Delta z/2}n(z,M\_{\rm min})\,{dV(z)\over d\Omega\,dz}\,dz$ |  | (26) |

where $\Omega\_{\rm survey}$ is the total solid angle covered
by the survey, $n(z,M\_{\rm min})$ is the comoving density of clusters
more massive than $M\_{\rm min}$, and $dV/d\Omega dz$ is the comoving
volume element. We assume $\Omega\_{\rm survey}=5000$
square degrees, roughly consistent with expectations for the Dark
Energy Survey or the South Pole Telescope. The fiducial survey has about 7000
clusters (for $\sigma\_{8}=0.76$ cosmology) and about 23,000 (for $\sigma\_{8}=0.9$).

Assuming Poisson statistics, the Fisher information matrix reads
[[102](#bib.bib102), [103](#bib.bib103), [104](#bib.bib104)]

|  |  |  |  |
| --- | --- | --- | --- |
|  | $F^{\rm clus}\_{ij}=\sum\_{k}{1\over N\_{k}(z\_{k},\Delta z)}{\partial N\_{k}\over\partial p\_{i}}\,{\partial N\_{k}\over\partial p\_{j}}$ |  | (27) |

where $p\_{i}$ are the 8 cosmological parameters including $f\_{\rm NL}$, $N\_{k}$ is the
number of clusters $k$th redshift bin, and the sum runs over the redshift bins
extending to maximal redshift $z\_{\rm max}$ 1111
11
Some attention needs to be
paid when taking the derivative with respect to $f\_{\rm NL}$, as it is especially
with this parameter that the assumption that the likelihood function
Gaussian may be violated, leading to results that are weaker or stronger
than a full likelihood calculation would reveal. We explore different values
of $df\_{\rm NL}$ and find convergence at $|df\_{\rm NL}|\lesssim 30$. We also find,
however, that the sensitivity to $f\_{\rm NL}$ (and also to the normalization $A$)
is slightly higher when $df\_{\rm NL}>0$ ($d\ln A>0$) than when $df\_{\rm NL}<0$ ($d\ln A<0$); this is expected as excess of rare objects like galaxy clusters
provides more cosmological leverage than their absence. This implies that
true constraints on $f\_{\rm NL}$ will be slightly asymmetric around our fiducial
value of zero; therefore, we make sure to take two-sided derivatives with
$df\_{\rm NL}=\pm 30$. For the EPS function, we take the two-sided derivative with
$df\_{\rm NL}=\pm 50$ (recall we ran sinulations with $|f\_{\rm NL}|=5$, $50$ and $500$),
and check that the results are similar, if noisier, if $df\_{\rm NL}=\pm 5$ is
used.. We assume no mass information (which would improve our parameter
constraints) but also no systematic errors (which would degrade the
constraints).

Lastly,
we add a Planck prior on the parameter set, neglecting forecasted
constraints on $f\_{\rm NL}$ expected from future CMB bispectrum
measurements (since we are interested in the sensitivity to NG of cluster
counts alone). The full Fisher matrix is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $F=F^{\rm clus}+F^{\rm CMB}.$ |  | (28) |

Figure 9: Forecasted errors on $f\_{\rm NL}$ from measurement of the cluster
mass function, as a function of the maximum extent of the
cluster survey, $z\_{\rm max}$. Black solid and dashed line show the marginalized and
unmarginalized error using our fitting formulae for $n\_{\rm NG}/n\_{\rm G}$,
while the red lines show the errors using the EPS formalism. Even though we use
the average of the nongaussian PDF tail over 10 simulations, the EPS result
becomes noisy at $z\gtrsim 1.5$ due to poor sampling of the
tails. Furthermore, it is clear that the EPS errors on $f\_{\rm NL}$ underestimate
those based on our simulations by up to a factor of three.

Fig. [9](#S6.F9 "Figure 9 ‣ VI.2 Constraints from cluster counts ‣ VI Cosmological consequences ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects") shows the result of our Fisher matrix
estimate, i.e. the forecasted errors on $f\_{\rm NL}$ as a function of the
maximum extent of the cluster survey, $z\_{\rm max}$. Black solid and dashed
lines show the marginalized and unmarginalized error using our fitting
formulae for $n\_{\rm NG}/n\_{\rm G}$, while the red lines show the
errors using the EPS formalism. The former errors are clearly well
behaved, and asymptote at high $z\_{\rm max}$ as expected since cluster
abundance rapidly vanishes. On the other hand EPS-produced $f\_{\rm NL}$
errors disagree with the simulations by up to a factor of
three. Moreover, even though we use the average of the nongaussian PDF
tail over 10 simulations, the EPS result becomes noisy at $z\gtrsim 1.5$ due to poor sampling of the tails. The magnitude of the
discrepancy between EPS estimates and our simulations appears similar
even for the higher $\sigma\_{8}=0.9$ model. As with our estimates from
power spectrum constraints, we do not find significant degeneracies
between $f\_{\rm NL}$ and other cosmological parameters (correlation
coefficient $\lesssim 0.5$).

Since we find a weaker effect on cluster abundance than previous
formulae like EPS or MVJ, this implies that constraints
found by [Sefusatti et al. [72]](#bib.bib72), who performed a similar
Fisher matrix estimate but with somewhat different assumptions, will
be weaker once the NG sensitivity is calibrated off simulations.
Direct quantitative comparison to two other relevant papers,
[Kang et al. [60]](#bib.bib60) and [Grossi et al. [61]](#bib.bib61), is however
difficult since these authors do not compute cosmological
parameter error estimates.

## VII Discussion

We have quantified the effects of primordial nongaussianity on the abundance
and power spectra of massive halos. Our two principal results are as
follows.

First, we have provided a new fitting formula for the halo mass
function. The formula is based on matching halos in Gaussian and non-Gaussian
simulations: for $f\_{\rm NL}>0$ the corresponding halos are more massive than in the
Gaussian case, and vice versa. The formula is consistent with the measured
mass function from our simulations to within $\sim 10\%$ over the entire range
of masses and redshifts that we consider. Being essentially a convolution of
the Gaussian mass function and a Gaussian kernel
(Eqs. ([11](#S4.E11 "In IV.1 A new fitting formula ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects"))-([13](#S4.E13 "In IV.1 A new fitting formula ‣ IV The halo mass function ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects"))), the formula is also easy to use
and does not require estimating the extreme tails of the nongaussian PDF of
the density field. Our results also indicate that previous work based on
Extended Press-Schechter type formulae overestimated the effects of
nongaussianity on the abundance of halos by a factor of $\sim 2$ over the
relevant mass scales.

Secondly, we showed both analytically and numerically that
nongaussianity (in the $f\_{\rm NL}$ model) leads to strong scale dependence
of the bias of dark matter halos. We find remarkably good agreement
between our analytic expression and our numerical results.
Measurement of the power spectrum
of biased objects therefore provides a new avenue to detect and measure
nongaussianity. While cluster counts can constrain NG at a level
comparable to existing CMB constraints, $|f\_{\rm NL}|\lesssim 100$, we found that
future large-scale redshift surveys can potentially do much better,
roughly $|f\_{\rm NL}|\lesssim 10$. We do not find significant degeneracies
between $f\_{\rm NL}$ and dark energy parameters in our Fisher matrix
calculations, either for mass function measurements or power spectrum
measurements. More precise estimates will require considerably more
sophisticated treatments than we have attempted in our illustrative
examples above.

We close this paper by considering, in light of our findings, the optimal
methods for constraining NG of the $f\_{\rm NL}$ form. Measurements of the power
spectrum would appear the most promising; observations of high redshift, highly
clustered objects on large scales would allow the strongest constraints on the
scale-dependent bias signature of $f\_{\rm NL}$. Fortunately, upcoming BAO surveys
will likely provide the necessary observations of, e.g. luminous red galaxies
(LRGs). Photometric surveys may also be useful in this regard. Since the
effects of NG are most pronounced on large scales, rather than small scales,
precise spectroscopic redshifts may not be necessary. Photometric redshifts
with errors of order $\Delta z\approx 0.03$ have already been achieved for LRGs
and for optically selected groups and clusters with prominent red sequences
[[105](#bib.bib105), [106](#bib.bib106), [46](#bib.bib46)]. At $z=0.5$, this
corresponds to roughly 100 $h^{-1}$Mpc comoving, fairly small compared to the
$\sim$Gpc scales where NG becomes most important. Since photometric surveys
can cover wider areas more deeply than spectroscopic surveys, they may turn out
to provide tighter bounds.

Besides their abundance and clustering, the internal properties of
massive halos may also be sensitive to nongaussianity.
For instance, the concentrations and substructure content of massive
halos have been found to depend upon primordial NG [[107](#bib.bib107)].
Our simulations lacked sufficient force resolution to explore this in
detail, but we note in passing that multiple groups find a tension
between observations of massive lensing clusters and theoretical
predictions for Gaussian perturbations
[[108](#bib.bib108), [109](#bib.bib109), [110](#bib.bib110), [111](#bib.bib111)].

Another intriguing possibility for probing primordial NG
is to use statistics of the largest
voids in the universe. Just as the abundance and clustering of high
density peaks are affected by nongaussianity, so are the same
properties for deep voids (albeit with an opposite sign, c.f. Fig. [1](#S3.F1 "Figure 1 ‣ III Numerical simulations ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")). In a sense, because voids are not as
nonlinear as overdense regions, their properties are more easily
related to the initial Lagrangian underdensities whose statistics are
straightforward to compute. Voids may be detected at high redshift as
a deficit of Lyman-$\alpha$ forest absorption features in QSO spectra.
The Sloan Digital Sky Survey (SDSS) has already measured spectra for
high redshift QSO’s over a roughly $\sim$8000 deg2 area,
corresponding to a volume of $\gtrsim 30({\rm Gpc}/h)^{3}$
[[112](#bib.bib112)]. Each QSO spectrum typically probes $\sim 400h^{-1}$ Mpc, and the typical transverse separation between QSO
sightlines in SDSS is $\sim 100h^{-1}$ Mpc, (P. McDonald, priv. comm.) so measurements of the clustering of $\sim 10$ Mpc-sized voids
on $\sim$ Gpc scales may already be feasible.

Finally, we note that our conclusions are based on simulations
implementing a very specific type of local primordial nongaussianity
quantified by the $f\_{\rm NL}$ parameter. The validity of our conclusions in the
context of other type of primordial nongaussianity is the subject of
ongoing studies.

## Acknowledgments

We are grateful to the organisers and participants of the “Life
beyond the Gaussian” workshop held at KICP (Chicago, June 2007) where
a preliminary version of this work was presented and discussed. We
thank Xuelei Chen and the National Astronomical Observatories of the
Chinese Academy of Sciences in Beijing where a part of this work was
completed. Finally we thank Niayesh Afshordi, Neil Barnaby, Wayne Hu,
Lam Hui, Nikhil
Padmanabhan, Uros Seljak, Robert Smith, and Emiliano Sefusatti for useful
conversations, Wayne Hu for providing the CMB Fisher matrix, and Pat
McDonald for discussions of the Lyman-$\alpha$ forest. All
simulations were performed on CITA’s Sunnyvale cluster, funded by the
Canada Foundation for Innovation and the Ontario Research Fund for
Research Infrastructure. This work was supported by the
Canadian Institute for Theoretical Astrophysics (CITA) and the Natural
Sciences and Engineering Research Council of Canada (NSERC).

\*

## Appendix A The abundance and clustering of high peaks

In this appendix we derive analytic expressions for the abundance
and clustering of regions above the spherical collapse threshold
$\delta\_{c}$. We first review previous results derived for Gaussian
statistics, and then show how they are modified by $f\_{\rm NL}$ nongaussianity.

### A.1 Review of Gaussian results

We begin by identifying massive halos at late times with high peaks in
the initial density distribution $\delta({\bm{x}})\equiv\delta\rho({\bm{x}})/{\bar{\rho}}$. Note that we work entirely in early-time, Lagrangian
coordinates ${\bm{x}}$ in this section rather than late-time, Eulerian
coordinates. Earlier work [[59](#bib.bib59), [113](#bib.bib113), [114](#bib.bib114), [69](#bib.bib69)]
has shown that the abundance of peaks above threshold
$\delta\_{c}\approx 1.686$
reasonably describes (at the order-of-magnitude level) the statistics
of halos forming at subsequent times. We briefly review some of these
previous results, as the methods will be used in our analysis.

Following the [Press and Schechter [59]](#bib.bib59) ansatz, we smooth the
density field and assume that density peaks with $\delta>\delta\_{c}$
produce halos. The density smoothed on scale $R$ is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\delta\_{R}({\bm{x}})=(2\pi)^{-3}\int d^{3}{\bm{k}}\ \delta\_{\bm{k}}W(kR)e^{i{\bm{k}}\cdot{\bm{x}}},$ |  | (29) |

where $W(x)$ is some smoothing window, e.g. top-hat or Gaussian.
Assuming that the Fourier modes $\delta\_{\bm{k}}$ are Gaussian
distributed with power spectrum $P(k)=\langle|\delta\_{k}|^{2}\rangle$,
then $\delta\_{R}({\bm{x}})$ also has a Gaussian distribution, with
variance

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma\_{\delta}^{2}(R)=\langle\delta\_{R}^{2}\rangle=\int d\ln k\frac{k^{3}P(k)}{2\pi^{2}}W^{2}(kR).$ |  | (30) |

The probability $P\_{1}$ for a given randomly selected region to exceed the threshold $\delta\_{c}$
is then simply the integral of the Gaussian probability distribution,

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle P\_{1}$ | $\displaystyle=$ | $\displaystyle\int\_{\delta\_{c}}^{\infty}d\delta\frac{dP}{d\delta}=\int\_{\nu\_{c}}^{\infty}d\nu(2\pi)^{-1/2}e^{-\nu^{2}/2}$ |  | (31) |
|  |  | $\displaystyle=$ | $\displaystyle\frac{1}{2}{\rm erfc}\left(\frac{\nu\_{c}}{\sqrt{2}}\right),$ |  |

where $\nu=\delta/\sigma\_{\delta}$, and similarly
$\nu\_{c}=\delta\_{c}/\sigma\_{\delta}$.

The same power spectrum $P(k)$ describing the density variance
$\sigma\_{\delta}^{2}(R)$ also gives the matter correlation function
$\xi(r\_{12})$, and, following an elegant argument by
[Kaiser [113]](#bib.bib113), can also be used to determine the correlation
function of rare peaks. Let us compute the probability $P\_{2}$ that two
randomly selected regions separated by distance $r\_{12}\gg R$ are both above threshold. Again,
this is simply an integral over the (joint) Gaussian distribution:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P\_{2}=\int\_{\delta\_{c}}^{\infty}d\delta\_{1}\int\_{\delta\_{c}}^{\infty}d\delta\_{2}\frac{\exp\left(-\frac{1}{2}{\bm{\delta}}\cdot{\bm{\Sigma}}^{-1}\cdot{\bm{\delta}}\right)}{2\pi|{\bf\Sigma}|^{1/2}}$ |  | (32) |

where ${\bm{\delta}}=(\delta\_{1},\delta\_{2})$, the covariance matrix is
given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\bf\Sigma}=\left(\begin{array}[]{cc}\sigma\_{\delta}^{2}&\xi\\ \xi&\sigma\_{\delta}^{2}\end{array}\right),$ |  | (33) |

and the matter correlation function $\xi(r\_{12})$ is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\xi(r\_{12})=\int d\ln k\frac{k^{3}P(k)}{2\pi^{2}}W^{2}(kR)j\_{0}(kr\_{12}).$ |  | (34) |

Rescaling the $\delta$’s by their variance, this becomes

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P\_{2}=\int\_{\nu\_{c}}^{\infty}d\nu\_{1}\int\_{\nu\_{c}}^{\infty}d\nu\_{2}\frac{\exp\left(-\frac{1}{2}{\bm{\nu}}\cdot{\bf S}^{-1}\cdot{\bm{\nu}}\right)}{2\pi|{\bf S}|^{1/2}},$ |  | (35) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\bf S}=\left(\begin{array}[]{cc}1&\psi\\ \psi&1\end{array}\right),$ |  | (36) |

and we follow the notation of BBKS [[114](#bib.bib114)] in writing the
normalized correlation function as $\psi(r\_{12})=\xi(r\_{12})/\sigma\_{\delta}^{2}$;
note that $\psi<1$.

To evaluate the integral in Eq. ([35](#A1.E35 "In A.1 Review of Gaussian results ‣ Appendix A The abundance and clustering of high peaks ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")), we change coordinates to
variables that are uncorrelated. Using the Cholesky decomposition of
the covariance matrix ${\bf S}={\bf C}^{\sf T}{\bf C}$, we write
${\bm{\nu}}={\bf C}^{\sf T}{\bm{y}}$ for new variables ${\bm{y}}$. Next,
we rotate coordinates ${\bm{y}}={\bf R}\cdot{\bm{x}}$ to bring the point
$(\nu\_{1}=\nu\_{c},\nu\_{2}=\nu\_{c})$ along the $x\_{1}$ axis. Then the integral
becomes

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle P\_{2}$ | $\displaystyle=$ | $\displaystyle\int d^{2}{\bm{x}}\frac{\exp\left(-\frac{1}{2}|{\bm{x}}|^{2}\right)}{2\pi}\Theta\left[(1,0)\cdot{\bf C}^{\sf T}\cdot{\bf R}\cdot{\bm{x}}-\nu\_{c}\right]$ |  | (37) |
|  |  |  | $\displaystyle\Theta\left[(0,1)\cdot{\bf C}^{\sf T}\cdot{\bf R}\cdot{\bm{x}}-\nu\_{c}\right],$ |  |

where the Heaviside function $\Theta$ accounts for the two integration
bounds. Since $\psi<1$, we can write this as

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle P\_{2}$ | $\displaystyle=$ | $\displaystyle\frac{1}{2\pi}\int\_{x\_{c}}^{\infty}dx\_{1}e^{-x\_{1}^{2}/2}\int\_{-c(x\_{1}-x\_{c})}^{c(x\_{1}-x\_{c})}dx\_{2}e^{-x\_{2}^{2}/2}$ |  | (38) |
|  |  | $\displaystyle=$ | $\displaystyle\frac{1}{2\pi}\int\_{x\_{c}}^{\infty}dx\_{1}e^{-x\_{1}^{2}/2}f(x\_{1}),$ |  |

where $c=\sqrt{(1+\psi)/(1-\psi)}$, and $x\_{c}=\nu\_{c}\sqrt{2/(1+\psi)}$.
We could easily evaluate the integral for $f(x\_{1})$ in terms of the
error function, but the resulting integral over $x\_{1}$ would then
not be analytic. However, we can derive an approximate solution in
the limit $\nu\_{c}\gg 1$. For integrals of the form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $I=\int\_{x\_{0}}^{\infty}dx\,e^{-x^{2}/2}f(x),$ |  | (39) |

we can construct an asymptotic series by repeated partial
integrations :

|  |  |  |  |
| --- | --- | --- | --- |
|  | $I\approx e^{-x\_{0}^{2}/2}\left[\frac{f(x\_{0})}{x\_{0}}\left(1-\frac{1}{x\_{0}^{2}}+\ldots\right)+\frac{f^{\prime}(x\_{0})}{x\_{0}^{2}}+\ldots\right]\;.$ |  | (40) |

In our case, $f(x\_{c})=0$ and $f^{\prime}(x\_{c})=2c$. Therefore, in the limit
$\nu\_{c}\gg 1$, we obtain

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle P\_{2}$ | $\displaystyle\approx$ | $\displaystyle\frac{1}{2\pi}e^{-x\_{c}^{2}/2}\frac{2c}{x\_{c}^{2}}$ |  | (41) |
|  |  | $\displaystyle=$ | $\displaystyle\frac{1}{2\pi}e^{-\nu\_{c}^{2}/(1+\psi)}\frac{(1+\psi)^{3/2}}{(1-\psi)^{1/2}}\nu\_{c}^{-2}\;.$ |  |

Comparing this expression to the probability for a single peak to be
above threshold then gives the peak-peak correlation function
$\xi\_{\rm pk}$, which in the limit $\nu\_{c}\gg 1$, $\psi\ll 1$ becomes

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle 1+\xi\_{\rm pk}$ | $\displaystyle=$ | $\displaystyle P\_{2}/P\_{1}^{2}\approx e^{\nu\_{c}^{2}(1-1/(1+\psi))}$ |  | (42) |
|  |  | $\displaystyle\approx$ | $\displaystyle 1+\nu\_{c}^{2}\psi=1+\frac{\nu\_{c}^{2}}{\sigma\_{\delta}^{2}}\xi,$ |  |

and therefore the (Lagrangian) bias $b\_{L}^{2}=\xi\_{\rm pk}/\xi$ becomes

|  |  |  |  |
| --- | --- | --- | --- |
|  | $b\_{L}\approx\nu\_{c}^{2}/\delta\_{c}.$ |  | (43) |

### A.2 Nongaussianity

Our discussion so far has merely reviewed previous results for
Gaussian fluctuations; we now turn to nongaussian fluctuations. As
noted above, we focus on NG of the form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Phi\_{\rm NG}=\phi+f\_{\rm NL}(\phi^{2}-\langle\phi^{2}\rangle).$ |  | (44) |

We adopt the approximation of §[II](#S2 "II Analytic estimates ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects") that the heights of rare
peaks are modified by NG as $\delta\_{\rm NG}\approx\delta[1+2f\_{\rm NL}\phi]$, where in this appendix we adopt the notation that
$\phi$ refers to the primordial potential. At late times, $\phi$
decays as the growth suppression factor $g(a)$.

Let us first consider the one-point distribution of peaks above
threshold, $\delta\_{\rm NG}>\delta\_{c}$. We express this as an integral
over Gaussian variables $\phi$ and $\delta$; the integration bound
then becomes $\delta\_{\rm NG}=\delta\,(1+2f\_{\rm NL}\phi)>\delta\_{c}$, and
using the fact that typically $f\_{\rm NL}|\phi|\ll 1$, we have
$\delta>\delta\_{c}(1-2f\_{\rm NL}\phi)$. The probability for $\delta\_{\rm NG}$ to exceed threshold then is

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\!\!\!P\_{1}$ | $\displaystyle=$ | $\displaystyle\int\!\!d\phi\!\int\_{\delta\_{c}(1-2f\_{\rm NL}\phi)}^{\infty}\!\!d\delta\frac{\exp\left(-\frac{1}{2}(\phi,\delta)\cdot{\bm{\Sigma}}^{-1}\cdot(\phi,\delta)\right)}{2\pi|{\bm{\Sigma}}|^{1/2}}$ |  | (45) |
|  |  | $\displaystyle=$ | $\displaystyle\int\!\!d\mu\!\int\_{\nu\_{c}-\eta\mu}^{\infty}\!\!d\nu\frac{\exp\left(-\frac{1}{2}(\mu,\nu)\cdot{\bf S}^{-1}\cdot(\mu,\nu)\right)}{2\pi|{\bf S}|^{1/2}},$ |  |

where $\mu=\phi/\sigma\_{\phi}$, $\nu=\delta/\sigma\_{\delta}$,
$\nu\_{c}=\delta\_{c}/\sigma\_{\delta}$, and $\eta=2f\_{\rm NL}\sigma\_{\phi}\nu\_{c}$. We
write the off-diagonal part of the normalized covariance matrix
${\bf S}$ as $\langle\mu\nu\rangle=r$, where the cross-correlation
coefficient $r$ is not to be confused with the peak-peak separation
$r\_{12}$ appearing above and below. By a coordinate
transformation, we can orient the integration bound along a single
axis. Changing coordinates from $(\mu,\nu)$ to $(\mu,v=\nu+\eta\mu)$,
and noting that the variance of $v$ is $\langle v^{2}\rangle=1+2\eta r+\eta^{2}$, we can integrate out $\mu$ to obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P\_{1}=\frac{1}{\sqrt{2\pi}}\int\_{x\_{c}}^{\infty}dx\,e^{-x^{2}/2}=\frac{1}{2}{\rm erfc}\left(\frac{x\_{c}}{\sqrt{2}}\right).$ |  | (46) |

where $x\_{c}=\nu\_{c}/\sqrt{1+2\eta r+\eta^{2}}$.
The effect of NG on the peak abundance is therefore simply to rescale
the threshold density by a mass- and redshift-dependent factor.

Next, we turn to the peak-peak correlation function. As in the
Gaussian case, we write the probability for two points both to be
above threshold as

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle P\_{2}$ | $\displaystyle=$ | $\displaystyle\int d^{4}{\bm{u}}\frac{\exp\left(-\frac{1}{2}{\bm{u}}\cdot{\bm{\Sigma}}\cdot{\bm{u}}\right)}{(2\pi)^{2}|{\bm{\Sigma}}|^{1/2}}\Theta(\nu\_{1}+\eta\mu\_{1}-\nu\_{c})$ |  | (47) |
|  |  |  | $\displaystyle\times\Theta(\nu\_{2}+\eta\mu\_{2}-\nu\_{c}),$ |  |

where ${\bm{u}}=(\mu\_{1},\mu\_{2},\nu\_{1},\nu\_{2})$, and the notation is
otherwise the same as above. We write the off-diagonal parts of the
normalized covariance matrix as $\langle\nu\_{1}\nu\_{2}\rangle=\psi$,
$\langle\mu\_{1}\mu\_{2}\rangle=\gamma$, $\langle\nu\_{1}\mu\_{1}\rangle=r$, and
$\langle\nu\_{1}\mu\_{2}\rangle=\beta$. As above, we change
variables from $\nu\_{i}$ to $v\_{i}=\nu\_{i}+\eta\mu\_{i}$ to align the
integration bounds along the density coordinate axes. This allows us
to integrate out the two potential variables, leaving behind a 2-D
integral. Rescaling the remaining two variables by their (identical)
variance and again writing $x\_{c}=\nu\_{c}/\sqrt{1+2\eta r+\eta^{2}}$, brings
the integral to the form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\int\_{x\_{c}}^{\infty}dx\_{1}\int\_{x\_{c}}^{\infty}dx\_{2}\frac{\exp\left(-\frac{1}{2}{\bm{x}}\cdot{\bf S}\cdot{\bm{x}}\right)}{2\pi|{\bf S}|^{1/2}}$ |  | (48) |

where the off-diagonal component of ${\bf S}$ is $\langle x\_{1}x\_{2}\rangle=\chi$ given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\chi=\frac{\psi+2\eta\beta+\eta^{2}\gamma}{1+2\eta r+\eta^{2}}\;.$ |  | (49) |

The form of equation ([48](#A1.E48 "In A.2 Nongaussianity ‣ Appendix A The abundance and clustering of high peaks ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")) is identical to Eq. ([35](#A1.E35 "In A.1 Review of Gaussian results ‣ Appendix A The abundance and clustering of high peaks ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")),
with $\nu\_{c}\rightarrow x\_{c}$ and $\psi\rightarrow\chi$. So we can
immediately write down the approximate solution,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P\_{2}\approx\frac{1}{2\pi}e^{-x\_{c}^{2}/(1+\chi)}x\_{c}^{-2}\frac{(1+\chi)^{3/2}}{(1-\chi)^{1/2}}.$ |  | (50) |

Comparing with the single-peak probability, we obtain the peak-peak
correlation function, in the limit $\nu\_{c}\gg 1$, $\chi\ll 1$ :

|  |  |  |  |
| --- | --- | --- | --- |
|  | $1+\xi\_{\rm pk}=P\_{2}/P\_{1}^{2}\approx 1+x\_{c}^{2}\chi,$ |  | (51) |

which to lowest order in $\eta$ becomes

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\xi\_{\rm pk}$ | $\displaystyle\approx$ | $\displaystyle\nu\_{c}^{2}[\psi+2\eta(\beta-2r\psi)]$ |  | (52) |
|  |  | $\displaystyle\approx$ | $\displaystyle\nu\_{c}^{2}(\psi+2\eta\beta)$ |  |
|  |  | $\displaystyle=$ | $\displaystyle b\_{L}^{2}(\xi\_{\delta\delta}+4f\_{\rm NL}\delta\_{c}\xi\_{\phi\delta})\;,$ |  |

where $b\_{L}$ was the Lagrangian bias obtained for Gaussian peaks,
c.f. Eq. ([43](#A1.E43 "In A.1 Review of Gaussian results ‣ Appendix A The abundance and clustering of high peaks ‣ The imprints of primordial non-gaussianities on large-scale structure: scale dependent bias and abundance of virialized objects")). Note that in going from the first line to the
second, we neglect $r\psi$ relative to $\beta$ since
$\xi\_{\delta\delta}(r\_{12})/\sigma\_{\delta\delta}$ is smaller than
$\xi\_{\phi\delta}(r\_{12})/\sigma\_{\phi\delta}$ by a factor scaling
like $(R/r\_{12})^{2}$, where $R$ is the smoothing scale of the peak and
$r\_{12}$ is the peak-peak separation.

The peak-peak correlation function is now no
longer simply proportional to the matter correlation function,
implying that the peak bias is not independent of scale. Fourier
transforming this expression gives the peak power spectrum,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P\_{\rm pk}=b\_{L}^{2}(P\_{\delta\delta}+4f\_{\rm NL}\delta\_{c}P\_{\phi\delta})$ |  | (53) |

which gives a scale-dependent change in the bias due to NG of

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta b(k)$ | $\displaystyle=$ | $\displaystyle 2b\_{L}f\_{\rm NL}\delta\_{c}\frac{P\_{\phi\delta}}{P\_{\delta\delta}}$ |  | (54) |
|  |  | $\displaystyle=$ | $\displaystyle 2b\_{L}f\_{\rm NL}\delta\_{c}\frac{3\Omega\_{m}}{2ag\,r\_{H}^{2}k^{2}}\;,$ |  |

where we have used the relation between the potential-density
cross-spectrum and the matter power spectrum
$P\_{\phi\delta}=(3\Omega\_{m}/2ag\,r\_{H}^{2}k^{2})P\_{\delta\delta}$,
arising from the Poisson equation.
The total Lagrangian bias is then $b\_{L}(k)=b\_{L}+\Delta b(k)$.
