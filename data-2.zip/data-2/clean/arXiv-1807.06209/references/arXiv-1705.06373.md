<!-- fulltext source=arxiv_html slug=arXiv-1705.06373 fetched=2026-09-18T00:58:26+00:00 -->

# The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2

The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2–[References](#bib "References ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")2017

Metin Ata,
Falk Baumgarten,
Julian Bautista,
Florian Beutler,
Dmitry Bizyaev,
Michael R. Blanton,
Jonathan A. Blazek,
Adam S. Bolton,
Jonathan Brinkmann,
Joel R. Brownstein,
Etienne Burtin,
Chia-Hsun Chuang,
Johan Comparat,
Kyle S. Dawson,
Axel de la Macorra,
Wei Du,
Hélion du Mas des Bourboux,
Daniel J. Eisenstein,
Héctor Gil-Marín,
Katie Grabowski,
Julien Guy,
Nick Hand,
Shirley Ho,
Timothy A. Hutchinson,
Mikhail M. Ivanov,
Francisco-Shu Kitaura,
Jean-Paul Kneib,
Pierre Laurent,
Jean-Marc Le Goff,
Joseph E. McEwen,
Eva-Maria Mueller,
Adam D. Myers,
Jeffrey A. Newman,
Nathalie Palanque-Delabrouille,
Kaike Pan,
Isabelle Pâris,
Marcos Pellejero-Ibanez,
Will J. Percival,
Patrick Petitjean,
Francisco Prada,
Abhishek Prakash,
Sergio A. Rodríguez-Torres,
Ashley J. Ross,
Graziano Rossi,
Rossana Ruggeri,
Ariel G. Sánchez,
Siddharth Satpathy,
David J. Schlegel,
Donald P. Schneider,
Hee-Jong Seo,
Anže Slosar,
Alina Streblyanska,
Jeremy L. Tinker,
Rita Tojeiro,
Mariana Vargas Magaña,
M. Vivek,
Yuting Wang,
Christophe Yèche,
Liang Yu,
Pauline Zarrouk,
Cheng Zhao,
Gong-Bo Zhao,
Fangzhou Zhu
††thanks: Email: hector.gilmarin@lpnhe.in2p3.fr††thanks: Email: Ashley.Jacob.Ross@gmail.com††thanks: Email: gbzhao@nao.cas.cn
Affiliation:  Leibniz-Institut für Astrophysik Potsdam (AIP), An der Sternwarte 16, D-14482 Potsdam, Germany
Affiliation:  Humboldt-Universität zu Berlin, Institut für Physik, Newtonstrasse 15,D-12589, Berlin, Germany
Affiliation:  Department Physics and Astronomy, University of Utah, 115 S 1400 E, Salt Lake City, UT 84112, USA
Affiliation:  Institute of Cosmology & Gravitation, Dennis Sciama Building, University of Portsmouth, Portsmouth, PO1 3FX, UK
Affiliation:  Apache Point Observatory and New Mexico State University, P.O. Box 59, Sunspot, NM 88349, USA
Affiliation:  Sternberg Astronomical Institute, Moscow State University, Universitetski pr. 13, 119992 Moscow, Russia
Affiliation:  Center for Cosmology and Particle Physics, Department of Physics, New York University, New York, NY 10003, USA
Affiliation:  Institute of Physics, Laboratory of Astrophysics, École Polytechnique Fédérale de Lausanne (EPFL), Observatoire de Sauverny, 1290 Versoix, Switzerland
Affiliation:  National Optical Astronomy Observatory, 950 N Cherry Ave, Tucson, AZ 85719, USA
Affiliation:  IRFU,CEA, Université Paris-Saclay, F-91191 Gif-sur-Yvette, France
Affiliation:  Max-Planck-Institut für Extraterrestrische Physik, Postfach 1312, Giessenbachstr., 85748 Garching bei München, Germany
Affiliation:  Instituto de Física, Universidad Nacional Autónoma de México, Apdo. Postal 20-364, México
Affiliation:  National Astronomy Observatories, Chinese Academy of Science, Beijing, 100012, P.R. China
Affiliation:  Harvard-Smithsonian Center for Astrophysics, 60 Garden St., MS #20, Cambridge, MA 02138, USA
Affiliation:  Sorbonne Universités, Institut Lagrange de Paris (ILP), 98 bis Boulevard Arago, 75014 Paris, France
Affiliation:  Laboratoire de Physique Nucléaire et de Hautes Energies, Université Pierre et Marie Curie, 4 Place Jussieu, 75005 Paris, France
Affiliation:  LPNHE, CNRS/IN2P3, Université Pierre et Marie Curie Paris 6, Université Denis Diderot Paris, 4 place Jussieu, 75252 Paris CEDEX, France
Affiliation:  Department of Astronomy, University of California at Berkeley, Berkeley, CA 94720, USA
Affiliation:  Lawrence Berkeley National Laboratory, 1 Cyclotron Road, Berkeley, CA 94720, USA
Affiliation:  Department of Physics, Carnegie Mellon University, 5000 Forbes Avenue, Pittsburgh, PA 15213, USA
Affiliation:  Berkeley Center for Cosmological Physics, LBL and Department of Physics, University of California, Berkeley, CA 94720, USA
Affiliation:  Institute of Physics, LPPC, École Polytechnique Fédérale de Lausanne (EPFL), CH-1015, Lausanne, Switzerland
Affiliation:  Institute for Nuclear Research of the Russian Academy of Sciences, 60th October Anniversary Prospect, 7a, 117312 Moscow, Russia
Affiliation:  Instituto de Astrofísica de Canarias (IAC), C/Vía Láctea, s/n, E-38200, La Laguna, Tenerife, Spain
Affiliation:  Dpto. Astrofísica, Universidad de La Laguna (ULL), E-38206 La Laguna, Tenerife, Spain
Affiliation:  Aix-Marseille Université, CNRS, LAM (Laboratoire d’Astrophysique de Marseille), 38 rue F. Joliot-Curie 13388 Marseille Cedex 13, France
Affiliation:  Center for Cosmology and Astro-Particle Physics, Ohio State University, Columbus, Ohio, USA
Affiliation:  Department of Physics and Astronomy and the Pittsburgh Particle Physics, Astrophysics and Cosmology Center (PITT PACC), University of Pittsburgh, 3941 O’Hara Street, Pittsburgh, PA 15260, USA
Affiliation:  Institut d’Astrophysique de Paris, Université Paris 6 et CNRS, 98bis Boulevard Arago, 75014 Paris, France
Affiliation:  Instituto de Física Teórica (UAM/CSIC), Universidad Autónoma de Madrid, Cantoblanco, E-28049 Madrid, Spain
Affiliation:  Campus of International Excellence UAM+CSIC, Cantoblanco, E-28049 Madrid, Spain
Affiliation:  Instituto de Astrofísica de Andalucía (CSIC), E-18080 Granada, Spain
Affiliation:  Departamento de Física Teórica M8, Universidad Autónoma de Madrid, E-28049 Cantoblanco, Madrid, Spain
Affiliation:  Department of Physics and Astronomy, Sejong University, Seoul 143-747, Korea
Affiliation:  The McWilliams Center for Cosmology, Carnegie Mellon University, 5000 Forbes Ave., Pittsburgh, PA 15213, USA
Affiliation:  Department of Astronomy and Astrophysics, The Pennsylvania State University, University Park, PA 16802, USA
Affiliation:  Institute for Gravitation and the Cosmos, The Pennsylvania State University, University Park, PA 16802, USA
Affiliation:  Department of Physics and Astronomy, Ohio University, 251B Clippinger Labs, Athens, OH 45701, USA
Affiliation:  Brookhaven National Laboratory, Bldg 510, Upton, New York 11973, USA
Affiliation:  School of Physics and Astronomy, University of St Andrews, St Andrews, KY16 9SS, UK
Affiliation:  Tsinghua Center for Astrophysics and Department of Physics, Tsinghua University, Beijing 100084, China
Affiliation:  Department of Physics, Yale University, 260 Whitney Ave, New Haven, CT 06520, USA

###### Abstract

We present measurements of the Baryon Acoustic Oscillation (BAO) scale in redshift-space using the clustering of quasars. We consider a sample of 147,000 quasars from the extended Baryon Oscillation Spectroscopic Survey (eBOSS) distributed over 2044 square degrees with redshifts $0.8<z<2.2$ and measure their spherically-averaged clustering in both configuration and Fourier space. Our observational dataset and the 1400 simulated realizations of the dataset
allow us to detect a preference for BAO that is greater than 2.8$\sigma$. We determine the spherically averaged BAO distance to $z=1.52$ to 3.8 per cent precision: $D\_{V}(z=1.52)=3843\pm 147\left(r\_{\rm d}/r\_{\rm d,fid}\right)\$Mpc. This is the first time the location of the BAO feature has been measured between redshifts 1 and 2. Our result is fully consistent with the prediction obtained by extrapolating the Planck flat $\Lambda$CDM best-fit cosmology. All of our results are consistent with basic large-scale structure (LSS) theory, confirming quasars to be a reliable tracer of LSS, and provide a starting point for numerous cosmological tests to be performed with eBOSS quasar samples. We combine our result with previous, independent, BAO distance measurements to construct an updated BAO distance-ladder. Using these BAO data alone and marginalizing over the length of the standard ruler, we find $\Omega\_{\Lambda}>0$ at 6.6$\sigma$ significance when testing a $\Lambda$CDM model with free curvature.

###### Keywords:

cosmology: observations - (cosmology:) large-scale structure of Universe - (cosmology:) distance scale - (cosmology:) dark energy

## 1 Introduction

Using Baryon Acoustic Oscillations (BAOs) to measure the expansion of the Universe is now a mature field, with the BAO signal having been detected and measured to ever greater precision using data from a number of large galaxy surveys including: the Sloan Digital Sky Survey (SDSS) I and II (e.g., [Eisenstein et al. 2005](#bib.bib36); [Percival et al. 2010](#bib.bib73); [Ross et al. 2015](#bib.bib80)), the 2-degree Field Galaxy Redshift Survey (2dFGRS) ([Percival et al., 2001](#bib.bib72); [Cole et al., 2005](#bib.bib27)), WiggleZ ([Blake et al., 2011](#bib.bib16)), and the 6-degree Field Galaxy Survey (6dFGS) ([Beutler et al., 2011](#bib.bib14)). The Baryon Oscillation Spectroscopic Survey (BOSS) ([Dawson et al., 2013](#bib.bib30)), part of SDSS III ([Eisenstein et al., 2011](#bib.bib38)), built on this legacy to obtain the first percent level BAO measurements ([Anderson et al., 2014](#bib.bib11)). Results from the completed, Data Release (DR) 12, sample of BOSS galaxies were presented in [Alam et al. (2016)](#bib.bib9).

As well as using galaxies as direct tracers of the BAO, analyses of the Lyman-$\alpha$ Forest in quasar spectra with BOSS have provided cosmological measurements at $z\sim 2.3$ (e.g. [Delubac et al. 2015](#bib.bib32); [Bautista et al. 2017](#bib.bib13)). However, between the current direct-tracer and Lyman-$\alpha$ measurements there is a lack of BAO measurements. Using quasars11
1
In this work ‘quasar’ is used as a synonym for quasi-stellar object (QSO) rather than quasi-stellar radio source; more specifically, we mean a high-redshift point source whose luminosity is presumably powered by a super-massive black hole at the centre of an unobserved galaxy. as direct tracers of the density field offers the possibility of $1<z<2$ observations, with the main hindrance being their low space density and the difficulty of performing an efficient selection. The extended-Baryon Oscillation Spectroscopic Survey (eBOSS; [Dawson et al. 2016](#bib.bib31)), part of SDSS-IV ([Blanton et al., 2017](#bib.bib18)), has been designed to target and measure redshifts for $\sim 500,000$ quasars at $0.8<z<2.2$ (including spectroscopically-confirmed quasars already observed in SDSS-I/II). Although the space density will still be relatively low (compared with the densities of galaxies in BOSS, for example), eBOSS will offset this drawback by covering a significant fraction of the enormous volume of the Universe between redshifts 1 and 2.

Quasars were selected in eBOSS using two techniques. A “CORE” sample used a likelihood-based routine called XDQSOz to select from optical $ugriz$ imaging, combined with a mid-IR-optical colour-cut. An additional selection was made based on variability in multi-epoch imaging from the Palomar Transient Factory ([Rau et al., 2009](#bib.bib76)). These selections are presented in [Myers et al. (2015)](#bib.bib67), alongside the characterisation of the final sample, as determined by the early data. The early data were observed as part of SEQUELS (The Sloan Extended QUasar, ELG and LRG Survey, undertaken as part of SDSS-III and SDSS-IV; described in the appendix of [Alam et al. 2015](#bib.bib8)), which acted as a pilot survey for eBOSS. SEQUELS used a broader quasar selection algorithm than that adopted for eBOSS, and a subsampled version of SEQUELS forms part of the eBOSS sample.

In this paper we present BAO measurements obtained from eBOSS, using quasars from the DR14 dataset to measure the BAO distance to redshift 1.5. These measurements represent the first instance of using the auto-correlation of quasars to measure BAO and the first BAO distance measurements between $1<z<2$. The low space density of quasars means that reconstruction techniques ([Eisenstein et al., 2007](#bib.bib37)) are not expected to be efficient, but we are still able to obtain a 4.4 per cent BAO distance measurement at greater than 2.5$\sigma$ significance. The results are an initial exploration of the power of the eBOSS quasar data set. We expect many forthcoming studies to further optimize these BAO measurements, measure structure growth, and probe the primordial conditions of the Universe.

This paper is structured as follows. In Section [2](#S2 "2 Data ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") we describe how eBOSS quasar candidates were ‘targeted’ for follow-up spectroscopy, observed, and how redshifts were measured. In Section [3](#S3 "3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"), we describe how these data are used to create catalogs suitable for clustering measurements. Section [4](#S4 "4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"), presents our analysis techniques, including explanations of our fiducial cosmology, how we measure clustering statistics, how we model BAO in these clustering statistics, and how we assign likelihoods to parameters that we measure. In Section [5](#S5 "5 Simulated Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"), we describe the two techniques used to produce a total of 1400 simulated realizations of the DR14 quasar sample, i.e., ‘mocks’. Section [6](#S6 "6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") reviews tests of our methodology using mocks; these tests allow us to define our methodological choices for combining measurements from different estimators. Section [7](#S7 "7 Results ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") presents the clustering of the DR14 quasar sample and the BAO measurements, including numerous robustness tests on these measurements. We then present an updated BAO distance ladder and place our measurement in the larger cosmological context in Section [8](#S8 "8 cosmological implications ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). We conclude with a preview of forthcoming cosmological tests expected to be performed using eBOSS quasar data and additional tracers in Section [9](#S9 "9 Conclusions ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2").

## 2 Data

In this section, we review the imaging data that was used to define a sample of quasar candindate ‘targets’ intended for spectroscopy. We then describe how we obtain spectroscopy for each target and then identify quasars and measure redshifts from this output. The process of transforming these data into large-scale structure (LSS) catalogs is described in Section [3](#S3 "3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2").

### 2.1 Imaging

All eBOSS quasar targets selected for LSS studies are selected on imaging from SDSS-I/II/III and the Wide Field Infrared Survey Explorer (WISE, [Wright et al. 2010](#bib.bib107)). We describe each dataset below.

SDSS-I/II ([York et al., 2000](#bib.bib110)) imaged approximately 7606 deg2 of the Northern galactic cap (NGC) and approximately 600 deg2 of the Southern galactic cap (SGC) in the $ugriz$ photometric pass bands ([Fukugita et al., 1996](#bib.bib43); [Smith et al., 2002](#bib.bib96); [Doi et al., 2010](#bib.bib34));
these data were released as part of the SDSS Data Release 7 (DR7, [Abazajian et al. 2009](#bib.bib2)). SDSS-III ([Eisenstein et al., 2011](#bib.bib38)) obtained additional photometry in the SGC to increase the contiguous footprint to 3172 deg2 of imaging in the SGC, released as part of DR8 ([Aihara et al., 2011](#bib.bib7)), alongside a re-processing of all DR7 imaging. The astrometry of this data was subsequently improved in DR9 ([Ahn et al., 2012](#bib.bib3)). All photometry was obtained using a drift-scanning mosaic CCD camera ([Gunn et al., 1998](#bib.bib45)) on the 2.5-meter Sloan Telescope ([Gunn et al., 2006](#bib.bib46)) at the Apache Point Observatory in New Mexico, USA.

The eBOSS project does not add any imaging area to that released in DR8, but takes advantage of updated calibrations of that data. [Schlafly et al. (2012)](#bib.bib86) applied the “uber-calibration” technique presented in [Padmanabhan et al. (2008)](#bib.bib68) to Pan-STARRS imaging ([Kaiser et al., 2010](#bib.bib54)). This work resulted in an improved global photometric calibration with respect to SDSS DR8, which is internally applied to SDSS imaging. Residual systematic errors in calibration are reduced to sub per-cent level on all photometric bands ([Finkbeiner et al., 2016](#bib.bib40)), and poorly constrained zero-points are much improved. The photometry with updated calibrations was released with SDSS DR13 ([Albareti et al., 2016](#bib.bib10)).

The WISE satellite observed the entire sky using four infrared channels centred at 3.4 $\mu$m (W1), 4.6 $\mu$m (W2), 12 $\mu$m (W3) and 22 $\mu$m (W4). The eBOSS quasar sample uses the W1 and W2 bands for targeting; see [Myers et al. (2015)](#bib.bib67) for details. All targeting is based on the publicly available unWISE coadded photometry force matched to SDSS photometry presented in [Lang (2014)](#bib.bib61).

### 2.2 Spectroscopic Observations

Quasar target selection for eBOSS is described in [Myers et al. (2015)](#bib.bib67). Objects that satisfy the target selection and which do not have a previously known and secure redshift are flagged as ${\tt QSO\\_EBOSS\\_CORE}$ and assigned optical fibers (via a process termed tiling - see Section [3.1](#S3.SS1 "3.1 Footprint ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")), and selected for spectroscopic observation. Spectroscopy is collected using the BOSS double-armed spectrographs ([Smee et al., 2013](#bib.bib95)), covering the wavelength range 3600 to 10000 Å with R$=1500-2600$. In BOSS, the pipelines to process data from CCD-level to 1d spectrum level to redshift are described in [Albareti et al. (2016)](#bib.bib10) and [Bolton et al. (2012)](#bib.bib21).

We divide the sources of secure redshift measurement into three classes:

* •

  Legacy: these are quasar redshifts obtained by SDSS I/II/III via non-eBOSS related progams;
* •

  SEQUELS: these are quasar redshifts obtained from the Sloan Extended QUasar, ELG and LRG Survey (SEQUELS) (designed as pilot survey for eBOSS, again see [Myers et al. 2015](#bib.bib67));
* •

  eBOSS: these are previously unknown quasar redshifts obtained by the eBOSS project.

#### 2.2.1 Legacy

The eBOSS program does not allocate fibers to targets previously observed that have a confident spectroscopic classification and a reliable redshift from previous SDSS observations. A target is considered to have a “confident” classification if neither ${\tt LITTLE\\_COVERAGE}$ nor ${\tt UNPLUGGED}$ are flagged in the ${\tt ZWARNING}$ bitmask. A target is considered to have a “good” redshift if it is not labeled ${\tt QSO?}$ or ${\tt QSO\\_Z?}$ in the DR12 quasar catalog of [Pâris et al. (2017a)](#bib.bib70). These targets, collectively termed legacy, typically have good, visually inspected, redshifts collated from SDSS-I, II and III data. Redshifts acquired before BOSS are obtained from a combination of [Schneider et al. (2010)](#bib.bib88) and a catalogue of known stellar spectra from SDSS-I/II. Targets observed during BOSS that resulted in a confident spectral classification and redshift are documented in the DR12 quasar catalogue (DR12Q, [Pâris et al. 2017a](#bib.bib70)), and are not re-observed in eBOSS. These known objects are therefore flagged as either ${\tt QSO\\_BOSS\\_TARGET}$, ${\tt QSO\\_SDSS\\_TARGET}$ or ${\tt QSO\\_KNOWN}$ (see section 4.4 of [Myers et al. 2015](#bib.bib67) for full details on how these flags are set). Targets that were previously observed in SDSS-I/II/III but failed to result in a confident classification (i.e., had at least one of ${\tt LITTLE\\_COVERAGE}$ or ${\tt UNPLUGGED}$ set) or a good redshift determination (i.e., were not labeled ${\tt QSO?}$ or ${\tt QSO\\_Z?}$ in DR12Q) were targeted for re-observation by either SEQUELS or eBOSS.

#### 2.2.2 SEQUELS

SEQUELS is a spectroscopic program started during SDSS-III that was designed as a pilot survey for eBOSS. The total program consists of 117 plates, 66 of which were observed during BOSS and are included in DR12 ([Alam et al., 2015](#bib.bib8)). The remaining 51 plates were observed during the 1st year of the eBOSS program and were released in DR13 ([Albareti et al., 2016](#bib.bib10)). The target selection for SEQUELS is by construction deeper and less constrained than the finalized eBOSS target selections, so only a (large) fraction of the SEQUELS targets satisfy the eBOSS final selection criteria.22
2
See §5.1 of Myers et al. (2015) for full details of the minor selection differences between SEQUELS and the rest of eBOSS. The SEQUELS area is not re-observed in eBOSS and, for the purpose of these catalogues, we treat SEQUELS targets that pass the final eBOSS target selection in an identical manner to eBOSS targets in the eBOSS footprint.

EBOSS\_TARGET0 holds the targeting flags for SEQUELS targets, whereas EBOSS\_TARGET1 contains the targeting flags for eBOSS targets. In the target collate file and in the LSS catalogues, all targets that pass the eBOSS selection have the appropriate EBOSS\_TARGET1 set, irrespective of whether they lie in the SEQUELS or eBOSS footprint. These flags match those that will exist in the publicly released catalogs.

#### 2.2.3 eBOSS

The eBOSS project, naturally, represents the bulk of our observations — over 75 per-cent of new redshifts in the DR14 LSS catalogues were observed during the eBOSS program. The target selection algorithm for quasars includes both LSS and Lyman$\alpha$ quasar targets. We use only the LSS quasars, which have the QSO\_CORE bit set in the targeting flags. The DR14 sample includes two years of eBOSS observations.

### 2.3 Measuring Redshifts

Robust spectral classification and redshift estimation is a challenging problem for quasars. In particular, the number and complexity of physical processes that can affect the spectrum of a quasar make it difficult to precisely and accurately disentangle systemic redshift (i.e., as a meaningful indicator of distance) from measured redshift (e.g., [Hewett & Wild 2010](#bib.bib48)). SEQUELS observations taken during SDSS-III (representing around half of the SEQUELS program) were all visually inspected, and helped define our process for identifying quasar candidates. As detailed in [Dawson et al. (2016)](#bib.bib31), 91 per cent of quasar spectra targeted for clustering studies are securely classified with an automated pipeline (according to said pipeline) and less than 0.5 per cent of these classifications were found to be false when visually examined. The automated classification fails to report a secure classification in the remaining nine per cent of cases and these are visually inspected, which is able to identify approximately half of these as quasars.

Information on all eBOSS quasars is detailed in the DR14 quasar catalogue (DR14Q, [Pâris et al. 2017b](#bib.bib71)), the successor to DR12Q, with the important distinction that the vast majority of LSS quasars are not visually inspected. DR14Q combines the LSS pipeline and visual inspection results together and provides a variety of value-added information. In particular, it contains three automated estimates of redshift that we consider in our LSS catalogs:

* •

  The SDSS quasar pipeline redshifts, denoted ‘ZPL’, and documented in [Bolton et al. (2012)](#bib.bib21). The pipeline uses a PCA decomposition of galaxy and quasar templates, alongside a library of stellar templates, to fit a linear combination of four eigenspectra to each observed spectrum.
* •

  A redshift estimate based on the location of the maximum of the MgII emission line blend at $\lambda=2799$Å , denoted ‘ZMgII’. The MgII broad emission line is less susceptible to systematic shifts due to astrophysical effects and, when a robust measurement of this emission line is present, it offers a minimally-biased estimate of a quasar’s systemic redshift (see e.g. [Hewett & Wild 2010](#bib.bib48); [Shen et al. 2016](#bib.bib91)).
* •

  A ‘ZPCA’ estimate, as documented in [Pâris et al. (2017a)](#bib.bib70). ‘ZPCA’ uses a PCA decomposition of a sample of quasars with redshifts measured at the location of the maximum of the MgII emission line, and fits a linear combination of four eigenvectors to each spectrum.

Whereas ZMgII offers the least biased estimate of the quasar’s systemic redshift, it is more susceptible to variations in S/N, and therefore ZPCA is able to obtain the accuracy of ZMgII with increased robustness provided by utilizing the information from the full spectrum (see Fig. 10 of [Dawson et al. 2016](#bib.bib31)).

DR14Q also contains a redshift, ‘Z’, which it considers to be the most robust of the available options, in that these redshifts are known to have the lowest rate of catastrophic failures (and can be any of the three options above, depending on the particular object). Further details will be available in [Pâris et al. (2017b)](#bib.bib71). We will test the robustness of our results to the redshift estimates by also testing BAO measurements where we use ZPCA as the redshift in all cases where it is available. Further tests, especially those focusing on the impact on redshift-space distortion (RSD) measurements, will be presented in [Zarrouk et al. (in prep.)](#bib.bib111).

The redshift distribution of the DR14 LSS quasar sample is displayed in Fig. [1](#S2.F1 "Figure 1 ‣ 2.3 Measuring Redshifts ‣ 2 Data ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). The curves show the result for the fiducial redshift sample. Our study uses the data with $0.8<z<2.2$. The target sample selection was optimized to yield quasars with $0.9<z<2.2$ ([Myers et al., 2015](#bib.bib67)). At lower redshifts, morphological cuts affect the sample selection; at higher redshift the redshift measurement is less secure. We can securely select quasars to $z<0.8$, but given that BAO at lower redshifts is better sampled by galaxies, we impose the $z>0.8$ cut. Affecting our choice of a high-redshift cut is that quasars with $z>2.2$ are used for Ly-$\alpha$ clustering measurements and we wish to cleanly separate the two volumes used for BAO measurements33
3
We are likely to re-evaluate this choice in future studies.. The data in the NGC (red) has a slightly greater number density than that of the SGC (blue). The imaging properties in the two regions are somewhat different, and, as explained in [Myers et al. (2015)](#bib.bib67), we expect a more efficient target selection (and thus yield of successful quasar redshifts) in the NGC. We describe weights that are applied to correct for the variations in targeting efficiency in Section [3.4](#S3.SS4 "3.4 Systematic Weights for Dependencies on Imaging Properties ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2").

Figure 1: The redshift distribution of the DR14 quasar sample, for 111,633 quasars in the NGC and 75,887 in the SGC. We use the data with $0.8<z<2.2$ for clustering statistics; this redshift region is marked with dotted lines. The $n(z)$ is slightly different in the NGC and SGC, due to known differences in the targeting efficiency, and we thus treat the two regions separately.

## 3 LSS Catalogs

In this section, we detail how the quasar target and redshift information is combined to create LSS catalogs suitable for large-scale clustering measurements.44
4
The catalogues will be available at this website <https://data.sdss.org/sas/dr14/eboss/lss/>, after eBOSS DR14 studies are complete. The clustering of the eBOSS quasar sample has already been studied by [Rodríguez-Torres et al. (2016)](#bib.bib78) and [Laurent et al. (2017)](#bib.bib62). LSS catalogs were generated for these studies in similar fashion to the methods we outline below, which are closely matched to the methods described in [Reid et al. (2016)](#bib.bib77). In particular, [Rodríguez-Torres et al. (2016)](#bib.bib78); [Laurent et al. (2017)](#bib.bib62) found that the clustering amplitude of the sample, and its redshift evolution, is consistent with the assumptions used in [Zhao et al. (2016)](#bib.bib112) and that the clustering can be modeled with the type of simulation techniques that have been successfully applied to galaxy samples.

### 3.1 Footprint

Targets that pass the target selection algorithm, and for which there are no known good redshifts, are fed into a tiling algorithm ([Blanton et al., 2003](#bib.bib17)), that allocates spectroscopic fibers to targets within a $3^{\circ}$ tile. Allocation is done in a way that maximises the number of fibers placed on targets, considering the constraints imposed by a pre-set target priority list and the $62"$ exclusion radius around each fiber ([Dawson et al., 2016](#bib.bib31)). The algorithm is sensitive to the target density on the sky, so overdense regions tend to be covered by more than one tile. This overlap of tiles locally resolves some collision conflicts, but all others are dealt with separately. For eBOSS and SEQUELS, quasars can have collisions with fellow quasars or higher priority target classes. Collisions with other target classes (including Lyman$\alpha$) are simply deemed ‘missed’ observations and will be treated as random. Collisions with fellow quasars are termed fiber collisions or close pair collisions; see Section [3.3](#S3.SS3 "3.3 Spectroscopic Completion Weights ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). Approximately 40% of the eBOSS area is covered by more than one tile.

We use the MANGLE software package ([Swanson et al., 2008](#bib.bib97)) to decompose the sky into a unique set of sectors, within each we compute a survey completeness. Within each sector we define the following:

* •

  Nlegacy: the number targets with previously known redshifts (excluded from tiling);
* •

  Ngood: the number of fibers that yield good quasar redshifts;
* •

  Nzfail: the number of fibers from which a redshift could not be measured;
* •

  Nbadclass: the number of targets with spectroscopic classification that does not match its target class, for our quasar sample, these are exclusively galaxies55
  5
  While we exclude them from our analysis, these are likely an interesting sample of object.;
* •

  Ncp: the number of targets which did not receive a fiber due to being in a collision group (or “close-pair”);
* •

  Nstar: the number of spectroscopically confirmed stars;
* •

  Nmissed: the number of quasar targets to be observed in the future or not observed because of a collision with a different eBOSS target class.

Table 1: Basic properties of the quasar LSS catalogues. The quantities are summed over all sectors, with no redshift cuts. $\rm N\_{Q}=N\_{good}+N\_{legacy}$. $\rm N\_{eff}$ is the effective total number of quasars, after correcting for redshift failures and fibre-collisions: $\rm N\_{eff}=\sum(w\_{cp}+w\_{zfail}-1)$. Unweighted area is the sum of the area of all sectors with $\rm C\_{eBOSS}>0.5$; weighted area multiplies this area by the completeness in each sector and weighted area post-veto multiplies this area by the total fraction of vetoed area. All other quantities are defined in the text.

|  | NGC | SGC | Total |
| --- | --- | --- | --- |
| $\rm\bar{N}\_{QSO}$ | 116866 | 77935 | 194801 |
| $\rm\bar{N}\_{good}$ | 78425 | 58277 | 136702 |
| $\rm\bar{N}\_{legacy}$ | 38441 | 19658 | 58099 |
| $\rm\bar{N}\_{zfail}$ | 3598 | 2865 | 6463 |
| $\rm\bar{N}\_{cp}$ | 3126 | 2352 | 5478 |
| $\rm\bar{N}\_{badclass}$ | 8908 | 5564 | 14472 |
| $\rm\bar{N}\_{star}$ | 3782 | 4517 | 8299 |
| $\rm\bar{N}\_{eff}$ | 123903 | 82876 | 206779 |
| Unweighted area (deg2) | 1356 | 1035 | 2391 |
| Weighted area (deg2) | 1288 | 995 | 2283 |
| Weighted area post-veto (deg2) | 1215 | 898 | 2113 |
|  |  |  |  |

A summary of the above numbers in each of our target samples, summed over all sectors, is given in Table [1](#S3.T1 "Table 1 ‣ 3.1 Footprint ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). We define a targeting completeness per sector and per target class as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{\rm eBOSS}=\frac{\rm N\_{\rm good}+N\_{\rm zfail}+N\_{\rm badclass}+N\_{\rm cp}+N\_{\rm star}}{\rm N\_{\rm good}+N\_{\rm zfail}+N\_{\rm badclass}+N\_{\rm cp}+N\_{\rm star}+N\_{\rm missed}}.$ |  | (1) |

Thus, $C\_{\rm eBOSS}$ tracks the fiber-allocation completeness of the eBOSS spectroscopic observations. This is the completeness that defines the eBOSS mask and which will be later used to construct random catalogues with a matched on-sky completeness (see Section [3.5](#S3.SS5 "3.5 Random Catalogues ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")). Inspection of Eq. [1](#S3.E1 "In 3.1 Footprint ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") reveals that $C\_{\rm eBOSS}$ is impacted only by $N\_{\rm missed}$; objects that were not assigned a fiber due to a fiber collision are treated separately (see Section [3.3](#S3.SS3 "3.3 Spectroscopic Completion Weights ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")).

Legacy targets are 100% complete, since they have already been observed. In order to account for this, we follow the same procedure as in BOSS ([Reid et al., 2016](#bib.bib77)) and sub-sample legacy targets to match the value of CeBOSS in each sector. SEQUELS and eBOSS observations are very similar and thus we treat them the same way, without distinction in the LSS catalogues. We keep all sectors with C${}\_{\rm eBOSS}>0.5$ in the LSS catalogues; the average completeness of the remaining sectors is high, averaging 95 and 96 per-cent in the North and South Galactic caps, respectively. The footprint of the DR14 LSS catalogues, coloured by the value of $C\_{\rm eBOSS}$ in each sector, is shown in Fig. [2](#S3.F2 "Figure 2 ‣ 3.1 Footprint ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). The completeness is generally quite high, except around the edges of the footprint where future observations will overlap with the DR14 data. Veto masks have also been applied and are detailed in the following subsection.

Figure 2: The footprint of the eBOSS DR14 quasar sample. The top panel displays the portion of the footprint in the NGC and the bottom panel the SGC. The colour mapping indicates the observational completeness, CeBOSS, as defined in the text.

Additionally, we define a redshift completeness per sector as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{\rm z}=\frac{\rm N\_{good}}{\rm N\_{good}+N\_{fail}},$ |  | (2) |

which tracks the quasar redshift efficiency averaged over each sector. We use this completeness value only to remove sectors with C${}\_{\rm z}<0.5$. Redshift failures themselves are corrected for separately (see Section [3.3](#S3.SS3 "3.3 Spectroscopic Completion Weights ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")).

### 3.2 Veto Masks

A number of veto masks are used to exclude sectors in problematic areas. For the DR14 quasar sample, we apply the same veto masks as in BOSS DR12 ([Reid et al., 2016](#bib.bib77)), removing regions due to:

* •

  Bad photometric fields, including cuts on seeing and Galactic extinction. In total, this mask excludes approximately 5 per-cent of the area. Cuts on extinction and seeing are only significant in the SGC (3.2 per-cent of the SGC area is excluded by the seeing cut and 2.6 per-cent by the extinction cut).
* •

  Bright stars, based on the Tycho catalog ([Høg et al. 2000](#bib.bib51); excluding 1.8 per cent of the area);
* •

  Bright objects, including, e.g., stars not in the Tycho catalog and bright galaxies ([Rykoff et al. 2014](#bib.bib84); excluding 0.05 per cent of the area);
* •

  Centerposts, which anchor the spectrographic plates and prevent any fibers from being placed there (excluding $<0.01$ per cent of the area);

We use the [Schlegel, Finkbeiner & Davis (1998)](#bib.bib85) map to determine extinction values and we remove areas with $E(B-V)>0.15$. For seeing, we use the value labeled ‘PSF\_FHWM’ in the catalogues and remove areas where is greater than 2.3, 2.1, 2.0 in the g, r, and i band, respectively. Further details on these masks and their motivation can be found in section 5.1.1 of [Reid et al. (2016)](#bib.bib77). The veto masks have been applied to Fig. [2](#S3.F2 "Figure 2 ‣ 3.1 Footprint ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). The large gap in coverage in the SGC at RA$\sim 345^{\rm o}$, Dec$\sim 22^{\rm o}$ is due to the extinction mask. The horizontal striped patterns are due to the photometric bad fields or poor seeing in the SDSS imaging. The other veto masks are generally too small to be distinguishable.

### 3.3 Spectroscopic Completion Weights

The spectroscopic completeness of the sample is affected by multiple factors. Again, our process for accounting for this incompleteness matches that described in [Reid et al. (2016)](#bib.bib77). The simplest is that not all targets in a given sector have been observed. We account for this effect by down-sampling the random catalogs by the completeness fraction. Targets also lack redshifts due to fiber collisions and redshift failures, and we describe how these are treated below.

Not all observations yield a valid redshift. Redshift failures do not happen randomly on a tile (see e.g. [Laurent et al. 2017](#bib.bib62)), meaning they cannot be accounted for uniformly within a sector. Instead, as in previous BOSS analyses (e.g. [Reid et al. 2016](#bib.bib77)), we choose to transfer the weight of the lost target to the nearest neighbour with a good redshift and spectroscopic classification in its target class, within a sector (this can be a quasar, a star or a galaxy, provided it is targeted as a quasar). This weight is tracked by WEIGHT\_NOZ ($w\_{\rm noz}$) in the LSS catalogues. WEIGHT\_NOZ is set to 1 by default for all objects, and incremented by $+1$ for objects with a neighbouring redshift failure. The median separation between a redshift failure and its up-weighted neighbour is 0.06o. This corrective scheme assumes that the redshift distribution of the redshift failures is the same as that of the good redshifts. This is not expected to be strictly true, but assumed for simplicity, given the small number of targets that are corrected as redshift failures (approximately 3.4 per-cent in the NGC and 3.6 per-cent in the SGC). This concern does not affect out BAO analysis, but its impact on RSD analysis is currently being studied.

Targets missed due to fiber collisions do not happen randomly on the sky - they are more likely to occur in overdense regions. Targets lost to fiber collisions have therefore a higher bias than average, and we must apply a correction to account for this. We correct for these fiber collisions by transferring the weight of the lost target to the nearest neighbour of the same target class with a valid redshift and spectroscopic classification. This weight is tracked by WEIGHT\_CP ($w\_{\rm cp}$) in the LSS catalogues. Legacy targets are allowed to accrue close-pair correction weights, and legacy targets are downsampled such that the number of eBOSS-legacy close-pairs matches the number of close-pairs in eBOSS within each sector. Like WEIGHT\_NOZ, it is set to 1 as default for all objects and incremented by $+1$ for every neighbouring fiber collision. A total of 4.0 per cent of the eBOSS quasar targets are corrected as close-pairs in the NGC; this fraction is 3.0 per cent in the SGC.

Redshift failures are allowed to accrue weight from neighbouring close pairs, in which case the closest neighbour sees $w\_{\rm noz}$ incremented by the total $w\_{\rm cp}$ of redshift failure. For example, it is possible for a quasar target to be unobserved due to a collision with another quasar target. The observed quasar target is given $w\_{\rm cp}=2$, but we then fail to obtain a good redshift. The nearest neighbour to this observed quasar target is thus given $w\_{\rm noz}=3$.

Thus, each quasar is given a spectroscopic completeness weight, $w\_{\rm c}=(w\_{\rm cp}+w\_{\rm noz}-1)$ to be used for any counting statistics.

### 3.4 Systematic Weights for Dependencies on Imaging Properties

Figure 3: The relationship between the number density of the DR14 quasar sample and various potential systematics before (dashed crimson curves, labeled ‘raw’) and after (grey squares, labeled ‘corrected’) weighting for limiting magnitude (depth) and Galactic extinction (E[B-V]). Weighting for limiting magnitude and E[B-V] removes correlations with other potential systematic quantities.

As described in [Laurent et al. (2017)](#bib.bib62), weights are required for the DR14 quasar sample in order to remove spurious dependency on the 5$\sigma$ limiting magnitude (‘depth’) and Galactic extinction. Quasars are more securely identified where the depth is best and Galactic extinction is the variable that we find most affects differences in depth between the SDSS imaging bands, as they were nearly simultaneously observed.

For the DR14 quasar sample, we define weights based on the depth in the $g$-band, in magnitudes (including the effect of Galactic extinction on this depth), and the Galactic extinction in units $E(B-V)$, using the map determined by [Schlegel, Finkbeiner & Davis (1998)](#bib.bib85). These are the important observational systematics identified in [Laurent et al. (2017)](#bib.bib62). We define the weights based on the sample DR14 quasars with $0.8<z<2.2$ (already passed through the steps defined in the preceding section). Compared to [Laurent et al. (2017)](#bib.bib62), our results differ in that we use the full DR14 set (approximately doubling the sample size) to determine the weights and that we define the weights separately for the NGC and SGC. As in [Ross et al. (2012)](#bib.bib79); [Ross et al. (2017)](#bib.bib81) and [Laurent et al. (2017)](#bib.bib62), we define the weights based on fits to linear relationships. We first determine the dependency with depth and then with extinction, after applying the weights for depth. The total weight is the multiplication of the two weights. Thus

|  |  |  |  |
| --- | --- | --- | --- |
|  | $w\_{\rm sys}=\frac{1}{(A\_{d}+dB\_{d})(A\_{e}+eB\_{e})},$ |  | (3) |

where $d$ is the $g$ band depth (in magnitudes) and $e$ is the Galactic extinction (in $E(B-V)$).
The best-fit coefficients are $A\_{d}=-3.52,B\_{d}=0.195,A\_{e}=1.045,B\_{e}=-2.01$ for the NGC and $A\_{d}=-6.20,B\_{d}=0.31,A\_{e}=1.052,B\_{e}=-1.00$ for the SGC. The differences in the coefficients for the two regions make it clear it is necessary to separate them for analysis of the DR14 sample. Fig. [3](#S3.F3 "Figure 3 ‣ 3.4 Systematic Weights for Dependencies on Imaging Properties ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") presents the relationship between the projected number density quasars and potential systematic quantities, combining the NGC and SGC. After weighting for depth and Galactic extinction (red squares) the systematic trends are removed.

Figure 4: The relationship between the number density of the DR14 quasar sample and the $i$-band 5$\sigma$ limiting magnitude (‘depth’) for four slices in redshift, after weights for depth and Galactic extinction have been applied. No systematic trends with redshift are apparent.

Fig. [4](#S3.F4 "Figure 4 ‣ 3.4 Systematic Weights for Dependencies on Imaging Properties ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") displays the relationship between quasar density and the depth when dividing the sample into four redshift bins. No systematic trends are apparent with redshift, suggesting that the systematic relationships do not need to be defined as a function of the colour/magnitude of the quasars. The $\chi^{2}$ for the null test for the quasars with $1.15<z<1.5$ is large — 25 for 10 degrees of freedom — but this result is dominated by a single 4$\sigma$ outlier at the worst depth. For the 9 bins at greater depth, the $\chi^{2}$ is 12. We will demonstrate that our results are robust to any fluctuations in density imparted by the depth fluctuations.

### 3.5 Random Catalogues

Random catalogues are constructed that match the angular and radial windows of the data, but with approximately 40 times the number density. Such catalogs are required for both correlation function and power spectrum estimates of the clustering of the DR14 quasar sample, as detailed in Section [4](#S4 "4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2").

We begin by using the MANGLE software to generate a set of points randomly distributed in the eBOSS footprint, where the angular number density in each sector is subsampled to match the value of CeBOSS in that sector. We then run the random points through the same veto masks that are applied to the data (see Section [3.2](#S3.SS2 "3.2 Veto Masks ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")). Finally, we assign each random point a redshift that is drawn from the distribution of data redshifts that clear the veto mask. The draws are weighted by the total quasar weight given by w${}\_{\rm tot}=w\_{\rm sys}\*w\_{\rm c}$, such that the weighted redshift distribution of data and randoms match.

## 4 Methodology

### 4.1 Fiducial Cosmology

We use a flat, $\Lambda$CDM cosmology with $\Omega\_{m}=0.31$, $\Omega\_{b}h^{2}=0.022$, $\sum m\_{\nu}=0.06\$eV and $h=0.676$, where the subscripts $m$, $b$ and $\nu$ stand for matter, baryon and neutrino, respectively, and $h$ is the standard dimensionless Hubble parameter. These choices match the fiducial cosmology adopted for BOSS DR12 analyses ([Alam et al., 2016](#bib.bib9)). One set of mocks we use, the EZmocks (see Section [5.1](#S5.SS1 "5.1 EZmocks ‣ 5 Simulated Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")), use the cosmology of MultiDark-PATCHY ([Kitaura et al., 2014](#bib.bib58); [Kitaura et al., 2016](#bib.bib59)) used in previous BOSS analyses. The other set of mocks we use, QPM mocks (see Section [5.2](#S5.SS2 "5.2 QPM Mocks ‣ 5 Simulated Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")), uses a geometry that matches our fiducial cosmology but with $\Omega\_{\nu}=0$. The properties of the cosmologies we use are listed in Table [2](#S4.T2 "Table 2 ‣ 4.1 Fiducial Cosmology ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2").
Following the values provided in Table [2](#S4.T2 "Table 2 ‣ 4.1 Fiducial Cosmology ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"), the BAO distance parameter at the effective redshift of the quasar sample, $D\_{V}(z\_{\rm eff})$ with $z\_{\rm eff}=1.52$ (see Eq. [13](#S4.E13 "In 4.3 BAO Modeling ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") for definition), are $3871.0\,{\rm Mpc}$
for both the fiducial cosmology and for the QPM cosmology and $3871.7\,{\rm Mpc}$ for the EZ mocks cosmology. A separate factor entering our analysis is the value for the comoving sound horizon at the baryon drag epoch, $r\_{\rm d}$; this parameter sets the position of the BAO scale in our theoretical templates. The different cosmologies and lack of a neutrino mass in the mocks shift $r\_{\rm d}$ to be less than the fiducial by just over $0.1\,{\rm Mpc}$ for each type of mock we use.

Table 2: Fiducial cosmology used in our BAO analysis and true cosmology for the QPM and EZ mocks, described in Section [5](#S5 "5 Simulated Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). Given that the cosmology in which we analyse the mocks is slightly different than their own one, we expect a shift in the BAO peak position with respect to the fiducial position, $\alpha$ (see Eq. [12](#S4.E12 "In 4.3 BAO Modeling ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") for definition). We also provide the values for the comoving sound horizon at the baryon drag epoch, $r\_{\rm d}$. The exact values used for the EZ mock are $\Omega\_{m}=0.307115$ and $h=0.6777$, which have been rounded to three significant figures below

| case | $\Omega\_{m}$ | $h$ | $\Omega\_{b}h^{2}$ | $\sum m\_{\nu}$ | $\alpha$ | $r\_{\rm d}$ (Mpc) |
| --- | --- | --- | --- | --- | --- | --- |
| fiducial | 0.31 | 0.676 | 0.022 | 0.06 eV | - | 147.78 |
| QPM | 0.31 | 0.676 | 0.022 | 0 | 1.00108 | 147.62 |
| EZ | 0.307 | 0.678 | 0.02214 | 0 | 1.00101 | 147.66 |
|  |  |  |  |  |  |  |

### 4.2 Clustering Estimators

We perform two complementary BAO analyses: i) in configuration space, where the observable is the angle (with respect to the line of sight) average (the monopole) of the correlation function; ii) in Fourier Space, where the observable is the monopole of the power spectrum. When the entire spectrum of frequencies and positions is considered, both correlation function and power spectrum contain identical information as one represents the Fourier transform of the other. However, since our spectral range is finite, the correlation function and power spectrum do not contain exactly the same information, although we expect a high correlation between results using either statistic. Long wavelengths are limited by the size of the survey and small wave-lengths are limited by the resolution of the analysis. Furthermore, we expect that any potential uncorrected observational or modelling systematics will affect the correlation function and power spectrum differently. Thus, by performing two complementary analyses and combining them we expect to produce a more robust final result.

For both analyses, we require the data catalogue, which contains the distribution of quasars (which can be an actual or synthetic distribution) and the random catalogue, which consists of a Poisson-sampled distribution with the same mask and selection function as the data catalogue with no other cosmological correlations.
We count each data and random object as a product of weights. For the data catalogue, the total weight corrects for systematic dependencies in the imaging, $w\_{\rm sys}$ and spectroscopic data, $w\_{\rm c}$ (see Section [3.4](#S3.SS4 "3.4 Systematic Weights for Dependencies on Imaging Properties ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") and [3.3](#S3.SS3 "3.3 Spectroscopic Completion Weights ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"), respectively) multiplied by a weight, $w\_{\rm FKP}$, that is meant to optimally ponderate the contribution of objects based on their number density at different redshifts. Conversely, for random catalogue, objects are weighted only by $w\_{\rm FKP}$. The $w\_{\rm FKP}$ weight is based on [Feldman et al. (1994)](#bib.bib39) and defined as,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $w\_{\rm FKP}(z)=1/[1+n(z)P\_{0}],$ |  | (4) |

where $P\_{0}$ is the amplitude of the power spectrum at the $k$ scale at which the FKP-weights optimise the measurement. For the expected BAO signature in the DR14 quasar sample this is $k\sim 0.14h$Mpc-1 ([Font-Ribera et al., 2014a](#bib.bib41)), and therefore, we use $P\_{0}=6\times 10^{3}\,[{\rm Mpc}\,h^{-1}]^{3}$. The FKP weights have only a small effect on our results, as the number density is both low and nearly constant, so the value of the weight varies by less than 10 per cent.

The total weight applied to each quasar is thus

|  |  |  |  |
| --- | --- | --- | --- |
|  | $w\_{\rm tot}=w\_{\rm FKP}w\_{\rm sys}(w\_{\rm cp}+w\_{\rm noz}-1),$ |  | (5) |

while for each random object, the weight is simply $w\_{\rm FKP}$.

#### 4.2.1 Configuration Space

For the configuration space analysis the procedure we follow is the same as in [Anderson et al. (2014)](#bib.bib11), except that our fiducial bin-size is 8 $h^{-1}$Mpc. We repeat some of the details here. We determine the multipoles of the correlation function, $\xi\_{\ell}(s)$, by finding the redshift-space separation, $s$, of pairs of quasars and randoms, in units $h^{-1}$Mpc assuming our fiducial cosmology, and cosine of the angle of the pair to the line-of-sight, $\mu$, and employing the standard [Landy & Szalay (1993)](#bib.bib60) method

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\xi(s,\mu)=\frac{DD(s,\mu)-2DR(s,\mu)+RR(s,\mu)}{RR(s,\mu)},$ |  | (6) |

where $D$ represents the quasar sample and $R$ represents the uniform random sample that simulates the selection function of the quasars. $DD(s,\mu)$ thus represent the number of pairs of quasars with separation $s$ and orientation $\mu$. In order to minimize any noise coming from the finite size of the random catalog, the random catalogs are many times the size of the data catalogs and the resulting counts are normalized accordingly. For the DR14 data, we use a random sample that is 40$\times$ as large as the data, which we have found is sufficiently large for our results to have converged within their quoted precision. For the mocks, we use larger random samples, 100$\times$ for the EZmocks and 70$\times$ for the QPM mocks. This is due to the fact that we use a single random catalog for all mocks. This eliminates any noise in the covariance matrix we determine from the mocks due to the finite size of the random catalogs. However, in order to obtain results to the precision expected for the full ensemble of mocks (e.g., to test their mean results) we require a random sample many times larger than required for a single realization.

We calculate $\xi(s,|\mu|)$ in evenly-spaced bins66
6
The pair-counts are tabulated using a bin width of 1 $h^{-1}$Mpc and summed into x $h^{-1}$Mpc bins, allowing different choices for bin centres and widths. in $s$, testing both 5 and 8 $h^{-1}$Mpc, and 0.01 in $|\mu|$. We then determine even moments of the redshift-space correlation function via

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{2\xi\_{\ell}(s)}{2\ell+1}=\sum^{100}\_{i=1}0.01\xi(s,\mu\_{i})L\_{\ell}(\mu\_{i}),$ |  | (7) |

where $\mu\_{i}=0.01i-0.005$ and $L\_{\ell}$ is a Legendre polynomial of order $\ell$. In this work we only use the $\ell=0$ moment. By defining the monopole this way, we ensure an equal weighting as a function of $\mu$ and thus a truly spherically averaged quantity. This means any distance scale we measure based on the BAO position in $\xi\_{0}$ matches our definition of $D\_{V}$ (given in Eq. [13](#S4.E13 "In 4.3 BAO Modeling ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")).

The resulting correlation function is displayed in Fig. [5](#S4.F5 "Figure 5 ‣ 4.2.1 Configuration Space ‣ 4.2 Clustering Estimators ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"), where it is also compared to the mean of the mock samples we use. We describe the measurements further in Section [7.1](#S7.SS1 "7.1 Clustering Measurements ‣ 7 Results ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2").

Figure 5: Top panel: The spherically averaged redshift-space correlation function of the DR14 quasar sample, for data in the SGC (blue squares) and NGC (red diamonds). The dashed curves display the mean of the 1000 EZmock samples. The data in each region are broadly consistent with the mean of the mocks and with each other. Bottom panel: The NGC and SGC data have been combined (solid black curve) and are now compared to both the EZ and QPM mocks (points with error-bars). The agreement is excellent. The dashed grey curve displays the result for the data when not applying systematic weights; the difference is dramatic and has $\chi^{2}$ significance of more than 180. The covariance matrix is dominated by the low number density of the DR14 quasar sample and the correlation between data points is low, e.g., the correlation between neighboring $s$ bins is $\sim$0.2.

#### 4.2.2 Fourier Space

In order to measure the power spectrum of the quasar sample we start by assigning the objects from the data and random catalogues to a regular Cartesian grid. This is the starting point for using Fourier Transform (FT) based algorithms. In order to avoid spurious grid effects we use a convenient interpolation scheme to smooth the configuration-space overdensity field.

We embed the entire survey volume into a cubic box with size $L\_{b}=7200\,h^{-1}\,{\rm Mpc}$, and subdivide it into $N\_{g}^{3}=1024^{3}$ cubic cells, whose resolution and Nyquist frequency are $7h^{-1}\,{\rm Mpc}$, and $k\_{\rm Ny}=(2\pi/L\_{b})N\_{g}/2=0.447\,h{\rm Mpc}^{-1}$, respectively. To obtain the smoothed overdensity field, an interpolation scheme is needed for the particle-to-grid assignment. By choosing a suitable interpolation scheme we can largely reduce the aliasing effect to a negligible level for frequencies smaller than the Nyqvist frequencies, which in this case comprises the typical scales for the BAO analysis.
Traditional interpolation schemes include the Nearest-Grid-Point (NGP), Cloud-in-Cell (CIC), Triangular-Shaped-Cloud (TSC) and Piecewise Cubic Spline (PCS). These options correspond to the zero-th, first, second and third order polynomial B-spline interpolations, respectively (see [Chaniotis & Poulikakos 2004](#bib.bib23) for higher order interpolation schemes based on B-spline). Additionally, each of these interpolation schemes has an associated grid correction factor that has to be applied to the overdensity field in Fourier space ([Jing, 2005](#bib.bib53)).
The higher the order of the B-spline polynomial used in the grid interpolation, the smaller the effect of the grid on the final measurement. Aliasing arises as an extra limitation which cannot be avoided by just increasing the order of the grid interpolation scheme. Since for cosmological perturbations the bandwidth is not limited above a certain maximum cutoff frequency, the unresolved small scale modes are spuriously identified as modes supported by the grid, resulting in a contamination of the power spectrum, typically at scales close to the Nyqvist frequency. Recently, [Sefusatti et al. (2016)](#bib.bib89) demonstrated that by displacing the position of the initial grid by fractions of the size of the grid cell the effect of the aliasing was greatly suppressed. This procedure is called interlacing and was originally presented in ([Hockney & Eastwood, 1981](#bib.bib50)). In particular, [Sefusatti et al. (2016)](#bib.bib89) found that when a 2-step interlacing was combined with a PCS interpolation, the effect of aliasing was reduced to a level below $0.1\%$, even at the Nyquist scale.

In this work, we apply a $5^{\rm th}$-order B-spline interpolation to calculate the overdensity field on the grid. Additionally, we combine two cartesian grids, displaced by half of their grid size, to account for the aliasing effect. We have checked (by doubling the number of grid cells per side) that the effect of aliasing is totally negligible in the range $k\lesssim 0.4\,h{\rm Mpc}^{-1}$.

After applying the grid interpolation, we obtain an overdensity field $\Delta({\bf r}\_{i})$ at each grid centre, ([Feldman et al., 1994](#bib.bib39)),

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta({\bf r}\_{i})\equiv{w\_{\rm tot}({\bf r}\_{i})}[n\_{\rm qso}({\bf r}\_{i})-\gamma n\_{\rm ran}({\bf r}\_{i})]/I^{1/2}\_{2}.$ |  | (8) |

The quantity $w\_{\rm tot}$ is the total weight for the quasars at the grid location given by Eq ([5](#S4.E5 "In 4.2 Clustering Estimators ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")), $n\_{\rm qso}$ and $n\_{\rm ran}$ are the number density at position ${\bf r}$ of the quasars and random objects, respectively, $\gamma$ is the ratio between the total weighted numbers of the quasars ($N\_{\rm qso}$) and random ($N\_{\rm ran}$) catalogues, i.e., $\gamma=N\_{\rm qso}/N\_{\rm ran}$. Same as for the $\xi$ calculation, we use a random sample with 40$\times$ the size of the DR14 data set, 100$\times$ the size of the mean EZmock, and 70$\times$ the size of the mean QPM mock. Therefore, e.g., $\gamma\sim 0.025$ for the data and $\gamma\sim 0.01$ for the EZmocks. The factor $I\_{2}$, normalizes the amplitude of the observed power in accordance with its definition in a quasar distribution with no survey selection,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $I\_{2}\equiv A\int\langle w\_{\rm sys}w\_{\rm c}n\_{\rm qso}\rangle^{2}(r)w\_{\rm FKP}^{2}(r){\rm d}r$ |  | (9) |

where, $\langle w\_{\rm sys}w\_{\rm c}n\_{\rm qso}\rangle$ is the mean number density of quasars and $A$ the area of the survey in steradians. We perform this integration by sampling the mean number density of quasars in shells of $6.5h^{-1}\,{\rm Mpc}$ and summing in the range $0.8\leq z\leq 2.2$.

In this work, we only present a measurement of the monopole (angle averaged with respect to the line of sight) of the power spectrum77
7
Future eBOSS studies will use the anisotropic signal.. To measure the power spectrum monopole, we must perform the Fourier transformation of the overdensity field $\Delta({\bf r})$ defined in Eq ([8](#S4.E8 "In 4.2.2 Fourier Space ‣ 4.2 Clustering Estimators ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")). Since we are interested in the monopole, the varying line-of-sight of the quasars has no effect on our calculation. Specifically, we need to calculate the following quantity,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $F\_{0}({\bf k})\equiv\int d{\bf r}\ \Delta({\bf r})e^{i{\bf k}\cdot{\bf r}}.$ |  | (10) |

The power spectrum monopole is evaluated by a summation over $k$-directions and in the defined $k$-bin,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P\_{0}(k\_{\rm eff})=\sum\_{i}^{k-bin}F\_{0}({\bf k}\_{i})F^{\*}\_{0}({\bf k}\_{i}),$ |  | (11) |

where $k\_{\rm eff}$ is the mean of all $|{\bf k}|$ values summed in the above equation.

Figure 6: The same as Fig. [5](#S4.F5 "Figure 5 ‣ 4.2.1 Configuration Space ‣ 4.2 Clustering Estimators ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"), except for the power spectrum. For the points with error-bars, a constant of 350 has been subtracted from the mean of the QPM mocks and a constant of 250 has been added to the mean of the EZ mocks. The agreement would be poor without adding these constant offsets, as shown by the dotted curves, which display the respective means without them. In this case, there is clear disagreement at high $k$ with the DR14 measurements, but in opposite directions. A constant is marginalized over in the BAO analysis and we will explicitly demonstrate that our results are insensitive to the choice of mocks used for the covariance matrix, suggesting the constant offsets are unimportant.

We display results for $0.02<k<0.30h$Mpc-1, which is the range that will be used for any BAO measurements (with $k<0.23$Mpc-1 being our fiducial limit).

We perform the measurement of $P\_{0}(k)$ binning $k$ linearly in bins of $0.01\,h~{\rm Mpc}^{-1}$ between $k=0$ and the Nyqvist Frequency. Within this wide range, we limit the BAO analysis to the frequencies $0.02\leq k[h~{\rm Mpc}^{-1}]\leq 0.23$. Scales outside of this range contain negligible information on the BAO peak position. We have checked these statements by using the mock quasar catalogues. The resulting power spectrum contains 21 $k$-bins and is displayed in Fig. [6](#S4.F6 "Figure 6 ‣ 4.2.2 Fourier Space ‣ 4.2 Clustering Estimators ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"), where it is also compared to the mean of the mock samples. We describe these results further in Section [7.1](#S7.SS1 "7.1 Clustering Measurements ‣ 7 Results ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2").

### 4.3 BAO Modeling

We use the same basic modeling template of the BAO signal for both configuration and Fourier space. The BAO model is determined in Fourier space and then either transformed to configuration space or passed through the window function in order to be compared to observations. For both approaches, we determine how different the BAO scale is in our clustering measurements compared to its location in a template constructed using our fiducial cosmology. There are two main effects with cosmological dependence88
8
There is a third effect, which is a small shift in the BAO position due to non-linear evolution, described later in this section. It has minor dependence on cosmology and its total effect is negligible compared to the precision of our measurements, which we demonstrate in later sections. that determine the difference between the observed BAO position and that in the template. The first effect is the difference between the BAO position in the true intrinsic primordial power spectrum and that in the model, with the multiplicative shift depending on the ratio $r\_{\rm d}/r^{\rm fid}\_{\rm d}$, where $r\_{\rm d}$ is the sound horizon at the drag epoch (and thus represents the expected location of the BAO feature in co-moving distance units, due to the physics of the early Universe). The second effect is the difference in projection. The data are measured using a fiducial distance-redshift relation, matching that of the template: if the actual cosmology is different than that assumed we expect a shift that depends on $H(z)$ in the radial direction, and $D\_{A}(z)$ in the angular direction. For spherically averaged clustering measurements, we thus measure

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\alpha=\frac{D\_{V}(z)r^{\rm fid}\_{\rm d}}{D^{\rm fid}\_{V}(z)r\_{\rm d}},$ |  | (12) |

with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D\_{V}(z)=\left[cz(1+z)^{2}H(z)^{-1}D\_{A}^{2}(z)\right]^{1/3}.$ |  | (13) |

Given sufficient signal-to-noise ratio, $D\_{A}$ and $H(z)$ can be measured separately by using the isotropic and anisotropic signal. In this paper we only focus on the isotropic signal due to limited signal-to-noise ratio, and hence, we constrain $D\_{V}$.

The methodology we adopted to measure $\alpha$ is based on that used in [Anderson et al. (2014)](#bib.bib11) (and references therein). We generate a template BAO feature using the linear power spectrum, $P\_{\rm lin}(k)$, obtained from Camb99
9
camb.info ([Lewis et al., 2000](#bib.bib64); [Howlett et al., 2012](#bib.bib52)) and a ‘no-wiggle’ $P\_{\rm nw}(k)$ obtained from the [Eisenstein
& Hu (1998)](#bib.bib35) fitting formulae1010
10
In order to best-match the broadband shape of the linear power spectrum, we use $n\_{s}=0.963$, to be compared to 0.97 when generating the full linear power spectrum from camb. for $\xi$ and following [Kirkby et al. (2013)](#bib.bib57) for $P(k)$, both using our fiducial cosmology (except where otherwise noted).

Again emulating [Anderson et al. (2014)](#bib.bib11) (and references therein), given $P\_{\rm lin}(k)$ and $P\_{\rm nw}(k)$, the linear theory BAO signal is described by the oscillation pattern in the $\mathcal{O}\_{\rm lin}(k)\equiv P\_{\rm lin}(k)/P\_{\rm nw}(k)$. We account for some non-linear evolution effects by ‘damping’ this BAO signal:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{O}\_{\rm damp}(k)=1+\left[\mathcal{O}\_{\rm lin}(k)-1\right]e^{-\frac{1}{2}\Sigma\_{\rm nl}^{2}k^{2}}.$ |  | (14) |

This damping is treated slightly different in the $P(k)$ and $\xi(s)$ analyses, as we describe in Sections [4.3.1](#S4.SS3.SSS1 "4.3.1 Correlation Function Modeling ‣ 4.3 BAO Modeling ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") and [4.3.2](#S4.SS3.SSS2 "4.3.2 Power Spectrum Modelling ‣ 4.3 BAO Modeling ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). In addition to damping the BAO oscillations, non-linear evolution effects are also expected to cause small shifts (of order 0.5 per cent) in the BAO position ([Padmanabhan
& White, 2009](#bib.bib69)), which should have a small cosmological dependence (e.g., the size of the shift is likely dependent on $\sigma\_{8}$). We will show that our results are insensitive to such effects.

#### 4.3.1 Correlation Function Modeling

For the correlation function, we simply use

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P(k)=P\_{\rm nw}(k)\mathcal{O}\_{\rm damp}(k),$ |  | (15) |

and its Fourier transform in order to obtain the configuration-space BAO template, $\xi\_{\rm temp}(s)$. We fix $\Sigma\_{\rm nl}=6h^{-1}$Mpc in the analysis and show that the results are insensitive to this choice. This choice is based on basic extensions of linear theory and the fact that the quasar sample has non-negligible redshift uncertainty. [Seo
& Eisenstein (2007)](#bib.bib90) provide predictions $\Sigma\_{\perp}=10.4D(z)\sigma\_{8}$ and $\Sigma\_{||}=(1+f)\Sigma\_{\perp}$. This decomposition accounts for redshift-space distortions; the real-space prediction is given by $\Sigma\_{\perp}$. The spherical average is $\Sigma^{2}\_{\rm nl}=([\Sigma^{2}\_{\perp}]^{2}\Sigma^{2}\_{||})^{1/3}$. For our fiducial cosmology, $\Sigma\_{\perp}=4.1h^{-1}$Mpc and $\Sigma\_{\rm nl}=5.2h^{-1}$Mpc. We compare these predictions to those obtained from real-space non-linear power spectrum predictions using [Blas et al. (2016)](#bib.bib19)1111
11
[Blas et al. (2016)](#bib.bib19) also includes the shift in the BAO peak, due to the non-linear growth of the matter power spectrum, which we evaluate in Section [6](#S6 "6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")., evaluated at $z=1.5$ using FAST-PT ([McEwen et al., 2016](#bib.bib66)). A value of $\Sigma\_{\perp}=3.7h^{-1}$Mpc produces a BAO feature in our template defined by Eq. [14](#S4.E14 "In 4.3 BAO Modeling ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"), matching the amplitude of the [Blas et al. (2016)](#bib.bib19) template, suggesting reasonable agreement with the more basic [Seo
& Eisenstein (2007)](#bib.bib90) approach. Thus, we expect $\Sigma\_{\rm nl}\sim 5h^{-1}$Mpc for redshift-space measurements; we increase this to $\Sigma\_{\rm nl}=6h^{-1}$Mpc in order to account for redshift uncertainties. We test and discuss this issue further in Section [6](#S6 "6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2").

Given $\xi\_{\rm temp}(s)$, we then fit to the data using the model

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\xi\_{0,{\rm mod}}(s)=B\_{0}\xi\_{\rm temp}(s\alpha)+A\_{1}+A\_{2}/s+A\_{3}/s^{2}.$ |  | (16) |

Including the polynomial makes our results insensitive to shifts in the broad-band shape of the measured $\xi\_{0}$. As in previous analyses (e.g., [Anderson et al. 2014](#bib.bib11)), we apply a Gaussian prior of width 0.4 around the $B\_{0}$ obtained when fitting $\xi\_{\rm temp}$ to the data in the range $30<s<50h^{-1}$Mpc (not including the polynomial terms). These scales are safely outside of the scales where the BAO feature is significant. Using this prior ensures that the BAO feature in the model is neither unphysically large or small.

For both mocks and for the data, we adopt the appropriately weighted average of the NGC and SGC $\xi$ in order to obtain our BAO measurements. The configuration-space analysis does not have the Fourier-space window function concerns discussed in the following section. Thus, each correlation function BAO fit has five free parameters.

#### 4.3.2 Power Spectrum Modelling

In the power spectrum analysis, the position of the BAO peak is described by the oscillation pattern in $\mathcal{O}\_{\rm lin}(k)$. The position of the peak is identified by shifting the pattern through the $\alpha$ parameter as $\mathcal{O}\_{\rm lin}(k/\alpha)$.
We use the same power spectrum template form used for previous BAO fits in the BOSS survey ([Gil-Marín et al., 2015](#bib.bib44)),

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P(k,\alpha)=P\_{\rm sm}(k)\left\{1+\left[\mathcal{O}\_{\rm lin}(k/\alpha)-1\right]e^{-\frac{1}{2}\Sigma\_{\rm nl}^{2}k^{2}}\right\}$ |  | (17) |

where the $P\_{\rm sm}(k)\equiv B^{2}P\_{\rm nw}(k)+A\_{1}k+A\_{2}+A\_{3}/k$ accounts for all the non-linear and redshift space effects in the power spectrum monopole. It is possible to model $P\_{\rm sm}(k)$ with higher polynomial coefficients such as $+A\_{4}/k^{2}+A\_{5}/k^{3}$. Although these terms were used for modelling the broadband power spectrum shape of the LRG galaxies at lower redshifts in BOSS ([Gil-Marín et al., 2015](#bib.bib44)), we have determined that for the current precision and redshift ranges in this paper, adding these two extra terms does not affect the determination of $\alpha$ significantly.

The last step we need to incorporate in the model of Eq. [17](#S4.E17 "In 4.3.2 Power Spectrum Modelling ‣ 4.3 BAO Modeling ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") is the effect of the window function caused by the non-uniform angular distribution of quasars (see Fig. [2](#S3.F2 "Figure 2 ‣ 3.1 Footprint ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")), and the dependence of the mean density of quasars with the radial distance (see. Fig. [1](#S2.F1 "Figure 1 ‣ 2.3 Measuring Redshifts ‣ 2 Data ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")). These two effects are accounted for by following the procedure described in [Wilson et al. (2017)](#bib.bib106).
The masked power spectrum, $\hat{P}\_{0}$ is written as a Hankel Transform (HT) of the masked correlation function $\hat{\xi}\_{0}$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{P}\_{0}(k)=4\pi\int\hat{\xi}\_{0}(s)j\_{0}(sk)\,{\rm d}s,$ |  | (18) |

where $j\_{0}$ is the spherical Bessel function, $j\_{0}(x)=\sin(x)/x$, and $\hat{\xi}\_{0}(s)$ can be written in terms of the correlation function $\ell$-multipoles, corresponding to the inverse HT of the un-masked power spectrum template model,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{\xi}\_{0}(s)={\xi}\_{0}(s)W\_{0}^{2}+\frac{1}{5}{\xi}\_{2}(s)W\_{2}^{2}+\dots.$ |  | (19) |

We neglect any contribution of the power spectrum quadrupole into the monopole through the window function, and therefore we approximate, $\hat{\xi}\_{0}(s)\simeq{\xi}\_{0}(s)W\_{0}^{2}$.
$W\_{i}$ contains all the information on the radial and angular selection functions, and can be modelled either analytically or through the pair-counts of the random catalogue.
For simplicity we follow the later option and we write $W^{2}\_{0}$ as,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $W\_{0}^{2}(s)\propto\sum\_{i,j}RR(s)/s^{2},$ |  | (20) |

where $W\_{0}^{2}(s)$ is normalised to 1 in the $s\rightarrow 0$ limit. The $s^{2}$ term in the denominator accounts for the volume of the shell when the binning is linear in $s$.

The top panel of Fig. [7](#S4.F7 "Figure 7 ‣ 4.3.2 Power Spectrum Modelling ‣ 4.3 BAO Modeling ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") displays the performance of $W\_{0}^{2}(s)$ for the redshift range $0.8\leq z\leq 2.2$, for the NGC and SGC patches, in solid and dashed black lines, respectively. In the case of no survey selection effect (for instance a periodic boundary condition simulation), the function $W\_{0}^{2}(s)$ would approach $W\_{0}^{2}(s)=1$, and the convolution between a theoretical power spectrum and the FT of $W\_{0}^{2}(s)$ (a Dirac delta in this case) would produce no difference between the theoretical and the observed power spectrum.
The effect of a non-flat redshift distribution and a non-uniform sky geometry produces a window function with the shape observed in the top panel of Fig. [7](#S4.F7 "Figure 7 ‣ 4.3.2 Power Spectrum Modelling ‣ 4.3 BAO Modeling ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). As expected, the departure from the ideal $W\_{0}^{2}(s)=1$ case is more prominent in the SGC than in the NGS, as the SGC footprint covers a smaller angular area. The effect of the window function is to produce an extra coupling term (in addition to the non-linear coupling) among the $k$-modes of the power spectrum. As a consequence, the covariance term is increased among $k$-modes and the amplitude of the observed power spectrum is reduced at large scales, as it is shown in the bottom panel of Fig. [7](#S4.F7 "Figure 7 ‣ 4.3.2 Power Spectrum Modelling ‣ 4.3 BAO Modeling ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2").

Figure 7: Top panel: The window function $W^{2}\_{0}$ (see Eq. [20](#S4.E20 "In 4.3.2 Power Spectrum Modelling ‣ 4.3 BAO Modeling ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")) for the NGC (solid line) and for the SGC (dashed line). Bottom panel: The convolution between the theoretical power spectrum with no survey effects (black solid line) and the Fourier Transform of the window function $W^{2}\_{0}$ (red dashed and blue dotted lines for the NGC and SGC geometries, respectively). The effect of the window is to damp the power at $k\lesssim 0.15,h~{\rm Mpc}^{-1}$.

Since the shape of the window function is slightly different for the NGC and SGC regions, we choose to perform the power spectrum BAO fit separately, assuming no correlation among the two disconnected regions. Furthermore, we fit for different broadband parameters in the NGC and SGC, to account for different observational effects, such as photometric calibration, that can yield to a different effective biases for the two separate regions. Thus, we fit for $B$, $A\_{1}$, $A\_{2}$ and $A\_{3}$ separately for NGC and SGC, and keep the same value for $\alpha$ and $\Sigma\_{\rm nl}$. Thus, in total we fit for 10 free parameters (9 if $\Sigma\_{\rm nl}$ is kept constant) using 42 $k$-modes (21 for each patch) in the range $0.02\leq k\,[h{\rm Mpc}^{-1}]\leq 0.23$. We have observed that by following such approach the constraints on $\alpha$ (in both mocks and data) are improved (when compared to the case where the weighted average is used in the fit) and that the resulting likelihoods are closer to a Gaussian distribution.

### 4.4 Parameter Estimation

We assume the likelihood distribution, ${\cal L}$, of any parameter (or vector of parameters), $p$, of interest is a multi-variate Gaussian:

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal L}(p)\propto e^{-\chi^{2}(p)/2}.$ |  | (21) |

The $\chi^{2}$ is given by the standard definition

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\chi^{2}={\bf D}{\sf C}^{-1}{\bf D}^{T},$ |  | (22) |

where ${\sf C}$ represents the covariance matrix of a data vector and ${\bf D}$ is the difference between the data and model vectors, when model parameter $p$ is used. We assume flat priors on all model parameters, unless otherwise noted.

In order to estimate covariance matrices, we use a large number of mock quasar samples (see Section [5](#S5 "5 Simulated Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")), unless otherwise noted. The noise from the finite number of mock realizations requires some corrections to the $\chi^{2}$ values, the width of the likelihood distribution, and the standard deviation of any parameter determined from the same set of mocks used to define the covariance matrix. These factors are defined in [Hartlap et al. (2007)](#bib.bib47); [Dodelson
& Schneider (2013)](#bib.bib33) and [Percival et al. (2014)](#bib.bib74); we apply the factors in the same way as in, e.g., [Anderson et al. (2014)](#bib.bib11). For our fiducial $\xi(s)$ results, we use 1000 mocks and 18 measurement bins (fitting to the weighted mean of the NGC and SGC results). For the $P(k)$ analysis we fit NGC and SGC separately, which corresponds of using 1000 mocks and 21 measurement bins for each NGC and SGC regions. In both cases, the number of mock realisations is much larger than the number of measurement bins, implying the finite number of mocks has less than a 2 per cent effect on our uncertainty estimates. We observe that for both $\xi(s)$ and $P(k)$ analyses the corresponding covariance matrices are dominated by their diagonal elements.

The covariance matrix derived from the mocks is dominated by its shot noise component due to the low density of the quasars. On one hand, the EZ and QPM mocks have been produced to match the effective number of objects observed in the data sample (${\bar{N}}\_{\rm eff}$ in Table [1](#S3.T1 "Table 1 ‣ 3.1 Footprint ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")). On the other hand, the EZ and QPM mocks do not currently include the redshift failures and collision pair effects. Therefore, the actual number of quasars in the mocks matches the effective number of quasars on the data catalogue, which makes the total number of quasars in the mocks slightly higher than in the data. As a consequence, the diagonal and off-diagonal components of the covariance are underestimated approximately by the ratio between ${\bar{N}}\_{\rm eff}$ and ${\bar{N}}\_{\rm Q}$ in the range $0.8\leq z\leq 2.2$. In order to correct for this effect we re-scale the derived covariance elements by these factors when analyzing the DR14 data, which are 1.069 for the NGC and 1.073 for the SGC. Future eBOSS analyses will include these effects in the mocks (and therefore this correction will be unnecessary). Here, we use the simple scaling as it has only a 3 per cent effect on the recovered uncertainty.

## 5 Simulated Catalogs

We use two different methods to create a total of 1400 simulations of the DR14 quasar sample, which we refer to as ‘mocks’. In order to create this number of mocks, approximate methods are required. Our approach in this respect is similar to previous BOSS analyses ([Manera et al., 2013](#bib.bib65); [Anderson et al., 2014](#bib.bib11); [Alam et al., 2016](#bib.bib9)). The two methods used are ‘EZmock’ and ‘QPM’ and are described in the following sub-sections.

### 5.1 EZmocks

For this work, we construct 1000 light-cone mock catalogues covering the full survey area of DR14 (NGC+SGC) and reproducing the redshift evolution of the observed quasar clustering. These are created using the ‘EZmock’ (Effective Zel’dovich approximation mock catalogue, [Chuang et al. 2015a](#bib.bib24)) method. EZmocks are constructed using the Zel’dovich approximation of the density field. This approach accounts for non-linear effects and also halo bias (i.e. linear, nonlinear, deterministic, and stochastic bias) into an effective modeling with few parameters, which can be efficiently calibrated with observations or N-body simulations. [Chuang et al. (2015b)](#bib.bib25) demonstrates that the EZmock technique is able to precisely reproduce the clustering of a given sample (including 2- and 3-point statistics) with minimal computational resources, compared to other methods. We use an improved version of EZmock code with respect to the one described in [Chuang et al. (2015a)](#bib.bib24). In our work, we assign the positions of quasars to simulated dark matter particles instead of populating them following a cloud-in-cell distribution. With this change, we do not need to enhance the BAO signal in the initial conditions, as done in [Chuang et al. (2015a)](#bib.bib24).

For this study, we calibrate the bias parameters with the observed DR14 eBOSS quasar clustering directly. The NGC and SGC regions are created from separate simulations and are treated independently, with bias values fit to the measured clustering and the $n(z)$ taken as in Fig. [1](#S2.F1 "Figure 1 ‣ 2.3 Measuring Redshifts ‣ 2 Data ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). Comparisons between the mean clustering in the EZmock samples and the measured eBOSS clustering can be found in Figs. [5](#S4.F5 "Figure 5 ‣ 4.2.1 Configuration Space ‣ 4.2 Clustering Estimators ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") and [6](#S4.F6 "Figure 6 ‣ 4.2.2 Fourier Space ‣ 4.2 Clustering Estimators ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"), demonstrating that a good match has been produced. The EZmocks use the same initial power spectrum used by the mock catalogues of the final BOSS data release (DR12; [Kitaura et al. 2016](#bib.bib59); [Alam et al. 2016](#bib.bib9)). The fiducial cosmology model is $\Lambda$CDM with $\Omega\_{m}$=0.307115, $h$=0.6777, $\sigma\_{8}$=0.8225, $\Omega\_{b}$=0.048206, $n\_{s}$=0.9611 (see [Kitaura et al. 2016](#bib.bib59) for details).

Each light-cone mock constructed for this work is composed of 7 redshift shells. The redshift shells for a given light-cone mock are computed using different EZmock parameters but they share the same initial Gaussian density field so that the background density field is continuous. Each redshift shell is taken from one corresponding EZmock periodic box with the size of (5$h^{-1}$Gpc)3. For this study, we generated 1000$\times$7(shells)$\times$2(NGC+SGC)$=$14,000 EZmock boxes in total. We use the code make\_survey [Carlson & White (2010)](#bib.bib22); [White et al. (2014)](#bib.bib105) to construct each redshift shell from the corresponding box.

Figure 8: 
We compare the linear bias measured from EZmocks used in this work with the other measurements from observed data ([Croom et al., 2005](#bib.bib28); [Laurent et al., 2017](#bib.bib62)). The bias evolution in the EZmocks is in good agreement with these works.

In order to determine the redshift evolution of each EZmock parameter, we need to measure/determine the parameters at different redshifts. However, the clustering measurements from the observation corresponding to each redshift shell are too noisy to be used to determine the EZmock parameter values. Therefore, we use samples from overlapping redshift bins to measure the EZmock parameters at different redshift and do a proper inter- or extra- polation to determine the parameters for all the 7 redshift shells.
For each EZmock parameter $p$, we assume that its functional dependency is well approximated by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle p=c\_{0}+c\_{1}Z(1)+c\_{2}Z(2),$ |  | (23) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle Z(i)=\frac{\sum\limits\_{z\_{min}\leq z\_{j}<z\_{max}}N(z\_{j}){z\_{j}}^{i}}{\sum\limits\_{z\_{min}\leq z\_{j}<z\_{max}}N(z\_{j})},\quad i=1,2,$ |  | (24) |

of the number count $N(z\_{j})$ within a given redshift bin $z\_{j}$ (with bin size $\Delta z=0.01$).

For this work, we measured the EZmock parameters from observation in the following three redshift ranges: $0.8\leq z\_{1}<1.5$, $1.2\leq z\_{2}<1.8$, and $1.5\leq z\_{3}<2.2$, respectively. We determine the $c\_{0}$, $c\_{1}$, and $c\_{2}$ by solving the following equations

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle p\_{1}=c\_{0}+c\_{1}Z\_{1}(1)+c\_{2}Z\_{1}(2),$ |  |
|  |  |  |
| --- | --- | --- |
|  | $\displaystyle p\_{2}=c\_{0}+c\_{1}Z\_{2}(1)+c\_{2}Z\_{2}(2),$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle p\_{3}=c\_{0}+c\_{1}Z\_{3}(1)+c\_{2}Z\_{3}(2).$ |  | (25) |

Having solved the system of Eqs. [25](#S5.E25 "In 5.1 EZmocks ‣ 5 Simulated Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") for the coefficients $c\_{0}$, $c\_{1}$ and $c\_{2}$, Eq. [23](#S5.E23 "In 5.1 EZmocks ‣ 5 Simulated Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") is used to determine an EZmock parameter value for any given redshift shell.

Fig. [8](#S5.F8 "Figure 8 ‣ 5.1 EZmocks ‣ 5 Simulated Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") compares the linear bias measured from EZmocks used in this work with the other measurements ([Croom et al., 2005](#bib.bib28); [Laurent et al., 2017](#bib.bib62)). For each redshift shell, the bias is measured from the 1000 EZmock boxes. The EZmock parameters have been calibrated using the observed data in three redshift bins as described above, so that EZmocks present a consistent linear bias evolution in comparison with other works.
More details of the algorithm, clustering performance, and tests on bias evolution will be provided in [Chuang et al. (in prep.)](#bib.bib26).

### 5.2 QPM Mocks

Figure 9: Left panel: The mean halo occupation of quasars used in the QPM mocks. The solid red curve shows the mean number of central quasars per halo, while the blue dashed curve indicates the mean number of satellite quasars per halo. The horizontal asymptote of 0.01 central quasars per halo reflects the adopted duty cycle of 1% for quasars in the eBOSS sample. The number of central and satellite quasars in a halo are uncorrelated with one another; i.e., the presence of a satellite quasar is not conditioned on the existence of a central quasar. Right panel: The projected correlation function, $w\_{p}(r\_{p})$, yielded by the HOD in the left panel. For comparison, the red squares are the measurement of $w\_{p}(r\_{p})$ of quasars from [Kayo & Oguri (2012)](#bib.bib55), while the blue circles represent the measurements from [Ross et al. (2009)](#bib.bib82). The solid curve is calculated from the theoretical HOD model of [Tinker et al. (2012)](#bib.bib99).

Quick Particle Mesh (QPM) mocks follow the method of [White et al. (2014)](#bib.bib105). In brief, QPM uses a low-resolution particle mesh gravity solver to evolve a density field forward in time. This approach captures the non-linear evolution of the density field, but does not have sufficient spatial or mass resolution to form dark matter halos. Particles are sampled from the density field in a fashion to approximate the distribution of small-scale densities of halos. This process mimics both the one-point and two-point distributions of halos—their mass function and bias function. This approximate halo catalog can then be treated in the same manner as that from a high-resolution simulation and populated with galaxies according to a halo occupation distribution (HOD; c.f. [Tinker et al. 2012](#bib.bib99)). For the mocks used in this paper, we have adjusted the parameters of [White et al. (2014)](#bib.bib105) that map local density to halo mass to account for the change in redshift ($z\sim 2.5$ rather than $z\sim 0.5$ in [White et al. 2014](#bib.bib105)), as well as extending this mapping to lower halo masses, as required by the halos occupied by quasars.

To parameterize the halo occupation of quasars, we use the five-parameter HOD presented in [Tinker et al. (2012)](#bib.bib99), which separates objects into central quasars and satellite quasars. To determine the HOD of the DR14 quasar sample, the peak of the $n(z)$ curve is the number density that the HOD is required to match. This number, in addition to the quasar large-scale bias measurement of $b\_{\rm Q}=2.45$ allows us to determine the duty cycle of quasars. In the HOD context, the duty cycle is the fraction of halos that have quasars at their centres. There is some extra freedom due to the fraction of quasars that are satellites in larger halos, but this population is a minority of quasars. The left-hand side of Fig. [9](#S5.F9 "Figure 9 ‣ 5.2 QPM Mocks ‣ 5 Simulated Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") shows the HOD that matches both the peak of $n(z)$ and $b\_{\rm Q}=2.45$ ([Laurent et al., 2017](#bib.bib62)) with a satellite fraction of 0.15. The right-hand side of Figure [9](#S5.F9 "Figure 9 ‣ 5.2 QPM Mocks ‣ 5 Simulated Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") compares the projected correlation function predicted by this HOD to measurements of quasar clustering from [Kayo & Oguri (2012)](#bib.bib55) and [Ross et al. (2009)](#bib.bib82). Although the quasar selection algorithms for these two papers are markedly different from eBOSS DR14, both yielding much smaller number densities than the DR14 sample, the measured clustering is remarkably similar to that predicted by the HOD model. The smaller number density in the [Ross et al. (2009)](#bib.bib82) and [Kayo & Oguri (2012)](#bib.bib55) samples would be reflected in a lower duty cycle, with limited impact on the amplitude and shape of clustering.

The implementation of the HOD used here assumes no correlation between the occupation of central and satellite quasars; i.e., the presence of a satellite quasar is not conditioned on the existence of a central quasar in a given halo. This assumption is also borne out by Fig. [9](#S5.F9 "Figure 9 ‣ 5.2 QPM Mocks ‣ 5 Simulated Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")—if all satellites were required to exist in halos with a central quasar, the amplitude of $w\_{p}(r\_{p})$ at $r\_{p}\la 1h^{-1}$Mpc would be larger by a factor of 100 while the large-scale bias would be unchanged. Such a dramatic change in the shape of quasar clustering is clearly not allowed by the data.

We simulated 100 cubic boxes of size $L=5120h^{-1}\,{\rm Mpc}$. The boxes are remapped to fit the volume of the full planned survey using the code make\_survey [Carlson & White (2010)](#bib.bib22); [White et al. (2014)](#bib.bib105). The same 100 cubic boxes are used for the Northern and Southern Galactic caps. The analysis presented here is based on the first two years of eBOSS data and therefore on a smaller volume. This situation allows to use different parts of a single QPM box to produce different realizations. Changing the orientation of the original box, we identified four configurations with less than 1.5 per cent overlap. We used these configurations to produce 400 QPM mocks per Galactic cap. The overlap between SGC and NGC can be as high as 10 per cent, but we identified pairs of configurations where the overlap is kept below 2 per cent. In this way we are able to compare Fourier space and configuration space results for the whole survey on a mock-by-mock basis (see Section [6](#S6 "6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")).

We transform the boxes to mock catalogs in the following manner. Cartesian comoving coordinates of the cubic boxes are transformed to angular coordinates and radial distances using a flat $\Lambda$CDM cosmology defined in Table [2](#S4.T2 "Table 2 ‣ 4.1 Fiducial Cosmology ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). Objects outside the angular mask are removed and veto masks accounting for bright stars, bright objects, plates centerposts and bad photometric fields are applied in the same manner as for the data (see Section [3.2](#S3.SS2 "3.2 Veto Masks ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")). The number density of quasars is downsampled to fit the redshift distribution (see Fig. [1](#S2.F1 "Figure 1 ‣ 2.3 Measuring Redshifts ‣ 2 Data ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")) and FKP weights are calculated using the same value of $P\_{0}$ (see Eq. [4](#S4.E4 "In 4.2 Clustering Estimators ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")). Furthermore, redshifts are smeared according to a Gaussian distribution of width taken from the eBOSS early analysis [Dawson et al. (2016)](#bib.bib31), namely $\sigma\_{z}=300\,$km s-1 for $z<1.5$ and $\sigma\_{z}=400\times(z-1.5)+300\,$km s-1 above.

## 6 Tests on Mocks

We test our methodological choices by analyzing our mock catalogs and the robustness of the results to these different choices. These tests inform our decisions about how to combine results from different clustering estimators. When quoting uncertainties, we use half the width of the $\Delta\chi^{2}=1$ region, matching the approach of [Ross et al. (2015)](#bib.bib80). This choice best extrapolates to the expectation for data with greater signal to noise (e.g., future data releases), as the likelihood for BAO measurements is generally wider than a Gaussian distribution1212
12
This effect is negligible for high signal-to-noise ratio measurements, such as those in [Alam et al. (2016)](#bib.bib9)..

We first consider the results obtained from the mean of the mock samples, which are listed in Table [3](#S6.T3 "Table 3 ‣ 6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). For $\alpha$, we subtract the expected value of 1.0010 from the EZ mocks and and 1.0011 for the QPM mocks. All of the mean mock results are biased to be high, by between 0.001 and 0.004. The correlation function and power spectrum results show good agreement, with negligible differences in $\alpha$ and its uncertainty for our fiducial cases.

Non-linear structure growth is expected to produce such slightly biased $\alpha$ values, of expected fractional size $\sim 0.5D(z)^{2}$ ([Padmanabhan
& White, 2009](#bib.bib69)), implying a shift of 0.13 per cent for the DR14 quasar sample. We test this assumption by using [Blas et al. (2016)](#bib.bib19) to produce a BAO template that incorporates the expected non-linear structure growth effects. We compare this result to our template given by Eq. [14](#S4.E14 "In 4.3 BAO Modeling ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") with $\Sigma\_{\rm nl}=3.7h^{-1}$Mpc, as such a value yields a BAO feature of matching size. We measure a shift between the two templates of 0.07 per cent, which represents the prediction for the shift in $\alpha$ for the matter power spectrum. [Padmanabhan
& White (2009)](#bib.bib69) demonstrate the expected shift is roughly proportional to the bias of the sample, as the shift can be explained by higher-order bias terms and these for dark matter halos are roughly proportional to the linear bias. Given that [Laurent et al. (2017)](#bib.bib62) obtains a bias of 2.45 for eBOSS quasars, we should expect roughly 0.2 per cent shifts in the $\alpha$ recovered from our fiducial template (which includes no shifts due to non-linear structure growth). This prediction is generally consistent with our results when using the mean of the mocks. The differences in these tests, compared with the expected $\alpha$, are at most 2$\sigma$ in terms of the ensemble of mocks being tested and never more than 0.1$\sigma$ compared to the expected result for a single realization. We thus consider any potential bias due to non-linear structure growth to be negligible given the uncertainty obtained from the DR14 quasar sample.

In order to test the effect of redshift uncertainties, we have run the QPM mocks with a variety of assumptions on the redshift uncertainty; full details can be found in [Zarrouk et al. (in prep.)](#bib.bib111). We simply consider the fiducial case, with redshift uncertainty matching Fig. 11 of [Dawson et al. (2016)](#bib.bib31) and a case without any redshift uncertainty. Without any redshift uncertainty, the mean $\xi(s)$ of the QPM mocks is best-fit by $\Sigma\_{\rm nl}=3.7h^{-1}$Mpc; with the redshift uncertainty, the best-fit is $\Sigma\_{\rm nl}=5.5h^{-1}$Mpc. These results suggest our choice to use $\Sigma\_{\rm nl}=6.0h^{-1}$Mpc is slightly conservative (greater $\Sigma\_{\rm nl}$ leads to a greater uncertainty obtained from the likelihood).

Table 3: Tests of BAO fits on the mean of the quasar mocks. Fiducial results use the EZmocks for the covariance matrix, $\Delta s=8h^{-1}$Mpc; $35<s<180h^{-1}$Mpc for $\xi(s)$, and evenly-spaced $\Delta k=0.01h$Mpc-1; $0.02<k<0.23\,h$Mpc-1 for $P(k)$. The uncertainties are those for the full ensemble, e.g., one with 1000 (400) times the size of a single EZ (QPM) mock. The EZmock and QPM results are independent, but results using the same set of mocks are highly correlated. A small positive bias is expected from non-linear structure growth, see text for details.

|  |  |
| --- | --- |
| case | $\alpha-\alpha\_{\rm exp}$ |
| EZ mocks: |  |
| $\xi(s)$: |  |
| fiducial | $0.0023\pm 0.0016$ |
| 5$h^{-1}$Mpc | $0.0027\pm 0.0016$ |
| $P(k)$: |  |
| fiducial | $0.0019\pm 0.0017$ |
| $k\_{\rm max}=0.30\,h{\rm Mpc}^{-1}$ | $0.0009\pm 0.0017$ |
| $\Sigma\_{\rm nl}=[6\pm 3]\,h^{-1}{\rm Mpc}$ | $0.0021\pm 0.0016$ |
| $\Sigma\_{\rm nl}=[6\pm 3]\,h^{-1}{\rm Mpc}$ & $k\_{\rm max}=0.30$ | $0.0011\pm 0.0016$ |
| log$k$ - binning | $0.0032\pm 0.0017$ |
| log$k$ - binning & $k\_{\rm max}=0.30\,h{\rm Mpc}^{-1}$ | $0.0022\pm 0.0016$ |
| $A\_{4}$, $A\_{5}$ terms | $0.0037\pm 0.0017$ |
| QPM mocks: |  |
| $\xi(s)$: |  |
| fiducial | $0.0017\pm 0.0028$ |
| 5$h^{-1}$Mpc | $0.0027\pm 0.0028$ |
| QPM cov | $0.0023\pm 0.0026$ |
| $P(k)$: |  |
| fiducial | $0.0017\pm 0.0027$ |
| QPM cov | $0.0012\pm 0.0026$ |
|  |  |

Table [4](#S6.T4 "Table 4 ‣ 6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") displays the results obtained when fitting each individual mock. Here, we only report statistics for mocks that have a $\Delta\chi^{2}=1$ on both sides of the minimum $\chi^{2}$, within our prior range of $0.8<\alpha<1.2$. We designate each such mock result a ‘detection’. Over 90 per cent of the mock samples satisfy this condition. For this reason, the mean $\sigma$s are slightly less than that obtained for the mean of the mock realizations (multiplying the uncertainty in Table [3](#S6.T3 "Table 3 ‣ 6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") by $\sqrt{N\_{\rm mock}}$). The standard deviation of these samples is close to the mean uncertainty, as would be expected for a Gaussian distribution.

Table 4: Statistics for BAO fits on EZ and QPM mocks. $\langle\alpha\rangle$ is the mean measured BAO parameter with $1\sigma$ bounds within the range $0.8<\alpha<1.2$. $\langle\sigma\rangle$ is the same for the uncertainty obtained from $\Delta\chi^{2}=1$ region and $S$ is the standard deviation of these $\alpha$. $N\_{\rm det}$ is the number of realizations with such $1\sigma$ bounds. Both EZmocks and QPMmocks were created with a slightly different cosmology than our fiducial assumed cosmology. Thus, for the EZmocks, the expected $\alpha$ values are 1.0010; and for QPM 1.0011. The $\xi$ bin size is 8$h^{-1}$Mpc, unless noted otherwise. Tests of shifting bin centres are noted by $+x$, with $x$ representing the shift in $h^{-1}$Mpc. The damping is $\Sigma\_{\rm nl}=6h^{-1}$Mpc, unless otherwise noted. The binning for $P(k)$ is linear spaced in 0.01$h$Mpc-1, unless otherwise noted. As for $\xi$, test of shifting bin centres are noted by $+x/4$, with $x/4$ representing the shift in fractions of the $k$-bin size. The EZmock and QPM results are independent, but results using the same set of mocks are highly correlated. A small positive bias is expected from non-linear structure growth, see text for details.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| case (+bin shift) | $\langle\alpha\rangle$ | $\langle\sigma\rangle$ | $S$ | $N\_{\rm det}/N\_{\rm tot}$ |
| EZ mocks: |  |  |  |  |
| consensus $P(k)+\xi(s)$ | 1.003 | 0.050 | 0.050 | 944/1000 |
| $\xi(s)$: |  |  |  |  |
| combined | 1.003 | 0.049 | 0.049 | 939/1000 |
| fiducial | 1.002 | 0.048 | 0.050 | 932/1000 |
| +2 | 1.002 | 0.049 | 0.050 | 928/1000 |
| +4 | 1.002 | 0.048 | 0.050 | 938/1000 |
| +6 | 1.003 | 0.048 | 0.051 | 929/1000 |
| 5$h^{-1}$Mpc | 1.003 | 0.049 | 0.050 | 937/1000 |
| $P(k)$: |  |  |  |  |
| combined | 1.002 | 0.052 | 0.050 | 941/1000 |
| fiducial | 1.002 | 0.051 | 0.051 | 929/1000 |
| +1/4 | 1.001 | 0.052 | 0.050 | 931/1000 |
| +2/4 | 1.004 | 0.051 | 0.049 | 935/1000 |
| +3/4 | 1.001 | 0.052 | 0.050 | 937/1000 |
| log$k$ - binning | 1.002 | 0.051 | 0.050 | 927/1000 |
| $k\_{\rm max}=0.30\,h{\rm Mpc}^{-1}$ | 1.002 | 0.051 | 0.051 | 934/1000 |
| QPM mocks: |  |  |  |  |
| $\xi(s)$: |  |  |  |  |
| fiducial | 1.001 | 0.051 | 0.052 | 361/400 |
| 5$h^{-1}$Mpc | 1.000 | 0.050 | 0.051 | 355/400 |
| QPM cov | 1.002 | 0.051 | 0.052 | 369/400 |
| $P(k)$: |  |  |  |  |
| fiducial | 0.998 | 0.049 | 0.051 | 354/400 |
| QPM cov | 0.999 | 0.049 | 0.049 | 359/400 |
|  |  |  |  |  |

For the correlation function, the mean $\alpha$ values are similar to those obtained when testing the mean of the mocks, as expected. We test bin sizes of 5$h^{-1}$Mpc and 8$h^{-1}$Mpc; the results are extremely similar and we thus choose 8$h^{-1}$Mpc binning as it represents the smaller data vector. The QPM and EZ mocks produce consistent results, suggesting the separate methods agree on the expected BAO signal-to-noise ratio in our DR14 quasar sample. In particular, the results for the QPM mocks are insensitive to whether we use the QPM mocks or the EZ mocks to construct the covariance matrix used for the fits. This suggests our results are robust to uncertainties in how we construct the covariance matrix.

For 8$h^{-1}$Mpc correlation function binning, results using different bin centres are not perfectly correlated. Instead, the correlation factors, when shifting by each available 2$h^{-1}$Mpc shift, are close to 0.9 (the range is 0.88 to 0.92). Thus, slightly improved results are obtained when combining the results of these four bin centres; for Gaussian distributions, we would expect a 4 per cent improvement given four measurements with correlation 0.9. We combine the results by simply taking the mean of the four likelihoods, matching the approach of [Ross et al. (2015)](#bib.bib80). This combination increases the number of detections from 932 to 939 and reduces the standard deviation from 0.050 to 0.049. These results are labeled ‘combined’ in Table [4](#S6.T4 "Table 4 ‣ 6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") and represent our optimized method for measuring the correlation function BAO scale.

We find broadly consistent results in Fourier space. The fiducial power spectrum case recovers essentially the same number of detections (929 compared to 932) and has a slightly larger mean uncertainty and standard deviation. We test four bin centres for $P(k)$, shifting the centre by factors of 0.025$k$Mpc-1. These results are more correlated than the $\xi(s)$ bin centre results, as they range 0.94 and 0.96. Combining across the bin centre results by taking the mean of the four likelihoods increases the number of detections to 941 while keeping the mean uncertainty and standard deviation unchanged. The power spectrum results are consistent whether the QPM or EZ mocks are being tested, whether a logarithmic or linear $k$-space binning is used, and whether the maximum $k$-vector for the analysis is set to $0.23$ or $0.30\,h{\rm Mpc}^{-1}$.

We compare the $P(k)$ and $\xi(s)$ results directly for the cases where we averaged across the bin centres for the EZmocks (denoted ‘combined’ in Table [4](#S6.T4 "Table 4 ‣ 6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")). The recovered $\alpha$ are plotted against each other in the top panel Fig. [10](#S6.F10 "Figure 10 ‣ 6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"), using steelblue circles. The results are strongly correlated (the correlation factor is 0.97) and are unbiased relative to each other. The bottom panel in Fig. [10](#S6.F10 "Figure 10 ‣ 6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") displays the uncertainty of the combined $P(k)$ and $\xi(s)$ results. The uncertainties are not as correlated as the best-fit $\alpha$, as the uncertainties obtained from the $P(k)$ likelihoods are more narrowly distributed than the $\xi(s)$ counterparts.

Given that the combined $P(k)$ and $\xi(s)$ produce slightly different likelihoods, but with strong correlation in the maximum likelihood, we adopt the mean of the $P(k)$ and $\xi(s)$ results as a ‘consensus’ measurement. Doing so, we obtain a slight increase in the number of detections (up to 944) and the standard deviation in the maximum likelihood value of $\alpha$ matches the mean uncertainty obtained from the likelihood. Further, $(\alpha-\langle\alpha\rangle)/\sigma(\alpha)$ is distributed similarly to a unit Gaussian distribution, as shown in Fig. [11](#S6.F11 "Figure 11 ‣ 6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). These results suggest that the uncertainty we obtain by combining the $P(k)$ and $\xi(s)$ likelihoods are indeed good estimates of the uncertainty on $\alpha$ for each mock realization. We copy this approach when obtaining our consensus results using the DR14 quasar data.

Figure 10: A comparison of power spectrum and correlation function BAO fit results. The results for the mocks are shown in steelblue circles, with the result for the DR14 quasar data indicated by an orange star. Top panel: The best-fit BAO parameter, $\alpha$. The two statistics reveal strongly correlated results, with a correlation coefficient 0.97. Bottom panel: The uncertainty on $\alpha$, recovered from the likelihood. The results are correlated, but the power spectrum uncertainties are drawn from a more narrow distribution. The differences between the power spectrum and correlation function results are clearly typical of our mock samples.

Figure 11:  The distribution of mock BAO results obtained from combining the power spectrum and correlation function BAO results, compared to a unit Gaussian. The low $D\_{n}$ and the high $p$-value suggest that the uncertainties we obtain are as expected for a Gaussian distribution.

The tests presented in this Section define our procedure for obtaining BAO measurements from the data. The results suggest that there are no reasonable methodological choices that will affect our estimate of the uncertainty on our measurements by more than 10 per cent or bias our results by more than 0.1$\sigma$.

## 7 Results

### 7.1 Clustering Measurements

We measure the clustering of the DR14 quasar sample in the respective SGC and NGC regions, i.e., the window function is normalized in each respective region, and then the results are combined. In this section, we present the clustering measurements, in both configuration and Fourier space, comparing the results to each other and to the mock DR14 samples.

Fig. [5](#S4.F5 "Figure 5 ‣ 4.2.1 Configuration Space ‣ 4.2 Clustering Estimators ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") displays the spherically averaged redshift-space correlation function of the DR14 quasar sample for the data in the SGC (blue squares) and NGC (red diamonds). The dashed curves display the mean of the 1000 EZmock samples. The data in each region is broadly consistent with the mean of the mocks and with each other. Each recovers a good $\chi^{2}$ when tested against the mean of the mocks, both when the NGC and SGC are combined and compared individually. We use the sum of the respective covariance matrices to test the consistency between the NGC and SGC, over the same range of scales. The $\chi^{2}$ is 30.0 for these 24 measurement bins, suggesting the clustering of the two regions is consistent.

The bottom panel of Fig. [5](#S4.F5 "Figure 5 ‣ 4.2.1 Configuration Space ‣ 4.2 Clustering Estimators ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") displays the results combining NGC and SGC (now with a solid black curve for the data) and includes the mean of the QPM mocks for an additional comparison. The $\chi^{2}$/dof, when comparing against both sets of mocks, is close to one and what appears to be the BAO feature can be seen at $s\sim 100h^{-1}$Mpc. In configuration space, the DR14 quasar clustering is consistent with the expected signal and noise. The grey dashed line in the figure displays the clustering of the DR14 quasar sample when the systematic weights (defined in Section [3.4](#S3.SS4 "3.4 Systematic Weights for Dependencies on Imaging Properties ‣ 3 LSS Catalogs ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")) for depth and Galactic extinction are not used. The $\chi^{2}$ in comparison to the mocks is labeled in parentheses in the figure; it is worse by $\Delta\chi^{2}>190$. This result is equivalent to having greater than a 13$\sigma$ effect, and can be compared to BOSS DR12, where the systematic weights had at most a 4$\sigma$ effect on the measured clustering ([Ross et al., 2017](#bib.bib81)).

Fig. [6](#S4.F6 "Figure 6 ‣ 4.2.2 Fourier Space ‣ 4.2 Clustering Estimators ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") displays the same information as in Fig. [5](#S4.F5 "Figure 5 ‣ 4.2.1 Configuration Space ‣ 4.2 Clustering Estimators ‣ 4 Methodology ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"), but in Fourier space. As expected, there is a similar consistency between the NGC and the SGC results, compared to each other and to the mean of the mock samples. For this comparison, we have added a constant value to the mock results; otherwise the agreement would not be so excellent. The mean $P(k)$ of the mocks with no constant applied are shown by the dotted curves. We marginalize over a free constant term in the BAO analysis, and therefore believe this to be a fair comparison to evaluate the agreement, in terms of the signal relevant to the BAO measurement. Further, this difference in power clearly does not strongly affect the covariance matrix, as we obtained nearly identical results when fitting the QPM mocks when using either the QPM mocks or EZmocks to construct the covariance matrix. The effect of the systematic weights is negligible at scales $k>0.02h$Mpc-1; the result without applying the weights is barely distinguishable (it is plotted with a grey, dashed curve) and the $\chi^{2}$ comparison to the mean of the mock samples changes by at most 5.2 (when compared to the QPM mocks). These results imply that, while the effect of the systematic weights has great total significance, any effect on the measurement of the BAO scale is likely to be negligible.

### 7.2 BAO Measurements

Figure 12: The eBOSS DR14 quasar spherically-averaged BAO signal, in Fourier- (top; $P(k)$) and configuration- (bottom; $\xi(s)$) space. In order to isolate the BAO feature, we have subtracted the smooth component of the best-fit model from the best-fit model and the measurements. In Fourier-space, we have additionally divided by the smooth component of the best-fit $P(k)$ model. Each clustering statistic prefers the BAO model to the smooth model at better than 2.5$\sigma$ and obtains a BAO distance measurement with a precision slightly greater than 4 per cent.

Fig. [12](#S7.F12 "Figure 12 ‣ 7.2 BAO Measurements ‣ 7 Results ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") displays the measured BAO feature in the eBOSS DR14 quasar sample, using our fiducial analysis choices. The top panel shows the Fourier-space result and the bottom panel the result in configuration space. The BAO feature has been isolated in each case by subtracting the smooth component of the best-fit model; for $P(k)$, we also divide the results by the smooth component. A clear BAO feature is visible in both spaces.

The statistics for the BAO measurement can be found in top rows of Table [5](#S7.T5 "Table 5 ‣ 7.2 BAO Measurements ‣ 7 Results ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). These are the ‘combined’ results, where we have taken the mean likelihood across our four bin centres (as described in Section [6](#S6 "6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2")). For both $P(k)$ and $\xi(s)$, the $\chi^{2}$/dof is less than 1 and the precision is close to 4 per cent, with $\xi(s)$ obtaining somewhat better precision (3.7 compared to 4.0 per cent). The two measurements differ by only 0.001 in $\alpha$. If anything, the agreement is surprisingly good. One can compare the orange star, representing our DR14 measurements, to the locus of mocks in the top panel of Fig. [10](#S6.F10 "Figure 10 ‣ 6 Tests on Mocks ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). The bottom panel of the same figure displays the comparison of the uncertainties we recover from each measurement. Our results are more precise than the average results but are clearly within the locus of points thus suggesting they are consistent with any expectations provided by our tests on mocks. We combine the two likelihoods and obtain a precision of 3.8 per cent. Translating this result to a distance measurement yields $D\_{V}(z=1.52)=3843\pm 147\left(r\_{\rm d}/r\_{\rm d,fid}\right)\$Mpc.

Fig. [13](#S7.F13 "Figure 13 ‣ 7.2 BAO Measurements ‣ 7 Results ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") displays the likelihood and detection significance, in terms of $\Delta\chi^{2}$, derived from the spherically-averaged correlation function (purple), power spectrum (burlywood), and their mean (black). The dashed curve represents the no BAO model; one can observe that the detection significance is greater than 2.8$\sigma$ for both $P(k)$ and $\xi(s)$. All of the likelihoods are similarly skewed compared to a Gaussian, as large values of $\alpha$ are not rejected to the same extent as low values. The black curve represents the eBOSS DR14 quasar BAO distance measurement. For any cosmological tests, we recommend directly using this likelihood, which is publicly available1313
13
The BAO likelihood will be released publicly after the results are accepted by the journal for publication..

Table 5: Results for BAO fits to the DR14 quasar data. The fiducial $\xi$ case uses data with 8$h^{-1}$Mpc bin size and centres in the range $35<s<180h^{-1}$Mpc and the EZmock covariance matrix. For the $P$ the fiducial case uses data with linear binning of $0.01\,h{\rm Mpc}^{-1}$, in the range $0.02<k[h{\rm Mpc}^{-1}]<0.23$ and the EZmocks covariance matrix.

|  |  |  |
| --- | --- | --- |
| case | $\alpha$ | $\chi^{2}$/dof |
| DR14 Measurement $P(k)+\xi(s)$ | $0.993\pm 0.038$ | – |
| $\xi(s)$ (combined) | $0.991\pm 0.037$ | 6.2/13 |
| $P(k)$ (combined) | $0.992\pm 0.040$ | 27.7/33 |
| Robustness tests |  |  |
| $\xi(s)$: |  |  |
| fiducial | 0.996$\pm$0.039 | 8.6/13 |
| +2 | 0.996$\pm$0.041 | 6.4/13 |
| +4 | 0.984$\pm$0.033 | 3.2/13 |
| +6 | 0.993$\pm$0.035 | 6.0/13 |
| $Z\_{\rm PCA}$ (combined) | 0.979$\pm$0.039 | 11.7/13 |
| NGC | 0.975$\pm$0.054 | 9.4/13 |
| SGC | 1.014$\pm$0.057 | 18.9/13 |
| QPM cov | 0.994$\pm$0.037 | 9.6/13 |
| $\Delta s=5h^{-1}$Mpc | 0.990$\pm$0.036 | 15.6/24 |
| no $w\_{sys}$ | 0.999$\pm$0.041 | 7.4/13 |
| $50<s<150h^{-1}$Mpc | 0.997$\pm$0.042 | 7.9/8 |
| $\Sigma\_{\rm nl}=3.0h^{-1}$Mpc | 0.990$\pm$0.036 | 8.7/13 |
| $\Sigma\_{\rm nl}=9.0h^{-1}$Mpc | 1.004$\pm$0.045 | 9.6/13 |
| $A\_{n}=0$ | 1.004$\pm$0.039 | 9.5/16 |
| no $B$ prior | 0.997$\pm$0.037 | 8.8/13 |
| $P(k)$: |  |  |
| $Z\_{\rm PCA}$ (combined) | $0.980\pm 0.041$ | 28.2/33 |
| fiducial | $0.990\pm 0.041$ | 30.1/33 |
| $+1/4$ | $0.985\pm 0.037$ | 25.4/33 |
| $+2/4$ | $0.985\pm 0.038$ | 25.0/33 |
| $+3/4$ | $0.996\pm 0.042$ | 30.3/33 |
| NGC | $0.963\pm 0.052$ | 15.8/16 |
| SGC | $1.018\pm 0.060$ | 13.8/16 |
| QPM cov | $1.000\pm 0.041$ | 29.7/33 |
| log$k$ - binning | $0.997\pm 0.042$ | 31.6/39 |
| log$k$ - binning, $k\_{\rm max}=0.30\,h{\rm Mpc}^{-1}$ | $1.002\pm 0.040$ | 37.0/45 |
| no $w\_{sys}$ | $0.992\pm 0.045$ | 29.2/33 |
| $k\_{\rm max}=0.30\,h{\rm Mpc}^{-1}$ | $0.994\pm 0.040$ | 53.3/47 |
| $\Sigma\_{\rm nl}=3\,h^{-1}{\rm Mpc}$ | $0.990\pm 0.035$ | 29.6/33 |
| $\Sigma\_{\rm nl}=9\,h^{-1}{\rm Mpc}$ | $0.997\pm 0.050$ | 30.2/33 |
| $\Sigma\_{\rm nl}=[6\pm 3]\,h^{-1}{\rm Mpc}$ | $0.987\pm 0.039$ | 29.9/32 |
| $A\_{4}\,A\_{5}$ terms | $0.983\pm 0.041$ | 20.6/29 |
| no-mask | $0.988\pm 0.037$ | 28.4/33 |
|  |  |  |

Figure 13: The solid curve displays the likelihood of the BAO parameter $\alpha$, in terms of $\Delta\chi^{2}$, recovered from the spherically averaged correlation function of the DR14 quasar sample. The dashed curve displays the same information for a no BAO model, where $\Delta\chi^{2}$ is determined by subtracting the minimum $\chi^{2}$ from the BAO model. The detection significance is slightly less than $3\sigma$ and the likelihood is slightly skewed compared to the Gaussian expectation. The purple curve displays correlation function results and the burlywood curve displays the power spectrum result. The black curve is the mean of the two likelihoods, which is what we use as our final measurement.

Robustness tests for our BAO measurements are shown in the bottom rows Table [5](#S7.T5 "Table 5 ‣ 7.2 BAO Measurements ‣ 7 Results ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). We find no particular causes for concern. Importantly, switching from our fiducial choice of redshift to $Z\_{\rm PCA}$ shifts the recovered $\alpha$ by only 0.012 (less than one third $\sigma$) for both $\xi(s)$ and $P(k)$ and increases the mean of the $P(k)$ and $\xi(s)$ uncertainty from 0.038 to 0.040. These results have been combined across bin centres and can be compared directly to the DR14 results on the top lines of the table. The choice of redshift technique clearly does not have a strong impact on our results. [Zarrouk et al. (in prep.)](#bib.bib111) will examine this issue more closely in the context of RSD measurements, but we note that, e.g., we find no clear differences in the linear bias or excess large-scale clustering obtained using either redshift.

Additional robustness tests should be compared to the ‘fiducial’ results, which are the results for the fiducial choice of bin centre. The variations with bin centre for $\xi(s)$ (labeled $+x$) and $P(k)$ (labeled $+x/4$) are consistent with our findings testing our results with mocks; the mean of these four likelihoods is used as the DR14 $\xi(s)$ measurement, labeled ‘combined’ in the top rows. Additional tests produce no changes that are greater than 0.2$\sigma$ for $\xi(s)$. For $P(k)$, the greatest change is only 0.3$\sigma$ when switching to logarithmic binning and increasing $k\_{\rm max}$ to 0.3$h$Mpc-1. Finally, the results obtained from the independent NGC and SGC regions agree within 1$\sigma$, for both $\xi(s)$ and $P(k)$

The systematic weights have negligible effects on our measurements, despite their enormous (13$\sigma$) effect on the large-scale correlation function of the DR14 quasar sample. We simply recover less than a 0.1$\sigma$ shift in $\alpha$ and a 5 per cent increase in the uncertainty. The $\chi^{2}$ of the best-fit actually decreases (by 1), suggesting the effect of the depth and extinction systematics on our correlation function measurements are trivially accounted for with the polynomial terms in our BAO model.

For both $\xi(s)$ and $P(k)$, there is a slight correlation between the assumed $\Sigma\_{\rm nl}$ and the recovered $\alpha$ that is less than $\sim$0.2$\sigma$ when testing in the range $\pm 3.0h^{1}$Mpc around our fiducial choice, with a similar impact on the size of the recovered uncertainty. For $P(k)$, we are able to marginalize over this parameter in the fit (using a Gaussian prior of $\pm 3.0h^{1}$Mpc) and we recover a result that matches the fiducial result with $\Sigma\_{\rm nl}$ fixed at 6.0$h^{1}$Mpc to better than 0.1$\sigma$. Thus, not only does the choice of $\Sigma\_{\rm nl}$ have a minor effect on our analysis, our choice for its fiducial value is sufficiently close to the best-fit value as to not make a difference in our results.

Overall, the robustness tests suggest that our results are insensitive to arbitrary choices in the analysis or the way the catalog was constructed. This is consistent with [Ross et al. (2017)](#bib.bib81); [Vargas-Magaña et al. (2016)](#bib.bib101) who showed that systematic uncertainties are small compared to the BOSS DR12 statistical uncertainties. The BOSS DR12 precision is a factor of four better than our own, and thus makes these systematic uncertainties negligibly small for our analysis. A separate systematic uncertainty is the possible shift in the acoustic peak due to a coupling of the quasar density field to the small relative velocity between baryons and cold dark matter at high redshift ([Tseliakhovich & Hirata, 2010](#bib.bib100); [Dalal et al., 2010](#bib.bib29); [Yoo et al., 2011](#bib.bib108); [Slepian & Eisenstein, 2015](#bib.bib92); [Blazek et al., 2016](#bib.bib20); [Schmidt, 2016](#bib.bib87)). This has been shown to be less than 0.5 per cent for low redshift galaxies ([Yoo et al., 2013](#bib.bib109); [Beutler et al., 2016](#bib.bib15); [Slepian et al., 2016](#bib.bib94)) and we expect it to be a minor effect for quasars with $z\sim 1.5$, compared to our statistical uncertainty. Further study is warranted, especially as the statistical uncertainty will be considerably improved with future datasets.

## 8 cosmological implications

In this section, we briefly discuss the cosmological implications of our DR14 quasar BAO measurement of $D\_{V}(z=1.52)=3843\pm 147\left(r\_{\rm d}/r\_{\rm d,fid}\right)\$Mpc. We first present an updated BAO distance ladder and then demonstrate how this BAO distance ladder alone provides a powerful constraint on the geometry of the Universe.

Figure 14: Spherically averaged BAO distance measurements ($D\_{V}$) compared to the Planck $\Lambda$CDM prediction and extrapolated 68 per cent CL (grey region). The eBOSS DR14 quasar sample measurement is shown using a gold star. The additional measurements are described in the text.

Figure 15: Left: The 68 and 95% CL contour plots for $\Omega\_{\rm m}$ and $\Omega\_{\Lambda}$ using only the three sets of BAO data as illustrated in the legend. Here we assume only that the BAO scale is constant with redshift (and thus treat $r\_{\rm d}$ as a nuisance parameter we marginalized over). The dashed line illustrates a flat Universe in which $\Omega\_{\rm m}+\Omega\_{\Lambda}=1$; Right: The one-dimensional probability distribution of $\Omega\_{\Lambda}$ derived using three BAO datasets. Thus, the cosmology preferred by BAO distance scale measurements is flat $\Lambda$CDM and non-zero $\Lambda$ is preferred at 3.3$\sigma$ for the combination BOSS galaxies and our eBOSS DR14 quasar measurement and is preferred at 6.5$\sigma$ for the combination of all available BAO measurements (including BOSS Ly$\alpha$, which increases this preference the most). See text for further details.

Fig. [14](#S8.F14 "Figure 14 ‣ 8 cosmological implications ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2") displays our spherically averaged BAO measurements overplotted with the $\Lambda$CDM prediction from Planck ([Planck Collaboration et al., 2015](#bib.bib75)), compared to various similar measurements in the literature: the 6dFGS result from [Beutler et al. (2011)](#bib.bib14), the SDSS MGS result from [Ross et al. (2015)](#bib.bib80), the BOSS DR12 results from [Alam et al. (2016)](#bib.bib9), the WiggleZ results from [Kazin et al. (2014)](#bib.bib56), and the BOSS Ly$\alpha$ from the combination of the [Bautista et al. (2017)](#bib.bib13) DR12 Ly$\alpha$ auto-correlation and the [Font-Ribera et al. (2014b)](#bib.bib42) measurement using the cross-correlation of the Ly$\alpha$ forest and quasars. Our measurement is in clear agreement with the expansion history predicted by Planck and other spherically averaged BAO distance measurements.

We have projected the combined Ly$\alpha$ results onto a $D\_{V}$ measurement, which brings them into agreement with the Planck prediction. These Ly$\alpha$ measurements are in $>2\sigma$ tension when considering their sensitivity to $H(z)$ and $D\_{A}(z)$ separately. We do not attempt to perform this decomposition with the DR14 quasar sample, as its signal-to-noise ratio makes it difficult to perform this decomposition robustly with BAO-only measurements. This will be done with future eBOSS quasar studies incorporating the RSD signal or using larger data sets.

We use the BAO distance ladder to constrain the geometry of the Universe. To do so, we assume only that the BAO feature has a constant co-moving size; we assume no knowledge of the physics that produced the feature. We use an open $\Lambda$CDM cosmology, which is parametrised using three parameters,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P\equiv\{\Omega\_{\rm m},\Omega\_{\Lambda},H\_{0}r\_{\rm d}\}$ |  | (26) |

where $\Omega\_{\Lambda}$ denotes the fractional energy budget contributed by dark energy, and $H\_{0}$ the Hubble parameter. This approach matches that recently presented in [Aubourg et al. (2015)](#bib.bib12); [Bautista et al. (2017)](#bib.bib13). In this way, we are using only BAO measurements in order to test cosmology. We defer further study of the cosmological constraints afforded by our eBOSS DR14 quasar BAO measurement in combination with non-BAO data to future studies.

To obtain the constraint on $\Omega\_{\rm m}$ and $\Omega\_{\Lambda}$, which quantifies the cosmic geometry at the present epoch, we perform a Monte Carlo Markov Chain (MCMC) fitting using a modified version of CosmoMC ([Lewis & Bridle, 2002](#bib.bib63)), and marginalise over $H\_{0}r\_{\rm d}$. The datasets we use are as follows,

* •

  BOSS galaxies: The anisotropic BAO measurement from BOSS DR12 presented in [Alam et al. (2016)](#bib.bib9);
* •

  BOSS galaxies+eBOSS: The isotropic BAO measurement $D\_{V}(z=1.52)=3843\pm 147\left(r\_{\rm d}/r\_{\rm d,fid}\right)\$Mpc determined in this work combined with the BOSS DR12 BAO measurement;
* •

  Full BAO: BOSS galaxies+eBOSS combined with the anisotropic BAO measurement from the DR11 Lyman-$\alpha$ cross-correlation sample ([Font-Ribera et al., 2014b](#bib.bib42)) and the DR12 auto-correlation sample [Bautista et al. (2017)](#bib.bib13), and the isotropic BAO measurements using MGS ([Ross et al., 2015](#bib.bib80)) and 6dFGRS ([Beutler et al., 2011](#bib.bib14)) galaxy samples.

The 68 & 95% CL joint constraint on $\Omega\_{\rm m}$ and $\Omega\_{\Lambda}$, and the one-dimensional probability distribution of $\Omega\_{\Lambda}$, are shown in Fig [15](#S8.F15 "Figure 15 ‣ 8 cosmological implications ‣ The clustering of the SDSS-IV extended Baryon Oscillation Spectroscopic Survey DR14 quasar sample: First measurement of Baryon Acoustic Oscillations between redshift 0.8 and 2.2"). The quasar BAO measurement in this work significantly improves the constraint, i.e.,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{\rm FoM\_{\rm BOSS+eBOSS}}{\rm FoM\_{\rm BOSS}}=2.0$ |  | (27) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\rm FoM}\propto 1/\sqrt{\rm det\ Cov(\Omega\_{\rm m},\Omega\_{\Lambda})}$ |  | (28) |

denotes the Figure of Merit (FoM) of the geometric constraint of the Universe. The significance of $\Omega\_{\Lambda}>0$, in other words, the existence of dark energy, is raised from $2.9\sigma$ to $3.4\sigma$ CL when the eBOSS quasar BAO is added to BOSS galaxies. Despite its relative lack in precision, the eBOSS DR14 quasar BAO measurement is able to provide a significant improvement over the BOSS galaxy BAO measurements alone as it provides a high-redshift constraint. Importantly, using all BAO measurements to date (the Full BAO) sample, we reach a $6.6\sigma$ detection of dark energy using BAO alone; this considerable improvement is mainly provided by the higher redshift and more precise BOSS Ly$\alpha$ measurements discussed earlier in this section1414
14
The DR14 measurement does not provide a significant improvement over what is achieved without it but with Ly$\alpha$; c.f. [Bautista et al. (2017)](#bib.bib13).. Finally, all variations of the data set tested are in full agreement with a flat geometry.

BAO distance measurements continue to be in broad agreement with the flat $\Lambda$CDM model and the best-fit parameters from the Planck mission ([Planck Collaboration et al., 2015](#bib.bib75)) assuming this model.

## 9 Conclusions

We have used a sample of 147,000 quasars distributed over more than 2000 deg2 in order to obtain the spherically-averaged BAO measurement $D\_{V}(z=1.52)=3843\pm 147\left(r\_{\rm d}/r\_{\rm d,fid}\right)\$Mpc. We have demonstrated this measurement is robust against a variety of methodological and observational concerns and choices, once again demonstrating BAO distance measurements to be one of the most robust observational probes of dark energy (as shown/discussed previously in, e.g., [Ross et al. 2012](#bib.bib79); [Weinberg et al. 2013](#bib.bib104); [Ross et al. 2017](#bib.bib81); [Vargas-Magaña et al. 2016](#bib.bib101)).

These results demonstrate that the BAO signal in the distribution of quasars is consistent with expectations of basic LSS predictions. The clustering we measure and its BAO signal are consistent with that in our mock realizations. While the formation and evolution of quasars remains an active research field, they are clearly not so exotic as to greatly disturb the BAO signal.

We combine our result with previous, independent, BAO distance measurements to construct an updated BAO distance-ladder. Using these BAO data alone, we tested a $\Lambda$CDM model with free curvature, assuming only that the acoustic scale has a fixed comoving size. We found $\Omega\_{\Lambda}>0$ at 6.6$\sigma$ significance. Considering only BOSS galaxy and eBOSS quasar results, the significance remained greater than 3$\sigma$. All of our results are fully consistent with a flat geometry. BAO distance measurements, now across a broad range of redshifts, are in clear agreement with the flat $\Lambda$CDM cosmological paradigm.

This work represents the first cosmological analysis to be done with eBOSS quasar data. We expect numerous studies to follow, both with this catalog and with future, larger data sets. In particular, given the wide redshift coverage of the eBOSS quasar sample, there is potentially ample tomographic information along the radial direction. This aspect is crucial to reconstruct the history of the cosmic expansion and structure growth, which is key for the probe of dynamical dark energy ([Wang et al., 2016](#bib.bib102); [Zhao et al., 2017a](#bib.bib113); [Zhao et al., 2017b](#bib.bib114)), modified gravity, and neutrino masses. We expect our DR14 results can be extended through the use of more optimal redshift-weighting methods for the BAO (e.g., [Zhu et al. 2016](#bib.bib115); [Wang et al. in prep.](#bib.bib103)), redshift-space distortion (RSD) analyses, or their combination ([Ruggeri et al., 2017](#bib.bib83)). Additional BAO information can be extracted from higher-order statistics ([Slepian et al., 2016](#bib.bib93)). Further, we anticipate the enormous volume probed by the entire eBOSS quasar sample will afford a precise measurement the signature of primordial non-Gaussianity. The final eBOSS quasar sample is expected to have approximately three times the volume of the DR14 sample, and will thus provide exciting improvements in the statistical precision of our BAO measurement, even without the expected methodological improvements.

The direct use of quasars as a tracer represents only one facet of the eBOSS program. Separate analyses of the eBOSS luminous red galaxy (LRG) and emission line galaxy (ELG) samples will measure BAO and RSD signal at redshift $z\sim$0.8, thereby filling the gap in redshift between BOSS galaxies and eBOSS quasars. Lyman$\alpha$ forest studies using eBOSS observations of quasars at $z>2.2$ will improve BAO measurements at $z\sim 2.3$. Upcoming galaxy spectroscopic surveys will provide unprecedented precision; these include the Hobby-Eberly Telescope Dark Energy Experiment (HETDEX; [Hill et al. 2008](#bib.bib49))1515
15
<http://hetdex.org/>, Dark Energy Spectroscopic Instrument (DESI [DESI Collaboration et al. 2016a](#bib.bib5); [DESI Collaboration et al. 2016b](#bib.bib6))1616
16
<http://desi.lbl.gov/>, Prime Focus Spectrograph (PFS; [Tamura et al. 2016](#bib.bib98))1717
17
<http://pfs.ipmu.jp/> and the Euclid satellite mission ([Amendola et al., 2013](#bib.bib4))1818
18
<https://www.cosmos.esa.int/web/euclid/>. These surveys will probe the Universe using multiple tracers including quasars, ELGs and LRGs. The work we have presented, and eBOSS studies in general, represent an exciting first step in obtaining a densely sampled BAO distance ladder to $z<3$.

## acknowledgements

We thank the anonymous referee for comments that helped improve this paper.

AJR is grateful for support from the Ohio State University Center for Cosmology and ParticlePhysics.

HGM acknowledges support from the Labex ILP (reference ANR-10-LABX-63) part of the Idex SUPER, and received financial state aid managed by the Agence Nationale
de la Recherche, as part of the programme Investissements d’avenir under the reference ANR-11-IDEX-0004-02.

GBZ is supported by NSFC Grant No. 11673025, and by a Royal Society Newton Advanced Fellowship.

RT acknowledges support from the Science and Technology Facilities Council via an Ernest Rutherford Fellowship (grant number ST/K004719/1)

CHC is grateful for support from Leibniz-Institut für Astrophysik Potsdam (AIP).

EB and PZ acknowledge support from the P2IO LabEx (ANR-10-LABX-0038).

JLT acknowledges support from National Science Foundation grant AST-1615997

YW is supported by the NSFC Grant No. 11403034

WJP acknowledges support from the UK Space Agency through grant ST/K00283X/1, and WJP acknowledges support from the European Research Council through grant Darksurvey, and the UK Science & Technology Facilities Council through the consolidated grant ST/K0090X/1.

ADM was partially supported by the NSF through grant numbers 1515404 and 1616168.

IP acknowledges the support of the OCEVU Labex (ANR-11-LABX-0060) and the A\*MIDEX project (ANR-11-IDEX-0001-02) funded by the “Investissements d’Avenir” French government program managed by the AN

JPK acknowledges support from the ERC advanced grant LIDA.

GR acknowledges support from the National Research Foundation of Korea (NRF) through NRF-SGER 2014055950 funded by the Korean Ministry of Education,
Science and Technology (MoEST), and from the faculty research fund of Sejong University in 2016.

Colours made possible by
<http://matplotlib.org/examples/color/named_colors.html>; figures made colourblind-friendly (hopefully) by use of Color Oracle software.

Funding for SDSS-III and SDSS-IV has been provided by
the Alfred P. Sloan Foundation and Participating Institutions.
Additional funding for SDSS-III comes from the
National Science Foundation and the U.S. Department of Energy Office of Science. Further information about
both projects is available at [www.sdss.org](https://www.sdss.org).
SDSS is managed by the Astrophysical Research Consortium
for the Participating Institutions in both collaborations.
In SDSS-III these include the University of
Arizona, the Brazilian Participation Group, Brookhaven
National Laboratory, Carnegie Mellon University, University
of Florida, the French Participation Group, the German Participation Group, Harvard University,
the Instituto de Astrofisica de Canarias, the Michigan
State / Notre Dame / JINA Participation Group, Johns
Hopkins University, Lawrence Berkeley National Laboratory,
Max Planck Institute for Astrophysics, Max Planck
Institute for Extraterrestrial Physics, New Mexico State
University, New York University, Ohio State University,
Pennsylvania State University, University of Portsmouth,
Princeton University, the Spanish Participation Group,
University of Tokyo, University of Utah, Vanderbilt University,
University of Virginia, University of Washington,
and Yale University.

The Participating Institutions in SDSS-IV are
Carnegie Mellon University, Colorado University, Boulder,
Harvard-Smithsonian Center for Astrophysics Participation
Group, Johns Hopkins University, Kavli Institute
for the Physics and Mathematics of the Universe
Max-Planck-Institut fuer Astrophysik (MPA Garching),
Max-Planck-Institut fuer Extraterrestrische Physik
(MPE), Max-Planck-Institut fuer Astronomie (MPIA
Heidelberg), National Astronomical Observatories of
China, New Mexico State University, New York University,
The Ohio State University, Penn State University,
Shanghai Astronomical Observatory, United Kingdom
Participation Group, University of Portsmouth, University
of Utah, University of Wisconsin, and Yale University.

This work made use of the facilities and staff of the UK Sciama High Performance Computing cluster supported by the ICG, SEPNet and the University of Portsmouth.
This research used resources of the National Energy Research
Scientific Computing Center, a DOE Office of Science User Facility
supported by the Office of Science of the U.S. Department of Energy
under Contract No. DE-AC02-05CH11231.
