<!-- fulltext source=arxiv_html slug=arXiv-1502.01591 fetched=2026-09-18T01:16:44+00:00 -->

# Planck 2015 results. XV. Gravitational lensing

Planck Collaboration: P. A. R. Ade
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
N. Aghanim
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
M. Arnaud
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
M. Ashdown
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
J. Aumont
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
C. Baccigalupi
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
A. J. Banday
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
R. B. Barreiro
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
J. G. Bartlett
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
N. Bartolo
Affiliation: Dipartimento di Fisica e Astronomia G. Galilei, Università degli Studi di Padova, via Marzolo 8, 35131 Padova, Italy
Affiliation: Istituto Nazionale di Fisica Nucleare, Sezione di Padova, via Marzolo 8, I-35131 Padova, Italy
  
S. Basak
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
E. Battaner
Affiliation: University of Granada, Departamento de Física Teórica y del Cosmos, Facultad de Ciencias, Granada, Spain
Affiliation: University of Granada, Instituto Carlos I de Física Teórica y Computacional, Granada, Spain
  
K. Benabed
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
A. Benoît
Affiliation: Institut Néel, CNRS, Université Joseph Fourier Grenoble I, 25 rue des Martyrs, Grenoble, France
  
A. Benoit-Lévy
Affiliation: Department of Physics and Astronomy, University College London, London WC1E 6BT, U.K.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
J.-P. Bernard
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
M. Bersanelli
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
P. Bielewicz
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Nicolaus Copernicus Astronomical Center, Bartycka 18, 00-716 Warsaw, Poland
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
J. J. Bock
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
A. Bonaldi
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
L. Bonavera
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
J. R. Bond
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
  
J. Borrill
Affiliation: Computational Cosmology Center, Lawrence Berkeley National Laboratory, Berkeley, California, U.S.A.
Affiliation: Space Sciences Laboratory, University of California, Berkeley, California, U.S.A.
  
F. R. Bouchet
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: Sorbonne Université-UPMC, UMR7095, Institut d’Astrophysique de Paris, 98 bis Boulevard Arago, F-75014, Paris, France
  
F. Boulanger
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
M. Bucher
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
C. Burigana
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: INFN, Sezione di Bologna, Via Irnerio 46, I-40126, Bologna, Italy
  
R. C. Butler
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
E. Calabrese
Affiliation: Sub-Department of Astrophysics, University of Oxford, Keble Road, Oxford OX1 3RH, U.K.
  
J.-F. Cardoso
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: Laboratoire Traitement et Communication de l’Information, CNRS (UMR 5141) and Télécom ParisTech, 46 rue Barrault F-75634 Paris Cedex 13, France
  
A. Catalano
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
A. Challinor
Affiliation: Centre for Theoretical Cosmology, DAMTP, University of Cambridge, Wilberforce Road, Cambridge CB3 0WA, U.K.
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
A. Chamballu
Affiliation: DSM/Irfu/SPP, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
H. C. Chiang
Affiliation: Astrophysics & Cosmology Research Unit, School of Mathematics, Statistics & Computer Science, University of KwaZulu-Natal, Westville Campus, Private Bag X54001, Durban 4000, South Africa
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
P. R. Christensen
Affiliation: Discovery Center, Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
Affiliation: Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
  
S. Church
Affiliation: Stanford University, Dept of Physics, Varian Physics Bldg, 382 Via Pueblo Mall, Stanford, California, U.S.A.
  
D. L. Clements
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
S. Colombi
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
L. P. L. Colombo
Affiliation: Department of Physics and Astronomy, Dana and David Dornsife College of Letter, Arts and Sciences, University of Southern California, Los Angeles, CA 90089, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
C. Combet
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
F. Couchot
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
A. Coulais
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
B. P. Crill
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
A. Curto
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
F. Cuttaia
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
L. Danese
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
R. D. Davies
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
R. J. Davis
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
P. de Bernardis
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
A. de Rosa
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
G. de Zotti
Affiliation: INAF - Osservatorio Astronomico di Padova, Vicolo dell’Osservatorio 5, Padova, Italy
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
J. Delabrouille
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
F.-X. Désert
Affiliation: IPAG: Institut de Planétologie et d’Astrophysique de Grenoble, Université Grenoble Alpes, IPAG, F-38000 Grenoble, France, CNRS, IPAG, F-38000 Grenoble, France
  
J. M. Diego
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
H. Dole
Affiliation: Institut Universitaire de France, 103, bd Saint-Michel, 75005, Paris, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
S. Donzelli
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
O. Doré
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
M. Douspis
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
A. Ducout
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
  
J. Dunkley
Affiliation: Sub-Department of Astrophysics, University of Oxford, Keble Road, Oxford OX1 3RH, U.K.
  
X. Dupac
Affiliation: European Space Agency, ESAC, Planck Science Office, Camino bajo del Castillo, s/n, Urbanización Villafranca del Castillo, Villanueva de la Cañada, Madrid, Spain
  
G. Efstathiou
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
  
F. Elsner
Affiliation: Department of Physics and Astronomy, University College London, London WC1E 6BT, U.K.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
T. A. Enßlin
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
H. K. Eriksen
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
J. Fergusson
Affiliation: Centre for Theoretical Cosmology, DAMTP, University of Cambridge, Wilberforce Road, Cambridge CB3 0WA, U.K.
  
F. Finelli
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: INFN, Sezione di Bologna, Via Irnerio 46, I-40126, Bologna, Italy
  
O. Forni
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
M. Frailis
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
A. A. Fraisse
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
E. Franceschi
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
A. Frejsel
Affiliation: Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
  
S. Galeotta
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
S. Galli
Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, Chicago, IL 60637, USA
  
K. Ganga
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
M. Giard
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
Y. Giraud-Héraud
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
E. Gjerløw
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
J. González-Nuevo
Affiliation: Departamento de Física, Universidad de Oviedo, Avda. Calvo Sotelo s/n, Oviedo, Spain
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
K. M. Górski
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
Affiliation: Warsaw University Observatory, Aleje Ujazdowskie 4, 00-478 Warszawa, Poland
  
S. Gratton
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
A. Gregorio
Affiliation: Dipartimento di Fisica, Università degli Studi di Trieste, via A. Valerio 2, Trieste, Italy
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
Affiliation: INFN/National Institute for Nuclear Physics, Via Valerio 2, I-34127 Trieste, Italy
  
A. Gruppuso
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
J. E. Gudmundsson
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
Affiliation: Nordita (Nordic Institute for Theoretical Physics), Roslagstullsbacken 23, SE-106 91 Stockholm, Sweden
Affiliation: The Oskar Klein Centre for Cosmoparticle Physics, Department of Physics,Stockholm University, AlbaNova, SE-106 91 Stockholm, Sweden
  
F. K. Hansen
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
D. Hanson
††thanks: Corresponding author: D.˜Hanson [duncan.hanson@gmail.com](mailto:duncan.hanson@gmail.com)
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
Affiliation: McGill Physics, Ernest Rutherford Physics Building, McGill University, 3600 rue University, Montréal, QC, H3A 2T8, Canada
  
D. L. Harrison
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
S. Henrot-Versillé
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
C. Hernández-Monteagudo
Affiliation: Centro de Estudios de Física del Cosmos de Aragón (CEFCA), Plaza San Juan, 1, planta 2, E-44001, Teruel, Spain
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
D. Herranz
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
S. R. Hildebrandt
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
E. Hivon
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
M. Hobson
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
  
W. A. Holmes
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
A. Hornstrup
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
W. Hovest
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
K. M. Huffenberger
Affiliation: Department of Physics, Florida State University, Keen Physics Building, 77 Chieftan Way, Tallahassee, Florida, U.S.A.
  
G. Hurier
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
A. H. Jaffe
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
T. R. Jaffe
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
W. C. Jones
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
M. Juvela
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
  
E. Keihänen
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
  
R. Keskitalo
Affiliation: Computational Cosmology Center, Lawrence Berkeley National Laboratory, Berkeley, California, U.S.A.
  
T. S. Kisner
Affiliation: Lawrence Berkeley National Laboratory, Berkeley, California, U.S.A.
  
R. Kneissl
Affiliation: Atacama Large Millimeter/submillimeter Array, ALMA Santiago Central Offices, Alonso de Cordova 3107, Vitacura, Casilla 763 0355, Santiago, Chile
Affiliation: European Southern Observatory, ESO Vitacura, Alonso de Cordova 3107, Vitacura, Casilla 19001, Santiago, Chile
  
J. Knoche
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
M. Kunz
Affiliation: African Institute for Mathematical Sciences, 6-8 Melrose Road, Muizenberg, Cape Town, South Africa
Affiliation: Département de Physique Théorique, Université de Genève, 24, Quai E. Ansermet,1211 Genève 4, Switzerland
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
H. Kurki-Suonio
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
G. Lagache
Affiliation: Aix Marseille Université, CNRS, LAM (Laboratoire d’Astrophysique de Marseille) UMR 7326, 13388, Marseille, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
A. Lähteenmäki
Affiliation: Aalto University Metsähovi Radio Observatory and Dept of Radio Science and Engineering, P.O. Box 13000, FI-00076 AALTO, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
J.-M. Lamarre
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
A. Lasenby
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
M. Lattanzi
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
  
C. R. Lawrence
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
R. Leonardi
Affiliation: CGEE, SCS Qd 9, Lote C, Torre C, 4∘ andar, Ed. Parque Cidade Corporate, CEP 70308-200, Brasília, DF,Ê Brazil
  
J. Lesgourgues
Affiliation: Institut für Theoretische Teilchenphysik und Kosmologie, RWTH Aachen University, D-52056 Aachen, Germany
Affiliation: Theory Division, PH-TH, CERN, CH-1211, Geneva 23, Switzerland
  
F. Levrier
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
A. Lewis
Affiliation: Department of Physics and Astronomy, University of Sussex, Brighton BN1 9QH, U.K.
  
M. Liguori
Affiliation: Dipartimento di Fisica e Astronomia G. Galilei, Università degli Studi di Padova, via Marzolo 8, 35131 Padova, Italy
Affiliation: Istituto Nazionale di Fisica Nucleare, Sezione di Padova, via Marzolo 8, I-35131 Padova, Italy
  
P. B. Lilje
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
M. Linden-Vørnle
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
M. López-Caniego
Affiliation: European Space Agency, ESAC, Planck Science Office, Camino bajo del Castillo, s/n, Urbanización Villafranca del Castillo, Villanueva de la Cañada, Madrid, Spain
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
P. M. Lubin
Affiliation: Department of Physics, University of California, Santa Barbara, California, U.S.A.
  
J. F. Macías-Pérez
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
G. Maggio
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
D. Maino
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
N. Mandolesi
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
A. Mangilli
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
M. Maris
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
P. G. Martin
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
  
E. Martínez-González
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
S. Masi
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
S. Matarrese
Affiliation: Dipartimento di Fisica e Astronomia G. Galilei, Università degli Studi di Padova, via Marzolo 8, 35131 Padova, Italy
Affiliation: Gran Sasso Science Institute, INFN, viale F. Crispi 7, 67100 L’Aquila, Italy
Affiliation: Istituto Nazionale di Fisica Nucleare, Sezione di Padova, via Marzolo 8, I-35131 Padova, Italy
  
P. McGehee
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
P. R. Meinhold
Affiliation: Department of Physics, University of California, Santa Barbara, California, U.S.A.
  
A. Melchiorri
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
Affiliation: INFN, Sezione di Roma 1, Università di Roma Sapienza, Piazzale Aldo Moro 2, 00185, Roma, Italy
  
L. Mendes
Affiliation: European Space Agency, ESAC, Planck Science Office, Camino bajo del Castillo, s/n, Urbanización Villafranca del Castillo, Villanueva de la Cañada, Madrid, Spain
  
A. Mennella
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
M. Migliaccio
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
S. Mitra
Affiliation: IUCAA, Post Bag 4, Ganeshkhind, Pune University Campus, Pune 411 007, India
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
M.-A. Miville-Deschênes
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
A. Moneti
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
  
L. Montier
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
G. Morgante
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
D. Mortlock
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
A. Moss
Affiliation: School of Physics and Astronomy, University of Nottingham, Nottingham NG7 2RD, U.K.
  
D. Munshi
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
J. A. Murphy
Affiliation: National University of Ireland, Department of Experimental Physics, Maynooth, Co. Kildare, Ireland
  
P. Naselsky
Affiliation: Discovery Center, Niels Bohr Institute, Copenhagen University, Blegdamsvej 17, Copenhagen, Denmark
Affiliation: Niels Bohr Institute, Copenhagen University, Blegdamsvej 17, Copenhagen, Denmark
  
F. Nati
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
P. Natoli
Affiliation: Agenzia Spaziale Italiana Science Data Center, Via del Politecnico snc, 00133, Roma, Italy
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
C. B. Netterfield
Affiliation: Department of Astronomy and Astrophysics, University of Toronto, 50 Saint George Street, Toronto, Ontario, Canada
  
H. U. Nørgaard-Nielsen
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
F. Noviello
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
D. Novikov
Affiliation: Lebedev Physical Institute of the Russian Academy of Sciences, Astro Space Centre, 84/32 Profsoyuznaya st., Moscow, GSP-7, 117997, Russia
  
I. Novikov
Affiliation: Lebedev Physical Institute of the Russian Academy of Sciences, Astro Space Centre, 84/32 Profsoyuznaya st., Moscow, GSP-7, 117997, Russia
Affiliation: Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
  
C. A. Oxborrow
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
F. Paci
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
L. Pagano
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
Affiliation: INFN, Sezione di Roma 1, Università di Roma Sapienza, Piazzale Aldo Moro 2, 00185, Roma, Italy
  
F. Pajot
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
D. Paoletti
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: INFN, Sezione di Bologna, Via Irnerio 46, I-40126, Bologna, Italy
  
F. Pasian
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
G. Patanchon
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
O. Perdereau
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
L. Perotto
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
F. Perrotta
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
V. Pettorino
Affiliation: HGSFP and University of Heidelberg, Theoretical Physics Department, Philosophenweg 16, 69120, Heidelberg, Germany
  
F. Piacentini
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
M. Piat
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
E. Pierpaoli
Affiliation: Department of Physics and Astronomy, Dana and David Dornsife College of Letter, Arts and Sciences, University of Southern California, Los Angeles, CA 90089, U.S.A.
  
D. Pietrobon
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
S. Plaszczynski
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
E. Pointecouteau
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
G. Polenta
Affiliation: Agenzia Spaziale Italiana Science Data Center, Via del Politecnico snc, 00133, Roma, Italy
Affiliation: INAF - Osservatorio Astronomico di Roma, via di Frascati 33, Monte Porzio Catone, Italy
  
L. Popa
Affiliation: Institute for Space Sciences, Bucharest-Magurale, Romania
  
G. W. Pratt
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
G. Prézeau
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
S. Prunet
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
J.-L. Puget
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
  
J. P. Rachen
Affiliation: Department of Astrophysics/IMAPP, Radboud University Nijmegen, P.O. Box 9010, 6500 GL Nijmegen, The Netherlands
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
W. T. Reach
Affiliation: Universities Space Research Association, Stratospheric Observatory for Infrared Astronomy, MS 232-11, Moffett Field, CA 94035, U.S.A.
  
R. Rebolo
Affiliation: Consejo Superior de Investigaciones Científicas (CSIC), Madrid, Spain
Affiliation: Departamento de Astrofísica, Universidad de La Laguna (ULL), E-38206 La Laguna, Tenerife, Spain
Affiliation: Instituto de Astrofísica de Canarias, C/Vía Láctea s/n, La Laguna, Tenerife, Spain
  
M. Reinecke
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
M. Remazeilles
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS (UMR8617) Université Paris-Sud 11, Bâtiment 121, Orsay, France
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
C. Renault
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
A. Renzi
Affiliation: Dipartimento di Matematica, Università di Roma Tor Vergata, Via della Ricerca Scientifica, 1, Roma, Italy
Affiliation: INFN, Sezione di Roma 2, Università di Roma Tor Vergata, Via della Ricerca Scientifica, 1, Roma, Italy
  
I. Ristorcelli
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
G. Rocha
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
C. Rosset
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
M. Rossetti
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
G. Roudier
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
M. Rowan-Robinson
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
J. A. Rubiño-Martín
Affiliation: Departamento de Astrofísica, Universidad de La Laguna (ULL), E-38206 La Laguna, Tenerife, Spain
Affiliation: Instituto de Astrofísica de Canarias, C/Vía Láctea s/n, La Laguna, Tenerife, Spain
  
B. Rusholme
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
M. Sandri
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
D. Santos
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
M. Savelainen
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
G. Savini
Affiliation: Optical Science Laboratory, University College London, Gower Street, London, U.K.
  
D. Scott
Affiliation: Department of Physics & Astronomy, University of British Columbia, 6224 Agricultural Road, Vancouver, British Columbia, Canada
  
M. D. Seiffert
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
E. P. S. Shellard
Affiliation: Centre for Theoretical Cosmology, DAMTP, University of Cambridge, Wilberforce Road, Cambridge CB3 0WA, U.K.
  
L. D. Spencer
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
V. Stolyarov
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Kazan Federal University, 18 Kremlyovskaya St., Kazan, 420008, Russia
Affiliation: Special Astrophysical Observatory, Russian Academy of Sciences, Nizhnij Arkhyz, Zelenchukskiy region, Karachai-Cherkessian Republic, 369167, Russia
  
R. Stompor
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
R. Sudiwala
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
R. Sunyaev
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
Affiliation: Space Research Institute (IKI), Russian Academy of Sciences, Profsoyuznaya Str, 84/32, Moscow, 117997, Russia
  
D. Sutton
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
A.-S. Suur-Uski
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
J.-F. Sygnet
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
  
J. A. Tauber
Affiliation: European Space Agency, ESTEC, Keplerlaan 1, 2201 AZ Noordwijk, The Netherlands
  
L. Terenzi
Affiliation: Facoltà di Ingegneria, Università degli Studi e-Campus, Via Isimbardi 10, Novedrate (CO), 22060, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
L. Toffolatti
Affiliation: Departamento de Física, Universidad de Oviedo, Avda. Calvo Sotelo s/n, Oviedo, Spain
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
M. Tomasi
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
M. Tristram
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
M. Tucci
Affiliation: Département de Physique Théorique, Université de Genève, 24, Quai E. Ansermet,1211 Genève 4, Switzerland
  
J. Tuovinen
Affiliation: CRANN, Trinity College, Dublin, Ireland
  
L. Valenziano
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
J. Valiviita
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
B. Van Tent
Affiliation: Laboratoire de Physique Théorique, Université Paris-Sud 11 & CNRS, Bâtiment 210, 91405 Orsay, France
  
P. Vielva
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
F. Villa
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
L. A. Wade
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
B. D. Wandelt
Affiliation: Department of Physics, University of Illinois at Urbana-Champaign, 1110 West Green Street, Urbana, Illinois, U.S.A.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
I. K. Wehus
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
M. White
Affiliation: Department of Physics, University of California, Berkeley, California, U.S.A.
  
D. Yvon
Affiliation: DSM/Irfu/SPP, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
A. Zacchei
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
A. Zonca
Affiliation: Department of Physics, University of California, Santa Barbara, California, U.S.A.

Draft compiled August 24, 2026

We present the most significant measurement of the cosmic microwave background (CMB) lensing potential to date (at a level of $40\thinspace\sigma$),
using temperature and polarization data from the Planck 2015 full-mission release.
Using a polarization-only estimator, we detect lensing at a significance of $5\thinspace\sigma$.
We cross-check the accuracy of our measurement using the wide frequency coverage
and complementarity of the temperature and polarization measurements.
Public products based on this measurement include an estimate of the lensing potential
over approximately
$70\thinspace\%$
of the sky, an estimate of the lensing potential power spectrum in bandpowers for the
multipole range
$40\!\leq\!L\!\leq\!400$,
and an associated likelihood for cosmological parameter constraints.
We find good agreement between our measurement of the lensing potential
power spectrum and that found in the $\Lambda$CDM model that best fits the Planck temperature and polarization power spectra.
Using the lensing likelihood alone we obtain a percent-level measurement of the parameter combination
$\sigma\_{8}\Omega\_{\rm m}^{0.25}=0.591\pm 0.021$.
We combine our determination of the lensing potential with the $E$-mode polarization, also measured by Planck, to generate an estimate of the lensing $B$-mode.
We show that this lensing $B$-mode estimate is correlated with the $B$-modes observed directly by Planck at the expected level and with a statistical significance of $10\thinspace\sigma$, confirming Planck’s sensitivity to this known sky signal.
We also correlate our lensing potential estimate with the large-scale
temperature anisotropies, detecting a cross-correlation at the
$3\thinspace\sigma$ level, as expected because of dark energy in the concordance $\Lambda$CDM model.

## 1 Introduction

The cosmic microwave background (CMB) gives us a direct measurement of the early Universe when it first became
transparent to radiation just
$375\thinspace 000$
years after the Big Bang.
It contains distinct signatures of the later Universe as well, which
were imprinted by the process of gravitational lensing.
The CMB photons that we observe today last scattered approximately 14 billion years ago,
and have travelled most of the way across the observable Universe to reach us.
During their journey, their paths were distorted by the gravitational tug of intervening matter,
a subtle effect that may be measured statistically with high angular resolution, low-noise observations of the CMB, such as those provided by Planck.
In this paper, we present lensing measurements that are based on the full-mission 2015 data release.
We produce the most powerful measurement of CMB lensing to date with a
$2.5\thinspace\%$
constraint on the amplitude of the lensing potential power spectrum
(or alternatively, a $40\thinspace\sigma$ detection of lensing effects).

The effect of lensing is to remap the CMB fluctuations,
so that the observed anisotropy in direction $\hat{\mathbf{n}}$ is in fact the unlensed,
‘primordial’ anisotropy in the direction $\hat{\mathbf{n}}+\nabla\phi(\hat{\mathbf{n}})$,
where $\phi(\hat{\mathbf{n}})$ is the CMB lensing potential defined by (e.g. [Lewis & Challinor 2006](#bib.bib27))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\phi(\hat{\mathbf{n}})=-2\int\_{0}^{\chi\_{\*}}d\chi\frac{f\_{K}(\chi\_{\*}-\chi)}{f\_{K}(\chi\_{\*})f\_{K}(\chi)}\Psi(\chi\hat{\mathbf{n}};\eta\_{0}-\chi).$ |  | (1) |

Here, $\chi$ is conformal distance (with $\chi\_{\*}\approx 14\thinspace 000\thinspace\mathrm{Mpc}$ denoting the distance to the CMB last-scattering surface).
The angular-diameter distance $f\_{K}(\chi)$ depends on the curvature of the Universe, and is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\_{K}(\chi)=\begin{cases}K^{-1/2}\sin(K^{1/2}\chi)&\text{for $K>0$ (closed)},\\ \chi&\text{for $K=0$ (flat)},\\ |K|^{-1/2}\sinh(|K|^{1/2}\chi)&\text{for $K<0$ (open)}.\\ \end{cases}$ |  | (2) |

Finally, $\Psi(\chi\hat{\mathbf{n}};\eta)$ is the (Weyl) gravitational potential at conformal distance $\chi$ along the direction $\hat{\mathbf{n}}$ at conformal time $\eta$ (the conformal time today is denoted as $\eta\_{0}$).
The lensing potential is an integrated measure of the mass distribution back to the last-scattering surface.
The power spectrum of the lensing potential probes the matter power spectrum, which is sensitive to ‘late-time’ parameters that modify the growth of structure such as neutrino mass ([Smith et al. 2009](#bib.bib55)).
The amplitude of lensing effects is also a sensitive probe of geometrical parameters, such as the curvature of the Universe.

The lens-induced remapping imprints distinctive statistical signatures onto the observed CMB fluctuations,
which can be mined for cosmological information in a process known as lens reconstruction ([Okamoto & Hu 2003](#bib.bib33)).
The past several years have been seen dramatic improvements in CMB lensing measurements,
moving from first detections in cross-correlation
([Smith et al. 2007](#bib.bib56); [Hirata et al. 2008](#bib.bib20)) to cosmologically useful measurements of the lensing potential power spectrum
([Das et al. 2011](#bib.bib8); [van Engelen et al. 2012](#bib.bib59); [Planck Collaboration
XVII 2014](#bib.bib37)).
Recently, ground-based experiments have been able to detect the effects of lensing in
polarization data as well ([Hanson et al. 2013](#bib.bib18); [POLARBEAR Collaboration 2014a](#bib.bib49); [POLARBEAR Collaboration 2014b](#bib.bib50); [van Engelen et al. 2015](#bib.bib60)).

The results in this paper extend our earlier results in
[Planck Collaboration
XVII (2014)](#bib.bib37). These were based on the
March 2013 Planck∗
∗\*∗
∗\*
$\*$
Planck (<http://www.esa.int/Planck>) is a project of the European Space Agency (ESA) with instruments provided by two scientific consortia funded by ESA member states and led by Principal Investigators from France and Italy, telescope reflectors provided through a collaboration between ESA and a scientific consortium led and funded by Denmark, and additional contributions from NASA (USA).
nominal-mission data release, which contains approximately 15 months of temperature data alone.
The additional information in the full-mission dataset, with 30 months of Planck HFI temperature and polarization data ([Planck Collaboration
VII 2016](#bib.bib41); [Planck Collaboration
VIII 2016](#bib.bib42)), allows us to improve our reconstruction noise levels by roughly a factor of two.
Approximately half of this improvement comes from lower noise levels in temperature, and the other half from inclusion of polarization data.
The improved lensing map is included as part of the Planck 2015 public data release ([Planck Collaboration
I 2016](#bib.bib40)),
as well as an estimate of the lensing potential power spectrum and associated likelihoods.
In this paper we describe the creation of these products, as well as first science results based on them. We highlight the following science results.

* $\bullet$

  We detect lensing $B$-modes in the Planck data at a significance of $10\thinspace\sigma$,
  using both a cross-correlation approach with the cosmic infrared background (CIB) as a tracer of the lensing potential,
  as well as a CMB-only approach using the $TTEB$ trispectrum.
  This provides an important confirmation that Planck is sensitive to this known source of $B$-modes on intermediate and small scales.
* $\bullet$

  We make an improved measurement of the 3-point function
  (bispectrum) that is induced in the CMB by the correlation between
  lensing and the integrated Sachs-Wolfe (ISW) effect, the latter being sourced by late-time acceleration. The lensing-ISW bispectrum is now detected at the $3\thinspace\sigma$ level.
* $\bullet$

  Using only lensing information (along with well-motivated priors),
  we constrain the parameter combination $\sigma\_{8}\Omega\_{\rm m}^{0.25}$ to roughly $3\thinspace\%$.

The organization of this paper is as follows. In Sect. [2](#S2 "2 Data and methodology ‣ Planck 2015 results. XV. Gravitational lensing") we give a summary of our analysis pipeline for the full-mission data.
Our analysis is very similar to that presented in [Planck Collaboration
XVII (2014)](#bib.bib37),
with straightforward extensions to polarization data, as well as a few additional improvements,
and so we have deferred most technical details to appendices.
In Sect. [3](#S3 "3 Results ‣ Planck 2015 results. XV. Gravitational lensing") we present our main results, including the lensing potential map, bandpower estimates of the lensing potential power spectrum, and implications for cosmological parameters.
In Sect. [4](#S4 "4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") we present a suite of consistency and null tests to verify our bandpower estimates, and in Sect. [5](#S5 "5 Conclusions ‣ Planck 2015 results. XV. Gravitational lensing") we conclude.
A series of appendices provide more technical details of our analysis pipeline, modeling of the CIB, and dependence of the lensing power spectrum on $\Lambda$CDM parameters.

## 2 Data and methodology

Here we give a brief overview of the procedure that we use to measure the CMB lensing potential and its power spectrum from the Planck maps.
We defer the detailed technical aspects of our pipeline to Appendix [A](#A1 "Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing").

Our main results are based on a foreground-cleaned map of the CMB synthesized from the raw Planck 2015 full-mission frequency maps using the
SMICA code ([Planck Collaboration
IX 2016](#bib.bib43)).
This foreground-cleaned map combines all nine frequency bands from 30 GHz to 857 GHz with scale-dependent coefficients chosen to provide unit response to the CMB with minimal variance;
for more details see [Planck Collaboration
IX (2016)](#bib.bib43)†
†††
††
$†$
We use
a slightly earlier version of SMICA maps than those in the
public release. They differ by pixel-smoothing and missing-pixel mask, however this has no significant effect on the results..
On the small scales where lensing effects are most important (multipoles above $\ell=1000$),
most of the CMB information in the foreground-cleaned maps originates with the 143 GHz and 217 GHz channel data.
These channels have beams that are approximately Gaussian with full-width-at-half-maximum (FWHM) parameters of $7^{\prime}$ and $5^{\prime}$, respectively.
Their noise is approximately white for
$1000\lesssim\ell\lesssim 3000$, with levels of
$30\thinspace\mu{\rm K}\thinspace{\rm arcmin}$ ($60\thinspace\mu{\rm K}\thinspace{\rm arcmin}$) in temperature (polarization) at 143 GHz, and
$40\thinspace\mu{\rm K}\thinspace{\rm arcmin}$ ($95\thinspace\mu{\rm K}\thinspace{\rm arcmin}$) at 217 GHz.

We reconstruct the CMB lensing potential using quadratic estimators that exploit the statistical anisotropy induced by lensing, following [Okamoto & Hu (2003)](#bib.bib33).
Neglecting the lensing of primordial $B$-modes there are five possible estimators, denoted by
$\hat{\phi}^{TT}$,
$\hat{\phi}^{TE}$,
$\hat{\phi}^{EE}$,
$\hat{\phi}^{EB}$, and
$\hat{\phi}^{TB}$, which are based on various correlations of the CMB temperature ($T$) and polarization ($E$ and $B$).
In addition, we can form a minimum-variance estimator that combines all five estimators, which we denote as $\hat{\phi}^{\rm MV}$.
In Fig. [1](#S2.F1 "Figure 1 ‣ 2 Data and methodology ‣ Planck 2015 results. XV. Gravitational lensing") we plot the lens reconstruction noise levels for these estimators.
The most powerful estimator is $TT$, although the $TE$ and $EE$ estimators are also useful on large angular scales.

Figure 1: 
Lens reconstruction noise levels
$N\_{L}^{\phi\phi}$ for the
$TT$, $TE$, $EE$, $EB$, and $TB$ estimators
applied to the SMICA full-mission CMB map.
The noise level for their minimum-variance combination (MV) is also shown.
The fiducial $\Lambda$CDM theory power spectrum $C\_{L}^{\phi\phi,{\rm fid}}$ used in our Monte Carlo simulations is plotted as the black solid line.

The quadratic lensing estimators take inverse-variance filtered CMB multipoles as input.
We obtain these using a filter that masks the Galaxy and point sources,
and also bandpass filters the data in harmonic space to $100\!\leq\!\ell\!\leq\!2048$.
For our baseline analysis, we start with the masks used in the analysis of [Planck Collaboration
XVII (2014)](#bib.bib37),
with a Galaxy mask that removes $30.2\thinspace\%$ of the sky and a point-source mask that removes an additional $0.7\thinspace\%$ of the sky.
This removes the brightest Sunyaev-Zel’dovich
(SZ) clusters as described in [Planck Collaboration
XVII (2014)](#bib.bib37); contamination
of the lensing reconstruction from residual unresolved SZ is
expected to be at the percent level for
Planck ([van Engelen et al. 2014](#bib.bib58)), even without component
separation.‡
‡‡‡
‡‡
$‡$
We mask clusters with $S/N\geq 5$ in the
Planck cluster catalogue that accompanied the 2013 release
(PSZ1; [Planck Collaboration
XXIX 2014](#bib.bib39)). The mass limit is redshift
dependent, with a high-redshift limit
at 80 % completeness of $M\_{500}\approx 6\times 10^{14}\thinspace{\rm M}\_{\mathord{\odot}}$. If we conservatively adopt this mass limit (we
certainly mask low-redshift clusters to lower masses), the results
of [van Engelen et al. (2014)](#bib.bib58) suggest that the SZ trispectrum at
143 GHz gives a positive bias of at most a few percent in the
reconstructed lensing
power spectrum for multipoles $L<2000$, while the lensing-SZ-SZ
bispectrum gives a negative bias of similar size. The SZ signal is
much smaller in the 217 GHz temperature data, which is around the
null of the (thermal) SZ effect.
This residual signal, and that from unresolved point-sources, is
further reduced by a correction that we make to the power
spectrum of the reconstructed lensing potential (see Appendix [A.3](#A1.SS3 "A.3 Power spectrum estimation ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")).
Finally, we apply SMICA-specific temperature and polarization masks described in
[Planck Collaboration
IX (2016)](#bib.bib43).
Combining all three sets of masks leaves a total of $67.3\thinspace\%$ of the sky for analysis.

We estimate the power spectrum of the lensing potential $C\_{L}^{\phi\phi}$ using the auto- and cross-spectra of the quadratic lensing estimators.§
§§§
§§
$§$
In this paper, we use multipole indices $LM$ for the lens reconstruction, reserving multipole indices $\ell m$ for the CMB fields.
These spectra probe the 4-point function of the lensed CMB, specifically the connected (trispectrum) part of the 4-point function that is sourced by lensing.
They also contain contributions from the disconnected part of the 4-point function (which is non-zero even in the absence of lensing effects). We estimate this contribution and subtract it, as well as several other smaller bias terms, obtaining an estimate $\hat{C}\_{L}^{\phi\phi}$ of the power spectrum.
This procedure is discussed in Appendix [A.3](#A1.SS3 "A.3 Power spectrum estimation ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing").
For cosmological parameter constraints, we use a Gaussian log-likelihood in bandpowers of the estimated lensing power spectrum, given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $-2\log{\cal L}\_{\phi}={\cal B}\_{i}^{L}(\hat{C}\_{L}^{\phi\phi}-C\_{L}^{\phi\phi,{\rm th}})\left[\Sigma^{-1}\right]^{ij}{\cal B}\_{j}^{L^{\prime}}(\hat{C}\_{L^{\prime}}^{\phi\phi}-C\_{L^{\prime}}^{\phi\phi,{\rm th}}).$ |  | (3) |

Here, bins are indexed by $i$ and $j$; ${\cal B}^{L}\_{i}$ is the bandpower binning function for the $i$th bin,
and $\Sigma$ is a covariance matrix for the bin estimates.
Paired upper/lower indices are summed over. The
$C\_{L}^{\phi\phi,{\rm th}}$ is the theoretical expectation value of the estimated $\hat{C}\_{L}^{\phi\phi}$ for the set of cosmological and nuisance parameters under consideration. This generally differs from the theory spectrum $C\_{L}^{\phi\phi}$ at the same cosmological parameters due to the way that our power spectrum estimates are normalized, and corrected for additional trispectrum couplings, with a fiducial model.
Both the binning function and $C\_{L}^{\phi\phi,{\rm th}}$ are discussed in Appendix [C](#A3 "Appendix C Power spectrum likelihood ‣ Planck 2015 results. XV. Gravitational lensing").
The binning function is chosen to have unit response to a fiducial theory spectrum
$C\_{L}^{\phi\phi,{\rm fid}}$, and so we denote

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{A}^{\phi}\_{i}={\cal B}^{L}\_{i}\hat{C}\_{L}^{\phi\phi}$ |  | (4) |

as the amplitude of the power spectrum for a particular bin relative to the fiducial
expectation
(with $\hat{A}=1$ for $\hat{C}\_{L}^{\phi\phi}=C\_{L}^{\phi\phi,{\rm fid}}$).

To characterize the variance of our lensing potential estimates, as well as to estimate several bias terms, we use simulated Planck maps.
These are based on the Full Focal Plane 8 (FFP8) Monte Carlo simulation set described in [Planck Collaboration
XII (2016)](#bib.bib45).
As discussed there,
the Planck maps were effectively renormalized by approximately $2$–$3$% in power in the time between the generation of FFP8 and the final Planck full-mission maps.
To account for this, we rescale the CMB component of the simulations by a factor of $1.0134$ before analysis.
The FFP8 simulations do not include contributions from residual foregrounds (Galactic dust, as well as unmasked point sources), and also underestimate the noise power spectra by several percent at high-$\ell$.
We account for this missing power simply by adding coloured Gaussian noise to the simulations to make their $TT$, $EE$, and $BB$ power spectra agree with the data.
This approach implicitly assumes that any non-Gaussianity of these residual components does not couple significantly to our lensing estimates.
We perform consistency tests in Sect. [4](#S4 "4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") to check the validity of these assumptions.

Throughout this paper we use a spatially-flat fiducial cosmology with
baryon density given by
$\omega\_{\rm b}=\Omega\_{\rm b}h^{2}=0.0222$,
cold dark matter density
$\omega\_{\rm c}=\Omega\_{\rm c}h^{2}=0.1203$,
neutrino energy density
$\omega\_{\nu}=\Omega\_{\nu}h^{2}=0.00064$ (corresponding to two massless neutrinos and one massive with mass $0.06\thinspace{\rm eV}$),
Hubble constant $H\_{0}=100h\thinspace\mathrm{km}\thinspace\mathrm{s}^{-1}\thinspace\mathrm{Mpc}^{-1}$ with $h=0.6712$,
spectral index of the power spectrum of the primordial curvature perturbation
$n\_{\rm s}=0.96$, amplitude of the primordial power spectrum (at $k=0.05\thinspace\mathrm{Mpc}^{-1}$) $A\_{\rm s}=2.09\times 10^{-9}$, and Thomson optical depth through reionization $\tau=0.065$.
These cosmological parameters also form the basis for the FFP8 Monte Carlo simulation set.
In addition to rescaling the FFP8 maps as already discussed, we have also adjusted the power spectra of the fiducial model by rescaling the CMB temperature and polarization spectra by a factor of $1.0134^{2}$, and the temperature-lensing cross-correlation $C\_{L}^{T\phi}$ by 1.0134. We have not applied any scaling to the fiducial lensing power spectrum.
Our reconstruction methodology (in particular, the renormalization corrections, addition of foreground power, and realization-dependent bias corrections that we apply, discussed in Appendix [C](#A3 "Appendix C Power spectrum likelihood ‣ Planck 2015 results. XV. Gravitational lensing")) renders the cosmological interpretation of our lensing estimates insensitive to errors in the fiducial model power spectra and simulations.

## 3 Results

In this section, we provide a summary of the first science results obtained with the minimum-variance lens reconstruction from the Planck full-mission data. The lensing potential map is presented in Sect. [3.1](#S3.SS1 "3.1 Lensing potential ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing"), and this is combined in Sect. [3.2](#S3.SS2 "3.2 Lensing 𝐵-mode power spectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") with the $E$-mode polarization measured by Planck to obtain a map of the expected $B$-mode polarization due to lensing. We further show that this is correlated with the $B$-modes measured by Planck at the expected level. In Sect. [3.3](#S3.SS3 "3.3 Lensing-ISW bispectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing"), we cross-correlate the reconstructed lensing potential with the large-angle temperature anisotropies to measure the $C\_{L}^{T\phi}$ correlation sourced by the ISW effect. Finally, the power spectrum of the lensing potential is presented in Sect. [3.4](#S3.SS4 "3.4 Lensing potential power spectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing").
We use the associated likelihood alone, and in combination with that constructed from the Planck temperature and polarization power spectra ([Planck Collaboration
XI 2016](#bib.bib44)), to constrain cosmological parameters in Sect. [3.5](#S3.SS5 "3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing").

### 3.1 Lensing potential

In Fig. [3](#S3.F3 "Figure 3 ‣ 3.1 Lensing potential ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") we plot the Wiener-filtered minimum-variance lensing estimate, given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{\phi}^{\rm WF}\_{LM}=\frac{C\_{L}^{\phi\phi,\ {\rm fid}}}{C\_{L}^{\phi\phi,\ {\rm fid}}+N\_{L}^{\phi\phi}}\hat{\phi}^{\rm MV}\_{LM},$ |  | (5) |

where $C\_{L}^{\phi\phi,\ {\rm fid}}$ is the lensing potential power spectrum in our fiducial model
and $N\_{L}^{\phi\phi}$ is the noise power spectrum of the reconstruction.
As we shall discuss in Sect. [4.5](#S4.SS5 "4.5 Bias-hardened estimators ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing"),
the lensing potential estimate is unstable for $L<8$,
and so we have excluded those modes for all analyses in this paper, as well as in the MV lensing map.

As a visual illustration of the signal-to-noise level in the lensing potential estimate,
in Fig. [3](#S3.F3 "Figure 3 ‣ 3.1 Lensing potential ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") we plot a simulation of the MV reconstruction, as well as the input $\phi$ realization used.
The reconstruction and input are clearly correlated, although the reconstruction has considerable additional power due to noise.
As can be seen in Fig. [1](#S2.F1 "Figure 1 ‣ 2 Data and methodology ‣ Planck 2015 results. XV. Gravitational lensing"), even the MV reconstruction only has $S/N\approx 1$ for a few modes around $L\approx 50$.

(Data)

Figure 2: 
Lensing potential estimated from the SMICA full-mission CMB maps using the MV estimator. The power spectrum of this map forms the basis of our lensing likelihood. The estimate has been Wiener filtered following Eq. ([5](#S3.E5 "Equation 5 ‣ 3.1 Lensing potential ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")), and band-limited to $8\leq L\leq 2048$.

(Sim.)

Input (Sim.)

Figure 3: 
Simulation of a Wiener-filtered MV lensing reconstruction (upper) and the input $\phi$ realization (lower), filtered in the same way as the MV lensing estimate.
The reconstruction and input are clearly correlated, although the reconstruction has considerable additional power due to noise.

The MV lensing estimate in Fig. [3](#S3.F3 "Figure 3 ‣ 3.1 Lensing potential ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") forms the basis for a public lensing map that we provide to the community ([Planck Collaboration
I 2016](#bib.bib40)).
The raw lensing potential estimate has a very red power spectrum, with most of its power on large angular scales.
This can cause leakage issues when cutting the map (for example to cross-correlate with an additional mass tracer over a small portion of the sky).
The lensing convergence $\kappa$ defined by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\kappa\_{LM}=\frac{L(L+1)}{2}\phi\_{LM},$ |  | (6) |

has a much whiter power spectrum, particularly on large angular scales.
The reconstruction noise on $\kappa$ is approximately white as well ([Bucher et al. 2012](#bib.bib5)).
For this reason, we provide a map of the estimated lensing convergence $\kappa$ rather than the lensing potential $\phi$.

### 3.2 Lensing $B$-mode power spectrum

The odd-parity $B$-mode component of the CMB polarization is of great importance for early-universe cosmology.
At first order in perturbation theory it is not sourced by the scalar fluctuations that dominate the temperature and polarization anisotropies,
and so the observation of primordial $B$-modes can be used as a uniquely powerful probe of tensor (gravitational wave) or vector perturbations in the early Universe.
A detection of $B$-mode fluctuations on degree angular scales, where the signal from gravitational waves is expected to peak, has recently been reported at $150\thinspace{\rm GHz}$ by the BICEP2 collaboration ([Ade et al. 2014](#bib.bib1)). Following the joint analysis of BICEP2 and Keck Array data (also at $150\thinspace{\rm GHz}$) and the Planck polarization data, primarily at $353\thinspace{\rm GHz}$ ([BICEP2/Keck Array and Planck Collaborations 2015](#bib.bib4)), it is now understood that the $B$-mode signal detected by BICEP2 is dominated by Galactic dust emission. The joint analysis gives no statistically-significant evidence for primordial gravitational waves, and establishes a 95 % upper limit $r\_{0.05}<0.12$. This still represents an important milestone for $B$-mode measurements, since the direct constraint from the $B$-mode power spectrum is now as constraining as indirect, and model-dependent, constraints from the $TT$ spectrum ([Planck Collaboration
XIII 2016](#bib.bib46)).

In addition to primordial sources, the effect of gravitational lensing also generates $B$-mode polarization.
The displacement of lensing mixes $E$-mode polarization into $B$-mode as ([Smith et al. 2009](#bib.bib55))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $B^{\rm lens}\_{\ell\_{B}m\_{B}}=(-1)^{m\_{B}}\sum\_{LM}\sum\_{\ell\_{E}m\_{E}}\left(\begin{array}[]{ccc}\!\ell\_{E}&\ell\_{B}&L\\ \!m\_{E}&-m\_{B}&M\end{array}\right)W^{\phi\_{EB}}\_{\ell\_{E}\ell\_{B}L}E\_{\ell\_{E}m\_{E}}\phi\_{LM},$ |  | (7) |

where $W^{\phi\_{EB}}\_{\ell\_{E}\ell\_{B}L}$ is a weight function and the bracketed term is a Wigner-$3j$ symbol.
On scales $\ell\_{B}\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}1000$ the lensing $B$-mode power spectrum resembles that of white noise, with a level of about $5\thinspace\mu{\rm K}\thinspace{\rm arcmin}$.
This lensing power acts as a potential source of confusion for the measurement of primordial $B$-modes, which can be estimated and ultimately removed in a process of delensing.
Given an estimate for the lensing potential $\phi$ and the $E$-mode polarization measured by Planck we can synthesize a lensed $B$-mode map for this purpose using Eq. ([7](#S3.E7 "Equation 7 ‣ 3.2 Lensing 𝐵-mode power spectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")).
The $5\thinspace\mu{\rm K}\thinspace{\rm arcmin}$ level of the lensing $B$-mode power spectrum is an order of magnitude lower than the Planck 2015 noise levels,
and so delensing does not significantly improve our $B$-mode measurements;
however, the cross-correlation of the lensing $B$-mode template with the observed $B$-mode sky provides a useful check on the ability of Planck to measure this known source of $B$-modes.

We show the results of such a cross-correlation in Fig. [4](#S3.F4 "Figure 4 ‣ 3.2 Lensing 𝐵-mode power spectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing"),
finding good agreement with the expected lensing $B$-mode power spectrum.
In addition to our fiducial MV lensing potential estimate, which uses both temperature and polarization data,
we have also estimated the lensing $B$-mode power spectrum using the $TT$-only lensing estimator to measure $\phi$,
as well as the CIB fluctuations measured by the $545\thinspace{\rm GHz}$ Planck channel.¶
¶¶¶
¶¶
$¶$
To calculate the scaling between the CIB map and the lensing potential $\phi$, we model the CIB using the simple model of [Hall et al. (2010)](#bib.bib16) for its redshift and frequency dependence. Further details are given in Appendix [D](#A4 "Appendix D CIB model ‣ Planck 2015 results. XV. Gravitational lensing").
We see good agreement in all cases with the expected power;
constraining the overall amplitude of the lensing $B$-mode power spectrum $\hat{A}^{B}$
(relative to the predicted spectrum in our fiducial model) for a large bin from
$8\leq\ell\_{B}\leq 2048$
we measure amplitudes of

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\hat{A}^{B}\_{8\rightarrow 2048}$ | $\displaystyle=0.93\pm 0.08\quad(\phi^{{\rm MV}}),$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\hat{A}^{B}\_{8\rightarrow 2048}$ | $\displaystyle=0.95\pm 0.09\quad({\phi^{TT}}),$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\hat{A}^{B}\_{8\rightarrow 2048}$ | $\displaystyle=0.93\pm 0.10\quad({\rm CIB})$ |  |

for the three estimates, each corresponding to a roughly
$10\thinspace\sigma$
detection of lensing $B$-mode power in the Planck data.
The shape of the cross-correlation is also in good agreement with expectation.
Taking the bins in Fig. [4](#S3.F4 "Figure 4 ‣ 3.2 Lensing 𝐵-mode power spectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") as independent, forming a $\chi^{2}$ relative to the theory model and
comparing to the distribution from simulations we obtain probability-to-exceed (PTE) values of
$48\%$, $71\%$, and $78\%$
using the MV, $TT$, and CIB lensing estimates, respectively.

Figure 4: 
Measurement of the lensing $B$-mode power spectrum, using cross-correlation with estimates of the lensing potential as discussed in Sect. [3.2](#S3.SS2 "3.2 Lensing 𝐵-mode power spectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing").
The theoretical lensing $B$-mode power spectrum, for the parameters of the fiducial cosmological model of Sect. [2](#S2 "2 Data and methodology ‣ Planck 2015 results. XV. Gravitational lensing"), is plotted as dashed black. Green squares and blue triangles are results using the $TT$ and MV $\phi$ reconstructions, respectively, to construct the lens-induced $B$-mode template, while red circles use the CIB (from the Planck $545\thinspace{\rm GHz}$ channel) to construct a proxy for $\phi$.
Lensing $B$-mode power is detected with the expected scale dependence and amplitude at a significance level of
approximately $10\thinspace\sigma$.

### 3.3 Lensing-ISW bispectrum

As photons travel towards us from the last scattering surface, they are not only deflected by gravitational lensing,
they also receive net red/blueshifts from gravitational potentials that evolve if they are crossed at late times.
This phenomenon, known as the integrated Sachs-Wolfe (ISW) effect, is believed to generate
anisotropies in the observed CMB temperature on large ($\ell\lesssim 100$) angular scales.
It is of particular interest because the decay of gravitational potentials, which produces the ISW effect, does not occur during matter domination,
but only at redshifts $z\lesssim 2$ when dark energy becomes dynamically important.
The ISW effect can be detected statistically by cross-correlating the observed temperature
anisotropies with a tracer of structure at these redshifts.
Here we use the lensing potential, which is well-matched to the ISW effect ([Hu 2002](#bib.bib22)).
Current Planck results incorporating additional external tracers of large-scale structure are summarized in
[Planck Collaboration
XXI (2016)](#bib.bib48).

In Fig. [5](#S3.F5 "Figure 5 ‣ 3.3 Lensing-ISW bispectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") we plot the cross-correlation $C\_{L}^{T\phi}$ between the MV lens reconstruction and the CMB temperature.
This cross-correlation probes the bispectrum, or three-point correlation function of the CMB, which is due to the correlation of the lensing and ISW effects.
The measurement is noisy, due to a combination of noise in the lens reconstruction and cosmic variance in the temperature (which ultimately limits the detection of the lensing-ISW bispectrum to about $9\thinspace\sigma$; [Lewis et al. 2011](#bib.bib28)).

To determine the overall detection significance for the cross-correlation, we use the minimum-variance bispectrum estimator

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{A}^{T\phi}=\frac{1}{N^{T\phi}}\sum\_{LM}\frac{C\_{L}^{T\phi,\ {\rm fid}}}{f\_{\rm sky}}\frac{\hat{\phi}\_{LM}}{(C\_{L}^{\phi\phi,\ {\rm fid}}+N\_{L}^{\phi\phi})}\frac{{T}^{\*}\_{LM}}{C\_{L}^{TT,\ {\rm fid}}},$ |  | (8) |

where $N^{T\phi}$ is a normalization determined from simulations.∥
∥∥∥
∥∥
$∥$
We find $N^{T\phi}$ is within
$4\%$
of the analytical expectation

$N^{T\phi}\approx\left[\sum\_{L}(2L+1)\left(C\_{L}^{T\phi,\ {\rm fid}}\right)^{2}\frac{1}{C\_{L}^{\phi\phi,\ {\rm fid}}+N\_{L}^{\phi\phi}}\frac{1}{C\_{L}^{TT,\ {\rm fid}}}\right].$
For the MV lens reconstruction, using $8\leq L\leq 100$ we measure an amplitude

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{A}^{T\phi}\_{8\rightarrow 100}=0.90\pm 0.28\quad\quad\mbox{(MV)}\thinspace,$ |  | (9) |

which is consistent with the theoretical expectation of unity and non-zero at just over $3\thinspace\sigma$.
Using the $TT$-only lensing estimate rather than the MV lensing estimate in the cross-correlation, we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{A}^{T\phi}\_{8\rightarrow 100}=0.68\pm 0.32\quad\quad\mbox{($TT$)}\thinspace.$ |  | (10) |

Using simulations, we measure an rms difference between the $TT$ and MV bispectrum amplitudes of 0.18
(roughly equal to the quadrature difference of their error bars, which is
$\sqrt{0.32^{2}-0.28^{2}}=0.15$). Therefore the difference of amplitudes,
$\Delta\hat{A}^{T\phi}\_{8\rightarrow 100}=0.22$, is compatible with the expected scatter.

Figure 5: 
Lensing-ISW bispectrum on large angular scales.
The cross-spectrum between the MV lensing potential estimate and the temperature anisotropy is plotted for bins of width $\Delta L=15$, covering the multipole range $L=8$–$98$. The dashed line shows the predicted cross-spectrum in the fiducial model.
The lensing-ISW bispectrum is detected at just over $3\thinspace\sigma$ significance.

In [Planck Collaboration
XVII (2014)](#bib.bib37), using the $TT$ lensing estimator on the multipole range $10\leq L\leq 100$
we measured a somewhat higher value for the lensing-ISW bispectrum amplitude of
$\hat{A}^{T\phi,\ 2013}\_{10\rightarrow 100}=0.85\pm 0.35$.∗
⁣
∗
∗⁣∗\*\*∗
⁣
∗
∗⁣∗\*\*
$\*\*$
The amplitude quoted in [Planck Collaboration
XVII (2014)](#bib.bib37) is actually
$\hat{A}^{T\phi,\ 2013}\_{10\rightarrow 100}=0.78\pm 0.32$, however this is measured with respect to
a slightly different fiducial cosmology than the one used here.
Those measurements have been renormalized to the fiducial model used for this paper with a factor of $1.09$.
We expect the difference with respect to the 2015 $TT$ measurement to have standard deviation of approximately
$\sqrt{0.35^{2}-0.32^{2}}=0.14$,
and so the observed difference of
$0.85-0.68=0.17$
is reasonable.

### 3.4 Lensing potential power spectrum

In Fig. [6](#S3.F6 "Figure 6 ‣ 3.4 Lensing potential power spectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") we plot our estimate of the lensing potential power spectrum obtained from the MV reconstruction, as well as several earlier measurements. We see good agreement with the shape in the fiducial model, as well as earlier measurements (detailed comparisons with the 2013 spectrum are given later in this section). In Sect. [4](#S4 "4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") we perform a suite of internal consistency and null tests to check the robustness of our lensing spectrum to different analysis and data choices.

We estimate the lensing potential power spectrum in bandpowers for two sets of bins:
a ‘conservative’ set of eight uniformly-spaced bins with $\Delta L=45$ in the range $40\leq L\leq 400$; and
an ‘aggressive’ set of 18 bins that are uniformly spaced in $L^{0.6}$ over the multipole range $8\leq L\leq 2048$.
The conservative bins cover a multipole range where the estimator signal-to-noise is greatest.
They were used for the Planck 2013 lensing likelihood described in [Planck Collaboration
XVII (2014)](#bib.bib37).
The aggressive bins provide good sensitivity to the shape of the lensing power on both large and small scales, however they are more easily biased by errors in the mean-field corrections (which are large at $L<40$) and the disconnected noise bias corrections (at $L>400$).
Results for the bandpower amplitudes $\hat{A}\_{i}^{\phi}$,
defined in Eq. ([4](#S2.E4 "Equation 4 ‣ 2 Data and methodology ‣ Planck 2015 results. XV. Gravitational lensing")), are given in Table [1](#S3.T1 "Table 1 ‣ 3.4 Lensing potential power spectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") for both sets of multipole bins.

Nearly all of the internal consistency tests that we
present in Sect. [4](#S4 "4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") are passed at an acceptable level.
There is, however, mild evidence for a correlated feature in the curl-mode null-test, centred around $L\approx 500$. The $L$ range covered by this feature includes $638\leq L\leq 762$, for which the (gradient) lensing reconstruction bandpower is $3.6\thinspace\sigma$ low compared to the predicted power of the fiducial model. In tests of the sensitivity of parameter constraints to lensing multipole range, described later in Sect. [3.5.4](#S3.SS5.SSS4 "3.5.4 Sensitivity to 𝐿-range ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing"),
we find shifts in some parameters of around $1\thinspace\sigma$ in going from the conservative to aggressive range, with negligible improvement in the parameter uncertainty. Around half of these shifts come from the outlier noted above. For this reason, we adopt the conservative multipole range as our baseline here, and in other Planck 2015 papers, when quoting constraints on cosmological parameters. However, where we quote constraints on amplitude parameters in this paper, we generally give these for both the aggressive and conservative binning.
The aggressive bins are also used for all of the $C\_{L}^{\phi\phi}$ bandpower plots in this paper.

Estimating an overall lensing amplitude (following Eq. [4](#S2.E4 "Equation 4 ‣ 2 Data and methodology ‣ Planck 2015 results. XV. Gravitational lensing")) relative to our fiducial theoretical model, for a single bin over both the aggressive and conservative multipole ranges we find

|  |  |  |  |
| --- | --- | --- | --- |
|  | | | |
|  | $\displaystyle\qquad\qquad\qquad\qquad\hat{A}^{\phi,\thinspace{\rm MV}}\_{40\rightarrow 400}=0.987\pm 0.025,$ |  | (11a) |
|  | $\displaystyle\qquad\qquad\qquad\qquad\hat{A}^{\phi,\thinspace{\rm MV}}\_{8\rightarrow 2048}=0.983\pm 0.025.$ |  | (11b) |

These measurements of the amplitude of the lensing power spectrum both have precision of 2.5 %, and are non-zero at $40\thinspace\sigma$.
Given the measured amplitude, it is clear that our overall lensing amplitude estimate is consistent with our fiducial $\Lambda$CDM model (which has $A=1$).
The shape of our measurement is also in reasonable agreement with the fiducial model.
Marginalizing over an overall amplitude parameter, for the
$19$
bins plotted in Fig. [6](#S3.F6 "Figure 6 ‣ 3.4 Lensing potential power spectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") we obtain a
$\chi^{2}$ with respect to our fiducial model of $28$ (with $N\_{\rm dof}=18$),
with a corresponding PTE of
$6\thinspace\%$.
A large portion of this $\chi^{2}$ is driven by the outlier bandpower with $638\!\leq\!L\!\leq\!762$.
Removing this bandpower gives a $\chi^{2}$ of $16.5$ ($N\_{\rm dof}=17$), with a PTE of $49\thinspace\%$.
For the more conservative multipole range $40\!\leq\!L\!\leq\!400$,
using eight linear bins we obtain $\chi^{2}$ of $8.9$ ($N\_{\rm dof}=7$), with a PTE of $26\thinspace\%$.

Finally, we note that the lensing bandpowers measured here are in good agreement with the Planck 2013 results ([Planck Collaboration
XVII 2014](#bib.bib37)).
The only clear visual difference between the two measurements in Fig. [6](#S3.F6 "Figure 6 ‣ 3.4 Lensing potential power spectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") is for the $L=40$–$65$ bin, where the 2013 bandpower is significantly higher than the current measurement.
As previously discussed in [Planck Collaboration
XVII (2014)](#bib.bib37), this bin amplitude was sensitive to the choice of foreground cleaning, and decreased when using a component-separated map for the reconstruction (as is done here), and so this difference is expected.
To compare measurements in further detail, we calculate a $\chi^{2}$ for the difference between our 2013 and 2015 MV lensing bandpower estimates assuming a diagonal covariance as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\chi^{2}\_{2013-2015}=\sum\_{L\_{b}}\frac{\left(\left.\hat{C}\_{L\_{b}}^{\phi\phi}\right|\_{\rm 2013}-\left.\hat{C}\_{L\_{b}}^{\phi\phi}\right|\_{\rm 2015}\right)^{2}}{{\rm Var}\left(\left.\hat{C}\_{L\_{b}}^{\phi\phi}\right|\_{\rm 2013}\right)-{\rm Var}\left(\left.\hat{C}\_{L\_{b}}^{\phi\phi}\right|\_{\rm 2015}\right)},$ |  | (12) |

where $L\_{b}$ indexes the bandpower bins. We approximate the variance of the differences of the bandpowers as the difference of the variances in forming this $\chi^{2}$.
Using the conservative bins for $40\leq L\leq 400$, which were used for the 2013 lensing likelihood, we obtain a value of
$\chi^{2}\_{2013-2015}=10.8$ ($N\_{\rm dof}=8$),
with a corresponding PTE of $22\thinspace\%$.
The 2013 result is temperature only; if we compare it directly to the 2015 $TT$ lensing bandpowers, we obtain a value of
$\chi^{2}=7.2$ ($N\_{\rm dof}=8$, ${\rm PTE}\!=\!52\%$).
We note that some care should be taken when comparing the measured lensing amplitudes between 2013 and 2015, because the fiducial spectra against which they are measured differ significantly.
In 2013, for example, we measured
$\hat{A}^{\phi,\thinspace\text{2013}}\_{40\rightarrow 400}=0.943\pm 0.040$.
However, this was measured with respect to a fiducial $C\_{L}^{\phi\phi}$ that is between $6\thinspace\%$ and $7\thinspace\%$ higher than the one used here in this multipole range.
Renormalizing the 2013 measurements to determine the amplitude for the 2015 fiducial cosmology, we obtain
$1.005\pm 0.043$, which can be compared directly to the measurement of
$\hat{A}^{\phi,\thinspace\text{MV}}\_{40\rightarrow 400}=0.987\pm 0.025$ for 2015.
It is interesting to note that there is a $2\thinspace\%$ difference in power between the Planck 2013 and 2015 maps from HFI due to a change in the calibration, as well as an improved beam model ([Planck Collaboration
VII 2016](#bib.bib41)). This shift does not couple to the lensing reconstruction; lensing is a geometric effect, and so an overall change in the calibration does not affect the lens reconstruction procedure, provided that a consistent power spectrum is used to analyse the maps, as is done here.

Table 1: 
Lensing potential power spectrum estimates from the MV lens reconstruction.
The $\hat{A}^{\phi}$ values are dimensionless, with
$A^{\phi}=1$
for a measured spectrum equal to the lensing potential power spectrum of our fiducial cosmology (described in Sect. [2](#S2 "2 Data and methodology ‣ Planck 2015 results. XV. Gravitational lensing")). The final column lists bandpower estimates, averaged within each bin.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  |  | | --- | --- | --- | --- | | Lensing power spectrum bandpowers | | | | |  | | | | | $L\_{\rm min}$ | $L\_{\rm max}$ | $\hat{A}^{\phi}$ | $10^{7}[L(L+1)]^{2}C\_{L}^{\phi\phi}/2\pi$ | |  | | | | | Conservative multipole range ($40\!\leq\!L\!\leq\!400$) | | | | | $\phantom{0}\phantom{0}40$ | $\phantom{0}\phantom{0}84$ | $\phantom{-}1.01\pm 0.05$ | $\phantom{-}1.28\pm 0.06$ | | $\phantom{0}\phantom{0}85$ | $\phantom{0}129$ | $\phantom{-}1.02\pm 0.04$ | $\phantom{-}1.00\pm 0.04$ | | $\phantom{0}130$ | $\phantom{0}174$ | $\phantom{-}0.93\pm 0.05$ | $\phantom{-}0.70\pm 0.04$ | | $\phantom{0}175$ | $\phantom{0}219$ | $\phantom{-}0.89\pm 0.07$ | $\phantom{-}0.52\pm 0.04$ | | $\phantom{0}220$ | $\phantom{0}264$ | $\phantom{-}0.86\pm 0.10$ | $\phantom{-}0.41\pm 0.05$ | | $\phantom{0}265$ | $\phantom{0}309$ | $\phantom{-}1.03\pm 0.11$ | $\phantom{-}0.41\pm 0.05$ | | $\phantom{0}310$ | $\phantom{0}354$ | $\phantom{-}1.24\pm 0.13$ | $\phantom{-}0.41\pm 0.04$ | | $\phantom{0}355$ | $\phantom{0}400$ | $\phantom{-}0.97\pm 0.16$ | $\phantom{-}0.27\pm 0.05$ | |  | | | | | Aggressive multipole range ($8\!\leq\!L\!\leq\!2048$) | | | | | $\phantom{0}\phantom{0}\phantom{0}8$ | $\phantom{0}\phantom{0}20$ | $\phantom{-}1.09\pm 0.17$ | $\phantom{-}1.29\pm 0.21$ | | $\phantom{0}\phantom{0}21$ | $\phantom{0}\phantom{0}39$ | $\phantom{-}1.01\pm 0.09$ | $\phantom{-}1.39\pm 0.13$ | | $\phantom{0}\phantom{0}40$ | $\phantom{0}\phantom{0}65$ | $\phantom{-}1.05\pm 0.07$ | $\phantom{-}1.40\pm 0.09$ | | $\phantom{0}\phantom{0}66$ | $\phantom{0}100$ | $\phantom{-}1.00\pm 0.05$ | $\phantom{-}1.13\pm 0.06$ | | $\phantom{0}101$ | $\phantom{0}144$ | $\phantom{-}0.99\pm 0.04$ | $\phantom{-}0.88\pm 0.04$ | | $\phantom{0}145$ | $\phantom{0}198$ | $\phantom{-}0.89\pm 0.05$ | $\phantom{-}0.60\pm 0.04$ | | $\phantom{0}199$ | $\phantom{0}263$ | $\phantom{-}0.90\pm 0.08$ | $\phantom{-}0.45\pm 0.04$ | | $\phantom{0}264$ | $\phantom{0}338$ | $\phantom{-}1.08\pm 0.10$ | $\phantom{-}0.40\pm 0.04$ | | $\phantom{0}339$ | $\phantom{0}425$ | $\phantom{-}1.08\pm 0.11$ | $\phantom{-}0.30\pm 0.03$ | | $\phantom{0}426$ | $\phantom{0}525$ | $\phantom{-}0.98\pm 0.13$ | $\phantom{-}0.20\pm 0.03$ | | $\phantom{0}526$ | $\phantom{0}637$ | $\phantom{-}0.69\pm 0.17$ | $\phantom{-}0.11\pm 0.03$ | | $\phantom{0}638$ | $\phantom{0}762$ | $\phantom{-}0.18\pm 0.23$ | $\phantom{-}0.02\pm 0.03$ | | $\phantom{0}763$ | $\phantom{0}901$ | $\phantom{-}0.73\pm 0.27$ | $\phantom{-}0.07\pm 0.02$ | | $\phantom{0}902$ | $1054$ | $\phantom{-}1.11\pm 0.40$ | $\phantom{-}0.08\pm 0.03$ | | $1055$ | $1221$ | $\phantom{-}0.27\pm 0.55$ | $\phantom{-}0.01\pm 0.03$ | | $1222$ | $1404$ | $\phantom{-}1.06\pm 0.80$ | $\phantom{-}0.05\pm 0.03$ | | $1405$ | $1602$ | $\phantom{-}0.91\pm 1.18$ | $\phantom{-}0.03\pm 0.04$ | | $1603$ | $1816$ | $-2.03\pm 1.75$ | $-0.06\pm 0.05$ | | $1817$ | $2048$ | $-0.54\pm 2.16$ | $-0.01\pm 0.05$ | |  |

Figure 6: 
Planck 2015 full-mission MV lensing potential power spectrum measurement, as well as earlier measurements using
the Planck 2013 nominal-mission temperature data ([Planck Collaboration
XVII 2014](#bib.bib37)),
the South Pole Telescope (SPT, [van Engelen et al. 2012](#bib.bib59)),
and the Atacama Cosmology Telescope (ACT, [Das et al. 2014](#bib.bib7)).
The fiducial $\Lambda$CDM theory power spectrum based on the parameters given in Sect. [2](#S2 "2 Data and methodology ‣ Planck 2015 results. XV. Gravitational lensing") is plotted as the black solid line.

### 3.5 Likelihoods and cosmological parameter constraints

In this section we discuss cosmological implications of the Planck lensing potential power spectrum estimate.
We use a Gaussian likelihood in the measured bandpowers, with corrections to account for errors in the fiducial CMB power spectra that are used to normalize and debias the lensing estimates.
This procedure is described in more detail in Appendix [C](#A3 "Appendix C Power spectrum likelihood ‣ Planck 2015 results. XV. Gravitational lensing").

In the following subsections, we discuss the information that can be gleaned from the lensing potential power spectrum alone, or in conjunction with the Planck 2015 CMB power spectrum likelihood. Some of the results in this section summarize the parts of [Planck Collaboration
XIII (2016)](#bib.bib46) that are directly related to lensing.

#### 3.5.1 Constraints from CMB lensing alone

Figure 7: 
Parameter constraints from CMB lensing alone in the $\Lambda$CDM model (samples, colour-coded by the value of the Hubble constant) using the minimal priors described in the text; grey bands give the corresponding $1\thinspace\sigma$ and $2\thinspace\sigma$ constraints using the approximate fit of Eq. ([13](#S3.E13 "Equation 13 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")).
Solid coloured contours show $68\thinspace\%$ and $95\thinspace\%$ constraints when additional information is included: BAO data from SDSS and 6DF ([Anderson et al. 2014](#bib.bib2); [Ross et al. 2015](#bib.bib53); [Beutler et al. 2011](#bib.bib3); blue), and the same but fixing the CMB acoustic-scale parameter $\theta\_{\rm MC}$ to a CMB power spectrum fit (red; $\theta\_{\rm MC}=1.0408$). Solid black contours show the constraint from the Planck CMB power spectra (Planck temperature+low-$\ell$ polarization).

The measurement of the lensing power spectrum is obtained from the 4-point function of the observed CMB anisotropies, and hence depends in general on both the lensing and CMB power spectra (see Appendix [C](#A3 "Appendix C Power spectrum likelihood ‣ Planck 2015 results. XV. Gravitational lensing")). However the latter are now well measured by Planck, and there is only a weak dependence on cosmological parameters given the observed spectra (mainly via different cosmological models changing foreground parameters, and hence the amplitude of underlying CMB power spectra). In this section we fix the CMB power spectra to a $\Lambda$CDM Planck TT+lowP best fit (i.e. using $TT$ on all scales and low-$\ell$ polarization), and consider the conditional probability of different cosmological parameters given only the lensing reconstruction power spectrum.

To avoid marginalizing over very unrealistic values of poorly constrained parameters, we adopt several well-motivated priors when considering constraints from lensing alone.

* $\bullet$

  The optical depth to reionization is fixed to $\tau=0.07$,
  because lensing deflections are independent of reionization (and scattering and subsequent lensing from sources at reionization is negligible).
* $\bullet$

  The baryon density is given a Gaussian $1\thinspace\sigma$ prior $\Omega\_{\mathrm{b}}h^{2}=0.0223\pm 0.0009$, as measured independently from big bang nucleosynthesis models combined with quasar absorption line observations ([Pettini & Cooke 2012](#bib.bib36)).
* $\bullet$

  The scalar spectral index is given a broad prior $n\_{\rm s}=0.96\pm 0.02$; results are only weakly sensitive to this choice, within plausible bounds.
* $\bullet$

  A top-hat prior is used for the reduced Hubble constant, $0.4<h<1$. This limits the extent of the parameter degeneracy, but does not affect the results over the region of interest for joint constraints.

In addition to the priors above, we adopt the same sampling priors and methodology as [Planck Collaboration
XIII (2016)](#bib.bib46),⁢
†
†
†​†††⁢
†
†
†​†††
$††$
For example, we split the neutrino component into approximately two massless neutrinos and one with $\sum m\_{\nu}=0.06\thinspace\rm{eV}$, by default.
using CosmoMC and camb for sampling and theoretical predictions ([Lewis & Bridle 2002](#bib.bib26); [Lewis et al. 2000](#bib.bib29)).
In the $\Lambda$CDM model, as well as $\Omega\_{\rm b}h^{2}$ and $n\_{\rm s}$, we sample $A\_{\rm s}$, $\Omega\_{\rm c}h^{2}$, and the (approximate) acoustic-scale parameter $\theta\_{\rm MC}$. Alternatively, we can think of our lensing-only results as constraining the sub-space of $\Omega\_{\rm m}$, $H\_{0}$, and $\sigma\_{8}$. Figure [7](#S3.F7 "Figure 7 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") shows the corresponding constraints from CMB lensing, along with tighter constraints from combining with additional external baryon acoustic oscillation (BAO) data, compared to the constraints from the Planck CMB power spectra. The contours overlap in a region of acceptable Hubble constant values, and hence are compatible. To show the multi-dimensional overlap region more clearly, the red contours show the lensing constraint when restricted to a reduced-dimensionality space with $\theta\_{\rm MC}$ fixed to the value accurately measured by the CMB power spectra; the intersection of the red and black contours gives a clearer visual indication of the consistency region in the $\Omega\_{\mathrm{m}}$–$\sigma\_{8}$ plane.

The lensing-only constraint defines a band in the $\Omega\_{\mathrm{m}}$–$\sigma\_{8}$ plane, with the well-constrained direction corresponding approximately to the constraint

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}=0.591\pm 0.021\quad(\text{lensing only; 68\thinspace\%}).$ |  | (13) |

This parameter combination is measured with approximately $3.5\%$ precision.

The dependence of the lensing potential power spectrum on the parameters of the $\Lambda$CDM model is discussed in detail in Appendix [E](#A5 "Appendix E Parameter dependence of 𝐶_𝐿^{ϕ⁢ϕ} in ΛCDM models ‣ Planck 2015 results. XV. Gravitational lensing"); see also [Pan et al. (2014)](#bib.bib35). Here, we aim to use simple physical arguments to understand the parameter degeneracies of the lensing-only constraints.
In the flat $\Lambda$CDM model, the bulk of the lensing signal comes from high redshift ($z>0.5$) where the Universe is mostly matter-dominated (so potentials are nearly constant), and from lenses that are still nearly linear. For fixed CMB (monopole) temperature, baryon density, and $n\_{\rm s}$, in the $\Lambda$CDM model the broad shape of the matter power spectrum is determined mostly by one parameter, $k\_{\rm eq}\equiv a\_{\rm eq}H\_{\rm eq}\propto\Omega\_{\mathrm{m}}h^{2}$. The matter power spectrum also scales with the primordial amplitude $A\_{\rm s}$; keeping $A\_{\rm s}$ fixed, but increasing $k\_{\rm eq}$, means that the entire spectrum shifts sideways so that lenses of the same typical potential depth $\Psi\_{\rm lens}$ become smaller.
Theoretical $\Lambda$CDM models that keep $\ell\_{\rm eq}\equiv k\_{\rm eq}\thinspace\chi\_{\*}$ fixed will therefore have the same number (proportional to $k\_{\rm eq}\thinspace\chi\_{\*}$) of lenses of each depth along the line of sight,
and distant lenses of the same depth will also maintain the same angular correlation on the sky, so that the shape of the spectrum remains roughly constant. There is therefore a shape and amplitude degeneracy where $\ell\_{\rm eq}\approx\text{constant}$, $A\_{\rm s}\approx\text{constant}$, up to corrections from sub-dominant changes in the detailed lensing geometry, changes from late-time potential decay once dark energy becomes important, and nonlinear effects.
In terms of standard $\Lambda$CDM parameters around the best-fit model, $\ell\_{\rm eq}\propto\Omega\_{\mathrm{m}}^{0.6}h$, with the power-law dependence on $\Omega\_{\mathrm{m}}$ only varying slowly with $\Omega\_{\mathrm{m}}$; the constraint $\ell\_{\rm eq}\propto\Omega\_{\mathrm{m}}^{0.6}h=\text{constant}$ defines the main dependence of $H\_{0}$ on $\Omega\_{\mathrm{m}}$ seen in Fig. [7](#S3.F7 "Figure 7 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing").

The argument above for the parameter dependence of the lensing power spectrum ignores the effect of baryon suppression on the small-scale amplitude of the matter power spectrum (e.g. [Eisenstein & Hu 1998](#bib.bib11)).
As discussed in Appendix [E](#A5 "Appendix E Parameter dependence of 𝐶_𝐿^{ϕ⁢ϕ} in ΛCDM models ‣ Planck 2015 results. XV. Gravitational lensing"), this introduces an explicit dependence of the lensing power spectrum on $\Omega\_{\rm m}h^{2}$. However, since the parameter dependence of $\ell\_{\rm eq}$ is close to
$(\Omega\_{\mathrm{m}}h^{2})^{1/2}$, we can still think of $A\_{\rm s}$ and $\ell\_{\rm eq}$ as giving the
dominant dependence of $C\_{L}^{\phi\phi}$ on parameters.

In practice the shape of $C\_{L}^{\phi\phi}$ is not measured perfectly, and there is also some degeneracy between $A\_{\rm s}$, which directly increases the amplitude, and $\ell\_{\rm eq}$, which increases the amplitude via an increase in the number of lenses along the line of sight and indirectly by changing the depth of potential wells of a given size. On small angular scales with $L>\ell\_{\rm eq}$,
$\Psi\_{\rm lens}$ becomes a strong function of scale due to the fall-off in the matter power spectrum for $k>k\_{\rm eq}$. For a fixed comoving scale, the amplitude increases if $k\_{\rm eq}$ becomes larger since this reduces the amount of decay of the gravitational potential during radiation domination ([Pan et al. 2014](#bib.bib35)), and also lessens the impact of baryon suppression. This increases the dependence of $C\_{L}^{\phi\phi}$ on $\ell\_{\rm eq}$ beyond the linear scaling from the number of lenses, and on small scales $L^{4}C\_{L}^{\phi\phi}\propto A\_{\rm s}\ell\_{\rm eq}^{1+n\_{L}}$, where $n\_{L}>0$ determines the actual $L$-dependence (inherited from the scale dependence of the small-scale matter power spectrum and the effect of baryon suppression).
For Planck, the lensing spectrum is best measured at $L\sim 200$: since $n\_{L}$ increases with $L$, making $A\_{\rm s}$ larger and $\ell\_{\rm eq}^{1+n\_{200}}$ smaller to keep the power constant at $L\sim 200$ leads to an increase in power at lower $L$ and a decrease in power at higher $L$ (see Fig. [8](#S3.F8 "Figure 8 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")).
The lensing amplitude at the peak $L\approx 50$ (and hence the rms deflection angle), is therefore slightly anti-correlated with the amount of small-scale power (as shown by the lensing only constraint in Fig. [9](#S3.F9 "Figure 9 ‣ 3.5.2 Joint parameter constraints ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing"); see discussion below).

Figure 8: 
Lensing potential power spectra in the base $\Lambda$CDM model drawn from the posterior of the lensing-only likelihood (left) and the Planck TT+lowP likelihood (right), coloured by the value of the dark matter density $\Omega\_{\mathrm{c}}h^{2}$. For fixed CMB power spectra (i.e. the right-hand plot) the
lensing power spectrum shape is nearly fixed, but the amplitude increases as the matter density increases across the acoustic-scale degeneracy (the accompanying reduction in $A\_{\rm s}$ is sub-dominant). With lensing reconstruction data, as $\Omega\_{\mathrm{c}}h^{2}$ varies the lensing spectrum changes shape, with the amplitude around the best-measured $L\approx 150$, remaining pinned by the accuracy of the measurement there. A combination of the lensing and Planck TT+lowP data measures the matter density significantly better, with the higher values in the right-hand plot being excluded. Note that the colour scales on the plots are different.

The actual three-parameter constraint is close to

|  |  |  |  |
| --- | --- | --- | --- |
|  | $A\_{\rm s}\left(\Omega\_{\mathrm{m}}^{0.6}h\right)^{2.3}\propto A\_{\rm s}\ell\_{\rm eq}^{2.3}\propto\text{constant}\pm 3\thinspace\%,$ |  | (14) |

which, in terms of $A\_{\rm s}$, $\ell\_{\rm eq}$, and $h$ is independent of $h$, as expected, given the parameter dependence of $C\_{L}^{\phi\phi}$ discussed above.
Recall that the fairly high power-law dependence with $\ell\_{\rm eq}$ comes from the rapid fall-off in the matter power spectrum with scale (and from the dependence on $\Omega\_{\rm m}h^{2}$ of baryon suppression effects).
Approximately the same scaling will also affect other measures of small-scale power, for example $\sigma\_{8}$.
From Eq. ([94](#A5.E94 "Equation 94 ‣ E.1 Normalization by 𝜎_8 ‣ Appendix E Parameter dependence of 𝐶_𝐿^{ϕ⁢ϕ} in ΛCDM models ‣ Planck 2015 results. XV. Gravitational lensing")), for parameter values of interest $\sigma\_{8}$ and $A\_{\rm s}$ are related approximately by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma\_{8}^{2}\Omega\_{\mathrm{m}}^{0.6}\propto A\_{\rm s}\ell\_{\rm eq}^{3.5}.$ |  | (15) |

The parameter direction $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}=\text{constant}$ is therefore close to the direction in which $A\_{\rm s}$ (and hence $L^{4}C\_{L}^{\phi\phi}$) is constant for fixed $\ell\_{\rm eq}$. The combination $A\_{\rm s}\ell\_{\rm eq}^{3.5}$ is also not that far from $A\_{\rm s}\ell\_{\rm eq}^{2.3}$ of Eq. ([14](#S3.E14 "Equation 14 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")), which remains nearly constant as $\ell\_{\rm eq}$ and $A\_{\rm s}$ vary within their degeneracy. The $\sigma\_{8}\Omega\_{\mathrm{m}}^{1/4}$ degeneracy direction shown in Fig. [7](#S3.F7 "Figure 7 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") and the constraint of Eq. ([13](#S3.E13 "Equation 13 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")) are therefore significantly tighter than the corresponding constraint in the $A\_{\rm s}$–$\Omega\_{\mathrm{m}}$ plane, because $\sigma\_{8}$ absorbs some of the degeneracy between matter density and primordial power at a fixed scale.

In terms of $\sigma\_{8}$, a well-determined three-parameter combination is⁢
‡
‡
‡​‡‡‡⁢
‡
‡
‡​‡‡‡
$‡‡$
This direction differs from that in Eq. ([14](#S3.E14 "Equation 14 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")), since the orthogonal direction in the $A\_{\rm s}$–$\ell\_{\rm eq}$ plane is not that much worse constrained, so the Fisher information in the three-parameter space is not fully dominated by a single direction.

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}\left(\Omega\_{\mathrm{m}}h^{2}\right)^{-0.37}=1.228\pm 0.028\quad(\text{lensing only; 68\thinspace\%}),$ |  | (16) |

at $2.3\%$ precision. In terms of power, the $4.6\thinspace\%$ precision of the square of this parameter combination is still weaker than the template amplitude measurement of Eq. ([11a](#S3.E11.1 "Equation 11a ‣ Equation 11 ‣ 3.4 Lensing potential power spectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")). This is expected, given the approximation of a power-law fit, and that in Eq. ([16](#S3.E16 "Equation 16 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")) we have also marginalized over variations in $n\_{\rm s}$ and $\Omega\_{\mathrm{b}}h^{2}$.
Marginalizing out the $\Omega\_{\mathrm{m}}h^{2}$ dependence in Eq. ([16](#S3.E16 "Equation 16 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")), the constraint on $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}$ of Eq. ([13](#S3.E13 "Equation 13 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")) is further degraded to $3.5\thinspace\%$.

We can also quantify the amplitude of lensing by the rms deflection angle $\langle d^{2}\rangle^{1/2}$, which we define via

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\langle d^{2}\rangle\equiv\sum\_{L=2}^{2000}\frac{(2L+1)}{4\pi}L(L+1)C\_{L}^{\phi\phi}.$ |  | (17) |

This is approximately an integral over all scales. It is proportional to the primordial fluctuation power $A\_{\rm s}$, and scales roughly as a power law in $\ell\_{\rm eq}$. A simple argument based on the number of lenses along the line of sight would suggest $\langle d^{2}\rangle\propto A\_{\rm s}\ell\_{\rm eq}$. This is almost correct, in particular the strong dependence of $C\_{L}^{\phi\phi}$ on $\ell\_{\rm eq}$ integrates out when forming $\langle d^{2}\rangle$ (see Eq. [78](#A5.E78 "Equation 78 ‣ Appendix E Parameter dependence of 𝐶_𝐿^{ϕ⁢ϕ} in ΛCDM models ‣ Planck 2015 results. XV. Gravitational lensing")). However, there is a further dependence on $\Omega\_{\rm m}$ and $h$ due to the effects of baryon suppression and the late-time decay of the gravitational potential, which is important at low-$L$; we find approximately

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\langle d^{2}\rangle\propto A\_{\rm s}\ell\_{\rm eq}(\Omega\_{\rm m}h)^{1/5},$ |  | (18) |

by taking derivatives of $C\_{L}^{\phi\phi}$ computed with CAMB.
The rms is measured at $2.4\thinspace\%$ precision to be

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\langle d^{2}\rangle^{1/2}=(2.46\pm 0.06)\thinspace\text{arcmin}\quad(\text{lensing only; 68\thinspace\%}).$ |  | (19) |

So far we have only considered a $\Lambda$CDM model. However, for most generalizations that are close to $\Lambda$CDM, the same scaling also approximately holds, and the constraint direction of $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}$ is only weakly model-dependent, although the centroid can shift and also the relation between $\Omega\_{\mathrm{m}}$ and $h$. For example, for a model with massless sterile neutrinos parameterized by $N\_{\rm eff}$, the constraint of Eq. ([13](#S3.E13 "Equation 13 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")) is virtually identical, but parameter samples shift towards systematically higher $\Omega\_{\mathrm{m}}h^{2}$ than in $\Lambda$CDM to keep the equality scale roughly constant when $N\_{\rm eff}>3.046$. As a further example, in models with three massive (active) neutrinos with degenerate masses, marginalizing over the mass of massive neutrinos shifts the constraint slightly down, giving

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}=0.566\pm 0.025\quad(\text{$\Lambda$CDM+$\Sigma m\_{\nu}$, lensing only; 68\thinspace\%}).$ |  | (20) |

Note that in the neutrino case non-linear corrections from halofit are unreliable away from $\Omega\_{\mathrm{m}}\approx 0.3$, which can affect this result at around the $0.01$ level.

#### 3.5.2 Joint parameter constraints

The small-scale CMB power spectra are only directly sensitive to the primordial power $A\_{\rm s}$ after damping by reionization, through the combination $A\_{\rm s}e^{-2\tau}$. However lensing also smooths the power spectra at the several percent level, which allows the amplitude $A\_{\rm s}$ to be constrained via the amplitude of the smoothing effect (and a small transfer of power to small scales), even when $\tau$ is not constrained precisely.∗
⁣
∗
∗⁣∗\*\*∗
⁣
∗
∗⁣∗\*\*
$\*\*$
The smoothing effect of lensing in the Planck $TT$ power spectrum is detected at around $10\thinspace\sigma$ ([Planck Collaboration
XIII 2016](#bib.bib46)). It is also detected at lower significance in the polarization power spectra.
The lensing smoothing can be thought of as approximately a convolution of the deflection angle power spectrum with the CMB power spectrum, and hence is mostly sensitive to scales around the peak of the deflection angle power spectrum.
We can quantify the amplitude of the smoothing approximately by the mean-squared deflection angle $\langle d^{2}\rangle$ from Eq. ([17](#S3.E17 "Equation 17 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")).

Figure 9: 
Constraints on the rms lensing deflection angle $\langle d^{2}\rangle^{1/2}$ from Planck TT+lowP CMB power spectra in the base $\Lambda$CDM model (samples, colour coded by the value of the Hubble constant), showing that the inferred lens deflection amplitude is strongly correlated with the parameter combination $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}$. The solid black contour is the constraint from CMB lensing only, which prefers lower values of the lensing amplitude, giving the joint constraint shown by the red contours. Since the lensing reconstruction mainly constrains scales smaller than the peak of the deflection angle power spectrum,
there is an additional degeneracy that makes $\langle d^{2}\rangle^{1/2}$ slightly anti-correlated with the measurement of lensing power on smaller scales, which is approximately proportional to (the square of) $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}$

The CMB power spectra determine the angular acoustic scale $\theta\_{\ast}$ very accurately, which can be used to eliminate the $h$-dependence from $\langle d^{2}\rangle$, considered as a function $\sigma\_{8}$, $h$, and $\Omega\_{\mathrm{m}}$. Empirically, we find that in the $\Lambda$CDM model the CMB power spectrum posterior has $\langle d^{2}\rangle^{1/2}\propto\sigma\_{8}\Omega\_{\mathrm{m}}^{0.2}$, close to the $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}$ combination measured more directly by lensing reconstruction;∗
†
∗†\*†∗
†
∗†\*†
$\*†$
The empirical parameter dependence of $\langle d^{2}\rangle^{1/2}$ on $\Omega\_{\mathrm{m}}$ for samples from the CMB power spectrum posterior differs from what one would infer from Eqs. ([15](#S3.E15 "Equation 15 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")) and ([18](#S3.E18 "Equation 18 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")). These equations assume fixed $n\_{\rm s}$ and $\Omega\_{\mathrm{b}}h^{2}$, which is appropriate for our lensing-only constraints with the assumed priors, but for the CMB samples the fractional dispersion in $n\_{\rm s}$ and $\Omega\_{\mathrm{b}}$ is comparable to that in $\sigma\_{8}$, $h$, and $\Omega\_{\mathrm{m}}$ and so cannot be neglected.
see Fig. [9](#S3.F9 "Figure 9 ‣ 3.5.2 Joint parameter constraints ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing").
For a flat $\Lambda$CDM model the constraint on the latter parameter is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}=0.621\pm 0.013\quad(\text{{Planck}\ TT+lowP; 68\thinspace\%}).$ |  | (21) |

The amplitude information here is coming from a combination of the lensing smoothing effect, and information from the CMB power spectrum amplitude combined with the constraint on $\tau$ from low-$\ell$ polarization. The lensing-only constraint of Eq. ([15](#S3.E15 "Equation 15 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing")) is slightly weaker, but somewhat lower than this (consistent at just over $1\thinspace\sigma$); see Fig. [7](#S3.F7 "Figure 7 ‣ 3.5.1 Constraints from CMB lensing alone ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing").
The combined constraint is tighter and restricted to slightly lower values compared to the Planck power spectrum measurement:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}=0.609\pm 0.007\quad(\text{{Planck}\ TT+lowP+lensing; 68\thinspace\%}).$ |  | (22) |

Here, for joint constraints we no longer apply the additional priors used in the lensing-only analysis, and allow for the full linearized CMB power spectrum dependence of the lensing renormalization in the likelihood. The overlap region in the $\Omega\_{\mathrm{m}}$–$\sigma\_{8}$ plane also excludes some of the lower Hubble constant values allowed by the power spectrum data, giving a slight shift of the mean in the direction of the higher values preferred by some local measurements ([Riess et al. 2011](#bib.bib52); [Humphreys et al. 2013](#bib.bib24); [Efstathiou 2014](#bib.bib10)), as shown in Fig. [9](#S3.F9 "Figure 9 ‣ 3.5.2 Joint parameter constraints ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing"). This could be an additional indication that the lower Hubble constant values from the CMB spectra are at least partly a random statistical fluctuation, in which case joint constraints should be usefully closer to the truth. The joint constraint gives

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle H\_{0}$ | $\displaystyle=(67.8\pm 0.9)\thinspace{\rm km}\thinspace{\rm s}^{-1}\thinspace{\rm Mpc}^{-1}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\hskip 51.7479pt(\text{{Planck}\ TT+lowP+lensing; 68\thinspace\%}),$ |  | (23) |

about $0.5\thinspace\sigma$ higher than Planck TT+lowP alone, and in good agreement with the constraint from Planck TT+lowP+BAO data.

The measurement of the fluctuation amplitude from lensing, combined with the amplitude of the CMB power spectrum on intermediate and small scales,
can also be used to constrain the reionization optical depth independently of low-$\ell$ polarization. The CMB power spectra themselves provide a weak constraint via the lensing smoothing, which is significantly improved by using the additional information in the lensing reconstruction.
Figure [10](#S3.F10 "Figure 10 ‣ 3.5.2 Joint parameter constraints ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") shows the constraint when Planck CMB temperature power spectrum constraints, without low-$\ell$ polarization, are combined with the lensing likelihood. We find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\tau=0.070\pm 0.024\quad(\text{{Planck}\ TT+lensing; 68\thinspace\%}),$ |  | (24) |

corresponding to a detection of a non-zero optical depth at more than $2\thinspace\sigma$,
and a corresponding reionization redshift $z\_{\rm re}=9.0^{+2.5}\_{-2.1}$ (68%). These results are consistent with the baseline Planck power spectrum constraints including low-$\ell$ polarization, which give $\tau=0.078\pm 0.019$ (Planck TT+lowP; 68%). Both results indicate a consistent downward shift in mean compared to the central value from WMAP ($\tau=0.089\pm 0.014$; [Hinshaw et al. 2013](#bib.bib19)), in agreement with lower predicted values based on recent results for the integrated luminosity function (e.g. [Finkelstein et al. 2015](#bib.bib13)). There is a corresponding downward shift in $\sigma\_{8}$, with joint constraint

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma\_{8}=0.815\pm 0.009\quad(\text{{Planck}\ TT+lowP+lensing; 68\thinspace\%}).$ |  | (25) |

For further discussion see [Planck Collaboration
XIII (2016)](#bib.bib46).

Figure 10: 
Constraints on the reionization (mid-point) redshift $z\_{\rm re}$ and $\sigma\_{8}$ from a combination of Planck CMB power spectra and the lensing reconstruction, excluding low-$\ell$ polarization information. The grey band denotes the approximate $z\_{\rm re}<6.5$ region excluded by observations of the spectra of high-redshift quasars ([Fan et al. 2006](#bib.bib12)).
The lensing data significantly shrink the allowed region of parameter space, preferring lower values of the reionization redshift, in good agreement with the measurement from Planck low-$\ell$ polarization.

#### 3.5.3 Constraints on extensions to the $\Lambda$CDM model

Figure 11:  Constraints on the curvature and rms lensing deflection angle from Planck TT+lowP CMB power spectra (samples, colour coded by the value of the Hubble constant), showing that the closed-universe models favoured at the $2\thinspace\sigma$ level have high lensing power that is inconsistent with the lensing reconstruction result. The combined lensing result (black contours) is much tighter, and provides additional information on top of the constraint when adding BAO data (red contours); both joint constraints, and the combined filled contours, are consistent with a flat universe.

The CMB power spectra only weakly constrain extended models that provide multiple ways to combine late-time parameters to give the same observed angular diameter distance to recombination. The main Planck CMB power spectrum constraints on these parameters are driven largely by the impact of lensing smoothing on the acoustic peaks, which weakly breaks the geometric degeneracy. As discussed in detail in [Planck Collaboration
XIII (2016)](#bib.bib46), the power spectrum results appear to prefer larger lensing smoothing than in $\Lambda$CDM (in this release, slightly above the $2\thinspace\sigma$ level). It is therefore particularly useful to study joint constraints with the lensing likelihood, which constrains the lensing amplitude more directly and more tightly. Since the lensing-reconstruction power spectrum has an amplitude that peaks slightly lower than the $\Lambda$CDM predictions from the CMB power spectra, the joint constraint eliminates a large region of parameter space with positive curvature allowed by the power spectrum results. For example, Fig. [11](#S3.F11 "Figure 11 ‣ 3.5.3 Constraints on extensions to the ΛCDM model ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") shows the constraints on the curvature parameter $\Omega\_{K}$ in non-flat models; the high lensing amplitudes, as show in the figure by the rms deflection angle, are ruled out by the lensing reconstruction, and the joint constraint is consistent with a flat universe ($\Omega\_{K}=0$). The improvement in error bars is dramatic, with the CMB power spectra giving

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Omega\_{K}=-0.052^{+0.03}\_{-0.02}\quad(\text{{Planck}\ TT+lowP; 68\thinspace\%}),$ |  | (26) |

and the joint constraint

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Omega\_{K}=-0.005^{+0.009}\_{-0.007}\quad(\text{{Planck}\ TT+lowP+lensing; 68\thinspace\%}).$ |  | (27) |

This measurement of curvature from the CMB alone has sub-percent precision.
External data can also break the geometric degeneracy; the joint BAO contours are shown in Fig. [11](#S3.F11 "Figure 11 ‣ 3.5.3 Constraints on extensions to the ΛCDM model ‣ 3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") and are consistent. Since the BAO results are independent of fluctuation amplitude, the lensing-reconstruction joint constraint adds significant additional information, shrinking the allowed parameter space compared to Planck+BAO alone.

In addition to curvature, CMB results for dark energy models also suffer a geometric degeneracy, and lensing results can similarly provide additional information; for applications to a variety of dark energy models and modified gravity see [Planck Collaboration
XIV (2016)](#bib.bib47).
Lensing can also improve the limits on many other parameters, though in a less dramatic fashion if the CMB power spectra are themselves able to place a good constraint. Full results for many combinations are available online in the grid tables and parameter chains.∗
‡
∗‡\*‡∗
‡
∗‡\*‡
$\*‡$
<http://www.cosmos.esa.int/web/planck/pla>

#### 3.5.4 Sensitivity to $L$-range

The results in the previous subsections were obtained using our conservative baseline likelihood, with eight bins in the multipole range $40\leq L\leq 400$. We now briefly discuss how joint constraints from the Planck power spectra and lensing change for different cuts of the lensing data.

Using the first nine bins of the aggressive binning described in Table [1](#S3.T1 "Table 1 ‣ 3.4 Lensing potential power spectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing"), covering $8\leq L\leq 425$, results from Planck TT+lowP+lensing are consistent at the $0.1\thinspace\sigma$ level with the conservative likelihood, in both $\Lambda$CDM and $\Lambda$CDM$+\sum m\_{\nu}$ cosmologies. Extending the range to higher $L$, the Planck TT+lensing constraint on the optical depth is stable, however the measured amplitude $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}$ shifts downwards by about $1\thinspace\sigma$ with a negligible change in the uncertainty.
About half of this comes from including the outlying bin at $638\leq L\leq 762$. In the $\Lambda$CDM+$\sum m\_{\nu}$ model, this preference for lower amplitudes on smaller scales pulls joint neutrino mass constraints up by about $1\thinspace\sigma$. The baseline result is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sum m\_{\nu}<0.145\thinspace{\rm eV}\quad(\text{{Planck}\ TT+lowP+lensing+BAO; 68\thinspace\%}),$ |  | (28) |

but using the full $L$-range the posterior peaks slightly (though not significantly) away from zero:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\sum m\_{\nu}$ | $\displaystyle=0.16^{+0.08}\_{-0.11}\thinspace{\rm eV}\quad(\text{{Planck}\ TT+lowP+aggressive lensing}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\hskip 198.37395pt\text{+BAO; 68\thinspace\%}).$ |  | (29) |

As discussed in Sect. [4](#S4 "4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing"), the multipole range $300\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}L\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}900$ may be unreliable, specifically due the failure of the $TTTT$ curl test. A priority for future analysis should be to develop a trustworthy likelihood over the full multipole range.

## 4 Consistency and null tests

With multiple frequency bands and the combination of both temperature and polarization data,
the Planck full-mission data set provides many opportunities to test internally the lens reconstruction.
In this section we present consistency and null tests for the MV lensing potential presented in Sect. [3](#S3 "3 Results ‣ Planck 2015 results. XV. Gravitational lensing").

For consistency tests, we perform lens reconstruction using different data/analysis choices than those used for our fiducial MV reconstruction,
obtaining an alternative measurement of the lensing potential power spectrum
$\hat{C}\_{L}^{\phi\phi}|\_{\rm test}$, which we then compare to the baseline MV reconstruction.
To compare the test and MV reconstructions more quantitatively, we use a $\chi^{2}$ statistic for the difference between the bandpowers, which is calculated as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\chi^{2}\_{\rm test}={\cal B}\_{i}^{L}\left(\left.\hat{C}\_{L}^{\phi\phi}\right|\_{\rm test}-\left.\hat{C}\_{L}^{\phi\phi}\right|\_{\rm MV}\right)\left[\Sigma^{-1}\_{\rm test}\right]^{ij}{\cal B}\_{j}^{L^{\prime}}\left(\left.\hat{C}\_{L^{\prime}}^{\phi\phi}\right|\_{\rm test}-\left.\hat{C}\_{L^{\prime}}^{\phi\phi}\right|\_{\rm MV}\right),$ |  | (30) |

where $\Sigma\_{\rm test}$ is a diagonal covariance matrix for the difference obtained from simulations of the two lens reconstructions.
We compare this $\chi^{2}$ to a set of values determined from simulations, to estimate a PTE.
We do this for several possible choices of binning: a single bin
for either the conservative ($40\leq L\leq 400$) likelihood range, or the low-$L$ and high-$L$ ranges ($8\leq L<40$ and $400<L\leq 2048$, respectively) that are additionally included in the aggressive likelihood; and the individual bins that span the conservative and high-$L$ multipole ranges.
The single-bin tests check for broad-band differences between the two reconstructions, while the multiple-bin tests provide a more sensitive check on shape differences or inaccuracies in the error bars for the two reconstructions.

Figure 12: 
Summary of lensing power spectrum consistency tests.
Upper panel: comparison of the lensing power spectra for the baseline MV reconstruction and several alternative estimators with different data/analysis choices discussed in the text.
Lower panels: detailed plots of the difference between each alternative reconstruction and the MV power spectrum, in units of the MV error bars ($\sigma$).
The $\pm 1\sigma$ band is indicated in grey.
Error bars on individual data points give the standard deviation of the expected difference from the MV reconstruction for each case, estimated using Monte Carlo simulations.

We group the consistency tests as follows, based on the issues which they are designed to probe.

* $\bullet$

  ‘Individual estimator crosses’ that test for consistency among the five quadratic estimators used to measure $\phi$.
* $\bullet$

  ‘Foregrounds tests’ that use single-frequency maps or different component-separation methods to test for possible foreground contamination.
* $\bullet$

  ‘Noise tests’ that check that our power spectrum estimates are not biased by instrumental noise, using cross-estimators designed to avoid noise biases.
* $\bullet$

  ‘Analysis choices’ that test our sensitivity to choices such as the unmasked sky fraction and multipole range.
* $\bullet$

  ‘Bias-hardened estimators’ in which we use lensing estimators that should be less sensitive to certain systematic and instrumental effects.

In Fig. [12](#S4.F12 "Figure 12 ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") we plot several of the most important consistency tests, as well as their difference from the MV reconstruction.
The $\chi^{2}$ values associated with the full set of consistency tests are presented in Table [2](#S4.T2 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing").
The tests themselves are described in more detail in Sects. [4.1](#S4.SS1 "4.1 Individual estimator crosses ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing")–[4.5](#S4.SS5 "4.5 Bias-hardened estimators ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing").

In addition to consistency tests, we also perform several null tests in which we apply our lens reconstruction and power spectrum estimation
procedure to maps that have been differenced to remove sky signal, or use curl-mode lensing estimators that should have zero contribution from the gradient lensing potential.
We check that the overall amplitude
(for a template given by the fiducial theory spectrum $C\_{L}^{\phi\phi,{\rm fid}}$)
is consistent with zero, and also evaluate a $\chi^{2}$ computed as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\chi^{2}\_{\rm null}={\cal B}\_{i}^{L}\left(\left.\hat{C}\_{L}^{\phi\phi}\right|\_{\rm test}\right)\left[\Sigma^{-1}\_{\rm null}\right]^{ij}{\cal B}\_{j}^{L^{\prime}}\left(\left.\hat{C}\_{L^{\prime}}^{\phi\phi}\right|\_{\rm test}\right),$ |  | (31) |

where $\Sigma\_{\rm null}$ is a diagonal covariance matrix measured from simulations of the particular null test.
A PTE for each null test is computed by comparison to simulations in the same way as for the consistency tests.
The null power spectra are plotted in Fig. [13](#S4.F13 "Figure 13 ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing"), and summary statistics are given in Table [3](#S4.T3 "Table 3 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing").
The null tests are discussed in more detail in Sect. [4.6](#S4.SS6 "4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing").

Figure 13: 
Power spectrum null tests discussed in Sect. [4.6](#S4.SS6 "4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing").
Curl null tests are denoted by $\psi$.
The individual null test power spectra have been scaled by the factors indicated in each panel for visual purposes. The fiducial (gradient-mode) lensing power spectrum is shown as the dashed line in each panel.

### 4.1 Individual estimator crosses

With the foreground-cleaned temperature and polarization maps from SMICA we can form five distinct lensing estimators,
and 15 distinct auto- and cross-spectra. We plot all of these spectra individually in Fig. [14](#S4.F14 "Figure 14 ‣ 4.1 Individual estimator crosses ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing").

Figure 14: 
Grid of lensing potential power spectra for the 15 possible auto- and cross-spectra of the five quadratic lensing estimators obtained from the SMICA foreground-cleaned maps.
The measurements are arranged in order of their total $S/N$ for a measurement of the lensing amplitude.
The MV power spectrum estimate, which combines the individual cross-spectra and is the basis for our fiducial lensing likelihood, is plotted in the top-left panel.

The lensing amplitudes, as well as PTEs for the differences from the MV reconstruction are given in Table [2](#S4.T2 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing").
There is a wide variation in the sensitivity of the different estimators, although we see high
(greater than $5\thinspace\sigma$ significance)
detections of lensing in nine of the spectra.∗
§
∗§\*§∗
§
∗§\*§
$\*§$
In the 2015 Planck data release, there is some evidence in the polarization
power spectra for uncorrected systematic effects associated with
temperature-to-polarization
leakage ([Planck Collaboration
XIII 2016](#bib.bib46); [Planck Collaboration
XI 2016](#bib.bib44)). Although we find no
evidence for inconsistencies in the polarization-based lens reconstructions, the
statistical errors are large and may obscure small systematic effects
that are subdominant for the current analysis. Leakage from the
CMB temperature anisotropies could impact the lensing analysis in
several ways. First, the disconnected (Gaussian) part of the CMB
4-point function is modified, and this would affect both our
mean-field and N0 corrections (see
Appendices [A.2](#A1.SS2 "A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")
and [A.3](#A1.SS3 "A.3 Power spectrum estimation ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")). These corrections are made using a mix
of data and simulations, such that even if the simulations do not
fully capture the leakage (note they do include leakage due to
main-beam mismatch, for example), the additive bias to the lensing
power spectrum is only second-order in any unmodelled effects. The
second way that leakage can affect the lensing power spectrum is
through changes to the lensing response functions in
Eq. ([45](#A1.E45 "Equation 45 ‣ A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")), which propagate through to normalization
errors. This should be partially captured by a Monte-Carlo correction
that we make to the lensing power spectrum. We have not attempted to
quantify more carefully any residual effects of
temperature-to-polarization leakage, since, ultimately, the
polarization data carries relatively little weight in our final MV reconstruction.

As a further test, we combine several of the spectra with the highest $S/N$ that only use estimator crosses
($TT\times EE$, $TT\times TE$, $TT\times EB$, and $EE\times TE$) into a single ‘crosses’ estimator.
This combination of cross-spectra has an order-of-magnitude smaller disconnected noise bias correction than the auto-spectrum of the fiducial MV estimator,
with
$\Delta\hat{A}^{N0,\ \rm Crosses}\_{8\rightarrow 2048}=0.4$,
compared to
$\Delta\hat{A}^{N0,\ {\rm MV}}\_{8\rightarrow 2048}=4.3$ for the baseline MV lensing reconstruction.
The results of this test are presented in Fig. [12](#S4.F12 "Figure 12 ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") and Table [2](#S4.T2 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing").
With the crosses power spectrum estimates we are able to test that the lensing amplitude is not biased by errors in the disconnected noise bias correction
$\Delta C\_{L}^{\hat{\phi}\hat{\phi}}|\_{\textsc{N0}}$ at around the $2\%$ level.

We also form a combined power spectrum estimate using only polarization data (the $EE$ and $EB$ estimators).
This ‘Pol. only’ estimator gives an amplitude estimate for the conservative multipole range of
$\hat{A}=0.76\pm 0.15$, a $5\thinspace\sigma$ detection of lensing at a level consistent with the fiducial MV reconstruction.

### 4.2 Foreground tests

The SMICA CMB map that is used for our baseline MV reconstruction combines multiple frequency bands as a function of angular scale to reject foregrounds and to produce a single high-fidelity estimate of the CMB.
We can also compare to a simpler approach based on individual frequency maps, which we clean by subtracting a dust template.
Our baseline results in [Planck Collaboration
XVII (2014)](#bib.bib37) were based on this approach using 143 GHz and 217 GHz data, with the 857 GHz map
projected out during the filtering process as a dust template.
In this work we repeat this analysis. We use 857 GHz as a dust template in temperature, and no cleaning in polarization.
The results of this test are presented in Fig. [12](#S4.F12 "Figure 12 ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") and Table [2](#S4.T2 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") with the labels
‘143 GHz’ and ‘217 GHz’, where it can be seen that we obtain lensing bandpowers that are consistent with the MV reconstruction for the conservative multipole range.
In the simulations used to characterize these reconstructions,
we add coloured Gaussian noise to the 143 GHz and 217 GHz temperature map simulations, designed to mimic the power of unsubtracted extragalactic foregrounds.
For this we use the same source model used in [Planck Collaboration
XVII (2014)](#bib.bib37).
We also add Gaussian power to the polarization maps, designed to mimic the power due to Galactic dust contamination that can be seen on large angular scales.
The resulting temperature and polarization simulations have power spectra that agree with those of the data at the percent level in power.

We can also test the stability of the lensing reconstruction to the choice of the SMICA component-separation method over other alternatives such as NILC, SEVEM, and Commander.
The results of these comparisons are also shown in Table [2](#S4.T2 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing"); all are very consistent with the SMICA-based reconstruction over the conservative multipole range, although the PTEs for the overall amplitude at high-$L$ ($400<L\leq 2048$) are low for NILC and Commander.
For the SEVEM and Commander analyses, polarization maps were not available at the high resolution used here ($N\_{\rm side}=2048$), and so we have limited the comparisons to temperature only.

As a test of Galactic contamination, we also repeat our baseline analysis (performed on a fraction $f\_{\rm sky}=0.7$ of the sky) using a more aggressive ($f\_{\rm sky}=0.8$) and more conservative ($f\_{\rm sky}=0.6$) Galactic mask.
These masks are constructed by thresholding maps from the Planck high-frequency channels to achieve the desired sky fraction.
In Table [2](#S4.T2 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") we see that for both alternative sky fractions we estimate lensing bandpowers that are consistent with the baseline.

As a final and very powerful test of high-frequency foreground contamination, we also perform a lens reconstruction in which we use the 353 GHz map as one of the four legs in the trispectrum used to estimate $C\_{L}^{\phi\phi}$.
Based on the approximate frequency scaling of dust ([Gispert et al. 2000](#bib.bib14)) we expect that any dust foreground bias ‘$b\_{\rm dust}$’ to the lensing power spectrum estimate that we see in this test will scale roughly as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $b^{353}\_{\rm dust}\approx 7b^{217}\_{\rm dust}\approx 20b^{143}\_{\rm dust},$ |  | (32) |

and so this should provide a sensitive test for such contamination in the SMICA map.
The 353 GHz map has significantly more power than CMB+noise-only simulations,
due primarily to Galactic dust, and temperature fluctuations from the CIB.
To obtain reasonable error bars from the 353 GHz simulations used to characterize this reconstruction, as with the other reconstructions
we add an isotropic Gaussian sky signal designed to match the simulation power spectrum to a smoothed power spectrum of the data.
When filtering the 353 GHz map, we use the same parameters as used for the SMICA map (except for the beam transfer function), to have the same weight given to different angular scales in the quadratic lensing estimators.
As with the 143 GHz and 217 GHz analyses, we project out the 857 GHz map as a dust template from the 353 GHz map in temperature, but make no attempt to subtract foreground contamination in polarization.
As can be seen in Fig. [12](#S4.F12 "Figure 12 ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") and Table [2](#S4.T2 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing"), we obtain good agreement between the ‘one leg 353 GHz’ reconstruction and the MV lensing power spectrum.
Lensing power is detected at
$20\thinspace\sigma$ even using 353 GHz as one of the four estimator legs.
The stability of the lens reconstruction in the presence of the foreground power at 353 GHz is very striking.
As a further test for the stability of the polarization-based lens reconstructions,
we can also use the ‘Pol. only’ estimator from Sect. [4.1](#S4.SS1 "4.1 Individual estimator crosses ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") with one leg given by the 353 GHz data.
This reconstruction is very noisy, however we do obtain an overall amplitude as well as bandpowers that are consistent with the MV ‘Pol. only’ reconstruction, as shown in Table [2](#S4.T2 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing").

### 4.3 Noise tests

As mentioned in Sect. [2](#S2 "2 Data and methodology ‣ Planck 2015 results. XV. Gravitational lensing"), the FFP8 simulations on which our results are based underestimate the noise power by several percent at high $\ell$.
We have dealt with this problem in our simulations by including isotropic Gaussian power to make up for the difference.
This neglects the fact that the missing noise component most likely has an anisotropic distribution (which could lead to errors in the mean-field subtraction),
and could be non-Gaussian as well.
To test that our treatment of the missing noise component is adequate, we have performed several tests.
Most stringently, we form quadratic lensing estimates using cross-correlation between pairs of maps with independent noise realizations.
We construct both a frequency cross $143\thinspace{\rm GHz}\times 217\thinspace{\rm GHz}$, as well as a cross between the first and second halves of the mission data.
These estimators have no noise mean field, and the lensing power spectrum estimated from them is insensitive to non-Gaussianity of the instrument noise.
The results of this analysis are given in Table [2](#S4.T2 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing"), where we see results that are consistent with the MV power spectrum estimate.

As an additional test, we have recreated the analysis of [Planck Collaboration
XVII (2014)](#bib.bib37), where the missing noise power was accounted for by scaling the noise component of the FFP8 simulations by a small factor.
This approach reasonably supposes that the anisotropy of the missing noise component is the same as that of the modeled component.
This test is labelled ‘Noise scaling’ in Table [2](#S4.T2 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing").
Again, we see a power spectrum measurement with an amplitude that is very similar to the MV estimate
(although we note that because the only difference in this test is the construction of the simulations that are used, the expected scatter between the ‘Noise scaling’ and baseline approaches is difficult to determine).

### 4.4 Analysis choices

We test the stability of our reconstruction to several analysis choices, re-running the baseline analysis implementing the following changes one at a time.

* $\bullet$

  Use a high-pass filter in temperature and polarization with
  $\ell\_{\rm min}\!=\!1000$
  rather than
  $\ell\_{\rm min}\!=\!100$, as adopted in the baseline analysis.
* $\bullet$

  Use a low-pass filter with
  $\ell\_{\rm max}\!=\!1500$
  rather than
  $\ell\_{\rm max}=2048$, as used in the baseline analysis.
* $\bullet$

  Apodize the lensing convergence estimate before power spectrum estimation, following the analysis in [Planck Collaboration
  XVII (2014)](#bib.bib37).
  This change reduces the size of the Monte Carlo correction, but does not produce a significant change in the lensing bandpower estimates.

The results of these tests are given in Table [2](#S4.T2 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing").

### 4.5 Bias-hardened estimators

Throughout this paper, we have used quadratic estimators optimized to detect the anisotropic covariance between CMB modes that is induced by (fixed) lensing.
These estimators are biased by non-lensing sources of such mode coupling,
including effects such as galaxy and point-source masking, inhomogeneous instrumental noise, and beam asymmetries.
As discussed in Sect. [2](#S2 "2 Data and methodology ‣ Planck 2015 results. XV. Gravitational lensing"),
we estimate these biases using Monte Carlo simulations and subtract them as a ‘mean-field’ contribution from the estimated lensing potential (as in Eq. [49](#A1.E49 "Equation 49 ‣ A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")).
A complementary method, which is less reliant on the quality of the Monte Carlo simulations used to perform this debiasing, is the bias-hardening procedure advocated by [Namikawa et al. (2013)](#bib.bib31).
In this approach, one constructs a new quadratic lensing estimator that is orthogonalized to worrisome sources of bias.
The construction of these estimators is reviewed in Appendix [B](#A2 "Appendix B Bias-hardened estimators ‣ Planck 2015 results. XV. Gravitational lensing").
In the analysis here we focus on temperature-only bias-hardened estimators to investigate the effects of bias-hardening,
because mean-field corrections are much smaller in polarization than in temperature.
We denote these estimators as $\hat{\phi}^{TT}-X$, where $X$ denotes the bias(es) that are orthogonalized against.
Here, we consider the biases due to masking ($M$), inhomogeneous noise ($N$), and the shot noise due to unresolved point sources ($S$).
As discussed in [Osborne et al. (2014)](#bib.bib34), the source-hardened estimator $\hat{\phi}^{TT}-S$ also reduces contamination from effects such as the cross-correlation between the unresolved sources and the lensing potential.

Figure 15: 
Upper:
power spectrum of the low-$L$ mean-field (measured from Monte Carlo simulations) for the $TT$ lensing estimator as well as several bias-hardened estimators.
The mean-field power spectrum of the $TE$ lensing estimator is plotted for comparison, and the fiducial lensing potential power spectrum is shown in dashed black.
To avoid visual clutter we have not shown the source-hardened estimator $TT-S$; its spectrum is midway between the noise-hardened ($TT-N$) and mask-hardened ($TT-M$) cases.
Lower:
power spectra of the differences between the $TT$ lensing estimate and the bias-hardened reconstructions or the $TE$ reconstruction (with the same colour scheme as in the top panel).
The expected power spectra of the differences, estimated from simulations, are plotted as black dotted lines.

Mean-field corrections are largest at low-$L$ (the power spectrum of the mean-field correction is larger than the fiducial lensing potential power spectrum for $L\la 100$),
and so we begin by looking closely at these scales.
In Fig. [15](#S4.F15 "Figure 15 ‣ 4.5 Bias-hardened estimators ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") we plot the power spectra of the mean-fields for each of the bias-hardened estimators.
In the lower panel we also plot the difference between each estimator and the non-bias-hardened $TT$ estimator.
For $L\geq 8$, we see agreement between all of the bias-hardened estimators and the non-bias-hardened reconstruction, regardless of the much smaller mean-field corrections for the former.
We have also used the bias-hardened estimators to measure the lensing potential power spectrum on smaller scales.
In Fig. [12](#S4.F12 "Figure 12 ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") and Table [2](#S4.T2 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing")
we report lensing bandpower estimates using the bias-hardened estimators, which we find to be consistent with the baseline MV reconstruction for $L\leq 400$.

### 4.6 Null tests

In addition to the consistency tests described above, we have also performed several direct null tests,
either using estimators or maps for which the lensing signal is expected to be zero.
These are plotted in Fig. [13](#S4.F13 "Figure 13 ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing"), and significance statistics for each are given in Table [3](#S4.T3 "Table 3 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing").
We discuss them in more detail below.

##### Half-ring difference:

The Planck observation strategy consists of scanning the sky in rings with an opening angle of approximately $85^{\circ}$.
Each scan ring is observed for between $39$ and $65$ minutes, and then the satellite is repointed.
This leads to a natural ‘half-ring’ null test in which we run our standard lensing estimator on the
half-difference of maps constructed from the
first and second half of each scanning ring, which should consist entirely of noise.
The PTE for the spectrum of the lensing reconstruction estimated from these half-ring difference maps is rather low for the conservative multipole range (see Table [3](#S4.T3 "Table 3 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing")). Since the maps should be only noise by construction, to obtain an acceptable $\chi^{2}$ for the power spectra of reconstructions based on such maps requires very good modeling of the instrument noise. As can be seen from the factor of 200 scaling applied in Fig. [13](#S4.F13 "Figure 13 ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing"), the impact on the reconstructed $\hat{C}\_{L}^{\phi\phi}$ of minor errors in the noise modeling that likely drive the low PTEs for the null test should be negligible.

##### Half-mission difference:

Noise that is correlated between rings (for example, due to glitches and destriping) can be nulled in the half-ring difference.
Another differencing approach, which avoids this problem, is to divide the entire mission into two halves that are then differenced.
This half-mission difference requires a slightly larger analysis mask, to account for the fact that the sky coverage is imperfect in both the first and second halves of the mission and some pixels are missed. The PTEs for the half-mission test are reasonable.

##### Curl-mode estimators:

In general, deflections due to lensing can be decomposed into gradient ($\phi$) and curl ($\psi$) modes.
The curl modes are expected to be consistent with zero for lensing by scalar perturbations at Planck reconstruction noise levels.
We construct curl-mode power spectrum estimators, analogous to those used for the gradient lensing modes, and measure their power spectra.
Full-sky weight functions for these estimators are presented in [Namikawa et al. (2012)](#bib.bib32).
Note that although they do not couple directly to the lensing potential, the curl power spectra do receive ‘N1’-type contributions from the lensing trispectrum,
which we estimate analytically and subtract as with the $C\_{L}^{\phi\phi}$ power spectrum estimates.
We do not make ‘PS’ or ‘MC’ corrections for the curl-mode power spectra.
In Table [3](#S4.T3 "Table 3 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") we report estimated amplitudes for a signal with the shape of the fiducial lensing power spectrum $C\_{L}^{\phi\phi,\ {\rm fid}}$ in the curl estimates.
These amplitudes are all consistent with zero at better than $2\thinspace\sigma$, with the exception of the $TT$ reconstruction over the high-$L$ range ($400<L\leq 2048$).
Indeed, there is mild evidence for a broad feature in the $TT$
curl-mode reconstruction centred around $L=500$ (see
Fig. [13](#S4.F13 "Figure 13 ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing")), which drives the low PTE of the $TT$
curl-mode power spectrum over the high-$L$ multipole
range. Considering $TT$ alone, the average curl power is
low by about $2.9\thinspace\sigma$ in the high-$L$ range, which is suggestive but not clearly
unacceptable given the number of tests performed. Combined with the
polarization reconstructions, which on their own appear consistent,
the MV estimate remains low but only at $2\thinspace\sigma$ over the
high-$L$ range. Since the origin of this feature in the curl-mode
spectrum is currently not understood, we have chosen to adopt the
conservative multipole range for the baseline Planck 2015 lensing
likelihood. This multipole range has little overlap with that covered
by the curl-mode feature and was determined in advance of
the curl result as it retains the majority of the $S/N$ in the reconstruction.

Table 2: 
Amplitude fits for a suite of alternative reconstructions of the lensing power spectrum and comparison to the baseline MV lensing power spectrum estimate.
The measured overall lensing amplitude $\hat{A}$ is given for the conservative ($40\!\leq\!L\!\leq\!400$) multipole range, as well as the lower signal-to-noise bins on either side.
The difference between the test amplitudes and the corresponding MV result (with amplitudes of
$\hat{A}^{\phi,\thinspace{\rm MV}}\_{8\rightarrow 40}=1.023\pm 0.085$,
$\hat{A}^{\phi,\thinspace{\rm MV}}\_{40\rightarrow 400}=0.987\pm 0.025$, and
$\hat{A}^{\phi,\thinspace{\rm MV}}\_{400\rightarrow 2048}=0.788\pm 0.097$ for the three multipole ranges)
is given as $\Delta\_{\rm MV}$.
The quoted uncertainty on the difference is obtained using Monte Carlo simulations and therefore accounts for any correlations between the MV and test estimates.
The PTE values are estimated by comparison of the $\chi^{2}$ values to the distribution from simulations.
PTEs are given for the square of the overall amplitude difference,
as well as for the $\chi^{2}$ of the difference between the bandpowers of the binned spectra.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | |  | Consistency test summary values | | | | | | | | | | | |  |  | | | | | | | | | | | |  | Low-$L$ | | | Conservative | | | | High-$L$ | | | | |  | 8 $\leq L<40$ | | | $40\leq L\leq 400$ | | | | $400<L\leq 2048$ | | | | |  | $\hat{A}\pm\sigma\_{A}$ | $\Delta\_{\rm MV}\pm\sigma\_{\Delta}$ | PTE${}\_{\Delta\_{\rm MV}=0}$ | $\hat{A}\pm\sigma\_{A}$ | $\Delta\_{\rm MV}\pm\sigma\_{\Delta}$ | PTE${}\_{\Delta\_{\rm MV}=0}$ | PTEbins | $\hat{A}\pm\sigma\_{A}$ | $\Delta\_{\rm MV}\pm\sigma\_{\Delta}$ | PTE${}\_{\Delta\_{\rm MV}=0}$ | PTEbins | |  |  | | |  | | | |  | | | | | Individual Estimator Crosses |  |  |  |  |  |  |  |  |  |  |  | | $TT\times TT$ | $\phantom{-}1.044\pm 0.111$ | $-0.035\pm 0.075$ | $0.65$ | $\phantom{-}0.990\pm 0.032$ | $-0.003\pm 0.023$ | $0.90$ | $0.47$ | $\phantom{-}0.724\pm 0.096$ | $\phantom{-}0.058\pm 0.042$ | $0.17$ | $0.81$ | | $TT\times TE$ | $\phantom{-}1.000\pm 0.108$ | $\phantom{-}0.009\pm 0.070$ | $0.91$ | $\phantom{-}0.969\pm 0.039$ | $\phantom{-}0.018\pm 0.028$ | $0.54$ | $0.12$ | $\phantom{-}0.628\pm 0.273$ | $\phantom{-}0.155\pm 0.243$ | $0.52$ | $0.52$ | | $TT\times EE$ | $\phantom{-}0.872\pm 0.149$ | $\phantom{-}0.137\pm 0.126$ | $0.29$ | $\phantom{-}1.012\pm 0.055$ | $-0.025\pm 0.051$ | $0.65$ | $0.89$ | $\phantom{-}1.616\pm 0.448$ | $-0.833\pm 0.446$ | $0.06$ | $0.18$ | | $TT\times EB$ | $\phantom{-}1.105\pm 0.308$ | $-0.096\pm 0.295$ | $0.76$ | $\phantom{-}0.988\pm 0.085$ | $-0.001\pm 0.081$ | $0.99$ | $0.83$ | $\phantom{-}1.118\pm 0.270$ | $-0.335\pm 0.269$ | $0.22$ | $0.48$ | | $TE\times TE$ | $\phantom{-}0.890\pm 0.194$ | $\phantom{-}0.118\pm 0.172$ | $0.47$ | $\phantom{-}1.057\pm 0.079$ | $-0.070\pm 0.075$ | $0.35$ | $0.94$ | $\phantom{-}3.607\pm 1.472$ | $-2.824\pm 1.461$ | $0.05$ | $0.41$ | | $EE\times TE$ | $\phantom{-}1.067\pm 0.209$ | $-0.058\pm 0.194$ | $0.77$ | $\phantom{-}0.995\pm 0.085$ | $-0.008\pm 0.080$ | $0.93$ | $0.77$ | $-0.441\pm 1.961$ | $\phantom{-}1.224\pm 1.964$ | $0.54$ | $0.18$ | | $TE\times EB$ | $\phantom{-}0.604\pm 0.424$ | $\phantom{-}0.405\pm 0.415$ | $0.31$ | $\phantom{-}1.016\pm 0.157$ | $-0.029\pm 0.156$ | $0.88$ | $0.86$ | $\phantom{-}0.786\pm 1.235$ | $-0.003\pm 1.223$ | $1.00$ | $0.57$ | | $TT\times TB$ | $\phantom{-}0.496\pm 0.631$ | $\phantom{-}0.512\pm 0.630$ | $0.42$ | $\phantom{-}0.890\pm 0.180$ | $\phantom{-}0.097\pm 0.178$ | $0.59$ | $0.76$ | $\phantom{-}1.413\pm 0.575$ | $-0.630\pm 0.571$ | $0.26$ | $0.06$ | | $EE\times EE$ | $\phantom{-}1.132\pm 0.407$ | $-0.124\pm 0.397$ | $0.72$ | $\phantom{-}0.748\pm 0.189$ | $\phantom{-}0.239\pm 0.186$ | $0.20$ | $0.50$ | $\phantom{-}4.503\pm 5.723$ | $-3.720\pm 5.717$ | $0.49$ | $0.56$ | | $EE\times EB$ | $\phantom{-}1.530\pm 0.664$ | $-0.522\pm 0.659$ | $0.44$ | $\phantom{-}0.643\pm 0.247$ | $\phantom{-}0.344\pm 0.246$ | $0.15$ | $0.20$ | $\phantom{-}4.131\pm 2.432$ | $-3.348\pm 2.429$ | $0.19$ | $0.29$ | | $TE\times TB$ | $\phantom{-}2.426\pm 0.837$ | $-1.417\pm 0.833$ | $0.09$ | $\phantom{-}0.722\pm 0.297$ | $\phantom{-}0.266\pm 0.294$ | $0.37$ | $0.75$ | $\phantom{-}5.242\pm 2.431$ | $-4.459\pm 2.425$ | $0.07$ | $0.20$ | | $EE\times TB$ | $-0.981\pm 1.212$ | $\phantom{-}1.990\pm 1.209$ | $0.10$ | $\phantom{-}1.288\pm 0.463$ | $-0.301\pm 0.463$ | $0.52$ | $0.01$ | $\phantom{-}3.154\pm 4.492$ | $-2.371\pm 4.482$ | $0.61$ | $0.81$ | | $EB\times EB$ | $\phantom{-}0.588\pm 1.819$ | $\phantom{-}0.421\pm 1.817$ | $0.82$ | $\phantom{-}1.401\pm 0.522$ | $-0.414\pm 0.521$ | $0.42$ | $0.39$ | $-0.422\pm 2.274$ | $\phantom{-}1.205\pm 2.263$ | $0.60$ | $0.80$ | | $TB\times EB$ | $\phantom{-}0.887\pm 2.954$ | $\phantom{-}0.122\pm 2.947$ | $0.95$ | $\phantom{-}0.618\pm 0.798$ | $\phantom{-}0.369\pm 0.798$ | $0.63$ | $0.34$ | $-2.591\pm 2.955$ | $\phantom{-}3.374\pm 2.945$ | $0.26$ | $0.43$ | | $TB\times TB$ | $\phantom{\thinspace}13.790\pm 8.353$ | $\!\!\!-12.781\pm 8.351$ | $0.12$ | $-2.809\pm 2.189$ | $\phantom{-}3.796\pm 2.189$ | $0.09$ | $0.08$ | $-0.532\pm 8.268$ | $\phantom{-}1.315\pm 8.260$ | $0.86$ | $0.20$ | | Crosses | $\phantom{-}0.958\pm 0.097$ | $\phantom{-}0.051\pm 0.053$ | $0.33$ | $\phantom{-}0.989\pm 0.033$ | $-0.002\pm 0.022$ | $0.91$ | $0.65$ | $\phantom{-}1.028\pm 0.193$ | $-0.245\pm 0.174$ | $0.15$ | $0.84$ | | Pol.-only[††Comparison is against the SMICA polarization-only reconstruction, rather than the MV reconstruction.](#S4.Ex4 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") | $\phantom{-}1.252\pm 0.350$ | $-0.243\pm 0.339$ | $0.46$ | $\phantom{-}0.761\pm 0.145$ | $\phantom{-}0.226\pm 0.142$ | $0.11$ | $0.39$ | $\phantom{-}1.787\pm 1.598$ | $-1.004\pm 1.586$ | $0.53$ | $0.84$ | | Foreground tests |  |  |  |  |  |  |  |  |  |  |  | | 143 GHz | $\phantom{-}0.958\pm 0.096$ | $\phantom{-}0.029\pm 0.069$ | $0.64$ | $\phantom{-}1.024\pm 0.034$ | $-0.034\pm 0.024$ | $0.16$ | $0.22$ | $\phantom{-}0.583\pm 0.122$ | $\phantom{-}0.198\pm 0.093$ | $0.04$ | $0.02$ | | 217 GHz | $\phantom{-}0.941\pm 0.092$ | $\phantom{-}0.046\pm 0.077$ | $0.57$ | $\phantom{-}0.963\pm 0.034$ | $\phantom{-}0.027\pm 0.024$ | $0.30$ | $0.71$ | $\phantom{-}0.929\pm 0.109$ | $-0.148\pm 0.088$ | $0.08$ | $0.80$ | | NILC | $\phantom{-}0.977\pm 0.073$ | $\phantom{-}0.010\pm 0.027$ | $0.75$ | $\phantom{-}0.988\pm 0.026$ | $\phantom{-}0.002\pm 0.011$ | $0.83$ | $0.94$ | $\phantom{-}0.877\pm 0.082$ | $-0.096\pm 0.031$ | $0.01$ | $0.09$ | | SEVEM-$TT$[††††Comparison is against the SMICA TT reconstruction, rather than the MV reconstruction.](#S4.Ex4 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") | $\phantom{-}1.015\pm 0.108$ | $\phantom{-}0.016\pm 0.053$ | $0.78$ | $\phantom{-}1.000\pm 0.032$ | $-0.011\pm 0.017$ | $0.53$ | $0.63$ | $\phantom{-}0.758\pm 0.094$ | $-0.039\pm 0.047$ | $0.40$ | $0.73$ | | Commander-$TT$[††††Comparison is against the SMICA TT reconstruction, rather than the MV reconstruction.](#S4.Ex4 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") | $\phantom{-}0.899\pm 0.124$ | $\phantom{-}0.132\pm 0.092$ | $0.15$ | $\phantom{-}1.018\pm 0.038$ | $-0.029\pm 0.028$ | $0.30$ | $0.42$ | $\phantom{-}0.950\pm 0.113$ | $-0.230\pm 0.099$ | $0.02$ | $0.21$ | | $f\_{\rm{sky}}=0.8$ | $\phantom{-}1.009\pm 0.064$ | $-0.022\pm 0.028$ | $0.36$ | $\phantom{-}0.987\pm 0.025$ | $\phantom{-}0.003\pm 0.009$ | $0.73$ | $0.14$ | $\phantom{-}0.761\pm 0.086$ | $\phantom{-}0.019\pm 0.031$ | $0.57$ | $0.22$ | | $f\_{\rm{sky}}=0.6$ | $\phantom{-}1.000\pm 0.078$ | $-0.014\pm 0.034$ | $0.71$ | $\phantom{-}0.991\pm 0.026$ | $-0.000\pm 0.010$ | $0.97$ | $0.90$ | $\phantom{-}0.777\pm 0.091$ | $\phantom{-}0.004\pm 0.037$ | $0.92$ | $0.68$ | | (SMICA)3353 GHz | $\phantom{-}1.000\pm 0.133$ | $-0.013\pm 0.114$ | $0.93$ | $\phantom{-}0.970\pm 0.048$ | $\phantom{-}0.021\pm 0.041$ | $0.64$ | $0.76$ | $\phantom{-}0.946\pm 0.134$ | $-0.165\pm 0.128$ | $0.21$ | $0.05$ | | (SMICA)3353 GHz-pol.-only[††Comparison is against the SMICA polarization-only reconstruction, rather than the MV reconstruction.](#S4.Ex4 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") | $\phantom{-}0.277\pm 0.996$ | $\phantom{-}1.016\pm 1.076$ | $0.33$ | $\phantom{-}0.264\pm 0.451$ | $\phantom{-}0.531\pm 0.495$ | $0.27$ | $0.80$ | $\phantom{-}7.045\pm 5.895$ | $-5.056\pm 6.440$ | $0.40$ | $0.31$ | | Noise tests |  |  |  |  |  |  |  |  |  |  |  | | $143\times 217\thinspace{\rm GHz}$ | $\phantom{-}0.949\pm 0.077$ | $\phantom{-}0.038\pm 0.050$ | $0.44$ | $\phantom{-}0.999\pm 0.027$ | $-0.008\pm 0.015$ | $0.61$ | $0.97$ | $\phantom{-}0.755\pm 0.095$ | $\phantom{-}0.025\pm 0.056$ | $0.66$ | $0.94$ | | $\text{HM1}\times\text{HM2}$ | $\phantom{-}1.028\pm 0.081$ | $-0.041\pm 0.050$ | $0.39$ | $\phantom{-}0.981\pm 0.029$ | $\phantom{-}0.009\pm 0.016$ | $0.63$ | $0.67$ | $\phantom{-}0.827\pm 0.090$ | $-0.047\pm 0.058$ | $0.40$ | $0.88$ | | Noise scaling[††††††This test only involves a change in the simulations used to perform the debiasing corrections and estimate error bars. We have quoted the scatter between the two sets of simulations, although this is an upper limit on the difference that we should actually see for the data.](#S4.Ex4 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") | $\phantom{-}0.989\pm 0.070$ | $-0.002\pm 0.030$ | $0.93$ | $\phantom{-}0.994\pm 0.026$ | $-0.003\pm 0.011$ | $0.73$ | $1.00$ | $\phantom{-}0.779\pm 0.084$ | $\phantom{-}0.001\pm 0.037$ | $0.94$ | $1.00$ | | Analysis choices |  |  |  |  |  |  |  |  |  |  |  | | $\ell\_{\rm{min}}=1000$ | $\phantom{-}1.136\pm 0.104$ | $-0.149\pm 0.081$ | $0.06$ | $\phantom{-}0.990\pm 0.036$ | $\phantom{-}0.000\pm 0.029$ | $1.00$ | $0.08$ | $\phantom{-}0.718\pm 0.153$ | $\phantom{-}0.063\pm 0.128$ | $0.57$ | $0.44$ | | $\ell\_{\rm{max}}=1500$ | $\phantom{-}1.013\pm 0.086$ | $-0.026\pm 0.060$ | $0.67$ | $\phantom{-}0.985\pm 0.035$ | $\phantom{-}0.006\pm 0.022$ | $0.76$ | $0.19$ | $\phantom{-}0.625\pm 0.181$ | $\phantom{-}0.156\pm 0.160$ | $0.41$ | $0.31$ | | Apodization | $\phantom{-}1.009\pm 0.088$ | $-0.001\pm 0.023$ | $0.98$ | $\phantom{-}0.985\pm 0.026$ | $\phantom{-}0.002\pm 0.008$ | $0.85$ | $0.58$ | $\phantom{-}0.753\pm 0.097$ | $\phantom{-}0.030\pm 0.042$ | $0.50$ | $0.91$ | | Bias-hardened estimators |  |  |  |  |  |  |  |  |  |  |  | | $\hat{\phi}^{TT}-{\rm M}$[††††Comparison is against the SMICA TT reconstruction, rather than the MV reconstruction.](#S4.Ex4 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") | $\phantom{-}1.117\pm 0.120$ | $-0.073\pm 0.054$ | $0.17$ | $\phantom{-}0.968\pm 0.039$ | $\phantom{-}0.022\pm 0.021$ | $0.30$ | $0.33$ | $\phantom{-}0.451\pm 0.136$ | $\phantom{-}0.273\pm 0.098$ | $0.01$ | $0.11$ | | $\hat{\phi}^{TT}-{\rm N}$[††††Comparison is against the SMICA TT reconstruction, rather than the MV reconstruction.](#S4.Ex4 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") | $\phantom{-}1.068\pm 0.116$ | $-0.024\pm 0.036$ | $0.52$ | $\phantom{-}0.986\pm 0.036$ | $\phantom{-}0.004\pm 0.014$ | $0.79$ | $0.79$ | $\phantom{-}0.651\pm 0.103$ | $\phantom{-}0.074\pm 0.035$ | $0.04$ | $0.09$ | | $\hat{\phi}^{TT}-{\rm S}$[††††Comparison is against the SMICA TT reconstruction, rather than the MV reconstruction.](#S4.Ex4 "Table 2 ‣ Curl-mode estimators: ‣ 4.6 Null tests ‣ 4 Consistency and null tests ‣ Planck 2015 results. XV. Gravitational lensing") | $\phantom{-}1.082\pm 0.118$ | $-0.038\pm 0.045$ | $0.43$ | $\phantom{-}0.982\pm 0.038$ | $\phantom{-}0.008\pm 0.017$ | $0.64$ | $0.62$ | $\phantom{-}0.617\pm 0.107$ | $\phantom{-}0.107\pm 0.045$ | $0.01$ | $0.06$ | |  |

Table 3: 
Null tests for a set of lens reconstructions based on maps that should contain no CMB signal, or estimators that should be orthogonal to the lensing signal.
The measured overall lensing amplitude $\hat{A}$ is given for the conservative ($40\!\leq\!L\!\leq\!400$) multipole range, as well as lower and higher multipoles. All should be consistent with zero.
The PTE values are estimated by comparison of the $\chi^{2}$ values to the distributions from simulations.
PTEs are given for the difference of the overall amplitude from zero,
as well as for the $\chi^{2}$ of the difference from zero of the binned spectra.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | --- | |  | Null test summary values | | | | | | | | |  |  | | | | | | | | |  | Low-$L$ | | Conservative | | | High-$L$ | | | |  | 8 $\leq L<40$ | | $40\leq L\leq 400$ | | | $400<L\leq 2048$ | | | |  | $\hat{A}\pm\sigma\_{A}$ | PTE${}\_{\hat{A}=0}$ | $\hat{A}\pm\sigma\_{A}$ | PTE${}\_{\hat{A}=0}$ | PTEbins | $\hat{A}\pm\sigma\_{A}$ | PTE${}\_{\hat{A}=0}$ | PTEbins | |  |  | |  | | |  | | | | Half-ring-difference | $(-0.116\pm 0.371)\times 10^{-2}$ | $0.78$ | $(-0.331\pm 0.154)\times 10^{-2}$ | $0.03$ | $0.04$ | $(-0.214\pm 0.434)\times 10^{-2}$ | $0.54$ | $0.18$ | | Half-mission-difference | $(-0.282\pm 0.565)\times 10^{-2}$ | $0.63$ | $(-0.215\pm 0.177)\times 10^{-2}$ | $0.21$ | $0.39$ | $(\phantom{-}0.075\pm 0.545)\times 10^{-2}$ | $0.93$ | $0.83$ | | $\psi^{\rm MV}$ | $(\phantom{-}0.658\pm 0.843)\times 10^{-1}$ | $0.43$ | $(-0.099\pm 0.290)\times 10^{-1}$ | $0.74$ | $0.46$ | $(-1.891\pm 0.967)\times 10^{-1}$ | $0.05$ | $0.41$ | | $\psi^{TT}$ | $(-0.241\pm 1.413)\times 10^{-1}$ | $0.87$ | $(-0.415\pm 0.428)\times 10^{-1}$ | $0.34$ | $0.27$ | $(-3.034\pm 1.047)\times 10^{-1}$ | $0.00$ | $0.03$ | | $\psi^{EE}$ | $(\phantom{-}1.138\pm 1.075)\times 10^{0}$ | $0.29$ | $(-0.266\pm 0.463)\times 10^{0}$ | $0.59$ | $0.66$ | $(\phantom{-}7.748\pm 13.27)\times 10^{0}$ | $0.53$ | $0.56$ | | $\psi^{TE}$ | $(\phantom{-}0.214\pm 0.463)\times 10^{0}$ | $0.64$ | $(-0.249\pm 0.185)\times 10^{0}$ | $0.18$ | $0.25$ | $(-3.183\pm 1.938)\times 10^{0}$ | $0.11$ | $0.75$ | | $\psi^{EB}$ | $(\phantom{-}0.484\pm 0.655)\times 10^{0}$ | $0.46$ | $(\phantom{-}0.057\pm 0.213)\times 10^{0}$ | $0.79$ | $0.41$ | $(\phantom{-}1.014\pm 1.222)\times 10^{0}$ | $0.43$ | $0.97$ | | $\psi^{TB}$ | $(\phantom{-}1.352\pm 2.563)\times 10^{0}$ | $0.60$ | $(\phantom{-}0.378\pm 0.860)\times 10^{0}$ | $0.63$ | $0.81$ | $(\phantom{-}6.597\pm 5.144)\times 10^{0}$ | $0.21$ | $0.24$ | |  |

## 5 Conclusions

We have presented a first analysis of gravitational lensing in the Planck 2015 full-mission data set. Using temperature and polarization data, we make the most powerful measurement of CMB lensing to date,
with an overall significance of around $40\thinspace\sigma$.
This paper is accompanied by the public release of the lensing potential map
(as well as simulations that can be used to characterize the map, e.g. for cross-correlation analyses with external data)
and a conservative lensing bandpower likelihood.

We have performed a number of tests to verify the internal consistency of the lens reconstruction,
in particular we have tested the compatibility between individual temperature and polarization estimators,
sensitivity to various analysis choices,
and possible foreground contamination.

Given Planck’s unique full-sky coverage,
the full-mission maps are unlikely to be displaced as the most powerful data set for
cosmological lensing analysis for the next several years
(until high signal-to-noise $E$- and $B$-mode polarization measurements can be made on sufficiently large sky fractions).
There is some room, however, for improvement on the analysis presented here.
The inverse-variance filtering we have used does not account for variations in the instrument noise level across the sky,
which could be incorporated to reduce the reconstruction noise (particularly in polarization, where instrumental noise dominates the signal).
We have high-pass filtered all results to $L\geq 8$, due to concerns about the lensing mean-field correction.
A more aggressive analysis could potentially remove this cut.
The conservative $L\leq 400$ cut that we make in our baseline likelihood, imposed because of mild evidence of a broad feature in curl-mode tests beyond this range, might also be relaxed in a future analysis, although only with minor improvements in the statistical power of the likelihood.

The microwave background is a unique source for lensing studies, as the most distant and well-understood source plane that can be observed.
The measurement presented here represents an integrated measurement of the total matter distribution
in the entire observable Universe, and another powerful test of the veracity of the concordance $\Lambda$CDM cosmological model.

###### Acknowledgements.

The Planck Collaboration acknowledges the support of: ESA; CNES and CNRS/INSU-IN2P3-INP (France); ASI, CNR, and INAF (Italy); NASA and DoE (USA); STFC and UKSA (UK); CSIC, MINECO, JA, and RES (Spain); Tekes, AoF, and CSC (Finland); DLR and MPG (Germany); CSA (Canada); DTU Space (Denmark); SER/SSO (Switzerland); RCN (Norway); SFI (Ireland); FCT/MCTES (Portugal); ERC and PRACE (EU). A description of the Planck Collaboration and a list of its members, indicating which technical or scientific activities they have been involved in, can be found at <http://www.cosmos.esa.int/web/planck/planck-collaboration>.
Some of the results in this paper have been derived using the HEALPix package. We acknowledge support from the Science and Technology Facilities Council [grant number ST/L000652/1].
The research leading to these results has received funding from the European Research Council under the European Union’s Seventh Framework Programme (FP/2007-2013) / ERC Grant Agreement No. [616170].
Part of this work was undertaken on the STFC DiRAC HPC Facilities at the University of Cambridge funded by UK BIS National E-infrastructure capital grants.

## Appendix A Pipeline

In this appendix we provide a more detailed technical overview of the pipeline that we use to extract lensing information from the Planck maps.
Starting from input CMB sky maps the pipeline has the following three distinct analysis stages.

1. (1)

   Filtering. In this step, we perform a linear operation on the maps, which performs three tasks.

   1. a.

      Mask out regions of the sky that may be contaminated by point sources or residual foreground emission (primarily from the Galaxy).
   2. b.

      Deconvolve the instrumental beam and pixel transfer functions.
   3. c.

      Downweight noisy modes to allow later steps of the pipeline to produce optimal
      (in the minimum-variance sense) estimates of the lensing potential and its power spectrum.

   Implementation details of the filtering procedure are described in Appendix [A.1](#A1.SS1 "A.1 Filtering ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing"). The filtering step provides us with filtered CMB temperature and polarization multipoles denoted by $\bar{T}\_{\ell m}$, $\bar{E}\_{\ell m}$, and $\bar{B}\_{\ell m}$.
2. (2)

   Quadratic Estimators.
   The filtered CMB multipoles are then fed into quadratic estimators designed to extract the statistical anisotropy that is induced by lensing.
   These estimators are formed by summing over pairs of CMB fluctuations with a weight function optimized to detect the off-diagonal contributions to their covariance matrix from (fixed) lenses.
   This step produces maps of the estimated lensing potential $\hat{\phi}$, and is described in detail in Appendix [A.2](#A1.SS2 "A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing").
3. (3)

   Power Spectrum Estimation.
   To estimate the power spectrum of the lensing potential, we exploit the non-Gaussianity induced by lensing.
   At first order in the power spectrum $C\_{L}^{\phi\phi}$, lensing generates a contribution to the connected 4-point function (or trispectrum) of the observed CMB,
   which we probe using auto- and cross-spectra of the 2-point quadratic estimators $\hat{\phi}$ obtained in step (2) of the pipeline.
   There are two complications here that are worth noting: the auto- and cross-spectra of the lensing estimates have noise biases even in the absence of lensing, which must be carefully estimated and subtracted; and non-Gaussian contamination from unresolved point sources can mimic lensing and bias the reconstructed power spectrum.
   Our approaches to these issues are described in Appendix [A.3](#A1.SS3 "A.3 Power spectrum estimation ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing").

We now proceed to describe the individual steps of the lensing pipeline in more detail.

### A.1 Filtering

At this stage in the pipeline, we have noisy maps of the CMB for both data and simulations.
To construct minimum-variance estimates of the lensing potential and its power spectrum, we need to filter these maps to downweight noise-dominated modes, as well as to deconvolve the transfer functions due to the finite beam size and pixelization.

To derive the optimal (minimum-variance) filter to apply, we use a simplified model of the data given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $d\_{i}=\sum\_{k}{\cal Y}\_{ik}s\_{k}+n\_{i},$ |  | (33) |

where $d\_{i}$ is a single long vector containing the pixelized $T$, $Q$, and $U$ sky maps.
The ‘pointing matrix’ ${\cal Y}\_{i,k}$ takes an input sky signal (consisting of $T$, $E$, and $B$ multipoles collectively indexed by $k$),
convolves it with a beam and pixel transfer function, and then performs a harmonic transform to map space.
The harmonic modes of the sky itself are denoted as $s\_{k}$, and $n\_{i}$ is the map noise realization.
We have used indices $i$ and $k$ for quantities in map-space and harmonic-space respectively.
Explicitly, the indices $k$ and $i$ are mapped as

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\qquad\qquad k$ | $\displaystyle\mapsto$ | $\displaystyle(X\in\{T,E,B\},\ell,m)$ |  | (34) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\qquad\qquad i$ | $\displaystyle\mapsto$ | $\displaystyle(M\in\{T,Q,U\},p),$ |  | (35) |

where $p$ denotes a pixel.
In this notation, we model the pointing matrix as

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal Y}\_{(M,p),(X,\ell m)}=H\_{\ell}B\_{\ell}R^{M}\_{X,\ell m}(\hat{{\mbox{\boldmath{$n$}}}}\_{p}),$ |  | (36) |

where $H\_{\ell}$ is the HEALPix ([Górski et al. 2005](#bib.bib15)) $N\_{\rm side}=2048$ pixel transfer function,
$B\_{\ell}$ is the effective beam transfer function for the map under consideration,
and $R^{M}\_{X,\ell m}(\hat{{\mbox{\boldmath{$n$}}}}\_{p})$ represents the real-valued spherical harmonic for field $X$
evaluated at the center of pixel $p$ in map $M$.

If both the sky signal and noise are Gaussian random fields
(with covariance matrices
$\langle s\_{k}s^{\*}\_{k^{\prime}}\rangle\equiv S\_{kk^{\prime}}$ and
$\langle n\_{i}n\_{i^{\prime}}\rangle\equiv N\_{ii^{\prime}}$, respectively)
then the inverse-variance filtered estimates of the beam-deconvolved sky signal $\bar{s}$ are given in matrix notation by ([Bunn et al. 1994](#bib.bib6))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bar{\mathbf{s}}=\mathsf{S}^{-1}\left[\mathsf{S}^{-1}+{\cal Y}^{T}\mathsf{N}^{-1}{\cal Y}\right]^{-1}{\cal Y}^{T}\mathsf{N}^{-1}\mathbf{d}.$ |  | (37) |

We use this equation to obtain the inverse-variance filtered $T$, $E$, and $B$ multipoles that are fed into our quadratic estimators, with one additional rescaling discussed below.
The large bracketed matrix inverse is performed using conjugate descent with a multi-grid preconditioner, following [Smith et al. (2007)](#bib.bib56).

For the purposes of filtering, we use a simplified model for the covariance matrices of $s\_{k}$ and $n\_{i}$
in which they are diagonal in harmonic space and pixel space, respectively, with

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\qquad\qquad\mathsf{S}$ | $\displaystyle=$ | $\displaystyle\langle s\_{(X,\ell m)}s^{\*}\_{(X^{\prime},\ell^{\prime}m^{\prime})}\rangle=\delta\_{XX^{\prime}}\delta\_{\ell\ell^{\prime}}\delta\_{mm^{\prime}}C\_{\ell}^{XX},$ |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\mathsf{N}$ | $\displaystyle=$ | $\displaystyle\langle n\_{(M,p)}n\_{(M^{\prime},p^{\prime})}\rangle=\delta\_{MM^{\prime}}\delta\_{pp^{\prime}}N^{M}\_{p}.$ |  | (38) |

Here,
$C\_{\ell}^{XX}$ are the fiducial theoretical CMB power spectra and
$N^{M}\_{p}$ gives the noise variance for pixel $p$ in map $M$.
With this diagonal assumption, we have ignored the cross-correlation $C\_{\ell}^{TE}$ for the purposes of filtering.
This is slightly sub-optimal, but has the advantage of allowing the temperature and polarization maps to be filtered independently.
It also has the benefit of making analytical calculations for the estimator normalization simpler (see Sect. [A.2](#A1.SS2 "A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")).
Also for simplicity, we take $N^{M}\_{p}$ to be constant over all unmasked pixels and given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $N^{M}\_{p}=\left(\frac{\pi N\_{\rm lev}^{M}}{10\thinspace 800}\right)^{2}\frac{N\_{\rm pix}}{4\pi}\frac{1}{M\_{p}}.$ |  | (39) |

Here $N^{M}\_{\rm lev}$ is the map noise level in $\mu{\rm K}\thinspace{\rm arcmin}$,
$N\_{\rm pix}$ is the number of pixels in an $N\_{\rm side}\!=\!2048$ HEALPix map,
and $M\_{p}$ is a mask map (which is zero for masked pixels, and unity otherwise).
We always take the noise level to be the same for paired $Q$/$U$ maps.
The mask term in Eq. ([39](#A1.E39 "Equation 39 ‣ A.1 Filtering ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")) takes the noise level to infinity for masked pixels.
In the filtering operation, which only involves the inverse of the noise matrix, this sets masked pixels to zero.

After evaluating Eq. ([37](#A1.E37 "Equation 37 ‣ A.1 Filtering ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")), we have a set of inverse-variance filtered sky multipoles $\bar{s}\_{X,\ell m}$ for $X\in\{T,E,B\}$.
The simplified CMB+white-noise model above results in a slightly sub-optimal filtering procedure since it ignores the following:

1. (1)

   variations in the noise level across the sky due to the uneven hit distribution (the Ecliptic poles receive more coverage than the equator for the Planck scan strategy);
2. (2)

   scale-dependence of the noise power; and
3. (3)

   foreground power.

In [Planck Collaboration
XVII (2014)](#bib.bib37) we showed that the sub-optimality due to (1) for temperature-based lensing reconstruction was small (accounting for it properly was estimated to improve the uncertainty on the overall lensing amplitude by $4\thinspace\%$).
The loss will be slightly smaller here for temperature, owing to a more even hit distribution in the full-mission data than in the nominal-mission data used in [Planck Collaboration
XVII (2014)](#bib.bib37).
The loss will be larger for polarization, where noise is a more important part of the total error budget, although we have not evaluated the size of the potential degradation.
To compensate for (2) and (3) we make a post-correction by rescaling the modes by a quality factor $Q\_{\ell}^{X}$ as a function of scale to obtain final filtered multipole that are closer to optimal.
We denote these as $\bar{X}\_{\ell m}$, and they are given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bar{X}\_{\ell m}=Q\_{\ell}^{X}\bar{s}\_{X,\ell m}.$ |  | (40) |

These inverse-variance filtered multipoles are the input to the lensing estimators described in Sect. [A.2](#A1.SS2 "A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing").
The choice of $Q\_{\ell}^{X}$ is discussed below.

For analytical calculations, it is useful to have an approximation to the filtering procedure that is diagonal in harmonic space
(i.e. neglecting the small amount of mode-mixing induced by the masking).
In this approximation, the filtered multipoles are given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bar{X}\_{\ell m}\approx F\_{\ell}^{X}X\_{\ell m}+\tilde{n}\_{\ell m},$ |  | (41) |

where $\tilde{n}$ is a noise realization and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $F\_{\ell}^{X}=\frac{Q\_{\ell}^{X}}{C\_{\ell}^{XX}+N\_{\ell}^{XX}}.$ |  | (42) |

Here, $C\_{\ell}^{XX}$ are the fiducial CMB auto-spectra used in Eq. ([38](#A1.E38 "Equation 38 ‣ A.1 Filtering ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")), and the quantity

|  |  |  |  |
| --- | --- | --- | --- |
|  | $N\_{\ell}^{XX}=(H\_{\ell}B\_{\ell})^{-2}\left(\frac{\pi N\_{\rm lev}^{M}}{10\thinspace 800}\right)^{2}$ |  | (43) |

is the pixel- and beam-deconvolved noise power spectrum for the field $X$, where
$N\_{\rm lev}^{M}$ is the appropriate map white-noise level in $\mu{\rm K}\thinspace{\rm arcmin}$.
We choose $Q\_{\ell}^{X}$ such that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{f\_{\rm sky}^{-1}}{(2L+1)}\sum\_{m}|\bar{X}\_{\ell m}|^{2}\approx F\_{\ell}^{X},$ |  | (44) |

where $f\_{\rm sky}=\sum\_{p}M\_{p}/N\_{\rm pix}$ is the unmasked sky fraction and
the approximation sign indicates a smoothing over multipoles.

### A.2 Quadratic estimators

Ensemble averaging over a fixed realization of the CMB lensing potential, the CMB covariance matrix acquires off-diagonal elements given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta\langle X\_{\ell\_{1}m\_{1}}Z\_{\ell\_{2}m\_{2}}\rangle=\sum\_{LM}(-1)^{M}\left(\begin{array}[]{ccc}\!\ell\_{1}&\ell\_{2}&L\\ \!m\_{1}&m\_{2}&-M\end{array}\right){\cal W}^{XZ}\_{\ell\_{1}\ell\_{2}L}\phi\_{LM},$ |  | (45) |

with the fields
$X\_{\ell m},Z\_{\ell m}\in\{{T}\_{\ell m}$, ${E}\_{\ell m}$, ${B}\_{\ell m}\}$.
The covariance response functions ${\cal W}^{XZ}$ for the possible field combinations can be found in [Okamoto & Hu (2003)](#bib.bib33). They are linear in the (lensed) CMB power spectra, and are only non-zero if $\ell\_{1}+\ell\_{2}+L$ is even for even-parity combinations, e.g. $TT$ and $TE$, and $\ell\_{1}+\ell\_{2}+L$ is odd for the odd-parity combinations $TB$ and $EB$. Furthermore, the ${\cal W}^{XZ}$ are real for the even-parity combinations and imaginary for the odd-parity.
We use the off-diagonal covariance to estimate the lensing potential;
after the inverse-variance-filtered sky maps are generated, pairs of fields
$\bar{X}\_{\ell m}$, $\bar{Z}\_{\ell m}\in\{\bar{T}\_{\ell m}$, $\bar{E}\_{\ell m}$, $\bar{B}\_{\ell m}\}$
are fed into quadratic estimators to estimate the lensing potential.
A general quadratic estimator is given as a function of input fields $\bar{X}$ and $\bar{Z}$ as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bar{x}\_{LM}[\bar{X},\bar{Z}]=\frac{(-1)^{M}}{2}\sum\_{\ell\_{1}m\_{1},\ell\_{2}m\_{2}}\left(\begin{array}[]{ccc}\!\ell\_{1}&\ell\_{2}&L\\ \!m\_{1}&m\_{2}&-M\end{array}\right)\\ \times W^{x}\_{\ell\_{1}\ell\_{2}L}\bar{X}\_{\ell\_{1}m\_{1}}\bar{Z}\_{\ell\_{2}m\_{2}},$ |  | (46) |

where $W^{x}\_{\ell\_{1}\ell\_{2}L}$ is a set of weight functions that define the estimator $x$, along
with the input inverse-variance filtered multipoles $\bar{X}$, $\bar{Z}$ for a particular map or pair of maps.
The choice of $\bar{T}$, $\bar{E}$, or $\bar{B}$ for $\bar{X}$ and $\bar{Z}$ depends on the specific estimator $x$.
In most of what follows we shall drop the $[\bar{X},\bar{Z}]$ unless it is necessary to avoid ambiguity.

Optimal lensing estimators use a matched filter for the lensing-induced covariance of Eq. ([45](#A1.E45 "Equation 45 ‣ A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")).
We denote these as $W^{XZ}$ for the fields $X$ and $Z$.
The temperature-only optimal estimator, for example, uses
$W^{TT}=\left.{\cal W}^{TT}\right|\_{\rm fid}$, where the ‘fid’ subscript indicates that the lensing weight function is evaluated for the fiducial cosmological model given at the end of Sect. [2](#S2 "2 Data and methodology ‣ Planck 2015 results. XV. Gravitational lensing"). For the odd-parity combinations, the matched filter is minus the covariance response function, e.g. $W^{TB}=-\left.{\cal W}^{TB}\right|\_{\rm fid}$. Neglecting the lensing of any primordial $B$-mode signal
(certainly a valid approximation for scales $\ell\_{B}>100$ with Planck polarization sensitivity), generally
there are eight possible lensing estimators based on the possible combinations of $T$, $E$, and $B$. (This reduces to five estimators for our baseline analysis that uses a foreground-cleaned map of the CMB in temperature and polarization, and for which there is no distinction between $TE$ and $ET$, for example.)

The quadratic estimators defined by Eq. ([46](#A1.E46 "Equation 46 ‣ A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")) will receive contributions from non-lensing sources such as
masking,
beam asymmetry, and
inhomogeneity of the instrumental noise.
We determine and correct for this bias by averaging the reconstruction
$\bar{x}\_{LM}$ over Monte Carlo simulations that include these effects,
thereby estimating a ‘mean-field’ $\bar{x}\_{LM}^{MF}$ that we then subtract.

The response of a quadratic estimator to the covariance given in Eq. ([45](#A1.E45 "Equation 45 ‣ A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")) (averaged over CMB realizations with a single mode $\phi\_{LM}$ of the lensing potential held fixed) is, in the diagonal approximation of Eq. ([41](#A1.E41 "Equation 41 ‣ A.1 Filtering ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")),

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\langle\bar{x}\_{LM}\rangle={\cal R}\_{L}^{x\phi}\phi\_{LM},$ |  | (47) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal R}\_{L}^{x\phi}=\frac{1}{2(2L+1)}\sum\_{\ell\_{1}\ell\_{2}}W^{x}\_{\ell\_{1}\ell\_{2}L}{\cal W}^{XZ}\_{\ell\_{1}\ell\_{2}L}F\_{\ell\_{1}}^{X}F\_{\ell\_{2}}^{Z}.$ |  | (48) |

As a baseline, all of the results in this paper are obtained using the fiducial model at the end of Sect. [2](#S2 "2 Data and methodology ‣ Planck 2015 results. XV. Gravitational lensing") to calculate the ${\cal W}^{XZ}$ that appear in the estimator response.
However, for cosmological parameter sampling with the lensing likelihood the normalization is recalculated using the appropriate CMB power spectra as the parameter space is explored. This is discussed further in Appendix [C](#A3 "Appendix C Power spectrum likelihood ‣ Planck 2015 results. XV. Gravitational lensing").

Putting the above together, we form estimates of the lensing potential as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{\phi}^{x}\_{LM}=\frac{1}{{\cal R}\_{L}^{x\phi}}(\bar{x}\_{LM}^{\phantom{MF}}-\bar{x}\_{LM}^{MF}).$ |  | (49) |

We can also sum the individual estimators into a combined minimum-variance estimator (MV) as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{\phi}^{\rm MV}\_{LM}=\frac{\sum\_{x}{\hat{\phi}^{x}\_{LM}{\cal R}\_{L}^{x\phi}}}{\sum\_{x}{{\cal R}\_{L}^{x\phi}}},$ |  | (50) |

where the sum is taken over the eight lensing estimators ($TT$, $EE$, $TE$, $TB$, $EB$, $ET$, $BT$, and $BE$).

Finally, we note an important implementation detail.
Naively, evaluating an estimator of the form in Eq. ([46](#A1.E46 "Equation 46 ‣ A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")) requires
${\cal O}(\ell\_{\rm max}^{4}L\_{\rm max}^{2})$ operations, which would be very computationally expensive at Planck resolution.
Fortunately, all of the weight functions used in this paper can be re-written as a sum of separable terms with the following form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $W^{x}\_{\ell\_{1}\ell\_{2}L}=\sum\_{j}(-1)^{s^{x,j}\_{L}}\sqrt{\frac{(2\ell\_{1}+1)(2\ell\_{2}+1)(2L+1)}{4\pi}}\\ \times\left(\begin{array}[]{ccc}\!\ell\_{1}&\ell\_{2}&L\\ \!-s\_{1}^{x,j}&-s\_{2}^{x,j}&s\_{L}^{x,j}\end{array}\right)w\_{\ell\_{1}}^{x,j}w\_{\ell\_{2}}^{x,j}w\_{L}^{x,j}.$ |  | (51) |

This separability leads to estimators that can be evaluated with ${\cal O}(j\_{\rm max}\ell\_{\rm max}^{2}L\_{\rm max})$ operations in position space as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bar{x}\_{LM}=\frac{1}{2}\int d\hat{\mathbf{n}}\sum\_{j}{}\_{s\_{L}^{x,j}}\!Y\_{LM}^{\*}(\hat{\mathbf{n}})w\_{L}^{x,j}\\ \times\left[\sum\_{\ell\_{1}m\_{1}}{}\_{s\_{1}^{x,j}}\!Y\_{\ell\_{1}m\_{1}}(\hat{\mathbf{n}})w\_{\ell\_{1}}^{x,j}\bar{X}^{x,j}\_{\ell\_{1}m\_{1}}\right]\\ \times\left[\sum\_{\ell\_{2}m\_{2}}{}\_{s\_{2}^{x,j}}\!Y\_{\ell\_{2}m\_{2}}(\hat{\mathbf{n}})w\_{\ell\_{2}}^{x,j}\bar{Z}^{x,j}\_{\ell\_{2}m\_{2}}\right].$ |  | (52) |

The separability of the weight functions also allows the response functions to be calculated quickly analytically;
using the position-space approach given in [Dvorkin & Smith (2009)](#bib.bib9) they can be evaluated in
${\cal O}(l\_{\rm max}^{2})$ operations.
A sample implementation of these weights can be found at <http://github.com/dhanson/quicklens> in the file [quicklens/qest/lens.py](https://github.com/dhanson/quicklens/blob/master/quicklens/qest/lens.py).

### A.3 Power spectrum estimation

Ensemble averaging over realizations of both the CMB lensing potential
and the primary temperature and polarization fluctuations, the CMB becomes non-Gaussian.
At first order in the lensing potential power spectrum $C\_{L}^{\phi\phi}$ this non-Gaussianity
is manifest as a connected 4-point function ([Hu 2001](#bib.bib21))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\langle X\_{\ell\_{1}m\_{1}}Z\_{\ell\_{2}m\_{2}}C\_{\ell\_{3}m\_{4}}D\_{\ell\_{4}m\_{4}}\rangle\_{c}=\sum\_{LM}\left(\begin{array}[]{ccc}\!\ell\_{1}&\ell\_{2}&L\\ \!m\_{1}&m\_{2}&M\end{array}\right)\left(\begin{array}[]{ccc}\!\ell\_{3}&\ell\_{4}&L\\ \!m\_{3}&m\_{4}&-M\end{array}\right)\\ \times(-1)^{M}C\_{L}^{\phi\phi}{\cal W}^{{XZ}}\_{\ell\_{1}\ell\_{2}L}{\cal W}^{{CD}}\_{\ell\_{3}\ell\_{4}L}+\text{2 perms}.$ |  | (53) |

As might be expected given the presence of the covariance response functions ${\cal W}$ in this expression,
estimators to extract $C\_{L}^{\phi\phi}$ from the trispectrum can be written using the quadratic estimators above as building blocks.
We write the cross-spectrum of two quadratic estimators explicitly as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C^{\hat{\phi}\hat{\phi}}\_{L,xy}[\bar{X},\bar{Z},\bar{C},\bar{D}]\equiv\frac{f\_{\rm sky}^{-1}}{2L+1}\sum\_{M}\hat{\phi}\_{LM}^{x}[\bar{X},\bar{Z}]\hat{\phi}\_{LM}^{y\*}[\bar{C},\bar{D}],$ |  | (54) |

where
$f\_{\rm sky}=\sum\_{p}M\_{p}/N\_{\rm pix}$ is the unmasked sky fraction, with $M\_{p}$ the mask map used in Eq. ([39](#A1.E39 "Equation 39 ‣ A.1 Filtering ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")).
We form estimates of the lensing potential power spectrum (based on estimators $x$ and $y$) as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\hat{C}\_{L,xy}^{\phi\phi}=C^{\hat{\phi}\hat{\phi}}\_{L,xy}-\left.\Delta C\_{L,xy}^{\hat{\phi}\hat{\phi}}\right|\_{\textsc{N0}}\\ -\left.\Delta C\_{L,xy}^{\hat{\phi}\hat{\phi}}\right|\_{\textsc{N1}}-\left.\Delta C\_{L,xy}^{\hat{\phi}\hat{\phi}}\right|\_{\textsc{MC}}-\left.\Delta C\_{L,xy}^{\hat{\phi}\hat{\phi}}\right|\_{\textsc{PS}}.$ |  | (55) |

There are several correction terms here, which are discussed in more detail below.
We also plot them for the MV reconstruction based on the Planck 2015 SMICA maps in Fig. [16](#A1.F16 "Figure 16 ‣ A.3 Power spectrum estimation ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing").

Figure 16: 
Lens reconstruction bias terms for the MV lensing estimator applied to the Planck 2015 SMICA maps.
Dashed lines indicate regions where the bias term is negative.
The fiducial $\Lambda$CDM theory power spectrum $C\_{L}^{\phi\phi,\ {\rm fid}}$ is plotted as the black solid line.

The $\Delta C\_{L,xy}^{\hat{\phi}\hat{\phi}}|\_{\textsc{N0}}$ term represents the disconnected contribution to the 4-point function, which would be non-zero even in the absence of lensing.
We estimate this term by replacing some of the data fields with those from two sets of independent simulations
(labelled MC1 and MC2), and then average over realizations as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\Delta C\_{L,xy}^{\hat{\phi}\hat{\phi}}\right|\_{\textsc{N0}}=\Bigg<-C\_{L,xy}^{\hat{\phi}\hat{\phi}}[\bar{X}\_{\textsc{MC1}},\bar{Z}\_{\textsc{MC2}},\bar{C}\_{\textsc{MC2}},\bar{D}\_{\textsc{MC1}}]\\ +C\_{L,xy}^{\hat{\phi}\hat{\phi}}[\bar{X}\_{\textsc{MC1}},\bar{Z},\bar{C}\_{\textsc{MC1}},\bar{D}]+C\_{L,xy}^{\hat{\phi}\hat{\phi}}[\bar{X}\_{\textsc{MC1}},\bar{Z},\bar{C},\bar{D}\_{\textsc{MC1}}]\\ +C\_{L,xy}^{\hat{\phi}\hat{\phi}}[\bar{X},\bar{Z}\_{\textsc{MC1}},\bar{C}\_{\textsc{MC1}},\bar{D}]+C\_{L,xy}^{\hat{\phi}\hat{\phi}}[\bar{X},\bar{Z}\_{\textsc{MC1}},\bar{C},\bar{D}\_{\textsc{MC1}}]\\ -C\_{L,xy}^{\hat{\phi}\hat{\phi}}[\bar{X}\_{\textsc{MC1}},\bar{Z}\_{\textsc{MC2}},\bar{C}\_{\textsc{MC1}},\bar{D}\_{\textsc{MC2}}]\Bigg>\_{\textsc{MC}1,\ \textsc{MC}2}.$ |  | (56) |

This method for determining the disconnected bias
can be derived from the Edgeworth expansion of the lensed CMB
([Regan et al. 2010](#bib.bib51);
neglecting the $T\phi$ and $E\phi$ correlations).
If the simulations have a covariance differing from reality by a linear (in general, anisotropic) correction, this form of the N0 estimator using a mixture of data and simulations is insensitive to the correction at linear order ([Namikawa et al. 2013](#bib.bib31)).
The largest difference we see between simulations and data is about
$5\%$ in power before correction, so the quadratic error should be at
most about $(0.05)^{2}=0.0025$, corresponding to an error of less
than $0.4\thinspace\sigma$ for aggressive bins at $L\leq 400$ rising to around $1.3\thinspace\sigma$ at $L=2000$.
Since we also match the data calibration, and add isotropic foreground
and noise power to the simulations to match the observed amplitude and
shape of the power spectrum of the data, the isotropic part of the
error is actually close to zero. A residual error only arises at
second order due to our inability to capture any statistical anisotropy in the missing
foreground and noise power, and hence should be much smaller than the
above estimates. This makes the N0 subtraction rather robust, despite it being substantially larger than the signal on small scales.
Furthermore, the mixed form reduces correlations of the lensing power spectrum estimates between different multipoles ([Hanson et al. 2011](#bib.bib17)) and with the measured CMB power spectra ([Schmittfull et al. 2013](#bib.bib54)).

The $\Delta C\_{L}^{\hat{\phi}\hat{\phi}}|\_{\textsc{N1}}$ term corrects for the non-Gaussian secondary contractions
(the other permutations in Eq. [53](#A1.E53 "Equation 53 ‣ A.3 Power spectrum estimation ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")) due to lensing, as discussed in [Kesden et al. (2003)](#bib.bib25).
We evaluate it using the flat-sky approximation in 2D Fourier space as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\Delta C\_{L,xy}^{\hat{\phi}\hat{\phi}}\right|\_{\textsc{N1}}=\frac{1}{{\cal R}\_{L}^{x\phi}{\cal R}\_{L}^{y\phi}}\int\frac{d^{2}\mathbf{\ell}\_{1}}{(2\pi)^{2}}\int\frac{d^{2}\mathbf{\ell}^{\prime}\_{1}}{(2\pi)^{2}}\\ \hskip-36.135pt\times\Big[C^{\phi\phi}\_{|\mathbf{\ell}\_{1}-\mathbf{\ell}^{\prime}\_{1}|}{\cal W}^{XC}(-\mathbf{\ell}\_{1},\mathbf{\ell}^{\prime}\_{1}){\cal W}^{ZD}(-\mathbf{\ell}\_{2},\mathbf{\ell}^{\prime}\_{2})\\ \qquad+C^{\phi\phi}\_{|\mathbf{\ell}\_{1}-\mathbf{\ell}^{\prime}\_{2}|}{\cal W}^{XD}(-\mathbf{\ell}\_{1},\mathbf{\ell}^{\prime}\_{2}){\cal W}^{ZC}(-\mathbf{\ell}\_{2},\mathbf{\ell}^{\prime}\_{1})\Big]\\ \times F^{X}\_{|\mathbf{\ell}\_{1}|}F^{Z}\_{|\mathbf{\ell}\_{2}|}F^{C}\_{|\mathbf{\ell}^{\prime}\_{1}|}F^{D}\_{|\mathbf{\ell}^{\prime}\_{2}|}\\ \times W^{x}(\mathbf{\ell}\_{1},\mathbf{\ell}\_{2})W^{y}(\mathbf{\ell}^{\prime}\_{1},\mathbf{\ell}^{\prime}\_{2}),$ |  | (57) |

where $\mathbf{\ell}\_{1}+\mathbf{\ell}\_{2}=\mathbf{\ell}^{\prime}\_{1}+\mathbf{\ell}^{\prime}\_{2}=\mathbf{L}$.
Here the weight functions are flat-sky lensing weight functions; they can be found in [Hu & Okamoto (2002)](#bib.bib23).

We characterize any differences between the average lensing power obtained on simulations with the input power.
This is determined by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\Delta C\_{L}^{\hat{\phi}\hat{\phi}}\right|\_{\textsc{MC}}\equiv\Bigg<C\_{L,xy}^{\hat{\phi}\hat{\phi}}[\bar{X}\_{\textsc{MC1}},\bar{Z}\_{\textsc{MC1}},\bar{C}\_{\textsc{MC1}},\bar{D}\_{\textsc{MC1}}]\\ -C\_{L,xy}^{\hat{\phi}\hat{\phi}}[\bar{X}\_{\textsc{MC1}},\bar{Z}\_{\textsc{MC2}},\bar{C}\_{\textsc{MC1}},\bar{D}\_{\textsc{MC2}}]\\ -C\_{L,xy}^{\hat{\phi}\hat{\phi}}[\bar{X}\_{\textsc{MC1}},\bar{Z}\_{\textsc{MC2}},\bar{C}\_{\textsc{MC2}},\bar{D}\_{\textsc{MC1}}]\\ -\left.\Delta C\_{L,xy}^{\hat{\phi}\hat{\phi}}\right|\_{\textsc{N1}}-\left.C\_{L}^{\phi\phi}\right|\_{\rm fid}\Bigg>\_{\textsc{MC1},\ \textsc{MC2}}.$ |  | (58) |

The MC correction is included to account for possible issues in the estimation of the normalization,
mixing of power between power spectrum bins, and errors in the calculation of the N1 bias.
Although in principle several of these effects should be included as multiplicative rather than additive corrections,
we find that the MC correction is generally small enough (less than $10\thinspace\%$ of the fiducial lensing power spectrum) that
it does not matter at our experimental sensitivity whether we apply the correction additively or multiplicatively.

Finally, we make a correction $\Delta C\_{L,xy}^{\hat{\phi}\hat{\phi}}|\_{\textsc{PS}}$
for the non-Gaussianity due to the shot-noise of unresolved point sources in temperature.
This is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\Delta C\_{L,xy}^{\hat{\phi}\hat{\phi}}\right|\_{\textsc{PS}}=\widehat{S^{4}}\frac{{\cal R}\_{L}^{xS^{2}}{\cal R}\_{L}^{yS^{2}}}{{\cal R}\_{L}^{x\phi}{\cal R}\_{L}^{y\phi}},$ |  | (59) |

where $\widehat{S^{4}}$ is an estimate of the shot-noise amplitude and
$S^{2}$ denotes the weight function (non-zero only for $TT$) defined by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $W^{S^{2}}\_{\ell\_{1}\ell\_{2}L}=\sqrt{\frac{(2\ell\_{1}+1)(2\ell\_{2}+1)(2L+1)}{4\pi}}\left(\begin{array}[]{ccc}\!\ell\_{1}&\ell\_{2}&L\\ \!0&0&0\end{array}\right).$ |  | (60) |

The ${\cal R}^{xS^{2}}$ is given by Eq. ([48](#A1.E48 "Equation 48 ‣ A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")) but with ${\cal W}\_{\ell\_{1}\ell\_{2}L}$ replaced by $W^{S^{2}}\_{\ell\_{1}\ell\_{2}L}$. Following [Osborne et al. (2014)](#bib.bib34), the estimate for the shot-noise trispectrum amplitude is obtained in an analogous way to Eq. ([55](#A1.E55 "Equation 55 ‣ A.3 Power spectrum estimation ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")), but using the quadratic estimator formed with the point-source weight function above rather than the lensing weight function.
The overall source amplitude is then estimated as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\widehat{S^{4}}=\frac{\sum\_{L}(2L+1)\left({\cal R}\_{L}^{S^{2}S^{2}}\right)^{2}\hat{C}\_{L}^{S^{2}S^{2}}}{\sum\_{L}(2L+1)\left({\cal R}\_{L}^{S^{2}S^{2}}\right)^{2}},$ |  | (61) |

where the sums are taken over $100\leq L\leq 2048$.
Note that ${\cal R}^{S^{2}S^{2}}$ is given by Eq. ([48](#A1.E48 "Equation 48 ‣ A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")) but with both ${\cal W}\_{\ell\_{1}\ell\_{2}L}$ and $W^{x}\_{\ell\_{1}\ell\_{2}L}$ replaced by $W^{S^{2}}\_{\ell\_{1}\ell\_{2}L}$.

We use Eq. ([55](#A1.E55 "Equation 55 ‣ A.3 Power spectrum estimation ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")) to estimate the lensing potential power spectrum,
which we then bin into bandpowers for plotting as well as constructing a lensing likelihood.
We use Monte-Carlo simulations of the power spectrum estimation to construct error bars for these bandpowers.
There is one technical point here, which is that the realization-dependent
$\Delta C\_{L,xy}^{\phi\phi}|\_{\textsc{N0}}$
correction term can be cumbersome to compute.
Instead, for the purpose of determining error bars, we use a semi-analytical approximation to this term given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\Delta C\_{L,xy}^{\phi\phi}\right|\_{\textsc{N0},\ {\rm analytic}}[\bar{X},\bar{Z},\bar{C},\bar{D}]=\frac{1}{{\cal R}\_{L}^{x\phi}{\cal R}\_{L}^{y\phi}}\frac{1}{4(2L+1)}\\ \times\sum\_{\ell\_{1}\ell\_{2}}W^{x}\_{\ell\_{1}\ell\_{2}L}\Big(W^{y\ast}\_{\ell\_{1}\ell\_{2}L}\bar{C}\_{\ell\_{1}}^{XC}\bar{C}\_{\ell\_{2}}^{ZD}+(-1)^{\ell\_{1}+\ell\_{2}+L}W^{y\ast}\_{\ell\_{2}\ell\_{1}L}\bar{C}\_{\ell\_{1}}^{XD}\bar{C}\_{\ell\_{2}}^{ZC}\Big),$ |  | (62) |

where the empirical power spectra of the filtered fields are

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\bar{C}\_{\ell}^{XZ}=\frac{f\_{\rm sky}^{-1}}{2L+1}\sum\_{m}\bar{X}\_{\ell m}\bar{Z}\_{\ell m}^{\*}.$ |  | (63) |

## Appendix B Bias-hardened estimators

The quadratic lensing estimators of Appendix [A.2](#A1.SS2 "A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing") can be biased by non-lensing sources of statistical anisotropy such as beam asymmetry, noise inhomogeneity, and masking.
In our fiducial analyses, we estimate these mean-field biases using Monte-Carlo simulations. However, this approach can be sensitive to the fidelity of the simulations, particularly for the reconstruction on large angular scales where the mean-field biases can be orders of magnitude above the lensing signals of interest.
As a cross-check, we also take a more data-dependent approach to correcting these biases.
As with lensing, most sources of statistical anisotropy in a map can be associated with a covariance response function ${\cal W}^{z}\_{\ell\_{1}\ell\_{2}L}$, and a field $z\_{LM}$ that describes the spatial dependence of the anisotropy.
It is possible to construct quadratic estimators for $z\_{LM}$, and then calculate and subtract the resulting lensing bias.
This procedure amounts to constructing special ‘bias-hardened’ estimators ([Namikawa et al. 2013](#bib.bib31)).
Given a source of bias $z$, we construct a bias-hardened estimator with weight function

|  |  |  |  |
| --- | --- | --- | --- |
|  | $W^{\phi-z}\_{\ell\_{1}\ell\_{2}L}=W^{\phi}\_{\ell\_{1}\ell\_{2}L}-\frac{{\cal R}\_{L}^{\phi z}}{{\cal R}\_{L}^{zz}}W^{z}\_{\ell\_{1}\ell\_{2}L},$ |  | (64) |

where ${\cal R}\_{L}^{\phi z}$ and ${\cal R}\_{L}^{zz}$ are generalizations of Eq. ([48](#A1.E48 "Equation 48 ‣ A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")), and $W^{z}\_{\ell\_{1}\ell\_{2}L}$ is the matched filter for
${\cal W}^{z}\_{\ell\_{1}\ell\_{2}L}$.
This method is potentially less susceptible to errors in the mean-field estimate (due to inaccuracies in the simulations used to obtain it), although it has several caveats that are discussed in more detail in [Namikawa et al. (2013)](#bib.bib31).

## Appendix C Power spectrum likelihood

Here, we provide more detail on the components of our lensing likelihood (given in Eq. [3](#S2.E3 "Equation 3 ‣ 2 Data and methodology ‣ Planck 2015 results. XV. Gravitational lensing"), and copied below for convenience)

|  |  |  |  |
| --- | --- | --- | --- |
|  | $-2\log{\cal L}\_{\phi}={\cal B}\_{i}^{L}(\hat{C}\_{L}^{\phi\phi}-C\_{L}^{\phi\phi,{\rm th}})\left[\Sigma^{-1}\right]^{ij}{\cal B}\_{j}^{L^{\prime}}(\hat{C}\_{L^{\prime}}^{\phi\phi}-C\_{L^{\prime}}^{\phi\phi,{\rm th}}).$ |  | (65) |

The bandpower binning function ${\cal B}\_{i}^{L}$ is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal B}\_{i}^{L}=\frac{C\_{L}^{\phi\phi,\ {\rm fid}}V\_{L}^{-1}}{\sum\_{L^{\prime}=L\_{\rm min}^{i}}^{L\_{\rm max}^{i}}\left(C\_{L^{\prime}}^{\phi\phi,\thinspace{\rm fid}}\right)^{2}V\_{L^{\prime}}^{-1}},$ |  | (66) |

where $V\_{L}$ is an approximation to the variance of the power spectrum estimate.
For a given cross-spectrum between estimators $x$ and $y$ we use

|  |  |  |  |
| --- | --- | --- | --- |
|  | $V\_{L}^{-1}=\frac{2L+1}{2f^{-1}\_{\rm sky}}{\cal R}\_{L}^{x\phi}{\cal R}\_{L}^{y\phi},$ |  | (67) |

which produces minimum-variance estimates of the lensing amplitude for each bin
in the limit that the sample variance of the lenses is negligible
(a reasonable approximation for Planck, which is noise dominated on any individual mode).

The dependence of the likelihood on cosmological parameters enters through the ‘theory’ spectrum
$C\_{L}^{\phi\phi,{\rm th}}$. This is the expected value of the estimated spectrum at each point in parameter space. It depends on the cosmological parameters ${\boldsymbol{\theta}}$ in several ways:

* $\bullet$

  directly, through the theory spectrum $\left.C\_{L}^{\phi\phi}\right|\_{\boldsymbol{\theta}}$;
* $\bullet$

  indirectly (but linearly) on $\left.C\_{L}^{\phi\phi}\right|\_{\boldsymbol{\theta}}$, via the theory-dependence of $N^{(1)}$ (Eq. [57](#A1.E57 "Equation 57 ‣ A.3 Power spectrum estimation ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")); and
* $\bullet$

  indirectly, and non-linearly, on the CMB power spectra $C\_{\ell}^{TT}$, $C\_{\ell}^{TE}$, and $C\_{\ell}^{EE}$ through the estimator normalization and $N^{(1)}$ (from the theory-dependent covariance response ${\cal W}$ of Eq. [45](#A1.E45 "Equation 45 ‣ A.2 Quadratic estimators ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")).

We neglect any other theory dependence, for example in the MC correction that is hard to quantify.
In detail, for a given set of cosmological parameters ${\boldsymbol{\theta}}$, we should calculate

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{L}^{\phi\phi,{\rm th}}=\frac{\left.({\cal R}\_{L}^{x\phi}{\cal R}\_{L}^{y\phi})\right|\_{{\boldsymbol{\theta}}}}{\left.({\cal R}\_{L}^{x\phi}{\cal R}\_{L}^{y\phi})\right|\_{\rm fid.}}\left.C\_{L}^{\phi\phi}\right|\_{{\boldsymbol{\theta}}}-\left.\Delta C\_{L,xy}^{\phi\phi}\right|\_{\textsc{N}1,\ {\rm fid}}+\left.\Delta C\_{L,xy}^{\phi\phi}\right|\_{\textsc{N}1,\ {\boldsymbol{\theta}}},$ |  | (68) |

where the ${\cal W}$ component of the response functions ${\cal R}$ in the numerator, as well as the $N^{(1)}$ term, are calculated using the CMB power spectra for parameters ${\boldsymbol{\theta}}$.

Fully recalculating everything for each point in parameter space is prohibitively slow, but for small deviations from the fiducial model we can use a linearized approximation. The dependence on $\left.C\_{L}^{\phi\phi}\right|\_{\boldsymbol{\theta}}$ is already linear, and expanding the CMB power spectrum dependence to linear order about the fiducial model
we can write

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{L}^{\phi\phi,{\rm th}}\approx\left.C\_{L}^{\phi\phi}\right|\_{{\boldsymbol{\theta}}}+\frac{d\ln({\cal R}\_{L}^{x\phi}{\cal R}\_{L}^{y\phi})}{dC\_{\ell^{\prime}}^{j}}\left(\left.C\_{\ell^{\prime}}^{j}\right|\_{\boldsymbol{\theta}}-\left.C\_{\ell^{\prime}}^{j}\right|\_{\rm fid}\right)\left.C\_{L}^{\phi\phi}\right|\_{\rm fid}\\ +M^{(1)\phi}\_{LL^{\prime},xy}\left(\left.C\_{L^{\prime}}^{\phi\phi}\right|\_{\boldsymbol{\theta}}-\left.C\_{L^{\prime}}^{\phi\phi}\right|\_{\rm fid}\right)+\frac{\left.d\Delta C\_{L,xy}^{\phi\phi}\right|\_{\textsc{N}1}}{dC\_{\ell^{\prime}}^{j}}\left(\left.C\_{\ell^{\prime}}^{j}\right|\_{\boldsymbol{\theta}}-\left.C\_{\ell^{\prime}}^{j}\right|\_{\rm fid}\right),$ |  | (69) |

where $j$ sums over the various CMB power spectra.
The matrix $M^{(1)\phi}\_{LL^{\prime}}$ (from Eq. [57](#A1.E57 "Equation 57 ‣ A.3 Power spectrum estimation ‣ Appendix A Pipeline ‣ Planck 2015 results. XV. Gravitational lensing")) gives the exact linear dependence of $N^{(1)}$ on the lensing potential for fixed CMB power spectra, and can be pre-computed along with the other derivative matrices for the fiducial model. The binned likelihood of Eq. ([65](#A3.E65 "Equation 65 ‣ Appendix C Power spectrum likelihood ‣ Planck 2015 results. XV. Gravitational lensing")) then depends on a binned ‘theory’ power spectrum given in the linear approximation by

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal B}\_{i}^{L}C\_{L}^{\phi\phi,{\rm th}}\approx{\cal B}\_{i}^{L}\left.C\_{L}^{\phi\phi}\right|\_{\boldsymbol{\theta}}+M\_{i}^{a,\ell^{\prime}}\left(\left.C^{a}\_{\ell^{\prime}}\right|\_{\boldsymbol{\theta}}-\left.C^{a}\_{\ell^{\prime}}\right|\_{\rm fid}\right),$ |  | (70) |

where now $a$ sums over both the $C\_{L}^{\phi\phi}$ and CMB power spectra terms, and $M\_{i}^{a,\ell^{\prime}}$ can be pre-computed in the fiducial model.

The Planck lensing likelihood consists of bandpower estimates
${\cal B}\_{i}^{L}\hat{C}\_{L}^{\phi\phi}$ and the covariance $\Sigma\_{ij}$, a set of binning functions ${\cal B}\_{i}^{L}$, a set of linear-correction kernels $M\_{i}^{a,\ell^{\prime}}$, and the band values of the linear-correction kernel applied to the fiducial spectrum $M\_{i}^{a,\ell^{\prime}}C^{a}\_{\ell^{\prime}}|\_{\rm fid}$. Note that since the lensing estimator is independent of the CMB calibration, for a theory model $C^{j}\_{\ell}$ and map calibration parameter $y\_{\rm cal}$, the theory CMB power spectra that are used in Eq. ([70](#A3.E70 "Equation 70 ‣ Appendix C Power spectrum likelihood ‣ Planck 2015 results. XV. Gravitational lensing")) are those matched to the data, i.e.
$C^{j}\_{\ell}|\_{\boldsymbol{\theta}}=C^{j}\_{\ell}/y\_{\rm cal}^{2}$.

When evaluating ‘lensing-only’ likelihoods, where the CMB power spectra are only very weakly indirectly constrained, we fix the $C^{j}\_{\ell}|\_{\boldsymbol{\theta}}$ used in the linear correction to a best-fit to the full data. When calculating joint lensing and CMB results, the correction depends on the CMB power spectra at each point in model space.

## Appendix D CIB model

The cosmic infrared background (CIB) is a diffuse sky signal which
begins to dominate over the CMB at frequencies
$\nu\gtrsim 300\thinspace{\rm GHz}$.
It is generated by dust that is heated by UV light from young stars and then re-radiates thermally in the infrared.
The CIB contains approximately half of the total extragalactic stellar flux, and has excellent redshift overlap with the CMB lensing potential ([Song et al. 2003](#bib.bib57)).
In Sect. [3.2](#S3.SS2 "3.2 Lensing 𝐵-mode power spectrum ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing") we use the CIB as a tracer of the lensing potential to estimate the lensing-induced B-mode signal.
This requires a model for the cross-correlation between the CIB and the lensing potential.
We calculate this in the Limber approximation as ([Limber 1954](#bib.bib30))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{L}^{\text{{cib}-}\phi}=\int d\chi\frac{1}{\chi^{2}}K\_{L}^{\textsc{cib}}(\chi)K\_{L}^{\phi}(\chi)P(k=L/\chi;\eta\_{0}-\chi),$ |  | (71) |

where $P(k;\eta)$ is the (non-linear) matter power spectrum at comoving wavenumber $k$ and conformal time $\eta$.
The lensing kernel in flat models is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $K\_{L}^{\phi}(\chi)=-\frac{3\Omega\_{\rm m}H\_{0}^{2}}{a(\chi)}\left(\frac{\chi}{L}\right)^{2}\left(\frac{\chi\_{\*}-\chi}{\chi\_{\*}\chi}\right),$ |  | (72) |

where $a(\chi)$ is the scale factor at conformal time
$\eta\_{0}-\chi$
and
$\chi\_{\*}$ denotes the last scattering surface at $z\approx 1100$.
To model the CIB, we use the simple SSED model of [Hall et al. (2010)](#bib.bib16), which has a kernel given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $K\_{L}^{\textsc{cib}}(\chi)=b\_{c}\frac{\chi^{2}}{(1+z)^{2}}\exp\left(-\frac{(z-z\_{c})^{2}}{2\sigma\_{z}^{2}}\right)f\_{\nu(1+z)},$ |  | (73) |

where $b\_{c}$ is an overall normalization and $z\_{c}=\sigma\_{z}=2$ describe the redshift distribution of the CIB intensity. The redshift $z$ is evaluated at conformal time $\eta\_{0}-\chi$.
The spectral energy distribution (SED) of a typical CIB source is described by $f\_{\nu}$. It is modelled as a modified blackbody with temperature $T=34\thinspace\rm{K}$, and spectral index $\beta=2$ up to a threshold $\nu^{\prime}\approx 4955\thinspace\rm{GHz}$,
where it transitions to a power-law decay with index $\alpha=2$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\_{\nu}=\begin{cases}\left[\exp\left(\frac{h\nu}{kT}\right)-1\right]^{-1}\nu^{\beta+3}&(\nu\leq\nu^{\prime}),\\ \left[\exp\left(\frac{h\nu^{\prime}}{kT}\right)-1\right]^{-1}{\nu^{\prime}}^{\beta+3}\left(\frac{\nu}{\nu^{\prime}}\right)^{-\alpha}&(\nu>\nu^{\prime}).\end{cases}$ |  | (74) |

The precise value of $\nu^{\prime}$ is chosen to match smoothly the slope of $f\_{\nu}$ on both sides of the transition frequency.
In this model, the modified blackbody component of the SED is generally what we observe;
even at an observation frequency of $1200\thinspace{\rm GHz}$ (i.e. $250\thinspace\mu{\rm m}$), the power-law transition does not occur until $z\approx 4$.
Our theory curve is plotted in Fig. [17](#A4.F17 "Figure 17 ‣ Appendix D CIB model ‣ Planck 2015 results. XV. Gravitational lensing"), as well as
the measured cross-correlation of the Planck 2015 545 GHz map with the MV lensing potential estimate (over $40\thinspace\%$ of the sky).
In addition we have plotted the bandpowers from the rigorous analysis presented in the Planck 2013 data release ([Planck Collaboration
XVIII 2014](#bib.bib38)).
We have set the normalization $b\_{c}$ for the theory curve such that the overall amplitude is consistent with both measurements;
calculating $\chi^{2}$ values against the theory curve we find
PTEs of
$73\thinspace\%$ for the MV lensing potential estimator and
$49\thinspace\%$ for the
for the 13 plotted bins we find a
$\chi^{2}$ PTE with respect to the theory curve of $49\thinspace\%$.

Figure 17: 
Cross-correlation between the MV lensing potential estimate and the Planck 545 GHz channel (red points).
The cross-correlation uses a Galaxy mask leaving $40\thinspace\%$ of the sky.
The earlier result from [Planck Collaboration
XVIII (2014)](#bib.bib38) using a $TT$ lensing estimator is shown with green points.
The simple CIB model discussed in Appendix [D](#A4 "Appendix D CIB model ‣ Planck 2015 results. XV. Gravitational lensing")
is plotted as the black dashed line.

## Appendix E Parameter dependence of $C\_{L}^{\phi\phi}$ in $\Lambda$CDM models

In this appendix we discuss the dependence of the lensing potential power spectrum at multipoles $L\gtrsim 100$ on the parameters of $\Lambda$CDM models, providing results that are used in the discussion of the ‘lensing-only’ constraints in Sect. [3.5](#S3.SS5 "3.5 Likelihoods and cosmological parameter constraints ‣ 3 Results ‣ Planck 2015 results. XV. Gravitational lensing"). Since these constraints adopt a prior on $n\_{\rm s}$ that is rather tighter than the resulting posterior widths for $\Omega\_{\rm m}h^{2}$ and $h$, we ignore dependencies on $n\_{\rm s}$ throughout this appendix. We caution the reader that for joint constraints, or fits to the CMB power spectra alone, fractional variations in $n\_{\rm s}$ can be comparable to those in $\Omega\_{\rm m}h^{2}$ and $h$, so the dependence of $C\_{L}^{\phi\phi}$ on $n\_{\rm s}$ cannot be ignored.
The dependence of $C\_{L}^{\phi\phi}$ on the matter density was recently discussed in [Pan et al. (2014)](#bib.bib35); we follow their discussion closely.

For multipoles $L\gtrsim 20$, the angular power spectrum of the lensing potential can be Limber-approximated as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L^{4}C\_{L}^{\phi\phi}=4\int\_{0}^{\chi\_{\*}}d\chi\thinspace(k^{4}P\_{\Psi})(k=L/\chi;\eta\_{0}-\chi)(1-\chi/\chi\_{\*})^{2}$ |  | (75) |

in spatially-flat models. Here, $P\_{\Psi}(k;\eta)$ is the equal-time dimensional power spectrum of the Weyl potential $\Psi$. Well after baryon decoupling, we have∗
¶
∗¶\*¶∗
¶
∗¶\*¶
$\*¶$
We ignore the small effects of non-zero neutrino mass in the base $\Lambda$CDM model, so that the linear growth of structure is scale-independent well after baryon decoupling.

|  |  |  |  |
| --- | --- | --- | --- |
|  | $k^{4}P\_{\Psi}(k;\eta)\propto k\mathcal{P}\_{\mathcal{R}}(k)T^{2}(k)g^{2}(a)\thinspace,$ |  | (76) |

where $\mathcal{P}\_{\mathcal{R}}(k)$ is the dimensionless power spectrum of the primordial curvature perturbation $\mathcal{R}$, $T(k)$ is the transfer function,
and $g(a)$ is the growth function for the Weyl potential at scale factor $a$ normalized to unity at high redshift. In $\Lambda$CDM,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $g(a)=\frac{5\Omega\_{\rm m}E(a)}{2a}\int\_{0}^{a}\frac{da^{\prime}}{\left[a^{\prime}E(a^{\prime})\right]^{3}}\thinspace,$ |  | (77) |

where $\Omega\_{\rm m}$ is the matter fraction at the present and $E(a)\equiv H(a)/H\_{0}$. For $\Omega\_{\rm m}=0.3$, the current value of the growth function is $0.78$ and $d\ln g/d\ln\Omega\_{\rm m}=0.23$. Close to $\Omega\_{\rm m}=0.3$, we can approximate the cosmology dependence of the growth function at redshift zero as $g(a=1)\approx 0.78(\Omega\_{\rm m}/0.3)^{0.23}$. For $L>100$, the lensing potential mostly probes early enough times that $g(a)\approx 1$ is a good approximation ([Pan et al. 2014](#bib.bib35)). However, if we wish to express the amplitude of $P\_{\Psi}(k)$ at early times in terms of $\sigma\_{8}$ (at the present), we require $g(a=1)$.

The transfer function is normalized to unity for $k\ll k\_{\rm eq}$, where
$k\_{\rm eq}\sim 10^{-2}\thinspace\mathrm{Mpc}^{-1}$ the inverse of the comoving Hubble parameter at matter-radiation equality. For $k\gg k\_{\rm eq}$ we have $T(k)\sim(k/k\_{\rm eq})^{-2}\ln(k/k\_{\rm eq})$. Keeping the radiation energy density fixed today, $k\_{\rm eq}\propto\omega\_{\rm m}$, where $\omega\_{\rm m}\equiv\Omega\_{\rm m}h^{2}$. As well as $k\_{\rm eq}$, the other scales that enter the transfer function are the sound horizon at the drag epoch (when baryons dynamically decouple) $r\_{\rm drag}$, and the diffusion scale $k\_{\rm D}$. The broad-band shape is controlled by $k\_{\rm eq}$, while $r\_{\rm drag}$ determines the scale below which baryon suppression effects are important (see e.g. [Eisenstein & Hu 1998](#bib.bib11)). The non-zero baryon fraction $\omega\_{\rm b}/\omega\_{\rm m}$ tends to suppress the transfer function on small scales since (essentially) unclustered baryons impede the growth of the CDM density perturbation up to the time after decoupling when baryon infall into the CDM potential wells is complete. The further effect of baryons is to imprint baryon acoustic oscillations in the transfer function for $kr\_{\rm drag}>\pi$ and $k\mathrel{\raise 1.72218pt\hbox{\hbox to0.0pt{$<$\hss}\lower 5.16663pt\hbox{$\sim$}}}k\_{\rm D}$. Baryon acoustic oscillations have little impact on $C\_{L}^{\phi\phi}$ since they are washed out by the line-of-sight integration. We therefore ignore them here and, where an explicit form for the transfer function is required, for illustrative purposes we use the ‘no-wiggle’ fit of [Eisenstein & Hu (1998)](#bib.bib11). For the range of parameters of interest, we can assume that the physical baryon density $\omega\_{\rm b}$ is fixed, so the transfer function can be thought of as a function of $k/k\_{\rm eq}$, $kr\_{\rm drag}$ and $\omega\_{\rm m}$.

Ignoring departures of the growth function from unity and approximating $\mathcal{P}\_{\mathcal{R}}(k)$ as scale-invariant with amplitude $A\_{\rm s}$, we can write

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L^{4}C\_{L}^{\phi\phi}\propto A\_{\rm s}\ell\_{\rm eq}\int\_{0}^{1}dx\thinspace\left(\frac{L}{\ell\_{\rm eq}x}\right)T^{2}\left(\frac{L}{x\chi\_{\*}}\right)(1-x)^{2}\thinspace,$ |  | (78) |

where $x=\chi/\chi\_{\*}$ and $\ell\_{\rm eq}\equiv k\_{\rm eq}\chi\_{\*}\approx 140$. The $A\_{\rm s}\ell\_{\rm eq}$ prefactor has a simple physical interpretation: CMB photons are typically deflected by $\ell\_{\rm eq}$ lenses of size $k\_{\rm eq}^{-1}$, and each mean-squared deflection is proportional to $A\_{\rm s}$, giving a mean-squared deflection proportional to $A\_{\rm s}\ell\_{\rm eq}$. Given the $k$-dependencies of the transfer function through $k/k\_{\rm eq}$ and $kr\_{\rm drag}$, and its direct parameter-dependence on $\omega\_{\rm m}$, we see that in $\Lambda$CDM, the lensing power spectrum at $L\gtrsim 100$ is (mostly) determined by only $A\_{\rm s}$, $L/\ell\_{\rm eq}$, $L/\ell\_{\rm drag}$, and $\omega\_{\rm m}$. Here, the multipole $\ell\_{\rm drag}\equiv\chi\_{\*}/r\_{\rm drag}$ characterizes the BAO scale at last-scattering. The integral in Eq. ([78](#A5.E78 "Equation 78 ‣ Appendix E Parameter dependence of 𝐶_𝐿^{ϕ⁢ϕ} in ΛCDM models ‣ Planck 2015 results. XV. Gravitational lensing")) determines the shape of the lensing power spectrum. Defining

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\left(\frac{L}{\ell\_{\rm eq}},\frac{L}{\ell\_{\rm drag}},\omega\_{\rm m}\right)\equiv\int\_{0}^{1}dx\thinspace\left(\frac{L}{\ell\_{\rm eq}x}\right)T^{2}\left(\frac{L}{\chi\_{\*}x}\right)(1-x)^{2}\thinspace,$ |  | (79) |

the dependence on the cosmological parameters (e.g. $\ell\_{\rm eq}$) in the vicinity of the fiducial model is, at any $L$, approximately a product of power laws with exponents

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle n\_{L}^{\rm eq}$ | $\displaystyle\equiv$ | $\displaystyle-\left.\partial\ln f\_{L}/\partial\ln(L/\ell\_{\rm eq})\right|\_{\rm fid}\thinspace,$ |  | (80) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle n\_{L}^{\rm drag}$ | $\displaystyle\equiv$ | $\displaystyle-\left.\partial\ln f\_{L}/\partial\ln(L/\ell\_{\rm drag})\right|\_{\rm fid}\thinspace,$ |  | (81) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle n\_{L}^{\rm m}$ | $\displaystyle\equiv$ | $\displaystyle\left.\partial\ln f\_{L}/\partial\ln\omega\_{\rm m}\right|\_{\rm fid}\thinspace,$ |  | (82) |

each evaluated for the fiducial cosmology. Note also that
$n\_{L}^{\rm eq}$ and $n\_{L}^{\rm drag}$ determine the local power-law slope of $C\_{L}^{\phi\phi}$, with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n\_{L}^{\rm eq}+n\_{L}^{\rm drag}=-d\ln(L^{4}C\_{L}^{\phi\phi})/d\ln L\thinspace.$ |  | (83) |

On the angular scales where Eq. ([78](#A5.E78 "Equation 78 ‣ Appendix E Parameter dependence of 𝐶_𝐿^{ϕ⁢ϕ} in ΛCDM models ‣ Planck 2015 results. XV. Gravitational lensing")) is valid, only modes with $k>k\_{\rm eq}$ contribute. For these scales, $(k/k\_{\rm eq})T^{2}(k)$ increases with $k\_{\rm eq}$ giving $n\_{L}^{\rm eq}>0$ (and monotonic increase of $n\_{L}^{\rm eq}$ with $L$).
Around $L=200$, the scales that dominate the $S/N$ of a lensing amplitude measurement from Planck, $n\_{L}^{\rm eq}\approx 0.9$. This, and $A\_{\rm s}$, dominate the parameter dependence of $C\_{L}^{\phi\phi}$. The effect of baryon suppression is reduced as $\omega\_{\rm m}$ increases at fixed $\omega\_{\rm b}$, so $n\_{L}^{\rm m}>0$ and also rises monotonically with $L$. Around $L=200$, we find $n\_{L}^{\rm m}\approx 0.3$, which gives a small, but non-negligible, further parameter dependence to $C\_{L}^{\phi\phi}$. Finally, the dependence on $\ell\_{\rm drag}$ is very small, since $n\_{L}^{\rm drag}\leq 0.15$ (with peak value around $L\approx 100$, roughly equal to $\ell\_{\rm drag}$). Putting these pieces together, we find a dependence of $L^{4}C\_{L}^{\phi\phi}$ on cosmological parameters scaling approximately as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L^{4}C\_{L}^{\phi\phi}\propto A\_{\rm s}\ell\_{\rm eq}^{n\_{L}^{\rm eq}+1}\ell\_{\rm drag}^{n\_{L}^{\rm drag}}\omega\_{\rm m}^{n\_{L}^{\rm m}}\thinspace,$ |  | (84) |

for $L\gtrsim 100$, where the dependence on $\ell\_{\rm drag}$ is very weak.

We can express the parameter dependence of $C\_{L}^{\phi\phi}$ in terms of the usual $\Lambda$CDM parameters. The comoving distance to last-scattering, $\chi\_{\*}$, is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\chi\_{\*}=\int\_{a\_{\*}}^{1}\frac{da}{a^{2}H(a)}\thinspace,$ |  | (85) |

where $a\_{\*}$ is the scale factor at last-scattering (whose dependence on cosmology can be ignored here).
At fixed radiation energy density today, the dependence on $\Omega\_{\rm m}$ and $h$ is approximately

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\chi\_{\*}\propto\Omega\_{\rm m}^{-0.4}h^{-1}\thinspace,$ |  | (86) |

around $\Omega\_{\rm m}=0.3$ and $h=0.7$.∗
∥
∗∥\*∥∗
∥
∗∥\*∥
$\*∥$
We ignore the small dynamical effects of radiation at high redshift. This differs from the $(\Omega\_{\rm m}h^{2})^{-1/2}$ of an Einstein-de Sitter universe due to the late-time effects of $\Lambda$. Using $k\_{\rm eq}\propto\Omega\_{\rm m}h^{2}$, we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\ell\_{\rm eq}\propto\Omega\_{\rm m}^{0.6}h\thinspace.$ |  | (87) |

At fixed baryon density, the sound horizon at the drag epoch scales like $r\_{\rm drag}\propto\omega\_{\rm m}^{-0.25}$ in the vicinity of the fiducial model, so that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\ell\_{\rm drag}\propto\Omega\_{\rm m}^{-0.15}h^{-0.5}\thinspace.$ |  | (88) |

Using these dependencies in Eq. ([84](#A5.E84 "Equation 84 ‣ Appendix E Parameter dependence of 𝐶_𝐿^{ϕ⁢ϕ} in ΛCDM models ‣ Planck 2015 results. XV. Gravitational lensing")), we find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $L^{4}C\_{L}^{\phi\phi}\propto A\_{\rm s}\left(\Omega\_{\rm m}^{0.6}h\right)^{n\_{L}+1}\Omega\_{\rm m}^{0.15\times n\_{L}^{\rm drag}-0.2\times n\_{L}^{\rm m}}\thinspace,$ |  | (89) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n\_{L}\equiv n\_{L}^{\rm eq}-0.5\times n\_{L}^{\rm drag}+2n\_{L}^{\rm m}$ |  | (90) |

is approximately $1.5$ at $L=200$. The remaining dependence on $\Omega\_{\rm m}$ is very weak, with $0.15\times n\_{L}^{\rm drag}-0.2\times n\_{L}^{\rm m}\approx-0.05$ at $L=200$. Equation ([89](#A5.E89 "Equation 89 ‣ Appendix E Parameter dependence of 𝐶_𝐿^{ϕ⁢ϕ} in ΛCDM models ‣ Planck 2015 results. XV. Gravitational lensing")) gives the main dependence of the lensing power spectrum on the cosmological parameters of $\Lambda$CDM models at multipoles $L\gtrsim 100$.

### E.1 Normalization by $\sigma\_{8}$

The dependence of the lensing power spectrum on $A\_{\rm s}$ can be eliminated in favour of $\sigma\_{8}$. We use the Poisson equation to relate the dimensional matter power spectrum at $a=1$ to that of the Weyl potential, giving

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P\_{\delta}(k;a=1)\propto\omega\_{\rm m}^{-2}k^{4}P\_{\Psi}(k;a=1)\thinspace.$ |  | (91) |

It follows that the variance of the density contrast in spheres of radius $R$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\sigma\_{R}^{2}$ | $\displaystyle\propto\omega\_{\rm m}^{-2}g^{2}(a=1)\int dk\thinspace k^{3}\mathcal{P}\_{\mathcal{R}}(k)T^{2}(k)W^{2}(kR)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\propto A\_{\rm s}k\_{\rm eq}^{4}\omega\_{\rm m}^{-2}g^{2}(a=1)\int\_{0}^{\infty}dx\thinspace x^{3}T^{2}(xk\_{\rm eq})W^{2}(xk\_{\rm eq}R)\thinspace,$ |  | (92) |

where we have assumed that $\mathcal{P}\_{\mathcal{R}}(k)$ is scale-invariant in passing to the second line. The window function

|  |  |  |  |
| --- | --- | --- | --- |
|  | $W(kR)\equiv\frac{3j\_{1}(kR)}{kR}=\frac{3}{(kR)^{3}}(kR\cos kR-\sin kR)\thinspace,$ |  | (93) |

is the Fourier transform of a normalized spherical top-hat function of radius $R$; following convention, we take $R=8h^{-1}\thinspace\mathrm{Mpc}$.

The integral in Eq. ([92](#A5.E92 "Equation 92 ‣ E.1 Normalization by 𝜎_8 ‣ Appendix E Parameter dependence of 𝐶_𝐿^{ϕ⁢ϕ} in ΛCDM models ‣ Planck 2015 results. XV. Gravitational lensing")) is a function of $k\_{\rm eq}R$, $k\_{\rm eq}r\_{\rm drag}$, and $\omega\_{\rm m}$ at fixed baryon density (with the latter two from the transfer function). Evaluating the logarithmic derivative with respect to these parameters at the fiducial values, using the ‘no-wiggle’ transfer function from [Eisenstein & Hu (1998)](#bib.bib11), we find that the integral scales as $(k\_{\rm eq}R)^{-1.4}\omega\_{\rm m}^{0.45}$, with only a very weak further dependence on $k\_{\rm eq}r\_{\rm drag}$, in the vicinity of the fiducial model. Finally, the parameter dependence of $\sigma\_{8}^{2}$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\sigma\_{8}^{2}$ | $\displaystyle\propto A\_{\rm s}k\_{\rm eq}^{4}\omega\_{\rm m}^{-2}g^{2}(a=1)(k\_{\rm eq}h^{-1})^{-1.4}\omega\_{\rm m}^{0.45}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\propto A\_{\rm s}\Omega\_{\rm m}^{1.5}h^{3.5}\thinspace.$ |  | (94) |

This parameter dependence agrees well with direct finite-differencing of $\sigma\_{8}$ calculations with CAMB.
