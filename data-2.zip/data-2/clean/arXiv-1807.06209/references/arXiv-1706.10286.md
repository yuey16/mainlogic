<!-- fulltext source=arxiv_html slug=arXiv-1706.10286 fetched=2026-09-18T00:58:38+00:00 -->

# A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite

K. Aylor,
Z. Hou,
L. Knox,
K. T. Story,
B. A. Benson,
L. E. Bleem,
J. E. Carlstrom,
C. L. Chang,
H-M. Cho,
R. Chown,
T. M. Crawford,
A. T. Crites,
T. de Haan,
M. A. Dobbs,
W. B. Everett,
E. M. George,
N. W. Halverson,
N. L. Harrington,
G. P. Holder,
W. L. Holzapfel,
J. D. Hrubes,
R. Keisler,
A. T. Lee,
E. M. Leitch,
D. Luong-Van,
D. P. Marrone,
J. J. McMahon,
S. S. Meyer,
M. Millea,
L. M. Mocanu,
J. J. Mohr,
T. Natoli,
Y. Omori,
S. Padin,
C. Pryke,
C. L. Reichardt,
J. E. Ruhl,
J. T. Sayre,
K. K. Schaffer,
E. Shirokoff,
Z. Staniszewski,
A. A. Stark,
K. Vanderlinde,
J. D. Vieira, and
R. Williamson

Alternate Affiliation: Department of Physics, University of California, Davis, CA, USA 95616
Alternate Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, Chicago, IL, USA 60637
Alternate Affiliation: Department of Astronomy and Astrophysics, University of Chicago, Chicago, IL, USA 60637
Alternate Affiliation: Kavli Institute for Particle Astrophysics and Cosmology, Stanford University, 452 Lomita Mall, Stanford, CA 94305
Alternate Affiliation: Dept. of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305
Alternate Affiliation: Fermi National Accelerator Laboratory, MS209, P.O. Box 500, Batavia, IL 60510
Alternate Affiliation: High Energy Physics Division, Argonne National Laboratory, Argonne, IL, USA 60439
Alternate Affiliation: Department of Physics, University of Chicago, Chicago, IL, USA 60637
Alternate Affiliation: Enrico Fermi Institute, University of Chicago, Chicago, IL, USA 60637
Alternate Affiliation: SLAC National Accelerator Laboratory, 2575 Sand Hill Road, Menlo Park, CA 94025
Alternate Affiliation: Department of Physics and McGill Space Institute, McGill University, Montreal, Quebec H3A 2T8, Canada
Alternate Affiliation: California Institute of Technology, Pasadena, CA, USA 91125
Alternate Affiliation: Department of Physics, University of California, Berkeley, CA, USA 94720
Alternate Affiliation: Canadian Institute for Advanced Research, CIFAR Program in Cosmology and Gravity, Toronto, ON, M5G 1Z8, Canada
Alternate Affiliation: Center for Astrophysics and Space Astronomy, Department of Astrophysical and Planetary Sciences, University of Colorado, Boulder, CO, 80309
Alternate Affiliation: European Southern Observatory, Karl-Schwarzschild-Straße 2, 85748 Garching, Germany
Alternate Affiliation: Department of Physics, University of Colorado, Boulder, CO, 80309
Alternate Affiliation: Astronomy Department, University of Illinois at Urbana-Champaign, 1002 W. Green Street, Urbana, IL 61801, USA
Alternate Affiliation: Department of Physics, University of Illinois Urbana-Champaign, 1110 W. Green Street, Urbana, IL 61801, USA
Alternate Affiliation: University of Chicago, Chicago, IL, USA 60637
Alternate Affiliation: Physics Division, Lawrence Berkeley National Laboratory, Berkeley, CA, USA 94720
Alternate Affiliation: Steward Observatory, University of Arizona, 933 North Cherry Avenue, Tucson, AZ 85721
Alternate Affiliation: Department of Physics, University of Michigan, Ann Arbor, MI, USA 48109
Alternate Affiliation: Faculty of Physics, Ludwig-Maximilians-Universität, 81679 München, Germany
Alternate Affiliation: Excellence Cluster Universe, 85748 Garching, Germany
Alternate Affiliation: Max-Planck-Institut für extraterrestrische Physik, 85748 Garching, Germany
Alternate Affiliation: Dunlap Institute for Astronomy & Astrophysics, University of Toronto, 50 St George St, Toronto, ON, M5S 3H4, Canada
Alternate Affiliation: Department of Physics, University of Minnesota, Minneapolis, MN, USA 55455
Alternate Affiliation: School of Physics, University of Melbourne, Parkville, VIC 3010, Australia
Alternate Affiliation: Physics Department, Center for Education and Research in Cosmology and Astrophysics, Case Western Reserve University,Cleveland, OH, USA 44106
Alternate Affiliation: Liberal Arts Department, School of the Art Institute of Chicago, Chicago, IL, USA 60603
Alternate Affiliation: Jet Propulsion Laboratory, California Institute of Technology, Pasadena, CA 91109, USA
Alternate Affiliation: Harvard-Smithsonian Center for Astrophysics, Cambridge, MA, USA 02138
Alternate Affiliation: Department of Astronomy & Astrophysics, University of Toronto, 50 St George St, Toronto, ON, M5S 3H4, Canada

###### Abstract

The Planck cosmic microwave background (CMB) temperature data
are best fit with a $\Lambda$CDM model that is in mild tension with constraints from other cosmological probes. The South Pole Telescope (SPT) 2540 $\text{deg}^{2}$ SPT-SZ survey offers measurements on
sub-degree angular scales (multipoles $650\leq\ell\leq 2500$) with sufficient precision to use as an independent check of the Planck data. Here we build on the recent joint analysis of the SPT-SZ and Planck data in [Hou et al. [8]](#bib.bib8) by comparing $\Lambda$CDM parameter estimates using the temperature power spectrum from both data sets in the SPT-SZ survey region. We also restrict the multipole range used in parameter fitting to focus on modes measured well by both SPT and Planck, thereby greatly reducing sample variance as a driver of parameter differences and creating a stringent test for systematic errors.
We find no evidence of systematic errors from such tests.
When we expand the maximum multipole of SPT data used, we see low-significance shifts in the angular scale of the sound horizon and the physical baryon and cold dark matter
densities, with a resulting trend to higher Hubble constant.
When we compare SPT and Planck data on the SPT-SZ sky patch to Planck full-sky data but keep the multipole range restricted,
we find differences in the parameters $n\_{s}$ and $A\_{s}e^{-2\tau}$.
We perform further checks, investigating instrumental effects and modeling assumptions, and we find no evidence that the effects investigated are responsible for any of the parameter shifts.
Taken together, these tests reveal no evidence for systematic errors in SPT or Planck data in the overlapping sky coverage and multipole range and, at most, weak evidence for a breakdown of $\Lambda$CDM or systematic errors influencing either the Planck data outside the SPT-SZ survey area or the SPT data at $\ell>2000$.

###### Subject headings

cosmic background radiation

## I. Introduction

Anisotropies in the cosmic microwave background (CMB) have provided a wealth of information about the universe.
The CMB temperature anisotropy power spectrum in particular provides some of the tightest current constraints
on cosmological models.
The most precise measurement of the CMB temperature power spectrum at medium and large angular scales has been made by the Planck satellite as published in the February 2015 Planck data release [[16](#bib.bib16)].
Sensitive measurements of the CMB temperature anisotropy have also been made using ground-based telescopes such as the South Pole Telescope [[5](#bib.bib5), SPT,] and the Atacama Cosmology Telescope [[23](#bib.bib23), ACT,].
[Story et al. [22, hereafter S13]](#bib.bib22) used SPT data from the 2540 deg2 SPT-SZ survey to make the most precise measurement of the CMB temperature power spectrum damping tail above angular multipoles $\ell\sim 2000$ and a measurement at $650\leq\ell\leq 2000$ second only to Planck in precision.

With the exquisite precision of the Planck measurements, signs of moderate tension have been noted between cosmological parameters estimated from the Planck CMB power spectra and other cosmological measurements.
For example, in [[20](#bib.bib20)], the value of $H\_{0}$ determined from measurements of type Ia supernovae, calibrated with Cepheids, is found to be inconsistent with the Planck value by 3$\sigma$.
Additionally, the amplitude of density fluctuations in the local universe implied by Planck CMB power spectrum data
disagrees with certain local measurements of the density fluctuations at the $2\sigma$ level
[[11](#bib.bib11), [17](#bib.bib17), e.g.,].

Some tension has also been noted between the cosmological parameter constraints from
measurements of the CMB using different instruments or multipole ranges.
Many authors, including [Calabrese et al. [4]](#bib.bib4), have demonstrated 1-2$\sigma$ differences
in the values of $H\_{0}$ and $\sigma\_{8}$ between pre-Planck and Planck data.
[[2](#bib.bib2)] point out discrepancies between cosmological parameters determined from two halves
of the Planck data (split at $\ell=1000$), and between the best-fit cosmologies of Planck and SPT,
although [[18](#bib.bib18)] argue that these discrepancies are statistically insignificant.

While the statistical significance of these reported discrepancies ranges from low to moderate, they could be hints of the $\Lambda$CDM model breaking down or systematic contamination in one or more of the measurements.
Because Planck and SPT provide the most precise temperature power spectrum measurements, it is particularly important to carefully investigate any differences between these two data sets.

In a previous paper, [Hou et al. [8, hereafter H17]](#bib.bib8) compared the SPT-SZ and Planck data at the map
and power-spectrum level, in a study similar to that performed by [Louis et al. [14]](#bib.bib14) on ACT and Planck data. H17 used the Planck 143 GHz and SPT 150 GHz maps to create three sets of binned power spectrum measurements, or “bandpowers,” in the SPT-SZ sky patch, namely: the cross-spectrum of two independent halves of the Planck 143 GHz data ($143\times 143$), the cross-spectrum of the SPT 150 GHz data and Planck 143 GHz data ($150\times 143$), and the cross-spectrum of two independent halves of the SPT 150 GHz data ($150\times 150$).
We will refer to these collectively as the “in-patch” bandpowers.
In H17, these bandpowers were shown to be consistent with each other and marginally consistent with the bandpowers obtained from the full Planck map.
In this paper, we extend this comparison to the cosmological parameters obtained from these bandpowers
and the Planck full-sky power spectrum.

We start by comparing the best-fit parameters obtained from the full-sky Planck data
and the best-fit parameters from the SPT-SZ data, with a null hypothesis that the $\Lambda$CDM model is correct and
the statistical models of both data sets are accurate.
Under this null hypothesis, the parameters derived from the two datasets are marginally discrepant—the $\chi^{2}$ values for these parameter differences should be larger only $3.2\%$ of the time (the probability to exceed the $\chi^{2}$ between the parameter sets is $0.032$; see Section 3 for details).
Assuming the null hypothesis is correct, this $3.2\%$ probability must be understood as resulting from a somewhat (but not highly) unlikely statistical fluctuation.
Other possible explanations include uncharacterized systematic errors or a breakdown in $\Lambda$CDM.
In this paper, we attempt to discriminate between these three possibilities.

After quantifying the discrepancy in parameters determined from the full SPT and Planck temperature power spectra,
we test for systematics by restricting the SPT-SZ and Planck datasets to the anisotropy modes measured well in both datasets. Specifically, we restrict both datasets to the SPT-SZ footprint, using the H17 in-patch
bandpowers, and consider a fixed multipole range. Such a restriction greatly reduces the covariance of parameter differences given our null hypothesis by eliminating nearly all the sample variance contribution.

After testing for systematic errors with the restricted data sets, we test for other potential sources of the observed parameter differences between the full data sets.
We first explore how parameters shift when the in-patch bandpowers are restricted to different ranges of angular scales; this tests for scale-dependent systematics or an inadequate cosmological model.
Next we study how parameters shift from the in-patch bandpowers to the full-sky Planck bandpowers; this tests if the SPT-SZ patch is sufficiently unusual to challenge the assumptions of statistical isotropy and Gaussianity underlying our cosmological model or if there are systematic errors in the Planck data outside of the SPT-SZ patch.
We also discuss influence on parameters of the tilt in the in-patch bandpowers relative to Planck full-sky data first noted in H17.

Finally, we explore several other factors that could cause the mild tension between the Planck- and SPT-derived parameters.
We examine the SPT foreground model, the SPT calculation of beam uncertainty, the SPT $\tau$ prior, and the effects of lensing.
These tests probe analysis and uncertainty modeling choices that could introduce systematic differences.

This paper is organized as follows. In Section 2 we describe our methodology for parameter estimation and comparison. In Section 3 we explore the consistency of Planck and SPT parameters estimated from the full data sets and from data restricted to the same sky patch and multipole range. In Section 4 we test for sources of systematic error from the foregrounds and beam uncertainty. We also discuss the influence of lensing and the $\tau$ prior on the parameter estimates. The conclusions are presented in Section 5.

## II. Parameter Estimation and Comparison Methodology

### II.1. Bandpowers

Several of our tests in this work make use of the publicly available Planck 2015 baseline high-$\ell$ temperature and low-$\ell$ temperature and polarization bandpowers. These are optimally combined multi-frequency bandpowers, and we refer to these as the Planck Full Sky (PlanckFS) bandpowers [[19](#bib.bib19)]. The Planck parameters we use are obtained from the baseline $\Lambda$CDM Monte Carlo Markov Chain (MCMC, [Planck Collaboration et al. 16](#bib.bib16)). We also use the designation PlanckFS to refer to the parameter estimates from this chain.

We also use bandpowers created from the SPT-SZ 150 GHz and Planck 143 GHz maps of the 2540 ${\rm deg^{2}}$ SPT-SZ survey region.
We refer to the cross-correlation of two half-depth maps as either $150\times 150$ or $143\times 143$.
The cross-spectrum $150\times 143$ is the correlation of the full-depth SPT and full-depth Planck maps.
A detailed description of the creation of these bandpowers is provided by H17.

### II.2. Cosmological Parameter Likelihood

Figure 1.— The parameter estimates for S13, S13\* (obtained from the same bandpowers as S13 but with the likelihood modifications discussed in Section [II.4](#S2.SS4 "II.4. Changes to Likelihood Since S13 ‣ II. Parameter Estimation and Comparison Methodology ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite")), and $150\times 150$ (H17). The vertical bars are the $1\sigma$ PlanckFS parameter constraints.
The estimates are based on the multipole range of $650\leq\ell\leq 3000$. The shift in $A\_{s}e^{-2\tau}$ and the reduction in the error bar on that parameter combination, between S13 and S13\*, come from a combination of the new calibration constraint from H17 and the correction of a bias in the calibration uncertainty treatment. The shift in $n\_{s}$ comes from the correction of the beam uncertainty bias. The shift in $\theta\_{MC}$ is primarily due to the inclusion of aberration effects.

We obtain parameter estimates by searching the space defined by the likelihood of the cosmological and nuisance parameters $\mathbf{\Theta}$ given the data $\mathbf{D}^{i\times j}$, a set of temperature bandpowers where $i$ and $j$ both run over the two frequency bands (143 GHz for Planck and 150 GHz for SPT). We assume the likelihood to take the following form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}-2\ln\mathcal{L}(\mathbf{\Theta}|\mathbf{D}^{i\times j})=(D^{i\times j}\_{b}-M^{i\times j}\_{b})(\Sigma\_{bb^{\prime}}^{i\times j})^{-1}(D^{i\times j}\_{b^{\prime}}\\ -M^{i\times j}\_{b^{\prime}}),\end{split}$ |  | (1) |

where $\Sigma\_{bb^{\prime}}^{i\times j}$ is the bandpower covariance, and the model temperature bandpowers are expressed as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $M^{i\times j}\_{b}=Y^{i}Y^{j}W\_{b\ell}^{i\times j}(D^{th}\_{\ell}+F\_{\ell}^{i\times j})a\_{\ell}=W\_{b\ell}^{i\times j}M^{i\times j}\_{\ell}$ |  | (2) |

for $i,j\in[143,150]$, and we have ignored the normalization constant in the likelihood. The $Y^{i},Y^{j}$ terms are temperature calibration parameters , $W\_{b\ell}^{i\times j}$ is the bandpower window function [[12](#bib.bib12), e.g.,], and $F\_{\ell}^{i\times j}$ is the foreground model from [[22](#bib.bib22)] with frequency dependence included [[6](#bib.bib6)]. The term $a\_{\ell}$ includes aberration effects due to our proper motion with respect to the CMB as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $a\_{\ell}=1-\frac{d\ln C\_{\ell}}{d\ln\ell}\beta\left<\cos\theta\right>,$ |  | (3) |

based on [[9](#bib.bib9)] and with $\beta=1.23\times 10^{-3}$ and $\left<\cos\theta\right>=-0.26$.

The calibration parameters are based on work from H17 where the three in-patch bandpowers are simultaneously calibrated to each other over the common multipole range. The calibration parameters are fixed to 1 for $Y^{143}$ and have a Gaussian prior of $Y^{150}=0.9914\pm 0.0017$.11
1
Note that our comparisons between parameters from 150x143 and 143x143 with parameters from PlanckFS have inconsistent treatments of 143 GHz calibration uncertainty.
In the former two the uncertainty is set to zero, while in the latter the 0.07% absolute calibration uncertainty reported by the Planck team is included.
We expect that these inconsistent treatments have negligible impact on our results due to the fact that a 0.07% map-level calibration uncertainty would be a highly sub-dominant contribution to any of our in-patch parameter uncertainties; for example, the fractional uncertainty on $A\_{\rm s}e^{-2\tau}$ is approximately 3% for 143x143.
We also find that fixing the relative calibration uncertainty between Planck and SPT has negligible impact on our parameter comparisons.

We use the May 2016 version of CAMB [[13](#bib.bib13)] to calculate the theoretical prediction for the lensed temperature power spectrum ($D^{th}\_{\ell}$) assuming the standard $\Lambda$CDM model. Our free parameters are: the approximation to the
angular scale of the sound horizon, $\theta\_{MC}$, the baryon and total matter densities, $\Omega\_{b}h^{2}$ and $\Omega\_{m}h^{2}$, the scalar amplitude, $A\_{s}e^{-2\tau}$,
and the scalar spectral index, $n\_{s}$.
While the Hubble constant $H\_{0}$ is derived from these five parameters, we discuss it throughout this work
because the discrepancy between the CMB-determined value of $H\_{0}$ and local measurements is of particular interest.
We place a Gaussian prior on the optical depth $\tau$ of $0.07\pm 0.02$.

Our parameter vector also includes six nuisance parameters.
The $Y^{i}Y^{j}$ term is treated as a single parameter, and we include five parameters for foregrounds (three for the template amplitudes and two for the frequency dependence), giving $\mathbf{\Theta}$ a total of twelve elements.
All other parameters are fixed to the baseline model values from [[16](#bib.bib16)] which are the default settings for the May 2016 version of CAMB.

### II.3. The Covariance for the In-patch Bandpowers

The covariances for the bandpowers $150\times 150$, $143\times 143$, and $150\times 143$ contain sample and noise variance along with beam uncertainty. A correlation matrix is formed for each source of beam uncertainty as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\rho^{B,i\times j}\_{\ell\ell^{\prime}}=\bigg(\frac{\delta D\_{\ell}}{D\_{\ell}}^{B,i\times j}\bigg)\bigg(\frac{\delta D\_{\ell^{\prime}}}{D\_{\ell^{\prime}}}^{B,i\times j}\bigg)$ |  | (4) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{\delta D\_{\ell}}{D\_{\ell}}^{B,i\times j}=\bigg(1+\frac{\delta B\_{\ell}}{B\_{\ell}}^{i}\bigg)^{-1}\bigg(1+\frac{\delta B\_{\ell}}{B\_{\ell}}^{j}\bigg)^{-1}-1$ |  | (5) |

and $\frac{\delta B\_{\ell}}{B\_{\ell}}^{i}$ is either the Planck 143 GHz or the SPT-SZ 150 GHz fractional beam uncertainty template. The SPT beam functions ($B\_{\ell}$) and their uncertainty ($\delta B\_{\ell}$) are determined using a combination of maps from Jupiter, Venus, and
the 18 brightest point sources in the SPT patch.
We refer the reader to S13 and [[21](#bib.bib21)] for more details on the creation of the beam templates. The correlation matrix $\rho^{B,i\times j}\_{\ell\ell^{\prime}}$ is then added into the full covariance as

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Sigma\_{bb^{\prime}}^{i\times j}$ | $\displaystyle=\Sigma\_{bb^{\prime}}^{S,i\times j}+\Sigma\_{bb^{\prime}}^{N,i\times j}+\Sigma\_{bb^{\prime}}^{B,i\times j}$ |  | (6) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Sigma^{B,i\times j}\_{bb^{\prime}}$ | $\displaystyle=W\_{b\ell}^{i\times j}W\_{b^{\prime}\ell^{\prime}}^{i\times j}M^{i\times j}\_{\ell}M^{i\times j}\_{\ell^{\prime}}\rho^{B,i\times j}\_{\ell\ell^{\prime}},$ |  | (7) |

where $S$, $N$ and $B$ superscripts signify the sample, noise, and beam covariances respectively.

[[19](#bib.bib19)] show that the uncertainty in the Planck beams has less than a 0.2% impact on $143\times 143$ bandpowers, and the resulting impact on parameter estimation is also extremely small
[[16](#bib.bib16)].
We thus make the simplifying assumption that $\frac{\delta B\_{\ell}}{B\_{\ell}}^{143}=0$.

### II.4. Changes to Likelihood Since S13

In 2013, S13 presented the SPT-SZ 150 GHz bandpowers and resulting $\Lambda$CDM parameter constraints.
There are some differences between the parameter estimation for S13 and for this analysis. First, in this work we assume massive neutrinos with a total mass of 0.06 eV and a Planck-based $\tau$ prior. The work in [[4](#bib.bib4)] points out the importance of these assumptions when comparing parameters estimated from the Planck data with other CMB results.

We handle calibration uncertainty by accounting for it in our model instead of including it in the bandpower covariance, and we use a different calibration prior than used in S13. The method outlined above for handling beam uncertainty differs from S13 in that the beam covariance is now formed in a model-dependent way based on $M\_{\ell}^{i\times j}$,
the cosmology of each MCMC sample. The previous methods for handling calibration and beam uncertainty used in S13 produced biased parameter constraints, lowering $A\_{s}e^{-2\tau}$ and $n\_{s}$ (see the Appendix for further detail).
The new, much tighter calibration prior is based on the in-patch bandpower comparisons in H17.

In S13, aberration effects due to our proper motion with respect to the CMB were not included in parameter estimation. Based on [[9](#bib.bib9)] we include aberration in Eq. 2. Accounting for aberration leads to an approximately 0.3$\sigma$ shift in the S13 $\Theta\_{MC}$ value towards the PlanckFS value.

In Figure [1](#S2.F1 "Figure 1 ‣ II.2. Cosmological Parameter Likelihood ‣ II. Parameter Estimation and Comparison Methodology ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), we show the differences in parameter estimates due to the above changes by comparing the parameters from S13 to parameters estimated from the same bandpowers but with the updated likelihood (S13\*). The decrease in $\theta\_{MC}$ is primarily the result of including aberration effects, $A\_{s}e^{-2\tau}$ is increased by the new calibration prior, and $n\_{s}$ is mostly increased by the new method of handling beam uncertainties. The changes to the likelihood relative to S13 lead to greater consistency between Planck and SPT.

In H17 and this work, we use the $150\times 150$ bandpowers generated from half-power SPT maps, instead of the bandpowers from S13, which were generated from cross-spectra of hundreds of single-observation maps. This choice makes the data easier to simulate, and simplifies the 143 GHz cross spectrum analysis, since that data was created in a similar manner. There was no significant difference found between the $150\times 150$ and S13 bandpowers—for more details see the Appendix of H17. In Figure [1](#S2.F1 "Figure 1 ‣ II.2. Cosmological Parameter Likelihood ‣ II. Parameter Estimation and Comparison Methodology ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), we compare the differences between parameters estimated from S13, S13\* (the S13 bandpowers with the updated likelihood) and $150\times 150$ (H17).

### II.5. Parameter Comparison and Parameter-difference Covariance

To obtain parameter estimates for our in-patch bandpowers we use the Metropolis-Hastings algorithm to produce a chain from which we generate the posterior for $\mathbf{\Theta}$ and then marginalize over the nuisance parameters (foreground and calibration parameters). We generate the chains using the likelihood sampler Cosmoslik [[15](#bib.bib15)].

The primary statistic we use to infer the compatibility between various parameter distributions is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\chi^{2}=\Delta\mathbf{\theta}^{T}\mathbf{C}^{-1}\Delta\mathbf{\theta}$ |  | (8) |

where $\mathbf{C}$ is the parameter difference covariance and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta\mathbf{\theta}=\mathbf{p}\_{1}-\mathbf{p}\_{2}.$ |  | (9) |

The $\mathbf{p}\_{\alpha}$ are either the means of the parameter posteriors or obtained through minimization of the negative log-likelihood. The latter method is used
when simulations are required as minimizing the negative log-likelihood requires significantly less computation time than running an MCMC. The $\mathbf{p}\_{\alpha}$ are composed of the five non-$\tau$ cosmological parameters: $\theta\_{MC}$, $\Omega\_{m}h^{2}$, $\Omega\_{b}h^{2}$, $A\_{s}e^{-2\tau}$, and $n\_{s}$.

When comparing parameters from the in-patch bandpowers to PlanckFS the parameter difference
covariance is approximated as
$\mathbf{C}=\mathbf{C}^{i\times j,\ell\_{\rm{max}}}+\mathbf{C}^{FS}$ with $i\times j\in\{143\times 143,150\times 143,150\times 150\}$ and $2000\leq\ell\_{\rm{max}}\leq 3000$. The small
correlations between the in-patch and full-sky parameter sets are ignored.

The parameter difference covariance for comparisons between the in-patch bandpowers cannot be calculated as simply. The parameters are obtained from bandpowers in the same sky cut, and therefore a large portion of the sample variance is common between all three sets and must be accounted for. It is necessary to estimate the covariance from the fluctuations across a set of simulations.

To calculate the in-patch parameter difference covariance matrices we generate 400 bandpower simulations for each of the in-patch spectra. The creation of the simulations is described in H17. To simulate the calibration uncertainty we multiply each simulation by a random draw from the appropriate calibration prior. The simulated bandpowers are then substituted into Eq. [1](#S2.E1 "In II.2. Cosmological Parameter Likelihood ‣ II. Parameter Estimation and Comparison Methodology ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") and we calculate a set of parameter estimates through minimization of the negative log-likelihood. The minimization is done using the scipy
minimize module with the Nelder-Mead method [[10](#bib.bib10)]. Running the minimizer on the $150\times 150$ bandpowers returns parameter values similar to the results obtained from the MCMC procedure.

With the 400 sets
of parameters for each of the three in-patch bandpowers we obtain the parameter difference covariances
for the three in-patch comparisons. The stability of our
covariances was tested by splitting the simulations into two groups of 200 and recalculating $\chi^{2}$
with each half. We find the results from the two halves to be consistent, and, as we show below, the simulated parameter differences follow a $\chi^{2}$ distribution with five degrees of freedom.
After calculating the $\chi^{2}$ for a set of parameter differences we convert it to a probability to exceed (PTE) which we use to infer compatibility between the sets of parameters.

## III. SPT-SZ and Planck Consistency Tests

In this section,
we use the methodology of Section [II.5](#S2.SS5 "II.5. Parameter Comparison and Parameter-difference Covariance ‣ II. Parameter Estimation and Comparison Methodology ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") to quantify
the significance of differences in parameters estimated from SPT-SZ data and Planck data.
Our primary metric is a $\chi^{2}$ statistic and its associated PTE.
We first compare the parameter constraints from the PlanckFS and SPT $150\times 150$ data sets
and find a relatively low PTE of $3.2\%$. We then perform a series of tests investigating
possible causes for this low PTE.

In Section [III.2](#S3.SS2 "III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), we test the hypothesis of a systematic error in one or both experiments by restricting the Planck and SPT datasets to modes on the sky that are measured well by both experiments. In particular, we restrict the Planck data to the SPT-SZ patch, and only consider multipoles in the range $650\leq\ell\leq 2000$. By doing so we greatly decrease the expected variance in parameter differences under our null hypothesis, primarily because we eliminate nearly all the sample variance contribution.
The volume of parameter space within the 1$\sigma$ uncertainties in parameter differences is reduced by
a factor of over 300 relative to the comparison of the full data sets, greatly increasing sensitivity to systematic errors.

In Section [III.3](#S3.SS3 "III.3. Relaxing Restrictions on Multipole Range ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), we re-introduce sky modes that are only measured well by one of the two experiments, either
by Planck outside the SPT-SZ survey region or by SPT in the multipole range above which
the in-patch Planck data become very noisy.
Specifically, we first explore the consistency of parameters from in-patch bandpowers over several multipole ranges by varying $\ell\_{\rm{max}}$, the maximum multipole included for parameter estimation.
In Section [III.4](#S3.SS4 "III.4. Relaxing Restrictions on Sky Coverage ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), we then compare the various in-patch bandpowers to the PlanckFS dataset, also comparing different $\ell$ ranges. We then discuss specific features of the data and parameter shifts of interest in Sections [III.5](#S3.SS5 "III.5. Bandpower Ratios ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") and [III.6](#S3.SS6 "III.6. Discussion of Shifts in Cosmological Parameters, and the Hubble Constant in Particular ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite").

### III.1. SPT and Planck Parameter Comparison, Full Data Sets

Comparing the parameter differences derived from the SPT $150\times 150$ and PlanckFS data sets, we find

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\rm PTE}=0.032\,(\hbox{PlanckFS vs.~$150\times 150$}).$ |  | (10) |

When considering parameters estimated from the full multipole range for $150\times 150$, the parameters that differ the most (in terms of standard deviations) are $\theta\_{MC}$ and $\Omega\_{m}h^{2}$, and subsequently $H\_{0}$.
As noted in previous publications, the larger value of $H\_{0}$ preferred by SPT is closer to the value reported by [[20](#bib.bib20)].
While a PTE of $0.032$ is plausibly due to a statistical fluctuation, it could
be an indication of potential systematic error or a breakdown of $\Lambda$CDM.

### III.2. Comparison of Planck and SPT in the SPT-SZ survey region

Figure 2.— The parameter estimates for the three sets of in-patch bandpowers for various $\ell\_{\rm{max}}$ values. The estimates are based on the multipole range of $650\leq\ell\leq\ell\_{\rm{max}}$. There is a noticeable trend in the $150\times 150$ density parameters towards better agreement with PlanckFS as $\ell\_{\rm{max}}$ is lowered.

Figure 3.— The fractional difference between the in-patch bandpowers and a PlanckFS best-fit model. The two panels are split at $\ell=1800$ to accommodate the
growth in the $143\times 143$ and $150\times 143$ errorbars beyond this point. The solid curves are the best-fit models of the in-patch bandpowers divided by the best-fit PlanckFS model. Foregrounds have been subtracted. Foreground and beam uncertainty are not included in the error bars.

In this section, we compare parameters derived from modes that are well measured by both Planck and SPT.
We consider data within the SPT-SZ sky region, which covers 2540 deg2, or about 6% of the sky, and within the multipole range $650\leq\ell\leq 2000$.
Specifically, we compare parameters estimated in this multipole range from the in-patch cross-spectrum bandpowers presented in H17.
This comparison provides a sensitive test of unaccounted-for systematic errors in either experiment.

The lower cutoff of $\ell=650$ is set by the SPT analysis in S13, which did not report data at larger angular scales (lower multipoles) due to the increasing noise from the atmosphere on these scales.
The upper cutoff of $\ell=2000$ is set by high-$\ell$ noise in the Planck 143 GHz data resulting from the larger Planck beam (roughly 7 arcmin FWHM, compared to 1 arcmin for SPT 150 GHz) and the
slightly higher noise per pixel in the Planck maps ($\sim$25 $\mu$K-arcmin for Planck 143 GHz
compared to $\sim$18 for SPT).
The variance of the $143\times 143$ bandpowers (the set with the largest noise variance)
is dominated by sample variance to approximately $\ell=1500$; as a result,
the three sets of bandpowers have similar uncertainty in this range.
The $143\times 143$ errorbars begin to grow significantly larger than those for $150\times 150$ around $\ell=1800$, and $150\times 143$ begins to show the same behavior around $\ell=2200$.
We choose $\ell\_{\rm{max}}=2000$ to maximize the signal-to-noise of the comparison between
$150\times 150$ and $150\times 143$.
When restricted to the SPT-SZ sky area and this range of angular scales, both experiments are measuring a very similar set of modes on the sky with similar signal-to-noise per mode.
Given our null hypothesis, the expected covariance of parameter differences for these modes is thus greatly reduced, making it easier for us to see the impact of any systematic errors.

The parameter estimates for the in-patch bandpowers over this multipole range are in Figure [2](#S3.F2 "Figure 2 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), and
Figure [3](#S3.F3 "Figure 3 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") shows the ratio of the in-patch bandpowers and models to the best-fit PlanckFS model.
The in-patch parameters are more similar to each other than to the Planck full-sky values, and the
features apparent by eye in the bandpower and best-fit-model ratios to PlanckFS are similar among
the three in-patch sets. These plots still include sample variance in the in-patch error bars, however,
so it is difficult to assess the statistical consistency of the three data sets.
Figure [4](#S3.F4 "Figure 4 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") shows the distribution of $\chi^{2}$ values for differences in simulation parameters calculated in this comparison (as expected, the histogram closely follows a $\chi^{2}$ distribution for five degrees of freedom).
This statistic accounts for the large decrease in sample variance in the parameter difference covariance
and provides a quantitative assessment of the consistency among the three in-patch parameter sets.
The $\chi^{2}$ values of the data differences are shown by vertical red lines, and none of these
values lie notably outside the main distribution.
The PTEs from this test are included in Table [1](#S3.T1 "Table 1 ‣ III.3. Relaxing Restrictions on Multipole Range ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") and confirm
that all three sets of in-patch bandpowers are consistent with each other in the multipole range
$650\leq\ell\leq 2000.$

There are some parameter differences among the three in-patch sets visible in Figure [2](#S3.F2 "Figure 2 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite").
Between the $143\times 143$ and $150\times 143$ data sets, the largest differences are the
slightly lower preferred values of $\Omega\_{m}h^{2}$ and $n\_{s}$ in $150\times 143$.
This trend continues in $150\times 150$, but as shown in Figure [4](#S3.F4 "Figure 4 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") and Table [1](#S3.T1 "Table 1 ‣ III.3. Relaxing Restrictions on Multipole Range ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"),
these differences are consistent with our null hypothesis.

We pay special attention to the comparison between the parameters derived from $150\times 150$ with $\ell\_{\rm max}=2000$ and those from $150\times 143$ with $\ell\_{\rm max}=2000$, because this comparison provides the most stringent test of our null hypothesis. In Fig. [5](#S3.F5 "Figure 5 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), one can see that the expected covariance of parameter differences, indicated by the contours in the upper triangle, are quite small, comparable to the covariance of parameter uncertainties in the PlanckFS posterior. In this regard, examining these parameter differences provides us with a much more powerful test than the comparison between the PlanckFS parameters and the $150\times 150$ full $\ell$-range parameters.

In addition to the visual impression of this increase in precision of the test given by Fig. [5](#S3.F5 "Figure 5 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), we also provide a quantitative description of the increase in precision.
We do so by simultaneously diagonalizing the covariances for the $150\times 150$ and PlanckFS parameter differences at $\ell\_{\rm{max}}=3000$ and the $150\times 150$ and $150\times 143$ parameter differences at $\ell\_{\rm{max}}=2000$.
We then multiply the square root of the eigenvalue ratios to calculate the reduction in the $1\sigma$ volume for the five-dimensional parameter space.
Comparing the ratio of the volumes, we find a ratio of 0.003, i.e., the volume in the parameter difference space containing 68% of the probability is 300 times smaller for the $\ell\_{\rm max}=2000$ $150\times 150$ vs. $150\times 143$ parameter differences than for the full $\ell$-range $150\times 150$ vs. PlanckFS parameter differences. Despite the precision of this test, we find a perfectly acceptable PTE for this comparison:

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\rm PTE}=0.74\,(\hbox{$150\times 150$ vs.~$150\times 143$}).$ |  | (11) |

In conclusion, when Planck and SPT data are restricted to modes on the sky measured well in both experiments, we find that the best-fit cosmological parameters are fully consistent.
The observed consistency between the two data sets in this stringent test provides strong evidence against instrumental systematics affecting either data set on these angular scales, on this part of the sky.

Figure 4.— The $\chi^{2}$ distributions for the three simulation differences. The vertical purple line marks the $\chi^{2}$ value from the data. The dashed line is a $\chi^{2}$ distribution for five degrees of freedom. The $\chi^{2}$ values are based on the multipole range of $650\leq\ell\leq 2000$.

Figure 5.— This plot shows posterior distributions for parameter differences for several different tests.
In all cases, contours indicate the 68$\%$ and 95$\%$ confidence regions. The dashed lines correspond to $\Delta=0$.
Lower triangle: The posterior distributions for $150\times 150$, $150\times 143$, both with $\ell\_{\rm{max}}=2000$, and PlanckFS. Each distribution has the PlanckFS best-fit values subtracted.
Upper triangle: Contours indicate the posterior distributions from simulations for $150\times 150-150\times 143$ with $\ell\_{\rm{max}}=2000$, and black stars indicate the parameter difference values from the same comparison in the data.
It is visually apparent that this comparison constitutes a much more stringent consistency test than comparing to PlanckFS;
in fact, this comparison reduces the parameter volume by a factor of $300$ (see text for details).
The observed consistency provides strong evidence against a systematic difference in the modes measured in common between the two experiments.

### III.3. Relaxing Restrictions on Multipole Range

Next, we re-introduce smaller angular scales measured within the SPT-SZ survey region.
Given the $\Lambda$CDM model and a spectrum measured in the range $650\leq\ell\leq 2000$, one can predict the spectrum at other angular scales.
Given the consistency found in the previous section, finding significant tension from extending the multipole range could indicate either a systematic affecting SPT data at high $\ell$ or a failure of the $\Lambda$CDM model.
Parameter estimates for the in-patch bandpowers at various values of $\ell\_{\rm{max}}$ are shown in Figure [2](#S3.F2 "Figure 2 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") and PTEs are reported in Table [1](#S3.T1 "Table 1 ‣ III.3. Relaxing Restrictions on Multipole Range ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite").

Table 1PTEs Between Parameters in SPT Sky Patch.

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\ell\_{\rm{max}}$ |  |
|  | $2000$ | $2500$ | $3000$ |
| $150\times 150-150\times 143$ | $0.74$ | $0.66$ | $0.57$ |
| $150\times 150-143\times 143$ | $0.32$ | $0.38$ | $0.20$ |
| $150\times 143-143\times 143$ | $0.62$ | $0.73$ |  |

For $143\times 143$, increasing $\ell\_{\rm{max}}$ from 2000 to 2500 adds little information to the parameter estimates.
This is consistent with Figure [3](#S3.F3 "Figure 3 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), where the errorbars of the $143\times 143$ bandpowers have become significantly larger by $\ell=1800$.
Some parameters in the $150\times 143$ measurement do shift when we expand the $\ell$ range:
$\theta\_{MC}$, $\Omega\_{b}h^{2}$, and $n\_{s}$ shift away from the $143\times 143$ values with increasing $\ell\_{\rm{max}}$.
Nevertheless, at $\ell\_{\rm{max}}$ = 2500 we still find that the $150\times 143$ and $143\times 143$ measurements are consistent with a PTE of $0.62$.22
2
Note that for the bottom two rows of Table 1 the PTE increases as $\ell\_{\rm{max}}$ is increased from 2000 to 2500. This increase is driven by the increase in the parameter difference covariances as sources of fluctuation are added that are not common to the two datasets in question—most predominantly from noise in the 143 GHz map.

For $150\times 150$, when $\ell\_{\rm{max}}$ is increased from 2000 to 2500, $\theta\_{MC}$ increases in a manner similar to what we saw with $150\times 143$, the baryon density increases, and the matter density decreases.
These shifts correspond to an increase in $H\_{0}$.
At $\ell\_{\rm{max}}=2500$, the $150\times 150$ measurement remains consistent with $150\times 143$ and $143\times 143$, with PTEs of $0.66$ and $0.38$ respectively.
The trend in parameter shifts continues when we increase $\ell\_{\rm{max}}$ to 3000 to include the full range of the $150\times 150$ data, yet the PTEs remain moderate. We also plot in Fig. [2](#S3.F2 "Figure 2 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") parameter results for $\ell\_{\rm max}=1800$, and we see the trend toward the PlanckFS values continues. Uncertainties rapidly grow for $\ell\_{\rm max}<1800$. Finally, we calculate the $\chi^{2}$ and PTEs for the comparison of parameters from $150\times 150$ data at $\ell\_{\rm max}=2000$ to parameters from $150\times 150$ data with $\ell\_{\rm max}=2500$ and 3000. These PTEs are 0.88 and 0.75 respectively. Thus, while the parameter shifts with increasing $\ell\_{\rm max}$ are suggestive of a potentially interesting trend, they are consistent with our expectations under the null hypothesis.

### III.4. Relaxing Restrictions on Sky Coverage

In the previous sections, we have found that the $\Lambda$CDM parameters estimated from the Planck and SPT in-patch bandpowers are consistent for all $\ell$ ranges considered.
In this section, we relax the restrictions on sky coverage and compare the in-patch parameters to the PlanckFS parameters in different fixed $\ell$ ranges.
This effectively tests $\Lambda$CDM and the assumptions of statistical isotropy in the CMB.
The PTEs between the in-patch parameters and PlanckFS parameters in all $\ell$ ranges tested are listed in Table [2](#S3.T2 "Table 2 ‣ III.4. Relaxing Restrictions on Sky Coverage ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite")
and the parameter constraints are shown in Figure [2](#S3.F2 "Figure 2 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite").

We first compare PlanckFS to $143\times 143$ at $\ell\_{\rm{max}}$ = 2000 and 2500.
Because of the rapidly increasing noise at high $\ell$ in the $143\times 143$ bandpowers,
we do not consider $\ell\_{\rm{max}}$ = 3000 for this comparison, and we see very little difference in the parameters
and comparison PTEs for $\ell\_{\rm{max}}$ = 2000 and 2500.
Those PTEs are $0.29$ and $0.31$, respectively.
Although the PTE values indicate no tension between the data sets,
we do see small differences in $\theta\_{MC}$, $A\_{s}e^{-2\tau}$, and $n\_{s}$ between PlanckFS and $143\times 143$ at $\ell\_{\rm{max}}$ = 2000 and 2500.
The two main differences between the sets of bandpowers that could drive parameter differences are the Planck low $\ell$ data (which are not included in the in-patch bandpowers) and the sky outside of the patch.
However, we can rule out the low-$\ell$ data as an explanation based on the results of [Planck Collaboration et al. [18]](#bib.bib18), who found only marginal parameter shifts when cutting the low-$\ell$ ($\ell\leq 650$) data.
Therefore, the majority of the parameter differences between PlanckFS and $143\times 143$ can be attributed to differences in the Planck data from the SPT-SZ patch and the Planck data from the rest of the sky.

As noted in H17, all three sets of in-patch bandpowers
have more power than the PlanckFS model at moderate $\ell$ and less power at high $\ell$, creating a tilt.
In Figure [3](#S3.F3 "Figure 3 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), we show the ratios of the in-patch bandpowers
to the PlanckFS best-fit model.
We also show the ratios of best-fit in-patch models to the PlanckFS best-fit model.
The tilt is clearly visible by eye in all bandpowers and best-fit models,
and it is this tilt that drives the differences in $A\_{s}e^{-2\tau}$ and $n\_{s}$.
We discuss this tilt further in Section [III.5](#S3.SS5 "III.5. Bandpower Ratios ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite").
There is also an oscillatory
pattern in the best-fit model ratios, consistent with the difference in best-fit $\theta\_{MC}$, though this
feature is not as obviously discernible directly in the bandpower ratios as is the tilt.

Next we compare PlanckFS to $150\times 143$ at $\ell\_{\rm{max}}$ = 2000 and 2500 (and again refer the reader to Figure [2](#S3.F2 "Figure 2 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite")).
Compared to $143\times 143$,
all parameters except $A\_{s}e^{-2\tau}$ shift away from PlanckFS values when SPT data are included
and as $\ell\_{\rm{max}}$ is increased.
Nevertheless, the comparison to PlanckFS still gives PTEs of $0.19$ at $\ell\_{\rm{max}}$ = 2000 and $0.18$ at $\ell\_{\rm{max}}$ = 2500.

Finally, we compare PlanckFS to $150\times 150$ with varying $\ell\_{\rm{max}}$.
In Fig. [2](#S3.F2 "Figure 2 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") we see a trend toward the PlanckFS values as $\ell\_{\rm max}$ is lowered, with near-convergence of $\Omega\_{\rm b}h^{2},\Omega\_{\rm m}h^{2}$, and $H\_{0}$ by $\ell\_{\rm{max}}=1800$. For $\ell\_{\rm{max}}$ = 1800, 2000, and 2500, we find $150\times 150$ and PlanckFS to be at least marginally consistent (minimum PTE of $0.094$).
The tension between the data sets only approaches the 2$\sigma$ level when we extend the parameter estimation to the full $150\times 150$ multipole range, where we find the PTE of $0.032$ with which we began this investigation.
As noted in the previous section, the only notable difference between the $150\times 143$ and $150\times 150$ data at $\ell\_{\rm{max}}$ = 2500 is the marginally lower matter density (and hence higher Hubble constant)
that $150\times 150$ prefers;
these parameters are pushed even farther in this direction when $\ell\_{\rm{max}}$ is increased to 3000.
From this comparison, we see that the $150\times 150$ bandpowers above $\ell>1800$ drive some of the tension with PlanckFS.

Table 2PTEs Between PlanckFS and In-patch Parameters.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\ell\_{\rm{max}}$ |  |  |
|  | 1800 | $2000$ | $2500$ | $3000$ |
| $150\times 150$ | 0.21 | $0.24$ | $0.094$ | $0.032$ |
| $150\times 143$ |  | $0.19$ | $0.18$ |  |
| $143\times 143$ |  | $0.29$ | $0.31$ |  |

* •

  The entries for $150\times 143$ and $143\times 143$ at $\ell\_{\rm{max}}=3000$ are blank since these spectra have negligible signal-to-noise above $\ell=2500$.

### III.5. Bandpower Ratios

Figure 6.— Upper panel: Residuals between the in-patch bandpowers and PlanckFS best-fit model. Lower panel: Ratios of the in-patch bandpowers and the PlanckFS best-fit model. The colored dashed lines are the best-fit power law for each ratio. The uncertainty for the best-fit power-law parameters is smallest for $143\times 143$ because of the small beam and calibration uncertainty for these bandpowers.

In H17, it was shown that the bandpowers from the SPT-SZ patch (from both SPT and Planck data) have a tilt relative to the PlanckFS bandpowers.
We also see this feature prominently in the ratios of in-patch bandpowers to the PlanckFS best-fit model,
as plotted in Figure [3](#S3.F3 "Figure 3 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite").
In this section, we investigate the impact of this tilt on cosmological parameters.
To do so we fit a power law to the ratio of the in-patch bandpowers to the PlanckFS best-fit model and multiply this power law into the theory spectrum in Eq.2 when estimating new parameters.

The power law takes the form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{D^{th,i\times j}\_{\ell}}{D^{\rm{PlanckFS}}\_{\ell}}=A\left(\frac{\ell}{1000}\right)^{n}.$ |  | (12) |

Using the PlanckFS model instead of the PlanckFS bandpowers allows us to better assess how this tilt drives the best-fit parameters away from the PlanckFS values.
We assume Gaussianity and use the following likelihood,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $-2\ln\mathcal{L}(\mathrm{A,n}|D^{i\times j})=\Delta\_{b}\Sigma\_{bb^{\prime}}^{-1}\Delta\_{b}^{\prime}$ |  | (13) |

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}\Delta\_{b}=D^{i\times j}\_{b}-Y^{i}Y^{j}W^{i\times j}\_{b\ell}a\_{\ell}\bigg(D^{\mathrm{PlanckFS}}\_{\ell}\mathrm{A}\bigg(\frac{\ell}{1000}\bigg)^{\mathrm{n}}\\ +F^{i\times j}\_{\ell}\bigg)\end{split}$ |  | (14) |

where $D^{\mathrm{PlanckFS}}\_{\ell}$ is the PlanckFS best-fit model. In Figure [6](#S3.F6 "Figure 6 ‣ III.5. Bandpower Ratios ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), we present the best-fit power laws for each spectrum with $\ell\_{\rm{max}}=2500$. As the amount of SPT data included is increased (i.e., as we go from $143\times 143$ to $150\times 143$ to $150\times 150$), we see an increase in the tilt, with $150\times 150$ having a best-fit value of $n$ that is discrepant with 0 by $2.2\sigma$. We note, however, that the best-fit tilt values from the three bandpower sets are consistent within 1$\sigma$.

To connect this feature with parameters, we remove this tilt from the $150\times 150$ bandpowers by multiplying the theory spectrum in Eq. [2](#S2.E2 "In II.2. Cosmological Parameter Likelihood ‣ II. Parameter Estimation and Comparison Methodology ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") by the best-fit power law for $150\times 150$ and run a new chain.
As shown in Figure [7](#S4.F7 "Figure 7 ‣ IV. Additional Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), removing this tilt from the full range of the $150\times 150$ bandpowers results in a decrease in $A\_{s}e^{-2\tau}$ and an increase in $n\_{s}$ to significantly better agreement with PlanckFS.
By contrast, we note that removing the tilt hardly affects the two density parameters (and $H\_{0}$);
therefore, the preference for higher $H\_{0}$ by $150\times 150$ is due to high-$\ell$ information unrelated to the tilt.

### III.6. Discussion of Shifts in Cosmological Parameters, and the Hubble Constant in Particular

The picture that emerges from the previous sections is the following: When SPT and Planck data
are restricted to modes on the sky measured well in both experiments—i.e., to modes in the SPT-SZ survey
region in the multipole range $650\leq\ell\leq 2000$—the best-fit parameters from the
two data sets are fully consistent.
When the comparison is relaxed to either just the same sky or just the same multipole range, parameter constraints from the two experiments are still marginally consistent, though parameter differences begin to emerge.
It is only when we relax all restrictions on sky coverage and multipole range that we find upwards of
2$\sigma$ tension between Planck and SPT.
This tension arises in roughly equal part from the SPT data at high $\ell$ and from differences in the SPT-SZ patch relative to the whole sky at moderate $\ell$.
The latter fluctuation accounts for nearly all of the difference in $A\_{s}e^{-2\tau}$, and a sizeable fraction of the differences in $\theta\_{MC}$ and $n\_{s}$, but almost none of the differences in the other parameters. The remainder of the parameter differences arise from the high-$\ell$ fluctuation.

Of the parameter differences driven by high-$\ell$ SPT data,
the Hubble constant is of particular interest given the discrepancy between the value derived from Planck CMB power spectrum data assuming $\Lambda$CDM and the traditional distance ladder measurement of [Riess et al. [20]](#bib.bib20).
As can be seen in Figure [2](#S3.F2 "Figure 2 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), half of the Hubble constant difference between SPT and Planck arises from the SPT data at $\ell>2000$.

In our parameterization, the Hubble constant is a derived parameter that can be calculated from $\Omega\_{b}h^{2}$, $\Omega\_{m}h^{2}$, and $\theta\_{\rm MC}$.
From the perspective of the Hubble constant, the angle $\theta\_{\rm MC}$ is essentially fixed—the uncertainties and shifts between data sets are so small that the impact on $H\_{0}$ is negligible.
Thus the observed variation in $H\_{0}$ between datasets is due to changes in the two density parameters.
Changing either the baryon density or the matter density (and enforcing a flat universe) would result in a
change in the angular size of the sound horizon at recombination and, hence, a different observed value
of $\theta\_{\rm MC}$. The only parameter available to preserve the observed $\theta\_{\rm MC}$ is $H\_{0}$.

Specifically, the baryon density affects the sound speed in the early universe. Increasing the baryon
density decreases the sound speed and thus the physical size of the sound horizon at recombination.
To preserve the angular size, the angular diameter distance to recombination

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle d\_{A}(z\_{\*})$ | $\displaystyle\propto$ | $\displaystyle\int\_{0}^{z\_{\*}}dz/H(z)$ |  | (15) |
|  |  | $\displaystyle\propto$ | $\displaystyle\frac{1}{H\_{0}}\int\_{0}^{z\_{\*}}\frac{dz}{\sqrt{\Omega\_{m,0}(1+z)^{3}+\Omega\_{\Lambda}}},$ |  |

where $z\_{\*}$ is the redshift of recombination, must be made smaller. At
fixed matter density and with flatness enforced, this can only be achieved by increasing $H\_{0}$.

Changing the matter density, meanwhile, affects the expansion rate, both in the early universe
and from recombination to today (as can be seen from Eq. [15](#S3.Ex1 "In III.6. Discussion of Shifts in Cosmological Parameters, and the Hubble Constant in Particular ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite")).
In the early universe, this change would affect the physical size of the sound horizon,
though its impact is softened by the contribution of radiation density to the expansion rate.
Decreasing the matter density at late times would increase the
angular diameter distance to recombination, which, at fixed baryon density, would make the
angular size of the sound horizon too small. To preserve the measured angular size, $H\_{0}$
must increase.
Thus both the increase in $\Omega\_{b}h^{2}$ and the decrease in $\Omega\_{m}h^{2}$ driven by the high-$\ell$ SPT data lead to an increase in the inferred value of $H\_{0}$.

## IV. Additional Tests

In the previous section, we found no evidence the parameter differences between SPT and PlanckFS at $650\leq\ell\leq 2000$ are driven by instrumental systematics.
In this section, we investigate potential systematic contributions to the parameter differences
driven by SPT data at $\ell>2000$
by examining the SPT foreground model and the SPT calculation of beam uncertainty.
We also investigate other known sources of potential systematic uncertainty (not specific
to high-$\ell$ data), including the SPT $\tau$ prior and the effects of lensing.
These tests differ from those in the previous section in that they are more specific probes for systematic errors that do not aim to reduce the comparison to parameters estimated from the same modes. Instead, they focus on places where systematics may have entered into the parameter estimation, either through instrumental effects or faulty modeling assumptions.

Figure 7.— Parameter estimates for $150\times 150$ bandpowers in the fiducial case and as a result of two tests for systematics discussed in Section [IV](#S4 "IV. Additional Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite").
“Lensing Fixed”: The parameter estimates from the chain with lensing fixed to the $150\times 150$ best-fit. Lensing information is important for constraining the matter density. “Tilt Removed”: The parameter estimates after removing the best-fit power law from Section 4.3 from the $150\times 150$ bandpowers. The tilt in the ratio of the $150\times 150$ bandpowers to the PlanckFS best-fit model connects mostly with $A\_{s}e^{-2\tau}$ and $n\_{s}$.
The estimates are based on the multipole range $650\leq\ell\leq 3000$.

### IV.1. Parameter Dependence on Beams and Foregrounds

In this section, we investigate the possible impact of foreground and beam mis-estimation on parameter
differences, particularly at high $\ell$.
To test for beam systematics, we include the amplitudes of the fractional beam uncertainty as parameters in the MCMC, rather than analytically marginalizing over the beam uncertainty.
What this means in practice is we modify Eq. [5](#S2.E5 "In II.3. The Covariance for the In-patch Bandpowers ‣ II. Parameter Estimation and Comparison Methodology ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") to include parametrized amplitudes of the SPT beam error templates for each source of beam uncertainty and multiply this into Eq. [2](#S2.E2 "In II.2. Cosmological Parameter Likelihood ‣ II. Parameter Estimation and Comparison Methodology ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"). The covariance in Eq. [1](#S2.E1 "In II.2. Cosmological Parameter Likelihood ‣ II. Parameter Estimation and Comparison Methodology ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") no longer has Eq. [7](#S2.E7 "In II.3. The Covariance for the In-patch Bandpowers ‣ II. Parameter Estimation and Comparison Methodology ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") included in it. Our model bandpowers now take the form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $M^{i\times j}\_{b}=W\_{b\ell}^{i\times j}M^{i\times j}\_{\ell}\bigg(1+\frac{\delta D\_{\ell}}{D\_{\ell}}^{B,i\times j}\bigg).$ |  | (16) |

At each step of the new $150\times 150$ chain we calculate the five-parameter $\chi^{2}$ from Eq. 8 using the difference between the cosmological parameters of the current step and the PlanckFS means. If a beam or foreground parameter were connected to the low PTE found in Section [III](#S3 "III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), we would expect to find the $\chi^{2}$ posterior to be correlated with said parameter. In other words, we treat the five-parameter $\chi^{2}$ as a derived parameter and
look for correlations or degeneracies between this derived parameter and the beam or foreground parameters.
We do not find any significant correlation;
the largest correlation found between any foreground or beam parameter and the five-parameter $\chi^{2}$ was 0.12, indicating a very weak linear response and no clear direction in the foreground and beam parameter space in which the parameter comparison $\chi^{2}$ can be lowered.

We find furthermore that the foreground and beam
posteriors are not driven significantly from their priors in any chain, as one would expect if any of
these components were a poor description. The largest deviation of a parameter’s posterior mean from the prior mean was $0.13\sigma$, and most parameters showed shifts of less than $0.1\sigma$.
These tests provide more support for our hypothesis that the somewhat low PTE between $150\times 150$ and PlanckFS is not due to a systematic errors in the beam or foreground treatment.

We expand on the foreground tests by adding free parameters for the kinematic Sunyaev-Zel’dovich (kSZ) effect—the S13 foreground model has a single parameter for the sum of kSZ and tSZ—and a cross-correlation between the tSZ and the cosmic infrared background (CIB) based on [[6](#bib.bib6)], since these components were also included in the determination of the PlanckFS parameters.
This change has a negligible impact on the parameter posteriors for $150\times 150$.
This result is expected: the motivation for the simplified foreground parameterization in S13 was
that these extra foreground components are expected to have a similar power-spectrum shape to tSZ
in the multipole range examined in S13 and here
and are thus only distinguishable via their frequency dependence.
Thus, the differences between Planck and SPT do not appear to be related to
foreground components included in the Planck analysis but not in S13.

### IV.2. $\tau$ Prior

Potential systematic errors may also creep in through the optical depth measurement, given the proven challenges in recovering the reionization peak from the midst of the Galactic foregrounds.
We test whether the $\tau$ prior is contributing to the low PTE by running $150\times 150$ chains with a low optical depth, $\tau=0.05\pm 0.02$, and a high optical depth, $\tau=0.10\pm 0.02$.
For the $\tau$ = 0.05 prior there are small shifts in both density parameters towards PlanckFS values but the shifts only change the PTE from $0.032$ to 0.058. For the $\tau$ = 0.1 prior we see the opposite effect and calculate a PTE of 0.015.
The small improvement in the PTE as $\tau$ is lowered argues against the idea that the parameter differences between PlanckFS and $150\times 150$ are significantly connected to the $\tau$ prior.

### IV.3. Gravitational Lensing

Two of the most discrepant parameters between $150\times 150$ and PlanckFS are $\Omega\_{m}h^{2}$ and $A\_{s}e^{-2\tau}$. Since these parameters both impact the lensing amplitude we test the hypothesis that the parameter differences are lensing-related. The impact of lensing on parameter estimates is often studied by marginalizing over an artifical lensing-power scaling parameter, $A\_{\rm L}$. Here we follow [Planck Collaboration et al. [18]](#bib.bib18) and instead fix the amount of lensing power. With this choice we avoid some difficulties of interpreting parameter constraints after marginalization over $A\_{L}$. With marginalization over $A\_{L}$, one projects out lensing information. That is useful, but interpretation is complicated by the fact that one also removes any sensitivity to parameter variations that produce effects that can be mimicked by lensing. In contrast, by fixing the lensing potential we can remove the contribution of lensing variation to our parameter constraints, while keeping the contribution of any non-lensing responses of the power spectrum to parameter variations.

Specifically, we fix the $150\times 150$ lensing potential to its best-fit $\Lambda$CDM value. In practice we modify our model of the bandpowers (Eq. [2](#S2.E2 "In II.2. Cosmological Parameter Likelihood ‣ II. Parameter Estimation and Comparison Methodology ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite")) so that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}M^{i\times j}\_{b}=Y^{i}Y^{j}W\_{b\ell}^{i\times j}a\_{\ell}\big(D^{th,UL}\_{\ell}(\theta)+D^{Lens}\_{\ell}(\theta\_{\*})\\ +F\_{\ell}^{i\times j}\big)\end{split}$ |  | (17) |

with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D^{Lens}\_{\ell}(\theta\_{\*})=D^{th}\_{\ell}(\theta\_{\*})-D^{th,UL}\_{\ell}(\theta\_{\*})$ |  | (18) |

where UL signifies an unlensed spectrum and $\theta\_{\*}$ represents cosmological parameters fixed to the $150\times 150$ $\Lambda$CDM best-fit values.

The first thing we note from the results of this test, shown in Figure [7](#S4.F7 "Figure 7 ‣ IV. Additional Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), is that there is still some preference in the SPT data for lower matter density even with the lensing information removed, albeit a weaker preference. The increase in the size of the error bar, in the case of the fixed lensing potential, indicates that the lensing variations induced by matter density variation are important for constraints on the matter density. Adding in the lensing information strengthens the preference for low matter density.

The second thing we note is that the PTE for comparison with PlanckFS
only improves to 0.045 with lensing fixed. We attribute this to the small shift in $A\_{s}e^{-2\tau}$ that also occurs when we fix the lensing potential. Thus, although lensing has an impact, removing the impact of lensing on the SPT parameter estimates does not significantly improve agreement with the PlanckFS parameter estimates.

Finally, we note that in [Planck Collaboration et al. [18]](#bib.bib18) the Planck collaboration performed a similar test with the Planck data. Fixing the lensing potential lowers the matter density for Planck and increases it for SPT, bringing the preferred matter density values for these two datasets closer together. However, the shifts
are relatively small when compared to the full SPT and Planck parameter differences.

## V. Conclusions

The Planck CMB temperature data at moderate angular scales ($650\leq\ell\leq 2000$) prefer a $\Lambda$CDM model that is in mild tension with some other cosmological probes.
In this paper, we have used measurements from the SPT as an independent check of the Planck data at these angular scales.
This check was performed by comparing $\Lambda$CDM parameter estimates using observations of the CMB temperature anisotropies from the Planck satellite and SPT.
When comparing parameter constraints from the full multipole range of SPT data to parameter constraints
from Planck full-sky data, we found mild tension between the two, with a PTE of $0.032$.
We have attempted to distinguish between three possibilities for the observed parameter differences:
slightly unusual statistical fluctuations, unaccounted-for systematic error, or a breakdown of $\Lambda$CDM.
To this end, we compared parameter estimates restricted to measurements of the same modes on the sky then relaxed the range of angular scales and sky coverage.

We have arrived at three primary conclusions:

1. 1.

   When Planck and SPT are restricted to measure the same modes on the sky (specifically, the SPT-SZ patch between $650\leq\ell\leq 2000$), the resulting cosmological parameters are fully consistent. This stringent test provides strong evidence against systematic contamination in either experiment at these angular scales and on this patch of sky.
2. 2.

   The observed tension between Planck on the full sky (PlanckFS) and SPT arise from both sky area (that is, the SPT-SZ patch vs. the full sky at $650\leq\ell\leq 2000$) and from data above $\ell>2000$ measured by SPT; however, both of these differences must be included for the difference between Planck and SPT parameter estimates to approach the 2$\sigma$ level.
3. 3.

   The high-$\ell$ SPT data (between $2000\leq\ell\leq 3000$) drive shifts away from PlanckFS in the two density parameters $\Omega\_{m}h^{2}$ and $\Omega\_{b}h^{2}$—and therefore in $H\_{0}$. While these shifts are intriguing in the context of broader discussions of the value of $H\_{0}$, when considered alone they are nevertheless consistent with expectations given the null hypothesis that the $\Lambda$CDM model is correct and the statistical models of both data sets are accurate.

We arrived at these conclusions from the following set of tests and calculations.
We first quantified the tension between the best-fit $\Lambda$CDM models for Planck and SPT and found a PTE of $3.2\%$.
We tested for systematic errors in one or both experiments by restricting Planck and SPT data to nearly the exact same modes on the sky. To this end, we restricted the Planck data to the SPT-SZ sky patch and limited each data set to the multipole range of $650\leq\ell\leq 2000$.
Using the measured bandpowers and simulations described in H17 to create parameter difference covariances, we calculated $\chi^{2}$ values and PTEs for parameter differences between different spectra.
We found PTEs of $0.74$ and $0.32$ for $150\times 143$ and $143\times 143$ respectively, when compared with $150\times 150$ at $\ell\_{\rm max}=2000$.
This is an extremely precise test of the consistency between the two measurements, as nearly all sample variance is eliminated from the comparison.
We quantified the increased precision of this test by calculating the reduction in the volume of the 68% confidence region for the expected distribution of parameter differences between different data comparisons;
using this metric, the $150\times 143$ vs. $150\times 150$ comparison is over 300 times more stringent than for the $150\times 150$ vs. PlanckFS comparison.
These powerful tests would have magnified any evidence for systematic errors in either experiment;
instead, their results strongly disfavor the presence of significant systematic errors in either the SPT or Planck data sets in the modes measured well by both experiments.

Next, we found that the tension between PlanckFS and SPT comes from two parts of the data.
The first is differences between the SPT-SZ patch at intermediate scales ($650\leq\ell\leq 2000$) and the whole sky over the full range of angular scales measured by Planck ($\ell\leq 2000$);
this can be seen from Table [2](#S3.T2 "Table 2 ‣ III.4. Relaxing Restrictions on Sky Coverage ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), Figures [4](#S3.F4 "Figure 4 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") and [5](#S3.F5 "Figure 5 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), and the text of Section [III.4](#S3.SS4 "III.4. Relaxing Restrictions on Sky Coverage ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite").
The second is the inclusion of high-$\ell$ data in the SPT-SZ patch ($2000\leq\ell\leq 3000$);
this can be seen from Table [1](#S3.T1 "Table 1 ‣ III.3. Relaxing Restrictions on Multipole Range ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), where the PTE between PlanckFS and $150\times 150$ drops below 5% only with the inclusion of data up to $\ell\_{\rm{max}}=3000$.
The tension between PlanckFS and SPT can be alleviated by removing either of these parts of the data.
By restricting Planck to the SPT-SZ patch, all comparisons are consistent (Table [2](#S3.T2 "Table 2 ‣ III.4. Relaxing Restrictions on Sky Coverage ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"));
alternately, removing the high-$\ell$ SPT data increases the PTE to $0.24$ (Table [1](#S3.T1 "Table 1 ‣ III.3. Relaxing Restrictions on Multipole Range ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), case PlanckFS vs. $150\times 150$ with $\ell\_{\rm{max}}=2000$).
Another way to say this is starting from the consistent in-patch comparison (SPT compared to Planck in-patch with $\ell\_{\rm{max}}=2000$), if we relax either the sky coverage (PlanckFS vs. $150\times 150$ with $\ell\_{\rm{max}}=2000$ $\rightarrow$ $\rm{PTE}=0.24$ ) or we relax the $\ell\_{\rm{max}}$ range ($150\times 150$ vs. $150\times 143$ $\ell\_{\rm{max}}=3000$ and $150\times 150$ vs. $143\times 143$ with $\ell\_{\rm{max}}=3000$ $\rightarrow$ PTE = $0.57$, $0.20$ respectively), the datasets remain consistent; it is only when we relax both the sky coverage and the $\ell$ range that the PTE drops below 0.05.

Third, we related certain of the parameter differences noted above to specific features in the bandpowers.
The in-patch data bandpowers have a tilt relative to PlanckFS; this can be seen from H17 and Figures [3](#S3.F3 "Figure 3 ‣ III.2. Comparison of Planck and SPT in the SPT-SZ survey region ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") and [6](#S3.F6 "Figure 6 ‣ III.5. Bandpower Ratios ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite").
This tilt is seen by both Planck and SPT data, and is thus unlikely to arise from systematics in this range of angular scales in either experiment.
We find that this tilt couples to the $\Lambda$CDM parameters $A\_{s}e^{-2\tau}$, and $n\_{s}$ (see Section [III.5](#S3.SS5 "III.5. Bandpower Ratios ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") and Figure [7](#S4.F7 "Figure 7 ‣ IV. Additional Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite")).
The tilt does not couple to the density parameters and $H\_{0}$;
this is confirmed by the fact that when the tilt is artifically removed, $H\_{0}$ remains high relative to PlanckFS (see Section [III.5](#S3.SS5 "III.5. Bandpower Ratios ‣ III. SPT-SZ and Planck Consistency Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite") and Figure [7](#S4.F7 "Figure 7 ‣ IV. Additional Tests ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite")).

Finally, we performed an additional set of tests designed to investigate whether specific potential sources
of systematic error could be responsible for any of the measured parameter differences. We investigated
the effects of the SPT instrument beam, the treatment of foregrounds in SPT data, and influence of
assumptions about the optical depth to reionization and the amplitude of gravitational lensing in the
analysis. We found no evidence of any coupling of these effects to the measured parameter differences.

We conclude that, at most, our tests reveal weak evidence for a breakdown of $\Lambda$CDM or systematic errors influencing either the Planck data outside the SPT-SZ survey area or the SPT data at $\ell>2000$.
Instead, the tension between SPT and Planck  under $\Lambda$CDM can plausibly be explained by two
individually insignificant statistical fluctuations—one between the SPT-SZ survey area and the full sky, the other in the high $\ell$ data better constrained by SPT.

Whether this explanation is correct will ultimately be determined most directly by additional observations of the CMB temperature anisotropies at $\ell>2000$, both within and beyond the SPT-SZ patch.
Additionally, measurements of the $EE$ and $TE$ CMB polarization power spectra—from, e.g., Advanced ACTPol [[7](#bib.bib7)], SPT-3G [[3](#bib.bib3)], and CMB-S4 [[1](#bib.bib1)]—will provide yet more stringent tests of our standard cosmological model.

The South Pole Telescope is supported by the National Science Foundation through grant PLR-1248097. Partial support is also provided by the NSF Physics
Frontier Center grant PHY-1125897 to the Kavli Institute of Cosmological Physics at the University of Chicago, the Kavli Foundation and the Gordon and
Betty Moore Foundation grant GBMF 947. B. Benson was supported by the Fermi Research Alliance, LLC under Contract No. DE-AC02-07CH11359 with the U.S. Department of Energy, Office of Science, Office of High Energy Physics. C. Reichardt acknowledges support from an Australian Research Council Future Fellowship (FT150100074). The McGill group acknowledges funding from the National Sciences and Engineering Research Council of Canada, Canada Research Chairs program, and the Canadian Institute for Advanced Research.
Work at Argonne National Laboratory was supported under U.S. Department of Energy contract DE-AC02-06CH11357. This work used resources made available on the Jupiter cluster, a joint data-intensive computing project between the High Energy Physics Division and the Computing, Environment, and Life Sciences (CELS) Directorate at Argonne National Laboratory.
We thank G. Addison for pointing out the importance of the aberration correction.

## Appendix A On the Calculation of Calibration and Beam Uncertainty

In this appendix, we discuss why we use a different method for handling beam and calibration uncertainty than what was done in S13. We discovered that the method used in S13 leads to a bias lowering the estimates for $A\_{s}e^{-2\tau}$ and $n\_{s}$. We explain why the method used in S13 leads to a bias and present an unbiased procedure to include beam and calibration uncertainty in the likelihood.

In S13, the calibration and beam uncertainty of the bandpowers was added into the full covariance ($\mathbf{\Sigma}$) in a data ($\mathbf{D}$) dependent way as

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Sigma\_{bb^{\prime}}$ | $\displaystyle=\Sigma\_{bb^{\prime}}^{S}+\Sigma\_{bb^{\prime}}^{N}+D\_{b}D\_{b^{\prime}}W\_{b\ell}W\_{b^{\prime}\ell^{\prime}}\rho^{B}\_{\ell\ell^{\prime}}+D\_{b}D\_{b^{\prime}}\sigma\_{Y}^{2}$ |  | (A1) |

where S, and N signify the sample and noise covariances, $W\_{b\ell}$ are the window functions, the beam correlation term, $\rho^{B}\_{\ell\ell^{\prime}}$, is formed in a manner similar to Eq. [4](#S2.E4 "In II.3. The Covariance for the In-patch Bandpowers ‣ II. Parameter Estimation and Comparison Methodology ‣ A Comparison of Cosmological Parameters Determined from CMB Temperature Power Spectra from the South Pole Telescope and the Planck Satellite"), and $\sigma\_{Y}$ is the calibration uncertainty.

Using the data in the calculation of the covariance instead of a fiducial model introduces a bias in the likelihood. Elements of $\mathbf{D}$ with smaller values will have less beam and calibration uncertainty than larger elements of $\mathbf{D}$. When fitting a model to $\mathbf{D}$, the preference will be to fit the smaller valued elements of $\mathbf{D}$ better than larger elements. The calibration uncertainty bias has a greater effect at low-$\ell$ and the beam uncertainty bias has a greater effect at high-$\ell$, explaining the connection to the parameters $A\_{s}e^{-2\tau}$ and $n\_{s}$. If the beam and calibration uncertainty are added into the covariance in a model-dependent way, the errorbars on all elements of $\mathbf{D}$ are adjusted with the model.
The resulting fits are unbiased, since a model that favors fitting the smallest elements of $\mathbf{D}$ produces smaller errorbars for all elements of $\mathbf{D}$ and gives a worse overall fit.

This bias can best be understood in the context of a simple example. Since the bias works in the same manner for both beam and calibration uncertainty, we focus on just the latter. We assume a set of data ($\mathbf{d}$) from a Gaussian distribution with covariance $\mathbf{C}$. Our model will take the form $Y\mathbf{m}(\theta)$, where we explicitly include the calibration $Y$, and $\mathbf{m}(\theta)$ depends on the remaining parameters in our model ($\theta$).

With a Gaussian prior on $Y$ of $N(1,\sigma\_{Y})$, the probability for the model parameters, $\theta$ and $Y$ given $\mathbf{d}$, can be written as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle P(\theta,Y|\mathbf{d})=\frac{P(\mathbf{d}|\theta,Y)P(Y)}{P(\mathbf{d})}\propto e^{-\frac{1}{2}(\mathbf{d}-Y\mathbf{m})^{\dagger}\mathbf{C}^{-1}(\mathbf{d}-Y\mathbf{m})}e^{-\frac{(Y-1)^{2}}{2\sigma\_{Y}^{2}}}.$ |  | (A2) |

If we analytically marginalize over $Y$ we get

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle P(\theta|\mathbf{d})=\int\_{-\infty}^{\infty}dYP(\theta,Y|\mathbf{d})\propto\int\_{-\infty}^{\infty}dYe^{-\frac{1}{2}(\mathbf{d}-Y\mathbf{m})^{\dagger}\mathbf{C}^{-1}(\mathbf{d}-Y\mathbf{m})}e^{-\frac{(Y-1)^{2}}{2\sigma\_{Y}^{2}}}$ |  | (A3) |

After integrating over $Y$ and working through some algebra, we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle P(\theta|\mathbf{d})\propto exp\Bigg(-\frac{1}{2}\Bigg[\mathbf{d}^{\dagger}\mathbf{C}^{-1}\mathbf{d}+\frac{1}{\sigma\_{Y}^{2}}-\frac{\Big(\mathbf{m}^{\dagger}\mathbf{C}^{-1}\mathbf{d}+\frac{1}{\sigma\_{Y}^{2}}\Big)^{2}}{\mathbf{m}^{\dagger}\mathbf{C}^{-1}\mathbf{m}+\frac{1}{\sigma\_{Y}^{2}}}\Bigg]\Bigg)$ |  | (A4) |

At this point, we only care about the term in brackets in Eq. A4 and wish to recast it in the form of $\chi^{2}=(\mathbf{d}-\mathbf{x})^{\dagger}\mathbf{C}^{\prime-1}(\mathbf{d}-\mathbf{x})$. Rearranging terms gives

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\chi^{2}=\mathbf{d}^{\dagger}\Bigg[\mathbf{C}^{-1}-\frac{\mathbf{C}^{-1}\mathbf{m}\mathbf{m}^{\dagger}\mathbf{C}^{-1}}{\mathbf{m}^{\dagger}\mathbf{C}^{-1}\mathbf{m}+\frac{1}{\sigma\_{Y}^{2}}}\Bigg]\mathbf{d}-2\mathbf{m}^{\dagger}\Bigg[\frac{\mathbf{C}^{-1}}{\sigma\_{Y}^{2}\mathbf{m}^{\dagger}\mathbf{C}^{-1}\mathbf{m}+1}\Bigg]\mathbf{d}-\frac{1}{\sigma\_{Y}^{4}\mathbf{m}^{\dagger}\mathbf{C}^{-1}\mathbf{m}+\sigma\_{Y}^{2}}+\frac{1}{\sigma\_{Y}^{2}}$ |  | (A5) |

The term quadratic in $\mathbf{d}$ gives us $\mathbf{C}^{\prime-1}$. Using the Sherman-Morrison-Woodbury formula tells us

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{C}^{\prime}=\mathbf{C}+\sigma\_{Y}^{2}\mathbf{m}\mathbf{m}^{\dagger}.$ |  | (A6) |

The correct way to include the calibration uncertainty into the covariance is by multiplying the uncertainty by the outer product of the model. If one were to run MCMC with the calibration marginalized over, then Eq. A6 would need to be updated with $\mathbf{m}$ at each step.

To see how using the data ($\mathbf{d}$) in Eq. A6 instead of $\mathbf{m}$ would lead to a bias, lets consider just two data points, one scattered high and one scattered low from the truth with equal variance.
If we wished to model the two data points as a constant line, the best-fit in terms of minimizing $\chi^{2}$ would be a horizontal line, $m\_{i}=m\mu\_{i}$ where $\mu\_{i}=1$ $\forall$ $i$ and $m=\frac{1}{2}(d\_{1}+d\_{2})$, that splits the difference between the two points. If we instead make the calibration uncertainty data dependent,
the covariance becomes

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\mathbf{C}^{\prime\prime}=\mathbf{C}+\sigma\_{Y}^{2}\mathbf{d}\mathbf{d}^{\dagger}$ |  | (A7) |

and minimizing $\chi^{2}$ tells us

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle m=\frac{\sum\_{i,j}(\mathbf{C}^{\prime\prime-1})\_{ij}d\_{j}}{\sum\_{i,j}(\mathbf{C}^{\prime\prime-1})\_{ij}}.$ |  | (A8) |

The best-fit line will be shifted towards the lower valued data point since it receives a greater weighting from $\mathbf{C}^{\prime\prime-1}$. The magnitude of the shift depends on the magnitude of the calibration uncertainty.

To avoid the bias discussed in this section, we multiply our model by a calibration parameter and include a prior in our likelihood. Beam uncertainty is either incorparated in a model dependent way similar to Eq. A6 or as parameterized templates.
