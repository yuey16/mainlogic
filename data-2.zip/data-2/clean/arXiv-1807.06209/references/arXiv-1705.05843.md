<!-- fulltext source=arxiv_html slug=arXiv-1705.05843 fetched=2026-09-18T01:18:46+00:00 -->

# HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results

2017HICOSMO - Cosmology with a complete sample of galaxy clusters.
  
II. Cosmological results–[4](#A2.T4 "Table 4 ‣ Appendix B Gas mass fraction ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")

G. Schellenberger
††thanks: E-mail: gerrit.schellenberger@cfa.harvard.edu
Affiliation: Argelander-Institut für Astronomie, Universität Bonn, Auf dem Hügel 71, 53121 Bonn, Germany
Affiliation: Harvard-Smithsonian Center for Astrophysics, 60 Garden Street, Cambridge, MA 02138, USA
  
T. H. Reiprich
Affiliation: Argelander-Institut für Astronomie, Universität Bonn, Auf dem Hügel 71, 53121 Bonn, Germany

Accepted XXX. Received YYY; in original form ZZZ

###### Abstract

The X-ray bright, hot gas in the potential well of a galaxy cluster enables systematic X-ray studies of samples of galaxy clusters to constrain cosmological parameters.
HIFLUGCS consists of the 64 X-ray brightest galaxy clusters in the Universe, building up a local sample. Here we utilize this sample to determine, for the first time, individual hydrostatic mass estimates for all the clusters of the sample and, by making use of the completeness of the sample, we quantify constraints on the two interesting cosmological parameters, $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$.
We apply our total hydrostatic and gas mass estimates from the X-ray analysis to a Bayesian cosmological likelihood analysis and leave several parameters free to be constrained.
We find $\Omega\_{\mathrm{m}}=$0.30(1)$$ and $\sigma\_{8}=$0.79(3)$$ (statistical uncertainties, 68% credibility level) using our default analysis strategy combining both, a mass function analysis and the gas mass fraction results.
The main sources of biases that we correct here are (1) the influence of galaxy groups (incompleteness in parent samples and differing behavior of the $L\_{x}-M$ relation), (2) the hydrostatic mass bias, (3) the extrapolation of the total mass (comparing various methods), (4) the theoretical halo mass function and (5) other physical effects (non-negligible neutrino mass). We find that galaxy groups introduce a strong bias, since their number density seems to be over predicted by the halo mass function. On the other hand, incorporating baryonic effects does not result in a significant change in the constraints. The total (uncorrected) systematic uncertainties ($\sim 20\%$) clearly dominate the statistical uncertainties on cosmological parameters for our sample.

###### Keywords:

cosmological parameters – large-scale structure of Universe – cosmology: observations – galaxies: clusters: intracluster medium – X-rays: galaxies: clusters

## 1 Introduction

Galaxy clusters reside at the intersections of Dark Matter filamentary structure. These largest gravitationally bound systems therefore bear witness to the growth of structure in the Universe and are excellent objects for cosmological studies. With our current knowledge of cosmological parameters it is possible to construct the cluster mass function and predict the number density of Dark Matter halos, reflected by the observed population of galaxy clusters. The key parameters are the normalized matter density, $\Omega\_{\rm M}$, and the amplitude of initial density fluctuations, $\sigma\_{8}$. Even using only nearby galaxy clusters these quantities can be constrained from the shape of the mass function (e.g., [Ikebe et al., 2002](#bib.bib45); [Reiprich &
Böhringer, 2002](#bib.bib75)).

In the past, tremendous efforts were made to break the degeneracy between these parameters and lower their uncertainties by using better instruments, larger samples of clusters, and more advanced analysis methods.

However, there are alternative approaches to constraining cosmology which can be applied alongside or in combination with studies of galaxy clusters. The primary anisotropies in the cosmic microwave background (CMB) are an independent probe of cosmological parameters, which trace the radiation from a very early epoch of the Universe. This makes them a complementary tool to galaxy clusters, which trace structure formation across cosmic time.
The ellipses of the $\Omega\_{\rm M}$ - $\sigma\_{8}$ confidence levels are almost perpendicular to each other, which means including different probes in the analysis will strongly shrink the uncertainties.
Although the combined analysis has advantages, it is crucial to interpret the cosmological results of each method separately to estimate and minimize systematic biases.

Assumptions have to be made to obtain the galaxy cluster total mass from X-ray observations. One way is to assume that the ICM is in hydrostatic equilibrium. Another is to use tracers like luminosity or temperature as a proxy for the total mass.
Calibrating the scaling relations of between these observables and the total mass using, e.g., weak gravitational lensing observations, might provide a way to be avoid biases caused by deviations from hydrostatic equilibrium. Unfortunately other (maybe unknown) biases are connected with weak lensing studies, such as noise bias (e.g., [Massey
et al., 2013](#bib.bib65)), mass sheet degeneracy (e.g., [Schneider &
Seitz, 1995](#bib.bib78); [Bradač et al., 2004](#bib.bib15)), asymmetry of the point spread function (e.g., [Hirata &
Seljak, 2003](#bib.bib41)), false photometric redshifts and miscentering ([Köhlinger et al., 2015](#bib.bib48)). Selection effects in the generation of a galaxy cluster sample (e.g., selecting only massive or intrinsically brighter objects) can also bias cosmological results, if they are not accounted for properly.

Moreover, all measurements depend on the calibration accuracy of the instrument used. Any systematic uncertainties arising from the instrument itself have to be known. As shown, e.g., in [Schellenberger et al. (2015)](#bib.bib77), instrumental calibrations are still relatively uncertain in the X-ray regime. Although the relative differences between two instruments, Chandra ACIS and XMM-Newton EPIC, are known, it cannot be determined which instrument is correct, if any. The known uncertainties between these two X-ray instruments can be incorporated as a range of instrumental systematics, but the true cluster temperature could be outside the range given by these two instruments, even though it has been shown with small samples that Chandra-ACIS and XMM-Newton PN mark roughly the extreme cases among 10 X-ray detectors ([Grant
et al., 2013](#bib.bib37); [Burrows
et al., 2014](#bib.bib18)). However, as described in [Schellenberger et al. (2015)](#bib.bib77), the impact of the cross calibration uncertainties between XMM-Newton and Chandra on cosmology is not larger than the statistical uncertainties for samples like HIFLUGCS, because most clusters have relatively low temperatures at $R\_{500}$. At these outer radii the temperature has dropped significantly for most clusters and groups compared to the peak temperature at inner radii (e.g., [De Grandi &
Molendi, 2002](#bib.bib24); [Vikhlinin
et al., 2005](#bib.bib84); [Rasmussen &
Ponman, 2007](#bib.bib74); [Leccardi &
Molendi, 2008](#bib.bib51); [Sun et al., 2009](#bib.bib81)).

An X-ray flux limited sample like HIFLUGCS is of special interest for cosmology: It provides high quality data of nearby galaxy clusters, which can be studied in detail to get precise temperature and surface brightness profiles. It has been shown in [Reiprich &
Böhringer (2002)](#bib.bib75) that with such a sample, $\Omega\_{\rm m}$ and $\sigma\_{8}$ can be quantified, so one has an independent probe for cosmological parameters in hand.

In the present study we aim to put constraints on at least these two cosmological parameters and also to gain knowledge about the physical processes in the X-ray brightest galaxy cluster sample.
For the first time we will use individual, X-ray derived hydrostatic mass estimates of a complete sample of galaxy clusters to constrain cosmological parameters. The HIFLUGCS sample consists of the X-ray brightest galaxy clusters, with very high data quality available. Not only will we study the halo mass function and the cosmological implications, but also evaluate and quantify many sources of systematic biases.

In [Schellenberger & Reiprich (2017)](#bib.bib76) (Paper I), we described in detail our data analysis strategy and presented the total and gas mass estimates for all HIFLUGCS clusters.
Here we apply these data in a cosmological likelihood analysis and discuss in detail the systematic effects entering in such a flux limited sample of galaxy clusters.
All uncertainties are 68.3% percent levels, unless stated otherwise. For the calculation of physical cluster quantities we assume a Flat $\Lambda$CDM cosmology with $H\_{0}=$71\text{\,}\mathrm{k}\mathrm{m}\,\mathrm{s}^{-1}\,\mathrm{M}\mathrm{p}\mathrm{c}^{-1}$$ and $\Omega\_{\mathrm{m}}=0.27$.

## 2 Cosmological analysis

We determined the important quantities, gas mass and total mass, for each HIFLUGCS galaxy cluster individually. In this section we describe how we constrain cosmological parameters from these two quantities. The model for the total mass is based on the halo mass function and described in following section ([2.2](#S2.SS2 "2.2 The likelihood estimate for the halo mass function ‣ 2 Cosmological analysis ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")).
The gas mass fraction analysis (Section [2.3](#S2.SS3 "2.3 Gas mass fraction as cosmological probe ‣ 2 Cosmological analysis ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")) is based on the idea that the gas mass to total mass fraction should reach a cosmic mean value in galaxy clusters at large radii.

### 2.1 Hydrostatic masses

In Paper I, we describe in detail the derivation of the hydrostatic masses for all HIFLUGCS clusters from Chandra data. We summarize here the important steps:

* •

  We parameterize the deprojected cluster temperature and density profiles. For the temperature profile, we use three different models depending on the available data quality, whereas for the surface brightness analysis we use a double-$\beta$ model to determine the density. The covariance between the free parameters is taken into account by an MCMC fitting algorithm.
* •

  Assuming hydrostatic equilibrium we can calculate a total mass within a given radius from the MCMC chains. To reach an overdensity of 500 ($R\_{500}$) we have to extrapolate for most of the clusters. After comparing several methods, we decided to use the NFW Freeze method as default: An NFW model is fitted to the mass profile at a radial range that corresponds to the last three to five temperature measurements. The concentration parameter of the NFW model is set by the $c-M$ relation given in [Bhattacharya et al. (2013)](#bib.bib10).
* •

  A comparison of the masses with dynamical and SZ masses results in overall agreement.
* •

  A small correction for the extrapolation algorithm is applied before they are used in our cosmological analysis. This correction is discussed in Section [4.2.4](#S4.SS2.SSS4 "4.2.4 𝑅_500-test ‣ 4.2 Systematics of the mass determination ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results").

### 2.2 The likelihood estimate for the halo mass function

The halo mass function is sensitive to cosmological parameters like $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$. It represents the galaxy cluster number density at a given mass and redshift. In order to account for the selection criterion, luminosities for each cluster are required. More details on the input parameters (total cluster mass, redshift and luminosity) are given in Paper I.
In order to construct a cluster mass function, the selection function of the sample is crucial. In the case of HIFLUGCS it is based on an X-ray flux cut. Since there exists a tight correlation between the cluster total mass and the luminosity, we include this scaling relation in the mass function analysis to correct for selection effects (see Appendix [A](#A1 "Appendix A Likelihood function ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") for details). A simultaneous fit by leaving scaling relation parameters free to vary ensures that the $L\_{x}-M$ relation is not affected by biases (e.g., Malmquist or Eddington bias), but reflects the behavior of the real cluster population given by the halo mass function.

As shown in Appendix [A](#A1 "Appendix A Likelihood function ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") the likelihood function, which evaluates the probability of observed cluster properties based on model parameters, is given by,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{L}\propto e^{-\langle N\_{\mathrm{det}}\rangle}\prod\limits\_{i=1}^{N\_{\mathrm{det}}}\langle N\_{\mathrm{det}}\rangle\cdot\tilde{P}\_{i}~,$ |  | (1) |

as also shown in [Mantz et al. (2010)](#bib.bib61); [Mantz
et al. (2015)](#bib.bib63).

The implementation in a `C` code also includes the CLASS source code ([Lesgourgues, 2011a](#bib.bib52)) to recalculate the transfer function for each cosmology.
For the cosmological application the Metropolis algorithm was implemented. In the following we describe the free parameters and their priors:

* •

  $\Omega\_{\mathrm{m}}$, the normalized matter density of today’s Universe. It is set to a (flat) uniform probability distribution as prior with 0.05 and 0.5 as the lower and upper limits.
* •

  $\sigma\_{8}$, the amplitude of density fluctuations in the initial density field: Uniform prior with 0.3 and 1.2 as boundaries.
* •

  $(1-b)$, the mass bias: Can be frozen to 1 (no bias, as in case of the “raw” analysis procedure), but in some cases variable with a uniform or normal prior (see Section [4.3](#S4.SS3 "4.3 Galaxy cluster physics ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")).

For the parameters of the mass($M$)-luminosity($L\_{x}$, in the $0.1-2.4\,$keV band) relation,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\log\_{10}\left(\frac{L\_{x}}{h^{-2}\,${10}^{44}\text{\,}\mathrm{e}\mathrm{r}\mathrm{g}\,\mathrm{s}^{-1}$}\right)=A\_{\mathrm{LM}}+B\_{\mathrm{LM}}\cdot\log\_{10}\left(\frac{M}{h^{-1}\,${10}^{15}\text{\,}\mathrm{M}\_{\odot}$}\right):$ |  | (2) |

* •

  $A\_{\mathrm{LM}}$, the intercept of the $L\_{x}-M$ relation (see Eq. [2](#S2.E2 "In 2.2 The likelihood estimate for the halo mass function ‣ 2 Cosmological analysis ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")): Uniform prior with 0 and 2.8 as boundaries.
* •

  $B\_{\mathrm{LM}}$, the slope of the $L\_{x}-M$ relation (see Eq. [2](#S2.E2 "In 2.2 The likelihood estimate for the halo mass function ‣ 2 Cosmological analysis ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")): Uniform prior with 0.8 and 2.5 as boundaries.
* •

  $\sigma\_{\mathrm{LM}}$, the scatter of the $L\_{x}-M$ relation: By defaults frozen to the scatter of the observed sample, but in some cases variable between 0.1 and 0.5 with a uniform prior.

The following parameters were not variable during the cosmological analysis, because either the local halo mass function is not sensitive to them, or they are highly degenerate with other parameters for any galaxy cluster sample and need supplementary methods (e.g., primary CMB anisotropies) to be determined:

* •

  $\Omega\_{\mathrm{k}}$, the spatial curvature parameter. It is set to 0, which implies a flat Universe.
* •

  $\Omega\_{\mathrm{r}}$, the radiation density of today’s Universe, which is set to 0 for all calculations except the transfer function.
* •

  $w$, the equation of state parameter for the Dark Energy. This is set to a constant value (no evolution term $w\_{a}$) of $-1$ (i.e. equivalent to a Cosmological Constant).
* •

  $N\_{\mathrm{eff}}$, the effective number of neutrino species. This is by default set to $3.046$ ([Dicus et al., 1982](#bib.bib25); [Mangano et al., 2002](#bib.bib59); [Lesgourgues &
  Pastor, 2006](#bib.bib54)). Usually one massive neutrino with $m\_{\nu}=$0.06\text{\,}\mathrm{e}\mathrm{V}$$ enters in the calculation of the transfer function ([Lesgourgues &
  Pastor, 2012](#bib.bib55); [Lesgourgues &
  Pastor, 2014](#bib.bib56)).
* •

  $T\_{0}$, the CMB temperature. It is set to $2.725\,48\text{\,}\mathrm{K}$ ([Fixsen, 2009](#bib.bib34)). For the given parameters this means that the photon energy density $\Omega\_{\gamma}=$5.0\text{\times}{10}^{-5}$$ and the neutrino density $\Omega\_{\nu}=$3.5\text{\times}{10}^{-5}$$, so the total radiation density used for the transfer function is $\Omega\_{\mathrm{r}}=$8.5\text{\times}{10}^{-5}$$. More details are also given in Section [4.6.2](#S4.SS6.SSS2 "4.6.2 Neutrinos ‣ 4.6 Reference model validity ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results").

The values are adopted from WMAP9 data ([Hinshaw
et al., 2013](#bib.bib40)), unless stated otherwise. For a discussion of the differences between WMAP and Planck results, and why we rely on the former, we refer to Section [4.1](#S4.SS1 "4.1 Difference to WMAP9 ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results"). For the Hubble constant, $H\_{0}=$100\text{\,}\mathrm{k}\mathrm{m}\,\mathrm{s}^{-1}\,\mathrm{M}\mathrm{p}\mathrm{c}^{-1}$\cdot h$, the Baryon density $\Omega\_{\mathrm{b}}$, and the spectral slope of the primordial power spectrum $n\_{s}$, the WMAP9 posterior distribution was adopted as a prior11
1
These priors were estimated from the WMAP9 parameter posterior distribution by a multivariate Gaussian. on these parameters.

### 2.3 Gas mass fraction as cosmological probe

It has been shown that the cluster ICM mass (called gas mass) can be extracted from X-ray observations. Using both the total and gas mass, one can directly draw conclusions on the baryon fraction in the Universe (e.g., [White et al., 1993b](#bib.bib89)):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{M\_{\mathrm{gas}}+M\_{\mathrm{stars}}}{M\_{\mathrm{tot}}}\approx\frac{\Omega\_{\mathrm{b}}}{\Omega\_{\mathrm{m}}}~,$ |  | (3) |

where $M\_{\mathrm{stars}}$ is the total stellar mass, which provides an additional minor contribution to the baryon budget. Observations (e.g., [Ettori, 2003](#bib.bib30); [Ettori
et al., 2003](#bib.bib32)) have shown that there exists a baryon deficit in clusters, which may be interpreted as undetected baryons or underestimated $\Omega\_{\mathrm{m}}$.
However, equation [3](#S2.E3 "In 2.3 Gas mass fraction as cosmological probe ‣ 2 Cosmological analysis ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") only holds if the gas is distributed in clusters in the same way as in the rest of the Universe. Furthermore, the radius at which the masses are measured should not change the gas mass fraction $f\_{\mathrm{gas}}$. In reality processes like AGN feedback and star formation can cause the gas to be ejected from potential wells. These effects are more dominant in galaxy groups than in clusters, so there may be a mass dependence of the potential baryon deficit.

Non-radiative simulations, including gravity, pressure gradients and hydrodynamical shocks by [Eke
et al. (1998)](#bib.bib29) or [Crain
et al. (2007)](#bib.bib21) predict that the baryon fraction within the virial radius of galaxy clusters is equal or close to the cosmic mean value inferred from CMB experiments. At smaller radii (e.g., $r\_{2500}$) a depletion factor can be calculated. These correction factors have been used for cosmology, e.g., by [Allen
et al., 2002](#bib.bib3); [Allen et al., 2008](#bib.bib4).
Other physical effects like AGN feedback, can introduce an additional bias, which has been implemented in more realistic simulations, e.g., by [Planelles
et al. (2013)](#bib.bib72) and [Battaglia et al. (2013)](#bib.bib8), and used, e.g., by [Mantz
et al. (2014)](#bib.bib62), who find $\Omega\_{\mathrm{m}}=$0.29(4)$$ and consistency with a flat Universe.

From the CMB power spectrum one has a very precise measurement of the baryon density, $\Omega\_{\mathrm{b}}=$0.022\,22$\,h^{-2}$ ([Planck
Collaboration et al., 2016a](#bib.bib70)). [Planelles
et al. (2013)](#bib.bib72) provide estimates for the gas mass fraction of galaxy clusters from simulations,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\_{\mathrm{gas}}^{\Lambda\mathrm{CDM}}=Y\_{\mathrm{g}}\,A^{\Lambda\mathrm{CDM}}\,\frac{\Omega\_{\mathrm{b}}}{\Omega\_{\mathrm{m}}}\left(\frac{d\_{\mathrm{A}}^{\Lambda\mathrm{CDM}}(z)}{d\_{\mathrm{A}}(z)}\right)^{1.5}~,$ |  | (4) |

where $\Lambda$CDM refers to the reference cosmology used for the gas and total mass calculation (flat $\Lambda$CDM model with $h=0.71$ and $\Omega\_{\mathrm{m}}=0.27$).
$Y\_{\mathrm{g}}$ is the gas depletion factor. [Planelles
et al. (2013)](#bib.bib72) used the WMAP7 ([Komatsu
et al., 2011](#bib.bib49)) cosmology, which simplifies to $\frac{\Omega\_{\mathrm{b}}}{\Omega\_{\mathrm{m}}}=0.167$.
We use the authors model of the gas depletion factor depending on radius, redshift and mass,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $Y\_{\mathrm{g}}=Y\_{0,\mathrm{g}}(1+\alpha z)\,\left(\frac{M\_{500}}{$5\text{\times}{10}^{14}\text{\,}\mathrm{h}^{-1}\,\mathrm{M}\_{\odot}$}\right)^{\beta\_{\mathrm{gas}}}\,\left(\frac{\Delta}{500}\right)^{\gamma}~,$ |  | (5) |

where $Y\_{0,\mathrm{g}}$ is the normalization, $\alpha$ the redshift dependence, $\beta\_{\mathrm{gas}}$ the mass dependence and $\gamma$ the radial dependence. Priors on these parameters are adopted from their simulations (see Tab. [1](#S3.T1 "Table 1 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")).
The ratio of angular diameter distances reflects the mass dependence on cosmology22
2
The power of 1.5 is due to the dependence $M\_{\mathrm{gas}}\propto h^{-\frac{5}{2}}$ and $M\_{\mathrm{tot}}\propto h^{-1}$..
$A^{\Lambda\mathrm{CDM}}$ is a correction factor to account for the fact that an overdensity rather than a fixed radius is used to compute the masses, which changes according to cosmology,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $A^{\Lambda\mathrm{CDM}}=\left(\frac{\theta\_{2500}^{\Lambda\mathrm{CDM}}}{\theta\_{2500}}\right)^{\eta}\approx\left(\frac{H(z)\,d\_{\mathrm{A}}}{[H(z)\,d\_{\mathrm{A}}]^{\Lambda\mathrm{CDM}}}\right)^{\eta}~.$ |  | (6) |

We used $\eta=0.71$ from our measurements of the slope of the $f\_{\mathrm{gas}}$ profile. [Allen et al. (2008)](#bib.bib4) used $\eta=$0.214(22)$$, which does not change our results since the influence of $A^{\Lambda\mathrm{CDM}}$ is very small.

We chose to measure the gas mass fraction at overdensity $\Delta=2500$ (in contrast to the mass function analysis, which uses $\Delta=500$), which only requires an extrapolation of profiles for less than half of the 64 clusters. Furthermore, in this context the total mass is measured from direct temperature profile extrapolation (“kT extrapolate”), to minimize the model influence which might enter with an NFW model.

We also include recent results on the hydrostatic bias by [Biffi
et al. (2016)](#bib.bib11) into our model.
At an overdensity of $\Delta=2500$ (unlike at $\Delta=500$) there is a significant difference between the bias for cool core (CC) and non-cool core clusters: We adopt the Gaussian distributed priors $(1-b)\_{\mathrm{CC}}=$0.999(27)$$ and $(1-b)\_{\mathrm{NCC}}=$0.877(11)$$ and use the classification of CC and NCC clusters by [Hudson et al. (2010)](#bib.bib44). Assuming the average gas density profile follows, in the outer regions, a $\beta$-model with $\beta=\frac{2}{3}$, it can be shown that the gas mass increases due to the increase of the radius as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $M\_{\mathrm{gas}}\propto\int\frac{x^{2}}{1+x^{2}}\,\mathrm{d}x~\approx x-\pi/2,$ |  | (7) |

where $x=\frac{r}{r\_{c}}\gg 1$, and $r\_{c}$ is the core radius. One can then derive the following dependence for the bias corrected gas mass,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $M\_{\mathrm{gas}}^{\mathrm{BC}}=M\_{\mathrm{gas}}\cdot(1-b)^{-\frac{1}{3}}~,$ |  | (8) |

and for the gas mass fraction,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\_{\mathrm{gas}}^{\mathrm{BC}}=f\_{\mathrm{gas}}\cdot(1-b)^{\frac{2}{3}}~.$ |  | (9) |

The fit was performed using an MCMC with priors on 8 variables and leaving only $\Omega\_{\mathrm{m}}$ with a uniform prior (see Tab. [1](#S3.T1 "Table 1 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")).

## 3 Results

Our cosmological results from the halo mass function and the gas mass fraction analysis are presented here. Since the $f\_{\mathrm{gas}}$ test only constrains $\Omega\_{\mathrm{m}}$, we present these results first, in order to add these results as priors to our mass function analysis and obtain combined results.

The posterior results in Table [1](#S3.T1 "Table 1 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") for the sample with mass cut (comprising 28 objects), shows excellent agreement with the priors, while $\Omega\_{\mathrm{m}}$ is significantly higher than in the halo mass function analysis.
Without the redshift cut $\Omega\_{\mathrm{m}}$ is 14% lower and the mass dependence of the depletion, $\beta\_{\mathrm{gas}}$, is in strong tension with the prior input (from simulations by [Planelles
et al., 2013](#bib.bib72)), but in rough agreement with other studies
([Sun et al., 2009](#bib.bib81); [Zhang et al., 2011b](#bib.bib93): $\beta\_{\mathrm{gas}}=$0.30(7)$$, also [Vikhlinin
et al., 2006](#bib.bib85); [Arnaud et al., 2007](#bib.bib6); [Sun et al., 2009](#bib.bib81): $\beta\_{\mathrm{gas}}=$0.21(3)$$ and [Chiu
et al., 2016](#bib.bib20): $\beta\_{\mathrm{gas}}=$0.22(6)$$), especially considering our broad mass coverage.
There exist correlations (absolute of Pearson coefficient larger than 0.5) for $\Omega\_{\mathrm{m}}$ and $h$, $\Omega\_{\mathrm{m}}$ and $\gamma$, and $\Omega\_{\mathrm{m}}$ and $Y\_{0,\mathrm{g}}$. The first correlation is negative (the larger $\Omega\_{\mathrm{m}}$, the smaller becomes $h$), while the remainder are positive. We also tested the algorithm by artificially multiplying all $f\_{\mathrm{gas}}$ values by 2 or 0.5. This leads to roughly halved or doubled $\Omega\_{\mathrm{m}}$ values, respectively, while the change for the other parameters is very small. This test was performed both with and without the mass cut, and indicates that the best-fit determination of $\Omega\_{\mathrm{m}}$ is not biased by the priors on the other parameters.
As discussed in Section [4.3.1](#S4.SS3.SSS1 "4.3.1 Galaxy groups ‣ 4.3 Galaxy cluster physics ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results"), to exclude the effects of biases arising from the structure of the local Universe, we use the redshift limited results ($z>0.05$) as our default. This analysis leads to $\Omega\_{\mathrm{m}}=$0.305(9)$$.

| Parameter | Prior | Posterior | |
| --- | --- | --- | --- |
|  |  | $z>0.05$ | All clusters |
| $\Omega\_{\mathrm{m}}$ | $U(0.05,0.8)$ | $0.305(9)$ | $0.260(8)$ |
| $h$ | $N(0.70,0.022)$ | $0.689(23)$ | $0.685(22)$ |
| $Y\_{0,\mathrm{g}}$ | $N(0.67,0.01)$ | $0.675(10)$ | $0.676(9)$ |
| $\alpha$ | $N(0.02,0.02)$ | $0.046(2)$ | $0.059(2)$ |
| $\beta\_{\mathrm{gas}}$ | $N(0.06,0.01)$ | $0.031(7)$ | $0.343(2)$ |
| $\gamma$ | $N(-0.12,0.01)$ | $-0.115(10)$ | $-0.115(10)$ |
| $(1-b)\_{\mathrm{CC}}$ | $N(0.999,0.027)$ | $1.025(16)$ | $1.160(15)$ |
| $(1-b)\_{\mathrm{NCC}}$ | $N(0.877,0.011)$ | $0.869(10)$ | $0.836(10)$ |

Table 1: 8 free parameters (with priors) for the $f\_{\mathrm{gas}}$ test. $N(x,y)$ is a normal distributed prior with mean $x$ and standard deviation $y$, while $U(v,w)$ is a uniform distributed prior with $v$ and $w$ as the lower and upper boundary.

Starting from the 64 HIFLUGCS $M\_{500}$ masses which are extrapolated using an NFW model with a frozen concentration parameter (“NFW Freeze”, see Paper I) we aim at constraining the two cosmological parameters, $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$, plus the two parameters of the $L\_{x}-M$ scaling relation, slope and intercept.
In the discussion section of this paper we estimate the reliability of these masses for the cosmological analysis.
Our main result for the cosmological analysis incorporates

* •

  a lower redshift threshold of $z>0.05$ to exclude galaxy groups on the one hand and the influence of the nearby Universe,
* •

  a correction for the extrapolation of the total mass based on the $R\_{500}$-test (Section [4.2.4](#S4.SS2.SSS4 "4.2.4 𝑅_500-test ‣ 4.2 Systematics of the mass determination ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")),
* •

  a Gaussian distributed hydrostatic bias of $(1-b)=0.877$ with a standard deviation of $0.015$ as described in [Biffi
  et al. (2016)](#bib.bib11) for $\Delta=500$. Since for this overdensity the difference between CC and NCC clusters (as well as for regular and disturbed clusters) is not significant, we use only one bias for all clusters (see also Section [4.3.2](#S4.SS3.SSS2 "4.3.2 Hydrostatic bias ‣ 4.3 Galaxy cluster physics ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")).
* •

  The result for $\Omega\_{\mathrm{m}}$ coming from the gas mass fraction analysis is added as a prior in the MCMC.

This is our default setup of the mass function analysis.
Luminosities are taken from [Reiprich &
Böhringer (2002)](#bib.bib75) and accounted for the K-correction.
As pointed out in Paper I, we stay consistent with the selection function of the HIFLUGCS cluster sample by using the same luminosities computed in [Reiprich &
Böhringer (2002)](#bib.bib75), which were mostly computed from ROSAT pointed observations. Moreover, other instruments (Chandra/ACIS, XMM-Newton/EPIC) do not cover the region up to the cluster outskirts. A combined ROSAT and XMM-Newton luminosity comparison has been shown in [Zhang
et al. (2011a)](#bib.bib92), and the authors conclude that the difference to ROSAT-only luminosities is smaller than the intrinsic scatter. Moreover, assuming all our luminosities were offset by a constant factor (as it is found, e.g., by [Zhang
et al., 2011a](#bib.bib92) for a comparison of ROSAT and XMM-Newton combined luminosities) would not affect our estimates of the cosmological parameters, since a change in the normalization $L\_{x}-M$ relation will compensate for a bias in $L\_{x}$. For a more extended discussion of the $L\_{x}-M$ relation we refer to Paper I.

The scatter of the $L\_{x}-M$ relation is frozen to the observed value, 0.24. The results for the four free parameters, $\Omega\_{\mathrm{m}}$, $\sigma\_{8}$, $A\_{\mathrm{LM}}$, $B\_{\mathrm{LM}}$, are shown in Fig. [1](#S3.F1 "Figure 1 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") and Tab. [2](#S3.T2 "Table 2 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results").

Figure 1: Results on the cosmological parameters, $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$. The default setup is shown in blue (circle) which incorporates the NFW Freeze masses with the $R\_{500}$-test corrections, a hydrostatic bias from [Biffi
et al. (2016)](#bib.bib11), the lower redshift cut at $0.05$ and the prior on $\Omega\_{\mathrm{m}}$ from the $f\_{\mathrm{gas}}$ test (yellow). Also shown are the results without the $f\_{\mathrm{gas}}$ constraints (black), the default plus WMAP9 priors (green, WMAP9 alone is shown in red).

In Figure [2](#S3.F2 "Figure 2 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") we show the detailed confidence levels (68.3% and 95.4%) in the 2D parameter space for the parameter combinations.

Figure 2: Confidence levels (68.3% and 95.4%) of the 2D parameter space of the four important quantities, $\Omega\_{\mathrm{m}}$, $\sigma\_{8}$, intercept and slope of the $L\_{x}-M$ relation ($A\_{\mathrm{LM}}$ and $B\_{\mathrm{LM}}$, respectively).

| Setup | $\Omega\_{\mathrm{m}}$ | $\sigma\_{8}$ | $A\_{\mathrm{LM}}$ | $B\_{\mathrm{LM}}$ |
| --- | --- | --- | --- | --- |
| MF + $f\_{\mathrm{gas}}$ (default) | $0.303^{+0.009}\_{-0.009}$ | $0.790^{+0.030}\_{-0.028}$ | $0.667^{+0.074}\_{-0.073}$ | $1.337^{+0.130}\_{-0.122}$ |
| MF + $f\_{\mathrm{gas}}$ + WMAP9 | $0.297^{+0.008}\_{-0.008}$ | $0.822^{+0.016}\_{-0.014}$ | $0.614^{+0.059}\_{-0.058}$ | $1.271^{+0.121}\_{-0.110}$ |
| MF | $0.217^{+0.073}\_{-0.054}$ | $0.894^{+0.098}\_{-0.095}$ | $0.654^{+0.071}\_{-0.071}$ | $1.225^{+0.154}\_{-0.154}$ |
| $f\_{\mathrm{gas}}$ | $0.305^{+0.009}\_{-0.009}$ |  |  |  |
| WMAP9 | $0.279^{+0.027}\_{-0.025}$ | $0.821^{+0.024}\_{-0.024}$ |  |  |

Table 2: MCMC results for the free parameters from the cosmological pipeline for the different setups. Uncertainties are marginalized 68.3%.

Figure 3: The cluster mass function (only for illustrational purpose) for the full sample (black) and just the high redshift subsample (red). See text for details.

The strong degeneracy between $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$, that can be seen for the mass function (MF) results in Fig. [1](#S3.F1 "Figure 1 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") disappears when adding prior from the $f\_{\mathrm{gas}}$ test.
For the MF results, the definition of $\sigma\_{8}$ forces the degeneracy, since the root mean square (RMS) amplitude of fluctuations at a given mass, $\sigma(M)$, enters in the mass function and depends on $\Omega\_{\mathrm{m}}$. The limit to a certain scale, $\sigma\_{8}$, still depends on $\Omega\_{\mathrm{m}}$ (see also [White
et al., 1993a](#bib.bib88); [Vikhlinin
et al., 2009b](#bib.bib87)).

Figure 4: 68.3% and 95.4% confidence regions for $\Omega\_{\mathrm{M}}$ and $\sigma\_{8}$ for various analysis setups (see text for details). Note that Vikhlinin$+$09 results have been reanalyzed with our pipeline.

A correlation between the slope and normalization of the $L\_{x}-M$ relation (the larger the slope, the higher the normalization) is also detected (Pearson 0.81), and does not disappear with a prior on $\Omega\_{\mathrm{m}}$.
No degeneracy is found for $\Omega\_{\mathrm{m}}$ and the slope or normalization. The chains show a very stable behavior, implying that convergence is very rapid. Testing the chains with different initial values (including values far away from the potential best-fit) produces the same results, which indicates that we are not just mapping a local minimum of the likelihood function.

Figure [3](#S3.F3 "Figure 3 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") shows the halo mass function with the binned cluster masses. The black line and data points correspond to all 64 HIFLUGCS clusters (without redshift cut), the red line and datapoints reflect just the high redshift sample ($z>0.05$) and the green line adds the prior on $\Omega\_{\mathrm{m}}$.
The masses have been corrected according to the $R\_{500}$-test (Section [4.2.4](#S4.SS2.SSS4 "4.2.4 𝑅_500-test ‣ 4.2 Systematics of the mass determination ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")) and hydrostatic bias, $(1-b)=0.877$ (Section [4.3.2](#S4.SS3.SSS2 "4.3.2 Hydrostatic bias ‣ 4.3 Galaxy cluster physics ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")).
Note that this illustration does not show a real fit to the datapoints, since the likelihood analysis accounts for each cluster redshift, simultaneously fits the $L\_{x}-M$ relation and does not depend on any binning of clusters.

We tested our pipeline with the (low redshift sub-)sample and results from [Vikhlinin
et al. (2009a)](#bib.bib86); [Vikhlinin
et al. (2009b)](#bib.bib87). This low redshift sample has broad overlap with the HIFLUGCS sample and was constructed using the BCS, REFLEX and HIFLUGCS samples with the same criterion on the survey area as in HIFLUGCS. Fluxes have been redetermined in the $0.52\text{\,}\mathrm{k}\mathrm{e}\mathrm{V}$ band using pointed ROSAT observations. The final fluxlimit is $1.3\text{\times}{10}^{-11}\text{\,}\mathrm{e}\mathrm{r}\mathrm{g}\,\mathrm{s}^{-1}\,\mathrm{c}\mathrm{m}^{-2}$ in this band and additionally a lower redshift limit of 0.025 was applied. This results in 49 galaxy clusters in this low redshift subsample. The high-redshift sample comprises 36 clusters from the 400d survey ([Burenin
et al., 2007](#bib.bib17)) above redshift 0.35. In the following we only test the low redshift sample. Masses have been obtained by using either the gas mass $M\_{\mathrm{gas}}$, temperature $kT$, or $Y\_{x}=kT\times M\_{\mathrm{gas}}$ as a proxy. Scaling relations between these quantities and the hydrostatic mass have been calibrated using a low redshift, relaxed sample of 10 clusters ([Vikhlinin
et al., 2006](#bib.bib85)). While the actual results on $\Omega\_{\mathrm{m}}$ or $\sigma\_{8}$ do not depend on the choice of the mass proxy, $Y\_{x}$ is chosen as default. The cluster masses $M\_{Y\_{X}}$ and luminosities of the low redshift subsample have been taken from this reference and tested with the cosmological analysis pipeline, accounting for the new selection and a new K-correction due to the changed energy band. As seen in Fig. [4](#S3.F4 "Figure 4 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") and Fig. 3 in [Vikhlinin
et al. (2009b)](#bib.bib87), the results are in good agreement. Note that only the combination of both samples is shown in the reference figure, so perfect agreement is not expected, despite the differences in the analysis strategy (e.g., we assume a flat Universe).

Another option is to leave the scatter $\sigma\_{\mathrm{LM}}$ free to vary (flat priors). This introduces an additional degree of freedom, but does not change results. The uncertainties increase slightly in this case, but the best-fit scatter is in perfect agreement with the observed scatter, which was used in the default setup.

We perform one more test by fixing the $L\_{x}-M$ relation to the bias-corrected one from [Pratt et al. (2009)](#bib.bib73), where luminosities were also calculated in the same energy band. In the $\Omega\_{\mathrm{m}}-\sigma\_{8}$ plane the confidence regions follow the main degeneracy of the default case (Fig. [1](#S3.F1 "Figure 1 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")), but shifted toward lower $\sigma\_{8}$.
We also show in Fig. [4](#S3.F4 "Figure 4 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") the mass function results for the plain NFW Freeze masses without $f\_{\mathrm{gas}}$ prior, redshift cut, extrapolation correction and hydrostatic bias (raw). Since these results are the most direct, we use these as a baseline in the discussion in the following section. We label those results raw from here on, to differentiate from the default results, which already include several corrections for systematics.

Figure 5: $S\_{8}$ parameter for various setups and comparison to other cosmological experiments (KiDS: [Hildebrandt
et al., 2017](#bib.bib39); [van Uitert
et al., 2017](#bib.bib96), WMAP9: [Hinshaw
et al., 2013](#bib.bib40), Planck: [Planck
Collaboration et al., 2016a](#bib.bib70), South Pole Telescope: [de Haan
et al., 2016](#bib.bib95)).

A quantity combining $\Omega\_{\rm m}$ and $\sigma\_{8}$, and easily comparable to other experiments is $S\_{8}=\sigma\_{8}\sqrt{\Omega\_{\rm m}/0.3}$, which we show in Fig. [5](#S3.F5 "Figure 5 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") for various setups. $S\_{8}$ is sensitive to the location of cosmological constraints in the $\Omega\_{\rm m}-\sigma\_{8}$ plane, taking into account the inferred degeneracy of these quantities for mass function analyses. We find excellent agreement of our default result with the WMAP9 (primary anisotropies), SPT (SZ) and KiDS (lensing, especially after combining the with other probes from galaxy-galaxy-lensing and angular clustering, see [van Uitert
et al., 2017](#bib.bib96)) results. Our raw results without any corrections are not in agreement. The source of this bias is evaluated in the following section.

## 4 Discussion

In this section we discuss the systematic effects that might enter in our cosmological analysis.
We compare here the effect of every test with the “raw” results, rather than the “default” corrected results.
In Table [3](#S4.T3 "Table 3 ‣ 4.1 Difference to WMAP9 ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") we summarize the cosmological results of the various tests and also estimate their bias by computing the shift in $S\_{8}$ with respect to the “raw” case.

### 4.1 Difference to WMAP9

CMB experiments which measure temperature fluctuations at a large variety of angular scales can constrain several cosmological parameters with great precision and provide, independent of galaxy clusters, another reference for the composition and evolution of the Universe.
The two latest all-sky CMB temperature fluctuation measurements come from the WMAP satellite (9 year data; [Hinshaw
et al., 2013](#bib.bib40)) and the Planck Satellite ([Planck
Collaboration et al., 2016a](#bib.bib70)) and are compared to the HIFLUGCS cosmological results in Fig. [6](#S4.F6 "Figure 6 ‣ 4.1 Difference to WMAP9 ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results").

Figure 6: HIFLUGCS cosmology results compared to WMAP9 ([Hinshaw
et al., 2013](#bib.bib40)) and Planck 2015 ([Planck
Collaboration et al., 2016a](#bib.bib70)) results in the $\Omega\_{\mathrm{m}}$-$\sigma\_{8}$ plane. The contours correspond to 68.3% and 95.4% confidence regions.

One great advantage of combining different measurements is to eliminate the degeneracy, e.g., of $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$.
The WMAP9 and HIFLUGCS (raw) results exhibit small overlap, while the Planck 2015 results are shifted toward larger $\Omega\_{\mathrm{m}}$. In the following we focus on a comparison with the WMAP9 results, for the following reasons: A Planck cosmology would predict slightly too many galaxy clusters (e.g., [Pacaud
et al., 2016](#bib.bib69)) and there is some tension with the Planck SZ results, which predict smaller $\Omega\_{\mathrm{m}}$. The latter problem could be solved at least partially by using a weak lensing mass calibration ([Planck
Collaboration et al., 2016b](#bib.bib71), Fig. 7). Furthermore, the Planck CMB result itself is not consistent between the low and high multipole constraints ([Addison et al., 2016](#bib.bib1)).

The results of the combined MF+$f\_{\mathrm{gas}}$+WMAP9 analysis, which is the default setup with the WMAP9 constraints as priors on $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$, are also shown in Tab. [2](#S3.T2 "Table 2 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") and Fig. [1](#S3.F1 "Figure 1 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results").

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| Setup | $\Omega\_{\mathrm{m}}$ | $\sigma\_{8}$ | $A\_{\mathrm{LM}}$ | $B\_{\mathrm{LM}}$ | $\sigma\_{\mathrm{LM}}$ | $\Delta S\_{8}$ |
| default | $0.303^{+0.009}\_{-0.009}$ | $0.790^{+0.030}\_{-0.028}$ | $0.667^{+0.074}\_{-0.073}$ | $1.337^{+0.130}\_{-0.122}$ | $0.24$ | $+0.123$ |
| [raw + $R\_{500}$-test + $(1-b)=$Biffi16 + $z>0.05$] |
| default + WMAP9 | $0.297^{+0.008}\_{-0.008}$ | $0.822^{+0.016}\_{-0.014}$ | $0.614^{+0.059}\_{-0.058}$ | $1.271^{+0.121}\_{-0.110}$ | $0.24$ | $+0.148$ |
| NFW Freeze (raw) | $0.170^{+0.024}\_{-0.021}$ | $0.888^{+0.053}\_{-0.052}$ | $0.842^{+0.062}\_{-0.059}$ | $1.351^{+0.073}\_{-0.071}$ | $0.26$ | – |
| NFW All (raw-like) | $0.216^{+0.024}\_{-0.023}$ | $1.085^{+0.036}\_{-0.038}$ | $0.136^{+0.056}\_{-0.054}$ | $1.204^{+0.048}\_{-0.048}$ | $0.42$ | $+0.249$ |
| NFW Hudson (raw-like) | $0.203^{+0.025}\_{-0.020}$ | $1.087^{+0.038}\_{-0.045}$ | $0.196^{+0.055}\_{-0.054}$ | $1.213^{+0.053}\_{-0.051}$ | $0.42$ | $+0.223$ |
| kT extrapolate (raw-like) | $0.175^{+0.027}\_{-0.023}$ | $1.003^{+0.071}\_{-0.068}$ | $0.479^{+0.067}\_{-0.066}$ | $1.234^{+0.078}\_{-0.076}$ | $0.30$ | $+0.097$ |
| XMM-Newton (kT extr.) | $0.167^{+0.022}\_{-0.019}$ | $0.853^{+0.048}\_{-0.057}$ | $0.904^{+0.069}\_{-0.061}$ | $1.316^{+0.077}\_{-0.065}$ | $0.24$ | $-0.039$ |
| raw + $z>0.05$ | $0.200^{+0.065}\_{-0.047}$ | $0.889^{+0.088}\_{-0.091}$ | $0.696^{+0.071}\_{-0.068}$ | $1.182^{+0.142}\_{-0.131}$ | $0.24$ | $+0.056$ |
| raw + $z<0.05$ | $0.150^{+0.039}\_{-0.028}$ | $0.914^{+0.134}\_{-0.121}$ | $1.244^{+0.107}\_{-0.106}$ | $1.627^{+0.101}\_{-0.100}$ | $0.22$ | $-0.025$ |
| raw + 25% Groups | $0.223^{+0.033}\_{-0.029}$ | $0.820^{+0.057}\_{-0.052}$ | $0.767^{+0.057}\_{-0.056}$ | $1.242^{+0.072}\_{-0.069}$ | $0.26$ | $+0.039$ |
| raw + 50% Groups | $0.198^{+0.028}\_{-0.026}$ | $0.854^{+0.058}\_{-0.053}$ | $0.796^{+0.059}\_{-0.056}$ | $1.291^{+0.072}\_{-0.070}$ | $0.26$ | $+0.024$ |
| raw + 80% Groups | $0.178^{+0.024}\_{-0.022}$ | $0.884^{+0.054}\_{-0.052}$ | $0.811^{+0.058}\_{-0.058}$ | $1.318^{+0.069}\_{-0.066}$ | $0.26$ | $+0.012$ |
| raw + Broken Powerlaw | $0.141^{+0.021}\_{-0.019}$ | $0.988^{+0.072}\_{-0.068}$ | $0.661^{+0.133}\_{-0.132}$ | $1.697^{+0.128}\_{-0.122}$ | ${}^{\mathrm{a}}0.995^{+0.112}\_{-0.106}$ | $+0.009$ |
| raw + $(1-b)=[0.7,1]$ | $0.174^{+0.026}\_{-0.021}$ | $0.938^{+0.066}\_{-0.061}$ | $0.725^{+0.082}\_{-0.079}$ | $1.336^{+0.071}\_{-0.068}$ | $0.26$ | $+0.046$ |
| raw + $(1-b)=0.8$ | $0.177^{+0.025}\_{-0.021}$ | $0.950^{+0.058}\_{-0.055}$ | $0.694^{+0.054}\_{-0.052}$ | $1.338^{+0.070}\_{-0.068}$ | $0.26$ | $+0.059$ |
| raw + $z>0.05$ + | $0.280^{+0.023}\_{-0.020}$ | $0.822^{+0.021}\_{-0.019}$ | $0.635^{+0.089}\_{-0.090}$ | $1.281^{+0.123}\_{-0.111}$ | $0.26$ | $+0.124$ |
| $(1-b)=[0.7,1]$ + WMAP9 |
| raw + undisturbed | $0.213^{+0.034}\_{-0.028}$ | $0.784^{+0.056}\_{-0.052}$ | $0.981^{+0.073}\_{-0.075}$ | $1.516^{+0.086}\_{-0.086}$ | $0.26$ | $-0.012$ |
| raw + undisturbed + $(1-b)=0.8$ | $0.224^{+0.036}\_{-0.031}$ | $0.828^{+0.057}\_{-0.057}$ | $0.837^{+0.064}\_{-0.066}$ | $1.524^{+0.085}\_{-0.087}$ | $0.26$ | $+0.045$ |
| raw + undisturbed + | $0.271^{+0.023}\_{-0.021}$ | $0.816^{+0.021}\_{-0.021}$ | $0.727^{+0.119}\_{-0.104}$ | $1.581^{+0.064}\_{-0.061}$ | $0.26$ | $+0.106$ |
| $(1-b)=[0.7,1]$ + WMAP9 |
| Planck SZ Masses | $0.234^{+0.042}\_{-0.033}$ | $0.790^{+0.051}\_{-0.052}$ | $0.980^{+0.055}\_{-0.053}$ | $1.606^{+0.107}\_{-0.095}$ | $0.197^{+0.025}\_{-0.021}$ | $+0.028$ |
| Dynamical Masses | $0.171^{+0.027}\_{-0.021}$ | $0.944^{+0.063}\_{-0.062}$ | $0.573^{+0.068}\_{-0.072}$ | $1.236^{+0.079}\_{-0.078}$ | $0.35$ | $+0.050$ |
| raw + Bocquet DM | $0.163^{+0.024}\_{-0.021}$ | $0.857^{+0.041}\_{-0.041}$ | $0.827^{+0.056}\_{-0.055}$ | $1.339^{+0.069}\_{-0.070}$ | $0.26$ | $-0.038$ |
| raw + Bocquet Hydro | $0.171^{+0.024}\_{-0.021}$ | $0.845^{+0.038}\_{-0.039}$ | $0.822^{+0.057}\_{-0.057}$ | $1.334^{+0.066}\_{-0.065}$ | $0.26$ | $-0.031$ |
| raw + $\sum m\_{\nu}=0.5\,\mathrm{eV}$ | $0.187^{+0.024}\_{-0.020}$ | $0.850^{+0.045}\_{-0.045}$ | $0.827^{+0.060}\_{-0.058}$ | $1.343^{+0.066}\_{-0.071}$ | $0.26$ | $+0.002$ |
| raw + $\sum m\_{\nu}=1.0\,\mathrm{eV}$ | $0.215^{+0.026}\_{-0.023}$ | $0.794^{+0.040}\_{-0.039}$ | $0.839^{+0.059}\_{-0.059}$ | $1.354^{+0.070}\_{-0.069}$ | $0.26$ | $+0.003$ |

Table 3: MCMC results for the free parameters from the cosmological pipeline for the default setup and various setups used to test systematic effects. Uncertainties are purely statistical and marginalized at 68.3%. $x$% Groups refer to the normal skyfraction multiplied by $x$/100 for all objects with $M<${10}^{14}\text{\,}\mathrm{M}\_{\odot}$$. a: The high mass slope for the broken powerlaw instead of the scatter, which is $0.26$. raw-like means that the setup is identical to the raw case, only the extrapolation method is different. The last column shows the difference in the derived parameter $S\_{8}$ (see Fig. [5](#S3.F5 "Figure 5 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")) with respect to the “raw” setup.

The uncertainties of $\sigma\_{8}$ decrease by about 50%, while the uncertainties of $\Omega\_{\mathrm{m}}$ are already limited by the $f\_{\mathrm{gas}}$ prior.

### 4.2 Systematics of the mass determination

It is of crucial importance to take all possible effects into account, which could systematically bias the results. In the following we will discuss the influence of the extrapolation methods, instrumental calibration effects and the use of a different overdensity than the default $500\rho\_{\mathrm{crit}}$. This will lead to an empiric correction for the extrapolation based on clusters where the temperature profile is measured out to $R\_{500}$.
Physical effects in individual clusters, such as strong AGN feedback, and modifications to the cosmological model, are discussed in subsections ([4.3](#S4.SS3 "4.3 Galaxy cluster physics ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") and [4.6](#S4.SS6 "4.6 Reference model validity ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")).

One general concern connected with the likelihood function and the sample selection is that a few clusters are very close to the flux limit. There is a chance that these clusters might slip, due to the variable K-correction (we compute the fluxes from the given luminosities), slightly below the flux limit, which results in a very small value of the likelihood. By excluding33
3
In order to not change the statistics these clusters were not really excluded, but just given much larger uncertainties on the luminosity. these clusters from the analysis it was ensured that the cosmological results do not get biased by a very small number of clusters at the flux limit.

A similar effect could also happen if a cluster is far away from the best fit $L\_{x}-M$ relation. Usually the luminosity uncertainties are very small and the probability could essentially be $0$ or very close to it. Excluding these objects as well ensures that distant outliers are not influencing the results too much. As with the lowest flux objects, here we also conclude that $L\_{x}-M$ relation outliers are not biasing the results.

#### 4.2.1 Impact of different extrapolation methods

In Paper I, four different total mass estimates were introduced, of which the “NFW Freeze” method was chosen as default and used up to now. Although the default method should give the most robust mass estimates for large extrapolations, we show the cosmological results using the other mass estimates as well. Since some of the “NFW All” or “NFW Hudson” masses are unphysically high ($>${10}^{16}\text{\,}\mathrm{M}\_{\odot}$$), the results might produce biased $\sigma\_{8}$ values, since this parameter is sensitive to the high mass end of the mass function.
Figure [7](#S4.F7 "Figure 7 ‣ 4.2.1 Impact of different extrapolation methods ‣ 4.2 Systematics of the mass determination ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") shows the cosmological constraints of these four different methods to obtain masses.

Figure 7: 68.3% and 95.4% confidence levels for $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ for the different extrapolation methods (see also Tab. [3](#S4.T3 "Table 3 ‣ 4.1 Difference to WMAP9 ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")).

The temperature profile extrapolation method (green) seems to be almost in agreement with constraints of the standard method (black) and gives very similar results in the $\Omega\_{\mathrm{m}}-\sigma\_{8}$ plane. The uncertainties are slightly larger for “kT extrapolate”, since “NFW Freeze” has only one free parameter for the extrapolation.

The results of “NFW All” and “NFW Hudson” are in very good agreement. Both methods use the inner parts of the mass profile (“Hudson” excludes the central cool core region, if present) for the extrapolation. The inner regions might deviate from an NFW profile, having a steeper central profile slope. This causes some cluster masses to be biased high, since the concentration parameter of the NFW profile becomes unrealistically small ($<1$) to fit the profile. In particular, an intrinsically high mass at the high mass end will force larger $\sigma\_{8}$, which can be seen in Fig. [7](#S4.F7 "Figure 7 ‣ 4.2.1 Impact of different extrapolation methods ‣ 4.2 Systematics of the mass determination ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results").
If we “average” the four masses for each cluster, by taking the median and using the highest and lowest mass as the upper and lower uncertainty range, we find that the uncertainties of $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ increase by roughly 30%, which reflects the systematics involved in the extrapolation.

#### 4.2.2 XMM-Newton masses

In [Schellenberger et al. (2015)](#bib.bib77) the impact of instrumental cross calibration uncertainties on the cosmological constraints from the mass function has been evaluated. The temperature
scaling ([Schellenberger et al., 2015](#bib.bib77), Table 2) was used to convert Chandra derived temperature profiles into XMM-Newton
profiles, which is the input for the mass determination and cosmological analysis. The main result was
a shift toward slightly smaller $\Omega\_{\rm m}$ for the XMM-Newton masses. While in [Schellenberger et al. (2015)](#bib.bib77) galaxy clusters
have been binned in mass and an external $L\_{x}-M$ relation from [Reiprich &
Böhringer (2002)](#bib.bib75) was
used to calculate the volumes, here we re-evaluate this effect using the derived masses for HIFLUGCS
and the likelihood approach including the simultaneous fit of the $L\_{x}-M$ relation. For the scaling of
the temperature profiles we again use the “ACIS-Combined XMM” relation for the full energy band. We note out that the Chandra calibration has changed, and now includes the new contamination model
vN0008, but the effect of this change is small (< 2%).
For this test we focus on the temperature
extrapolation method used to calculate the masses, because the purpose is to study the effects of
calibration uncertainties (entering in the temperature profile) and NFW fits could possibly introduce an
additional bias.
We find Chandra and scaled XMM-Newton masses exhibit a different
behavior than what was inferred in the previous work: In [Schellenberger et al. (2015)](#bib.bib77) the masses were
found to have a constant fractional difference ($\sim 14\%$), while now the difference between Chandra and
XMM-Newton masses is increasing with mass, which leads to lower $\sigma\_{8}$ of the XMM-Newton masses with respect to Chandra.
We confirm the previous results that the overall shift in the
$\Omega\_{\rm m}-\sigma\_{8}$ plane cannot explain the difference between cosmological constraints of Planck primary CMB
anisotropies and SZ, and also that for the present study, the shift is smaller than the statistical uncertainty.

#### 4.2.3 Different overdensities

The ideal halo mass function is a universal parametrization, which applies at all redshifts and cosmologies. Unfortunately, as pointed out in [Tinker
et al. (2008)](#bib.bib82); [Bocquet
et al. (2016)](#bib.bib12), not only redshift correction have to be made, but also at overdensities larger than $180\rho\_{\mathrm{mean}}$, deviations from universality should be expected. Many cosmological analyses that involve galaxy clusters use $500\rho\_{\mathrm{crit}}$ as an overdensity for the mass calculation, which enables us to easily compare our results. Furthermore, $500\rho\_{\mathrm{crit}}$ seems to be a good compromise for keeping extrapolation to a minimum and not moving to too small radii, where hydrostatic equilibrium might not hold.
We recalculate the masses and extrapolate until $200\rho\_{\mathrm{crit}}$ using the “kT extrapolate” and “NFW Freeze” methods.
For the temperature extrapolation no significant change can be detected, only that the uncertainties increase. For the “NFW Freeze” method, the uncertainties increase as well, but there is also a clear shift toward higher ($\sim 40\%$) $\Omega\_{\mathrm{m}}$. This can be explained because the NFW model with a frozen concentration parameter puts more constraints on the shape of the mass profile, which can cause larger biases the more it is extrapolated. The observed direction of the shift toward larger $\Omega\_{\mathrm{m}}$ may just be chance.

#### 4.2.4 $R\_{500}$-test

Here we focus on the systematics of the default extrapolation method, NFW Freeze. Starting from 6 clusters44
4
A85, A1644, A2029, A3667, A4059 and HydraA where the temperature profile can be measured out to more than 90% of $R\_{500}$, we recalculate the total mass by removing all temperature measurements beyond 20%, 40%, 60% and 80% of the real $R\_{500}$.
Despite the scatter among the six clusters, we find that with smaller covered regions of $R\_{500}$ also the total mass is underestimated (using the NFW Freeze method).
We parameterize the fraction of the real $M\_{500}$, $\kappa$, as a function of the measured $R\_{500}$ fraction, $\epsilon$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\kappa=1+e^{-a}-e^{-a\epsilon^{b}}~,$ |  | (10) |

where $a=9.7$ and $b=1.7$.
This means if only half of the temperature profile is measured, the mass is underestimated by 5%, while if only 30% is measured one will also find a 30% too low mass.
The scatter (standard deviation, $\Delta\kappa$) between the results of the 6 individual clusters is used as an additional uncertainty and measured to follow the relation

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta\kappa=0.31\cdot(1-\epsilon)~.$ |  | (11) |

For the default results, all our measured masses are corrected by a factor $1/\kappa$, while the $\Delta\kappa$ is added in quadrature to the relative uncertainty of the cluster mass.

### 4.3 Galaxy cluster physics

In this Section we will discuss various effects and processes that could cause the observed difference in $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$, but we do point out that the aim is not to reproduce, e.g., the CMB results, but to test several influences that enter in a purely flux limited sample.

#### 4.3.1 Galaxy groups

Figure 8: $L\_{x}-M$ relations for the low (raw + $z<0.05$) and high redshift (raw + $z\geq 0.05$) sample.

Figure 9: 68.3% and 95.4% confidence levels for the full sample (black, raw in Tab. [3](#S4.T3 "Table 3 ‣ 4.1 Difference to WMAP9 ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")), the high redshift sample (raw + $z\geq 0.05$, red) and the low redshift sample (raw + $z<0.05$, green).

The first effect to be analyzed here is the sample composition: In contrast to, e.g., [Vikhlinin
et al. (2009b)](#bib.bib87), the HIFLUGCS sample includes several galaxy groups.
In the following we consider every object with $M\_{500}<${10}^{14}\text{\,}\textit{h}^{-1}\,\mathrm{M}\_{\odot}$$ as a galaxy group, since there is not a well defined threshold to separate groups from clusters ([Sun et al., 2009](#bib.bib81)).
As shown, e.g., in [Sun et al. (2009)](#bib.bib81); [Eckmiller et al. (2011)](#bib.bib26); [Bharadwaj et al. (2014)](#bib.bib9); [Lovisari et al. (2015)](#bib.bib58) these objects have different scaling properties than galaxy clusters. One simple powerlaw to describe the $L\_{x}-M$ relation for the full sample might not be enough. First, we exclude the galaxy groups by introducing a lower redshift cut. We decided to use 0.05 as the redshift threshold; this will split the sample into two equal sized subsamples and the minimum mass of the high redshift samples is roughly ${10}^{14}\text{\,}\textit{h}^{-1}\,\mathrm{M}\_{\odot}$ (see Fig [8](#S4.F8 "Figure 8 ‣ 4.3.1 Galaxy groups ‣ 4.3 Galaxy cluster physics ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")). Already the observed $L\_{x}-M$ relations of these subsamples show a clear break with the high redshift (and high mass) sample found to be significantly flatter.
$\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ can be seen in Fig. [9](#S4.F9 "Figure 9 ‣ 4.3.1 Galaxy groups ‣ 4.3 Galaxy cluster physics ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results"): The high redshift sample gives larger values of $\Omega\_{\mathrm{m}}$, which cannot be explained by the degeneracy between the $L\_{x}-M$ slope and $\Omega\_{\mathrm{m}}$. The $\Omega\_{\mathrm{m}}-\sigma\_{8}$ constraints are in perfect agreement with [Vikhlinin
et al. (2009b)](#bib.bib87), but have larger uncertainties.

To test in more detail the effect on the mass function of galaxy groups in the sample we introduced a scaling factor $x$ for the skyfraction (by default set to $64.78\%$) for objects with a mass lower than ${10}^{14}\text{\,}\mathrm{M}\_{\odot}$ (for $h=0.71$). This should mimic a possible increase in the incompleteness of ROSAT catalogs on galaxy group scale. Implicitly this also tests if missing flux for galaxy groups can be an issue for the cosmological constraints of the HIFLUGCS sample. For example in [Lovisari et al. (2015)](#bib.bib58), a higher luminosity for low mass systems was detected than what is given in the ROSAT catalogs. The authors argue that ROSAT was not able to detect the emission out to large radii for these faint objects. In order not to have discontinuities we model this change in the skyfraction by a sigmoid function, where 99% of the final skyfraction is reached at mass of $1.7\text{\times}{10}^{14}\text{\,}\mathrm{M}\_{\odot}$.

Figure 10: 68.3% and 95.4% confidence levels for $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ assuming higher incompleteness of galaxy groups in the catalogs (black and blue), or an broken powerlaw for the $L\_{x}-M$ relation (green).

We set $x$ to 25%, 50% and 80%. For 80% and 50% we do not detect any significant change in the cosmological parameters, while for 25% of the original skyfraction there is a clear shift toward higher $\Omega\_{\mathrm{m}}$ (see Tab. [3](#S4.T3 "Table 3 ‣ 4.1 Difference to WMAP9 ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") and Fig. [10](#S4.F10 "Figure 10 ‣ 4.3.1 Galaxy groups ‣ 4.3 Galaxy cluster physics ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")), which seems to be in rough agreement with WMAP9 results. However, detecting only a quarter of the existing galaxy groups is quite unrealistic, given the high flux limit, where even low mass objects are reliably detected (e.g., [Böhringer
et al., 2001](#bib.bib14), Fig. 23).

Another approach to model the different behavior of galaxy groups is to use a broken powerlaw for the $L\_{x}-M$ relation (Tab. [3](#S4.T3 "Table 3 ‣ 4.1 Difference to WMAP9 ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")). We set the break point for the slope to ${10}^{14}\text{\,}\mathrm{M}\_{\odot}$. As expected a much shallower slope is detected for the high mass objects, which is only about 50% of the slope for the low mass objects. The result for $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ is only shifted along the degeneracy toward lower $\Omega\_{\mathrm{m}}$. But in case groups are missed in the sample due to selection effects or catalog incompleteness a broken powerlaw would just model the observed behavior and neglect these effects. The real distribution of galaxy clusters and groups in the $L\_{x}-M$ plane could look different, and unknown effects push the groups toward lower luminosities, which cause the observed steepening. So a lower $\Omega\_{\mathrm{m}}$, mostly driven by the lower number of groups that has to be matched, is the expected trend for this case.
The split into a high and low redshift sample seems to be more justified than to just treat groups differently, since the low redshift objects require more extrapolation due to their larger apparent extent. We conclude that the high redshift sample which does not contain any object $M\_{500}<${10}^{14}\text{\,}\textit{h}^{-1}\,\mathrm{M}\_{\odot}$$ is most reliable for cosmology.

#### 4.3.2 Hydrostatic bias

Several effects can lead to systematically biased cosmological results, such as instrumental calibrations, substructure, clumping, major merger events or non-thermal pressure which is not accounted in the hydrostatic equation. In [Nagai
et al. (2007)](#bib.bib67) the authors estimate that Chandra mass measurements are biased by 10% to 20% low with the respect to the “true” masses found in simulations of relaxed clusters. This can originate from subsonic turbulent gas motion ([Evrard
et al., 1996](#bib.bib33)).
With hydrodynamic simulations it is possible to derive hydrostatic equilibrium correction factors for clusters (e.g., [Nelson
et al., 2014](#bib.bib68); [Shi
et al., 2016](#bib.bib79); [Avestruz et al., 2015](#bib.bib7)), but individual clusters might deviate from this trend because of asphericity or clumping. Also the mass accretion rate (i.e. the dynamical state of the cluster) plays an important role. Typically, the unrelaxed clusters show a larger hydrostatic bias.

Observationally there have been studies finding agreement with the predictions on the hydrostatic bias, e.g., by comparing Planck SZ masses derived from XMM-Newton scaling relations with weak-lensing masses ([von der Linden
et al., 2014](#bib.bib97)). Other studies find agreement of X-ray masses (mostly from Chandra) with weak-lensing masses ([Gruen
et al., 2014](#bib.bib38); [Israel et al., 2015](#bib.bib46); [Applegate
et al., 2016](#bib.bib5); [Smith
et al., 2016](#bib.bib80)).
[Maughan et al., 2016](#bib.bib66) found that X-ray hydrostatic masses are not smaller than masses from galaxy dynamics.
In fact the situation is more complicated since the procedure of estimating a mass matters as well as the weak lensing masses can be biased. Furthermore, in earlier XMM-Newton studies ([Zhang
et al., 2008](#bib.bib90); [Zhang
et al., 2010](#bib.bib91); [Foëx
et al., 2012](#bib.bib35)) a negligible hydrostatic bias has been found as well.

Here we model the mass bias,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $(1-b)=\frac{M\_{\mathrm{hydro}}}{M\_{\mathrm{true}}}~,$ |  | (12) |

where both masses are at an overdensity $\Delta=500$. Furthermore, one can marginalize over a uniformly distributed bias, $(1-b)=[0.7,1.0]$. The shift (see Fig. [11](#S4.F11 "Figure 11 ‣ 4.3.2 Hydrostatic bias ‣ 4.3 Galaxy cluster physics ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")) is toward higher $\Omega\_{\mathrm{m}}$ and higher $\sigma\_{8}$ values. Also the uncertainties are slightly larger.

Figure 11: 68.3% and 95.4% confidence levels for various setups including a hydrostatic mass bias $(1-b)=\frac{M\_{\mathrm{hydro}}}{M\_{\mathrm{true}}}$. See text for details.

If one uses the large confidence intervals of the high redshift sample from the previous section together with the WMAP9 priors, it is possible to constrain the bias since the $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ values are determined almost entirely by WMAP9 (Fig. [11](#S4.F11 "Figure 11 ‣ 4.3.2 Hydrostatic bias ‣ 4.3 Galaxy cluster physics ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")). The result is $(1-b)=0.83^{+0.11}\_{-0.12}$, which is in agreement with simulations and shows overlap with weak lensing studies comparing their masses to Planck SZ masses, like Weighing the Giants ($1-b=0.70\pm 0.06$ ; [von der Linden
et al., 2014](#bib.bib97)) or CCCP ($1-b=0.76\pm 0.05$ with only statistical uncertainties; [Hoekstra
et al., 2015](#bib.bib43)). This is a different way of predicting a hydrostatic bias than illustrated before, where masses have been compared to reference values (weak or strong lensing), since now cosmological constraints are compared to a reference (CMB). Since many effects can bias cosmological constraints, this should not be seen as a solid determination of the bias, but as one way of interpreting the HIFLUGCS cosmology results.

Recent results from simulations by [Biffi
et al. (2016)](#bib.bib11) quantify the hydrostatic bias for various types of clusters (CC or NCC, regular and disturbed) and at several cluster radii ($\Delta=2500$, $500$, $200$). The authors find that at $\Delta=500$ the differences for $(1-b)$ between different types of clusters are not significant, so one could adopt a general bias of $(1-b)\_{\Delta=500}=$0.877(15)$$. At inner radii, differences are more significant, especially for CC clusters, in which the authors find no significant hydrostatic bias. So we use for our default procedure of the mass function analysis (at $\Delta=500$) a Gaussian distributed hydrostatic bias, $(1-b)=$0.877(15)$$, while for the gas mass fraction analysis (at $\Delta=2500$) we use $(1-b)=0.999(27)$ for CC clusters and $(1-b)=$0.877(11)$$ for NCC clusters.

#### 4.3.3 Relaxed clusters

Many studies require dynamically relaxed clusters (i.e., shape close to spherical, no substructure or major merger) to calibrate their scaling relations. This may have an influence on the cosmological result for the full sample.

Up to now we have used the pure flux cut which creates a sample of relaxed and unrelaxed objects. Unfortunately, there is no general criterion to define relaxed clusters: [Vikhlinin
et al. (2009a)](#bib.bib86) classify clusters with a second emission maximum, filamentary structure or significant centroid shifts as unrelaxed, while [Hudson et al. (2010)](#bib.bib44) call clusters with round or elliptical isophote and the emission peak in the center of all isophotes relaxed.
[Zhang
et al. (2011a)](#bib.bib92) find that clusters with a large offset between the BCG position and the X-ray emission weighted center are often disturbed.
A clearer distinction of clusters can be made via the central cooling time, which splits clusters into cool core or non cool core clusters55
5
One can also split clusters into three classes, strong-, weak-, and non-cool core clusters as demonstrated in [Hudson et al. (2010)](#bib.bib44). Although the cool core criterion seems to be more objective, there are several disturbed clusters with short cooling times (see [Hudson et al., 2010](#bib.bib44), Fig. 19).
We decide to take the disturbed-undisturbed classification from Tab. 2 in [Zhang
et al. (2011a)](#bib.bib92), which is based on the visual inspection of the X-ray flux images as also done in [Vikhlinin
et al. (2009a)](#bib.bib86). Disturbed clusters are: A0119, A0399, A0400, A0754, A1367, A1644, A1656, A1736, A2065, A2147, A2163, A2255, A2256, A3266, A3376, A3395, A3526, A3558, A3667, MKW8, NGC507. Note that the study by [Zhang
et al. (2011a)](#bib.bib92) misses 2A0355 and RXCJ1504, but both of them are strong cool core clusters ([Hudson et al., 2010](#bib.bib44)), so we assume that they are relaxed as well.

Figure 12: 68.3% and 95.4% confidence levels for various setups to demonstrate the effect of dynamically disturbed clusters (raw + undisturbed in Tab. [3](#S4.T3 "Table 3 ‣ 4.1 Difference to WMAP9 ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")).

With unconstrained masses for the unrelaxed clusters (Fig. [12](#S4.F12 "Figure 12 ‣ 4.3.3 Relaxed clusters ‣ 4.3 Galaxy cluster physics ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")) (i.e. very large errorbars mean that these clusters have small weightings and the mass is constrained mainly by the $L\_{x}-M$ relation which itself is determined by the remaining, relaxed clusters) the constraints of $\Omega\_{\mathrm{m}}$ are shifted toward larger values along the degeneracy with $\sigma\_{8}$.
Adding a hydrostatic bias on this shifts the contours toward higher $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ (as shown in the previous section), which will exhibit broad overlap with WMAP9. So we put a uniform prior on the hydrostatic bias and added WMAP9 priors on the two variable cosmological parameters. The resulting bias (Fig. [12](#S4.F12 "Figure 12 ‣ 4.3.3 Relaxed clusters ‣ 4.3 Galaxy cluster physics ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")) is $(1-b)=0.66^{+0.10}\_{-0.12}$, which slightly overlaps with the 68.3% uncertainties of the bias constraints from the high redshift subsample combined with WMAP9.

### 4.4 Independent mass estimates

In Paper I, we compared our hydrostatic masses to the available Planck SZ masses as well as to the dynamical masses from optical velocity dispersions using the caustic method to select member galaxies.
We show now briefly a comparison of the cosmological parameters using these alternative masses for (part of) the HIFLUGCS clusters.

Figure [13](#S4.F13 "Figure 13 ‣ 4.4 Independent mass estimates ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") shows that for the Planck SZ masses of HIFLUGCS, there exists an overlap for $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ with the high redshift subsample of the raw analysis procedure, as expected since 12 low redshift clusters are already excluded. The $L\_{x}-M$ relation constrained from the Planck masses (using the same luminosities) deviates strongly from the default or high redshift sample: The slope and normalization are about 30% larger than the high redshift subsample constraints. A higher normalization of the $L\_{x}-M$ relation could be due to a systematic bias that lowers all Planck masses. Following the degeneracy between slope and normalization, the slope has to increase as well. The Chandra$-$XMM-Newton cross calibration could contribute to this effect, but it is unlikely that it is fully attributable to calibration uncertainties, which would not cause such a strong deviation. In Paper I we discuss the differences between our hydrostatic and Planck masses in more detail.

Figure 13: 68.3% and 95.4% confidence levels for the analysis of the Planck SZ masses of HIFLUGCS (green), compared to the raw analysis procedure (black) and the high redshift subsample (raw + $z>0.05$, red).

We use the mass estimates by [Zhang
et al. (2017)](#bib.bib94) based on the velocity dispersion of the HIFLUGCS sample from [Zhang
et al. (2011a)](#bib.bib92) with some updates.

Figure 14: 68.3% and 95.4% confidence levels for the analysis of the dynamic masses of HIFLUGCS (green; [Zhang
et al., 2017](#bib.bib94)), compared to the raw analysis procedure (black) and the raw setup plus a fixed hydrostatic bias of $(1-b)=0.8$ (red).

The two missing clusters (2A0355 and RXCJ1504) have very large uncertainties so their mass is determined by the $L\_{x}-M$ relation. The direct comparison to the (raw) hydrostatic masses in Paper I shows that despite the scatter the dynamic and hydrostatic masses are in good agreement, so it is no surprise the cosmological results are also matching (Fig. [14](#S4.F14 "Figure 14 ‣ 4.4 Independent mass estimates ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")). As indicated in Fig. [14](#S4.F14 "Figure 14 ‣ 4.4 Independent mass estimates ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") adding a hydrostatic bias $(1-b)=0.8$ to the default masses gives even better agreement with the dynamic mass cosmology. This independent mass estimator shows that the hydrostatic masses derived here are robust: First, there is no mass dependency between the Chandra derived hydrostatic masses and the dynamic mass estimates, which can give a hint that the Chandra instrumental calibration is reliable. Second, the offset of the mass-mass comparison (see Paper I) is consistent with zero ($-0.02\pm 0.04$), which also makes the existence of a large amount of unaccounted non-thermal pressure less likely.

### 4.5 Influence of cosmic variance

The number of galaxy clusters within a certain volume emerges from the fluctuations of the large-scale matter density distribution.
Especially within small volumes the statistical fluctuations related to the sample size dominate over other sources of uncertainty.
For HIFLUGCS, the most nearby galaxy clusters populate a relatively small volume and their number density could be highly biased in either direction. At the same time, these nearby objects are also low mass galaxy groups, and make an important contribution to the halo mass function. To test the influence of cosmic variance on our cosmological results, we exclude the 13 objects within $100\text{\,}\mathrm{M}\mathrm{p}\mathrm{c}$. If our local Universe was biased in either direction, one should be able to see a significant shift of the cosmological parameters. Figure [15](#S4.F15 "Figure 15 ‣ 4.5 Influence of cosmic variance ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") shows that no influence of the 13 closest objects can be detected, so unless the Universe is inhomogeneous on larger scales than expected, we conclude that cosmic variance has a negligible influence on our results.

Figure 15: Influence of cosmic variance on the $\Omega\_{\mathrm{M}}$ - $\sigma\_{8}$ determination. The red confidence intervals excludes the 13 clusters within $100\text{\,}\mathrm{M}\mathrm{p}\mathrm{c}$.

### 4.6 Reference model validity

In this final part of the discussion on the HIFLUGCS cosmology results of the mass function analysis we focus on the mass function itself. For the construction of the [Tinker
et al. (2008)](#bib.bib82) halo mass function Dark Matter simulations without baryons were used. We point out that the following tests are used to demonstrate the impact of these components, but not to put any constraints on them. This is not easily possible with galaxy clusters alone, especially not with a local sample.

#### 4.6.1 Impact of baryons

The clear difference between baryonic matter and Dark Matter is the fact that Dark Matter only interacts gravitationally. Dark Matter is seen as collisionless and so does not have pressure. Obviously the Universe consists of baryonic matter, but due to its interaction simplicity and the much higher energy density in the Universe, simulations in the past were often performed using Dark Matter particles and neglecting baryons.

Up to now we only included the properties of the baryonic matter in the matter power spectrum (or matter transfer function): The interaction of the baryons and the tightly coupled photons in the early Universe led to oscillations (Baryonic acoustic oscillations, e.g., [Eisenstein, 2005](#bib.bib27)). These are imprinted on the matter power spectrum, since baryons change the total gravitational potential. Apart from the oscillations a damping can also be observed due to photons smoothing out the small scale temperature fluctuations at the epoch of recombination. More details are given in [Eisenstein &
Hu (1998)](#bib.bib28); [Eisenstein (2005)](#bib.bib27). The effect of baryons on the transfer function is fully accounted for by the CLASS software.

For the mass function the situation is the following: By adiabatic contraction baryons force a larger halo concentration, which leads to a uniform shift of halo masses toward larger values (e.g., [Cui et al., 2012](#bib.bib22)). Furthermore, baryons cause several physical effects that are accounted in current hydrodynamic simulations ([Cui
et al., 2014](#bib.bib23); [Bocquet
et al., 2016](#bib.bib12)), such as gas heating, radiative cooling, star formation and feedback processes from active galactic nuclei (AGN) and galactic winds driven by supernovae. It was found that the impact of baryons is much larger in the inner regions (e.g., $r\_{2500}$) and almost negligible at the virial radius. Cooling and star formation lead to a slightly larger halo density (i.e. increase of the mass function with respect to Dark Matter only derived mass functions), while adding AGN feedback on top can result in a suppression of the mass function ([Cui
et al., 2014](#bib.bib23)).
This has also been shown with a different type of simulations (AMR instead of SPH) by [Martizzi et al. (2014)](#bib.bib64), where the authors demonstrate that the effect of baryons on cosmological parameters is on a percent level.

Here we adopt the mass function from [Bocquet
et al. (2016)](#bib.bib12), which includes stellar evolution, chemical enrichment, star formation and feedback processes (AGN and SNe). The simulations are based on three different box sizes of the Magneticum simulation with an input cosmology $\Omega\_{\mathrm{m}}=0.272,\Omega\_{\mathrm{b}}=0.0456,\sigma\_{8}=0.809$ and $h=0.704$.
[Bocquet
et al. (2016)](#bib.bib12) predict for $z<0.3$ that the mass function from hydrodynamic simulations (including the baryonic effects, HydroMF in the following) will be smaller than [Tinker
et al. (2008)](#bib.bib82) at all masses, while the difference seems to be minimal around ${10}^{15}\text{\,}\mathrm{M}\_{\odot}$. Naively that would mean that the HydroMF gives larger $\Omega\_{\mathrm{m}}$ than [Tinker
et al. (2008)](#bib.bib82). Of course the impact will depend on the individual sample selection. For example, for an eROSITA like sample (X-ray flux selected) the [Tinker
et al. (2008)](#bib.bib82) mass function would predict lower $\Omega\_{\mathrm{m}}$ and smaller $\sigma\_{8}$. Note that the input cosmology for these tests in [Bocquet
et al. (2016)](#bib.bib12) was close to the cosmology used in the simulations.

Figure 16: 68.3% and 95.4% constraints on $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ from the mass functions by [Bocquet
et al. (2016)](#bib.bib12). Green ellipses are from hydrodynamical simulations, while the red ellipses are Dark Matter only simulations. The [Tinker
et al. (2008)](#bib.bib82) constraints (“raw”) are shown in black.

Applying the [Bocquet
et al. (2016)](#bib.bib12) mass function to HIFLUGCS (raw) results in a different trend (see Fig. [16](#S4.F16 "Figure 16 ‣ 4.6.1 Impact of baryons ‣ 4.6 Reference model validity ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")): We detect no change in $\Omega\_{\mathrm{m}}$ and a lower $\sigma\_{8}$ when using the HydroMF, which is not expected. The Dark Matter only mass function from [Bocquet
et al. (2016)](#bib.bib12) shows good agreement with the HydroMF, which is also not expected. The uncertainties of the HydroMF are larger, mostly because the covariance matrix enters and puts uncertainties on the parameters, which was not done for the Dark Matter only mass function of [Tinker
et al. (2008)](#bib.bib82) and [Bocquet
et al. (2016)](#bib.bib12). Directly comparing the HydroMF mass function against [Tinker
et al. (2008)](#bib.bib82) reveals that for $\Omega\_{\mathrm{m}}\approx 0.17$ the situation is the reverse of that described in [Bocquet
et al. (2016)](#bib.bib12): [Tinker
et al. (2008)](#bib.bib82) gives a lower halo density than HydroMF for high masses and shows agreement for low masses, which is locally equivalent to a change in $\sigma\_{8}$ as observed. One reason could be that one (or both) mass functions compared here are not universal at $\Delta\_{\mathrm{500c}}$. As indicated already in [Bocquet
et al. (2016)](#bib.bib12) the best universality is given at an overdensity of $\Delta\_{\mathrm{200m}}$. It seems that for HIFLUGCS the effects of baryons in the mass function is negligible (if HydroMF is correct), especially if one compares the tiny difference between the Dark Matter only (orange) and HydroMF (green) constraints of the [Bocquet
et al. (2016)](#bib.bib12) mass functions in Fig. [16](#S4.F16 "Figure 16 ‣ 4.6.1 Impact of baryons ‣ 4.6 Reference model validity ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results"). The differences between different Dark Matter only simulations on the other hand can be significant, as in the described case there is only small overlap of the 68.3% confidence regions.

#### 4.6.2 Neutrinos

In the standard model of particle physics neutrinos are considered as massless particles without charge, although several studies have concluded that they have a non-zero mass (e.g., [Kamionkowski
& Kosowsky, 1999](#bib.bib47); [Hirsch &
Valle, 2004](#bib.bib42); [Fogli et al., 2012](#bib.bib36); [Burenin, 2013](#bib.bib16)).
A massive neutrino will have an effect on the large scale structure that can be seen in the matter power spectrum (e.g., [Lesgourgues &
Pastor, 2006](#bib.bib54); [Lesgourgues &
Pastor, 2012](#bib.bib55); [Lesgourgues &
Pastor, 2014](#bib.bib56)): On sub-free-streaming-scales neutrinos will smooth the density field, which makes the gravitational potential shallower and slows down structure growth ([Agarwal &
Feldman, 2011](#bib.bib2)).
The distribution of masses among the neutrino species is uncertain, but the sum of the masses of the three species, $\sum m\_{\nu}$, is important for our analysis.

The neutrino mass enters in the calculation of the matter power spectrum and it is taken into account by CLASS ([Lesgourgues, 2011a](#bib.bib52); [Lesgourgues, 2011b](#bib.bib53); [Lesgourgues &
Tram, 2011](#bib.bib57)).
Massive neutrinos are no longer in the relativistic regime, but can be described by a Fermi-Dirac distribution. The mass can be translated into an energy density,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Omega\_{\nu}=\frac{\sum m\_{\nu}}{$93.14\text{\,}\mathrm{e}\mathrm{V}$\,h^{2}}~,$ |  | (13) |

which is taken into account when calculating the total matter density.
The oscillation experiments now determine three neutrino mass states, and each mass corresponds to a superposition of the three different neutrino flavors. Theory predicts two different scenarios for the distribution of mass states: The normal and inverse hierarchy (see also [Cahn
et al., 2013](#bib.bib19)), with each having different implications on the standard model of particle physics. However, for cosmological applications, the sum of neutrino masses is important.

The results for the REFLEX2 galaxy cluster sample ([Böhringer &
Chon, 2015](#bib.bib13)) suggest a smaller $\sigma\_{8}$ and larger $\Omega\_{\mathrm{m}}$, when increasing the neutrino mass. This is in good agreement with what is obtained for HIFLUGCS (see Fig. [17](#S4.F17 "Figure 17 ‣ 4.6.2 Neutrinos ‣ 4.6 Reference model validity ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")).

Figure 17: 68.3% and 95.4% constraints on $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$ for an increased (summed) mass of neutrinos (raw: $\sum m\_{\nu}=$0.06\text{\,}\mathrm{e}\mathrm{V}$$).

The cases shown here ($\sum m\_{\nu}$ up to $1\text{\,}\mathrm{e}\mathrm{V}$) are unrealistically high.
Current upper limits are found by [Planck
Collaboration et al. (2016a)](#bib.bib70) ($0.17\text{\,}\mathrm{e}\mathrm{V}$), and by [Vagnozzi et al. (2017)](#bib.bib83) ($0.12\text{\,}\mathrm{e}\mathrm{V}$), both at 95% confidence level,
but our examples are shown here to demonstrate the mass at which the effect would be significant.

The constraints on the $L\_{x}-M$ relation are unchanged for any high neutrino mass tested here. The effect in the $\Omega\_{\mathrm{m}}$-$\sigma\_{8}$ plane is perpendicular to the hydrostatic bias,
which makes it possible to approach the WMAP9 results by
adding a sufficiently high bias and neutrino mass, which both would be unphysical. As stated before, it is not our aim to reproduce CMB results.

### 4.7 Gas mass measurements

The results of the $f\_{\mathrm{gas}}$ test (Section [2.3](#S2.SS3 "2.3 Gas mass fraction as cosmological probe ‣ 2 Cosmological analysis ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")) alone can only constrain $\Omega\_{\mathrm{m}}$, but not $\sigma\_{8}$. The derived constraints on $\Omega\_{\mathrm{m}}$ of the $z>0.05$-sample can be added as a prior on the halo mass function analysis. As shown in Fig. [1](#S3.F1 "Figure 1 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") this additional information eliminates the degeneracy between $\Omega\_{\mathrm{m}}$ and $\sigma\_{8}$.
For the setup including the $f\_{\mathrm{gas}}$ priors one cannot detect any significant difference of the $L\_{x}-M$ relation compared to the MF-only setup.
The slightly different $\Omega\_{\mathrm{m}}$ constraints of these two analysis procedures (halo mass function and $f\_{\mathrm{gas}}$ test) of the same sample can probably be explained by the sensitivities of the test: $f\_{\mathrm{gas}}$ is compared to hydrodynamic simulations with many degrees of freedom in the fit.
In particular, the mass dependence modeled by $\beta\_{\mathrm{gas}}$ in Eq. [5](#S2.E5 "In 2.3 Gas mass fraction as cosmological probe ‣ 2 Cosmological analysis ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") gives flexibility to account for the different behavior of galaxy groups. The values of $\beta\_{\mathrm{gas}}$ in Table [1](#S3.T1 "Table 1 ‣ 3 Results ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") and Fig. [18](#S4.F18 "Figure 18 ‣ 4.7 Gas mass measurements ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") show that simulations do not reproduce the observed properties of galaxy groups well (high values of $\beta\_{\mathrm{gas}}$), but since this parameter is free, the fit is able to account for the observed lower gas mass fractions in groups (which is also supported by other studies).
As found by [Vikhlinin
et al. (2006)](#bib.bib85); [Arnaud et al. (2007)](#bib.bib6); [Sun et al. (2009)](#bib.bib81) (gray), [Sun et al. (2009)](#bib.bib81); [Zhang et al. (2011b)](#bib.bib93) (yellow), [Lovisari et al. (2015)](#bib.bib58) (red), [Ettori (2015)](#bib.bib31) (black) or [Laganá
et al. (2013)](#bib.bib50) (blue), all shown in Fig. [18](#S4.F18 "Figure 18 ‣ 4.7 Gas mass measurements ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results"), the mass dependence of the gas depletion factor is typically around 0.15 to 0.25, but depends on the sample composition. In our sample there are several low mass galaxy groups. Especially the lowest mass system, NGC4636, seems to introduce a large bias for $\beta\_{\mathrm{gas}}$: If one excludes only this group from the $f\_{\mathrm{gas}}$ analysis, the value of $\beta\_{\mathrm{gas}}$ is reduced by almost 50% (Fig. [18](#S4.F18 "Figure 18 ‣ 4.7 Gas mass measurements ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")), making it consistent with the other studies mentioned before. Note that the colorbars in Fig. [18](#S4.F18 "Figure 18 ‣ 4.7 Gas mass measurements ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") should not refer to a specific value or range of $\Omega\_{\mathrm{m}}$, but are just placed in the figure for comparison reasons.
Since neither the simulations, nor other studies have included galaxy groups with this low mass in their studies, the high value of $\beta\_{\mathrm{gas}}$ could be real.
But conclusions based on just one single object are not justified.

Figure 18: 68.3% and 95.4% confidence levels of the $f\_{\mathrm{gas}}$ tests for $\Omega\_{\mathrm{m}}$ and $\beta\_{\mathrm{gas}}$, the mass dependence of the gas depletion factor, for the HIFLUGCS sample, calculated at $r\_{2500}$. See text for details.

## 5 Conclusion

We present a cosmological analysis using a complete, X-ray selected, purely flux limited sample of 64 local galaxy clusters and calibrate the $L\_{x}-M$ scaling relation (Eq. [2](#S2.E2 "In 2.2 The likelihood estimate for the halo mass function ‣ 2 Cosmological analysis ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")), for whose parameters we find $A\_{\mathrm{LM}}=$0.67(7)$$ and $B\_{\mathrm{LM}}=1.34^{+0.13}\_{-0.12}$.
Masses of the galaxy clusters have been calculated individually for each cluster from the temperature and surface brightness profiles. A crucial step was to perform the extrapolation of the mass, since the Chandra FOV and, for some clusters, the limited exposure time, does not allow us to measure the temperature and its gradient at $R\_{500}$. Several methods are applied to perform the extrapolation, either simply by using models for the temperature profiles, which can produce (unphysical) decreasing total mass profiles in the outer regions, or by using an NFW model (see Paper I, for more details). The NFW fit with a concentration parameter linked to the total mass was used as the default. Additionally we noticed with the $R\_{500}$-test (using a subsample of clusters whose temperature profile reaches $R\_{500}$) that cluster masses are underestimated depending on the extrapolation to reach $R\_{500}$. Although for most clusters this is a small effect, we took this into account.

We performed several tests to measure the robustness of these constraints: Simple tests like excluding some extreme clusters (fluxes which are just at the flux limit, large deviations from the $L\_{x}-M$ relation), did not show a significant effect.
We also confirmed past results indicating that the Chandra/XMM-Newton cross calibration has no significant effect on the cosmological parameters for the HIFLUGCS sample.
Systematic modifications of the sample selection function, like a redshift cut, revealed an interesting trend: The high redshift subsample shows larger uncertainties, as expected, but is also in better agreement with CMB measurements. The low redshift subsample, containing all the groups of the full sample, exhibits a much steeper $L\_{x}-M$ relation and even lower $\Omega\_{\mathrm{m}}$ values. Since some effects, like the influence of galaxy groups, seems to be important, this was evaluated in more detail:

* •

  Galaxy groups: The parent sample may have a higher incompleteness and/or missing flux fraction at the galaxy group scale. This could be corrected either by reanalyzing the RASS data with a source detection algorithm adapted to special group properties (e.g., lower surface brightness or flatter surface brightness profiles), or by quantifying their influence, i.e., assuming a higher incompleteness for groups (see Section [4.3.1](#S4.SS3.SSS1 "4.3.1 Galaxy groups ‣ 4.3 Galaxy cluster physics ‣ 4 Discussion ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results")). The latter test revealed that for our sample $\Omega\_{\mathrm{m}}$ might be biased low by about $0.03$ in the raw analysis. Furthermore, the astrophysical processes in galaxy groups might be different, which results in a steep $L\_{x}-M$ relation for low mass objects and the powerlaw might not be a good parametrization. This can only be better described with large, complete samples of galaxy groups, where statistical uncertainties are small and selection effects can be corrected for.
* •

  Hydrostatic mass bias: Simulations and comparisons of the X-ray and weak lensing masses of galaxy clusters point to the existence of a hydrostatic mass bias. Using alternative cluster masses (e.g., dynamical masses from velocity dispersion) we find very good agreement if we assume a bias of $(1-b)=0.8$ for the X-ray masses. Dynamically disturbed clusters, which often violate (to some extent) hydrostatic equilibrium, can bias results, since the exclusion of this subsample leads to higher values of $\Omega\_{\mathrm{m}}$ and lower values of $\sigma\_{8}$. But assuming that reference cosmological results (e.g., WMAP9) are correct, one can obtain an indirect mass calibration when leaving the hydrostatic bias free to vary. For our default analysis we rely on the very recent simulation results by [Biffi
  et al. (2016)](#bib.bib11).
* •

  Extrapolation: For many of our clusters an extrapolation is needed to constrain the total mass at $R\_{500}$. The only way to avoid this is to gather many expensive observations at large cluster radii. For our analysis, we correct our NFW extrapolation model with a few clusters having temperature measurements to large radii. Although for most clusters this correction is small, we find a systematic shift of $\Omega\_{\mathrm{m}}$ by $0.01$ due to this correction.
* •

  Theoretical mass function: Comparing two different halo mass functions based on N-body simulations results only in a small shift of $\sigma\_{8}$ by $\sim 0.03$.
  Baryonic effects (e.g., feedback processes) are expected to play a significant role for low mass systems. Using a mass function which incorporates these effects shows no changes: Compared to a consistently derived Dark Matter only mass function, the change is completely insignificant.
* •

  Other physical/cosmological effects: Several physical and/or cosmological effects could help (e.g., here we show explicitly the effects of neutrinos with masses $\gg$0.06\text{\,}\mathrm{e}\mathrm{V}$$), but the other effects above need to be controlled better before robust conclusions can be drawn.

In sum, the effect of galaxy groups and/or disturbed objects (in the raw analysis) in HIFLUGCS seems to bias results toward lower $\Omega\_{\mathrm{m}}$.
Due to large uncertainties in the results from subsamples, the changes are often insignificant.
The $f\_{\mathrm{gas}}$ test also shows that galaxy groups need to be treated more carefully.
Simulations are not able to recover the values of $f\_{\mathrm{gas}}$ for low mass system, raising the suspicion that halo mass function simulations may also not reproduce the number density of those systems well.

The final cosmological results with purely statistical (68%) uncertainties from the halo mass function ([Tinker
et al., 2008](#bib.bib82)) give $\Omega\_{\mathrm{m}}=0.22^{+0.07}\_{-0.05}$ and $\sigma\_{8}=$0.89(10)$$, and after adding the prior from the gas mass fraction analysis we get our default results: $\Omega\_{\mathrm{m}}=$0.30(1)$$ and $\sigma\_{8}=$0.79(3)$$.
These include corrections and modifications based on the tests presented in the discussion: The effects of galaxy groups and the uncertainties of cosmic variance in the very nearby Universe (leading to a lower redshift cut of $z>0.05$), and the corrections for the mass extrapolation and hydrostatic mass biases.

Including these results for systematics in a broader framework, e.g., by increasing the sample size (eHIFLUGCS), will enable us to estimate more detailed cosmological parameters (the Dark Energy density, $\Omega\_{\mathrm{DE}}$, and its equation of state).

## Acknowledgements

The authors would like to thank the anonymous referee for constructive feedback, and Ewan O’Sullivan for providing helpful comments. GS, THR acknowledge support by the German Research Association (DFG) through grant RE 1462/6. GS acknowledges support by the Bonn-Cologne Graduate School of Physics and Astronomy (BCGS) and the International Max Planck Research School (IMPRS) for Astronomy and Astrophysics at the Universities of Bonn and Cologne. THR acknowledges support by the DFG through Heisenberg grant RE 1462/5 and the Transregio 33 “The Dark Universe” sub-project B18.
This research made use of Astropy, a community-developed core Python package for Astronomy.

## Appendix A Likelihood function

In order to get rid of biases arising from binning the clusters in mass, flux, luminosity and/or redshift, one can do the transition to make these volume bins as small as possible, as done, e.g., by [Mantz et al. (2008)](#bib.bib60); [Vikhlinin
et al. (2009a)](#bib.bib86). A corresponding likelihood function would then comprise a simple source counting within a Bayesian regression model:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{L}(\hat{M},\hat{L},N\_{\mathrm{det}})=\underbrace{\frac{\langle N\rangle^{N}\,e^{-\langle N\rangle}}{N!}}\_{\mathrm{Poisson}}\cdot\underbrace{\frac{N!}{N\_{\mathrm{det}}!\,N\_{\mathrm{mis}}!}\,p^{N\_{\mathrm{det}}}\,\left(1-p\right)^{N\_{\mathrm{mis}}}}\_{\mathrm{Binomial}}\cdot\underbrace{\prod\limits\_{i=1}^{N\_{\mathrm{det}}}\tilde{P\_{i}}}\_{\mathrm{observational\,probability}}~.$ |  | (14) |

The hat, $\hat{x}$, on parameters marks observed quantities.
The first part is the Poisson likelihood for predicting $\langle N\rangle$ clusters with the halo mass function (without selection) while having $N$ clusters in the Universe. The second term is a Binomial likelihood for detecting $N\_{\mathrm{det}}$ clusters using the selection function out of the $N$ clusters and missing $N\_{\mathrm{mis}}=N-N\_{\mathrm{det}}$ clusters in the sample. $p$ is the probability for all the detected sources to be detected within the current constraints on the cosmology, scaling relation and selection function, while $(1-p)$ is the probability to miss $N\_{\mathrm{mis}}$ sources.
The last term is the probability for observing each individual cluster with its properties like mass and luminosity, so $\tilde{P}\_{i}$ depends on the $\hat{M}$, $\hat{L}$, the parameters of the scaling relation and the selection criteria.
Following the derivations in [Mantz et al. (2010)](#bib.bib61), one can rewrite the parameters in the following:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\langle N\rangle=\int\mathrm{d}z\,\frac{\mathrm{d}V}{\mathrm{d}z}\cdot\int\mathrm{d}M\,\Omega\_{\mathrm{frac}}(z,M)\cdot\frac{\mathrm{d}n}{\mathrm{d}M}~,$ |  | (15) |

where $\langle N\rangle$, as mentioned before, is the total number of predicted clusters and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\langle N\_{\mathrm{det}}\rangle=\int\mathrm{d}z\,\frac{\mathrm{d}V}{\mathrm{d}z}\int\mathrm{d}M\,\Omega\_{\mathrm{frac}}(z,M)\cdot\frac{\mathrm{d}n}{\mathrm{d}M}\int\mathrm{d}L\,\int\mathrm{d}\hat{L}\cdot\mathcal{N}(L,\hat{L},\sigma\_{\hat{L}})\cdot\mathcal{N}(L,L\_{\mathrm{LM}},\sigma\_{\mathrm{LM}})\cdot P\_{I}~,$ |  | (16) |

is the number of predicted clusters accounting for the selection function, where $\frac{\mathrm{d}V}{\mathrm{d}z}$ is the comoving volume element at redshift $z$, $\Omega\_{\mathrm{frac}}(z,M)$ is the covered sky fraction (which is assumed to be constant for HIFLUGCS, but will be tested to depend on redshift or mass) and $\frac{\mathrm{d}n}{\mathrm{d}M}$ is the halo mass function (halo number density per mass, e.g., by [Tinker
et al., 2008](#bib.bib82)). The fact that the sky fraction can depend on parameters like redshift or mass is a way to include a more complicated selection function without changing the luminosity integrals.
$L$ and $\hat{L}$ are “real” and observed luminosities, respectively. $\sigma\_{\hat{L}}$ is the uncertainty (model) of the measured luminosities, which could in principle depend on flux or solid angle.
$L\_{\mathrm{LM}}$ is the luminosity coming from the $L-M$ relation and $\sigma\_{\mathrm{LM}}$ is the scatter of the mass-luminosity function that is being used, which can also be variable during the cosmological fit.
$P\_{I}$ is the selection function and in the most simple case considered here it can be identified with a heavyside step function (1 for clusters above the flux limit and 0 below), so here it will just depend on $\hat{L}$ and $z$.
$\mathcal{N}(x,y,z)$ denotes the normal distribution probability density function at $x-y$ and with a standard deviation $z$.
The probability function $p$ in Eq. [14](#A1.E14 "In Appendix A Likelihood function ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") can be identified by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $p=\frac{\langle N\_{\mathrm{det}}\rangle}{\langle N\rangle}~,$ |  | (17) |

where $P\_{i,\,\mathrm{det}}$ is the probability to detect a cluster with certain observed quantities ($\hat{M},\hat{L},\hat{z},$…),

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\tilde{P}\_{i}=\frac{1}{\langle N\_{\mathrm{det}}\rangle}\int\mathrm{d}z\,\delta(\hat{z}\_{i})\cdot\frac{\mathrm{d}V}{\mathrm{d}z}\int\mathrm{d}M\,\Omega\_{\mathrm{frac}}(z,M)\cdot\frac{\mathrm{d}n}{\mathrm{d}M}\int\mathrm{d}L\,\mathcal{N}(L,\hat{L}\_{i},\sigma\_{\hat{L}\_{i}})\cdot\mathcal{N}(M,\hat{M}\_{i},\sigma\_{\hat{M}\_{i}})\cdot\mathcal{N}(L,L\_{\mathrm{LM}},\sigma\_{\mathrm{LM}})\cdot P\_{I}~,$ |  | (18) |

where the redshift is assumed to be perfectly known (modeled by a delta function). $\hat{M}\_{i}$ and $\sigma\_{\hat{M}\_{i}}$ are the measured total mass and its standard deviation, respectively.
The probability for the missed sources is simply

|  |  |  |  |
| --- | --- | --- | --- |
|  | $(1-p)=\frac{\langle N\_{\mathrm{mis}}\rangle}{\langle N\rangle}~.$ |  | (19) |

Putting all these derivations together one simplifies Eq. [14](#A1.E14 "In Appendix A Likelihood function ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results") to,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{L}=\underbrace{\frac{\langle N\rangle^{N}}{\langle N\rangle^{N\_{\mathrm{det}}}\langle N\rangle^{N\_{\mathrm{mis}}}}}\_{\mathrm{1}}\underbrace{\frac{1}{N\_{\mathrm{det}}!}}\_{\mathrm{constant}}\underbrace{\frac{\langle N\_{\mathrm{mis}}\rangle^{N\_{\mathrm{mis}}}\,e^{-\langle N\_{\mathrm{mis}}\rangle}}{N\_{\mathrm{mis}}!}}\_{\mathrm{for}\,N\_{\mathrm{mis}}\in[0,\infty]=1}\cdot e^{-\langle N\_{\mathrm{det}}\rangle}\prod\limits\_{i=1}^{N\_{\mathrm{det}}}\langle N\_{\mathrm{det}}\rangle\cdot\tilde{P\_{i}}~.$ |  | (20) |

The third term is a Poisson likelihood which is equal to unity when marginalizing over $N\_{\mathrm{mis}}$ from 0 to $\infty$.
As indicated, only the last term depends on model parameters which gives the likelihood as in [Mantz et al. (2010)](#bib.bib61); [Mantz
et al. (2015)](#bib.bib63),

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathcal{L}\propto e^{-\langle N\_{\mathrm{det}}\rangle}\prod\limits\_{i=1}^{N\_{\mathrm{det}}}\langle N\_{\mathrm{det}}\rangle\cdot\tilde{P}\_{i}~.$ |  | (21) |

## Appendix B Gas mass fraction

| Cluster | $f\_{\mathrm{gas,2500}}$ | $\Delta f\_{\mathrm{gas,2500}}$ |
| --- | --- | --- |
| 2A0335 | 0.107 | 0.002 |
| A0085 | 0.087 | 0.001 |
| A0119 | 0.068 | 0.005 |
| A0133 | 0.078 | 0.005 |
| A0262 | 0.065 | 0.001 |
| A0399 | 0.126 | 0.004 |
| A0400 | 0.051 | 0.003 |
| A0401 | 0.107 | 0.002 |
| A0478 | 0.092 | 0.007 |
| A0496 | 0.076 | 0.003 |
| A0576 | 0.059 | 0.005 |
| A0754 | 0.027 | 0.003 |
| A1060 | 0.046 | 0.002 |
| A1367 | 0.063 | 0.003 |
| A1644 | 0.078 | 0.003 |
| A1650 | 0.076 | 0.001 |
| A1651 | 0.093 | 0.004 |
| A1656 | 0.085 | 0.002 |
| A1736 | 0.093 | 0.005 |
| A1795 | 0.088 | 0.002 |
| A2029 | 0.095 | 0.002 |
| A2052 | 0.111 | 0.001 |
| A2063 | 0.065 | 0.003 |
| A2065 | 0.087 | 0.002 |
| A2142 | 0.080 | 0.004 |
| A2147 | 0.104 | 0.008 |
| A2163 | 0.133 | 0.004 |
| A2199 | 0.075 | 0.001 |
| A2204 | 0.090 | 0.004 |
| A2244 | 0.095 | 0.002 |
| A2255 | 0.085 | 0.004 |
| A2256 | 0.093 | 0.001 |
| A2589 | 0.065 | 0.002 |
| A2597 | 0.097 | 0.001 |
| A2634 | 0.045 | 0.002 |
| A2657 | 0.077 | 0.005 |
| A3112 | 0.070 | 0.004 |
| A3158 | 0.093 | 0.002 |
| A3266 | 0.087 | 0.007 |
| A3376 | 0.046 | 0.002 |
| A3391 | 0.066 | 0.004 |
| A3395 | 0.055 | 0.002 |
| A3526 | 0.067 | 0.001 |
| A3558 | 0.069 | 0.004 |
| A3562 | 0.066 | 0.004 |
| A3571 | 0.079 | 0.002 |
| A3581 | 0.058 | 0.003 |
| A3667 | 0.094 | 0.002 |
| A4038 | 0.077 | 0.006 |
| A4059 | 0.068 | 0.001 |
| EXO0422 | 0.075 | 0.004 |
| HydraA | 0.075 | 0.003 |
| IIIZw54 | 0.078 | 0.002 |
| MKW3S | 0.071 | 0.001 |
| MKW4 | 0.044 | 0.001 |
| MKW8 | 0.048 | 0.003 |
| NGC1399 | 0.041 | 0.001 |
| NGC1550 | 0.052 | 0.001 |
| NGC4636 | 0.020 | 0.000 |
| NGC5044 | 0.043 | 0.000 |
| NGC507 | 0.044 | 0.002 |
| RXCJ1504 | 0.109 | 0.008 |
| S1101 | 0.077 | 0.002 |
| ZwCl1215 | 0.081 | 0.004 |

Table 4: Gas mass fraction values for the clusters at $R=\Delta\_{2500}$, as used in Section [2.3](#S2.SS3 "2.3 Gas mass fraction as cosmological probe ‣ 2 Cosmological analysis ‣ HICOSMO - Cosmology with a complete sample of galaxy clusters. II. Cosmological results").
