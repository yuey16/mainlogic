<!-- fulltext source=arxiv_html slug=arXiv-1603.06522 fetched=2026-09-18T01:02:13+00:00 -->

# Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ SurveyNote: Submitted to the Astrophysical Journal

T. de Haan,
B. A. Benson,
L. E. Bleem,
S. W. Allen,
D. E. Applegate,
M. L. N. Ashby,
M. Bautz,
M. Bayliss,
S. Bocquet,
M. Brodwin,
J. E. Carlstrom,
C. L. Chang,
I. Chiu,
H-M. Cho,
A. Clocchiatti,
T. M. Crawford
A. T. Crites,
S. Desai,
J. P. Dietrich,
M. A. Dobbs,
A. N. Doucouliagos,
R. J. Foley,
W. R. Forman,
G. P. Garmire,
E. M. George,
M. D. Gladders,
A. H. Gonzalez,
N. Gupta,
N. W. Halverson,
J. Hlavacek-Larrondo,
H. Hoekstra,
G. P. Holder,
W. L. Holzapfel,
Z. Hou,
J. D. Hrubes,
N. Huang,
C. Jones,
R. Keisler,
L. Knox,
A. T. Lee,
E. M. Leitch,
A. von der Linden,
D. Luong-Van,
A. Mantz,
D. P. Marrone,
M. McDonald,
J. J. McMahon,
S. S. Meyer,
L. M. Mocanu,
J. J. Mohr,
S. S. Murray,
S. Padin,
C. Pryke,
D. Rapetti,
C. L. Reichardt,
A. Rest,
J. Ruel,
J. E. Ruhl,
B. R. Saliwanchik,
A. Saro,
J. T. Sayre,
K. K. Schaffer,
T. Schrabback,
E. Shirokoff,
J. Song,
H. G. Spieler,
B. Stalder,
S. A. Stanford,
Z. Staniszewski,
A. A. Stark,
K. T. Story,
C. W. Stubbs,
K. Vanderlinde,
J. D. Vieira,
A. Vikhlinin,
R. Williamson,
and
A. Zenteno

Alternate Affiliation: Department of Physics, University of California, Berkeley, CA, USA 94720
Alternate Affiliation: Department of Physics, McGill University, Montreal, Quebec H3A 2T8, Canada
Alternate Affiliation: Department of Astronomy and Astrophysics, University of Chicago, Chicago, IL, USA 60637
Alternate Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, Chicago, IL, USA 60637
Alternate Affiliation: Fermi National Accelerator Laboratory, Batavia, IL 60510-0500, USA
Alternate Affiliation: Department of Physics, University of Chicago, Chicago, IL, USA 60637
Alternate Affiliation: Argonne National Laboratory, Argonne, IL, USA 60439
Alternate Affiliation: Kavli Institute for Particle Astrophysics and Cosmology, Stanford University, 452 Lomita Mall, Stanford, CA 94305
Alternate Affiliation: Department of Physics, Stanford University, 382 Via Pueblo Mall, Stanford, CA 94305
Alternate Affiliation: SLAC National Accelerator Laboratory, 2575 Sand Hill Road, Menlo Park, CA 94025
Alternate Affiliation: Argelander-Institut für Astronomie, Auf dem Hügel 71, D-53121 Bonn, Germany
Alternate Affiliation: Harvard-Smithsonian Center for Astrophysics, Cambridge, MA, USA 02138
Alternate Affiliation: Kavli Institute for Astrophysics and Space Research, Massachusetts Institute of Technology, 77 Massachusetts Avenue, Cambridge, MA 02139
Alternate Affiliation: Department of Physics, Harvard University, 17 Oxford Street, Cambridge, MA 02138
Alternate Affiliation: Department of Physics, Ludwig-Maximilians-Universität, Scheinerstr. 1, 81679 Munich, Germany
Alternate Affiliation: Excellence Cluster Universe, Boltzmannstr. 2, 85748 Garching, Germany
Alternate Affiliation: Department of Physics and Astronomy, University of Missouri, 5110 Rockhill Road, Kansas City, MO 64110
Alternate Affiliation: Enrico Fermi Institute, University of Chicago, Chicago, IL, USA 60637
Alternate Affiliation: NIST Quantum Devices Group, Boulder, CO, USA 80305
Alternate Affiliation: Departamento de Astronomia y Astrosifica, Pontificia Universidad Catolica,Chile
Alternate Affiliation: California Institute of Technology, Pasadena, CA, USA 91125
Alternate Affiliation: Canadian Institute for Advanced Research, CIFAR Program in Cosmology and Gravity, Toronto, ON, M5G 1Z8, Canada
Alternate Affiliation: School of Physics, University of Melbourne, Parkville, VIC 3010, Australia
Alternate Affiliation: Astronomy Department, University of Illinois at Urbana-Champaign, 1002 W. Green Street, Urbana, IL 61801, USA
Alternate Affiliation: Department of Physics, University of Illinois Urbana-Champaign, 1110 W. Green Street, Urbana, IL 61801, USA
Alternate Affiliation: Huntingdon Institute for X-ray Astronomy, LLC
Alternate Affiliation: Max Planck Institute for Extraterrestrial Physics, Giessenbachstr. 1, 85748 Garching, Germany
Alternate Affiliation: Department of Astronomy, University of Florida, Gainesville, FL 32611
Alternate Affiliation: Department of Astrophysical and Planetary Sciences and Department of Physics, University of Colorado, Boulder, CO, USA 80309
Alternate Affiliation: Department of Physics, Université de Montréal, Montrea, Quebec H3T 1J4, Canada
Alternate Affiliation: Kavli Institute for Particle Astrophysics and Cosmology, Stanford University, 452 Lomita Mall, Stanford, CA 94305-4085, USA
Alternate Affiliation: Leiden Observatory, Leiden University, Niels Bohrweg 2, 2333 CA, Leiden, the Netherlands
Alternate Affiliation: University of Chicago, Chicago, IL, USA 60637
Alternate Affiliation: Department of Physics, University of California, Davis, CA, USA 95616
Alternate Affiliation: Physics Division, Lawrence Berkeley National Laboratory, Berkeley, CA, USA 94720
Alternate Affiliation: Department of Physics and Astronomy, Stony Brook University, Stony Brook, NY 11794, USA
Alternate Affiliation: Dark Cosmology Centre, Niels Bohr Institute, University of Copenhagen Juliane Maries Vej 30, 2100 Copenhagen, Denmark
Alternate Affiliation: Steward Observatory, University of Arizona, 933 North Cherry Avenue, Tucson, AZ 85721
Alternate Affiliation: Department of Physics, University of Michigan, Ann Arbor, MI, USA 48109
Alternate Affiliation: Department of Physics, University of Minnesota, Minneapolis, MN, USA 55455
Alternate Affiliation: Space Telescope Science Institute, 3700 San Martin Dr., Baltimore, MD 21218
Alternate Affiliation: Physics Department, Center for Education and Research in Cosmology and Astrophysics, Case Western Reserve University,Cleveland, OH, USA 44106
Alternate Affiliation: Liberal Arts Department, School of the Art Institute of Chicago, Chicago, IL, USA 60603
Alternate Affiliation: Korea Astronomy and Space Science Institute, Daejeon 305-348, Republic of Korea
Alternate Affiliation: Institute of Geophysics and Planetary Physics, Lawrence Livermore National Laboratory, Livermore, CA 94551
Alternate Affiliation: Dunlap Institute for Astronomy & Astrophysics, University of Toronto, 50 St George St, Toronto, ON, M5S 3H4, Canada
Alternate Affiliation: Department of Astronomy & Astrophysics, University of Toronto, 50 St George St, Toronto, ON, M5S 3H4, Canada
Alternate Affiliation: Cerro Tololo Inter-American Observatory, Casilla 603, La Serena, Chile

###### Abstract

We present cosmological parameter constraints obtained from galaxy clusters identified by their Sunyaev-Zel’dovich effect signature in the 2500 square degree South Pole Telescope Sunyaev Zel’dovich (SPT-SZ) survey.
We consider the 377 cluster candidates identified at $z>0.25$ with a
detection significance greater than five, corresponding to the $95\%$ purity threshold for the survey.
We compute constraints on cosmological models using the measured cluster abundance as a function of mass and redshift.
We include additional constraints from multi-wavelength observations, including *Chandra* X-ray data for 82 clusters
and a weak lensing-based prior on the normalization of the mass-observable scaling relations.
We introduce a numerical technique to efficiently compute the cluster likelihood in the presence of an arbitrary number
of mass proxies, each of which relate to the underlying cluster mass with a power-law scaling relation and contain scatter, of which a log-normal component may be correlated between mass proxies.
Assuming a spatially flat
$\Lambda$CDM cosmology, where the species-summed neutrino mass has the minimum allowed value ($\Sigma m\_{\nu}=0.06~\mathrm{eV}$) from neutrino oscillation experiments,
we combine the cluster data with a prior on $H\_{0}$ and
find $\sigma\_{8}=0.784\pm 0.039$ and $\Omega\_{m}=0.289\pm 0.042$,
with the parameter combination $\sigma\_{8}\left(\Omega\_{m}/0.27\right)^{0.3}=0.797\pm 0.031$.
These results are in good agreement with constraints from the cosmic microwave background (CMB) from SPT, WMAP, and Planck, as well as with constraints from other cluster datasets.
Adding the sum of the neutrino masses as a free parameter, we find $\Sigma m\_{\nu}=0.14\pm 0.08~\mathrm{eV}$
when combining the SPT cluster data with Planck CMB data and baryon acoustic oscillation (BAO) data, consistent with the minimum allowed value.
With this dataset, when we simultaneously free $\Sigma m\_{\nu}$ and the effective number of relativistic species ($N\_{\mathrm{eff}}$), we find $N\_{\mathrm{eff}}=3.28\pm 0.20$ and $\Sigma m\_{\nu}=0.18\pm 0.09~\mathrm{eV}$.
Finally, we consider a cosmology where $\Sigma m\_{\nu}$ and $N\_{\mathrm{eff}}$ are fixed to the $\Lambda$CDM values, but the dark energy equation of state parameter $w$ is free. Using the SPT cluster data in combination with an $H\_{0}$ prior,
we measure $w=-1.28\pm 0.31$, a constraint consistent with the $\Lambda$CDM cosmological model and derived from
the combination of growth of structure and geometry.
When combined with primarily geometrical constraints from Planck CMB, $H\_{0}$, BAO and SNe, adding the SPT cluster data improves the $w$ constraint from the geometrical data alone by $14\%$, to $w=-1.023\pm 0.042$.

###### Subject headings

cosmology: observations – galaxies: clusters: general

## I. Introduction

Galaxy clusters trace extreme peaks in the matter density field on megaparsec scales.
The abundance of these peaks as a function of mass and redshift is highly sensitive
to the matter density and the growth of structure. As this abundance can be predicted
with sufficient accuracy for a given cosmology [[85](#bib.bib85), [16](#bib.bib16), [35](#bib.bib35)], even modest
measurements of cluster abundance can yield powerful cosmological constraints.
These constraints are particularly powerful when combined with or compared to independent constraints
from probes such as the power spectrum of the cosmic microwave background (CMB)
and baryon acoustic oscillations (BAO). Taken together, growth-based and geometrical probes can place
significantly tighter constraints on parameters such as the equation of state of dark energy than either
one independently, because of
nearly orthogonal parameter degeneracies. Considered independently, these constraints provide a
consistency test of
the dark energy paradigm and the validity of general relativity [[39](#bib.bib39), [97](#bib.bib97), [59](#bib.bib59), [60](#bib.bib60), [68](#bib.bib68), [69](#bib.bib69), [2](#bib.bib2), [87](#bib.bib87)].

In recent years, constraints on cosmological parameters from cluster abundance measurements have advanced
significantly using cluster samples selected at
X-ray [[90](#bib.bib90), [52](#bib.bib52), [54](#bib.bib54), e.g.,],
optical [[72](#bib.bib72), e.g.,],
and millimeter [[70](#bib.bib70), [65](#bib.bib65), [29](#bib.bib29), [18](#bib.bib18), [66](#bib.bib66), e.g.,] wavelengths.
The predominant millimeter-wave (mm-wave)
signal from clusters arises from the thermal Sunyaev-Zel’dovich (tSZ) effect [[84](#bib.bib84)],
i.e., the scattering of CMB photons by hot electrons in
the intra-cluster medium (ICM). The surface brightness of the tSZ effect is
redshift-independent, allowing high-resolution mm-wave surveys to obtain nearly
mass-limited samples of clusters to arbitrarily high redshift. The ability to cleanly select
clusters out to the redshift at which dark energy begins to contribute significantly to the energy budget
of the universe ($z\sim 1$) is particularly important for constraints on the dark energy equation of
state and tests of the dark energy paradigm. Cluster surveys using high-resolution tSZ data
are uniquely positioned to deliver such constraints [[21](#bib.bib21)].

The primary limitation to cosmological constraints from current cluster surveys at all wavelengths
is an imperfect understanding of the relationship between the quantity that can be predicted from theory or
simulations (the cluster mass or the height of the associated density peak) and the observable property of
the cluster that is used as a proxy for this quantity.
The mass proxy can be the observable quantity used to construct the sample; it can also include
observables from follow-up observations, often at different wavelengths than the cluster selection observable.
Since the cluster abundance is an extremely steep function of mass, misestimation of the relation between the mass proxy and the true cluster mass can lead to significant biases on the resulting cosmological parameter constraints.

Different cluster mass proxies have distinct advantages and disadvantages related to the
accuracy and precision with which they trace the true cluster mass and the expense of obtaining
the data required to construct them. In terms of ultimate accuracy, or absence of bias, the current gold
standard mass proxy is derived from measurements of weak gravitational lensing of background galaxies
by clusters (see [von der Linden et al. 92](#bib.bib92) for a discussion).
Optical mass measurements from weak gravitational lensing
are observationally expensive to obtain at high redshift, and the
scatter on individual cluster mass estimates is large.
Gravitational lensing of the CMB by clusters
is a promising future avenue for mass estimation—e.g., [Madhavacheril et al. 50](#bib.bib50), [Baxter et al. 12](#bib.bib12), [Planck Collaboration et al. 66](#bib.bib66).
Cluster velocity dispersions, generally obtained through spectroscopic observations of tens
of cluster member galaxies, are also mostly unaffected by complex ICM physics
but are expensive observationally and
have large scatter [[24](#bib.bib24), [74](#bib.bib74), [79](#bib.bib79), [73](#bib.bib73), e.g.,],
as well as uncertain velocity bias [[62](#bib.bib62), e.g.,].
Where weak lensing measurements provide high accuracy, measurements of the gas mass $M\_{\mathrm{gas}}$, and/or of
the integrated cluster pressure $Y$ provide
high precision.
Estimated from tSZ or X-ray data, integrated cluster pressure
is predicted and measured to track cluster mass with low scatter
[[61](#bib.bib61), [63](#bib.bib63), [82](#bib.bib82), [45](#bib.bib45), e.g.,],
but its relation to true cluster mass can be complicated by non-thermal
pressure support in clusters [[25](#bib.bib25), [63](#bib.bib63), [96](#bib.bib96), e.g.,]. Furthermore, robust $Y$ estimates require either
relatively high-quality X-ray data (to provide deprojected temperature and density profiles), or tSZ measurements with
accurate information on all cluster scales (sub-arcminute
scales to the virial radius).
Mass proxies built from the same data used to select clusters,
such as optical richness, X-ray luminosity, and tSZ detection significance, come at no extra cost
but can demonstrate high scatter and
require external calibration data to tie them robustly to the true cluster mass.

In this work, we use a sample of clusters derived from the SPT-SZ survey, a three-band mm-wave survey
of 2500 $\mathrm{deg}^{2}$ of the southern sky conducted with the South Pole Telescope [[20](#bib.bib20), SPT,].
The cluster selection method, redshift determination, and sample characteristics are described in detail in
[Bleem et al. [17, hereafter B15]](#bib.bib17). We use the mm-wave and redshift information from B15
in conjunction with targeted X-ray follow-up observations from *Chandra* to obtain cosmological constraints.
The mass proxy we use is the tSZ detection significance $\xi$, calibrated using X-ray integrated pressure $Y\_{\mathrm{X}}$,
which is in turn tied to true cluster mass using optical weak lensing (WL) measurements.

The paper is organized as follows. In §[II](#S2 "II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"), we briefly describe the cluster sample,
including the mm-wave data and analysis methods that went into producing the sample.
We summarize the optical/infrared data and redshift estimation in §[III](#S3 "III. Redshift Estimation ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"),
and the X-ray data and analysis methods in §[IV](#S4 "IV. Chandra X-ray Dataset and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey").
The cosmological analysis methods are described in §[V](#S5 "V. Cosmological Analysis ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"), and we
present the cosmological parameter constraints in §[VI](#S6 "VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). We compare the
cosmological constraints from this work to those from other cluster surveys in §[VII](#S7 "VII. Comparison to Other Cluster Surveys ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"),
and we conclude in §[VIII](#S8 "VIII. Conclusion ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey").

When parameter constraints are reported, the best-fit value and uncertainties correspond to the mean
and standard deviation of the posterior distribution.
Cluster masses, denoted with $M\_{\Delta}$, refer to spherical overdensities for which the enclosed density is equal to $\Delta$ times the critical density, $\rho\_{c}$. Similarly, $r\_{\Delta}$ refers to the associated radius such that $M\_{\Delta}=\frac{4}{3}\pi r\_{\Delta}^{3}\Delta\rho\_{c}(z)$.

## II. SZ Data and Methods

The cluster sample used in this work is a subset of that previously presented in B15. We choose the clusters with
redshift $z>0.25$ and detection significance $\xi>5$. The significance cut was chosen such that
the resulting catalog has high ($\sim 95\%$) purity, and the redshift cut allows for a nearly redshift-independent selection function [[86](#bib.bib86), hereafter V10].
Our strategy for tying the cluster abundance measurement to the cosmologically predicted halo mass function is to calibrate the SZ-mass scaling relation using *Chandra*  X-ray measurements. The X-ray scaling relation is taken from [Vikhlinin et al. [88, hereafter V09]](#bib.bib88), [Vikhlinin et al. [90, hereafter V09]](#bib.bib90), though we modify the
overall normalization of this relation in §[IV.2](#S4.SS2 "IV.2. Prior on the Normalization of the 𝑌_X - 𝑀 Relation ‣ IV. Chandra X-ray Dataset and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") to be consistent with more recent weak lensing measurements from [Hoekstra et al. [32, hereafter H15]](#bib.bib32) and the Weighing the Giants (WtG) project [[5](#bib.bib5), [91](#bib.bib91), [54](#bib.bib54)].

### II.1. Sample of SZ Cluster Candidates

The SPT is a 10-m telescope located at the geographic South Pole. With a 1 degree field of view and $\sim 1$ arcminute resolution, it was designed to rapidly map large areas of sky while being well matched to the angular size of high-redshift clusters. The SPT-SZ camera operated from 2007 through 2011 and consisted of a 960-element, photon-noise-limited bolometer
array observing in three frequency bands centered at 95, 150, and 220 GHz, though this work uses only the first two bands.
The observation strategy and analysis for the 2500-square-degree SPT-SZ survey
are described in many previous SPT papers (e.g. [Schaffer et al. 75](#bib.bib75)), and the
analysis specific to obtaining the cluster sample is described in B15.
Briefly, the majority of the 2500 square-degree survey was performed using the following scan strategy. The telescope is moved using a right-going scan in azimuth, followed by a left-going scan, followed by a step in elevation. This pattern is repeated until a $\gtrsim$ 100 square degree patch of sky is observed. One such iteration is termed an *observation*, whereas the patch of sky is termed a *field*.
In the only exception to this observing strategy, for two thirds of the data taken on one field (ra21hdec-50), the scan pattern instead consisted of scans in elevation at a series of fixed azimuth positions.
Each field was observed until a depth of $\lesssim$ $18~\mathrm{\mu K}$-arcmin at 150 GHz was reached. Table [1](#S2.T1 "Table 1 ‣ II.2. By-Field Simulations ‣ II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") lists the 19 fields that comprise the full survey. For more information on the properties of the fields, see Table 1 of B15.

Two-dimensional maps of the sky are made by binning the time ordered data (TOD), to which mild time-domain filtering has been applied, into 0.25-arcminute pixels.
This produces estimates of the 95 and 150 GHz sky, to which we apply a simultaneous spatial-spectral filter, yielding a filtered estimate of the tSZ sky, optimized for extracting cluster candidates. The candidates are identified using a peak-finding algorithm.

Due to the exact choice of field extent, as well as the finite footprint of the SPT-SZ array on the sky, the fields overlap slightly.
The overlap regions only comprise $\sim 2\%$ of the total survey area, and for simplicity we choose to treat the fields as fully independent. As a result of this treatment, we would expect to double-count roughly $2\%$ of cluster candidates, or seven to eight of our total number of candidates. In fact we find nine cases of candidates with a very high probability of having been detected in two different fields (i.e., 18 total candidates that correspond to nine physical clusters). There is no bias to our cosmological constraints from this treatment. Our uncertainties will be very slightly underestimated, but this has a negligible effect on our final cosmological constraints.

#### II.1.1 SZ-Mass Scaling Relation Parameterization

We use the same functional form for the SZ-mass scaling relation as previous SPT cluster cosmology analyses
(V10; [Benson et al. 14](#bib.bib14), hereafter B13; [Reichardt et al. 70](#bib.bib70), hereafter R13; [Bocquet et al. 18](#bib.bib18)).

Briefly, we introduce two SZ parameters related to the cluster detection process. The first is the detection significance $\xi$.
After generating filtered synthesized SZ maps at a series of filter scales,
each map pixel value is divided by the RMS of the map in a strip that spans 90 arcminutes in declination. Then the maximum peak height over all filter scales is identified and
defined as $\xi$, the SZ observable used in this paper.
Because this observable allows for a very well-understood selection function, and cosmological constraints are dominated by the unknown normalization of the observable-mass scaling relation, we find that this observable is preferred over going to a different SZ observable such as $Y\_{\mathrm{SZ}}$.

The second parameter is the unbiased significance $\zeta$. It is defined as the value of $\xi$ that would be found in the absence of instrumental noise and astrophysical contaminants (including the SZ background). Due to the fact that $\xi$ is determined by maximizing the significance after searching in two-dimensional position space and source template size, the average $\xi$ found across many noise realizations is enhanced by those three degrees of freedom, resulting in the approximate relation

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left<\xi\right>^{2}=\zeta^{2}+3.$ |  | (1) |

Since this relation cannot hold down to very low $\zeta$, we only model this maximization bias for $\zeta>2$. We find that changing the location of this cutoff to $\zeta>1.5$ or $\zeta>2.5$ has negligible impact on the results presented in this work. Motivated by the definition of $\xi$, and the fact that the astrophysical contaminants and instrument noise are Gaussian to a high degree, we model $\xi$ as related to $\left<\xi\right>$ by unit-width Gaussian scatter. We then parameterize the $\zeta$ - $M$ scaling relation as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\zeta=A\_{\mathrm{SZ}}\left(\frac{M}{3\times 10^{14}M\_{\odot}h^{-1}}\right)^{B\_{\mathrm{SZ}}}\left(\frac{E(z)}{E(0.6)}\right)^{C\_{\mathrm{SZ}}},$ |  | (2) |

with an additional log-normal intrinsic scatter parameter $\sigma\_{\ln\zeta}$. The dimensionless Hubble parameter is denoted by $E(z)$. We follow B13 and R13 and apply Gaussian priors to these scaling relation parameters. However, the mean values and widths of the priors are updated to reflect results from the more recent cosmo-OWLS hydrodynamic simulations [[46](#bib.bib46)], which will be discussed in §[II.2](#S2.SS2 "II.2. By-Field Simulations ‣ II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). Specifically, we use the Gaussian priors $A\_{\mathrm{SZ}}=5.38\pm 1.61$, $B\_{\mathrm{SZ}}=1.340\pm 0.268$, $C\_{\mathrm{SZ}}=0.49\pm 0.49$, and $\sigma\_{\ln\zeta}=0.13\pm 0.13$, while requiring $\sigma\_{\ln\zeta}>0.05$.

### II.2. By-Field Simulations

Each of the 19 fields that comprises the 2500 square degree survey has slightly different properties, which we account for using two similar types of simulations. The first is to account for the fact that the map noise is slightly different in each of the fields. This causes the detection significance $\xi$ (the selection observable) of a cluster to relate to true underlying mass differently depending on the field in which the cluster was found. We model this by simulating the relation between true cluster mass and unbiased significance $\zeta$ separately for each field. The simulations contain several components.

1. 1.

   A Gaussian random field with a power spectrum equal to the CMB power spectrum calculated using the best-fit $\Lambda$CDM parameters from [Keisler et al. [40]](#bib.bib40).
2. 2.

   A Gaussian random field meant to approximate the background of emissive point sources after the brightest sources are masked. The power spectrum is generated using three components. The first is a Poisson component modeling the radio point source population with an amplitude at $\ell=3000$ of $D\_{3000}^{r}=1.28\mathrm{\mu K\_{CMB}}^{2}$ at 150 GHz and spectral index $\alpha\_{r}=-0.6$ (defined by flux $\propto\nu^{\alpha}$). The second and third components model the Poisson and clustered dusty star-forming galaxy (DSFG) populations, respectively. The assumed spectral index is $\alpha\_{\mathrm{DSFG}}=3.6$ and the amplitudes are the best-fit values from [Shirokoff et al. [78]](#bib.bib78).
3. 3.

   Atmospheric and instrumental noise. These are simulated using the actual TOD. The coherent nature of the sky signal, modulated by the scan strategy, and the incoherent nature of the instrumental and atmospheric noise contributions allow us to estimate the map noise by simply subtracting the right-going scan TOD from the left-going scan TOD (up- and down-going in the case of most of the ra21hdec-50 field) in the map making process. This removes any coherent signal present on the sky. We furthermore apply a sign change to half the observations before they are coadded into the final map. By changing which signs are assigned, we generate different realizations of realistic noise maps.
4. 4.

   Maps of the Compton $y$ parameter from the cosmo-OWLS simulations in [Le Brun et al. [46]](#bib.bib46). We use maps from the AGN8.0 model and convert the Comptonization maps to CMB temperature units by integrating the measured frequency response of the instrument against a relativistic 5 keV tSZ spectrum.

A modified version of the standard cluster-finding process is run on the sum of these four components, and the cluster candidates are recorded. In addition, the same spatial-spectral filter is applied to the maps only containing SZ signal. The latter is used to identify cluster candidates and define their SZ center. The amplitude in these filtered, SZ-only maps, divided by the standard deviation in a 90-arcminute strip in the filtered maps that include noise is precisely the unbiased significance $\zeta$ introduced in §[II.1.1](#S2.SS1.SSS1 "II.1.1 SZ-Mass Scaling Relation Parameterization ‣ II.1. Sample of SZ Cluster Candidates ‣ II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). These candidates are then compared to the underlying halo catalog used to generate the mock SZ maps, which provide the cluster redshift. For each SZ-identified cluster candidate, we choose the nearest dark matter halo with $M\_{200}>5\times 10^{13}\mathrm{M}\_{\odot}$.

With mass, unbiased significance and redshift in hand, we use the method of least absolute deviations to fit the $\zeta$ - $M$ relation from Equation [2](#S2.E2 "In II.1.1 SZ-Mass Scaling Relation Parameterization ‣ II.1. Sample of SZ Cluster Candidates ‣ II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") over the range $z>0.25$, $M\_{500}>1\times 10^{14}\mathrm{M}\_{\odot}$.
We find nearly identical results when using a linear least squares method.
The normalization parameter $A\_{\mathrm{SZ}}$ differs from field to field by up to $30\%$, while the other scaling relation parameters only vary at the few percent level. We therefore model field variation with one parameter $\gamma\_{\mathrm{field}}$ that renormalizes the overall scaling: $A\_{\mathrm{SZ}}\rightarrow\gamma\_{\mathrm{field}}A\_{\mathrm{SZ}}$.
For consistency with previous publications, we normalize $\gamma\_{\mathrm{field}}$  such that the weighted average over the three fields which share 100% of the raw data used in R13 matches the weighted average in that work. We note that any other choice of normalization would simply alter the definition of $A\_{\mathrm{SZ}}$, leaving all other results unaffected. The values of $\gamma\_{\mathrm{field}}$  are shown in Table [1](#S2.T1 "Table 1 ‣ II.2. By-Field Simulations ‣ II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey").

The other field-specific simulation is used to compute the expected false detection rate. At a detection threshold of $\xi>5$, approximately $5\%$ of cluster candidates are expected to be false. In order to simulate the rate of false detections, we perform the cluster-finding process on the simulated maps described above, omitting the SZ component. The resulting number of cluster candidates as a function of $\xi$ is recorded for 100 such simulations. To reduce shot noise from the finite number of simulated realizations, we model the false detection rate with the empirically chosen fitting function

|  |  |  |  |
| --- | --- | --- | --- |
|  | $N\_{\mathrm{false}}(>\xi)=\alpha\_{\mathrm{field}}\exp\left(-\beta\_{\mathrm{field}}(\xi-5)\right)\ .$ |  | (3) |

The values of $\alpha\_{\mathrm{field}}$  and $\beta\_{\mathrm{field}}$  are shown in Table [1](#S2.T1 "Table 1 ‣ II.2. By-Field Simulations ‣ II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). The total number of expected
false detections per 2500 square degrees with $\xi>5$ from these simulations is $18\pm 4$, which is
consistent with the number of optically unconfirmed cluster candidates, 21 (B15).

Table 1The 19 SPT-SZ fields with the simulation-derived inputs to the cosmological analysis of the 2500 square degree survey

| Name | $\alpha\_{\mathrm{field}}$ | $\beta\_{\mathrm{field}}$ | $\gamma\_{\mathrm{field}}$ |
| --- | --- | --- | --- |
| ra5h30dec-55 | 16.79 | 4.60 | 1.33 |
| ra23h30dec-55 | 17.58 | 4.03 | 1.39 |
| ra21hdec-60 | 25.64 | 4.07 | 1.29 |
| ra3h30dec-60 | 20.53 | 4.70 | 1.25 |
| ra21hdec-50 | 25.28 | 4.14 | 1.11 |
| ra4h10dec-50 | 16.75 | 5.48 | 1.27 |
| ra0h50dec-50 | 20.76 | 5.11 | 1.14 |
| ra2h30dec-50 | 14.98 | 4.78 | 1.19 |
| ra1hdec-60 | 17.25 | 5.38 | 1.18 |
| ra5h30dec-45 | 15.91 | 4.81 | 1.08 |
| ra6h30dec-55 | 17.77 | 4.58 | 1.16 |
| ra3h30dec-42.5 | 16.85 | 4.31 | 1.20 |
| ra23hdec-62.5 | 14.90 | 4.92 | 1.18 |
| ra21hdec-42.5 | 17.11 | 4.49 | 1.15 |
| ra1hdec-42.5 | 18.41 | 5.55 | 1.19 |
| ra22h30dec-55 | 16.45 | 5.23 | 1.13 |
| ra23hdec-45 | 17.00 | 5.20 | 1.19 |
| ra6h30dec-45 | 14.78 | 4.23 | 1.16 |
| ra6hdec-62.5 | 16.53 | 4.70 | 1.18 |

Note. — The parameter $\alpha\_{\mathrm{field}}$ describes the number of false detections expected above $\xi=5$ scaled to 2500 square degrees, while $\beta\_{\mathrm{field}}$ describes the scaling of the number of false detections with $\xi$ as defined in Equation [3](#S2.E3 "In II.2. By-Field Simulations ‣ II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). $\gamma\_{\mathrm{field}}$ describes the renormalization of $A\_{\mathrm{SZ}}$ in the SZ-mass scaling relation of Equation [2](#S2.E2 "In II.1.1 SZ-Mass Scaling Relation Parameterization ‣ II.1. Sample of SZ Cluster Candidates ‣ II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey").

## III. Redshift Estimation

As the SPT-SZ selection is essentially independent of redshift, we require optical and—for the highest-redshift systems—near-infrared (NIR) data to both confirm the SPT candidates as clusters and to obtain redshifts for these systems.
We provide a brief overview of this process here; for more details readers are referred to B15.

As a first step, each SPT cluster candidate is visually inspected in imaging data from the Digitized Sky Survey (DSS),11
1
http://archive.stsci.edu/dss/ as we have found most SPT clusters at redshift $z<0.5$ are visible in these scanned photographic plates.
These relatively low-redshift systems are then reimaged with 1 – 2 m class telescopes to obtain robust confirmations and redshifts.
Higher-redshift candidates not visible in the DSS (or designated non-confirmed after imaging on the small telescopes) are observed with 4 – 6.5 m class telescopes.
The latter observations are conducted in two passes: first-pass observations are designed to ensure $\geq 5\sigma$ detection of
$0.4$L∗ red-sequence galaxies
(where L∗ is the characteristic luminosity that appears in the
[Schechter [76]](#bib.bib76) formulation of the galaxy luminosity function)
at $z<0.75$; higher-redshift clusters or candidates not confirmed in the first pass are also observed (telescope resources permitting) in the optical and/or NIR to extend this redshift range to $z>0.9$.
In total 69/78 of the highest-redshift ($z>0.75$) or non-confirmed systems received second-pass imaging; the majority of these systems (58/78) were observed with Spitzer/IRAC [[26](#bib.bib26), PI: Brodwin] at 3.6 $\mu$m and 4.5 $\mu$m to a depth
sufficient for the $10\sigma$ detection of $0.4$L∗ galaxies at $z=1.5$ [[19](#bib.bib19)].

Following imaging, a few arcmin region around each SPT location is searched for an overdensity of red-sequence cluster galaxies.
When such an overdensity is identified, we confirm the candidate as a cluster and assign the system a redshift using a red-sequence model calibrated using the subset of SPT clusters with spectroscopic redshifts.
For candidates not confirmed in our imaging data we compute a redshift “lower limit” corresponding to the highest redshift for which we would have detected the overdensity of red galaxies we require to confirm a cluster [[81](#bib.bib81)].
The redshift range of the confirmed cosmological cluster sample is $0.25\leq z\lesssim 1.7$ with a median redshift $z\_{\textrm{med}}=0.58$.
Typical redshift uncertainties range from $\sigma\_{z}\sim$0.02$\times(1+z)$ for the optical-based redshifts to $\sim$0.035$\times(1+z)$ for clusters with redshifts determined from Spitzer/IRAC observations.

A large subset (31%) of the SPT cosmological cluster sample has also been spectroscopically observed.
Spectroscopic redshifts for 86 SPT clusters were obtained as part of a dedicated follow-up campaign using spectrographs on the Magellan telescope, the Gemini-South telescope, and the Very Large Telescope.
We have also searched the literature for cluster counterparts and find an additional 21 clusters with reported spectroscopic redshifts.
The spectroscopic sample spans almost the full redshift range of the cluster sample, from $0.26<z\leq 1.478$, with a median redshift of $z\_{\textrm{med}}=0.53$.
The SPT spectroscopic follow-up effort is described in detail in [Ruel et al. [73]](#bib.bib73), and the redshifts are presented in B15.

## IV. *Chandra* X-ray Dataset and Methods

The X-ray data used in this work were originally presented in [McDonald et al. [56]](#bib.bib56) and most were acquired as part of a *Chandra* X-ray Visionary Project (PI: Benson). In general, exposure times were chosen to ensure 2000 X-ray counts, based on measured ROSAT fluxes (when available) or a combination of the $L\_{\mathrm{X}}-M$ relation and mass estimates from the SZ signal. Data were obtained using the front-illuminated ACIS-I CCDs, and cleaned for background flares before applying calibration corrections using ciao v4.7 and caldb v4.6.8.

Global cluster properties (e.g., gas mass $M\_{g,500}$ and X-ray temperature $kT\_{500}$) for each cluster are derived in
[McDonald et al. [56]](#bib.bib56), following closely the procedures described in [Andersson et al. [4]](#bib.bib4). For a detailed description of the X-ray analysis, the reader is directed to these works. In this work, we make use of the mass proxy $Y\_{\mathrm{X}}$, which is obtained from the measured gas mass and X-ray temperature. This temperature $kT\_{500}$ is derived by first assuming some value of $r\_{500}$ (i.e., 1 Mpc), and measuring the core-excised ($0.15~r\_{500}$ to $1.0~r\_{500}$) temperature within this radius. Using this temperature, we compute a new estimate of $r\_{500}$ using the $T\_{\mathrm{X}}-M$ relation from V09. The temperature is then measured within this radius, and the process is repeated until it converges.

We also measure the enclosed gas mass as a function of $r\_{500}$, following the procedures described in [McDonald et al. [55]](#bib.bib55). This involves measuring the X-ray surface brightness in the rest-frame energy range $0.7-2.0$ keV as a function of radius, and fitting a line-of-sight projected model for the electron density profile to these data, following [Vikhlinin et al. [89]](#bib.bib89). In converting from the electron density to the gas density, we assume $\rho\_{g}=m\_{p}n\_{e}A/Z$, where $A=1.397$ is the average nuclear charge and $Z=1.199$ is the average nuclear mass. The enclosed gas mass within a given radius is simply the volume integral of the gas density profile out to the specified radius.

These two quantities are combined into the mass proxy $Y\_{\mathrm{X}}$. Since $r\_{500}$ must be known to compute $M\_{g,500}$, we numerically solve $\mbox{$Y\_{\mathrm{X}}$}=M\_{g,500}kT\_{500}$ together with the scaling relation given in Equation [4](#S4.E4 "In IV.1. 𝑌_X - 𝑀 Scaling Relation Parameterization ‣ IV. Chandra X-ray Dataset and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). This numerical calculation is performed for each set of cosmological parameters that will be explored in §[V](#S5 "V. Cosmological Analysis ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey").

### IV.1. $Y\_{\mathrm{X}}$ - $M$ Scaling Relation Parameterization

Following V09, B13, R13, and [Bocquet et al. [18]](#bib.bib18), we use $Y\_{\mathrm{X}}$ as a proxy for the total cluster mass. We write the scaling relation as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}\frac{M\_{500}}{10^{14}M\_{\odot}/h}=\left(A\_{\mathrm{X}}h^{3/2}\left(\frac{h}{0.72}\right)^{\frac{5}{2}B\_{\mathrm{X}}-\frac{3}{2}}\right)\\ \times\left(\frac{\mbox{$Y\_{\mathrm{X}}$}}{3\times 10^{14}M\_{\odot}\,\mathrm{keV}}\right)^{B\_{\mathrm{X}}}E(z)^{C\_{\mathrm{X}}},\end{split}$ |  | (4) |

where the parameters $A\_{\mathrm{X}}$, $B\_{\mathrm{X}}$, $C\_{\mathrm{X}}$ describe the normalization, mass dependence and redshift dependence of the relation, respectively.22
2
This equation differs slightly from B13 and R13 in order to more rigorously scale the V09 results if $B\_{\mathrm{X}}\neq 0.6$ and $h\neq 0.72$ simultaneously. This modification has negligible effect on any of the results in this work. As we did for the $\zeta$ - $M$ relation, we introduce a parameter $\sigma\_{\ln\mathrm{Yx}}$ which models a log-normal intrinsic scatter in the $Y\_{\mathrm{X}}$ - $M$ relation. We allow the intrinsic scatter in the $Y\_{\mathrm{X}}$ - $M$ relation and the $\zeta$ - $M$ relation to be correlated, parameterizing this with the correlation coefficient $\rho\_{\zeta,\mathrm{Yx}}$. We follow B13 and R13 and apply Gaussian priors of $B\_{\mathrm{X}}=0.57\pm 0.03$, $C\_{\mathrm{X}}=-0.40\pm 0.20$, and $\sigma\_{\ln\mathrm{Yx}}=0.12\pm 0.08$, respectively, as well as a uniform prior between $-0.98$ and 0.98 on $\rho\_{\zeta,\mathrm{Yx}}$.

### IV.2. Prior on the Normalization of the $Y\_{\mathrm{X}}$ - $M$ Relation

In B13 and R13, we used a prior on the normalization of the $Y\_{\mathrm{X}}$ - $M$ relation, $A\_{\mathrm{X}}$, motivated from V09.
In V09, the normalization was cross-checked against weak lensing mass estimates
from [Hoekstra [31]](#bib.bib31) for the 10 clusters at $z<0.3$ that, at the time, also had sufficient *Chandra* observations to measure $Y\_{\mathrm{X}}$. In B13,
this normalization was remeasured using more recent weak lensing mass estimates from [Hoekstra et al. [33]](#bib.bib33), and
found to be consistent with the assumed calibration from V09. In this work, we revisit the $Y\_{\mathrm{X}}$ - $M$ normalization again, using the most recent
weak lensing mass estimates from H15 to constrain any mean offset in the normalization of the original hydrostatic mass
calibration of the $Y\_{\mathrm{X}}$-mass scaling relation from V09. In addition, we also consider any systematic offset
in the H15 weak lensing mass estimates, by comparing to alternative weak lensing mass estimates from WtG.

In Figure [1](#S4.F1 "Figure 1 ‣ IV.2. Prior on the Normalization of the 𝑌_X - 𝑀 Relation ‣ IV. Chandra X-ray Dataset and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"), we compare weak lensing-based mass estimates from H15 to $Y\_{\mathrm{X}}$-based mass estimates and to weak-lensing masses from WtG.
We have remeasured $Y\_{\mathrm{X}}$ from archival *Chandra* X-ray data for the 14 clusters from H15 with sufficiently deep X-ray measurements,
which we use to estimate a cluster mass ($M\_{\rm\mathrm{Yx}}$) using the $Y\_{\mathrm{X}}$-mass scaling relation from V09. For these clusters, we also remeasure the
deprojected weak-lensing aperture mass from the
H15 dataset using the X-ray implied $r\_{500}$.
Using the X-ray implied $r\_{500}$ approximates
what would happen if the weak lensing mass estimates were included in a joint $Y\_{\mathrm{X}}$- WL scaling relation fit because of the relatively low scatter of $Y\_{\mathrm{X}}$ with cluster mass, and,
as we will show later,
the agreement in the resulting $Y\_{\mathrm{X}}$ - $M$ relation.
To compare H15 and WtG mass estimates at the same radius, we extract a WtG mass
for each of the 18 clusters in common at the value of $r\_{500}$
implied by the H15 analysis. We specifically use the mass estimates computed
by fitting an NFW model to the observed shear profiles from the WtG
“color-cut” method [[5](#bib.bib5)].

In Table [2](#S4.T2 "Table 2 ‣ IV.2. Prior on the Normalization of the 𝑌_X - 𝑀 Relation ‣ IV. Chandra X-ray Dataset and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"), we give three different measures of the relative cluster mass estimates between H15, WtG, and V09.
First, we fit a scaling relation of the form $\ln(M\_{\rm WL})=A+\ln(M\_{\rm\mathrm{Yx}})$ with a free log-normal intrinsic scatter, using the
Bayesian linear regression fitting code from [Kelly [41]](#bib.bib41).
For comparison, we also estimate the bootstrap mean and median of the log of the mass ratio, which makes no assumption about the
underlying scatter.

First considering the mass ratio between H15 and V09, we find all three estimates imply a mass ratio near unity with the scaling relation,
bootstrap mean, and bootstrap median giving ratios of $1.01\pm 0.07$, $1.03\pm 0.06$, and $1.12\pm 0.05$, respectively. This implies
that the $Y\_{\mathrm{X}}$-based masses from V09 are in relatively good agreement with H15, with the H15 masses $\sim$1-12% larger,
depending on how the mass ratio is estimated.
Next, we consider the mass ratio between WtG and H15. We also find that all three estimates imply a mass ratio near unity with the scaling
relation, bootstrap mean, and bootstrap median giving ratios of $1.06\pm 0.07$, $1.07\pm 0.07$, and $1.11\pm 0.05$, respectively.
Therefore the weak lensing-based mass estimates from H15 and WtG are also in relatively good agreement, with the WtG
masses $\sim$6-11% larger, comparable to the $7\%$ estimated systematic uncertainty from H15.
The overlapping cluster sample between our V09-$Y\_{\mathrm{X}}$ sample and WtG is smaller (eight clusters), and therefore
has larger uncertainty on the mass ratio. We find that the three different
mass ratio estimates between WtG and V09 range from $1.15-1.24$. This range is somewhat larger, but comparable with,
the expectation when
considering the mass ratios of the larger samples used to calculate the WtG/H15 and H15/V09 mass ratios, which would predict
a mass ratio between WtG and V09 of $\sim 1.1-1.2$.

In summary, comparing to the original $Y\_{\mathrm{X}}$ - $M$ calibration from V09, we find that the weak lensing measurements imply a
normalization that increases the $Y\_{\mathrm{X}}$-based cluster masses by a factor between 1.0 and 1.2, depending on the weak lensing analysis and dataset (H15, WtG),
and the fit assumptions. We therefore choose a Gaussian prior on the normalization of our $Y\_{\mathrm{X}}$ - $M$ relation of
$A\_{\mathrm{X}}=6.35\pm 0.61$, which increases the normalization from V09 by a factor of $1.1$ with an overall uncertainty
of $10\%$. We expect that this uncertainty includes the sum of our statistical and systematic uncertainty, because it brackets the
range of values in the above comparison with the weak lensing measurements and is comparable to our naive expectation given the
statistical uncertainty in the fit above and the systematic uncertainty estimated in H15. This effectively gives us a purely
weak lensing-derived mass scale, independent of the hydrostatic mass estimates. We expect our constraints on the mass scale to improve in future work using
weak lensing observations of SPT-SZ survey clusters, which we will then be able to directly include in our cosmological analysis.

Finally, we have also estimated the dependence of the weak-lensing and X-ray-derived mass estimates on cosmological parameters. Over the range of cosmological parameters explored, the ratio of the two varies negligibly compared to the uncertainty of $10\%$.

Figure 1.— A plot comparing cluster weak lensing and $Y\_{\mathrm{X}}$-based mass estimates.
Plotted along the $y$-axis are weak lensing-based mass estimates from
WtG (red) and $Y\_{\mathrm{X}}$-based mass estimates using the scaling from V09 (black).
On the $x$-axis are weak lensing-based mass estimates from H15. For the H15/V09 comparison
(black points), we have re-estimated the H15 masses using the X-ray implied $r\_{500}$.
The solid grey line shows a one-to-one relation, and the dashed black and red lines give the
normalization implied for the bootstrap mean fit to the ratio of the masses (for details see text).

Table 2Mass ratios between weak lensing (H15, WtG) and $Y\_{\mathrm{X}}$ (V09) based mass estimates.

| Dataset | $N\_{\mathrm{clust}}$ | Log-Normal | Mean | Median |
| --- | --- | --- | --- | --- |
| H15/V09 | 14 | $1.01\pm 0.07$ | $1.03\pm 0.06$ | $1.12\pm 0.05$ |
| WtG/H15 | 18 | $1.06\pm 0.07$ | $1.07\pm 0.07$ | $1.11\pm 0.05$ |
| WtG/V09 | 8 | $1.15\pm 0.10$ | $1.17\pm 0.13$ | $1.24\pm 0.09$ |

## V. Cosmological Analysis

Armed with the abundance of clusters as a function of the observables $z$, $\xi$, and $Y\_{\mathrm{X}}$,
and models of the scaling of these observables with cluster mass, we are almost ready to place constraints on
cosmological parameters. For the final step, we need a theoretical framework for translating cosmological
parameters into a prediction for the number of clusters as a function of mass and redshift, and we need a
statistical method for comparing those predictions to our observed abundance. For both of these requirements,
we closely follow the methods of V10, B13, and R13.

### V.1. Parameters to Cluster Abundance Predictions

For a given set of cosmological parameters, we use the Code for Anisotropies in the Microwave Background
[[49](#bib.bib49), CAMB,] to generate the matter power spectrum as a function of redshift.
We use this power spectrum as input to the [[85](#bib.bib85)] halo mass function, with which we calculate the
number of dark matter halos as a function of spherical overdensity mass $M\_{500}$ and redshift.

More recent results
[[16](#bib.bib16), [80](#bib.bib80), e.g.,] confirm that, over the range of cluster masses and redshifts
considered in this work, the Tinker mass function is accurate to a level that is more than sufficient for
the cosmological parameter constraints presented in this work.
For instance, even a shift as large as 10% in the halo mass function at $M\_{500}\sim 3\times 10^{14}~\mathrm{\mathrm{M}\_{\odot}}$ would only affect the cosmological constraints presented in §[VI.2](#S6.SS2 "VI.2. ΛCDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") at the $\lesssim 0.2\sigma$ level.

Given the Tinker mass function, we relate the
cluster mass to the observed quantities
$\xi$ and $Y\_{\mathrm{X}}$ using the scaling relations described in §[II.1.1](#S2.SS1.SSS1 "II.1.1 SZ-Mass Scaling Relation Parameterization ‣ II.1. Sample of SZ Cluster Candidates ‣ II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") and §[IV.1](#S4.SS1 "IV.1. 𝑌_X - 𝑀 Scaling Relation Parameterization ‣ IV. Chandra X-ray Dataset and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey").

In our default cosmological analysis, we use the standard six-parameter $\Lambda$CDM model,
parameterized by the physical densities of baryons and cold dark matter at $z=0$, $\Omega\_{b}h^{2}$
and $\Omega\_{c}h^{2}$, the angular scale of the sound horizon at last scattering $\theta\_{s}$,
the tilt of the scalar power spectrum $n\_{s}$, the amplitude of the scalar power spectrum
$A\_{s}$, and the optical depth to reionization $\tau$. We will often refer to values of
parameters derived from combinations of these original six, such as $\sigma\_{8}$, the amplitude
of linear matter fluctuations on 8 Mpc$/h$ scales at $z=0$, $\Omega\_{m}$, the total matter density at $z=0$,
and $H\_{0}=100h~\mathrm{km/s/Mpc}$, the value of the Hubble parameter at $z=0$. We explore three extensions
to $\Lambda$CDM. We first explore a model in which the sum of the neutrino masses $\Sigma m\_{\nu}$ is a free
parameter. In this work we use the prescription from [Costanzi et al. [23]](#bib.bib23) to predict the
effect of massive neutrinos on the halo mass function.
We also consider a cosmological model in which $\Sigma m\_{\nu}$ and $N\_{\mathrm{eff}}$, the effective number of relativistic particle species,
are both free parameters, and a model in which $w$, the parameter describing the equation of state of dark energy, is allowed to vary.

### V.2. Cluster Likelihood Evaluation

To compare theoretical predictions for cluster abundance to the observations in this work, we closely follow the likelihood derivation of V10, B13, and R13. We differ from those analyses in this work by presenting
an efficient numerical technique that scales linearly rather than exponentially with the number of mass proxies.

As is appropriate for a cluster abundance measurement [[38](#bib.bib38), [34](#bib.bib34)], we start with the binned Poisson statistic.
For a given observable-space bin $x\_{i}$, the probability of observing $n$ events, with expectation value $y(x\_{i})$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $P\_{i}=\frac{e^{-y(x\_{i})}y(x\_{i})^{n}}{n!}.$ |  | (5) |

We choose to take the limit of small bins where $y$ becomes arbitrarily small at all $x\_{i}$, and $n$ is zero except at the locations of $x\_{i}$ where clusters have been observed [[51](#bib.bib51), [52](#bib.bib52), V09]. If we let $x\_{j}$ denote the bin that contains the $j^{\mathrm{th}}$ cluster, we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\ln\mathcal{L}=\sum\_{i}\ln P\_{i}=-\sum\_{i}y(x\_{i})+\sum\_{j}\ln y(x\_{j}).$ |  | (6) |

In our case, we are dealing with the three-dimensional cluster observable space $\textbf{x}=\left[z,\xi,\mbox{$Y\_{\mathrm{X}}$}\right]$, though this method generalizes efficiently to a larger number of observables. Writing the model expectation value $y(x\_{i})=N(z\_{i},\xi\_{i},Y\_{\mathrm{X},i})$ and going to one-dimensional indices gives

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\ln\mathcal{L}$ | $\displaystyle=$ | $\displaystyle-\sum\_{i\_{1},i\_{2},i\_{3}}N(z\_{i\_{1}},\xi\_{i\_{2}},Y\_{\mathrm{X},{i\_{3}}})+$ |  | (7) |
|  |  |  | $\displaystyle\sum\_{j}\ln N(z\_{j},\xi\_{j},Y\_{\mathrm{X},j}),$ |  |

where the $i\_{1},i\_{2},i\_{3}$ sums again run over all possible values and $j$ only runs over the bins where clusters were detected. Going to the continuous limit would result in a divergent likelihood expression. This can be understood by the fact that the model is increasingly unlikely to produce our particular realization of the cluster catalog as we go to finer binning. The divergence can be removed by simply adding $-\ln\Delta z\Delta\xi\Delta\mbox{$Y\_{\mathrm{X}}$}$ to Equation [7](#S5.Ex1 "In V.2. Cluster Likelihood Evaluation ‣ V. Cosmological Analysis ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). This quantity depends only on bin size, so that $\Delta\ln\mathcal{L}$ for different values of cosmological or scaling relation parameters remains meaningful. We then obtain the expression

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\ln\mathcal{L}$ | $\displaystyle=$ | $\displaystyle-\int dzd\xi d\mbox{$Y\_{\mathrm{X}}$}\frac{dN(z,\xi,Y\_{\mathrm{X}})}{dzd\xi d\mbox{$Y\_{\mathrm{X}}$}}+$ |  | (8) |
|  |  |  | $\displaystyle\sum\_{j}\ln\frac{dN(z\_{j},\xi\_{j},Y\_{\mathrm{X},j})}{dzd\xi d\mbox{$Y\_{\mathrm{X}}$}}.$ |  |

V10, B13, and R13 evaluated this expression on either a two-dimensional or three-dimensional uniformly spaced grid. Each dimension was gridded into several hundred points, such that the computational cost rises exponentially with the number of mass proxies. The computational cost was trivial for V10, challenging for B13 and R13, and likely untractable in future work if another mass proxy
is added. The techniques used in [Mantz et al. [52]](#bib.bib52) and [Vikhlinin et al. [90]](#bib.bib90) also scale exponentially with the number of mass proxies.

Instead of computing Equation [8](#S5.Ex2 "In V.2. Cluster Likelihood Evaluation ‣ V. Cosmological Analysis ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") on a uniformly spaced grid, we use the following numerical techniques. First, we note that the follow-up mass proxy $Y\_{\mathrm{X}}$ immediately integrates out of the first term. This applies to any mass proxy that does not affect the survey selection function. Therefore, we only need to perform a two-dimensional integral

|  |  |  |  |
| --- | --- | --- | --- |
|  | $-\int dzd\xi d\mbox{$Y\_{\mathrm{X}}$}\frac{dN(z,\xi,Y\_{\mathrm{X}})}{dzd\xi d\mbox{$Y\_{\mathrm{X}}$}}=-\int\_{z\_{\mathrm{cut}}}^{\infty}dz\int\_{\xi\_{\mathrm{cut}}}^{\infty}d\xi\frac{dN}{dzd\xi}.$ |  | (9) |

We evaluate this expression with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\int\_{z\_{\mathrm{cut}}}^{\infty}dz\int\_{\xi\_{\mathrm{cut}}}^{\infty}d\xi\frac{dN}{dzd\xi}\hskip 113.81102pt$ |  | (10) |
|  |  |  |
| --- | --- | --- |
|  | $\displaystyle=\int\_{z\_{\mathrm{cut}}}^{\infty}dz\int\_{0}^{\infty}dM\frac{dN}{dzdM}P(\xi>\xi\_{\mathrm{cut}}|M),$ |  |

where $P(\xi>\xi\_{\mathrm{cut}}|M)$ is simply the significance cut modelled through the scaling relation as described in §[II.1.1](#S2.SS1.SSS1 "II.1.1 SZ-Mass Scaling Relation Parameterization ‣ II.1. Sample of SZ Cluster Candidates ‣ II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey").

The second term of Equation [8](#S5.Ex2 "In V.2. Cluster Likelihood Evaluation ‣ V. Cosmological Analysis ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") is more challenging to evaluate. Employing a more compact notation with $\textbf{x}=\left[z,\xi,\mbox{$Y\_{\mathrm{X}}$}\right]$, we start by writing the expectation density as an integral over the mass function,

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{dN(\textbf{x}\_{j})}{d\textbf{x}}$ | $\displaystyle=$ | $\displaystyle\int d\textbf{x}^{\prime}\int d\ln M^{\prime}$ |  | (11) |
|  |  |  | $\displaystyle\prod\_{i}P(x\_{i,j}|x\_{i}^{\prime})P(\textbf{x}^{\prime}|z,\ln M^{\prime})\frac{dN}{dzd\ln M^{\prime}}.$ |  |

The probability density functions $P(x\_{i,j}|x\_{i}^{\prime})$ describe the measurement error of the $i^{\mathrm{th}}$ mass proxy (with the measurements being independent). The $P(\textbf{x}^{\prime}|z,\ln M^{\prime})$ describe the joint scaling relations, implemented with multi-dimensional log-normal intrinsic scatter. In our case of two mass proxies ($\xi$, $Y\_{\mathrm{X}}$), this is implemented with three parameters: two parameters describing the marginal variances and one correlation coefficient, each of which is marginalized over in this work.

The computational bottleneck for evaluating the cluster likelihood in the presence of several mass proxies lies in evaluating Equation [11](#S5.Ex4 "In V.2. Cluster Likelihood Evaluation ‣ V. Cosmological Analysis ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). Considering a slice in redshift, we have to perform an ($N\_{\mathrm{obs}}+1$)-dimensional integral. To do so, we perform Monte-Carlo integration, randomly sampling the mass function $\frac{dN}{d\ln M^{\prime}}$ with points drawn from the probability distribution $\prod\_{i}P(x\_{i,j}|x\_{i}^{\prime})P(\textbf{x}^{\prime}|\ln M^{\prime})$. Let $\ln\textbf{m}^{\prime}$ denote the integration variables corresponding to the nominal mass estimates (i.e. $\textbf{x}^{\prime}$ substituted into the observable-mass scaling relations). We can then write

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle P(\ln\textbf{m}^{\prime}|\ln M^{\prime})=\frac{1}{\sqrt{(2\pi)^{N\_{\mathrm{obs}}}|\Psi|}}\hskip 85.35826pt$ |  | (12) |
|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\exp\left(-\frac{1}{2}\left(\ln\textbf{m}^{\prime}-\ln M^{\prime}\right)^{\top}\Psi^{-1}\left(\ln\textbf{m}^{\prime}-\ln M^{\prime}\right)\right),$ |  |

where $\Psi$ is the mass proxy covariance matrix containing the intrinsic scatter and correlation coefficient parameters introduced in §[II.1.1](#S2.SS1.SSS1 "II.1.1 SZ-Mass Scaling Relation Parameterization ‣ II.1. Sample of SZ Cluster Candidates ‣ II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") and §[IV.1](#S4.SS1 "IV.1. 𝑌_X - 𝑀 Scaling Relation Parameterization ‣ IV. Chandra X-ray Dataset and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") such that $\Psi\_{kl}=\left\langle(\ln m\_{k}^{\prime}-\ln M^{\prime})(\ln m\_{l}^{\prime}-\ln M^{\prime})\right\rangle$.

Now, we wish to obtain samples of the integration variable $\ln M^{\prime}$, given the location at which we are attempting to evaluate $dN(\textbf{x}\_{j})/d\textbf{x}$. When the probabilities $P(x\_{i,j}|x\_{i}^{\prime})$ involved are Gaussian or log-normal, they are constructed to be correctly normalized. Due to the treatment of maximization bias in §[II.1.1](#S2.SS1.SSS1 "II.1.1 SZ-Mass Scaling Relation Parameterization ‣ II.1. Sample of SZ Cluster Candidates ‣ II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"), the normalization condition needs to be explicitly applied to the SZ scaling relation. This yields a factor of

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\int\exp\left(-\frac{1}{2}\left(\langle\xi\rangle-\zeta\right)^{2}\right)\frac{1}{\zeta}d\zeta,$ |  | (13) |

which we evaluate numerically using the trapezoid rule. In order to efficiently draw samples we first, for each $i$, draw samples from the measurement error $P(x\_{i,j}|x\_{i}^{\prime})$, which is assumed to be independent for each $i$. We then substitute these values into the scaling relations to obtain an ensemble of $\ln\textbf{m}^{\prime}$. The remaining task is then to draw random deviates $\ln M^{\prime}$ that follow the probability distribution explicitly shown in Equation [12](#S5.E12 "In V.2. Cluster Likelihood Evaluation ‣ V. Cosmological Analysis ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"), given each value of $\ln\textbf{m}^{\prime}$. To do so, we note that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{array}[]{l}\left(\ln\textbf{m}^{\prime}-\ln M^{\prime}\right)^{\top}\Psi^{-1}\left(\ln\textbf{m}^{\prime}-\ln M^{\prime}\right)\\ =\Sigma\_{ij}(\ln m^{\prime}\_{i}-\ln M^{\prime})(\ln m^{\prime}\_{j}-\ln M^{\prime})(\Psi^{-1})\_{ij}\\ =\Sigma\_{ij}\ln m^{\prime}\_{i}\ln m^{\prime}\_{j}(\Psi^{-1})\_{ij}\\ -2\ln M^{\prime}\Sigma\_{i}\ln m^{\prime}\_{i}\Sigma\_{j}(\Psi^{-1})\_{ij}+\ln M^{\prime 2}\Sigma\_{ij}(\Psi^{-1})\_{ij}\\ =T\_{0}-2T\_{1}\ln M^{\prime}+T\_{2}\ln M^{\prime 2}\\ =\left(\frac{\ln M^{\prime}-T\_{1}/T\_{2}}{1/\sqrt{T\_{2}}}\right)^{2}+T\_{0}-\frac{T\_{1}^{2}}{T\_{2}},\\ \end{array}$ |  | (14) |

where $T\_{0}=\Sigma\_{ij}\ln m^{\prime}\_{i}\ln m^{\prime}\_{j}(\Psi^{-1})\_{ij}$, $T\_{1}=\Sigma\_{i}\ln{m^{\prime}\_{i}}\Sigma\_{j}(\Psi^{-1})\_{ij}$, and $T\_{2}=\Sigma\_{ij}(\Psi^{-1})\_{ij}$,
which is quadratic in $\ln M^{\prime}$, such that Equation [12](#S5.E12 "In V.2. Cluster Likelihood Evaluation ‣ V. Cosmological Analysis ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") is a log-normal distribution in $M^{\prime}$ with a known mean, width and normalization. We compute $T\_{0}$, $T\_{1}$, and $T\_{2}$ explicitly and sample from the resulting distribution.

Having obtained samples of $\ln M^{\prime}$, which we denote as $\ln\tilde{M^{\prime}}$, we average the mass function

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{1}{N\_{\mathrm{samples}}}\sum\_{k}\left.\frac{dN}{d\ln M^{\prime}}\right|\_{\ln\tilde{M^{\prime}}\_{k}}\sqrt{\frac{T\_{2}}{2\pi}}\frac{\exp{-\frac{1}{2}\left(T\_{0}-\frac{T\_{1}^{2}}{T\_{2}}\right)}}{\sqrt{(2\pi)^{N\_{\mathrm{obs}}}|\Psi|}}$ |  | (15) |

and combine with Equation [14](#S5.E14 "In V.2. Cluster Likelihood Evaluation ‣ V. Cosmological Analysis ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") to obtain an estimate for Equation [11](#S5.Ex4 "In V.2. Cluster Likelihood Evaluation ‣ V. Cosmological Analysis ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). Our implementation of this estimator has been demonstrated to be unbiased through extensive simulations, with well-behaved residuals. The error on the mean is found to decrease as the inverse square root of the number of deviates drawn. In practice, for two mass proxies and 377  cluster candidates, we draw $10^{4}$ deviates per cluster candidate, resulting in RMS noise on the likelihood surface of $\Delta(-2\ln\mathcal{L})\lesssim 0.1$ near the maximum likelihood. For the cluster catalog used in this work, the execution time is approximately one second on a single CPU thread.
This likelihood module has been checked against an independent implementation, based on the estimator presented in [Bocquet et al. [18]](#bib.bib18). The comparison shows agreement to well within the 1-$\sigma$ uncertainties on the cosmological parameter constraints found in this work.

### V.3. External Datasets

In §[VI](#S6 "VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"), we will discuss the cosmological constraints obtained using the analysis laid out so far. We will evaluate the compatibility of the cluster data with other datasets, as well as show the improvements in parameter constraints when the cluster dataset is combined with other datasets. The primary external data we use are CMB power spectrum measurements, measurements of BAO from galaxy surveys, and distances to Type Ia supernovae (SNe).

The canonical CMB power spectrum data we use is the temperature-temperature power spectrum from the Planck  2013 release, combined with low-$\ell$ polarization information from WMAP  [[64](#bib.bib64), hereafter Planck+WP]. The qualitative results from this work will be very similar to those that would have been obtained by considering the Planck  2015 dataset, since the constraints on $\sigma\_{8}$ and $\Omega\_{m}$ from the temperature and low-$\ell$ polarization power spectrum are very similar between the two Planck  releases. In §[VI.2](#S6.SS2 "VI.2. ΛCDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"), we will briefly review the effect of substituting the best CMB power spectrum data from before the Planck  2013 release, using instead the combination of WMAP9 [[30](#bib.bib30)] and SPT [[83](#bib.bib83), hereafter S13] CMB power spectrum data.

We sometimes use a prior on the angular scale of the sound horizon $\theta\_{s}$. This is a powerful piece of cosmological information, and relies only very weakly on the details of the CMB analysis, since it is sensitive to peak positions. We use the Planck+WP measurement, though we conservatively increase the uncertainty by a factor of five to $100\theta\_{\mathrm{MC}}=1.0413\pm 0.0034$.33
3
$\theta\_{\mathrm{MC}}$ is the approximation to $\theta\_{s}$ used in CosmoMC [[48](#bib.bib48)]. Since $\theta\_{s}$ is so well-measured, none of the results presented in this work that use a prior on $\theta\_{s}$ are sensitive to the specific value of the assumed uncertainty.

When BAO data are used in this work, we use the SDSS-III BOSS results from data release 11. Specifically, we use the measurements of the parameter combination $D\_{V}/r\_{s}$ at $z=0.32$ (LOWZ) and $z=0.57$ (CMASS) from [Anderson et al. [3]](#bib.bib3).

When considering cosmologies with a free parameter describing the dark energy equation of state, we compare to and contrast with the SN results from the joint likelihood analysis of the SDSS-II and SNLS SN samples from [Betoule et al. [15]](#bib.bib15).

Cluster abundances do weakly constrain the baryon density, but for our main results we choose to
adopt a prior based on big-bang nucleosynthesis calculations and deuterium abundance measurements
of $\Omega\_{b}h^{2}=0.02202\pm 0.00045$ [[22](#bib.bib22)]. This uncertainty is subdominant for all
results presented in this work.

Finally, where stated, we adopt a prior of $H\_{0}=73.8\pm 2.4~\mathrm{km/s/Mpc}$ from the direct $H\_{0}$ measurements of [Riess et al. [71]](#bib.bib71). We find that changing this prior by $1\sigma$ affects the resulting $\sigma\_{8}$ constraint by $\lesssim 0.2\sigma$, while the $\Omega\_{m}$ constraint is affected by $\sim 0.4\sigma$. These two effects are anti-correlated such that the commonly used parameter combination $\sigma\_{8}\left(\Omega\_{m}/0.27\right)^{0.3}$ is highly insensitive to the assumed value of $H\_{0}$.

## VI. Cosmological Constraints

In this section, we discuss the parameter constraints obtained using the data and methods described in the
previous sections. We first explain which parameters and combinations of parameters are most strongly
constrained by cluster abundance measurements. We then discuss the constraints from this cluster sample,
both in comparison to and in combination with other cosmological datasets, for different choices of
cosmological models.
We assume spatial flatness throughout this work.

### VI.1. Parameter Sensitivity to Cluster Abundance

A measurement of cluster abundance as a function of redshift provides constraints on cosmological parameters through several mechanisms. First, the total number of clusters found strongly depends on the matter density and the amplitude of the matter power spectrum [[8](#bib.bib8), [94](#bib.bib94), e.g.,]. As shown in, e.g., [White et al. [94]](#bib.bib94), a simple
spherical-collapse model for the halo mass function [[67](#bib.bib67)] indicates that the total number of
clusters should most strongly constrain the parameter combination $\sigma\_{8}\Omega\_{m}^{\alpha}$,
where $\alpha$ is related to the local slope of the matter power spectrum at the mean mass of the cluster catalog.
This prediction has been empirically borne out in many cluster abundance studies, including this one.

The redshift dependence of the cluster abundance contains information on the growth function, as well as a dependence on the cosmic volume surveyed.
This combination of sensitivity to growth and volume provides a unique constraint on parameters that
affect the expansion history, notably $w$, the equation of state of dark energy [[28](#bib.bib28), e.g.,].
In the case of $w$, the effect of changing this parameter on the cluster abundance actually changes
sign at $z\sim 1$ [[58](#bib.bib58), e.g., Fig. 1 of].
The 377  cluster candidates presented in this work provide a large enough sample to constrain cosmological parameters by measuring the evolution of cluster abundance. However,
this constraint is also potentially limited by knowledge of the observable-mass scaling relations,
in this case their evolution with redshift.
This is further discussed in the context of dark energy in §[VI.5](#S6.SS5 "VI.5. 𝑤CDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey").

In addition to their effect on the true abundance of clusters as a function of mass and redshift, cosmological parameters
also affect the cluster observables through their influence on the SZ and X-ray scaling relations.
Specifically, while the mass estimate inferred from the $\zeta$ - $M$ relation depends weakly on redshift,
the mass estimate inferred from the $Y\_{\mathrm{X}}$ - $M$ scaling relation depends strongly on the angular diameter distance to the cluster.

### VI.2. $\Lambda$CDM

Figure 2.— Comparison of cluster constraints on $\sigma\_{8}$ and $\Omega\_{m}$  from this work with those from previous SPT publications. The B13 analysis (outermost, gray contours) used 18 clusters, 14 of which have *Chandra*  observations. The number of clusters increased to 100 in R13 (red contours), whereas this work uses 377  cluster candidates, 82  of which have high-quality *Chandra*  observations. If we adopt the same observable-mass priors as B13 and R13, we obtain the innermost, purple contours. However, the main results in this paper assume a new weak lensing-based prior on the
X-ray scaling relation normalization, which changes the central value by 10% and increases the 1$\sigma$ uncertainty slightly from 9% to 11%. The $\sigma\_{8}$-$\Omega\_{m}$  constraints using this prior and the current cluster data
are shown by the light-blue contours.

In this section, we present constraints on the parameters of the $\Lambda$CDM model.
Because not all parameters of this model are well constrained by cluster counts alone, we adopt
priors on some of the six parameters ($\Omega\_{b}h^{2}$, $\Omega\_{c}h^{2}$, $\theta\_{s}$, $n\_{s}$,
$A\_{s}$, and $\tau$, defined in §[V.1](#S5.SS1 "V.1. Parameters to Cluster Abundance Predictions ‣ V. Cosmological Analysis ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey")).
The cluster likelihood is insensitive to the optical depth to reionization $\tau$ as well as to the primordial scalar spectrum power law index $n\_{s}$, once an appropriate pivot point is chosen. Therefore, when discussing cluster constraints without the inclusion of CMB temperature power spectrum data, we fix these parameters to the best-fit values from [Planck Collaboration et al. [64]](#bib.bib64).

Figure 3.— Number density of clusters as a function of redshift (left panel) and of the SPT-SZ mass proxy $\xi$ (right panel). The data points show the measured abundance with $\sqrt{N}$ error bars. The grey bands show the $68\%$ and $95\%$ allowed model ranges after marginalizing over all cosmological and scaling relation parameters in the $\Lambda$CDM model with the SPT${}\_{\mbox{\scriptsize CL}}$+$H\_{0}$+BBN dataset. In the right hand panel, the $\xi$ axis is shown on a logarithmic scale and the abundance axis has been multiplied by three powers of $\xi$ in order to visualize the abundance over a range of $\xi$ values despite the extreme steepness of the measured mass function.

These two prior constraints, in addition to the $H\_{0}$ and BBN priors discussed in [V.3](#S5.SS3 "V.3. External Datasets ‣ V. Cosmological Analysis ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"),
leave us two remaining degrees of freedom in the $\Lambda$CDM model, which
we choose to express as $\Omega\_{m}$  and $\sigma\_{8}$ (though in exploring the likelihood surface we actually vary the base parameters $\Omega\_{b}h^{2}$, $\Omega\_{c}h^{2}$, $\ln 10^{10}A\_{s}$ and
$H\_{0}$).
We fix the species-summed neutrino mass $\Sigma m\_{\nu}$  to $0.06$ eV, the minimum allowed value from terrestrial measurements of squared neutrino mass differences [see e.g. [27](#bib.bib27), for a review].
Figure [2](#S6.F2 "Figure 2 ‣ VI.2. ΛCDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") shows the constraints on $\sigma\_{8}$ and $\Omega\_{m}$  from B13, R13 and this work. The large increase in the number of clusters primarily reduces the uncertainty on $\Omega\_{m}$  by constraining the shape of the halo mass function. The uncertainty on the parameter combination $\sigma\_{8}\left(\Omega\_{m}/0.27\right)^{0.3}$ is set by the knowledge of the overall mass scale, rather than the number of clusters, since Poisson errors on this number are subdominant. The improvement in the $\sigma\_{8}\left(\Omega\_{m}/0.27\right)^{0.3}$constraint results from the increase in the number of clusters with *Chandra* follow-up data. These two effects result in tighter
joint constraints on the two parameters than we obtained in previous cluster analyses, if we use the same prior
on the observable-mass relations.
This can be seen in Figure [2](#S6.F2 "Figure 2 ‣ VI.2. ΛCDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"): the innermost, purple contours use the
current cluster sample and the same observable-mass priors as B13 and R13.
However, in contrast to B13 and R13 we choose to use a weak lensing-based prior on the overall mass scale for our baseline results, as discussed in [IV.2](#S4.SS2 "IV.2. Prior on the Normalization of the 𝑌_X - 𝑀 Relation ‣ IV. Chandra X-ray Dataset and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). This results in slightly
degraded constraints, in particular on $\sigma\_{8}$, as can be seen from the light-blue contours in
Figure [2](#S6.F2 "Figure 2 ‣ VI.2. ΛCDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). With the current cluster sample, the stated priors on cosmological
parameters, and the updated priors on the observable-mass relations,
we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma\_{8}=0.784\pm 0.039,$ |  | (16) |

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Omega\_{m}=0.289\pm 0.042,$ |  | (17) |

and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma\_{8}\left(\Omega\_{m}/0.27\right)^{0.3}=0.797\pm 0.031.$ |  | (18) |

The $\Lambda$CDM parameter constraints, including scaling relation parameters, are shown in Table [3](#S6.T3 "Table 3 ‣ VI.2. ΛCDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey").

Table 3Constraints on cosmological and scaling relation parameters assuming a $\Lambda$CDM cosmology

| Parameter | Prior | SPT${}\_{\mbox{\scriptsize CL}}$+$H\_{0}$+BBN | SPT${}\_{\mbox{\scriptsize CL}}$+BAO+BBN | SPT${}\_{\mbox{\scriptsize CL}}$+Planck+WP+BAO |
| --- | --- | --- | --- | --- |
| $A\_{\mathrm{SZ}}$ | $5.38\pm 1.61$ | $4.842\pm 0.913$ | $4.936\pm 0.955$ | $3.531\pm 0.273$ |
| $B\_{\mathrm{SZ}}$ | $1.340\pm 0.268$ | $1.668\pm 0.083$ | $1.660\pm 0.064$ | $1.661\pm 0.060$ |
| $C\_{\mathrm{SZ}}$ | $0.49\pm 0.49$ | $0.550\pm 0.315$ | $0.864\pm 0.159$ | $0.733\pm 0.123$ |
| $\sigma\_{\ln\zeta}$ | $0.13\pm 0.13$ | $0.199\pm 0.069$ | $0.201\pm 0.070$ | $0.203\pm 0.066$ |
| $A\_{\mathrm{X}}$ | $6.38\pm 0.61$ | $6.235\pm 0.514$ | $6.316\pm 0.505$ | $7.030\pm 0.341$ |
| $B\_{\mathrm{X}}$ | $0.57\pm 0.03$ | $0.491\pm 0.023$ | $0.493\pm 0.023$ | $0.498\pm 0.021$ |
| $C\_{\mathrm{X}}$ | $-0.40\pm 0.20$ | $-0.251\pm 0.127$ | $-0.280\pm 0.122$ | $-0.174\pm 0.102$ |
| $\sigma\_{\ln\mathrm{Yx}}$ | $0.12\pm 0.08$ | $0.162\pm 0.070$ | $0.160\pm 0.069$ | $0.154\pm 0.064$ |
| $\rho\_{\zeta,\mathrm{Yx}}$ | $[-0.98,0.98]$ | $-0.147\pm 0.458$ | $-0.136\pm 0.465$ | $-0.204\pm 0.443$ |
| $\Omega\_{m}$ |  | $0.289\pm 0.042$ | $0.306\pm 0.010$ | $0.304\pm 0.007$ |
| $\sigma\_{8}$ |  | $0.784\pm 0.039$ | $0.768\pm 0.030$ | $0.820\pm 0.009$ |
| $\sigma\_{8}\left(\Omega\_{m}/0.27\right)^{0.3}$ |  | $0.797\pm 0.031$ | $0.797\pm 0.030$ | $0.850\pm 0.013$ |

In the left- and right-hand panels of Figure [3](#S6.F3 "Figure 3 ‣ VI.2. ΛCDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey")
we show the cluster abundance as a function of redshift and detection significance, respectively. Both show one-dimensional representations of the observable-space mass function. The data points, with approximate ($\sqrt{N}$) error bars shown, are independent of cosmological and scaling relation parameters. The points are independent between bins for $dN/d\xi$, and nearly independent for $dN/dz$, where clusters without spectroscopic redshift information can contribute to multiple bins.

Shifts in the parameters $\sigma\_{8}$ and $A\_{\mathrm{SZ}}$ result in roughly global shifts in the amplitude of both curves, simultaneously. The scaling relation parameter $B\_{\mathrm{SZ}}$ induces a roughly power-law tilt in $dN/d\xi$, and parameters such as $C\_{\mathrm{SZ}}$ and $\Omega\_{m}$  induce tilts in $dN/dz$. This visualization shows two important ways in which the model, marginalized over a large number of scaling relation and cosmological parameters, is tested for agreement with the data.

Figure 4.— Comparison of cluster constraints on $\sigma\_{8}$ and $\Omega\_{m}$  to constraints from primary CMB anisotropies, assuming a $\Lambda$CDM cosmology. The cluster constraints, when combined with either the $H\_{0}$ or BAO$+\theta\_{s}$ prior, are in agreement with the CMB datasets.

Figure [4](#S6.F4 "Figure 4 ‣ VI.2. ΛCDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") shows the cluster constraints on the $\Lambda$CDM model in
the $\sigma\_{8}$-$\Omega\_{m}$  plane, when combined with either the $H\_{0}$+BBN prior or the
BAO$+\theta\_{s}$+BBN prior. We also show the constraints from CMB power spectrum measurements from
Planck+WP and
WMAP9+S13 data.
The 68% confidence regions from the cluster constraints and the CMB power spectrum constraints overlap. We proceed to adopt the Planck+WP dataset as the baseline CMB dataset for the remainder of this work.
We also combine the SPT${}\_{\mbox{\scriptsize CL}}$+Planck+WP+BAO datasets to obtain joint $\Lambda$CDM parameter constraints.
Finally, we note that the $\sigma\_{8}$ constraint obtained using the SPT${}\_{\mbox{\scriptsize CL}}$ data in Table [3](#S6.T3 "Table 3 ‣ VI.2. ΛCDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey")
is within $1\sigma$ of the value recently reported by the Planck collaboration for the full-mission data (their 2015 TT+lowP+lensing dataset) of $\sigma\_{8}=0.815\pm 0.009$ .

#### VI.2.1 Constraints on Scaling Relation Parameters

While the main focus of this work is on the cosmological constraints, the nuisance parameters are of interest themselves, both in terms of the cluster scaling relation parameter constraints and their degeneracy with the cosmological parameters. In Figure [5](#S6.F5 "Figure 5 ‣ VI.2.1 Constraints on Scaling Relation Parameters ‣ VI.2. ΛCDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"), we show the marginalized posterior in the multi-dimensional parameter space.

Figure 5.— Contour triangle plot showing the degeneracies between scaling relation parameters and cosmological parameters. Parameters $\Omega\_{b}h^{2}$, $H\_{0}$, $n\_{s}$, $\sigma\_{\ln\mathrm{Yx}}$, and $\rho\_{\zeta,\mathrm{Yx}}$ are marginalized over and not shown since they are primarily constrained by priors, or by the Planck data. The cluster likelihood is nearly flat over the explored range of these parameters.

The dominant systematic uncertainty limiting the cosmological constraints from the SPT-SZ cluster sample is the uncertainty of the overall cluster mass scale. This can be seen as a strong degeneracy between $A\_{\mathrm{X}}$ and $\sigma\_{8}\left(\Omega\_{m}/0.27\right)^{0.3}$, which are $85\%$ correlated given the SPT${}\_{\mbox{\scriptsize CL}}$+$H\_{0}$+BBN dataset.
The second-most important source of systematic uncertainty in the cosmological constraints is from the parameter characterizing the redshift evolution of the scaling relation, $C\_{\mathrm{SZ}}$. In a $\Lambda$CDM cosmology, it is highly degenerate with $\Omega\_{m}$, correlated at 87% when considering the SPT${}\_{\mbox{\scriptsize CL}}$+$H\_{0}$+BBN dataset.

The parameters that shift most significantly away from their priors are the $B\_{\mathrm{SZ}}$ and $B\_{\mathrm{X}}$ parameters which encode the
power-law slopes of the scaling relations. We find that the preference for high $B\_{\mathrm{SZ}}$ persists when the X-ray data
are not used. In addition, this preference is not localized to any particular region of the data; when considering half the
cluster sample at a time, either by redshift, $\xi$, or $\gamma\_{\mathrm{field}}$, the high $B\_{\mathrm{SZ}}$ persists, albeit at a lower significance.

This high $B\_{\mathrm{SZ}}$ implies that the measured observable-space mass function, $dN/d\xi$, is shallower than expected given the
scaling relation found from the simulations described in §[II.2](#S2.SS2 "II.2. By-Field Simulations ‣ II. SZ Data and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey").
We can approximately quantify this by assuming $dN/d\xi$ follows a power law. The data
prefers a power-law index of $\sim 4.0$, compared to the simulation prediction of $\sim 5.0$, which
is disfavored by the measured $dN/d\xi$ at $\sim 4.5\sigma$.

The preference for a higher $B\_{\mathrm{SZ}}$, i.e., a steeper $\zeta$ - $M$ relation, is statistically weak, approximately $1\sigma$, due to the
relatively weak $20\%$ width assumed on the $B\_{\mathrm{SZ}}$ prior.
By contrast,
the assumed width of the prior on the X-ray scaling relation slope $B\_{\mathrm{X}}$ is $5\%$, leading to a tension
between the likelihood and the prior of approximately $4\sigma$. There is some evidence for a similarly
steep $Y\_{\mathrm{X}}$ - $M$ scaling relation from the comparison of the V09 and H15 weak lensing mass estimates in Figure [1](#S4.F1 "Figure 1 ‣ IV.2. Prior on the Normalization of the 𝑌_X - 𝑀 Relation ‣ IV. Chandra X-ray Dataset and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"),
which prefers $B\_{X}\sim 0.42$. Such a
slope would be in $\sim 4\sigma$ tension with the expected self-similar cluster slope of $B\_{\mathrm{X}}=0.6$.

In this work, we will assume that our observational priors on the $Y\_{\mathrm{X}}$ - $M$ slope and theoretical priors on the
mass function slope are well motivated, but note that the shape of the observable-space mass function will
need to be studied in more detail for future work.

### VI.3. $\Lambda$CDM + $\Sigma m\_{\nu}$

Figure 6.— Constraints on the species-summed neutrino mass. The addition of cluster constraints to either the Planck+WP or Planck+WP+BAO datasets has a similar effect: the posterior peaks at positive values, but remains consistent with zero.

We now consider a cosmological model in which the species-summed neutrino mass $\Sigma m\_{\nu}$ is a free parameter.
Constraints on this model from the CMB power spectrum show a strong degeneracy between $\sigma\_{8}$ and $\Sigma m\_{\nu}$ [[44](#bib.bib44), [64](#bib.bib64), [1](#bib.bib1), e.g.,].
This allows even modest measurements of $\sigma\_{8}$ to improve on neutrino mass constraints from the CMB power spectrum data alone.
Figure [6](#S6.F6 "Figure 6 ‣ VI.3. ΛCDM + Σ⁢𝑚_𝜈 ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey") shows the improvement in constraints when adding cluster abundance information
to CMB power spectrum data alone (Planck+WP), and also when including BAO data.
In both cases, the addition of cluster information tightens the constraint and
causes the posterior to peak at positive values of $\Sigma m\_{\nu}$, though the $95\%$ upper limit
on $\Sigma m\_{\nu}$ remains largely unchanged.
Allowing the $\Sigma m\_{\nu}$ to vary in the range of 0–2 eV, and using the combination of
the SPT${}\_{\mbox{\scriptsize CL}}$+Planck+WP+BAO datasets, we find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Sigma m\_{\nu}=0.14\pm 0.08\ \mathrm{eV}.$ |  | (19) |

We note that the preference for positive $\Sigma m\_{\nu}$, when we combine our cluster abundance measurements
with Planck data, is driven by the small residual tension between the preferred values of $\sigma\_{8}$ in
the two datasets. Such a preference has been pointed out by several authors [[65](#bib.bib65), [95](#bib.bib95), [11](#bib.bib11), e.g.,],
but is in contrast to the preference for positive $\Sigma m\_{\nu}$ shown, for example, by the combination of
WMAP+SPT CMB power spectrum data and SPT cluster data in [Hou et al. [37]](#bib.bib37), in which the
evidence for positive $\Sigma m\_{\nu}$ is not driven by the cluster data.
In this work, we find relatively good agreement between the preferred $\sigma\_{8}$ using
the CMB and SPT${}\_{\mbox{\scriptsize CL}}$ datasets, so the preference for positive $\Sigma m\_{\nu}$ is weak and
consistent at 1$\sigma$ with the minimum expected value of $\sim$0.06 eV from neutrino oscillation experiments
[[47](#bib.bib47)].
Relative to the previous cluster-based constraints cited above, the updated weak lensing-based calibration described in §[IV.2](#S4.SS2 "IV.2. Prior on the Normalization of the 𝑌_X - 𝑀 Relation ‣ IV. Chandra X-ray Dataset and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"),
has shifted the normalization and increased the uncertainty of the observable-mass relation in
a way that relieves tension with the Planck CMB data (see Figure [2](#S6.F2 "Figure 2 ‣ VI.2. ΛCDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey")).
We also note that our constraint on $\Sigma m\_{\nu}$ is largely independent of the change in the optical depth to reionization, $\tau$, between
the Planck 2013 and 2015 data release; the SPT${}\_{\mbox{\scriptsize CL}}$ constraints are independent of $\tau$, and
the Planck CMB constraints on $\sigma\_{8}$ and $\Omega\_{m}$ negligibly changed between the two data releases.

### VI.4. $\Lambda$CDM + $\Sigma m\_{\nu}$ + $N\_{\mathrm{eff}}$

Figure 7.— Simultaneous constraints on the effective number of relativistic species and the species-summed neutrino mass. The addition of the SPT cluster data reduces the allowed parameter space.

The effective number of relativistic species, $N\_{\mathrm{eff}}$, affects the CMB power spectrum by altering the time of matter-radiation equality, changing the apparent
sound horizon at recombination [[36](#bib.bib36), e.g.,]. This mechanism results in strong degeneracies between $N\_{\mathrm{eff}}$ and other cosmological parameters, notably $H\_{0}$ and $\sigma\_{8}$, when considering CMB data alone [[9](#bib.bib9), e.g.,].
Thus, the addition of constraints on $\sigma\_{8}$—such as from the cluster data in this work—and $H\_{0}$ can improve upon CMB-only constraints on $N\_{\mathrm{eff}}$.

Here, we
consider simultaneously varying the species-summed neutrino mass and the effective number of relativistic species. In this cosmological model, the
Planck+WP data alone constrain the $\sigma\_{8}$-$\Omega\_{m}$-$H\_{0}$ parameter volume relatively poorly.
Adding the cluster information improves on all three of those parameters by roughly a factor of two. Through parameter degeneracies, this improves the simultaneous constraints on $N\_{\mathrm{eff}}$  and $\Sigma m\_{\nu}$  as shown in Figure [7](#S6.F7 "Figure 7 ‣ VI.4. ΛCDM + Σ⁢𝑚_𝜈 + 𝑁_eff ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). The simultaneous constraints are

|  |  |  |  |
| --- | --- | --- | --- |
|  | $N\_{\mathrm{eff}}=3.25\pm 0.23$ |  | (20) |

and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Sigma m\_{\nu}=0.39\pm 0.20~\mathrm{eV},$ |  | (21) |

factors of $1.3$ and $1.6$ respective improvement over the Planck+WP data alone.

Adding BAO data reduces the remaining allowed parameter space significantly to $N\_{\mathrm{eff}}=3.28\pm 0.20$ and $\Sigma m\_{\nu}=0.18\pm 0.09$, and results in a degeneracy between $N\_{\mathrm{eff}}$ and $\Sigma m\_{\nu}$, allowing for larger values of $N\_{\mathrm{eff}}$ for increasing $\Sigma m\_{\nu}$.
These constraints can be further tightened with the addition of local $H\_{0}$ measurements, with the caveat that the best-fit value of $H\_{0}$ from the SPT${}\_{\mbox{\scriptsize CL}}$+Planck+WP+BAO dataset,
$H\_{0}=68.6\pm 1.2~\mathrm{km/s/Mpc}$, is in mild tension with direct local measurements from [Riess et al. [71]](#bib.bib71). Proceeding to add those local measurements, such that we
consider a SPT${}\_{\mbox{\scriptsize CL}}$+Planck+WP+$H\_{0}$+BAO dataset, we find a preference for larger $N\_{\mathrm{eff}}$, resulting in the marginalized constraints of

|  |  |  |  |
| --- | --- | --- | --- |
|  | $N\_{\mathrm{eff}}=3.43\pm 0.16$ |  | (22) |

and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Sigma m\_{\nu}=0.16\pm 0.08~\mathrm{eV}.$ |  | (23) |

The combined dataset has a $2.3\sigma$ preference for $N\_{\mathrm{eff}}>3.046$, the standard model prediction. This is partially
driven by the weak tension between local $H\_{0}$ measurements and the Planck+BAO dataset, as has been noted by other
authors [[37](#bib.bib37), [95](#bib.bib95), [11](#bib.bib11), e.g.,]. However, the sensitivity to the $H\_{0}$ prior is relatively weak. The preference for $N\_{\mathrm{eff}}$ exceeding the standard model prediction would still be $2.0\sigma$ if the central value of the $H\_{0}$ prior was reduced by one standard deviation.

### VI.5. $w$CDM

Figure 8.— Comparison of different cosmological probes of dark energy. The countours show the simultaneous constraints on the present day density of dark energy $\Omega\_{\mathrm{DE}}=1-\Omega\_{m}$ and the dark energy equation of state parameter $w$. Using priors on $H\_{0}$ and $\Omega\_{b}h^{2}$, the SPT cluster data are able to simultaneously constrain the two parameters, and are in good agreement with the other probes. The other probes are sensitive to dark energy primarily through its effect on the geometry of the universe.

With the increased number of clusters in this work we are able to place constraints not only on the local cluster abundance but also on the evolution of cluster abundance with redshift.
In particular, we examine the constraints on the $w$CDM cosmology, where the equation of state of dark energy $w$ is a free parameter. We assume that $w$ is a constant (i.e., its value does not evolve with redshift). This additional parameter affects the cluster abundance and observables through its influence on
the geometry of the universe and, more importantly, the growth of structure.
The geometrical effects include the change in the survey volume element and the angular diameter distance that modifies the implied X-ray mass information. However, in contrast to other probes of dark energy, the cluster abundance measurement is
very sensitive to the effect of $w$ on the growth of structure, primarily $\sigma\_{8}(z)$ [[93](#bib.bib93), [28](#bib.bib28), e.g.,].

In Figure [8](#S6.F8 "Figure 8 ‣ VI.5. 𝑤CDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"), we show constraints on the dark energy equation of state parameter $w$ and the energy density of dark energy today $\Omega\_{\mathrm{DE}}$ for different cosmological probes. With the SPT${}\_{\mbox{\scriptsize CL}}$+$H\_{0}$+BBN dataset, we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $w=-1.28\pm 0.31$ |  | (24) |

and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Omega\_{\mathrm{DE}}=0.738\pm 0.046.$ |  | (25) |

This is in good agreement, and of comparable precision, with the constraints when considering other
cosmological probes, including Planck+WP, BAO, and SNe, as can be seen in Figure [8](#S6.F8 "Figure 8 ‣ VI.5. 𝑤CDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey").
Since all these probes except the cluster abundance measurement are geometrical tests in this plane, the consistency between the
cluster-implied parameter constraints, and those from other datasets, offers an important systematic test of dark energy.
This measurement is limited primarily by our knowledge of the redshift evolution of the $\zeta$ - $M$ scaling relation, $C\_{\mathrm{SZ}}$.
Specifically, both $\Omega\_{m}$  and $w$ are correlated with $C\_{\mathrm{SZ}}$ at the $\sim 60\%$ level, whereas the correlation
with $A\_{\mathrm{X}}$ is only $\sim 30\%$.

Figure 9.— Combined constraints on $w$ and $\sigma\_{8}$. The CMB power spectrum data from Planck+WP shows a strong degeneracy, while the purely geometric constraints from $H\_{0}$+BAO+SNe do not constrain $\sigma\_{8}$. The cluster data simultaneously constrains the two parameters, improving the joint CMB+$H\_{0}$+BAO+SNe constraints both through breaking the $w$-$\sigma\_{8}$ degeneracy present in the CMB constraints, and the direct measurement of $w$.

As shown in Figure [9](#S6.F9 "Figure 9 ‣ VI.5. 𝑤CDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"), the Planck+WP measurements of the primary CMB show a strong degeneracy between $w$ and $\sigma\_{8}$. The addition of cluster data breaks the degeneracy and results in the marginalized constraints

|  |  |  |  |
| --- | --- | --- | --- |
|  | $w=-1.04\pm 0.17$ |  | (26) |

and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma\_{8}=0.803\pm 0.045.$ |  | (27) |

This level of $w$-uncertainty is $\sim$2.5 times larger compared to the constraints when adding either of the
BAO or SNe data sets to the Planck+WP measurements [[6](#bib.bib6), [15](#bib.bib15)].

For the dataset combination $H\_{0}$+BAO+SNe, which does not include primary CMB data, $\sigma\_{8}$ is not determined. Adding the cluster data improves the $w$ constraint by $37\%$ through a direct measurement of the dark energy parameters $w$ and $\Omega\_{\mathrm{DE}}$, rather than by breaking the $w$-$\sigma\_{8}$ degeneracy. For this combination, we find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $w=-1.08\pm 0.07.$ |  | (28) |

Finally, when considering the Planck+WP+$H\_{0}$+BAO+SNe datasets, $w$ is constrained to $-1.062\pm 0.048$. The allowed parameter space shows a significant $w$-$\sigma\_{8}$ degeneracy, which allows the addition of the cluster data to improve this constraint by $14\%$, to

|  |  |  |  |
| --- | --- | --- | --- |
|  | $w=-1.023\pm 0.042,$ |  | (29) |

consistent with $\Lambda$CDM where $w=-1$.

## VII. Comparison to Other Cluster Surveys

In this section, we compare the SPT${}\_{\mbox{\scriptsize CL}}$ cosmological constraints to results using other cluster surveys.
We focus on the $\Lambda$CDM constraints from §[VI.2](#S6.SS2 "VI.2. ΛCDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"), which employed a SPT${}\_{\mbox{\scriptsize CL}}$+$H\_{0}$+BBN dataset, and where
we constrained $\sigma\_{8}\left(\Omega\_{m}/0.27\right)^{0.3}=0.797\pm 0.031$ and $\sigma\_{8}=0.784\pm 0.039$. When comparing to other results, we will discuss
differences where appropriate.

Other SZ cluster-based constraints include results from the Atacama Cosmology Telescope [[29](#bib.bib29), ACT,]
and Planck [[65](#bib.bib65), [66](#bib.bib66)] cluster surveys. However,
comparisons to both are complicated by differences in the assumed mass calibration. In [Hasselfield et al. [29]](#bib.bib29), the ACT collaboration reported
cosmological constraints using 15 SZ-selected clusters between $0.2<z<1.4$. Several sets of constraints were presented, which assumed
different priors on the SZ-scaling parameters and also included a calibration based on the dynamical mass measurements from [Sifón et al. [79]](#bib.bib79). The latter relied on a
scaling relation between velocity dispersion and cluster mass, which was later found to be biased high by $\sim$20% when using more recent simulations [[43](#bib.bib43)].
Using a fixed SZ-scaling relation based on the simulations from [Battaglia et al. [10]](#bib.bib10) i.e., without including any uncertainty in the
cluster mass calibration, the ACT${}\_{\mbox{\scriptsize CL}}$+$H\_{0}$+BBN dataset was used to constrain $\sigma\_{8}\left(\Omega\_{m}/0.27\right)^{0.3}=0.848\pm 0.032$ and $\sigma\_{8}=0.872\pm 0.065$, consistent with the constraints presented in this work.

The Planck collaboration has produced two cluster-based cosmological analyses [[65](#bib.bib65), [66](#bib.bib66)].
[Planck Collaboration et al. [65]](#bib.bib65) used a sample of 189 SZ-selected clusters between $0.0<z<0.55$ with a median redshift
of 0.15, which is lower redshift than the SPT cluster sample due to the Planck selection function. Assuming an
identical $H\_{0}$+BBN dataset to our work and assuming a fixed scaling relation except for an overall mass-bias
factor $b$ with a uniform prior between 0.7 and 1.0, they constrained $\sigma\_{8}\left(\Omega\_{m}/0.27\right)^{0.3}=0.774\pm 0.024$ and $\sigma\_{8}=0.77\pm 0.03$,
consistent with our results.
In [Planck Collaboration et al. [66]](#bib.bib66), the previous scaling relation calibration was compared to more recent weak lensing
measurements (H15, WtG), which are also used in this work. For example, H15 found a mass-bias factor of $0.76\pm 0.08$ for the Planck clusters in their lensing sample.
While no numerical constraints were given,
the newer Planck constraints were found to be consistent with the previous Planck results, and are also visually in good
agreement with our results using this mass-bias factor.

Figure 10.— Comparison of the constraints on $\sigma\_{8}$ and $\Omega\_{m}$  from this work, Weighing the Giants (WtG), and Planck+WP CMB measurements. We also show the results from this work after adding the approximate parameter constraints from the $f\_{\mathrm{gas}}$ analysis of [Mantz et al. [53]](#bib.bib53) for a more direct comparison to the WtG cluster constraints.

In addition, our cosmological constraints are consistent with other previous cluster surveys, including constraints from the
X-ray selected sample from [Vikhlinin et al. [90]](#bib.bib90) and the optically selected sample from [Rozo et al. [72]](#bib.bib72).

Finally, we compare to more recent cosmological constraints
from WtG [[54](#bib.bib54)].
Their baseline constraints incorporate
a cluster sample selected from the ROSAT All-Sky Survey (RASS),
follow-up X-ray observations from *Chandra*, including
cosmological constraints from cluster gas-fraction [[53](#bib.bib53), $f\_{\mathrm{gas}}$, see] measurements, and weak lensing data from WtG; a
sub-set of which we used to estimate our cluster mass calibration in Section [IV.2](#S4.SS2 "IV.2. Prior on the Normalization of the 𝑌_X - 𝑀 Relation ‣ IV. Chandra X-ray Dataset and Methods ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). In Figure [10](#S7.F10 "Figure 10 ‣ VII. Comparison to Other Cluster Surveys ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"),
we compare directly to the WtG constraints in the $\sigma\_{8}$-$\Omega\_{m}$ plane (WtG find
marginalized constraints of $\sigma\_{8}=0.830\pm 0.035$ and $\Omega\_{m}=0.259\pm 0.030$). We also plot the SPT${}\_{\mbox{\scriptsize CL}}$ constraints
with an additional prior of $\Omega\_{b}/\Omega\_{m}h^{1.5}=0.089\pm 0.012$, to mimic the
$f\_{\mathrm{gas}}$ constraints.

Overall, we find good agreement between our SPT${}\_{\mbox{\scriptsize CL}}$ dataset and both the Planck-CMB and WtG data.
The agreement between
the WtG and SPT${}\_{\mbox{\scriptsize CL}}$ constraints is impressive considering the different selection
methods (SZ vs. X-ray), the different
X-ray observable ($Y\_{\mathrm{X}}$ vs. gas mass) and corresponding observable-mass
scaling relation, as well as
the independent X-ray analysis pipelines.
This agreement extends to the $w$CDM cosmological model. For example, using the WtG cluster data
(including $f\_{\mathrm{gas}}$ measurements), [Mantz et al. [54]](#bib.bib54) constrain $w=-0.98\pm 0.15$, consistent with the
results in Section [VI.5](#S6.SS5 "VI.5. 𝑤CDM ‣ VI. Cosmological Constraints ‣ Cosmological Constraints from Galaxy Clusters in the 2500 square-degree SPT-SZ Survey"). The combination of the two cluster datasets is
potentially very powerful for improving cluster-based constraints due to the different redshift ranges of each sample; the
majority of the WtG sample is at $z<0.25$, below the lower redshift cut of the SPT${}\_{\mbox{\scriptsize CL}}$ sample used in this work. This is
particularly important for cluster-based constraints on dark energy because the combined data sets would provide
improved constraints on the evolution of the cluster mass function. This complementarity
was also noted in [Mantz et al. [54]](#bib.bib54), who estimated that the combined datasets could improve the WtG cluster-based
constraints on dark energy and modified gravity by a factor of $>$2.

## VIII. Conclusion

In this work, we have taken a well-defined subsample of the SPT cluster catalog from [Bleem et al. [17]](#bib.bib17), selecting only for redshift $z>0.25$ and SPT-SZ detection significance $\xi>5$.
In order to obtain cosmological constraints, we combine this cluster catalog with
*Chandra* X-ray observations for 82 clusters. In addition, we adopt a purely
weak lensing-based prior on the overall mass scale of the sample from a reanalysis
of [Vikhlinin et al. [90]](#bib.bib90) using the more recent weak lensing mass
estimates from [Hoekstra et al. [32, denoted with H15]](#bib.bib32) and the Weighing the Giants
(WtG) project [[42](#bib.bib42), [5](#bib.bib5), [91](#bib.bib91), [54](#bib.bib54)]. The 1$\sigma$ width of
this prior is 10%, which is limited by the small number of clusters in the reanalysis.

The computation of the cluster likelihood uses a new algorithm that scales linearly with the number of mass proxies, where previous algorithms scaled exponentially, which makes incorporating more mass proxies such as weak lensing shear, velocity dispersions, and/or multiple X-ray mass proxies computationally tractable. Our algorithm includes the option to marginalize over all possible correlations between the observables.

Assuming a $\Lambda$CDM cosmology and combining with $H\_{0}$+BBN, we find the marginalized constraints $\sigma\_{8}=0.784\pm 0.039$ and $\Omega\_{m}=0.289\pm 0.042$. The combined parameter combination $\sigma\_{8}\left(\Omega\_{m}/0.27\right)^{0.3}$ is constrained to $0.797\pm 0.031$. We find good agreement with the parameter constraints obtained from the WtG project, as well as CMB constraints from either WMAP9+S13 [[30](#bib.bib30), [83](#bib.bib83)] or Planck+WP [[64](#bib.bib64)]. We proceed to adopt Planck+WP as our baseline CMB dataset.

We consider several extensions to the $\Lambda$CDM model. When we allow the species-summed neutrino mass to be a free parameter, the addition of cluster information to CMB information causes the posterior to peak at positive values of neutrino mass (though it is consistent with zero). The same behavior is seen when combining with CMB+BAO, yielding $\Sigma m\_{\nu}=0.14\pm 0.08~\mathrm{eV}$.
When further allowing the effective number of relativistic species $N\_{\mathrm{eff}}$ to be a free parameter, and combining with CMB+$H\_{0}$+BAO, we find $N\_{\mathrm{eff}}=3.43\pm 0.16$ and $\Sigma m\_{\nu}=0.16\pm 0.08~\mathrm{eV}$.

Finally, when the dark energy equation of state parameter $w$ is allowed to be free, this cluster catalog can be combined only with priors on $H\_{0}$ and $\Omega\_{b}h^{2}$ to measure $w=-1.28\pm 0.31$, showing good consistency with the $\Lambda$CDM cosmological model. Adding the cluster data to CMB+$H\_{0}$+BAO+SNe improves the $w$ constraint to $w=-1.023\pm 0.042$.

The full cosmological power of the 2500 square-degree SPT-SZ cluster survey has not
yet been realized. A joint analysis of the WtG and SPT-SZ cluster samples is currently
being performed. In addition, weak-lensing observations of SPT-SZ
discovered clusters themselves
are currently being analyzed and are expected to improve on the 10% mass normalization
uncertainty in this paper, in turn sharpening the cosmological constraints. Especially
important is accurate knowledge of the mass scale over a range of redshifts, which would
specifically improve constraints on models of dark energy or modified gravity.

The SPT is presently reobserving a 500 square degree patch of the SPT-SZ survey area with the polarization-sensitive receiver SPTpol [[7](#bib.bib7)].
While the primary science goals are related to polarization, the greater map depth allows for a lower cluster mass threshold, therefore extending the survey out to higher redshift. The next receiver, SPT-3G [[13](#bib.bib13)], is currently being built and will allow for significant progress in the SPT cluster program.
The SPT-3G receiver will have a mapping speed $\sim$20 times higher than SPTpol, which should yield $\sim$5000 cluster detections and, importantly, allow cluster mass calibration through CMB-cluster lensing [[77](#bib.bib77), [57](#bib.bib57), [12](#bib.bib12), e.g.,].

The South Pole Telescope is supported by the National Science Foundation through grant PLR-1248097. Partial support is also provided by the NSF Physics
Frontier Center grant PHY-1125897 to the Kavli Institute of Cosmological Physics at the University of Chicago, the Kavli Foundation and the Gordon and
Betty Moore Foundation grant GBMF 947. This work used resources of McGill University’s High Performance Computing centre, a part of Compute Canada. This work was supported in part by the Kavli Institute for Cosmological Physics at the University of Chicago through grant NSF PHY-1125897 and an endowment from the Kavli Foundation and its founder Fred Kavli. This work was supported in part by the US Department of Energy under contract number DE-AC02-76SF00515. The McGill group acknowledges funding from the National Sciences and Engineering Research Council of Canada, Canada Research Chairs program, and the Canadian Institute for Advanced Research. T. de Haan is supported by a Miller Research Fellowship, as well as receiving support from a Natural Science and Engineering Research Council of Canada Postgraduate Scholarship-Doctoral award.
BB is supported by the Fermi Research Alliance, LLC under Contract No. De-AC02-07CH11359 with the United States Department of Energy.
Argonne National Laboratory’s work was supported under U.S. Department of Energy contract DE-AC02-06CH11357.
D. Applegate and T. Schrabback acknowledge support from the German Federal Ministry of Economics and Technology (BMWi) provided through DLR under projects 50 OR 1210 and 50 OR 1407. R.J.F. gratefully acknowledges support from the Alfred P. Sloan Foundation.
CR acknowledges support from the University of Melbourne and from the Australian Research Council’s Discovery Projects scheme (DP150103208).
JHL is supported by NSERC through the discovery grant and Canada Research Chair programs, as well as FRQNT.
The Munich group acknowledges the support of the DFG Cluster of Excellence “Origin and Structure of the Universe” and the Transregio program TR33 “The Dark Universe”.
The Dark Cosmology Centre is funded by the Danish National Research Foundation.
Optical and infrared followup of SPT Clusters at the Harvard-Smithsonian Center for Astrophysics was supported by NSF grant ANT-1009649.
