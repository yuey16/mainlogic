<!-- fulltext source=arxiv_html slug=arXiv-1411.1074 fetched=2026-09-18T00:58:29+00:00 -->

# Cosmological implications of baryon acoustic oscillation (BAO) measurements

Éric Aubourg1
  
Stephen Bailey2
  
Julian E. Bautista1
  
Florian Beutler2
  
Vaishali Bhardwaj3,2
  
Dmitry Bizyaev4
  
Michael Blanton5
  
Michael Blomqvist6
  
Adam S. Bolton7
  
Jo Bovy8
  
Howard Brewington4
  
J. Brinkmann4
  
Joel R. Brownstein7
  
Angela Burden9
  
Nicolás G. Busca1,10,11
  
William Carithers2
  
Chia-Hsun Chuang12
  
Johan Comparat12
  
Rupert A.C. Croft13,14
  
Antonio J. Cuesta15,16
  
Kyle S. Dawson7
  
Timothée Delubac17
  
Daniel J. Eisenstein18
  
Andreu Font-Ribera2
  
Jian Ge19
  
J.-M. Le Goff20
  
Satya Gontcho A Gontcho16
  
J. Richard Gott, III21
  
James E. Gunn21
  
Hong Guo22,7
  
Julien Guy23,2
  
Jean-Christophe Hamilton1
  
Shirley Ho13
  
Klaus Honscheid24,25
  
Cullan Howlett9
  
David Kirkby6
  
Francisco S. Kitaura26
  
Jean-Paul Kneib17,27
  
Khee-Gan Lee28
  
Dan Long4
  
Robert H. Lupton21
  
Mariana Vargas Magaña1
  
Viktor Malanushenko4
  
Elena Malanushenko4
  
Marc Manera9,29
  
Claudia Maraston9
  
Daniel Margala6
  
Cameron K. McBride18
  
Jordi Miralda-Escudé30,16
  
Adam D. Myers31
  
Robert C. Nichol9
  
Pasquier Noterdaeme32
  
Sebastián E. Nuza26
  
Matthew D. Olmstead7
  
Daniel Oravetz4
  
Isabelle Pâris33
  
Nikhil Padmanabhan15
  
Nathalie Palanque-Delabrouille2,20
  
Kaike Pan4
  
Marcos Pellejero-Ibanez34,35
  
Will J. Percival9
  
Patrick Petitjean32
  
Matthew M. Pieri36
  
Francisco Prada12,37,38
  
Beth Reid2,39
  
James Rich20
  
Natalie A. Roe2
  
Ashley J. Ross9,25
  
Nicholas P. Ross40
  
Graziano Rossi41,20
  
Jose Alberto Rubiño-Martín34,35
  
Ariel G. Sánchez42
  
Lado Samushia43,44
  
Ricardo Tanausú Génova Santos34
  
Claudia G. Scóccola12,34,45
  
David J. Schlegel2
  
Donald P. Schneider46,47
  
Hee-Jong Seo25,48
  
Erin Sheldon49
  
Audrey Simmons4
  
Ramin A. Skibba50
  
Anže Slosar49
  
Michael A. Strauss21
  
Daniel Thomas9
  
Jeremy L. Tinker5
  
Rita Tojeiro9
  
Jose Alberto Vazquez49
  
Matteo Viel33,51
  
David A. Wake52,53
  
Benjamin A. Weaver5
  
David H. Weinberg25,54
  
W. M. Wood-Vasey55
  
Christophe Yèche20
  
Idit Zehavi56
  
Gong-Bo Zhao57,9

August 24, 2026. Authors’ institutions can be found in Appendix A.

###### Abstract

We derive constraints on cosmological parameters and tests of dark
energy models from the combination of baryon acoustic oscillation
(BAO) measurements with cosmic microwave background (CMB) data and a
recent reanalysis of Type Ia supernova (SN) data. In particular, we
take advantage of high-precision BAO measurements from galaxy
clustering and the Lyman-$\alpha$ forest (LyaF) in the SDSS-III
Baryon Oscillation Spectroscopic Survey (BOSS). Treating the BAO
scale as an uncalibrated standard ruler, BAO data alone yield a high
confidence detection of dark energy; in combination with the CMB
angular acoustic scale they further imply a nearly flat
universe. Adding the CMB-calibrated physical scale of the sound
horizon, the combination of BAO and SN data into an “inverse
distance ladder” yields a measurement of $H\_{0}=67.3\pm 1.1\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$,
with 1.7% precision. This measurement assumes standard
pre-recombination physics but is insensitive to assumptions about
dark energy or space curvature, so agreement with CMB-based
estimates that assume a flat $\Lambda$CDM cosmology is an important
corroboration of this minimal cosmological model. For constant dark
energy ($\Lambda$), our BAO+SN+CMB combination yields matter density
$\Omega\_{m}=0.301\pm 0.008$ and curvature $\Omega\_{k}=-0.003\pm 0.003$. When we allow more general forms of evolving dark energy,
the BAO+SN+CMB parameter constraints are always consistent with flat
$\Lambda$CDM values at $\approx 1\sigma$. While the overall $\chi^{2}$ of
model fits is satisfactory, the LyaF BAO measurements are in
moderate ($2-2.5\sigma$) tension with model predictions. Models
with early dark energy that tracks the dominant energy component at
high redshift remain consistent with our expansion history
constraints, and they yield a higher $H\_{0}$ and lower matter
clustering amplitude, improving agreement with some low redshift
observations. Expansion history alone yields an upper limit on
the summed mass of neutrino species, $\sum m\_{\nu}<0.56\,{\rm eV}$ (95%
confidence), improving to $\sum m\_{\nu}<0.25\,{\rm eV}$ if we include the
lensing signal in the Planck CMB power spectrum. In a flat $\Lambda$CDM model that allows extra relativistic species, our data combination
yields $N\_{\rm eff}=3.43\pm 0.26$; while the LyaF BAO data prefer
higher $N\_{\rm eff}$ when excluding galaxy BAO, the galaxy BAO alone
favor $N\_{\rm eff}\approx 3$. When structure growth is
extrapolated forward from the CMB to low redshift, standard dark
energy models constrained by our data predict a level of matter
clustering that is high compared to most, but not all, observational
estimates.

## I Introduction

Acoustic oscillations that propagate in the pre-recombination universe imprint a
characteristic scale in the clustering of matter, providing a cosmological
“standard ruler” that can be measured in the power spectrum of cosmic
microwave background (CMB) anisotropies
and in maps of large-scale structure at lower
redshifts [[1](#bib.bib1), [2](#bib.bib2), [3](#bib.bib3), [4](#bib.bib4), [5](#bib.bib5)]. While distance
scale measurements with Type Ia supernovae (SNIa) are calibrated against
systems in the local Hubble flow [[6](#bib.bib6), [7](#bib.bib7), [8](#bib.bib8)], the baryon
acoustic oscillation (BAO) scale is computed from first principles, using
physical parameters (such as the radiation, matter, and baryon densities) that
are well constrained by CMB data. The difference between absolute and relative
measurements, the sharpening of BAO precision with increasing redshift, and the
entirely independent systematic uncertainties make BAO and SNe highly
complementary tools for measuring the cosmic expansion history and testing dark
energy models. In spectroscopic surveys, BAO measurements in the line-of-sight
dimension allow direct determinations of the expansion rate $H(z)$, in addition
to the constraints from transverse clustering on the comoving angular diameter
distance $D\_{M}(z)\propto\int\_{0}^{z}cH^{-1}(z)dz$ in a flat spatial
metric.11
1
We use the notation $D\_{M}(z)$ to
refer to the comoving angular diameter distance, which is also referred to in
the literature as the proper motion distance [[9](#bib.bib9)]. This notation
avoids confusion with the proper angular diameter distance
$D\_{A}(z)=D\_{M}(z)/(1+z)$.

The first clear detections of low-redshift BAO
[[10](#bib.bib10), [11](#bib.bib11)] came from galaxy clustering analyses of the
Two Degree Field Galaxy Redshift Survey (2dFGRS, [[12](#bib.bib12)]) and
the luminous red galaxy (LRG, [[13](#bib.bib13)]) sample of the Sloan
Digital Sky Survey (SDSS, [[14](#bib.bib14)]). Analyses of the final
2dFGRS and SDSS-II redshift surveys yielded BAO distance measurements
with aggregate precision of 2.7% at $z\approx 0.275$
[[15](#bib.bib15)], subsequently sharpened to 1.9%
[[16](#bib.bib16)] by application of reconstruction methods
[[17](#bib.bib17)] that suppress non-linear degradation of the BAO
feature. The WiggleZ survey [[18](#bib.bib18)] pushed BAO
measurements to higher redshifts, achieving 3.8% aggregate precision
from galaxies in the redshift range $0.4<z<1.0$ [[19](#bib.bib19)].
The Six Degree Field Galaxy Survey (6dFGS, [[20](#bib.bib20)]) took
advantage of its 17,000 deg2 sky coverage to provide a BAO
measurement at low redshift, achieving 4.5% precision at $z=0.1$
[[21](#bib.bib21)]. A recent reanalysis that applies reconstruction to
the main galaxy sample [[22](#bib.bib22)] of SDSS-II obtained 3.8%
precision at $z=0.15$ [[23](#bib.bib23)], in a sky area that has
minimal ($<3\%$) overlap with 6dFGS.

The Baryon Oscillation Spectroscopic Survey
(BOSS, [[24](#bib.bib24)])
of SDSS-III [[25](#bib.bib25)] has two defining objectives:
to measure the BAO distance scale with one-percent precision from a
redshift survey of 1.5 million luminous galaxies at $z=0.2-0.7$,
and to make the first BAO measurement at $z>2$ using 3-dimensional
structure in the Ly$\alpha$ forest absorption towards a dense grid of 160,000
high-redshift quasars.
This paper explores the cosmological implications of BAO measurements
from the BOSS Data Release 11 (DR11) data sample, in combination with
a variety of other cosmological data. The measurements themselves,
including detailed discussion of statistical uncertainties and extensive
tests for systematic errors, have been presented in previous papers.
For the galaxy survey, [[26](#bib.bib26)] report a 1.4% measurement of
$D\_{M}(z)$ and a 3.5% measurement of $H(z)$ at $z=0.57$ (1$\sigma$
uncertainties, with a correlation coefficient of $-0.52$), and
a 2.0% measurement of $D\_{V}(z)\equiv[D\_{M}^{2}(z)\times cz/H(z)]^{1/3}$
from lower redshift BOSS galaxies at $z=0.32$. The $D\_{V}(z)$ precision
at $z=0.57$ is 1.0%. For the Ly$\alpha$ forest (often abbreviated as LyaF below), we combine constraints
from the auto-correlation function, with 2.6% precision on $H(z)$
and 5.4% precision on $D\_{M}(z)$ [[27](#bib.bib27)], and the
quasar-forest cross-correlation, with precision of 3.3% on $H(z)$
and 3.7% on $D\_{M}(z)$ [[28](#bib.bib28)], both at an effective redshift
$z\approx 2.34$.
While some cosmological analysis appears in these
papers, the combination of galaxy and Ly$\alpha$ forest BAO measurements
and the addition of
other data allow us to constrain broader classes of cosmological
models and to search for deviations from standard assumptions.

The combination of BAO measurements with precise CMB measurements from
the Planck and WMAP satellites already yields tight
constraints on the parameters of the $\Lambda$CDM cosmological model
(inflationary cold dark matter with a cosmological constant and
zero space curvature22
2
Throughout the paper, the notation
$\Lambda$CDM refers to spatially flat models; cosmological constant models
allowing non-zero curvature are denoted $o\Lambda$CDM.)
and on one-parameter extensions of this model that
allow, e.g., non-zero curvature, an evolving dark energy density, or a
cosmologically significant neutrino mass [[29](#bib.bib29)].
We also take advantage of another major recent advance, a comprehensive
reassessment of the SNIa distance scale by [[30](#bib.bib30)] using
data from the 3-year Supernova Legacy Survey [[31](#bib.bib31)]
and SDSS-II Supernova Survey [[32](#bib.bib32), [33](#bib.bib33)] samples and
additional data at low and high redshifts.
We will examine the consistency of the BAO and SNIa results for relative
distances and the constraints on $H\_{0}$ that emerge from an “inverse
distance ladder” that combines the two data sets, in essence using
SNIa to transfer the absolute calibration of the BAO scale from the
intermediate redshifts where it is precisely measured down to $z=0$.
Our primary focus will be on the cosmological parameter
constraints and model tests that come from combining the BAO
and SNIa data with Planck CMB data.33
3
We use the Planck 2013
data, which were publicly available at the time of our analysis
and paper submission. Because best-fit parameter values from
the Planck 2015 data are similar to those from the Planck 2013 data
[[34](#bib.bib34)], we expect that using the 2015 data would make
little difference to our results, though with some modest improvements
in parameter uncertainties. We will present analyses that use the
Planck 2015 data in concert with BOSS DR12 BAO measurements in future work.
When fitting models to these
data, we will also examine their predictions for observable
measures of structure growth and compare the results to inferences from
weak lensing, clusters, redshift-space distortions,
and the 1-d Ly$\alpha$ power spectrum.
The interplay of BAO, CMB, and SNIa constraints, and the more general
interplay between measurements of expansion history and structure
growth, are reviewed at length by [[35](#bib.bib35)], along with detailed
introductions to the methods themselves.
In particular, Section 4 of [[35](#bib.bib35)] provides a thorough description
of the BAO method and its motivation.

Section [II](#S2 "II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") describes the basic methodology of our analysis,
including the relevant underlying equations, and reviews the BAO,
CMB, and SN measurements that we adopt for our constraints, concluding
with variants of “BAO Hubble diagrams” that illustrate our qualitative
results. Section [III](#S3 "III BAO as an uncalibrated ruler ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") presents the constraints obtainable by
assuming that the BAO scale is a standard ruler independent of redshift
without computing its physical scale; in particular, we demonstrate that galaxy
and LyaF BAO alone yield a convincing detection of dark energy and that
addition of the angular scale of the CMB acoustic peaks requires a nearly
flat universe if dark energy is a cosmological constant.
Section [IV](#S4 "IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") presents our inverse distance ladder
determination of $H\_{0}$, which assumes standard recombination physics
but does not assume a specific dark energy model or a flat universe.
Section [V](#S5 "V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") describes our constraints on the parameters
of standard dark energy models, while Section [VI](#S6 "VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") considers
models that allow early dark energy, decaying dark matter, cosmologically
significant neutrino mass, or extra relativistic species. We compare the
predictions of our BAO+SN+CMB constrained models to observational estimates
of matter clustering in Section [VII](#S7 "VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") and summarize our overall
conclusions in Section [VIII](#S8 "VIII Conclusions ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").

## II Methodology, Models and Data Sets

### II.1 Methodology

A homogenenous and isotropic cosmological model is
specified by the curvature parameter $k$
entering the Friedman-Robertson-Walker metric

|  |  |  |  |
| --- | --- | --- | --- |
|  | $ds^{2}=-dt^{2}+a^{2}(t)\left[\frac{dr^{2}}{1-kr^{2}}+r^{2}d\Omega^{2}\right]\penalty\ ,$ |  | (1) |

which governs conversion between radial and transverse distances,
and by the evolution of $a(t)=(1+z)^{-1}$.
In General Relativity (GR), this evolution is governed by
the Friedmann equation [[36](#bib.bib36)], which can be written in
the form

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{H^{2}(a)}{H^{2}\_{0}}=\frac{\rho(a)}{\rho\_{0}}+\Omega\_{k}a^{-2}\penalty\ ,$ |  | (2) |

where $H\equiv\dot{a}/a$ is the Hubble parameter, $\rho(a)$ is
the total energy density (radiation + matter + dark energy), and
the subscript 0 denotes the present day ($a=1$).
We define the density parameter of component $x$ by the ratio

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Omega\_{x}={\rho\_{x}\over\rho\_{\rm crit}}={8\pi G\over 3H^{2}}\rho\_{x}\penalty\$ |  | (3) |

and the curvature parameter

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Omega\_{k}=1-\sum\Omega\_{x}\penalty\ ,$ |  | (4) |

where the sum is over all matter and energy components and
$\Omega\_{k}=0$ for a flat ($k=0$) universe.
Density parameters and $\rho\_{\rm crit}$ always refer to values at $z=0$
unless a dependence on $a$ or $z$ is written explicitly,
e.g., $\Omega\_{x}(z)$. We will frequently refer to the Hubble
constant $H\_{0}$ through the dimensionless ratio
$h\equiv H\_{0}/100\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$.
The dimensionless quantity $\omega\_{x}\equiv\Omega\_{x}h^{2}$ is
proportional to the physical density of component $x$ at the
present day.

Given the curvature parameter and $H(z)$ from the Friedmann equation,
the comoving angular diameter distance can be computed as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}D\_{M}(z)&={c\over H\_{0}}S\_{k}\left({D\_{C}(z)\over c/H\_{0}}\right)\\ &\approx D\_{C}(z)\left[1+{1\over 6}\Omega\_{k}\left({D\_{C}(z)\over c/H\_{0}}\right)^{2}\right],\end{split}$ |  | (5) |

where the line-of-sight comoving distance is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D\_{C}(z)={c\over H\_{0}}\int\_{0}^{z}dz^{\prime}{H\_{0}\over H(z^{\prime})}$ |  | (6) |

where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S\_{k}(x)=\begin{cases}\sin(\sqrt{-\Omega\_{k}}x)/\sqrt{-\Omega\_{k}}&\Omega\_{k}<0,\\ \sinh(\sqrt{\Omega\_{k}}x)/\sqrt{\Omega\_{k}}&\Omega\_{k}>0,\\ x&\Omega\_{k}=0.\\ \end{cases}$ |  | (7) |

Positive $k$ corresponds to negative $\Omega\_{k}$.
We do not use the small $\Omega\_{k}$ approximation of
equation ([5](#S2.E5 "In II.1 Methodology ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")) in our calculations, but we provide it here to
illustrate that for small non-zero curvature the change in distance is
linear in $\Omega\_{k}$ and quadratic in $D\_{C}(z)$.

Curvature affects $D\_{M}(z)$ both through its influence on
$H(z)$ and through the geometrical factor in equation ([5](#S2.E5 "In II.1 Methodology ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")).
The luminosity distance (relevant to supernovae) is $D\_{L}=D\_{M}(1+z)$.

The energy components considered in our models are pressureless
(cold) dark matter, baryons, radiation, neutrinos, and dark energy.
The densities of CDM and baryons scale as $a^{-3}$; we refer
to the density parameter of these two components together as
$\Omega\_{cb}$. The energy density of neutrinos with non-zero
mass scales like radiation at early times and like matter at late times, with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}\frac{\rho\_{\nu+r}(a)}{\rho\_{\rm crit}}=&\frac{8\pi^{3}k\_{B}^{4}G}{45\hbar^{3}c^{5}H\_{0}^{2}}\times\\ &\left[T\_{\rm CMB}(a)^{4}+T\_{\nu}(a)^{4}\sum\_{i}I(m\_{i}c^{2}/k\_{B}T\_{\nu}(a))\right]\penalty\ ,\end{split}$ |  | (8) |

where both CMB temperature $T\_{\rm CMB}$ and neutrino temperature
scale inversely with scale factor, and the neutrino temperature is
given by $T\_{\nu}=T\_{\rm CMB}\left(\frac{4}{11}\right)^{\nicefrac{{1}}{{3}}}g\_{c}$, where
$g\_{c}=\left(\nicefrac{{3.046}}{{3}}\right)^{\nicefrac{{1}}{{4}}}$ accounts for
small amount of heating of neutrinos due to electron-positron
annihilation. The sum in the above expression is over
neutrino species with masses $m\_{i}$. The integral $I$ is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $I(r)=\frac{15}{\pi^{4}}\int\_{0}^{\infty}\frac{\sqrt{x^{2}+r^{2}}}{e^{x}+1}x^{2}dx$ |  | (9) |

and must be evaluated numerically. For massless neutrinos
$I(0)=\nicefrac{{7}}{{8}}$, while in the limit of very massive neutrinos
$I(r)\sim 45\zeta(3)(2\pi^{4})^{-1}r$ (for $r\gg 1$; here $\zeta(3)$
is the Riemann function), i.e., scaling proportionally with $a$ so
that neutrinos behave like pressureless matter. When we refer to the
$z=0$ matter density parameter $\Omega\_{m}$, we include the
contributions of radiation (which is small compared to the
uncertainties in $\Omega\_{m}$) and neutrinos (which are non-relativistic
at $z=0$), so that $\Omega\_{m}+\Omega\_{\rm de}+\Omega\_{k}\equiv 1$. Following the Planck Collaboration [[29](#bib.bib29)], we adopt
$\sum m\_{\nu}=0.06\,$ eV with one massive and two massless neutrino
species in all models except the one referred to as
$\nu$CDM, where it is a free parameter. The
default implies $\omega\_{\nu}=6.57\times 10^{-4}$ including massless
species and $\omega\_{\nu}=6.45\times 10^{-4}$ excluding them. The
effect of finite neutrino temperature at $z=0$ is a very small
$10^{-4}$ relative effect. The adopted values are close to the
minimum value allowed by neutrino oscillation experiments.

We consider a variety of models for the evolution of the energy
density or equation-of-state parameter $w=p\_{\rm de}/\rho\_{\rm de}$.
Table [1](#S2.T1 "Table 1 ‣ II.1 Methodology ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") summarizes the primary models discussed in the
paper, though we consider some additional special cases in
Section [VI](#S6 "VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"). $\Lambda$CDM represents a flat universe
with a cosmological constant ($w=-1$). $o\Lambda$CDM extends this model to
allow non-zero $\Omega\_{k}$. $w$CDM adopts a flat universe and constant
$w$, and $ow$CDM generalizes to non-zero $\Omega\_{k}$. $w\_{0}w\_{a}$CDM and
$ow\_{0}w\_{a}$CDM allow $w(a)$ to evolve linearly with $a(t)$, $w(a)=w\_{0}+w\_{a}(1-a)$. PolyCDM adopts a quadratic polynomial form for $\rho\_{\rm de}(a)$ and allows non-zero space curvature, to provide a highly
flexible description of the effects of dark energy at low
redshift. Finally, Slow Roll Dark Energy is an example of a
one-parameter evolving-$w$ model, based on a quadratic dark energy
potential.

We focus in this paper on parameter constraints and model tests
from measurements of cosmic distances and expansion rates,
which we refer to collectively as “expansion history” or
“geometric” constraints.
We briefly consider comparisons to measurements of low-redshift
matter clustering in Section [VII](#S7 "VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
In this framework, the crucial roles of CMB anisotropy measurements
are to constrain the parameters (mainly $\omega\_{m}$ and $\omega\_{b}$)
that determine the BAO scale and to determine the angular diameter
distance to the redshift of recombination.
For most of our analyses, this approach allows us to use a highly compressed
summary of CMB constraints, discussed in Section [II.3](#S2.SS3 "II.3 Cosmic Microwave Background Data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") below,
and to compute parameter constraints with a simple and fast
Markov Chain Monte Carlo (MCMC) code that computes expansion rates
and distances from the Friedmann equation.
The code is publicly available with data used in this paper at
https://github.com/slosar/april.

|  |  |  |  |
| --- | --- | --- | --- |
| Name | Friedmann equation ($\nicefrac{{H^{2}}}{{H^{2}\_{0}}}$) | Curvature | Section(s) |
| $\Lambda$CDM | $\Omega\_{cb}a^{-3}+\Omega\_{\Lambda}+{\rho\_{\nu+r}(z)}/{\rho\_{\rm crit}}$ | no | [III](#S3 "III BAO as an uncalibrated ruler ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")-[V](#S5 "V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") |
| $o\Lambda$CDM | $\Omega\_{cb}a^{-3}+\Omega\_{\Lambda}+{\rho\_{\nu+r}(z)}/{\rho\_{\rm crit}}+\Omega\_{k}a^{-2}$ | yes | [III](#S3 "III BAO as an uncalibrated ruler ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")-[V](#S5 "V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") |
| $w$CDM | $\Omega\_{cb}a^{-3}+\Omega\_{\rm de}a^{-3(1+w)}+{\rho\_{\nu+r}(z)}/{\rho\_{\rm crit}}$ | no | [V](#S5 "V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") |
| $ow$CDM | $\Omega\_{cb}a^{-3}+\Omega\_{\rm de}a^{-3(1+w)}+{\rho\_{\nu+r}(z)}/{\rho\_{\rm crit}}+\Omega\_{k}a^{-2}$ | yes | [V](#S5 "V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") |
| $w\_{0}w\_{a}$CDM | $\Omega\_{cb}a^{-3}+\Omega\_{\rm de}a^{-3(1+w\_{0}+w\_{a})}\exp[{-3w\_{a}(1-a)}]+{\rho\_{\nu+r}(z)}/{\rho\_{\rm crit}}$ | no | [V](#S5 "V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") |
| Slow Roll Dark Energy | $\Omega\_{cb}a^{-3}+{\rho\_{\nu+r}(z)}/{\rho\_{\rm crit}}+\Omega\_{DE}\left[{a^{-3}}/(\Omega\_{m}a^{-3}+\Omega\_{DE})\right]^{\delta w\_{0}/\Omega\_{DE}}$ | no | [V](#S5 "V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") |
| $ow\_{0}w\_{a}$CDM | $\Omega\_{cb}a^{-3}+\Omega\_{\rm de}a^{-3(1+w\_{0}+w\_{a})}\exp[{-3w\_{a}(1-a)}]+{\rho\_{\nu+r}(z)}/{\rho\_{\rm crit}}+\Omega\_{k}a^{-2}$ | yes | [IV](#S4 "IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")-[V](#S5 "V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") |
| PolyCDM | $\Omega\_{cb}a^{-3}+(\Omega\_{1}+\Omega\_{k})a^{-2}+\Omega\_{2}a^{-1}+(1-\Omega\_{cb}-\Omega\_{k}-\Omega\_{1}-\Omega\_{2})$ | yes44 4 with Gaussian prior $\Omega\_{k}=0\pm 0.1$ | [IV](#S4 "IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") |
| Early Dark Energy | See relevant section. | no | [VI.1](#S6.SS1 "VI.1 Early Dark Energy ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") |
| Decaying Dark Matter | See relevant section. | no | [VI.2](#S6.SS2 "VI.2 Decaying Dark Matter ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") |
| $\nu$CDM | free neutrino mass ($\Sigma m\_{\nu}<1\,{\rm eV}$) | no | [VI.3](#S6.SS3 "VI.3 Massive Neutrinos ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") |
| $\Delta N\_{\rm eff}\penalty\ \Lambda$CDM | non-standard radiation component ( $2<N\_{\rm eff}<5$) | no | [VI.4](#S6.SS4 "VI.4 Extra Relativistic Species ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") |
| Tuned Oscillation | See relevant section. | no | [VI.5](#S6.SS5 "VI.5 A Tuned Oscillation ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") |

Table 1: Models considered in the paper and section in the paper
where they are discussed. The top section is the minimal
cosmological model (with and without curvature) and various
extensions in the dark energy sector. The middle group are two
models used to mimic non-parametric methods (i.e.,
flexible models where the only de-facto assumption is smoothness of
the expansion history). The bottom group are various extension of
the minimal model to which we are sensitive only in conjuction
with the CMB data. Throughout, $\Omega\_{cb}$ is the $z=0$
density parameter of baryons + CDM and $\rho\_{\nu+r}(z)$ is the energy
density of radiation + massive neutrinos. All models except
$\nu$CDM and $\Delta N\_{\rm eff}\Lambda$CDM
adopt $\sum m\_{\nu}=0.06\,$eV and the
standard radiation content $N\_{\rm eff}=3.046$.

### II.2 BAO data

The BAO data in this work are summarized in Table [2](#S2.T2 "Table 2 ‣ II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")
and more extensively discussed below.

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Name | Redshift | $D\_{V}/r\_{d}$ | $D\_{M}/r\_{d}$ | $D\_{H}/r\_{d}$ | $r\_{\rm off}$ |
| 6dFGS | 0.106 | $3.047\pm 0.137$ | – | – | – |
| MGS | 0.15 | $4.480\pm 0.168$ | – | – | – |
| BOSS LOWZ Sample | 0.32 | $8.467\pm 0.167$ | – | – | – |
| BOSS CMASS Sample | 0.57 | – | $14.945\pm 0.210$ | $20.75\pm 0.73$ | $-0.52$ |
| LyaF auto-correlation | 2.34 | – | $37.675\pm 2.171$ | $9.18\pm 0.28$ | $-0.43$ |
| LyaF-QSO cross correlation | 2.36 | – | $36.288\pm 1.344$ | $9.00\pm 0.30$ | $-0.39$ |
| Combined LyaF | 2.34 | – | $36.489\pm 1.152$ | $9.145\pm 0.204$ | $-0.48$ |

Table 2: 
BAO constraints used in this work. These values are taken from
[[21](#bib.bib21)] (6dFGS), [[23](#bib.bib23)] (MGS), [[26](#bib.bib26)] (BOSS galaxies),
[[27](#bib.bib27)] (BOSS LyaF auto-correlation), and
[[28](#bib.bib28)] (BOSS LyaF cross-correlation).
For our likelihood calculations, we adopt Gaussian approximations for
6dFGS and LOWZ (with 6dFGS truncated at $\Delta\chi^{2}=4$), while
for others we use the full $\chi^{2}$ look-up tables.
The LyaF auto-correlation and cross-correlation
results are used directly; the combined LyaF numbers are provided here for convenience.

The robustness of BAO measurements arises from the fact that a
sharp feature in the correlation function (or an oscillatory feature
in the power spectrum) cannot be readily mimicked by systematics,
whether observational or astrophysical, as these should be
agnostic about the BAO scale and hence smooth over the relevant part
of the correlation function (or power spectrum).
In most current analyses, the BAO scale is determined by adopting
a fiducial cosmological model that translates angular and redshift separations
to comoving distances but allowing the location of the BAO feature
itself to shift relative to the fiducial model expectation.
One then determines the likelihood of obtaining the observed
two-point correlation function or power spectrum as a function
of the BAO offsets, while marginalizing over nuisance parameters.
These nuisance parameters characterize “broad-band”
physical or observational effects that smoothly change the
shape or amplitude of the underlying correlation function or power spectrum,
such as scale-dependent bias of galaxies or the LyaF, or distortions
caused by continuum fitting or by variations in star-galaxy separation.
In an isotropic fit, the measurement is encoded in the $\alpha$
parameter, the ratio of the measured BAO scale to that predicted by
the fiducial model.
In an anisotropic analysis, one separately constrains $\alpha\_{\perp}$
and $\alpha\_{\parallel}$, the ratios perpendicular and parallel
to the line of sight. In real surveys the errors on $\alpha\_{\perp}$ and
$\alpha\_{\parallel}$ are significantly correlated for a given redshift
slice, but they are typically uncorrelated across different redshift slices.
While the values of $\alpha$ are referred to a specified fiducial model,
the corresponding physical BAO scales are insensitive to the choice of
fiducial model within a reasonable range.

The BAO scale is set by the radius of the sound horizon at the
drag epoch $z\_{d}$ when photons and baryons decouple,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $r\_{d}=\int\_{z\_{d}}^{\infty}{c\_{s}(z)\over H(z)}dz\penalty\ ,$ |  | (10) |

where the sound speed in the photon-baryon fluid is
$c\_{s}(z)=3^{-1/2}c\left[1+\frac{3}{4}\rho\_{b}(z)/\rho\_{\gamma}(z)\right]^{-1/2}$.
A precise prediction of the BAO signal requires a
full Boltzmann code computation, but for reasonable variations
about a fiducial model the ratio of BAO scales is
given accurately by the ratio of $r\_{d}$ values computed from the
integral ([10](#S2.E10 "In II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")). Thus, a measurement of $\alpha\_{\perp}$
from clustering at redshift $z$ constrains the ratio of the
comoving angular diameter distance to the sound horizon:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D\_{M}(z)/r\_{d}=\alpha\_{\perp}D\_{M,{\rm fid}}(z)/r\_{d,{\rm fid}}\penalty\ .$ |  | (11) |

A measurement of $\alpha\_{\parallel}$ constrains the Hubble parameter
$H(z)$, which we convert to an analogous quantity:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D\_{H}(z)=c/H(z),$ |  | (12) |

with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D\_{H}(z)/r\_{d}=\alpha\_{\parallel}D\_{H,{\rm fid}}(z)/r\_{d,{\rm fid}}\penalty\ .$ |  | (13) |

An isotropic BAO analysis measures some effective combination of these
two distances. If redshift-space distortions are weak, which is a
good approximation for luminous galaxy surveys after reconstruction
but not for the LyaF, then the constrained quantity is the volume
averaged distance

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D\_{V}(z)=\left[zD\_{H}(z)D\_{M}^{2}(z)\right]^{1/3},$ |  | (14) |

with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D\_{V}(z)/r\_{d}=\alpha D\_{V,{\rm fid}}(z)/r\_{d,{\rm fid}}.$ |  | (15) |

There are different conventions in use for defining $r\_{d}$, which
differ at the 1-2% level, but ratios of $r\_{d}$ for different cosmologies
are independent of the convention provided one is consistent throughout.
In this work we adopt the CAMB convention for $r\_{d}$, i.e.,
the value that is reported by the linear perturbations code
CAMB[[37](#bib.bib37)]. In practice, we use the
numerically calibrated approximation

|  |  |  |  |
| --- | --- | --- | --- |
|  | $r\_{d}\approx{55.154\exp\left[-72.3(\omega\_{\nu}+0.0006)^{2}\right]\over\omega\_{cb}^{0.25351}\,\omega\_{b}^{0.12807}}\penalty\ {\rm Mpc}\penalty\ .$ |  | (16) |

This approximation is accurate to 0.021%
for a standard radiation background with
$N\_{\rm eff}=3.046$, $\sum m\_{\nu}<0.6\,{\rm eV}$, and
values of $\omega\_{b}$ and $\omega\_{cb}$ within $3\sigma$ of values
derived by Planck.
It supersedes a somewhat less
accurate (but still sufficiently accurate)
approximation from [[26](#bib.bib26)] (their eq. 55).
Note that $\omega\_{\nu}=0.0107(\sum m\_{\nu}/1.0\,{\rm eV})$,
and a 0.5 (1.0) eV neutrino mass changes $r\_{d}$ by $-0.26\%$
($-0.92\%$) for fixed $\omega\_{cb}$.
For neutrino masses in the range allowed by current cosmological
constraints, the CMB constrains $\omega\_{cb}$ rather
than $\omega\_{cb}+\omega\_{\nu}$ because neutrinos remain relativistic
at recombination, even though they are non-relativistic at $z=0$.
For the case of extra relativistic species, a useful fitting formula is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $r\_{d}\approx{56.067\,\exp\left[-49.7(\omega\_{\nu}+0.002)^{2}\right]\over\omega\_{cb}^{0.2436}\,\omega\_{b}^{0.128876}\,[1+(N\_{\rm eff}-3.046)/30.60]}\penalty\ {\rm Mpc}\penalty\ ,$ |  | (17) |

which is accurate to 0.119% if we restrict
to neutrino masses in the range $0<\sum m\_{\nu}<0.6\,{\rm eV}$ and $3<N\_{\rm eff}<5$.
Increasing $N\_{\rm eff}$ by unity decreases $r\_{d}$ by about 3.2%.

For $\Lambda$CDM models (with $\sum m\_{\nu}=0.06\,{\rm eV}$, $N\_{\rm eff}=3.046$) constrained by
Planck, $r\_{d}=147.49\pm 0.59$ Mpc. This 0.4% uncertainty is only slightly
larger for $o\Lambda$CDM, $ow$CDM, or even $ow\_{0}w\_{a}$CDM (see Table
[1](#S2.T1 "Table 1 ‣ II.1 Methodology ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") for cosmological model definitions), because the relevant quantities
$\omega\_{cb}$ and $\omega\_{b}$ are constrained by the relative heights of the
acoustic peaks, not by their angular locations. The inference of matter energy
densities from peak heights thus depends on correct understanding of physics in
the pre-recombination epoch, where curvature and dark energy are negligible in
any of these models.

BAO measurements constrain cosmological parameters through their
influence on $r\_{d}$, their influence on $D\_{H}(z)$ via the
Friedmann equation, and their influence on
$D\_{M}(z)$ via equation ([5](#S2.E5 "In II.1 Methodology ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")).
For standard models, the 0.4% error on $r\_{d}$ from Planck
is small compared to current BAO measurement errors, so the
constraints come mainly through $D\_{H}$ and $D\_{M}$.
From the Friedmann equation, we see that $D\_{H}(z)$ is directly
sensitive to the total energy density at redshift $z$, while
$D\_{M}(z)$ constrains an effective average of the energy density
and is also sensitive to curvature.

Measurements in Table [2](#S2.T2 "Table 2 ‣ II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") are reported in terms of
$D\_{V}/r\_{d}$, $D\_{M}/r\_{d}$, and $D\_{H}/r\_{d}$, using the $r\_{d}$ convention
of equation ([10](#S2.E10 "In II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")). Expressed in these terms,
the results are independent of the fiducial cosmologies assumed
in the individual analysis papers.
Note that some of the referenced papers quote values
of $D\_{A}/r\_{d}$ rather than $D\_{M}/r\_{d}$, differing by a factor $(1+z)$.
An anisotropic analysis yields
anti-correlated errors on $D\_{M}$ and $D\_{H}$, and the correlation
coefficients are reported in Table [2](#S2.T2 "Table 2 ‣ II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
Each sample spans a range of redshift, and the quoted effective
redshift is usually weighted by statistical contribution to the BAO
measurement. Because redshift-space positions are scaled to comoving
coordinates based on a fiducial cosmological model, and BAO measurements are
obtained as ratios relative to that fiducial model,
the values of the effective redshift in Table [2](#S2.T2 "Table 2 ‣ II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")
can be treated as exact, e.g., one should compare the
BOSS CMASS numbers to model predictions computed at
$z=0.5700.$

#### II.2.1 Galaxy BAO Measurements

The most precise BAO measurements to date come from analyses
of the BOSS DR11 galaxy sample by [[26](#bib.bib26)].
BOSS uses the same telescope [[38](#bib.bib38)] as the original SDSS,
with spectrographs [[39](#bib.bib39)] that were substantially
upgraded to improve throughput and increase multiplexing
(from 640 fibers per plate to 1000).
Redshift completeness for the primary BOSS sample
is nearly 99%, with typical redshift uncertainty of
a few tens of $\,{\rm km}\,{\rm s}^{-1}$ [[40](#bib.bib40)].
The DR11 sample has a footprint of 8377 deg2, compared
to 10,500 deg2 expected for the final BOSS galaxy
sample to appear in DR12.

BOSS targets two distinct samples of luminous galaxies
selected by different flux and color cuts [[24](#bib.bib24)]:
CMASS, designed to approximate a constant threshold
in galaxy stellar mass in the range $0.43<z<0.7$,
and LOWZ, which provides roughly three times the
density of the SDSS-II LRG sample in the range $0.15<z<0.43$.
Analysis of both samples incorporates reconstruction
[[17](#bib.bib17), [16](#bib.bib16)] to sharpen the BAO
peak by partly reversing non-linear effects, thus improving
measurement precision. For CMASS, we use results of the
anisotropic analysis by [[26](#bib.bib26)], which yields
$D\_{M}/r\_{d}=14.945\pm 0.210$ (1.4% precision) and
$D\_{H}/r\_{d}=20.75\pm 0.73$ (3.5% precision) with
anti-correlated errors ($r=-0.52$).

The LOWZ sample does not have sufficient statistical power
for a robust anisotropic analysis, so we use the measurement
of $D\_{V}=8.467\pm 0.167$ at $z=0.320$
(discussed in detail by [[41](#bib.bib41)]).
We have not included results from the SDSS-II LRG or WiggleZ
surveys cited in the introduction because these partly overlap
the BOSS volume and are not statistically independent.
We do include results of a new analysis [[23](#bib.bib23)] that uses
reconstruction to achieve a 3.8% $D\_{V}/r\_{d}$ measurement from
the SDSS main galaxy sample (MGS) at effective redshift $z=0.150$,
which should be nearly independent of the BOSS LOWZ measurement.
We also include the 6dFGS measurement of $D\_{V}/r\_{d}=3.047\pm 0.137$
(4.5% precision) at $z=0.106$. Because the 6dFGS BAO
detection is of moderate statistical significance and we do
not have a full $\chi^{2}$ surface for it, we truncate
its $\chi^{2}$ contributions at $\Delta\chi^{2}=4$ to guard
against non-Gaussian tails of the error distribution.
In practice the 6dFGS measurement carries little
statistical weight in our constraints.
These galaxy BAO measurements are listed in the first
four lines of Table [2](#S2.T2 "Table 2 ‣ II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").

#### II.2.2 BOSS Ly$\alpha$ forest BAO Measurements

The BAO scale was first measured at higher redshift ($z\sim 2.4$) from
the auto-correlation of the Ly$\alpha$ forest fluctuations in the spectra
of high-redshift quasars from BOSS DR9
([[42](#bib.bib42)],[[43](#bib.bib43)],[[44](#bib.bib44)]) following the
pioneering work of measuring 3D fluctuations in the forest
[[45](#bib.bib45)].
Here we use the
results from [[27](#bib.bib27)], who present an improved measurement
using roughly twice as many quasar spectra from BOSS DR11.
The DR11 quasar catalog will be made publicly available simultaneously
with the DR12 catalog in 2015. The catalog construction is similar
to that of the DR10 quasar catalog described by
[[46](#bib.bib46)]. The BOSS quasar selection criteria
are described by [[47](#bib.bib47)] and the
background methodology papers
[[48](#bib.bib48), [49](#bib.bib49), [50](#bib.bib50), [51](#bib.bib51)].

The measurement of LyaF BAO peak positions is marginalized over parameters
describing broad-band distortion of the correlation function using the
methodology of [[44](#bib.bib44)].
Because of the low effective bias factor of the LyaF, redshift-space
distortion strongly enhances the BAO peak in the line-of-sight direction.
The measurement of $D\_{H}/r\_{d}$ is therefore more precise (3.1%) than
that of $D\_{M}/r\_{d}$ (5.8%), as seen in line 5 of Table [2](#S2.T2 "Table 2 ‣ II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
The errors of these two measurements are anti-correlated, with
$r\_{\rm off}=-0.43$, and the optimally measured combination
$D\_{H}^{0.7}D\_{M}^{0.3}$ is determined with a precision of $\sim 2\%$.
While the overall signal-to-noise ratio of the BAO measurement is high,
the detection significance for transverse separations ($\mu<0.5$)
is only moderate, as one can see in Figure 3 of [[27](#bib.bib27)].

At the same redshift, BAO have also been measured in the cross-correlation of
the Ly$\alpha$ forest with the density of quasars in BOSS DR11
[[28](#bib.bib28)].
While the number of quasar-pixel pairs
is much lower than the number of pixel-pixel pairs in the auto-correlation
function, the clustering signal is much stronger because of the high
bias factor of quasars. For the same reason, redshift-space distortion
is much weaker in the cross-correlation, and in this case the measurement
precision is comparable for $D\_{M}/r\_{d}$ (3.7%) and for $D\_{H}/r\_{d}$ (3.3%),
(line 6 of Table [2](#S2.T2 "Table 2 ‣ II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")).
The higher precision of the transverse measurement makes the
cross-correlation measurement an especially valuable complement to the
auto-correlation measurement.

Even though these results are derived from the same volume, we can consider
them as independent because their uncertainties are not dominated by
cosmic variance. They are dominated instead by the combination of
noise in the spectra and sparse sampling of the structure in the
survey volume, both of which affect the auto-correlation and
cross-correlation almost independently. A number of tests using mock
catalogs and several analysis procedures are presented in
[[27](#bib.bib27)], finding good agreement between error estimates from
the likelihood function and from the variance in mock catalogs. This
independence allows us to add the $\chi^{2}$ surfaces from both
publications, which are publicly available at
<http://darkmatter.ps.uci.edu/baofit/>. While we use these two
$\chi^{2}$ surfaces separately, the last line of Table [2](#S2.T2 "Table 2 ‣ II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")
lists the $D\_{M}/r\_{d}$ and $D\_{H}/r\_{d}$ constraints from the combined
measurement, with respective precision of 3.2% and 2.2% and a
correlation coefficient $r\_{\rm off}=-0.48$.

We caution that BAO measurement from LyaF data is a relatively
new field, pioneered entirely by BOSS, in contrast to the now mature
subject of galaxy BAO measurement, which has been studied both
observationally and theoretically by many groups.
[[27](#bib.bib27)] present numerous tests using mock catalogs and
different analysis procedures, finding good agreement between
error estimates from the likelihood surface and from mock catalog
variance and identifying no systematic effects that are
comparable to the statistical errors.
However, the analysis uses only 100 mock catalogs, limiting the
external tests of the tails of the error distribution.
The systematics and error estimation of
the cross-correlation measurement have also been less thoroughly
examined than those of the auto-correlation measurement,
though continuing investigations within the BOSS collaboration
find good agreement with the errors and covariances reported in the
publications above.
On the theoretical side, [[52](#bib.bib52)] and [[53](#bib.bib53)]
have examined the potential impact of UV background fluctuations
on LyaF BAO measurement, finding effects that are much
smaller than the current statistical errors.

We anticipate significant improvements in the LyaF analyses
of the Data Release 12 sample, thanks to the larger data set
and ongoing work on broadband distortion modeling,
larger mock catalog samples, and spectro-photometric calibration.
For the current paper, we adopt the BAO
likelihood surfaces as reported in [[28](#bib.bib28)] and
[[27](#bib.bib27)].

### II.3 Cosmic Microwave Background Data

In this paper we focus on constraints on the expansion history of the
homogeneous cosmological model. For this purpose, we compress the
Cosmic Microwave Background (CMB) measurements to the variables
governing this expansion history. This approach greatly simplifies the
required computations, allowing us to fit complex models that have a
simple solution to the Friedmann equation without the need to
numerically solve for the evolution of perturbations.
It is also physically illuminating, making clear what relevant
quantities the CMB determines and distinguishing expansion history
constraints from those that depend on the evolution of clustering.
For some models or special cases we use more complete CMB results obtained
by running the industry-standard cosmomc
[[54](#bib.bib54)] or by relying on the publicly available
Planck MCMC
chains.55
5
http://wiki.cosmos.esa.int/planckpla/index.php/ Cosmological\_Parameters

The CMB plays two distinct but important roles in our analysis.
First, we treat the CMB as a “BAO experiment” at redshift
$z\_{\star}=1090$, measuring the angular scale of the sound horizon
at very high redshift.
Here we
ignore the small dependence of the last-scattering
redshift $z\_{\star}$ on cosmological parameters and the fact that the
relevant scale for the CMB is $r\_{\star}$ rather than the drag redshift
$r\_{d}$ that sets the BAO scale in low-redshift structure. We have
checked that both approximations are valid to around $0.1\sigma$
for the case of BAO and Planck data and the $\Lambda$CDM model.
In its second important role,
the CMB calibrates the absolute length of the BAO ruler
through its determination of $\omega\_{b}$ and $\omega\_{cb}$.

Inspired by the existence of well-known degeneracies in CMB data
[[55](#bib.bib55), [56](#bib.bib56), [57](#bib.bib57)], we compress
the CMB measurements into three variables: $\omega\_{b}$, $\omega\_{cb}$ and
$D\_{M}(1090)/r\_{d}$. The mean vector and the $3\times 3$ covariance
matrix are used to describe the CMB constraints by a simple Gaussian
likelihood. In order to calibrate these variables, we rely on the
publicly available Planck chains. In particular, we use the
base\_Alens chains with the planck\_lowl\_lowLike
dataset corresponding to the Planck dataset with low-$\ell$ WMAP
polarization (referred to in this paper as Planck+WP).
We find that the data vector

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{v}=\left(\begin{matrix}\omega\_{b}\\ \omega\_{cb}\\ D\_{M}(1090)/r\_{d}\\ \end{matrix}\right)$ |  | (18) |

can be described by a Gaussian
likelihood with mean

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mu\_{\mathbf{v}}=\left(\begin{matrix}0.02245\\ 0.1386\\ 94.33\\ \end{matrix}\right)$ |  | (19) |

and covariance

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{\mathbf{v}}=\left(\begin{matrix}1.286\times 10^{-7}&-6.033\times 10^{-7}&1.443\times 10^{-5}\\ -6.033\times 10^{-7}&7.542\times 10^{-6}&-3.605\times 10^{-5}\\ 1.443\times 10^{-5}&-3.605\times 10^{-5}&0.004264\\ \end{matrix}\right).$ |  | (20) |

The fractional diagonal errors on $\omega\_{b}$, $\omega\_{cb}$, and
$D\_{M}(1090)/r\_{d}$ are 1.5%, 1.9%, and 0.06%, respectively.
We similarly compress the WMAP 9-yr data into

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mu\_{\mathbf{v}}=\left(\begin{matrix}0.02259\\ 0.1354\\ 94.51\\ \end{matrix}\right)$ |  | (21) |

and covariance

|  |  |  |  |
| --- | --- | --- | --- |
|  | $C\_{\mathbf{v}}=\left(\begin{matrix}2.864\times 10^{-7}&-4.809\times 10^{-7}&-1.111\times 10^{-5}\\ -4.809\times 10^{-7}&1.908\times 10^{-5}&-7.495\times 10^{-6}\\ -1.111\times 10^{-5}&-7.495\times 10^{-6}&0.02542\\ \end{matrix}\right).$ |  | (22) |

For
reference in interpreting the cosmological constraints from CMB+BAO
data, especially in Section [VI](#S6 "VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") below, note
that the contributions to $D\_{M}(1090)$ accumulate over a wide range of
redshift,
with 14%, 25%, 38%, 47%, 69%, 88%, and 99% of the integral
in equation ([6](#S2.E6 "In II.1 Methodology ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"))
coming from redshifts $z<0.5$, 1.0, 2.0, 3.0, 10, 50, and 640,
respectively.

The base\_Alens model corresponds to the basic flat
$\Lambda$CDM cosmology with explicit marginalisation over the
foreground lensing potential. Our decision to use the flat model
was intentional, since we found that in curved models
there is significant non-Gaussian correlation of $\omega\_{b}$ and
$\omega\_{m}$ with curvature. Because our BAO data inevitably collapse
more complex models to nearly flat ones, use of the flat data is more
appropriate. We have tested the data compression in a couple of
simple cases by comparing results of BAO+CMB data to cosmomc
chains and found less than $0.5\sigma$ differences in
best-fit parameter values between using compressed and full
chains. The residual differences
are driven by the fact that our compressed likelihood
attempts to extract purely geometric information from the CMB data
(for example, values of $\omega\_{b}$ and $\omega\_{m}$ are different at
roughly the same level between chains that marginalise over lensing
potential and those that do not). For BAO-only data combinations
the results are completely consistent.

Throughout the paper, we refer to the constraints represented
by equations ([18](#S2.E18 "In II.3 Cosmic Microwave Background Data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"))-([20](#S2.E20 "In II.3 Cosmic Microwave Background Data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")) simply as
“Planck” (although they also include information from
WMAP polarization measurements).
In Section [III](#S3 "III BAO as an uncalibrated ruler ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") we treat the CMB as a BAO experiment measuring
$D\_{M}(1090)/r\_{d}$, but we eliminate its calibration of the absolute BAO scale
by artificially blowing up
the errors on $\omega\_{b}$ and $\omega\_{cb}$; we denote this case as
“$+$Planck $D\_{M}$”.
Conversely, in Section [IV](#S4 "IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") we use the CMB
information on $\omega\_{b}$ and $\omega\_{cb}$ to set the
size of our standard ruler $r\_{d}$ but omit the $D\_{M}(1090)/r\_{d}$
information by artificially inflating its errors;
we denote this case as “$+r\_{d}$”.
When we use a full Planck chain instead of the compressed information,
we adopt the notation “Planck (full)” and specify what additional
parameters (such as $A\_{\rm lens}$, $N\_{\rm eff}$, or tensor-to-scalar ratio $r$)
are being varied in the chain.

If one assumes a flat universe, a cosmological constant ($w=-1$),
standard relativistic background ($N\_{\rm eff}=3.046$), and minimal
neutrino mass ($\sum m\_{\nu}=0.06\,{\rm eV}$), then the CMB data
summarized by equations ([18](#S2.E18 "In II.3 Cosmic Microwave Background Data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"))-([20](#S2.E20 "In II.3 Cosmic Microwave Background Data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"))
also provide a precise constraint on the Hubble parameter $h$,
and thus on $\Omega\_{cb}$, $\Omega\_{b}$, and $\Omega\_{\Lambda}$.
At various points in the paper we refer to a “fiducial” Planck
$\Lambda$CDM model for which we adopt $\omega\_{b}h^{2}=0.022032$,
$\Omega\_{m}=0.3183$, and $h=0.6704$, which are the best fit parameters for
“Planck+WP” combination as cited in the Table 2 of [[29](#bib.bib29)].
The CMB constraints on $h$ and $\Omega\_{m}$ become much weaker
if one allows $w\neq-1$ or $\Omega\_{k}\neq 0$,
so for more general models BAO data or other constraints are
needed to restore high precision on cosmological parameters.

### II.4 Supernova Data

A comprehensive set of relative luminosity distances of 740 SNIa was
presented in [[30](#bib.bib30)], based on a joint calibration and
training set of the SDSS-II Supernova Survey [[33](#bib.bib33)] and the
Supernova Legacy Survey (SNLS) 3-year data set [[31](#bib.bib31)]. The
374 supernovae from SDSS-II and 239 from SNLS were combined with 118
nearby supernovae from
[[58](#bib.bib58), [59](#bib.bib59), [60](#bib.bib60), [61](#bib.bib61), [62](#bib.bib62), [6](#bib.bib6)] and nine
high-redshift supernovae discovered and studied by HST [[63](#bib.bib63)].
We use this set, dubbed Joint Light-curve Analysis (JLA), rather than
the Union 2.1 compilation of [[64](#bib.bib64)] because of the
demonstrated improvement in calibration and corresponding reduction in
systematic uncertainties presented in [[30](#bib.bib30)].

While [[30](#bib.bib30)] also provide a full cosmomc
module and a covariance
matrix in relevant parameters, we here instead use their
compressed representation of
relative distance constraints due to conceptual simplicity and
a drastic increase in computational
speed when combining with other cosmology probes.
The compressed information consists of a piece-wise linear function fit
over 30 bins (leading to 31 nodes) spaced evenly in $\log{z}$ (to
minimum $z\sim 0.01$) with a $31\times 31$
covariance matrix that includes all of the systematics from the
original analysis.
SNIa constrain relative distances, so the remaining
marginalization required to use this compressed
respresentation in a comological analysis is over the fiducial absolute
magnitude of a SNIa, $M\_{B}$.
In Section [IV](#S4 "IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") we also utilize a similar
compression of the Union 2.1 SN data set, which we have
constructed in analogous fashion.

### II.5 Visualizing the BAO Constraints

Figure 1: The BAO “Hubble diagram” from a world collection of
detections. Blue, red, and green points show BAO measurements
of $D\_{V}/r\_{d}$, $D\_{M}/r\_{d}$, and $zD\_{H}/r\_{d}$, respectively, from the
sources indicated in the legend. These can be compared to the
correspondingly colored lines, which represents predictions of
the fiducial Planck $\Lambda$CDM model (with $\Omega\_{m}=0.3183$,
$h=0.6704$, see Section [II.3](#S2.SS3 "II.3 Cosmic Microwave Background Data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")). The scaling by
$\sqrt{z}$ is arbitrary, chosen to compress the dynamic range
sufficiently to make error bars visible on the plot. Filled
points represent BOSS data, which yield the most precise BAO
measurements at $z<0.7$ and the only measurements at $z>2$.
For visual clarity, the Ly$\alpha$ cross-correlation points have
been shifted slightly in redshift; auto-correlation points are
plotted at the correct effective redshift.

Figure [1](#S2.F1 "Figure 1 ‣ II.5 Visualizing the BAO Constraints ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") shows the “Hubble diagram”
(distance vs. redshift) from a variety of recent BAO measurements
of $D\_{V}/r\_{d}$, $D\_{M}/r\_{d}$, or $zD\_{H}/r\_{d}$; these three
quantities converge at low redshift.
In addition to the data listed in Table [2](#S2.T2 "Table 2 ‣ II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"), we show
measurements from the DR7 data set of SDSS-II by [[15](#bib.bib15)]
and from the WiggleZ survey by [[19](#bib.bib19)], which are not
included in our cosmological analysis because they are not
independent of the (more precise) BOSS measurements in
similar redshift ranges.
Curves represent the predictions of the fiducial Planck $\Lambda$CDM model,
whose parameters are determined independently of the BAO measurements
but depend on the assumptions of a flat universe and a cosmological constant.
Overall, there is impressively good agreement between the
CMB-constrained $\Lambda$CDM model and the BAO measurements, especially
as no parameters have been adjusted in light of the BAO data.
However, there is noticeable tension between the Planck $\Lambda$CDM model
and the LyaF BAO measurements.

Figure 2: BAO measurements and model predictions of $H(z)$ and $D\_{M}(z)$
as a function of redshift, with physically informative scalings.
The top panel shows $H(z)/(1+z)$, the proper velocity between
two objects 1 comoving Mpc apart.
The bottom panel shows $c\ln(1+z)/D\_{M}(z)$, a scaling
that matches a constant line $H(z)=(1+z)H\_{0}$ in the top panel
to the same constant line in the bottom panel for a flat universe.
Filled circles and squares show the BOSS CMASS and LyaF measurements
of $H(z)$ and $D\_{M}(z)$, respectively; we show the LyaF-quasar
cross-correlation as crosses to distinguish from the LyaF auto-correlation
measurments.
Filled triangles in
the bottom panel show the BOSS LOWZ and MGS measurements of $D\_{V}(z)$
converted to $D\_{M}(z)$. Open squares show the value of
$H\_{0}=67.3\pm 1.1\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$ determined from the combination
of BAO and SNIa data described in Section [IV](#S4 "IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
The grey swath in both panels is the prediction from the Planck
$\Lambda$CDM cosmology including $1\sigma$ parameter errors;
in the top panel, one can easily see the model transition from
deceleration to acceleration at $z\approx 0.6$.
The dashed line shows the $\Lambda$CDM prediction using the
best-fit WMAP parameters, which has lower $\Omega\_{m}h^{2}$.
Dotted curves show models that match the best-fit Planck values of
$\omega\_{cb}$, $\omega\_{b}$, and $D\_{M}(1090)/r\_{d}$ but
have $\Omega\_{k}=0.01$ (blue), $w=-0.7$ (green), or $w=-1.3$ (red).
The $x$-axis is set to $\sqrt{1+z}$ both for display purposes
and so that a pure matter universe ($\Omega\_{m}=1$)
appears as a decreasing straight line on the top panel.

Figure [2](#S2.F2 "Figure 2 ‣ II.5 Visualizing the BAO Constraints ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") displays a subset of these BAO measurements with
scalings that elucidate their physical content.
In the upper panel, we plot $H(z)/(1+z)$, which is
the proper velocity between two objects with a constant comoving
separation of 1 Mpc.
This quantity is declining in a decelerating universe and
increasing in an accelerating universe.
We set the $x$-axis to be $\sqrt{1+z}$, which makes
$H(z)/(1+z)$ a straight line of slope $H\_{0}$ in an
Einstein-de Sitter ($\Omega\_{m}=1$) model.
For the transverse BAO measurements in the lower panel, we plot
$c\ln(1+z)/D\_{M}(z)$,
chosen so that a constant (horizontal) line in the $H(z)/(1+z)$
plot would produce
the same constant line in this panel, assuming a flat Universe.
This quantity would decrease monotonically in
a non-accelerating flat cosmology.
The quantities in both the upper and lower panels approach $H\_{0}$
as $z$ approaches zero, independent of other cosmological parameters.
We convert the BOSS LOWZ and MGS measurements of $D\_{V}(z)$ to $D\_{M}(z)$
in the lower panel assuming the fiducial Planck $\Lambda$CDM parameters;
this is a robust approximation because all acceptable cosmologies
produce similar scaling at these low redshifts.
Note that the $H(z)$ and $D\_{M}(z)$ measurements from a given data set
(i.e., at a particular redshift) are covariant, in the sense that
the points on these panels are anti-correlated (see Table [2](#S2.T2 "Table 2 ‣ II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")).
For example,
if $H(z)$ at $z=2.34$ were scattered upward by a
statistical fluctuation, then the $z=2.34$ point in the lower panel
would be scattered downward.

As discussed below in Section [IV](#S4 "IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"), the galaxy BAO and
JLA supernova data can be combined to yield an “inverse distance ladder”
measurement of $H\_{0}$, which utilizes the CMB measurements of
$\omega\_{cb}$ and $\omega\_{b}$ but no other CMB information.
This value of $H\_{0}$ is robust to a wide range of assumptions about
dark energy evolution and space curvature, although it does assume
a standard radiation background for the calculation of $r\_{d}$.
We plot the resulting determination of $H\_{0}=67.3\pm 1.1\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$
as the open square in both panels.

The grey swath in both panels of Figure [2](#S2.F2 "Figure 2 ‣ II.5 Visualizing the BAO Constraints ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")
represents the 1$\sigma$ region for the
fiducial Planck $\Lambda$CDM model, with the top panel clearly
showing the transition from deceleration to acceleration at $z\approx 0.6$.
Formally, we are scaling both panels by $(r\_{d}/r\_{d,{\rm fid}})$, so that the
comparison of the BAO data points to the CMB prediction is invariant
to changes in the sound horizon.
The galaxy BAO measurements of $D\_{M}(z)$ from BOSS and MGS
are in excellent agreement with the predictions of this model
(as are the other measurements shown previously in
Fig. [1](#S2.F1 "Figure 1 ‣ II.5 Visualizing the BAO Constraints ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")),
and the combination of BAO and SNe yields an $H\_{0}$ value in excellent
agreement with this model’s prediction.
The expansion rate
$H(0.57)$ from CMASS is high compared to the model prediction, at
moderate significance.
Compared to Planck, the best-fit value of $\Omega\_{m}h^{2}$ from
the 9-year WMAP analysis [[65](#bib.bib65)] is lower, 0.143 vs. 0.137,
implying lower $\Omega\_{m}$ and slightly higher $h$ for a $\Lambda$CDM model.
The model using these best-fit parameters, shown by the dashed lines,
agrees better with the CMASS $H(z)$ measurement but
is in tension with the distance data, especially the CMASS value of
$D\_{M}(0.57)$.

The Ly$\alpha$ forest measurements are much more
difficult to reconcile with the $\Lambda$CDM model: compared to the
Planck curve, the LyaF BAO $H(z)$ is low and $[D\_{M}(z)]^{-1}$ is high.
It is important to keep the error anti-correlation
in mind when assessing significance —
if $H(z)$ fluctuates up then $1/D\_{M}(z)$ will fluctuate down,
which tends to reduce the tension relative to the CMB.
However, our subseqent analyses
(and those already reported by [[27](#bib.bib27)]) will show that
the discrepancy is significant at the $2-2.5\sigma$ level.
The dotted curves show predictions of cosmological models with
$\Omega\_{k}=0.01$ or $1+w=\pm 0.3$.
While changing curvature or the dark energy equation-of-state
can improve agreement with some of the data points,
it worsens agreement with other data points,
and on the whole (as demonstrated quantitatively in
Section [V](#S5 "V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")) such variations do not
noticeably improve the fit to the combined CMB, BAO, and SN data.

Not plotted in Figure [2](#S2.F2 "Figure 2 ‣ II.5 Visualizing the BAO Constraints ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")
is the value of $D\_{M}(1090)$ that comes from the angular
acoustic scale in the CMB. Connecting the acoustic scale measured in
CMB anisotropy to that measured in large-scale structure does require model
assumptions about structure formation at the recombination epoch.
However, it would be difficult to move the relative calibration significantly
without making substantial changes to the CMB damping tail,
which is already well constrained by observations.
Using the ratio of $D\_{M}(1090)/r\_{d}$ in equation ([19](#S2.E19 "In II.3 Cosmic Microwave Background Data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"))
and $r\_{d}=147.49$ Mpc, we find $c\ln(1+z)/D\_{M}(z)=151\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$ at $z=1090$
with percent level accuracy,
a factor of two larger than any of the low-redshift values in
Figure [2](#S2.F2 "Figure 2 ‣ II.5 Visualizing the BAO Constraints ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
On their own, the BAO data in Figure [2](#S2.F2 "Figure 2 ‣ II.5 Visualizing the BAO Constraints ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") clearly
favor a universe that transitions from deceleration at $z>1$
to acceleration at low redshifts, and this evidence becomes
overwhelming if one imagines the corresponding CMB measurements
off the far left of the plot.
We quantify these points in the following section.

It is tempting to consider a flat cosmology with a constant $H/(1+z)$
as an alternative model of these data [[66](#bib.bib66)].
Note that although this form of $H(z)$ occurs in coasting (empty)
cosmologies in general relativity, those models have open curvature
and hence a sharply different $D\_{M}(z)$.
But even for the flat model, the data are not consistent with a
constant $H(z)/(1+z)$, first because
the increase in $c\ln(1+z)/D\_{M}(z)$ from $z=0.57$ to $z=0.0$ is statistically significant,
and second because of the factor of two change of this quantity relative
to that inferred from the CMB angular
acoustic scale. The change from $z=0.57$ to $z=0$ is more significant
than the plot indicates because the data points are correlated;
this occurs because the $H\_{0}$ value results from normalizing the SNe
distances with the BAO measurements.
We measure the ratio of the values, $H\_{0}D\_{M}(0.57)/c\ln(1.57)$, to
be $1.080\pm 0.014$ from the combination of BAO and SNe datasets,
a 5.5$\sigma$ rejection of a constant hypothesis and an indication
of the strength of the SNe data in detecting the low-redshift
accelerating expansion.

## III BAO as an uncalibrated ruler

### III.1 Convincing Detection of dark energy from BAO data alone

For quantitative contraints, we start by considering BAO data alone
with the simple assumption that the BAO scale is a standard comoving
ruler, whose length is independent of redshift and orientation but is
not necessarily the value computed using CMB parameter
constraints. A similar analysis has been presented in
[[67](#bib.bib67)]. In this case, a simple dimensional
analysis shows that in addition to fractional densities in cosmic
components, one can constrain the dimensionless quantity $P=c/(H\_{0}r\_{d})$.

Figure [3](#S3.F3 "Figure 3 ‣ III.1 Convincing Detection of dark energy from BAO data alone ‣ III BAO as an uncalibrated ruler ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") presents constraints on relevant quantities
in $o\Lambda$CDM models, which assume that dark energy is a
cosmological constant but allow $\Omega\_{\Lambda}=0$ and arbitrary $\Omega\_{k}$.
The combination of galaxy and LyaF BAO measurements
yields a marginalised constraint of
$\Omega\_{\Lambda}=0.73^{+0.25}\_{-0.68}$ at 99.7% confidence,
implying a $>3\sigma$ detection of dark energy
from BAO alone without CMB data.

These constraints become much tighter if we assume that the CMB is measuring the
same acoustic scale, functioning as an additional BAO experiment at a much
higher redshift. As discussed in Section [II.3](#S2.SS3 "II.3 Cosmic Microwave Background Data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"), we implement this case
by retaining the high-precision CMB measurement of $D\_{M}(1090)/r\_{d}$ but
drastically inflating (by a factor of 100) the CMB errors on $\omega\_{cb}$ and
$\omega\_{b}$, so that the value of $r\_{d}$ itself remains effectively unknown.
Combining the CMB measurement with galaxy or LyaF BAO alone
yields a strong detection of non-zero $\Omega\_{\Lambda}$, but with different
central values reflecting the tensions already discussed in
Section [II.5](#S2.SS5 "II.5 Visualizing the BAO Constraints ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") and examined further in
Sections [V](#S5 "V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")–[VI](#S6 "VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
Combining all three measurements yields a marginalised
$\Omega\_{\Lambda}=0.72^{+0.030}\_{-0.034}$ (at 68% confidence, with reasonably
Gaussian errors), implying $>20\sigma$ preference for a low-density universe
dominated by dark energy.
The dimensionless quantity $P=c/(H\_{0}r\_{d})=29.63^{+0.48}\_{-0.45}$ is determined with 1.6% precision. Most importantly,
this data combination also requires a nearly flat universe,
with a total density $\Omega\_{m}+\Omega\_{\Lambda}=1.011^{+0.014}\_{-0.016}$
determined to 1.5% and consistent with the critical density.
Thus, with the minimal assumption that the BAO scale is a standard ruler,
these data provide strong support for the standard cosmological
model.

Figure 3: Constraints from BAO on the parameters of $o\Lambda$CDM models,
treating the BAO scale as a redshift-independent standard
ruler of unknown length. Green curves/contours in each
panel show the combined constraints from galaxy and LyaF BAO,
with no CMB information. Black curves/contours include
the measurement of $D\_{M}(1090)/r\_{d}$ from the CMB acoustic
scale, again with no assumption about the value of $r\_{d}$
except that it is the same scale as the lower redshift measurements.
This combination of BAO measurements yields precise
constraints on $\Omega\_{\Lambda}$ (top panel) and the dimensionless
quantity $c/(H\_{0}r\_{d})$ (bottom panel), and it requires a low
density ($\Omega\_{m}\approx 0.29$), nearly flat universe
(middle panel). Blue and red curves in the top and
bottom panels show the result of combining the CMB BAO
measurement with either the galaxy or LyaF BAO
measurement separately. The dotted line in the middle panel
marks $\Omega\_{m}+\Omega\_{\Lambda}=1$.

### III.2 External calibration of $r\_{d}$

We proceed further by computing the sound horizon scale $r\_{d}$ from the
standard physics of the pre-recombination universe but adopting
empirical constraints external to the CMB. In particular, we adopt a
prior on the baryon density of $\omega\_{b}=0.02202\pm 0.00046$ determined
from big bang nucleosynthesis (BBN) and the observed primordial
deuterium abundance [[68](#bib.bib68)], and we assume a standard relativistic
background ($N\_{\rm eff}=3.046$, $\omega\_{\nu}\approx 0$). For any values
of $\Omega\_{m}$ and the Hubble parameter $h$ that arise in our MCMC
chain, we can then compute the value of $r\_{d}$ from
equation ([16](#S2.E16 "In II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")). Compared to the previous section, the
addition of the physical scale allows us to convert the measured value
of $c/(H\_{0}r\_{d})$ into a measurement of the dimensional parameter
$H\_{0}$. In practice, we derive constraints in a separate MCMC run
where, instead of a flat prior on $P$, we have a flat prior on $h$ and
the above prior on $\omega\_{b}$. We also fix the curvature parameter
$\Omega\_{k}$ to zero.
Results are presented in Figure [4](#S3.F4 "Figure 4 ‣ III.2 External calibration of 𝑟_𝑑 ‣ III BAO as an uncalibrated ruler ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"). The red
(galaxy BAO) and blue (LyaF BAO) contours in this figure use no CMB
information at all, but they do assume a spatially flat universe
in contrast to Figure [3](#S3.F3 "Figure 3 ‣ III.1 Convincing Detection of dark energy from BAO data alone ‣ III BAO as an uncalibrated ruler ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").

The point of this exercise is the following. The homogeneous part of the minimal
$\Lambda$CDM model has just two adjustable parameters, $\Omega\_{m}$ and $h$, which
matches the two degrees of freedom offered by a measurement of anisotropic BAO
at a single redshift.
(The weak BBN prior is required to fix the magnitude of $r\_{d}$, but it does
not affect the expansion history.)
One can therefore get meaningful constraints from
either galaxy BAO or LyaF BAO alone, though this is no longer
true if one allows non-zero curvature and therefore introduces a
third parameter.
There is substantial $\Omega\_{m}-h$
degeneracy for either measurement individually, but both are generally
compatible with standard values of these parameters. The tension of the LyaF BAO with the Planck $\Lambda$CDM model manifests itself here as a best fit at
relatively low matter density and high Hubble parameter. Combining the galaxy
and LyaF measurements produces a precise measurement of both
$\Omega\_{m}$ and the Hubble parameter coming from BAO alone,
independent of CMB data. In combination,
we find $h=0.67\pm 0.013$ and $\Omega\_{m}=0.29\pm 0.02$ (68% confidence).
The small black ellipse in Figure [4](#S3.F4 "Figure 4 ‣ III.2 External calibration of 𝑟_𝑑 ‣ III BAO as an uncalibrated ruler ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") shows the Planck constraints
for $\Lambda$CDM, computed from full Planck chains, which are in excellent agreement
with the region allowed by the joint BAO measurements.

Figure 4: Constraints on $\Omega\_{m}$ and $h$ in a flat $\Lambda$CDM model
from galaxy BAO (red), LyaF BAO (blue), and the combination
of the two (green), using a BBN prior on $\omega\_{b}$ and standard
physics to compute the sound horizon $r\_{d}$ but incorporating
no CMB information. Contours are plotted at 68%, 95%,
and 99.7% confidence (the interior white region of
the green “donut” is 68%).
Black contours show the entirely independent constraints on
$\Omega\_{m}$ and $h$ in $\Lambda$CDM from full Planck CMB chains.

## IV BAO, SNIa, and the Inverse Distance Ladder

The traditional route to measuring the Hubble constant $H\_{0}$
is built on a distance ladder anchored in the nearby Universe:
stellar distances to galaxies
within $\sim 20\,$Mpc are used to calibrate secondary indicators,
and these in turn are used to measure distances to galaxies
“in the Hubble flow,” i.e., far enough away that peculiar
velocities are a sub-dominant source of uncertainty when
inferring $H\_{0}=v/d$ [[69](#bib.bib69)].
The most powerful implementations of this program in recent
years have used Cepheid variables — calibrated by direct parallax,
by distance estimates to the LMC, or by the maser distance to
NGC 4258 — to determine distances to host galaxies of
SNIa, which are the most precise of the
available secondary distance indicators
[[70](#bib.bib70), [71](#bib.bib71), [72](#bib.bib72)].

Because the BAO scale can be computed in absolute units from basic
underlying physics, the combination of BAO with SNIa allows a
measurement of $H\_{0}$ via an “inverse distance ladder,” anchored at
intermediate redshift. The BOSS BAO data provide absolute values of
$D\_{V}$ at $z=0.32$ and $D\_{M}$ at $z=0.57$ with precision of 2.0% and
1.4%, respectively. The JLA SNIa sample provides a high-precision
relative distance scale, which transfers the BAO measurement down to
low redshift, where $H\_{0}$ is simply the slope of the distance-redshift
relation. Equivalently, this procedure calibrates the absolute
magnitude scale of SNIa using BAO distances instead of the
Cepheid distance scale.
Although the extrapolation from the BAO redshifts to
low redshifts depends on the dark energy model, the SNIa relative
distance scale is precisely measured over a well sampled redshift
interval which includes the BAO redshifts, so this extrapolation
introduces practically no uncertainty even when the dark energy model
is extremely flexible. CMB data enter the inverse distance ladder by
constraining the values of $\omega\_{m}$ and $\omega\_{b}$ and thus allowing
computation of the sound horizon scale $r\_{d}$.

Figure 5:  Determination of $H\_{0}$ by the “inverse distance ladder”
combining BAO absolute distance measurements and SNIa relative
distance measurements, with CMB data used to calibrate the sound
horizon scale $r\_{d}$. The quantity $c\ln(1+z)/D\_{M}(z)$
converges to $H\_{0}$ at $z=0$. Filled circles show the four BAO
measurements, normalized with $r\_{d}=147.49\,$Mpc; for the three
lower redshift points, $D\_{V}$ has been converted to $D\_{M}$ assuming
$\Lambda$CDM. Crosses show the SNIa measurements, with error bars
representing diagonal elements of the covariance matrix. Because
the absolute luminosity of SNIa is not known a priori, the
SNIa points are free to shift vertically by a constant factor,
which is chosen here to produce the best joint fit with the BAO data.
The red square and error bar shows the value $H\_{0}=(67.3\pm 1.1)\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$ determined by the full inverse distance ladder
procedure described in the text. The black curve shows the
prediction for a $\Lambda$CDM model with $\Omega\_{m}=0.3$ and the best-fit
$H\_{0}$, and green curves show ten PolyCDM models randomly selected
from our MCMC chain that have $\Delta\chi^{2}<4$ relative to the
best-fit PolyCDM model. This $H\_{0}$ determination assumes standard
pre-recombination physics to evaluate $r\_{d}$. For non-standard
energy backgrounds (e.g., extra relativistic species or early
dark energy) the more general result is described by
equation ([23](#S4.E23 "In IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")).

Figure [5](#S4.F5 "Figure 5 ‣ IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") provides a conceptual illustration
of this approach, zeroing in on the $z<1$ portion of the
Hubble diagram. Filled points show $c\ln(1+z)/D\_{M}(z)$ from the
CMASS, LOWZ, MGS, and 6dFGS BAO measurements, where for illustrative
purposes only we have converted the latter three measurements
from $D\_{V}(z)$ to $D\_{M}(z)$ using Planck $\Lambda$CDM parameters.
The error bars on these points include the 0.4% uncertainty
in $r\_{d}$ arising from the uncertainties in the Planck determination
of $\omega\_{m}$ and $\omega\_{b}$, but this is a small
contribution to the error budget. Crosses show the binned
SNIa distance measurements, with the best absolute magnitude
calibration from the joint BAO+SNIa fit. We caution that
systematic effects introduce error correlations across redshift
bins in the SNIa data, which are accounted for in our full analysis.
To allow flexibility in the dark energy model, we adopt the
PolyCDM parameterization described in Section [II.1](#S2.SS1 "II.1 Methodology ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"),
imposing a loose Gaussian prior $\Omega\_{k}=0\pm 0.1$ to suppress
high curvature models that are clearly inconsistent with the CMB.
Thin green curves in
Figure [5](#S4.F5 "Figure 5 ‣ IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") show $c\ln(1+z)/D\_{M}(z)$ for
ten PolyCDM models that have $\Delta\chi^{2}<4$ relative
to the best-fit model,
selected from the MCMC chains described below.
The intercept of these curves at $z=0$ is the value of $H\_{0}$.
While low-redshift BAO measurements like those of 6dFGS and MGS incur
minimal uncertainty from the extrapolation to $z=0$,
the statistical error is necessarily large because of the limited
volume at low $z$. It is evident from Figure [5](#S4.F5 "Figure 5 ‣ IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")
that using SNIa to transfer intermediate redshift BAO measurements
to the local Universe yields a much more precise determination of $H\_{0}$
than using only low-redshift BAO measurements, even allowing
for great flexibility in the dark energy model.

To compute our $H\_{0}$ constraints, we adopt the $D\_{M}(z)$ and $H(z)$
constraints from CMASS BAO (including covariance), the $D\_{V}(z)$
constraints from LOWZ, MGS, and 6dFGS BAO, the compressed JLA SNIa
data set with its full $31\times 31$ covariance matrix, and an $r\_{d}$
constraint from Planck (see Section [II.3](#S2.SS3 "II.3 Cosmic Microwave Background Data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")).
Marginalizing over the PolyCDM parameters yields
$H\_{0}=67.3\pm 1.1\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$, a 1.7% measurement.
Even if we include the CMB angular diameter distance at its full precision,
our central value and error bar on $H\_{0}$ change negligibly
because the flexibility of the PolyCDM model effectively
decouples low- and high-redshift information.

As a by-product of our $H\_{0}$ measurement, we determine the
absolute luminosity of a fiducial SNIa
to be $M\_{B}=-19.14\pm 0.042$ mag.
Here
we define a fiducial SNIa as having SALT2 (as retrained in [[30](#bib.bib30)])
light-curve width and color parameters $x\_{1}=0$ and $C=0$ and having exploded in
a galaxy with a stellar mass $<10^{10}M\_{\odot}.$

Our best-fit $H\_{0}$ and its $1\sigma$ uncertainty are shown by the open
square and error bar in Figures [2](#S2.F2 "Figure 2 ‣ II.5 Visualizing the BAO Constraints ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")
and [5](#S4.F5 "Figure 5 ‣ IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"). To characterize the sources of error, we
have repeated our analyses after multiplying either the CMB, SN, or BAO
covariance matrix by a factor of ten (and thus reducing errors by
$\sqrt{10}$). Reducing the CMB errors, so that they yield an
essentially perfect determination of $r\_{d}$, makes almost no difference
to our $H\_{0}$ error, because the 0.4% uncertainty in $r\_{d}$ is already
small. Reducing either the SNIa or BAO errors shrinks the $H\_{0}$
error by approximately a factor of two, indicating that the BAO
measurement uncertainties and the SNIa measurement uncertainties make
comparable contributions to our error budget; the errors add (roughly)
linearly rather than in quadrature because both measurements constrain
the redshift evolution in our joint fit. If we replace PolyCDM with
$ow\_{0}w\_{a}$CDM in our analysis, substituting a different but still highly
flexible dark energy model, the derived value of $H\_{0}$ drops by less
than $0.2\sigma$ and the error bar is essentially unchanged. If we
instead fix the dark energy model to $\Lambda$CDM, the central value and
error bar are again nearly unchanged, because with the dense sampling
provided by SNe the extrapolation from the BAO redshifts down to $z=0$
is also only a small source of uncertainty. To test sensitivity to
the SN data set, we constructed a compressed description of the Union
2.1 compilation [[64](#bib.bib64)] analogous to that of the JLA
compilation; substituting Union 2.1 for JLA makes negligible
difference to our best-fit $H\_{0}$ while increasing the error bar by
about 30% (see Table [3](#S4.T3 "Table 3 ‣ IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")). Finally, if we substitute
the WMAP9 constraints on $\omega\_{m}$ and $\omega\_{b}$ for the Planck
constraints, the central $H\_{0}$ decreases by 0.5% (to $66.9\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$)
and the error bar grows by 8% (to $1.2\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$).

To summarize, this 1.7% determination of $H\_{0}$ is robust to details of our
analysis, with the error dominated by the BAO and SNIa measurement
uncertainties. The key assumptions behind this method are (a)
standard matter and radiation content, with three species of light
neutrinos, and (b) no unrecognized systematics at the level of our
statistical errors in the CMB determinations of $\omega\_{m}$ and
$\omega\_{b}$, in the BAO measurements, or in the SNIa measurements used
to tie them to $z=0$. Note that the SNIa covariance matrix already
incorporates the detailed systematic error budget of [[30](#bib.bib30)].
The measurement systematics are arguably smaller than those that
affect the traditional distance ladder. Thus, with the caveat that it
assumes a standard matter and radiation content, this measurement of
$H\_{0}$ is more precise and probably more robust than current distance-ladder
measurements.

Non-standard radiation backgrounds remain a topic
of intense cosmological investigation, and a convincing mismatch
between $H\_{0}$ determinations from the forward and inverse distance
ladders could be a distinctive signature of non-standard
physics that alters $r\_{d}$. We can express our constraint in
a more model-independent form as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $H\_{0}=(67.3\pm 1.1)\times(147.49\,{\rm Mpc}/r\_{d})\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}.$ |  | (23) |

Raising $N\_{\rm eff}$ from 3.046 to 4.0
would increase our central value of $H\_{0}$ to $69.5\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$
(eq. [17](#S2.E17 "In II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"), but see further discussion in Section [VI.4](#S6.SS4 "VI.4 Extra Relativistic Species ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")).

Figure 6: Constraints on the Hubble constant $H\_{0}$ from
this paper’s inverse distance ladder analysis (blue, at bottom),
from three direct distance ladder estimates (red, at top),
and from Planck or WMAP CMB data assuming $\Lambda$CDM (green, middle). All error bars are $1\sigma$.
The inverse distance ladder estimates assume
$r\_{d}=147.49\pm 0.59$ Mpc, based on Planck constraints
for a standard radiation background, while the green points
make the much stronger assumptions of a flat universe with
a cosmological constant.

Figure [6](#S4.F6 "Figure 6 ‣ IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") compares our $H\_{0}$ determination to several
other values from the literature. The lower two points show our
results using either the PolyCDM model or the $ow\_{0}w\_{a}$CDM model.
The top three points show recent distance-ladder determinations
from Riess et al. [[70](#bib.bib70)], Freedman et al. [[71](#bib.bib71)],
and a reanalysis of the Riess et al. data set by [[73](#bib.bib73)].
There is mild ($\approx 2\sigma$) tension between these determinations
and our value.
The central two points show the values of $H\_{0}$ inferred
from Planck or WMAP CMB data assuming a flat $\Lambda$CDM model,
with values and uncertainties taken from the MCMC chains
provided by the Planck collaboration.
These inferences of $H\_{0}$ are much more model dependent
than our inverse distance ladder measurement; with the
$ow\_{0}w\_{a}$CDM or PolyCDM dark energy models the errors on $H\_{0}$ from CMB
data alone increase by more than order of magnitude because of
the CMB geometric degeneracy. Consistency of these $H\_{0}$ values is therefore a
consistency test for the $\Lambda$CDM model, which it passes here with
flying colors.

| Combination | Model | $H\_{0}$ |
| --- | --- | --- |
| Galaxy BAO + SN + $r\_{d}$ | PolyCDM | $67.3\pm 1.1$ |
| Galaxy BAO + SN + $r\_{d}$ | $ow\_{0}w\_{a}$CDM | $67.1\pm 1.1$ |
| Galaxy BAO + Union SN + $r\_{d}$ | PolyCDM | $67.3\pm 1.5$ |
| Galaxy BAO + Union SN + $r\_{d}$ | $ow\_{0}w\_{a}$CDM | $67.2\pm 1.5$ |

Table 3: Constraints on $H\_{0}$ (in $\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$) from the
inverse distance ladder, assuming $r\_{d}=147.49\pm 0.59$ Mpc
as inferred from Planck with a standard radiation background.
The bottom two lines substitute the Union 2.1 SN data set
for the JLA data set. Errorbars are $1\sigma$.

Our results can be compared to those of several other recent
analyses. [[74](#bib.bib74)] determine $H\_{0}$ from a collection of
BAO data sets using the Planck-calibrated value of $r\_{d}$.
They do not incorporate SNIa, but they assume a flat $\Lambda$CDM model,
which allows them to obtain a tight constraint
$H\_{0}=68.11\pm 0.86\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$.
[[75](#bib.bib75)] carry out a more directly comparable
inverse distance ladder measurement with essentially the
same data sets but cosmological models that are 1-parameter
extensions of $\Lambda$CDM, finding $H\_{0}=68.0\pm 1.2\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$
for either $o\Lambda$CDM or $w$CDM.
[[76](#bib.bib76)] carry out a rather different analysis that
uses age measurements for early-type galaxies to provide an
absolute timescale. In combination with BAO and SNIa, they then
constrain the acoustic oscillation scale $r\_{d}=101.9\pm 1.9h^{-1}\,{\rm Mpc}$
independent of CMB data or early universe physics.
Their result, which assumes an $o\Lambda$CDM cosmology,
can be cast in a form similar to ours,
$H\_{0}=(69.9\pm 1.3)\times(147.49\,{\rm Mpc}/r\_{d})\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$;
the agreement implies that their stellar evolution
age scale is consistent with the scale implied by early-universe
BAO physics. As an $H\_{0}$ determination, our analysis makes
much more general assumptions about dark energy than these
other analyses, but it yields a consistent result.
It is also notable that our value of $H\_{0}$ agrees with
the value of $67\pm 2\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$ inferred from a
median-statistics analysis of direct distance
ladder estimates circa 2001 ([[77](#bib.bib77)], see
[[78](#bib.bib78)] for a 2011 update).

From Figure [5](#S4.F5 "Figure 5 ‣ IV BAO, SNIa, and the Inverse Distance Ladder ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"), it is visually evident
that the relative distance scales implied by our BAO and
SN are in fairly good agreement. We have converted
SN luminosity distances to comoving angular diameter distances
with $D\_{M}(z)=D\_{L}(z)/(1+z)$, a relation that holds in any
metric theory of gravity (see section 4.2 of [[79](#bib.bib79)]
and references therein).
As a quantitative consistency test,
we refit the PolyCDM model with an additional free parameter
that artificially modifies the luminosity distance by
$D\_{L}(z)\rightarrow D\_{L}(1+z)^{\beta}$, finding $\beta=0.13\pm 0.063$.
This result is consistent with the expected $\beta=0$ at
$2\sigma$, but there is a mild tension because the SN data
are in good agreement with $\Lambda$CDM predictions while the
ratio of $D\_{M}(z)$ between the CMASS and LOWZ samples is
somewhat higher than expected in $\Lambda$CDM.

## V Constraints on Dark Energy Models

We now turn to constraints on dark energy and space curvature
from the combination of BAO, CMB, and SNIa data.
In this section, we consider models with standard matter
and radiation content, including three neutrino species
with the minimal allowed mass $\sum m\_{\nu}=0.06\,{\rm eV}$
(although the cosmological differences between $0.06\,{\rm eV}$ and $0\,{\rm eV}$
are negligible relative to current measurement errors).
In Section [VI](#S6 "VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"), we will consider models that
allow dynamically significant neutrino mass, extra relativistic
species, dark matter
that decays into radiation, or “early” dark energy
that is dynamically non-negligible even at high redshifts.

To set the scene, Figure [7](#S5.F7 "Figure 7 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") compares
the predictions of models constrained by CMB data
to the BOSS BAO constraints on $D\_{M}$ and $D\_{H}$ at $z=0.57$
and $z=2.34$, from CMASS galaxies and the LyaF, respectively.
Black dots mark best-fit values of $(D\_{M},D\_{H})$, and contours are
shown at $\Delta\chi^{2}=2.30,$ 6.18, and 11.83 (coverage
fractions of 68%, 95%, and 99.7% for a 2-d Gaussian).
The top row shows results for $o\Lambda$CDM models, which assume
a constant dark energy density but allow non-zero space curvature.
Here we have taken models from the Planck Collaboration MCMC
chains, based on the combination of Planck, WMAP polarization,
and ACT/SPT data. The upper right panel shows the one-dimensional
PDF for the curvature parameter $\Omega\_{k}$ based on the CMB
data alone. Each point in the left and middle panels
represents a model from the chains, color-coded by the value
of $\Omega\_{k}$ on the scale in the right panel.
The green cross-hairs mark the predicted $(D\_{M},D\_{H})$ from
the flat $\Lambda$CDM model that best fits the CMB data alone.
This model lies just outside the 68% contour
for CMASS, but it is discrepant at $>95\%$ with the
LyaF measurements, as remarked already by [[27](#bib.bib27)].
When the flatness assumption is dropped, both
the galaxy and LyaF BAO data strongly prefer $\Omega\_{k}$ close to zero, firmly
ruling out the slightly closed ($\Omega\_{k}\sim-0.05$)
models that are allowed by the CMB alone.

The bottom row shows results for $w$CDM models, which assume
a flat universe but allow a constant equation-of-state parameter
$w\equiv p/\rho\neq-1$ for dark energy.
The CMB data alone are consistent with a wide range of $w$ values,
and they are generally better fit with $w<-1$.
However, the combination with CMASS BAO data sharply
limits the acceptable range of $w$, favoring values
close to $-1.0$ (a cosmological constant).
The fit to the LyaF BAO results could be significantly
improved by going to $w\leq-1.3$, but this change would be
inconsistent with the CMASS measurements.
This example illustrates a general theme of our results:
parameter changes that improve agreement with the LyaF BAO measurements usually run afoul of the galaxy BAO measurements.

Figure 7: BAO constraints in the $D\_{M}-D\_{H}$ planes at $z=0.57$
(left) and $z=2.34$ (middle) compared to predictions of
$o\Lambda$CDM (top row) or $w$CDM (bottom row) models constrained
by CMB data. Black curves show 68%, 95%, and 99.7% likelihood
contours from the CMASS and LyaF BAO measurements,
relative to the best-fit values (black dots).
Colored points represent individual models from
Planck+WP+ACT/SPT MCMC chains, which are color-coded
by the value of $\Omega\_{k}$ (top row) or $w$ (bottom row)
as illustrated in the right panels.
Green cross-hairs mark the predictions of the flat
$\Lambda$CDM model that best fits the CMB data.
White curves show 68% and 95% likelihood contours
for the CMB data alone.

More quantitative constraints appear in Figure [8](#S5.F8 "Figure 8 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")
and Table [4](#S5.T4 "Table 4 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
We begin with $\Lambda$CDM and continue to the progressively more
flexible models described in Table [1](#S2.T1 "Table 1 ‣ II.1 Methodology ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
For CMB data, we now use the compression of Planck or WMAP9
constraints described in Section [II.3](#S2.SS3 "II.3 Cosmic Microwave Background Data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").

We include all of the BAO data listed in Table [2](#S2.T2 "Table 2 ‣ II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
Omitting the LyaF BAO data makes almost no difference to the
central values or error bars on model parameters, though it has
a significant impact on goodness-of-fit as we discuss later.

|  |  |
| --- | --- |
|  |  |
|  |  |
|  |  |

Figure 8: Constraints on interesting parameter combinations in
a variety of dark energy models: $\Lambda$CDM (upper
left), $o\Lambda$CDM (upper right), $w$CDM (middle left), $ow$CDM (middle
right), $w\_{0}w\_{a}$CDM (bottom left) and $ow\_{0}w\_{a}$CDM (bottom right).
Curves show 68%, 95%, and 99.7% confidence contours for
the data combinations indicated in the legend.
In the top panels the red contours are almost
fully obscured by the green contours because the
BAO+Planck combination is already as constraining as
the BAO+SN+Planck combination, but for models with
freedom in dark energy the SN and BAO constraints
are complementary.
The bottom panels, with evolving $w(z)$, display
the value of $w$ at $z=0.266$, the “pivot” redshift
where $w$ is best constrained by BAO+SN+Planck in the
$w\_{0}w\_{a}$CDM model.
For our BAO+SN+Planck contours, the white zone
interior to the dark green annulus marks the 68% confidence
region, and the outer edge of the dark annulus is 95%.

For $\Lambda$CDM and $o\Lambda$CDM, the combination of Planck CMB constraints and
BAO is remarkably powerful, a point already emphasized by
[[29](#bib.bib29)]. Adding SN data makes negligible difference to the
parameter constraints of these models; SN+Planck constraints have
nearly identical central values to BAO+Planck, but larger errors. In
$\Lambda$CDM, substituting BAO+SN+WMAP9 for BAO+SN+Planck has a tiny effect,
shifting $\Omega\_{m}=0.302\pm 0.008$ to $\Omega\_{m}=0.300\pm 0.008$
with a small compensating shift in $h$. Figure [8](#S5.F8 "Figure 8 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")
illustrates the extremely tight curvature constraint that comes from
combining CMB and BAO data: for $o\Lambda$CDM we find $\Omega\_{k}=-0.003\pm 0.003$ using Planck CMB or $\Omega\_{k}=-0.004\pm 0.004$ using WMAP9.

Supernovae play a much more important role in models that allow
$w\neq-1$, as their high precision relative distance measurements provide
strong constraints on low-redshift acceleration. For both
$w$CDM and $ow$CDM, SN+Planck and BAO+Planck constraints are
perfectly consistent but complementary, and the combination of
all three data sets provides much tighter error bars than
any pairwise combination. For $w$CDM we find $w=-0.97\pm 0.05$.
For $ow$CDM the curvature constraint from BAO is particularly
important, lifting the degeneracy between $w$ and $\Omega\_{k}$
that arises for SN+CMB alone; we find $w=-0.98\pm 0.06$ and
$\Omega\_{k}=-0.002\pm 0.003$.
Substituting WMAP9 for Planck again produces only slight shifts
to central values and a minor increase of error bars.

Even with these powerful BAO, SN, and CMB data sets, constraining the
evolution of $w$ is difficult. The constraint on the evolution
parameter from BAO+SN+Planck is $w\_{a}=-0.2\pm 0.4$ in $w\_{0}w\_{a}$CDM and
weakens to $w\_{a}=-0.6\pm 0.6$ in $ow\_{0}w\_{a}$CDM. Both results are
consistent with constant $w$, but they allow order unity changes of
$w$ at $z<1$. This data combination still provides a good
constraint on the value of $w$ at a “pivot” redshift $z\_{p}=0.266$
where it is uncorrelated with $w\_{a}$ (determined specifically for
$w\_{0}w\_{a}$CDMfor BAO+SN+Planck combiations): $w(0.266)=-0.97\pm 0.05$ in
$w\_{0}w\_{a}$CDM and $-0.99\pm 0.06$ in $ow\_{0}w\_{a}$CDM.

We note that the degradation of our ability to constrain the evolution
of the equation of state is not accompanied with significant
degradation in our ability to measure the curvature of space: the
constraint on curvature remains tight even when allowing an evolving
equation of state, $\Omega\_{k}=-0.005\pm 0.004$.

By decoupling the time dependence of $w$ from its present-day value,
the $w\_{0}-w\_{a}$ model allows flexible evolution of the dark energy density.
Adopting a particular form for the dark energy potential reduces
this freedom, and one can construct physically motivated models
that have evolving dark energy but do not require an additional
free parameter to describe it.
[[80](#bib.bib80)] advocate an interesting example of this model class,
in which dark energy is a slowly rolling scalar field with a
$\frac{1}{2}m^{2}\phi^{2}$ potential, analogous to the inflaton
of chaotic inflation models.
[[80](#bib.bib80)] show that this model yields
$\delta w(z)\equiv 1+w(z)\approx\delta w\_{0}\times H\_{0}^{2}/H^{2}(z)$
and therefore [[81](#bib.bib81)]

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{H^{2}(z)}{H^{2}\_{0}}$ | $\displaystyle\approx$ | $\displaystyle\Omega\_{m}(1+z)^{3}$ |  | (24) |
|  |  | $\displaystyle+$ | $\displaystyle\Omega\_{\rm de}\left[\frac{(1+z)^{3}}{\Omega\_{m}(1+z)^{3}+\Omega\_{\rm de}}\right]^{\delta w\_{0}/\Omega\_{\rm de}},$ |  |

where
the approximation is first-order in $\delta w\_{0}=1+w\_{0}$.

| Model | Data | $\Omega\_{m}$ | $\Omega\_{b}h^{2}$ | $h$ | $\Omega\_{k}$ | $w$ | $w\_{a}$ |
| --- | --- | --- | --- | --- | --- | --- | --- |
| $\Lambda$CDM | BAO+Planck | 0.303 (8) | 0.0223 (3) | 0.682 (7) | – | – | – |
| $\Lambda$CDM | SN+Planck | 0.295 (16) | 0.0224 (3) | 0.688 (13) | – | – | – |
| $\Lambda$CDM | BAO+SN+Planck | 0.302 (8) | 0.0223 (3) | 0.682 (6) | – | – | – |
| $\Lambda$CDM | BAO+SN+WMAP | 0.300 (8) | 0.0224 (5) | 0.681 (7) | – | – | – |
| $o\Lambda$CDM | BAO+Planck | 0.301 (8) | 0.0225 (3) | 0.679 (7) | -0.003 (3) | – | – |
| $o\Lambda$CDM | SN+Planck | 0.30 (4) | 0.0224 (4) | 0.68 (4) | -0.002 (10) | – | – |
| $o\Lambda$CDM | BAO+SN+Planck | 0.301 (8) | 0.0225 (3) | 0.679 (7) | -0.003 (3) | – | – |
| $o\Lambda$CDM | BAO+SN+WMAP | 0.295 (9) | 0.0226 (5) | 0.677 (8) | -0.004 (4) | – | – |
| $w$CDM | BAO+Planck | 0.311 (13) | 0.0225 (3) | 0.669 (17) | – | -0.94 (8) | – |
| $w$CDM | SN+Planck | 0.298 (18) | 0.0225 (4) | 0.685 (17) | – | -0.99 (6) | – |
| $w$CDM | BAO+SN+Planck | 0.305 (10) | 0.0224 (3) | 0.676 (11) | – | -0.97 (5) | – |
| $w$CDM | BAO+SN+WMAP | 0.303 (10) | 0.0225 (5) | 0.674 (12) | – | -0.96 (6) | – |
| $ow$CDM | BAO+Planck | 0.308 (17) | 0.0225 (4) | 0.671 (19) | -0.001 (4) | -0.95 (11) | – |
| $ow$CDM | SN+Planck | 0.28 (8) | 0.0225 (4) | 0.73 (11) | 0.01 (3) | -0.97 (18) | – |
| $ow$CDM | BAO+SN+Planck | 0.303 (10) | 0.0225 (4) | 0.676 (11) | -0.002 (3) | -0.98 (6) | – |
| $ow$CDM | BAO+SN+WMAP | 0.299 (11) | 0.0227 (5) | 0.671 (12) | -0.004 (4) | -0.96 (6) | – |
| $w\_{0}w\_{a}$CDM | BAO+Planck | 0.34 (3) | 0.0224 (3) | 0.639 (25) | – | -0.58 (24) | -1.0 (6) |
| $w\_{0}w\_{a}$CDM | SN+Planck | 0.292 (23) | 0.0224 (4) | 0.693 (24) | – | -0.90 (16) | -0.5 (8) |
| $w\_{0}w\_{a}$CDM | BAO+SN+Planck | 0.307 (11) | 0.0223 (3) | 0.676 (11) | – | -0.93 (11) | -0.2 (4) |
| $w\_{0}w\_{a}$CDM | BAO+SN+WMAP | 0.305 (11) | 0.0224 (5) | 0.674 (12) | – | -0.93 (11) | -0.2 (5) |
| $ow\_{0}w\_{a}$CDM | BAO+Planck | 0.34 (3) | 0.0225 (4) | 0.640 (25) | -0.003 (4) | -0.57 (23) | -1.1 (6) |
| $ow\_{0}w\_{a}$CDM | SN+Planck | 0.29 (8) | 0.0225 (4) | 0.72 (11) | 0.01 (3) | -0.94 (21) | -0.3 (9) |
| $ow\_{0}w\_{a}$CDM | BAO+SN+Planck | 0.307 (11) | 0.0225 (4) | 0.673 (11) | -0.005 (4) | -0.87 (12) | -0.6 (6) |
| $ow\_{0}w\_{a}$CDM | BAO+SN+WMAP | 0.302 (11) | 0.0227 (5) | 0.670 (12) | -0.006 (5) | -0.88 (11) | -0.5 (5) |
| SlowRDE | BAO+SN+Planck | 0.307 (10) | 0.0224 (3) | 0.676 (11) | – | -0.95 (7) | – |

Table 4: Cosmological parameter constraints from Galaxy+LyaF BAO data
combined with our compressed description of CMB constraints
from Planck+WP or WMAP9 and the JLA SN data.
Entries for which the parameter is fixed in the listed cosmological model
are marked with a dash.
For $w\_{0}w\_{a}$CDM and $ow\_{0}w\_{a}$CDM, column 7 lists the value of
$w$ at $z=0.266$, which is the “pivot” redshift for $w\_{0}w\_{a}$CDM with the full data combination.
For SlowRDE, this column lists $w=\delta w\_{0}-1$.

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  | $\rho\_{DE}/\rho\_{c}$ | | | |
|  | $\Omega\_{m}$ | $H\_{0}$ | $z<0.5$ | $0.5<z<1.0$ | $1.0<z<1.6$ | $1.6<z$ |
| Suzuki et al 2012 [[64](#bib.bib64)] | … | … | $0.731^{+0.015}\_{-0.014}$ | $0.880^{+0.240}\_{-0.210}$ | $0.330^{+1.900}\_{-1.000}$ | $0.700^{+2.400}\_{-1.800}$ |
| BAO+PLANCK | $0.317\_{-0.020}^{+0.009}$ | $66.4\_{-0.9}^{+1.5}$ | $0.667^{+0.026}\_{-0.012}$ | $0.844^{+0.194}\_{-0.188}$ | $8.581^{+5.237}\_{-6.278}$ | $-0.921^{+0.897}\_{-0.611}$ |
| BAO+SN+PLANCK | $0.307\_{-0.014}^{+0.012}$ | $67.3\_{-1.0}^{+1.5}$ | $0.685^{+0.022}\_{-0.016}$ | $0.765^{+0.146}\_{-0.165}$ | $5.154^{+4.761}\_{-4.259}$ | $-0.634^{+0.957}\_{-0.601}$ |

Table 5: Parameter constraints in the model in which $\rho\_{\rm de}(z)$ is
held constant in four discrete bins of redshift.
Uncertainties on each parameter are marginalized over all others,
including $\Omega\_{b}h^{2}$, which is not listed in the table. $H\_{0}$ is in
km s-1 Mpc-1.

Figure [9](#S5.F9 "Figure 9 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") presents parameter constraints for the slow
roll dark energy scenario in a flat universe, a model that has the
same number of parameters as $w$CDM.
BAO and SN both contribute to the constraints of the joint fit,
which yields $\delta w\_{0}=0.05\pm 0.07$,
$h=0.675\pm 0.011$, and $\Omega\_{m}=0.306\pm 0.010$.
Results for this scenario are thus consistent with $\Lambda$CDM but allow
small departures from $w\_{0}=-1$.

A striking feature of Table [4](#S5.T4 "Table 4 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") is that
the best-fit parameter values barely shift as additional freedom
is added to the models. For the BAO+SN+Planck combination,
the best-fit $\Omega\_{m}$ values range from 0.301 to 0.307
and the best-fit $h$ values from 0.676 to 0.682,
while combinations with WMAP9 favor just slightly lower values
of $\Omega\_{m}$ and $h$.
More importantly, models that allow dark energy
evolution are all consistent with constant $w=-1.0$ at $\approx 1\sigma$,
and $\Omega\_{k}$ is consistent with zero at $1\sigma$
in all cases that allow curvature.
The fact that models with additional freedom remain consistent
with $\Lambda$CDM is a substantial argument in favor of this minimal model.

Figure [10](#S5.F10 "Figure 10 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") illustrates the goodness-of-fit for
the models in Table [4](#S5.T4 "Table 4 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"), and for additional
models discussed below in Section [VI](#S6 "VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
For the best-fit parameter values in each model,
horizontal bars show the total $\chi^{2}$, with colors
indicating the separate contributions from the JLA SN data, the various
galaxy BAO data sets,
and the LyaF auto-correlation and cross-correlation measurements.
For visualization purposes, we have subtracted 30 from
the SN $\chi^{2}$, which would otherwise dominate the total
length of these bars because there are 31 SN data points and
many fewer in other data sets. The constraints on
$\omega\_{cb}$, $\omega\_{b}$, and $D\_{M}(1090)/r\_{d}$ from the
CMB are sufficiently tight that parameter variations within
the allowed range have minimal impact on other observables.
Our minimization yields $\chi^{2}\approx 0$ for the CMB data
in essentially every case, since all the models have enough
parameters to fit the three (compressed) CMB constraints perfectly.
For this plot, we have chosen to omit the CMB constraints from
both the $\chi^{2}$ sum and the degrees-of-freedom (d.o.f.)
computation, though these constraints are still used
when determining model parameters.

The bottom bar in Figure [10](#S5.F10 "Figure 10 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") indicates the number of
d.o.f. associated with each data set: 31 for SNe, one each
for the $D\_{V}$ measurements from LOWZ, MGS, and 6dFGS, two
for the $D\_{M}$ and $D\_{H}$ measurements from CMASS, and two
each ($D\_{M}$ and $D\_{H}$) for LyaF auto- and cross-correlation, totaling 40.
Numbers to the right of each model bar list the $\chi^{2}$ of the model
fit and the corresponding d.o.f. after subtracting the number of fit
parameters. For $\Lambda$CDM, for example, we count as free parameters
$\Omega\_{m}$, $h$, and the SNIa absolute magnitude normalization $M\_{0}$,
yielding d.o.f.$=40-3=37$. We omit
$\omega\_{b}$ because it is determined almost entirely by the CMB data,
which we have excluded from the $\chi^{2}$ sum. The total $\chi^{2}$ for this
model is 46.79, with a one-tailed $p$-value (probability of obtaining
$\chi^{2}\geq 46.79$) of 0.13 for 37 d.o.f.
Thus, if we consider all of the data collectively, the fit
of the $\Lambda$CDM model is acceptable, and for any of the more
complex models considered so far the reduction in $\chi^{2}$ is
smaller than the number of additional free parameters in the model.

As already emphasized in our discussion, the $\Lambda$CDM model does not give a
good fit to the LyaF BAO data. This tension is evident in
Figure [10](#S5.F10 "Figure 10 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") in the length of the yellow and green $\chi^{2}$
bars relative to the corresponding d.o.f. Combining the
Lyman-$\alpha$ auto- and cross-correlation
measurements into a single likelihood
because they measure the same quantities,
the $\Lambda$CDM $\chi^{2}\_{{\rm Ly}\alpha}=8.3$ for two d.o.f.
has a $p$-value of 0.016, consistent with
Figure [7](#S5.F7 "Figure 7 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"). It is unclear how much to make of
this mild tension in the context of a fit that yields
adequate-to-excellent agreement with multiple other data sets and an
acceptable $\chi^{2}$ overall. It is evident that none of the more
complex models considered so far allows a significantly better fit to
the LyaF BAO data. The partial exception is $ow\_{0}w\_{a}$CDM, which has
the most freedom to adjust high-redshift behavior relative to
low-redshift behavior, but even here the reduction in $\chi^{2}$
relative to $\Lambda$CDM is only 1.33 (coming almost entirely from LyaF),
for three additional model parameters. Omitting the LyaF data makes
almost no difference to the best-fit parameter values or their error
bars in any of these models, which are driven mainly by the
high-precision CMB, CMASS, and SN constraints.

To conclude this section, we examine a model
in which dark energy is characterized by specifying its energy density
in four discrete bins of redshift:
$z<0.5$, $0.5<z<1.0$, $1.0<z<1.6$, and $z>1.6$.
This step-wise model is a useful complement to models that
specify $\rho\_{\rm de}(z)$ through parameterized descriptions of $w(z)$.
The bins are chosen to be the same as the ones considered in
a similar analysis by [[64](#bib.bib64)] (their Table 8),
who combined Union 2.1 SN data,
WMAP7 CMB data [[82](#bib.bib82)],
BAO from the combined analysis of SDSS DR7 and 2dFGRS
[[83](#bib.bib83)],
and the distance-ladder $H\_{0}$ measurement of [[70](#bib.bib70)].
We fit simultaneously for $\rho\_{\rm de}(z)$ in each of these bins and
for the values of $\Omega\_{m}$, $\Omega\_{b}$, and $H\_{0}$, assuming
$\Omega\_{k}=0$ to match [[64](#bib.bib64)].
Within an individual bin, $\rho\_{\rm de}$ is held constant and $H(z)$
evolves according to the Friedmann equation, but there are
discontinuities in $H(z)$ at bin boundaries to accommodate the
discontinuous changes in $\rho\_{\rm de}(z)$. The matter density evolves
as $\rho\_{m}(z)=\Omega\_{m}\rho\_{\rm crit}(1+z)^{3}$, where $\Omega\_{m}$ and
$\rho\_{\rm crit}$ denote $z=0$ values as usual.

Constraints on this model
from our BAO+Planck and BAO+SN+Planck data combinations
appear in Figure [11](#S5.F11 "Figure 11 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") and Table [5](#S5.T5 "Table 5 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
As in our other models that allow time-varying dark energy,
BAO and SN data both contribute significantly to the parameter
constraints.
Our results show a clear detection of non-zero dark energy density
in each of the first two redshift bins at $z<1$, and they are
consistent with a constant energy density across this redshift range.
Compared to [[64](#bib.bib64)], we obtain a significantly tighter
constraint in the $0.5<z<1.0$ bin, where the CMASS BAO
measurement makes an important difference, but a slightly looser
constraint in the $z<0.5$ bin, where we do not incorporate
a direct $H\_{0}$ measurement.
We obtain much poorer constraints in the $1<z<1.6$ bin
because the JLA sample contains only 8 SNe with $z>1$ compared to 29
for the Union 2.1 sample.
At $z>1.6$ our constraint is stronger thanks to the LyaF BAO
measurement, but the uncertainty is large nonetheless, and
the low LyaF value of $H(z)$ leads to a preference for
negative dark energy density in this bin, although consistent
with zero at $1\sigma$.

Figure 9: Constraints on $h$ and $\delta w\_{0}\equiv 1+w\_{0}$ in
the slow roll dark energy model (eq. [24](#S5.E24 "In V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")),
in the same format as Fig. [8](#S5.F8 "Figure 8 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").

Figure 10: $\chi^{2}$ values for the best-fit versions of
cosmological models considered in the paper.
Each bar represents the minimum $\chi^{2}$ for the model
listed at the left axis, and colors show the $\chi^{2}$
contributions of individual data sets.
For better visualization, we subtract 30 from the SN $\chi^{2}$.
CMB contributions are not included but (with our 3-parameter
compression) are always close to zero.
The total $\chi^{2}$ and model degrees-of-freedom (d.o.f.,
40 data points minus number of fit parameters, which includes
the SNIa absolute magnitude normalization as well as cosmological
quantities) are listed
to the right of each bar.
The bottom bar shows the number of d.o.f. associated with
each data set.
For the $\Delta N\_{\rm eff}$ model we use cosmomc rather than
our compressed CMB description, but we again omit CMB
contributions to $\chi^{2}$.

Figure 11: Constraints on $\rho\_{DE}(z)$ assumed to be constant
within redshift bins, in units of the present-day critical density $\rho\_{c}$.
Shaded areas represent 68% confidence levels.
Yellow bands show constraints in the same bins from [[64](#bib.bib64)].
Our constraints in the $z=1.0-1.6$ bin are omitted.

## VI Alternative Models

We now turn to models with more unusual histories of the
dark energy, matter, or radiation components.
In part we want to know what constraints
our combined data can place on interesting physical quantities, such
as neutrino masses, extra relativistic species, dark energy that is
dynamically significant at early times, or dark matter that decays
into radiation over the history of the universe. We also want to see
whether any of these alternative models can resolve the tension with
the LyaF measurements at $z=2.34$, which persists in all of the
models considered in Section [V](#S5 "V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
We begin with the early dark energy model, because understanding
the origin of the constraints on this model informs the discussion
of subsequent models.

### VI.1 Early Dark Energy

In typical dark energy models, including all of those
discussed in Section [V](#S5 "V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"), dark energy is
dynamically negligible at high redshifts because its
energy density grows with redshift much more slowly
than $(1+z)^{3}$.
However, some scalar field potentials yield a dark
energy density that tracks the energy density of
the dominant species during the radiation and matter
dominated eras, then asymptotes towards a cosmological
constant at late times [[84](#bib.bib84), [85](#bib.bib85)].
These models ameliorate, to some degree, the
“coincidence problem” of constant-$w$ models
because the ratio of dark energy density to total
energy density varies over a much smaller range.

As a generic parameterized form of such early dark energy models,
we adopt the formulation of Doran & Robbers [[86](#bib.bib86)],
in which the density
parameter of the dark energy component evolves with $a=(1+z)^{-1}$ as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Omega\_{\rm de}(a)={\Omega\_{\rm de}-\Omega\_{\rm de}^{e}\left(1-a^{-3w\_{0}}\right)\over\Omega\_{\rm de}+\Omega\_{m}a^{3w\_{0}}}+\Omega\_{\rm de}^{e}\left(1-a^{-3w\_{0}}\right)\penalty\ ,$ |  | (25) |

where $\Omega\_{\rm de}$ and $\Omega\_{m}$ denote $z=0$ values as usual
and $\Omega\_{\rm de}^{e}$ is the dark energy density parameter at early times.
A flat universe is assumed, with $\Omega\_{\rm de}+\Omega\_{m}=1$.
The quantity $w\_{0}$ is the effective value of the equation-of-state
parameter today. At high redshift ($a\ll 1$),
the denominator of the first term is $\gg 1$, and $\Omega\_{d}(a)$
approaches the constant value $\Omega\_{\rm de}^{e}$.
This in turn requires a dark energy density that scales
as $a^{-3}$ in the matter-dominated era and as $a^{-4}$
in the radiation-dominated era, though it is $\Omega\_{\rm de}(a)$
rather than $\rho\_{\rm de}(a)$ that is specified explicitly.
For $w\_{0}=-1$, the model approaches $\Lambda$CDM as $\Omega\_{\rm de}^{e}$ goes to zero.
There are other generic forms of models with early dark energy,
as well as non-parametric descriptions (see discussion by
[[87](#bib.bib87)]).

Figure 12: Predicted BAO scales for early dark energy models with
CMB observables $\Omega\_{b}h^{2}$, $\Omega\_{m}h^{2}$, and $D\_{M}(1090)/r\_{d}$
held fixed to the values of the best-fit Planck+WP $\Lambda$CDM model.
We adopt equation ([25](#S6.E25 "In VI.1 Early Dark Energy ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")) with $w\_{0}=-1$.
Solid lines show the case in which $r\_{d}$ is rescaled by
$(1-\Omega\_{\rm de}^{e})^{1/2}$ to represent the effect of early dark
energy in the pre-recombination era, while dashed lines show the
case in which $r\_{d}$ is held fixed at the fiducial model value
of $r\_{d}=147.49$ Mpc. We show ratios of $D\_{H}(z)/r\_{d}$ (top) or
$D\_{M}(z)/r\_{d}$ (bottom) relative to the fiducial ($\Omega\_{\rm de}^{e}=0$) model.
Points with error bars show the BAO measurements from
CMASS galaxies at $z=0.57$ (filled square) and from LyaF auto-correlation
(open circle) and cross-correlation (filled circle) at $z=2.34$.
For visual clarity, the LyaF cross-correlation points have been slightly
shifted in redshift.

Figure 13: Constraints in the $\Omega\_{\rm de}^{e}-\Omega\_{m}$ plane from
the combination of our compressed CMB description with galaxy+LyaF BAO data. Black contours (68%, 95%, and 99.7%) show the tight
constraints on early dark energy for models with fixed $r\_{d}=147.49$ Mpc.
Blue contours show the constraints for models with
$r\_{d}\propto(1-\Omega\_{\rm de}^{e})^{1/2}$ as expected if $\Omega\_{\rm de}^{e}$ is
constant into the radiation-dominated era.
The red solid line traces the parameter degeneracy
$\Omega\_{m}=\Omega\_{m,{\rm fid}}(1-\Omega\_{\rm de}^{e})$ predicted
by the approximate scaling arguments described in the text.

If dark energy is important in
the pre-recombination era, then the boosted energy density
in this era reduces the sound horizon
by a factor $(1-\Omega\_{\rm de}^{e})^{1/2}$ relative
to a conventional model with the same parameters
[[86](#bib.bib86), [87](#bib.bib87)].
Pre-recombination dark energy also influences the detailed shape
of the CMB anisotropy spectrum by altering the early integrated
Sachs-Wolfe contribution and the CMB damping tail [[88](#bib.bib88)].
Our analysis here incorporates the rescaling of the sound horizon,
but we continue to use the compressed CMB description
of Section [II.3](#S2.SS3 "II.3 Cosmic Microwave Background Data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") and therefore
ignore the more detailed changes to the power spectrum shape.
Because of the exquisite precision of CMB measurements, the
power spectrum shape may impose tighter constraints
on early dark energy than the expansion history measurements
employed here (see, e.g., [[88](#bib.bib88)]).
However, those constraints are more dependent on the specifics
of the models being examined, both the dark energy evolution
and other parameters that describe the inflationary spectrum,
tensor fluctuations, relativistic energy density, and reionization.

Figure [12](#S6.F12 "Figure 12 ‣ VI.1 Early Dark Energy ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")
plots the evolution of $D\_{H}(z)/r\_{d}$ and $D\_{M}(z)/r\_{d}$ for models
with $\Omega\_{\rm de}^{e}=0,$ 0.02, 0.04, and 0.08.
We always adopt $w\_{0}=-1$, but we constrain
$h$, $\Omega\_{b}$, and $\Omega\_{m}=1-\Omega\_{\rm de}-\Omega\_{\nu+r}$
by fixing $\Omega\_{b}h^{2}$, $\Omega\_{m}h^{2}$, and
$D\_{M}(1090)/r\_{d}$ to the values in the best-fit
Planck+WP $\Lambda$CDM model, in effect forcing the errors in our
compressed CMB description to zero.
Solid curves incorporate the expected
$(1-\Omega\_{\rm de}^{e})^{1/2}$ reduction of $r\_{d}$.
Dotted curves show the case in which we instead keep $r\_{d}$ fixed
at its fiducial value of 147.49 Mpc.
The latter case would be physically relevant in a model where dark energy is
dynamically negligible in the pre-recombination era
but approaches the evolution of equation ([25](#S6.E25 "In VI.1 Early Dark Energy ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"))
later in the matter dominated era.
To highlight model differences, we scale all values to those
of the fiducial $\Lambda$CDM model, which corresponds to $\Omega\_{\rm de}^{e}=0$.

Remarkably, for the rescaled $r\_{d}$ case, the predicted values
of $D\_{H}(z)/r\_{d}$ and $D\_{M}(z)/r\_{d}$ change by less than 0.5% at
all redshifts, even for $\Omega\_{\rm de}^{e}=0.08$.
We can understand this insensitivity by considering the low and
high-redshift limits for the simplified case of a flat cosmology
with only matter and dark energy. The matter density at redshift $z$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}\rho\_{m}(z)&=\rho\_{\rm crit}\times\Omega\_{m}(1+z)^{3}\\ &={3\left(100\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}\right)^{2}\over 8\pi G}\times\left(\Omega\_{m}h^{2}\right)(1+z)^{3}\penalty\ ,\end{split}$ |  | (26) |

where $\rho\_{\rm crit}$ denotes the $z=0$ value as usual and we have used
$H\_{0}=100h\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$ but relocated $h$ to the second factor.
Using $\rho\_{m}(z)+\rho\_{\rm de}(z)=\rho\_{\rm crit}(z)=3H^{2}(z)/8\pi G$ implies

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}H(z)=&\left(100\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}\right)\times\left[\left(\Omega\_{m}h^{2}\right)(1+z)^{3}\right]^{1/2}\\ &\times\left[1+\rho\_{\rm de}(z)/\rho\_{m}(z)\right]^{1/2}\penalty\ .\end{split}$ |  | (27) |

For a cosmological constant, $\rho\_{\rm de}(z)/\rho\_{m}(z)\propto(1+z)^{-3}$,
so the ratio tends rapidly to zero at high redshift, but for the early
dark energy model this ratio asymptotes instead to
$\Omega\_{\rm de}^{e}/\Omega\_{m}(z)\approx\Omega\_{\rm de}^{e}/(1-\Omega\_{\rm de}^{e})$.
Thus, at fixed
$\Omega\_{m}h^{2}$, $H(z)$ is higher in the early dark energy model by a factor
$(1-\Omega\_{\rm de}^{e})^{-1/2}$, and $D\_{H}(z)$ is smaller by the same factor.
This reduction in $D\_{H}(z)$ exactly compensates the $(1-\Omega\_{\rm de})^{1/2}$
rescaling of $r\_{d}$,
leaving $D\_{H}(z)/r\_{d}$ independent of $\Omega\_{\rm de}^{e}$.

At low redshift, conversely,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D\_{M}(z)={c\over H\_{0}}\int\_{0}^{z}{H\_{0}\over H(z^{\prime})}dz^{\prime}$ |  | (28) |

depends mainly on $H\_{0}$, since the evolution of $H\_{0}/H(z)$ is
insensitive to moderate changes in $\Omega\_{m}$ and $\Omega\_{\rm de}$
for $z\ll 1$. Therefore, to keep the value of $D\_{M}(1090)/r\_{d}$
fixed to the CMB constraint, one must increase $H\_{0}$ by approximately
$(1-\Omega\_{\rm de}^{e})^{-1/2}$ so that both the low and high-redshift
contributions to $D\_{M}(1090)$ shrink by the factor required to compensate
the change in $r\_{d}$. This change again forces $D\_{H}(z)/r\_{d}$ to nearly
the same value as the fiducial model with $\Omega\_{\rm de}^{e}=0$.

These scaling arguments are not perfect because they break down at
intermediate redshifts and because a change in $H\_{0}$ at fixed
$\Omega\_{m}h^{2}$ implies a change in $\Omega\_{m}$, which itself affects
the low-redshift evolution of $H\_{0}/H(z)$. Nonetheless, the full
calculation in Figure [12](#S6.F12 "Figure 12 ‣ VI.1 Early Dark Energy ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")
demonstrates that for $\Omega\_{\rm de}^{e}$ as large as 0.08 there is minimal
change in $D\_{H}(z)$ at any redshift, and minimal
change in $H(z)$ in turn implies minimal change in $D\_{M}(z)$.
However, the values of $H\_{0}$ are larger, and $\Omega\_{m}$ correspondingly
smaller, for the successively higher $\Omega\_{\rm de}^{e}$
curves in Figure [12](#S6.F12 "Figure 12 ‣ VI.1 Early Dark Energy ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
The combination $H\_{0}r\_{d}$ is nearly constant, decreasing by just 0.14%,
0.24%, and 0.49% for $\Omega\_{\rm de}^{e}=0.02$, 0.04, and 0.08, respectively.

Reversing these arguments explains why $D\_{H}(z)$ and $D\_{M}(z)$ change
rapidly with $\Omega\_{\rm de}^{e}$ if $r\_{d}$ stays fixed instead of rescaling
(dashed curves in Fig. [12](#S6.F12 "Figure 12 ‣ VI.1 Early Dark Energy ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")).
In this case, $D\_{M}(1090)$ must stay fixed to keep the angular
scale of the acoustic peaks unchanged, so the decrease of
high-redshift contributions to
$D\_{M}(z)$ by $(1-\Omega\_{\rm de}^{e})^{1/2}$ requires
a compensating increase of $D\_{M}(z)$ at low redshift. This requires
a large fractional reduction in $H\_{0}$, since most of the contribution
to $D\_{M}(1090)$ comes from high redshift (e.g., 75% from $z>1$).
This in turn leads to large deviations in $D\_{H}(z)/r\_{d}$ and $D\_{M}(z)/r\_{d}$
at low redshift. At high redshift, $D\_{H}(z)$ is again smaller
by $(1-\Omega\_{\rm de}^{e})^{1/2}$, but this now leads to a deviation in
$D\_{H}(z)/r\_{d}$ because it is no longer compensated by a smaller $r\_{d}$.
Even for $\Omega\_{\rm de}^{e}=0.02$, fixing CMB observables requires a 4.3%
reduction in $H\_{0}$. Furthermore, adding early dark energy in this
case moves model predictions further from the CMASS and
LyaF measurements of $D\_{H}(z)/r\_{d}$ and further from the
LyaF $D\_{M}(z)/r\_{d}$. We therefore expect tight constraints on
$\Omega\_{\rm de}^{e}$ in the case of fixed $r\_{d}$.

Figure [13](#S6.F13 "Figure 13 ‣ VI.1 Early Dark Energy ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") presents constraints on these
early dark energy models from our MCMC analysis, with $w\_{0}$
fixed to $-1$. We now account for uncertainties in the CMB
constraints, using the compressed description of Section [II.3](#S2.SS3 "II.3 Cosmic Microwave Background Data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
Note that we assume that the CMB constraints on $\omega\_{m}$ and $\omega\_{b}$
are not altered by the introduction of early dark energy, which might not
hold in a complete analysis that uses the full CMB spectrum.
The non-rescaled case is tightly constrained as expected,
with a $2\sigma$ upper limit $\Omega\_{\rm de}^{e}<0.031$.
SNe do not significantly improve these constraints,
although they would play a larger role if we allowed $w\_{0}$ as a free
parameter.
To summarize, adding early dark energy with fixed $r\_{d}$ worsens agreement
with our BAO measurements, and a dynamically significant value
of $\Omega\_{\rm de}^{e}$ is ruled out.

For rescaled $r\_{d}$, which is the physically expected case if
$\Omega\_{\rm de}^{e}$ remains constant back into the radiation-dominated
era, we instead find a valley of near-perfect degeneracy between
$\Omega\_{m}$ and $\Omega\_{\rm de}^{e}$.
For $H\_{0}r\_{d}=\,{\rm const.}$ and fixed $\Omega\_{m}h^{2}$,
the expected degeneracy line is
$\Omega\_{m}\propto r\_{d}^{-2}\propto(1-\Omega\_{\rm de}^{e})$, marked
by the red solid line in Figure [13](#S6.F13 "Figure 13 ‣ VI.1 Early Dark Energy ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
This prediction describes our numerical MCMC results extremely well.
Along this line, there are
models with $\Delta\chi^{2}<1$ relative to the best-fit
$\Lambda$CDM ($\Omega\_{\rm de}^{e}=0$) model, at least out to $\Omega\_{\rm de}^{e}=0.32$.
Including SNe again makes minimal difference to our constraints
because the models along the degeneracy line predict
nearly identical $D\_{M}(z)$.

Although these models are degenerate with respect to our
geometrical constraints, they predict different values of $H\_{0}$
and different measures of structure growth.
Intriguingly, non-zero $\Omega\_{\rm de}^{e}$ with rescaled $r\_{d}$
reduces tension
with distance-ladder measurements of $H\_{0}$ and with the level of
matter clustering inferred from cluster masses, weak lensing,
and redshift-space distortions. We discuss the impact on structure
growth measures in Section [VII](#S7 "VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").

As already emphasized, the detailed shape of the CMB power spectrum
may impose much tighter constraints on early dark energy;
e.g., for the specific case of the Doran-Robbers model,
[[88](#bib.bib88)] infer $\Omega\_{\rm de}^{e}<0.012$ at 95% confidence.
However, the degeneracies identified here in the expansion history
constraints are striking, and highlight the potential value of
early dark energy studies that fully explore
degeneracies with other parameters that affect the CMB power
spectrum shape.

### VI.2 Decaying Dark Matter

Figure 14: Constraints on decaying dark matter from CMB, SN and
galaxy+LyaF BAO data. For various choices of the fraction
$f\_{x}$ of dark matter in the decaying component, we plot
posterior probability distributions for the product $\lambda f\_{x}$, where $\lambda$ is the decay constant, assuming a flat
prior on $\lambda$ vs value of $\Omega\_{m}$ today (which, by
definition, includes both the non-decaying component and the
undecayed fraction of the decaying component). Removing SN data
does not significantly relax these constraints.

If dark matter is a metastable particle that decays into undetected
radiation on a timescale comparable to $H\_{0}^{-1}$, where the
undetected radiation could be neutrinos or some other low-mass
particle that interacts weakly enough to avoid detection (note that
decay of a significant fraction of the dark matter into photons would
need to have a very small branching ratio to be consistent with upper
limits on cosmic backgrounds), then the matter density will decrease
faster at low redshift than simple $(1+z)^{3}$ dilution (for an early
discussion, see [[89](#bib.bib89)]). While the radiation density is
boosted by dark matter decay, it subsequently decreases as $(1+z)^{4}$,
so the total energy density at low redshift is lower in a decaying
dark matter (DDM) model than it would be for stable dark matter with
the same high-redshift density. We initially considered this model as
a potential explanation of the low $H(2.34)$ inferred from the LyaF BAO. The heights of the acoustic peaks constrain the value of
$\Omega\_{m}h^{2}$ at the recombination epoch, but the reduced matter
density at low redshift implies a lower value of $H^{2}(z)=(8\pi G/3)\rho\_{\rm crit}(z).$ The sound horizon scale $r\_{d}$ is unchanged
because the pre-recombination densities are unchanged. However, the
full impact of introducing DDM is complex, because the values of $h$
and $\Omega\_{m}$ must change to keep $D\_{M}(1090)/r\_{d}$ at its precisely
measured value, and because these changes and the dark matter decay
itself affect the galaxy BAO observables and the LyaF value of
$D\_{M}(2.34)$.

We assume exponential decay of the dark matter (i.e., a constant decay
rate), so that the governing equations for the decaying matter density
(marked with subscript $x$) and decay products’ radiation density
(marked with subscript $g$) are:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\dot{\rho}\_{x}$ | $\displaystyle=$ | $\displaystyle-3H\rho\_{x}-\lambda H\_{0}\rho\_{x},$ |  | (29) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\dot{\rho}\_{g}$ | $\displaystyle=$ | $\displaystyle-4H\rho\_{g}+\lambda H\_{0}\rho\_{x}.$ |  | (30) |

The decay rate $\lambda$ is dimensionless, and $\lambda^{-1}$ is the
decay time in units of $H\_{0}^{-1}$. However, we allow for the
possibility that there are two kinds of dark matter, only one of which
is susceptible to decay, so we introduce an additional parameter $f\_{x}=\lim\_{z\rightarrow\infty}\Omega\_{x}(z)/\Omega\_{\rm dm}(z)$ that is the
ratio of this decaying component to the total dark matter density in
the infinite past.66
6
The earlier arXiv version of this
paper had $f$ defined as a fraction of total matter density
today. The other components of the model remain the same as
those used for $\Lambda$CDM. Initial conditions are chosen so that there is
no energy density in the decay product radiation in the infinite past.
We discuss some details of our solution technique in
Appendix [B](#A2 "Appendix B Decaying dark matter model ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").

An important subtlety in this analysis is that that the CMB
peaks constrain the dark-matter density at the time of recombination,
and hence the $\omega\_{b}$ and $\omega\_{c}$ densities that we feed into
the compressed CMB likelihood corresponds to the densities the system
would have had if the decay did not take place. Of course, the
distance to the last scattering surface is still affected by the
changes in the expansion history due to decaying dark matter.

Figure [14](#S6.F14 "Figure 14 ‣ VI.2 Decaying Dark Matter ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") shows two-dimensional posterior probability
distributions in the $\lambda f\_{x}-\Omega\_{m}$ plane for several values of
$f\_{x}$. Although the data prefer no decaying dark matter, we see strong
degeneracies that extend to surprisingly large values of
$\lambda$. For $f\_{x}=1$, decay of nearly 50% of the primordial dark matter
is allowed at 95% confidence.
As expected, $\Omega\_{m}$ is negatively correlated
with $\lambda f\_{x}$: the CMB constrains $\omega\_{c}$ in the early
universe, and if more dark matter decays then $\Omega\_{m}$ today is lower.
There is also a weak correlation with the Hubble parameter (not shown),
with $h$ rising by $\sim 0.01$ for $\lambda f\_{x}\sim 0.5$.

To gain some understanding of this degeneracy,
one can calculate the effective $w$ of the
fluid composed of the combined decaying dark matter and the resulting
radiation. At $f\_{x}=1$, $\Omega\_{m}=0.23$ and $\lambda=0.4$ (the edge of
our 68% contour), the effective $w$ takes values $0.07$ at
$z=0$, falling to $0.03$ at $z=2$ and $10^{-4}$ at $z=100$.
With no decay, this component (which starts at the same energy
density, as fixed by the CMB) would evolve with $w=0$.
The surprisingly small corrections to the total $w$ make it hard to
constrain the decaying dark matter from expansion history data alone.

Using combinations of CMB, SN, and large-scale structure data sets,
[[90](#bib.bib90)] obtained a limit $\Gamma^{-1}>100\,$Gyr
for the dark matter decay constant, using methodology similar to that
described here but also including constraints from the full shape of
the CMB power spectrum and the amplitude of matter clustering. A more
recent analysis by [[91](#bib.bib91)], using the Planck+WP CMB
power spectrum and BAO measurements from BOSS and WiggleZ, obtained a
somewhat stronger limit of $\Gamma^{-1}>160\,$Gyr. For a Hubble
parameter $h=0.68$, our limit for $f\_{x}=1$ corresponds $\Gamma^{-1}>28\,$Gyr at 95% confidence level. A more detailed analysis by
[[92](#bib.bib92)] calculates the velocity distributions of
daughter particles for varying assumptions about the decay products.
For a daughter relativistic fraction of 1% and higher, they find
$\Gamma^{-1}>10\,$Gyr based on analysis of Union 2.1 SNIa data in the
context of CMB determined cosmological model. From these results we
conclude that, somewhat surprisingly, the expansion history alone is
not sufficient to significantly constrain the decay of dark matter
into an unknown relativistic component.

We note that [[93](#bib.bib93)] state a limit
$\Gamma^{-1}>700\,$Gyr based on only the CMB acoustic scale and
SNIa data available in 2008. We do not understand how these more
limited data could lead to a stronger bound on the decay time,
which suggests that the analysis of [[93](#bib.bib93)]
contains a hidden assumption.

### VI.3 Massive Neutrinos

Figure 15: BAO constraints in the $D\_{M}-D\_{H}$ planes at $z=0.57$
(left) and $z=2.34$ (middle) compared to predictions of
CMB-constrained, flat $\Lambda$CDM models in which the neutrino mass
$\sum m\_{\nu}$ or the number of relativistic species $N\_{\rm eff}$ is a
free parameter. Black curves show 68%, 95%, and 99.7%
likelihood contours from the CMASS and LyaF BAO measurements,
relative to the best-fit values (black dots). Colored points
represent individual models from Planck+WP+ACT/SPT MCMC chains,
which are color-coded by the value of $\sum m\_{\nu}$ (top row) or
$N\_{\rm eff}$ (bottom row) as illustrated in the right panels. Green
cross-hairs mark the predictions of the flat $\Lambda$CDM model with
$\sum m\_{\nu}=0.06\,{\rm eV}$ and $N\_{\rm eff}=3.046$ that best fits
the CMB data. White curves show 68% and 95% likelihood
contours for the CMB data alone. CMB results in the top row are
marginalized over the lensing parameter $A\_{L}$.

Figure 16: Neutrino mass constraints for several combinations of
data and model freedom. In the top panel, the red curve shows
the posterior pdf (with a flat prior) on $\sum m\_{\nu}$ from the
expansion history constraint on the neutrino mass, based on the
combination of BAO with our compressed CMB description, which
yields $\sum m\_{\nu}<0.56\,{\rm eV}$ at 95% confidence.
The green curve shows the result obtained by replacing our
compressed CMB description with the full Planck+WP power spectrum
using cosmomc, which strengthens the upper limit to
$\sum m\_{\nu}<0.25\,{\rm eV}$. The blue curve adopts the same data combination
but additionally marginalizes
over the parameter $A\_{L}$, demonstrating that
the difference between the green and red curves is driven mainly
by the lensing amplitude information in the Planck data. In the
lower panel, curves show the posterior pdf of $\sum m\_{\nu}$ from
our usual BAO+Planck (thick) or BAO+SN+Planck (thin) geometrical
constraints, assuming $\Lambda$CDM, $w$CDM, or $o\Lambda$CDM (red, blue,
green, respectively).

In addition to constraining dark energy and space curvature, measuring
neutrino masses is a key objective of precision cosmology. Given CMB
constraints that $\omega\_{m}\approx 0.14$, the fractional contribution of
neutrinos to the low-redshift
matter density is $\omega\_{\nu}/\omega\_{m}\approx 0.07(\sum m\_{\nu}/1\,{\rm eV})$, so neutrino masses have a
noticeable cosmological impact if they are a significant fraction of
an eV. Atmospheric and laboratory measurements constrain the mass
splittings among the three standard-model neutrino species to be
$m\_{2}^{2}-m\_{1}^{2}=7.54^{+0.26}\_{-0.22}\times 10^{-5}$ eV2 and
$m\_{3}^{2}-(m\_{1}^{2}+m\_{2}^{2})/2=\pm 2.43^{+0.06}\_{-0.10}\times 10^{-3}$
eV2 [[94](#bib.bib94)]. This sets the minimum neutrino mass in a
normal hierarchy, where $m\_{1}<m\_{2}\ll m\_{3}$, to $\sum m\_{\nu}=58.4^{+1.2}\_{-0.8}\rm\ meV$, which motivates our assumption that $\sum m\_{\nu}=0.06\,{\rm eV}$ in the standard $\Lambda$CDM model. In the case of an inverted
hierarchy, where $m\_{1}\simeq m\_{2}\gg m\_{3}$, the sum of the neutrino
masses must exceed $0.1\,{\rm eV}$, and for the degenerate neutrino
mass case where $m\_{1}\simeq m\_{2}\simeq m\_{3}$, the minimum mass sum
is approximately $0.15\,{\rm eV}$. These masses are well within
reach of the cosmological experiments in the coming decade.

Neutrinos affect the CMB and large-scale structure differently from
cold dark matter because they are still relativistic at the epoch of
matter-radiation equality, because their linear clustering is
suppressed on scales below $k\_{\rm sup}=2\pi/\lambda\_{\rm sup}=0.018\sqrt{m\_{\nu}/1{\rm eV}}h^{-1}\,{\rm Mpc}$ [[95](#bib.bib95)], and
because their high thermal velocities prevent them from clustering in
small potential wells even in the non-linear regime
[[96](#bib.bib96), [97](#bib.bib97)]. The relative suppression in the
linear matter power spectrum is linear in the fraction density in
neutrinos $f\_{\nu}$ and is about $\Delta P/P\sim-8f\_{\nu}\sim 0.063\left(\sum m\_{\nu}/0.1{\rm eV}\right)$ (at best fit values of
$\Omega\_{m}$ and $h$).

Measurements of matter clustering can constrain $\sum m\_{\nu}$
by detecting the suppression of small scale power.
Expansion history measurements, which we focus on here,
can constrain $\sum m\_{\nu}$ because of their transition from a
relativistic species whose energy density scales as $(1+z)^{4}$
to a non-relativistic species whose energy density scales as $(1+z)^{3}$,
effectively the converse of decaying dark matter.
Specifically, the CMB acoustic peaks constrain $\omega\_{cb}$
almost independently of $\omega\_{\nu}$, but the matter density that
affects late-time expansion rates and distances is $\omega\_{cb}+\omega\_{\nu}$.
With other parameters held fixed, a $0.2\,{\rm eV}$ neutrino mass-sum increases the
late-time matter density by 1.4%, which is significant given
the extremely precise CMB measurement of $D\_{M}(1090)/r\_{d}$ and
precise distance scale measurements from BAO. In practice, changing
$\sum m\_{\nu}$ leads to adjustments in other parameters to seek
a global best fit. Although the neutrino mass influences the
sound horizon (eq. [16](#S2.E16 "In II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")), this impact is small for
the range of $\sum m\_{\nu}$ allowed by our constraints
($-0.26\%$ for $\sum m\_{\nu}=0.5\,{\rm eV}$).

The top row of Figure [15](#S6.F15 "Figure 15 ‣ VI.3 Massive Neutrinos ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") compares the CMASS
and LyaF BAO constraints to the predictions of CMB-constrained, flat
$\Lambda$CDM models with $\sum m\_{\nu}$ as a free parameter, in the same
format as Figure [7](#S5.F7 "Figure 7 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"). The Planck CMB chain used
here is base\_mnu\_planck\_lowl\_lowLike\_highL\_Alens,
where we have selected a chain that
marginalizes over the lensing amplitude parameter $A\_{L}$ for
reasons discussed below.
The base Planck $\Lambda$CDM model
adopts $\sum m\_{\nu}=0.06\,{\rm eV}$, but this chain allows $\sum m\_{\nu}$ down to
zero. While $\sum m\_{\nu}>0.5\,{\rm eV}$ is allowed by the CMB data alone,
this mass significantly worsens agreement with the BAO data, both at $z=0.57$
and at $z=2.34$. Higher $m\_{\nu}$ increases $\Omega\_{m}h^{2}$ and thus
decreases $D\_{H}(2.34)$, moving further from the LyaF measurement. Additionally, because of the tight CMB constraint on
$D\_{M}(1090)/r\_{d}$, the reduction in $c/H(z)$ at high redshift must be
compensated by changes in $h$ and $\Omega\_{m}$ that raise $D\_{M}$ at low
redshift, so $D\_{M}(2.34)$, $D\_{M}(0.57)$, and $D\_{H}(0.57)$ all
increase, again moving away from the BAO measurements. Conversely,
moving towards $\sum m\_{\nu}=0$ slightly improves agreement with the
LyaF BAO because $D\_{H}(2.34)$ increases while $D\_{M}(2.34)$, which
has a large contribution from lower redshifts, decreases. However,
the same change worsens agreement with the CMASS BAO, which are
already well fit by the base model with $\sum m\_{\nu}=0.06\,{\rm eV}$.

The red curve in the upper panel of Figure [16](#S6.F16 "Figure 16 ‣ VI.3 Massive Neutrinos ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") shows
the purely geometric constraint that arises from combining just
the compressed CMB description with galaxy and LyaF BAO data.
This constraint is surprisingly tight at $\sum m\_{\nu}<0.56\,{\rm eV}$ (at 95% c.l.), and it is independent of mass constraints
based on the suppression of structure
growth by neutrino free-streaming. Adding
SN data does not significantly improve this constraint. The
geometrical constraint on neutrino mass weakens if we allow either
curvature or $w\neq-1$, as shown by the blue and green curves in the
lower panel of Figure [16](#S6.F16 "Figure 16 ‣ VI.3 Massive Neutrinos ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"). Because neutrinos influence
the observables only via the effect of $\omega\_{m}$ on
distances and expansion rates, adding another degree of freedom
introduces degeneracy. In these cases, including SN data
does improve the neutrino mass constraint,
as shown by the thin curves. The improvement
is not dramatic, indicating that our multiple BAO measurements can
break the degeneracy themselves to a significant degree.

The 95% upper limits on $\sum m\_{\nu}$ for the various models and data
combinations we have considered are listed in Table [6](#S6.T6 "Table 6 ‣ VI.3 Massive Neutrinos ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
Direct measurements of matter clustering at low redshift can be a
powerful diagnostic of neutrino masses because they are sensitive to
the distinctive effect of suppressing small scale power, which is not
easily mimicked by other parameter variations. We return to this
point in Section [VII](#S7 "VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").

In the top panel of Figure [16](#S6.F16 "Figure 16 ‣ VI.3 Massive Neutrinos ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"),
the green curve shows the result of full
fitting using the cosmomc machinery. The constraint
tightens significantly to $\sum m\_{\nu}<0.25$eV (at 95% c.l.). This
number is the same as the Planck collaboration constraint
for Planck+BAO [[29](#bib.bib29)], even though we
use more and better constraining BAO data. This exercise demonstrates
that the compression into $\omega\_{cb}$, $\omega\_{b}$, and
$D\_{M}(1090)/r\_{d}$ is missing important information that the CMB
provides on neutrino mass. The extra information is in the constraint
on the amplitude of low-redshift matter clustering that comes from the
smoothing of the acoustic peaks in the CMB power spectrum
by weak gravitational lensing.
The BAO information in this case fixes the
matter density of the universe, thus allowing inference on the
amplitude of matter fluctuations and hence neutrino mass to be
determined from the smoothness of the peaks (the CMB only constraint
is $\sum m\_{\nu}<0.93$eV [[29](#bib.bib29)]). The role of CMB lensing is further
demonstrated by the blue curve in the top panel.
Here we have run a cosmomc chain that, in addition to having
$\sum m\_{\nu}$ as a free parameter, marginalizes over a parameter $A\_{L}$
that multiplies the predicted lensing signal, effectively removing the
lensing information. (The base model fixes $A\_{L}=1$.) The
result here is very similar to that found by using the compressed
CMB description.

For $\Lambda$CDM, fitting the CMB temperature power spectrum from Planck
(together with WMAP polarization and high-$l$ data from ground-based
experiments) yields $A\_{L}=1.23\pm 0.11$ [[29](#bib.bib29)], showing
that the lensing signal measured in the Planck power spectrum is
significantly stronger than the predicted signal based on
extrapolating the observed CMB fluctuations forward in time. A larger
neutrino mass suppresses the low-redshift clustering, exacerbating
this tension, which is why the $\sum m\_{\nu}$ limit is considerably
tighter when $A\_{L}$ is fixed to unity. However, the Planck measurement
of lensing through the CMB 4-point function does agree with $A\_{L}=1$
[[29](#bib.bib29)]. These internal tensions on the lensing signal
within the CMB data alone suggest that one should be cautious in using
them to constrain $\sum m\_{\nu}$. The red curve is thus a more
conservative inference, using only geometric constraints plus the CMB
constraints on $\omega\_{cb}$ and $\omega\_{b}$. It is impressive that
even a 3.5% contribution of neutrinos to $\omega\_{m}$ ($\sum m\_{\nu}=0.5\,{\rm eV}$) is enough to be substantially disfavored by these
expansion history measurements.

| Combination | Model | 95% limit on $\sum m\_{\nu}$ |
| --- | --- | --- |
| BAO+Planck(full) | $\Lambda$CDM | 0.25eV |
| BAO+Planck(full) | $\Lambda$CDM + free $A\_{L}$ | 0.43eV |
| BAO+Planck | $\Lambda$CDM | 0.56eV |
| BAO+Planck | $w$CDM | 0.68eV |
| BAO+Planck | $o\Lambda$CDM | 0.87eV |
| BAO+SN+Planck | $\Lambda$CDM | 0.56eV |
| BAO+SN+Planck | $w$CDM | 0.61eV |
| BAO+SN+Planck | $o\Lambda$CDM | 0.84eV |

Table 6: 95% confidence limits for the sum of the mass of neutrino species.
The first two cases use full Planck CMB chains, while other cases adopt
our compressed CMB description.

### VI.4 Extra Relativistic Species

If the universe contains extra relativistic degrees of freedom
beyond those in the standard model, these increase the expansion
rate during the radiation dominated era and shift the epoch of
matter-radiation equality, thereby altering the sound horizon,
the shape of the matter power spectrum, and the history of
recombination. Extra radiation is usually parameterized by
the quantity $\Delta N\_{\rm eff}$, where $\Delta N\_{\rm eff}=1$ corresponds to
the amount of radiation that an extra massless
thermalized neutrino species (i.e., a fermion that thermally decouples
before electron-positrion annihilation) would produce.
In general, however, there is no requirement that
$\Delta N\_{\rm eff}$ be an integer.
The standard model has $N\_{\rm eff}=3.046$ and $\Delta N\_{\rm eff}=0$.

Figure 17: Constraints on the effective number of relativistic
species $N\_{\rm eff}$, assuming $w=-1$ and $\Omega\_{k}=0$.
These contours use full Planck+WP CMB constraints
computed with cosmomc, combined with LyaF BAO
only (red) or with our full set of BAO measurements (green).
We marginalize over the tensor-to-scalar ratio $r$.

The bottom row of Figure [15](#S6.F15 "Figure 15 ‣ VI.3 Massive Neutrinos ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") shows the
probability distribution for $N\_{\rm eff}$ from CMB data alone
(right panel, from the chain
base\_nnu\_planck\_lowl\_lowLike\_highL).
which peaks at $N\_{\rm eff}\approx 3.4$, with a 95% confidence
range $2.7\leq N\_{\rm eff}\leq 4.04$.
The middle panel shows that values of $N\_{\rm eff}$ at the upper
end of this range can noticeably improve consistency with
the LyaF BAO measurement, pushing the predicted values of
$D\_{H}(2.34)/r\_{d}$ up and $D\_{M}(2.34)/r\_{d}$ down so that
they lie within the 95% likelihood contour of the BAO data.
However, high values of $N\_{\rm eff}$ reduce the predicted
values of $D\_{H}/r\_{d}$ and $D\_{M}/r\_{d}$ at $z=0.57$, worsening
agreement with the galaxy BAO measurements.

We can understand these trends by arguments similar to those given for
early dark energy in Section [VI.1](#S6.SS1 "VI.1 Early Dark Energy ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"). An increase of $\Delta N\_{\rm eff}=1$
reduces the sound horizon $r\_{d}$ by 3.2% (eq. [17](#S2.E17 "In II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"))
because of the higher expansion rate in the early universe.
Maintaining the precisely measured value of $D\_{M}(1090)/r\_{d}$ requires
changes in $\Omega\_{m}$ and $h$ to reduce $D\_{M}(1090)$ by the same
factor. Some of this reduction can be accomplished by raising
$\Omega\_{m}h^{2}$, and thus raising $H(z)$ at high redshift, but
$\Omega\_{m}h^{2}$ is already tightly constrained by the heights of the
acoustic peaks. Therefore, the fractional change to $D\_{H}(2.34)$ is
much lower than the fractional change to $r\_{d}$, and the value of
$D\_{H}(2.34)/r\_{d}$ rises. To maintain $D\_{M}(1090)/r\_{d}$, the value
of $H\_{0}$ (which controls the low-redshift contribution to the $D\_{M}$
integral) must increase by more than the drop in $r\_{d}$. Because
$D\_{M}(2.34)$ is an integral over all $z<2.34$, the ratio
$D\_{M}(2.34)/r\_{d}$ drops even as $D\_{H}(2.34)/r\_{d}$ rises. At $z=0.57$,
where the value of $H(z)$ retains sensitivity to $H\_{0}$, both
$D\_{H}/r\_{d}$ and $D\_{M}/r\_{d}$ drop as $N\_{\rm eff}$ increases.

A change in $N\_{\rm eff}$ has multiple effects on the CMB, which renders
our compression into a 3-variable matrix questionable.
For this section of the paper, therefore, we have run cosmomc
chains using the full Planck+WP CMB information,
while still treating the BAO
data as measurements of $D\_{M}/r\_{d}$ and $D\_{H}/r\_{d}$.
We have checked that using our simplemc chains,
which adopt the compressed CMB description, yields qualitatively
similar but quantitatively different results.
We assume a flat universe with a cosmological constant,
but we treat the tensor-to-scalar ratio $r$ as a free parameter
and marginalize over it, since there is no theoretical reason
to expect $r=0$. While allowing free $r$ would not alter the
compressed CMB constraints used elsewhere in the paper, it
has an impact here because $r$ and $N\_{\rm eff}$ have partially
degenerate effects on the shape of the CMB power spectrum.

Red contours in Figure [17](#S6.F17 "Figure 17 ‣ VI.4 Extra Relativistic Species ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") show confidence intervals
in the $N\_{\rm eff}-h$ plane obtained by
combining the CMB data with LyaF BAO alone.
The allowed range of $N\_{\rm eff}$
is larger here than in Figure [15](#S6.F15 "Figure 15 ‣ VI.3 Massive Neutrinos ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") because
we do not fix $r=0$.
As one would expect from Figure [15](#S6.F15 "Figure 15 ‣ VI.3 Massive Neutrinos ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"),
the addition of LyaF BAO pulls the preferred value of $N\_{\rm eff}$
upward, with a best-fit value of $N\_{\rm eff}\approx 4$ and $N\_{\rm eff}=3$
significantly disfavored.
However, the galaxy BAO measurements prefer $N\_{\rm eff}\approx 3$ and
have higher precision, so when they are added (green contours)
the allowed range shifts downward to $N\_{\rm eff}=3.43\pm 0.26$ (68%)
or $N\_{\rm eff}=3.43\pm 0.53$ (95%).
Higher $N\_{\rm eff}$ correlates with higher $h$ for the reasons discussed above,
and with $N\_{\rm eff}$ and $r$
as an additional degree of freedom our BAO+CMB constraint
is $h=0.71\pm 0.017$.
Adding SN data does not significantly shift these contours
once galaxy BAO are included.
As shown in Figure [10](#S5.F10 "Figure 10 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"), introducing $\Delta N\_{\rm eff}$ as a
parameter reduces $\chi^{2}$ by 0.75 relative to $\Lambda$CDM, with nearly
all of the change coming from a slightly better fit to the LyaF BAO data.

One complication in constraining $\Delta N\_{\rm eff}$ models is that
changing the radiation density can alter the broadband power
spectrum shape enough to affect the BAO fitting procedure itself.
[[26](#bib.bib26)] find that the compression of BAO data into
the $\alpha\_{\parallel}-\alpha\_{\perp}$ plane (in other words, the fact that the
inferred values of $D\_{M}/r\_{d}$ and $D\_{H}/r\_{d}$ are independent
of the adopted fiducial model) breaks down in the presence of extra
radiation at a $\sim 0.4$% level. This effect is negligible
compared to the statistical errors in the LyaF BAO data, but
it is not completely negligible relative to the galaxy BAO errors.
A more exact treatment of the $N\_{\rm eff}$ constraints therefore
requires refitting the BAO data themselves, but we would expect
only small shifts relative to the constraints reported here.
We plan to revisit this question when the final BOSS measurements
are available.

### VI.5 A Tuned Oscillation

Figure 18: A “tuned oscillation” model in which a Gaussian perturbation of
the $\Lambda$CDM $D\_{M}(z)$ is introduced to allow a good simultaneous fit
to the galaxy and LyaF BAO data.
Solid lines show the same $\Lambda$CDM model plotted in
Figure [1](#S2.F1 "Figure 1 ‣ II.5 Visualizing the BAO Constraints ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"), while the dashed line
shows the perturbed model.

Figure 19: Implied variation in the energy density of the dark
energy component for the model shown in Figure
[18](#S6.F18 "Figure 18 ‣ VI.5 A Tuned Oscillation ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"). The dotted line corresponds to the density becoming
negative. These plots illustrate the difficulty of concurrently
fitting the LyaF and galaxy BAO constraints on $D\_{M}$ and $D\_{H}$
while satisfying the CMB constraint on $D\_{M}$.

While the $\Delta N\_{\rm eff}$ model moderately reduces tension with the
LyaF BAO data, none of the models we have considered
produces a truly good fit to all the measurements. To understand
what is required to achieve a good fit, we have constructed an artificial
model that maintains the mathematical link between $D\_{M}(z)$ and $D\_{H}(z)$
but has the freedom needed to fit all the BAO and CMB data
at the $\approx 1\sigma$ level.
We consider a flat universe whose angular diameter
distance is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D\_{M}^{(w)}(z)=D\_{M}^{(\Lambda{\rm CDM})}(z)\left[1+A\times G(\log z;\log z\_{o},\sigma\_{o})\right],$ |  | (31) |

where $G(\log z;\log z\_{m},\sigma\_{o})$ denotes a Gaussian in $\log z$
with mean $z\_{o}$ and variance $\sigma\_{o}$ and $A$ is an amplitude
parameter. It is clear that such model can, for a sufficiently
localized Gaussian perturbation, fit the low-redshift and CMB data
with sufficient goodness of fit. Given three parameters it has
enough flexibility to also match our $z=2.34$ points.
Figure [18](#S6.F18 "Figure 18 ‣ VI.5 A Tuned Oscillation ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") plots the best fitting model of this form.
The Hubble parameter undergoes an oscillation between
$z\approx 4$ and $z\approx 0.8$, which allows it to
match the LyaF and CMASS values of $D\_{H}$ and to
change $D\_{M}$ at $z=2.34$ without altering the low and high
redshift values.

This model reduces the overall $\chi^{2}$ by 6.6 with three extra degrees of
freedom, a considerable improvement over any other model we have
investigated (see Figure [10](#S5.F10 "Figure 10 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")).
Generically, any small perturbation to the Friedmann equation
that is able to improve fits to our LyaF data runs afoul of
CMB and/or galaxy BAO constraints.
This model works because it is fine-tuned to change distances
near $z=2$ but not upset the distance to the last-scattering surface.
However, the model is physically extreme,
as demonstrated in Figure [19](#S6.F19 "Figure 19 ‣ VI.5 A Tuned Oscillation ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"), where we have
converted $H(z)$ into an implied dark energy density
via the Friedmann equation. Producing the desired oscillation
in $H(z)$ requires a negative $\rho\_{\rm de}$ between $z=6$ and $z=2$
(see eq. [27](#S6.E27 "In VI.1 Early Dark Energy ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")).
[[98](#bib.bib98)] argue that the BOSS LyaF measurements may be
explained in a modified gravity model that alters the
Friedmann equation itself in a physically motivated way, but
more work is needed to determine whether any such model can
provide a good fit to all of the BAO measurements while
satisfying CMB constraints.

The difficulty in finding a well motivated model that matches
the BOSS LyaF measurements suggests that the tension with
these measurements may be a statistical fluke, or a consequence
of an unrecognized systematic that either biases the central values
of $D\_{M}(z)$ and $D\_{H}(z)$ or causes their error bars to be
underestimated. Analyses of the final BOSS data set will
address both of the latter points, as they will allow more
exhaustive investigation of analysis procedures and tests
against larger suites of mock catalogs.
Addressing the first point will require high-redshift
BAO measurements from new data sets, such as the
Ly$\alpha$ emission-line galaxy survey of HETDEX [[99](#bib.bib99)]
or a much larger LyaF sample from DESI [[100](#bib.bib100)].

## VII Comparison to Structure Growth Constraints

The Planck cosmology papers highlighted a tension
between the predictions of the CMB-normalized $\Lambda$CDM model and observational constraints on matter clustering
at low redshifts, from cluster abundances, weak gravitational lensing,
or redshift-space distortions. We now revisit this issue
with our updated BAO and SN constraints and our broader
set of models, to see whether these tensions persist and
whether they are significantly reduced in some classes of models.

Low-redshift measurements of cluster abundances and weak lensing
most tightly constrain the parameter combination $\sigma\_{8}\Omega\_{m}^{\alpha}$
with $\alpha\approx 0.4-0.6$ (see discussions in [[35](#bib.bib35)]
and references therein).
As representative but not exhaustive
examples of constraints at $z\approx 0$ we adopt:
$\sigma\_{8}(\Omega\_{m}/0.27)^{0.46}=0.774\_{-0.041}^{+0.032}$
from tomographic cosmic shear measurements in the CFHTLens
survey [[101](#bib.bib101)];
$\sigma\_{8}(\Omega\_{m}/0.27)^{0.5}=0.86\pm 0.035$ from
cosmic shear measurements in the
Deep Lens Survey77
7
The authors do not quote their results
in this form, so this constraint has been eyeballed from
their Fig. 25 [[102](#bib.bib102)];
$\sigma\_{8}(\Omega\_{m}/0.27)^{0.57}=0.77\pm 0.05$ from
the combination of galaxy-galaxy lensing and galaxy clustering
in the SDSS [[103](#bib.bib103)];
$\sigma\_{8}(\Omega\_{m}/0.25)^{0.47}=0.813\pm 0.013$ from the
mass function of X-ray clusters observed with Chandra
and ROSAT [[104](#bib.bib104)];
$\sigma\_{8}(\Omega\_{m}/0.25)^{0.41}=0.832\pm 0.033$
from stacked weak lensing of clusters in the SDSS [[105](#bib.bib105)];
and
$\sigma\_{8}(\Omega\_{m}/0.27)^{0.3}=0.78\pm 0.01$ from Sunyaev-Zeldovich
clusters in Planck, where we have taken the value quoted for a 20%
X-ray mass bias [[106](#bib.bib106)].
These estimates are shown as red points with $1\sigma$ error bars in
Figure [20](#S7.F20 "Figure 20 ‣ VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")a, where we have scaled the amplitudes
to $\Omega\_{m}=0.30$ using the formulas listed above and retained
the original fractional errors.
We compare to model predictions of $\sigma\_{8}(\Omega\_{m}/0.3)^{0.4}$,
treating 0.4 as a representative slope for these constraints.

Recently [[107](#bib.bib107)] have completed an independent analysis of
tomographic cosmic shear in the CFHTLens data and confirmed the
findings of [[101](#bib.bib101)].
Conversely, [[108](#bib.bib108)] have
performed a cluster mass function analysis using extensive
weak lensing calibration of X-ray cluster masses and found
$\sigma\_{8}(\Omega\_{m}/0.3)^{0.17}=0.81\pm 0.03$, which
corresponds to higher $\sigma\_{8}$ for $\Omega\_{m}\approx 0.3$ than the
other cluster studies listed above.
We also show this point in Figure [20](#S7.F20 "Figure 20 ‣ VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")a, with the
caution that the scaling with $\Omega\_{m}$ reported by
[[108](#bib.bib108)] is quite different from that
of the other analyses.

For redshift-space distortion (RSD),
the point labeled Beu14 in Figure [20](#S7.F20 "Figure 20 ‣ VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")b shows
the recent BOSS CMASS measurement
by [[109](#bib.bib109)], which yields
$f(z)\sigma\_{8}(z)=0.422\pm 0.027$ at $z=0.57$, where
$f(z)\approx[\Omega\_{m}(z)]^{0.55}$ is the linear fluctuation growth rate.
This analysis fits simultaneously for redshift-space distortion and
the Alcock-Paczynski (AP) effect [[110](#bib.bib110)].
Here we have used the error for fixed value of the AP parameter
$D\_{M}(z)H(z)$ because the geometry is well constrained by our
BAO+SN+CMB data, so that the fractional error in the AP parameter
is much smaller than the 6.4% error on $f(z)\sigma\_{8}(z)$.
The point labeled Sam14 shows the estimate $f(z)\sigma\_{8}(z)=0.447\pm 0.028$
from the same data set using a power spectrum analysis instead of a
correlation function analysis. Since the data are the same, the
difference from Beu14 provides an indication of the uncertainties
associated with modeling systematics.
Other analyses of redshift-space clustering in BOSS
[[111](#bib.bib111), [112](#bib.bib112)] and the WiggleZ survey [[113](#bib.bib113)]
yield compatible results.
We also plot an estimate of $f(z)\sigma\_{8}(z)=0.450\pm 0.011$
from an analysis of smaller scale redshift-space distortions in
the CMASS sample by [[114](#bib.bib114)], which adopts more aggressive
modeling assumptions and achieves a substantially smaller statistical
error.

At higher redshift, the 1-dimensional flux power spectrum
of the Lyman-$\alpha$ forest probes the underlying matter clustering,
with the tightest constraints on comoving scales of
a few Mpc [[115](#bib.bib115), [116](#bib.bib116), [117](#bib.bib117)].
Here we take the result from the BOSS analysis of
[[117](#bib.bib117)], who find $\sigma\_{8}=0.83\pm 0.03$
when fitting a $\Lambda$CDM model to the 1-d $P(k)$ at redshifts
$z=2.2-4.0$. We translate this result to a constraint on
$\sigma\_{8}(z=2.5)=0.311\pm 0.011$ by using the growth factor
at $z=3$ for their central value of $\Omega\_{m}=0.26$.
This measurement is indicated by
a point with $1\sigma$ error bar in
Figure [20](#S7.F20 "Figure 20 ‣ VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")c.

Given the wide range of models that we wish to consider and
the several-percent errors on the observational data, we
have opted for an approximate method of computing clustering
amplitude predictions that is accurate at the 0.5-percent
level or better.
Following the strategy of [[118](#bib.bib118)] and [[35](#bib.bib35)],
we first use CAMB calculations to calibrate a Taylor expansion
for the value of $\sigma\_{8}(z=9)$ about a fiducial Planck $\Lambda$CDM model,
finding

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}\sigma\_{8}(&z=9)=0.1058\times\left({A\_{s}\over 2.196\times 10^{-9}}\right)^{1/2}\left({\Omega\_{m}h^{2}\over 0.1426}\right)^{0.520}\\ &\times\left({\Omega\_{b}h^{2}\over 0.02205}\right)^{-0.294}\left({h\over 0.673}\right)^{0.683}\left({N\_{\rm eff}\over 3.046}\right)^{-0.24}\\ &\times e^{0.3727(n\_{s}-0.96)}\left(1-\Omega\_{k}\right)^{0.175}.\end{split}$ |  | (32) |

Here $A\_{s}$ is the amplitude of primordial curvature perturbations
at the scale $k\_{0}=0.05\,$Mpc-1.
This formula updates equations (46)-(47) of [[35](#bib.bib35)],
which were expanded about a WMAP7 fiducial model.
The fairly strong $h$-dependence arises because of the conversion
from a power spectrum predicted in Mpc units based on cosmological
parameter values to an amplitude defined on a scale of $8h^{-1}\,{\rm Mpc}$.
We have made numerous checks
of this formula against full CAMB calculations
for models in the parameter ranges allowed by Planck + WP data,
finding accuracy of better than 0.1% for $\Lambda$CDM,
for $o\Lambda$CDM with $-0.2<\Omega\_{k}<0.2$,
and for $w$CDM with $-1.2<w<-0.8$, and
accuracy better than 0.5% for $\Delta N\_{\rm eff}$ models
with $2.5<N\_{\rm eff}<4.5$.
While equation ([32](#S7.E32 "In VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")) correctly reflects the response
of $\sigma\_{8}(z=9)$ to an isolated change in $N\_{\rm eff}$, in practice
the CMB-preferred values of $A\_{s}$, $\omega\_{m}$, $\omega\_{n}$, $h$, and
$n\_{s}$ all increase when $N\_{\rm eff}$ increases, with the result that
higher $N\_{\rm eff}$ models end up predicting higher clustering amplitudes.
We have not attempted to incorporate the effects of non-zero
neutrino mass in this formula because the suppression of clustering
by neutrino free streaming is redshift and scale dependent
(see [[119](#bib.bib119)] for useful representations).

Except in early dark energy models, the value of $\sigma\_{8}(z=9)$
is essentially independent of dark energy parameters because
dark energy is dynamically insignificant at $z>9$
(e.g., $\rho\_{\Lambda}/\rho\_{m}<0.003$ for a cosmological constant).
To evolve $\sigma\_{8}$ forward to $z=3$, 0.57, or 0, we use
the approximate integral formulation of the growth factor
from equation (16) of [[35](#bib.bib35)], which simply integrates
the growth rate approximation of [[120](#bib.bib120)],
$f(z)\approx[\Omega\_{m}(z)]^{\gamma}$ with
$\gamma=0.55+0.05[1+w(z=1)]$.
Spot checks against exact calculations with cosmomc
indicate that this approach is accurate to 0.3% or better
for models with $m\_{\nu}=0$ and other
parameters in the range allowed by our CMB+BAO+SN data,
although it becomes less accurate for more extreme parameter
values (especially of $\Omega\_{k}$).
For $\sum m\_{\nu}=0.06\,{\rm eV}$, CAMB yields a ratio
$\sigma\_{8}(z=0)/\sigma\_{8}(z=9)$ that is 0.5% lower than
for $m\_{\nu}=0$, with little dependence on other parameters,
so we also multiply all of our low-redshift $\sigma\_{8}$ values
by 0.995 to account for this effect.

We determine the mean values and error bars on the predicted
growth observables for our models by computing the posterior-weighted
mean and $1\sigma$ dispersion of $\sigma\_{8}\Omega\_{m}^{0.4}$,
$\sigma\_{8}(z=0.57)[\Omega\_{m}(z=0.57)]^{0.55}$, or
$\sigma\_{8}(z=2.5)$ for the parameter values in our MC chains,
using the above approximations for $\sigma\_{8}$.
Because our chains do not actually use or include values of $A\_{s}$,
we compute $\sigma\_{8}$ for the fiducial value in
equation ([32](#S7.E32 "In VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")) and add a fractional error
(based on the Planck+WP column in Table 5 of [[29](#bib.bib29)])
of 1.25% in quadrature to the MCMC error to account for the 2.5%
error in $A\_{s}$, which is proportional to $\sigma\_{8}^{2}$.
Inspection of Planck chains indicates only weak correlations
between $A\_{s}$ and other cosmological parameters, so the approximation
of an independent error contribution added in quadrature
should be adequate.
We also add in quadrature a fractional error of 0.3% to
represent potential errors of our approximate growth calculations,
though our spot checks indicate higher accuracy than this.

Figure 20: Predictions of matter clustering from our BAO+SN+CMB
constrained models compared to observational estimates.
The vertical location of the observational estimates (red points)
is arbitrary.
Labels for the model points (black) in all panels
are indicated along the left vertical axis.
Panel (a) shows the $z=0$ parameter combination
$\sigma\_{8}(\Omega\_{m}/0.3)^{0.4}$, which approximately describes
the quantity best constrained by low-redshift measurements
of the cluster mass function or weak lensing.
Black points show the mean and $1\sigma$ range computed from
our model chains, and red points show observational estimates
discussed in the text. Panel (b) presents a similar
comparison for $\sigma\_{8}(z=0.57)f(z=0.57)$, constrained by
redshift-space distortions in CMASS galaxy clustering.
Panel (c) compares $\sigma\_{8}(z=2.5)$ to an estimate
from the BOSS LyaF 1-d power spectrum.
Observational sources are the cosmic shear measurements of
Hey13 [[101](#bib.bib101)] and Jee13 [[102](#bib.bib102)],
the galaxy-galaxy lensing measurement of
Man13 [[103](#bib.bib103)], the cluster mass function measurements of
Vik09 [[104](#bib.bib104)], Roz10 [[105](#bib.bib105)], Pla13 [[106](#bib.bib106)],
and Man14 [[108](#bib.bib108)], the RSD measurements of
Beu14 [[109](#bib.bib109)], Sam14 [[121](#bib.bib121)],
and Rei14 [[114](#bib.bib114)], and the LyaF power spectrum measurement of Pal13 [[117](#bib.bib117)].
Dotted vertical lines are provided for visual reference.

Figure [20](#S7.F20 "Figure 20 ‣ VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")a shows a persistent offset between
the predicted amplitude of matter clustering and the
majority of observational
estimates from weak lensing and cluster masses.
For $\Lambda$CDM, where the model predictions are best constrained,
the statistical significance of the tension with any given
data set is usually only $\approx 2\sigma$ or smaller.
However, the sign of discrepancy is usually the same, so the
overall significance is high unless multiple analyses are
affected by a common systematic.
The important exceptions are the cosmic shear measurement
from the Deep Lens Survey [[102](#bib.bib102)] and
the recent cluster analysis of
[[108](#bib.bib108)], which both agree well
with the $\Lambda$CDM prediction. The authors of [[108](#bib.bib108)]
emphasize that theirs was
a “blind” analysis in which technical choices about
data cuts and procedures were made without knowing their eventual
impact on inferred cosmological parameter values.
Our predicted value of $\sigma\_{8}\Omega\_{m}^{0.4}$ is somewhat
lower than the value inferred by [[29](#bib.bib29)]
from CMB data alone (Planck+WP+highL),
in part because the BAO data pull
towards lower $\Omega\_{m}$, and in part because our compressed
CMB description does not include the lensing information in the
Planck power spectrum, which pulls towards higher $\sigma\_{8}$.
For more flexible dark energy models, central values of
$\sigma\_{8}\Omega\_{m}^{0.4}$ remain within the $1\sigma$ range
found for $\Lambda$CDM, and the error bars are moderately larger.
The tension with the data is moderately reduced in these models,
but not eliminated. A formal assessment of this reduced disagreement
is difficult because the true level of systematic uncertainty
in the low-redshift measurements is itself uncertain, but
at a qualitative level this reduction appears too small to favor
adopting one of these more complex models.

Figure [20](#S7.F20 "Figure 20 ‣ VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")b shows an offset of similar magnitude between the
predictions of our standard dark energy models and the redshift-space
distortion measurement of [[109](#bib.bib109)] at $z=0.57$.
However, the statistical significance of this tension is low because
of the statistical error on the measurement, and the power spectrum
analysis of [[121](#bib.bib121)] yields a higher central value.
The more precise
determination from [[114](#bib.bib114)], which draws on simulation-based
modeling of non-linear scales, overlaps the $\Lambda$CDM prediction
at $\approx 1\sigma$.
A recent analysis that combines galaxy clustering and galaxy-galaxy
lensing of CMASS galaxies [[122](#bib.bib122)]
yields constraints in the $\sigma\_{8}-\Omega\_{m}$
plane that are consistent with the $\Lambda$CDM model predictions,
but the current statistical errors are large enough to be
compatible with the central values from any of the redshift-space
distortion analyses shown here.
In contrast to the lower redshift results,
Figure [20](#S7.F20 "Figure 20 ‣ VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")c shows that
the predicted clustering amplitude at $z=2.5$
in our standard models
is lower than that inferred from the LyaF power spectrum,
though consistent at $\approx 1\sigma$.

In the $\Delta N\_{\rm eff}$ model, where we assume a $\Lambda$CDM cosmology
but allow extra relativistic species, the preferred value of
$N\_{\rm eff}$ is higher than the standard value of 3.046, as shown
previously in Figure [17](#S6.F17 "Figure 17 ‣ VI.4 Extra Relativistic Species ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"). Because of the
correlation of $N\_{\rm eff}$ with other cosmological parameters
in CMB fits, the central value of the clustering amplitude
predictions shifts upwards, while the freedom in $N\_{\rm eff}$
broadens the error bar relative to standard $\Lambda$CDM.
These changes noticeably increase the tension with
the clustering measurements at $z=0$ and the RSD measurements
at $z=0.57$, though they improve agreement with the LyaF power spectrum at $z=2.5$. Overall, current clustering
measurements provide moderate evidence against extra
relativistic species, though a firmer understanding of
systematic uncertainties in these measurements will be needed
to draw solid conclusions.

Massive neutrinos have a redshift- and scale-dependent impact on
matter clustering, which changes between the linear and non-linear regimes.
We have not attempted a full examination of free-$\sum m\_{\nu}$
models in this section because the summary of the observational
results in terms of $\sigma\_{8}-\Omega\_{m}$ constraints may not
adequately capture the effect of massive neutrinos on the
clustering observables. A value of $\sum m\_{\nu}=0.5\,{\rm eV}$,
near the 95% upper bound inferred from our compressed CMB description
and BAO constraints, would lower the predicted value of $\sigma\_{8}$ in a
Planck+WP-normalized $\Lambda$CDM model by about 12% relative to
$\sum m\_{\nu}=0.06\,{\rm eV}$. A value $\sum m\_{\nu}=0.25\,{\rm eV}$, near the
upper bound that we find when combining the full Planck likelihood
with BAO data, would produce a 6% suppression of $\sigma\_{8}$. These
numbers are somewhat different from what a naive expectation based on
linear suppression would indicate because CMB degeneracies are important
at these relatively large neutrino mass fractions.
Even the lower value is enough to remove the tension
seen in Figure [20](#S7.F20 "Figure 20 ‣ VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")a. However, the corresponding
decrease in $\sigma\_{8}(z=2.5)$ produces a significant discrepancy with the
LyaF measurement in Figure [20](#S7.F20 "Figure 20 ‣ VII Comparison to Structure Growth Constraints ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")c, and a full analysis
that models the LyaF power spectrum based on
hydrodynamic simulations with a massive neutrino component
leads to a stringent upper limit on neutrino mass
[[123](#bib.bib123)].

As discussed in Section [VI.1](#S6.SS1 "VI.1 Early Dark Energy ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"), our geometric constraints
are nearly degenerate with respect to the presence of an early
dark energy component, provided this early dark energy is present
in the radiation-dominated epoch as well as the matter-dominated
epoch and therefore shrinks the scale of the sound horizon.
Increasing the early dark energy fraction reduces the value
of $\Omega\_{m}$ (see Fig. [13](#S6.F13 "Figure 13 ‣ VI.1 Early Dark Energy ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements"))
and will also suppress growth of structure relative
to $\Lambda$CDM. Predictions of structure for early dark energy are
subtle because of the combined impacts of CMB normalization,
the imprint of early dark energy fluctuations on the CMB itself,
and the post-recombination growth rate. We therefore defer
detailed investigation of early dark energy models to future
work and make the qualitative observation that an early dark energy
component will go in
the direction of reducing tensions with low redshift clustering
measurements.

## VIII Conclusions

In the decade since the first observational detection of baryon
acoustic oscillations, BAO analysis has emerged as one of the sharpest
tools of precision cosmology. Its power arises from
the grounding of its absolute distance scale in straightforward
underlying physics, from the distinctiveness of a feature that is localized
in scale and thus not easily mimicked by observational systematics,
and from its insensitivity to non-linear gravitational evolution and galaxy
formation physics (a consequence of the large scale of BAO). The
principal challenge of the method is that one must map enormous cosmic
volumes to obtain good statistical precision. Building on the legacy
of 2dFGRS, SDSS-I/II, 6dFGS, and WiggleZ, BOSS has made major progress
on this challenge, with distance scale measurements of $1-2\%$
precision at $z=0.32$, 0.57, and 2.34. The combination of BAO
measurements with Planck+WP CMB data and the JLA SNIa compilation
leads to numerous significant
constraints on dark energy, space curvature, and the
cosmic matter and radiation density.

If we treat BAO as an uncalibrated standard ruler,
assuming only that it is constant in time, then the combination
of galaxy and LyaF BAO measurements yields a strong
($>3\sigma$) detection of dark energy, independent of
any other cosmological data.
If we assume that the angular acoustic scale of the CMB
represents the same standard ruler, then the resulting
constraints in an $o\Lambda$CDM model collapse around
a flat universe dominated by dark energy,
with $\Omega\_{m}=0.292\pm 0.18$, $\Omega\_{k}=-0.010\pm 0.016$.
Thus, high-precision measurements of a common
standard ruler at $z<0.7$, $z=2.34$, and $z=1090$
already lead to strong constraints on the cosmological model.

BAO become much more powerful when we incorporate the absolute
calibration of the sound horizon $r\_{d}$ using CMB measurements
of the matter, baryon, and radiation energy density
(eq. [16](#S2.E16 "In II.2 BAO data ‣ II Methodology, Models and Data Sets ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")).
With Planck+WP CMB data, residual uncertainties in
$\omega\_{m}$ and $\omega\_{b}$ leave only 0.4% uncertainty in
the acoustic scale $r\_{d}=147.49\pm 0.59$ Mpc
assuming a standard radiation background with three
neutrino species.
One particularly interesting application of this calibration
is to combine galaxy BAO measurements with the high-precision
measurements of relative distances from Type Ia SNe
to infer $H\_{0}$. The addition of the SN data makes the inferred
value of $H\_{0}$ insensitive to uncertainties in the dark
energy model, which would otherwise affect the extrapolation
of the distance scale from the moderate redshifts of the
BAO measurements down to $z=0$. With our standard BAO and
SN data sets, this inverse distance ladder measurement yields
$H\_{0}=67.3\pm 1.1\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$, where the 1.7% uncertainty
includes the Planck+WP uncertainty in $r\_{d}$.
This value agrees perfectly with the value inferred from current
CMB data under the much stronger assumption of a flat $\Lambda$CDM model, an important consistency test of the standard cosmology.
It is lower than most recent estimates using a Cepheid-based distance ladder.
Our measurement of $H\_{0}$ does rely on the
assumption of a standard cosmic radiation background, and
the directly constrained parameter combination is $H\_{0}r\_{d}$.
A convincing discrepancy with conventional distance-ladder
determinations of $H\_{0}$ could not be resolved by appealing
to the late-time behavior of dark energy.
It would point instead to
non-standard physics in the pre-recombination universe,
such as extra relativistic degrees of freedom or early dark energy,
which can shrink $r\_{d}$ and thus raise the inferred value of $H\_{0}$.

The full combination of CMB, BAO, and SN data places strong constraints
on dark energy and space curvature, as summarized in
Figure [8](#S5.F8 "Figure 8 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") and Table [4](#S5.T4 "Table 4 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements").
In models that allow both $w\neq-1$ and non-zero curvature,
the BAO and SN data are highly complementary.
For the $ow$CDM model, we find $w=-0.98\pm 0.06$ and
$\Omega\_{k}=-0.002\pm 0.003$. For models with $w(a)=w\_{0}+w\_{a}(1-a)$,
the constraint on evolution remains poor,
with $w\_{a}=-0.6\pm 0.6$ in $ow\_{0}w\_{a}$CDM, but the value
of $w$ at the pivot redshift where it is best constrained
remains close to $-1$.
A striking feature of Table [4](#S5.T4 "Table 4 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") is that
as degrees of freedom are added to the cosmological model
the best-fit values of parameters barely change, always remaining
close to those of flat $\Lambda$CDM.

These models are fit to a total of 43 observables:
three in our compressed description of the CMB,
31 for the compressed SN data, five for the galaxy BAO data
($D\_{V}$ from 6dFGS, MGS and BOSS LOWZ, $D\_{M}$ and $D\_{H}$ from
BOSS CMASS), and four for the LyaF BAO
($D\_{H}$ and $D\_{M}$ from forest auto-correlation
and from quasar-forest cross-correlation).
The $\Lambda$CDM model, with three free parameters ($\Omega\_{\Lambda}$, $h$, and
the absolute magnitude normalization for SNIa),
has $\chi^{2}=46.79$ for 40 d.o.f., which is statistically
acceptable.88
8
Note that Figure [10](#S5.F10 "Figure 10 ‣ V Constraints on Dark Energy Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements") omits the
CMB data from the $\chi^{2}$ accounting, so it has three fewer d.o.f.
The decrease in $\chi^{2}$ for the alternative models is not enough to
justify the addition of parameters; for example, the addition of
three free parameters in $ow\_{0}w\_{a}$CDM reduces $\chi^{2}$ by only 1.33.
However, the best-fit models in all of these cases are in significant
tension with the LyaF measurements on their own, typically at the
$2-2.5\sigma$ level. The LyaF data have little impact
on the best-fit parameter values in any of these models,
not because they agree well with the model predictions
but because parameter changes that would significantly
improve agreement with the LyaF run afoul of the
higher precision galaxy BAO measurements. Moreover,
because the LyaF measurements have lower $D\_{H}$ but
higher $D\_{M}$ than expected in the best-fit $\Lambda$CDM model,
many parameter changes that would improve the fit to $D\_{H}$
worsen the fit to $D\_{M}$, and vice versa.

We have examined several models with non-standard dark energy or
dark matter histories or non-standard radiation backgrounds.
Early dark energy that has constant $\Omega\_{\rm de}^{e}$ in the
radiation and matter dominated eras (before evolving
towards a cosmological constant at low redshift)
alters the sound horizon $r\_{d}$ and evolution of
$H(z)$ and $D\_{M}(z)$. Remarkably, the
cancellation of these effects leaves the BAO observables
$D\_{H}(z)/r\_{d}$ and $D\_{M}(z)/r\_{d}$ nearly unchanged (including
at $z=1090$), even for $\Omega\_{\rm de}^{e}$ as large as 0.3,
so that the observations incorporated in our fits still
allow a substantial early dark energy component.
Because of the smaller $r\_{d}$, such model fits yield a
higher $H\_{0}$ and lower $\Omega\_{m}$, and the suppression of
growth by early dark energy is likely to reduce the amplitude
of low-redshift matter clustering.
Full CMB power spectrum analyses yield stronger
but more model-dependent constraints on early dark energy
through its influence on the shape of the acoustic peaks
and the structure of the damping tail [[88](#bib.bib88)].
Nonetheless, the ability of these models to match expansion
history constraints while improving agreement with local $H\_{0}$
and structure growth measurements suggests that they merit
further investigation.

If “early” dark energy becomes important only
after recombination, so that it does not alter the acoustic
scale, then CMB+BAO data impose strong constraints, with
$\Omega\_{\rm de}^{e}<0.03$ at 95% confidence.
A similar conclusion applies to other physical effects that
distort the low-redshift distance scale relative to $r\_{d}$
and the distance to last scattering.
In particular, we considered models in which a component of dark
matter decays into radiation on cosmological timescales,
boosting $\Omega\_{r}$ and decreasing $\Omega\_{m}$ at low
redshifts. The BAO+CMB data limit the
fraction of dark matter that can decay by $z=0$ to below
3% (95% confidence).

With respect to expansion history, massive neutrinos are in some
sense the converse of decaying dark matter: they are relativistic
at the epoch of recombination, but at low redshift they increase
the matter density $\Omega\_{m}$ relative to the value $\Omega\_{cb}$
inferred from the CMB acoustic peaks.
The purely geometric constraints that come from BAO and our
compressed CMB description yield a 95% confidence upper limit of
$\sum m\_{\nu}<0.56\,{\rm eV}$ assuming $\Lambda$CDM, with moderately weaker
limits for models that allow $w\neq-1$ or non-zero $\Omega\_{k}$
(see Table [6](#S6.T6 "Table 6 ‣ VI.3 Massive Neutrinos ‣ VI Alternative Models ‣ Cosmological implications of baryon acoustic oscillation (BAO) measurements")). If we use full Planck CMB chains
in place of our compressed description we obtain the significantly
stronger limit $\sum m\_{\nu}<0.25\,{\rm eV}$, a difference driven by the
relatively high amplitude lensing signal detected in the Planck
power spectrum. Measurements of low-redshift matter clustering
can yield more sensitive limits on neutrino masses, and potentially
a measurement of $\sum m\_{\nu}$ through its impact on structure growth,
but the expansion history constraints are robust and impressively
stringent on their own.

Adding relativistic degrees of freedom can noticeably
improve the agreement with the LyaF BAO, and if we combine
only CMB and LyaF data the preferred $N\_{\rm eff}$ is $\approx 4$.
However, increasing $N\_{\rm eff}$ worsens agreement with the
galaxy BAO data, and when we consider our full data
combination we find $N\_{\rm eff}=3.43\pm 0.26$.
Increasing $N\_{\rm eff}$ reduces the value of $r\_{d}$ and thereby leads
to a higher inferred $H\_{0}$; for a model with free $N\_{\rm eff}$ and
free tensor-to-scalar ratio $r$ we find a marginalized constraint
$H\_{0}=70.1\pm 1.7\,{\rm km}\,{\rm s}^{-1}\,{\rm Mpc}^{-1}$.
We caution that modifying the radiation background alters
the shape of the acoustic peaks, an effect not accounted
for in the BAO measurements used here; we expect this effect
to be smaller than our statistical errors, but perhaps
not negligible.

Among these alternative models, only the model with
free $N\_{\rm eff}$ can reduce the tension with the LyaF data,
and even there the reduction is small once the galaxy BAO
constraints are also imposed.
We did construct a model with a tuned
oscillation in $D\_{M}(z)$ that reproduces both the
$D\_{M}/r\_{d}$ and $D\_{H}/r\_{d}$ measurements from the LyaF BAO
while continuing to satisfy all other constraints.
However, this model requires non-monotonic evolution of $H(z)$
and thus of $\rho\_{\rm tot}(z)$, which is difficult to
achieve in any model with non-negative dark energy density.
The artificiality and physical implausibility of this
model, and the failure of our more physically motivated models,
illustrate how difficult it is to obtain a good fit
to the BOSS LyaF BAO measurements.
This difficulty suggests that the tension of simpler models
with the LyaF data is a statistical fluke,
or perhaps reflects an unrecognized systematic
in the BAO measurement, but it highlights the importance
of further measurements of $D\_{M}$ and $H(z)$ at high redshifts.

The cosmological constraints considered here are essentially
geometrical, tied to the expansion history of the homogeneous
universe. As a further test, we have computed the predictions
of our models for low redshift measurements of matter clustering.
Confirming previous findings, but now with tighter
cosmological parameter constraints, we find that a $\Lambda$CDM model
normalized to the observed amplitude of CMB anisotropies
predicts cluster masses, weak lensing signals, and redshift-space
distortions that are higher than most observational estimates.
The tension with individual data sets is only $\approx 2\sigma$,
and the measurements themselves may be affected by systematics.
However, the direction of the discrepancy is consistent across
many analyses (though not all of them).
The additional freedom in standard
dark energy models does not reduce this tension because the
parameter values allowed by our data are always close to those of $\Lambda$CDM.
Massive neutrinos can reduce the tension by suppressing
structure growth on small scales (lowering $\sigma\_{8}$),
an effect that is small but not negligible for neutrino masses
in the range allowed by our fits.
Conversely, increasing $N\_{\rm eff}$ above the standard value of 3.046
leads to higher predicted values of $\sigma\_{8}$ because of correlation
with other cosmological parameters, thus amplifying the tension.
As previously noted,
early dark energy may reduce the tension
with the clustering data, both because it suppresses growth
of structure during the matter dominated era and because
the reduced $r\_{d}$ value leads to higher $h$ and lower $\Omega\_{m}$
when combined with CMB constraints.
Our standard $\Lambda$CDM fits produce good agreement with the matter
clustering amplitude inferred from the LyaF power spectrum
at $z\approx 2.5$; this agreement is itself an important
constraint on neutrino masses or other physical mechanisms
that reduce small scale clustering [[123](#bib.bib123)].

The application of the BAO technique to large cosmological surveys has
enabled the first percent-level measurements of absolute distances
beyond the Milky Way. In combination with CMB and SN data, these
measurements yield impressively tight constraints on the cosmic
expansion history and correspondingly stringent tests of dark energy
theories. Over the next year, the strength
of these tests will advance significantly with the final results
from BOSS and with CMB polarization and improved temperature maps from Planck.
In the longer term, BAO measurements will gain in precision and
redshift range through a multitude of ongoing or planned spectroscopic surveys,
including SDSS-IV eBOSS, HETDEX, SuMIRE, DESI, WEAVE, Euclid, and
WFIRST.99
9
See [[124](#bib.bib124)] for a brief summary
of these projects and references to more detailed descriptions.
These data sets also enable precise measurements of matter
clustering through redshift-space distortion analyses, the shape
of the 3-dimensional power spectrum, and other clustering statistics.
In combination with the expansion history constraints, these measurements can
test modified gravity explanations of cosmic acceleration and
probe the physics of inflation, the masses of neutrinos, and
the properties of dark matter.
In parallel with these large spectroscopic surveys,
supernova measurements of expansion history are gaining in precision,
data quality, and redshift range, and weak lensing constraints
on matter clustering are advancing to the percent and sub-percent
level as imaging surveys grow from millions of galaxy shape measurements
to hundreds of millions, and eventually to billions.
From the mid-1990s through the early 21st century, improving cosmological
data sets transformed our picture of the universe.
The next decade — of time and of precision —
could bring equally surprising changes to our understanding of the cosmos.

## Acknowledgements

We thank Eric Linder for useful discussions of early dark energy and
structure growth. We also thank Savvas Koushiappas and Gordon
Blackadder for alerting us to an error in the decaying dark matter
section of the preprint version of this paper and answering
our questions as we corrected it.

Funding for SDSS-III has been provided by the Alfred P. Sloan
Foundation, the Participating Institutions, the National Science
Foundation, and the U.S. Department of Energy Office of Science. The
SDSS-III web site is http://www.sdss3.org/.

SDSS-III is managed by the Astrophysical Research Consortium for the
Participating Institutions of the SDSS-III Collaboration including the
University of Arizona, the Brazilian Participation Group, Brookhaven
National Laboratory, Carnegie Mellon University, University of
Florida, the French Participation Group, the German Participation
Group, Harvard University, the Instituto de Astrofisica de Canarias,
the Michigan State/Notre Dame/JINA Participation Group, Johns Hopkins
University, Lawrence Berkeley National Laboratory, Max Planck
Institute for Astrophysics, Max Planck Institute for Extraterrestrial
Physics, New Mexico State University, New York University, Ohio State
University, Pennsylvania State University, University of Portsmouth,
Princeton University, the Spanish Participation Group, University of
Tokyo, University of Utah, Vanderbilt University, University of
Virginia, University of Washington, and Yale University.

## Appendix A List of institutions

The following is the list of institutions corresponding to the
list of authors on the front page.

1 APC, Astroparticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/Irfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon & Léonie Duquet, 75205 Paris Cedex 13, France
  
2 Lawrence Berkeley National Laboratory, 1 Cyclotron Road, Berkeley, CA 94720, USA
  
3 Department of Astronomy, University of Washington, Box 351580, Seattle, WA 98195, USA
  
4 Apache Point Observatory, P.O. Box 59, Sunspot, NM 88349-0059, USA
  
5 Center for Cosmology and Particle Physics, New York University, New York, NY 10003, USA
  
6 Department of Physics and Astronomy, UC Irvine, 4129 Frederick Reines Hall, Irvine, CA 92697, USA
  
7 Department Physics and Astronomy, University of Utah, UT 84112, USA
  
8 Institute for Advanced Study, Einstein Drive, Princeton, NJ 08540, USA
  
9 Institute of Cosmology & Gravitation, Dennis Sciama Building, University of Portsmouth, Portsmouth, PO1 3FX, UK
  
10 Observatório Nacional, Rua Gal. José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
  
11 Laboratório Interinstitucional de e-Astronomia, - LIneA, Rua Gal.José Cristino 77, Rio de Janeiro, RJ - 20921-400, Brazil
  
12 Instituto de Fisica Teorica (UAM/CSIC), Universidad Autonoma de Madrid, Cantoblanco, E-28049 Madrid, Spain
  
13 Department of Physics, Carnegie Mellon University, 5000 Forbes Avenue, Pittsburgh, PA 15213, USA
  
14 Astrophysics, University of Oxford, Keble Road, Oxford OX13RH, UK
  
15 Department of Physics, Yale University, 260 Whitney Ave, New Haven, CT 06520, USA
  
16 Institut de Ciències del Cosmos, Universitat de Barcelona, IEEC-UB, Martí i Franquès 1, E08028 Barcelona, Spain
  
17 Laboratoire d’astrophysique, Ecole Polytechnique Fédérale de Lausanne (EPFL), Observatoire de Sauverny,CH-1290 Versoix, Switzerland
  
18 Harvard-Smithsonian Center for Astrophysics, 60 Garden St., Cambridge, MA 02138, USA
  
19 Department of Astronomy, University of Florida, Gainesville, FL 32611, USA
  
20 CEA, Centre de Saclay, IRFU, 91191 Gif-sur-Yvette, France
  
21 Department of Astrophysical Sciences, Princeton University, Ivy Lane, Princeton, NJ 08544, USA
  
22 Key Laboratory for Research in Galaxies and Cosmology of Chinese Academy of Sciences, Shanghai Astronomical Observatory, Shanghai 200030, China
  
23 LPNHE, CNRS/IN2P3, Université Pierre et Marie Curie Paris 6, Université Denis Diderot Paris 7, 4 place Jussieu, 75252 Paris CEDEX, France
  
24 Department of Physics, Ohio State University, Columbus, Ohio 43210, USA
  
25 Center for Cosmology and Astro-Particle Physics, Ohio State University, Columbus, Ohio, USA
  
26 Leibniz-Institut für Astrophysik Potsdam (AIP), An der Sternwarte 16, 14482 Potsdam, Germany
  
27 CPPM, Aix-Marseille Université, CNRS/IN2P3, Marseille, France
  
28 Max-Planck-Institut für Astronomie, Königstuhl 17, D69117 Heidelberg, Germany
  
29 University College London, Gower Street, London WC1E 6BT, UK
  
30 Institució Catalana de Recerca i Estudis Avançats, Barcelona, Spain
  
31 Department of Physics and Astronomy, University of Wyoming, Laramie, WY 82071, USA
  
32 Institut d’Astrophysique de Paris, UPMC-CNRS, UMR7095, 98bis boulevard Arago, 75014 Paris, France
  
33 INAF, Osservatorio Astronomico di Trieste, Via G. B. Tiepolo 11, 34131 Trieste, Italy
  
34 Instituto de Astrofísica de Canarias (IAC), C/Vía Láctea, s/n, E-38200, La Laguna, Tenerife, Spain
  
35 Departamento Astrofísica, Universidad de La Laguna (ULL), E-38206 La Laguna, Tenerife, Spain
  
36 A\*MIDEX, Aix Marseille Université, CNRS, LAM (Laboratoire d’Astrophysique de Marseille) UMR 7326, Marseille, France
  
37 Campus of International Excellence UAM+CSIC, Cantoblanco, E-28049 Madrid, Spain
  
38 Instituto de Astrofísica de Andalucía (CSIC), E-18080 Granada, Spain
  
39 Department of Physics, University of California, 366 LeConte Hall, Berkeley, CA 94720, USA
  
40 Department of Physics, Drexel University, 3141 Chestnut Street, Philadelphia, PA 19104, USA
  
41 Department of Astronomy and Space Science, Sejong University, Seoul, 143-747, Korea
  
42 Max-Planck-Institut für extraterrestrische Physik, Postfach 1312, Giessenbachstr., 85748 Garching, Germany
  
43 Department of Physics, Kansas State University, 116 Cardwell Hall, Manhattan, KS 666506, USA
  
44 National Abastumani Astrophysical Observatory, Ilia State University, 2A Kazbegi Ave. GE-1060 Tbilisi, Georgia
  
45 Departamento de Física Teórica, Universidad Autónoma de Madrid, E-28049 Cantoblanco, Madrid, Spain
  
46 Department of Astronomy and Astrophysics, The Pennsylvania State University, University Park, PA 16802, USA
  
47 Institute for Gravitation and the Cosmos, The Pennsylvania State University, University Park, PA 16802, USA
  
48 Department of Physics and Astronomy, Ohio University, 251B Clippinger Labs, Athens, OH 45701
  
49 Brookhaven National Laboratory, 2 Center Road, Upton, NY 11973, USA
  
50 Center for Astrophysics and Space Sciences, Department of Physics, University of California, 9500 Gilman Dr., San Diego, CA 92093 USA
  
51 INFN/National Institute for Nuclear Physics, Via Valerio 2, 34127 Trieste, Italy
  
52 Department of Astronomy, University of Wisconsin-Madison, 475 N. Charter Street, Madison, WI, 53706, USA
  
53 Department of Physical Sciences, The Open University, Milton Keynes, MK7 6AA, UK
  
54 Department of Astronomy, Ohio State University, Columbus, Ohio, USA
  
55 PITT PACC, Department of Physics and Astronomy, University of Pittsburgh, Pittsburgh, PA 15260, USA
  
56 Department of Astronomy, Case Western Reserve University, Cleveland, Ohio 44106, USA
  
57 National Astronomy Observatories, Chinese Academy of Science, Beijing, 100012, P.R. China

## Appendix B Decaying dark matter model

We consider a model of dark matter decaying into radiation as

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\dot{\rho\_{x}}$ | $\displaystyle=$ | $\displaystyle-3H(t)\rho\_{x}-\lambda H\_{0}\rho\_{x},$ |  | (33) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\dot{\rho\_{g}}$ | $\displaystyle=$ | $\displaystyle-4H(t)\rho\_{g}+\lambda H\_{0}\rho\_{x},$ |  | (34) |

where $\rho\_{x}$ and $\rho\_{g}$ are the new decaying dark matter and
radiation components and the decay time constant
$\lambda$ is made dimensionless by expressing it in units of $H\_{0}$. The
Hubble parameter is given by the usual expression for $\Lambda$CDM with two
extra components

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left(\frac{H}{H\_{0}}\right)^{2}=\Omega\_{cb}a^{-3}+\Omega\_{\Lambda}+{\rho\_{\nu+r}(z)}/{\rho\_{\rm crit}}+\frac{\rho\_{x}(a)+\rho\_{g}(a)}{\rho\_{\rm crit}}$ |  | (35) |

Writing $\rho\_{x}=\rho\_{\rm crit}r\_{x}a^{-3}$ and $\rho\_{g}=\rho\_{\rm crit}r\_{r}a^{-4}$, the system of equations can be rewritten as

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{d\,r\_{x}}{d\,\ln a}$ | $\displaystyle=$ | $\displaystyle-\lambda r\_{x}\left(\frac{H}{H\_{0}}\right)^{-1},$ |  | (36) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{d\,r\_{r}}{d\,\ln a}$ | $\displaystyle=$ | $\displaystyle+a\lambda r\_{x}\left(\frac{H}{H\_{0}}\right)^{-1},$ |  | (37) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\left(\frac{H}{H\_{0}}\right)^{2}$ | $\displaystyle=$ | $\displaystyle\Omega\_{cb}a^{-3}+\Omega\_{\Lambda}+{\rho\_{\nu+r}(z)}/{\rho\_{\rm crit}}$ |  | (38) |
|  |  |  | $\displaystyle+r\_{x}(a)a^{-3}+r\_{r}(a)a^{-4},$ |  |

with initial conditions $r\_{x}(a=1)=\Omega\_{x}$ and $r\_{r}(a=1)=\Omega\_{r}$.
We can solve this system of differential equations starting at $a=1$
and going backwards in time for a given choice of $\Omega\_{x}$,
$\Omega\_{r}$ and $\lambda$.

However, in our parametrization, boundary conditions are specified in
the infinite past. We therefore use a minimizing routine that
determines the values of $\Omega\_{x}$ and $\Omega\_{r}$ today that are
required to obtain the right fraction of decaying dark matter fraction
and zero initial density in the decay product in the infinite past (assumed
to be $a\sim 10^{-4}$ in the code). At each step in minimization, the
evolution equations are solved numerically and a suitable penalty
function is evaluated.
