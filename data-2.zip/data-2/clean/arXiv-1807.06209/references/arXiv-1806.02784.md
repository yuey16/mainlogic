<!-- fulltext source=arxiv_html slug=arXiv-1806.02784 fetched=2026-09-18T00:58:23+00:00 -->

# First search for short-baseline neutrino oscillations at HFIR with PROSPECT

Preprint: APS/123-QED

J. Ashenfelterp,
A.B. Balantekinm,
C. Baldenegroi,
H.R. Bandp,
C.D. Bassf,
D.E. Bergerong,
D. Berishj,
L.J. Bignella,
N.S. Bowdene,
J. Briccon,
J.P. Brodskye,
C.D. Bryanh,
A. Bykadorova Tellesp,
J.J. Cherwinkan,
T. Classene,
K. Commefordb,
A.J. Conantc,
A.A. Coxl,
D. Daveeo,
D. Deani,
G. Deicherth,
M.V. Diwana,
M.J. Dolinskib,
A. Ericksonc,
M. Febbraroi,
B.T. Foustp,
J.K. Gaisonp,
A. Galindo-Uribarrii,k,
C.E. Gilberti,k,
K.E. Giljed,
A. Glenne,
B.W. Goddardb,
B.T. Hacketti,k,
K. Hanp,
S. Hansa,
A.B. Hansellj,
K.M. Heegerp,
B. Heffroni,k,
J. Inslerb,
D.E. Jaffea,
X. Jia,
D.C. Jonesj,
K. Koehlern,
O. Kyzylovab,
C.E. Laneb,
T.J. Langfordp,
J. LaRosag,
B.R. Littlejohnd,
F. Lopezp,
X. Lui,k,
D.A. Martinez Caicedod,
J.T. Mattai,
R.D. McKeowno,
M.P. Mendenhalle,
H.J. Millerg,
J.M. Minockb,
P.E. Muelleri,
H.P. Mummg,
J. Napolitanoj,
R. Neilsonb,
J.A. Nikkelp,
D. Norcinip,
S. Nourg,
D.A. Pushinl,
X. Qiana,
E. Romero-Romeroi,k,
R. Roseroa,
D. Sarenacl,
B.S. Seilhane,
R. Sharmaa,
P.T. Surukuchid,
C. Trinhb,
M.A. Tyrag,
R.L. Varneri,
B. Virena,
J.M. Wagnerb,
W. Wango,
B. Whitei,
C. Whited,
J. Wilhelmij,
T. Wisep,
H. Yaoo,
M. Yeha,
Y.R. Yenb,
A. Zhanga,
C. Zhanga,
X. Zhangd,
M. Zhaoa
Address: aBrookhaven National Laboratory, Upton, NY 11973, USA
Address: bDepartment of Physics, Drexel University, Philadelphia, PA 19104, USA
Address: cGeorge W. Woodruff School of Mechanical Engineering, Georgia Institute of Technology, Atlanta, GA 30332, USA
Address: dDepartment of Physics, Illinois Institute of Technology, Chicago, IL 60616, USA
Address: eNuclear and Chemical Sciences Division, Lawrence Livermore National Laboratory, Livermore, CA 94550, USA
Address: fDepartment of Physics, Le Moyne College, Syracuse, NY 13214, USA
Address: gNational Institute of Standards and Technology, Gaithersburg, MD 20899, USA
Address: hHigh Flux Isotope Reactor, Oak Ridge National Laboratory, Oak Ridge, TN 37830, USA
Address: iPhysics Division, Oak Ridge National Laboratory, Oak Ridge, TN 37830, USA
Address: jDepartment of Physics, Temple University, Philadelphia, PA 19122, USA
Address: kDepartment of Physics and Astronomy, University of Tennessee, Knoxville, TN 37996, USA
Address: lInstitute for Quantum Computing and Department of Physics and Astronomy, University of Waterloo, Waterloo, ON N2L 3G1, Canada
Address: mDepartment of Physics, University of Wisconsin, Madison, Madison, WI 53706, USA
Address: nPhysical Sciences Laboratory, University of Wisconsin, Madison, Madison, WI 53706, USA
Address: oDepartment of Physics, College of William and Mary, Williamsburg, VA 23185, USA
Address: pWright Laboratory, Department of Physics, Yale University, New Haven, CT 06520, USA
  
PROSPECT Collaboration
Email: [prospect.collaboration@gmail.com](mailto:prospect.collaboration@gmail.com)

August 24, 2026

###### Abstract

This Letter reports the first scientific results from the observation of antineutrinos emitted by fission products of 235U at the High Flux Isotope Reactor.
PROSPECT, the Precision Reactor Oscillation and Spectrum Experiment, consists of a segmented 4 ton 6Li-doped liquid scintillator detector covering a baseline range of 7-9 m from the reactor and operating under less than 1 meter water equivalent overburden.
Data collected during 33 live-days of reactor operation at a nominal power of 85 MW yields
a detection of 25461 $\pm$ 283 (stat.) inverse beta decays.
Observation of reactor antineutrinos can be achieved in PROSPECT at 5$\sigma$ statistical significance within two hours of on-surface reactor-on data-taking.
A reactor model independent analysis of the inverse beta decay prompt energy spectrum as a function of baseline constrains significant portions of the previously allowed sterile neutrino oscillation parameter space at 95 % confidence level and disfavors the best fit of the Reactor Antineutrino Anomaly at 2.2 $\sigma$ confidence level.

Experiments at nuclear reactors have led to the first direct observation of antineutrinos [[1](#bib.bib1)], the discovery of electron antineutrino oscillation [[2](#bib.bib2)], and many precise neutrino oscillation parameter measurements [[3](#bib.bib3), [4](#bib.bib4), [5](#bib.bib5)].
Nuclear models are used to predict the flux and energy spectrum of electron antineutrinos ($\overline{\nu}\_{e}$) emitted from the decay of fission products.
Absolute $\overline{\nu}\_{e}$ flux measurements show a $\sim$ 6 % deficit with respect to recent calculations [[6](#bib.bib6), [7](#bib.bib7)], with this deficit appearing to be dependent on the fuel content of nearby reactors [[8](#bib.bib8)].
The measured spectrum also deviates from model predictions [[3](#bib.bib3), [9](#bib.bib9), [10](#bib.bib10)].
It has been suggested that these discrepancies indicate incomplete reactor models or nuclear data [[11](#bib.bib11)], oscillation of $\overline{\nu}\_{e}$ to sterile neutrinos [[12](#bib.bib12)], or a combination these effects.
A range of experimental [[13](#bib.bib13), [14](#bib.bib14), [15](#bib.bib15), [16](#bib.bib16), [17](#bib.bib17)], theoretical [[18](#bib.bib18), [19](#bib.bib19), [20](#bib.bib20), [21](#bib.bib21), [22](#bib.bib22)], and global analysis [[23](#bib.bib23), [24](#bib.bib24), [25](#bib.bib25), [23](#bib.bib23), [26](#bib.bib26)] efforts have sought to understand the origin of these discrepancies.

In a schematic one active plus one sterile neutrino mixing scenario, the oscillation hypothesis predicts reactor $\overline{\nu}\_{e}$ disappearance due to an eV-scale sterile neutrino described by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle P\_{\rm{dis}}=\sin^{2}2\theta\_{14}\sin^{2}\left(1.27\Delta m^{2}\_{41}({\rm eV}^{2})\frac{L({\rm m})}{E\_{\nu}({\rm MeV})}\right),$ |  | (1) |

where $L$ and $E\_{\nu}$ are the experimental baselines and neutrino energies, $\Delta$m${}^{2}\_{41}$ is the mass squared difference between mass eigenstates, and $\theta\_{14}$ is the mixing angle between active and sterile flavor states [[27](#bib.bib27)].
Widely-cited global fits of this oscillation model to historical neutrino data including reactor flux and spectrum measurements have suggested values of $\Delta$m${}^{2}\_{41}$ and $\theta\_{14}$ of $\sim~2$ eV2 and $\sim~0.15$, respectively [[12](#bib.bib12)]; we refer to this as the ‘Reactor Antineutrino Anomaly’ oscillation parameter space.
New experiments seek to unambiguously test this hypothesis via differential measurements of the $\overline{\nu}\_{e}$ energy spectrum over a range of short ${\cal O}(10)$  m baselines [[15](#bib.bib15), [16](#bib.bib16), [17](#bib.bib17), [28](#bib.bib28), [29](#bib.bib29)].
Such efforts are complicated by the need to perform precision $\overline{\nu}\_{e}$ measurements in the challenging background environment close to a reactor core and near the Earth’s surface with little overburden [[28](#bib.bib28)].

Using a novel detector concept, PROSPECT is designed to make a reactor-model independent search for short-baseline oscillation and provide a high-precision measurement of the 235U $\overline{\nu}\_{e}$ spectrum at a highly-enriched uranium (HEU) reactor.
This Letter describes the first surface detection of reactor $\overline{\nu}\_{e}$ by PROSPECT and a model-independent search for sterile neutrino oscillations at the High Flux Isotope Reactor (HFIR) at Oak Ridge National Laboratory.

PROSPECT consists of a single segmented detector surrounded by a passive shielding package operated at a fixed position near the HFIR core [[30](#bib.bib30), [28](#bib.bib28)].
The cylindrical reactor core (diameter $=0.435\,$m, height $=0.508$ m) uses fuel enriched in 235U.
HFIR operates at a fixed power of 85 MW${}\_{\textrm{th}}$ for $24$ day cycles, with fresh fuel being used for each cycle.
A detailed reactor core model incorporating typical fuel and operational data [[31](#bib.bib31)] indicates that the 235U fission fraction always remains above 99 %.
The PROSPECT detector is deployed in a ground level room adjacent to the water pool containing the HFIR core.
In this position, the HFIR building provides less than one meter-water-equivalent of vertical concrete overburden, and the HFIR core center is located $\sim~45\,^{\circ}$ below the horizontal from the detector center at a distance of $(7.9\pm 0.1)$ m.

The PROSPECT detector is a $\sim~2.0$ m$\times$1.6 m$\times$1.2 m rectangular volume containing $\sim~4$ tons of pulse shape discriminating (PSD) liquid scintillator (LS) loaded with 6Li to a mass fraction of 0.1 % [[32](#bib.bib32), [33](#bib.bib33)].
Thin specularly reflecting panels divide the LS volume into an $11\times 14$ two-dimensional array of 154 optically isolated rectangular segments (14.5 cm$\times$14.5 cm$\times$117.6 cm).
Hollow plastic support rods
secure panels in position at segment corners, with row-adjacent segments being vertically offset to create space for the rods outside the active segment volume.
The segment long axis is almost perpendicular ($79\,^{\circ}$) to the vector between the reactor and detector centers.
The LS volume of each segment is viewed by two 5 inch photomultiplier tubes (PMTs) housed in mineral oil-filled acrylic boxes.
Thirty-five (42) support rod axes have been instrumented with removable (stationary) radioactive (optical) calibration sources, enabling in situ calibration throughout the target volume.
The detector structure and LS are contained within a rectangular acrylic vessel under a continuous flow of nitrogen cover gas, which is itself housed inside a light-tight aluminum tank.

PMT signals from collected scintillation light in a segment are recorded using CAEN V1725 250 MHz 14-bit waveform digitizer (WFD) modules [[34](#bib.bib34)].
Above-threshold ($\sim$ 5 photoelectron) signals from both PMTs in a single segment are required to trigger zero-suppressed readout of the full detector.
Trigger rates of roughly 30 kHz and 5 kHz are achieved during reactor-on and reactor-off running.
To avoid ambiguity related to detector re-triggering, analysis cuts actively remove closely-timed triggers, resulting in a dead time of $<$ 2 % ($<$ 1 %) during reactor-on (-off) periods that is directly determined from data.

For analysis, PSD, energy, and longitudinal position ($z$) values for particle interactions in a single segment are collected in a pulse.
PSD values for individual PMTs (“tail/total” ratio of ADC integrals relative to the waveform leading edge) are combined in a weighted average to produce one value for each pulse.
Pulse energy is determined by summing the ADC integral from each PMT waveform and applying $z$-dependent light collection factors determined from background neutron captures on 6Li (denoted nLi).
Relative pulse arrival times and ADC integral ratios are used to reconstruct $z$.
Using a 20 ns coincidence requirement, pulses are grouped into clusters.
Cluster energy, E${}\_{\textrm{rec}}$, is summed over all contained pulses.
Cluster $z$-position and segment number, Z${}\_{\textrm{rec}}$ and S${}\_{\textrm{rec}}$, are taken from the highest-energy pulse.
Along with pulse PSD values, these are the primary quantities used in signal selection and physics analyses.

Detector response stability and uniformity are demonstrated via examination of reconstructed physics quantities as a function of time and segment number (Fig. [1](#S0.F1 "Figure 1 ‣ First search for short-baseline neutrino oscillations at HFIR with PROSPECT")).
Sources include high-purity samples of detector-intrinsic (219Rn,215Po) correlated decays from 227Ac deliberately dissolved in the LS, (214Bi,214Po) correlated decays from 238U, background neutron captures on hydrogen, and 137Cs source $z$-scans along multiple axes.
Reconstructed energies ($z$ positions) and energy resolutions ($z$ resolutions) are stable to within $\sim$1 % ($\sim$5 cm) and $\sim$10 % ($\sim$10 %), respectively, over all times and segments.
Additionally, the rate of (Rn,Po) events
is stable to within $\sim~2$ %, consistent with the expected 0.7 % variation due to the half-life of 227Ac.

Figure 1: Detector time stability and segment-to-segment uniformity in energy (E${}\_{\textrm{rec}}$), longitudinal position resolution ($\sigma\_{z}$), and detection rate (R).
Quantities are calculated for 214Po (black) and 215Po (blue) alpha decays and neutron-hydrogen captures uniformly distributed throughout the detector (magenta), and for 137Cs (red) source deployments.
Reconstructed quantities are described in more detail in the text.
All quantities are shown relative to the average of all points in the dataset.
All error bars represent statistical uncertainties.

This Letter reports $\overline{\nu}\_{e}$ measurements based on 33 live-days of reactor-on and 28 of reactor-off data taken between March and May 2018.
During this data taking period PMTs in 31 segments exhibited intermittent bias current instabilities (19 inside the outer ring of segments, or fiducial volume).
While this behavior is investigated, segments that at any time exhibited instability are excluded from the analysis.
This corresponds to a 20 % volume reduction (18 % in the fiducial volume), in addition to a reduction in detection efficiency for nearby segments as described below.

PROSPECT detects reactor $\overline{\nu}\_{e}$ via the inverse beta decay (IBD) interaction,
$\overline{\nu}\_{e}+p\rightarrow e^{+}+n$, with analysis cuts focused on the selection of a time- and position-correlated prompt positron signal and delayed signal from nLi.
IBD candidates are selected via the following criteria:
a prompt cluster of any size with the PSD of all cluster pulses within 3.0$\sigma$ of the gamma-like PSD band mean;
a delayed single segment cluster with $0.46<\textrm{E}\_{\textrm{rec}}<0.60$ MeV and PSD more than 3.6$\sigma$ above the gamma-like PSD band mean [[33](#bib.bib33)];
a coincidence time difference $\Delta$t of (+1,+120) $\mu$s;
and a requirement that prompt and delayed clusters lie within identical or horizontally/vertically adjacent S${}\_{\textrm{rec}}$, with an added $z$-coincidence requirement of 18 cm and 14 cm for coincidences in identical or adjacent S${}\_{\textrm{rec}}$, respectively.
IBD candidates with the delayed cluster in a (0,+100) $\mu$s window around cosmic muon clusters (E${}\_{\textrm{rec}}>$15 MeV) or a (-200,+200) $\mu$s window around other high-PSD pulses with E${}\_{\textrm{rec}}>0.25$ MeV are also rejected.
These veto criteria result in a well determined inefficiency between 5.5 % and 6.9 % during this data taking period that varies due to contamination from time-varying $\gamma$-ray backgrounds [[35](#bib.bib35)].
Finally, IBD candidates with S${}\_{\textrm{rec}}$ in the outermost layer of segments or Z${}\_{\textrm{rec}}$ within 14 cm of a cell end are rejected.

The primary backgrounds to the PROSPECT $\overline{\nu}\_{e}$ measurement are time-correlated signals from cosmogenic neutrons [[28](#bib.bib28)] and accidental coincidences of ambient $\gamma$-ray fluxes and nLi captures.
Accidental coincidence rates during reactor-on and reactor-off periods are calculated with little statistical uncertainty using a $\Delta$t selection of (-12,-2) ms. Cosmogenic background rates and spectra are estimated by applying the IBD selection to reactor-off data.
The reactor-off correlated event rate is adjusted by $<1$ % to account for relative differences in atmospheric pressure, and thus cosmogenic fluxes, between reactor-on and reactor-off datasets [[36](#bib.bib36)]; this factor is determined via measurement and correlation of multiple cosmogenic event classes with local atmospheric pressure measurements [[37](#bib.bib37)].
The resulting reactor-on cosmogenic neutron background prediction is then conservatively assigned a 5 % normalization uncertainty.
Other time-correlated backgrounds
are expected to contribute $<1$ % of the reactor-off sample.

Between prompt reconstructed energies (E${}\_{\textrm{rec,p}}$) of 0.8 MeV and 7.2 MeV the reactor-on dataset contains 56378 IBD candidates and an estimated $11580\pm 12$ accidental coincidences, yielding $44797\pm 238$ correlated events.
The corresponding number of correlated background events in the reactor-off data set is $19337\pm 153$.
Correlated background subtraction yields $25461\pm 283$ detected IBDs (771/day), with a signal-to-background ratio (S/B) of 2.20 and 1.32 for accidental and correlated backgrounds, respectively.
The correlated event rate for $(0.8<\textrm{E}\_{\textrm{rec,p}}<7.2)$ MeV as a function of time and relative IBD detection rate versus baseline are shown in Fig. [2](#S0.F2 "Figure 2 ‣ First search for short-baseline neutrino oscillations at HFIR with PROSPECT").
The difference in the correlated event rate between reactor-off and -on periods indicates a clear detection of IBD events above background.
The expected 1/r2 variation in IBD rate within the detector is also observed.
Using the correlated background rate averaged over the entire reactor-off period, the transition to reactor-on operation using the $\overline{\nu}\_{e}$ signal alone can be identified to 5$\sigma$ statistical significance within 2 hours.

Figure 2: Top: Accidentals-subtracted daily IBD-like candidates (black) and calculated accidental coincidences (red). IBD candidate event rates are corrected for time-dependent variations in detector veto and livetime. Shaded regions correspond to reactor-on periods.
The gap in reactor-off data points corresponds to a planned period of detector maintenance and calibration. Bottom: Normalized background-subtracted IBD event rate versus baseline. The data is consistent with 1/r2 behavior. All error bars represent statistical uncertainties.

To perform a differential test of oscillation-induced spectral distortion, an IBD response model is generated for all detector positions using PG4, a GEANT4-based [[38](#bib.bib38)] Monte Carlo (MC) simulation package developed by the collaboration.
Accurate energy scale, non-linearity, and energy resolution simulation are established via a simultaneous fit to the energy spectra of 137Cs, 22Na, and 60Co center-deployed calibration sources and the $\beta+\gamma$-ray spectrum of cosmogenic 12B distributed uniformly throughout the detector volume.
MC data is generated for each calibration dataset in PG4 using an energy response model with two LS non-linearity parameters,
one photo-statistics resolution parameter, and one absolute energy scale parameter.
The E${}\_{\textrm{rec,p}}$ spectra of 137Cs, 60Co, and 12B are shown in Fig. [3](#S0.F3 "Figure 3 ‣ First search for short-baseline neutrino oscillations at HFIR with PROSPECT") along with PG4-simulated spectra generated using the best fit 4-parameter set.
Non-linearities for the best fit model are $\sim$20 % over the relevant E${}\_{\textrm{rec,p}}$ range with a best fit photo-statistics energy resolution of 4.5 % at 1 MeV.
Model uncertainties, treated as correlated between all segments, are derived by sampling from sets of the 4 model parameters that yield a $\chi^{2}$ value within 2 $\sigma$ of the best fit parameter set.

Figure 3: a) Measured and best fit simulated E${}\_{\textrm{rec}}$ spectra for separate 137Cs and 60Co $\gamma$-ray calibration runs deployed in the detector center. b) Observed and best fit MC-predicted reconstructed energy spectra for uniformly distributed beta decays of cosmogenic 12B. The red bands represent the energy model uncertainty in the prediction.

Accuracy of PG4-reported energy loss is checked using $z$-position scans of a 22Na $\gamma$-ray source that produces spectral features at $\sim~1.6$ MeV and $\sim~2.0$ MeV for detector-edge and detector-center calibration axes, respectively.
Observed spectrum shifts of up to $\sim~30$ keV between $z=0$ cm (segment midpoint) and $z=30$ cm deployments are correctly reproduced in MC to $\pm$ 10 keV.
This $10$ keV envelope, as well as the 1 % time stability of E${}\_{\textrm{rec}}$ observed for (Rn,Po) and (Bi,Po) are treated as both segment-correlated and segment-uncorrelated energy scale uncertainties.

Relative detection efficiency variations between segments are modeled with PG4 IBD simulations.
The largest factor contributing to efficiency non-uniformity is capture of IBD neutrons in segments currently excluded from the IBD selection.
To understand this effect, data-MC comparisons of IBD candidate prompt-delayed Z${}\_{\textrm{rec}}$ and S${}\_{\textrm{rec}}$ coincidence were performed.
Combined with the previously-mentioned 2% variation in (Rn,Po) detection rates versus time, this source of uncertainty is conservatively propagated as a 5 % segment-uncorrelated IBD rate uncertainty.

To test for the possible existence of sterile neutrino oscillations, measured prompt energy spectra are compared between different baselines.
For this purpose, a $\chi^{2}$ is defined as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\chi^{2}=\bm{\Delta}^{\textrm{T}}\textrm{V}\_{\textrm{tot}}^{-1}\bm{\Delta}.$ |  | (2) |

$\bm{\Delta}$ is a 96-element vector representing the relative agreement between measurement and prediction in 6 position bins and 16 energy bins:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta\_{l,e}=M\_{l,e}-M\_{e}\frac{P\_{l,e}}{P\_{e}}.$ |  | (3) |

In this expression, $M\_{l,e}$ and $P\_{l,e}$ are the measured and predicted content of the $l^{th}$ position bin and $e^{th}$ $E\_{\textrm{rec,p}}$ bin, respectively, while $M\_{e}$ and $P\_{e}$ are the detector-wide measured and predicted content of bin $e$, respectively:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $M\_{e}=\sum\_{l=1}^{6}M\_{l,e}\,\,\textrm{\,and\,}\,\,P\_{e}=\sum\_{l=1}^{6}P\_{l,e}.$ |  | (4) |

This form for $\Delta\_{l,e}$ is chosen to minimize the dependence of the fitted oscillation parameters on the choice of the input reactor $\overline{\nu}\_{e}$ model.
$P\_{e}$ was formed by applying the best fit PG4-generated detector response model to IBD interactions following the 235U $\overline{\nu}\_{e}$  energy spectrum of Ref. [[6](#bib.bib6)] and the cross-section of Ref. [[39](#bib.bib39)]. $P\_{l,e}$ was then determined using these inputs, a baseline generator taking into account the finite detector and core sizes, and sterile neutrino oscillation parameters ($\Delta$m${}^{2}\_{41}$,sin${}^{2}2\theta\_{14}$) as defined in Eq. [1](#S0.E1 "In First search for short-baseline neutrino oscillations at HFIR with PROSPECT").

Statistical and systematic uncertainties and their correlation between energy bins are taken into account through the covariance matrix $V\_{\textrm{tot}}$.
For each systematic uncertainty described in the previous sections, a covariance matrix $V\_{x}$ is produced via generation of toy MC datasets including 1 $\sigma$ variation of the parameter in question unless otherwise previously specified.
For signal and background statistical uncertainties, $V\_{x}$ are calculated directly.
All $V\_{x}$ are then summed to form $V\_{\textrm{tot}}$.

Figure 4: Ratio of measured IBD prompt E${}\_{\textrm{rec},p}$ spectra in six baseline bins from 6.7 to 9.2 m to the baseline-integrated spectrum. Also shown are the no-oscillation (flat) expectation and an oscillated expectation corresponding to the the best fit Reactor Antineutrino Anomaly oscillation parameters [[12](#bib.bib12)]. Error bars indicate statistical and systematic uncertainties, with statistical correlations between numerator and denominator properly taken into account.

Fig. [4](#S0.F4 "Figure 4 ‣ First search for short-baseline neutrino oscillations at HFIR with PROSPECT") shows ratios of the measured IBD E${}\_{\textrm{rec,p}}$ spectra at differing baselines ($M\_{l,e}$) to the baseline-integrated measured spectrum ($M\_{e}\frac{P\_{l,e}}{P\_{e}}$).
Also shown are the no-oscillation case (flat line) and the expected behavior due to oscillations matching the best fit parameters of the Reactor Antineutrino Anomaly (dashed line) [[12](#bib.bib12)].
No significant deviations from unity are observed at specific baseline or energy ranges.

This level of agreement is quantified using the $\chi^{2}$ of Eq. [2](#S0.E2 "In First search for short-baseline neutrino oscillations at HFIR with PROSPECT").
At $\theta\_{14}$ = 0, the $\chi^{2}$/NDF is 61.9/80, indicating good agreement between the data and the no-oscillation hypothesis.
If oscillations are allowed, a global minimum is found at $\Delta$m${}^{2}\_{41}$ = 0.5 eV2 and sin${}^{2}2\theta\_{14}$ = 0.35, with $\chi^{2}$/NDF = 57.9/78.
Using a frequentist approach [[40](#bib.bib40)], this $\Delta\chi^{2}$ is found to have an associated p-value of 0.58, indicating little incompatibility with the no-oscillation hypothesis.
An exclusion contour, shown in Fig. [5](#S0.F5 "Figure 5 ‣ First search for short-baseline neutrino oscillations at HFIR with PROSPECT"), is generated to identify all grid points whose $\Delta\chi^{2}$ with respect to the best-fit in data exceeds that of 95 % (2 $\sigma$) of oscillated toy datasets generated at that grid point 11
1
See supplementary material provided with this Letter..
The present dataset excludes significant portions of the Reactor Antineutrino Anomaly allowed region [[12](#bib.bib12)], and disfavors its best fit point at 2.2$\,\sigma$ confidence level (p-value 0.013).
The present sensitivity is limited by statistics.
Shown along with the data exclusion contour is the expected PROSPECT 95 % confidence level sensitivity curve for this dataset.
This result was further cross checked with an independent oscillation analysis using the Gaussian CLs method [[42](#bib.bib42)].

Figure 5: Sensitivity and 95 % confidence level sterile neutrino oscillation exclusion contour from the 33 live-day PROSPECT reactor-on dataset. The best fit of the Reactor Antineutrino Anomaly [[12](#bib.bib12)] is disfavored at 2.2 $\sigma$ confidence level.

In summary, the PROSPECT experiment has observed interactions of 25461 reactor $\overline{\nu}\_{e}$ produced by 235U fission in 33 live-days of reactor-on running.
The current signal selection provides a ratio of 1.32 $\overline{\nu}\_{e}$ detections to cosmogenic backgrounds, as well as the capability to identify reactor-on/off state transitions to 5$\,\sigma$ statistical confidence level within 2 hours.
These demonstrate the feasibility of on-surface reactor $\overline{\nu}\_{e}$ detection and the potential utility of this technology for reactor power monitoring.
A comparison of measured IBD prompt energy spectra between detector baselines with the 33 live-day dataset provides no indication of sterile neutrino oscillations.
This disfavors the Reactor Antineutrino Anomaly best fit point at 2.2$\,\sigma$ confidence level and constrains significant portions of the previously allowed parameter space at 95 % confidence level.

This material is based upon work supported by the following sources: US Department of Energy (DOE) Office of Science, Office of High Energy Physics under Award No. DE-SC0016357 and DE-SC0017660 to Yale University, under Award No. DE-SC0017815 to Drexel University, under Award No. DE-SC0008347 to Illinois Institute of Technology, under Award No. DE-SC0016060 to Temple University, under Contract No. DE-SC0012704 to Brookhaven National Laboratory, and under Work Proposal Number SCW1504 to Lawrence Livermore National Laboratory. This work was performed under the auspices of the U.S. Department of Energy by Lawrence Livermore National Laboratory under Contract DE-AC52-07NA27344 and by Oak Ridge National Laboratory under Contract DE-AC05-00OR22725. Additional funding for the experiment was provided by the Heising-Simons Foundation under Award No. #2016-117 to Yale University.

J.G. is supported through the NSF Graduate Research Fellowship Program and A.C. performed work under appointment to the Nuclear Nonproliferation International Safeguards Fellowship Program sponsored by the National Nuclear Security Administration’s Office of International Nuclear Safeguards (NA-241). This work was also supported by the Canada First Research Excellence Fund (CFREF), and the Natural Sciences and Engineering Research Council of Canada (NSERC) Discovery program under grant #RGPIN-418579, and Province of Ontario.

We further acknowledge support from Yale University, the Illinois Institute of Technology, Temple University, Brookhaven National Laboratory, the Lawrence Livermore National Laboratory LDRD program, the National Institute of Standards and Technology, and Oak Ridge National Laboratory. We gratefully acknowledge the support and hospitality of the High Flux Isotope Reactor and Oak Ridge National Laboratory, managed by UT-Battelle for the U.S. Department of Energy.
