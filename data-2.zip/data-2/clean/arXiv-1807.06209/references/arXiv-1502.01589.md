<!-- fulltext source=arxiv_html slug=arXiv-1502.01589 fetched=2026-09-18T01:16:37+00:00 -->

# Planck 2015 results. XIII. Cosmological parameters

The Planck team
  
Planck Collaboration: P. A. R. Ade
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
N. Aghanim
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
M. Arnaud
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
M. Ashdown
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
J. Aumont
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
C. Baccigalupi
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
A. J. Banday
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
R. B. Barreiro
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
J. G. Bartlett
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
N. Bartolo
Affiliation: Dipartimento di Fisica e Astronomia G. Galilei, Università degli Studi di Padova, via Marzolo 8, 35131 Padova, Italy
Affiliation: Istituto Nazionale di Fisica Nucleare, Sezione di Padova, via Marzolo 8, I-35131 Padova, Italy
  
E. Battaner
Affiliation: University of Granada, Departamento de Física Teórica y del Cosmos, Facultad de Ciencias, Granada, Spain
Affiliation: University of Granada, Instituto Carlos I de Física Teórica y Computacional, Granada, Spain
  
R. Battye
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
K. Benabed
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
A. Benoît
Affiliation: Institut Néel, CNRS, Université Joseph Fourier Grenoble I, 25 rue des Martyrs, Grenoble, France
  
A. Benoit-Lévy
Affiliation: Department of Physics and Astronomy, University College London, London WC1E 6BT, U.K.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
J.-P. Bernard
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
M. Bersanelli
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
P. Bielewicz
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Nicolaus Copernicus Astronomical Center, Bartycka 18, 00-716 Warsaw, Poland
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
J. J. Bock
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
A. Bonaldi
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
L. Bonavera
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
J. R. Bond
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
  
J. Borrill
Affiliation: Computational Cosmology Center, Lawrence Berkeley National Laboratory, Berkeley, California, U.S.A.
Affiliation: Space Sciences Laboratory, University of California, Berkeley, California, U.S.A.
  
F. R. Bouchet
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: Sorbonne Université-UPMC, UMR7095, Institut d’Astrophysique de Paris, 98 bis Boulevard Arago, F-75014, Paris, France
  
F. Boulanger
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
M. Bucher
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
C. Burigana
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: INFN, Sezione di Bologna, viale Berti Pichat 6/2, 40127 Bologna, Italy
  
R. C. Butler
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
E. Calabrese
Affiliation: Sub-Department of Astrophysics, University of Oxford, Keble Road, Oxford OX1 3RH, U.K.
  
J.-F. Cardoso
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: Laboratoire Traitement et Communication de l’Information, CNRS (UMR 5141) and Télécom ParisTech, 46 rue Barrault F-75634 Paris Cedex 13, France
  
A. Catalano
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
A. Challinor
Affiliation: Centre for Theoretical Cosmology, DAMTP, University of Cambridge, Wilberforce Road, Cambridge CB3 0WA, U.K.
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
A. Chamballu
Affiliation: DSM/Irfu/SPP, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
R.-R. Chary
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
H. C. Chiang
Affiliation: Astrophysics & Cosmology Research Unit, School of Mathematics, Statistics & Computer Science, University of KwaZulu-Natal, Westville Campus, Private Bag X54001, Durban 4000, South Africa
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
J. Chluba
Affiliation: Department of Physics and Astronomy, Johns Hopkins University, Bloomberg Center 435, 3400 N. Charles St., Baltimore, MD 21218, U.S.A.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
P. R. Christensen
Affiliation: Discovery Center, Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
Affiliation: Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
  
S. Church
Affiliation: Stanford University, Dept of Physics, Varian Physics Bldg, 382 Via Pueblo Mall, Stanford, California, U.S.A.
  
D. L. Clements
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
S. Colombi
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
L. P. L. Colombo
Affiliation: Department of Physics and Astronomy, Dana and David Dornsife College of Letter, Arts and Sciences, University of Southern California, Los Angeles, CA 90089, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
C. Combet
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
A. Coulais
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
B. P. Crill
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
A. Curto
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
F. Cuttaia
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
L. Danese
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
R. D. Davies
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
R. J. Davis
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
P. de Bernardis
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
A. de Rosa
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
G. de Zotti
Affiliation: INAF - Osservatorio Astronomico di Padova, Vicolo dell’Osservatorio 5, Padova, Italy
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
J. Delabrouille
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
F.-X. Désert
Affiliation: IPAG: Institut de Planétologie et d’Astrophysique de Grenoble, Université Grenoble Alpes, IPAG, F-38000 Grenoble, France, CNRS, IPAG, F-38000 Grenoble, France
  
E. Di Valentino
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: Sorbonne Université-UPMC, UMR7095, Institut d’Astrophysique de Paris, 98 bis Boulevard Arago, F-75014, Paris, France
  
C. Dickinson
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
J. M. Diego
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
K. Dolag
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
Affiliation: University Observatory, Ludwig Maximilian University of Munich, Scheinerstrasse 1, 81679 Munich, Germany
  
H. Dole
Affiliation: Institut Universitaire de France, 103, bd Saint-Michel, 75005, Paris, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
S. Donzelli
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
O. Doré
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
M. Douspis
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
A. Ducout
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
  
J. Dunkley
Affiliation: Sub-Department of Astrophysics, University of Oxford, Keble Road, Oxford OX1 3RH, U.K.
  
X. Dupac
Affiliation: European Space Agency, ESAC, Planck Science Office, Camino bajo del Castillo, s/n, Urbanización Villafranca del Castillo, Villanueva de la Cañada, Madrid, Spain
  
G. Efstathiou
††thanks: Corresponding author: G. Efstathiou, [gpe@ast.cam.ac.uk](mailto:gpe@ast.cam.ac.uk)
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
F. Elsner
Affiliation: Department of Physics and Astronomy, University College London, London WC1E 6BT, U.K.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
T. A. Enßlin
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
H. K. Eriksen
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
M. Farhang
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
Affiliation: Physics Department, Shahid Beheshti University, Tehran, Iran
  
J. Fergusson
Affiliation: Centre for Theoretical Cosmology, DAMTP, University of Cambridge, Wilberforce Road, Cambridge CB3 0WA, U.K.
  
F. Finelli
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: INFN, Sezione di Bologna, viale Berti Pichat 6/2, 40127 Bologna, Italy
  
O. Forni
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
M. Frailis
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
A. A. Fraisse
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
E. Franceschi
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
A. Frejsel
Affiliation: Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
  
S. Galeotta
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
S. Galli
Affiliation: Kavli Institute for Cosmological Physics, University of Chicago, Chicago, IL 60637, USA
  
K. Ganga
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
C. Gauthier
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Affiliation: Leung Center for Cosmology and Particle Astrophysics, National Taiwan University, Taipei 10617, Taiwan
  
M. Gerbino
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
Affiliation: Nordita (Nordic Institute for Theoretical Physics), Roslagstullsbacken 23, SE-106 91 Stockholm, Sweden
Affiliation: The Oskar Klein Centre for Cosmoparticle Physics, Department of Physics,Stockholm University, AlbaNova, SE-106 91 Stockholm, Sweden
  
T. Ghosh
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
M. Giard
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
Y. Giraud-Héraud
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
E. Giusarma
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
E. Gjerløw
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
J. González-Nuevo
Affiliation: Departamento de Física, Universidad de Oviedo, Avda. Calvo Sotelo s/n, Oviedo, Spain
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
K. M. Górski
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
Affiliation: Warsaw University Observatory, Aleje Ujazdowskie 4, 00-478 Warszawa, Poland
  
S. Gratton
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
A. Gregorio
Affiliation: Dipartimento di Fisica, Università degli Studi di Trieste, via A. Valerio 2, Trieste, Italy
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
Affiliation: INFN/National Institute for Nuclear Physics, Via Valerio 2, I-34127 Trieste, Italy
  
A. Gruppuso
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
J. E. Gudmundsson
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
Affiliation: Nordita (Nordic Institute for Theoretical Physics), Roslagstullsbacken 23, SE-106 91 Stockholm, Sweden
Affiliation: The Oskar Klein Centre for Cosmoparticle Physics, Department of Physics,Stockholm University, AlbaNova, SE-106 91 Stockholm, Sweden
  
J. Hamann
Affiliation: Sydney Institute for Astronomy, School of Physics A28, University of Sydney, NSW 2006, Australia
Affiliation: Theory Division, PH-TH, CERN, CH-1211, Geneva 23, Switzerland
  
F. K. Hansen
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
D. Hanson
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
Affiliation: McGill Physics, Ernest Rutherford Physics Building, McGill University, 3600 rue University, Montréal, QC, H3A 2T8, Canada
  
D. L. Harrison
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
G. Helou
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
  
S. Henrot-Versillé
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
C. Hernández-Monteagudo
Affiliation: Centro de Estudios de Física del Cosmos de Aragón (CEFCA), Plaza San Juan, 1, planta 2, E-44001, Teruel, Spain
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
D. Herranz
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
S. R. Hildebrandt
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
E. Hivon
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
M. Hobson
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
  
W. A. Holmes
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
A. Hornstrup
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
W. Hovest
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
Z. Huang
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
  
K. M. Huffenberger
Affiliation: Department of Physics, Florida State University, Keen Physics Building, 77 Chieftan Way, Tallahassee, Florida, U.S.A.
  
G. Hurier
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
A. H. Jaffe
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
T. R. Jaffe
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
W. C. Jones
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
M. Juvela
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
  
E. Keihänen
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
  
R. Keskitalo
Affiliation: Computational Cosmology Center, Lawrence Berkeley National Laboratory, Berkeley, California, U.S.A.
  
T. S. Kisner
Affiliation: Lawrence Berkeley National Laboratory, Berkeley, California, U.S.A.
  
R. Kneissl
Affiliation: Atacama Large Millimeter/submillimeter Array, ALMA Santiago Central Offices, Alonso de Cordova 3107, Vitacura, Casilla 763 0355, Santiago, Chile
Affiliation: European Southern Observatory, ESO Vitacura, Alonso de Cordova 3107, Vitacura, Casilla 19001, Santiago, Chile
  
J. Knoche
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
L. Knox
Affiliation: Department of Physics, University of California, One Shields Avenue, Davis, California, U.S.A.
  
M. Kunz
Affiliation: African Institute for Mathematical Sciences, 6-8 Melrose Road, Muizenberg, Cape Town, South Africa
Affiliation: Département de Physique Théorique, Université de Genève, 24, Quai E. Ansermet,1211 Genève 4, Switzerland
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
H. Kurki-Suonio
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
G. Lagache
Affiliation: Aix Marseille Université, CNRS, LAM (Laboratoire d’Astrophysique de Marseille) UMR 7326, 13388, Marseille, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
A. Lähteenmäki
Affiliation: Aalto University Metsähovi Radio Observatory and Dept of Radio Science and Engineering, P.O. Box 13000, FI-00076 AALTO, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
J.-M. Lamarre
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
A. Lasenby
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
M. Lattanzi
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INFN, Sezione di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
  
C. R. Lawrence
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
J. P. Leahy
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
R. Leonardi
Affiliation: CGEE, SCS Qd 9, Lote C, Torre C, 4∘ andar, Ed. Parque Cidade Corporate, CEP 70308-200, Brasília, DF, Brazil
  
J. Lesgourgues
Affiliation: Institut für Theoretische Teilchenphysik und Kosmologie, RWTH Aachen University, D-52056 Aachen, Germany
Affiliation: Theory Division, PH-TH, CERN, CH-1211, Geneva 23, Switzerland
  
F. Levrier
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
A. Lewis
Affiliation: Department of Physics and Astronomy, University of Sussex, Brighton BN1 9QH, U.K.
  
M. Liguori
Affiliation: Dipartimento di Fisica e Astronomia G. Galilei, Università degli Studi di Padova, via Marzolo 8, 35131 Padova, Italy
Affiliation: Istituto Nazionale di Fisica Nucleare, Sezione di Padova, via Marzolo 8, I-35131 Padova, Italy
  
P. B. Lilje
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
  
M. Linden-Vørnle
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
M. López-Caniego
Affiliation: European Space Agency, ESAC, Planck Science Office, Camino bajo del Castillo, s/n, Urbanización Villafranca del Castillo, Villanueva de la Cañada, Madrid, Spain
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
P. M. Lubin
Affiliation: Department of Physics, University of California, Santa Barbara, California, U.S.A.
  
J. F. Macías-Pérez
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
G. Maggio
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
D. Maino
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
N. Mandolesi
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
A. Mangilli
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
A. Marchini
Affiliation: INFN, Sezione di Roma 1, Università di Roma Sapienza, Piazzale Aldo Moro 2, 00185, Roma, Italy
  
M. Maris
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
P. G. Martin
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
  
M. Martinelli
Affiliation: University of Heidelberg, Institute for Theoretical Physics, Philosophenweg 16, 69120, Heidelberg, Germany
  
E. Martínez-González
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
S. Masi
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
S. Matarrese
Affiliation: Dipartimento di Fisica e Astronomia G. Galilei, Università degli Studi di Padova, via Marzolo 8, 35131 Padova, Italy
Affiliation: Gran Sasso Science Institute, INFN, viale F. Crispi 7, 67100 L’Aquila, Italy
Affiliation: Istituto Nazionale di Fisica Nucleare, Sezione di Padova, via Marzolo 8, I-35131 Padova, Italy
  
P. McGehee
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
P. R. Meinhold
Affiliation: Department of Physics, University of California, Santa Barbara, California, U.S.A.
  
A. Melchiorri
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
Affiliation: INFN, Sezione di Roma 1, Università di Roma Sapienza, Piazzale Aldo Moro 2, 00185, Roma, Italy
  
J.-B. Melin
Affiliation: DSM/Irfu/SPP, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
L. Mendes
Affiliation: European Space Agency, ESAC, Planck Science Office, Camino bajo del Castillo, s/n, Urbanización Villafranca del Castillo, Villanueva de la Cañada, Madrid, Spain
  
A. Mennella
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
M. Migliaccio
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
M. Millea
Affiliation: Department of Physics, University of California, One Shields Avenue, Davis, California, U.S.A.
  
S. Mitra
Affiliation: IUCAA, Post Bag 4, Ganeshkhind, Pune University Campus, Pune 411 007, India
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
M.-A. Miville-Deschênes
Affiliation: CITA, University of Toronto, 60 St. George St., Toronto, ON M5S 3H8, Canada
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
A. Moneti
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
  
L. Montier
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
G. Morgante
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
D. Mortlock
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
A. Moss
Affiliation: School of Physics and Astronomy, University of Nottingham, Nottingham NG7 2RD, U.K.
  
D. Munshi
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
J. A. Murphy
Affiliation: National University of Ireland, Department of Experimental Physics, Maynooth, Co. Kildare, Ireland
  
P. Naselsky
Affiliation: Discovery Center, Niels Bohr Institute, Copenhagen University, Blegdamsvej 17, Copenhagen, Denmark
Affiliation: Niels Bohr Institute, Copenhagen University, Blegdamsvej 17, Copenhagen, Denmark
  
F. Nati
Affiliation: Department of Physics, Princeton University, Princeton, New Jersey, U.S.A.
  
P. Natoli
Affiliation: Agenzia Spaziale Italiana Science Data Center, Via del Politecnico snc, 00133, Roma, Italy
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INFN, Sezione di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
  
C. B. Netterfield
Affiliation: Department of Astronomy and Astrophysics, University of Toronto, 50 Saint George Street, Toronto, Ontario, Canada
  
H. U. Nørgaard-Nielsen
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
F. Noviello
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
D. Novikov
Affiliation: Lebedev Physical Institute of the Russian Academy of Sciences, Astro Space Centre, 84/32 Profsoyuznaya st., Moscow, GSP-7, 117997, Russia
  
I. Novikov
Affiliation: Lebedev Physical Institute of the Russian Academy of Sciences, Astro Space Centre, 84/32 Profsoyuznaya st., Moscow, GSP-7, 117997, Russia
Affiliation: Niels Bohr Institute, Blegdamsvej 17, Copenhagen, Denmark
  
C. A. Oxborrow
Affiliation: DTU Space, National Space Institute, Technical University of Denmark, Elektrovej 327, DK-2800 Kgs. Lyngby, Denmark
  
F. Paci
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
L. Pagano
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
Affiliation: INFN, Sezione di Roma 1, Università di Roma Sapienza, Piazzale Aldo Moro 2, 00185, Roma, Italy
  
F. Pajot
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
R. Paladini
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
D. Paoletti
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: INFN, Sezione di Bologna, viale Berti Pichat 6/2, 40127 Bologna, Italy
  
B. Partridge
Affiliation: Haverford College Astronomy Department, 370 Lancaster Avenue, Haverford, Pennsylvania, U.S.A.
  
F. Pasian
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
G. Patanchon
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
T. J. Pearson
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
O. Perdereau
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
L. Perotto
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
F. Perrotta
Affiliation: SISSA, Astrophysics Sector, via Bonomea 265, 34136, Trieste, Italy
  
V. Pettorino
Affiliation: HGSFP and University of Heidelberg, Theoretical Physics Department, Philosophenweg 16, 69120, Heidelberg, Germany
  
F. Piacentini
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
M. Piat
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
E. Pierpaoli
Affiliation: Department of Physics and Astronomy, Dana and David Dornsife College of Letter, Arts and Sciences, University of Southern California, Los Angeles, CA 90089, U.S.A.
  
D. Pietrobon
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
S. Plaszczynski
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
E. Pointecouteau
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
G. Polenta
Affiliation: Agenzia Spaziale Italiana Science Data Center, Via del Politecnico snc, 00133, Roma, Italy
Affiliation: INAF - Osservatorio Astronomico di Roma, via di Frascati 33, Monte Porzio Catone, Italy
  
L. Popa
Affiliation: Institute for Space Sciences, Bucharest-Magurale, Romania
  
G. W. Pratt
Affiliation: Laboratoire AIM, IRFU/Service d’Astrophysique - CEA/DSM - CNRS - Université Paris Diderot, Bât. 709, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
G. Prézeau
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
S. Prunet
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
J.-L. Puget
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
J. P. Rachen
Affiliation: Department of Astrophysics/IMAPP, Radboud University Nijmegen, P.O. Box 9010, 6500 GL Nijmegen, The Netherlands
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
W. T. Reach
Affiliation: Universities Space Research Association, Stratospheric Observatory for Infrared Astronomy, MS 232-11, Moffett Field, CA 94035, U.S.A.
  
R. Rebolo
Affiliation: Consejo Superior de Investigaciones Científicas (CSIC), Madrid, Spain
Affiliation: Departamento de Astrofísica, Universidad de La Laguna (ULL), E-38206 La Laguna, Tenerife, Spain
Affiliation: Instituto de Astrofísica de Canarias, C/Vía Láctea s/n, La Laguna, Tenerife, Spain
  
M. Reinecke
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
M. Remazeilles
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
C. Renault
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
A. Renzi
Affiliation: Dipartimento di Matematica, Università di Roma Tor Vergata, Via della Ricerca Scientifica, 1, Roma, Italy
Affiliation: INFN, Sezione di Roma 2, Università di Roma Tor Vergata, Via della Ricerca Scientifica, 1, Roma, Italy
  
I. Ristorcelli
Affiliation: CNRS, IRAP, 9 Av. colonel Roche, BP 44346, F-31028 Toulouse cedex 4, France
Affiliation: Université de Toulouse, UPS-OMP, IRAP, F-31028 Toulouse cedex 4, France
  
G. Rocha
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
C. Rosset
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
M. Rossetti
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
G. Roudier
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
Affiliation: LERMA, CNRS, Observatoire de Paris, 61 Avenue de l’Observatoire, Paris, France
  
B. Rouillé d’Orfeuil
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
M. Rowan-Robinson
Affiliation: Imperial College London, Astrophysics group, Blackett Laboratory, Prince Consort Road, London, SW7 2AZ, U.K.
  
J. A. Rubiño-Martín
Affiliation: Departamento de Astrofísica, Universidad de La Laguna (ULL), E-38206 La Laguna, Tenerife, Spain
Affiliation: Instituto de Astrofísica de Canarias, C/Vía Láctea s/n, La Laguna, Tenerife, Spain
  
B. Rusholme
Affiliation: Infrared Processing and Analysis Center, California Institute of Technology, Pasadena, CA 91125, U.S.A.
  
N. Said
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
V. Salvatelli
Affiliation: Aix Marseille Université, Centre de Physique Théorique, 163 Avenue de Luminy, 13288, Marseille, France
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
L. Salvati
Affiliation: Dipartimento di Fisica, Università La Sapienza, P. le A. Moro 2, Roma, Italy
  
M. Sandri
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
D. Santos
Affiliation: Laboratoire de Physique Subatomique et Cosmologie, Université Grenoble-Alpes, CNRS/IN2P3, 53, rue des Martyrs, 38026 Grenoble Cedex, France
  
M. Savelainen
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
G. Savini
Affiliation: Optical Science Laboratory, University College London, Gower Street, London, U.K.
  
D. Scott
Affiliation: Department of Physics & Astronomy, University of British Columbia, 6224 Agricultural Road, Vancouver, British Columbia, Canada
  
M. D. Seiffert
Affiliation: California Institute of Technology, Pasadena, California, U.S.A.
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
P. Serra
Affiliation: Institut d’Astrophysique Spatiale, CNRS, Univ. Paris-Sud, Université Paris-Saclay, Bât. 121, 91405 Orsay cedex, France
  
E. P. S. Shellard
Affiliation: Centre for Theoretical Cosmology, DAMTP, University of Cambridge, Wilberforce Road, Cambridge CB3 0WA, U.K.
  
L. D. Spencer
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
M. Spinelli
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
V. Stolyarov
Affiliation: Astrophysics Group, Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, U.K.
Affiliation: Kazan Federal University, 18 Kremlyovskaya St., Kazan, 420008, Russia
Affiliation: Special Astrophysical Observatory, Russian Academy of Sciences, Nizhnij Arkhyz, Zelenchukskiy region, Karachai-Cherkessian Republic, 369167, Russia
  
R. Stompor
Affiliation: APC, AstroParticule et Cosmologie, Université Paris Diderot, CNRS/IN2P3, CEA/lrfu, Observatoire de Paris, Sorbonne Paris Cité, 10, rue Alice Domon et Léonie Duquet, 75205 Paris Cedex 13, France
  
R. Sudiwala
Affiliation: School of Physics and Astronomy, Cardiff University, Queens Buildings, The Parade, Cardiff, CF24 3AA, U.K.
  
R. Sunyaev
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
Affiliation: Space Research Institute (IKI), Russian Academy of Sciences, Profsoyuznaya Str, 84/32, Moscow, 117997, Russia
  
D. Sutton
Affiliation: Institute of Astronomy, University of Cambridge, Madingley Road, Cambridge CB3 0HA, U.K.
Affiliation: Kavli Institute for Cosmology Cambridge, Madingley Road, Cambridge, CB3 0HA, U.K.
  
A.-S. Suur-Uski
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
J.-F. Sygnet
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
  
J. A. Tauber
Affiliation: European Space Agency, ESTEC, Keplerlaan 1, 2201 AZ Noordwijk, The Netherlands
  
L. Terenzi
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: SMARTEST Research Centre, Università degli Studi e-Campus, Via Isimbardi 10, Novedrate (CO), 22060, Italy
  
L. Toffolatti
Affiliation: Departamento de Física, Universidad de Oviedo, Avda. Calvo Sotelo s/n, Oviedo, Spain
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
M. Tomasi
Affiliation: Dipartimento di Fisica, Università degli Studi di Milano, Via Celoria, 16, Milano, Italy
Affiliation: INAF/IASF Milano, Via E. Bassini 15, Milano, Italy
  
M. Tristram
Affiliation: LAL, Université Paris-Sud, CNRS/IN2P3, Orsay, France
  
T. Trombetti
Affiliation: Dipartimento di Fisica e Scienze della Terra, Università di Ferrara, Via Saragat 1, 44122 Ferrara, Italy
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
M. Tucci
Affiliation: Département de Physique Théorique, Université de Genève, 24, Quai E. Ansermet,1211 Genève 4, Switzerland
  
J. Tuovinen
Affiliation: CRANN, Trinity College, Dublin, Ireland
  
M. Türler
Affiliation: ISDC, Department of Astronomy, University of Geneva, ch. d’Ecogia 16, 1290 Versoix, Switzerland
  
G. Umana
Affiliation: INAF - Osservatorio Astrofisico di Catania, Via S. Sofia 78, Catania, Italy
  
L. Valenziano
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
J. Valiviita
Affiliation: Department of Physics, Gustaf Hällströmin katu 2a, University of Helsinki, Helsinki, Finland
Affiliation: Helsinki Institute of Physics, Gustaf Hällströmin katu 2, University of Helsinki, Helsinki, Finland
  
F. Van Tent
Affiliation: Laboratoire de Physique Théorique, Université Paris-Sud 11 & CNRS, Bâtiment 210, 91405 Orsay, France
  
P. Vielva
Affiliation: Instituto de Física de Cantabria (CSIC-Universidad de Cantabria), Avda. de los Castros s/n, Santander, Spain
  
F. Villa
Affiliation: INAF/IASF Bologna, Via Gobetti 101, Bologna, Italy
  
L. A. Wade
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
B. D. Wandelt
Affiliation: Department of Physics, University of Illinois at Urbana-Champaign, 1110 West Green Street, Urbana, Illinois, U.S.A.
Affiliation: Institut d’Astrophysique de Paris, CNRS (UMR7095), 98 bis Boulevard Arago, F-75014, Paris, France
Affiliation: UPMC Univ Paris 06, UMR7095, 98 bis Boulevard Arago, F-75014, Paris, France
  
I. K. Wehus
Affiliation: Institute of Theoretical Astrophysics, University of Oslo, Blindern, Oslo, Norway
Affiliation: Jet Propulsion Laboratory, California Institute of Technology, 4800 Oak Grove Drive, Pasadena, California, U.S.A.
  
M. White
Affiliation: Department of Physics, University of California, Berkeley, California, U.S.A.
  
S. D. M. White
Affiliation: Max-Planck-Institut für Astrophysik, Karl-Schwarzschild-Str. 1, 85741 Garching, Germany
  
A. Wilkinson
Affiliation: Jodrell Bank Centre for Astrophysics, Alan Turing Building, School of Physics and Astronomy, The University of Manchester, Oxford Road, Manchester, M13 9PL, U.K.
  
D. Yvon
Affiliation: DSM/Irfu/SPP, CEA-Saclay, F-91191 Gif-sur-Yvette Cedex, France
  
A. Zacchei
Affiliation: INAF - Osservatorio Astronomico di Trieste, Via G.B. Tiepolo 11, Trieste, Italy
  
A. Zonca
Affiliation: Department of Physics, University of California, Santa Barbara, California, U.S.A.

August 24, 2026

###### Abstract

This paper presents cosmological results based on
full-mission Planck observations of temperature and polarization
anisotropies of the cosmic microwave background (CMB) radiation. Our
results are in very good agreement with the 2013 analysis of
the Planck nominal-mission temperature data, but with increased
precision. The temperature and polarization power spectra are
consistent with the standard spatially-flat 6-parameter $\rm{\Lambda CDM}$ cosmology with a power-law spectrum of adiabatic scalar perturbations
(denoted “base $\rm{\Lambda CDM}$” in this paper). From the Planck temperature
data combined with Planck lensing, for this cosmology we find a
Hubble constant, $H\_{0}=(67.8\pm 0.9)\thinspace\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$, a matter density
parameter $\Omega\_{\rm m}=0.308\pm 0.012$, and a tilted scalar
spectral index with $n\_{\rm s}=0.968\pm 0.006$, consistent with the
2013 analysis. Note that in this abstract we quote 68 % confidence limits on
measured parameters and 95 % upper limits on other parameters. We
present the first results of polarization measurements with the Low
Frequency Instrument at large angular scales. Combined with the Planck temperature and lensing data, these measurements give a reionization optical
depth of $\tau=0.066\pm 0.016$, corresponding to a reionization redshift of
$z\_{\rm re}=8.8^{+1.7}\_{-1.4}$.
These results are consistent with those from WMAP polarization
measurements cleaned for dust emission using 353-GHz polarization
maps from the High Frequency Instrument. We find no evidence for any
departure from base $\rm{\Lambda CDM}$ in the neutrino sector of the theory; for
example, combining Planck observations with other astrophysical data
we find $N\_{\rm eff}=3.15\pm 0.23$ for the effective number of relativistic
degrees of freedom, consistent with the value $N\_{\rm eff}=3.046$ of
the Standard Model of particle physics. The sum of
neutrino masses is constrained to $\sum m\_{\nu}<0.23\thinspace{\rm eV}$.
The spatial curvature of our Universe is found to be very close to
zero, with $|\Omega\_{K}|<0.005$. Adding a tensor component as a
single-parameter extension to base $\rm{\Lambda CDM}$ we find an upper limit on the
tensor-to-scalar ratio
of $r\_{0.002}<0.11$, consistent with the Planck 2013 results and
consistent with the $B$-mode polarization constraints from a joint
analysis of BICEP2, Keck Array, and Planck (BKP)
data. Adding the BKP $B$-mode data to our analysis leads to a tighter
constraint of $r\_{0.002}<0.09$ and disfavours inflationary models
with a $V(\phi)\propto\phi^{2}$ potential. The addition of Planck polarization data leads to strong constraints on deviations from a
purely adiabatic spectrum of fluctuations. We find no evidence for any
contribution from isocurvature perturbations or from cosmic
defects. Combining Planck data with other astrophysical data,
including Type Ia supernovae, the equation of state of dark energy is
constrained to $w=-1.006\pm 0.045$, consistent with the expected
value for a cosmological constant. The standard big bang
nucleosynthesis predictions for the helium and deuterium abundances
for the best-fit Planck base $\rm{\Lambda CDM}$ cosmology are in excellent
agreement with observations. We also analyse constraints on
annihilating dark matter and on possible deviations from the standard
recombination history. In neither case do we find no evidence for new
physics. The Planck results for base $\rm{\Lambda CDM}$ are in good agreement
with baryon acoustic oscillation data and with the JLA sample of Type
Ia supernovae. However, as in the 2013 analysis, the amplitude of the
fluctuation spectrum is found to be higher than inferred from some
analyses of rich cluster counts and weak gravitational lensing. We
show that these tensions cannot easily be resolved with simple
modifications of the base $\rm{\Lambda CDM}$ cosmology. Apart from these tensions,
the base $\rm{\Lambda CDM}$ cosmology provides an excellent description of
the Planck CMB observations and many other astrophysical data sets.

###### Key Words.

Cosmology: observations – Cosmology: theory
– cosmic microwave background – cosmological parameters

## 1 Introduction

The cosmic microwave background (CMB) radiation offers an extremely
powerful way of testing the origin of fluctuations and of constraining
the matter content, geometry, and late-time evolution of the
Universe. Following the discovery of anisotropies in the CMB by the
COBE satellite ([Smoot et al. 1992](#bib.bib323)), ground-based, sub-orbital
experiments and notably the WMAP satellite ([Bennett et al. 2003](#bib.bib36); [Bennett et al. 2013](#bib.bib39)) have mapped the CMB anisotropies with increasingly high
precision, providing a wealth of new information on cosmology.

Planck11
1
Planck (<http://www.esa.int/Planck>) is a project of the European Space Agency (ESA) with instruments provided by two scientific consortia funded by ESA member states and led by Principal Investigators from France and Italy, telescope reflectors provided through a collaboration between ESA and a scientific consortium led and funded by Denmark, and additional contributions from NASA (USA).
is the third-generation space mission, following COBE and
WMAP, dedicated to measurements of the CMB anisotropies. The first
cosmological results from Planck were reported in a series of papers
(for an overview see [Planck Collaboration
I 2014](#bib.bib256), and references therein)
together with a public release of the first 15.5 months of temperature
data (which we will refer to as the nominal mission data).
Constraints on cosmological parameters from Planck were reported in
[Planck Collaboration
XVI (2014)](#bib.bib258).22
2
This paper refers extensively to the
earlier 2013 Planck cosmological parameters paper and CMB power
spectra and likelihood paper ([Planck Collaboration
XVI 2014](#bib.bib258); [Planck Collaboration
XV 2014](#bib.bib257)).
To simplify the presentation, these papers will henceforth be
referred to as [258](#bib.bib258) and [257](#bib.bib257), respectively. The
Planck 2013 analysis showed that the temperature power spectrum from
Planck was remarkably consistent with a spatially flat
$\rm{\Lambda CDM}$ cosmology specified by six parameters, which we will refer to
as the base $\rm{\Lambda CDM}$ model. However, the cosmological parameters of this
model were found to be in tension, typically at the 2–3$\thinspace\sigma$
level, with some other astronomical measurements, most notably direct
estimates of the Hubble constant ([Riess et al. 2011](#bib.bib296)), the matter density
determined from distant supernovae ([Conley et al. 2011](#bib.bib86); [Rest et al. 2014](#bib.bib294)), and
estimates of the amplitude of the fluctuation spectrum from weak
gravitational lensing ([Heymans et al. 2013](#bib.bib165); [Mandelbaum et al. 2013](#bib.bib222)) and the
abundance of rich clusters of galaxies ([Planck Collaboration
XX 2014](#bib.bib260); [Benson et al. 2013](#bib.bib40); [Hasselfield et al. 2013](#bib.bib164)). As reported in the revised version of
[258](#bib.bib258), and discussed further in Sect. [5](#S5 "5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"), some of
these tensions have been resolved with the acquisition of more
astrophysical data, while other new tensions have emerged.

The primary goal of this paper is to present the results from the full
Planck mission, including a first analysis of the
Planck polarization data. In addition, this paper introduces some
refinements in data analysis and addresses the effects of small
instrumental systematics discovered (or better understood) since
[258](#bib.bib258) appeared.

The Planck 2013 data were not entirely free of systematic effects. The
Planck instruments and analysis chains are complex and our understanding of
systematics has improved since [258](#bib.bib258). The most important of these
was the incomplete removal of line-like features in the
power spectrum of the time-ordered data, caused by interference of the 4-K
cooler electronics with the bolometer readout electronics.
This resulted in correlated systematics across detectors, leading to a small
“dip” in the power spectra at multipoles $\ell\approx 1800$ at 217 GHz,
which is most noticeable in the first sky survey.
Various tests were presented in [258](#bib.bib258) that
suggested that this systematic caused only small shifts to
cosmological parameters. Further analyses, based on the full mission data from
the HFI (29 months, 4.8 sky surveys) are consistent with this conclusion (see
Sect. [3](#S3 "3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")). In addition, we discovered
a minor error in the beam transfer functions applied to the 2013 217-GHz
spectra, which had negligible impact on the scientific results. Another
feature of the Planck data, not fully understood at the time of the 2013 data
release, was a $2.6\thinspace\%$ calibration offset (in power) between Planck and
WMAP ([Planck Collaboration
XXXI 2014](#bib.bib266), reported in [258](#bib.bib258), see also).
As discussed in Appendix A of [258](#bib.bib258), the
2013 Planck and WMAP power spectra agree to high precision if this
multiplicative factor is taken into account and it has no significant
impact on cosmological parameters apart from a rescaling of the
amplitude of the primordial fluctuation spectrum. The reasons for the 2013
calibration offsets are now largely understood and in the 2015 release the
calibrations of both Planck instruments and WMAP are consistent to
within about $0.3\thinspace\%$ in power (see [Planck Collaboration
I 2016](#bib.bib267), for further details). In addition, the Planck beams have been
characterized more accurately in the 2015 data release and there have
been minor modifications to the low-level data processing.

The layout of this paper is as follows. Section [2](#S2 "2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters")
summarizes a number of small changes to the parameter estimation
methodology since [258](#bib.bib258). The full mission temperature and
polarization power spectra are presented in
Sect. [3](#S3 "3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). The first subsection
(Sect. [3.1](#S3.SS1 "3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")) discusses the changes in the
cosmological parameters of the base $\rm{\Lambda CDM}$ cosmology compared to those
presented in 2013. Section [3.2](#S3.SS2 "3.2 545-GHz-cleaned spectra ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") presents an
assessment of the impact of foreground cleaning (using the 545-GHz
maps) on the cosmological parameters of the base $\rm{\Lambda CDM}$ model. The
power spectra and associated likelihoods are presented in
Sect. [3.3](#S3.SS3 "3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). This subsection also discusses the
internal consistency of the Planck $TT$, $TE$, and $EE$ spectra. The
agreement of $TE$ and $EE$ with the $TT$ spectra provides an important
additional test of the accuracy of our foreground corrections to the
$TT$ spectra at high multipoles.

[258](#bib.bib258) used the WMAP polarization likelihood at low multipoles to
constrain the reionization optical depth parameter $\tau$. The 2015
analysis replaces the WMAP likelihood with polarization data from the
Planck Low Frequency Instrument ([Planck Collaboration
II 2016](#bib.bib268), LFI,).
The impact of this change on
$\tau$ is discussed in Sect. [3.4](#S3.SS4 "3.4 Constraints on the reionization optical depth parameter 𝜏 ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"), which also presents an
alternative (and competitive) constraint on $\tau$ based on combining
the Planck $TT$ spectrum with the power spectrum of the lensing
potential measured by Planck. We also compare the LFI polarization
constraints with the WMAP polarization data cleaned with the
Planck HFI 353-GHz maps.

Section [4](#S4 "4 Comparison of the Planck power spectrum with high-resolution experiments ‣ Planck 2015 results. XIII. Cosmological parameters") compares the Planck power spectra with the
power spectra from high-resolution ground-based CMB data from the
Atacama Cosmology Telescope ([Das et al. 2014](#bib.bib94), ACT,) and the South
Pole Telescope ([George et al. 2015](#bib.bib140), SPT,). This section applies a
Gibbs sampling technique to sample over foreground and other
“nuisance” parameters to recover the underlying CMB power spectrum
at high multipoles ([Dunkley et al. 2013](#bib.bib105); [Calabrese et al. 2013](#bib.bib68)). Unlike
[258](#bib.bib258), in which we combined the likelihoods of the high-resolution
experiments with the Planck temperature likelihood, in
this paper we use the high-resolution experiments mainly to check the
consistency of the “damping tail” in the Planck power spectrum at
multipoles $\ga 2000$.

Section [5](#S5 "5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") introduces additional data, including the
Planck lensing likelihood ([Planck Collaboration
XV 2016](#bib.bib276), described in detail in)
and other astrophysical data sets. As in
[258](#bib.bib258), we are highly selective in the
astrophysical data sets that we combine with
Planck. As mentioned above, the main purpose of this
paper is to describe what the Planck data have to
say about cosmology. It is not our purpose to present
an exhaustive discussion of what happens when the
Planck data are combined with a wide range of
astrophysical data. This can be done by others, using
the publicly released
Planck likelihood. Nevertheless, some cosmological
parameter combinations are highly degenerate using
CMB power spectrum measurements alone, the most
severe being the “geometrical degeneracy” that
opens up when spatial curvature is allowed to
vary. Baryon acoustic oscillation (BAO) measurements
are a particularly important astrophysical data
set. Since BAO surveys involve a simple geometrical
measurement, these data are less prone to systematic
errors than most other astrophysical data. As in
[258](#bib.bib258), BAO measurements are used as a primary
astrophysical data set in combination with
Planck to break parameter degeneracies. It is
worth mentioning explicitly our approach to
interpreting tensions between Planck and other
astrophysical data sets. Tensions may be indicators of
new physics beyond that assumed in the base
$\rm{\Lambda CDM}$ model. However, they may also be caused by
systematic errors in the data. Our primary goal is to
report whether the Planck data support any
evidence for new physics. If evidence for new
physics is driven primarily by astrophysical data,
but not by Planck, then the emphasis must
necessarily shift to establishing whether the
astrophysical data are free of systematics. This type
of assessment is beyond the scope of this paper, but
sets a course for future research.

Extensions to the base $\rm{\Lambda CDM}$ cosmology are discussed in
Sect. [6](#S6 "6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"), which explores a large grid of possibilities.
In addition to these models, we also explore
constraints on big bang nucleosynthesis, dark matter annihilation,
cosmic defects, and departures from the standard recombination
history. As in [258](#bib.bib258), we find no convincing evidence for a
departure from the base $\rm{\Lambda CDM}$ model. As far as we can tell, a simple
inflationary model with a slightly tilted, purely adiabatic, scalar
fluctuation spectrum fits the Planck data and most other precision
astrophysical data. There are some “anomalies” in this picture,
including the poor fit to the CMB temperature fluctuation spectrum at
low multipoles, as reported by WMAP ([Bennett et al. 2003](#bib.bib36)) and in
[258](#bib.bib258), suggestions of departures from statistical isotropy at low
multipoles ([Planck Collaboration
XXIII 2014](#bib.bib262); [Planck Collaboration
XVI 2016](#bib.bib277), as reviewed in), and hints
of a discrepancy with the amplitude of the matter fluctuation spectrum at
low redshifts (see Sect. [5.5](#S5.SS5 "5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")). However, none of
these anomalies are of decisive statistical significance at this stage.

One of the most interesting developments since the appearance of
[258](#bib.bib258) was the detection by the BICEP2 team of a $B$-mode
polarization anisotropy ([BICEP2 Collaboration 2014](#bib.bib53)), apparently in conflict with
the 95 % upper limit on the tensor-to-scalar ratio,
$r\_{0.002}<0.11$,33
3
The subscript on $r$ refers to the pivot scale
in ${\rm Mpc}^{-1}$ used to define the tensor-to-scalar ratio. For
Planck we usually quote $r\_{0.002}$,
since a pivot scale of $0.002\thinspace{\rm Mpc}^{-1}$
is close to the scale at which there is some sensitivity to tensor modes
in the large-angle temperature power spectrum.
For a scalar spectrum with no running and a scalar
spectral index of $n\_{\rm s}=0.965$, $r\_{0.05}\approx 1.12r\_{0.002}$ for small $r$. For $r\approx 0.1$, assuming the
inflationary consistency relation, we have instead
$r\_{0.05}\approx 1.08r\_{0.002}$. reported in [258](#bib.bib258).
Clearly, the detection of
$B$-mode signal from primordial gravitational waves would have
profound consequences for cosmology and inflationary theory. However,
a number of studies, in particular an analysis of Planck 353-GHz
polarization data, suggested that polarized dust emission might
contribute a significant part of the BICEP2 signal
([Planck Collaboration Int.
XXX 2016](#bib.bib284); [Mortonson & Seljak 2014](#bib.bib233); [Flauger et al. 2014](#bib.bib125)). The situation
is now clearer following the joint analysis of BICEP2, Keck Array, and Planck data ([BICEP2/Keck Array and Planck Collaborations 2015](#bib.bib54), hereafter [54](#bib.bib54)); this increases the
signal-to-noise ratio on polarized dust emission primarily by directly
cross-correlating the BICEP2 and Keck Array data at 150 GHz with the
Planck polarization data at 353 GHz. The results of [54](#bib.bib54) give a
95 % upper limit on the tensor-to-scalar ratio of $r\_{0.05}<0.12$,
with no statistically significant evidence for a primordial gravitational
wave signal. Section [6.2](#S6.SS2 "6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") presents a brief discussion of
this result and how it fits in with the indirect constraints on $r$ derived
from the Planck 2015 data.

Our conclusions are summarized in Sect. [7](#S7 "7 Conclusions 42 footnote 42 42 footnote 42 As in the abstract, here we quote 68 % confidence limits on measured parameters and 95 % upper limits on other parameters. ‣ Planck 2015 results. XIII. Cosmological parameters").

## 2 Model, parameters, and methodology

The notation, definitions and methodology used in this paper largely
follow those described in [258](#bib.bib258),
and so will not be repeated here. For completeness, we list some
derived parameters of interest in Sect. [2.2](#S2.SS2 "2.2 Derived parameters ‣ 2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters").
We have made a small number of modifications
to the methodology, as described in Sect. [2.1](#S2.SS1 "2.1 Theoretical model ‣ 2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters"). We have also
made some minor changes to the model of unresolved foregrounds
and nuisance parameters used in the high-$\ell$ likelihood. These are
described in detail in [Planck Collaboration
XI (2016)](#bib.bib273), but to make this paper
more self-contained, these changes are summarized in
Sect. [2.3](#S2.SS3 "2.3 Changes to the foreground model ‣ 2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters").

### 2.1 Theoretical model

We adopt the same general methodology as described in [258](#bib.bib258), with small
modifications. Our main results are now based on the lensed CMB power spectra
computed with the updated January 2015 version of the
camb44
4
<http://camb.info> Boltzmann code ([Lewis et al. 2000](#bib.bib211)),
and parameter constraints are based on the January 2015 version of CosmoMC ([Lewis & Bridle 2002](#bib.bib209); [Lewis 2013](#bib.bib208)). Changes in our physical
modelling are as follows.

* $\bullet$

  For each model in which the fraction of baryonic mass in helium $Y\_{\text{P}}$ is
  not varied independently of other parameters, it is now set from the big bang
  nucleosynthesis (BBN) prediction by interpolation from a recent fitting
  formula based on results from the PArthENoPE BBN code
  ([Pisanti et al. 2008](#bib.bib255)).
  We now use a fixed fiducial neutron decay constant of
  $\tau\_{\rm n}=880.3\thinspace{\rm s}$, and also account for the small difference
  between the mass-fraction ratio $Y\_{\text{P}}$ and the nucleon-based fraction
  $Y\_{\rm P}^{\rm BBN}$. These modifications result in changes of about 1 %
  to the inferred value of $Y\_{\text{P}}$ compared to [258](#bib.bib258), giving best-fit values
  $Y\_{\text{P}}\approx 0.2453$ ($Y\_{\text{P}}^{\rm BBN}\approx 0.2467$) in $\rm{\Lambda CDM}$.
  See Sect. [6.5](#S6.SS5 "6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") for a detailed discussion of the impact of
  uncertainties arising from variations of $\tau\_{\rm n}$ and nuclear reaction
  rates; however, these uncertainties have minimal impact on our main results.
  Section [6.5](#S6.SS5 "6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") also corrects a small error arising from how the difference
  between $N\_{\rm eff}=3.046$ and $N\_{\rm eff}=3$ was handled in the BBN fitting formula.
* $\bullet$

  We have corrected a missing source term in the dark energy
  modelling for $w\neq-1$.
  The correction of this error has very little impact on our science results,
  since it is only important for values of $w$ far from $-1$.
* $\bullet$

  To model the small-scale matter power spectrum, we use the halofit approach ([Smith et al. 2003](#bib.bib321)), with the updates of [Takahashi et al. (2012)](#bib.bib334),
  as in [258](#bib.bib258), but with revised fitting parameters for
  massive neutrino models.55
  5
  Results for neutrino models with galaxy
  and CMB lensing alone use
  the camb Jan 2015 version of halofit to avoid problems at large $\Omega\_{\mathrm{m}}$;
  other results use the previous (April 2014) halofit version.
  We also now include the
  halofit corrections when calculating the lensed CMB power spectra.

As in [258](#bib.bib258) we adopt a Bayesian framework for testing theoretical models.
Tests using the “profile likelihood” method, described in
[Planck Collaboration Int.
XVI (2014)](#bib.bib282), show excellent agreement for the mean
values of the cosmological parameters and their errors, for both the base
$\rm{\Lambda CDM}$ model and its $N\_{\rm eff}$
extension. Tests have also been carried out using the class Boltzmann
code ([Lesgourgues 2011](#bib.bib206)) and the Monte Python MCMC code
([Audren et al. 2013](#bib.bib25)) in place of camb and CosmoMC, respectively.
Again, for flat models
we find excellent agreement with the baseline
choices used in this paper.

### 2.2 Derived parameters

Our base parameters are defined as in [258](#bib.bib258), and we also calculate the
same derived parameters. In addition we now compute:

* $\bullet$

  the helium nucleon fraction defined by
  $Y\_{\mathrm{P}}^{\mathrm{BBN}}\equiv 4n\_{\mathrm{He}}/n\_{\mathrm{b}}$;
* $\bullet$

  where standard BBN is assumed, the mid-value deuterium ratio predicted
  by BBN, $y\_{\mathrm{DP}}\equiv 10^{5}n\_{\mathrm{D}}/n\_{\mathrm{H}}$, using a fit
  from the PArthENoPE BBN code ([Pisanti et al. 2008](#bib.bib255));
* $\bullet$

  the comoving wavenumber of the perturbation mode that entered the Hubble radius at matter-radiation equality $z\_{\text{eq}}$, where this redshift is calculated
  approximating all neutrinos as relativistic at that time, i.e.,
  $k\_{\rm eq}\equiv a(z\_{\text{eq}})H(z\_{\text{eq}})$;
* $\bullet$

  the comoving angular diameter distance to last scattering,
  $D\_{\rm A}(z\_{\*})$;
* $\bullet$

  the angular scale of the sound horizon at matter-radiation equality,
  $\theta\_{\rm s,eq}\equiv r\_{\rm s}(z\_{\text{eq}})/D\_{\rm A}(z\_{\*})$, where $r\_{\rm s}$ is the sound
  horizon and $z\_{\*}$ is the redshift of last scattering;
* $\bullet$

  the amplitude of the CMB power spectrum $\mathcal{D}\_{\ell}\equiv\ell(\ell+1)C\_{\ell}/2\pi$ in $\thinspace\mu$K2, for
  $\ell=40$, 220, 810, 1520, and 2000;
* $\bullet$

  the primordial spectral index of the curvature perturbations at wavenumber
  $k=0.002\thinspace\text{Mpc}^{-1}$, $n\_{{\rm s},0.002}$ (as in [258](#bib.bib258), our default pivot
  scale is $k=0.05\thinspace\text{Mpc}^{-1}$, so that $n\_{\rm s}\equiv n\_{{\rm s},0.05}$);
* $\bullet$

  parameter combinations close to those probed by galaxy and CMB lensing
  (and other external data), specifically $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.5}$ and
  $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}$;
* $\bullet$

  various quantities reported by BAO and redshift-space distortion
  measurements, as described in Sects. [5.2](#S5.SS2 "5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") and [5.5.1](#S5.SS5.SSS1 "5.5.1 Redshift space distortions ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters").

### 2.3 Changes to the foreground model

Unresolved foregrounds contribute to the temperature power spectrum
and must be modelled to extract accurate cosmological parameters.
[257](#bib.bib257) and [258](#bib.bib258)
used a parametric approach to modelling foregrounds,
similar to the approach adopted in the analysis of the SPT and ACT
experiments ([Reichardt et al. 2012](#bib.bib291); [Dunkley et al. 2013](#bib.bib105)). The unresolved foregrounds
are described by a set of power spectrum
templates together with nuisance parameters, which are sampled via MCMC
along with the cosmological parameters.66
6
Our treatment of Galactic
dust emission also differs from that used in [257](#bib.bib257) and [258](#bib.bib258).
Here we describe changes to the extragalactic model and our treatment
of errors in the Planck absolute
calibration, deferring a discussion of Galactic dust modelling in temperature and polarization to
Sect. [3](#S3 "3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). The components of the extragalactic foreground
model consist of:

* $\bullet$

  the shot noise from Poisson fluctuations in the number density of point sources;
* $\bullet$

  the power due to clustering of point sources (loosely referred to as the CIB component);
* $\bullet$

  a thermal Sunyaev-Zeldovich (tSZ) component;
* $\bullet$

  a kinetic Sunyaev-Zeldovich (kSZ) component;
* $\bullet$

  the cross-correlation between tSZ and CIB.

In addition, the likelihood includes a number of other nuisance parameters,
such as relative calibrations between frequencies, and beam eigenmode
amplitudes.
We use the same templates for the tSZ, kSZ, and tSZ/CIB cross-correlation
as in the 2013 papers. However, we have made a number of changes to the CIB
modelling and the priors adopted for the SZ effects, which
we now describe in detail.

#### 2.3.1 CIB

In the 2013 papers, the CIB anisotropies were modelled as a power law:

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal D}\_{\ell}^{\nu\_{1}\times\nu\_{2}}=A^{\rm CIB}\_{\nu\_{1}\times\nu\_{2}}\left({\ell\over 3000}\right)^{\gamma\_{\rm CIB}}.$ |  | (1) |

Planck data alone provide a constraint on $A^{\rm CIB}\_{217\times 217}$
and very weak constraints on the CIB amplitudes at lower frequencies.
[258](#bib.bib258) reported typical values of
$A^{\rm CIB}\_{217\times 217}=(29\pm 6)\thinspace\mu{\rm K}^{2}$ and
$\gamma^{\rm CIB}=0.40\pm 0.15$, fitted over the range
$500\leq\ell\leq 2500$. The addition of the ACT and SPT data (“highL”)
led to solutions with steeper values of $\gamma\_{\rm CIB}$, closer to $0.8$,
suggesting that the CIB component was not well fit by a power law.

Planck results on the CIB, using H i as a tracer of Galactic dust,
are discussed in detail in [Planck Collaboration
XXX (2014)](#bib.bib265).
In that paper, a model with 1-halo and 2-halo contributions was
developed that provides an accurate description of the Planckand IRAS CIB
spectra from 217 GHz through to 3000 GHz. At high
multipoles, $\ell\ga 3000$, the halo-model spectra are reasonably well approximated by power laws, with a slope $\gamma\_{\rm CIB}\approx 0.8$ (though see Sect. [4](#S4 "4 Comparison of the Planck power spectrum with high-resolution experiments ‣ Planck 2015 results. XIII. Cosmological parameters")). At multipoles
in the range $500\la\ell\la 2000$, corresponding to the
transition from the 2-halo term dominating the clustering power to the 1-halo term dominating, the [Planck Collaboration
XXX (2014)](#bib.bib265) templates have a shallower slope, consistent with
the results of [258](#bib.bib258). The amplitudes of these templates at
$\ell=3000$ are

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle A^{\rm CIB}\_{217\times 217}$ | $\displaystyle=63.6\thinspace\mu{\rm K}^{2},$ | $\displaystyle A^{\rm CIB}\_{143\times 217}$ | $\displaystyle=19.1,\mu{\rm K}^{2},$ |  |
|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | $\displaystyle A^{\rm CIB}\_{143\times 143}$ | $\displaystyle=5.9\thinspace\mu{\rm K}^{2},$ | $\displaystyle A^{\rm CIB}\_{100\times 100}$ | $\displaystyle=1.4\thinspace\mu{\rm K}^{2}.$ |  | (2) |

Note that in [258](#bib.bib258), the CIB amplitude of the $143\times 217$ spectrum
was characterized by a correlation coefficient

|  |  |  |  |
| --- | --- | --- | --- |
|  | $A^{\rm CIB}\_{143\times 217}=r^{\rm CIB}\_{143\times 217}\sqrt{A^{\rm CIB}\_{217\times 217}A^{\rm CIB}\_{143\times 143}}.$ |  | (3) |

The combined Planck+highL solutions in [258](#bib.bib258) always give a high
correlation coefficient with a $95\thinspace\%$ lower limit of
$r^{\rm CIB}\_{143\times 217}\ga 0.85$, consistent with the model of
Eq. ([2](#S2.E2 "In 2.3.1 CIB ‣ 2.3 Changes to the foreground model ‣ 2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters")), which has $r^{\rm CIB}\_{143\times 217}\approx 1$.
In the 2015 analysis, we use the [Planck Collaboration
XXX (2014)](#bib.bib265) templates,
fixing the relative amplitudes at $100\times 100$,
$143\times 143$, and $143\times 217$ to the amplitude of the
$217\times 217$ spectrum. Thus, the CIB model used in this paper
is specified by only one amplitude, $A^{\rm CIB}\_{217\times 217}$,
which is assigned a uniform prior in the range
0–200 $\mu{\rm K}^{2}$.

In [258](#bib.bib258) we solved for the CIB amplitudes
at the CMB effective frequencies of $217$ and
$143$ GHz, and so we included colour corrections in the amplitudes
$A^{\rm CIB}\_{217\times 217}$ and $A^{\rm CIB}\_{143\times 143}$
(there was no CIB component in the $100\times 100$ spectrum).
In the 2015 Planck analysis, we do not include
a colour term since we define $A^{\rm CIB}\_{217\times 217}$ to be the actual
CIB amplitude measured in the Planck $217$-GHz
band. This is higher by a factor of about $1.33$ compared to the amplitude
at the CMB effective frequency of the
Planck 217-GHz band. This should be borne in mind by readers
comparing $2015$ and $2013$ CIB amplitudes measured by Planck.

#### 2.3.2 Thermal and kinetic SZ amplitudes

In the 2013 papers we assumed template shapes for the thermal (tSZ)
and kinetic (kSZ) spectra characterized by two amplitudes, $A^{\rm tSZ}$
and $A^{\rm kSZ}$, defined in equations (26) and (27) of [258](#bib.bib258). These
amplitudes were assigned uniform priors in the range 0–10 $(\mu{\rm K})^{2}$ . We
used the [Trac et al. (2011)](#bib.bib337) kSZ template spectrum and the
$\epsilon=0.5$ tSZ template from [Efstathiou & Migliaccio (2012)](#bib.bib110). We adopt
the same templates for the 2015 Planck analysis, since, for example, the tSZ
template is actually a good match to the results from the recent numerical
simulations of [McCarthy et al. (2014)](#bib.bib227). In addition, we previously included a template
from [Addison et al. (2012)](#bib.bib7) to model the cross-correlation between the CIB and tSZ emission from clusters of galaxies. The
amplitude of this template was characterized by a dimensionless
correlation coefficient, $\xi^{\rm tSZ\times CIB}$, which was assigned
a uniform prior in the range 0–1.
The three parameters $A^{\rm tSZ}$, $A^{\rm kSZ}$,
and $\xi^{\rm tSZ\times CIB}$, are not well constrained by Planck alone.
Even when combined with ACT and SPT, the three parameters are highly
correlated with each other.
Marginalizing over $\xi^{\rm tSZ\times CIB}$, [Reichardt et al. (2012)](#bib.bib291)
find that SPT spectra constrain the linear combination

|  |  |  |  |
| --- | --- | --- | --- |
|  | $A^{\rm kSZ}+1.55\thinspace A^{\rm tSZ}=(9.2\pm 1.3)\thinspace\mu{\rm K}^{2}.$ |  | (4) |

The slight differences in the coefficients compared to the
formula given in [Reichardt et al. (2012)](#bib.bib291) come from the different effective
frequencies used to define the Planck amplitudes $A^{\rm kSZ}$
and $A^{\rm tSZ}$.
An investigation of the 2013 Planck+highL solutions show a similar degeneracy
direction, which is almost independent of cosmology, even for extensions
to the base $\rm{\Lambda CDM}$ model:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $A^{\rm SZ}=A^{\rm kSZ}+1.6\thinspace A^{\rm tSZ}=(9.4\pm 1.4)\thinspace\mu{\rm K}^{2}$ |  | (5) |

for Planck+WP+highL,
which is very close to the degeneracy direction (Eq. [4](#S2.E4 "In 2.3.2 Thermal and kinetic SZ amplitudes ‣ 2.3 Changes to the foreground model ‣ 2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters")) measured by
SPT. In the 2015 Planck analysis, we impose a conservative Gaussian prior
for $A^{\rm SZ}$, as defined in Eq. ([5](#S2.E5 "In 2.3.2 Thermal and kinetic SZ amplitudes ‣ 2.3 Changes to the foreground model ‣ 2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters")), with a mean of $9.5\thinspace\mu{\rm K}^{2}$ and a dispersion $3\mu{\rm K}^{2}$ ([Reichardt et al. 2012](#bib.bib291), i.e., somewhat broader than
the dispersion measured by). The purpose of imposing
this prior on $A^{\rm SZ}$ is to prevent the parameters
$A^{\rm kSZ}$ and $A^{\rm tSZ}$ from wandering into unphysical
regions of parameter space when using Planck data alone. We retain the
uniform prior of [0,1] for $\xi^{\rm tSZ\times CIB}$. As this paper was being
written, results from the complete 2540 ${\rm deg}^{2}$ SPT-SZ survey area
appeared ([George et al. 2015](#bib.bib140)). These are consistent with Eq. ([5](#S2.E5 "In 2.3.2 Thermal and kinetic SZ amplitudes ‣ 2.3 Changes to the foreground model ‣ 2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters"))
and in addition constrain the correlation parameter to low values,
$\xi^{\rm tSZ\times CIB}=0.113^{+0.057}\_{-0.054}$. The looser priors on
these parameters adopted in this paper are, however, sufficient to eliminate
any significant sensitivity of cosmological parameters derived from
Planck to the modelling of the SZ components.

#### 2.3.3 Absolute Planck calibration

In [258](#bib.bib258), we treated the calibrations of the 100 and 217-GHz channels
relative to $143\thinspace{\rm GHz}$ as nuisance parameters.
This was an approximate way of dealing with small differences in relative
calibrations between different detectors at high multipoles, caused by
bolometer time-transfer function corrections and intermediate and far
sidelobes of the Planck beams.
In other words, we approximated these effects as a purely multiplicative
correction to the power spectra over the multipole
range $\ell=50$–$2500$. The absolute
calibration of the 2013 Planck power spectra was therefore fixed, by
construction, to the absolute calibration of the 143-5 bolometer.
Any error in the absolute calibration of this reference bolometer was not
propagated into errors on cosmological parameters.
For the 2015 Planck likelihoods we use an identical relative calibration
scheme between $100$, $143$, and $217$ GHz, but we
now include an absolute calibration parameter $y\_{\rm p}$, at the map level,
for the 143-GHz reference frequency. We adopt a Gaussian prior on $y\_{\rm p}$ centred on unity
with a (conservative) dispersion of $0.25\thinspace\%$.
This overall calibration uncertainty is then propagated through to cosmological
parameters such as $A\_{\rm s}$ and $\sigma\_{8}$. A discussion of the
consistency of the absolute calibrations across the nine Planck frequency
bands is given in [Planck Collaboration
I (2016)](#bib.bib267).

## 3 Constraints on the parameters of the base $\boldsymbol{\Lambda}$CDM cosmology from Planck

### 3.1 Changes in the base $\rm{\Lambda CDM}$ parameters compared to the 2013 data release

Table 1: Parameters of the base $\rm{\Lambda CDM}$ cosmology (as defined in
[258](#bib.bib258)) determined from the publicly released
nominal-mission CamSpec DetSet likelihood [2013N(DS)] and the
2013 full-mission CamSpec DetSet and cross-yearly (${\rm Y}1\times{\rm Y}2$) likelihoods with the extended sky coverage [2013F(DS) and
2013F(CY)]. These three likelihoods are combined with the WMAP polarization likelihood to constrain $\tau$. The column labelled
2015F(CHM) lists parameters for a CamSpec cross-half-mission likelihood
constructed from the 2015 maps using similar sky coverage to the
2013F(CY) likelihood (but greater sky coverage at $217$ GHz and
different point source masks, as discussed in the text). The column
labelled 2015F(CHM) (Plik) lists parameters for the Plik cross-half-mission likelihood that uses identical
sky coverage to the CamSpec likelihood. The 2015
temperature likelihoods are combined with the Planck lowP likelihood to constrain $\tau$. The last two columns list the
deviations of the Plik parameters from those of the nominal-mission and
the CamSpec 2015(CHM) likelihoods. To help refer to specific columns,
we have numbered the first six explicitly. The high-$\ell$
likelihoods used here include only $TT$ spectra. $H\_{0}$ is given in the
usual units of ${\rm km}\thinspace{\rm s}^{-1}\thinspace{\rm Mpc}^{-1}$.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | | [1] Parameter | [2] 2013N(DS) | [3] 2013F(DS) | [4] 2013F(CY) | [5] 2015F(CHM) | [6] 2015F(CHM) (Plik) | $([2]-[6])/\sigma\_{[6]}$ | $([5]-[6])/\sigma\_{[5]}$ | | $100\theta\_{\rm MC}$. | $1.04131\pm 0.00063$ | $1.04126\pm 0.00047$ | $1.04121\pm 0.00048$ | $1.04094\pm 0.00048$ | $1.04086\pm 0.00048$ | $\kern 6.13892pt0.71$ | $\kern 6.13892pt0.17$ | | $\Omega\_{b}h^{2}$. | $0.02205\pm 0.00028$ | $0.02234\pm 0.00023$ | $0.02230\pm 0.00023$ | $0.02225\pm 0.00023$ | $0.02222\pm 0.00023$ | $-0.61$ | $\kern 6.13892pt0.13$ | | $\Omega\_{c}h^{2}$. | $0.1199\pm 0.0027$ | $0.1189\pm 0.0022$ | $0.1188\pm 0.0022$ | $0.1194\pm 0.0022$ | $0.1199\pm 0.0022$ | $\kern 6.13892pt0.00$ | $-0.23$ | | $H\_{0}$. | $67.3\pm 1.2\kern 3.98613pt$ | $67.8\pm 1.0\kern 3.98613pt$ | $67.8\pm 1.0\kern 3.98613pt$ | $67.48\pm 0.98\kern 3.98613pt$ | $67.26\pm 0.98\kern 3.98613pt$ | $\kern 6.13892pt0.03$ | $\kern 6.13892pt0.22$ | | $n\_{\rm s}$. | $0.9603\pm 0.0073$ | $0.9665\pm 0.0062$ | $0.9655\pm 0.0062$ | $0.9682\pm 0.0062$ | $0.9652\pm 0.0062$ | $-0.67$ | $\kern 6.13892pt0.48$ | | $\Omega\_{\mathrm{m}}$. | $0.315\pm 0.017$ | $0.308\pm 0.013$ | $0.308\pm 0.013$ | $0.313\pm 0.013$ | $0.316\pm 0.014$ | $-0.06$ | $-0.23$ | | $\sigma\_{8}$. | $0.829\pm 0.012$ | $0.831\pm 0.011$ | $0.828\pm 0.012$ | $0.829\pm 0.015$ | $0.830\pm 0.015$ | $-0.08$ | $-0.07$ | | $\tau$. | $0.089\pm 0.013$ | $0.096\pm 0.013$ | $0.094\pm 0.013$ | $0.079\pm 0.019$ | $0.078\pm 0.019$ | $\kern 6.13892pt0.85$ | $\kern 6.13892pt0.05$ | | $10^{9}A\_{\rm s}e^{-2\tau}$. | $1.836\pm 0.013$ | $1.833\pm 0.011$ | $1.831\pm 0.011$ | $1.875\pm 0.014$ | $1.881\pm 0.014$ | $-3.46$ | $-0.42$ | |  |

The principal conclusion of [258](#bib.bib258) was the excellent agreement of
the base $\rm{\Lambda CDM}$ model with the temperature power spectra measured by
Planck. In this subsection, we compare the parameters of the base
$\rm{\Lambda CDM}$ model reported in [258](#bib.bib258) with those measured from the
full-mission 2015 data. Here we restrict the comparison to the high
multipole temperature ($TT$) likelihood (plus low-$\ell$
polarization), postponing a discussion of the $TE$ and $EE$ likelihood
blocks to Sect. [3.2](#S3.SS2 "3.2 545-GHz-cleaned spectra ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). The main differences
between the 2013 and 2015 analyses are as follows.

##### (1)

There have been a number of changes to the low-level Planck data
processing, as discussed in [Planck Collaboration
II (2016)](#bib.bib268) and
[Planck Collaboration
VII (2016)](#bib.bib269). These include: changes to the filtering
applied to remove “4-K” cooler lines from the time-ordered data
(TOD); changes to the deglitching algorithm used to correct the TOD
for cosmic ray hits; improved absolute calibration based on the
spacecraft orbital dipole and more accurate models of the beams,
accounting for the intermediate and far sidelobes. These revisions
largely eliminate the calibration difference between Planck-2013 and
WMAP reported in [258](#bib.bib258) and [Planck Collaboration
XXXI (2014)](#bib.bib266),
leading to upward shifts of the HFI and LFI Planck power spectra of
approximately 2.0 % and 1.7 %, respectively.
In addition, the mapmaking used for 2015
data processing utilizes “polarization destriping” for the polarized
HFI detectors ([Planck Collaboration
VIII 2016](#bib.bib270)).

##### (2)

The 2013 papers used WMAP polarization measurements
([Bennett et al. 2013](#bib.bib39)) at multipoles $\ell\leq 23$ to constrain the
optical depth parameter $\tau$; this likelihood was denoted “WP” in
the 2013 papers. In the 2015 analysis, the WMAP polarization
likelihood is replaced by a Planck polarization likelihood
constructed from low-resolution maps of $Q$ and $U$ polarization
measured by LFI at $70$ GHz,
foreground cleaned using the LFI 30-GHz and HFI 353-GHz maps as
polarized synchrotron and dust templates, respectively, as described in
[Planck Collaboration
XI (2016)](#bib.bib273). After a comprehensive analysis of survey-to-survey
null tests, we found possible low-level residual systematics in Surveys 2 and 4, likely related to the unfavourable alignment of the CMB dipole in those
two surveys ([Planck Collaboration
II 2016](#bib.bib268), for details see). We therefore conservatively use only six of the eight LFI 70-GHz full-sky surveys, excluding Surveys
2 and 4, The
foreground-cleaned LFI 70-GHz polarization maps are used over 46 %
of the sky, together with the temperature map from the Commander
component-separation algorithm over 94 % of the sky (see [Planck Collaboration
IX 2016](#bib.bib271), for
further details), to form a low-$\ell$
Planck temperature+polarization pixel-based likelihood that extends
up to multipole $\ell=29$. Use of the polarization information in this likelihood is denoted as
“lowP” in this paper The optical depth inferred from the lowP
likelihood combined with the Planck $TT$ likelihood
is
typically $\tau\approx 0.07$, and is about $1\thinspace\sigma$ lower than the
typical values of $\tau\approx 0.09$ inferred from the WMAP polarization
likelihood (see Sect. [3.4](#S3.SS4 "3.4 Constraints on the reionization optical depth parameter 𝜏 ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")) used in the 2013 papers. As
discussed in Sect. [3.4](#S3.SS4 "3.4 Constraints on the reionization optical depth parameter 𝜏 ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")
([Planck Collaboration
XI 2016](#bib.bib273), and in more detail in) the LFI 70-GHz and WMAP polarization maps are
consistent when both are cleaned with the HFI 353-GHz polarization maps.77
7
Throughout this paper, we adopt the following labels for likelihoods:
(i) Planck TT denotes the combination of the $TT$ likelihood at multipoles $\ell\geq 30$ and a low-$\ell$ temperature-only likelihood based on the CMB map recovered with Commander; (ii) Planck TT+lowP further includes the Planck polarization data in the low-$\ell$ likelihood, as described in the main text; (iii) labels such as Planck TE+lowP denote the $TE$ likelihood at $\ell\geq 30$ plus the polarization-only component of the map-based low-$\ell$ Planck likelihood; and (iv) Planck TT,TE,EE+lowP denotes the combination of the likelihood at $\ell\geq 30$ using $TT$, $TE$, and $EE$ spectra and the low-$\ell$ temperature+polarization likelihood. We make occasional use of combinations of the polarization likelihoods at $\ell\geq 30$ and the temperature+polarization data at low-$\ell$, which we denote with labels such as Planck TE+lowT,P.

##### (3)

In the 2013 papers, the Planck temperature likelihood was a hybrid:
over the multipole range $\ell\thinspace{=}\thinspace 2$–49, the likelihood was based
on the Commander algorithm applied to 87 % of the sky computed
using a Blackwell-Rao estimatorl the likelihood at higher multipoles
($\ell\thinspace{=}50$–2500) was constructed from cross-spectra over the
frequency range 100–217 GHz using the CamSpec software
([Planck Collaboration
XV 2014](#bib.bib257)), which is based on the methodology developed in
[Efstathiou (2004)](#bib.bib107) and [Efstathiou (2006)](#bib.bib108). At each of the
Planck HFI frequencies, the sky is observed by a number of
detectors. For example, at 217 GHz the sky is observed by four
unpolarized spider-web bolometers (SWBs) and eight polarization
sensitive bolometers (PSBs). The TOD from the 12 bolometers can be
combined to produce a single map at 217 GHz for any given period of
time. Thus, we can produce 217-GHz maps for individual sky surveys
(denoted S1, S2, S3, etc.), or by year (Y1, Y2), or split by
half-mission (HM1, HM2). We can also produce a temperature map from
each SWB and a temperature and polarization map from quadruplets of
PSBs. For example, at 217 GHz we produce four temperature and two
temperature+polarization maps. We refer to these maps as
detectors-set maps (or “DetSets” for short); note that the DetSet
maps can also be produced for any arbitrary time period. The high
multipole likelihood used in the 2013 papers was computed by
cross-correlating HFI DetSet maps for the “nominal” Planck mission
extending over 15.5 months.88
8
Although we analysed a
Planck full-mission temperature likelihood extensively, prior to
the release of the 2013 papers. For the 2015 papers we use the
full-mission Planck data, extending over 29 months for the HFI and 48
months for the LFI. In the Planck 2015 analysis, we have produced
cross-year and cross-half-mission likelihoods in addition to a DetSet
likelihood. The baseline 2015 Planck temperature-polarization
likelihood is also a hybrid, matching the high-multipole likelihood at
$\ell=30$ to the Planck pixel-based likelihood at lower multipoles.

##### (4)

The sky coverage used in the $2013$ CamSpec likelihood was
intentionally conservative, retaining effectively 49 % of the sky at 100 GHz
and 31 % of the sky at 143 and 217 GHz.99
9
These quantities are
explicitly the apodized effective $f^{\rm eff}\_{\rm sky}$, calculated as the
average of the square of the apodized mask values (see Eq. [10](#S3.E10 "In (1) Temperature masks. ‣ 3.3.1 Temperature spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")).
This was done to ensure
that on the first exposure of Planck cosmological results to the
community, corrections for Galactic dust emission were demonstrably
small and had negligible impact on cosmological parameters. In the 2015
analysis we make more aggressive use of the sky at each of these frequencies.
We have also tuned the point-source masks to each frequency,
rather than using a single point-source mask constructed from the
union of the point source catalogues at 100, 143, 217, and 353 GHz.
This results in many fewer point source holes in the 2015
analysis compared to the 2013 analysis.

##### (5)

Most of the results in this paper are derived from a revised
Plik likelihood, based on cross-half-mission spectra. The
Plik likelihood has been modified since 2013 so that it is now
similar to the CamSpec likelihood used in [258](#bib.bib258). Both likelihoods
use similar approximations to compute the covariance matrices. The
main difference is in the treatment of Galactic dust corrections in
the analysis of the polarization spectra. The two likelihoods have
been written independently and give similar (but not identical)
results, as discussed further below. The Plik likelihood is
discussed in [Planck Collaboration
XI (2016)](#bib.bib273). The CamSpec likelihood is
discussed in a separate paper (Efstathiou et al. in preparation).

##### (6)

We have made minor changes to the foreground modelling and to the
priors on some of the foreground parameters, as discussed in
Sect. [2.3](#S2.SS3 "2.3 Changes to the foreground model ‣ 2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters") and [Planck Collaboration
XI (2016)](#bib.bib273).

Given these changes to data processing, mission length, sky coverage, etc.,
it is reasonable to ask whether the base $\rm{\Lambda CDM}$ parameters have changed
significantly compared to the 2013 numbers. In fact, the parameter shifts
are relatively small. The situation is summarized in Table [1](#S3.T1 "Table 1 ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters").
The second column of this table lists the Planck+WP parameters, as given in
table 5 of [258](#bib.bib258). Since these numbers are based on
the 2013 processing of the nominal mission and computed via a DetSet
CamSpec likelihood, the column is labelled
2013N(DS). We now make a number of specific remarks about these comparisons.

##### (1) 4-K cooler line systematics.

After the submission of
[258](#bib.bib258) we found strong evidence that a residual in the
$217\times 217$ DetSet spectrum at $\ell\approx 1800$ was a systematic
caused by electromagnetic interference between the Joule-Thomson 4-K
cooler electronics and the bolometer readout electronics. This
interference leads to a set of time-variable narrow lines in the power spectrum
of the TOD. The data processing pipelines apply a filter to remove these
lines; however, the filtering failed to reduce their impact on the power spectra
to negligible levels. Incomplete removal of the 4-K cooler lines
affects primarily the $217\times 217$ PSB$\times$PSB cross-spectrum in
Survey 1. The
presence of this systematic was reported in the revised versions of
2013 Planck papers. Using simulations and also comparison with the 2013
full-mission likelihood (in which the $217\times 217$ power spectrum “dip” is
strongly diluted by the additional sky surveys) we assessed that the 4-K line systematic was causing shifts in cosmological parameters
of less than $0.5\thinspace\sigma$.1010
10
The revised version of [258](#bib.bib258) also reported
an error in the ordering of the beam-transfer functions applied to
some of the 2013 $217\times 217$ DetSet cross-spectra, leading to an offset
of a few $(\mu{\rm K})^{2}$ in the coadded $217\times 217$ spectrum. As
discussed in [258](#bib.bib258), this offset is largely absorbed
by the foreground model and has negligible impact on the 2013 cosmological
parameters. Column 3 in Table [1](#S3.T1 "Table 1 ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")
lists the DetSet parameters for the full-mission 2013
data. This full-mission likelihood uses more extensive sky coverage
than the nominal mission likelihood (effectively 39 % of sky at 217 GHz,
55 % of sky at 143 GHz, and 63 % of sky at 100 GHz);
otherwise the methodology
and foreground model are identical to the CamSpec likelihood
described in [257](#bib.bib257). The parameter shifts are
relatively small and consistent with the improvement in
signal-to-noise of the full-mission spectra and the systematic shifts
caused by the $217\times 217$ dip in the nominal mission (for example,
raising $H\_{0}$ and $n\_{\rm s}$, as discussed in appendix C4 of [258](#bib.bib258)).

##### (2) DetSets versus cross-surveys.

In a reanalysis of the publicly
released Planck maps, [Spergel et al. (2015)](#bib.bib325) constructed cross-survey
(${\rm S}1\times{\rm S}2$) likelihoods and found cosmological
parameters for the base $\rm{\Lambda CDM}$ model that were close to (within
approximately $1\thinspace\sigma$) the nominal mission parameters listed in
Table [1](#S3.T1 "Table 1 ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). The [Spergel et al. (2015)](#bib.bib325) analysis differs
substantially in sky coverage and foreground modelling compared to the
2013 Planck analysis and so it is encouraging that they find no
major differences with the results presented by the
Planck collaboration. On the other hand, they did not identify the
reasons for the roughly $1\thinspace\sigma$ parameter shifts. They argue that
foreground modelling and the $\ell\thinspace{=}\thinspace 1800$ dip in the
$217\times 217$ DetSet spectrum can contribute towards some of the
differences but cannot produce $1\thinspace\sigma$ shifts, in agreement with
the conclusions of [258](#bib.bib258).
The 2013F(DS) likelihood disfavours the
[Spergel et al. (2015)](#bib.bib325) cosmology (with parameters listed in their
table 3) by $\Delta\chi^{2}=11$, i.e., by about $2\thinspace\sigma$, and
almost all of the $\Delta\chi^{2}$ is contributed by the multipole
range 1000–1500, so the parameter shifts are not driven by
cotemporal systematics resulting in correlated noise biases at high
multipoles.
However, as discussed in [257](#bib.bib257) and [Planck Collaboration
XI (2016)](#bib.bib273), low-level
correlated noise in
the DetSet spectra affects all HFI channels at high multipoles
where the spectra are noise dominated. The impact of this
correlated noise on cosmological parameters is relatively small. This is
illustrated by column 4 of Table [1](#S3.T1 "Table 1 ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") (labelled
“2013F(CY)”), which lists the parameters of a 2013
CamSpec cross-year likelihood using the same sky coverage and
foreground model as the DetSet likelihood used for column 3. The
parameters from these two likelihoods are in good agreement (better
than $0.2\thinspace\sigma$), illustrating
that cotemporal systematics in the DetSets are at sufficiently low
levels that there is very little effect on cosmological
parameters. Nevertheless, in the 2015 likelihood analysis we apply
corrections for correlated noise to the DetSet cross-spectra, as
discussed in [Planck Collaboration
XI (2016)](#bib.bib273), and typically find agreement in
cosmological parameters between DetSet, cross-year, and
cross-half-mission likelihoods to better than $0.5\thinspace\sigma$ accuracy
for a fixed likelihood code (and to better than $0.2\thinspace\sigma$ accuracy for
base $\rm{\Lambda CDM}$).

Figure 1: Planck 2015 temperature power spectrum. At multipoles $\ell\geq 30$
we show the maximum likelihood frequency-averaged temperature spectrum
computed from the Plik cross-half-mission likelihood, with foreground and other nuisance parameters
determined from the MCMC analysis of the base $\rm{\Lambda CDM}$ cosmology. In the multipole range $2\leq\ell\leq 29$, we plot the
power spectrum estimates from the Commander component-separation algorithm, computed over 94 % of the sky.
The best-fit base $\rm{\Lambda CDM}$ theoretical spectrum fitted to the Planck TT+lowP likelihood is plotted in the
upper panel. Residuals with respect to this model are shown in the lower panel.
The error bars show $\pm 1\thinspace\sigma$ uncertainties.

##### (3) 2015 versus 2013 processing.

Column 5 (labelled “2015F(CHM)”) lists the parameters
computed from the CamSpec cross-half-mission likelihood using the
HFI 2015 data with revised absolute calibration and beam-transfer functions.
We also replace the WP likelihood of the 2013 analysis with the Planck lowP likelihood. The 2015F(CHM) likelihood uses slightly more sky coverage
(60 %) at 217 GHz, compared to the 2013F(CY) likelihood and also uses
revised point source masks. Despite these changes, the base $\rm{\Lambda CDM}$ parameters
derived from the 2015 CamSpec likelihood are within $\approx 0.4\thinspace\sigma$
of the 2013F(CY) parameters, with the exception of $\theta\_{\rm MC}$,
which is lower by $0.67\thinspace\sigma$,
$\tau$, which is lower by $1\thinspace\sigma$, and $A\_{\rm s}e^{-2\tau}$, which is
higher by about $4\thinspace\sigma$ . The change in $\tau$
simply reflects the preference for a lower value of $\tau$ from the Planck LFI polarization data compared to the WMAP polarization likelihood in the form
delivered by the WMAP team (see Sect. [3.4](#S3.SS4 "3.4 Constraints on the reionization optical depth parameter 𝜏 ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") for further discussion).
The large upward shift in $A\_{\rm s}e^{-2\tau}$ reflects the change in the
absolute calibration of the HFI. As noted in Sect. [2.3](#S2.SS3 "2.3 Changes to the foreground model ‣ 2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters"),
the 2013 analysis did not propagate an error on the Planck absolute
calibration through to cosmological parameters. Coincidentally, the
changes to the absolute calibration compensate for the downward change
in $\tau$ and variations in the other cosmological parameters to keep the
parameter $\sigma\_{8}$ largely unchanged from the 2013 value. This will be
important when we come to discuss possible tensions between the amplitude of
the matter fluctuations at low redshift estimated from various astrophysical
data sets and the Planck CMB values for the base $\rm{\Lambda CDM}$ cosmology
(see Sect. [5.6](#S5.SS6 "5.6 Cosmic concordance? ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")).

##### (4) Likelihoods.

Constructing a high-multipole likelihood for Planck, particularly
with $TE$ and $EE$ spectra, is complicated and difficult to check at the
sub-$\sigma$ level against numerical simulations because the simulations
cannot model the foregrounds, noise properties, and low-level
data processing of the real Planck data to sufficiently high accuracy. Within the Planck collaboration, we have tested the sensitivity of the results to the likelihood
methodology by developing several independent analysis pipelines.
Some of these are described in [Planck Collaboration
XI (2016)](#bib.bib273). The most highly
developed of them are the CamSpec and revised Plik pipelines. For
the 2015 Planck papers,
the Plik pipeline was chosen as the baseline. Column 6 of Table [1](#S3.T1 "Table 1 ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")
lists the cosmological parameters for base $\rm{\Lambda CDM}$ determined from the Plik cross-half-mission likelihood, together with the
lowP likelihood, applied to the 2015 full-mission data. The sky
coverage used in this likelihood is identical to that used
for the CamSpec 2015F(CHM) likelihood. However, the two likelihoods differ in
the modelling of instrumental noise, Galactic dust, treatment of relative
calibrations, and multipole limits applied to each spectrum.

As summarized in column 8 of Table [1](#S3.T1 "Table 1 ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"), the
Plik and CamSpec parameters agree to within $0.2\thinspace\sigma$, except
for $n\_{\rm s}$, which differs by nearly
$0.5\thinspace\sigma$. The difference in $n\_{\rm s}$ is perhaps not surprising, since this
parameter is sensitive to small differences in the foreground modelling.
Differences in $n\_{\rm s}$ between Plik and CamSpec are systematic and persist throughout the grid of
extended $\rm{\Lambda CDM}$ models discussed in Sect. [6](#S6 "6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters").
We emphasize that the CamSpec and Plik likelihoods have been written
independently, though they are based on the same theoretical framework.
None of the conclusions in this paper (including those based
on the full “TT,TE,EE” likelihoods) would differ in any substantive
way had we chosen to use the CamSpec likelihood in place of Plik.
The overall shifts of parameters between the Plik 2015 likelihood and the
published 2013 nominal mission parameters are summarized in column 7 of
Table [1](#S3.T1 "Table 1 ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). These shifts are within $0.7\thinspace\sigma$ except for
the parameters $\tau$ and $A\_{\rm s}e^{-2\tau}$, which are sensitive to the
low-multipole polarization likelihood and absolute calibration.

In summary, the Planck 2013 cosmological parameters were pulled
slightly towards lower $H\_{0}$ and $n\_{\rm s}$ by the $\ell\approx 1800$ 4-K
line systematic in the $217\times 217$ cross-spectrum, but the net
effect of this systematic is relatively small, leading to shifts of $0.5\thinspace\sigma$ or less
in cosmological parameters. Changes to the low-level data processing, beams,
sky coverage, etc., as well as the likelihood code also produce shifts of typically
$0.5\thinspace\sigma$ or less. The combined effect of these changes is to introduce
parameter shifts relative to [258](#bib.bib258) of less than $0.7\thinspace\sigma$,
with the exception of $\tau$ and $A\_{\rm s}e^{-2\tau}$.
The main scientific conclusions of [258](#bib.bib258) are therefore
consistent with the 2015 Planck analysis.

Parameters for the base $\rm{\Lambda CDM}$ cosmology derived from full-mission
DetSet, cross-year, or cross-half-mission spectra are in extremely
good agreement, demonstrating that residual (i.e., uncorrected)
cotemporal systematics are at low
levels. This is also true for the extensions of the $\rm{\Lambda CDM}$ model
discussed in Sect. [6](#S6 "6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). It is therefore worth explaining
why we have adopted the cross-half-mission likelihood as the baseline
for this and other 2015 Planck papers. The cross-half-mission
likelihood has lower signal-to-noise than the full-mission DetSet
likelihood; however, the errors on the cosmological parameters from the
two likelihoods are almost identical, as can be seen from the entries
in Table [1](#S3.T1 "Table 1 ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). This is also true for extended
$\rm{\Lambda CDM}$ models. However, for more complicated tests, such as searches
for localized features in the power spectra ([Planck Collaboration
XX 2016](#bib.bib279)), residual
4-K line systematic effects and residual uncorrected correlated noise at high
multipoles in the DetSet likelihood can produce
results suggestive of new physics (though not at a high significance level).
We have therefore decided to adopt the cross-half-mission
likelihood as the baseline for the 2015 analysis, sacrificing some
signal-to-noise in favour of reduced systematics. For almost all
of the models considered in this paper, the Planck results are
limited by small systematics of various types, including systematic errors
in modelling foregrounds, rather than by signal-to-noise.

The foreground-subtracted, frequency-averaged, cross-half-mission
spectrum is plotted in Fig. [1](#S3.F1 "Figure 1 ‣ (2) DetSets versus cross-surveys. ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"), together with the
Commander power spectrum at multipoles $\ell\leq 29$. The high
multipole spectrum plotted in this figure is an approximate maximum
likelihood solution based on equations (A24) and (A25) of [257](#bib.bib257), with the
foregrounds and nuisance parameters for each spectrum fixed to the
best-fit values of the base $\rm{\Lambda CDM}$ solution. Note that a different way of
solving for the Planck CMB spectrum, by marginalizing over foreground
and nuisance parameters, is presented in Sect. [4](#S4 "4 Comparison of the Planck power spectrum with high-resolution experiments ‣ Planck 2015 results. XIII. Cosmological parameters"). The
best-fit base $\rm{\Lambda CDM}$ model is plotted in the upper panel, while residuals with
respect to this model are plotted in the lower panel.
In this plot, there are only four bandpowers at $\ell\geq 30$ that differ from the best-fit
model by more than $2\thinspace\sigma$. These are: $\ell\thinspace{=}\thinspace 434$ ($-2.0\thinspace\sigma$);
$\ell\thinspace{=}\thinspace 465$ ($2.5\thinspace\sigma$); $\ell\thinspace{=}\thinspace 1214$ ($-2.5\thinspace\sigma$);
and $\ell\thinspace{=}\thinspace 1455$ ($-2.1\thinspace\sigma$). The $\chi^{2}$ of the coadded
$TT$ spectrum plotted in Fig. [1](#S3.F1 "Figure 1 ‣ (2) DetSets versus cross-surveys. ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") relative to the
best-fit base $\rm{\Lambda CDM}$ model is $2547$ for $2479$ degrees of freedom
($30\leq\ell\leq 2500$), which is a $0.96\thinspace\sigma$ fluctuation
(PTE$\thinspace{=}\thinspace 16.8\thinspace\%$).
These numbers confirm the extremely good fit of the base $\rm{\Lambda CDM}$ cosmology to
the Planck $TT$ data at high multipoles. The consistency of the
Planck polarization spectra with base $\rm{\Lambda CDM}$ is discussed
in Sect. [3.3](#S3.SS3 "3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters").

[258](#bib.bib258) noted some mild internal tensions within the Planck data,
for example, the preference of the phenomenological lensing parameter
$A\_{\rm L}$ (see Sect. [5.1](#S5.SS1 "5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) towards values greater than unity and
a preference for a negative running of the scalar spectral index (see
Sect. [6.2.2](#S6.SS2.SSS2 "6.2.2 Scale dependence of primordial fluctuations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")). These tensions were partly caused by the poor fit of
base $\rm{\Lambda CDM}$ model to the temperature spectrum at multipoles below about 50.
As noted by the WMAP team ([Hinshaw et al. 2003](#bib.bib169)), the temperature spectrum
has a low quadrupole amplitude and a glitch in the multipole range $20\la\ell\la 30$. These features can be seen in the Planck 2015 spectrum of Fig. [1](#S3.F1 "Figure 1 ‣ (2) DetSets versus cross-surveys. ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). They have a similar (though slightly reduced)
effect on cosmological parameters to those described in [258](#bib.bib258).

### 3.2 545-GHz-cleaned spectra

As discussed in [258](#bib.bib258), unresolved extragalactic foregrounds (principally Poisson point
sources and the clustered component of the CIB)
contribute to the Planck $TT$ spectra at high multipoles. The approach to
modelling these foreground contributions in [258](#bib.bib258)
is similar to that used by the ACT and SPT teams
([Reichardt et al. 2012](#bib.bib291); [Dunkley et al. 2013](#bib.bib105)) in that the foregrounds are modelled
by a set of physically motivated power spectrum
template shapes with an associated set of
adjustable nuisance parameters. This approach
has been adopted as the baseline for the Planck 2015 analysis. The foreground
model has been adjusted for this new analysis, in relatively minor ways,
as summarized in Sect. [2.3](#S2.SS3 "2.3 Changes to the foreground model ‣ 2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters") and described in further detail
in [Planck Collaboration
XII (2016)](#bib.bib274). Galactic dust
emission also contributes to the temperature and polarization power spectra and must be subtracted
from the spectra used to form the Planck likelihood.
Unlike the extragalactic foregrounds, Galactic dust emission is anisotropic
and so its impact can be reduced by appropriate masking of the
sky. In [258](#bib.bib258), we intentionally adopted conservative masks, tuned for
each of the frequencies used to form the likelihood, to keep dust emission
at low levels. The results in [258](#bib.bib258) were therefore insensitive to the
modelling of residual dust contamination.

Figure 2: Residual plots illustrating the accuracy of the foreground modelling.
The blue points in the upper panels show the CamSpec 2015(CHM) spectra
after subtraction of the best-fit $\rm{\Lambda CDM}$ spectrum. The residuals in the
upper panel should be accurately described by the foreground model. Major
foreground components are shown by the solid lines, colour coded as follows:
total foreground spectrum (red); Poisson point sources (orange);
clustered CIB (blue); thermal SZ (green); and Galactic dust
(purple). Minor foreground components are shown by the dotted lines,
colour-coded as follows: kinetic SZ (green); and tSZ$\times$CIB
cross-correlation (purple). The red points in the upper panels show
the 545-GHz-cleaned spectra (minus the best-fit CMB as subtracted from the uncleaned spectra)
that are fitted to a power-law residual foreground model, as discussed in the text.
The lower panels show the spectra after subtraction of the best-fit
foreground models. These agree to within a few $(\mu{\rm K})^{2}$.
The $\chi^{2}$ values of the residuals of the blue points, and the number of
bandpowers, are listed in the lower panels.

In the 2015 analysis, we have extended the sky coverage at each of 100,
143, and 217 GHz, and so in addition to testing the
accuracy of the extragalactic foreground model, it is important to test
the accuracy of the Galactic dust model. As described in
[257](#bib.bib257) and [Planck Collaboration
XII (2016)](#bib.bib274) the Galactic dust templates used in the
CamSpec and Plik likelihoods are derived by fitting
the 545-GHz mask-differenced power spectra. Mask differencing isolates the
anisotropic contribution of Galactic dust from the
isotropic extragalactic components. For the extended sky coverage used
in the 2015 likelihoods, the Galactic dust contributions
are a significant fraction of the extragalactic foreground contribution in
the $217\times 217$ temperature spectrum at high multipoles, as illustrated in
Fig. [2](#S3.F2 "Figure 2 ‣ 3.2 545-GHz-cleaned spectra ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). Galactic dust dominates over all other foregrounds
at multipoles $\ell\la 500$ at HFI frequencies.

A simple and direct test of the parametric foreground modelling used in the
CamSpec and Plik likelihoods is to compare results with a completely
different approach in which the low-frequency maps are “cleaned” using
higher frequency maps as foreground templates ([Lueker et al. 2010](#bib.bib215), see, e.g.,).
In a similar approach to [Spergel et al. (2015)](#bib.bib325),
we can form cleaned maps at lower frequencies $\nu$ by subtracting
a 545-GHz map as a template,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $M^{T\_{\nu}{\rm clean}}=(1+\alpha^{T\_{\nu}})M^{T\_{\nu}}-\alpha^{T\_{\nu}}M^{T\_{\nu\_{\rm t}}},$ |  | (6) |

where $\nu\_{\rm t}$ is the frequency of the template map
$M^{T\_{\nu\_{\rm t}}}$ and $\alpha^{T\_{\nu}}$ is the cleaning
coefficient. Since the maps have different beams, the
subtraction is actually done in the power spectrum domain:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\hat{C}^{T\_{\nu\_{1}}T\_{\nu\_{2}}{\rm clean}}$ | $\displaystyle=$ | $\displaystyle(1+\alpha^{T\_{\nu\_{1}}})(1+\alpha^{T\_{\nu\_{2}}})\hat{C}^{T\_{\nu\_{1}}T\_{\nu\_{2}}}$ |  | (7) |
|  |  |  | $\displaystyle-(1+\alpha^{T\_{\nu\_{1}}})\alpha^{T\_{\nu\_{2}}}\hat{C}^{T\_{\nu\_{2}}T\_{\nu\_{\rm t}}}$ |  |
|  |  |  | $\displaystyle-(1+\alpha^{T\_{\nu\_{2}}})\alpha^{T\_{\nu\_{1}}}\hat{C}^{T\_{\nu\_{1}}T\_{\nu\_{\rm t}}}+\alpha^{T\_{\nu\_{1}}}\alpha^{T\_{\nu\_{2}}}\hat{C}^{T\_{\nu\_{\rm t}}T\_{\nu\_{\rm t}}},$ |  |

where $\hat{C}^{T\_{\nu\_{1}}T\_{\nu\_{2}}}$ etc. are the mask-deconvolved
beam-corrected power spectra. The coefficients $\alpha^{T\_{\nu\_{i}}}$
are determined by minimizing

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sum\_{\ell=\ell\_{\rm min}}^{\ell\_{\rm max}}\sum\_{\ell^{\prime}=\ell\_{\rm min}}^{\ell\_{\rm max}}\hat{C}^{T\_{\nu\_{i}}T\_{\nu\_{i}}{\rm clean}}\_{\ell}\left(\hat{\mathsf{M}}^{T\_{\nu\_{i}}T\_{\nu\_{i}}}\_{\ell\ell^{\prime}}\right)^{-1}\hat{C}^{T\_{\nu\_{i}}T\_{\nu\_{i}}{\rm clean}}\_{\ell^{\prime}},$ |  | (8) |

where $\hat{\mathsf{M}}^{T\_{\nu\_{i}}T\_{\nu\_{i}}}$ is the covariance
matrix of the estimates $\hat{C}^{T\_{\nu\_{i}}T\_{\nu\_{i}}}$.
We choose $\ell\_{\rm min}\thinspace{=}\thinspace 100$ and $\ell\_{\rm max}\thinspace{=}\thinspace 500$ and
compute the spectra in Eq. ([7](#S3.E7 "In 3.2 545-GHz-cleaned spectra ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")) by cross-correlating half-mission maps
on the 60 % mask used to compute the $217\times 217$ spectrum.
The resulting cleaning coefficients are $\alpha^{T}\_{143}=0.00194$
and $\alpha^{T}\_{217}=0.00765$; note that all of the
input maps are in units of thermodynamic temperature. The cleaning coefficients
are therefore optimized to remove Galactic dust at low multipoles,
though by using 545 GHz as a dust template we find that the
cleaning coefficients are almost constant over the multipole range 50–2500.
We note, however, that this is not true if the 353- and 857-GHz maps are used
as dust templates, as discussed in Efstathiou et al. (in preparation).

The 545-GHz-cleaned spectra are shown by the red points in
Fig. [2](#S3.F2 "Figure 2 ‣ 3.2 545-GHz-cleaned spectra ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") and can be compared directly to the “uncleaned”
spectra used in the CamSpec likelihood (upper panels). As can be
seen, Galactic dust emission is removed to high accuracy and the
residual foreground contribution at high multipoles is strongly
suppressed in the $217\times 217$ and $143\times 217$
spectra. Nevertheless, there remains small foreground contributions
at high multipoles, which we model heuristically as power laws,

|  |  |  |  |
| --- | --- | --- | --- |
|  | ${\cal\hat{D}}\_{\ell}=A\left(\ell\over 1500\right)^{\epsilon},$ |  | (9) |

with free amplitudes $A$ and spectral indices $\epsilon$. We
construct another CamSpec cross-half-mission likelihood using
exactly the same sky masks as the 2015F(CHM) likelihood, but using
545-GHz-cleaned $217\times 217$, $143\times 217$, and $143\times 143$ spectra.
We then use the simple model of Eq. ([9](#S3.E9 "In 3.2 545-GHz-cleaned spectra ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")) in the likelihood to remove
residual unresolved foregrounds at high multipoles for each frequency combination. We do not
clean the $100\times 100$ spectrum and so for this spectrum we use the standard
parametric foreground model in the likelihood. The
lower panels in Fig. [2](#S3.F2 "Figure 2 ‣ 3.2 545-GHz-cleaned spectra ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") show the residuals with respect to
the best-fit base $\rm{\Lambda CDM}$ model and foreground solution for the
uncleaned CamSpec spectra (blue points) and for the 545-GHz-cleaned
spectra (red points). These residuals are almost identical, despite
the very different approaches to Galactic dust removal and foreground
modelling. The cosmological parameters from these two likelihoods are
also in very good agreement, typically to better than $0.1\thinspace\sigma$,
with the exception of $n\_{\rm s}$, which is lower in the cleaned likelihood
by $0.26\thinspace\sigma$. It is not surprising, given the heuristic nature of
the model (Eq. [9](#S3.E9 "In 3.2 545-GHz-cleaned spectra ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")), that $n\_{\rm s}$ shows the largest shift. We can also
remove the $100\times 100$ spectrum from the likelihood entirely, with
very little impact on cosmological parameters.

Further tests of map-based cleaning are presented in
[Planck Collaboration
XI (2016)](#bib.bib273), which additionally describes another independently
written power-spectrum analysis pipeline (MSPEC) tuned to map-cleaned
cross-spectrum analysis and using a more complex model for fitting
residual foregrounds than the heuristic model of Eq. ([9](#S3.E9 "In 3.2 545-GHz-cleaned spectra ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")).
[Planck Collaboration
XI (2016)](#bib.bib273) also describes power spectrum analysis and cosmological
parameters derived from component-separated Planck maps. However,
the simple demonstration presented in this section shows that the
details of modelling residual dust contamination and other foregrounds
are under control in the 2015 Planck likelihood. A further strong
argument that our $TT$ results are insensitive to foreground modelling
is presented in the next section, which compares the cosmological
parameters derived from the $TT$, $TE$, and $EE$ likelihoods. Unresolved
foregrounds at high multipoles are completely negligible in the
polarization spectra and so the consistency of the parameters,
particularly from the $TE$ spectrum (which has higher signal-to-noise
than the $EE$ spectrum) provides an additional cross-check of the $TT$ results.

Finally, one can ask why we have not chosen to use a 545-GHz-cleaned
likelihood as the baseline for the 2015 Planck parameter
analysis. Firstly, it would not make any difference to the results of
this paper had we chosen to do so. Secondly, we feel that the
parametric foreground model used in the baseline likelihood has a
sounder physical basis. This allows us to link the amplitudes of
the unresolved foregrounds across the various Planck frequencies
with the results from other ways of studying foregrounds, including the
higher resolution CMB experiments described in Sect. [4](#S4 "4 Comparison of the Planck power spectrum with high-resolution experiments ‣ Planck 2015 results. XIII. Cosmological parameters").

### 3.3 The 2015 Planck temperature and polarization spectra and likelihood

Table 2: Goodness-of-fit tests for the 2015 Planck temperature and
polarization spectra. $\Delta\chi^{2}=\chi^{2}-N\_{\rm dof}$ is the difference
from the mean assuming that the best-fit base $\rm{\Lambda CDM}$ model (fitted to Planck TT+lowP) is correct
and $N\_{\rm dof}$
is the number of degrees of freedom (set equal to the number of multipoles).
The sixth column expresses $\Delta\chi^{2}$ in units of
the expected dispersion, $\sqrt{2N\_{\rm dof}}$, and the last column lists the
probability to exceed (PTE) the tabulated value of $\chi^{2}$.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | --- | | Likelihood | Frequency | Multipole range | $\chi^{2}$ | $\chi^{2}/N\_{\rm dof}$ | $N\_{\rm dof}$ | $\Delta\chi^{2}/\sqrt{2N\_{\rm dof}}$ | PTE [%] | | $TT$ | 100$\times$100 | 30–1197 | 1234.37 | 1.06 | 1168 | $\kern 7.7778pt1.37$ | 8.66 | |  | 143$\times$143 | 30–1996 | 2034.45 | 1.03 | 1967 | $\kern 7.7778pt1.08$ | 14.14 | |  | 143$\times$217 | 30–2508 | 2566.74 | 1.04 | 2479 | $\kern 7.7778pt1.25$ | 10.73 | |  | 217$\times$217 | 30–2508 | 2549.66 | 1.03 | 2479 | $\kern 7.7778pt1.00$ | 15.78 | |  | Combined | 30–2508 | 2546.67 | 1.03 | 2479 | $\kern 7.7778pt0.96$ | 16.81 | | $TE$ | 100$\times$100 | 30– 999 | 1088.78 | 1.12 | 970 | $\kern 7.7778pt2.70$ | 0.45 | |  | 100$\times$143 | 30– 999 | 1032.84 | 1.06 | 970 | $\kern 7.7778pt1.43$ | 7.90 | |  | 100$\times$217 | 505– 999 | 526.56 | 1.06 | 495 | $\kern 7.7778pt1.00$ | 15.78 | |  | 143$\times$143 | 30–1996 | 2028.43 | 1.03 | 1967 | $\kern 7.7778pt0.98$ | 16.35 | |  | 143$\times$217 | 505–1996 | 1606.25 | 1.08 | 1492 | $\kern 7.7778pt2.09$ | 2.01 | |  | 217$\times$217 | 505–1996 | 1431.52 | 0.96 | 1492 | $-1.11$ | 86.66 | |  | Combined | 30–1996 | 2046.11 | 1.04 | 1967 | $\kern 7.7778pt1.26$ | 10.47 | | $EE$ | 100$\times$100 | 30– 999 | 1027.89 | 1.06 | 970 | $\kern 7.7778pt1.31$ | 9.61 | |  | 100$\times$143 | 30– 999 | 1048.22 | 1.08 | 970 | $\kern 7.7778pt1.78$ | 4.05 | |  | 100$\times$217 | 505– 999 | 479.72 | 0.97 | 495 | $-0.49$ | 68.06 | |  | 143$\times$143 | 30–1996 | 2000.90 | 1.02 | 1967 | $\kern 7.7778pt0.54$ | 29.18 | |  | 143$\times$217 | 505–1996 | 1431.16 | 0.96 | 1492 | $-1.11$ | 86.80 | |  | 217$\times$217 | 505–1996 | 1409.58 | 0.94 | 1492 | $-1.51$ | 93.64 | |  | Combined | 30–1996 | 1986.95 | 1.01 | 1967 | $\kern 7.7778pt0.32$ | 37.16 | |  |

The coadded 2015 Planck temperature spectrum was introduced in
Fig. [1](#S3.F1 "Figure 1 ‣ (2) DetSets versus cross-surveys. ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). In this section, we present additional details
and consistency checks of the temperature likelihood and describe the
full mission Planck $TE$ and $EE$ spectra and likelihood; preliminary
Planck $TE$ and $EE$ spectra were presented in [258](#bib.bib258). We then discuss
the consistency of the cosmological parameters for base
$\rm{\Lambda CDM}$ measured separately from the $TT$, $TE$, and $EE$ spectra. For the
most part, the discussion given in this section is specific to the
Plik likelihood, which is used as the baseline in this paper. A more
complete discussion of the Plik and other likelihoods developed by the
Planck team is given in [Planck Collaboration
XI (2016)](#bib.bib273).

#### 3.3.1 Temperature spectra and likelihood

##### (1) Temperature masks.

As in the 2013 analysis, the high-multipole $TT$ likelihood uses the
$100\times 100$ , $143\times 143$, $217\times 217$, and $143\times 217$ spectra.
However, in contrast to the 2013 analysis, which used conservative sky masks to
reduce the effects of Galactic dust emission, we make more aggressive use of
sky in the 2015 analysis.
The 2015 analysis retains 80 %, 70 %, and 60 % of sky at 100 GHz,
143 GHz, and 217 GHz, respectively, before apodization. We also apply
apodized point source masks to remove compact sources with a
signal-to-noise threshold $>5$ at each frequency (see [Planck Collaboration
XXVI 2016](#bib.bib281)
for a description of the Planck Catalogue of Compact Sources). Apodized masks
are also applied to remove extended objects, and regions of high CO emission
were masked at 100 GHz and 217 GHz ([Planck Collaboration
X 2016](#bib.bib272), see).
As an
estimate of the effective sky area, we compute the following sum over pixels:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f^{\rm eff}\_{\rm sky}={1\over 4\pi}\sum w\_{i}^{2}\Omega\_{i},$ |  | (10) |

where $w\_{i}$ is the weight of the apodized mask and $\Omega\_{i}$ is the area
of pixel $i$. All input maps
are at HEALpix ([Górski et al. 2005](#bib.bib149)) resolution $N\_{\rm side}=2048$.
Eq. ([10](#S3.E10 "In (1) Temperature masks. ‣ 3.3.1 Temperature spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")) gives $f^{\rm eff}\_{\rm sky}=66.3\thinspace\%$ at 100 GHz,
57.4 % at 143 GHz, and 47.1 % at 217 GHz.

##### (2) Galactic dust templates.

With the increased sky coverage used in the 2015 analysis, we take a
slightly different approach to subtracting Galactic dust emission to
that described in [257](#bib.bib257) and [258](#bib.bib258). The shape of the Galactic dust
template is determined from mask-differenced power spectra estimated
from the 545-GHz maps. The mask differencing removes the isotropic
contribution from the CIB and point sources. The resulting dust template has
a similar shape to the template used in the 2013 analysis, with
power-law behaviour $\mathcal{D}^{\rm dust}\_{\ell}\propto\ell^{-0.63}$
at high multipoles, but with a “bump” at $\ell\approx 200$ (as shown in
Fig. [2](#S3.F2 "Figure 2 ‣ 3.2 545-GHz-cleaned spectra ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")). The absolute amplitude of the dust templates at
100, 143, and 217 GHz is determined by cross-correlating the
temperature maps at these frequencies with the 545-GHz maps (with
minor corrections for the CIB and point source contributions). This
allows us to generate priors on the dust template amplitudes, which
are treated as additional nuisance parameters when running MCMC chains
(unlike the 2013 analysis, in which we fixed the amplitudes of the
dust templates). The actual priors used in the Plik likelihood are
Gaussians on $\mathcal{D}^{\rm dust}\_{\ell=200}$ with the following means
and dispersions: $(7\pm 2)\thinspace\thinspace\mu$K2
for the $100\times 100$ spectrum; $(9\pm 2)\thinspace\thinspace\mu$K2 for $143\times 143$;
$(21\pm 8.5)\thinspace\thinspace\mu$K2 for $143\times 217$; and $(80\pm 20)\thinspace\thinspace\mu$K2 for
$217\times 217$. The MCMC solutions show small movements of the
best-fit dust template amplitudes, but always within statistically acceptable
ranges given the priors.

##### (3) Likelihood approximation and covariance matrices.

The approximation to the likelihood function follows the methodology
described in [257](#bib.bib257) and is based on a Gaussian likelihood assuming a
fiducial theoretical power spectrum (a fit to Plik TT with prior
$\tau=0.07\pm 0.02$). We have also included a number of small refinements to
the covariance matrices. Foregrounds, including Galactic dust, are added to
the fiducial theoretical power spectrum, so that the additional small
variance associated with foregrounds is included, along with cosmic
variance of the CMB, under the assumption that the
foregrounds are Gaussian random fields. The 2013 analysis did not
include corrections to the covariance matrices arising from leakage of
low-multipole power to high multipoles via the point source
holes; these can introduce errors in the covariance matrices of a few percent
at $\ell\approx 300$, corresponding approximately to the first peak of the CMB
spectrum. In the 2015 analysis we apply corrections to the fiducial
theoretical power spectrum, based on Monte Carlo simulations, to
correct for this effect. We also apply Monte Carlo based corrections
to the analytic covariance matrices at multipoles $\ell\leq 50$, where the
analytic approximations begin to become inaccurate even for large
effective sky areas ([Efstathiou 2004](#bib.bib107), see). Finally, we add
the uncertainties on the beam shapes to the covariance matrix
following the methodology described in [257](#bib.bib257). The Planck beams are
much more accurately characterized in the 2015 analysis, and so the
beam corrections to the covariance matrices are extremely small. The
refinements to the covariance matrices described in this paragraph are
all relatively minor and have little impact on
cosmological parameters.

##### (4) Binning.

The baseline Plik likelihood uses binned temperature and polarization spectra.
This is done because all frequency combinations of the $TE$ and $EE$ spectra
are used in the Plik likelihood, leading to a large data vector of length
$22\thinspace 865$ if the spectra are retained multipole-by-multipole. The baseline
Plik likelihood reduces the size of the data vector by binning these spectra.
The spectra are binned into bins of width $\Delta\ell=5$ for
$30\leq\ell\leq 99$, $\Delta\ell=9$ for $100\leq\ell\leq 1503$,
$\Delta\ell=17$ for $1504\leq\ell\leq 2013$ and $\Delta\ell=33$ for
$2014\leq\ell\leq 2508$, with a weighting of $C\_{\ell}$ proportional to
$\ell(\ell+1)$ over the bin widths. The bins span an odd number of multipoles,
since for approximately azimuthal masks we expect a nearly
symmetrical correlation function
around the central multipole. The binning does not affect
the determination of cosmological parameters in $\rm{\Lambda CDM}$-type models (which have
smooth power spectra), but significantly reduces the size of the
joint TT,TE,EE covariance matrix, speeding up the computation of the
likelihood. However, for
some specific purposes, e.g., searching for oscillatory features in the
$TT$ spectrum, or testing $\chi^{2}$ statistics, we produce blocks of the
likelihood multipole-by-multipole.

##### (5) Goodness of fit.

The first five rows of Table [2](#S3.T2 "Table 2 ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") list $\chi^{2}$ statistics for the $TT$ spectra (multipole-by-multipole)
relative to the Planck best-fit base $\rm{\Lambda CDM}$ model and foreground
parameters (fitted to Planck TT+lowP). The first four entries list the statistics
separately for each of the four spectra that form the $TT$ likelihood and the
fifth line (labelled “Combined”) gives the $\chi^{2}$ value for the maximum
likelihood $TT$ spectrum plotted in Fig. [1](#S3.F1 "Figure 1 ‣ (2) DetSets versus cross-surveys. ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). Each of the
individual spectra provides an acceptable fit to the base
$\rm{\Lambda CDM}$ model, as does the frequency-averaged spectrum plotted in
Fig. [1](#S3.F1 "Figure 1 ‣ (2) DetSets versus cross-surveys. ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). This demonstrates the excellent consistency of the
base $\rm{\Lambda CDM}$ model across frequencies. More detailed consistency checks of
the Planck spectra are presented in [Planck Collaboration
XI (2016)](#bib.bib273); however, as
indicated by Table [2](#S3.T2 "Table 2 ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"), we find no evidence
for any inconsistencies between the foreground-corrected temperature power
spectra computed for different frequency combinations.
The temperature spectra are largely signal dominated over the multipole
ranges listed in Table [2](#S3.T2 "Table 2 ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") and so the $\chi^{2}$ values are
insensitive to small errors in the
Planck noise model used in the covariance matrices. As discussed in the
next subsection, this is not true for the $TE$ and
$EE$ spectra, which are noise dominated over much of the multipole range.

Figure 3: Frequency-averaged $TE$ and $EE$ spectra (without fitting for
temperature-to-polarization leakage). The theoretical $TE$ and $EE$ spectra
plotted in the upper panel of each plot are computed from the Planck TT+lowP best-fit model
of Fig. [1](#S3.F1 "Figure 1 ‣ (2) DetSets versus cross-surveys. ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). Residuals with respect to this theoretical
model are shown in the lower panel in each plot. The error bars
show $\pm 1\thinspace\sigma$ errors. The green lines in the lower panels show the
best-fit temperature-to-polarization leakage model of Eqs. ([0a](#S3.E1 "In (2) Polarization spectra and residual systematics. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")) and
([0b](#S3.E2 "In (2) Polarization spectra and residual systematics. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")), fitted separately to the $TE$ and $EE$ spectra.

Figure 4: Conditionals for the Plik $TE$ and $EE$ spectra, given the $TT$ data
computed from the Plik likelihood. The black lines show the expected
$TE$ and $EE$ spectra given the $TT$ data. The shaded areas show the
$\pm 1$ and $\pm 2\thinspace\sigma$ ranges computed from Eq. ([5](#S3.E5 "In (3) 𝑇⁢𝐸 and 𝐸⁢𝐸 conditionals. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")).
The blue points show the residuals for the measured $TE$ and $EE$ spectra.

Figure 5: Conditionals for the CamSpec $TE$ and $EE$ spectra, given the $TT$ data
computed from the CamSpec likelihood. As in Fig. [4](#S3.F4 "Figure 4 ‣ (5) Goodness of fit. ‣ 3.3.1 Temperature spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"),
the shaded areas show $\pm 1$ and $\pm 2\thinspace\sigma$ ranges, computed
from Eq. ([5](#S3.E5 "In (3) 𝑇⁢𝐸 and 𝐸⁢𝐸 conditionals. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")) and blue points show the residuals for the measured
$TE$ and $EE$ spectra.

#### 3.3.2 Polarization spectra and likelihood

In addition to the $TT$ spectra, the 2015 Planck likelihood includes
the $TE$ and $EE$ spectra. As discussed in Sect. [3.1](#S3.SS1 "3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"),
the Planck 2015 low-multipole polarization analysis is based on the
LFI 70-GHz data. Here we discuss the $TE$ and $EE$ spectra
that are used in the high-multipole likelihood, which are computed from
the HFI data at $100$, $143$ and $217$ GHz.
As summarized in [Planck Collaboration
XI (2016)](#bib.bib273), there is
no evidence for any unresolved foreground components at high multipoles in
the polarization spectra. We therefore include all frequency combinations in
computing the $TE$ and $EE$ spectra to maximize the signal-to-noise.1111
11
In
temperature, the $100\times 143$ and $100\times 217$
spectra are not included in the likelihood because the temperature spectra
are largely signal dominated. These spectra therefore add little new information
on the CMB, but would require additional nuisance parameters to correct for
unresolved foregrounds at high multipoles.

##### (1) Masks and dust corrections.

At low multipoles ($\ell\la 300$) polarized Galactic dust emission is
significant at all frequencies and is subtracted in a similar way to the dust
subtraction in temperature, i.e., by including additional nuisance parameters
quantifying the amplitudes of a power-law dust template
with a slope constrained to
$\mathcal{D}^{\rm dust}\_{\ell}\propto\ell^{-0.40}$ for both $TE$ and $EE$
([Planck Collaboration Int.
XXX 2016](#bib.bib284)). Polarized synchrotron emission (which has been shown
to be negligible at 100 GHz and higher frequencies for Planck noise levels,
[Fuskeland et al. 2014](#bib.bib130)) is ignored. Gaussian priors on the polarization
dust amplitudes are determined by cross-correlating the lower frequency
maps with the 353-GHz polarization maps (the highest frequency polarized
channel of the HFI) in a similar way to
the determination of temperature dust priors.
We use the temperature-based apodized masks in $Q$ and $U$ at each frequency,
retaining 70 %, 50 %, and 41 %
of the sky at 100, 143, and 217 GHz, respectively, after apodization (slightly smaller
than the temperature masks at 143 and 217 GHz).
However, we do not apply point source or CO masks to the $Q$ and $U$ maps.
The construction of the full TT,TE,EE likelihood is then a
straightforward extension of the $TT$ likelihood
using the analytic covariance matrices given by [Efstathiou (2006)](#bib.bib108)
and [Hamimeche & Lewis (2008)](#bib.bib157).

##### (2) Polarization spectra and residual systematics.

Maximum likelihood frequency coadded $TE$ and $EE$ spectra are shown in
Fig. [3](#S3.F3 "Figure 3 ‣ (5) Goodness of fit. ‣ 3.3.1 Temperature spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). The theoretical curves plotted in these figures are
the $TE$ and $EE$ spectra computed from the best-fit base $\rm{\Lambda CDM}$ model fitted
to the temperature spectra (Planck TT+lowP), as plotted in
Fig. [1](#S3.F1 "Figure 1 ‣ (2) DetSets versus cross-surveys. ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). The lower panels in each figure show the residuals
with respect to this model. The theoretical model provides a very good fit
to the $TE$ and $EE$ spectra.
Table [2](#S3.T2 "Table 2 ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") lists $\chi^{2}$ statistics for the $TE$ and $EE$
spectra for each frequency combination (with the $TE$ and $ET$ spectra
for each frequency combination coadded to form a single $TE$ spectrum).
Note that since the $TE$ and
$EE$ spectra are noisier than the $TT$ spectra, these values of $\chi^{2}$ are
sensitive to the procedure used to estimate Planck noise
(see [Planck Collaboration
XI 2016](#bib.bib273) for further details).

Some of these $\chi^{2}$ values are unusually high, for example the $100\times 100$ and $143\times 217$ $TE$ spectra and the $100\times 143$ $EE$
spectrum all have low PTEs. The Planck $TE$ and $EE$ spectra for
different frequency combinations are not as internally consistent as
the Planck $TT$ spectra. Inter-comparison of the $TE$ and $EE$ spectra at
different frequencies is much more straightforward than for the
temperature spectra because unresolved foregrounds are unimportant in
polarization. The high $\chi^{2}$ values listed in Table [2](#S3.T2 "Table 2 ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")
therefore provide clear evidence of residual instrumental systematics
in the $TE$ and $EE$ spectra.

With our present understanding of the Planck polarization data, we believe
that the dominant source of systematic error in the polarization spectra is
caused by beam mismatch that generates leakage from temperature to
polarization (recalling that the HFI polarization maps are generated by
differencing signals between quadruplets of polarization sensitive
bolometers). In principle, with accurate knowledge of the beams this
leakage could be described by effective polarized beam window
functions. For the 2015 papers, we use the $TT$ beams rather than
polarized beams, and characterize temperature-to-polarization leakage using
a simplified model. The impact of beam mismatch on
the polarization spectra in this model is

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta C\_{\ell}^{TE}$ | $\displaystyle=$ | $\displaystyle\epsilon\_{\ell}C\_{\ell}^{TT},$ |  | (0a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta C\_{\ell}^{EE}$ | $\displaystyle=$ | $\displaystyle\epsilon\_{\ell}^{2}C\_{\ell}^{TT}+2\epsilon\_{\ell}C\_{\ell}^{TE},$ |  | (0b) |

where $\epsilon\_{\ell}$ is a polynomial in multipole.
As a consequence of the Planck scanning strategy, pixels are visited
approximately every
six months, with a rotation of the focal plane by $180^{\circ}$, leading to a
weak coupling to beam modes $b\_{\ell m}$ with odd values of $m$.
The dominant contributions are expected to come from modes with $m=2$ and
$4$, describing the beam ellipticity. We therefore fit the spectra using a
fourth-order polynomial,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\epsilon\_{\ell}=a\_{0}+a\_{2}\ell^{2}+a\_{4}\ell^{4},$ |  | (1) |

treating the coefficients $a\_{0}$, $a\_{2}$, and $a\_{4}$ as nuisance parameters
in the MCMC analysis. We have ignored the odd coefficients of the polynomial,
which should be suppressed by our scanning strategy.
We do however include a constant term in the polynomial to account for small
deviations of the polarization efficiency from unity.

The fit is performed separately on the $TE$ and $EE$ spectra. A different
polynomial is used for each cross-frequency spectrum. The coadded
corrections are shown in the lower panels of Fig. [3](#S3.F3 "Figure 3 ‣ (5) Goodness of fit. ‣ 3.3.1 Temperature spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters").
Empirically, we find that temperature-to-polarization leakage
systematics tend to cancel in the coadded spectra. Although the best-fit
leakage corrections to the coadded spectra are small, the corrections
for individual frequency cross-spectra can be up to 3 times
larger than those shown in Fig. [3](#S3.F3 "Figure 3 ‣ (5) Goodness of fit. ‣ 3.3.1 Temperature spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters").
The model of Eqs. ([0a](#S3.E1 "In (2) Polarization spectra and residual systematics. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")) and ([0b](#S3.E2 "In (2) Polarization spectra and residual systematics. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")) is clearly crude, but gives
us some idea of the impact of temperature-to-polarization leakage in the
coadded spectra.
With our present empirical understanding of leakage, we find a correlation
between the polarization spectra that have the highest expected
temperature-to-polarization leakage and those that display high $\chi^{2}$ in
Table [2](#S3.T2 "Table 2 ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). However, the characterization of this
leakage is not yet accurate enough to reduce the $\chi^{2}$
values for each frequency combination to acceptable levels.

As discussed in [258](#bib.bib258), each Planck data release and accompanying
set of papers should be viewed as a snapshot of the state of the Planck analysis at the time of the release. For the 2015 release, we have a high
level of confidence in the temperature power spectra. However, we have
definite evidence for low-level systematics associated with
temperature-to-polarization
leakage in the polarization spectra. The tests described
above suggest that these are at low levels of a few $(\mu{\rm K})^{2}$ in
$D\_{\ell}$. However, temperature-to-polarization leakage can introduce
correlated features in the spectra, as shown by the $EE$ leakage model
plotted in Fig. [3](#S3.F3 "Figure 3 ‣ (5) Goodness of fit. ‣ 3.3.1 Temperature spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). Until we have a more accurate
characterization of these systematics, we urge caution in the
interpretation of features in the $TE$ and $EE$ spectra. For some of the 2015
papers, we use the $TE$ and $EE$ spectra,
without leakage corrections. For most of the models considered in this paper,
the $TT$ spectra alone provide tight constraints and so we take a conservative
approach and usually quote the $TT$ results. However, as we will see, we find
a high level of consistency between the Planck $TT$ and full Planck $TT,TE,EE$ likelihoods.
Some models considered in Sect. [6](#S6 "6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") are, however, sensitive
to the polarization blocks of the likelihood. Examples include constraints
on isocurvature modes, dark matter annihilation, and non-standard recombination
histories. Planck 2015 constraints on these models should be viewed as
preliminary, pending a more complete analysis of polarization systematics,
which will be presented in the next series of Planck papers accompanying
a third data release.

Table 3: Parameters of the base $\rm{\Lambda CDM}$ cosmology computed from the 2015 baseline Planck likelihoods, illustrating the consistency of parameters determined from the
temperature and polarization spectra at high multipoles.
Column [1] uses the $TT$ spectra at low and high multipoles and is the
same as column [6] of Table [1](#S3.T1 "Table 1 ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters").
Columns [2] and [3]
use only the $TE$ and $EE$ spectra at high multipoles, and only polarization
at low multipoles. Column [4] uses the full likelihood. The last
column lists the deviations of the cosmological parameters determined from
the Planck TT+lowP and Planck TT,TE,EE+lowP likelihoods.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | | Parameter | [1] Planck TT+lowP | [2] Planck TE+lowP | [3] Planck EE+lowP | [4] Planck TT,TE,EE+lowP | $([1]-[4])/\sigma\_{[1]}$ | | $\Omega\_{\mathrm{b}}h^{2}$. | $0.02222\pm 0.00023$ | $0.02228\pm 0.00025$ | $0.0240\pm 0.0013$ | $0.02225\pm 0.00016$ | $-0.1$ | | $\Omega\_{\mathrm{c}}h^{2}$. | $0.1197\pm 0.0022$ | $0.1187\pm 0.0021$ | $0.1150^{+0.0048}\_{-0.0055}$ | $0.1198\pm 0.0015$ | $\kern 7.7778pt0.0$ | | $100\theta\_{\mathrm{MC}}$. | $1.04085\pm 0.00047$ | $1.04094\pm 0.00051$ | $1.03988\pm 0.00094$ | $1.04077\pm 0.00032$ | $\kern 7.7778pt0.2$ | | $\tau$. | $0.078\pm 0.019$ | $0.053\pm 0.019$ | $0.059^{+0.022}\_{-0.019}$ | $0.079\pm 0.017$ | $-0.1$ | | $\ln(10^{10}A\_{\mathrm{s}})$. | $3.089\pm 0.036$ | $3.031\pm 0.041$ | $3.066^{+0.046}\_{-0.041}$ | $3.094\pm 0.034$ | $-0.1$ | | $n\_{\mathrm{s}}$. | $0.9655\pm 0.0062$ | $0.965\pm 0.012$ | $0.973\pm 0.016$ | $0.9645\pm 0.0049$ | $\kern 7.7778pt0.2$ | | $H\_{0}$. | $67.31\pm 0.96\kern 5.00002pt$ | $67.73\pm 0.92\kern 5.00002pt$ | $70.2\pm 3.0\kern 5.00002pt$ | $67.27\pm 0.66\kern 5.00002pt$ | $\kern 7.7778pt0.0$ | | $\Omega\_{\mathrm{m}}$. | $0.315\pm 0.013$ | $0.300\pm 0.012$ | $0.286^{+0.027}\_{-0.038}$ | $0.3156\pm 0.0091$ | $\kern 7.7778pt0.0$ | | $\sigma\_{8}$. | $0.829\pm 0.014$ | $0.802\pm 0.018$ | $0.796\pm 0.024$ | $0.831\pm 0.013$ | $\kern 7.7778pt0.0$ | | $10^{9}A\_{\mathrm{s}}e^{-2\tau}$. | $1.880\pm 0.014$ | $1.865\pm 0.019$ | $1.907\pm 0.027$ | $1.882\pm 0.012$ | $-0.1$ | |  |

##### (3) $TE$ and $EE$ conditionals.

Given the best-fit base $\rm{\Lambda CDM}$ cosmology and foreground parameters determined
from the temperature spectra, one can test whether the $TE$ and $EE$ spectra
are consistent with the $TT$ spectra by computing conditional
probabilities. Writing the data vector as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{\hat{C}}=(\mathbf{\hat{C}}^{TT},\mathbf{\hat{C}}^{TE},\mathbf{\hat{C}}^{EE})^{\sf T}=(\mathbf{\hat{X}}\_{T},\mathbf{\hat{X}}\_{P})^{\sf T},$ |  | (2) |

where the quantities $\mathbf{\hat{C}}^{TT}$, $\mathbf{\hat{C}}^{TE}$, and
$\mathbf{\hat{C}}^{EE}$ are the maximum likelihood freqency co-added foreground-corrected spectra.
The covariance matrix of this vector can be partitioned as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathsf{\hat{M}}=\left(\begin{array}[]{c|c}\mathsf{M}\_{T}&\mathsf{M}\_{TP}\\ \hline\cr\mathsf{M}\_{TP}^{\sf T}&\mathsf{M}\_{P}\end{array}\right).$ |  | (3) |

The expected value of the polarization vector, given the observed temperature
vector $\mathbf{\hat{X}}\_{T}$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{\hat{X}}^{\rm cond}\_{P}=\mathbf{\hat{X}}^{\rm theory}\_{P}+\mathbf{M}^{\sf T}\_{TP}\mathbf{M}^{-1}\_{T}(\mathbf{\hat{X}}\_{T}-\mathbf{\hat{X}}^{\rm theory}\_{T}),$ |  | (4) |

with covariance

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathsf{\hat{\Sigma}}\_{P}=\mathsf{M}\_{P}-\mathsf{M}^{\sf T}\_{TP}\mathsf{M}^{-1}\_{T}\mathsf{M}\_{TP}.$ |  | (5) |

In Eq. ([4](#S3.E4 "In (3) 𝑇⁢𝐸 and 𝐸⁢𝐸 conditionals. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")), $\mathbf{X}^{\rm theory}\_{T}$ and $\mathbf{X}^{\rm theory}\_{P}$
are the theoretical temperature and polarization spectra
deduced from minimizing the Planck TT+lowP likelihood. Equations ([4](#S3.E4 "In (3) 𝑇⁢𝐸 and 𝐸⁢𝐸 conditionals. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"))
and ([5](#S3.E5 "In (3) 𝑇⁢𝐸 and 𝐸⁢𝐸 conditionals. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")) give the expectation values and
distributions of the polarization spectra conditional on the observed
temperature spectra. These are shown in
Fig. [4](#S3.F4 "Figure 4 ‣ (5) Goodness of fit. ‣ 3.3.1 Temperature spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). Almost all of the data points sit within the
$\pm 2\thinspace\sigma$ bands and in the case of the $TE$ spectra, the data
points track the fluctuations expected from the $TT$ spectra at
multipoles $\ell\la 1000$. Figure [4](#S3.F4 "Figure 4 ‣ (5) Goodness of fit. ‣ 3.3.1 Temperature spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") therefore
provides an important additional check of the consistency of the $TE$
and $EE$ spectra with the base $\rm{\Lambda CDM}$ cosmology.

##### (4) Likelihood implementation.

Section [3.1](#S3.SS1 "3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") showed good consistency between the
independently written CamSpec and Plik codes in temperature. The
methodology used for the temperature likelihoods are very similar,
but the treatment of the polarization spectra in the two codes differs
substantially. CamSpec uses low-resolution CMB-subtracted 353-GHz
polarization maps thresholded by $P=(Q^{2}+U^{2})^{1/2}$ to define
diffuse Galactic polarization masks. The same apodized polarization
mask, with an effective sky
fraction $f^{\rm eff}\_{\rm sky}=48.8\thinspace\%$ (as defined by
Eq. ([10](#S3.E10 "In (1) Temperature masks. ‣ 3.3.1 Temperature spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"))), is used for 100-, 143-, and 217-GHz $Q$ and $U$ maps. Since there are no unresolved extragalactic
foregrounds detected in the $TE$ and $EE$ spectra, all of the different
frequency combinations of $TE$ and $EE$ spectra are compressed into
single $TE$ and $EE$ spectra (weighted by the inverse of the diagonals of the
appropriate covariance matrices), after foreground cleaning using the 353-GHz
maps1212
12
To reduce the impact of noise at 353 GHz,
the map-based cleaning of the $TE$ and $EE$ spectra is applied at
$\ell\leq 300$. At higher multipoles, the polarized dust corrections
are small and are subtracted as power laws fitted to the Galactic
dust spectra at lower multipoles. (generalizing the map cleaning technique
described in Sect. [3.2](#S3.SS2 "3.2 545-GHz-cleaned spectra ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") to polarization).
This allows the construction of a
full $TT,TE,EE$ likelihood with no binning of the spectra and with no
additional nuisance parameters in polarization. As noted in
Sect. [3.1](#S3.SS1 "3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") the consistency of results from the
polarization blocks of the CamSpec and Plik likelihoods is not as
good as in temperature. Cosmological parameters from fits to the $TE$
and $EE$ CamSpec and Plik likelihoods can differ by up to about
$1.5\thinspace\sigma$, although no major
science conclusions would change had we chosen to use the
CamSpec likelihood as the baseline in this paper. We will, however,
sometimes quote results from CamSpec in addition to those from
Plik to give the reader an indication of the uncertainties in
polarization associated with different likelihood implementations.
Figure [5](#S3.F5 "Figure 5 ‣ (5) Goodness of fit. ‣ 3.3.1 Temperature spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") shows the CamSpec $TE$ and $EE$
residuals and error ranges conditional on the best-fit base $\rm{\Lambda CDM}$ and
foreground model fitted to the CamSpec temperature+lowP
likelihood. The residuals in both $TE$ and $EE$ are similar to those
from Plik. The main difference can be seen at low multipoles in the
$EE$ spectrum, where CamSpec shows a higher dispersion, consistent with the
error model, though there are several high points at $\ell\approx 200$
corresponding to the minimum in the $EE$ spectrum, which may be caused
by small errors in the subtraction of polarized Galactic
emission using 353 GHz as a foreground template (and there are also
differences in the covariance matrices at high multipoles caused by
differences in the methods used
in CamSpec and Plik to estimate noise). Generally, cosmological
parameters determined from the CamSpec likelihood have smaller formal
errors than those from Plik because there are no nuisance parameters
describing polarized Galactic foregrounds in CamSpec.

#### 3.3.3 Consistency of cosmological parameters from the $TT$, $TE$, and $EE$ spectra

The consistency between parameters of the base $\rm{\Lambda CDM}$ model determined
from the Plik temperature and polarization spectra are summarized in
Table [3](#S3.T3 "Table 3 ‣ (2) Polarization spectra and residual systematics. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") and in Fig. [6](#S3.F6 "Figure 6 ‣ 3.3.3 Consistency of cosmological parameters from the 𝑇⁢𝑇, 𝑇⁢𝐸, and 𝐸⁢𝐸 spectra ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). As
pointed out by [Zaldarriaga et al. (1997)](#bib.bib354) and [Galli et al. (2014)](#bib.bib132),
precision measurements of the CMB polarization spectra have the
potential to constrain cosmological parameters to higher accuracy than
measurements of the $TT$ spectra because the acoustic peaks are narrower
in polarization and unresolved foreground contributions at high
multipoles are much lower in polarization than in temperature. The
entries in Table [3](#S3.T3 "Table 3 ‣ (2) Polarization spectra and residual systematics. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") show that cosmological parameters
that do not depend strongly on $\tau$ are consistent between the
$TT$ and $TE$ spectra, to within typically $0.5\thinspace\sigma$ or better.
Furthermore, the cosmological parameters derived from the
$TE$ spectra have comparable errors to the $TT$
parameters. None of the conclusions in this paper would change in any
significant way were we to use the $TE$ parameters in place of the $TT$
parameters. The consistency of the cosmological parameters for base
$\rm{\Lambda CDM}$ between temperature and polarization therefore gives added
confidence that Planck parameters are insensitive to the specific
details of the foreground model that we have used to correct the $TT$
spectra. The $EE$ parameters are also typically within about $1\thinspace\sigma$ of
the $TT$ parameters, though because the $EE$ spectra from Planck are
noisier than the $TT$ spectra, the errors on the $EE$ parameters are
significantly larger than those from $TT$. However, both the $TE$ and $EE$
likelihoods give lower values of $\tau$, $A\_{\rm s}$ and $\sigma\_{8}$,
by over $1\thinspace\sigma$ compared to the $TT$ solutions. Noticee that the $TE$ and
EE entries in Table [3](#S3.T3 "Table 3 ‣ (2) Polarization spectra and residual systematics. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") do not use any information from the
temperature in the low-multipole likelihood. The tendency for higher
values of $\sigma\_{8}$, $A\_{\rm s}$, and $\tau$ in the Planck TT+lowP solution is
driven, in part, by the temperature power spectrum at low multipoles.

Figure 6: Comparison of the base $\rm{\Lambda CDM}$ model parameter constraints from Planck temperature and polarization data.

Columns [4] and [5] of Table [3](#S3.T3 "Table 3 ‣ (2) Polarization spectra and residual systematics. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") compare the parameters of
the Planck $TT$ likelihood with the full Planck $TT,TE,EE$ likelihood.
These are in agreement, shifting by less than $0.2\thinspace\sigma$. Although we
have emphasized the presence of systematic effects in the Planck polarization
spectra, which are not accounted for in the errors quoted in column [4]
of Table [3](#S3.T3 "Table 3 ‣ (2) Polarization spectra and residual systematics. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"), the consistency of the Planck $TT$
and Planck $TT,TE,EE$ parameters provides strong
evidence that residual systematics in the polarization spectra have
little impact on the scientific conclusions in this paper. The
consistency of the base $\rm{\Lambda CDM}$ parameters from temperature and
polarization is illustrated graphically in
Fig. [6](#S3.F6 "Figure 6 ‣ 3.3.3 Consistency of cosmological parameters from the 𝑇⁢𝑇, 𝑇⁢𝐸, and 𝐸⁢𝐸 spectra ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). As a rough rule-of-thumb, for base
$\rm{\Lambda CDM}$, or extensions to $\rm{\Lambda CDM}$ with spatially flat geometry, using the
full Planck $TT,TE,EE$ likelihood produces improvements in cosmological
parameters of about the same size as adding BAO to the Planck TT+lowP likelihood.

### 3.4 Constraints on the reionization optical depth parameter $\tau$

Figure 7: Marginalized constraints on parameters of the base $\rm{\Lambda CDM}$ model
for various data combinations, excluding low-multipole polarization, compared to
the Planck TT+lowP constraints.

The reionization optical depth parameter $\tau$ provides an important
constraint on models of early galaxy evolution and star formation. The
evolution of the inter-galactic Ly$\alpha$ opacity measured in the
spectra of quasars can be used to set limits on the epoch of
reionization ([Gunn & Peterson 1965](#bib.bib154)). The most recent measurements suggest
that the reionization of the inter-galactic medium was largely
complete by a redshift $z\approx 6$ ([Fan et al. 2006](#bib.bib115)). The steep
decline in the space density of Ly$\alpha$-emitting galaxies over the
redshift range $6\la z\la 8$ also implies a low redshift of
reionization ([Choudhury et al. 2015](#bib.bib82)). As a reference, for the
Planck parameters listed in Table [3](#S3.T3 "Table 3 ‣ (2) Polarization spectra and residual systematics. ‣ 3.3.2 Polarization spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"), instantaneous
reionization at redshift $z=7$ results in an optical depth of $\tau=0.048$.

The optical depth $\tau$ can also be constrained from observations of
the CMB. The WMAP9 results of [Bennett et al. (2013)](#bib.bib39) give $\tau=0.089\pm 0.014$, corresponding to an instantaneous redshift of reionization
$z\_{\text{re}}=10.6\pm 1.1$. The WMAP constraint comes mainly from the $EE$
spectrum in the multipole range $\ell=2$–6. It has been argued
(e.g., [Robertson et al. 2013](#bib.bib298), and references therein) that the high
optical depth reported by WMAP cannot be produced by galaxies seen in
deep redshift surveys, even assuming high escape fractions for
ionizing photons, implying additional sources of photoionizing
radiation from still fainter objects. Evidently, it would be useful to
have an independent CMB measurement of $\tau$.

The $\tau$ measurement from CMB polarization is difficult because it
is a small signal, confined to low multipoles, requiring accurate
control of instrumental systematics and polarized foreground
emission. As discussed by [Komatsu et al. (2009)](#bib.bib197), uncertainties in
modelling polarized foreground emission are comparable to the
statistical error in the WMAP $\tau$ measurement. In particular, at
the time of the WMAP9 analysis there was very little information
available on polarized dust emission. This situation has been
partially rectified by the 353-GHz polarization maps from
Planck ([Planck Collaboration Int.
XXII 2015](#bib.bib283); [Planck Collaboration Int.
XXX 2016](#bib.bib284)). In [257](#bib.bib257), we used
preliminary 353-GHz Planck polarization maps to
clean the WMAP Ka, Q, and V maps for polarized dust emission, using WMAP
K-band as a template for polarized synchrotron emission. This lowered
$\tau$ by about 1$\thinspace\sigma$ to $\tau=0.075\pm 0.013$, compared to
$\tau=0.089\pm 0.013$ using the WMAP dust model.1313
13
Neither
of these error estimates reflect the true uncertainty in
foreground removal. However, given the preliminary nature of the
Planck polarization analysis we decided for the Planck 2013 papers
to use the WMAP polarization likelihood, as produced by the WMAP team.

In the 2015 papers, we use Planck polarization maps based on
low-resolution LFI 70-GHz maps, excluding Surveys 2 and 4. These maps
are foreground-cleaned using the LFI 30-GHz and HFI 353-GHz maps as
polarized synchrotron and dust templates, respectively. These cleaned
maps form the polarization part (“lowP’ ) of the low-multipole
Planck pixel-based likelihood, as described in [Planck Collaboration
XI (2016)](#bib.bib273).
The temperature part of this likelihood is provided by the Commander
component-separation algorithm. The Planck low-multipole likelihood
retains 46 % of the
sky in polarization and is completely independent of the WMAP
polarization likelihood. In combination with the Planck high
multipole $TT$ likelihood, the Planck low-multipole likelihood gives $\tau=0.078\pm 0.019$. This constraint is somewhat higher than the
constraint $\tau=0.067\pm 0.022$ derived from the
Planck low-multipole likelihood alone (see [Planck Collaboration
XI 2016](#bib.bib273) and also
Sect. [5.1.2](#S5.SS1.SSS2 "5.1.2 Detection of lensing in the CMB power spectra ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")).

Following the 2013 analysis, we have used the 2015 HFI 353-GHz
polarization maps as a dust template, together with the WMAP K-band data as
a template for polarized synchrotron emission, to clean the
low-resolution WMAP Ka, Q, and V maps (see [Planck Collaboration
XI 2016](#bib.bib273) for
further details). For the purpose of cosmological parameter
estimation, this data set is masked using the WMAP P06 mask, which
retains 73 % of the sky. The noise-weighted combination of the
Planck 353-cleaned WMAP polarization maps yields $\tau=0.071\pm 0.013$ when combined with the Planck $TT$ information in the range
$2\leq\ell\la 2508$, consistent with the value of $\tau$ obtained
from the LFI 70-GHz polarization maps. In fact, null tests described
in [Planck Collaboration
XI (2016)](#bib.bib273) demonstrate that the LFI and WMAP
polarization data are statistically consistent. The HFI polarization
maps have higher signal-to-noise than the LFI and could, in principle,
provide a third cross-check. However, at the time of writing, we are
not yet confident that systematics in the HFI maps at low multipoles
($\ell\la 20$) are at negligible levels. A discussion of HFI
polarization at low multipoles will therefore be deferred to future
papers.1414
14
See [Planck Collaboration Int.
XLVI (2016)](#bib.bib285), which has been
submitted since this paper was written.

Given the difficulty of making accurate CMB polarization measurements
at low multipoles, it is useful to investigate other ways of
constraining $\tau$. Measurements of the temperature power spectrum
provide a highly accurate measurement of the amplitude $A\_{\rm s}e^{-2\tau}$. However, as shown in [258](#bib.bib258) CMB lensing
breaks the degeneracy between $\tau$ and $A\_{\rm s}$. The observed
Planck $TT$ spectrum is, of course, lensed, so the degeneracy
between $\tau$ and $A\_{\rm s}$ is partially broken when we fit models to the
Planck $TT$ likelihood. However, the degeneracy breaking is much
stronger if we combine the Planck TT likelihood with the
Planck lensing likelihood constructed from measurements of the power
spectrum of the lensing potential $C^{\phi\phi}\_{\ell}$. The 2015
Planck TT and lensing likelihoods are statistically more powerful
than their $2013$ counterparts and the corresponding determination of
$\tau$ is more precise. The 2015 Planck lensing likelihood (labelled
“lensing”) is
summarized in Sec. [5.1](#S5.SS1 "5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") and discussed in more detail in
[Planck Collaboration
XV (2016)](#bib.bib276). The constraints on $\tau$ and
$z\_{\text{re}}$1515
15
We use the same specific definition of $z\_{\text{re}}$ as in
the $2013$ papers, where reionization is assumed to be relatively
sharp, with a mid-point parameterized by a redshift $z\_{\text{re}}$ and width
$\Delta z\_{\text{re}}=0.5$. Unless otherwise stated we impose a flat prior on
the optical depth with $\tau>0.01$. for various data combinations
excluding low-multipole polarization data from
Planck are summarized in Fig. [7](#S3.F7 "Figure 7 ‣ 3.4 Constraints on the reionization optical depth parameter 𝜏 ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") and
compared with the baseline Planck TT+lowP parameters. This figure
also shows the shifts of other parameters of the base
$\rm{\Lambda CDM}$ cosmology, illustrating their sensitivity to changes in $\tau$.

The Planck constraints on $\tau$ and $z\_{\text{re}}$ in the base $\rm{\Lambda CDM}$ model for
various data combinations are:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\tau$ | $\displaystyle=$ | $\displaystyle 0.078^{+0.019}\_{-0.019},\ z\_{\text{re}}=9.9^{+1.8}\_{-1.6},\ \textit{Planck}\ {\rm TT}{+}{\rm lowP};$ |  | (6a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\tau$ | $\displaystyle=$ | $\displaystyle 0.070^{+0.024}\_{-0.024},\ z\_{\text{re}}=9.0^{+2.5}\_{-2.1},\ {\textit{Planck}\ {\rm TT}{+}{\rm lensing}};$ |  | (6b) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\tau$ | $\displaystyle=$ | $\displaystyle 0.066^{+0.016}\_{-0.016},\ z\_{\text{re}}=8.8^{+1.7}\_{-1.4},\ \textit{Planck}\ {\rm TT}{+}{\rm lowP}$ |  | (6c) |
|  |  |  | $\displaystyle\qquad\qquad\qquad\qquad\qquad\qquad\qquad\qquad\qquad+{\rm lensing};$ |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\tau$ | $\displaystyle=$ | $\displaystyle 0.067^{+0.016}\_{-0.016},\ z\_{\text{re}}=8.9^{+1.7}\_{-1.4},\ {\textit{Planck}\ {\rm TT}{+}{\rm lensing}}$ |  | (6d) |
|  |  |  | $\displaystyle\qquad\qquad\qquad\qquad\qquad\qquad\qquad\qquad\qquad{{+}{\rm BAO}};$ |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\tau$ | $\displaystyle=$ | $\displaystyle 0.066^{+0.013}\_{-0.013},\ z\_{\text{re}}=8.8^{+1.3}\_{-1.2},\ \textit{Planck}\ {\rm TT}{+}{\rm lowP}$ |  | (6e) |
|  |  |  | $\displaystyle\qquad\qquad\qquad\qquad\qquad\qquad\qquad\quad{{+}{\rm lensing}{+}{\rm BAO}}.$ |  |

The constraint from Planck TT+lensing+BAO on $\tau$ is
completely independent of low-multipole CMB polarization data and
agrees well with the result from Planck polarization (and has
comparable precision). These results all indicate a lower redshift of
reionization than the value $z\_{\text{re}}=11.1\pm 1.1$ derived in [258](#bib.bib258),
based on the WMAP9 polarization likelihood. The low values of $\tau$
from Planck are also consistent with the lower value of $\tau$
derived from the WMAP Planck 353-GHz-cleaned polarization
likelihood, suggesting strongly that the WMAP9 value is biased
slightly high by residual polarized dust emission.

The Planck results of Eqs. ([6a](#S3.E1aa "In 3.4 Constraints on the reionization optical depth parameter 𝜏 ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"))–([6e](#S3.Ex9 "In 3.4 Constraints on the reionization optical depth parameter 𝜏 ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")) provide evidence for a lower optical
depth and redshift of reionization than inferred from WMAP ([Bennett et al. 2013](#bib.bib39)), partially alleviating the
difficulties in reionizing the intergalactic medium using starlight
from high-redshift galaxies. A key goal of the Planck analysis over
the next year is to assess whether these results are consistent with
the HFI polarization data at low multipoles.

Given the consistency between the LFI and WMAP polarization maps when
both are cleaned with the HFI 353-GHz polarization maps, we have also
constructed a combined WMAP+Planck low-multipole polarization
likelihood (denoted “lowP+WP”). This likelihood uses 73 % of the sky and
is constructed from a noise-weighted combination of LFI 70-GHz and
WMAP Ka, Q, and V maps,
as summarized in Sect. [3.1](#S3.SS1 "3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") and discussed in more detail
in [Planck Collaboration
XI (2016)](#bib.bib273). In combination with the Planck high-multipole
$TT$ likelihood, the combined lowP+WP likelihood gives $\tau=0.074^{+0.011}\_{-0.013}$, consistent with the individual LFI and WMAP
likelihoods to within about $0.5\thinspace\sigma$.

Figure 8: Marginalized constraints on the reionization optical depth in the
base $\rm{\Lambda CDM}$ model for various data combinations. Solid lines do not
include low-multipole polarization; in these cases the optical depth is
constrained by Planck lensing. The dashed/dotted lines include
LFI polarization (+lowP), or the combination of LFI and WMAP polarization
cleaned using 353 GHz as a dust template (+lowP+WP).

The various Planck and Planck+WMAP constraints on $\tau$ are
summarized in Fig. [8](#S3.F8 "Figure 8 ‣ 3.4 Constraints on the reionization optical depth parameter 𝜏 ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"). The tightest of these
constraints comes from the combined lowP+WP likelihood. It is
therefore reasonable to ask why we have chosen to use the
lowP likelihood as the baseline in this paper, which gives a higher
statistical error on $\tau$. The principal reason is to produce a
Planck analysis, utilizing the LFI polarization data, that is
independent of WMAP. All of the constraints shown in
Fig. [8](#S3.F8 "Figure 8 ‣ 3.4 Constraints on the reionization optical depth parameter 𝜏 ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") are compatible with each other, and
insofar as other cosmological parameters are sensitive to small
changes in $\tau$, it would make very little difference to the results
in this paper had we chosen to use WMAP or Planck+WMAP polarization
data at low multipoles.

## 4 Comparison of the Planck power spectrum with high-resolution experiments

In [258](#bib.bib258) we combined Planck with the small-scale measurements of the
ground-based, high-resolution Atacama Cosmology Telescope (ACT) and
South Pole Telescope (SPT). The primary role of using ACT and SPT was to
set limits on foreground components that were poorly constrained by
Planck alone and to provide more accurate constraints on the damping
tail of the temperature power spectrum. In this paper, with the higher
signal-to-noise levels of the full mission Planck data, we have taken a
different approach, using the ACT and SPT data to impose a prior on the thermal
and kinetic SZ power spectrum parameters in the Planck foreground
model as described in Sect. [2.3](#S2.SS3 "2.3 Changes to the foreground model ‣ 2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters"). In this section, we
check the consistency of the temperature power spectra measured by Planck,
ACT, and SPT, and test the effects of
including the ACT and SPT data on the recovered CMB power spectrum.

We use the latest ACT temperature power spectra presented in
[Das et al. (2014)](#bib.bib94), with a revised binning described in
[Calabrese et al. (2013)](#bib.bib68) and final beam estimates in
[Hasselfield et al. (2013)](#bib.bib163). As in [258](#bib.bib258) we use ACT data in the range
$1\thinspace 000<\ell<10\thinspace 000$ at 148 GHz, and $1\thinspace 500<\ell<10\thinspace 000$ for the
$148\times 218$ and 218-GHz spectra. We use SPT measurements in the
range $2\thinspace 000<\ell<13\thinspace 000$ from the complete $2\thinspace 540\thinspace{\rm deg}^{2}$ SPT-SZ
survey at 95, 150, and 220 GHz presented in [George et al. (2015)](#bib.bib140).

Each of these experiments uses a foreground model to describe the
multi-frequency power spectra. Here we implement a common foreground
model to combine Planck with the high-multipole data, following a similar
approach to [258](#bib.bib258) but with some refinements. Following the 2013 analysis,
we solve for
common nuisance parameters describing the tSZ, kSZ, and tSZ$\times$CIB
components, extending the templates used for Planck to $\ell=13\thinspace 000$
to cover the full ACT and SPT multipole range. As in [258](#bib.bib258), we use five
point-source amplitudes to fit for the total dusty and radio Poisson
power, namely $A^{\mathrm{PS,\thinspace ACT}}\_{148}$, $A^{\mathrm{PS,\thinspace ACT}}\_{218}$,
$A^{\mathrm{PS,\thinspace SPT}}\_{95}$, $A^{\mathrm{PS,\thinspace SPT}}\_{150}$, and
$A^{\mathrm{PS,\thinspace SPT}}\_{220}$. We rescale these amplitudes to
cross-frequency spectra using point-source correlation coefficients,
improving on the 2013 treatment by using different parameters for the
ACT and SPT correlations, $r^{\mathrm{PS,ACT}}\_{148\times 218}$ and
$r^{\mathrm{PS,SPT}}\_{150\times 220}$ (a single
$r^{\mathrm{PS}}\_{150\times 220}$ parameter was used in 2013). We vary
$r^{\mathrm{PS,SPT}}\_{95\times 150}$ and $r^{\mathrm{PS,SPT}}\_{95\times 220}$
as in 2013, and include dust amplitudes for
ACT, with Gaussian priors as in [258](#bib.bib258).

As described in Sect. [2.3](#S2.SS3 "2.3 Changes to the foreground model ‣ 2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters") we use a theoretically
motivated clustered CIB model fitted to Planck+IRAS estimates of the
CIB. The model at all frequencies in the range 95–220 GHz is
specified by a single amplitude $A^{\mathrm{CIB}}\_{217}$. The CIB
power is well constrained by Planck data at $\ell<2000$. At multipoles
$\ell\ga 3000$, the 1-halo component of the CIB model steepens and
becomes degenerate with the Poisson power. This causes an underestimate of the
Poisson levels for ACT and SPT, inconsistent with predictions from source
counts. We therefore use the Planck CIB template only in the range
$2<\ell<3000$, and extrapolate to higher multipoles using a power law
$\mathcal{D}\_{\ell}\propto\ell^{\thinspace 0.8}$. While this may
not be a completely accurate model for the clustered CIB spectrum at
high multipoles ([Viero et al. 2013](#bib.bib343); [Planck Collaboration
XXX 2014](#bib.bib265), see, e.g.,),
this extrapolation is consistent with the CIB model
used in the analysis of ACT and SPT.
We then need to extrapolate the Planck 217-GHz CIB power to the ACT and
SPT frequencies. This requires converting the CIB measurement in the HFI
217-GHz channel to the ACT and SPT bandpasses assuming a spectral
energy distribution; we use the CIB
spectral energy distribution from [Béthermin et al. (2012)](#bib.bib42).
Combining this model with the ACT and SPT bandpasses, we find that
$A\_{217}^{\rm CIB}$ has to be multiplied by 0.12 and 0.89 for ACT 148 and
218 GHz, and by 0.026, 0.14, and 0.91 for SPT 95, 150, and 220 GHz,
respectively. With this model in place, the best-fit Planck, ACT, and SPT
Poisson levels agree with those predicted from source counts, as
discussed further in [Planck Collaboration
XI (2016)](#bib.bib273).

The nuisance model includes seven calibration parameters as in [258](#bib.bib258) (four
for ACT and three for SPT). The ACT spectra are internally calibrated
using the WMAP 9-year maps, with 2 % and 7 % uncertainty at 148 and
218 GHz, while SPT calibrates using the Planck 2013 143-GHz maps,
with 1.1 %, 1.2 %, and 2.2 % uncertainty at 95, 150, and 220 GHz. To
account for the increased 2015 Planck absolute calibration (2 %
higher in power) we increase the mean of the SPT map-based calibrations from
1.00 to 1.01.

Figure 9: Residual power with respect to the Planck TT+lowP
$\Lambda$CDM best-fit model for the Planck (grey), ACT south (orange),
ACT equatorial (red), and SPT (green) CMB bandpowers.
The ACT and SPT bandpowers are scaled by the best-fit calibration factors.

This common foreground and calibration model fits the data well. We
first fix the cosmology to that of the best-fit Planck TT+lowP base-$\rm{\Lambda CDM}$ model,
and estimate the foreground and calibration parameters, finding a
best-fitting $\chi^{2}$ of 734 for 731 degrees of freedom (reduced
$\chi^{2}=1.004$, PTE = 0.46). We then simultaneously estimate the
Planck, ACT- (S: south, E: equatorial) and SPT CMB bandpowers, $C\_{b}$,
following the Gibbs sampling scheme of [Dunkley et al. (2013)](#bib.bib105) and
[Calabrese et al. (2013)](#bib.bib68), marginalizing over the nuisance
parameters.

To simultaneously solve for the Planck, ACT, and SPT CMB spectra, we extend
the nuisance model described above, including the four Planck point
source amplitudes, the dust parameters and the Planck 100-GHz and
217-GHz calibration parameters (relative to 143 GHz) with the same
priors as used in the Planck multi-frequency likelihood analysis. For ACT
and SPT, the calibration factors are defined for each frequency (rather
than relative to a central frequency). Following
[Calabrese et al. (2013)](#bib.bib68), we separate out the 148-GHz calibration for the
ACT-(S,E) spectra and the 150-GHz calibration for SPT, estimating the CMB
bandpowers as $C\_{b}/A\_{\rm cal}$.1616
16
This means that the other calibration
factors (e.g., ACT 218 GHz) are re-defined to be relative to 148 GHz (or
150 GHz for SPT) data. We impose Gaussian priors on $A\_{\rm cal}$: $1.00\pm 0.02$ for ACT-(S,E); and $1.010\pm 0.012$ for SPT. The estimated CMB
spectrum will then have an overall calibration uncertainty for each of
the ACT-S, ACT-E, and SPT spectra. We do not require the Planck CMB
bandpowers to be the same as those for ACT or SPT, so that we can
check for consistency between the three experiments.

In Fig. [9](#S4.F9 "Figure 9 ‣ 4 Comparison of the Planck power spectrum with high-resolution experiments ‣ Planck 2015 results. XIII. Cosmological parameters") we show the residual CMB power with
respect to the Planck TT+lowP $\rm{\Lambda CDM}$ best-fit model for the three
experiments. All of the data sets are consistent over the multipole range
plotted in this figure. For ACT-S, we find $\chi^{2}=17.54$
(18 data points, ${\rm PTE}=0.49$); For ACT-E we find
$\chi^{2}=23.54$ (18 data points, ${\rm PTE}=0.17$); and for SPT
$\chi^{2}=5.13$ (6 data points, ${\rm PTE}=0.53$).

Figure 10: Planck CMB power spectrum that is marginalized over foregrounds
(red), including a prior on the thermal and kinetic SZ power. The inclusion of
the full higher resolution ACT and SPT data (shown in blue) does not
significantly decrease the errors.

Figure [10](#S4.F10 "Figure 10 ‣ 4 Comparison of the Planck power spectrum with high-resolution experiments ‣ Planck 2015 results. XIII. Cosmological parameters") shows the effect of including ACT and SPT data
on the recovered Planck CMB spectrum. We find that including the ACT and SPT
data does not reduce the Planck errors significantly. This is expected
because the dominant small-scale foreground
contributions for Planck are the Poisson source amplitudes, which are treated
independently of the Poisson amplitudes for ACT and SPT. The
high-resolution experiments do help tighten the
CIB amplitude (which is reasonably well constrained by Planck)
and the tSZ and kSZ amplitudes (which are sub-dominant
foregrounds for Planck). The kSZ effect in particular is degenerate
with the CMB, since both have blackbody components; imposing a
prior on the allowed kSZ power (as discussed in Sect. [2.3](#S2.SS3 "2.3 Changes to the foreground model ‣ 2 Model, parameters, and methodology ‣ Planck 2015 results. XIII. Cosmological parameters")) breaks this degeneracy. The net effect is
that the errors on the recovered Planck CMB spectrum are only marginally
reduced with the inclusion of the ACT and SPT data. This motivates our choice
to include the information from ACT and SPT into the joint tSZ and kSZ prior
applied to Planck.

The Gibbs sampling technique recovers a best-fit CMB spectrum marginalized over
foregrounds and other nuisance parameters. The Gibbs samples can then be used
to form a fast CMB-only Planck likelihood that depends on only one nuisance
parameter, the overall calibration $y\_{p}$. MCMC chains run using the
CMB-only likelihood therefore converge much faster than using the full
multi-frequency Plik likelihood. The CMB-only likelihood is also extremely
accurate, even for extensions to the base $\rm{\Lambda CDM}$ cosmology and is
discussed further in [Planck Collaboration
XI (2016)](#bib.bib273).

## 5 Comparison of the Planck base $\rm{\Lambda CDM}$ model with other astrophysical data sets

### 5.1 CMB lensing measured by Planck

Gravitational lensing by large-scale structure leaves imprints on the
CMB temperature and polarization that can be measured in high angular
resolution, low-noise observations, such as those from Planck. The
most relevant effects are a smoothing of the acoustic peaks and
troughs in the $TT$, $TE$, and $EE$ power spectra, the conversion
of $E$-mode polarization to $B$-modes, and the generation of
significant non-Gaussianity in the form of a non-zero connected
4-point function (see [Lewis & Challinor 2006](#bib.bib210) for a review). The
latter is proportional to the power spectrum $C\_{\ell}^{\phi\phi}$ of
the lensing potential $\phi$, and so one can estimate this power
spectrum from the CMB 4-point functions. In the 2013 Planck release,
we reported a $10\thinspace\sigma$ detection of the lensing effect in the $TT$
power spectrum (see [258](#bib.bib258))
and a $25\thinspace\sigma$ measurement of the amplitude of $C\_{\ell}^{\phi\phi}$ from
the $TTTT$ 4-point function ([Planck Collaboration
XVII 2014](#bib.bib259)). The power of such lensing
measurements is that they provide sensitivity to parameters that affect the
late-time expansion, geometry, and matter clustering (e.g., spatial curvature
and neutrino masses) *from the CMB alone*.

Since the 2013 Planck release, there have been significant
developments in the field of CMB lensing. The SPT team have reported a
$7.7\thinspace\sigma$ detection of lens-induced $B$-mode polarization based on
the $EB\phi^{\rm CIB}$ 3-point function, where $\phi^{\rm CIB}$ is a
proxy for the CMB lensing potential $\phi$ derived from CIB
measurements ([Hanson et al. 2013](#bib.bib159)). The POLARBEAR
collaboration ([POLARBEAR Collaboration 2014b](#bib.bib288)) and the ACT
collaboration ([van Engelen et al. 2015](#bib.bib342)) have performed similar
analyses at somewhat lower significance ([POLARBEAR Collaboration 2014b](#bib.bib288)).
In addition, the first detections of the polarization 4-point function
from lensing, at a significance of around $4\thinspace\sigma$, have been
reported by the POLARBEAR ([Ade et al. 2014](#bib.bib8)) and
SPT ([Story et al. 2015](#bib.bib330)) collaborations, and the former have
also made a direct measurement of the $BB$ power spectrum due to
lensing on small angular scales with a significance around
$2\thinspace\sigma$ ([POLARBEAR Collaboration 2014a](#bib.bib287)). Finally, the $BB$ power
spectrum from lensing has also been detected on degree angular scales,
with similar significance, by the BICEP2
collaboration ([BICEP2 Collaboration 2014](#bib.bib53)); see also [54](#bib.bib54).

#### 5.1.1 The Planck lensing likelihood

Lensing results from the full-mission Planck data are discussed
in [Planck Collaboration
XV (2016)](#bib.bib276).1717
17
In that paper we are careful
to highlight the 4-point function origin of the lensing power spectrum
reconstruction by using the index $L$; however, in this paper we use the
notation $\ell$. With approximately twice the amount of
temperature data, and the inclusion of polarization, the noise levels
on the reconstructed $\phi$ are a factor of about 2 better than
in [Planck Collaboration
XVII (2014)](#bib.bib259). The broad-band amplitude of
$C\_{\ell}^{\phi\phi}$ is now measured to better than $2.5\thinspace\%$ accuracy,
the most significant measurement of CMB lensing to date. Moreover,
lensing $B$-modes are detected at $10\thinspace\sigma$, both through a
correlation analysis with the CIB and via the $TTEB$ 4-point
function. Many of the results in this paper make use of the Planck measurements of $C\_{\ell}^{\phi\phi}$. In particular, they provide an
alternative route to estimate the optical depth (as already discussed
in Sect. [3.4](#S3.SS4 "3.4 Constraints on the reionization optical depth parameter 𝜏 ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")), and to tightly constrain spatial curvature
(Sect. [6.2.4](#S6.SS2.SSS4 "6.2.4 Curvature ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")).

Figure 11: Planck measurements of the lensing power spectrum compared to the
prediction for the best-fitting base $\rm{\Lambda CDM}$ model to the Planck TT+lowP data.
*Left*: the conservative cut of the Planck lensing data used throughout
this paper, covering the multipole range $40\leq\ell\leq 400$.
*Right*: lensing data over the range $8\leq\ell\leq 2048$,
demonstrating the general consistency with the $\rm{\Lambda CDM}$ prediction over this
extended multipole range. In both cases, green points are the power from
lensing reconstructions using only temperature data, while blue points combine
temperature and polarization. They are offset in $\ell$ for clarity and
error bars are $\pm 1\thinspace\sigma$. In the top panels the solid lines are the
best-fitting base $\rm{\Lambda CDM}$ model to the Planck TT+lowP data with no renormalization
or $\delta N^{(1)}$ correction applied (see text for explanation).
The bottom panels show the
difference between the data and the renormalized and $\delta N^{(1)}$-corrected
theory bandpowers, which enter the likelihood. The mild preference of the
lensing measurements for lower lensing power around $\ell=200$
pulls the theoretical prediction for $C\_{\ell}^{\phi\phi}$ downwards at the
best-fitting parameters of a fit to the combined Planck TT+lowP+lensing data,
shown by the dashed blue lines
(always for the conservative cut of the lensing data, including polarization).

The estimation of $C\_{\ell}^{\phi\phi}$ from the Planck full-mission data is
discussed in detail in [Planck Collaboration
XV (2016)](#bib.bib276). There are a number of
significant changes from the 2013 analysis that are worth noting here.

* $\bullet$

  The lensing potential power spectrum is now estimated from lens
  reconstructions that use both temperature and polarization data in the
  multipole range $100\leq\ell\leq 2048$. The likelihood used here is based
  on the power spectrum of a lens reconstruction derived from the
  minimum-variance combination of five quadratic estimators
  ($TT$, $TE$, $EE$, $TB$, and $EB$). The power spectrum is therefore based on
  15 different 4-point functions.
* $\bullet$

  The results used here are derived from foreground-cleaned maps of the
  CMB synthesized from all nine Planck frequency maps with the SMICA algorithm, while the baseline 2013 results used a minimum-variance combination
  of the 143-GHz and 217-GHz nominal-mission maps. After
  masking the Galaxy and point-sources, $67.3\thinspace\%$ of the sky is retained for
  the lensing analysis.
* $\bullet$

  The lensing power spectrum is estimated in the multipole range
  $8\leq\ell\leq 2048$. Multipoles $\ell<8$ have large mean-field
  corrections due to survey anisotropy and are rather unstable to
  analysis choices; they are therefore excluded from all lensing results. Here,
  we use only the range $40\leq\ell\leq 400$ (the same as used in the 2013
  analysis), with eight bins each of width $\Delta\ell=45$. This choice is
  based on the extensive suite of null tests reported in [Planck Collaboration
  XV (2016)](#bib.bib276).
  Nearly all tests are passed over the full multipole range
  $8\leq\ell\leq 2048$, with the exception of a slight excess of curl modes
  in the $TT$ reconstruction around $\ell=500$. Given that the range
  $40\leq\ell\leq 400$ contains most of the statistical power in the
  reconstruction, we have conservatively adopted this range for use in the
  Planck 2015 cosmology papers.
* $\bullet$

  To normalize $C\_{\ell}^{\phi\phi}$ from the measured 4-point functions
  requires knowledge of the CMB power spectra. In practice, we normalize with
  fiducial spectra, but then correct for changes in the true normalization at
  each point in parameter space within the likelihood. The exact renormalization
  scheme adopted in the 2013 analysis proved to be too slow for the extension to
  polarization, so we now use a linearized approximation, based on pre-computed
  response functions, which is very efficient within an MCMC analysis. Spot-checks
  have confirmed the accuracy of this approach.
* $\bullet$

  The measurement of $C\_{\ell}^{\phi\phi}$ can be thought of as being derived
  from an optimal combination of trispectrum configurations. In practice, the
  expectation value of this combination at any multipole $\ell$ has a local part
  proportional to $C\_{\ell}^{\phi\phi}$, but also a non-local (“$N^{(1)}$ bias”)
  part that couples to a broad range of multipoles in
  $C\_{\ell}^{\phi\phi}$ ([Kesden et al. 2003](#bib.bib191));
  this non-local part comes from non-primary trispectrum couplings.
  In the Planck 2013 analysis we corrected for the $N^{(1)}$ bias by making a
  fiducial correction, but this ignores its parameter dependence. We improve on
  this in the 2015 analysis by correcting for errors in the fiducial $N^{(1)}$
  bias at each point in parameter space within the lensing likelihood. As with
  the renormalization above, we linearize this $\delta N^{(1)}$ correction for
  efficiency. As a result, we no longer need to make an approximate correction
  in the $C\_{\ell}^{\phi\phi}$ covariance matrix to account for the cosmological
  uncertainty in $N^{(1)}$.
* $\bullet$

  Beam uncertainties are no longer included in the covariance matrix of
  $C\_{\ell}^{\phi\phi}$, since, with the improved knowledge of the beams, the
  estimated uncertainties are negligible for the lensing analysis. The only
  inter-bandpower correlations included in the $C\_{\ell}^{\phi\phi}$ bandpower
  covariance matrix are from the uncertainty in the correction applied for the
  point-source 4-point function.

As in the 2013 analysis, we approximate the lensing likelihood as Gaussian in
the estimated bandpowers, with a fiducial covariance matrix. Following the
arguments in [Schmittfull et al. (2013)](#bib.bib307), it is a good approximation to ignore
correlations between the 2- and 4-point functions; so, when combining the
Planck power spectra with Planck lensing, we simply multiply their
respective likelihoods.

It is also worth noting that the changes in absolute calibration of the
Planck power spectra (around $2\thinspace\%$ between the 2013 and 2015 releases)
do not directly affect the lensing results. The CMB 4-point functions do, of
course, respond to any recalibration of the data, but in estimating
$C\_{\ell}^{\phi\phi}$ this dependence is removed by normalizing with theory
spectra fit to the observed CMB spectra. The measured $C\_{\ell}^{\phi\phi}$
bandpowers from the 2013 and current Planck releases can therefore be
directly compared, and are in good agreement ([Planck Collaboration
XV 2016](#bib.bib276)). Care is
needed, however, in comparing consistency of the lensing measurements across
data releases with the best-fitting model predictions. Changes in calibration
translate directly into changes in $A\_{\rm s}e^{-2\tau}$, which, along with any
change in the best-fitting optical depth, alter $A\_{\rm s}$, and hence the predicted
lensing power. These changes from 2013 to the current release go in opposite
directions, leading to a net decrease in $A\_{\rm s}$ of $0.6\thinspace\%$. This, combined with
a small ($0.15\thinspace\%$) increase in $\theta\_{\rm eq}$, reduces the
expected $C\_{\ell}^{\phi\phi}$ by approximately $1.5\thinspace\%$ for multipoles
$\ell>60$.

The Planck measurements of $C\_{\ell}^{\phi\phi}$, based on the temperature and
polarization 4-point functions, are plotted in Fig. [11](#S5.F11 "Figure 11 ‣ 5.1.1 The Planck lensing likelihood ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")
(with results of a temperature-only reconstruction included for comparison).
The measured $C\_{\ell}^{\phi\phi}$ are compared with the predicted lensing power
from the best-fitting base $\rm{\Lambda CDM}$ model to the Planck TT+lowP data in this figure. The bandpowers that
are used in the conservative lensing likelihood adopted in this paper are shown
in the left-hand plot, while bandpowers over the range
$8\leq\ell\leq 2048$ are shown in the right-hand plot, to demonstrate the
general consistency with the $\rm{\Lambda CDM}$ prediction over the full multipole range.
The difference between the measured bandpowers and the best-fit prediction are
shown in the bottom panels. Here, the theory predictions are corrected in the
same way as they are in the likelihood.1818
18
In detail, the theory spectrum
is binned in the same way as the data, renormalized to account for the
(very small) difference between the CMB spectra in the best-fit model and the
fiducial spectra used in the lensing analysis, and corrected for the difference
in $N^{(1)}$, calculated for the best-fit and fiducial models (around a
$4\thinspace\%$ change in $N^{(1)}$, since the fiducial-model $C\_{\ell}^{\phi\phi}$ is
higher by this amount than in the best-fit model).

Figure [11](#S5.F11 "Figure 11 ‣ 5.1.1 The Planck lensing likelihood ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") suggests that the Planck measurements of
$C\_{\ell}^{\phi\phi}$ are mildly in tension with the prediction of the
best-fitting $\rm{\Lambda CDM}$ model. In particular, for the conservative multipole range
$40\leq\ell\leq 400$, the temperature+polarization reconstruction has
$\chi^{2}=15.4$ (for eight degrees of freedom), with a PTE of $5.2\thinspace\%$.
For reference, over the full multipole range $\chi^{2}=40.8$ for 19
degrees of freedom (PTE of $0.3\thinspace\%$); the large $\chi^{2}$ is driven by a
single bandpower ($638\leq\ell\leq 762$), and excluding this gives an
acceptable $\chi^{2}=26.8$ (PTE of $8\thinspace\%$). We caution the reader that this
multipole range is where the lensing reconstruction shows a mild excess of
curl-modes ([Planck Collaboration
XV 2016](#bib.bib276)), and for this reason we adopt the
conservative multipole range for the lensing likelihood in this paper.

This simple $\chi^{2}$ test does not account for the uncertainty in the predicted
$C\_{\ell}^{\phi\phi}$. In the $\rm{\Lambda CDM}$ model, the dominant uncertainty in the
multipole range $40\leq\ell\leq 400$ comes from that in $A\_{\rm s}$
($1\thinspace\sigma$ uncertainty of $3.7\thinspace\%$ for Planck TT+lowP), which itself derives from the
uncertainty in the reionization optical depth, $\tau$. The predicted rms lensing deflection from
Planck TT+lowP data is $\langle d^{2}\rangle^{1/2}=(2.50\pm 0.05)\thinspace{\rm arcmin}$, corresponding to a $3.6\thinspace\%$ uncertainty ($1\thinspace\sigma$) in the
amplitude of $C\_{\ell}^{\phi\phi}$ (which improves to $3.1\thinspace\%$ uncertainty for
the combined Planck+WP likelihood). Note that this is larger
than the uncertainty on the measured amplitude, i.e., *the lensing
measurement is more precise than the prediction from the CMB power spectra in
even the simplest $\rm{\Lambda CDM}$ model*. This model uncertainty is reflected in a
scatter in the $\chi^{2}$ of the lensing data over the Planck TT+lowP chains,
$\chi^{2}\_{\rm lens}=17.9\pm 9.0$, which is significantly larger than the
expected scatter in $\chi^{2}$ at the true model, due to the uncertainties in
the lensing bandpowers ($\sqrt{2N\_{\rm dof}}=4$).
Following the treatment in [258](#bib.bib258),
we can assess consistency more carefully by introducing a parameter $A\_{\rm L}^{\phi\phi}$
that scales the theory lensing trispectrum at every point in parameter space
in a joint analysis of the CMB spectra and the lensing spectrum. We find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $A\_{\rm L}^{\phi\phi}=0.95\pm 0.04\quad(68\%,\text{{Planck}\ TT{+}lowP{+}lensing}),$ |  | (7) |

in good agreement with the expected value of unity. The posterior for
$A\_{\rm L}^{\phi\phi}$, and other lensing amplitude measures discussed below, is shown in
Fig. [12](#S5.F12 "Figure 12 ‣ 5.1.1 The Planck lensing likelihood ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters").

Figure 12: Marginalized posterior distributions for measures of the lensing
power amplitude. The dark-blue (dot-dashed) line is the constraint on the
parameter $A\_{\rm L}^{\phi\phi}$, which scales the amplitude of the lensing power spectrum
in the lensing likelihood for the Planck TT+lowP+lensing data combination. The
other lines are for the $A\_{\rm L}$ parameter, which scales the lensing power
spectrum used to lens the CMB spectra, for the data combinations Planck TT+lowP (blue, solid), Planck TE+lowP (red, dashed), Planck EE+lowP (green, dashed), and Planck TT,TE,EE+lowP (black, dashed).
The dotted lines show the $A\_{\rm L}$ constraints when the Plik likelihood is
replaced with CamSpec, highlighting that the preference for high $A\_{\rm L}$ in
the Planck EE+lowP data combination is not robust to the treatment of
polarization on intermediate and small scales.

Given the precision of the measured $C\_{\ell}^{\phi\phi}$ compared to the
uncertainty in the predicted spectrum from fits to the Planck TT+lowP data, the
structure in the residuals seen in Fig. [11](#S5.F11 "Figure 11 ‣ 5.1.1 The Planck lensing likelihood ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") might be
expected to pull parameters in joint fits. As discussed
in [Planck Collaboration
XV (2016)](#bib.bib276) and [Pan et al. (2014)](#bib.bib246), the primary
parameter dependence of $C\_{\ell}^{\phi\phi}$ at multipoles $\ell\ga 100$ is
through $A\_{\rm s}$ and $\ell\_{\rm eq}$ in $\rm{\Lambda CDM}$ models. Here, $\ell\_{\rm eq}\propto 1/\theta\_{\rm eq}$ is the angular multipole corresponding to the
horizon size at matter-radiation equality observed at a distance $\chi\_{\ast}$.
The combination $A\_{\rm s}\ell\_{\rm eq}$ determines the mean-squared deflection
$\langle d^{2}\rangle$, while $\ell\_{\rm eq}$ controls the shape of
$C\_{\ell}^{\phi\phi}$. For the parameter ranges of interest,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\delta C\_{\ell}^{\phi\phi}/C\_{\ell}^{\phi\phi}=\delta A\_{\rm s}/A\_{\rm s}+(n\_{\ell}+1)\delta\ell\_{\rm eq}/\ell\_{\rm eq},$ |  | (8) |

where $n\_{\ell}$ arises (mostly) from the strong wavenumber dependence of the transfer
function for the gravitational potential, with $n\_{\ell}\approx 1.5$ around
$\ell=200$.

In joint fits to Planck TT+lowP+lensing, the main parameter changes from Planck TT+lowP alone are a $2.6\thinspace\%$ reduction in the best-fit $A\_{\rm s}$, with an accompanying
reduction in the best-fit $\tau$, to $0.067$ (around $0.6\thinspace\sigma$; see
Sect. [3.4](#S3.SS4 "3.4 Constraints on the reionization optical depth parameter 𝜏 ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")). There is also a $0.7\thinspace\%$ reduction in
$\ell\_{\rm eq}$, achieved at fixed $\theta\_{\ast}$ by reducing $\omega\_{\mathrm{m}}$. These
combine to reduce $C\_{\ell}^{\phi\phi}$ by approximately $4\thinspace\%$ at $\ell=200$,
consistent with Eq. ([8](#S5.E8 "In 5.1.1 The Planck lensing likelihood ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")). The difference between the theory
lensing spectrum at the best-fit parameters in the Planck TT+lowP and
Planck TT+lowP+lensing fits are shown by the dashed blue lines in
Fig. [11](#S5.F11 "Figure 11 ‣ 5.1.1 The Planck lensing likelihood ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"). In the joint fit, the $\chi^{2}$ for the lensing
bandpowers improves by 6, while the $\chi^{2}$ for the Planck TT+lowP data degrades
by only $1.2$ ($2.8$ for the high-$\ell$ $TT$ data and $-1.6$ for the low-$\ell$
$TEB$ data).

The lower values of $A\_{\rm s}$ and $\omega\_{\mathrm{m}}$ in the joint fit give a $2\thinspace\%$ reduction
in $\sigma\_{8}$, with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sigma\_{8}=0.815\pm 0.009\quad(68\%,\text{{Planck}\ TT{+}lowP{+}lensing}),$ |  | (9) |

as shown in Fig. [19](#S5.F19 "Figure 19 ‣ 5.6 Cosmic concordance? ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"). The decrease in matter density
leads to a corresponding decrease in $\Omega\_{\mathrm{m}}$, and at fixed $\theta\_{\ast}$
(approximately $\propto\Omega\_{\mathrm{m}}h^{3}$) a $0.5\thinspace\sigma$ increase in $H\_{0}$, giving

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\begin{aligned} H\_{0}&=(67.8\pm 0.9)\thinspace\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}\\ \Omega\_{\mathrm{m}}&=0.308\pm 0.012\end{aligned}\ \right\}\ \ \mbox{\text{{Planck}\ TT{+}lowP{+}lensing. }}$ |  | (10) |

Joint Planck+lensing constraints on other parameters of the base $\rm{\Lambda CDM}$ cosmology are given in
Table. [4](#S5.T4 "Table 4 ‣ 5.6 Cosmic concordance? ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters").

[Planck Collaboration
XV (2016)](#bib.bib276) discusses the effect on parameters of extending the
lensing multipole range in joint fits with $\textit{Planck}\ {\rm TT}{+}{\rm lowP}$. In the base $\rm{\Lambda CDM}$ model, using the full multipole range $8\leq\ell\leq 2048$, the parameter
combination $\sigma\_{8}\Omega\_{\mathrm{m}}^{1/4}\approx(A\_{\rm s}\ell\_{\rm eq}^{2.5})^{1/2}$
(which is well determined by the lensing measurements) is pulled around
$1\thinspace\sigma$ lower that its value using the conservative lensing range, with a
negligible change in the uncertainty. Around half of this shift comes from the
$3.6\thinspace\sigma$ outlying bandpower ($638\leq\ell\leq 762$). In massive
neutrino models, the total mass is similarly pulled higher by around
$1\thinspace\sigma$ when using the full lensing multipole range.

#### 5.1.2 Detection of lensing in the CMB power spectra

The smoothing effect of lensing on the acoustic peaks and troughs of the $TT$
power spectrum is detected at high significance in the Planck data.
Following [258](#bib.bib258) (see also [Calabrese et al. 2008](#bib.bib69)), we
introduce a parameter $A\_{\rm L}$, which scales the theory
$C\_{\ell}^{\phi\phi}$ power spectrum at each point in parameter space, and which
is used to lens the CMB spectra.1919
19
We emphasize the difference
between the phenomenological parameters $A\_{\rm L}$ and $A\_{\rm L}^{\phi\phi}$
(introduced earlier). The amplitude $A\_{\rm L}$ multiplies
$C\_{\ell}^{\phi\phi}$ when calculating both the lensed CMB theory spectra and
the lensing likelihood, while $A\_{\rm L}^{\phi\phi}$ affects only the lensing
likelihood by scaling the theory $C\_{\ell}^{\phi\phi}$ when comparing with the
power spectrum of the reconstructed lensing potential $\phi$.
The expected value for base $\rm{\Lambda CDM}$ is $A\_{\rm L}=1$. The results of such an analysis for models with variable
$A\_{\rm L}$ is shown in Fig. [12](#S5.F12 "Figure 12 ‣ 5.1.1 The Planck lensing likelihood ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"). The marginalized constraint on
$A\_{\rm L}$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $A\_{\rm L}=1.22\pm 0.10\quad(68\%,\text{{Planck}\ TT{+}lowP})\thinspace.$ |  | (11) |

This is very similar to the result from the 2013 Planck data reported in
[258](#bib.bib258). The persistent preference for $A\_{\rm L}>1$ is discussed in detail
there. For the 2015 data, we find that $\Delta\chi^{2}=-6.4$ between the
best-fitting $\rm{\Lambda CDM}$$+A\_{\rm L}$ model and the best-fitting base $\rm{\Lambda CDM}$ model.
There is roughly equal preference for high $A\_{\rm L}$ from intermediate and high
multipoles (i.e., the Plik likelihood; $\Delta\chi^{2}=-2.6$) and from the
low-$\ell$ likelihood ($\Delta\chi^{2}=-3.1$), with a further small change
coming from the priors.

Figure 13: Changes in the CMB $TT$ spectrum and foreground spectra, between the
best-fitting $A\_{\rm L}$ model and the best-fitting base $\rm{\Lambda CDM}$ model to the
Planck TT+lowP data. The solid blue line shows the difference between the $A\_{\rm L}$
model and $\rm{\Lambda CDM}$  while the dashed line has the the same values of the
other cosmological parameters, but with $A\_{\rm L}$ set to unity, to highlight
the changes in the spectrum arising from differences in the other
parameters. Also shown are the changes in the best-fitting foreground
contributions to the four frequency cross-spectra between the $A\_{\rm L}$ model
and the $\rm{\Lambda CDM}$ model.
The data points (with $\pm 1\thinspace\sigma$ errors) are the differences between the
high-$\ell$ maximum-likelihood frequency-averaged CMB spectrum and the
best-fitting $\rm{\Lambda CDM}$ model to the Planck TT+lowP data (as in Fig. [1](#S3.F1 "Figure 1 ‣ (2) DetSets versus cross-surveys. ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")).
Note that the changes in the CMB spectrum and the foregrounds should be added
when comparing to the residuals in the data points.

Increases in $A\_{\rm L}$ are accompanied by changes in all other parameters, with
the general effect being to reduce the predicted CMB power on large scales,
and in the region of the second acoustic peak, and to increase CMB power on small
scales (see Fig. [13](#S5.F13 "Figure 13 ‣ 5.1.2 Detection of lensing in the CMB power spectra ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")). A reduction in the high-$\ell$
foreground power compensates the CMB increase on small scales. Specifically,
$n\_{\rm s}$ is increased by $1\thinspace\%$ relative to the best-fitting base model and
$A\_{\rm s}$ is reduced by $4\thinspace\%$, both of which lower the large-scale power to
provide a better fit to the measured spectra around $\ell=20$ (see
Fig. [1](#S3.F1 "Figure 1 ‣ (2) DetSets versus cross-surveys. ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")).
The densities $\omega\_{\mathrm{b}}$ and $\omega\_{\mathrm{c}}$ respond to the change in $n\_{\rm s}$, following the
usual $\rm{\Lambda CDM}$ acoustic degeneracy, and $A\_{\rm s}e^{-2\tau}$ falls by $1\thinspace\%$,
attempting to reduce power in the damping tail due to the increase in $n\_{\rm s}$ and
reduction in the diffusion angle $\theta\_{\rm D}$ (which follows from the
reduction in $\omega\_{\mathrm{m}}$). The changes in $A\_{\rm s}$ and $A\_{\rm s}e^{-2\tau}$ lead to a
reduction in $\tau$ from $0.078$ to $0.060$. With these cosmological
parameters, the lensing power is lower than in the base model, which
additionally increases the CMB power in the acoustic peaks and reduces it in
the troughs. This provides a poor fit to the measured spectra around the
fourth and fifth peaks, but this can be mitigated by increasing $A\_{\rm L}$
to give more smoothing from lensing than in the base model.
However, $A\_{\rm L}$ further increases power in the damping tail, but this is
partly offset by reduction of the power in the high-$\ell$ foregrounds.

The trends in the $TT$ spectrum that favour high $A\_{\rm L}$ have a similar pull
on parameters such as curvature (Sect. [6.2.4](#S6.SS2.SSS4 "6.2.4 Curvature ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) and the dark
energy equation of state (Sect. [6.3](#S6.SS3 "6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) in extended models.
These parameters affect the late-time geometry and clustering and so alter the
lensing power, but their effect on the primary CMB fluctuations is degenerate
with changes in the Hubble constant (to preserve $\theta\_{\ast}$). The same
parameter changes as those in $A\_{\rm L}$ models are found in these extended
models, but with, for example, the increase in $A\_{\rm L}$ replaced by a reduction
in $\Omega\_{K}$. Adding external data, however, such as the Planck lensing data or
BAO (Sect. [5.2](#S5.SS2 "5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")), pull these extended models back to base $\rm{\Lambda CDM}$.

Finally, we note that lensing is also detected at lower significance
in the polarization power spectra (see Fig. [12](#S5.F12 "Figure 12 ‣ 5.1.1 The Planck lensing likelihood ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")):

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | | | | |
|  | $\displaystyle A\_{\rm L}$ | $\displaystyle=0.98^{+0.21}\_{-0.24}\quad(68\%,\text{{Planck}\ TE+lowP})\thinspace;$ |  | (12a) |
|  | $\displaystyle A\_{\rm L}$ | $\displaystyle=1.54^{+0.28}\_{-0.33}\quad(68\%,\text{{Planck}\ EE+lowP})\thinspace.$ |  | (12b) |

These results use only polarization at low multipoles, i.e., with no temperature
data at multipoles $\ell<30$.
These are the first detections of lensing in the CMB polarization
spectra, and reach almost $5\thinspace\sigma$ in $TE$. We caution the reader that the
$A\_{\rm L}$ constraints from $EE$ and low-$\ell$ polarization are rather unstable
between high-$\ell$ likelihoods because of differences in the treatment of
the polarization data (see Fig. [12](#S5.F12 "Figure 12 ‣ 5.1.1 The Planck lensing likelihood ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"),
which compares constraints from the Plik and CamSpec polarization
likelihoods).
The result of replacing Plik with the CamSpec likelihood is $A\_{\rm L}=1.19^{+0.20}\_{-0.24}$,
i.e., around $1\thinspace\sigma$ lower than the result from Plik reported in
Eq. ([12b](#S5.E12.2 "In 12 ‣ 5.1.2 Detection of lensing in the CMB power spectra ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")). If we additionally include the low-$\ell$ temperature
data, $A\_{\rm L}$ from $TE$ increases:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $A\_{\rm L}=1.13\pm 0.2\quad(68\%,\text{{Planck}\ TE+lowT,P})\thinspace.$ |  | (13) |

The pull to higher $A\_{\rm L}$ in this case is due to the reduction in $TT$ power
in these models on large scales (as discussed above).

### 5.2 Baryon acoustic oscillations

Baryon acoustic oscillation (BAO) measurements are geometric
and largely unaffected by uncertainties in the nonlinear
evolution of the matter density field and additional systematic errors
that may affect other types of astrophysical data. As in [258](#bib.bib258), we
therefore use BAO as a primary astrophysical data set to break parameter
degeneracies from CMB measurements.

Figure 14: Acoustic-scale distance ratio $D\_{\rm V}(z)/r\_{\rm drag}$ in the base $\rm{\Lambda CDM}$ model divided by the mean distance ratio from Planck TT+lowP+lensing.
The points with $1\thinspace\sigma$ errors are as follows: green star
([Beutler et al. 2011](#bib.bib46), 6dFGS, ); square ([Ross et al. 2015](#bib.bib300), SDSS MGS, );
red triangle and large circle
([Anderson et al. 2014](#bib.bib18), BOSS “LOWZ” and CMASS surveys,);
and small blue circles ([Kazin et al. 2014](#bib.bib190), WiggleZ, as analysed by).
The grey bands show the $68\thinspace\%$ and $95\thinspace\%$ confidence ranges allowed by
Planck TT+lowP+lensing.

Figure [14](#S5.F14 "Figure 14 ‣ 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") shows an updated version of figure 15 from [258](#bib.bib258).
The plot shows the acoustic-scale distance ratio $D\_{\rm V}(z)/r\_{\rm drag}$ measured
from a number of large-scale structure surveys with effective redshift $z$,
divided by the mean acoustic-scale ratio in the base $\rm{\Lambda CDM}$ cosmology using
Planck TT+lowP+lensing. Here
$r\_{\rm drag}$ is the comoving sound horizon at the end of the baryon drag epoch and
$D\_{\rm V}$ is a combination of the angular diameter distance $D\_{\rm A}(z)$ and Hubble
parameter $H(z)$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $D\_{\rm V}(z)=\left[(1+z)^{2}D\_{\rm A}^{2}(z){cz\over H(z)}\right]^{1/3}.$ |  | (14) |

The grey bands in the figure show the $\pm 1\thinspace\sigma$ and $\pm 2\thinspace\sigma$ ranges allowed by Planck in the base $\rm{\Lambda CDM}$ cosmology.

The changes to the data points compared to figure 15 of [258](#bib.bib258) are as
follows. We have replaced the SDSS DR7 measurements of [Percival et al. (2010)](#bib.bib251)
with the recent analysis of the SDSS Main Galaxy Sample (MGS) of [Ross et al. (2015)](#bib.bib300)
at $z\_{\rm eff}=0.15$, and by the [Anderson et al. (2014)](#bib.bib18) analysis of the Baryon
Oscillation Spectroscopic Survey (BOSS) “LOWZ” sample at $z\_{\rm eff}=0.32$.
Both of these analyses use peculiar velocity field reconstructions to
sharpen the BAO feature and reduce the errors on $D\_{\rm V}/r\_{\rm drag}$. The
blue points in Fig. [14](#S5.F14 "Figure 14 ‣ 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") show a reanalysis of the WiggleZ redshift survey
by [Kazin et al. (2014)](#bib.bib190) that applyies peculiar velocity reconstructions.
These reconstructions cause small shifts in $D\_{\rm V}/r\_{\rm drag}$ compared to the
unreconstructed WiggleZ results of [Blake et al. (2011)](#bib.bib56) and lead to
reductions in the errors on the distance measurements at $z\_{\rm eff}=0.44$
and $z\_{\rm eff}=0.73$. The point labelled BOSS CMASS at $z\_{\rm eff}=0.57$
shows $D\_{\rm V}/r\_{\rm drag}$ from the analysis of [Anderson et al. (2014)](#bib.bib18), updating the
BOSS-DR9 analysis of [Anderson et al. (2012)](#bib.bib19) used in [258](#bib.bib258).

In fact, the [Anderson et al. (2014)](#bib.bib18) analysis solves jointly for the positions of
the BAO feature in both the line-of-sight and transverse directions (the
distortion in the transverse direction caused by the background cosmology
is sometimes called the Alcock-Paczynski effect, [Alcock & Paczynski 1979](#bib.bib13)), leading
to joint constraints on the angular diameter distance $D\_{\rm A}(z\_{\rm eff})$
and the Hubble parameter $H(z\_{\rm eff})$.
These constraints, using the tabulated likelihood included in the CosmoMC module,2020
20
<http://www.sdss3.org/science/boss_publications.php>
are plotted in Fig. [15](#S5.F15 "Figure 15 ‣ 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"). Samples from the Planck TT+lowP+lensing
chains are shown for comparison, coloured by the value of $\Omega\_{\mathrm{c}}h^{2}$.
The length of the degeneracy line is set
by the allowed variation in $H\_{0}$ (or equivalently $\Omega\_{\mathrm{m}}h^{2}$).
In the Planck TT+lowP+lensing $\rm{\Lambda CDM}$ analysis the line is defined approximately by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{D\_{\rm A}(0.57)/r\_{\rm drag}}{9.384}\left(\frac{H(0.57)r\_{\rm drag}/c}{0.4582}\right)^{1.7}=1.0000\pm 0.0004,$ |  | (15) |

which just grazes the BOSS CMASS 68 % error ellipse plotted in Fig. [15](#S5.F15 "Figure 15 ‣ 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters").
Evidently, the Planck base $\rm{\Lambda CDM}$ parameters are in good agreement with both the
isotropized $D\_{\rm V}$ BAO measurements plotted in Fig. [14](#S5.F14 "Figure 14 ‣ 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"), and with the anisotropic
constraints plotted in Fig. [15](#S5.F15 "Figure 15 ‣ 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters").

Figure 15: 68 % and 95 % constraints on the angular diameter distance
$D\_{\rm A}(z=0.57)$ and Hubble parameter $H(z=0.57)$ from the [Anderson et al. (2014)](#bib.bib18)
analysis of the BOSS CMASS-DR11 sample. The fiducial sound horizon adopted
by [Anderson et al. (2014)](#bib.bib18) is $r\_{\rm drag}^{\rm fid}=149.28\thinspace{\rm Mpc}$.
Samples from the Planck TT+lowP+lensing chains are plotted coloured by their value of
$\Omega\_{\mathrm{c}}h^{2}$, showing consistency of the data, but also that the BAO measurement
can tighten the Planck constraints on the matter density.

In this paper, we use the 6dFGS, SDSS-MGS, and BOSS-LOWZ BAO
measurements of $D\_{\rm V}/r\_{\rm drag}$ ([Beutler et al. 2011](#bib.bib46); [Ross et al. 2015](#bib.bib300); [Anderson et al. 2014](#bib.bib18)) and
the CMASS-DR11 anisotropic BAO measurements of
[Anderson et al. (2014)](#bib.bib18). Since the WiggleZ volume partially overlaps that of the
BOSS-CMASS sample, and the correlations have not been quantified, we do not
use the WiggleZ results in this paper. It is clear from Fig. [14](#S5.F14 "Figure 14 ‣ 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") that
the combined BAO likelihood is dominated by the two BOSS measurements.

In the base $\rm{\Lambda CDM}$ model, the Planck data constrain
the Hubble constant $H\_{0}$ and matter density $\Omega\_{\mathrm{m}}$ to high precision:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\begin{aligned} H\_{0}&=(67.3\pm 1.0)\thinspace\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}\\ \Omega\_{\mathrm{m}}&=0.315\pm 0.013\end{aligned}\ \right\}\ \ \mbox{\text{{Planck}\ TT{+}lowP. }}$ |  | (16) |

With the addition of the BAO measurements, these constraints are strengthened
significantly to

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\begin{aligned} H\_{0}&=(67.6\pm 0.6)\thinspace\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}\\ \Omega\_{\mathrm{m}}&=0.310\pm 0.008\end{aligned}\ \right\}\ \ \mbox{\text{{Planck}\ TT{+}lowP{+}BAO. }}$ |  | (17) |

These numbers are consistent with the Planck+lensing constraints of
Eq. ([10](#S5.E10 "In 5.1.1 The Planck lensing likelihood ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")).
Section [5.4](#S5.SS4 "5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") discusses the consistency of these estimates of $H\_{0}$
with direct measurements.

Although low-redshift BAO measurements are in good agreement with Planck for the base $\rm{\Lambda CDM}$ cosmology, this may not be true at high redshifts.
Recently, BAO features have been measured in the flux-correlation function of
the Ly$\alpha$ forest of BOSS quasars ([Delubac et al. 2015](#bib.bib97))
and in the cross-correlation of the Ly$\alpha$ forest with quasars
([Font-Ribera et al. 2014](#bib.bib126)). These observations give measurements of
$c/(H(z)r\_{\rm drag})$ and $D\_{\rm A}(z)/r\_{\rm drag}$ (with somewhat lower precision) at
$z=2.34$ and $z=2.36$, respectively. For example, from table II of
[Aubourg et al. (2015)](#bib.bib24) the two Ly$\alpha$ BAO measurements combined
give $c/(H(2.34)r\_{\rm drag})=9.14\pm 0.20$, compared to the predictions of the
base Planck $\rm{\Lambda CDM}$ cosmology of
$8.586\pm 0.021$, which are discrepant at the $2.7\thinspace\sigma$ level. At present,
it is not clear whether this discrepancy is caused by systematics in the
Ly$\alpha$ BAO measurements (which are more complex and less mature than
galaxy BAO measurements) or an indicator of new physics. As
[Aubourg et al. (2015)](#bib.bib24) discuss, it is difficult to find a physical
explanation for the Ly$\alpha$ BAO results without disrupting the consistency
with the much more precise galaxy BAO measurements at lower redshifts.

### 5.3 Type Ia supernovae

Type Ia supernovae (SNe) are powerful probes of cosmology
([Riess et al. 1998](#bib.bib295); [Perlmutter et al. 1999](#bib.bib253)) and particularly of the equation of
state of dark energy. In [258](#bib.bib258), we used two samples of type Ia
SNe, the “SNLS” compilation ([Conley et al. 2011](#bib.bib86)) and the “Union2.1”
compilation ([Suzuki et al. 2012](#bib.bib332)). The SNLS sample was found to be in
mild tension, at about the $2\thinspace\sigma$ level, with the 2013
Planck base $\rm{\Lambda CDM}$ cosmology favouring a value of $\Omega\_{\mathrm{m}}\approx 0.23$ compared to the Planck value of $\Omega\_{\mathrm{m}}=0.315\pm 0.017$. Another consequence of this tension showed up in extensions to
the base $\rm{\Lambda CDM}$ model, where the combination of Planck and the SNLS
sample showed $2\thinspace\sigma$ evidence for a “phantom” ($w<-1$) dark
energy equation of state.

Following the submission of [258](#bib.bib258), [Betoule et al. (2013)](#bib.bib43) reported
the results of an extensive campaign to improve the relative
photometric calibrations between the SNLS and SDSS supernova
surveys. The ‘‘Joint Light-curve Analysis’’ (JLA) sample, used in this
paper, is constructed from the SNLS and SDSS SNe data, together with
several samples of low redshift SNe.2121
21
A CosmoMC likelihood
model for the JLA sample is available at
<http://supernovae.in2p3.fr/sdss_snls_jla/ReadMe.html>. The
latest version in CosmoMC includes numerical integration over the
nuisance parameters for use when calculating joint constraints using
importance sampling; this can give different $\chi^{2}$ values compared to
parameter best fits.. Cosmological constraints from the JLA sample
are discussed by [Betoule et al. (2014)](#bib.bib44) and residual biases associated
with the photometry and light curve fitting are assessed by
[Mosher et al. (2014)](#bib.bib234). For the base $\rm{\Lambda CDM}$ cosmology,
[Betoule et al. (2014)](#bib.bib44) find $\Omega\_{\mathrm{m}}=0.295\pm 0.034$, consistent with the
2013 and 2015 Planck values for base $\rm{\Lambda CDM}$. This relieves the
tension between the SNLS and Planck data reported in
[258](#bib.bib258). Given the consistency between Planck and the JLA sample
for base $\rm{\Lambda CDM}$, one can anticipate that the combination of these two
data sets will constrain the dark energy equation of state to be close
to $w=-1$ (see Sect. [6.3](#S6.SS3 "6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")).

Since the submission of [258](#bib.bib258), first results from a sample of Type Ia SNe
discovered with the Pan-STARRS survey have been reported by [Rest et al. (2014)](#bib.bib294)
and [Scolnic et al. (2014)](#bib.bib309). The Pan-STARRS sample is still relatively small
(consisting of $146$ spectroscopically confirmed Type Ia SNe) and is not
used in this paper.

### 5.4 The Hubble constant

CMB experiments provide indirect and highly model-dependent estimates of the
Hubble constant. It is therefore important to compare CMB estimates with
direct estimates of $H\_{0}$, since any significant evidence of a tension could
indicate the need for new physics. In [258](#bib.bib258), we used the
[Riess et al. (2011, hereafter R11)](#bib.bib296) Hubble Space Telescope
(HST) Cepheid+SNe based estimate of
$H\_{0}=(73.8\pm 2.4)\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$ as a supplementary “$H\_{0}$-prior.”
This value was in tension at about the $2.5\thinspace\sigma$ level with the
2013 Planck base $\rm{\Lambda CDM}$ value of $H\_{0}$.

For the base $\rm{\Lambda CDM}$ model, CMB and BAO experiments consistently find a value
of $H\_{0}$ lower than the R11 value.
For example, the 9-year WMAP data ([Bennett et al. 2013](#bib.bib39); [Hinshaw et al. 2013](#bib.bib168))
give:2222
22
These numbers are taken from our parameter grid, which includes
a neutrino mass of $0.06\thinspace{\rm eV}$ and the same updated BAO compilation as
Eq. ([17](#S5.E17 "In 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) (see Sect. [5.2](#S5.SS2 "5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")).

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle H\_{0}$ | $\displaystyle=$ | $\displaystyle(69.7\pm 2.1)\thinspace\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1},\qquad\ \ \rm WMAP9,$ |  | (18a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle H\_{0}$ | $\displaystyle=$ | $\displaystyle(68.0\pm 0.7)\thinspace\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1},\quad\ \ \rm WMAP9{+}{\rm BAO}.$ |  | (18b) |

These numbers can be compared with the Planck 2015 values
given in Eqs. ([16](#S5.E16 "In 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) and ([17](#S5.E17 "In 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")). The WMAP
constraints are driven towards the Planck values by the addition
of the BAO data and so there is persuasive evidence for a low $H\_{0}$ in
the base $\rm{\Lambda CDM}$ cosmology independently of the high-multipole CMB
results from Planck. The 2015 Planck TT+lowP value is entirely
consistent with the 2013 Planck value and so the tension with the
R11 $H\_{0}$ determination remains at about $2.4\thinspace\sigma$.

The tight constraint on $H\_{0}$ in Eq. ([18b](#S5.E2 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) is an example of an
“inverse distance ladder,” where the CMB primarily constrains the
sound horizon within a given cosmology, providing an absolute
calibration of the BAO acoustic-scale (e.g., [Percival et al. 2010](#bib.bib251); [Cuesta et al. 2015](#bib.bib92); [Aubourg et al. 2015](#bib.bib24), see also
[258](#bib.bib258)). In fact, in a
recent paper [Aubourg et al. (2015)](#bib.bib24) use the 2013 Planck constraints on
$r\_{\rm s}$ in combination with BAO and the JLA SNe data to find $H\_{0}=(67.3\pm 1.1)\thinspace\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$, in excellent agreement with the 2015 Planck value
for base $\rm{\Lambda CDM}$ given in Eq. ([16](#S5.E16 "In 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")), which is based on the
Planck temperature power spectrum. Note that by adding SNe
data, the [Aubourg et al. (2015)](#bib.bib24) estimate of $H\_{0}$ is insensitive to
spatial curvature and to late time variations of the dark energy
equation of state. Evidently, there are a number of lines of evidence
that point to a lower value of $H\_{0}$ than the direct determination of
R11.

The R11 Cepheid data have been reanalysed by
[Efstathiou (2014, hereafter E14)](#bib.bib109) using the revised geometric maser distance
to NGC 4258 of [Humphreys et al. (2013)](#bib.bib179). Using NGC 4258 as a distance anchor,
E14 finds

|  |  |  |  |
| --- | --- | --- | --- |
|  | $H\_{0}=(70.6\pm 3.3)\thinspace\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1},\qquad{\rm NGC\ 4258},$ |  | (19) |

which is within $1\thinspace\sigma$ of the Planck TT estimate given in
Eq. ([16](#S5.E16 "In 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")). In this paper we use Eq. ([19](#S5.E19 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) as a
“conservative” $H\_{0}$ prior.

R11 also use Large Magellanic Cloud Cepheids and a small sample of Milky Way
Cepheids with parallax distances as alternative distance anchors to NGC4258.
The R11 $H\_{0}$ prior used in [258](#bib.bib258) combines all
three distance anchors. Combining the LMC and MW distance anchors, E14 finds

|  |  |  |  |
| --- | --- | --- | --- |
|  | $H\_{0}=(73.9\pm 2.7)\thinspace\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1},\qquad{\rm LMC+MW},$ |  | (20) |

under the assumption that there is no metallicity variation of the
Cepheid period-luminosity relation. This is discrepant with
Eq. ([16](#S5.E16 "In 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) at about the $2.2\thinspace\sigma$ level. However,
neither the central value nor the error in Eq. ([20](#S5.E20 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) is
reliable. The MW Cepheid sample is small and dominated by short period
($<10\thinspace{\rm day}$) objects. The MW Cepheid sample therefore
has very little overlap
with the period range of SNe host galaxy Cepheids observed with
HST. As a result, the MW solutions for $H\_{0}$ are unstable (see
Appendix A of E14). The LMC solution is sensitive to the metallicity
dependence of the Cepheid period-luminosity relation which is poorly
constrained by the R11 data. Furthermore, the estimate in Eq. ([19](#S5.E19 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"))
is based on a differential measurement, comparing HST
photometry of Cepheids in NGC 4258 with those in SNe host
galaxies. It is therefore less prone to
photometric systematics, such as crowding corrections, than is the
LMC+MW estimate of Eq. ([20](#S5.E20 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")). It is for these reasons that we
have adopted the prior of Eq. ([19](#S5.E19 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) in preference
to using the LMC and MW distance anchors.2323
23
As this paper was
nearing completion, results from the Nearby Supernova Factory have been
presented that indicate a correlation between the peak brightness of Type Ia
SNe and the local star-formation rate ([Rigault et al. 2015](#bib.bib297)). These
authors argue that this correlation introduces a systematic bias of around
$1.8\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$ in the SNe/Cepheid distance
scale measurement of $H\_{0}$ . For example,
according to these authors, the estimate of Eq. ([19](#S5.E19 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) should be
lowered to $H\_{0}=(68.8\pm 3.3)\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$, a downward shift of approximately
$0.5\thinspace\sigma$. Clearly, further work needs to be done to assess the importance
of such a bias on the distance scale. It is ignored in the rest of this paper.

Direct measurements of the Hubble constant have a long and sometimes
contentious history ([Tammann et al. 2008](#bib.bib336), see, e.g.,). The controversy
continues to this day and in the literature one can find “high” values,
e.g., $H\_{0}=(74.3\pm 2.6)\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$ ([Freedman et al. 2012](#bib.bib127)), and “low” values,
e.g., $H\_{0}=(63.7\pm 2.3)\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$ ([Tammann & Reindl 2013](#bib.bib335)).
The key point that we wish to make is that
the Planck-only estimates of Eqs. ([10](#S5.E10 "In 5.1.1 The Planck lensing likelihood ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) and ([16](#S5.E16 "In 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")), and
the Planck+BAO estimate of Eq. ([17](#S5.E17 "In 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) all have small errors and
are consistent. If a persuasive case can be made that a direct
measurement of $H\_{0}$ conflicts with these estimates, then this will
be strong evidence for additional physics beyond the base $\rm{\Lambda CDM}$ model.

Finally, we note that in a recent analysis [Bennett et al. (2014)](#bib.bib38) derive a
“concordance” value of $H\_{0}=(69.6\pm 0.7)\thinspace\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$ for base $\rm{\Lambda CDM}$ by
combining WMAP9+SPT+ACT+BAO with a slightly revised version of the R11
$H\_{0}$ value, $(73.0\pm 2.4)\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$. The [Bennett et al. (2014)](#bib.bib38) central
value for $H\_{0}$ differs from the Planck value of Eq. ([17](#S5.E17 "In 5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) by
nearly $3\thinspace\%$ (or $2.5\thinspace\sigma$). The reason for this difference is that the
Planck data are in tension with the [Story et al. (2013)](#bib.bib329) SPT data
(as discussed in Appendix B of [258](#bib.bib258);
note that the tension is increased with the Planck full mission data) and
with the revised R11 $H\_{0}$ determination. Both tensions drive the
[Bennett et al. (2014)](#bib.bib38) value of $H\_{0}$ away from the Planck solution.

### 5.5 Additional data

#### 5.5.1 Redshift space distortions

Transverse versus line-of-sight anisotropies in the redshift-space clustering
of galaxies induced by peculiar motions can, potentially, provide a
powerful way of constraining the growth rate of structure
([Percival & White 2009](#bib.bib252), e.g.,). A number of studies of redshift-space
distortions (RSD) have been conducted to measure the parameter combination
$f\sigma\_{8}(z)$, where for models with scale-independent growth

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f(z)={d\ln D\over d\ln a},$ |  | (21) |

and $D$ is the linear growth rate of matter fluctuations. Notice that the
parameter combination $f\sigma\_{8}$ is insensitive to differences between the
clustering of galaxies and dark matter, i.e., to galaxy bias ([Song & Percival 2009](#bib.bib324)).
In the base $\rm{\Lambda CDM}$ cosmology, the
growth factor $f(z)$ is well approximated as $f(z)=\Omega\_{\mathrm{m}}(z)^{0.545}$.
More directly, in linear theory
the quadrupole of the redshift-space clustering anisotropy actually probes the
density-velocity correlation power spectrum, and we therefore define

|  |  |  |  |
| --- | --- | --- | --- |
|  | $f\sigma\_{8}(z)\equiv\frac{\left[\sigma\_{8}^{(vd)}(z)\right]^{2}}{\sigma\_{8}^{(dd)}(z)},$ |  | (22) |

as an approximate proxy for the quantity actually being measured.
Here $\sigma\_{8}^{(vd)}$ measures the smoothed density-velocity correlation and
is defined analogously to $\sigma\_{8}\equiv\sigma\_{8}^{(dd)}$, but using the
correlation power spectrum $P\_{vd}(k)$, where
$v=-\nabla\cdot\mathbf{v}\_{\rm N}/H$ and $\mathbf{v}\_{\rm N}$ is the
Newtonian-gauge (peculiar) velocity of the baryons and dark matter, and $d$
is the total matter density perturbation.
This definition assumes that the observed galaxies follow the flow of the cold
matter, not including massive neutrino velocity effects. For models close to
$\rm{\Lambda CDM}$, where the growth is nearly scale independent, it is equivalent
to defining $f\sigma\_{8}$ in terms of the growth of the baryon+CDM density
perturbations (excluding neutrinos).

Figure 16: Constraints on the growth rate of fluctuations from various redshift
surveys in the base $\rm{\Lambda CDM}$ model: green star
([Beutler et al. 2012](#bib.bib47), 6dFGRS, ); purple square
([Howlett et al. 2015](#bib.bib173), SDSS MGS, ); cyan cross ([Oka et al. 2014](#bib.bib239), SDSS LRG, );
red triangle ([Gil-Marín et al. 2015](#bib.bib143), BOSS LOWZ survey,);
large red circle ([Samushia et al. 2014](#bib.bib304), BOSS CMASS, as analysed by);
blue circles ([Blake et al. 2012](#bib.bib55), WiggleZ,);
and green diamond ([de la Torre et al. 2013](#bib.bib96), VIPERS,). The points with dashed
red error bars correspond to alternative analyses of BOSS CMASS from
[Beutler et al. (2014, small circle, offset for clarity)](#bib.bib48) and
[Chuang et al. (2013, small square)](#bib.bib83). Of the BOSS CMASS points, two are based on
the same DR11 data set ([Samushia et al. 2014](#bib.bib304); [Beutler et al. 2014](#bib.bib48)), while the third
is based on the more recent DR12 ([Chuang et al. 2013](#bib.bib83)), and are therefore not
independent.
The grey bands show the range allowed by Planck TT+lowP+lensing in the base
$\rm{\Lambda CDM}$ model. Where available (for SDSS MGS and BOSS), we have plotted
conditional constraints on $f\sigma\_{8}$
assuming a Planck $\rm{\Lambda CDM}$ background cosmology. The WiggleZ points are plotted conditional on the mean Planck cosmology prediction for $F\_{\rm AP}$ (evaluated using the covariance between
$f\sigma\_{8}$ and $F\_{\rm AP}$ given in [Blake et al. 2012](#bib.bib55)).
The 6dFGS point is at sufficiently low redshift that it is insensitive to the
cosmology.

The use of RSD as a measure of the growth of structure is still under
active development and is considerably more difficult than measuring
the positions of BAO features. Firstly, adopting the wrong fiducial
cosmology can induce an anisotropy in the clustering of galaxies, via the
Alcock-Paczynski (AP) effect, which is strongly degenerate
with the anisotropy induced by peculiar motions. Secondly, much of the
RSD signal currently comes from scales where nonlinear effects and
galaxy bias are significant and must be accurately modelled in
order to relate the density and velocity fields ([Bianchi et al. 2012](#bib.bib52); [Okumura et al. 2012](#bib.bib240); [Reid et al. 2014](#bib.bib292); [White et al. 2015](#bib.bib348), see,
e.g., the discussions in).

Current constraints,2424
24
The constraint
of [Chuang et al. (2013)](#bib.bib83) plotted in the original version of this paper was
subsequently shown to be in error. We therefore now show updated
BOSS data points for DR12 from [Chuang et al. (2013, for CMASS)](#bib.bib83) and
[Gil-Marín et al. (2015, for LOWZ)](#bib.bib143).
assuming a Planck base $\rm{\Lambda CDM}$ model, are shown in
Fig. [16](#S5.F16 "Figure 16 ‣ 5.5.1 Redshift space distortions ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"). Neglecting the AP effect can lead to biased measurements
of $f\sigma\_{8}$ if the assumed cosmology differs, and to significant
underestimation of
the errors ([Howlett et al. 2015](#bib.bib173)). The analyses summarized in Fig. [16](#S5.F16 "Figure 16 ‣ 5.5.1 Redshift space distortions ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")
solve simultaneously for RSD and the AP effect, except for the
6dFGS point (which is insensitive to cosmology) and the VIPERS point (which has a large error).
The grey bands show the range allowed by Planck TT+lowP+lensing in the base $\rm{\Lambda CDM}$ model, and are consistent with the RSD data.
The tightest constraints on $f\sigma\_{8}$ in this figure come from the BOSS
CMASS-DR11 analyses of [Beutler et al. (2014)](#bib.bib48) and [Samushia et al. (2014)](#bib.bib304). The
[Beutler et al. (2014)](#bib.bib48) analysis is performed in Fourier space and shows a
small bias in $f\sigma\_{8}$ compared to numerical simulations when
fitting over the wavenumber range 0.01–$0.20\thinspace h{\rm Mpc}^{-1}$. The
[Samushia et al. (2014)](#bib.bib304) analysis is performed in configuration space and shows
no evidence of biases when compared to numerical simulations.
The updated DR12 CMASS result from [Chuang et al. (2013)](#bib.bib83) marginalizes
over a polynomial model for systematic errors in the correlation function
monopole, and is consistent with these and the Planck constraints, with a
somewhat larger error bar.

Figure 17: 68 % and 95 % contours in the $f\sigma\_{8}$–$F\_{\rm AP}$ plane
(marginalizing over $D\_{\rm v}/r\_{\rm s}$)
for the CMASS-DR11 sample as analysed by [Samushia et al. (2014, solid, our defult)](#bib.bib304),
and [Beutler et al. (2014, dotted)](#bib.bib48). The green contours
show the constraint from Planck TT+lowP+lensing in the base $\rm{\Lambda CDM}$ model.

The [Samushia et al. (2014)](#bib.bib304) results are expressed as a $3\times 3$ covariance
matrix for the three parameters $D\_{\rm V}/r\_{\rm drag}$, $F\_{\rm AP}$ and $f\sigma\_{8}$,
evaluated at an effective redshift of $z\_{\rm eff}=0.57$, where $F\_{\rm AP}$ is
the “Alcock-Paczynski” parameter

|  |  |  |  |
| --- | --- | --- | --- |
|  | $F\_{\rm AP}(z)=(1+z)D\_{\rm A}{H(z)\over c}.$ |  | (23) |

The principal degeneracy is between $f\sigma\_{8}$ and $F\_{\rm AP}$ and is
illustrated in Fig. [17](#S5.F17 "Figure 17 ‣ 5.5.1 Redshift space distortions ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"), compared to the constraint from
Planck TT+lowP+lensing for the base $\rm{\Lambda CDM}$ cosmology. The Planck results sit
slightly high but overlap the $68\thinspace\%$ contour from [Samushia et al. (2014)](#bib.bib304).
The Planck result lies about $1.5\thinspace\sigma$ higher than the [Beutler et al. (2014)](#bib.bib48)
analysis of the BOSS CMASS sample.

RSD measurements are not used in combination with Planck in this paper.
However, in the companion paper
exploring dark energy and modified gravity ([Planck Collaboration
XIV 2016](#bib.bib275)), the
RSD/BAO measurements of [Samushia et al. (2014)](#bib.bib304) are used together with Planck.
Where this is done, we exclude the [Anderson et al. (2014)](#bib.bib18) BOSS-CMASS
results from the BAO likelihood. Since [Samushia et al. (2014)](#bib.bib304) do not apply a
density field reconstruction in their analysis,
the BAO constraints from BOSS-CMASS are then slightly weaker, though consistent,
with those of [Anderson et al. (2014)](#bib.bib18).

#### 5.5.2 Weak gravitational lensing

Weak gravitational lensing offers a potentially powerful technique for
measuring the amplitude of the matter fluctuation spectrum at low redshifts.
Currently, the largest weak lensing data set is provided by the CFHTLenS survey ([Heymans et al. 2012](#bib.bib166); [Erben et al. 2013](#bib.bib112)). The first science results
from this survey appeared shortly before the completion of [258](#bib.bib258) and it
was not possible to do much more than offer a cursory comparison with the
Planck 2013 results. As reported in [258](#bib.bib258), at face value the results
from CFHTLenS appeared to be in tension with the Planck 2013 base $\rm{\Lambda CDM}$ cosmology at about the 2–$3\thinspace\sigma$ level. Since neither the CFHTLenS results nor
the 2015 Planck results have changed significantly from those in [258](#bib.bib258),
it is worth discussing this discrepancy in more detail in this paper.

Weak lensing data can be analysed in various ways. For example, one can
compute two correlation functions from the ellipticities of pairs of images
separated by angle $\theta$,which are related to the convergence power
spectrum $P^{\kappa}(\ell)$ of the survey at multipole $\ell$ via

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\xi\_{\pm}(\theta)={1\over 2\pi}\int d\ell\ell P^{\kappa}(\ell)J\_{\pm}(\ell\theta),$ |  | (24) |

where the Bessel functions in ([24](#S5.E24 "In 5.5.2 Weak gravitational lensing ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) are $J\_{+}\equiv J\_{0}$ and
$J\_{-}\equiv J\_{4}$ ([Bartelmann & Schneider 2001](#bib.bib28), see, e.g.,). Much of the information
from the CFHTLenS survey correlation function analyses comes from wavenumbers
at which the matter power spectrum is strongly nonlinear, complicating any
direct comparison with Planck.

This can be circumventing by performing a 3D spherical harmonic
analysis of the shear field, allowing one to impose lower limits on the
wavenumbers that contribute to a weak lensing likelihood. This has
been done by [Kitching et al. (2014)](#bib.bib196). Including only wavenumbers with
$k\leq 1.5\thinspace h{\rm Mpc}^{-1}$, [Kitching et al. (2014)](#bib.bib196)
find constraints in the $\sigma\_{8}$–$\Omega\_{\mathrm{m}}$ plane that are consistent with the
results from Planck. However, by excluding modes with higher wavenumbers,
the lensing constraints are weakened. When they increase the wavenumber
cut-off to $k=5\thinspace h{\rm Mpc}^{-1}$ some tension with Planck begins to emerge
(which these authors argue may be an indication of the effects of baryonic
feedback in suppressing the matter power spectrum at small scales).
The large-scale properties of CFHTLenS therefore seem broadly consistent
with Planck and it is only as CFHTLenS probes higher wavenumbers,
particular in the 2D and tomographic correlation function analyses
([Heymans et al. 2013](#bib.bib165); [Kilbinger et al. 2013](#bib.bib195); [Fu et al. 2014](#bib.bib129); [MacCrann et al. 2015](#bib.bib220)), that
apparently strong discrepancies with Planck appear.

Figure 18: Samples in the $\sigma\_{8}$–$\Omega\_{\mathrm{m}}$ plane from the H13 CFHTLenS data
(with angular cuts as discussed in the text), coloured by the value of the
Hubble parameter, compared to the joint constraints when the lensing data are
combined with BAO (blue), and BAO with the CMB acoustic scale parameter fixed
to $\theta\_{\rm MC}=1.0408$ (green). For comparison, the Planck TT+lowP constraint
contours are shown in black. The grey bands show the constraint from Planck CMB lensing. We impose a weak prior on the primoridal
amplitude, $2<\ln(10^{10}A\_{\rm s})<4$, which has some impact on the
distribution of CFHTLenS-only samples.

The situation is summarized in Fig. [18](#S5.F18 "Figure 18 ‣ 5.5.2 Weak gravitational lensing ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"). The sample points show
parameter values in the $\sigma\_{8}$–$\Omega\_{\mathrm{m}}$ plane for the $\rm{\Lambda CDM}$ base model,
computed from the [Heymans et al. (2013, hereafter H13)](#bib.bib165) tomographic
measurements of $\xi\_{\pm}$. These data consist of correlation function
measurements in six photometric redshift bins extending over the
redshift range 0.2–1.3. We use the blue galaxy sample, since H13
find that this sample shows no evidence for intrinsic galaxy
alignments (simplifying the comparison with theory) and we apply the
“conservative” cuts of H13, intended to reduce sensitivity to the
nonlinear part of the power spectrum; these cuts eliminate measurements
with $\theta<3^{\prime}$ for any redshift combination that involves the
lowest two redshift bins. Here we have used the
halofit prescription of [Takahashi et al. (2012)](#bib.bib334) to model the
nonlinear power spectrum, but do not include any model of baryon feedback
or intrinsic alignments. For the lensing-only constraint we also impose
additional priors in a similar way to the CMB lensing analysis
described in [Planck Collaboration
XV (2016)](#bib.bib276), i.e., Gaussian priors
$\Omega\_{\mathrm{b}}h^{2}=0.0223\pm 0.0009$ and $n\_{\rm s}=0.96\pm 0.02$, where the exact values
(chosen to span reasonable ranges given CMB data) have little impact on the results. The sample
range shown also restricts the Hubble parameter to $0.2<h<1$; note that when
comparing with constraint contours, the location of the contours can change
significantly depending on the $H\_{0}$ prior range assumed.
We also use a weak prior on the primoridal amplitude,
$2<\ln(10^{10}A\_{\rm s})<4$,
which shows up the strong correlation between $\Omega\_{\mathrm{m}}$–$\sigma\_{8}$–$H\_{0}$ in
the region of parameter space relevant for comparison with Planck.
In Fig. [18](#S5.F18 "Figure 18 ‣ 5.5.2 Weak gravitational lensing ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") we only show lensing contours after the samples have
been projected into the space allowed by the BAO data (blue contours), or also
additionally restricting to the reduced space where $\theta\_{\rm MC}$ is fixed to the
Planck value, which is accurately measured.
The black contours show the constraints from Planck TT+lowP.

The lensing samples just overlap with Planck, and superficially one might
conclude that the two data sets are consistent. However, the weak lensing
constraints approximately define a 1D degeneracy in the
3D $\Omega\_{\mathrm{m}}$–$\sigma\_{8}$–$H\_{0}$ space, so consistency of the Hubble
parameter at each point in the projected space must also be considered
([Planck Collaboration
XV 2016](#bib.bib276), see appendix E1 of).
Comparing the contours in Fig. [18](#S5.F18 "Figure 18 ‣ 5.5.2 Weak gravitational lensing ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") (the regions
where the weak lensing constraints are consistent with BAO observations)
the CFHTLenS data favour a lower value of $\sigma\_{8}$ than the Planck data (and much of the area of the blue contours also has higher $\Omega\_{\mathrm{m}}$).
However, even with the conservative angular cuts
applied by H13, the weak lensing constraints depend on the
nonlinear model of the power spectrum and on the possible
influence of baryonic feedback in reshaping the matter power spectrum at
small spatial scales ([Harnois-Déraps et al. 2015](#bib.bib160); [MacCrann et al. 2015](#bib.bib220)). The
importance of these effects can be reduced by imposing even more conservative
angular cuts on $\xi\_{\pm}$, but of course, this weakens the statistical
power of the weak lensing data. The CFHTLenS data are not used in
combination with Planck in this paper
(apart from specific cases in Sects. [6.3](#S6.SS3 "6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")
and [6.4.4](#S6.SS4.SSS4 "6.4.4 Neutrino models and tension with external data ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) and, in any case, would have
little impact on most of the extended $\rm{\Lambda CDM}$ constraints discussed in
Sect. [6](#S6 "6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). Weak lensing can, however, provide important constraints
on dark energy and modified gravity. The CFHTLenS data are therefore
used in combination with Planck in the companion paper ([Planck Collaboration
XIV 2016](#bib.bib275)),
which explores several halofit prescriptions and the impact of
applying more conservative angular cuts to the H13 measurements.

#### 5.5.3 Planck cluster counts

In 2013 we noted a possible tension between our primary CMB
constraints and those from the Planck SZ cluster counts, with the
clusters preferring lower values of $\sigma\_{8}$ in the base
$\Lambda$CDM model in some analyses ([Planck Collaboration
XX 2014](#bib.bib260)). The
comparison is interesting because the cluster counts directly measure
$\sigma\_{8}$ at low redshift; any tension could signal the need for
extensions to the base model, such as non-minimal neutrino mass
(though see Sect. [6.4](#S6.SS4 "6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")). However, limited knowledge of
the scaling relation between SZ signal and mass have hampered the
interpretation of this result.

With the full mission data we have created a larger catalogue of SZ
clusters with a more accurate characterization of its
completeness ([Planck Collaboration
XXIV 2016](#bib.bib280)). By fitting the counts in
redshift and signal-to-noise, we are able to simultaneously constrain
the slope of the SZ signal–mass scaling relation and the cosmological
parameters. A major uncertainty, however, remains the overall mass
calibration, which in [Planck Collaboration
XX (2014)](#bib.bib260) we quantified with a “hydrostatic
bias” parameter, $(1-b)$, with a fiducial value of $0.8$ and a range
$0.7<(1-b)<1$ (consistent with some other studies, e.g.,
[Simet et al. 2015](#bib.bib318)). In the base $\rm{\Lambda CDM}$ model, the primary CMB
constraints prefer a normalization below the lower end of this range,
$(1-b)\approx 0.6$. The recent, empirical normalization of the
relation by the Weighing the Giants lensing
programme ([von der Linden et al. 2014](#bib.bib346), WtG;) gives $0.69\pm 0.07$ for the 22
clusters in common with the Planck cluster sample. This calibration
reduces the tension with the primary CMB constraints in base $\rm{\Lambda CDM}$.
In contrast, correlating the entire
Planck 2015 SZ cosmology sample with Planck CMB lensing gives
$1/(1-b)=1.0\pm 0.2$ ([Planck Collaboration
XXIV 2016](#bib.bib280)), toward the upper end of the range
adopted in [Planck Collaboration
XX (2014)](#bib.bib260), although with a large uncertainty.
An alternative lensing calibration analysis by the Canadian Cluster Comparison
Project, which uses 37 clusters in common with the Planck cluster
sample ([Hoekstra et al. 2015](#bib.bib171)) finds
$(1-b)=0.76\pm 0.05\ ({\rm stat.})\pm 0.06\ ({\rm syst.})$, which lies between
the other two mass calibrations.
These calibrations are not yet definitive and the situation will continue to
evolve with improvements in mass measurements from larger samples of clusters.

A recent analysis of cluster counts for an X-ray-selected sample
(REFLEX II) shows some tension with the Planck base $\rm{\Lambda CDM}$ cosmology
([Böhringer et al. 2014](#bib.bib57)).
However, an analysis of cluster counts of X-ray-selected clusters by the WtG
collaboration, incorporating the WtG weak lensing mass calibration, finds
$\sigma\_{8}(\Omega\_{\rm m}/0.3)^{0.17}=0.81\pm 0.03$, in good agreement
with the Planck CMB results for base $\rm{\Lambda CDM}$ ([Mantz et al. 2015](#bib.bib224)).
This raises the possibility that there may be systematic biases in the assumed
scaling relations for SZ-selected clusters compared to X-ray-selected clusters
(in addition to a possible mass calibration bias).
[Mantz et al. (2015)](#bib.bib224) give a brief review of recent determinations of
$\sigma\_{8}$ from X-ray, optically-selected, and SZ-selected samples,
to which we refer the reader.
More detailed discussion of constraints from combining Planck cluster counts
with primary CMB anisotropies and other data sets can be found in
[Planck Collaboration
XXIV (2016)](#bib.bib280).

### 5.6 Cosmic concordance?

Figure 19: 
Marginalized constraints on parameters of the base $\rm{\Lambda CDM}$ model without
low-$\ell$ $E$-mode polarization (filled contours), compared to the
constraints from using low-$\ell$ $E$-mode polarization (unfilled contours)
or assuming a strong prior that reionization was at $z\_{\text{re}}=7\pm 1$ and
$z\_{\text{re}}>6.5$ (“reion prior,” dashed contours). Grey bands show the
constraint from CMB lensing alone.

Table [4](#S5.T4 "Table 4 ‣ 5.6 Cosmic concordance? ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") summarizes the cosmological parameters in the base
$\rm{\Lambda CDM}$ for Planck combined with
various data sets discussed in this section. Although we have seen from the
survey presented above that base $\rm{\Lambda CDM}$ is consistent with a wide range of
cosmological data, there are two areas of tension:

1. 1.

   the Ly$\alpha$ BAO measurements at high redshift (Sect. [5.2](#S5.SS2 "5.2 Baryon acoustic oscillations ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"));
2. 2.

   the Planck CMB estimate of the amplitude of the fluctuation spectrum
   and the lower values inferred from weak lensing, and (possibly)
   cluster counts and
   redshift space distortions (Sect. [5.5](#S5.SS5 "5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")).

The first point to note is that the astrophysical data in areas (1) and (2)
are complex and more difficult to interpret than most of the astrophysical
data sets discussed in this section. The interpretation of the data in
area (2) depends on nonlinear modelling of the power spectrum, and in the
case of clusters and weak lensing, on
uncertain baryonic physics. Understanding these effects more accurately
sets a direction for future research.

It is, however, worth reviewing our findings on $\sigma\_{8}$ and $\Omega\_{\mathrm{m}}$ from
Planck assuming base $\rm{\Lambda CDM}$. These are summarized in
Fig. [19](#S5.F19 "Figure 19 ‣ 5.6 Cosmic concordance? ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") and the following constraints:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\sigma\_{8}$ | $\displaystyle=$ | $\displaystyle 0.829\pm 0.014,\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP};$ |  | (25a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\sigma\_{8}$ | $\displaystyle=$ | $\displaystyle 0.815\pm 0.009,\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP}{+}{\rm lensing};$ |  | (25b) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\sigma\_{8}$ | $\displaystyle=$ | $\displaystyle 0.810\pm 0.006,\quad\text{{Planck}\ TT+{\rm lensing}+$z\_{\text{re}}$}.$ |  | (25c) |

The last line imposes a Gaussian prior of $z\_{\text{re}}=7\pm 1$ with a limit
$z\_{\text{re}}>6.5$ on the reionization redshift in place of the reionization
constraints from the lowP likelihood. As discussed in Sect. [3.4](#S3.SS4 "3.4 Constraints on the reionization optical depth parameter 𝜏 ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"),
such a low redshift of reionization is close to
the lowest plausible value allowed by
astrophysical data (though such low values are
not favoured by either the WMAP or LFI polarization data). The addition of Planck lensing
data pulls $\sigma\_{8}$ down by about $1\thinspace\sigma$ from the Planck TT+lowP value,
so Eq. ([25c](#S5.E3 "In 5.6 Cosmic concordance? ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) is the lowest possible range allowed by the Planck CMB data. As shown in Fig. [19](#S5.F19 "Figure 19 ‣ 5.6 Cosmic concordance? ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"), adding the $TE$
and $EE$ spectra at high multipoles does not change the Planck constraints. If a convincing case can be made that astrophysical data
conflict with the estimate of Eq. ([25c](#S5.E3 "In 5.6 Cosmic concordance? ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")), then this will be powerful
evidence for new physics beyond base $\rm{\Lambda CDM}$ with minimal-mass neutrinos.

A number of authors have interpreted the discrepancies in area (2) as
evidence for new physics in the neutrino sector
([Planck Collaboration
XX 2014](#bib.bib260); [Hamann & Hasenkamp 2013](#bib.bib155); [Battye & Moss 2014](#bib.bib32); [Battye et al. 2015](#bib.bib31); [Wyman et al. 2014](#bib.bib352); [Beutler et al. 2014](#bib.bib49), e.g.,).
They use various data combinations together with Planck to argue for
massive neutrinos with mass $\sum m\_{\nu}\approx 0.3\thinspace{\rm eV}$ or for a single
sterile neutrino with somewhat higher mass. The problem here is that
any evidence for new neutrino physics is driven mainly by the
additional astrophysical data, not by Planck CMB anisotropy measurements.
In addition, the external data sets are
not entirely consistent, so tensions remain. As discussed in [258](#bib.bib258)
([Leistedt et al. 2014](#bib.bib204); [Battye et al. 2015](#bib.bib31), see also) Planck data usually
favour base $\rm{\Lambda CDM}$ over extended models. Implications of the Planck 2015
data for neutrino physics are discussed in Sect. [6.4](#S6.SS4 "6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") and
tensions between Planck and external data in various extended neutrino
models are discussed further in Sect. [6.4.4](#S6.SS4.SSS4 "6.4.4 Neutrino models and tension with external data ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters").

As mentioned above, we do not use RSD or galaxy weak lensing
measurements for combined constraints in this paper (apart from
Sects. [6.3](#S6.SS3 "6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") and [6.4.4](#S6.SS4.SSS4 "6.4.4 Neutrino models and tension with external data ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"), where we use the CFHTLenS data) .
They are, however, used in the paper
exploring constraints on dark energy and modified gravity
([Planck Collaboration
XIV 2016](#bib.bib275)). For some models discussed in that paper, the
combination of Planck, RSD, and weak lensing data does prefer
extensions to the base $\rm{\Lambda CDM}$ cosmology.

Table 4: Parameter $68\thinspace\%$ confidence limits for the base $\rm{\Lambda CDM}$ model from
Planck CMB power spectra, in combination with lensing reconstruction
(“lensing”) and external data (“ext”, BAO+JLA+$H\_{0}$).
While we see no evidence that systematic effects in polarization are
biasing parameters in the base $\rm{\Lambda CDM}$ model, a conservative choice would be to
use the parameter values listed in Column 3 (i.e., for TT+lowP+lensing).
Nuisance parameters are not listed here for brevity, but can be
found in the extensive tables on the Planck Legacy Archive,
<http://pla.esac.esa.int/pla>; however,
the last three parameters listed here give a summary measure of the total
foreground amplitude (in $\thinspace\mu$K2) at $\ell=2000$ for the three high-$\ell$
temperature power spectra used by the likelihood. In all cases the helium
mass fraction used is predicted by BBN from the baryon abundance
(posterior mean $Y\_{\text{P}}\approx 0.2453$, with theoretical uncertainties in the
BBN predictions dominating over the Planck error on $\Omega\_{\mathrm{b}}h^{2}$).
The Hubble constant is given in units of ${\rm km\thinspace s}^{-1}\thinspace{\rm Mpc}^{-1}$,
while $r\_{\ast}$ is in Mpc and wavenumbers are in ${\rm Mpc}^{-1}$.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | |  | TT+lowP | TT+lowP+lensing | TT+lowP+lensing+ext | TT,TE,EE+lowP | TT,TE,EE+lowP+lensing | TT,TE,EE+lowP+lensing+ext | | Parameter | 68 % limits | 68 % limits | 68 % limits | 68 % limits | 68 % limits | 68 % limits | | $\Omega\_{\mathrm{b}}h^{2}$. | $0.02222\pm 0.00023$ | $0.02226\pm 0.00023$ | $0.02227\pm 0.00020$ | $0.02225\pm 0.00016$ | $0.02226\pm 0.00016$ | $0.02230\pm 0.00014$ | | $\Omega\_{\mathrm{c}}h^{2}$. | $0.1197\pm 0.0022$ | $0.1186\pm 0.0020$ | $0.1184\pm 0.0012$ | $0.1198\pm 0.0015$ | $0.1193\pm 0.0014$ | $0.1188\pm 0.0010$ | | $100\theta\_{\mathrm{MC}}$. | $1.04085\pm 0.00047$ | $1.04103\pm 0.00046$ | $1.04106\pm 0.00041$ | $1.04077\pm 0.00032$ | $1.04087\pm 0.00032$ | $1.04093\pm 0.00030$ | | $\tau$. | $0.078\pm 0.019$ | $0.066\pm 0.016$ | $0.067\pm 0.013$ | $0.079\pm 0.017$ | $0.063\pm 0.014$ | $0.066\pm 0.012$ | | $\ln(10^{10}A\_{\mathrm{s}})$. | $3.089\pm 0.036$ | $3.062\pm 0.029$ | $3.064\pm 0.024$ | $3.094\pm 0.034$ | $3.059\pm 0.025$ | $3.064\pm 0.023$ | | $n\_{\mathrm{s}}$. | $0.9655\pm 0.0062$ | $0.9677\pm 0.0060$ | $0.9681\pm 0.0044$ | $0.9645\pm 0.0049$ | $0.9653\pm 0.0048$ | $0.9667\pm 0.0040$ | | $H\_{0}$. | $67.31\pm 0.96\kern 3.98613pt$ | $67.81\pm 0.92\kern 3.98613pt$ | $67.90\pm 0.55\kern 3.98613pt$ | $67.27\pm 0.66\kern 3.98613pt$ | $67.51\pm 0.64\kern 3.98613pt$ | $67.74\pm 0.46\kern 3.98613pt$ | | $\Omega\_{\Lambda}$. | $0.685\pm 0.013$ | $0.692\pm 0.012$ | $0.6935\pm 0.0072$ | $0.6844\pm 0.0091$ | $0.6879\pm 0.0087$ | $0.6911\pm 0.0062$ | | $\Omega\_{\mathrm{m}}$. | $0.315\pm 0.013$ | $0.308\pm 0.012$ | $0.3065\pm 0.0072$ | $0.3156\pm 0.0091$ | $0.3121\pm 0.0087$ | $0.3089\pm 0.0062$ | | $\Omega\_{\mathrm{m}}h^{2}$. | $0.1426\pm 0.0020$ | $0.1415\pm 0.0019$ | $0.1413\pm 0.0011$ | $0.1427\pm 0.0014$ | $0.1422\pm 0.0013$ | $0.14170\pm 0.00097$ | | $\Omega\_{\mathrm{m}}h^{3}$. | $0.09597\pm 0.00045$ | $0.09591\pm 0.00045$ | $0.09593\pm 0.00045$ | $0.09601\pm 0.00029$ | $0.09596\pm 0.00030$ | $0.09598\pm 0.00029$ | | $\sigma\_{8}$. | $0.829\pm 0.014$ | $0.8149\pm 0.0093$ | $0.8154\pm 0.0090$ | $0.831\pm 0.013$ | $0.8150\pm 0.0087$ | $0.8159\pm 0.0086$ | | $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.5}$. | $0.466\pm 0.013$ | $0.4521\pm 0.0088$ | $0.4514\pm 0.0066$ | $0.4668\pm 0.0098$ | $0.4553\pm 0.0068$ | $0.4535\pm 0.0059$ | | $\sigma\_{8}\Omega\_{\mathrm{m}}^{0.25}$. | $0.621\pm 0.013$ | $0.6069\pm 0.0076$ | $0.6066\pm 0.0070$ | $0.623\pm 0.011$ | $0.6091\pm 0.0067$ | $0.6083\pm 0.0066$ | | $z\_{\mathrm{re}}$. | $9.9^{+1.8}\_{-1.6}$ | $8.8^{+1.7}\_{-1.4}$ | $8.9^{+1.3}\_{-1.2}$ | $10.0^{+1.7}\_{-1.5}$ | $8.5^{+1.4}\_{-1.2}$ | $8.8^{+1.2}\_{-1.1}$ | | $10^{9}A\_{\mathrm{s}}$. | $2.198^{+0.076}\_{-0.085}$ | $2.139\pm 0.063$ | $2.143\pm 0.051$ | $2.207\pm 0.074$ | $2.130\pm 0.053$ | $2.142\pm 0.049$ | | $10^{9}A\_{\mathrm{s}}e^{-2\tau}$. | $1.880\pm 0.014$ | $1.874\pm 0.013$ | $1.873\pm 0.011$ | $1.882\pm 0.012$ | $1.878\pm 0.011$ | $1.876\pm 0.011$ | | $\mathrm{Age}/\mathrm{Gyr}$. | $13.813\pm 0.038\kern 3.98613pt$ | $13.799\pm 0.038\kern 3.98613pt$ | $13.796\pm 0.029\kern 3.98613pt$ | $13.813\pm 0.026\kern 3.98613pt$ | $13.807\pm 0.026\kern 3.98613pt$ | $13.799\pm 0.021\kern 3.98613pt$ | | $z\_{\ast}$. | $1090.09\pm 0.42\kern 3.98613pt\kern 3.98613pt\kern 3.98613pt$ | $1089.94\pm 0.42\kern 3.98613pt\kern 3.98613pt\kern 3.98613pt$ | $1089.90\pm 0.30\kern 3.98613pt\kern 3.98613pt\kern 3.98613pt$ | $1090.06\pm 0.30\kern 3.98613pt\kern 3.98613pt\kern 3.98613pt$ | $1090.00\pm 0.29\kern 3.98613pt\kern 3.98613pt\kern 3.98613pt$ | $1089.90\pm 0.23\kern 3.98613pt\kern 3.98613pt\kern 3.98613pt$ | | $r\_{\ast}$. | $144.61\pm 0.49\kern 3.98613pt\kern 3.98613pt$ | $144.89\pm 0.44\kern 3.98613pt\kern 3.98613pt$ | $144.93\pm 0.30\kern 3.98613pt\kern 3.98613pt$ | $144.57\pm 0.32\kern 3.98613pt\kern 3.98613pt$ | $144.71\pm 0.31\kern 3.98613pt\kern 3.98613pt$ | $144.81\pm 0.24\kern 3.98613pt\kern 3.98613pt$ | | $100\theta\_{\ast}$. | $1.04105\pm 0.00046$ | $1.04122\pm 0.00045$ | $1.04126\pm 0.00041$ | $1.04096\pm 0.00032$ | $1.04106\pm 0.00031$ | $1.04112\pm 0.00029$ | | $z\_{\mathrm{drag}}$. | $1059.57\pm 0.46\kern 3.98613pt\kern 3.98613pt\kern 3.98613pt$ | $1059.57\pm 0.47\kern 3.98613pt\kern 3.98613pt\kern 3.98613pt$ | $1059.60\pm 0.44\kern 3.98613pt\kern 3.98613pt\kern 3.98613pt$ | $1059.65\pm 0.31\kern 3.98613pt\kern 3.98613pt\kern 3.98613pt$ | $1059.62\pm 0.31\kern 3.98613pt\kern 3.98613pt\kern 3.98613pt$ | $1059.68\pm 0.29\kern 3.98613pt\kern 3.98613pt\kern 3.98613pt$ | | $r\_{\mathrm{drag}}$. | $147.33\pm 0.49\kern 3.98613pt\kern 3.98613pt$ | $147.60\pm 0.43\kern 3.98613pt\kern 3.98613pt$ | $147.63\pm 0.32\kern 3.98613pt\kern 3.98613pt$ | $147.27\pm 0.31\kern 3.98613pt\kern 3.98613pt$ | $147.41\pm 0.30\kern 3.98613pt\kern 3.98613pt$ | $147.50\pm 0.24\kern 3.98613pt\kern 3.98613pt$ | | $k\_{\mathrm{D}}$. | $0.14050\pm 0.00052$ | $0.14024\pm 0.00047$ | $0.14022\pm 0.00042$ | $0.14059\pm 0.00032$ | $0.14044\pm 0.00032$ | $0.14038\pm 0.00029$ | | $z\_{\mathrm{eq}}$. | $3393\pm 49\kern 3.98613pt\kern 3.98613pt$ | $3365\pm 44\kern 3.98613pt\kern 3.98613pt$ | $3361\pm 27\kern 3.98613pt\kern 3.98613pt$ | $3395\pm 33\kern 3.98613pt\kern 3.98613pt$ | $3382\pm 32\kern 3.98613pt\kern 3.98613pt$ | $3371\pm 23\kern 3.98613pt\kern 3.98613pt$ | | $k\_{\rm{eq}}$. | $0.01035\pm 0.00015$ | $0.01027\pm 0.00014$ | $0.010258\pm 0.000083$ | $0.01036\pm 0.00010$ | $0.010322\pm 0.000096$ | $0.010288\pm 0.000071$ | | $100\theta\_{\rm{s,eq}}$. | $0.4502\pm 0.0047$ | $0.4529\pm 0.0044$ | $0.4533\pm 0.0026$ | $0.4499\pm 0.0032$ | $0.4512\pm 0.0031$ | $0.4523\pm 0.0023$ | | $f\_{2000}^{143}$. | $29.9\pm 2.9\kern 3.98613pt$ | $30.4\pm 2.9\kern 3.98613pt$ | $30.3\pm 2.8\kern 3.98613pt$ | $29.5\pm 2.7\kern 3.98613pt$ | $30.2\pm 2.7\kern 3.98613pt$ | $30.0\pm 2.7\kern 3.98613pt$ | | $f\_{2000}^{143\times 217}$. | $32.4\pm 2.1\kern 3.98613pt$ | $32.8\pm 2.1\kern 3.98613pt$ | $32.7\pm 2.0\kern 3.98613pt$ | $32.2\pm 1.9\kern 3.98613pt$ | $32.8\pm 1.9\kern 3.98613pt$ | $32.6\pm 1.9\kern 3.98613pt$ | | $f\_{2000}^{217}$. | $106.0\pm 2.0\kern 3.98613pt\kern 3.98613pt$ | $106.3\pm 2.0\kern 3.98613pt\kern 3.98613pt$ | $106.2\pm 2.0\kern 3.98613pt\kern 3.98613pt$ | $105.8\pm 1.9\kern 3.98613pt\kern 3.98613pt$ | $106.2\pm 1.9\kern 3.98613pt\kern 3.98613pt$ | $106.1\pm 1.8\kern 3.98613pt\kern 3.98613pt$ | |  |

## 6 Extensions to the base $\mathbf{\Lambda}$CDM model

Table 5: Constraints on 1-parameter extensions to the base $\rm{\Lambda CDM}$ model for
combinations of Planck power spectra, Planck lensing, and external data
(BAO+JLA+$H\_{0}$, denoted “ext”). All limits and confidence
regions quoted here are 95 %.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  |  |  |  |  | | --- | --- | --- | --- | --- | --- | --- | | Parameter | $\hfil\hskip 8.50012pt{\rm TT}\hskip 8.50012pt\hfil$ | $\hfil{\rm TT}{+}{\rm lensing}$ | $\hfil{\rm TT}{+}{\rm lensing}{+}{\rm ext}\hfil$ | $\hfil{\rm TT,TE,EE}\hfil$ | $\hfil{\rm TT,TE,EE}{+}{\rm lensing}\hfil$ | $\hfil{\rm TT,TE,EE}{+}{\rm lensing}{+}{\rm ext}$ | | $\Omega\_{K}$. | $-0.052^{+0.049}\_{-0.055}$ | $-0.005^{+0.016}\_{-0.017}$ | $-0.0001^{+0.0054}\_{-0.0052}$ | $-0.040^{+0.038}\_{-0.041}$ | $-0.004^{+0.015}\_{-0.015}$ | $0.0008^{+0.0040}\_{-0.0039}$ | | $\Sigma m\_{\nu}\thinspace[\mathrm{eV}]$. | $<0.715$ | $<0.675$ | $<0.234$ | $<0.492$ | $<0.589$ | $<0.194$ | | $N\_{\mathrm{eff}}$. | $3.13^{+0.64}\_{-0.63}$ | $3.13^{+0.62}\_{-0.61}$ | $3.15^{+0.41}\_{-0.40}$ | $2.99^{+0.41}\_{-0.39}$ | $2.94^{+0.38}\_{-0.38}$ | $3.04^{+0.33}\_{-0.33}$ | | $Y\_{\mathrm{P}}$. | $0.252^{+0.041}\_{-0.042}$ | $0.251^{+0.040}\_{-0.039}$ | $0.251^{+0.035}\_{-0.036}$ | $0.250^{+0.026}\_{-0.027}$ | $0.247^{+0.026}\_{-0.027}$ | $0.249^{+0.025}\_{-0.026}$ | | $\mathrm{d}n\_{\mathrm{s}}/\mathrm{d}\ln k$. | $-0.008^{+0.016}\_{-0.016}$ | $-0.003^{+0.015}\_{-0.015}$ | $-0.003^{+0.015}\_{-0.014}$ | $-0.006^{+0.014}\_{-0.014}$ | $-0.002^{+0.013}\_{-0.013}$ | $-0.002^{+0.013}\_{-0.013}$ | | $r\_{0.002}$. | $<0.103$ | $<0.114$ | $<0.114$ | $<0.0987$ | $<0.112$ | $<0.113$ | | $w$. | $-1.54^{+0.62}\_{-0.50}$ | $-1.41^{+0.64}\_{-0.56}$ | $-1.006^{+0.085}\_{-0.091}$ | $-1.55^{+0.58}\_{-0.48}$ | $-1.42^{+0.62}\_{-0.56}$ | $-1.019^{+0.075}\_{-0.080}$ | |  |

### 6.1 Grid of models

The full grid results are available online.2525
25
See the Planck Legacy
Archive, <http://www.cosmos.esa.int/web/planck/pla>, which
contains considerably more detailed information than presented
in this paper.
Figure [20](#S6.F20 "Figure 20 ‣ 6.1 Grid of models ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") and Table [5](#S6.T5 "Table 5 ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") summarize
the constraints on one-parameter extensions to base $\rm{\Lambda CDM}$. As in [258](#bib.bib258), we
find no strong evidence in favour of any of these
simple one-parameter extensions using Planck or Planck combined with BAO.
The entire grid has been run using both the Plik and CamSpec likelihoods.
As noted in Sect. [3](#S3 "3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"), the parameters derived from these two
$TT$ likelihoods agree to better than $0.5\thinspace\sigma$ for base $\rm{\Lambda CDM}$. This level
of agreement also holds for the extended models analysed in our grid.
In Sect. [3](#S3 "3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") we also pointed out that we have
definite evidence, by comparing spectra computed with different frequency
combinations, of residual systematics in the $TE$ and $EE$ spectra. These
systematics average down in the coadded $TE$ and $EE$ spectra, but the
remaining level of systematics in these coadded spectra are not yet well
quantified (though they are small). Thus, we urge the reader to treat
parameters computed from the TT,TE,EE likelihoods with some caution. In the
case of polarization, the agreement between the Plik and CamSpec $TE$
and $EE$ likelihoods is less good, with shifts in parameters of up
to $1.5\thinspace\sigma$ (though such large shifts are unusual). In general, the behaviour of the
TT,TE,EE likelihoods is as shown in Fig. [20](#S6.F20 "Figure 20 ‣ 6.1 Grid of models ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters").
For extended models, the addition of the Planck polarization
data at high multipoles reduces the errors on extended parameters compared
to the Planck temperature data and pulls the parameters towards those of
base $\rm{\Lambda CDM}$. A similar behaviour is seen if the Planck TT
(or Planck TT,TE,EE) data are combined with BAO.

The rest of this section discusses the grid results in more detail and
also reports results on some additional models (specifically dark matter
annihilation, tests of the recombination history, and cosmic defects) that
are not included in our grid.

Figure 20: 68 % and 95 % confidence regions on 1-parameter extensions of
the base $\rm{\Lambda CDM}$ model for Planck TT+lowP (grey), Planck TT,TE,EE+lowP (red),
and Planck TT,TE,EE+lowP+BAO (blue).
Horizontal dashed lines correspond to the parameter values assumed in the
base $\rm{\Lambda CDM}$ cosmology,
while vertical dashed lines show the mean posterior values in the base model
for Planck TT,TE,EE+lowP+BAO.

### 6.2 Early-Universe physics

Arguably the most important result from 2013 Planck analysis was the finding
that simple single-field inflationary models, with a tilted scalar
spectrum $n\_{\rm s}\approx 0.96$, provide a very good fit to the
Planck data. We found no evidence for a tensor component or running
of the scalar spectral index, no strong evidence for isocurvature
perturbations or features in the primordial power spectrum
([Planck Collaboration
XXII 2014](#bib.bib261)), and no evidence for non-Gaussianity
([Planck Collaboration
XXIV 2014](#bib.bib263)), cosmic strings or other topological defects
([Planck Collaboration
XXV 2014](#bib.bib264)). On large angular scales, the Planck data
showed some evidence for “anomalies” seen previously in the
WMAP data ([Bennett et al. 2011](#bib.bib37)). These include a dip in the power
spectrum in the multipole range $20\la\ell\la 30$ (see Fig. [1](#S3.F1 "Figure 1 ‣ (2) DetSets versus cross-surveys. ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")) and
some evidence for a departure from statistical isotropy on large angular
scales ([Planck Collaboration
XXIII 2014](#bib.bib262)). However, the statistical significance
of these anomalies is not high enough to provide compelling evidence
for new physics beyond simple single-field inflation.

Figure 21: 
Left: Constraints on the tensor-to-scalar ratio $r\_{0.002}$ in the
$\rm{\Lambda CDM}$ model, using Planck TT+lowP and Planck TT+lowP+lensing+BAO+JLA+$H\_{0}$
(red and blue, respectively) assuming negligible running and the inflationary
consistency relation. The result is model-dependent; for example, the grey
contours show how the results change if there were
additional relativistic degrees of freedom with $\Delta N\_{\rm eff}=0.39$
(disfavoured, but not excluded, by Planck).
Dotted lines show loci of approximately constant $e$-folding number $N$,
assuming simple $V\propto(\phi/m\_{\text{Pl}})^{p}$ single-field inflation. Solid lines
show the approximate $n\_{\rm s}$–$r$ relation for quadratic and linear
potentials, to first order in slow roll;
red lines show the approximate allowed range assuming $50<N<60$ and a power-law
potential for the duration of inflation.
The solid black line (corresponding to a linear potential) separates concave
and convex potentials.
Right: Equivalent constraints in the $\rm{\Lambda CDM}$ model when adding $B$-mode
polarization results corresponding to the default configuration of the
BICEP2/Keck Array+Planck (BKP) likelihood. These exclude the
quadratic potential at a higher level of significance compared to the
Planck-alone constraints.

The Planck 2013 results led to renewed interest in the $R^{2}$
inflationary model, originally introduced by [Starobinsky (1980)](#bib.bib328),
and related inflationary models that have flat effective potentials of similar form
([Kallosh & Linde 2013](#bib.bib187); [Ferrara et al. 2013](#bib.bib119); [Buchmuller et al. 2013](#bib.bib65); [Ellis et al. 2013](#bib.bib111), e.g.,).
A characteristic of these models is that they produce a red tilted
scalar spectrum and a low tensor-to-scalar ratio. For reference, the
Starobinsky model predicts

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle n\_{\rm s}$ | $\displaystyle\approx$ | $\displaystyle 1-{2\over N}\in(0.960,0.967),$ |  | (26a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle r$ | $\displaystyle\approx$ | $\displaystyle{12\over N^{2}}\in(0.003,0.005),$ |  | (26b) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{dn\_{\rm s}}{d\ln k}$ | $\displaystyle\approx$ | $\displaystyle-{2\over N^{2}}\in(-0.0008,-0.0006),$ |  | (26c) |

where $N$ is the number of e-foldings between the end of inflation and
the time that our present day Hubble scale crossed the inflationary horizon,
and numerical values are for the range $50\leq N\leq 60$.

Although the Planck 2013 results stimulated theoretical work on
inflationary models with low tensor-to-scalar ratios, the cosmological
landscape became more complicated following the detection of a $B$-mode
polarization anisotropy by the BICEP2 team ([BICEP2 Collaboration 2014](#bib.bib53)).
If the BICEP2 signal were primarily caused by primordial gravitational waves,
then the inferred tensor-to-scalar ratio would have been
$r\_{0.01}\approx 0.2$,2626
26
The pivot scale quoted here is roughly
appropriate for the multipoles probed by BICEP2. apparently in
conflict with the 2013 Planck 95 % upper limit of $r\_{0.002}<0.11$, based
on fits to the temperature power spectrum. Since the
Planck constraints on $r$ are highly model dependent (and fixed
mainly by lower $k$) it is possible to reconcile these
results by introducing additional parameters, such as large tilts or
strong running of the spectral indices.

The situation has been clarified following a joint analysis of
BICEP2/Keck observations and Planck polarization data reported in
[54](#bib.bib54). This analysis shows that polarized dust emission contributes a
significant part of the BICEP2 signal. Correcting for polarized dust emission,
[54](#bib.bib54) report a 95 % upper limit of $r\_{0.05}<0.12$ on scale-invariant
tensor modes, eliminating the tension between the BICEP2 and the Planck 2013
results. There is therefore no evidence for inflationary tensor modes from
$B$-mode polarization measurements at this time (although the BKP
analysis leaves open the possibility of a much higher tensor-to-scalar
ratio than the prediction of Eq. [26b](#S6.E2 "In 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") for Starobinsky-type models).

The layout of the rest of this subsection is as follows. In
Sect. [6.2.1](#S6.SS2.SSS1 "6.2.1 Scalar spectral index and tensor fluctuations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") we review the Planck 2015 and Planck+BKP constraints
on $n\_{\rm s}$ and $r$. Constraints on the running of the scalar spectral
index are presented in Sect. [6.2.2](#S6.SS2.SSS2 "6.2.2 Scale dependence of primordial fluctuations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). Polarization data
provide a powerful way of testing for isocurvature modes, as discussed
in Sect. [6.2.3](#S6.SS2.SSS3 "6.2.3 Isocurvature perturbations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). Finally,
Sect. [6.2.4](#S6.SS2.SSS4 "6.2.4 Curvature ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") summarizes our results on spatial
curvature. A discussion of specific inflationary models and tests for
features in the primordial power spectrum can be found in
[Planck Collaboration
XX (2016)](#bib.bib279).

#### 6.2.1 Scalar spectral index and tensor fluctuations

Primordial tensor fluctuations (gravitational waves) contribute to
both the CMB temperature and polarization power spectra. Gravitational
waves entering the horizon between recombination and the present day
generate a tensor contribution to the large-scale CMB temperature anisotropy. In
this data release, the strongest constraint on tensor modes from
Planck data still comes from the CMB temperature spectrum at
$\ell\la 100$. The corresponding
comoving wavenumbers probed by the Planck temperature spectrum have $k\la 0.008\thinspace\text{Mpc}^{-1}$, with very little sensitivity to higher wavenumbers
because gravitational waves decay on sub-horizon scales. The
precision of the Planck constraint is limited by cosmic
variance of the large-scale anisotropies (which are dominated by the scalar
component), and it is also model dependent. In polarization, in addition to
$B$-modes, the $EE$ and $TE$ spectra also contain a signal from tensor modes
coming from the last-scattering and reionization epochs. However, in this
release the addition of Planck polarization constraints at $\ell\geq 30$ do
not significantly change the results from temperature and low-$\ell$
polarization (see Table [5](#S6.T5 "Table 5 ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")).

Figure [21](#S6.F21 "Figure 21 ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") shows the 2015 Planck constraint in the
$n\_{\rm s}$–$r$ plane, adding $r$ as a 1-parameter extension to base $\rm{\Lambda CDM}$.
For base $\rm{\Lambda CDM}$ ($r=0$), the value of $n\_{\rm s}$ is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $n\_{\rm s}=0.9655\pm 0.0062,\qquad\textit{Planck}\ {\rm TT}{+}{\rm lowP}.$ |  | (27) |

We highlight this number here since $n\_{\rm s}$, a key parameter for
inflationary cosmology, shows one of the largest shifts
of any parameter in base $\rm{\Lambda CDM}$ between the Planck 2013 and Planck 2015
analyses (about $0.7\thinspace\sigma$).
As explained in
Sect. [3.1](#S3.SS1 "3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters"), part of this shift was caused by the
$\ell\approx 1800$ systematic in the nominal-mission $217\times 217$ spectrum
used in [258](#bib.bib258).

The red contours in Fig. [21](#S6.F21 "Figure 21 ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") show the constraints
from Planck TT+lowP. These are similar to the constraints shown in Fig. 23
of [258](#bib.bib258), but with $n\_{\rm s}$ shifted to slightly higher values. The
addition of BAO or the Planck lensing data to Planck TT+lowP lowers the
value of $\Omega\_{\mathrm{c}}h^{2}$, which, at fixed $\theta\_{\ast}$, increases the
small-scale CMB power. To maintain the fit to the Planck temperature
power spectrum for models with $r=0$, these parameter shifts are
compensated by a change in the amplitude $A\_{\rm s}$ and the tilt $n\_{\rm s}$ (by
about $0.4\thinspace\sigma$). The increase in $n\_{\rm s}$ to match the observed
power on small scales leads to a decrease in the scalar power on large
scales, allowing room for a slightly larger contribution from tensor
modes. The constraints shown by the blue contours in
Fig. [21](#S6.F21 "Figure 21 ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"), which combine Planck lensing, BAO, and
other astrophysical data, are therefore tighter in the $n\_{\rm s}$ direction
and shifted to slightly higher values, but marginally weaker in the
$r$-direction. The 95 % limits on $r\_{0.002}$ are

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle r\_{0.002}$ | $\displaystyle<$ | $\displaystyle 0.10,\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP},$ |  | (28a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle r\_{0.002}$ | $\displaystyle<$ | $\displaystyle 0.11,\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP}{+}{\rm lensing}{+}{\rm ext},$ |  | (28b) |

consistent with the results reported in [258](#bib.bib258). Here we assume
the second-order slow-roll consistency relation for the tensor spectral index.
The result in Eqs. ([28a](#S6.E1a "In 6.2.1 Scalar spectral index and tensor fluctuations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) and ([28b](#S6.E2a "In 6.2.1 Scalar spectral index and tensor fluctuations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) are mildly scale dependent,
with equivalent limits on $r\_{0.05}$ being weaker by about $5\thinspace\%$.

[258](#bib.bib258) noted a mismatch between the best-fit base $\rm{\Lambda CDM}$ model and
the temperature power spectrum at multipoles $\ell\la 40$, partly
driven by the dip in the multipole range $20\la\ell\la 30$. If this
mismatch is simply a statistical fluctuation of the $\rm{\Lambda CDM}$ model (and
there is no compelling evidence to think otherwise), the strong
Planck limit (compared to forecasts) is the result of chance low
levels of scalar mode confusion. On the other hand, if the dip
represents a failure of the $\rm{\Lambda CDM}$ model, the $95\thinspace\%$ limits of
Eqs. ([28a](#S6.E1a "In 6.2.1 Scalar spectral index and tensor fluctuations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) and ([28b](#S6.E2a "In 6.2.1 Scalar spectral index and tensor fluctuations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) may be underestimates. These
issues are considered at greater length in [Planck Collaboration
XX (2016)](#bib.bib279) and
will not be discussed further in this paper.

As mentioned above, the Planck temperature constraints on $r$ are
model-dependent and extensions to $\rm{\Lambda CDM}$ can give significantly
different results. For example, extra relativistic degrees of freedom
increase the small-scale damping of the CMB anisotropies at a fixed
angular scale, which can be compensated by increasing $n\_{\rm s}$, allowing
a larger tensor mode. This is illustrated by the grey contours
in Fig. [21](#S6.F21 "Figure 21 ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"), which show the constraints for a model
with $\Delta N\_{\rm eff}=0.39$. Although this value of $\Delta N\_{\rm eff}$
is disfavoured by the Planck data (see Sect. [6.4.1](#S6.SS4.SSS1 "6.4.1 Constraints on the total mass of active neutrinos ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) it is not
excluded at a high significance level.

This example emphasizes the need for direct tests of tensor modes
based on measurements of a large-scale $B$-mode pattern in CMB
polarization.
Planck $B$-mode constraints from the 100- and 143-GHz HFI channels, presented
in [Planck Collaboration
XI (2016)](#bib.bib273), give a
95 % upper limit of $r\la 0.27$. However, at
present the tightest $B$-mode constraints on $r$ come
from the [54](#bib.bib54) analysis of the BICEP2/Keck field, which covers approximately
$400\\
,{\rm deg}^{2}$ centred on ${\rm RA}=0^{\rm h}$, ${\rm Dec}=-57$.${}^{\circ}5$.
These measurements probe the peak of the $B$-mode power spectrum at
around $\ell=100$, corresponding to gravitational waves with $k\approx 0.01\thinspace\text{Mpc}^{-1}$ that enter the horizon during recombination (i.e.,
somewhat smaller than the scales that contribute to the
Planck temperature constraints on $r$). The results of [54](#bib.bib54)
give a posterior for $r$ that peaks at $r\_{0.05}\approx 0.05$, but is
consistent with $r\_{0.05}=0$. Thus, at present there is no convincing evidence
of a primordial $B$-mode signal. At these low values of $r$, there is no
longer any tension with Planck temperature constraints.

The analysis of [54](#bib.bib54) constrains $r$ defined relative to a fixed
fiducial $B$-mode spectrum, and on its own does not
give a useful constraint on either the scalar amplitude or $n\_{\rm s}$. A combined
analysis of the Planck CMB spectra and the BKP likelihood can,
self-consistently, give constraints in the $n\_{\rm s}$–$r$ plane,
as shown in the right-hand panel of Fig. [21](#S6.F21 "Figure 21 ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters").
The BKP likelihood pulls the
contours to slightly non-zero values of $r$, with best fits of around
$r\_{0.002}\approx 0.03$, but at very low levels of statistical
significance. The BKP likelihood also rules out the upper tail of $r$
values allowed by Planck alone. The joint Planck+BKP likelihood analyses
give the $95\thinspace\%$ upper limits

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle r\_{0.002}$ | $\displaystyle<$ | $\displaystyle 0.08,\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP}{+}{\rm BKP},$ |  | (29a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle r\_{0.002}$ | $\displaystyle<$ | $\displaystyle 0.09,\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP}{+}{\rm lensing}{+}{\rm ext}{+}{\rm BKP}.$ |  | (29b) |

The exact values of these upper limits are weakly dependent on
the details of the foreground modelling applied in the BKP analysis
(see [54](#bib.bib54) for further details).
The results given here are for the baseline 2-parameter
model, varying the $B$-mode dust amplitude and frequency scaling, using the lowest five $B$-mode bandpowers.

Figure 22: 
Constraints on the tensor-to-scalar ratio $r\_{0.002}$ in the $\rm{\Lambda CDM}$ model with
running, using Planck TT+lowP (samples, coloured by the running parameter), and
Planck TT+lowP+lensing+BAO (black contours). Dashed contours show the
corresponding constraints also including the [54](#bib.bib54) $B$-mode likelihood. These
are compared to the constraints when the running is
fixed to zero (blue contours). Parameters are plotted at
$k=0.002\thinspace\text{Mpc}^{-1}$, which is approximately the scale at which Planck probes tensor fluctuations; however, the scalar tilt is only constrained
well on much
smaller scales. The inflationary slow-roll consistency relation is used here
for $n\_{\rm t}$ (though the range of running allowed is much larger than would be
expected in most slow-roll models).

Allowing a running of the scalar spectral index as an additional
free parameter weakens the Planck constraints on $r\_{0.002}$, as shown in
Fig. [22](#S6.F22 "Figure 22 ‣ 6.2.1 Scalar spectral index and tensor fluctuations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). The coloured samples in
Fig. [22](#S6.F22 "Figure 22 ‣ 6.2.1 Scalar spectral index and tensor fluctuations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") illustrate how a negative running allows the
large-scale scalar spectral index $n\_{{\rm s},0.002}$ to shift towards
higher values, lowering the scalar power on large scales relative to small
scales, thereby allowing a larger tensor contribution. However
adding the BKP likelihood, which directly constrains the tensor
amplitude on smaller scales, significantly reduces the extent of this
degeneracy leading to a $95\thinspace\%$ upper limit of $r\_{0.002}<0.10$ even in the
presence of running (i.e., similar to the results of Eqs. [29a](#S6.E1b "In 6.2.1 Scalar spectral index and tensor fluctuations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") and
[29b](#S6.E2b "In 6.2.1 Scalar spectral index and tensor fluctuations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")).

The Planck+BKP joint analysis rules out a quadratic
inflationary potential ($V(\phi)\propto m^{2}\phi^{2}$, predicting
$r\approx 0.16$) at over 99 % confidence and reduces the allowed range of
the parameter space for models with convex potentials. Starobinsky-type
models are an example of a wider class of inflationary theories in which
$n\_{\rm s}-1=\mathcal{O}(1/N)$ is not a coincidence, yet $r=\mathcal{O}(1/N^{2})$
([Roest 2014](#bib.bib299); [Creminelli et al. 2015](#bib.bib91)). These models have concave
potentials, and include a variety of string-inspired models with
exponential potentials. Models with $r=\mathcal{O}(1/N)$ are, however, still
allowed by the data, including a simple linear potential and
fractional-power monomials, as well as regions of parameter space in
between where $n\_{\rm s}-1=\mathcal{O}(1/N)$ is just a coincidence. Models that
have sub-Planckian field evolution, so satisfying the Lyth bound ([Lyth 1997](#bib.bib218); [Garcia-Bellido et al. 2014](#bib.bib137)), will typically have
$r\la 2\times 10^{-5}$ for $n\_{\rm s}\approx 0.96$, and are also consistent
with the tensor constraints shown in Fig. [21](#S6.F21 "Figure 21 ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters").
For further discussion of the implications of the Planck 2015 data
for a wide range of inflationary models see [Planck Collaboration
XX (2016)](#bib.bib279).

In summary, the Planck limits on $r$ are consistent with the BKP
limits from $B$-mode measurements. Both data sets are consistent with
$r=0$; however, the combined data sets yield an upper limit to the
tensor-to-scalar ratio of $r\approx 0.09$ at the 95 % level.
The Planck temperature constraints on
$r$ are limited by cosmic variance. The only way of improving these limits,
or potentially detecting gravitational waves with $r\la 0.09$, is through
direct $B$-mode detection. The Planck 353-GHz polarization maps
([Planck Collaboration Int.
XXX 2016](#bib.bib284)) show that at frequencies of around 150 GHz,
Galactic dust emission is an important contaminant at the $r\approx 0.05$
level even in the cleanest regions of the sky. [54](#bib.bib54) demonstrates further
that on small regions of the sky covering a few hundred square degrees
(typical of ground based $B$-mode experiments), the Planck 353-GHz
maps are of limited use as monitors of polarized Galactic dust emission
because of their low signal-to-noise level. To achieve limits substantially
below $r\approx 0.05$ will require observations of comparably high sensitivity
over a range of frequencies, and with increased sky coverage.
The forthcoming measurements from Keck Array and BICEP3 at
95 GHz and the Keck Array receivers at 220 GHz should offer significant
improvements on the current constraints. A number of other ground-based and
sub-orbital experiments should also return high precision $B$-mode data within
the next few years (see [Abazajian et al. 2015a](#bib.bib1), for a review).

#### 6.2.2 Scale dependence of primordial fluctuations

In simple single-field models of inflation, the running of the
spectral index is of second order in inflationary slow-roll parameters
and is typically small, $|dn\_{\rm s}/d\ln k|\approx(n\_{\rm s}-1)^{2}\approx 10^{-3}$ ([Kosowsky & Turner 1995](#bib.bib199)). Nevertheless, it is possible to
construct models that produce a large running over a wavenumber range
accessible to CMB experiments, whilst simultaneously achieving enough
e-folds of inflation to solve the horizon problem. Inflation with an
oscillatory potential of sufficiently long period, perhaps related to
axion monodromy, is an example ([Silverstein & Westphal 2008](#bib.bib317); [Meerburg 2014](#bib.bib228); [Czerny et al. 2014](#bib.bib93); [Minor & Kaplinghat 2015](#bib.bib229)).

Figure 23: 
Constraints on the running of the scalar spectral index in the $\rm{\Lambda CDM}$ model,
using Planck TT+lowP (samples, coloured by the spectral index at
$k=0.05\thinspace\text{Mpc}^{-1}$), and Planck TT,TE,EE+lowP (black contours). The Planck data are
consistent with zero running, but also allow for significant negative
running, which gives a positive tilt on large scales and hence less
power on large scales.

As reviewed in [258](#bib.bib258), previous CMB experiments, either on their own or
in combination with other astrophysical data, have sometimes given hints of
a non-zero running at about the $2\thinspace\sigma$ level
([Spergel et al. 2003](#bib.bib326); [Hinshaw et al. 2013](#bib.bib168); [Hou et al. 2014](#bib.bib172)). The results of [258](#bib.bib258) showed
a slight preference for negative running at the $1.4\thinspace\sigma$ level,
driven almost entirely by the mismatch between the CMB temperature power
spectrum at high multipoles and the spectrum at multipoles $\ell\la 50$.

The 2015 Planck results (Fig. [23](#S6.F23 "Figure 23 ‣ 6.2.2 Scale dependence of primordial fluctuations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) are similar to those in
[258](#bib.bib258). Adding running as an additional parameter to base $\rm{\Lambda CDM}$  with $r=0$, we find

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{dn\_{\rm s}}{d\ln k}$ | $\displaystyle=$ | $\displaystyle-0.0084\pm 0.0082,\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP},$ |  | (30a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{dn\_{\rm s}}{d\ln k}$ | $\displaystyle=$ | $\displaystyle-0.0057\pm 0.0071,\quad\textit{Planck}\ {\rm TT,TE,EE}{+}{\rm lowP}.$ |  | (30b) |

There is a slight preference for negative running, which, as in [258](#bib.bib258),
is driven by the mismatch between the high and low multipoles
in the temperature power spectrum. However, in the 2015 Planck data
the tension between high and low multipoles is reduced somewhat,
primarily because of changes to the HFI beams at multipoles $\ell\la 200$
(see Sect. [3.1](#S3.SS1 "3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")). A consequence of
this reduced tension can be seen in the 2015 constraints on models that
include tensor fluctuations in addition to running:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{dn\_{\rm s}}{d\ln k}$ | $\displaystyle=$ | $\displaystyle-0.0126^{+0.0098}\_{-0.0087},\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP};$ |  | (31a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{dn\_{\rm s}}{d\ln k}$ | $\displaystyle=$ | $\displaystyle-0.0085\pm 0.0076,\quad\textit{Planck}\ {\rm TT,TE,EE}{+}{\rm lowP};$ |  | (31b) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\frac{dn\_{\rm s}}{d\ln k}$ | $\displaystyle=$ | $\displaystyle-0.0065\pm 0.0076,\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP}{+}{\rm lensing}$ |  | (31c) |
|  |  |  | $\displaystyle\qquad\qquad\qquad\qquad\qquad\qquad{+}{\rm ext}{+}{\rm BKP}.$ |  |

[258](#bib.bib258) found an approximately $2\thinspace\sigma$ pull towards negative running for
these models. This tension is reduced to about $1\thinspace\sigma$ with the
2015 Planck data, and to lower values when we include the [54](#bib.bib54)
likelihood, which reduces the range of allowed tensor amplitudes.

In summary, the Planck data are consistent with zero running of the scalar
spectral index. However, as illustrated in Fig. [23](#S6.F23 "Figure 23 ‣ 6.2.2 Scale dependence of primordial fluctuations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"),
the Planck data still allow running at roughly the $10^{-2}$ level, i.e.,
an order of magnitude higher than expected in simple inflationary models.
One way of potentially improving these constraints is to extend the wavenumber
range from CMB scales to smaller scales using additional astrophysical data,
for example by using measurements of the Ly$\alpha$ flux
power spectrum of high-redshift quasars ([Spergel et al. 2003](#bib.bib326), as in the first year WMAP
analysis,).
[Palanque-Delabrouille et al. (2015)](#bib.bib245) have recently reported an analysis of a large
sample of quasar spectra from the SDSSIII/BOSS
survey. These authors find a low value of the scalar spectral index
$n\_{\rm s}=0.928\pm 0.012\ ({\rm stat.})\pm(0.02)\ ({\rm syst.})$
on scales of $k\approx 1\thinspace{\rm Mpc}^{-1}$. To extract
physical parameters, the Ly$\alpha$ power spectra need to
be calibrated against numerical hydrodynamical simulations.
The large systematic error in this spectral index determination is
dominated by the fidelity of the hydrodynamic simulations and by the
splicing used to achieve high resolution over large scales. These
uncertainties need to be reduced before addressing the consistency of
Ly$\alpha$ results with CMB measurements of the running of the spectral index.

#### 6.2.3 Isocurvature perturbations

A key prediction of single-field inflation is that the primordial
perturbations are adiabatic. More generally, the observed fluctuations will
be adiabatic in any model in which the curvature perturbations were the only
super-horizon perturbations left by the time that dark matter (and other
matter) first decoupled, or was produced by decay. The different matter
components then all have perturbations proportional to the curvature
perturbation, so there are no isocurvature perturbations. However,
it is possible to produce an observable amount of isocurvature modes
by having additional degrees of freedom present during inflation and through
reheating. For example, the curvaton model can generate correlated adiabatic
and isocurvature modes from a second field ([Mollerach 1990](#bib.bib231); [Lyth & Wands 2002](#bib.bib217)).

Isocurvature modes describe relative perturbations between the different
species ([Bucher et al. 2001b](#bib.bib64)), with perhaps the simplest being a perturbation in
the baryonic or dark matter sector (relative to the radiation). However,
only one total matter isocurvature mode is observable in the linear CMB
(in the accurate approximation in which the baryons are pressureless);
a compensated mode (between the baryons and the cold dark matter)
with $\delta\rho\_{\rm b}=-\delta\rho\_{\rm c}$ has no net density
perturbation, and produces no CMB anisotropies ([Gordon & Lewis 2003](#bib.bib147); [Grin et al. 2011](#bib.bib151); [Grin et al. 2014](#bib.bib152)).
It is possible to generate isocurvature modes in the neutrino sector;
however, this requires interaction of an additional perturbed super-horizon
field with neutrinos after they have decoupled, and hence is harder to achieve.
Finally, neutrino velocity potential and vorticity modes are other possible
consistent perturbations to the photon-neutrino fluid after neutrino
decoupling. However, they are essentially impossible to excite,
since they consist of photon and neutrino fluids coherently moving in opposite
directions on super-horizon scales (although the relative
velocity would have been zero before neutrino decoupling).

Figure 24: Constraints on the correlated matter isocurvature mode amplitude
parameter $\alpha$, where $\alpha=0$ corresponds to purely adiabatic
perturbations. The Planck temperature data slightly favour negative values,
since this lowers the large-scale anisotropies; however, the polarization
signal from an isocurvature mode is distinctive and the Planck polarization
data significantly shrink the allowed region around the value $\alpha=0$
corresponding to adiabatic perturbations.

Figure 25: Power spectra drawn from the Planck TT+lowP posterior for the correlated
matter isocurvature model, colour-coded by the value of the isocurvature
amplitude parameter $\alpha$, compared to the Planck data points. The
left-hand figure shows how the negatively-correlated modes lower the
large-scale temperature spectrum,
slightly improving the fit at low multipoles. Including polarization, the
negatively-correlated modes are disfavoured, as illustrated at the first
acoustic peak in $EE$ on the right-hand plot. Data points at $\ell<30$ are not
shown for polarization, as they are included with both the default temperature
(i.e., TT+lowP) and polarization (i.e., TT,TE,EE+lowP) likelihood combinations.

[Planck Collaboration
XXII (2014)](#bib.bib261) presented constraints on a variety of general
isocurvature models using the Planck temperature data, finding consistency
with adiabaticity, though with some mild preference for isocurvature models
that reduce the power at low multipoles to provide a better match to the
Planck temperature spectrum at $\ell\la 50$.
For matter isocurvature perturbations, the photons are initially unperturbed
but perturbations develop as the Universe becomes more matter dominated. As a
result, the phase of the acoustic oscillations differs from adiabatic modes;
this is most clearly distinctive with the addition of polarization
data ([Bucher et al. 2001a](#bib.bib63))

An extended analysis of isocurvature models is given in [Planck Collaboration
XX (2016)](#bib.bib279).
Here we focus on a simple illustrative case of a totally-correlated matter
isocurvature mode. We define an isocurvature amplitude parameter $\alpha$,
such that2727
27
[Planck Collaboration
XX (2016)](#bib.bib279) gives equivalent one-tailed
constraints on $\beta\_{\rm iso}=|\alpha|$, where the correlated and
anti-correlated cases are considered separately.

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S\_{\rm m}={\rm sgn}(\alpha)\sqrt{\frac{|\alpha|}{1-|\alpha|}}\zeta,$ |  | (32) |

where $\zeta$ is the primordial curvature perturbation.
Here $S\_{\rm m}$ is the total matter isocurvature mode, defined as the
observable sum of the baryon and CDM isocurvature modes, i.e.,
$S\_{\rm m}=S\_{\rm c}+S\_{\rm b}(\rho\_{\rm b}/\rho\_{\rm c})$,
where

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S\_{i}\equiv\frac{\delta\rho\_{i}}{\rho\_{i}}-\frac{3\delta\rho\_{\gamma}}{4\rho\_{\gamma}}.$ |  | (33) |

All modes are assumed to have a power spectrum with the same spectral index
$n\_{\rm s}$, so that $\alpha$ is independent of scale.
For positive $\alpha$ this agrees with the definitions in
[Bean et al. (2006)](#bib.bib34) and [Larson et al. (2011)](#bib.bib203) for $\alpha\_{-1}$, but also allows
for the correlation to have the opposite sign. Approximately,
${\rm sgn}(\alpha)\thinspace\alpha^{2}\approx B\_{\rm c}$, where $B\_{\rm c}$ is the
CDM version of the amplitude defined as in [Amendola et al. (2002)](#bib.bib16). Note that
in our conventions, negative values of $\alpha$ *lower* the
Sachs–Wolfe contribution to the large-scale $TT$ power spectrum. We caution
the reader that this convention differs from some others, e.g.,
[Larson et al. (2011)](#bib.bib203).

Planck constraints on the correlated isocurvature amplitude are shown in
Fig. [24](#S6.F24 "Figure 24 ‣ 6.2.3 Isocurvature perturbations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"), with and without high-multipole polarization.
The corresponding marginalized limit from the temperature data is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\alpha=-0.0025^{+0.0035}\_{-0.0047}\quad(95\%,\text{{Planck}\ TT{+}lowP}),$ |  | (34) |

which is significantly tightened around zero when Planck polarization
information is included at high multipoles:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\alpha=0.0003^{+0.0016}\_{-0.0012}\quad(95\%,\text{{Planck}\ TT,TE,EE{+}lowP}).$ |  | (35) |

This strongly limits the isocurvature contribution to be less than about
3 % of the adiabatic modes.
Figure [25](#S6.F25 "Figure 25 ‣ 6.2.3 Isocurvature perturbations ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") shows how models with negative correlation
parameter, $\alpha$, fit the temperature data at low multipoles slightly better
than models with $\alpha=0$; however, these models are disfavoured from the
corresponding change in the polarization acoustic peaks.

In this model most of the gain in sensitivity comes from relatively large
scales, $\ell\la 300$, where the correlated isocurvature modes with delayed
phase change the first polarization acoustic peak ($\ell\approx 140$)
significantly more than in temperature ([Bucher et al. 2001a](#bib.bib63)). The polarization
data are not entirely robust to systematics on these scales, but in this case
the result appears to be quite stable between the different likelihood
codes. However, it should be noted that a particularly low point in the
$TE$ spectrum at $\ell\approx 160$ (see Fig. [3](#S3.F3 "Figure 3 ‣ (5) Goodness of fit. ‣ 3.3.1 Temperature spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")) pulls in
the direction of positive $\alpha$, and could be giving an artificially
strong constraint if this were caused by an unidentified systematic.

#### 6.2.4 Curvature

Figure 26: Constraints in the $\Omega\_{\rm m}$–$\Omega\_{\Lambda}$ plane from the
Planck TT+lowP data (samples; colour-coded by the value of $H\_{0}$)
and Planck TT,TE,EE+lowP (solid contours). The geometric degeneracy
between $\Omega\_{\rm m}$ and $\Omega\_{\Lambda}$ is partially broken because
of the effect of lensing on the temperature and polarization power spectra.
These limits are improved significantly by the inclusion of the Planck lensing reconstruction (blue contours) and BAO (solid red contours). The red
contours tightly constrain the geometry of our Universe to be nearly flat.

The simplifying assumptions of large-scale homogeneity and isotropy
lead to the familiar Friedman-Lemaître-Robertson-Walker (FLRW) metric that
appears to be an accurate description of our Universe. The base $\rm{\Lambda CDM}$ cosmology assumes an FLRW metric with a flat 3-space. This is a very
restrictive assumption that needs to be tested empirically. In this subsection,
we investigate constraints on the parameter $\Omega\_{K}$, where for $\rm{\Lambda CDM}$ models
$\Omega\_{K}\equiv 1-\Omega\_{\rm m}-\Omega\_{\Lambda}$.
For FLRW models $\Omega\_{K}>0$ corresponds to negatively-curved 3-geometries
while $\Omega\_{K}<0$ corresponds to positively-curved 3-geometries.
Even with perfect data within our past lightcone, our inference of
the curvature $\Omega\_{K}$ is limited by the cosmic variance of curvature
perturbations that are still super-horizon at the present, since these cannot
be distinguished from background curvature within our observable volume.

The parameter $\Omega\_{K}$ decreases exponentially with time during
inflation, but grows only as a power law during the radiation and
matter-dominated phases, so the standard inflationary prediction has
been that curvature should be unobservably small today. Nevertheless,
by fine-tuning parameters it is possible to devise inflationary models
that generate open ([Bucher et al. 1995](#bib.bib62); [Linde 1999](#bib.bib212), e.g.,) or
closed universes
([Linde 2003](#bib.bib213), e.g.,). Even more speculatively, there has been
interest recently in multiverse models, in which
topologically-open “pocket universes” form by bubble
nucleation ([Coleman & De Luccia 1980](#bib.bib85); [Gott 1982](#bib.bib150), e.g.,)
between different vacua of a “string landscape” ([Freivogel et al. 2006](#bib.bib128); [Bousso et al. 2015](#bib.bib60), e.g.,). Clearly, the detection of a significant
deviation from $\Omega\_{K}=0$ would have profound consequences for inflation theory
and fundamental physics.

The Planck power spectra give the constraint

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Omega\_{K}=-0.052^{+0.049}\_{-0.055}\quad(95\%,\text{{Planck}\ TT{+}lowP}).$ |  | (36) |

The well-known geometric degeneracy ([Bond et al. 1997](#bib.bib58); [Zaldarriaga et al. 1997](#bib.bib354)) allows for
the small-scale linear CMB spectrum to remain almost
unchanged if changes in $\Omega\_{K}$ are compensated by changes in $H\_{0}$ to obtain the same angular diameter distance to last scattering.
The Planck constraint is therefore mainly determined by the (wide)
priors on $H\_{0}$, and the effect of lensing smoothing on the power
spectra. As discussed in Sect. [5.1](#S5.SS1 "5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"), the Planck temperature
power spectra show a slight preference for more lensing than expected in the
base $\rm{\Lambda CDM}$ cosmology, and since positive curvature increases the amplitude
of the lensing signal, this preference
also drives $\Omega\_{K}$ towards negative values.

Taken at face value, Eq. ([36](#S6.E36 "In 6.2.4 Curvature ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) represents a detection
of positive curvature at just over $2\thinspace\sigma$, largely via the impact of
lensing on the power spectra. One might wonder whether this is mainly
a parameter volume effect, but that is not the case, since the best fit
closed model has $\Delta\chi^{2}\approx 6$ relative to base $\rm{\Lambda CDM}$, and the fit is
improved over almost all the posterior volume, with the mean improvement
being $\langle\Delta\chi^{2}\rangle\approx 5$ (very similar
to the phenomenological case of $\rm{\Lambda CDM}$+$A\_{\rm L}$). Addition of the Planck polarization spectra shifts $\Omega\_{K}$ towards zero by $\Delta\Omega\_{K}\approx 0.015$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Omega\_{K}=-0.040^{+0.038}\_{-0.041}\quad(95\%,\text{{Planck}\ TT,TE,EE{+}lowP}),$ |  | (37) |

but $\Omega\_{K}$ remains negative at just over $2\thinspace\sigma$.

What’s more, the lensing reconstruction from Planck measures the lensing
amplitude directly and, as discussed in Sect. [5.1](#S5.SS1 "5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"), this does
not prefer more lensing than base $\rm{\Lambda CDM}$. The
combined constraint shows impressive consistency with a flat universe:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Omega\_{K}=-0.005^{+0.016}\_{-0.017}\quad(95\%,\text{{Planck}\ TT{+}lowP{+}lensing}).$ |  | (38) |

The dramatic improvement in the error bar is another illustration of the power
of the lensing reconstruction from Planck.

The constraint can be sharpened further by adding external data that break
the main geometric degeneracy. Combining the Planck data with BAO, we find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Omega\_{K}=0.000\pm 0.005\quad(95\%,\text{ {Planck}\ TT{+}lowP{+}lensing{+}BAO}).$ |  | (39) |

This constraint is unchanged at the quoted precision if we add the JLA
supernovae data and the $H\_{0}$ prior of Eq. ([19](#S5.E19 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")).

Figure [26](#S6.F26 "Figure 26 ‣ 6.2.4 Curvature ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") illustrates these results in the $\Omega\_{\mathrm{m}}$–$\Omega\_{\Lambda}$
plane. We adopt Eq. ([39](#S6.E39 "In 6.2.4 Curvature ‣ 6.2 Early-Universe physics ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) as our most reliable
constraint on spatial curvature. Our Universe appears to be spatially
flat to a $1\thinspace\sigma$ accuracy of 0.25 %.

### 6.3 Dark energy

Figure 27: Samples from the distribution of the dark energy parameters $w\_{0}$
and $w\_{a}$ using Planck TT+lowP+BAO+JLA data, colour-coded by the value of the Hubble
parameter $H\_{0}$. Contours show the corresponding 68 % and 95 % limits.
Dashed grey lines intersect at the point in parameter space corresponding to
a cosmological constant.

The physical explanation for the observed accelerated expansion of the
Universe is currently not known. In standard $\rm{\Lambda CDM}$ the acceleration is
provided by a cosmological constant, i.e., an additional fluid
satisfying an equation of state
$w\equiv p\_{\rm DE}/\rho\_{\rm DE}=-1$. However, there are many possible
alternatives, typically described either in terms of extra degrees of freedom
associated with scalar fields or modifications of general relativity
on cosmological scales ([Copeland et al. 2006](#bib.bib90); [Tsujikawa 2010](#bib.bib339), for reviews see,
e.g.,). A detailed study of these
models and the constraints imposed by Planck and other data are
presented in a separate paper, [Planck Collaboration
XIV (2016)](#bib.bib275).

Here we will limit ourselves to the most basic extensions of $\rm{\Lambda CDM}$, which
can be phenomenologically described in terms of the equation of state
parameter $w$ alone. Specifically we will use the
camb implementation of the “parameterized post-Friedmann” (PPF)
framework of [Hu & Sawicki (2007)](#bib.bib176) and [Fang et al. (2008)](#bib.bib116) to test whether there is
any evidence that $w$ varies with time. This framework aims to recover the
behaviour of canonical (i.e., those with a standard kinetic term)
scalar field cosmologies minimally coupled to
gravity when $w\geq-1$, and accurately approximates them for values
$w\approx-1$. In these models the speed of sound is equal to the speed of
light, so that the clustering of the dark energy inside the horizon is
strongly suppressed. The advantage of using the PPF formalism is that
it is possible to study the phantom domain, $w<-1$, including
transitions across the “phantom barrier,” $w=-1$, which is
not possible for canonical scalar fields.

The CMB temperature data alone do not tightly constrain $w$, because of a
strong geometrical degeneracy, even for spatially-flat models. From Planck we
find

|  |  |  |  |
| --- | --- | --- | --- |
|  | $w=-1.54^{+0.62}\_{-0.50}\quad(95\%,\text{{Planck}\ TT{+}lowP}),$ |  | (40) |

i.e., almost a $2\thinspace\sigma$ shift into the phantom domain.
This is partly, but not entirely, a parameter volume effect, with the average
effective $\chi^{2}$ improving by $\langle\Delta\chi^{2}\rangle\approx 2$
compared to base $\rm{\Lambda CDM}$. This is consistent with the
preference for a higher lensing amplitude
discussed in Sect. [5.1.2](#S5.SS1.SSS2 "5.1.2 Detection of lensing in the CMB power spectra ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"),
improving the fit in the $w<-1$ region,
where the lensing smoothing amplitude becomes slightly larger.
However, the lower limit in Eq. ([40](#S6.E40 "In 6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) is largely determined by
the (arbitrary) prior $H\_{0}<100\thinspace\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$, chosen
for the Hubble parameter. Much of the posterior volume in the phantom region
is associated with extreme values for cosmological parameters, which are
excluded by other astrophysical data. The mild tension with base $\rm{\Lambda CDM}$ disappears as we add more data that break the geometrical degeneracy. Adding
Planck lensing and BAO, JLA and
$H\_{0}$ (“ext”) gives the 95 % constraints

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle w$ | $\displaystyle=$ | $\displaystyle-1.023^{+0.091}\_{-0.096}\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP}{+}{\rm ext},$ |  | (41a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle w$ | $\displaystyle=$ | $\displaystyle-1.006^{+0.085}\_{-0.091}\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP}{+}{\rm lensing}{+}{\rm ext},$ |  | (41b) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle w$ | $\displaystyle=$ | $\displaystyle-1.019^{+0.075}\_{-0.080}\quad\textit{Planck}\ {\rm TT,TE,EE}{+}{\rm lowP}{+}{\rm lensing}{+}{\rm ext}.\thinspace$ |  | (41c) |
|  |  |  |  |  |

The addition of Planck lensing, or using the full
Planck temperature+polarization likelihood together with the BAO, JLA, and
$H\_{0}$ data does not substantially improve the constraint of Eq. ([41a](#S6.E1e "In 6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")).
All of these data set combinations are compatible with the
base $\rm{\Lambda CDM}$ value of $w=-1$. In [258](#bib.bib258), we conservatively quoted
$w=-1.13^{+0.24}\_{-0.25}$, based on combining Planck with BAO, as our most
reliable limit on $w$. The errors in Eqs. ([41a](#S6.E1e "In 6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"))–([41c](#S6.E3b "In 6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) are
substantially smaller, mainly because of the addition of the JLA SNe data,
which offer a sensitive probe of the dark energy equation of state at
$z\la 1$. In [258](#bib.bib258), the addition of the SNLS SNe data pulled $w$ into
the phantom domain at the $2\thinspace\sigma$ level, reflecting the tension between
the SNLS sample and the Planck 2013 base $\rm{\Lambda CDM}$ parameters.
As noted in Sect. [5.3](#S5.SS3 "5.3 Type Ia supernovae ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"), this discrepancy is no longer present,
following improved photometric calibrations of the
SNe data in the JLA sample. One consequence of this is the tightening of the
errors in Eqs. ([41a](#S6.E1e "In 6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"))–([41c](#S6.E3b "In 6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"))
around the $\rm{\Lambda CDM}$ value $w=-1$ when we combine the JLA sample with Planck.

If $w$ differs from $-1$, it is likely to change with time. We consider here
the case of a Taylor expansion of $w$ at first order in the scale factor,
parameterized by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $w=w\_{0}+(1-a)w\_{a}.$ |  | (42) |

More complex models of dynamical dark energy are discussed in
[Planck Collaboration
XIV (2016)](#bib.bib275). Figure [27](#S6.F27 "Figure 27 ‣ 6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") shows the 2D marginalized
posterior distribution for $w\_{0}$ and $w\_{a}$ for the
combination Planck+BAO+JLA. The JLA SNe data are again crucial in breaking
the geometrical degeneracy at low redshift and with these data we find no
evidence for a departure from the base $\rm{\Lambda CDM}$ cosmology. The points in
Fig. [27](#S6.F27 "Figure 27 ‣ 6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") show samples from these chains colour-coded
by the value of $H\_{0}$. From these MCMC chains, we find
$H\_{0}=(68.2\pm 1.1)\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$.
Much higher values of $H\_{0}$ would favour the phantom regime, $w<-1$.

As pointed out in Sects. [5.5.2](#S5.SS5.SSS2 "5.5.2 Weak gravitational lensing ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") and [5.6](#S5.SS6 "5.6 Cosmic concordance? ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")
the CFHTLenS weak lensing data are in tension with the Planck base
$\rm{\Lambda CDM}$ parameters. Examples of this tension can be seen in
investigations of dark energy and modified gravity, since some of
these models can modify the growth rate of fluctuations from the base
$\rm{\Lambda CDM}$ predictions. This tension can be seen even in the simple model
of Eq. ([42](#S6.E42 "In 6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")). The green regions in Fig. [28](#S6.F28 "Figure 28 ‣ 6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")
show 68 % and 95 % contours in the
$w\_{0}$–$w\_{a}$ plane for Planck TT+lowP combined with the CFHTLenS H13
data. In this example, we have applied ultra-conservative cuts,
excluding $\xi\_{-}$ entirely and excluding measurements with $\theta<17$′ in $\xi\_{+}$ for all tomographic redshift bins. As
discussed in [Planck Collaboration
XIV (2016)](#bib.bib275), with these cuts the
CFHTLenS data are insensitive to modelling the nonlinear evolution
of the power spectrum, but this reduction in sensitivity comes
at the expense of reducing the statistical power
of the weak lensing data. Nevertheless,
Fig. [28](#S6.F28 "Figure 28 ‣ 6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") shows that the combination of
Planck+CFHTLenS pulls the contours into the phantom domain and is
discrepant with base $\rm{\Lambda CDM}$ at about the $2\thinspace\sigma$ level.
The Planck+CFHTLenS data also favour a high value of $H\_{0}$. If we add the (relatively weak)
$H\_{0}$ prior of Eq. ([19](#S5.E19 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")), the contours (shown in cyan) in
Fig. [28](#S6.F28 "Figure 28 ‣ 6.3 Dark energy ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") shift towards $w=-1$. It therefore seems
unlikely that the tension between Planck and CFHTLenS can be resolved by
allowing a time-variable equation of state for dark energy.

Figure 28: Marginalized posterior distributions for ($w\_{0},w\_{a}$) for various data
combinations. We show
$\textit{Planck}\ {\rm TT}{+}{\rm lowP}$ in combination with BAO, JLA, $H\_{0}$ (“ext”), and two data combinations
that add the CFHTLenS data with ultra-conservative cuts as described in the text
(denoted “WL”). Dashed grey lines show the parameter values corresponding to a
cosmological constant.

A much more extensive investigation of models of dark energy and also
models of modified gravity can be found in [Planck Collaboration
XIV (2016)](#bib.bib275). The
main conclusions of that analysis are as follows:

* $\bullet$

  an investigation of more general time-variations of the equation of
  state shows a high degree of consistency with $w=-1$;
* $\bullet$

  a study of several dark energy and modified gravity models either finds
  compatibility with base $\rm{\Lambda CDM}$, or mild tensions, which are driven mainly by
  external data sets.

### 6.4 Neutrino physics and constraints on relativistic components

In the following subsections, we update Planck constraints on the
mass of standard (active) neutrinos, additional relativistic degrees
of freedom, models with a combination of the two, and models with
massive sterile neutrinos. In each subsection we emphasize the
Planck-only constraint, and the implications of the Planck result
for late-time cosmological parameters measured from other
observations. We then give a brief discussion of tensions between
Planck and some discordant external data, and assess whether any of these
model extensions can help to resolve them. Finally we provide
constraints on neutrino interactions.

#### 6.4.1 Constraints on the total mass of active neutrinos

Detection of neutrino oscillations has proved that neutrinos have mass
(see, e.g., [Lesgourgues & Pastor 2006](#bib.bib207) and [Nakamura & Petcov 2014](#bib.bib236) for
reviews). The Planck base
$\rm{\Lambda CDM}$ model assumes a normal mass hierarchy with $\sum m\_{\nu}\approx 0.06\thinspace\thinspace\text{eV}$ (dominated by the heaviest neutrino mass eigenstate) but
there are other possibilities, including a degenerate hierarchy with
$\sum m\_{\nu}\ga 0.1\thinspace\thinspace\text{eV}$. At this time there are no compelling
theoretical reasons to strongly prefer any of these possibilities, so
allowing for larger neutrino masses is perhaps one of the most well-motivated extensions to base $\rm{\Lambda CDM}$ considered in this paper. There
has also been significant interest recently in larger neutrino masses
as a possible way to lower $\sigma\_{8}$ (the late-time fluctuation
amplitude), and thereby reconcile Planck with weak lensing measurements and
the abundance of rich clusters (see Sects. [5.5](#S5.SS5 "5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")
and [5.6](#S5.SS6 "5.6 Cosmic concordance? ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")). Though model dependent, neutrino mass
constraints from cosmology are already significantly stronger than those
from tritium $\beta$-decay experiments ([Drexlin et al. 2013](#bib.bib103), see, e.g.,).

Here we give constraints assuming three species of degenerate massive
neutrinos, neglecting the small differences in mass expected from the
observed mass splittings. At the level of sensitivity of Planck this
is an accurate approximation, but note that it does not quite match
continuously on to the base $\rm{\Lambda CDM}$ model (which assumes two massless
and one massive neutrino with $\sum m\_{\nu}=0.06\thinspace\thinspace\text{eV}$). We assume that the
neutrino mass is constant, and that the distribution function is
Fermi-Dirac with zero chemical potential.

Masses well below $1\thinspace\thinspace\text{eV}$ have only a mild effect on the shape of the
CMB power spectra, since they became non-relativistic after
recombination. The effect on the background cosmology can be
compensated by changes in $H\_{0}$, to ensure the same observed acoustic
peak scale $\theta\_{\*}$. There is, however, some sensitivity of the CMB
anisotropies to neutrino masses as the neutrinos start to become less
relativistic at recombination (modifying the early ISW effect), and
from the late-time effect of lensing on the power spectrum. The
Planck power spectrum (95 %) constraints are

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\sum m\_{\nu}$ | $\displaystyle<$ | $\displaystyle 0.72\thinspace\thinspace\text{eV}\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP},$ |  | (43a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\sum m\_{\nu}$ | $\displaystyle<$ | $\displaystyle 0.21\thinspace\thinspace\text{eV}\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP}{+}{\rm BAO},$ |  | (43b) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\sum m\_{\nu}$ | $\displaystyle<$ | $\displaystyle 0.49\thinspace\thinspace\text{eV}\quad\textit{Planck}\ {\rm TT,TE,EE}{+}{\rm lowP},$ |  | (43c) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\sum m\_{\nu}$ | $\displaystyle<$ | $\displaystyle 0.17\thinspace\thinspace\text{eV}\quad\textit{Planck}\ {\rm TT,TE,EE}{+}{\rm lowP}{+}{\rm BAO}.$ |  | (43d) |

The Planck TT+lowP constraint has a broad tail to high masses, as shown in
Fig. [29](#S6.F29 "Figure 29 ‣ 6.4.1 Constraints on the total mass of active neutrinos ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"), which also illustrates the acoustic scale
degeneracy with $H\_{0}$. Larger masses imply a lower $\sigma\_{8}$ through
the effects of neutrino free-streaming on structure formation, but the
larger masses also require a lower Hubble constant, leading to possible
tensions with direct measurements of $H\_{0}$. Masses below about $0.4\thinspace\thinspace\text{eV}$ can
provide an acceptable fit to the direct $H\_{0}$ measurements, and adding the
BAO data helps to break the acoustic scale degeneracy and tightens the
constraint on $\sum m\_{\nu}$ substantially. Adding Planck polarization data
at high multipoles produces a relatively small improvement to the Planck TT+lowP+BAO
constraint (and the improvement is even smaller with the alternative
CamSpec likelihood), so we consider the $TT$ results to be our most
reliable constraints.

Figure 29: Samples from the Planck TT+lowP posterior in the $\sum m\_{\nu}$–$H\_{0}$
plane, colour-coded by $\sigma\_{8}$. Higher $\sum m\_{\nu}$ damps the matter
fluctuation amplitude $\sigma\_{8}$, but also decreases $H\_{0}$. The grey
bands show the direct measurement, $H\_{0}=(70.6\pm 3.3)\thinspace\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$,
Eq. ([19](#S5.E19 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")). Solid black contours show the constraint from
Planck TT+lowP+lensing (which mildly prefers larger masses), and filled
contours show the constraints from Planck TT+lowP+lensing+BAO.

The constraint of Eq. ([43b](#S6.E2f "In 6.4.1 Constraints on the total mass of active neutrinos ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) is consistent with the 95 % limit
of $\sum m\_{\nu}<0.23\thinspace\thinspace\text{eV}$ reported in [258](#bib.bib258) for Planck+BAO. The limits are
similar because the linear CMB is insensitive to the mass of neutrinos that
are relativistic at recombination. There is little to be gained from improved
measurement of the CMB temperature power spectra, though improved external data
can help to break the geometric degeneracy to higher precision.
CMB lensing can also provide additional information at lower redshifts, and
future high-resolution CMB polarization measurements that accurately reconstruct
the lensing potential can probe much smaller masses
([Abazajian et al. 2015b](#bib.bib2), see, e.g.).

As discussed in detail in [258](#bib.bib258) and Sect. [5.1](#S5.SS1 "5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"), the
Planck CMB power spectra prefer somewhat more lensing smoothing than
predicted in $\rm{\Lambda CDM}$ (allowing the lensing amplitude to vary gives
$A\_{\rm L}>1$ at just over $2\thinspace\sigma$). The neutrino mass constraint from
the power spectra is therefore quite tight, since increasing the
neutrino mass lowers the predicted smoothing even further compared to
base $\rm{\Lambda CDM}$. On the other hand the lensing reconstruction data, which
directly probes the lensing power, prefers lensing amplitudes slightly
below (but consistent with) the base $\rm{\Lambda CDM}$ prediction
(Eq. [7](#S5.E7 "In 5.1.1 The Planck lensing likelihood ‣ 5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")). The Planck+lensing constraint therefore pulls
the constraints slightly away from zero towards higher neutrino
masses, as shown in Fig. [30](#S6.F30 "Figure 30 ‣ 6.4.1 Constraints on the total mass of active neutrinos ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). Although the
posterior has less weight at zero, the lensing data are
incompatible with very large neutrino masses so the
Planck+lensing 95 % limit is actually
tighter than the Planck TT+lowP result:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sum m\_{\nu}<0.68\thinspace\thinspace\text{eV}\quad(95\%,\text{{Planck}\ TT{+}lowP{+}lensing}).$ |  | (44) |

Adding the polarization spectra improves this constraint slightly to

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sum m\_{\nu}<0.59\thinspace\thinspace\text{eV}\quad(95\%,\text{{Planck}\ TT,TE,EE{+}lowP{+}lensing}).$ |  | (45) |

We take the combined constraint that further includes BAO, JLA, and $H\_{0}$
(“ext”) as our best limit:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\begin{aligned} \sum m\_{\nu}&<0.23\thinspace\thinspace\text{eV}\\ \Omega\_{\nu}h^{2}&<0.0025\end{aligned}\ \right\}\ \ \mbox{95\%, \text{{Planck}\ TT{+}lowP{+}lensing{+}ext. }}$ |  | (46) |

This is slightly weaker than the constraint from Planck TT,TE,EE+lowP+lensing+BAO
(which is tighter in both the CamSpec and Plik likelihoods), but is immune
to low level systematics that might affect the constraints from the Planck polarization spectra. Equation ([46](#S6.E46 "In 6.4.1 Constraints on the total mass of active neutrinos ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) is therefore a conservative limit.
Marginalizing over the range of neutrino masses, the Planck constraints on
the late-time parameters are2828
28
To simplify the
displayed equations, $H\_{0}$ is given in units of $\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$ in this section.

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\begin{aligned} H\_{0}=67.7\pm 0.6\\ \sigma\_{8}=0.810^{+0.015}\_{-0.012}\end{aligned}\ \right\}\ \ \mbox{\text{{Planck}\ TT{+}lowP{+}lensing{+}ext.}}$ |  | (47) |

For this restricted range of neutrino masses, the impact on the other
cosmological parameters is small and, in particular, low values of $\sigma\_{8}$
will remain in tension with the parameter space preferred by Planck.

Figure 30: Constraints on the sum of the neutrino masses for various data
combinations.

The constraint of Eq. ([46](#S6.E46 "In 6.4.1 Constraints on the total mass of active neutrinos ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) is weaker than the constraint of
Eq. ([43b](#S6.E2f "In 6.4.1 Constraints on the total mass of active neutrinos ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) excluding lensing, but there is no good
reason to disregard the Planck lensing information while retaining other
astrophysical data. The CMB lensing signal probes very-nearly linear scales and
passes many consistency checks over the multipole range used in the
Planck lensing likelihood (see Sect. [5.1](#S5.SS1 "5.1 CMB lensing measured by Planck ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") and
[Planck Collaboration
XV 2016](#bib.bib276)). The situation with galaxy weak lensing is
rather different, as discussed in Sect. [5.5.2](#S5.SS5.SSS2 "5.5.2 Weak gravitational lensing ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"). In addition to
possible observational systematics, the weak lensing data probe lower
redshifts than CMB lensing, and smaller spatial scales, where uncertainties
in modelling nonlinearities in the matter power spectrum and baryonic
feedback become important ([Harnois-Déraps et al. 2015](#bib.bib160)).

A larger range of neutrino masses was found by [Beutler et al. (2014)](#bib.bib49)
using a combination of RSD, BAO, and weak lensing information. The
tension between the RSD results and base $\rm{\Lambda CDM}$ was subsequently
reduced following the analysis of [Samushia et al. (2014)](#bib.bib304), as shown in
Fig. [17](#S5.F17 "Figure 17 ‣ 5.5.1 Redshift space distortions ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"). Galaxy weak lensing and some cluster constraints
remain in tension with base $\rm{\Lambda CDM}$, and we discuss possible neutrino
resolutions of these problems in Sect. [6.4.4](#S6.SS4.SSS4 "6.4.4 Neutrino models and tension with external data ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters").

Another way of potentially improving neutrino mass constraints is to use measurements of the Ly$\alpha$ flux
power spectrum of high-redshift quasars. [Palanque-Delabrouille et al. (2015)](#bib.bib245) have recently reported an
analysis of a large sample of quasar spectra from the SDSSIII/BOSS survey. When combining their results
with 2013 Planck data, these authors find a bound $\sum m\_{\nu}<0.15\thinspace\thinspace\text{eV}$ (95 % CL),
compatible with the results presented in this section.

An exciting future prospect is the possible direct detection of
non-relativistic cosmic neutrinos by capture on tritium, for example
with the PTOLEMY
experiment ([Cocco et al. 2007](#bib.bib84); [Betts et al. 2013](#bib.bib45); [Long et al. 2014](#bib.bib214)). Unfortunately,
for the mass range $\sum m\_{\nu}<0.23\thinspace\thinspace\text{eV}$ preferred by Planck, detection
with the first generation experiment will be extremely difficult.

#### 6.4.2 Constraints on $N\_{\rm eff}$

Figure 31: Samples from Planck TT+lowP chains in the
$N\_{\rm eff}$–$H\_{0}$ plane, colour-coded by $\sigma\_{8}$. The grey bands show the
constraint $H\_{0}=(70.6\pm 3.3)\thinspace\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$ of Eq. ([19](#S5.E19 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")).
Notice that higher $N\_{\rm eff}$ brings $H\_{0}$ into better consistency with direct
measurements, but increases $\sigma\_{8}$.
Solid black contours show the constraints from Planck TT,TE,EE+lowP+BAO.
Models with $N\_{\rm eff}<3.046$ (left of the solid vertical line) require photon
heating after neutrino decoupling or incomplete thermalization. Dashed vertical
lines correspond to specific fully-thermalized particle models, for example
one additional massless boson that decoupled around the same time as the
neutrinos ($\Delta N\_{\rm eff}\approx 0.57$), or before muon annihilation
($\Delta N\_{\rm eff}\approx 0.39$), or an additional sterile neutrino that decoupled
around the same time as the active neutrinos ($\Delta N\_{\rm eff}\approx 1$).

Dark radiation density in the early Universe is usually parameterized
by $N\_{\rm eff}$, defined so that the total relativistic
energy density in neutrinos and any other dark radiation is given in
terms of the photon density $\rho\_{\gamma}$ at $T\ll 1\thinspace\thinspace\text{MeV}$ by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\rho=N\_{\rm eff}\frac{7}{8}\left(\frac{4}{11}\right)^{4/3}\rho\_{\gamma}.$ |  | (48) |

The numerical factors in this equation are included so that $N\_{\rm eff}=3$
for three standard model neutrinos that were thermalized in the early
Universe and decoupled well before electron-positron annihilation.
The standard cosmological prediction is actually $N\_{\rm eff}=3.046$, since
neutrinos are not completely decoupled at electron-positron
annihilation and are subsequently slightly
heated ([Mangano et al. 2002](#bib.bib223)).

In this section we focus on additional energy density from massless
particles. In addition to massless sterile neutrinos, a variety of
other particles could contribute to $N\_{\rm eff}$. We assume that the
additional massless particles are produced well before recombination,
and neither interact nor decay, so that their energy density scales
with the expansion exactly like massless neutrinos. An additional
$\Delta N\_{\rm eff}=1$ could correspond to a fully thermalized sterile
neutrino that decoupled at $T\la 100\thinspace\thinspace\text{MeV}$; for example, any sterile
neutrino with mixing angles large enough to provide a potential
resolution to short-baseline reactor neutrino oscillation anomalies
would most likely thermalize rapidly in the early Universe. However,
this solution to the neutrino oscillation anomalies requires approximately
1-eV sterile neutrinos, rather than the massless case considered in this
section; exploration of the two parameters $N\_{\rm eff}$ and $\sum m\_{\nu}$ is
reported in Sect. [6.4.3](#S6.SS4.SSS3 "6.4.3 Simultaneous constraints on 𝑁_eff and neutrino mass ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). For a review of sterile
neutrinos see [Abazajian et al. (2012)](#bib.bib3).

More generally the additional radiation does not need to be fully
thermalized, for example there are many possible models of non-thermal
radiation production via particle decays ([Hasenkamp & Kersten 2013](#bib.bib162); [Conlon & Marsh 2013](#bib.bib87), see,
e.g.,). The radiation could also
be produced at temperatures $T>100\thinspace\thinspace\text{MeV}$, in which case typically
$\Delta N\_{\rm eff}<1$ for each additional species, since heating by photon
production at muon annihilation (corresponding to $T\approx 100\thinspace\thinspace\text{MeV}$)
decreases the fractional importance of the additional component at the later
times relevant for the CMB. For particles produced at $T\gg 100\thinspace\thinspace\text{MeV}$ the
density would be diluted even more by numerous phase transitions and
particle annihilations, and give $\Delta N\_{\rm eff}\ll 1$. Furthermore, if
the particle is not fermionic, the factors entering the entropy
conservation equation are different, and even thermalized particles
could give specific fractional values of $\Delta N\_{\rm eff}$. For
example [Weinberg (2013)](#bib.bib347) considers the case of a thermalized
massless boson, which contributes $\Delta N\_{\rm eff}=4/7\approx 0.57$ if
it decouples in the range $0.5\thinspace\thinspace\text{MeV}<T<100\thinspace\thinspace\text{MeV}$ like the neutrinos,
or $\Delta N\_{\rm eff}\approx 0.39$ if it decouples at $T>100\thinspace\thinspace\text{MeV}$ (before the
photon production at muon annihilation, hence undergoing
fractional dilution).

In this paper we follow the usual phenomenological approach, where one
constrains $N\_{\rm eff}$ as a free parameter with a wide flat prior, although we
comment on a few discrete cases separately below. Values
of $N\_{\rm eff}<3.046$ are less well motivated, since they would require the
standard neutrinos to be incompletely thermalized or additional photon
production after neutrino decoupling, but we include this range for
completeness.

Figure [31](#S6.F31 "Figure 31 ‣ 6.4.2 Constraints on 𝑁_eff ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") shows that Planck is entirely consistent with
the standard value $N\_{\rm eff}=3.046$. However, a significant density of
additional radiation is still allowed, with the (68 %) constraints

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle N\_{\rm eff}$ | $\displaystyle=$ | $\displaystyle 3.13\pm 0.32\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP},$ |  | (49a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle N\_{\rm eff}$ | $\displaystyle=$ | $\displaystyle 3.15\pm 0.23\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP}{+}{\rm BAO},$ |  | (49b) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle N\_{\rm eff}$ | $\displaystyle=$ | $\displaystyle 2.99\pm 0.20\quad\textit{Planck}\ {\rm TT,TE,EE}{+}{\rm lowP},$ |  | (49c) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle N\_{\rm eff}$ | $\displaystyle=$ | $\displaystyle 3.04\pm 0.18\quad\textit{Planck}\ {\rm TT,TE,EE}{+}{\rm lowP}{+}{\rm BAO}.$ |  | (49d) |

Notice the significantly tighter constraint with the inclusion of Planck high-$\ell$ polarization, with $\Delta N\_{\rm eff}<1$ at over $4\thinspace\sigma$ from
Planck alone. This constraint is not very stable between likelihoods, with
the CamSpec likelihood giving a roughly $0.8\thinspace\sigma$
*lower* value of $N\_{\rm eff}$. However, the strong limit from polarization is
also consistent with the joint Planck TT+lowP+BAO result, so Eq. ([49b](#S6.E2g "In 6.4.2 Constraints on 𝑁_eff ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) leads
to the robust conclusion that $\Delta N\_{\rm eff}<1$ at over $3\thinspace\sigma$. The
addition of Planck lensing has very little effect on this constraint.

For $N\_{\rm eff}>3$, the Planck data favour higher values of the
Hubble parameter than the Planck base $\rm{\Lambda CDM}$ value, which as discussed
in Sect. [5.4](#S5.SS4 "5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters") may be in better agreement with some direct
measurements of $H\_{0}$ . This is because Planck accurately measures the
acoustic scale $r\_{\ast}/D\_{\rm A}$; increasing $N\_{\rm eff}$ means (via the Friedmann
equation) that the early Universe expands faster, so the sound horizon
at recombination, $r\_{\ast}$, is smaller and hence recombination has to be
closer (larger $H\_{0}$ and hence smaller $D\_{\rm A}$) for it to subtend the
same angular size observed by Planck. However, models with $N\_{\rm eff}>3$ and a
higher Hubble constant also have higher values of the fluctuation amplitude
$\sigma\_{8}$, as shown by the coloured samples in Fig. [31](#S6.F31 "Figure 31 ‣ 6.4.2 Constraints on 𝑁_eff ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters").
As a result, these models increase the tensions
between the CMB measurements and astrophysical measurements of $\sigma\_{8}$
discussed in Sect. [5.6](#S5.SS6 "5.6 Cosmic concordance? ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"). It therefore seems
unlikely that additional radiation alone can help to resolve tensions
with large-scale structure data.

The energy density in the early Universe can also be probed by the
predictions of BBN. In particular
$\Delta N\_{\rm eff}>0$ increases the primordial expansion rate, leading to
earlier freeze-out, with a higher neutron density and hence a greater
abundance of helium and deuterium after BBN has completed. A detailed
discussion of the implications of Planck for BBN is given in
Sect. [6.5](#S6.SS5 "6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). Observations of
both the primordial helium and deuterium abundance are compatible with the
predictions of standard BBN for the Planck base $\rm{\Lambda CDM}$ value of the baryon
density. The Planck+BBN constraints on $N\_{\rm eff}$
(Eqs. [64](#S6.E64 "In 6.5.2 Primordial abundances from Planck data and standard BBN ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") and [65](#S6.E65 "In 6.5.2 Primordial abundances from Planck data and standard BBN ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"))
are compatible, and slightly tighter than Eq. ([49b](#S6.E2g "In 6.4.2 Constraints on 𝑁_eff ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")).

Although there is a large continuous range of plausible $N\_{\rm eff}$ values,
it is worth mentioning briefly a few of the discrete values
from fully thermalized models. This serves as an indication of how strongly
Planck prefers base $\rm{\Lambda CDM}$, and also how the inferred values of other
cosmological parameters might be affected by this particular extension to base
$\rm{\Lambda CDM}$. As discussed above, one fully
thermalized neutrino ($\Delta N\_{\rm eff}\approx 1$) is ruled out at over
$3\thinspace\sigma$, and is disfavoured by $\Delta\chi^{2}\approx 8$ compared to
base $\rm{\Lambda CDM}$ by Planck TT+lowP, and much more strongly in combination with Planck high-$\ell$ polarization or BAO data. The thermalized boson models that give
$\Delta N\_{\rm eff}=0.39$ or $\Delta N\_{\rm eff}=0.57$ are disfavoured by
$\Delta\chi^{2}\approx 1.5$ and $\Delta\chi^{2}\approx 3$, respectively, and are
therefore not strongly excluded. We focus on the former, since it is
also consistent with the Planck TT+lowP+BAO constraint at $2\thinspace\sigma$. As shown
in Fig. [31](#S6.F31 "Figure 31 ‣ 6.4.2 Constraints on 𝑁_eff ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"), larger $N\_{\rm eff}$ corresponds to a region
of parameter space with significantly higher Hubble parameter,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $H\_{0}=70.6\pm 1.0\quad(68\%,\text{{Planck}\ TT{+}lowP; $\Delta N\_{\rm eff}=0.39$}).$ |  | (50) |

This can be compared to
the direct measurements of $H\_{0}$ discussed in Sect. [5.4](#S5.SS4 "5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters").
Evidently, Eq. ([50](#S6.E50 "In 6.4.2 Constraints on 𝑁_eff ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) is consistent with the $H\_{0}$ prior
adopted in this paper (Eq. [19](#S5.E19 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")), but this example shows
that an accurate direct measurement of $H\_{0}$ can potentially provide
evidence for new physics beyond that probed by Planck.
As shown in Fig. [31](#S6.F31 "Figure 31 ‣ 6.4.2 Constraints on 𝑁_eff ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"), the $\Delta N\_{\rm eff}=0.39$ cosmology also
has a significantly higher small-scale fluctuation amplitude and the spectral
index $n\_{\rm s}$ is also bluer, with

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\begin{aligned} \sigma\_{8}=0.850\pm 0.015\\ n\_{\rm s}=0.983\pm 0.006\end{aligned}\ \right\}\ \ \mbox{\text{{Planck}\ TT{+}lowP; $\Delta N\_{\rm eff}=0.39$.}}$ |  | (51) |

The $\sigma\_{8}$ range in this model is higher than preferred by the Planck lensing likelihood in base $\rm{\Lambda CDM}$. However, the fit to the Planck lensing
likelihood is model dependent and the lensing degeneracy direction also
associates high $H\_{0}$ and low $\Omega\_{\mathrm{m}}$ values with higher $\sigma\_{8}$. The joint
Planck TT+lowP+lensing constraint does pull $\sigma\_{8}$ down slightly to
$\sigma\_{8}=0.84\pm 0.01$ and provides an acceptable fit to the Planck data.
For Planck TT+lowP+lensing, the difference in $\chi^{2}$ between the best
fit base $\rm{\Lambda CDM}$ model and the extension with $\Delta N\_{\rm eff}=0.39$ is only
$\Delta\chi^{2}\_{\rm CMB}\approx 2$.
The higher spectral index with $\Delta N\_{\rm eff}=0.39$ gives a decrease in
large-scale power, fitting the low $\ell<30$ Planck $TT$ spectrum better
by $\Delta\chi^{2}\approx 1$, but at the same time the high-$\ell$ data prefer
$\Delta N\_{\rm eff}\approx 0$. Correlations with other cosmological parameters can be
seen in Fig. [20](#S6.F20 "Figure 20 ‣ 6.1 Grid of models ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters").
Clearly, a very effective way of testing these models would be to obtain
reliable, accurate, astrophysical measurements of $H\_{0}$ and $\sigma\_{8}$.

In summary, models with $\Delta N\_{\rm eff}=1$ are disfavoured by
Planck combined with BAO data at about the $3\thinspace\sigma$ level. Models
with fractional changes of $\Delta N\_{\rm eff}\approx 0.39$ are mildly
disfavoured by Planck, but require higher $H\_{0}$ and $\sigma\_{8}$
compared to base $\rm{\Lambda CDM}$.

#### 6.4.3 Simultaneous constraints on $N\_{\rm eff}$ and neutrino mass

Figure 32: Samples from Planck TT+lowP in the
$N\_{\rm eff}$–$m\_{\nu,\thinspace\mathrm{sterile}}^{\mathrm{eff}}$ plane, colour-coded by $\sigma\_{8}$, for models
with one massive sterile neutrino family, with effective mass $m\_{\nu,\thinspace\mathrm{sterile}}^{\mathrm{eff}}$,
and the three active neutrinos as in the base $\rm{\Lambda CDM}$ model.
The physical mass of the sterile neutrino in the thermal scenario,
$m\_{\rm sterile}^{\rm thermal}$, is constant along the grey dashed lines, with
the indicated mass in $\mathrm{eV}$; the grey shading shows the region
excluded by our prior $m\_{\rm sterile}^{\rm thermal}<10\thinspace\thinspace\text{eV}$,
which cuts out most of the area where the neutrinos behave nearly like
dark matter. The physical mass in the Dodelson-Widrow
scenario, $m\_{\rm sterile}^{\rm DW}$, is constant along the dotted lines
(with the value indicated on the adjacent dashed lines).

As discussed in the previous sections, neither a higher neutrino mass
nor additional radiation density alone can
resolve all of the tensions between Planck and other astrophysical data.
However, the presence of additional massive
particles, such as massive sterile neutrinos, could potentially
improve the situation by introducing enough freedom to allow
higher values of the Hubble constant *and*
lower values of $\sigma\_{8}$. As mentioned in Sect. [6.4.2](#S6.SS4.SSS2 "6.4.2 Constraints on 𝑁_eff ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"),
massive sterile neutrinos offer a possible solution to reactor neutrino
oscillation anomalies ([Kopp et al. 2013](#bib.bib198); [Giunti et al. 2013](#bib.bib144)) and this has led to
significant recent interest in this class of
models ([Hamann & Hasenkamp 2013](#bib.bib155); [Wyman et al. 2014](#bib.bib352); [Battye & Moss 2014](#bib.bib32); [Leistedt et al. 2014](#bib.bib204); [Bergström et al. 2014](#bib.bib41); [MacCrann et al. 2015](#bib.bib220)). Alternatively,
active neutrinos could have significant degenerate masses above the
minimal baseline value together with additional massless particles contributing
to $N\_{\rm eff}$. Many more complicated scenarios could also be envisaged.

Figure 33: 68 % and 95 % constraints from Planck TT+lowP (green),
Planck TT+lowP+lensing (grey), and Planck TT+lowP+lensing+BAO (red) on the
late-Universe parameters $H\_{0}$, $\sigma\_{8}$, and $\Omega\_{\mathrm{m}}$ in various
neutrino extensions of the base $\rm{\Lambda CDM}$ model. The blue contours show
the base $\rm{\Lambda CDM}$ constraints from Planck TT+lowP+lensing+BAO. The dashed
cyan contours show joint constraints from the H13 CFHTLenS galaxy weak
lensing likelihood (with angular cuts as in
Fig. [18](#S5.F18 "Figure 18 ‣ 5.5.2 Weak gravitational lensing ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")) at constant CMB acoustic scale $\theta\_{\rm MC}$ (fixed to
the Planck TT+lowP $\rm{\Lambda CDM}$ best fit) combined with BAO and the Hubble constant
measurement of Eq. ([19](#S5.E19 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")). These additional constraints break large
parameter degeneracies in the weak lensing likelihood that would
otherwise obscure the comparison with the Planck contours. Here priors
on other parameters applied to the CFHTLenS analysis are as described
in Sect. [5.5.2](#S5.SS5.SSS2 "5.5.2 Weak gravitational lensing ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters").

In the case of massless radiation density, the cosmological
predictions are independent of the actual form of the distribution function,
since all particles travel at the speed of light. However, for
massive particles the results are more model dependent. To formulate a
well-defined model, we follow [258](#bib.bib258) and consider the
case of one massive sterile neutrino parameterized by
$m\_{\nu,\thinspace\mathrm{sterile}}^{\mathrm{eff}}\equiv(94.1\thinspace\Omega\_{\nu,{\rm sterile}}h^{2})\thinspace\thinspace\text{eV}$,
in addition to the two approximately massless and one massive neutrino
of the baseline model. For thermally-distributed sterile
neutrinos, $m\_{\nu,\thinspace\mathrm{sterile}}^{\mathrm{eff}}$ is related to the true mass via

|  |  |  |  |
| --- | --- | --- | --- |
|  | $m\_{\nu,\thinspace\mathrm{sterile}}^{\mathrm{eff}}=(T\_{\mathrm{s}}/T\_{\nu})^{3}m\_{\rm sterile}^{\rm thermal}=(\Delta N\_{\rm eff})^{3/4}m\_{\rm sterile}^{\rm thermal}\thinspace,$ |  | (52) |

and for the cosmologically-equivalent Dodelson-Widrow (DW) case
([Dodelson & Widrow 1994](#bib.bib100)) the relation is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $m\_{\nu,\thinspace\mathrm{sterile}}^{\mathrm{eff}}=\chi\_{\rm s}\thinspace m\_{\rm sterile}^{\rm DW}\thinspace,$ |  | (53) |

with $\Delta N\_{\rm eff}=\chi\_{\rm s}$.
We impose a prior on the physical thermal mass, $m\_{\rm sterile}^{\rm thermal}<10\thinspace\thinspace\text{eV}$,
when generating parameter chains, to exclude regions of parameter space in
which the particles are so massive that their effect on the CMB spectra
is identical to that of cold dark matter. Although we consider only
the specific case of one massive sterile neutrino with a thermal (or DW)
distribution, our constraints will be reasonably accurate for other models,
for example  eV-mass particles produced as non-thermal decay
products ([Hasenkamp 2014](#bib.bib161)).

Figure [32](#S6.F32 "Figure 32 ‣ 6.4.3 Simultaneous constraints on 𝑁_eff and neutrino mass ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") shows that although Planck is
perfectly consistent with no massive sterile neutrinos, a significant
region of parameter space with fractional $\Delta N\_{\rm eff}$ is allowed,
where $\sigma\_{8}$ is lower than in the base $\rm{\Lambda CDM}$ model. This is also
the case for massless sterile neutrinos combined with massive active
neutrinos. In the single massive sterile model, the combined
constraints are

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\begin{aligned} N\_{\rm eff}&<3.7\\ m\_{\nu,\thinspace\mathrm{sterile}}^{\mathrm{eff}}&<0.52\thinspace\thinspace\text{eV}\end{aligned}\ \right\}\ \ \mbox{95\%, \text{{Planck}\ TT{+}lowP+lensing+BAO.}}$ |  | (54) |

The upper tail of $m\_{\nu,\thinspace\mathrm{sterile}}^{\mathrm{eff}}$ is largely associated with high physical
masses near to the prior cutoff; if instead we restrict to the region where
$m\_{\rm sterile}^{\rm thermal}<2\thinspace\thinspace\text{eV}$ the constraint is

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\begin{aligned} N\_{\rm eff}&<3.7\\ m\_{\nu,\thinspace\mathrm{sterile}}^{\mathrm{eff}}&<0.38\thinspace\thinspace\text{eV}\end{aligned}\ \right\}\ \ \mbox{95\%, \text{{Planck}\ TT{+}lowP+lensing+BAO.}}$ |  | (55) |

Massive sterile neutrinos with mixing angles large enough to help resolve the
reactor anomalies would typically imply full thermalization in the early
Universe, and hence give $\Delta N\_{\rm eff}=1$ for each additional species. Such a
high value of $N\_{\rm eff}$, especially combined with
$m\_{\rm sterile}\approx 1\thinspace\thinspace\text{eV}$, as required by reactor anomaly solutions,
were virtually ruled out by previous cosmological
data ([Mirizzi et al. 2013](#bib.bib230); [Archidiacono et al. 2013a](#bib.bib21); [Gariazzo et al. 2013](#bib.bib138)). This
conclusion is strengthened by the analysis presented here, since $N\_{\rm eff}=4$ is
excluded at greater than 99 % confidence. Unfortunately, there does not
appear to be a consistent resolution to the reactor anomalies, unless
thermalization of the massive neutrinos can be suppressed, for example,
by large lepton asymmetry, new interactions, or particle decay
(see [Gariazzo et al. 2014](#bib.bib139); [Bergström et al. 2014](#bib.bib41), and references therein).

We have also considered the case of additional radiation and degenerate
massive active neutrinos, with the combined constraint

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\begin{aligned} N\_{\rm eff}&=3.2\pm 0.5\\ \sum m\_{\nu}&<0.32\thinspace\thinspace\text{eV}\end{aligned}\ \right\}\ \ \mbox{95\%, \text{{Planck}\ TT{+}lowP+lensing+BAO.}}$ |  | (56) |

Again Planck shows no evidence for a deviation from the base $\rm{\Lambda CDM}$ model.

#### 6.4.4 Neutrino models and tension with external data

The extended models discussed in this section allow Planck to be
consistent with a wider range of late-Universe parameters than in base
$\rm{\Lambda CDM}$. Figure [33](#S6.F33 "Figure 33 ‣ 6.4.3 Simultaneous constraints on 𝑁_eff and neutrino mass ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") summarizes the constraints on
$\Omega\_{\mathrm{m}}$, $\sigma\_{8}$, and $H\_{0}$ for the various models that we have
considered. The inferred Hubble parameter can increase or decrease, as
required to maintain the observed acoustic scale, depending on the
relative contribution of additional radiation (changing the sound
horizon) and neutrino mass (changing mainly the angular diameter
distance). However, all of the models follow similar degeneracy
directions in the $\Omega\_{\mathrm{m}}$–$\sigma\_{8}$ and $H\_{0}$–$\sigma\_{8}$ planes,
so these models remain predictive: large common areas of the parameter
space are excluded in all of these models. The two-parameter
extensions are required to fit substantially lower values of $\sigma\_{8}$ without
also decreasing $H\_{0}$ below the values determined from direct measurements,
but the scope for doing this is clearly limited.

External data sets need to be reanalysed consistently in extended
models, since the extensions change the growth of
structure, angular distances, and the matter-radiation equality
scale. For example, the dashed lines in
Fig. [33](#S6.F33 "Figure 33 ‣ 6.4.3 Simultaneous constraints on 𝑁_eff and neutrino mass ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") show how different models affect the
CFHTLenS galaxy weak lensing constraints from [Heymans et al. (2013)](#bib.bib165) (see
Sect. [5.5.2](#S5.SS5.SSS2 "5.5.2 Weak gravitational lensing ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")), when restricted to the region of parameter
space consistent with the Planck acoustic scale measurements and the local
Hubble parameter. The filled green, grey, and red contours in
Fig. [33](#S6.F33 "Figure 33 ‣ 6.4.3 Simultaneous constraints on 𝑁_eff and neutrino mass ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") show the CMB constraints on these models for
various data combinations. The tightest of these constraints comes from the
Planck TT+lowP+lensing+BAO combination. The blue contours show the constraints in
the base $\rm{\Lambda CDM}$ cosmology. The red contours are broader than the
blue contours and there is greater overlap with the CFHTLenS contours,
but this offers only a marginal improvement compared to base $\rm{\Lambda CDM}$
(compare with Fig. [18](#S5.F18 "Figure 18 ‣ 5.5.2 Weak gravitational lensing ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"); see also the discussions in
[Leistedt et al. 2014](#bib.bib205) and [Battye et al. 2015](#bib.bib31)).
For each of these models, the CFHTLenS results
prefer lower values of $\sigma\_{8}$. Allowing for a higher neutrino mass lowers
$\sigma\_{8}$ from Planck, but does not help alleviate the discrepancy with the
CFHTLenS data, since the Planck data prefer a lower value of $H\_{0}$. A joint
analysis of the CFHTLenS likelihood with Planck TT+lowP shows a $\Delta\chi^{2}<1$
preference for the extended neutrino models compared to base $\rm{\Lambda CDM}$, and the
fits to Planck TT+lowP are worse in all cases. In base $\rm{\Lambda CDM}$ the
CFHTLenS data prefer a region of parameter space $\Delta\chi^{2}\approx 4$
away from the Planck TT+lowP+CFHTLenS joint fit, indicative of the tension
between the data sets. This is only slightly relieved to
$\Delta\chi^{2}\approx 3$ in the extended models.

In summary, modifications to the neutrino sector alone cannot easily
explain the discrepancies between Planck and other
astrophysical data described in Sect. [5.5](#S5.SS5 "5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"), including
the inference of a low value of $\sigma\_{8}$ from rich cluster counts.

#### 6.4.5 Testing perturbations in the neutrino background

As shown in the previous sections, the Planck data provide evidence for a
cosmic neutrino background at a very high significance level. Neutrinos affect
the CMB anisotropies at the background level, by changing the expansion rate
before recombination and hence relevant quantities such as the sound horizon
and the damping scales. Neutrinos also affect the CMB anisotropies via their
perturbations. Perturbations in the neutrino background are coupled through
gravity to the perturbations in the photon background, and
can be described (for massless neutrinos) by the following set of
equations ([Hu 1998](#bib.bib174); [Hu et al. 1999](#bib.bib175); [Trotta & Melchiorri 2005](#bib.bib338); [Archidiacono et al. 2011](#bib.bib20)):

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\dot{\delta}\_{\nu}$ | $\displaystyle=$ | $\displaystyle\frac{\dot{a}}{a}\left(1-3c\_{\rm eff}^{2}\right)\left(\delta\_{\nu}+3\frac{\dot{a}}{a}\frac{q\_{\nu}}{k}\right)-k\left(q\_{\nu}+\frac{2}{3k}\dot{h}\right)\thinspace;$ |  | (57a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\dot{q}\_{\nu}$ | $\displaystyle=$ | $\displaystyle k\thinspace c\_{\rm eff}^{2}\left(\delta\_{\nu}+3\frac{\dot{a}}{a}\frac{q\_{\nu}}{k}\right)-\frac{\dot{a}}{a}q\_{\nu}-\frac{2}{3}k\pi\_{\nu}\thinspace;$ |  | (57b) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\dot{\pi}\_{\nu}$ | $\displaystyle=$ | $\displaystyle 3k\thinspace c\_{\rm vis}^{2}\left(\frac{2}{5}q\_{\nu}+\frac{4}{15k}(\dot{h}+6\dot{\eta})\right)-\frac{3}{5}kF\_{\nu,3}\thinspace;$ |  | (57c) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\dot{F}\_{\nu,\ell}$ | $\displaystyle=$ | $\displaystyle\frac{k}{2\ell+1}\left(\ell F\_{\nu,\ell-1}-\left(\ell+1\right)F\_{\nu,\ell+1}\right),\quad(\ell\geq 3)\thinspace.$ |  | (57d) |

Here dots denote derivatives with respect to conformal time, $\delta\_{\nu}$ is
the neutrino density contrast, $q\_{\nu}$ is the neutrino velocity perturbation,
$\pi\_{\nu}$ the anisotropic stress, $F\_{\nu,\ell}$ are higher-order
moments of the neutrino distribution function, and $h$ and $\eta$ are the
scalar metric perturbations in the synchronous gauge.
In these equations, $c\_{\rm eff}^{2}$ is the neutrino sound speed in its own
reference frame and $c\_{\rm vis}^{2}$ parameterizes the anisotropic stress.
For standard non-interacting massless neutrinos
$c\_{\rm eff}^{2}=c\_{\rm vis}^{2}=1/3$. Any deviation from the expected values
could provide a hint of non-standard physics in the neutrino sector.

A greater (lower) neutrino sound speed would increase (decrease) the
neutrino pressure, leading to a lower (higher) perturbation
amplitude. On the other hand, changing $c\_{\rm vis}^{2}$ alters the
viscosity of the neutrino fluid. For $c\_{\rm vis}^{2}=0$, the
neutrinos act as a perfect fluid, supporting undamped acoustic oscillations.

Figure 34: 1D posterior distributions
for the neutrino
perturbation parameters $c\_{\rm eff}^{2}$ (top) and $c\_{\rm vis}^{2}$ (bottom).
Dashed vertical
lines indicate the conventional values $c\_{\rm eff}^{2}=c\_{\rm vis}^{2}=1/3$.

Several previous studies have used this approach to constrain $c^{2}\_{\rm eff}$
and $c^{2}\_{\rm vis}$ using cosmological data
([Trotta & Melchiorri 2005](#bib.bib338); [Smith et al. 2012](#bib.bib322); [Archidiacono et al. 2013b](#bib.bib22); [Gerbino et al. 2013](#bib.bib141); [Audren et al. 2015](#bib.bib26), see, e.g.,),
with the motivation that deviations from the expected values could be a
hint of non-standard physics in the neutrino sector. Non-standard
interactions could involve, for example, neutrino coupling with light
scalar particles ([Hannestad 2005](#bib.bib158); [Beacom et al. 2004](#bib.bib33); [Bell 2005](#bib.bib35); [Sawyer 2006](#bib.bib306)). If neutrinos are strongly coupled at recombination,
this would result in a lower value for $c^{2}\_{\rm vis}$ than in the
standard model. Alternatively, the presence of early dark
energy that mimics a relativistic component at recombination could
possibly lead to a value for $c\_{\rm eff}^{2}$ that differs from $1/3$
([Calabrese et al. 2011](#bib.bib67), see, e.g.,).

In this analysis, for
simplicity, we assume $N\_{\rm eff}=3.046$ and massless neutrinos. By using
an equivalent parameterization for massive neutrinos ([Audren et al. 2015](#bib.bib26)) we
have checked that assuming one massive neutrino with
$\Sigma m\_{\nu}\approx 0.06$ eV, as in the base model used throughout this
paper, has no impact on the constraints on $c^{2}\_{\rm eff}$ and $c^{2}\_{\rm vis}$
reported in this section.2929
29
We also do not explore extended
cosmologies in this section, since no significant degeneracies are expected between
($\sum m\_{\nu}$, $N\_{\rm eff}$, $w$, $dn\_{\rm s}/d\ln k$) and ($c^{2}\_{\rm eff}$,
$c^{2}\_{\rm vis}$) ([Audren et al. 2015](#bib.bib26)). We adopt a flat prior between zero
and unity for both $c^{2}\_{\rm vis}$ and $c\_{\rm eff}^{2}$.

The top and bottom panels of Fig. [34](#S6.F34 "Figure 34 ‣ 6.4.5 Testing perturbations in the neutrino background ‣ 6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") show the
posterior distributions of $c^{2}\_{\rm eff}$ and $c^{2}\_{\rm vis}$ from
Planck TT+lowP, Planck TT+lowP+BAO, Planck TT,TE,EE+lowP, and Planck TT,TE,EE+lowP+BAO. The mean
values and 68 % errors on $c^{2}\_{\rm eff}$ and $c^{2}\_{\rm vis}$ are

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\left.\begin{aligned} c\_{\rm eff}^{2}&=0.312\pm 0.011\phantom{0}\\ c\_{\rm vis}^{2}&=0.47\_{-0.12}^{+0.26}\end{aligned}\ \right\}\ \ \mbox{\text{{Planck}\ TT{+}lowP,\phantom{,TE,EE+BAO}}}$ |  | (58a) |
|  | $\left.\begin{aligned} c\_{\rm eff}^{2}&=0.316\pm 0.010\phantom{0}\\ c\_{\rm vis}^{2}&=0.44\_{-0.10}^{+0.15}\end{aligned}\ \right\}\ \ \mbox{\text{{Planck}\ TT{+}lowP{+}BAO,\phantom{,TE,EE}}}$ |  | (58b) |
|  | $\left.\begin{aligned} c\_{\rm eff}^{2}&=0.3240\pm 0.0060\\ c\_{\rm vis}^{2}&=0.327\pm 0.037\end{aligned}\ \right\}\ \ \mbox{\text{{Planck}\ TT,TE,EE{+}lowP,\phantom{+BAO}}}$ |  | (58c) |
|  | $\left.\begin{aligned} c\_{\rm eff}^{2}&=0.3242\pm 0.0059\\ c\_{\rm vis}^{2}&=0.331\pm 0.037\end{aligned}\ \right\}\ \ \mbox{\text{{Planck}\ TT,TE,EE{+}lowP{+}BAO.}}$ |  | (58d) |

Constraints on these parameters are consistent with the conventional values
$c^{2}\_{\rm eff}=c^{2}\_{\rm vis}=1/3$. A vanishing value of $c\_{\rm vis}^{2}$,
which might imply a strong interaction between neutrinos and other species, is
excluded at more than the $95\thinspace\%$ level arising from the Planck temperature
data. This conclusion is greatly strengthened (to about $9\thinspace\sigma$) when
Planck polarization data are included. As discussed in
[Bashinsky & Seljak (2004)](#bib.bib29),
neutrino anisotropic stresses introduce a phase shift in the CMB angular
power spectra, which is more visible in polarization than temperature because
of the sharper acoustic peaks. This explains why we see such a dramatic
reduction in the error on $c\_{\rm vis}^{2}$ when including polarization data.

The precision of our results is consistent with the forecasts discussed
in [Smith et al. (2012)](#bib.bib322), and we find strong evidence, purely from CMB observations,
for neutrino anisotropies with the standard values
$c\_{\rm vis}^{2}=1/3$ and $c\_{\rm eff}^{2}=1/3$.

### 6.5 Primordial nucleosynthesis

#### 6.5.1 Details of analysis approach

Standard big bang nucleosynthesis (BBN) predicts light element
abundances as a function of parameters relevant to the CMB, such as
the baryon-to-photon density ratio $\eta\_{\mathrm{b}}\equiv n\_{\mathrm{b}}/n\_{\gamma}$, the radiation density parameterized by
$N\_{\mathrm{eff}}$, and the chemical potential of the electron
neutrinos. In [258](#bib.bib258), we presented consistency checks between the
Planck 2013 results, light element abundance data, and standard
BBN. The goal of Sect. [6.5.2](#S6.SS5.SSS2 "6.5.2 Primordial abundances from Planck data and standard BBN ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") below is to update these
results and to provide improved tests of the standard BBN model. In
Sect. [6.5.3](#S6.SS5.SSS3 "6.5.3 Constraints from Planck and deuterium observations on nuclear reaction rates ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") we show how Planck data can be used to
constrain nuclear reaction rates, and in Sect. [6.5.4](#S6.SS5.SSS4 "6.5.4 Model-independent bounds on the helium fraction from Planck ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") we
will present the most stringent CMB bounds to date on the primordial helium
fraction.

For simplicity, our analysis assumes a negligible leptonic asymmetry
in the electron neutrino sector. For a fixed photon temperature today
(which we take to be $T\_{0}=2.7255$ K), $\eta\_{\mathrm{b}}$ can be related to
$\omega\_{\mathrm{b}}\equiv\Omega\_{b}h^{2}$, up to a small (and negligible)
uncertainty associated
with the primordial helium fraction. Standard BBN then predicts the abundance
of each light element as a function of only two parameters,
$\omega\_{\mathrm{b}}$ and $\Delta N\_{\mathrm{eff}}\equiv N\_{\mathrm{eff}}-3.046$,
with a theoretical error coming mainly from uncertainties in the neutron
lifetime and a few nuclear reaction rates.

We will confine our discussion to BBN predictions for the primordial
abundances3030
30
BBN calculations usually refer to nucleon number density
fractions rather than mass fractions. To avoid any ambiguity with
the helium mass fraction $Y\_{\mathrm{P}}$, normally used in CMB physics,
we use superscripts to distinguish between the two definitions
$Y\_{\mathrm{P}}^{\mathrm{CMB}}$ and $Y\_{\mathrm{P}}^{\mathrm{BBN}}$. Typically,
$Y\_{\mathrm{P}}^{\mathrm{BBN}}$ is about 0.5 % higher
than $Y\_{\mathrm{P}}^{\mathrm{CMB}}$.
of 4He and deuterium, expressed, respectively as
$Y\_{\mathrm{P}}^{\mathrm{BBN}}=4n\_{\mathrm{He}}/n\_{\mathrm{b}}$ and $y\_{\mathrm{DP}}=10^{5}n\_{\mathrm{D}}/n\_{\mathrm{H}}$.
We will not discuss other light elements, such as
tritium and lithium, because the observed abundance measurements
and their interpretation is more controversial (see [Fields et al. 2014](#bib.bib120), for a recent
review). As in [258](#bib.bib258), the BBN predictions for
$Y\_{\mathrm{P}}^{\mathrm{BBN}}(\omega\_{\mathrm{b}},\Delta N\_{\mathrm{eff}}$) and
$y\_{\mathrm{DP}}(\omega\_{\mathrm{b}},\Delta N\_{\mathrm{eff}}$) are given by
Taylor expansions obtained with the PArthENoPE code
([Pisanti et al. 2008](#bib.bib255)), similar to the ones presented in [Iocco et al. (2009)](#bib.bib183),
but updated by the PArthENoPE team with the latest observational data on
nuclear rates and on the neutron life-time:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\begin{split}Y\_{\mathrm{P}}^{\mathrm{BBN}}&=0.2311+0.9502\omega\_{\mathrm{b}}-11.27\omega\_{\mathrm{b}}^{2}\\ \ \ &+\Delta N\_{\mathrm{eff}}\left(0.01356+0.008581\omega\_{\mathrm{b}}-0.1810\omega\_{\mathrm{b}}^{2}\right)\\ \ \ &+\Delta N\_{\mathrm{eff}}^{2}\left(-0.0009795-0.001370\omega\_{\mathrm{b}}+0.01746\omega\_{\mathrm{b}}^{2}\right)\thinspace;\end{split}$ | |  | (59) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\begin{split}y\_{\mathrm{DP}}&=18.754-1534.4\omega\_{\mathrm{b}}+48656\omega\_{\mathrm{b}}^{2}-552670\omega\_{\mathrm{b}}^{3}\\ \ \ &+\Delta N\_{\mathrm{eff}}\left(2.4914-208.11\omega\_{\mathrm{b}}+6760.9\omega\_{\mathrm{b}}^{2}-78007\omega\_{\mathrm{b}}^{3}\right)\\ \ \ &+\Delta N\_{\mathrm{eff}}^{2}\left(0.012907-1.3653\omega\_{\mathrm{b}}+37.388\omega\_{\mathrm{b}}^{2}-267.78\omega\_{\mathrm{b}}^{3}\right).\end{split}$ | |  | (60) |

By averaging over several
measurements, the Particle Data Group 2014 ([Olive et al. 2014](#bib.bib241))
estimates the neutron life-time to be $\tau\_{\rm n}=(880.3\pm 1.1)\thinspace{\rm s}$ at 68 % CL.3131
31
However, the most recent individual
measurement by [Yue et al. (2013)](#bib.bib353) gives $\tau\_{\rm n}=[887.8\pm 1.2\penalty\ \mathrm{(stat.)}\pm 1.9\penalty\ \mathrm{(syst.)}]\thinspace{\rm s}$, which is
discrepant at $3.3\thinspace\sigma$ with the previous average (including only
statistical errors). Hence one should bear in mind that systematic effects
could be underestimated in the Particle Data Group result. Adopting the central
value of [Yue et al. (2013)](#bib.bib353) would shift our results by a small amount (by a
factor of 1.0062 for $Y\_{\mathrm{P}}$ and 1.0036 for $y\_{\mathrm{DP}}$).
The expansions in Eqs. ([59](#S6.E59 "In 6.5.1 Details of analysis approach ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) and ([60](#S6.E60 "In 6.5.1 Details of analysis approach ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) are based on
this central value, and we assume that Eq. ([59](#S6.E59 "In 6.5.1 Details of analysis approach ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) predicts the
correct helium fraction
up to a standard error $\sigma(Y\_{\mathrm{P}}^{\mathrm{BBN}})=0.0003$,
obtained by propagating the error on $\tau\_{\rm n}$.

Figure 35: 
Predictions of standard BBN for the
primordial abundance of 4He (top) and deuterium (bottom), as a function of
the baryon density $\omega\_{\mathrm{b}}$. The width of the green stripes corresponds
to 68 % uncertainties on nuclear reaction rates and on the neutron lifetime.
The horizontal bands show observational bounds on primordial element abundances
compiled by various authors, and the red vertical band shows the
Planck TT+lowP+BAO bounds on $\omega\_{\mathrm{b}}$ (all with 68 % errors). The BBN
predictions and CMB results shown here assume $N\_{\mathrm{eff}}=3.046$ and no
significant lepton asymmetry.

The uncertainty on the deuterium fraction is dominated by that on the rate
of the reaction ${\rm d}({\rm p},\gamma)^{3}\mbox{He}$. For that rate,
in [258](#bib.bib258) we
relied on the result of [Serpico et al. (2004)](#bib.bib314), obtained by fitting several
experiments. The expansions of Eqs. ([59](#S6.E59 "In 6.5.1 Details of analysis approach ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) and ([60](#S6.E60 "In 6.5.1 Details of analysis approach ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"))
now adopt the latest experimental determination by [Adelberger et al. (2011)](#bib.bib9)
and use the best-fit expression in their equation (29). We also rely on the
uncertainty quoted in [Adelberger et al. (2011)](#bib.bib9)
and propagate it to the deuterium fraction. This gives
a standard error $\sigma(y\_{\mathrm{DP}})=0.06$, which is more conservative
than the error adopted in [258](#bib.bib258).

#### 6.5.2 Primordial abundances from Planck data and standard BBN

We first investigate the consistency of standard BBN and the CMB by fixing the
radiation density to its standard value, i.e., $N\_{\mathrm{eff}}=3.046$, based
on the assumption of standard neutrino decoupling and no extra light relics.
We can then use Planck data to measure $\omega\_{\mathrm{b}}$, assuming base
$\rm{\Lambda CDM}$, and test for consistency with experimental abundance measurements.
The 95 % CL bounds obtained for the base $\Lambda$CDM model for various
data combinations are

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\omega\_{\mathrm{b}}=\left\{\mathrm{\begin{tabular}[]{ll}$0.02222^{+0.00045}\_{-0.00043}$&{Planck}\ TT{+}lowP,\\ $0.02226^{+0.00040}\_{-0.00039}$&{Planck}\ TT{+}lowP{+}BAO,\\ $0.02225^{+0.00032}\_{-0.00030}$&{Planck}\ TT,TE,EE{+}lowP,\\ $0.02229^{+0.00029}\_{-0.00027}$&{Planck}\ TT,TE,EE{+}lowP{+}BAO,\end{tabular}}\right.$ |  | (61) |

corresponding to a predicted primordial 4He number density fraction
(95 % CL) of

|  |  |  |  |
| --- | --- | --- | --- |
|  | $Y\_{\mathrm{P}}^{\mathrm{BBN}}\!\!=\!\!\left\{\!\!\mathrm{\begin{tabular}[]{ll}$0.24665^{+(0.00020)\ 0.00063}\_{-(0.00019)\ 0.00063}$&\!\!\!\! {Planck}\ TT{+}lowP,\\ $0.24667^{+(0.00018)\ 0.00063}\_{-(0.00018)\ 0.00063}$&\!\!\!\! {Planck}\ TT{+}lowP{+}BAO,\\ $0.24667^{+(0.00014)\ 0.00062}\_{-(0.00014)\ 0.00062}$&\!\!\!\! {Planck}\ TT,TE,EE{+}lowP,\\ $0.24668^{+(0.00013)\ 0.00061}\_{-(0.00013)\ 0.00061}$&\!\!\!\! {Planck}\ TT,TE,EE{+}lowP{+}BAO,\end{tabular}}\right.$ |  | (62) |

and deuterium fraction (95 % CL)

|  |  |  |  |
| --- | --- | --- | --- |
|  | $y\_{\mathrm{DP}}=\left\{\mathrm{\begin{tabular}[]{ll}$2.620^{+(0.083)\ 0.15}\_{-(0.085)\ 0.15}$&{Planck}\ TT{+}lowP,\\ $2.612^{+(0.075)\ 0.14}\_{-(0.074)\ 0.14}$&{Planck}\ TT{+}lowP{+}BAO,\\ $2.614^{+(0.057)\ 0.13}\_{-(0.060)\ 0.13}$&{Planck}\ TT,TE,EE{+}lowP,\\ $2.606^{+(0.051)\ 0.13}\_{-(0.054)\ 0.13}$&{Planck}\ TT,TE,EE{+}lowP{+}BAO.\end{tabular}}\right.$ |  | (63) |

The first set of error bars (in parentheses) in Eqs. ([62](#S6.E62 "In 6.5.2 Primordial abundances from Planck data and standard BBN ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"))
and ([63](#S6.E63 "In 6.5.2 Primordial abundances from Planck data and standard BBN ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) reflect only the uncertainty on $\omega\_{\mathrm{b}}$.
The second set includes the theoretical uncertainty on the BBN predictions, added in
quadrature to the errors from $\omega\_{\mathrm{b}}$. The total errors in the
predicted helium abundances are dominated by the BBN uncertainty, as in
[258](#bib.bib258). For deuterium, the Planck 2015 results improve the determination
of $\omega\_{\mathrm{b}}$ to the point where the theoretical errors
are comparable or larger than the errors from the CMB. In other words, for
base $\rm{\Lambda CDM}$ the predicted abundances cannot be improved substantially by
further measurements of the CMB. This also means that Planck results
can, in principle, be used to investigate nuclear reaction rates that dominate
the theoretical uncertainty (see Sect. [6.5.3](#S6.SS5.SSS3 "6.5.3 Constraints from Planck and deuterium observations on nuclear reaction rates ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")).

The results of Eqs. ([62](#S6.E62 "In 6.5.2 Primordial abundances from Planck data and standard BBN ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) and ([63](#S6.E63 "In 6.5.2 Primordial abundances from Planck data and standard BBN ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) are well
within the ranges indicated by the latest measurements of primordial
abundances, as illustrated in Fig. [35](#S6.F35 "Figure 35 ‣ 6.5.1 Details of analysis approach ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). The helium data
compilation of [Aver et al. (2013)](#bib.bib27) gives $Y\_{\mathrm{P}}^{\mathrm{BBN}}=0.2465\pm 0.0097$ (68 % CL), and the Planck prediction is near the
middle of this range.3232
32
A substantial part of this error comes
from the regression to zero metallicity. The mean of the 17
measurements analysed by [Aver et al. (2013)](#bib.bib27) is $\langle Y\_{\mathrm{P}}^{\mathrm{BBN}}\rangle=0.2535\pm 0.0036$, i.e., about
$1.7\thinspace\sigma$ higher than the Planck predictions of
Eq. ([62](#S6.E62 "In 6.5.2 Primordial abundances from Planck data and standard BBN ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")). As summarized by
[Aver et al. (2013)](#bib.bib27) and [Peimbert (2008)](#bib.bib250), helium abundance measurements
derived from emission lines in low-metallicity H ii regions are
notoriously difficult and prone to systematic errors. As a result, many
discrepant helium abundance measurements can be found in the
literature. [Izotov et al. (2014)](#bib.bib184) have reported
$Y\_{\mathrm{P}}^{\mathrm{BBN}}=0.2551\pm 0.0022$, which is discrepant
with the base $\rm{\Lambda CDM}$ predictions by $3.4\thinspace\sigma$. Such a high
helium fraction could be accommodated by increasing $N\_{\rm eff}$ (see
Fig. [36](#S6.F36 "Figure 36 ‣ 6.5.2 Primordial abundances from Planck data and standard BBN ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") and Sect. [6.5.4](#S6.SS5.SSS4 "6.5.4 Model-independent bounds on the helium fraction from Planck ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")); however, at
present it is not clear whether the error quoted by
[Izotov et al. (2014)](#bib.bib184) accurately reflects systematic uncertainties,
including in particular the error in extrapolating to zero metallicity.

Historically, deuterium abundance measurements have shown excess scatter over
that expected from statistical errors, indicating the presence of systematic
uncertainties in the observations. Figure [35](#S6.F35 "Figure 35 ‣ 6.5.1 Details of analysis approach ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") shows
the data compilation of [Iocco et al. (2009)](#bib.bib183), $y\_{\mathrm{DP}}=2.87\pm 0.22$ (68 % CL), which includes measurements based on damped
Ly$\alpha$ and Lyman limit systems. We also show the more recent
results by [Cooke et al. (2014)](#bib.bib88) ([Pettini & Cooke 2012](#bib.bib254), see also) based
on their observations of low-metallicity damped Ly$\alpha$
absorption systems in two quasars (SDSS J1358+6522, $z\_{\rm abs}=3.06726$ and SDSS J1419+0829, $z\_{\rm abs}=3.04973$) and a reanalysis of
archival spectra of damped Ly$\alpha$ systems in three further
quasars that satisfy strict selection criteria. The
[Cooke et al. (2014)](#bib.bib88) analysis gives $y\_{\mathrm{DP}}=2.53\pm 0.04$
(68 % CL), somewhat lower than the central [Iocco et al. (2009)](#bib.bib183) value,
and with a much smaller error. The [Cooke et al. (2014)](#bib.bib88) value is almost
certainly the more reliable measurement, as evidenced by the consistency of
the deuterium abundances of the five systems in their analysis.
The Planck base $\rm{\Lambda CDM}$ predictions of Eq. ([63](#S6.E63 "In 6.5.2 Primordial abundances from Planck data and standard BBN ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")) lie within
1$\thinspace\sigma$ of the [Cooke et al. (2014)](#bib.bib88) result. This is a remarkable success
for the standard theory of BBN.

Figure 36: 
Constraints in the $\omega\_{\mathrm{b}}$–$N\_{\rm eff}$ plane from Planck and Planck+BAO data
(68 % and 95 % contours) compared to the predictions of BBN, given
primordial element abundance measurements.
We show the 68 % and 95 % confidence regions derived from 4He bounds
compiled by [Aver et al. (2013)](#bib.bib27) and from deuterium bounds compiled by
[Cooke et al. (2014)](#bib.bib88). In the CMB analysis, $N\_{\mathrm{eff}}$ is allowed to vary
as an additional parameter to base $\rm{\Lambda CDM}$, with $Y\_{\rm P}$ fixed as
a function of $\omega\_{\mathrm{b}}$ and $N\_{\mathrm{eff}}$, according to BBN
predictions. These constraints assume no significant
lepton asymmetry.

It is worth noting that the Planck data are so accurate that $\omega\_{\mathrm{b}}$ is
insensitive to the underlying cosmological model. In our grid of extensions
to base $\rm{\Lambda CDM}$ the largest degradation of the error in $\omega\_{\mathrm{b}}$ is in models
that allow $N\_{\rm eff}$ to vary. In these models, the mean value of $\omega\_{\mathrm{b}}$
is almost identical to that for base $\rm{\Lambda CDM}$, but the error on $\omega\_{\mathrm{b}}$
increases by about 30 %. The value of $\omega\_{\mathrm{b}}$ is stable to even more
radical changes to the cosmology, for example, adding general isocurvature
modes ([Planck Collaboration
XX 2016](#bib.bib279)).

If we relax the assumption that $N\_{\mathrm{eff}}=3.046$ (but adhere to
the hypothesis that electron neutrinos have a standard distribution,
with a negligible chemical potential), BBN predictions depend on both
parameters $(\omega\_{\mathrm{b}}$ and $N\_{\mathrm{eff}}$. Following
the same methodology as in Sect. 6.4.4 of
[258](#bib.bib258), we can identify the region of the
$\omega\_{\mathrm{b}}$–$N\_{\mathrm{eff}}$ parameter space that is
compatible with direct measurements of the primordial helium and
deuterium abundances, including the BBN theoretical errors.
This is illustrated in Fig. [36](#S6.F36 "Figure 36 ‣ 6.5.2 Primordial abundances from Planck data and standard BBN ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") for the
$N\_{\mathrm{eff}}$ extension to base $\rm{\Lambda CDM}$. The region preferred by CMB observations lies at the
intersection between the helium and deuterium abundance 68 % CL preferred
regions and is compatible with the standard value of $N\_{\rm eff}=3.046$.
This confirms the beautiful agreement between CMB and BBN
physics. Figure [36](#S6.F36 "Figure 36 ‣ 6.5.2 Primordial abundances from Planck data and standard BBN ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") also shows that the Planck polarization data help in reducing the degeneracy between
$\omega\_{\mathrm{b}}$ and $N\_{\mathrm{eff}}$.

We can actually make a more precise statement by combining the posterior
distribution on $\omega\_{\mathrm{b}}$ and $N\_{\mathrm{eff}})$ obtained for Planck with that inferred from helium and deuterium abundance, including
observational and theoretical errors. This provides joint CMB+BBN predictions
on these parameters. After marginalizing over $\omega\_{\mathrm{b}}$, the
95 % CL preferred ranges for $N\_{\mathrm{eff}}$ are

|  |  |  |  |
| --- | --- | --- | --- |
|  | $N\_{\mathrm{eff}}=\left\{\mathrm{\begin{tabular}[]{ll}$3.11\_{-0.57}^{+0.59}$&He+{Planck}\ TT{+}lowP,\\ $3.14\_{-0.43}^{+0.44}$&He+{Planck}\ TT{+}lowP{+}BAO,\\ $2.99\_{-0.39}^{+0.39}$&He+{Planck}\ TT,TE,EE{+}lowP,\end{tabular}}\right.$ |  | (64) |

when combining Planck with the helium abundance estimated by [Aver et al. (2013)](#bib.bib27), or

|  |  |  |  |
| --- | --- | --- | --- |
|  | $N\_{\mathrm{eff}}=\left\{\mathrm{\begin{tabular}[]{ll}$2.95\_{-0.52}^{+0.52}$&D+{Planck}\ TT{+}lowP,\\ $3.01\_{-0.37}^{+0.38}$&D+{Planck}\ TT{+}lowP{+}BAO,\\ $2.91\_{-0.37}^{+0.37}$&D+{Planck}\ TT,TE,EE{+}lowP,\end{tabular}}\right.$ |  | (65) |

when combining with the deuterium abundance measured by [Cooke et al. (2014)](#bib.bib88).
These bounds represent the best currently-available estimates of
$N\_{\mathrm{eff}}$ and are remarkably consistent with the standard
model prediction.

The allowed region in $\omega\_{\mathrm{b}}$–$N\_{\mathrm{eff}}$ space
does not increase significantly when other parameters are allowed to
vary at the same time. From our grid of extended models, we have checked that
this conclusion holds in models with neutrino masses, tensor
fluctuations, or running of the scalar spectral index, for example.

#### 6.5.3 Constraints from Planck and deuterium observations on nuclear reaction rates

We have seen that primordial element abundances estimated from direct
observations are consistent with those inferred from Planck data
under the assumption of standard BBN. However, the
Planck determination of $\omega\_{\mathrm{b}}$ is so precise that the
theoretical errors in the BBN predictions are now a dominant source of
uncertainty. As noted by [Cooke et al. (2014)](#bib.bib88), one can begin to
think about using CMB measurements together with accurate deuterium
abundance measurements to learn about the underlying BBN physics.

While for helium the theoretical error comes mainly from the uncertainties in
the neutron lifetime, for deuterium it is dominated by uncertainties in the
radiative capture process ${\rm d}({\rm p},\gamma)^{3}\mbox{He}$, converting
deuterium into helium. The present experimental uncertainty for the
$S$-factor at low energy (relevant for BBN), is in the range
6–10 % ([Ma et al. 1997](#bib.bib219)). However, as noted by several authors
([Nollett & Holder 2011](#bib.bib237); [Di Valentino et al. 2014](#bib.bib98), see, e.g.,) the best-fit value
of $S(E)$ inferred from experimental data in the range
$30\thinspace{\rm keV}\thinspace{\leq}\thinspace E\thinspace{\leq}\thinspace 300\thinspace{\rm keV}$
is about 5–10 % lower than theoretical
expectations ([Viviani et al. 2000](#bib.bib345); [Marcucci et al. 2005](#bib.bib225)). The
PArthENoPE BBN code assumes the lower experimental value
for ${\rm d}({\rm p},\gamma)^{3}\mbox{He}$, and this might explain why the
deuterium abundance determined by [Cooke et al. (2014)](#bib.bib88) is slightly lower than
the value inferred by Planck.

To investigate this further, following the methodology of [Di Valentino et al. (2014)](#bib.bib98),
we perform a combined analysis of Planck and deuterium observations,
to constrain the value of the ${\rm d}({\rm p},\gamma)^{3}\mbox{He}$
reaction rate.
As in [Di Valentino et al. (2014)](#bib.bib98), we parameterize the thermal rate $R\_{2}(T)$ of the
${\rm d}({\rm p},\gamma)^{3}\mbox{He}$ process in the
PArthENoPE code by introducing a rescaling factor $A\_{2}$ of the
experimental rate $R\_{2}^{\thinspace\rm ex}(T)$, i.e., $R\_{2}(T)=A\_{2}\thinspace R\_{2}^{\rm ex}(T)$,
and solve for $A\_{2}$ using various Planck+BAO data combinations, given
the [Cooke et al. (2014)](#bib.bib88) deuterium abundance measurements.

Assuming the base $\rm{\Lambda CDM}$ model we find (68 % CL)

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle A\_{2}$ | $\displaystyle=$ | $\displaystyle 1.106\pm 0.071\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP}\thinspace,$ |  | (66a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle A\_{2}$ | $\displaystyle=$ | $\displaystyle 1.098\pm 0.067\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP}{+}{\rm BAO}\thinspace,$ |  | (66b) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle A\_{2}$ | $\displaystyle=$ | $\displaystyle 1.110\pm 0.062\quad\textit{Planck}\ {\rm TT,TE,EE}{+}{\rm lowP}\thinspace,$ |  | (66c) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle A\_{2}$ | $\displaystyle=$ | $\displaystyle 1.109\pm 0.058\quad\textit{Planck}\ {\rm TT,TE,EE}{+}{\rm lowP}{+}{\rm BAO}\thinspace.$ |  | (66d) |

The posteriors for $A\_{2}$ are shown in Fig. [37](#S6.F37 "Figure 37 ‣ 6.5.3 Constraints from Planck and deuterium observations on nuclear reaction rates ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). These results
suggest that the ${\rm d}({\rm p},\gamma)^{3}\mbox{He}$ reaction rate may
be have been underestimated by about 10 %. Evidently, tests of the
standard BBN picture appear to have reached the point where they are
limited by uncertainties in nuclear reaction rates. There is therefore
a strong case to improve the precision of experimental measurements
([Anders et al. 2014](#bib.bib17), e.g.,) and theoretical computations of key
nuclear reaction rates relevant for BBN.

Figure 37: Posteriors for the $A\_{2}$ reaction rate parameter for
various data combinations. The vertical dashed line shows the value $A\_{2}=1$
that corresponds to the current experimental estimate of the
${\rm d}({\rm p},\gamma)^{3}\mbox{He}$ rate used in the PArthENoPE
BBN code.

#### 6.5.4 Model-independent bounds on the helium fraction from Planck

Figure 38: 
Constraints in the $\omega\_{\mathrm{b}}$–$Y\_{\rm P}^{\mathrm{BBN}}$ plane from Planck and
Planck+BAO, compared to helium abundance measurements. Here 68 % and 95 %
contours are plotted for the CMB(+BAO) data combinations when
$Y\_{\rm P}^{\mathrm{BBN}}$ is allowed to vary as an additional parameter to
base $\rm{\Lambda CDM}$. The horizontal band shows observational bounds on 4He compiled
by [Aver et al. (2013)](#bib.bib27) with 68 % and 95 % errors, while the dashed line at
the top of the figure delineates the conservative 95 % upper bound inferred
from the Solar helium abundance by [Serenelli & Basu (2010)](#bib.bib313). The green stripe shows
the predictions of standard BBN for the
primordial abundance of 4He as a function of the baryon density. Both BBN
predictions and CMB results assume $N\_{\mathrm{eff}}=3.046$ and no
significant lepton asymmetry.

Figure 39: As in Fig. [38](#S6.F38 "Figure 38 ‣ 6.5.4 Model-independent bounds on the helium fraction from Planck ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"), but now allowing
$Y\_{\rm P}^{\mathrm{BBN}}$ and $N\_{\mathrm{eff}}$ to vary as parameter extensions
to base $\rm{\Lambda CDM}$.

Instead of inferring the primordial helium abundance from BBN codes
using $(\omega\_{\mathrm{b}},N\_{\mathrm{eff}})$ constraints from Planck,
we can measure it directly, since variations in $Y\_{\mathrm{P}}^{\mathrm{BBN}}$
modify the density of free electrons between helium and hydrogen recombination
and therefore affect the damping tail of the CMB anisotropies.

If we allow $Y\_{\mathrm{P}}^{\mathrm{CMB}}$ to vary as an additional parameter to
base $\rm{\Lambda CDM}$, we find the following constraints (at 95 % CL):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $Y\_{\mathrm{P}}^{\mathrm{BBN}}=\left\{\mathrm{\begin{tabular}[]{ll}$0.253^{+0.041}\_{-0.042}$&{Planck}\ TT{+}lowP\thinspace;\\ $0.255^{+0.036}\_{-0.038}$&{Planck}\ TT{+}lowP{+}BAO\thinspace;\\ $0.251^{+0.026}\_{-0.027}$&{Planck}\ TT,TE,EE{+}lowP\thinspace;\\ $0.253^{+0.025}\_{-0.026}$&{Planck}\ TT,TE,EE{+}lowP{+}BAO\thinspace.\\ \end{tabular}}\right.$ |  | (67) |

Joint constraints on $Y\_{\mathrm{P}}^{\mathrm{BBN}}$ and $\omega\_{\mathrm{b}}$ are
shown in Fig. [38](#S6.F38 "Figure 38 ‣ 6.5.4 Model-independent bounds on the helium fraction from Planck ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). The addition of Planck polarization
measurements results in a substantial reduction in the uncertainty on the
helium fraction. In fact, the standard deviation on
$Y\_{\mathrm{P}}^{\mathrm{BBN}}$ in the case of Planck TT,TE,EE+lowP is only 30 % larger
than the observational error quoted by [Aver et al. (2013)](#bib.bib27). As emphasized
throughout this paper, the systematic effects in the Planck polarization
spectra, although at low levels, have not been accurately characterized at this
time. Readers should therefore treat the polarization constraints with some
caution. Nevertheless, as shown in Fig. [38](#S6.F38 "Figure 38 ‣ 6.5.4 Model-independent bounds on the helium fraction from Planck ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"), all three data
combinations agree well with the observed helium abundance measurements and
with the predictions of standard BBN.

There is a well-known parameter degeneracy between $Y\_{\mathrm{P}}$ and the
radiation density (see the discussion in [258](#bib.bib258)).
Helium abundance predictions from the CMB are therefore particularly sensitive
to the addition of the parameter $N\_{\mathrm{eff}}$ to base $\rm{\Lambda CDM}$. Allowing
both $Y\_{\mathrm{P}}^{\mathrm{BBN}}$ and $N\_{\mathrm{eff}}$ to vary
we find the following constraints (at 95 % CL):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $Y\_{\mathrm{P}}^{\mathrm{BBN}}=\left\{\mathrm{\begin{tabular}[]{ll}$0.252^{+0.058}\_{-0.065}$&{Planck}\ TT{+}lowP\thinspace;\\ $0.251^{+0.058}\_{-0.064}$&{Planck}\ TT{+}lowP{+}BAO\thinspace;\\ $0.263^{+0.034}\_{-0.037}$&{Planck}\ TT,TE,EE{+}lowP\thinspace;\\ $0.262^{+0.035}\_{-0.037}$&{Planck}\ TT,TE,EE{+}lowP{+}BAO\thinspace.\\ \end{tabular}}\right.$ |  | (68) |

Contours in the $Y\_{\mathrm{P}}^{\mathrm{BBN}}$–$N\_{\mathrm{eff}}$ plane are shown
in Fig. [39](#S6.F39 "Figure 39 ‣ 6.5.4 Model-independent bounds on the helium fraction from Planck ‣ 6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). Here again, the impact of Planck polarization data
is important, and helps to substantially reduce the degeneracy
between these two parameters. The Planck TT,TE,EE+lowP contours are in
very good agreement with standard BBN and $N\_{\mathrm{eff}}=3.046$.
However, even if we relax the assumption of standard BBN, the
CMB does not allow high values of $N\_{\mathrm{eff}}$. It is
therefore difficult to accommodate an extra thermalized relativistic species,
even if the standard BBN prior on the helium fraction is relaxed.

### 6.6 Dark matter annihilation

Energy injection from dark matter (DM) annihilation can alter the
recombination history, leading to changes in the temperature and
polarization power spectra of the CMB
([Chen & Kamionkowski 2004](#bib.bib72); [Padmanabhan & Finkbeiner 2005](#bib.bib244), e.g.,). As demonstrated in
several papers ([Galli et al. 2009](#bib.bib133); [Slatyer et al. 2009](#bib.bib320); [Finkbeiner et al. 2012](#bib.bib121), e.g.,), CMB anisotropies offer an opportunity to
constrain the nature of DM. Furthermore, CMB
experiments such as Planck can achieve limits on the annihilation
cross-section that are relevant for the interpretation of the rise in
the cosmic-ray positron fraction at energies $\ga 10\thinspace{\rm GeV}$
observed by PAMELA, Fermi, and AMS
([Adriani et al. 2009](#bib.bib10); [Ackermann et al. 2012](#bib.bib5); [Aguilar et al. 2014](#bib.bib11)). The CMB constraints
are complementary to those determined from other astrophysical
probes, such as the $\gamma$-ray observations of dwarf galaxies
by the Fermi satellite ([Ackermann et al. 2014](#bib.bib6)).

The way in which DM annihilations heat and ionize the gaseous
background depends on the nature of the cascade of particles produced
following annihilation and, in particular, on the production of
${\rm e}^{\pm}$ pairs and photons that couple to the gas.
The fraction of the rest mass energy that is injected into the gas
can be modelled by an “efficiency factor,” $f(z)$, which
is typically in the range 0.01--1 and depends on
redshift.3333
33
To maintain consistency with other papers on dark
matter annihilation, we retain the notation $f(z)$ for the
efficiency factor in this section; it should not be confused with
the growth rate factor introduced in Eq. ([21](#S5.E21 "In 5.5.1 Redshift space distortions ‣ 5.5 Additional data ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters")).
Computations of $f(z)$ for various annihilation channels can be found
in [Slatyer et al. (2009)](#bib.bib320), [Hütsi et al. (2009)](#bib.bib182), and
[Evoli et al. (2013)](#bib.bib113). The rate of energy release per unit volume by
annihilating DM can therefore be written as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{dE}{dtdV}(z)=2\thinspace g\thinspace\rho^{2}\_{\rm crit}c^{2}\Omega^{2}\_{\rm c}(1+z)^{6}p\_{\rm ann}(z),$ |  | (69) |

where $p\_{\rm ann}$ is defined as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $p\_{\rm ann}(z)\equiv f(z)\frac{\langle\sigma\varv\rangle}{m\_{\chi}}.$ |  | (70) |

Here $\rho\_{\rm crit}$ the critical density of the Universe today, $m\_{\chi}$ is
the mass of the DM particle,
and $\langle\sigma\varv\rangle$ is the thermally-averaged annihilation
cross-section times the velocity (explicitly the so-called
M$\o$ller velocity); we will refer to this quantity
loosely as the “cross-section” hereafter. In Eq. ([69](#S6.E69 "In 6.6 Dark matter annihilation ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")),
$g$ is a degeneracy factor that is equal to $1/2$ for Majorana
particles and $1/4$ for Dirac particles. In this paper, the
constraints will refer to Majorana particles. Note that to produce
the observed dark matter density from thermal DM relics requires an
annihilation cross-section of $\langle\sigma\varv\rangle\approx 3\times 10^{-26}\thinspace{\rm cm}^{3}\thinspace{\rm s}^{-1}$ (assuming s-wave annihilation)
at the time of freeze-out
([Profumo 2013](#bib.bib290), see, e.g., the review by).

Both the amplitude and redshift dependence of the efficiency factor
$f(z)$ depend on the details of the annihilation process
([Slatyer et al. 2009](#bib.bib320), e.g.,). The functional shape of $f(z)$ can
be taken into account using generalized parameterizations or principal
components ([Finkbeiner et al. 2012](#bib.bib121); [Hutsi et al. 2011](#bib.bib181)), similar to the
analysis of the recombination history presented in
Sect. [6.7.4](#S6.SS7.SSS4 "6.7.4 Semi-blind perturbed recombination analysis ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). However, as shown in [Galli et al. (2011)](#bib.bib134),
[Giesen et al. (2012)](#bib.bib142), and [Finkbeiner et al. (2012)](#bib.bib121), to a first
approximation the redshift dependence of $f(z)$ can be ignored, since
current CMB data (including Planck) are sensitive to energy injection over
a relatively narrow range of redshift, typically $z\approx 1000$–600.
The effects of DM annihilation can therefore be reasonably well parameterized
by a single constant parameter, $p\_{\rm ann}$ (with $f(z)$ set to a constant
$f\_{\rm eff}$), which encodes the dependence on the properties of the DM
particles. In the following, we calculate constraints on the $p\_{\rm ann}$
parameter, assuming that it is constant, and then project these constraints
on to a particular dark matter
model assuming $f\_{\rm eff}\equiv f(z=600)$, since the effect of dark matter
annihilation peaks at $z\approx 600$ ([Finkbeiner et al. 2012](#bib.bib121), see). The
$f(z)$ functions used here are those calculated in [Slatyer et al. (2009)](#bib.bib320),
with the updates described in [Galli et al. (2013)](#bib.bib136) and
[Madhavacheril et al. (2014)](#bib.bib221). Finally, we estimate the fractions of injected
energy that affect the gaseous background, from heating,
ionizations, or Ly$\alpha$ excitations, using the updated calculations
described in [Galli et al. (2013)](#bib.bib136) and
[Valdes et al. (2010)](#bib.bib341), following [Shull & van Steenberg (1985)](#bib.bib316).

We compute the theoretical angular power spectrum in the presence of DM
annihilations by modifying the recfast routine ([Seager et al. 1999](#bib.bib310)) in
the camb code as in [Galli et al. (2011)](#bib.bib134).3434
34
We checked that we obtain
similar results using either the HyRec code ([Ali-Haimoud & Hirata 2011](#bib.bib15)), as
detailed in [Giesen et al. (2012)](#bib.bib142), or
CosmoRec ([Chluba & Thomas 2011](#bib.bib80)), instead of recfast.
We then add $p\_{\rm ann}$ as an additional parameter to those of the base $\rm{\Lambda CDM}$ cosmology. Table [6](#S6.T6 "Table 6 ‣ 6.6 Dark matter annihilation ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") shows the constraints for various
data combinations.

Table 6: Constraints on $p\_{\rm ann}$ in units of
${\rm cm}^{3}\thinspace{\rm s}^{-1}\thinspace{\rm GeV}^{-1}$.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  | | --- | --- | | Data combinations | $p\_{\rm ann}$ (95 % upper limits) | | TT+lowP. | $<5.7\times 10^{-27}$ | | EE+lowP. | $<1.4\times 10^{-27}$ | | TE+lowP. | $<5.9\times 10^{-28}$ | | TT+lowP+lensing. | $<4.4\times 10^{-27}$ | | TT,TE,EE+lowP. | $<4.1\times 10^{-28}$ | | TT,TE,EE+lowP+lensing. | $<3.4\times 10^{-28}$ | | TT,TE,EE+lowP+ext. | $<3.5\times 10^{-28}$ | |  |

Figure 40: 2D marginal distributions in the $p\_{\rm ann}$–$n\_{\rm s}$ plane
for Planck TT+lowP (red), Planck EE+lowP (yellow), Planck TE+lowP (green), and Planck TT,TE,EE+lowP (blue) data combinations. We also show the
constraints obtained using WMAP9 data (light blue).

The constraints on $p\_{\rm ann}$ from the Planck TT+lowP spectra are about 3
times weaker than the 95 % limit of $p\_{\rm ann}<2.1\times 10^{-27}\thinspace{\rm cm^{3}}\thinspace{\rm s}^{-1}\thinspace{\rm GeV}^{-1}$ derived from WMAP9, which
includes WMAP polarization data at low multipoles. On the other hand, the
Planck $TE$ or $EE$ spectra improve the constraints on $p\_{\rm ann}$ by about
an order of magnitude compared to those from Planck $TT$ alone. This is
because the main effect of dark matter annihilation is to increase the
width of last scattering, leading to a suppression of the amplitude of
the peaks, both in temperature and polarization. As a result, the
effects of DM annihilation on the power spectra at high multipole are
degenerate with other parameters of base $\rm{\Lambda CDM}$, such as $n\_{\rm s}$ and $A\_{\rm s}$
([Chen & Kamionkowski 2004](#bib.bib72); [Padmanabhan & Finkbeiner 2005](#bib.bib244)). At large angular scales
($\ell\lesssim 200$), however, dark matter annihilation can produce an
enhancement in polarization, caused by the increased ionization
fraction in the freeze-out tail following recombination. As a result,
large-angle polarization information is crucial for breaking the
degeneracies between parameters, as illustrated in
Fig. [40](#S6.F40 "Figure 40 ‣ 6.6 Dark matter annihilation ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). The strongest constraints on $p\_{\rm ann}$ therefore
come from the full Planck temperature and polarization likelihood
and there is little improvement if other astrophysical data, or
Planck lensing, are added.3535
35
It is interesting to note that
the constraint derived from Planck TT,TE,EE+lowP is consistent with the
forecast given in [Galli et al. (2009)](#bib.bib133), $p\_{\rm ann}<3\times 10^{-28}\thinspace{\rm cm^{3}}\thinspace{\rm s}^{-1}\thinspace{\rm GeV}^{-1}$.

We verified the robustness of the Planck TT,TE,EE+lowP constraint by also
allowing other parameter extensions of base $\Lambda$CDM ($N\_{\rm eff}$, $dn\_{\rm s}/d\ln k$,
or $Y\_{\text{P}}$) to vary together with $p\_{\rm ann}$. We found that the constraint
is weakened by up to 20 %. Furthermore, we have verified that we
obtain consistent results
when relaxing the priors on the amplitudes of the Galactic dust templates
or if we use the CamSpec likelihood instead of the baseline Plik likelihood.

Figure 41: Constraints on the self-annihilation cross-section at recombination,
$\langle\sigma\varv\rangle\_{z\_{\ast}}$, times the efficiency parameter, $f\_{\rm eff}$
(Eq. [70](#S6.E70 "In 6.6 Dark matter annihilation ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")). The blue area shows the parameter space excluded by the
Planck TT,TE,EE+lowP data at 95 % CL. The yellow line indicates
the constraint using WMAP9 data. The dashed green line delineates the region
ultimately accessible to a cosmic-variance-limited experiment with angular
resolution comparable to that of Planck. The horizontal red band includes
the values of the
thermal-relic cross-section multiplied by the appropriate $f\_{\rm eff}$ for
different DM annihilation channels. The dark grey circles show the best-fit
DM models for the PAMELA/AMS-02/Fermi cosmic-ray excesses, as
calculated in [Cholis & Hooper (2013)](#bib.bib81) (caption of their figure 6). The light
grey stars show the best-fit DM models for the Fermi Galactic centre
$\gamma$-ray excess, as calculated by [Calore et al. (2015)](#bib.bib70) (their tables I,
II, and III), with the light grey area indicating the astrophysical
uncertainties on the best-fit cross-sections.

Figure [41](#S6.F41 "Figure 41 ‣ 6.6 Dark matter annihilation ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") shows the constraints from WMAP9,
Planck TT,TE,EE+lowP, and a forecast for a cosmic-variance-limited experiment
with similar angular resolution to Planck.3636
36
We assumed here that the
cosmic-variance-limited experiment would measure the angular power spectra
up to a maximum multipole of $\ell\_{\mathrm{max}}=2500$, observing a sky
fraction $f\_{\rm sky}=0.65$.
The horizontal red band includes the values of the thermal-relic cross-section
multiplied by the appropriate $f\_{\rm eff}$ for different DM annihilation
channels. For example, the upper red line corresponds to $f\_{\rm eff}=0.67$,
which is appropriate for a DM particle of mass $m\_{\chi}=10\thinspace{\rm GeV}$
annihilating into ${\rm e}^{+}{\rm e}^{-}$, while the lower red line corresponds to
$f\_{\rm eff}=0.13$,
for a DM particle annihilating into $2\pi^{+}\pi^{-}$ through an intermediate
mediator ([Arkani-Hamed et al. 2009](#bib.bib23), see, e.g.,). The Planck data exclude at
95 % confidence level a thermal relic cross-section for DM particles of mass
$m\_{\chi}\la 44\thinspace{\rm Gev}$ annihilating into ${\rm e}^{+}{\rm e}^{-}$
($f\_{\rm eff}\approx 0.6$), $m\_{\chi}\la 16\thinspace{\rm GeV}$ annihilating into
$\mu^{+}\mu^{-}$ or ${\rm b}\bar{\rm b}$ ($f\_{\rm eff}\approx 0.2$),
and $m\_{\chi}\la 11\thinspace{\rm GeV}$ annihilating into $\tau^{+}\tau^{-}$
($f\_{\rm eff}\approx 0.15$).

The dark grey shaded area in Fig. [41](#S6.F41 "Figure 41 ‣ 6.6 Dark matter annihilation ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") shows the
approximate allowed region of parameter space, as calculated by
[Cholis & Hooper (2013)](#bib.bib81) on the assumption that the PAMELA, AMS, and Fermi
cosmic-ray excesses are caused by DM annihilation; the dark grey dots
indicate the best-fit dark matter models described in that paper
([Boudaud et al. 2015](#bib.bib59), for a recent discussion on best-fitting models, see
also).
The favoured value of the cross-section is about two orders of magnitude
higher than the thermal relic cross-section ($\approx 3\times 10^{-26}\thinspace{\rm cm^{3}}\thinspace{\rm s}^{-1}$). Attempts to reconcile such a high
cross-section with the relic abundance of DM include a Sommerfeld
enhanced cross-section (that may saturate at $\langle\sigma\varv\rangle\approx 10^{-24}\thinspace{\rm cm^{3}}\thinspace{\rm s}^{-1}$) or non-thermal
production of DM ([Madhavacheril et al. 2014](#bib.bib221), see, e.g., the discussion by). Both of these possibilities are strongly
disfavoured by the Planck data. We cannot, however, exclude more
exotic possibilities, such as DM annihilation through a p-wave channel
with a cross-section that scales as $\varv^{2}$
([Diamanti et al. 2014](#bib.bib99)). Since the relative velocity of DM particles
at recombination is many orders of magnitude smaller than in the
Galactic halo, such a model cannot be constrained using CMB data.

Observations from the Fermi Large Area Telescope of extended
$\gamma$-ray emission towards the centre of the Milky Way, peaking at energies
of around 1–3 GeV, have been interpreted as evidence for annihilating DM
([Goodenough & Hooper 2009](#bib.bib146); [Gordon & Macías 2013](#bib.bib148); [Daylan et al. 2016](#bib.bib95); [Abazajian et al. 2014](#bib.bib4); [Lacroix et al. 2014](#bib.bib202), e.g.,). The light grey
stars in Fig. [41](#S6.F41 "Figure 41 ‣ 6.6 Dark matter annihilation ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") show specific models of DM
annihilation designed to fit the Fermi $\gamma$-ray excess
([Calore et al. 2015](#bib.bib70)), while the light grey box shows the uncertainties of
the best-fit cross-sections due to imprecise knowledge of the Galactic DM
halo profile. Although the interpretation of the Fermi
excess remains controversial (because of uncertainties in the
astrophysical backgrounds), DM annihilation remains a possible
explanation. The best-fit models of [Calore et al. (2015)](#bib.bib70) are
consistent with the Planck constraints on DM annihilation.

### 6.7 Testing recombination physics with Planck

The cosmological recombination process determines how CMB photons
decoupled from baryons around redshift $z\approx 10^{3}$, when the Universe
was about 400 000 years old. The importance of this transition on
the CMB anisotropies has long been recognized
([Sunyaev & Zeldovich 1970](#bib.bib331); [Peebles & Yu 1970](#bib.bib249)). The most advanced
computations of the ionization history ([Ali-Haïmoud & Hirata 2010](#bib.bib14); [Chluba & Thomas 2011](#bib.bib80); [Ali-Haimoud & Hirata 2011](#bib.bib15); [Chluba et al. 2012](#bib.bib74), e.g.,) account for many subtle atomic
physics and radiative transfer effects that were not included in the
earliest calculations ([Zeldovich et al. 1968](#bib.bib355); [Peebles 1968](#bib.bib247)).

With precision data from Planck, we are sensitive to sub-percent
variations of the free electron fraction around last-scattering
([Hu et al. 1995](#bib.bib177); [Seager et al. 2000](#bib.bib311); [Seljak et al. 2003](#bib.bib312), e.g.,). Quantifying the impact of
uncertainties in
the ionization history around the maximum of the Thomson visibility
function on predictions of the CMB power spectra is thus crucial
for the scientific interpretation of data from Planck. In particular, for tests
of models of inflation and extensions to $\rm{\Lambda CDM}$, the interpretation of the
CMB data can be significantly compromised by inaccuracies in the recombination
calculation ([Wong et al. 2008](#bib.bib349); [Rubiño-Martín et al. 2010](#bib.bib301); [Shaw & Chluba 2011](#bib.bib315), e.g.,). This problem can be
approached in two ways, either by using modified recombination models with a
specific physical process (or parameter) in mind, or in a semi-blind,
model-independent way. Both approaches provide useful insights in
assessing the robustness of the results from Planck.

Model-dependent limits on varying fundamental constants
([Kaplinghat et al. 1999](#bib.bib188); [Scóccola et al. 2009](#bib.bib308); [Galli et al. 2009](#bib.bib135)), annihilating or
decaying particles
(e.g., [Chen & Kamionkowski 2004](#bib.bib72); [Padmanabhan & Finkbeiner 2005](#bib.bib244); [Zhang et al. 2006](#bib.bib357), and Sect. [6.6](#S6.SS6 "6.6 Dark matter annihilation ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")),
or more general sources of extra ionization and excitation photons
([Peebles et al. 2000](#bib.bib248); [Doroshkevich et al. 2003](#bib.bib102); [Galli et al. 2008](#bib.bib131)), have been discussed
extensively in the literature.

As already discussed in [258](#bib.bib258), the choice for Planck has been to use the
rapid calculations of the recfast code, modified using corrections calculated
with the more precise codes. To start this sub-section we
quantify the effect on the analysis of Planck data of the remaining
uncertainties in the standard recombination history obtained with different
recombination codes
(Sect. [6.7.1](#S6.SS7.SSS1 "6.7.1 Comparison of different recombination codes ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")). We also derive CMB anisotropy-based
measurements of the hydrogen $2s$–$1s$ two-photon decay rate,
$A\_{2s\rightarrow 1s}$ (Sect. [6.7.2](#S6.SS7.SSS2 "6.7.2 Measuring 𝐴_{2⁢𝑠→1⁢𝑠} with Planck ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")), and the average CMB
temperature, $T\_{0}$ derived at the last-scattering epoch
(Sect. [6.7.3](#S6.SS7.SSS3 "6.7.3 Measuring 𝑇_0 at last-scattering with Planck ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")). These two parameters strongly
affect the recombination history but are usually kept fixed when
fitting models to CMB data
(as in the analyses described in previous sections).
Section [6.7.4](#S6.SS7.SSS4 "6.7.4 Semi-blind perturbed recombination analysis ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") describes model-independent constraints on perturbed
recombination scenarios. A discussion of these
cases provides both a test of the consistency of the CMB data with the
standard recombination scenario and also a demonstration of the
impressive sensitivity of Planck to small variations in the
ionization history at $z\approx 1100$.

#### 6.7.1 Comparison of different recombination codes

Even for pre-Planck data, it was realized that the early recombination
calculations of [Zeldovich et al. (1968)](#bib.bib355) and [Peebles (1968)](#bib.bib247) had to be improved.
This led to the development of the widely-used and computationally quick
recfast code
([Seager et al. 1999](#bib.bib310); [Seager et al. 2000](#bib.bib311)). However, for Planck, the recombination
model of recfast in its original form is not accurate enough.
Percent-level corrections, due to detailed radiative transfer and atomic
physics effects have to be taken into account. Ignoring these effects can bias
the inferred cosmological parameters, some by as much as a few
standard deviations.

The recombination problem was solved as a common effort of several
groups ([Dubrovich & Grachev 2005](#bib.bib104); [Kholupenko et al. 2007](#bib.bib193); [Chluba & Sunyaev 2006b](#bib.bib76); [Rubiño-Martín et al. 2006](#bib.bib302); [Karshenboim & Ivanov 2008](#bib.bib189); [Wong & Scott 2007](#bib.bib350); [Switzer & Hirata 2008](#bib.bib333); [Grin & Hirata 2010](#bib.bib153); [Ali-Haïmoud & Hirata 2010](#bib.bib14)). This work
was undertaken, to a large extent, in preparation for the precision data from
Planck. Both CosmoRec ([Chluba & Thomas 2011](#bib.bib80)) and
HyRec ([Ali-Haimoud & Hirata 2011](#bib.bib15))
allow fast and precise computations of the ionization history,
explicitly capturing the physics of the recombination problem. For the
standard cosmology, the ionization histories obtained from these two
codes in their default settings agree to within 0.05 % for hydrogen
recombination ($600\la z\la 1600$) and 0.35 %
during helium recombination3737
37
Helium recombination is treated
in more detail by CosmoRec ([Rubiño-Martín et al. 2008](#bib.bib303); [Chluba et al. 2012](#bib.bib74), e.g.,), which explains most of the difference.
($1600\la z\la 3000$). The effect of these
small differences on the CMB power spectra is $\la 0.1\thinspace\%$ at
$\ell<4000$ and so has a negligible impact on the interpretation
of precision CMB data; for the standard six parameters of base $\rm{\Lambda CDM}$, we find
that the largest effect is a bias in $\ln(10^{10}A\_{\rm s})$ at the level of
$0.04\thinspace\sigma\approx 0.0012$ for Planck TT,TE,EE+lowP+BAO.

For Planck analyses, the recombination model of recfast is used by
default. In recfast, the precise dynamics of recombination is not
modelled physically, but approximated with fitting-functions
calibrated against the full
recombination calculations assuming
a reference cosmology ([Seager et al. 1999](#bib.bib310); [Seager et al. 2000](#bib.bib311); [Wong et al. 2008](#bib.bib349)).
At the level of precision required for
Planck, the recfast approach is sufficiently accurate,
provided that the cosmologies are close to base $\rm{\Lambda CDM}$ ([Rubiño-Martín et al. 2010](#bib.bib301); [Shaw & Chluba 2011](#bib.bib315)). Comparing the latest version of
recfast (camb version) with CosmoRec, we find agreement to within
0.2 % for hydrogen recombination ($600\la z\la 1600$)
and 0.2 % during helium recombination for the
standard ionization history. The effect on the CMB power spectra
is $\la 0.15\thinspace\%$ at $\ell<4000$, although with
slightly more pronounced shifts in the peak positions than when
comparing CosmoRec and HyRec. For the base $\rm{\Lambda CDM}$ model, we
find that the largest bias is on $n\_{\rm s}$, at the level of $0.15\thinspace\sigma$
($\approx 0.0006$) for Planck TT,TE,EE+lowP+BAO. Although this is about 5 times larger
than the difference in $n\_{\rm s}$ between CosmoRec and HyRec, this bias is
nevertheless
unimportant at the current level of precision (and smaller than the differences
seen from different likelihoods, see Sect. [3.1](#S3.SS1 "3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters")).

Finally we compare CosmoRec with recfast in its original form
(i.e., before recalibrating the fitting-functions on refined recombination
calculations). For base $\rm{\Lambda CDM}$, we expect to see biases of
$\Delta\Omega\_{\mathrm{b}}h^{2}\approx-2.1\thinspace\sigma\approx-0.00028$ and
$\Delta n\_{\rm s}\approx-3.3\thinspace\sigma\approx-0.012$ ([Shaw & Chluba 2011](#bib.bib315)).
Using the actual data (Planck TT,TE,EE+lowP+BAO) we find biases of
$\Delta\Omega\_{\mathrm{b}}h^{2}\approx-1.8\thinspace\sigma\approx-0.00024$ and
$\Delta n\_{\rm s}\approx-2.6\thinspace\sigma\approx-0.010$, very close
to the expected values.
This illustrates explicitly the importance of the improvements of
CosmoRec and HyRec over the original version of recfast for the interpretation of Planck data. However, CosmoRec and
HyRec themselves are much more computationally intensive than the
modified recfast, which is why we use recfast in most Planck cosmological
analyses.

#### 6.7.2 Measuring $A\_{2s\rightarrow 1s}$ with Planck

The crucial role of the $2s$–$1s$ two-photon decay channel for the
dynamics of hydrogen recombination has been appreciated since the early days of
CMB research ([Zeldovich et al. 1968](#bib.bib355); [Peebles 1968](#bib.bib247)). Recombination is an
out-of-equilibrium process and energetic photons emitted in the far
Wien tail of the CMB by Lyman continuum and series transitions keep
the primordial plasma ionized for a much longer period than expected from
simple equilibrium recombination physics. Direct recombinations to the ground
state of hydrogen are prohibited,
causing a modification of the free electron number density, $N\_{\rm e}$,
by only $\Delta N\_{\rm e}/N\_{\rm e}\approx 10^{-6}$ around
$z\approx 10^{3}$ ([Chluba & Sunyaev 2007](#bib.bib77)). Similarly, the slow escape of
photons from the Ly$\alpha$ resonance reduces the effective
Ly-$\alpha$ transition rate to $A^{\ast}\_{2p\rightarrow 1s}\approx 1$–10 s-1 (by more than seven orders of
magnitude), making it comparable to the vacuum $2s$–$1s$ two-photon
decay rate of $A\_{2s\rightarrow 1s}\approx 8.22\thinspace{\rm s^{-1}}$. About
$57\thinspace\%$ of all hydrogen atoms in the Universe became neutral through
the $2s$–$1s$ channel ([Wong et al. 2006](#bib.bib351); [Chluba & Sunyaev 2006a](#bib.bib75), e.g.,),
and subtle effects, such as
the induced $2s$–$1s$ two-photon decay and Ly$\alpha$
re-absorption, need to be considered in precision recombination calculations
([Chluba & Sunyaev 2006b](#bib.bib76); [Kholupenko & Ivanchik 2006](#bib.bib192); [Hirata 2008](#bib.bib170)).

The high sensitivity of the recombination process to the $2s$–$1s$
two-photon transition rate also implies that instead of simply
adopting a value for $A\_{2s\rightarrow 1s}$ from theoretical
computations ([Breit & Teller 1940](#bib.bib61); [Spitzer & Greenstein 1951](#bib.bib327); [Goldman 1989](#bib.bib145))
one can directly determine it
with CMB data. From the theoretical point of view it would be
surprising to find a value that deviates significantly from
$A\_{2s\rightarrow 1s}=8.2206\thinspace{\rm s^{-1}}$, derived from the most detailed
computation ([Labzowsky et al. 2005](#bib.bib201)). However, laboratory
measurements of this transition rate are extremely challenging
([O’Connell et al. 1975](#bib.bib238); [Krüger & Oed 1975](#bib.bib200); [Cesar et al. 1996](#bib.bib71)).
The most stringent limit is for the differential decay
rate, $A\_{2s\rightarrow 1s}(\lambda)\thinspace{\rm d}\lambda=(1.5\pm 0.65)\thinspace{\rm s}^{-1}$ (a $43\thinspace\%$ error) at wavelengths
$\lambda=255.4$–$232.0\thinspace{\rm nm}$, consistent with the
theoretical value of $A\_{2s\rightarrow 1s}(\lambda)\thinspace{\rm d}\lambda=1.02\thinspace{\rm s}^{-1}$ in the same wavelength range
([Krüger & Oed 1975](#bib.bib200)). With precision data from Planck we are in a
position to perform the best measurement to date, using cosmological
data to inform us about atomic transition rates at last scattering ([Mukhanov et al. 2012](#bib.bib235), as
also emphasized by).

The $2s$–$1s$ two-photon rate affects the CMB anisotropies only
through its effect on the recombination history. A larger value of
$A\_{2s\rightarrow 1s}$, accelerates recombination, allowing photons and
baryons to decouple earlier, an effect that shifts the acoustic peaks
towards smaller scales. In addition, slightly less damping occurs, as
in the case of the stimulated $2s$–$1s$ two-photon decays
([Chluba & Sunyaev 2006b](#bib.bib76)). This implies that for flat cosmologies, variations
of $A\_{2s\rightarrow 1s}$ correlate with $\Omega\_{\mathrm{c}}h^{2}$ and $H\_{0}$ (which
affect the distance to the last scattering surface), while
$A\_{2s\rightarrow 1s}$ anti-correlates with $\Omega\_{\mathrm{b}}h^{2}$ and $n\_{\rm s}$
(which modify the slope of the damping tail). Despite these degeneracies,
one expects that Planck will provide a measurement of $A\_{2s\rightarrow 1s}$
to within $\pm 0.5\thinspace{\rm s}^{-1}$, corresponding to an approximately 6 %
uncertainty ([Mukhanov et al. 2012](#bib.bib235)).

Figure 42: Marginalized posterior for $A\_{2s\rightarrow 1s}$, obtained using
CosmoRec, with and without small-scale polarization data.
We find good agreement with the theoretical value of
$A\_{2s\rightarrow 1s}=8.2206\thinspace{\rm s^{-1}}$. For comparison, we also
show the result for Planck TT,TE,EE+lowP+BAO obtained with recfast, emphasizing the
consistency of different treatments.

In Fig. [42](#S6.F42 "Figure 42 ‣ 6.7.2 Measuring 𝐴_{2⁢𝑠→1⁢𝑠} with Planck ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"), we show the marginalized posterior for
$A\_{2s\rightarrow 1s}$ from Planck and for Planck combined with BAO.
Using CosmoRec to compute the recombination history, we find

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle A\_{2s\rightarrow 1s}$ | $\displaystyle\!=$ | $\displaystyle\!7.70\pm 1.01\thinspace{\rm s}^{-1}\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP},$ |  | (71a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle A\_{2s\rightarrow 1s}$ | $\displaystyle\!=$ | $\displaystyle\!7.72\pm 0.60\thinspace{\rm s}^{-1}\quad\textit{Planck}\ {\rm TT,TE,EE}{+}{\rm lowP},$ |  | (71b) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle A\_{2s\rightarrow 1s}$ | $\displaystyle\!=$ | $\displaystyle\!7.71\pm 0.99\thinspace{\rm s}^{-1}\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP}{+}{\rm BAO},$ |  | (71c) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle A\_{2s\rightarrow 1s}$ | $\displaystyle\!=$ | $\displaystyle\!7.75\pm 0.61\thinspace{\rm s}^{-1}\quad\textit{Planck}\ {\rm TT,TE,EE}{+}{\rm lowP}$ |  | (71d) |
|  |  |  | $\displaystyle\qquad\qquad\qquad\qquad\qquad\qquad\qquad\qquad{{+}{\rm BAO}}.$ |  |

These results are in very good agreement with the theoretical value,
$A\_{2s\rightarrow 1s}=8.2206\thinspace{\rm s^{-1}}$. For Planck TT,TE,EE+lowP+BAO, approximately
8 % precision is reached using cosmological data. These constraints
are not sensitive to the addition of BAO, or other external data (JLA+$H\_{0}$).
The slight shift away from the theoretical value is accompanied by
small (fractions of a $\sigma$) shifts in $n\_{\rm s}$, $\Omega\_{\mathrm{c}}h^{2}$, and
$H\_{0}$, to compensate for the effects of $A\_{2s\rightarrow 1s}$
on the distance to the last scattering surface and damping tail.
This indicates that
additional constraints on the acoustic scale are required to fully
break degeneracies between these parameters and their effects on the
CMB power spectrum, a task that could be achieved in the future using
large-scale structure surveys and next generation CMB experiments.

The values for $A\_{2s\rightarrow 1s}$ quoted above were obtained using
CosmoRec. When varying $A\_{2s\rightarrow 1s}$, the range of
cosmologies becomes large enough to potentially introduce a mismatch of the
recfast fitting-functions that could affect the posterior. In
particular, with recfast the $2s$–$1s$ two-photon and
Ly$\alpha$ channels are not treated separately, so that changes
specific to the $2s$–$1s$ decay channel propagate
inconsistently.3838
38
One effect is that by increasing
$A\_{2s\rightarrow 1s}$ fewer Ly$\alpha$ photons are
produced. This reduces the Ly$\alpha$ feedback correction to the
$2s$–$1s$ channel, which further accelerates recombination, an
effect that is not captured with recfast in the current
implementation. However, repeating the analysis with recfast, we find
$A\_{2s\rightarrow 1s}=7.78\pm 0.58\thinspace{\rm s}^{-1}$ (see
Fig. [42](#S6.F42 "Figure 42 ‣ 6.7.2 Measuring 𝐴_{2⁢𝑠→1⁢𝑠} with Planck ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")), for Planck TT,TE,EE+lowP+BAO, which is in excellent agreement
with CosmoRec, showing that these effects can be neglected.

#### 6.7.3 Measuring $T\_{0}$ at last-scattering with Planck

Our best constraint on the CMB monopole temperature comes from the
measurements of the CMB spectrum with COBE/FIRAS, giving a $0.02\thinspace\%$
determination of $T\_{0}$ ([Fixsen et al. 1996](#bib.bib124); [Fixsen 2009](#bib.bib123)). Other
constraints from molecular lines typically reach $1\thinspace\%$ precision
(see table 2 in [Fixsen 2009](#bib.bib123), for an overview), while independent
BBN constraints provide 5–10 % limits ([Simha & Steigman 2008](#bib.bib319); [Jeong et al. 2014](#bib.bib186)).

The CMB anisotropies provide additional ways of determining
the value of $T\_{0}$ (for fixed values of $N\_{\rm eff}$ and $Y\_{\text{P}}$).
One is through the energy distribution of the CMB anisotropies
([Fixsen et al. 1996](#bib.bib124); [Fixsen 2003](#bib.bib122); [Chluba 2014](#bib.bib73)) and another through their
power spectra ([Opher & Pelinson 2004](#bib.bib242); [Opher & Pelinson 2005](#bib.bib243); [Chluba 2014](#bib.bib73)). Even small changes
in $T\_{0}$, compatible with the COBE/FIRAS error, affect the ionization history
at the 0.5 % level around last-scattering, propagating to a roughly 0.1 %
uncertainty in the CMB power spectrum ([Chluba & Sunyaev 2008](#bib.bib78)). Overall, the
effect of this uncertainty on the parameters of $\rm{\Lambda CDM}$ models is small
([Hamann & Wong 2008](#bib.bib156)); however, without prior knowledge of $T\_{0}$ from the
COBE/FIRAS measurement, the situation would change significantly.

The CMB monopole affects the CMB anisotropies in several ways. Most
importantly, for larger $T\_{0}$, photons decouple from baryons at lower
redshift, since more ionizing photons are present in the Wien-tail of
the CMB. This effect is amplified because of the exponential dependence
of the atomic level populations on the ratio of the ionization
potentials and CMB temperature. In addition, increasing $T\_{0}$ lowers
the expansion timescale of the Universe and the redshift of matter-radiation
equality, while increasing the photon sound speed. Some of
these effects are also produced by varying $N\_{\rm eff}$; however, the
effects of $T\_{0}$ on the ionization history and photon sound speed are
distinct.

Figure 43: Marginalized posterior for $T\_{0}$. We find excellent agreement with
the COBE/FIRAS measurement. For comparison, we show the result for
Planck TT,TE,EE+lowP+BAO obtained using both CosmoRec and recfast, emphasizing the
consistency of different treatments.

With CMB data alone, the determination of $T\_{0}$ is degenerate with other
parameters, but the addition of other
data sets breaks this degeneracy.
Marginalized posterior distributions for $T\_{0}$ are shown in Fig. [43](#S6.F43 "Figure 43 ‣ 6.7.3 Measuring 𝑇_0 at last-scattering with Planck ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters").
Using CosmoRec, we find

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle T\_{0}$ | $\displaystyle=$ | $\displaystyle 2.722\pm 0.027\thinspace{\rm K}\quad\textit{Planck}\ {\rm TT}{+}{\rm lowP}{+}{\rm BAO},$ |  | (72a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle T\_{0}$ | $\displaystyle=$ | $\displaystyle 2.718\pm 0.021\thinspace{\rm K}\quad\textit{Planck}\ {\rm TT,TE,EE}{+}{\rm lowP}{+}{\rm BAO},$ |  | (72b) |

and similar results are obtained with recfast.
This is in excellent agreement with the COBE/FIRAS measurement,
$T\_{0}=2.7255\pm 0.0006\thinspace{\rm K}$ ([Fixsen et al. 1996](#bib.bib124); [Fixsen 2009](#bib.bib123)).
These measurements of $T\_{0}$
reach a precision that is comparable to the accuracy obtained with
interstellar molecules. Since the systematics of these independent
methods are very different, this result demonstrates the consistency of
all these data. Allowing $T\_{0}$ to vary causes the errors of the
other cosmological parameters to increase. The strongest effect is
on $\theta\_{\rm MC}$, which is highly degenerate with $T\_{0}$. The error on
$\theta\_{\rm MC}$ increases by a factor of roughly $25$ if $T\_{0}$ is allowed
to vary. The error
on $\Omega\_{\mathrm{b}}h^{2}$ increases by a factor of about 4, while the errors on $n\_{\rm s}$
and $\Omega\_{\mathrm{c}}h^{2}$ increase by factors of 1.5–2, and the other cosmological
parameters are largely unaffected by variations in $T\_{0}$. Because of the
strong degeneracy with $\theta\_{\rm MC}$, no constraint on $T\_{0}$ can be
obtained using Planck data alone. External data, such as BAO, are
therefore required to break this geometric degeneracy.

It is important to emphasize that the CMB measures the temperature at a
redshift of $z\approx 1100$, so the comparison with measurements of $T\_{0}$
at the present day is effectively a test of the constancy of $aT\_{\rm CMB}$,
where $a\approx 1/1100$ is the scale-factor at the time
of last-scattering. It is remarkable that we are able to test
the constancy of $aT\_{\rm CMB}\equiv T\_{0}$ over such a large dynamic range in
redshift. Of course, if we did find that $aT\_{\rm CMB}$ around recombination
were discrepant with $T\_{0}$ now, then we would need to invent a finely-tuned
late-time photon injection mechanism3939
39
Pure energy release in the form
of heating of ordinary matter would leave a Compton $y$-distortion
([Zeldovich & Sunyaev 1969](#bib.bib356)) at these late times
([Burigana et al. 1991](#bib.bib66); [Hu & Silk 1993](#bib.bib178); [Chluba & Sunyaev 2012](#bib.bib79)). to explain the anomaly.
Fortunately, the data are consistent with the standard
$T\_{\rm CMB}\propto(1+z)$ scaling of the CMB temperature.

Another approach to measuring $aT\_{\rm CMB}$ is through the thermal
Sunyaev-Zeldovich effect in rich clusters of galaxies at various redshifts
([Fabbri et al. 1978](#bib.bib114); [Rephaeli 1980](#bib.bib293)), although it is unclear how one would
interpret a failure of this test without an explicit model.
In practice this approach
is consistent with a scaling $aT\_{\rm CMB}={\rm constant}$, but with lower
precision than obtained here from Planck ([Battistelli et al. 2002](#bib.bib30); [Luzzi et al. 2009](#bib.bib216); [Saro et al. 2014](#bib.bib305); [Hurier et al. 2014](#bib.bib180), e.g.,).
A simple $T\_{\rm CMB}=T\_{0}(1+z)^{1-\beta}$ modification to the standard
temperature redshift relation is frequently discussed in the literature
([Chluba 2014](#bib.bib73), though this case is not justified by any physical model and is
difficult to realize without creating a CMB spectral distortion,
see). For this parameterization we find

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\beta$ | $\displaystyle=$ | $\displaystyle(0.2\pm 1.4)\times 10^{-3}\thinspace\ \ \textit{Planck}\ {\rm TT}{+}{\rm lowP}{+}{\rm BAO},$ |  | (73a) |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\beta$ | $\displaystyle=$ | $\displaystyle(0.4\pm 1.1)\times 10^{-3}\thinspace\ \ \textit{Planck}\ {\rm TT,TE,EE}{+}{\rm lowP}{+}{\rm BAO},$ |  | (73b) |

where we have adopted a recombination redshift of
$z\_{\ast}=1100$.4040
40
The test depends on the logarithm of the
redshift and so is insensitive to the precise value adopted for
$z\_{\ast}$. Because of the long lever-arm in redshift afforded by the CMB,
this is an improvement over earlier constraints by more than an order of
magnitude ([Hurier et al. 2014](#bib.bib180), e.g.,).

In a self-consistent picture, changes of $T\_{0}$ would also affect the
BBN era. We might therefore consider a simultaneous variation of
$N\_{\rm eff}$ and $Y\_{\text{P}}$ to reflect the variation of the neutrino energy
density accompanying a putative variation in the photon energy
density. Since we find $aT\_{\rm CMB}$ at recombination to be highly consistent
with the observed CMB temperature from COBE/FIRAS, considering this
extra variation seems unnecessary. Instead, we may view the $aT\_{\rm CMB}$
variation investigated here as further support for the limits
discussed in Sects. [6.4](#S6.SS4 "6.4 Neutrino physics and constraints on relativistic components ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") and [6.5](#S6.SS5 "6.5 Primordial nucleosynthesis ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters").

#### 6.7.4 Semi-blind perturbed recombination analysis

The high sensitivity of small-scale CMB anisotropies to the ionization
history of the Universe around the epoch of recombination allows us to
constrain possible deviations from the standard recombination scenario
in a model-independent way ([Farhang et al. 2012](#bib.bib117); [Farhang et al. 2013](#bib.bib118)). The
method relies on an eigen-analysis (often referred to as a principle
component analysis) of perturbations in the free electron fraction,
$X\_{\rm e}(z)=N\_{\rm e}/N\_{\rm H}$, where $N\_{\rm H}$ denotes the
number density of hydrogen nuclei. The eigenmodes selected are specific to the
data used in the analysis. Similar approaches
have been used to constrain deviations of the reionization
history from the simplest models ([Mortonson & Hu 2008](#bib.bib232)) and
annihilating dark matter scenarios ([Finkbeiner et al. 2012](#bib.bib121)), both
with the prior assumption that the standard recombination physics is
fully understood, as well as for constraining
trajectories in inflation [Planck Collaboration
XX (2016)](#bib.bib279) and
dark energy [Planck Collaboration
XIV (2016)](#bib.bib275) parameterizations.

Here, we use Planck data to find preferred ionization fraction
trajectories $X\_{\rm e}(z)$ composed of low-order perturbation
eigenmodes to the standard history ($X\_{\rm e}$-modes). The $X\_{\rm e}$-modes
are constructed through the eigen-decomposition of the
inverse of the Fisher information matrix for base $\rm{\Lambda CDM}$ (the six
cosmological parameters and the nuisance parameters) and
recombination perturbation parameters (see [Farhang et al. 2012](#bib.bib117), for
details). This procedure allows us to estimate the
errors on the eigenmode amplitudes, $\mu\_{i}$, providing a rank
ordering of the $X\_{\rm e}$-modes and their information content.

The first three $X\_{\rm e}$-modes for Planck TT,TE,EE+lowP are illustrated in
Fig. [44](#S6.F44 "Figure 44 ‣ 6.7.4 Semi-blind perturbed recombination analysis ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"), together with their impact on
the differential visibility function. Figure [45](#S6.F45 "Figure 45 ‣ 6.7.4 Semi-blind perturbed recombination analysis ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters") shows
the response of the CMB temperature and polarization power spectra to these
eigenmodes. The first mode mainly leads to a
change in the width and height of the Thomson visibility function
(bottom panel of Fig. [44](#S6.F44 "Figure 44 ‣ 6.7.4 Semi-blind perturbed recombination analysis ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")). This implies less diffusion
damping, which is also reflected in the modifications to the CMB power
spectra (as shown in Fig. [45](#S6.F45 "Figure 45 ‣ 6.7.4 Semi-blind perturbed recombination analysis ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")). The second mode causes the
visibility maximum to shift towards higher redshifts for $\mu\_{2}>0$,
which leads to a shift of the
CMB extrema to smaller scales; however, for roughly constant width of
the visibility function it also introduces less damping at small
scales. The third mode causes a combination
of changes in both the position and width of the visibility function,
with a pronounced effect on the location of the acoustic peaks.
For the analysis of Planck data
combinations, we only use $X\_{\rm e}$-modes that are optimized for Planck TT,TE,EE+lowP.

Figure 44: Eigen-modes of the recombination history, marginalized over the
standard six cosmological and Planck nuisance parameters.
The upper panel shows the first three $X\_{\rm e}$-modes constructed for
Planck TT,TE,EE+lowP data. The lower panel show changes in the differential visibility
corresponding to $1\thinspace\sigma$ deviations from the standard recombination
scenario for the first three $X\_{\rm e}$-modes. The maximum of the Thomson
visibility function and width are indicated in both figures.

Figure 45: Changes in the $TT$ (upper panel) and $EE$ (lower panel) power
spectra caused by a $1\thinspace\sigma$ deviation from the standard recombination
scenario for the first three $X\_{\rm e}$-modes (see Fig. [44](#S6.F44 "Figure 44 ‣ 6.7.4 Semi-blind perturbed recombination analysis ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")).

We modified CosmoMC to estimate the mode amplitudes. The results for
Planck TT,TE,EE+lowP+BAO are presented in Table [7](#S6.T7 "Table 7 ‣ 6.7.4 Semi-blind perturbed recombination analysis ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). Although all
mode amplitudes are consistent with standard recombination, adding the
second $X\_{\rm e}$-mode causes mild shifts in $H\_{0}$ and $\tau$. For
Planck TT+lowP, we find $\mu\_{1}=-0.11\pm 0.51$ and $\mu\_{2}=-0.23\pm 0.50$,
using the Planck TT,TE,EE+lowP eigenmodes, again consistent with the standard
recombination scenario. Adding the
polarization data improves the errors by more than a factor of 2.
However, the mode amplitudes are insensitive to the addition of
external data.

Table 7: Standard parameters and the first three $X\_{\rm e}$-modes, as determined for
Planck TT,TE,EE+lowP+BAO.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  |  | | --- | --- | --- | --- | | Parameter | + 1 mode | + 2 modes | + 3 modes | | $\Omega\_{\mathrm{b}}h^{2}$. | $\kern 7.1944pt\kern 4.62497pt0.02229\pm 0.00017$ | $\kern 7.1944pt\kern 4.62497pt0.02237\pm 0.00018$ | $\kern 7.1944pt0.02237\pm 0.00019$ | | $\Omega\_{\mathrm{c}}h^{2}$. | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt0.1190\pm 0.0010\kern 4.62497pt$ | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt0.1186\pm 0.0011\kern 4.62497pt$ | $\kern 7.1944pt\kern 4.62497pt0.1187\pm 0.0012\kern 4.62497pt$ | | $H\_{0}$. | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt67.64\pm 0.48\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt$ | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt67.80\pm 0.51\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt$ | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt67.80\pm 0.56\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt$ | | $\tau$. | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt0.065\pm 0.012\kern 4.62497pt\kern 4.62497pt$ | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt0.068\pm 0.013\kern 4.62497pt\kern 4.62497pt$ | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt0.068\pm 0.013\kern 4.62497pt\kern 4.62497pt$ | | $n\_{\rm s}$. | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt0.9667\pm 0.0053\kern 4.62497pt$ | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt0.9677\pm 0.0055\kern 4.62497pt$ | $\kern 7.1944pt\kern 4.62497pt0.9678\pm 0.0067\kern 4.62497pt$ | | $\ln(10^{10}A\_{\rm s})$. | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt3.062\pm 0.023\kern 4.62497pt\kern 4.62497pt$ | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt3.066\pm 0.024\kern 4.62497pt\kern 4.62497pt$ | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt3.066\pm 0.024\kern 4.62497pt\kern 4.62497pt$ | | $\mu\_{1}$. | $\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt-0.03\pm 0.12\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt$ | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt0.03\pm 0.14\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt$ | $\kern 7.1944pt\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt0.02\pm 0.15\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt$ | | $\mu\_{2}$. | $\ldots$ | $\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt-0.17\pm 0.18\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt$ | $\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt-0.18\pm 0.19\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt$ | | $\mu\_{3}$. | $\ldots$ | $\ldots$ | $\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt-0.02\pm 0.88\kern 4.62497pt\kern 4.62497pt\kern 4.62497pt$ | |  |

With pre-Planck data, only the amplitude, $\mu\_{1}$, of the first
eigenmode could be constrained. The corresponding change in the
ionization history translates mainly into a change in the slope of the
CMB damping tail, with this mode resembling the first mode determined using
Planck data
(Fig. [44](#S6.F44 "Figure 44 ‣ 6.7.4 Semi-blind perturbed recombination analysis ‣ 6.7 Testing recombination physics with Planck ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters")). The WMAP9+SPT data gave a non-zero value
for the first eigenmode at about $2\thinspace\sigma$, $\mu^{\rm SPT}\_{1}=-0.80\pm 0.37$.
However, the WMAP9+ACT data gave $\mu^{\rm ACT}\_{1}=0.14\pm 0.45$
and the combined pre-Planck data
(WMAP+ACT+SPT) gave $\mu^{\rm pre}\_{1}=-0.44\pm 0.33$, both consistent
with the standard recombination scenario ([Calabrese et al. 2013](#bib.bib68)).
The variation among these results is another manifestation of the
tensions between different pre-Planck CMB data, as discussed in [258](#bib.bib258).

Although not optimal for Planck data, we also compute the
amplitudes of the first three $X\_{\rm e}$-modes constructed for the
WMAP9+SPT data set. This provides a more direct comparison with the
pre-Planck constraints. For Planck TT,TE,EE+lowP+BAO we obtain
$\mu^{\rm SPT}\_{1}=-0.10\pm 0.13$ and $\mu^{\rm SPT}\_{2}=-0.13\pm 0.18$.
The mild tension of the pre-Planck data with
the standard recombination scenario disappears when using Planck data. This
is especially impressive, since the errors have improved by more than a factor
of 2.
By projecting onto the Planck modes, we find that the first two SPT
modes can be expressed as $\mu^{\rm SPT}\_{1}\approx 0.69\mu\_{1}+0.66\mu\_{2}\approx-0.09$ and $\mu^{\rm SPT}\_{2}\approx-0.70\mu\_{1}+0.64\mu\_{2}\approx-0.13$, which emphasizes the consistency of the
results. Adding the first three SPT modes, we obtain $\mu^{\rm SPT}\_{1}=-0.09\pm 0.13$, $\mu^{\rm SPT}\_{2}=-0.14\pm 0.21$, and
$\mu^{\rm SPT}\_{3}=-0.12\pm 0.86$, which again is consistent with the standard
model of recombination. The small changes in the mode
amplitudes when adding the third mode arise because the SPT modes are
not optimal for Planck and so are correlated.

### 6.8 Cosmic defects

Topological defects are a generic by-product of symmetry-breaking
phase transitions and a common phenomenon in condensed matter
systems. Cosmic defects of various types can be formed in phase
transitions in the early Universe ([Kibble 1976](#bib.bib194)). In
particular, cosmic strings can be produced in some supersymmetric and
grand-unified theories at the end of inflation
([Jeannerot et al. 2003](#bib.bib185)), as well as in higher-dimensional theories
([Polchinski 2005](#bib.bib289), e.g.,). Constraints on the abundance of
cosmic strings and other defects therefore place limits on a range of
models of the early Universe. More discussion on the formation, evolution, and
cosmological role of topological defects can be found, for example, in
the reviews by [Vilenkin & Shellard (2000)](#bib.bib344), [Hindmarsh & Kibble (1995)](#bib.bib167), and
[Copeland & Kibble (2010)](#bib.bib89).

In this section we revisit the power spectrum-based constraints
on the abundance of cosmic strings and other topological defects
using the 2015
Planck data, including Planck polarization measurements.
The general approach follows that described in the Planck 2013
analysis of cosmic defects ([Planck Collaboration
XXV 2014](#bib.bib264)),
so here we focus on the updated constraints rather than on details of
the methodology.

Figure 46: Marginalized posterior distributions for the fractional
contribution, $f\_{10}$, of the defect contribution to the temperature power
spectrum at $\ell=10$ (see the text for the precise definition).
Here we show the constraints for the Nambu-Goto cosmic strings
(NG, solid black), field-theory simulations of Abelian-Higgs cosmic strings
(AH, solid red), semi-local strings (SL, dotted blue), and global textures
(TX, dashed green).
The upper panel shows the 1D posterior for the Planck+lowP data, while
constraints shown in the lower panel additionally use the $TE$ and $EE$ data.

Topological defects are non-perturbative excitations of the underlying
field theory and their study requires numerical simulations.
Unfortunately, since the Hubble scale, $c/H\_{0}$, is over 50
orders of magnitude greater that the thickness of a GUT-scale string, approximately
$(\hbar/\mu c)^{1/2}$ with $\mu$ the mass per unit length of
the string, it is impractical to simulate the string
dynamics exactly in the late Universe. For this reason one needs to make
approximations. One approach considers the limit of an infinitely thin
string, which corresponds to using the Nambu-Goto (“NG”) action for the
string dynamics. In an alternative approach, the actual field dynamics for a
given model are solved on a lattice. In this case it is necessary to
resolve the
string core, which generally requires more computationally intensive simulations than in the NG
approach. Lattice simulations, however, can include additional physics,
such as field radiation that is not present in NG simulations. Here we will use
field-theory simulations of the Abelian-Higgs action (“AH”); details of these
simulations are discussed in [Bevis et al. (2007)](#bib.bib50); [Bevis et al. (2010)](#bib.bib51).

The field-theory approach also allows one to simulate theories in which
the defects are not cosmic strings and so cannot be described by the NG
action. Examples include semi-local strings
([Urrestilla et al. 2008](#bib.bib340), “SL”,) and global defects. Here we will
specifically consider the breaking of a global $O(4)$ symmetry resulting in
texture defects (“TX”).

For the field-theory defects, we measure the energy-momentum tensor
from the simulations and insert it as an additional constituent into a
modified version of the CMBEASY Boltzmann code
([Doran 2005](#bib.bib101)) to predict the defect contribution to
the CMB temperature and polarization power spectra ([Durrer et al. 2002](#bib.bib106), see,
e.g.,). The same approach can be applied to NG
strings, but rather than using simulations directly, we model the strings
using the unconnected segment model
([Albrecht et al. 1999](#bib.bib12); [Pogosian & Vachaspati 1999](#bib.bib286), “USM”,). In this model, strings
are represented by a set of uncorrelated straight segments, with scaling
properties chosen to match those determined from numerical simulations. In this
case, the string energy-momentum tensor can be computed analytically
and used as an active source in a modified Boltzmann code. For this
analysis we use CMBACT version
4,4141
41
<http://www.sfu.ca/~levon/cmbact.html>
whereas
[Planck Collaboration
XXV (2014)](#bib.bib264) used version 3. There have been several
improvements to the code since the 2013 analysis, including a correction to the
normalization of vector mode spectra. However, the largest change comes
from an improved treatment of the scaling properties. The string
correlation length and velocity are described by an updated
velocity-dependent one-scale model ([Martins & Shellard 2002](#bib.bib226)), which
provides better agreement with numerical simulations.
Small-scale structure of the string, which was previously a free
parameter, is accounted for by the one-scale model.

The CMB power spectra from defects are proportional to $(G\mu/c^{2})^{2}$. We scale the computed template CMB spectra, and add these to the inflationary and
foreground power spectra, to form the theory spectra that enter the likelihood. In practice, we parameterize the defects with their relative contribution to the $TT$ spectrum at multipole $\ell=10$, $f\_{10}\equiv C^{TT{\rm(defect)}}\_{10}/C^{TT{\rm(total)}}\_{10}$. We vary $f\_{10}$ and the standard six parameters of the base $\rm{\Lambda CDM}$ model, using CosmoMC. We also report our results in terms of the derived parameter $G\mu/c^{2}$.

Table 8: 95 % upper limits on the parameter $f\_{10}$
and on the derived parameter $G\mu/c^{2}$ for the defect models discussed in
the text. We show results for Planck TT+lowP data as well as for
Planck TT,TE,EE+lowP.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | |  |  |  |  |  | | --- | --- | --- | --- | --- | |  | TT+lowP | | TT,TE,EE+lowP | | | Defect type | $f\_{10}$ | $G\mu/c^{2}$ | $f\_{10}$ | $G\mu/c^{2}$ | | NG. | $<0.020$ | $<\kern 5.00002pt1.8\times 10^{-7}$ | $<0.011$ | $<1.3\times 10^{-7}$ | | AH. | $<0.030$ | $<\kern 5.00002pt3.3\times 10^{-7}$ | $<0.015$ | $<2.4\times 10^{-7}$ | | SL. | $<0.039$ | $<10.6\times 10^{-7}$ | $<0.024$ | $<8.5\times 10^{-7}$ | | TX. | $<0.047$ | $<\kern 5.00002pt9.8\times 10^{-7}$ | $<0.036$ | $<8.6\times 10^{-7}$ | |  |

The constraints on $f\_{10}$ and the inferred limits on $G\mu/c^{2}$ are
summarized in Table [8](#S6.T8 "Table 8 ‣ 6.8 Cosmic defects ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). The marginalized 1D
posterior distribution functions are shown in
Fig. [46](#S6.F46 "Figure 46 ‣ 6.8 Cosmic defects ‣ 6 Extensions to the base 𝚲CDM model ‣ Planck 2015 results. XIII. Cosmological parameters"). For Planck TT+lowP we find that the
results are similar to the Planck+WP constraints reported in
[Planck Collaboration
XXV (2014)](#bib.bib264), for the AH model, or somewhat better for SL
and TX. However, the addition of the Planck high-$\ell$ $TE$ and $EE$
polarization data leads to a significant improvement compared to the
2013 constraints.

For the NG string model, the results based on
Planck TT+lowP are slightly weaker than the 2013
Planck+WP constraints. This is caused by a
difference in the updated defect spectrum from the USM model, which has a
less pronounced peak and shifts towards the AH spectrum. With the
inclusion of polarization, Planck TT,TE,EE+lowP improves the
upper limit on $f\_{10}$ by a factor of 2, as for the AH
model. The differences between the AH and NG results quoted here can be
regarded as a rough indication of the uncertainty in the theoretical
string power spectra.

In summary, we find no evidence for cosmic defects from the Planck 2015 data,
with tighter limits than before.

## 7 Conclusions4242 42 As in the abstract, here we quote 68 % confidence limits on measured parameters and 95 % upper limits on other parameters.

##### (1)

The six-parameter base $\rm{\Lambda CDM}$ model continues to
provide a very good match to the more extensive 2015 Planck data, including
polarization.
This is the most important conclusion of this paper.

##### (2)

The 2015 Planck $TT$, $TE$, $EE$, and lensing spectra are consistent with
each other under the assumption of the base $\rm{\Lambda CDM}$ cosmology.
However, when comparing the $TE$ and $EE$ spectra computed for different
frequency combinations, we find evidence for systematic effects caused by
temperature-to-polarization leakage. These effects are at low
levels and have little impact on the science conclusions of this paper.

##### (3)

We have presented the first results on polarization from the LFI at
low multipoles. The LFI polarization data, together with
Planck lensing and high-multipole temperature data, gives a
reionization optical depth of $\tau=0.066\pm 0.016$ and a
reionization redshift of $z\_{\text{re}}=8.8^{+1.7}\_{-1.4}$. These numbers are
in good agreement with those inferred from the WMAP9 polarization data
cleaned for polarized dust emission using HFI 353-GHz maps.
They are also in good agreement with results from Planck temperature
and lensing data, i.e., excluding any information from polarization at
low multipoles.

##### (4)

The absolute calibration of the Planck 2015 HFI spectra is higher by
$2\thinspace\%$ (in power) compared to 2013, largely resolving the calibration
difference noted in [258](#bib.bib258) between WMAP and Planck. In addition, there
have been a number of small changes to the low-level
Planck processing and more accurate calibrations of the HFI
beams. The 2015 Planck likelihood also makes more aggressive use of
sky than in [258](#bib.bib258) and incorporates some refinements to the modelling
of unresolved foregrounds. Apart from differences in $\tau$ (caused by
switching to the LFI low-multipole polarization likelihood, as described in
item 3 above) and the amplitude-$\tau$ combination
$A\_{\rm s}{\rm e}^{-2\tau}$ (caused by the change in absolute
calibration), the 2015 parameters for base $\rm{\Lambda CDM}$ are in good
agreement with those reported in [258](#bib.bib258).

##### (5)

The Planck $TT$, $TE$, and $EE$ spectra are accurately described by a
purely adiabatic spectrum of fluctuations with a spectral tilt $n\_{\rm s}=0.968\pm 0.006$, consistent with the predictions of single-field
inflationary models. Combining Planck data with BAO, we find tight
limits on the spatial curvature of the Universe, $|\Omega\_{K}|<0.005$, again consistent with the inflationary prediction of
a spatially-flat Universe.

##### (6)

The Planck data show no evidence for tensor modes. Adding a tensor
amplitude as a one-parameter extension to base $\rm{\Lambda CDM}$, we derive a 95 %
upper limit of $r\_{0.002}<0.11$. This is consistent with the
$B$-mode polarization analysis reported in [54](#bib.bib54), resolving the
apparent discrepancy between the Planck constraints on $r$ and the
BICEP2 results reported by [BICEP2 Collaboration (2014)](#bib.bib53). In fact, by combining
the Planck and BKP likelihoods, we find an even tighter constraint,
$r\_{0.002}<0.09$, strongly disfavouring inflationary models with a
$V(\phi)\propto\phi^{2}$ potential.

##### (7)

The Planck data show no evidence for any significant running of
the spectral index. We also set strong limits on a possible departure from
a purely adiabatic spectrum, either through an admixture of
fully-correlated isocurvature modes or from cosmic defects.

##### (8)

The Planck best-fit base $\rm{\Lambda CDM}$ cosmology (we quote numbers for
Planck TT+lowP+lensing here) is in good agreement with results from BAO
surveys, and with the recent JLA sample of Type Ia SNe. The Hubble
constant in this cosmology is $H\_{0}=(67.8\pm 0.9)\penalty\ \text{km}\penalty\ \text{s}^{-1}\text{Mpc}^{-1}$,
consistent with the direct measurement of $H\_{0}$ of Eq. ([19](#S5.E19 "In 5.4 The Hubble constant ‣ 5 Comparison of the Planck base Λ⁢CDM model with other astrophysical data sets ‣ Planck 2015 results. XIII. Cosmological parameters"))
used as an $H\_{0}$ prior in this paper. The Planck base
$\rm{\Lambda CDM}$ cosmology is also consistent with the recent analysis of
redshift-space distortions of the BOSS CMASS-DR11 data by
[Samushia et al. (2014)](#bib.bib304) and [Beutler et al. (2014)](#bib.bib48). The amplitude of the
present-day fluctuation spectrum, $\sigma\_{8}$, of the Planck base
$\rm{\Lambda CDM}$ cosmology is higher than inferred from weak lensing measurements
from the CFHTLenS survey ([Heymans et al. 2012](#bib.bib166); [Erben et al. 2013](#bib.bib112)) and, possibly,
from counts of rich clusters of galaxies (including Planck cluster counts
reported in [Planck Collaboration
XXIV 2016](#bib.bib280)). The Planck base $\rm{\Lambda CDM}$ cosmology is
also discordant with Ly$\alpha$ BAO measurements at $z\approx 2.35$
([Delubac et al. 2015](#bib.bib97); [Font-Ribera et al. 2014](#bib.bib126)). At present, the reasons for these
tensions are unclear.

##### (9)

By combining the Planck TT+lowP+lensing data with other astrophysical data,
including the JLA supernovae, the equation of state for dark energy is
constrained to $w=-1.006\pm 0.045$ and is therefore compatible with a
cosmological constant, as assumed in the base $\rm{\Lambda CDM}$ cosmology.

##### (10)

We have presented a detailed analysis of possible extensions to the
neutrino sector of the base $\rm{\Lambda CDM}$ model. Combining Planck TT+lowP+lensing with BAO
we find $N\_{\rm eff}=3.15\pm 0.23$ for the effective number of relativistic degrees of freedom,
consistent with the value $N\_{\rm eff}=3.046$ of the standard
model. The sum of neutrino masses is constrained to $\sum m\_{\nu}<0.23\thinspace{\rm eV}$. The Planck data strongly disfavour fully thermalized
sterile neutrinos with $m\_{\rm sterile}\approx 1\thinspace{\rm eV}$ that have
been proposed as a solution to reactor neutrino oscillation
anomalies. From Planck, we find no evidence for new neutrino physics.
Standard neutrinos with masses larger than those in the minimal mass hierarchy are still allowed,
and could be detectable in combination with future astrophysical and CMB lensing data.

##### (11)

The standard theory of big bang nucleosynthesis, with $N\_{\rm eff}=3.046$ and negligible leptonic asymmetry in the electron neutrino
sector, is in excellent agreement with Planck data and observations
of primordial light element abundances. This agreement is particularly
striking for deuterium, for which accurate primordial abundance measurements
have been reported recently ([Cooke et al. 2014](#bib.bib88)). The BBN theoretical
predictions for deuterium are now dominated by uncertainties in nuclear
reaction rates (principally the ${\rm d}({\rm p},\gamma)^{3}\mbox{He}$
radiative capture process), rather than from Planck uncertainties in the
physical baryon density $\omega\_{\mathrm{b}}\equiv\Omega\_{\mathrm{b}}h^{2}$.

##### (12)

We have investigated the temperature and polarization signatures associated with annihilating dark matter and
possible deviations from the standard recombination history. Again, we find no evidence for new physics from
the Planck data.

In summary, the Planck temperature and polarization spectra
presented in Figs. [1](#S3.F1 "Figure 1 ‣ (2) DetSets versus cross-surveys. ‣ 3.1 Changes in the base Λ⁢CDM parameters compared to the 2013 data release ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") and [3](#S3.F3 "Figure 3 ‣ (5) Goodness of fit. ‣ 3.3.1 Temperature spectra and likelihood ‣ 3.3 The 2015 Planck temperature and polarization spectra and likelihood ‣ 3 Constraints on the parameters of the base 𝚲CDM cosmology from Planck ‣ Planck 2015 results. XIII. Cosmological parameters") are more
precise (and accurate) than those from any previous CMB experiment,
and improve on the 2013 spectra presented in [258](#bib.bib258). Yet we find
no signs for any significant deviation from the base
$\rm{\Lambda CDM}$ cosmology. Similarly, the analysis of 2015 Planck data
reported in [Planck Collaboration
XVII (2016)](#bib.bib278) sets unprecedentedly tight limits
on primordial non-Gaussianity. The Planck results offer powerful
evidence in favour of simple inflationary models, which provide an
attractive mechanism for generating the slightly tilted spectrum of
(nearly) Gaussian adiabatic perturbations that match our data
to such high precision. In addition, the Planck data show that the
neutrino sector of the theory is consistent with the assumptions of
the base $\rm{\Lambda CDM}$ model and that the dark energy is compatible with a
cosmological constant. If there is new physics beyond base $\rm{\Lambda CDM}$,
then the corresponding observational signatures in the CMB are weak
and difficult to detect. This is the legacy of the Planck mission
for cosmology.

###### Acknowledgements.

The Planck Collaboration acknowledges the support of: ESA; CNES and CNRS/INSU-IN2P3-INP (France); ASI, CNR, and INAF (Italy); NASA and DoE (USA); STFC and UKSA (UK); CSIC, MINECO, JA, and RES (Spain); Tekes, AoF, and CSC (Finland); DLR and MPG (Germany); CSA (Canada); DTU Space (Denmark); SER/SSO (Switzerland); RCN (Norway); SFI (Ireland); FCT/MCTES (Portugal); ERC and PRACE (EU). A description of the Planck Collaboration and a list of its members, indicating which technical or scientific activities they have been involved in, can be found at [http://www.cosmos.esa.int/web/planck/planck-collaboration](http://www.cosmos.esa.int/web/planck/planck%2dcollaboration).
Some of the results in this paper have been derived using the HEALPix
package.
The research leading to these results has received funding from the European
Research Council under the European Union’s Seventh Framework Programme
(FP/2007–2013) / ERC Grant Agreement No. [616170] and from the UK Science and
Technology Facilities Council [grant number ST/L000652/1].
Part of this work was undertaken on the STFC DiRAC HPC Facilities at the
University of Cambridge, funded by UK BIS National E-infrastructure capital
grants, and on the Andromeda cluster of the University of Geneva.
A large set of cosmological parameter constraints from different
data combinations, and including many separate extensions to the 6-parameter
base $\rm{\Lambda CDM}$ model, are available at
<http://pla.esac.esa.int/pla/#cosmology>.
