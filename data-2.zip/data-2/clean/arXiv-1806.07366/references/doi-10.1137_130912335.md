<!-- fulltext source=oa_pdf slug=doi-10.1137_130912335 fetched=2026-09-18T01:32:06+00:00 -->

# **FATODE: A LIBRARY FOR FORWARD, ADJOINT, AND TANGENT LINEAR INTEGRATION OF ODES**<sup>_∗_</sup> 

HONG ZHANG<sup>_†_</sup> AND ADRIAN SANDU<sup>_‡_</sup> 

**Abstract.** Fatode is a fortran library for the integration of ordinary differential equations with direct and adjoint sensitivity analysis capabilities. The paper describes the capabilities, implementation, code organization, and usage of this package. Fatode implements four families of methods – explicit Runge-Kutta for nonstiff problems and fully implicit Runge-Kutta, singly diagonally implicit Runge-Kutta, and Rosenbrock for stiff problems. Each family contains several methods with different orders of accuracy; users can add new methods by simply providing their coefficients. For each family the forward, adjoint, and tangent linear models are implemented. General purpose solvers for dense and sparse linear algebra are used; users can easily incorporate problem-tailored linear algebra routines. The performance of the package is demonstrated on several test problems. To the best of our knowledge fatode is the first publicly available general purpose package that offers forward and adjoint sensitivity analysis capabilities in the context of Runge Kutta methods. A wide range of applications are expected to benefit from its use; examples include parameter estimation, data assimilation, optimal control, and uncertainty quantification. 

**Key words.** Runge Kutta methods, tangent linear model, adjoint model, sensitivity analysis. 

**AMS subject classifications.** 97N80, 65L99, 49Q12 

**1. Introduction.** Many dynamical systems in science and engineering are modeled by ordinary differential equations (ODEs) 



Here _y_ ( _t_ ) _∈_ R<sup>_d_</sup> is the solution vector, _y_ 0 the initial condition, and _p ∈_ R<sup>_m_</sup> a vector of model parameters. Stiffness results from the existence of multiple dynamical scales, with the fastest characteristic times being much smaller than the time scales of interest in the simulation. It is well known that the numerical solution of stiff systems requires unconditionally stable discretizations which allow time steps that are not bounded by the fastest time scales in the system [17]. Here we assume that the system parameters _p_ are independent of time. In the context of the ODE system (1.1), sensitivity analysis yields derivatives of the solution with respect to the initial conditions or system parameters, as follows 



Two main approaches are available for computing the sensitivities (1.2). The direct (or tangent linear) method is efficient when the number of parameters is smaller than the dimension of the system ( _m ≪ d_ ), while the adjoint method is efficient when the number of parameters is larger than the dimension of the system ( _m ≫ d_ ). Furthermore, two distinct approaches can be taken for defining adjoint sensitivities; the continuous adjoint (differentiate then discretize) and the discrete adjoint (discretize then differentiate) approaches typically lead to different computational results. 

> _∗_ This work is supported by the National Science Foundation through the awards NSF DMS– 0915047, NSF CCF–0916493, NSF OCI–0904397. 

> _†_ Computational Science Laboratory, Department of Computer Science, Virginia Polytechnic Institute and State University, Blacksburg, VA 24061 (zhang@vt.edu) 

> _‡_ Computational Science Laboratory, Department of Computer Science, Virginia Polytechnic Institute and State University, Blacksburg, VA 24061 (sandu@cs.vt.edu) 

1 

Sensitivity analysis is an essential ingredient for uncertainty quantification, parameter estimation, optimization, optimal control, and construction of reduced order models. Only a few available software packages for the solution of ODEs have the capability to compute sensitivities. One of the earlier packages is Odessa [19], which performs direct sensitivity analysis. A modern package is cvodes within sundials [26] from Lawrence Livermore National Laboratory. cvodes is able to compute direct and continuous adjoint sensitivities. Both Odessa and cvodes are based on backward differentiation formulas (BDF). A software based on explicit Runge-Kutta discretizations is denserks [2] which implements continuous adjoint sensitivity analysis for non-stiff ODEs. The Kinetic PreProcessor KPP [23, 1] is a widely used tool for the simulation of chemical kinetics, and incorporates Runge-Kutta and Rosenbrock solvers that are endowed with tangent linear and discrete adjoint sensitivity analysis capabilities. 

In this paper we present a library of explicit/implicit Runge-Kutta and Rosenbrock solvers for the simulation of nonstiff and stiff ODEs. The library, called fatode, performs forward simulations, and sensitivity analysis via the discrete adjoint and the tangent linear methods. Fatode is based on the KPP library of solvers. While the KPP implementation is specifically aimed at chemical kinetic systems, the fatode implementation is general and suitable for a wide range of applications. 

The paper is organized as follows. Section 2 reviews several numerical integration algorithms. Section 3 discusses the structure and implementation of fatode. The code usage in applications is summarized in Section 4. An example is shown in Section 5, and conclusions are drawn in Section 6. 

**2. Numerical integration methods in** fatode **.** Explicit Runge-Kutta methods [16] are well suited for solving nonstiff systems of ODEs. Implicit methods are preferred for solving stiff systems due to their better numerical stability properties. Fatode implements four families of methods: explicit Runge-Kutta, Rosenbrock, fully implicit Runge-Kutta, and singly diagonally implicit Runge-Kutta, as well as their tangent linear models and discrete adjoint models. The implicit methods have been implemented in implemented in KPP [23, 1] and have proved to be very efficient for solving many stiff chemical problems including CBM-IV [11], SAPRC [5] and NASA HSRP/AESA. 

_Runge-Kutta methods._ A general _s_ -stage Runge-Kutta method reads [16] 



where the coefficients 



define the method and determine its accuracy and stability properties. Explicit Runge-Kutta methods are characterized by the coefficients _ai,j_ = 0 for all _i_ and _j ≥ i_ . Singly diagonal implicit Runge-Kutta methods are defined by (2.1) with the coefficients _ai,i_ = _γ_ and _ai,j_ = 0 for all _i_ and _j > i_ . Fully implicit methods have three stages and require a coupled solution of all of them. Detailed information on available Runge Kutta methods is given in Table 2.1. 

2 

_Rosenbrock methods._ An _s_ -stage Rosenbrock method [16] is given by the formulas 





where particular methods are defined by their coefficients 



and 



We have _γi,i_ = _γ_ for all _i_ for computational efficiency. Here **_fy_** = _∂f/∂y_ represents the Jacobian of the ODE function, as discussed in Appendix A. We will denote matrices and tensors by bold symbols, and vectors and scalar by regular symbols. Rosenbrock methods are attractive because of their outstanding stability properties and conservation of the linear invariants of the system. They typically outperform backward differentiation formulas such as those implemented in SMVGEAR [10] for medium accuracy solutions. 

Detailed information regarding these methods is given in Table 2.1. 

**3. Implementation.** This section summarizes several implementation aspects of fatode. We start with the the forward integrators, and continue with the implementation of the tangent linear models and discrete adjoint models. The derivation of the sensitivity models can be found in earlier literature [24, 6]. We also describe linear algebra olvers and error control schemes in fatode, which are important factors in determining the efficiency of the code. 

# **3.1. Forward model integration.** 

_Explicit Runge Kutta methods._ The implementation of explicit methods is based on (2.1). The stage vectors are computed in succession using 



_Matrices for solving implicit methods._ The implementations of implicit methods use the following matrices 



Table 2.1 

_Time stepping methods implemented in_ fatode _. (ERK, FIRK, SDIRK and ROS stand for Explicit Runge-Kutta, Fully Implicit Runge-Kutta, Singly Diagonally Implicit Runge-Kutta and Rosenbrock, respectively.)_ 

|Family|Method|Stages|Order|Stability properties|
|---|---|---|---|---|
||RK2(3) [16]|3|2|conditionally stable|
||RK3(2) [16]|4|3|conditionally stable|
|ERK|RK4(3) [16]|5|4|conditionally stable|
||DOPRI-5 [16]|7|5|conditionally stable|
||Verner [16]|8|6|conditionally stable|
||DOPRI-853 [16]|12|8|conditionally stable|
||Radau-1A [17]|3|5|Stiffly-accurate|
|FIRK|Radau-2A [17]|3|5|Stiffly-accurate|
||Lobatto-3C [17]|3|4|Stiffly-accurate|
||Gauss [17]|3|6|Stiffly-accurate|
||Sdirk-2a|2|2|L-stable|
||Sdirk-2b|2|2|L-stable|
|SDIRK|Sdirk-3a|3|2|Stiffly-accurate|
||Sdirk-4a [17]|5|4|L-stable|
||Sdirk-4b [17]|5|4|L-stable|
||Ros-2 [28]|2|2|L-stable|
|ROS|Ros-3 [25]|3|3|L-stable|
||Rodas-3 [25]|4|3|Stiffly-stable|
||Ros-4 [17]|4|4|L-stable|
||Rodas-4 [17]|6|4|Stiffly-stable|



# and 



Replacing each **_fy_** ( _Ti, Yi_ ) in (3.2c) by **_fy_** ( _tn, tn_ ) leads to the approximation: (3.2d) **R** _n_ = **_I_** ( _ds,ds_ ) _− h_ **_A_** _⊗_ **_fy_** ( _tn , yn_ ) _≈_ **R**<sup>�</sup> _n ,_ where _⊗_ is the matrix Kronecker product [17]. 

_Implicit Runge-Kutta methods._ To reduce the influence of round-off errors, we apply the transformation _zi_ = _Yi − yn_ [17] in the formulas (2.1) to obtain 



The new coefficients are (3.4) **_d_** = [ _di_ ]1 _≤i≤s ,_ **_d_**<sup>_T_</sup> = **_b_**<sup>_T_</sup> _·_ **_A_**<sup>_−_1</sup> _._ 4 

_Singly diagonally implicit Runge-Kutta methods._ The stage equations (3.3a) read 



The nonlinear systems of equations (3.5) are solved in succession for each stage _i_ = 1 _, . . . , s_ by simplified Newton iterations of the form 



The same matrix is shared for all iterations and all stages, so that only one LU decomposition of **R** _n_ is performed in each time step. 

_Fully implicit Runge-Kutta methods._ Fully implicit Runge-Kutta methods require the solution of the _ds × ds_ nonlinear system (3.3a) [24]. With the compact notation 



The system (3.8) is solved by simplified Newton iterations [17], 



Note that only the Jacobian at the beginning of the time step is used in Newton’s iterations. Following [17], our implementation of the fully implicit _s_ -stage RungeKutta method uses a transformation of the system (3.9) to a complex form such that the costly _ds_ -dimensional real LU decomposition is replaced by _d_ -dimensional LU decompositions of matrices of the form **R** ( _λi, tn, yn_ ), where _λi_ are the eigenvalues of **A** . For the 3-stage methods implemented in fatode the coefficient matrices **A** have one real and two complex conjugate eigenvalues, which leads to solving one real and one complex _d_ -dimensional systems. 

_Rosenbrock methods._ For implementation purpose, we use the alternative formulation [16] of the formula (2.3) 



where 



At each stage (3.10b) the solution of a linear system of dimension _d × d_ is required. The same matrix **R**<sup>�</sup> _n_ is shared by all the stages and one LU decomposition per step is required. 

**3.2. Tangent linear model integration.** Small changes _δy_ 0 in the initial conditions result in small perturbations _δy_ ( _t_ ) of the solution of ODE system (1.1). Let _y_ ˙ = _δy/ ∥δy_ 0 _∥_ be the directions of solution change. These directions propagate forward in time according to the _tangent linear ODE_ : 



The sensitivity equations (3.11) are solved forward in time together with original ODE system (1.1). Tangent linear models are derived for direct sensitivity analysis with each of the families of methods in fatode. Highly efficient implementations are obtained by re-using the LU decompositions from the forward solution on the sensitivity equations [9]. 

_Tangent linear Runge Kutta methods._ A tangent linear Runge-Kutta (2.1) method reads 



Similar to the implementation of implicit forward integrators, we introduce the sensitivity stage variables _z_ ˙ _i_ = _Y_<sup>˙</sup> _i − y_ ˙ _n_ and the sensitivity part becomes 



Using the compact notation (3.7) and the matrix (3.2c) the stage equations (3.13a) can be written as 



_Explicit RK methods._ For ERK methods the equations (3.12a) are solved successively for each stage _i_ = 1 _, · · · , s_ , using 



_Singly diagonally implicit RK methods._ For SDIRK methods the system (3.13a) reduces to _s_ independent _d_ -dimensional linear systems that are solved successively for each stage _i_ = 1 _, · · · , s_ 



fatode allows users to choose to solve the linear system (3.15) directly at the expense of an additional LU decomposition of the matrix **R** _n_ ( _γ, Ti, Yi_ ) per stage, or to apply simplified Newton iterations of the form 



The LU decomposition of the matrix **R** _n_ ( _γ, tn, yn_ ) is also necessary in forward integration. So the equations (3.15) re-use the LU decomposition which is available after the equations (3.6) are calculated in each step. 

_Fully implicit RK methods._ For fully implicit Runge-Kutta methods two options are available for solving the system (3.14). One is to construct the _ds × ds_ linear system (3.14) explicitly and solve it directly by factorizing the matrix **R**<sup>�</sup> _n_ . 

The other is to apply simplified Newton iterations of the form 



The matrix **R** _n_ of the resulting _ds × ds_ linear system is available from the forward solution process, i.e., the calculations of the equations (3.9). The real and complex LU decompositions can be reused. According to our experience, the second option is usually more efficient than the first one for large systems. 

_Rosenbrock methods._ The tangent linear Rosenbrock method consists of the formula formula (3.10) plus the sensitivity part, which is obtained by differentiating the formula (3.10). In each step we solve the combined set of equations 



The stage vectors _k_<sup>˙</sup> _i_ are obtained in succession by solving a sequence of linear systems, all of which re-use the LU decomposition of **R**<sup>�</sup> ( _hγ, tn, yn_ ) performed in (3.10). Formula (3.17b) involves the Hessian tensor **_fy,y_** ( _tn, yn_ ). In practice, an analytical Hessian tensor is difficult to obtain, and its evaluation is costly in both CPU time and memory storage. Note that the above equation only needs the product ( ˙ _yn ·_ **_fy,y_** ( _tn, yn_ )) _· ki_ . Such terms can be obtained efficiently using automatic differentiation [4, 13] twice, in forward over reverse mode. 

7 

**3.3. Adjoint model integration.** Adjoint sensitivity analysis provides an efficient alternative to the direct method when gradients of a relatively few derived functionals with respect to many model parameters required. The continuous (differentiate then discretize) and the discrete (discretize-then-differentiate) adjoint approaches lead, in general, to different computational results [27]. The continuous adjoint approach requires interpolation to obtain intermediate state variables at the times required by the the backward integration, which brings additional computational effort. The discrete adjoint approach follows exactly the same sequence of time steps as the forward integration, but in reverse order. 

Fatode implements discrete adjoints of all the methods. Such discrete adjoints have good theoretical properties, in the sense that they are consistent discretizations of the adjoint ODE [21, 22]. For efficiency our implementation distinguishes between sensitivities with respect to initial conditions and sensitivities with respect to parameters. We first discuss sensitivities with respect to initial conditions. 

The goal is to evaluate the sensitivities a scalar function of interest 

# (3.18) 



with respect to the initial conditions. The discrete adjoint model equations are obtained directly from the discrete forward model equations 



where Φ<sup>_n_</sup> represents the one-step numerical integration formula which advances the solution from _tn_ to _tn_ +1. 

The discrete adjoint model equations propagates the adjoint variables _λn_ backwards in time 



The adjoint solution at the initial time represents the sensitivities 

(3.21) ( _∂_ Ψ _/∂y_ 0)<sup>_T_</sup> = _λ_ 0 _._ 

For details on derivation see [23, 21]. 

The discrete adjoint Runge-Kutta method [15] solving the discrete adjoint equations (3.20) reads 



The stage equations (3.22a) form a _ds × ds_ linear system involving the transpose of matrix (3.2c): 



_Explicit RK methods._ The stage equations (3.22a) are solved in succession for stages _s_ down to 1: 



Each stage _i_ requires the computation of the Jacobian **_fy_** ( _Ti, Yi_ ), forming the vector _bi λ_<sup>_n_+1</sup> +<sup>∑</sup><sup>_s_</sup> _j_ = _i_ +1<sup>_aj,iuj_frompreviouslycomputedstages</sup><sup>_us . . . ui_+1,andperforming</sup> one Jacobian vector product. 

_Singly diagonally implicit Runge-Kutta methods._ For SDIRK methods the _s_ stages of the system (3.22a) are solved successively from the last stage to the first. Each stage requires the solution of a different linear system: 



Fatode offers two options: to form and solve one linear system (3.25) per stage, or to employ simplified Newton iterations of the form (3.15) and re-use the LU decomposition of **R** _n_ ( _γ, tn, yn_ ) for all stages. 

_Fully implicit Runge-Kutta methods._ For the fully implicit Runge-Kutta methods the _ds × ds_ system (3.23) is fully coupled. fatode offers two approaches to solve it. The first is to build and solve directly (3.23) via a _ds × ds_ LU decomposition of **R**<sup>�</sup> _n_ . The second approach uses simplified Newton iterations of the form (3.14), where **R**<sup>�</sup> _n_ is replaced by **R** _n_ in (3.23), and the transformation to real and complex systems is performed. The real and complex LU factorizations associated with the matrix **R** _n_ are re-used in all iterations. These factorizations are computed during the forward solution, and in principle they can be checkpointed. The tradeoff between the size of the LU factorizations to store and the time needed to recompute them will determine the best strategy. 

_Rosenbrock methods._ The discrete Rosenbrock adjoint [1] is 



The linear system (3.26a) can be solved directly at each stage. Users have to supply a routine for calculating the term ( _ui ·_ **_fy,y_** ( _tn, yn_ )) _· ki_ , whose meaning is explained in Appendix A. Automatic differentiation tools like TAMC [13] provide considerable help: the product between the Hessian transposed times vector can be obtained by two consecutive runs of TAMC in forward mode. 

_Checkpointing._ The adjoint model requires two runs. First the forward code performs a regular integration of the ODE system. At each step the time _tn_ , the step size h, the state vector _yn_ , and the intermediate stage vectors _zi_ or _ki_ are all saved in checkpoints. Next, the discrete adjoint code is run backward in time and 

9 

traces the same sequence of steps, but in reverse order. At each step, the data in the checkpoint storage is retrieved and used to construct the adjoint system. The results of LU factorizations can, in principle, be checkpointed and reused in the adjoint calculations. This is not done in our implementation, due to the following reasons. The memory and input/output costs for storing LU factors can be extremely large when the system is large or when many steps are taken. Next, fatode is designed such that the details of the linear solver are transparent to the main integrator. This transparency cannot be preserved when one builds and manages a stack for data structures that are specific to particular linear solvers. 

**3.4. Adjoint sensitivities with respect to a vector of parameters.** We now consider the case where the adjoint sensitivity is computed with respect to a time-independent vector of parameters _p ∈_ R<sup>_m_</sup> which appears in the right hand side of (1.1). The quantity of interest is a scalar derived function in the general form 



To account for the evolution of the parameters we add the formal equations for the parameter evolution _p_<sup>_′_</sup> = 0. To compute the cost function (3.27) we add the quadrature variables _q ∈_ R whose evolution is defined by _q_ ( _t_ 0) = 0 and _q_<sup>_′_</sup> = _r_ ( _y, p_ ). We have that Ψ = _g_ ( _y_ ( _tF_ ) _, p_ ) + _q_ ( _tF_ ). The equation (1.1) becomes 



As shown in Appendix C the numerical solution of (3.28) provides the discrete _yn_ and _qn_ . The discrete adjoint model equations calculate the adjoint variables _λn_ and _µn_ backward in time, such that 



For details on derivation see [21] and Appendix C . 

_Runge-Kutta methods._ The derivation of sensitivities with respect to parameters for Runge Kutta methods is detailed in Appendix D. Consider the Runge-Kutta method (2.1) applied to the extended ODE system (3.28) 



Note that, since _r_ does not depend on _q_ , there is no need to compute the stage values for the quadrature variable. 

As shown in Appendix D the discrete adjoint Runge-Kutta method (D.2) reads 





The stages _ui_ are obtained by solving the system in a similar way as solving system (3.24) and the implementation differs between SDIRK and fully implicit 3-stage Runge-Kutta method. Then _vi_ can be readily obtained from the right-hand side calculation. 

_Rosenbrock methods._ Applying the Rosenbrock method (3.10) to the extended system (3.28) gives the following formula for evaluating the quadrature term in the cost functional (3.27): 



Equation (3.32) is evaluated simultaneously with the ODE integration. The derivation of the adjoint Rosenbrock method for computing sensitivities with respect to parameters is given in Appendix E. 





where 



**3.5. Linear solvers.** The most computationally intensive part in solving largescale ODE systems by implicit methods is the solution of linear systems at each step. Linear systems arise from the simplified Newton iterations applied to solve the nonlinear systems in case of fully implicit Runge-Kutta methods and SDIRK methods. For Rosenbrock methods, linear systems appear directly in the formula (2.3). In general, all implicit time stepping methods in fatode require the solution of linear systems with matrices **R** or **R**<sup>�</sup> defined in (3.2). These matrices inherit the sparsity structure of the system Jacobian. 

Best efficiency is achieved when taking advantage of the problem-specific characteristics. Consequently, fatode was designed to allow users to provide their own linear solvers and sparse data structures. The linear system can be solved by either direct methods or iterative methods. Direct methods perform LU factorizations which are reused for efficiency. We have incorporated three direct methods in current version of fatode. For dense systems calls to lapack [3] routines are provided. For large sparse systems, substantial memory and execution time benefits can be gained by calling the direct sparse solvers umfpack [7] and superlu [8] and representing the sparse matrices in a compressed column format. Interfaces to both these codes are provided. Iterative methods can be more efficient than direct methods for solving extremely large linear systems regardless of the reuse of LU decompositions. The choice between direct and iterative methods depends on the specific properties of the problems. Fatode does not provide iterative solvers; these need to be supplied by the user. 

**3.6. Step size control.** Variable step size control is routinely adopted by general ODE solvers to control numerical errors and maximize efficiency. Fatode’s forward integrators use estimates of the truncation error to decide whether the step is accepted or rejected and to compute the next step size. The maximum number of integration steps before unsuccessful return can be specified by the user. 

Two different error estimation options are provided for fully implicit Runge-Kutta methods. One is the classical error estimation [17] which uses an embedded third order method based on an additional explicit stage. The embedded solution is 



where the increment vectors _zi_ are already computed in previous stages. The second estimator uses two additional stages: an explicit stage at the beginning of the time step and another SDIRK stage which re-uses the LU decomposition from the solution of the main integrator. The SDIRK stage reads 



The coefficients are chosen such that the order of consistency of _y_ ˆ _n_ +1 is _p_ ˆ = _p −_ 1, where _p_ is the order of _yn_ +1. The difference vector _Est_ = _y_ ˆ _n_ +1 _−yn_ +1 is used as a local error estimator. Based on our experience, the classical error estimator is inaccurate for low relative tolerances, while the SDIRK error estimator yields very good results and keeps the accuracy of the solution below the specified tolerance. For the ERK, SDIRK, and Rosenbrock methods the classical error estimators based on embedded solutions are implemented; they proved to work well in practice. 

12 

The local error test is performed as follows. Let _Tolk_ = _atolk_ + _rtolk · |yn_ +1 _,k|_ , where _atol_ and _rtol_ are the absolute and relative error tolerance specified by users and _|yn_ +1 _,k|_ is the absolute value of the _k_ -th component of _yn_ +1. The relative and absolute error tolerances can be either vector or scalar (in which case the same tolerance values are used for all components _k_ ). The local error test takes the form 



If the test passes the step size is accepted, otherwise it rejected and the step is recomputed. The new step size, for both accepted and rejected cases, is given by the formula 



where _F_ max is the upper bound on step increase factor, _F_ min the lower bound on step decrease factor, and _F_ safe is a safety factor. The default values of these factors depend on the specific method. All of them can be changed by the user in the parameter settings. If the step size is rejected at the first step, the step increase factor _F_ max is set to 1. and the step size is reduced by a factor of 10. Furthermore, the step size can be constrained by minimum ( _h_ min) and maximum ( _h_ max) values. The starting step size _h_ start can be specified by the user. 

For the tangent linear model integration fatode provides two options for controlling errors in the sensitivities. The first option is to use only the forward error estimates for step size control. The second option is to estimate the truncation errors for both the forward solution and the tangent linear model solution. The solution error is taken as the maximum between the forward truncation error and the truncation error of any column of the sensitivities. This solution error is then used to control the step size. 

The discrete adjoint model integration traces the same sequence of steps as the forward integration, in reverse order. Therefore, the choice of the step sizes is completely determined during the forward integration, and the accuracy of the adjoint solution will depend on the error control performed during the forward run. 

**3.7. Code organization.** Fatode implements four types of methods: explicit, fully implicit, and singly diagonally implicit Runge-Kutta methods, and Rosenbrock methods. For each family of methods, a module is given for the main integrator, a module for linear system solver interface, and a set of modules for generic linear system solvers. They form the basic structure shown in Figure 3.1. 

The main integration module provides the basic time stepping framework, and is independent of the linear system solver. The forward integrator calls the usersupplied right-hand side function and Jacobian and accesses the linear system solver, in order to compute the ODE solution. The tangent linear integrator and the adjoint integrator require users to also specify the parameters of interest as additional inputs. The tangent linear integrator, by default, considers the initial conditions of the ODE system as the parameters of interest and computes the sensitivity of the ODE solution with respect to them. The adjoint integrator, by default, computes the sensitivity of an objective function Ψ with respect to the initial conditions. The function and its derivatives are supplied by the user; function derivatives are used to define the adjoint initial conditions, see (3.20) and (C.3). Fatode also implements sensitivities 

13 



Fig. 3.1. _Overall structure of_ fatode 

of a general cost function (3.27) with respect to parameters other than the initial conditions (e.g., reaction coefficients in a chemical kinetic ODE system). This version of adjoint code is based on the techniques described in Section 3.4. 

The linear system solver module provides interfaces to generic linear solvers, which can be called seamlessly by the routines in the integrator modules. Specifically, we provide interfaces to the following four generic routines: _LS_ _~~I~~ nit_ , _LS_ _~~D~~ ecomp_ , _LS_ _~~S~~ olve_ , and _LS_ _~~F~~ ree_ . _LS_ _~~I~~ nit_ deals with initialization and memory allocation required by the specific linear solver. _LS_ _~~D~~ ecomp_ performs the LU decomposition, and _LU_ _~~S~~ olve_ solves the triangular systems by substitution. _LS_ _~~F~~ ree_ frees the memory allocated and clears the objects created during the initialization stage. The main integrator makes calls to these functions without having to consider the implementation details of these routines; many linear algebra packages can be used without having to modify the time stepping code. The user can choose one of the linear solvers provided (lapack, umfpack, superlu), or can add a new linear solver by providing their own implementation and add it to this module. The linear system solver module also contains several routines related to computing the Jacobian and its transpose, and taking the product of the Jacobian (or its transpose) with a vector vector. The implementation of these operations depends critically on the data structures used to represent the Jacobian. For example, Jacobian matrix could be stored in either dense format or in one of the many available sparse formats, and each representation leads to a totally different implementation. For computational efficiency users should to take advantage of the appropriate data structure for the Jacobian matrix when they add a new linear solver. All the required code modifications are done within this single module. 

Different families of methods require solving different types of linear systems. Fully implicit Runge-Kutta methods involve real and complex linear systems of dimension _d × d_ , or real linear systems of dimension _ds × ds_ . Singly diagonally implicit Runge-Kutta and Rosenbrock methods deal with only real-valued linear systems of dimension _d × d_ . Jacobian related operations also vary greatly between the three families of implicit methods. To manage this complexity we provide individual linear solver modules for each of the implicit time stepping families in fatode. 

The linear system modules in fatode currently include three linear solvers: lapack [3], umfpack [7] and superlu [8]. Each requires its own data format, e.g., a 

14 

full matrix is used with the lapack version, while a compressed column sparse matrix is needed with umfpack or superlu versions. The existing linear solvers can be used as templates for users who wish to add their own. A new solver requires the user to provide the four basic solution routines, as well as the Jacobian related routines if necessary. 

**4. Code usage.** This section discusses the usage of fatode for forward ODE integration, direct sensitivity analysis via tangent linear models, and computing sensitivities of a cost function with respect to initial conditions and specified parameters via adjoint models. The user interface is very similar to classic ODE solvers such as lsode, vode, radau5. A uniform interface is provided for all four integration families in fatode. This interface allows users to control nearly every aspect of the solution process, such as method selection, step size adjustment, error estimation, convergence of simplified Newton iterations, and so on. 

**4.1. ODE integration.** The call to the integrator routine is as follows: 

CALL INTEGRATE( 

TIN,TOUT,NVAR,NNZERO,VAR,RTOL,ATOL,FUN,ICNTRL, RCNTRL,ISTATUS,RSTATUS,IERR) 

All arguments except ISTATUS, RSTATUS, IERR are input arguments. ICNTRL, RCNTRL, ISTATUS, RSTATUS, IERR are optional. The arguments have the following meaning: 

|TIN|start time|
|---|---|
|TOUT|end time|
|NVAR|the number of ordinary differential equations to be solved|
|NNZERO|number of non-zero elements in the Jacobian matrix|
|VAR|a vector of length NVAR containing the initial values of the de-<br>pendent variables. Upon return, VAR is the numerical solution<br>at the last step.|
|RTOL|relative error tolerance|
|ATOL|absolute error tolerance|
|FUN|the name of the user-supplied subroutine that computes the _f_<br>in the ODE|
|ICNTRL|an optional integer-valued array containing input parameters|
|RCNTRL|an optional real-valued array containing input parameters|
|ISTATUS|an optional integer-valued array containing output statistics|
|RSTATUS|an optional real-valued array containing output statistics|
|IERR|job status upon return|



The value of variable NNZERO is only needed in the case that a sparse linear solver is used. ICNTRL and RCNTRL provide a wide range of options for users to tune the behavior of the integrator. The first four elements in ICNTRL and the first seven elements in RCNTRL are general options which apply to all families. ICNTRL(1) indicates whether the system is autonomous. ICNTRL(2) indicates whether ATOL and RTOL are vectors or scalars. ICNTRL(3) allows the user to select a particular method within each family. ICNTRL(4) specifies maximum number of integration steps before unsuccessful return. RCNTRL(1-7) control the behavior of the integration step size adjustment process. 

Some switches are specific to certain families of methods. Simplified Newton iterations are used in fully implicit and singly diagonally implicit Runge-Kutta methods. 

15 

For these two families, users can specify the maximum number of Newton iterations, stopping criterion, bounds on step decrease, increase, and on step rejection. Default values are assigned to these parameters after careful experimenting and using [16]. Additional options regarding step size control and error estimation are provided for the fully implicit Runge-Kutta family. In this family two step-size strategies are implemented: the classical approach and the modified predictive controller [14]. There are also two strategies implemented for error estimation: the classical error estimation [16] using the embedded third order method based on an additional explicit stage, and an error estimator based on an additional SDIRK stage which re-uses the real LU decomposition from the main method. 

**4.2. Tangent linear methods and forward sensitivity calculations.** The call to the tangent linear model integrator is as follows: 

# CALL INTEGRAT ~~E T~~ LM( 

NVAR,NTLM,NNZERO,Y,Y ~~T~~ LM, TIN,TOUT,ATO ~~L T~~ LM,RTO ~~L T~~ LM, ATOL,RTOL,FUN,ICNTRL,RCNTRL,ISTATUS,RSTATUS,IERR) 

There are four more arguments compared to forward integrator: NTLM specifies the number of sensitivity coefficients to be computed, Y ~~T~~ LM contains sensitivities of Y with respect to the specified coefficients, and ATOL ~~T~~ LM and RTOL ~~T~~ LM are used to calculate error estimates for sensitivity coefficients if the switch ICNTRL(9) is set to 1. All the options of the forward code also apply to TLM code. Several TLM-specific options are as follows: 

- use forward error estimation only, or control the truncation errors for both the forward and the sensitivity solutions; and 

- control the convergence of TLM simplified Newton iterations (3.15), (3.16), for fully implicit Runge-Kutta and SDIRK families. 

The TLM integrators generate sensitivity results along with the numerical solution of forward ODE system. When sensitivities of _y_ ( _t_ ) with respect to fixed model parameters are desired the augmenting technique described in Section 3.4 can be applied. Note that the argument list for the Rosenbrock method includes the additional function HESS ~~V~~ EC for calculating the Hessian times vector term in (3.17b). 

**4.3. Adjoint methods and discrete adjoint sensitivity calculations.** The call to the adjoint model integrator is as follows: 

# CALL INTEGRATE ~~A~~ DJ( 

NVAR,NP,NADJ,NNZERO,Y, Lambda ,Mu, TIN,TOUT, ATOL adj , RTOL adj ,ATOL,RTOL,FUN,JAC, ADJINIT ,HESSTR ~~V~~ EC,JACP, DRDY,DRDP,HESSTR ~~V~~ EC ~~F P~~ Y,HESSTR ~~V~~ EC ~~R P~~ Y,HESSTR ~~V~~ EC ~~R~~ , ICNTRL ~~U~~ ,RCNTRL ~~U~~ ,ISTATUS ~~U~~ ,RSTATUS ~~U~~ ,Q,QFUN) 

The integer arguments NADJ and NP specify the number of cost functionals and the number of system parameters for which adjoints are evaluated simultaneously. Lambda (of dimension NVAR _×_ NADJ) and Mu (optional variable of dimension NP _×_ NADJ) contain the sensitivities of the cost functional(s) with respect to the initial conditions and system parameters respectively. ADJINIT is a routine provided by users to initialize the adjoint variables; it is called after the forward run ends, and before the backward run starts. The optional variable Q represents the quadrature term in the cost functional and the optional routine QFUN computes the integrand for the quadrature term. JACP, DRDY, DRDP are optional routines to calculate the derivatives **_fp_** , **_ry_** , and **_rp_** discussed in Section 3.4. 

16 

Several additional optional arguments (with names beginning with HESS), perform Hessian related operations and are only available in the interface for the Rosenbrock methods. The behavior of the program is controlled by the user through these optional arguments. 

- Mu and JACP are required when the sensitivities with respect to system parameters are desired. 

- Q and QFUN are required when the cost functional(s) contain(s) a quadrature term. Upon completion Q stores the value of the quadrature term at the final step. 

- DRDY (DRDP) are required when the cost functional(s) contain(s) a quadrature term and the sensitivities with respect to initial conditions (or system parameters, respectively) are desired. 

The integrator performs a forward run from _t_ 0 (specified by TIN) to _tF_ (specified by TOUT) followed by a backward, adjoint run from _tF_ to _t_ 0. ATOL and RTOL define the tolerances for the forward run while ATOL ~~A~~ DJ and RTOL ~~A~~ DJ for the backward run. Note that ATOL ~~A~~ DJ and RTOL ~~A~~ DJ control only the convergence of the iterations, not the time steps since the backward run follows exactly the same sequence of time steps as the forward run in reverse order. 

If the simplified Newton iterations for solving the adjoint stage variables do not converge, the code switches automatically to a direct solution method (3.23) – at the expense of additional LU decompositions. The other options for adjoint methods are the same as with the forward code. 

**5. Numerical experiments.** In this section we illustrate the capabilities of fatode and evaluate the performance of each family of methods. We compare fatode with the well established code cvode and cvodes within sundials [18] for both the ODE solution, and direct and adjoint sensitivity analysis. In addition, we assess the efficiency of sparse linear solvers incorporated in fatode by comparing their performance with lapack full linear solvers. All the experiments are performed on a 8-core (1.86Ghz) Intel Xeon workstation running Fedora 14 (x86 ~~6~~ 4) Linux. PGI fortran Version 7.2-5 is used for compilation, with level O3 optimization. Unless stated otherwise, the default settings for parameters are used in all fatode calls. 

We consider the two-dimensional Saint-Venant system of shallow water equations 



on the spatial domain Ω= [ _−_ 3 _,_ 3]<sup>2</sup> , where _u_ ( _t, x, y_ ), _v_ ( _t, x, y_ ) are the components of the velocity field, _h_ ( _t, x, y_ ) is the fluid layer thickness, and g denotes the standard value of the gravitational acceleration. 

The shallow water equations (5.2) are converted to a semi-discrete form using third order upwind finite differences. The spatial domain is covered by a grid of size 40 _×_ 40, resulting in an ODE system of dimension 40 _×_ 40 _×_ 3 = 4800 which is solved by fatode. 

**5.1. ODE solution.** Cvode [18] is a general-purpose ODE solver which uses the Adams-Moulton method for non-stiff ODE systems and the BDF method for 

17 



<!-- Start of picture text -->
10−1 10−1<br>RK RK<br>10−2 SDIRK 10−2 SDIRK<br>ROS ROS<br>10−3 CVODE 10−3 CVODE<br>10−4 10−4<br>10−5 10−5<br>10−6 10−6<br>10−7 10−7<br>10−8 10−8<br>15 22 32 47 68 99 145 211 308 450 20 29 43 64 94 138 204 300 441 650<br>Number of steps CPU time (in seconds)<br>(a) Relative error vs number of steps (b) Relative error vs CPU time<br>Relative error Relative error<br><!-- End of picture text -->

Fig. 5.1. _Work-precision diagrams for the forward integration of the shallow water equations (5.2) over the time interval_ [ _t_ 0 _, tF_ ] _≈_ [0 _,_ 0 _._ 11] _using stiff integrators. Comparison is made between FIRK, SDIRK, and Rosenbrock methods in_ fatode _with the BDF method in_ cvode _. Different points on the plots correspond to different absolute and relative tolerances levels in the range_ 10<sup>_−_2</sup> _, . . . ,_ 10<sup>_−_7</sup> _._ 

stiff ODE systems. Both methods are implemented in a variable-order variable-step form. In our test, we choose the option of the BDF method for the comparison with implicit methods in fatode and the option of the Adams-Moulton method for the comparison with explicit Runge-Kutta methods in fatode. From each family of implicit integrators in fatode we select a representative fourth-order method for the tests: Lobatto3C (fully implicit Runge-Kutta), Rodas4 (Rosenbrock), and Sdirk-4a (singly diagonally implicit Runge-Kutta). The Gustafsson predictive error controller is used for all integrators. An additional SDIRK stage was used in the error estimator in the fully implicit Runge-Kutta integrator. For the explicit Runge-Kutta family we select the fifth-order seven-stage method DOPRI5. 

Since solution of linear systems dominates the computational cost of implicit integration, especially for large-scale ODE systems, it is necessary to use the same linear solvers for both cvode and fatode for a fair performance comparison. In our comparison experiments we use the direct linear solver (dgetrf and dgetrs) from lapack. In all cases, the full Jacobian is supplied. 

We vary both absolute and relative error tolerances from 10<sup>_−_2</sup> to 10<sup>_−_7</sup> to obtain solutions of different levels of accuracy (the absolute and relative error tolerances are equal to each other). A reference solution is obtained by using lsode [20], a well known but relatively slow ODE solver, with a very tight relative and absolute tolerances of 10<sup>_−_9</sup> . The relative error is defined in the L<sup>2</sup> norm: 



where _ytF_ is the numerical solution at the final step and _y_ ref is the reference solution at _tF_ . The work-precision diagrams for the stiff solvers are shown in Figure 5.1. The results indicate that singly diagonally implicit and fully implicit Runge-Kutta methods implemented in fatode outperform the BDF method implemented in cvode, requiring considerably less time steps to reach a desired accuracy. The Rosenbrock method is also more efficient than cvode for accuracy levels below 10<sup>_−_6</sup> . The workprecision diagrams for the non-stiff solvers are shown in Figure 5.2. For the same level of accuracy, the explicit Runge-Kutta method in fatode takes fewer steps than the 

18 



<!-- Start of picture text -->
10−2 10−2<br>ERK ERK<br>CVODE CVODE<br>10−3 10−3<br>10−4 10−4<br>10−5 10−5<br>10−6 10−6<br>10−7 10−7<br>20 25 31 39 49 61 77 96 120 150 80 100 125 157 196 245 307 383 480 600<br>Number of steps Number of right−hand side evaluations<br>Relative error Relative error<br><!-- End of picture text -->

(a) Relative error vs number of steps 



<!-- Start of picture text -->
(b) relative error vs number of right-hand side<br>evaluations<br><!-- End of picture text -->



<!-- Start of picture text -->
10−2<br>ERK<br>CVODE<br>10−3<br>10−4<br>10−5<br>10−6<br>10−7<br>25 48 94 181 350<br>CPU time (in milliseconds)<br>Relative error<br><!-- End of picture text -->



<!-- Start of picture text -->
(c) Relative error vs CPU time<br><!-- End of picture text -->

Fig. 5.2. _Computational statistics for the forward integration of the shallow water equations (5.2) over the time interval_ [ _t_ 0 _, tF_ ] _≈_ [0 _,_ 0 _._ 11] _using nonstiff integrators. Comparison is made between the explicit RK method in_ fatode _with the Adams-Moulton method in_ cvode _. Different points on the plots correspond to different absolute and relative tolerances levels in the range_ 0 _._ 3 _×_ 10<sup>_−_2</sup> _, . . . ,_ 0 _._ 3 _×_ 10<sup>_−_7</sup> _._ 

Adams-Moulton method in cvode, but the cost per step is higher. The performance is similar in terms of CPU time. 

**5.2. Direct sensitivity analysis.** We now calculate the sensitivities of all solution components at the final time with respect to the initial value of the first solution component _∂yi_ ( _tF_ ) _/∂y_ 1( _t_ 0) _, i_ = 1 _. . . n_ using tangent linear model integration. The fatode results are compared against those obtained with cvodes [26], an extension of cvode capable to perform sensitivity analysis. The lapack linear solvers are used in both cvodes and fatode. 

Tangent linear model results with stiff integrators are shown in Figure 5.3 and 5.4 ). The three implicit methods in fatode and cvodes require nearly the same number of LU decompositions for relative errors below 10<sup>_−_4</sup> . The performance of the SDIRK and Rosenbrock methods is comparable to that of the BDF method in cvodes. The fully implicit Runge-Kutta method is nearly three times more costly because it requires either solving a large real-valued system or solving a complex-valued system. It is also observed that fatode saves a considerable number of steps and right-hand side evaluations. Tangent linear model results with non-stiff integrators are shown in Figure 5.4. A finite difference approximation to the product of Jacobian matrix and 

19 



<!-- Start of picture text -->
10−1 10−1<br>RK_TLM RK_TLM<br>SDIRK_TLM SDIRK_TLM<br>ROS_TLM ROS_TLM<br>10−2 CVODES_TLM 10−2 CVODES_TLM<br>10−3 10−3<br>10−4 10−4<br>10−5 10−5<br>5 7 9 11 15 20 26 35 46 60 4 5 7 9 11 14 19 24 31 40<br>Number of steps Number of LU decompositions<br>(a) Relative error vs number of steps (b) Relative error vs number of LU decomposi-<br>tions<br>10−1 10−1<br>RK_TLM<br>SDIRK_TLM<br>ROS_TLM<br>10−2 CVODES_TLM 10−2<br>10−3 10−3<br>10−4 10−4 RK_TLM<br>SDIRK_TLM<br>ROS_TLM<br>10−5 10−5 CVODES_TLM<br>30 39 50 65 83 108 139 180 232 300 100 135 183 247 333 450 608 822 1110 1500<br>Number of right−hand side evaluations CPU time (in seconds)<br>Relative error Relative error<br>Relative error Relative error<br><!-- End of picture text -->

(c) Relative error vs number of right-hand side evaluations 



<!-- Start of picture text -->
(d) Relative error vs CPU time<br><!-- End of picture text -->

Fig. 5.3. _Computational statistics for the tangent linear model integration of the shallow water equations (5.2) over the time interval_ [ _t_ 0 _, tF_ ] _≈_ [0 _,_ 0 _._ 011] _using stiff integrators. Comparison is made between implicit methods in_ fatode _with the BDF method in_ cvodes _. Different points on the plots correspond to different absolute and relative tolerances levels in the range_ 10<sup>_−_2</sup> _, . . . ,_ 10<sup>_−_6</sup> _. The tangent linear model computes the sensitivity ∂yi_ ( _tF_ ) _/∂y_ 1( _t_ 0) _, i_ = 1 _. . . d._ 

sensitivity vector is used with both the explicit Runge-Kutta method in fatode and the Adams-Moulton method in cvodes for a fair comparison. The performance of the two codes is similar in terms of both CPU time and number of right-hand side evaluations. 

**5.3. Adjoint sensitivity analysis.** We calculate the sensitivities of the first solution component at the final time with respect to all initial values _∂y_ 1( _tF_ ) _/∂yi_ ( _t_ 0), _i_ = 1 _. . . d_ using adjoint model integration. Work-precision diagrams for the implicit solvers are shown in Figure 5.5. All implicit methods in fatode outperforms the BDF method in cvodes in terms of work-precision ratio, with the highest efficiency being achieved by the Rosenbrock method. Work-precision diagrams for the explicit solvers are shown in Figure 5.6. The explicit Runge-Kutta method in fatode runs slightly slower than the Adams-Moulton method in cvodes, though the former takes fewer steps. This is due to the fact that the explicit Runge-Kutta method in fatode requires more Jacobian evaluations and Jacobian-vector products during the adjoint backward run. 

20 



<!-- Start of picture text -->
10−1 10−1<br>ERK_TLM ERK_TLM<br>CVODES_TLM CVODES_TLM<br>10−2 10−2<br>10−3 10−3<br>10−4 10−4<br>10−5 10−5<br>10−6 10−6<br>5 6 8 11 14 18 23 30 39 50 50 61 74 91 111 135 165 201 246 300<br>Number of steps Number of right−hand side evaluations<br>Relative error Relative error<br><!-- End of picture text -->

(a) Relative error vs number of steps 



<!-- Start of picture text -->
(b) relative error vs number of right-hand side<br>evaluations<br><!-- End of picture text -->



<!-- Start of picture text -->
10−1<br>ERK_TLM<br>CVODES_TLM<br>10−2<br>10−3<br>10−4<br>10−5<br>10−6<br>25 29 34 40 46 54 63 73 86 100<br>CPU time (in milliseconds)<br>Relative error<br><!-- End of picture text -->



<!-- Start of picture text -->
(c) Relative error vs CPU time<br><!-- End of picture text -->

Fig. 5.4. _Computational statistics for the tangent linear model integration of the shallow water equations (5.2) over the time interval_ [ _t_ 0 _, tF_ ] _≈_ [0 _,_ 0 _._ 011] _using nonstiff integrators. Comparison is made between the explicit RK method in_ fatode _with the Adams-Moulton method in_ cvodes _. Different points on the plots correspond to different absolute and relative tolerances levels in the range_ 10<sup>_−_2</sup> _, . . . ,_ 10<sup>_−_6</sup> _. The tangent linear model computes the sensitivity ∂yi_ ( _tF_ ) _/∂y_ 1( _t_ 0) _, i_ = 1 _. . . d. In_ fatode _, we choose the option to use only the forward error for step size control._ 

**5.4. Efficiency of sparse linear solvers.** In our test, the Jacobian matrix is of dimension 4800, but only 100,800 elements are non-zeros; about 99 _._ 5625% of the entries of this sparse matrix are zeros. The incorporation of sparse linear solvers leads to significant computational savings and allows for very efficient forward, tangent linear, and adjoint model integration. Table 5.1 shows the compute times for all integrators in fatode using different linear solvers. The tolerances are set as _ATOL_ = _RTOL_ = 10<sup>_−_6</sup> and time interval is from _t_ 0 = 0 to _tF_ = 0 _._ 011. As expected, fatode benefits significantly from sparse linear solvers. Umfpack is typically a little faster than superlu, both of them give essentially the same results as the full algebra linear solver does. 

**6. Conclusions.** This paper presents the fatode library for the integration of stiff ODE systems, and for performing direct and discrete adjoint sensitivity analysis. fatode generalizes the KPP numerical library, and implements fully implicit RungeKutta, singly diagonally implicit Runge-Kutta, and Rosenbrock methods. While KPP is specifically designed to solve chemical kinetic systems, fatode offers a general purpose implementation that makes it potentially useful for a wide range of applications. 

21 



<!-- Start of picture text -->
10−1 10−1<br>10−2 10−2<br>10−3 10−3<br>10−4 10−4<br>10−5 10−5<br>RK_ADJ RK_ADJ<br>10−6 SDIRK_ADJ 10−6 SDIRK_ADJ<br>ROS_ADJ ROS_ADJ<br>10−7 CVODES_ADJ 10−7 CVODES_ADJ<br>8 11 14 19 25 33 43 57 76 100 7 10 13 19 26 35 49 68 94 130<br>Number of steps Number of LU decompositions<br>(a) Relative error vs number of steps (b) Relative error vs number of LU decomposi-<br>tions<br>10−1 10−1<br>RK_ADJ<br>10−2 SDIRK_ADJROS_ADJ 10−2<br>CVODES_ADJ<br>10−3 10−3<br>10−4 10−4<br>10−5 10−5<br>RK_ADJ<br>10−6 10−6 SDIRK_ADJ<br>ROS_ADJ<br>10−7 10−7 CVODES_ADJ<br>12 17 24 33 46 65 91 127 178 250 200 292 426 621 907 1323 1931 2818 4112 6000<br>Number of right−hand side evaluations CPU time (in seconds)<br>(c) Relative error vs number of right-hand side (d) Relative error vs CPU time<br>Relative error Relative error<br>Relative error Relative error<br><!-- End of picture text -->



<!-- Start of picture text -->
(c) Relative error vs number of right-hand side<br>evaluations<br><!-- End of picture text -->

Fig. 5.5. _Computational statistics for the adjoint integration of the shallow water equations (5.2) over the time interval_ [ _t_ 0 _, tF_ ] _≈_ [0 _,_ 0 _._ 011] _using stiff integrators. Comparison is made between implicit methods in_ fatode _with the BDF method in_ cvodes _. Different points on the plots correspond to different absolute and relative tolerances levels in the range_ 10<sup>_−_2</sup> _, . . . ,_ 10<sup>_−_6</sup> _. The adjoint model computes the sensitivity ∂y_ 1( _tF_ ) _/∂yi_ ( _t_ 0) _, i_ = 1 _. . . d._ 

Its capabilities of direct and adjoint sensitivity analysis will enable users to tackle important problems such as uncertainty quantification, parameter estimation, and data assimilation within these application domains. In addition, fatode contains stand-alone generic linear system solvers to deal with different types of systems. The decoupling between main integrators and linear solvers makes it feasible and convenient for users to provide their own implementations of linear solvers. 

**Code availability.** The code is available from the web page http://people.cs. vt.edu/~asandu/Software/FATODE/index.html. The code has been tested under the following compilers: Portland group’s pgf90, Lahey’s lf95, Sun’s sunf90, gfortran, g95, Absoft. 

## REFERENCES 

> [1] A. Sandu and D. Daescu and G.R. Carmichael, _Direct and adjoint sensitivity analysis of chemical kinetic systems with KPP: II – Numerical validation and applications_ , Atmospheric Environment, 37 (2003), pp. 5097–5114. 

22 



<!-- Start of picture text -->
10−1 10−1<br>ERK_ADJ ERK_ADJ<br>CVODES_ADJ CVODES_ADJ<br>10−2 10−2<br>10−3 10−3<br>10−4 10−4<br>10−5 10−5<br>10−6 10−6<br>10 13 16 21 27 34 43 55 71 90 35 41 48 57 67 79 92 109 128 150<br>Number of steps Number of right−hand side evaluations<br>Relative error Relative error<br><!-- End of picture text -->

(a) Relative error vs number of steps 



<!-- Start of picture text -->
(b) relative error vs number of right-hand side<br>evaluations<br><!-- End of picture text -->



<!-- Start of picture text -->
10−1<br>ERK_ADJ<br>CVODES_ADJ<br>10−2<br>10−3<br>10−4<br>10−5<br>10−6<br>15 19 24 30 38 48 60 76 95 120<br>CPU time (in milliseconds)<br>Relative error<br><!-- End of picture text -->



<!-- Start of picture text -->
(c) Relative error vs CPU time<br><!-- End of picture text -->

Fig. 5.6. _Computational statistics for the adjoint integration of the shallow water equations (5.2) over the time interval_ [ _t_ 0 _, tF_ ] _≈_ [0 _,_ 0 _._ 011] _using nonstiff integrators. Comparison is made between the explicit RK method in_ fatode _with the Adams-Moulton method in_ cvodes _. Different points on the plots correspond to different absolute and relative tolerances levels in the range_ 10<sup>_−_2</sup> _, . . . ,_ 10<sup>_−_6</sup> _. The adjoint model computes the sensitivity ∂y_ 1( _tF_ ) _/∂yi_ ( _t_ 0) _, i_ = 1 _. . . d._ 

- [2] M. Alexe and A. Sandu, _Forward and adjoint sensitivity analysis with continuous explicit Runge-Kutta schemes_ , Applied Mathematics and Computation, 208 (2009), pp. 328–334. 

- [3] E. Anderson, Z. Bai, C. Bischof, L. S. Blackford, J. Demmel, J. Dongarra, J. Du Croz, S. Hammarling, A. Greenbaum, A. McKenney, and D. Sorensen, _LAPACK Users’ guide (third ed.)_ , Society for Industrial and Applied Mathematics, Philadelphia, PA, USA, 1999. 

- [4] H. M. Bcker, G. F. Corliss, P. D. Hovland, U. Naumann, and B. Norris, _Automatic Differentiation: Applications, Theory, and Tools_ , Lecture Notes in Computational Science and Engineering, Springer, New York, 2005. 

- [5] W. P. L. Carter, _A detailed mechanism for the gas-phase atmospheric reactions of organic compounds_ , Atmospheric Environment, 24 (1990), p. 481518. 

- [6] D. Daescu, G. R. Carmichael, and A. Sandu, _Adjoint implementation of Rosenbrock methods applied to variational data assimilation problems_ , Journal of Computational Physics, 165 (2000), pp. 496–510. 

- [7] Timothy A. Davis, _Algorithm 832: UMFPACK V4.3—an unsymmetric-pattern multifrontal method_ , ACM Transactions on Mathematical Software, 30 (2004), pp. 196–199. 

- [8] J. W. Demmel, S. C. Eisenstat, J. R. Gilbert, X. S. Li, and J. W. H. Liu, _A supernodal approach to sparse partial pivoting_ , SIAM Journal on Matrix Analysis and Applications, 20 (1999), pp. 720–755. 

- [9] A. M. Dunker, _The decoupled direct method for calculating sensitivity coefficients in chemical kinetics_ , 81 (1984), pp. 2385–2393. 

- [10] P. Eller, K. Singh, A. Sandu, K. Bowman, D. K. Henze, and M. Lee, _Implementation_ 

23 

Table 5.1 

_Overall compute time (in seconds) using different linear solvers_ 

||Full algebra|Spar|se algebra|
|---|---|---|---|
|Solver|lapack|umfpack|superlu|
|ROS|286_._4|18_._7|26_._8|
|ROS<br>~~T~~LM|1093_._2|300_._4|321_._5|
|ROS<br>~~A~~DJ|1832_._6|363_._5|399_._9|
|RK|857_._7|25_._6|44_._9|
|RK<br>~~T~~LM|1390_._0|92_._4|126_._9|
|RK<br>~~A~~DJ|2467_._9|149_._9|206_._6|
|SDIRK|175_._3|9_._9|15_._4|
|SDIRK<br>~~T~~LM|499_._9|122_._0|135_._8|
|SDIRK<br>~~A~~DJ|2631_._5|174_._2|238_._0|



_and evaluation of an array of chemical solvers in the Global Chemical Transport Model GEOS-Chem_ , Geoscientific Model Development, 2 (2009), p. 8996. 

- [11] M. W. Gery, G. Z. Whitten, J. P. Killus, and M. C. Dodge, _A photochemical kinetics mechanism for urban and regional scale computer modeling_ , Journal of Geophysical Research, 94 (1989), p. 1292512956. 

- [12] R. Giering, _Tangent linear and adjoint model compiler, users manual 1.4_ , (1999). 

- [13] R. Giering and T. Kaminski, _Recipes for adjoint code construction_ , ACM Transactions on Mathematical Software, 24 (1998), pp. 437–474. 

- [14] K. Gustafsson, _Control-theoretic techniques for stepsize selection in implicit Runge-Kutta methods_ , ACM Transactions on Mathematical Software, 20 (1994), pp. 496–517. 

- [15] W. Hager, _Runge Kutta methods in optimal control and the transformed adjoint system_ , Numerische Mathematik, 87 (2000), pp. 247–282. 

- [16] E. Hairer, S.P. Norsett, and G. Wanner, _Solving Ordinary Differential Equations I. Nonstiff Problems_ , Springer-Verlag, Berlin, 1993. 

- [17] E. Hairer and G. Wanner, _Solving Ordinary Differential Equations II. Stiff and DifferentialAlgebraic Problems_ , Springer Series in Computational Mathematics, Berlin, 1991. 

- [18] A. C. Hindmarsh, P. N. Brown, K. E. Grant, S. L. Lee, R. Serban, D. E. Shumaker, and C. S. Woodward, _SUNDIALS: Suite of Nonlinear and Differential/Algebraic Equation Solvers_ , ACM Transactions on Mathematical Software, 31 (2005), pp. 363–396. 

- [19] J.R. Leis and M.A. Kramer, _ODESSA - an ordinary differential equation solver with explicit simultaneous sensitivity analysis_ , ACM Transactions on Mathematical Software, 14 (1986), pp. 61–75. 

- [20] K. Radhakrishnan and A. C. Hindmarsh, _Description and use of lsode, the livermore solver for ordinary differential equations_ , Tech. Report UCRL-ID-113855, Lawrence Livermore National Laboratory, 1993. 

- [21] A. Sandu, _On the properties of Runge Kutta discrete adjoints_ , in ICCS 2006, IV,LNCS 3994, Berlin Heidelberg, 2006, Springer-Verlag, pp. 550–557. 

- [22] ~~,~~ _Solution of inverse ODE problems using discrete adjoints_ , Large Scale Inverse Problems and Quantification of Uncertainty, (2010), pp. 345–364. 

- [23] A. Sandu, D. Daescu, and G.R. Carmichael, _Direct and Adjoint Sensitivity Analysis of Chemical Kinetic Systems with KPP: I – Theory and Software Tools_ , Atmospheric Environment, 37 (2003), pp. 5083–5096. 

- [24] A. Sandu and P. Miehe, _Forward, Tangent Linear,and Adjoint Runge Kutta Methods in KPP–2.2 for Efficient Chemical Kinetic Simulations_ , International Journal of Computer Mathematics, (2008). 

- [25] A. Sandu, J.G. Verwer, J.G. Blom, E.J. Spee, G.R. Carmichael, and F.A. Potra, _Benchmarking stiff ODE solvers for atmospheric chemistry problems II: Rosenbrock methods_ , Atmospheric Environment, 31 (1997), pp. 3459–3472. 

- [26] R. Serban and A.C. Hindmarsh, _CVODES, the sensitivity-enabled ODE solver in SUNDIALS_ , Tech. Report UCRL-PROC-210300, Lawrence Livermore National Laboratory, 2003. 

- [27] Z. Sirkes and E. Tziperman, _Finite difference of adjoint or adjoint of finite difference_ , Monthly Weather Review, 125 (1997), pp. 3373–3378. 

- [28] J. Verwer, E.J. Spee, J. G. Blom, and W. Hunsdorfer, _A second order Rosenbrock method_ 

24 

_applied to photochemical dispersion problems_ , SIAM Journal on Scientific Computing, 20 (1999), pp. 1456–1480. 

# **Appendix A. Derivatives.** 

Consider the following derivatives of _f_ ( _y_ ) 



For _u, v ∈_ R<sup>_d_</sup> we have that 



The derivatives of Jacobian-vector products are 



For the Hessian (extended) transpose times vector term we have that 



# **Appendix B. Automatic differentiation.** 

In the following we illustrate the use of the well-known automatic differentiation tool TAMC for code generation. Detailed information on TAMC is given in the users manual [12]. 

Consider a given subroutine with the following parameter list: 

subroutine fun(n, t, y, f) 

- ! dimension of state vector y 

integer :: n double precision :: t 

- ! y is the numerical solution at time t and p is the 

- ! right hand side function at time t double precision :: y(n), f(n) 

The forward mode of TAMC can generate derivative code to compute the sensitivity of the dependent variable _f_ with respect to the independent variable _y_ by: 

25 

./stamc -reply <your_email> -toplevel fun -input y 

-output f -forward -pure -Jacobian <m> <source file name> The generated code has the following parameter list: subroutine g_fun(n, t, y, g_y, g_f) ! dimension of state vector y integer :: n double precision :: t ! y is the numerical solution at time t and p is the ! right hand side function at time t double precision :: y(n), p(n) double precision :: g_y(n,m), g_f(n,m) If you specify the number after option ’-Jacobian’ with the number of dependent variables and initialize the input variable _g_ _~~f~~_ with identity matrix, full Jacobian will be obtained and stored in _g_ _~~y~~_ . Otherwise, the number after option ’-Jacobian’ defines the number of columns of a seed matrix _S_ , denoted by _m_ . 

_∂f_ (B.1) _∂y_<sup>_· S_[</sup><sup>_n×m_]</sup> 

The backward mode of TAMC can generate derivative code to compute the sensitivity of the dependent variable with respect to the many independent variables by: 

./stamc -reply <your_email> -toplevel fun -input y -output f -reverse -pure -Jacobian <m> <source file name> The generated code has the following parameter list: 

subroutine adfun(n, t, y, ady, adf) ! dimension of state vector y integer :: n double precision :: t ! y is the numerical solution at time t and p is the ! right hand side function at time t double precision :: y(n), p(n) double precision :: ady(m,n), adf(m,n) 

If you specify the number after option ’-Jacobian’ with the number of dependent variables and initialize the input variable _adf_ with identity matrix, full Jacobian will be obtained and stored in _ady_ . Otherwise, the number after option ’-Jacobian’ defines the number of rows of a seed matrix _S_ , denoted by _m_ . 



Note that if you use the option ’-Jacobian 1’, product of Jacobian times a vector<sup>_∂_</sup> _∂y_<sup>_<u>f</u>·v_</sup> is provided by the forward mode while product of Jacobian transpose times a vector ( _∂∂yf_ ) _T · v_ is provided by the backward mode. To obtain the code calculating the Hessian times vector term ( _u · H_ ) _· v_ , we run TAMC in forward over reverse mode 

./stamc -reply <your_email> -toplevel fun -input y -output f -reverse -pure -Jacobian 1 <source file name> ./stamc -reply <your_email> -toplevel fun -input y 

-output g_y -forward -pure -Jacobian 1 <source file name> 

26 

The generated code has the following parameter list: subroutine g_adfun(n, t, y, adf, g_y, g_ady) ! dimension of state vector y integer :: n double precision :: t ! y is the numerical solution at time t and p is the ! right hand side function at time t double precision :: y(n), p(n) double precision :: g_y(1,n), adf(1,n),g_ady(1,n) where the variable _adf_ corresponds to the vector _v_ and _gy_ correspond to the vector _u_ . Similarly the Hessian transpose times vector term ( _u · H_<sup>_T_</sup> ) _· v_ can be obtained by two consecutive forward runs: ./stamc -reply <your_email> -toplevel fun -input y -output f -forward -pure -Jacobian 1 <source file name> ./stamc -reply <your_email> -toplevel fun -input y -output g_y -forward -pure -Jacobian 1 <source file name> The generated code has the following parameter list: subroutine g_g_fun(n, t, y, g_y, g_f, g_g_y) ! dimension of state vector y integer :: n double precision :: t ! y is the numerical solution at time t and p is the ! right hand side function at time t double precision :: y(n), p(n) double precision :: g_y(1,n), g_f(1,n),g_g_y(1,n) where the variable _g_ _~~f~~_ corresponds to the vector _v_ and _g_ _~~y~~_ correspond to the vector _u_ . 

**Appendix C. Discrete sensitivities with respect to parameters.** A numerical solution of (3.28) provides the discrete forward model equations: 



Replacing _pn_ = _p_ for all _n_ leads to (C.2) 



and calculate the adjoint variables in time according to the discrete adjoint model equations 





Replacing in (C.4) leads to equations (C.5) 

**Appendix D. Discrete sensitivities with respect to parameters: RungeKutta methods.** 

Using the extended co-state vector and the extended Jacobian (D.1) into the discrete Runge-Kutta adjoint (3.22) leads to 



From the last equation of (D.2b) we see that _wi_ = 0, _∀ i_ , and therefore _θn_ = _θn_ +1 = _· · ·_ = _θN_ = 1. The discrete adjoint Runge-Kutta method (D.2) can be rewritten as (3.31). 

# **Appendix E. Discrete sensitivities with respect to parameters: Rosenbrock methods.** 

Extending the discrete Rosenbrock adjoint (3.26) in the same way as we did for Runge Kutta methods yields 



Using the derivative notation in Appendix A, this equation can be written component by component as follows: 





This can be further simplified. Note that _θn_ = 1 for all _n_ and that the numbers _u_ � _i_ can be computed by the simple recurrence 



The vector combined by _ki_ , _ki_ , and<sup>�</sup> _ki_ is obtained from the solution of the extended form of forward integration (3.10), where the second equation 



indicates _ki_ = 0 for all time steps since _p_ = 0 as assumption. And the quantity _<u>u</u>_ is not needed to update the adjoint variables _λ_ and _µ_ so that the third equation can be omitted. 

Thus we obtain: 



30
