<!-- fulltext source=arxiv_html slug=arXiv-2108.07790 fetched=2026-09-21T06:07:43+00:00 -->

# Mitigating harm in language models with conditional-likelihood filtration

Helen Ngo
††thanks: Correspondence to: Helen Ngo <helen@cohere.ai>, Nicholas Frosst <nick@cohere.ai>††thanks: Cohere, Toronto, Canada.
  
Cooper Raterink22footnotemark: 
2
  
João G.M. Araújo22footnotemark: 
2
  
Ivan Zhang22footnotemark: 
2
  
Carol Chen22footnotemark: 
2
  
Adrien Morisot22footnotemark: 
2
  
Nicholas Frosst11footnotemark: 
1
22footnotemark: 
2

###### Abstract

Language models trained on large-scale unfiltered datasets curated from the open web acquire systemic biases, prejudices, and harmful views from their training data. We present a methodology for programmatically identifying and removing harmful text from web-scale datasets.
A pretrained language model is used to assess the log-likelihood of researcher-written trigger phrases conditioned on a specific document, which is used to identify and filter documents from the dataset. We demonstrate that models trained on this filtered dataset exhibit lower propensity to generate harmful text, with a marginal decrease in performance on standard language modeling benchmarks compared to unfiltered baselines. We provide a partial explanation for this performance gap by surfacing examples of hate speech and other undesirable content from standard language modeling benchmarks. Finally, we discuss the generalization of this method and how trigger phrases reflecting specific values can be used by researchers to build language models which are more closely aligned with their values.

## 1 Introduction

Neural language models pretrained on datasets scraped from the open web have become foundational in natural language systems, and continued scaling across datasets and architectures have resulted in many advancements in natural language processing [[Brown et al., 2020](#bib.bib2)].
However, these models reflect and amplify the systemic biases and prejudice present in their training corpuses. Datasets scraped from the open web may include harmful views (e.g. racism, sexism, ableism, jingoism), hate speech, abusive language, and other forms of toxicity
[[Bender et al., 2021](#bib.bib1)]. The size of these datasets make human evaluation and filtration impractical, as they would be infeasible to read in their entirety. [[Gehman et al., 2020](#bib.bib5)] compare language models trained on a variety of internet corpuses and observe that models trained solely on Wikipedia exhibit lower expected maximum toxicity. As Wikipedia is assumed to be less toxic than other internet data sources, this suggests that models acquire toxicity from their pretraining data. Datasets sourced from the web are also used to create widely-used benchmarks for evaluating language models [[Merity et al., 2016](#bib.bib6), [Chelba et al., 2013](#bib.bib3)], highlighting the need for methods which effectively identify undesirable content for removal. This paper contributes the following:

* •

  a method to programmatically identify and remove large volumes of undesirable text from a dataset by using the learned knowledge of a language model
* •

  human-labelled experiments verifying that this method consistently identifies non-value-aligned (e.g. toxic) text
* •

  experiments demonstrating that models trained on the filtered dataset exhibit lower maximum toxicity according to the metric in [[Gehman et al., 2020](#bib.bib5)]
* •

  analysis surfacing undesirable examples in existing language modeling benchmarks, highlighting the need for researchers to identify and remove harmful data before releasing evaluation benchmarks built on internet text corpuses

## 2 Related Work

Word-level blocklists are commonly employed to address toxicity in language modeling (i.e. a document is removed from the corpus if it contains a word on the blocklist) [[Raffel et al., 2020](#bib.bib9)]. This removes webpages with simple hateful text (e.g. racial slurs), but misses harmful webpages which do not use blocklisted words. It also erroneously flags non-harmful webpages which use blocklisted words in academic, rhetorical, or expository contexts, and has been shown to disproportionately filter out text associated with minority identities [[Dodge et al., 2021](#bib.bib4)].

Vocabulary shifting [[Gehman et al., 2020](#bib.bib5)] is a technique which learns a representation of toxicity vs. non-toxicity for every token in the vocabulary, which is used to boost the likelihood of
non-toxic tokens. This has similar issues to word-level blocklists, where individual tokens are assigned positive or negative connotations regardless of the context in which they are used.

Self-debiasing [[Schick et al., 2021](#bib.bib11)] mitigates corpus-based bias in language models during generation by using the learned knowledge of a language model to identify biases in text with a zero-shot prompt-based approach. Similarly, we use the learned knowledge of a pretrained language model to identify undesirable content within a text corpus, but intervene during dataset curation as opposed to the generation step.

Finetuning a language model on a small (n=80) number of handwritten question-answer pairs which reflect a predetermined set of target values has been shown to reduce model propensity to generate non-value-aligned text [[Solaiman and Dennison, 2021](#bib.bib12)]. Our work instead focuses on how a large-scale dataset can be improved by filtering out non-value-aligned documents, allowing researchers to define what should be removed as opposed to defining what should be kept.

## 3 Conditional-Likelihood Filtration

We present a method for identifying and filtering undesirable documents from the training data. Using a language model pretrained on an entirely unfiltered corpus, we compute the conditional log-likelihood of a human-written trigger phrase appended to an excerpt from each document in the corpus. We define a trigger phrase as a succinct statement of the rhetoric we aim to remove, e.g., "Social justice warriors hate the white race.", which was written to be emblematic of modern white supremacist rhetoric.
Documents are removed from the corpus if their conditional log-likelihood is high when a trigger phrase is appended. We demonstrate that models trained on the resulting dataset are less likely to generate harmful text by measuring the maximum toxicity of their samples as scored by the Perspective API.

Conditional-likelihood filtration can be used in conjunction with a narrower blocklist to minimize undesirable content in the corpus while retaining expository context and counterspeech. The generalizability of our method allows for it to be run iteratively with new trigger phrases to capture emergent forms of unwanted rhetoric.

### 3.1 Methodology

We accumulated 366 GB of text from the open web. This unfiltered dataset is composed of the Colossal Clean Crawled Corpus (C4) [[Raffel et al., 2020](#bib.bib9)] and proprietary web scrapes. This dataset was used to train a Transformer using the standard decoder-only architecture [[Radford et al., 2019](#bib.bib8)] with 1517M parameters, referred to as the baseline-1.5B model throughout the text. Details for the baseline-1.5B model can be found in table [A.1](#A1.SS1 "A.1 Pretrained filtration model ‣ Appendix A Appendix ‣ Mitigating harm in language models with conditional-likelihood filtration"). We then wrote trigger phrases, which are succinct statements representing the rhetoric we wish to remove. Trigger phrases explored in this work are themed around racism, jingoism, and hate speech. These topics were selected for study because they are well-represented within news articles, which are overrepresented in text corpuses commonly used for language modeling [[Dodge et al., 2021](#bib.bib4)].

Figure 1: Data flow through an end-to-end filtration system.

Trigger phrases are appended to an excerpt extracted from the beginning of each document in our training corpus. Due to memory constraints, concatenated sequences are truncated to a maximum length of 384 tokens. This is limited by the assumption that the heading of a webpage reflects the content that follows. We calculate the conditional log-likelihood of each of these phrases under the probability distribution of the baseline-1.5B model, conditioned on each document in our training corpus (i.e. $p(t|d)$, where $t$ is a trigger phrase and $d$ is a document excerpt). This allows us to calculate a likelihood score for each document over each trigger. The entire dataset is then sorted by ranking examples according to their conditional likelihood in descending order, and a threshold is selected for document removal which maximizes removal of undesirable content while minimizing the removal of neutral or value-aligned text. Intuitively, this method discards documents in which the addition of an undesirable trigger phrase is not out-of-distribution according to the baseline-1.5B model, implying that the document is expressing similar views as the trigger phrase.

## 4 Dataset creation & human evaluation

Eleven human evaluators from our organization were tasked with validating the results of this likelihood ranking. A verification dataset was created by sampling examples from the likelihood-labeled dataset. Evaluators were instructed to read examples from the verification dataset and label each one as harmful, expository, counterspeech, or non-harmful according to the following definitions:

* •

  Harmful documents include identity-based hate speech, propaganda, or misinformation.
* •

  Expository documents discuss issues or events related to sensitive topics, but do not perpetuate harmful views themselves.
* •

  Counterspeech documents contains text which aims to counter-act or refute oppressive or harmful views.
* •

  Unknown documents are either non-parseable or written in languages other than English.
* •

  Non-harmful documents are benign documents which do not fit into any of the other categories.

For example, the Wikipedia entry on the history of racism in North America would be considered expository text, whereas an educational website criticizing racist practices would be counterspeech, and a document containing white supremacist propaganda would be considered harmful.

We find that documents with high conditional log-likelihood (i.e. within the top 10% of likelihoods according to our baseline-1.5B model) were more likely to be classified as harmful than those with low log-likelihood. As seen in table [4](#S4 "4 Dataset creation & human evaluation ‣ Mitigating harm in language models with conditional-likelihood filtration"), 9.43% of documents filtered out were classified as harmful, compared to 0.66% of documents which were retained. As seen in Table [4](#S4 "4 Dataset creation & human evaluation ‣ Mitigating harm in language models with conditional-likelihood filtration"), evaluators identify that 5.86% of the data we propose to filter out is counterspeech or expository text, compared to 0.80% of documents that were retained. Appendix A details the trigger phrases used to calculate the conditional log-likelihood. These trigger phrases reflect the values we seek to filter out, though the method could be generalized to other sets of values by using different trigger phrases.

| Bucket | Harmful | Expository or Counterspeech | Non-Harmful | Unknown |
| --- | --- | --- | --- | --- |
| Proposed to filter | 9.43% | 5.86% | 83.16% | 1.55% |
| Proposed to keep | 0.66% | 0.80% | 92.66% | 5.88% |

Table [4](#S4 "4 Dataset creation & human evaluation ‣ Mitigating harm in language models with conditional-likelihood filtration"): Composition of data according to human labels.

Thresholds are selected to minimize the amount of non-harmful data filtered out. After applying a word-level blocklist11
1
Adapted from <https://www.cs.cmu.edu/~biglou/resources/bad-words.txt>, modified to avoid filtering out mentions of individuals based on identity (e.g. asian, canadian) to filter out explicit content and racial slurs, documents are removed if their maximum score across all triggers exceeds a selected threshold value, as illustrated in Figure [3](#S4.F3 "Figure 3 ‣ 4 Dataset creation & human evaluation ‣ Mitigating harm in language models with conditional-likelihood filtration"). A threshold of log-likelihood > -4.0 results in a post-filtration dataset 3.7% smaller than the original, using the trigger phrases seen in Appendix A. Examples of webpages removed can be seen in table [A.4](#A1.SS4 "A.4 Likelihood-filtered examples ‣ Table 2 ‣ A.2.2 Finetuned on likelihood-filtered ‣ A.2 Ablations ‣ Appendix A Appendix ‣ Mitigating harm in language models with conditional-likelihood filtration").

We compare this method with filtration using the Perspective API22
2
<https://github.com/conversationai/perspectiveapi>, which defines toxicity as a rude, disrespectful, or unreasonable comment which is likely to make people leave a discussion. Perspective has several shortcomings, including demographic biases [[Sap et al., 2019](#bib.bib10)], and relies on the specific definition of toxicity used to train the underlying model. Unlike Perspective, conditional-likelihood filtration can be adapted to any set of values with new trigger phrases. As illustrated in Figure [3](#S4.F3 "Figure 3 ‣ 4 Dataset creation & human evaluation ‣ Mitigating harm in language models with conditional-likelihood filtration"), conditional-likelihood filtration and Perspective API capture distinct subsets of the dataset.

Figure 2: A histogram of documents in the corpus along with their conditional log-likelihoods from a single trigger phrase, as measured with the baseline-1.5B model.

Figure 3: Perspective filtration compared to conditional-likelihood filtration. Perspective does not capture the majority of data removed by conditional-likelihood filtration.

## 5 Results

In this section we compare four different 355M-sized models, each representing a different approach to dataset filtration and training:

* •

  Trained on unfiltered data
* •

  Trained on blocklist-filtered data (word-level blocklist filtration)
* •

  Finetuned on likelihood-filtered data (blocklist & conditional-likelihood filtration)
* •

  Trained on likelihood-filtered data (blocklist & conditional-likelihood filtration)

[[Gehman et al., 2020](#bib.bib5)] demonstrate that continued domain-adaptive pretraining (i.e. an additional phase of pretraining on a non-toxic subset of the corpus) is an effective way to mitigate harmful generation in an existing model. As the environmental and financial cost of retraining state-of-the-art language models from scratch can be prohibitively expensive, we explore the effect of finetuning an existing blocklist-filtered model on the likelihood-filtered data for an additional 30k steps to assess whether finetuning can mitigate toxicity learned from pretraining. Conditional-likelihood filtration is always applied post-blocklist filtration in these experiments.

### 5.1 Language modeling benchmarks

Though the likelihood-filtered dataset is comprised of 96.3% of the original dataset, there is potential for conditional-likelihood filtration to adversely affect performance on standard language modeling benchmarks. We find that models trained on the entirely unfiltered dataset still perform best on LAMBADA and lm1b, but models trained on the likelihood-filtered dataset perform significantly better on both tasks compared to models trained on the blocklist-filtered dataset. This suggests that conditional-likelihood filtration results in an overall higher-quality training corpus than word-level blocklist-filtering alone.
Comparisons on the LAMBADA [[Paperno et al., 2016](#bib.bib7)] and One Billion Word Benchmark (lm1b) [[Chelba et al., 2013](#bib.bib3)] benchmarks can be seen in figure [4](#S5.F4 "Figure 4 ‣ 5.1 Language modeling benchmarks ‣ 5 Results ‣ Mitigating harm in language models with conditional-likelihood filtration").

Figure 4: Models trained on unfiltered data perform best on both tasks, but models trained on conditional-likelihood filtered data outperform models trained on blocklist-filtered data.

The decrease in performance on both tasks for models trained on filtered datasets prompted us to cross-reference the blocklist with the content in the lm1b evaluation set, revealing several examples of hate speech and problematic content within lm1b. Examples can be seen in Appendix A. We find that 2.3% of examples within the lm1b evaluation set include words from the blocklist.

Though blocklisted words are occasionally used in explanatory or academic contexts within lm1b, they are also commonly used in negative contexts on the internet, and their presence in evaluation datasets highlights an important finding that existing benchmarks may inadvertently incentivize researchers and practitioners to build language models which are more likely to generate harmful text.

As a follow-up experiment, we compare two 128M models trained with the same hyperparameters on a blocklist-filtered corpus and an unfiltered corpus, and evaluate these models on lm1b and LAMBADA. We find that training on the unfiltered corpus results in better performance on both tasks, but filtering the evaluation tasks for examples with blocklisted words did not result in better performance for models trained on either corpus. Details can be found in table [5.1](#S5.SS1 "5.1 Language modeling benchmarks ‣ 5 Results ‣ Mitigating harm in language models with conditional-likelihood filtration").

| Training dataset | Evaluation datasets | LAMBADA last-token accuracy | lm1b ppl |
| --- | --- | --- | --- |
| Unfiltered | Unfiltered | 48.97% | 73.12 |
| Unfiltered | Filtered | 48.89% | 85.69 |
| Filtered | Unfiltered | 46.15% | 80.44 |
| Filtered | Filtered | 46.17% | 94.31 |

Table [5.1](#S5.SS1 "5.1 Language modeling benchmarks ‣ 5 Results ‣ Mitigating harm in language models with conditional-likelihood filtration"): 128M model experiments on unfiltered vs. blocklisted-filtered lm1b and LAMBADA tasks. The unfiltered model performs best on both tasks.

This finding suggests that models which are optimized for generative safety may be trading off performance on standard language modeling benchmarks which unknowingly include toxic text, and further work must be invested into ensuring that standard benchmarks do not inadvertently incentivize more harmful language models.

### 5.2 Maximum toxicity scores

Models trained on likelihood-filtered datasets consistently exhibit lower maximum toxicity than unfiltered and blocklist-filtered baselines. Maximum toxicity is measured as in [[Gehman et al., 2020](#bib.bib5)], by using the Perspective API to score 5000 generations from each model for the rating along the toxicity axis.

Prompts from the RealToxicityPrompts dataset are used for evaluation, where each prompt has been labeled for toxicity with the Perspective API. As the predictions from Perspective are calibrated, this can be viewed as a >50% probability that the text will be harmful. All generations are sampled with nucleus sampling (p = 0.9, k = 0, N = 5000, temperature = 1.0).

Figure 5: Models trained or finetuned on the likelihood-filtered dataset exhibit lower maximum toxicity as measured by the Perspective API.

### 5.3 Ablation by Trigger Phrase

Our method relies on the curation of several trigger phrases to be used with conditional-likelihood filtration. We investigate the relative effect of each trigger phrase by creating versions of the blocklist-filtered dataset, which are then likelihood-filtered with a single trigger phrase and used to train new models, each with 355M parameters. Models trained on datasets filtered with trigger phrases across different undesirable axes of harm (e.g. racism, nationalism) consistently result in lower maximum toxicity according to the toxicity labels from the Perspective API. Full comparisons are outlined in appendix table [A.2.2](#A1.SS2.SSS2 "A.2.2 Finetuned on likelihood-filtered ‣ A.2 Ablations ‣ Appendix A Appendix ‣ Mitigating harm in language models with conditional-likelihood filtration").

## 6 Limitations & Future Work

While conditional-likelihood filtration effectively identifies undesirable text for removal from a pretraining corpus, it is dependent on using an existing large language model which has been pretrained on an unfiltered dataset, which is computationally intensive. We experimented with using smaller language models (128M and 355M parameters) to label likelihood of text in order to save on computational resources. They did not reliably surface text related to the trigger phrases, suggesting that larger language models are needed for effective filtration.

We also find that researcher-written triggers about politics are more effective at surfacing harmful text compared to triggers about sexism or homophobia. This may suggest that our corpus is overindexed on news domains from 2011-2020, as reflected in [[Dodge et al., 2021](#bib.bib4)]. As conditional-likelihood filtration is dependent on the learned distribution of a specific language model, it may not consistently surface undesirable text which is less well-represented in the training corpus. Furthermore, this method relies on researcher-written triggers which succinctly capture the type of sentiment they wish to remove. As shown in table [4](#S4 "4 Dataset creation & human evaluation ‣ Mitigating harm in language models with conditional-likelihood filtration"), this trigger-based approach sometimes flags counterspeech and expository text for removal, as the type of language used may be overlapping. Future work will seek to characterize the types of trigger phrases which result in successful filtration.

Additionally, conditional-likelihood filtration surfaces text for removal which is distinct from the distribution captured by a blocklist, as evident by the amount of additional data removed by conditional-likelihood filtration after blocklist filtration. Promising avenues for future work include large-scale comparison of blocklists versus conditional-likelihood filtration, with the aim to shift standard filtration techniques away from overly-broad blocklists to more nuanced, model-based approaches.

Language models have also been shown to be vulnerable to adversarial attacks which can be used to trigger models to generate undesirable text. We implemented universal adversarial triggers as per [[Wallace et al., 2021](#bib.bib14)] to generate potential filtration triggers from the learned distribution of the baseline model. Appending the programmatically-generated triggers to documents did not successfully surface candidate text for filtration, likely because adversarial triggers do not fit the distribution of natural language. For example, adversarially attacking the pretrained 1517M baseline resulted in the trigger "Psych ethical stereotype make teachesrduralivity!!!!", but appending this to documents from our data corpus did not successfully surface harmful data for removal. Further work may seek to develop programmatic methods for writing trigger phrases as opposed to relying on researcher-written text.

Pretrained language models are also limited by the temporal window of the corpus curation process. Language models will not accurately capture or represent information about a topic or event which happens outside of the data collection window (e.g. a language model pretrained on news articles up to the last six months will not be useful for capturing an event which happened last month). As a result, conditional-likelihood filtration may not successfully surface undesirable text about recent events. Researchers should carefully document temporal information about the pretraining corpus used to train the baseline model used for computing the conditional log-likelihood of each document.

## 7 Risks and Social Impact

Decisions about what text should be removed from training corpora should depend on the social and ethical contexts in which the resulting language model will be deployed [[Bender et al., 2021](#bib.bib1)]. Conditional-likelihood filtration is appealing in this regard because trigger phrases can be adapted for various contexts. While the adaptability of conditional-likelihood filtration means it can accommodate diverse social environments, it also means that malicious actors could use it to their advantage. For example, they could use the method to remove oppositional speech from training data and encourage language models to proliferate their ideas [[Yang and Roberts, 2021](#bib.bib15)]. Adverse use cases need to be studied in greater detail to understand the threat landscape around publishing value-alignment methods such as conditional-likelihood filtration or PALMS [[Solaiman and Dennison, 2021](#bib.bib12)].

Defining undesirable text is difficult and context-dependent; using automated methods to flag it presents additional challenges [[Vidgen et al., 2019](#bib.bib13)]. In our research, we reduced the risk of unintentionally moderating beneficial speech by evaluating our method using human annotators. Human evaluations should always be performed before deploying conditional-likelihood filtration, and more research should be conducted to understand its limitations, in particular those described above.

## 8 Conclusion

We demonstrate that the knowledge from a pretrained language model can be used in conjunction with researcher-written trigger phrases to filter a web-scale text corpus for undesirable content, and training on the resulting filtered dataset results in language models which exhibit lower maximum toxicity. These models show a slight decrease on standard language modeling benchmarks, suggesting that models optimized for generative safety may be trading off performance according to standard benchmarks. We offer a partial explanation for this performance decrease by surfacing examples in lm1b which use words found in standard word-level blocklists, highlighting that existing standard language modeling benchmarks may be inadvertently incentivizing researchers to build language models which are more likely to generate harmful text. We encourage researchers building evaluation benchmarks to conduct more thorough analysis on the content and possible harms of their benchmark datasets before public release.

Conditional-likelihood filtration does not solve the problem of corpus-based harm in natural language processing, but provides a scalable way to identify and remove undesirable text in a web-scale language modeling corpus, enabling researchers to partially mitigate toxicity learned during the pretraining phase. Though we use conditional-likelihood filtration to remove harmful data from a corpus according to our specific set of values, the generalizability of this method allows for it to be adapted for trigger phrases which reflect other value sets, allowing researchers to curate custom trigger phrases used to build language models which are more closely aligned with their values.

## 9 Acknowledgments

We thank Aviv Ovadya, Jade Abbott, Tim Hwang and Aidan Gomez for their feedback and insights while preparing this work.

## Appendix A Appendix

### A.1 Pretrained filtration model

|  |  |
| --- | --- |
| Parameter | Specification |
| Model parameters | 1517M |
| Training steps | 48.7k |
| Batch size | 4080 |
| Sequence length | 1024 |
| Embedding dimension | 1536 |
| Layers | 24 |
| Attention heads | 24 |
| Optimizer | Adam |
| Initial learning rate | 0.0001 |
| Training dataset size | 366GB |

Table [A.1](#A1.SS1 "A.1 Pretrained filtration model ‣ Appendix A Appendix ‣ Mitigating harm in language models with conditional-likelihood filtration"): Details for pretrained 1517M model used for filtration.

### A.2 Ablations

#### A.2.1 Trained on likelihood-filtered

All models are pretrained for 360k steps with a batch size of 768 and sequence length of 1024.

|  |  |  |  |
| --- | --- | --- | --- |
|  |  |  |  |
| Trigger phrase used for filtration | LAMBADA last-token accuracy | lm1b ppl | Max toxicity |
| Baseline (unfiltered) | 67.99% | 41.26 | 0.93 |
| Baseline (blocklist-filtered only) | 62.19% | 46.68 | 0.88 |
| Working class citizens are getting their jobs taken away by illegal immigrants. | 68.00% | 43.77 | 0.77 |
| Black people are inferior to white people. | 67.10% | 43.77 | 0.83 |
| Antifa is anti-American. | 68.82% | 43.05 | 0.84 |
| Social justice warriors hate the white race. | 69.13% | 44.18 | 0.75 |
| Union of all triggers | 67.54% | 43.49 | 0.78 |

#### A.2.2 Finetuned on likelihood-filtered

All finetuned models are trained with a batch size of 768 and sequence length of 1024.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |
| Trigger phrase used for filtration | Finetuning steps | LAMBADA last-token accuracy | lm1b ppl | Max toxicity |
| Baseline (unfiltered) | - | 67.99% | 41.26 | 0.93 |
| Baseline (blocklist-filtered only) | - | 62.19% | 46.68 | 0.88 |
| Working class citizens are getting their jobs taken away by illegal immigrants. | 10k | 61.92% | 48.09 | 0.87 |
| Working class citizens are getting their jobs taken away by illegal immigrants. | 20k | 62.19% | 48.04 | 0.82 |
| Working class citizens are getting their jobs taken away by illegal immigrants. | 30k | 61.78% | 48.18 | 0.79 |
| Black people are inferior to white people. | 30k | 61.99% | 48.18 | 0.88 |
| Antifa is anti-American. | 30k | 60.42% | 47.46 | 0.85 |
| Social justice warriors hate the white race. | 30k | 61.98% | 47.62 | 0.79 |
| Union of all triggers | 30k | 61.89% | 47.65 | 0.80 |

### A.3 One Billion Word Benchmark samples with frequently blocklisted words

| Word | Text |
| --- | --- |
| sodomy | Sorry gay community, sorry Elton John and other wealthy gays, but at least until the appeal you’ll have to keep your disgusting perversion and sodomy inside your closets. |
| gays | " Your conclusion is that gays and lesbians lack sufficient political power even though the speaker is openly gay? " |
| whites | Why is it so easy for blacks to denounce whites as racists, but when the roles are reversed, people in the liberal media go nuts? |
| raped | My heart breaks because we will now have to put these animals on trial and hope they get the death penalty, they will then live for another 10-20 yrs on us, Maybe they should be raped and dumped on the side of the road like the trash that they are. |
| fetish | But when the fetish femme fatale isn’t flashing her finest assets, how does she make herself feel sexy and strong? |
| violence | Using violence and intimidation to force a political ultimatum on a populace. |
| fuck | After a couple of weeks at my lovely in-laws, the urge to stand up and shout " fuck " as loud as you can becomes strong. |
| sexual | Go for the weekly sexual adventure, no apologies. |
| abortion | One can be a good Christian while living in a society where abortion is legal. |
| terrorist | He reportedly called her a " terrorist " when they first met. |
| moron | This man (Giblet) is an absolute moron and each time he opens his mouth he speaks for all the other Kool-Aid drinking morons (aka Dumbocrats) out there. |
| suicide | Do I look fat in this suicide vest? |
| racial | I am growing tired of all of the racial bias crap. |
| jews | She told me that Russians hate jews plain and simple. |
| rape | Let’s preserve the bright line that distinguishes between rape and not-rape. |
| porn | Ideally, they should look as though they live on internet porn and chips. |
| nude | Future of Iowa nude dancing clubs hangs on answer to question:Is stripping an art? |
| prostitute | As the old cliche goes, a man doesn’t pay a prostitute for sex, he pays her to leave afterwards. |
| sexual | But the connection between conventional sexual morality and intelligence is not mirrored in women, it seems. |
| moron | So what moron is in charge of your cyber security? |
| homosexual | " Get Aids and die, you pig, " the American radio " shock jock " told a purportedly homosexual man who once badmouthed his teeth. |
| scum | Thanks a lot you morons for ever voting for cheap scum thieving fascist traitor murder pig democrats. |
| welfare | All welfare should be ended. |
| pornography | 24 (UPI) – A Canadian pizza delivery driver in Windsor, Ontario, says his car’s wireless rear-view camera system shows pornography when he drives on a certain street. |

Table 1: Examples from the lm1b benchmark containing words found in commonly used word-level blocklists.

### A.4 Likelihood-filtered examples

| Likelihood | Document text |
| --- | --- |
| -3.989315 | Right & Free is an online community of Constitutional conservatives dedicated to defeating the liberal agenda with the power of the internet. We believe that in order to preserve our liberty and prosperity, we must fight to protect it - and we must do it together. Here at Right & Free, we are informed, we are active, and we are engaged. But above all else, we are patriots. |
| -3.780214 | I just wanted to write down a thought about morality that I had recently, since a lot of people liked it. Picking morals from religion is like picking out food from the trash. Sure, you’ll find something edible, and maybe even tasty, but it’ll be tainted with the horrid smell of the rest of the junk. Why not just get your food fresh from nature where it came from in the first place. Also, see this nice image by a fellow poster on RichardDawkins.net. |
| -3.834188 | Support me on Patreon! Meat Monkey’s House of Weirdness: Strange, weird, and funny stuff Hawanja.com: The adventures of a loner ninja in a messed up world The Ultimate Console Database: Pics and info on every video game system ever made. Hawanja’s Etsy Store: Come by often and buy lots of stuff! Why I hate the World: Angry, partisan filled rants with lots of F-words. Enjoy! Hawanja on Deviant art: Please give me honest feedback. I am a grown man now. I can take it. |
| -3.989428 | I easily WIN the Presidency of the United States with LEGAL VOTES CAST. The OBSERVERS were not allowed, in any way, shape, or form, to do their job and therefore, votes accepted during this period must be determined to be ILLEGAL VOTES. U.S. Supreme Court should decide! — Donald J. Trump (@realDonaldTrump) November 6, 2020 |
| -3.970951 | Schools are closing, people are freaking out, but here’s a little tidbit buried in another series of front page stories in today’s Chron: 36,000 people DIE every year from the flu in the United States alone. And what do we have so far — one confirmed death in this country? Even in Mexico, ground zero for the outbreak, less than 200 people have died. This "pandemic" could turn out to be far less deadly than a typical flu season. In fact, it may be the mildest outbreak of "deadly" flu ever. |
| -3.782735 | Donald Trump had some tough words for the Germans at the NATO summit in Belgium on Thursday. "The Germans are bad, very bad," he reportedly told Jean-Claude Juncker, the president of the European Union. "Look at the millions of cars that they’re selling in the USA. Horrible. We’re gonna stop that."It is certainly true that Germany runs a big trade surplus with the world and with the United States…. But Trump can’t stop the German cars from coming in to the U.S. because, to a large degree, … |
| -3.702403 | Well said, Dan! One would think that, representing a Chicago district in the midst of a crippling recession, she would have a hundred issues more important to her constituents and herself than this one, but… A Me Generation liberal state rep is sure to make a bigger deal about her own ability to file a joint tax return than about the inability of 10%-plus of her constituents to find a job. Taxes, spending, and regulations? Nope, she’s more interested in concentrating on the discriminatio… |
| -3.991992 | HOUSE RULES 1. We welcome reader comments on the top stories of the day. Some comments may be republished on the website or in the newspaper email addresses will not be published. 2. Please understand that comments are moderated and it is not always possible to publish all that have been submitted. We will, however, try to publish comments that are representative of all received.3. We ask that comments are civil and free of libellous or hateful material. Also please stick to the top… |
| -3.774133 | DC: Trump supporters attacked by Antifa and BLM Antifa and BLM hit, throw eggs and unknown liquids at Trump Supporters walking through BLM Plaza You can hear see and hear the female Trump Supporter cry in fear pic.twitter.com/No1QDp4KLd — Drew Hernandez (@livesmattershow) November 14, 2020 |
| -3.642176 | I can only say the same thing I have been saying all along, the Democrats have failed America for a very long time and they still are. If you do not build the fence, do not worry about it. Unicorn I So Grumpy I Am Not Even Talking To Myself. It would be just another lie’. you are pretty good at that. Unicorn I So Grumpy I Am Not Even Talking To Myself shirt Only problem is Washington does not run on common sense. Actually I don’t think common sense even exists today – so few people still h… |
| -3.990500 | This man is trash in human form… the fact that to this day he still gains millions of streams and views on his half-ass music is abhorrent. Really didn’t appreciate the doc trying to humanize him & justify his actions by saying he’s a product of abuse, neglect and his a low socioeconomic status. You can come from all of that and not grow up to be a convicted felon and pedophile. All in all, it was interesting to watch but it would’ve been better if the narrator didn’t try to justify or c… |
| -3.911217 | Recent Comments Chicken farming, like all farming, is a thankless task. frankchapeau At the time the Bank of England was started it’s very First investment was 12 million pounds of the Duke of Orange to underwrite it’s operations….Awordinyourear I go back and forth between democrats being evil and democrats being stupid. I haven’t been able to settle on one yet. CarterBurger If the vulnerable will still be vulnerable then surely the best defence for them and the best form… |

Table 2: Examples of webpages filtered out with the trigger "Antifa is anti-American." and a threshold of >-4.00. The first 384 tokens of each document are shown.
