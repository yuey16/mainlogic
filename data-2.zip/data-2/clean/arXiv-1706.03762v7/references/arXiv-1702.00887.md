<!-- fulltext source=arxiv_html slug=arXiv-1702.00887 fetched=2026-09-16T11:52:49+00:00 -->

# Structured Attention Networks

Yoon Kim
††thanks: Equal contribution.
  
Carl Denton\*
  
Luong Hoang
  
Alexander M. Rush
Email: [{yoonkim@seas,carldenton@college,lhoang@g,srush@seas}.harvard.edu](mailto:)
Affiliation: School of Engineering and Applied Sciences
Affiliation: Harvard University
Affiliation: Cambridge, MA 02138, USA

###### Abstract

Attention networks have proven to be an effective approach for
embedding categorical inference within a deep neural network.
However, for many tasks we may want to model richer structural
dependencies without abandoning end-to-end training. In this work,
we experiment with incorporating richer structural distributions,
encoded using graphical models, within deep networks. We
show that these structured attention networks are simple extensions
of the basic attention procedure, and that they allow for extending
attention beyond the standard soft-selection approach, such
as attending to partial segmentations or to subtrees. We experiment
with two different classes of structured attention networks: a
linear-chain conditional random field and a graph-based parsing
model, and describe how these models can be practically implemented
as neural network layers. Experiments show that this approach is
effective for incorporating structural biases, and structured attention
networks outperform baseline attention models on a variety of synthetic
and real tasks: tree transduction, neural machine translation, question answering, and natural language
inference. We further find that models trained in this way learn
interesting unsupervised hidden representations that generalize simple attention.

|  |
| --- |
|  |

## 1 Introduction

Attention networks are now a standard part of the deep learning
toolkit, contributing to impressive results in neural machine
translation ([Bahdanau et al., 2015](#bib.bib2); [Luong et al., 2015](#bib.bib34)), image captioning
([Xu et al., 2015](#bib.bib54)), speech recognition ([Chorowski et al., 2015](#bib.bib11); [Chan et al., 2015](#bib.bib7)),
question answering ([Hermann et al., 2015](#bib.bib24); [Sukhbaatar et al., 2015](#bib.bib48)), and
algorithm-learning ([Graves et al., 2014](#bib.bib21); [Vinyals et al., 2015](#bib.bib49)), among many other
applications (see [Cho et al. (2015)](#bib.bib10) for a comprehensive review).
This approach alleviates the bottleneck of compressing a source
into a fixed-dimensional vector by equipping a model with
variable-length memory ([Weston et al., 2014](#bib.bib52); [Graves et al., 2014](#bib.bib21); [Graves et al., 2016](#bib.bib22)),
thereby providing random access into the source as needed. Attention
is implemented as a hidden layer which computes a categorical
distribution (or hierarchy of categorical distributions) to make a
soft-selection over source elements.

Noting the empirical effectiveness of attention networks, we also
observe that the standard attention-based architecture does not
directly model any structural dependencies that may exist
among the source elements, and instead relies completely on the hidden
layers of the network. While one might argue that these structural
dependencies can be learned implicitly by a deep model with enough
data, in practice, it may be useful to provide a structural
bias. Modeling structural dependencies at the final, output layer has
been shown to be important in many deep learning applications, most
notably in seminal work on graph transformers ([LeCun et al., 1998](#bib.bib31)), key work on NLP
([Collobert et al., 2011](#bib.bib12)), and in many other areas
([Peng et al., 2009](#bib.bib41); [Do & Artiéres, 2010](#bib.bib13); [Jaderberg et al., 2014](#bib.bib25); [Chen et al., 2015](#bib.bib8); [Durrett & Klein, 2015](#bib.bib17); [Lample et al., 2016](#bib.bib30), inter alia).

In this work, we consider applications which may require structural
dependencies at the attention layer, and develop internal
structured layers for modeling these directly. This approach
generalizes categorical soft-selection attention layers by
specifying possible structural
dependencies in a soft manner. Key applications will be the
development of an attention function that segments the source input
into subsequences and one that takes into account the latent
recursive structure (i.e. parse tree) of a source sentence.

Our approach views the attention mechanism as a graphical model over a
set of latent variables. The standard attention network can be seen
as an expectation of an annotation function with respect to a single
latent variable whose categorical distribution is parameterized to be
a function of the source. In the general case we can specify a
graphical model over multiple latent variables whose edges encode the
desired structure. Computing forward attention requires performing
inference to obtain the expectation of the annotation function, i.e.
the context vector. This expectation is computed over an
exponentially-sized set of structures (through the machinery of
graphical models/structured prediction), hence the name structured
attention network. Notably each step of this process (including inference)
is differentiable, so the model can be trained end-to-end without
having to resort to deep policy gradient methods ([Schulman et al., 2015](#bib.bib44)).

The differentiability of inference algorithms over graphical models
has previously been noted by various researchers
([Li & Eisner, 2009](#bib.bib32); [Domke, 2011](#bib.bib14); [Stoyanov et al., 2011](#bib.bib47); [Stoyanov & Eisner, 2012](#bib.bib46); [Gormley et al., 2015](#bib.bib20)),
primarily outside the area of deep learning. For example,
[Gormley et al. (2015)](#bib.bib20) treat an entire graphical model as a
differentiable circuit and backpropagate risk through variational
inference (loopy belief propagation) for minimium risk training of
dependency parsers. Our contribution is to combine these ideas to
produce structured internal attention layers within deep
networks, noting that these approaches allow us to use the resulting
marginals to create new features, as long as we do so a differentiable
way.

We focus on two classes of structured attention:
linear-chain conditional random fields (CRFs) ([Lafferty et al., 2001](#bib.bib29)) and
first-order graph-based dependency parsers ([Eisner, 1996](#bib.bib18)). The
initial work of [Bahdanau et al. (2015)](#bib.bib2) was particularly interesting in
the context of machine translation, as the model was able to
implicitly learn an alignment model as a hidden layer,
effectively embedding inference into a neural network. In similar
vein, under our framework the model has the capacity to learn a
segmenter as a hidden layer or a parser as a hidden
layer, without ever having to see a segmented sentence or a parse
tree. Our experiments apply this approach to a difficult synthetic
reordering task, as well as to machine translation, question answering, and
natural language inference. We find that models trained with structured attention
outperform standard attention models. Analysis
of learned representations further reveal that interesting structures
emerge as an internal layer of the model. All code is available at
http://github.com/harvardnlp/struct-attn.

## 2 Background: Attention Networks

A standard neural network consist of a series of non-linear
transformation layers, where each layer produces a fixed-dimensional
hidden representation. For tasks with large input spaces, this
paradigm makes it hard to control the interaction between
components. For example in machine translation, the source consists of
an entire sentence, and the output is a prediction for each word in
the translated sentence. Utilizing a standard network leads to an
information bottleneck, where one hidden layer must encode the entire
source sentence. Attention provides an alternative approach.11
1
Another line
of work involves marginalizing over latent variables (e.g.
latent alignments) for sequence-to-sequence transduction
([Kong et al., 2016](#bib.bib28); [Lu et al., 2016](#bib.bib33); [Yu et al., 2016](#bib.bib55); [Yu et al., 2017](#bib.bib56)). An attention network
maintains a set of hidden representations that scale
with the size
of the source. The model uses an internal
inference step to perform a soft-selection over these representations.
This method allows the model to maintain a variable-length memory
and has shown to be crucially important for scaling systems for many tasks.

Formally, let $x=[x\_{1},\dots,x\_{n}]$ represent a sequence of inputs,
let $q$ be a query, and let $z$ be a categorical latent variable with
sample space $\{1,\ldots,n\}$ that encodes the desired selection
among these inputs. Our aim is to produce a context $c$ based
on the sequence and the query. To do so, we assume access to an
attention distribution $z\sim p(z\,|\,x,q)$, where we
condition $p$ on the inputs $x$ and a query $q$. The context
over a sequence is defined as expectation,
$c=\mathbb{E}\_{z\sim p(z\,|\,x,q)}[f(x,z)]$ where $f(x,z)$ is an
annotation function. Attention of this form can be applied
over any type of input, however, we will primarily be concerned with
“deep” networks, where both the annotation function and attention
distribution are parameterized with neural networks, and the context
produced is a vector fed to a downstream network.

For example, consider the case of attention-based neural machine
translation ([Bahdanau et al., 2015](#bib.bib2)). Here the sequence of inputs
$[\mathbf{x}\_{1},\ldots,\mathbf{x}\_{n}]$ are the hidden states of a
recurrent neural network (RNN), running over the words in the source
sentence, $\mathbf{q}$ is the RNN hidden state of the target decoder (i.e. vector
representation of the query $q$),
and $z$ represents the source position to be attended to for
translation. The attention distribution $p$ is simply
$p(z=i\,|\,x,q)=\softmax(\theta\_{i})$ where $\theta\in\mathbb{R}^{n}$
is a parameterized potential typically based on a neural network,
e.g. $\theta\_{i}=\mlp([\mathbf{x}\_{i};\mathbf{q}])$. The annotation function is
defined to simply return the selected hidden state,
$f(\mathbf{x},z)=\mathbf{x}\_{z}$. The context vector can then be computed
using a simple sum,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbf{c}=\mathbb{E}\_{z\sim p(z\,|\,x,q)}[f(x,z)]=\sum\_{i=1}^{n}p(z=i\,|\,x,q)\mathbf{x}\_{i}$ |  | (1) |

Other tasks such as question answering use attention in a similar
manner, for instance by replacing source $[x\_{1},\ldots,x\_{n}]$ with a
set of potential facts and $q$ with a representation of the question.

In summary we interpret the attention mechanism as taking the
expectation of an annotation function $f(x,z)$ with respect to a latent
variable $z\sim p$, where $p$ is parameterized to be function of $x$
and $q$.

## 3 Structured Attention

Attention networks simulate selection from a set
using a soft model. In this work we consider generalizing selection to
types of attention, such as selecting chunks, segmenting inputs, or
even attending to latent subtrees. One interpretation of this
attention is as using soft-selection that considers all possible
structures over the input, of which there may be exponentially many
possibilities. Of course, this expectation can no longer be computed
using a simple sum, and we need to incorporate the machinery of inference
directly into our neural network.

Define a structured attention model as being an attention model where
$z$ is now a vector of discrete latent variables $[z\_{1},\ldots,z\_{m}]$
and the attention distribution is $p(z\,|\,x,q)$ is defined as a
conditional random field (CRF), specifying the independence
structure of the $z$ variables. Formally, we assume an undirected
graph structure with $m$ vertices. The CRF is parameterized with
clique (log-)potentials $\theta\_{C}(z\_{C})\in\mathbb{R}$, where the $z\_{C}$
indicates the subset of $z$ given by clique $C$. Under this
definition, the attention probability is defined as,
$p(z\,|\,x,q;\theta)=\softmax(\sum\_{C}\theta\_{C}(z\_{C}))$, where for
symmetry we use $\softmax$ in a general sense,
i.e. $\softmax(g(z))=\frac{1}{Z}\exp(g(z))$ where
$Z=\sum\_{z^{\prime}}\exp(g(z^{\prime}))$ is the implied partition function. In
practice we use a neural CRF, where $\theta$ comes from a deep model
over $x,q$.

In structured attention, we also assume that the annotation function
$f$ factors (at least) into clique annotation functions
$f(x,z)=\sum\_{C}f\_{C}(x,z\_{C})$. Under standard conditions on the
conditional independence structure, inference techniques from
graphical models can be used to compute the forward-pass expectations
and the context:

|  |  |  |
| --- | --- | --- |
|  | $c=\mathbb{E}\_{z\sim p(z\,|\,x,q)}[f(x,z)]=\sum\_{C}\mathbb{E}\_{z\sim p(z\_{C}\,|\,x,q)}[f\_{C}(x,z\_{C})]$ |  |

### 3.1 Example 1: Subsequence Selection

$q$$z\_{1}$$x\_{1}$$x\_{2}$$x\_{3}$$x\_{4}$

(a)

$q$$z\_{1}$$z\_{2}$$z\_{3}$$z\_{4}$$x\_{1}$$x\_{2}$$x\_{3}$$x\_{4}$

(b)

$q$$z\_{1}$$z\_{2}$$z\_{3}$$z\_{4}$$x\_{1}$$x\_{2}$$x\_{3}$$x\_{4}$

(c)

Figure 1:  Three versions of a latent variable attention
model:
(a) A standard soft-selection attention network, (b) A
Bernoulli (sigmoid) attention network, (c) A linear-chain
structured attention model for segmentation. The input and query are denoted with $x$ and $q$ respectively.

Suppose instead of soft-selecting a single input, we wanted to
explicitly model the selection of contiguous subsequences. We could
naively apply categorical attention over all subsequences, or hope
the model learns a multi-modal distribution to combine neighboring
words. Structured attention provides an alternate approach.

Concretely, let $m=n$, define $z$ to be a random vector
$z=[z\_{1},\dots,z\_{n}]$ with $z\_{i}\in\{0,1\}$, and define our
annotation function to be, $f(x,z)=\sum\_{i=1}^{n}f\_{i}(x,z\_{i})$ where $f\_{i}(x,z\_{i})=\mathbbm{1}\{z\_{i}=1\}\mathbf{x}\_{i}$.
The explicit expectation is then,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\mathbb{E}\_{z\_{1},\dots,z\_{n}}[f(x,z)]=\sum\_{i=1}^{n}p(z\_{i}=1\,|\,x,q)\mathbf{x}\_{i}$ |  | (2) |

Equation ([2](#S3.E2 "In 3.1 Example 1: Subsequence Selection ‣ 3 Structured Attention ‣ Structured Attention Networks")) is similar to equation ([1](#S2.E1 "In 2 Background: Attention Networks ‣ Structured Attention Networks"))—both are a linear
combination of the input representations where the scalar is between $[0,1]$ and represents how much
attention should be focused on each input. However, (2) is fundamentally different in two ways: (i)
it allows for multiple inputs (or no inputs) to be selected for a given query; (ii)
we can incorporate structural dependencies across the $z\_{i}$’s. For instance, we can model the distribution over $z$ with a linear-chain CRF with pairwise edges,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle p(z\_{1},\dots,z\_{n}\,|\,x,q)=\softmax\left(\sum\_{i=1}^{n-1}\theta\_{i,i+1}(z\_{i},z\_{i+1})\right)$ |  | (3) |

where $\theta\_{k,l}$ is the pairwise potential for $z\_{i}=k$ and $z\_{i+1}=l$. This model is shown in Figure [1](#S3.F1 "Figure 1 ‣ 3.1 Example 1: Subsequence Selection ‣ 3 Structured Attention ‣ Structured Attention Networks")c.
Compare this model to the standard attention in Figure [1](#S3.F1 "Figure 1 ‣ 3.1 Example 1: Subsequence Selection ‣ 3 Structured Attention ‣ Structured Attention Networks")a, or to a simple Bernoulli (sigmoid) selection
method, $p(z\_{i}=1\,|\,x,q)=\sigmoid(\theta\_{i})$, shown in Figure [1](#S3.F1 "Figure 1 ‣ 3.1 Example 1: Subsequence Selection ‣ 3 Structured Attention ‣ Structured Attention Networks")b.
All three of these methods can use potentials
from the same neural network or RNN that takes $x$ and $q$ as inputs.

In the case of the linear-chain CRF in ([3](#S3.E3 "In 3.1 Example 1: Subsequence Selection ‣ 3 Structured Attention ‣ Structured Attention Networks")), the marginal distribution
$p(z\_{i}=1\,|\,x)$ can be calculated efficiently in
linear-time for all $i$ using message-passing, i.e. the
forward-backward algorithm. These marginals allow us to calculate
([2](#S3.E2 "In 3.1 Example 1: Subsequence Selection ‣ 3 Structured Attention ‣ Structured Attention Networks")), and in doing so we implicitly sum over an
exponentially-sized set of structures (i.e. all binary sequences of
length $n$) through dynamic programming.
We refer to this type of attention layer as a *segmentation attention* layer.

Note that the forward-backward algorithm is being used as parameterized
pooling (as opposed to output computation), and can be
thought of as generalizing the standard attention softmax.
Crucially this generalization from vector softmax to forward-backward
is just a series of differentiable steps,22
2
As are other dynamic
programming algorithms for inference in graphical models, such as
(loopy and non-loopy) belief propagation. and we can compute
gradients of its output (marginals) with respect to its input
(potentials). This will allow the structured attention model to be
trained end-to-end as part of a deep model.

### 3.2 Example 2: Syntactic Tree Selection

This same approach can be used for more involved structural
dependencies. One popular structure for natural language tasks is a
dependency tree, which enforces a structural bias on the recursive
dependencies common in many languages. In particular a dependency tree
enforces that each word in a source sentence is assigned exactly one
parent word (head word), and that these assignments do not cross (projective
structure). Employing this bias encourages the system to make a
soft-selection based on learned syntactic dependencies, without
requiring linguistic annotations or a pipelined decision.

A dependency parser can be partially formalized as a graphical model with the
following cliques ([Smith & Eisner, 2008](#bib.bib45)): latent variables
$z\_{ij}\in\{0,1\}$ for all $i\neq j$, which indicates that the
$i$-th word is the parent of the $j$-th word (i.e.
$x\_{i}\rightarrow x\_{j}$); and a special global constraint that rules out
configurations of $z\_{ij}$’s that violate parsing constraints
(e.g. one head, projectivity).

The parameters to the graph-based CRF dependency parser are the
potentials $\theta\_{ij}$, which reflect the score of selecting
$x\_{i}$ as the parent of $x\_{j}$. The probability of a parse tree $z$
given the sentence $x=[x\_{1},\ldots,x\_{n}]$ is,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $p(z\,|\,x,q)=\softmax\left(\mathbbm{1}\{z\ \text{is valid}\}\sum\_{i\neq j}\mathbbm{1}\{z\_{ij}=1\}\theta\_{ij}\right)$ |  | (4) |

where $z$ is represented as a vector of $z\_{ij}$’s for all $i\neq j$.
It is possible to calculate the marginal probability of each edge $p(z\_{ij}=1\,|\,x,q)$
for all $i,j$ in $O(n^{3})$ time using the inside-outside algorithm ([Baker, 1979](#bib.bib3))
on the data structures of [Eisner (1996)](#bib.bib18).

The parsing contraints ensure that each word has exactly one head (i.e. $\sum\_{i=1}^{n}z\_{ij}=1$). Therefore if we want to utilize the *soft-head*
selection of a position $j$,
the context vector is defined as:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle f\_{j}(x,z)=\sum\_{i=1}^{n}\mathbbm{1}\{z\_{ij}=1\}\mathbf{x}\_{i}$ |  | $\displaystyle\mathbf{c}\_{j}=\mathbb{E}\_{z}[f\_{j}(x,z)]=\sum\_{i=1}^{n}p(z\_{ij}=1\,|\,x,q)\mathbf{x}\_{i}$ |  |

Note that in this case the annotation function has the subscript $j$ to produce a context vector for each word in the sentence.
Similar types of attention can be applied for other tree properties (e.g. soft-children).
We refer to this type of attention layer as a *syntactic attention* layer.

### 3.3 End-to-End Training

```
procedure ForwardBackward(θ\theta)

                
                α⁡[0,⟨t⟩]←0\alpha[0,\langle t\rangle]\leftarrow 0

                
                β⁡[n+1,⟨t⟩]←0\beta[n+1,\langle t\rangle]\leftarrow 0

                
                for i=1,…,n;c∈𝒞i=1,\dots,n;c\in\mathcal{C} do

                
                 α⁡[i,c]←⨁yα⁡[i−1,y]⊗θi−1,i​(y,c)\alpha[i,c]\leftarrow\bigoplus_{y}\alpha[i-1,y]\otimes\theta_{i-1,i}(y,c)
  

                
                for i=n,…,1;c∈𝒞i=n,\dots,1;c\in\mathcal{C} do

                
                 β⁡[i,c]←⨁yβ⁡[i+1,y]⊗θi,i+1​(c,y)\beta[i,c]\leftarrow\bigoplus_{y}\beta[i+1,y]\otimes\theta_{i,i+1}(c,y)
  

                
                A←α⁡[n+1,⟨t⟩]A\leftarrow\alpha[n+1,\langle t\rangle]

                
                for i=1,…,n;c∈𝒞i=1,\dots,n;c\in\mathcal{C} do

                
                 p⁡(zi=c|x)←exp⁡(α⁡[i,c]⊗β⁡[i,c]CLOSEp(z_{i}=c\,|\,x)\leftarrow\exp(\alpha[i,c]\otimes\beta[i,c]

                
                       ⊗−A)\otimes-A)
  

                
                return pp
```

```
procedure BackpropForwardBackward(θ,p,∇pℒ\theta,p,\nabla^{\mathcal{L}}_{p})

                
                ∇ℒα←logp⊗log∇pℒ⊗β⊗−A\nabla^{\mathcal{L}}_{\alpha}\leftarrow\log p\otimes\log\nabla_{p}^{\mathcal{L}}\otimes\beta\otimes-A

                
                ∇ℒβ←logp⊗log∇pℒ⊗α⊗−A\nabla^{\mathcal{L}}_{\beta}\leftarrow\log p\otimes\log\nabla_{p}^{\mathcal{L}}\otimes\alpha\otimes-A

                
                α^​[0,⟨t⟩]←0\hat{\alpha}[0,\langle t\rangle]\leftarrow 0

                
                β^​[n+1,⟨t⟩]←0\hat{\beta}[n+1,\langle t\rangle]\leftarrow 0

                
                for i=n,…​1;c∈𝒞i=n,\dots 1;c\in\mathcal{C} do

                
                 β^​[i,c]←∇αℒ[i,c]⊕⨁yθi,i+1​(c,y)⊗β^​[i+1,y]\hat{\beta}[i,c]\leftarrow\nabla^{\mathcal{L}}_{\alpha}[i,c]\oplus\bigoplus_{y}\theta_{i,i+1}(c,y)\otimes\hat{\beta}[i+1,y]
  

                
                for i=1,…,n;c∈𝒞i=1,\dots,n;c\in\mathcal{C} do

                
                 α^​[i,c]←∇βℒ[i,c]⊕⨁yθi−1,i​(y,c)⊗α^​[i−1,y]\hat{\alpha}[i,c]\leftarrow\nabla^{\mathcal{L}}_{\beta}[i,c]\oplus\bigoplus_{y}\theta_{i-1,i}(y,c)\otimes\hat{\alpha}[i-1,y]
  

                
                for i=1,…,n;y,c∈𝒞i=1,\dots,n;y,c\in\mathcal{C} do

                
                 ∇θi−1,i​(y,c)ℒ←signexp⁡(α^​[i,y]⊗β⁡[i+1,c]CLOSE\nabla^{\mathcal{L}}_{\theta_{i-1,i}(y,c)}\leftarrow\signexp(\hat{\alpha}[i,y]\otimes\beta[i+1,c]

                
                      ⊕α[i,y]⊗β^[i+1,c]\oplus\>\alpha[i,y]\otimes\hat{\beta}[i+1,c]

                
                      ⊕α[i,y]⊗β[i+1,c]⊗−A)\oplus\>\alpha[i,y]\otimes\beta[i+1,c]\otimes-A)
  

                
                return ∇θℒ\nabla^{\mathcal{L}}_{\theta}
```

Figure 2:  Algorithms for linear-chain CRF: (left)
computation of forward-backward tables $\alpha$, $\beta$, and marginal probabilities $p$
from potentials $\theta$ (forward-backward algorithm); (right)
backpropagation of loss gradients with respect to the marginals $\nabla\_{p}^{\cal L}$.
$\mathcal{C}$ denotes the state space and $\langle t\rangle$ is the special start/stop state. Backpropagation uses the identity $\nabla\_{\log p}^{\mathcal{L}}=p\odot\nabla\_{p}^{\mathcal{L}}$ to
calculate $\nabla^{\mathcal{L}}\_{\theta}=\nabla\_{\log p}^{\mathcal{L}}\nabla^{\log p}\_{\theta}$, where $\odot$ is the element-wise multiplication.
Typically the forward-backward with marginals is performed in the
log-space semifield $\mathbb{R}\cup\{\pm\infty\}$ with binary operations $\oplus=\logadd$ and $\otimes=+$ for numerical precision. However,
backpropagation requires working with the log of negative values (since $\nabla\_{p}^{\mathcal{L}}$ could be negative),
so we extend to a field $\left[\mathbb{R}\cup\{\pm\infty\}\right]\times\{+,-\}$ with special $+$/$-$
log-space operations. Binary operations applied to vectors are implied to be element-wise. The
$\signexp$ function is defined as $\signexp(l\_{a})=s\_{a}\exp(l\_{a})$.
See Section [3.3](#S3.SS3 "3.3 End-to-End Training ‣ 3 Structured Attention ‣ Structured Attention Networks") and Table [1](#S3.T1 "Table 1 ‣ 3.3 End-to-End Training ‣ 3 Structured Attention ‣ Structured Attention Networks") for more details.

Graphical models of this form have been widely used as the final layer
of deep models. Our contribution is to argue that these networks can
be added within deep networks in place of simple attention layers. The
whole model can then be trained end-to-end.

The main complication in utilizing this approach within the network
itself is the need to backpropagate the gradients through an inference algorithm as
part of the structured attention network. Past work has demonstrated
the techniques necessary for this approach (see [Stoyanov et al. (2011)](#bib.bib47)), but to our knowledge it
is very rarely employed.

Consider the case of the simple linear-chain CRF layer from equation ([3](#S3.E3 "In 3.1 Example 1: Subsequence Selection ‣ 3 Structured Attention ‣ Structured Attention Networks")).
Figure [2](#S3.F2 "Figure 2 ‣ 3.3 End-to-End Training ‣ 3 Structured Attention ‣ Structured Attention Networks") (left) shows the standard
forward-backward algorithm for computing the marginals $p(z\_{i}=1\,|\,x,q;\theta)$.
If we treat the forward-backward algorithm as a neural network layer, its input are the
potentials $\theta$, and its output after the forward pass are
these marginals.33
3
Confusingly, “forward” in this case is
different than in the forward-backward algorithm, as the marginals
themselves are the output. However the two uses of the term are
actually quite related. The forward-backward algorithm can be
interpreted as a forward and backpropagation pass on the log partition
function. See [Eisner (2016)](#bib.bib19) for further details
(appropriately titled “Inside-Outside and Forward-Backward
Algorithms Are Just Backprop”). As such our full approach can be
seen as computing second-order information. This interpretation is
central to [Li & Eisner (2009)](#bib.bib32). To backpropagate a loss through this
layer we need to compute the gradient of the loss $\mathcal{L}$ with respect to
$\theta$, $\nabla\_{\theta}^{\mathcal{L}}$, as a function of the gradient
of the loss with respect to the marginals, $\nabla\_{p}^{\mathcal{L}}$.44
4
In general
we use $\nabla^{a}\_{b}$ to denote the Jacobian of $a$ with respect to $b$. As the
forward-backward algorithm consists of differentiable steps, this
function can be derived using reverse-mode automatic differentiation
of the forward-backward algorithm itself. Note that this reverse-mode algorithm
conveniently has a parallel structure to the forward version, and can
also be implemented using dynamic programming.

|  |  | $\oplus$ | | $\otimes$ | |
| --- | --- | --- | --- | --- | --- |
| $s\_{a}$ | $s\_{b}$ | $l\_{a+b}$ | $s\_{a+b}$ | $l\_{a\cdot b}$ | $s\_{a\cdot b}$ |
| $+$ | $+$ | $l\_{a}+\log(1+d)$ | $+$ | $l\_{a}+l\_{b}$ | $+$ |
| $+$ | $-$ | $l\_{a}+\log(1-d)$ | $+$ | $l\_{a}+l\_{b}$ | $-$ |
| $-$ | $+$ | $l\_{a}+\log(1-d)$ | $-$ | $l\_{a}+l\_{b}$ | $-$ |
| $-$ | $-$ | $l\_{a}+\log(1+d)$ | $-$ | $l\_{a}+l\_{b}$ | $+$ |

Table 1:  Signed log-space semifield (from [Li & Eisner (2009)](#bib.bib32)). Each real number $a$
is represented as a pair $(l\_{a},s\_{a})$ where $l\_{a}=\log|a|$ and $s\_{a}=\sign(a)$.
Therefore $a=s\_{a}\exp(l\_{a})$. For the above we let $d=\exp(l\_{b}-l\_{a})$ and assume $|a|>|b|$.

However, in practice, one cannot simply use current off-the-shelf
tools for this task. For one, efficiency is quite important for these
models and so the benefits of hand-optimizing the reverse-mode
implementation still outweighs simplicity of automatic
differentiation. Secondly, numerical precision becomes a major issue
for structured attention networks. For computing the forward-pass and
the marginals, it is important to use the standard log-space semifield
over $\mathbb{R}\cup\{\pm\infty\}$ with binary operations
$(\oplus=\logadd,\otimes=+)$ to avoid underflow of probabilities. For computing
the backward-pass, we need to remain in log-space, but also handle
log of negative values (since $\nabla\_{p}^{\mathcal{L}}$ could be negative). This requires extending to the
signed log-space semifield over $\left[\mathbb{R}\cup\{\pm\infty\}\right]\times\{+,-\}$
with special $+$/$-$ operations. Table [1](#S3.T1 "Table 1 ‣ 3.3 End-to-End Training ‣ 3 Structured Attention ‣ Structured Attention Networks"), based on [Li & Eisner (2009)](#bib.bib32),
demonstrates how to handle this issue, and Figure [2](#S3.F2 "Figure 2 ‣ 3.3 End-to-End Training ‣ 3 Structured Attention ‣ Structured Attention Networks") (right)
describes backpropagation through the forward-backward algorithm.
For dependency parsing,
the forward pass can be computed using the
inside-outside implementation of Eisner’s algorithm
([Eisner, 1996](#bib.bib18)). Similarly, the backpropagation parallels the inside-outside
structure. Forward/backward pass through the inside-outside algorithm is
described in Appendix [B](#A2 "Appendix B Forward/Backward through the Inside-Outside Algorithm ‣ Structured Attention Networks").

## 4 Experiments

We experiment with three instantiations of structured attention networks on
four different tasks: (a) a simple, synthetic tree manipulation task using
the syntactic attention layer,
(b) machine translation with segmentation attention (i.e. two-state linear-chain CRF),
(c) question answering using an $n$-state linear-chain CRF for
multi-step inference over $n$ facts, and (d)
natural language inference with syntactic tree attention.
These experiments are not intended to boost the state-of-the-art for
these tasks but to test whether these methods can be trained
effectively in an end-to-end fashion, can yield improvements over
standard selection-based attention, and can learn plausible latent
structures. All model architectures, hyperparameters, and training details
are further described in Appendix [A](#A1 "Appendix A Model Details ‣ Structured Attention Networks").

### 4.1 Tree Transduction

The first set of experiments look at a tree-transduction task. These
experiments use synthetic data to explore a failure case of
soft-selection attention models. The task is to learn to convert a
random formula given in prefix notation to one in infix notation,
e.g.,

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle(\,\,\,\*\,\,\,(\,\,\,+\,\,\,(\,\,\,+\,\,\,15\,\,\,7\,\,\,)\,\,\,1\,\,\,8\,\,\,)\,\,\,(\,\,\,+\,\,\,19\,\,\,0\,\,\,11\,\,\,)\,\,\,)\,\,\Rightarrow(\,\,(\,\,15\,\,+\,\,7\,\,\,)\,\,+\,\,1\,\,+\,\,8\,\,\,)\,\,\*\,\,(\,\,\,19\,\,+\,\,0\,\,+\,\,11\,\,\,)$ |  |

The alphabet consists of symbols $\{(,),+,\*\}$, numbers between $0$
and $20$, and a special root symbol $\$$. This task is used
as a preliminary task to see if the model is able to learn the implicit
tree structure on the source side. The
model itself is an encoder-decoder model, where the encoder is defined below
and the decoder is an LSTM. See
Appendix [A.2](#A1.SS2 "A.2 Tree Transduction ‣ Appendix A Model Details ‣ Structured Attention Networks") for the full model.

Training uses $15$K prefix-infix pairs where the maximum nesting depth
is set to be between $2$-$4$ (the above example has depth $3$), with
$5$K pairs in each depth bucket. The number of expressions in each
parenthesis is limited to be at most $4$. Test uses $1$K unseen
sequences with depth between $2$-$6$ (note specifically deeper than
train), with $200$ sequences for each depth. The performance is
measured as the average proportion of correct target tokens produced
until the first failure (as in [Grefenstette et al. (2015)](#bib.bib23)).

For experiments we try using different forms of self-attention over embedding-only encoders.
Let $\mathbf{x}\_{j}$ be an embedding for each source symbol; our three
variants of the source representation $\hat{\mathbf{x}}\_{j}$ are: (a) no atten, just symbol
embeddings by themselves, i.e. $\hat{\mathbf{x}}\_{j}=\mathbf{x}\_{j}$; (b) simple attention, symbol
embeddings and soft-pairing for each symbol, i.e. $\hat{\mathbf{x}}\_{j}=[\mathbf{x}\_{j};\mathbf{c}\_{j}]$ where $\mathbf{c}\_{j}=\sum\_{i=1}^{n}\softmax(\theta\_{ij})\mathbf{x}\_{i}$ is calculated using soft-selection; (c)
structured attention, symbol embeddings and soft-parent,
i.e. $\hat{\mathbf{x}}\_{j}=[\mathbf{x}\_{j};\mathbf{c}\_{j}]$ where $\mathbf{c}\_{j}=\sum\_{i=1}^{n}p(z\_{ij}=1\,|\,x)\mathbf{x}\_{i}$ is
calculated using parsing marginals, obtained from the syntactic attention layer.
None of these models use an
explicit query value—the potentials come from running a bidirectional
LSTM over the source, producing hidden vectors $\mathbf{h}\_{i}$, and then computing

|  |  |  |
| --- | --- | --- |
|  | $\theta\_{ij}=\tanh(\mathbf{s}^{\top}\tanh(\mathbf{W}\_{1}\mathbf{h}\_{i}+\mathbf{W}\_{2}\mathbf{h}\_{j}+\mathbf{b}))$ |  |

where $\mathbf{s},\mathbf{b},\mathbf{W}\_{1},\mathbf{W}\_{2}$ are parameters (see Appendix [A.1](#A1.SS1 "A.1 Syntactic Attention ‣ Appendix A Model Details ‣ Structured Attention Networks")).

| Depth | No Atten | Simple | Structured |
| --- | --- | --- | --- |
| $2$ | $7.6$ | $87.4$ | $99.2$ |
| $3$ | $4.1$ | $49.6$ | $87.0$ |
| $4$ | $2.8$ | $23.3$ | $64.5$ |
| $5$ | $2.1$ | $15.0$ | $30.8$ |
| $6$ | $1.5$ | $8.5$ | $18.2$ |

Table 2:  Performance (average length to failure %) of models on the tree-transduction task.

Figure 3:  Visualization of the source self-attention distribution for the simple (left) and structured (right) attention
models on the tree transduction task. $\$$ is the special root symbol. Each row delineates the distribution
over the parents (i.e. each row sums to one). The attention distribution obtained from the parsing marginals
are more able to capture the tree structure—e.g. the attention weights of
closing parentheses are generally placed on the opening parentheses (though not necessarily on a single parenthesis).

The source representation $[\hat{\mathbf{x}}\_{1},\dots,\hat{\mathbf{x}}\_{n}]$ are attended over using the standard attention mechanism at each
decoding step by an LSTM decoder.55
5
Thus there are two attention mechanisms at work
under this setup. First, structured attention over the source only to obtain
soft-parents for each symbol (i.e. self-attention). Second, standard softmax alignment attention
over the source representations during decoding.
Additionally, symbol
embedding parameters are shared between the parsing LSTM and the source
encoder.

##### Results

Table [2](#S4.T2 "Table 2 ‣ 4.1 Tree Transduction ‣ 4 Experiments ‣ Structured Attention Networks") has the results for the task. Note that this task is
fairly difficult as the encoder is quite simple.
The baseline model (unsurprisingly) performs poorly
as it has no information about the source ordering. The simple attention model performs better, but is significantly outperformed by the structured model with a tree structure bias. We hypothesize that the model is partially reconstructing the arithmetic tree. Figure [3](#S4.F3 "Figure 3 ‣ 4.1 Tree Transduction ‣ 4 Experiments ‣ Structured Attention Networks") shows the attention distribution for the simple/structured models on
the same source sequence, which indicates that the structured model is able to learn boundaries (i.e. parentheses).

### 4.2 Neural Machine Translation

Our second set of experiments use a full neural machine translation
model utilizing attention over subsequences. Here both the encoder/decoder are LSTMs, and
we replace standard simple attention with a segmentation
attention layer. We experiment with two settings: translating directly from
unsegmented Japanese characters to English words (effectively using structured attention to perform soft word segmentation),
and translating from segmented Japanese words to English words (which can be interpreted as doing *phrase-based*
neural machine translation). Japanese word segmentation is done using
the KyTea toolkit ([Neubig et al., 2011](#bib.bib39)).

The data comes from the Workshop on Asian Translation (WAT) ([Nakazawa et al., 2016](#bib.bib38)).
We randomly pick $500$K sentences from the original training set (of $3$M sentences)
where the Japanese sentence was at most $50$ characters and the English sentence was at most
$50$ words. We apply the same length filter on the provided validation/test sets for evaluation.
The vocabulary consists of all tokens that occurred
at least $10$ times in the training corpus.

The segmentation attention layer is a two-state CRF where the unary potentials
at the $j$-th decoder step are parameterized as

|  |  |  |
| --- | --- | --- |
|  | $\theta\_{i}(k)=\begin{cases}\mathbf{h}\_{i}\mathbf{W}\mathbf{h}\_{j},&k=1\\ 0,&k=0\end{cases}$ |  |

Here $[\mathbf{h}\_{1},\dots,\mathbf{h}\_{n}]$ are the encoder hidden states and
$\mathbf{h}\_{j}^{\prime}$ is the $j$-th decoder hidden state (i.e. the query vector).
The pairwise potentials are
parameterized linearly with $\mathbf{b}$, i.e. all together

|  |  |  |
| --- | --- | --- |
|  | $\theta\_{i,i+1}(z\_{i},z\_{i+1})=\theta\_{i}(z\_{i})+\theta\_{i+1}(z\_{i+1})+\mathbf{b}\_{z\_{i},z\_{i+1}}$ |  |

Therefore the segmentation attention layer requires
just $4$ additional parameters. Appendix [A.3](#A1.SS3 "A.3 Neural Machine Translation ‣ Appendix A Model Details ‣ Structured Attention Networks") describes the full model
architecture.

We experiment with three attention configurations: (a)
standard simple attention, i.e.
$\mathbf{c}\_{j}=\sum\_{i=1}^{n}\softmax(\theta\_{i})\mathbf{h}\_{i}$; (b)
sigmoid attention: multiple selection with Bernoulli random variables,
i.e. $\mathbf{c}\_{j}=\sum\_{i=1}^{n}\sigmoid(\theta\_{i})\mathbf{h}\_{i}$; (c)
structured attention, encoded with normalized CRF marginals,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbf{c}\_{j}=\sum\_{i=1}^{n}\frac{p(z\_{i}=1\,|\,x,q)}{\gamma}\mathbf{h}\_{i}$ |  | $\displaystyle\gamma=\frac{1}{\lambda}\sum\_{i=1}^{n}p(z\_{i}=1\,|\,x,q)$ |  |

The normalization term $\gamma$ is not ideal but we found it to be helpful for stable
training.66
6
With standard expectation (i.e. $\mathbf{c}\_{j}=\sum\_{i=1}^{n}p(z\_{i}=1\,|\,x,q)\mathbf{h}\_{i}$)
we empirically observed the marginals to quickly saturate.
We tried various strategies to overcome this, such as putting an $l\_{2}$ penalty on the unary potentials and initializing
with a pretrained sigmoid attention model, but simply normalizing the marginals proved to be the most effective.
However, this changes the interpretation of the context vector as the expectation of an annotation function in this case.
$\lambda$ is a hyperparameter (we use $\lambda=2$) and we
further add an $l\_{2}$ penalty of $0.005$ on the pairwise potentials $\mathbf{b}$. These values
were found via grid search on the validation set.

|  | Simple | Sigmoid | Structured |
| --- | --- | --- | --- |
| Char | $12.6$ | $13.1$ | $14.6$ |
| Word | $14.1$ | $13.8$ | $14.3$ |

Table 3: Translation performance as measured by BLEU (higher is better)
on character-to-word and word-to-word Japanese-English translation for the three different models.

##### Results

Results for the translation task on the test set are given in
Table [3](#S4.T3 "Table 3 ‣ 4.2 Neural Machine Translation ‣ 4 Experiments ‣ Structured Attention Networks").
Sigmoid attention outperforms simple (softmax) attention
on the character-to-word task, potentially because it is able to learn many-to-one alignments.
On the word-to-word task, the opposite is true, with simple attention outperforming sigmoid attention.
Structured attention outperforms both models on both tasks, although improvements on the word-to-word
task are modest and unlikely to be statistically significant.

For further analysis, Figure [4](#S4.F4 "Figure 4 ‣ Results ‣ 4.2 Neural Machine Translation ‣ 4 Experiments ‣ Structured Attention Networks") shows a visualization of
the different attention mechanisms on the character-to-word setup. The simple model generally focuses attention heavily
on a single character. In contrast, the sigmoid and structured models are able to
spread their attention distribution on contiguous subsequences.
The structured attention learns additional parameters (i.e. $\mathbf{b}$) to smooth out this type of attention.

Figure 4:  Visualization of the source attention distribution for the simple (top left), sigmoid (top right), and structured (bottom left) attention
models over the ground truth sentence on the character-to-word translation task. Manually-annotated alignments are shown in
bottom right. Each row delineates the attention weights over the source sentence at each step of
decoding. The sigmoid/structured attention models are able learn an implicit segmentation model
and focus on multiple characters at each time step.

### 4.3 Question Answering

Our third experiment is on question answering (QA) with the linear-chain CRF attention layer for
inference over multiple facts.
We use the bAbI dataset ([Weston et al., 2015](#bib.bib53)), where the input is a set of sentences/facts paired
with a question, and the answer is a single token. For many of the tasks the model has
to attend to multiple supporting facts to arrive at the correct answer (see Figure [5](#S4.F5 "Figure 5 ‣ Results ‣ 4.3 Question Answering ‣ 4 Experiments ‣ Structured Attention Networks") for an example),
and existing approaches use multiple ‘hops’ to greedily attend to different facts.
We experiment with employing structured attention to perform inference in a non-greedy way.
As the ground truth supporting facts are given in the dataset, we are able to assess the model’s inference accuracy.

The baseline (simple) attention model is the End-To-End Memory Network ([Sukhbaatar et al., 2015](#bib.bib48)) (MemN2N),
which we briefly describe here. See Appendix [A.4](#A1.SS4 "A.4 Question Answering ‣ Appendix A Model Details ‣ Structured Attention Networks") for full model details.
Let $\mathbf{x}\_{1},\dots,\mathbf{x}\_{n}$ be the input embedding vectors for the $n$ sentences/facts and let
$\mathbf{q}$ be the
query embedding. In MemN2N, $z\_{k}$ is the random variable for the sentence to
select at the $k$-th inference step (i.e. $k$-th hop), and thus $z\_{k}\in\{1,\dots,n\}$.
The probability distribution over $z\_{k}$ is given by
$p(z\_{k}=i\,|\,x,q)=\softmax((\mathbf{x}\_{i}^{k})^{\top}\mathbf{q}^{k})$, and the context vector is given by
$\mathbf{c}^{k}=\sum\_{i=1}^{n}p(z\_{k}=i\,|\,x,q)\mathbf{o}\_{i}^{k}$, where $\mathbf{x}\_{i}^{k},\mathbf{o}\_{i}^{k}$ are the
input and output embedding for the $i$-th sentence at the $k$-th hop, respectively.
The $k$-th context vector is used to modify the query $\mathbf{q}^{k+1}=\mathbf{q}^{k}+\mathbf{c}^{k}$, and this
process repeats for $k=1,\dots,K$ (for $k=1$ we have $\mathbf{x}\_{i}^{k}=\mathbf{x}\_{i},\mathbf{q}^{k}=\mathbf{q},\mathbf{c}^{k}=\mathbf{0}$).
The $K$-th context and query vectors are used to obtain the final answer.
The attention mechanism for a
$K$-hop MemN2N network can therefore be interpreted as a greedy selection of a length-$K$
sequence of facts (i.e. $z\_{1},\dots,z\_{K}$).

For structured attention, we use an $n$-state, $K$-step linear-chain CRF.77
7
Note that this
differs from the segmentation attention for the neural machine translation experiments described above, which was a $K$-state (with $K=2$), $n$-step linear-chain CRF.
We experiment with two
different settings: (a) a unary CRF model with node potentials

|  |  |  |
| --- | --- | --- |
|  | $\theta\_{k}(i)=(\mathbf{x}\_{i}^{k})^{\top}\mathbf{q}^{k}$ |  |

and (b)
a binary CRF model with pairwise potentials

|  |  |  |
| --- | --- | --- |
|  | $\theta\_{k,k+1}(i,j)=(\mathbf{x}\_{i}^{k})^{\top}\mathbf{q}^{k}+(\mathbf{x}\_{i}^{k})^{\top}\mathbf{x}\_{j}^{k+1}+(\mathbf{x}\_{j}^{k+1})^{\top}\mathbf{q}^{k+1}$ |  |

The binary CRF model is designed to test the model’s ability to perform sequential reasoning.
For both (a) and (b), a *single* context vector is computed:
$\mathbf{c}=\sum\_{z\_{1},\ldots,z\_{K}}p(z\_{1},\ldots,z\_{K}\,|\,x,q)f(x,z)$ (unlike
MemN2N which computes $K$ context vectors). Evaluating $\mathbf{c}$
requires summing over all $n^{K}$ possible sequences of length $K$, which may not be
practical for large values of $K$. However, if $f(x,z)$ factors over the components of $z$
(e.g. $f(x,z)=\sum\_{k=1}^{K}f\_{k}(x,z\_{k})$) then one can rewrite the above sum in terms of marginals:
$\mathbf{c}=\sum\_{k=1}^{K}\sum\_{i=1}^{n}p(z\_{k}=i\,|\,x,q)f\_{k}(x,z\_{k})$. In our experiments, we use
$f\_{k}(x,z\_{k})=\mathbf{o}\_{z\_{k}}^{k}$. All three models are
described in further detail in Appendix [A.4](#A1.SS4 "A.4 Question Answering ‣ Appendix A Model Details ‣ Structured Attention Networks").

|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | MemN2N | | Binary CRF | | Unary CRF | |
| Task | $K$ | Ans $\%$ | Fact $\%$ | Ans $\%$ | Fact $\%$ | Ans $\%$ | Fact $\%$ |
| Task 02 - Two Supporting Facts | 2 | $87.3$ | $46.8$ | $84.7$ | $81.8$ | $43.5$ | $22.3$ |
| Task 03 - Three Supporting Facts | 3 | $52.6$ | $1.4$ | $40.5$ | $0.1$ | $28.2$ | $0.0$ |
| Task 07 - Counting | 3 | $83.2$ | $-$ | $83.5$ | $-$ | $79.3$ | $-$ |
| Task 08 - Lists Sets | 3 | $94.1$ | $-$ | $93.3$ | $-$ | $87.1$ | $-$ |
| Task 11 - Indefinite Knowledge | 2 | $97.8$ | $38.2$ | $97.7$ | $80.8$ | $88.6$ | $0.0$ |
| Task 13 - Compound Coreference | 2 | $95.6$ | $14.8$ | $97.0$ | $36.4$ | $94.4$ | $9.3$ |
| Task 14 - Time Reasoning | 2 | $99.9$ | $77.6$ | $99.7$ | $98.2$ | $90.5$ | $30.2$ |
| Task 15 - Basic Deduction | 2 | $100.0$ | $59.3$ | $100.0$ | $89.5$ | $100.0$ | $51.4$ |
| Task 16 - Basic Induction | 3 | $97.1$ | $91.0$ | $97.9$ | $85.6$ | $98.0$ | $41.4$ |
| Task 17 - Positional Reasoning | 2 | $61.1$ | $23.9$ | $60.6$ | $49.6$ | $59.7$ | $10.5$ |
| Task 18 - Size Reasoning | 2 | $86.4$ | $3.3$ | $92.2$ | $3.9$ | $92.0$ | $1.4$ |
| Task 19 - Path Finding | 2 | $21.3$ | $10.2$ | $24.4$ | $11.5$ | $24.3$ | $7.8$ |
| Average | $-$ | $81.4$ | $39.6$ | $81.0$ | $53.7$ | $73.8$ | $17.4$ |

Table 4:  Answer accuracy (Ans $\%$) and supporting fact selection accuracy (Fact $\%$)
of the three QA models on the $1$K bAbI dataset. $K$ indicates the number of hops/inference steps used for each task.
Task 7 and 8 both contain variable number of facts and hence they are excluded from the fact accuracy
measurement. Supporting fact selection accuracy is calculated by taking the average of $10$ best
runs (out of $20$) for each task.

##### Results

We use the version of the dataset with $1$K questions for each task.
Since all models reduce to the same network for tasks with $1$ supporting fact, they are excluded from our experiments.
The number of hops (i.e. $K$) is task-dependent, and the number of memories (i.e. $n$) is limited to be at most $25$ (note
that many question have less than $25$ facts—e.g. the example in Figure [5](#S4.F5 "Figure 5 ‣ Results ‣ 4.3 Question Answering ‣ 4 Experiments ‣ Structured Attention Networks") has $9$ facts).
Due to high variance in model performance, we train $20$ models with different initializations for each task and report the
test accuracy of the model that performed the best on a $10\%$ held-out validation set
(as is typically done for bAbI tasks).

Figure 5:  Visualization of the attention distribution over supporting fact sequences for an example question in task $16$ for the Binary CRF model.
The actual question is displayed at the bottom along with the correct answer and the ground truth supporting facts ($5\rightarrow 6\rightarrow 8$).
The edges represent the marginal probabilities $p(z\_{k},z\_{k+1}\,|\,x,q)$, and the nodes represent the $n$ supporting facts (here we have $n=9$).
The text for the supporting facts are shown on the left. The top three most likely sequences are:
$p(z\_{1}=5,z\_{2}=6,z\_{3}=8\,|\,x,q)=0.0564,p(z\_{1}=5,z\_{2}=6,z\_{3}=3\,|\,x,q)=0.0364,p(z\_{1}=5,z\_{2}=2,z\_{3}=3\,|\,x,q)=0.0356$.

Results of the three different models are shown in Table [4](#S4.T4 "Table 4 ‣ 4.3 Question Answering ‣ 4 Experiments ‣ Structured Attention Networks").
For correct answer seletion (Ans $\%$), we find that MemN2N and the Binary CRF model
perform similarly while the Unary CRF model does worse, indicating the importance
of including pairwise potentials. We also assess each model’s ability to attend to the correct supporting facts in
Table [4](#S4.T4 "Table 4 ‣ 4.3 Question Answering ‣ 4 Experiments ‣ Structured Attention Networks") (Fact $\%$).
Since ground truth supporting facts are provided for each query, we can check the sequence accuracy of supporting facts
for each model
(i.e. the rate of selecting the exact correct sequence of facts) by taking the highest probability sequence
$\hat{z}=\argmax p(z\_{1},\dots,z\_{K}\,|\,x,q)$ from the model and checking against the ground truth.
Overall the Binary CRF is able to recover supporting facts better than MemN2N. This improvement
is significant and can be up to two-fold as seen for task $2$, $11$, $13$ & $17$.
However we observed that on many tasks it is sufficient to select only the last (or first) fact correctly to
predict the answer,
and thus higher sequence selection accuracy does not necessarily imply better answer accuracy (and vice versa).
For example, all three models get $100\%$ answer accuracy on task $15$ but have different supporting fact accuracies.

Finally, in Figure [5](#S4.F5 "Figure 5 ‣ Results ‣ 4.3 Question Answering ‣ 4 Experiments ‣ Structured Attention Networks") we visualize of the output
edge marginals produced by the Binary CRF model for a single question in task $16$. In this instance, the model
is uncertain but ultimately able to select the right sequence of facts $5\rightarrow 6\rightarrow 8$.

### 4.4 Natural Language Inference

The final experiment looks at the task of natural language inference
(NLI) with the syntactic attention layer. In NLI, the model is given two sentences (hypothesis/premise)
and has to predict their relationship: entailment, contradiction,
neutral.

For this task, we use the Stanford NLI dataset ([Bowman et al., 2015](#bib.bib5)) and model
our approach off of the decomposable attention model of
[Parikh et al. (2016)](#bib.bib40). This model
takes in the matrix of word embeddings as the input for each sentence and performs inter-sentence
attention to predict the answer.
Appendix [A.5](#A1.SS5 "A.5 Natural Language Inference ‣ Appendix A Model Details ‣ Structured Attention Networks") describes the full model.

As in the transduction task, we focus on modifying the input representation
to take into account soft parents via self-attention (i.e. intra-sentence attention).
In addition to the three baselines
described for tree transduction (No Attention, Simple, Structured), we
also explore two additional settings: (d) hard pipeline parent selection,
i.e. $\hat{\mathbf{x}}\_{j}=[\mathbf{x}\_{j};\mathbf{x}\_{\head(j)}]$,
where $\head(j)$ is the index of $x\_{j}$’s parent88
8
The parents are obtained from running the
dependency parser of [Andor et al. (2016)](#bib.bib1), available at
  
https://github.com/tensorflow/models/tree/master/syntaxnet;
(e) pretrained structured attention: structured attention where the parsing layer is
pretrained for one epoch on a parsed dataset (which was enough for convergence).

| Model | Accuracy $\%$ |
| --- | --- |
| Handcrafted features ([Bowman et al., 2015](#bib.bib5)) | $78.2$ |
| LSTM encoders ([Bowman et al., 2015](#bib.bib5)) | $80.6$ |
| Tree-Based CNN ([Mou et al., 2016](#bib.bib36)) | $82.1$ |
| Stack-Augmented Parser-Interpreter Neural Net ([Bowman et al., 2016](#bib.bib6)) | $83.2$ |
| LSTM with word-by-word attention ([Rocktäschel et al., 2016](#bib.bib43)) | $83.5$ |
| Matching LSTMs ([Wang & Jiang, 2016](#bib.bib51)) | $86.1$ |
| Decomposable attention over word embeddings ([Parikh et al., 2016](#bib.bib40)) | $86.3$ |
| Decomposable attention $+$ intra-sentence attention ([Parikh et al., 2016](#bib.bib40)) | $86.8$ |
| Attention over constituency tree nodes ([Zhao et al., 2016](#bib.bib57)) | $87.2$ |
| Neural Tree Indexers ([Munkhdalai & Yu, 2016](#bib.bib37)) | $87.3$ |
| Enhanced BiLSTM Inference Model ([Chen et al., 2016](#bib.bib9)) | $87.7$ |
| Enhanced BiLSTM Inference Model $+$ ensemble ([Chen et al., 2016](#bib.bib9)) | $88.3$ |
| No Attention | $85.8$ |
| No Attention + Hard parent | $86.1$ |
| Simple Attention | $86.2$ |
| Structured Attention | $86.8$ |
| Pretrained Structured Attention | $86.5$ |

Table 5:  Results of our models (bottom) and others (top) on the Stanford NLI test set.
Our baseline model has the same architecture as [Parikh et al. (2016)](#bib.bib40) but the performance is
slightly different due to different settings (e.g. we train for $100$ epochs
with a batch size of $32$ while [Parikh et al. (2016)](#bib.bib40) train for
$400$ epochs with a batch size of $4$ using asynchronous SGD.)

##### Results

Results of our models are shown in Table [5](#S4.T5 "Table 5 ‣ 4.4 Natural Language Inference ‣ 4 Experiments ‣ Structured Attention Networks"). Simple attention improves upon the no attention model, and this is
consistent with improvements observed by [Parikh et al. (2016)](#bib.bib40) with their intra-sentence attention model. The pipelined model with
hard parents also slightly improves upon the baseline. Structured attention outperforms both models, though surprisingly, pretraining the syntactic attention
layer on the parse trees performs worse than training it from scratch—it is possible that the
pretrained attention is too strict for this task.

We also obtain the hard parse for an example sentence by running the
Viterbi algorithm on the syntactic attention layer with the non-pretrained model:

Despite being trained without ever being exposed to an explicit parse tree, the syntactic attention
layer learns an almost plausible dependency structure. In the above example it is able to correctly
identify the main verb fighting, but makes mistakes on determiners
(e.g. head of The should be men). We generally observed this pattern across sentences,
possibly because the verb structure is more important for the inference task.

## 5 Conclusion

This work outlines structured attention networks, which incorporate
graphical models to generalize simple attention, and describes the
technical machinery and computational techniques for backpropagating
through models of this form. We implement two classes of structured
attention layers: a linear-chain CRF (for neural machine translation
and question answering) and a more complicated first-order dependency
parser (for tree transduction and natural language inference). Experiments show that this method can learn interesting
structural properties and improve on top of standard models.
Structured attention could also be a way of learning latent labelers or parsers through
attention on other tasks.

It should be noted that the
additional complexity in computing the attention distribution
increases run-time—for example,
structured attention was approximately $5\times$ slower
to train than simple attention for the neural machine translation
experiments, even though both attention layers have the same asymptotic run-time (i.e. $O(n)$).

Embedding differentiable inference (and more generally, differentiable algorithms)
into deep models is an exciting
area of research. While we have focused on models that admit
(tractable) exact inference, similar technique can be used to embed
approximate inference methods.
Many optimization algorithms (e.g. gradient descent, LBFGS) are also differentiable ([Domke, 2012](#bib.bib15); [Maclaurin et al., 2015](#bib.bib35)),
and have been used as output layers for structured prediction in energy-based models
([Belanger & McCallum, 2016](#bib.bib4); [Wang et al., 2016](#bib.bib50)).
Incorporating them as internal neural network layers is an interesting avenue for future work.

#### Acknowledgments

We thank Tao Lei, Ankur Parikh, Tim Vieira, Matt Gormley, André Martins, Jason Eisner, Yoav Goldberg, and the anonymous reviewers
for helpful comments, discussion, notes, and code. We additionally thank Yasumasa Miyamoto for verifying Japanese-English translations.

## APPENDICES

## Appendix A Model Details

### A.1 Syntactic Attention

The syntactic attention layer (for tree transduction and natural language inference) is similar to the first-order graph-based
dependency parser of [Kipperwasser & Goldberg (2016)](#bib.bib27).
Given an input sentence $[x\_{1},\dots,x\_{n}]$ and the corresponding word vectors
$[\mathbf{x}\_{1},\dots,\mathbf{x}\_{n}]$, we use a bidirectional LSTM
to get the hidden states for each time step $i\in[1,\dots,n]$,

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbf{h}\_{i}^{\text{fwd}}=\lstm(\mathbf{x}\_{i},\mathbf{h}\_{i-1}^{\text{fwd}})$ |  | $\displaystyle\mathbf{h}\_{i}^{\text{bwd}}=\lstm(\mathbf{x}\_{i},\mathbf{h}\_{i+1}^{\text{bwd}})$ |  | $\displaystyle\mathbf{h}\_{i}=[\mathbf{h}\_{i}^{\text{fwd}};\mathbf{h}\_{i}^{\text{bwd}}]$ |  |

where the forward and backward LSTMs have their own parameters. The score for
$x\_{i}\rightarrow x\_{j}$ (i.e. $x\_{i}$ is the parent of $x\_{j}$), is given by an MLP

|  |  |  |
| --- | --- | --- |
|  | $\theta\_{ij}=\tanh(\mathbf{s}^{\top}\tanh(\mathbf{W}\_{1}\mathbf{h}\_{i}+\mathbf{W}\_{2}\mathbf{h}\_{j}+\mathbf{b}))$ |  |

These scores are used as input to the inside-outside algorithm (see Appendix [B](#A2 "Appendix B Forward/Backward through the Inside-Outside Algorithm ‣ Structured Attention Networks"))
to obtain the probability
of each word’s parent $p(z\_{ij}=1\,|\,x)$, which is used to obtain the
soft-parent $\mathbf{c}\_{j}$ for each word $x\_{j}$. In the non-structured case
we simply have $p(z\_{ij}=1\,|\,x)=\softmax(\theta\_{ij})$.

### A.2 Tree Transduction

Let $[x\_{1},\dots,x\_{n}],[y\_{1},\dots,y\_{m}]$ be the sequence of source/target
symbols, with the associated embeddings $[\mathbf{x}\_{1},\dots,\mathbf{x}\_{n}],[\mathbf{y}\_{1},\dots,\mathbf{y}\_{m}]$ with $\mathbf{x}\_{i},\mathbf{y}\_{j}\in\mathbb{R}^{l}$. In the simplest baseline
model we take the source representation to be the matrix of the
symbol embeddings. The decoder is a one-layer LSTM which produces the hidden states
$\mathbf{h}\_{j}^{\prime}=\lstm(\mathbf{y}\_{j},\mathbf{h}\_{j-1}^{\prime})$, with $\mathbf{h}\_{j}^{\prime}\in\mathbb{R}^{l}$.
The hidden states are combined with the input representation via a bilinear map
$\mathbf{W}\in\mathbb{R}^{l\times l}$ to produce the attention distribution
used to obtain the vector $\mathbf{m}\_{i}$, which is combined with the decoder hidden state
as follows,

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\alpha\_{i}=\frac{\exp\mathbf{x}\_{i}\mathbf{W}\mathbf{h}\_{j}^{\prime}}{\sum\_{k=1}^{n}\exp\mathbf{x}\_{k}\mathbf{W}\mathbf{h}\_{j}^{\prime}}$ |  | $\displaystyle\mathbf{m}\_{i}=\sum\_{i=1}^{n}\alpha\_{i}\mathbf{x}\_{i}$ |  | $\displaystyle\hat{\mathbf{h}}\_{j}=\tanh(\mathbf{U}[\mathbf{m}\_{i};\mathbf{h}\_{j}^{\prime}])$ |  |

Here we have $\mathbf{W}\in\mathbb{R}^{l\times l}$ and $\mathbf{U}\in\mathbb{R}^{2l\times l}$. Finally, $\hat{\mathbf{h}}\_{j}$ is used to to obtain a distribution
over the next symbol $y\_{j+1}$,

|  |  |  |
| --- | --- | --- |
|  | $p(y\_{j+1}\,|\,x\_{1},\dots,x\_{n},y\_{1},\dots,y\_{j})=\softmax(\mathbf{V}\hat{\mathbf{h}}\_{j}+\mathbf{b})$ |  |

For structured/simple models, the $j$-th source representation are respectively

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\hat{\mathbf{x}}\_{i}=\left[\mathbf{x}\_{i};\sum\_{k=1}^{n}p(z\_{ki}=1\,|\,x)\,\mathbf{x}\_{k}\right]$ |  | $\displaystyle\hat{\mathbf{x}}\_{i}=\left[\mathbf{x}\_{i};\sum\_{k=1}^{n}\softmax(\theta\_{ki})\,\mathbf{x}\_{k}\right]$ |  |

where $\theta\_{ij}$ comes from the bidirectional LSTM described in [A.1](#A1.SS1 "A.1 Syntactic Attention ‣ Appendix A Model Details ‣ Structured Attention Networks").
Then $\alpha\_{i}$ and $\mathbf{m}\_{i}$ changed accordingly,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\alpha\_{i}=\frac{\exp\hat{\mathbf{x}}\_{i}\mathbf{W}\mathbf{h}\_{j}^{\prime}}{\sum\_{k=1}^{n}\exp\hat{\mathbf{x}}\_{k}\mathbf{W}\mathbf{h}\_{j}^{\prime}}$ |  | $\displaystyle\mathbf{m}\_{i}=\sum\_{i=1}^{n}\alpha\_{i}\hat{\mathbf{x}}\_{i}$ |  |

Note that in this case we have $\mathbf{W}\in\mathbb{R}^{2l\times l}$ and $\mathbf{U}\in\mathbb{R}^{3l\times l}$.
We use $l=50$ in all our experiments. The forward/backward LSTMs for the parsing LSTM
are also $50$-dimensional. Symbol embeddings are shared between the encoder and the parsing LSTMs.

Additional training details include: batch size of $20$; training for
$13$ epochs with a learning rate of $1.0$, which starts decaying by half after epoch $9$
(or the epoch at which performance does not improve on validation, whichever comes first);
parameter initialization over a uniform distribution $U[-0.1,0.1]$; gradient normalization at $1$
(i.e. renormalize the gradients to have norm $1$ if the $l\_{2}$ norm exceeds $1$). Decoding
is done with beam search (beam size $=5$).

### A.3 Neural Machine Translation

The baseline NMT system is from [Luong et al. (2015)](#bib.bib34).
Let $[x\_{1},\dots,x\_{n}],[y\_{1},\dots,y\_{m}]$ be the
source/target sentence, with the associated word embeddings $[\mathbf{x}\_{1},\dots,\mathbf{x}\_{n}],[\mathbf{y}\_{1},\dots,\mathbf{y}\_{m}]$.
The encoder is an LSTM over the source sentence, which produces the hidden states $[\mathbf{h}\_{1},\dots,\mathbf{h}\_{n}]$
where

|  |  |  |
| --- | --- | --- |
|  | $\mathbf{h}\_{i}=\lstm(\mathbf{x}\_{i},\mathbf{h}\_{i-1})$ |  |

and $\mathbf{h}\_{i}\in\mathbb{R}^{l}$.
The decoder is another LSTM
which produces the hidden states $\mathbf{h}\_{j}^{\prime}\in\mathbb{R}^{l}$.
In the simple attention case with categorical attention, the hidden states
are combined with the input representation via a bilinear map
$\mathbf{W}\in\mathbb{R}^{l\times l}$ and this distribution is used to obtain the context vector
at the $j$-th time step,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\theta\_{i}=\mathbf{h}\_{i}\mathbf{W}\mathbf{h}\_{j}^{\prime}$ |  | $\displaystyle\mathbf{c}\_{j}=\sum\_{i=1}^{n}\softmax(\theta\_{i})\mathbf{h}\_{i}$ |  |

The Bernoulli attention network has the same $\theta\_{i}$ but instead uses a $\sigmoid$ to obtain the weights of the linear combination, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\mathbf{c}\_{j}=\sum\_{i=1}^{n}\sigmoid(\theta\_{i})\mathbf{h}\_{i}$ |  |

And finally, the structured attention model uses a bilinear map to parameterize one of the unary potentials

|  |  |  |
| --- | --- | --- |
|  | $\theta\_{i}(k)=\begin{cases}\mathbf{h}\_{i}\mathbf{W}\mathbf{h}\_{j}^{\prime},&k=1\\ 0,&k=0\end{cases}$ |  |

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\theta\_{i,i+1}(z\_{i},z\_{i+1})$ | $\displaystyle=\theta\_{i}(z\_{i})+\theta\_{i+1}(z\_{i+1})+\mathbf{b}\_{z\_{i},z\_{i+1}}$ |  |

where $\mathbf{b}$ are the pairwise potentials.
These potentials are used as inputs to the forward-backward algorithm to obtain the marginals $p(z\_{i}=1\,|\,x,q)$,
which are further normalized to obtain the context vector

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbf{c}\_{j}=\sum\_{i=1}^{n}\frac{p(z\_{i}=1\,|\,x,q)}{\gamma}\mathbf{h}\_{i}$ |  | $\displaystyle\gamma=\frac{1}{\lambda}\sum\_{i}^{n}p(z\_{i}=1\,|\,x,q)$ |  |

We use $\lambda=2$ and also add an $l\_{2}$ penalty of $0.005$ on the pairwise potentials $\mathbf{b}$.
The context vector is then combined with the decoder hidden state

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\hat{\mathbf{h}}\_{j}=\tanh(\mathbf{U}[\mathbf{c}\_{j};\mathbf{h}\_{j}^{\prime}])$ |  |

and $\hat{\mathbf{h}}\_{j}$ is used to obtain the distribution over the next target word $y\_{j+1}$

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle p(y\_{j+1}\,|\,x\_{1},\dots,x\_{n},y\_{1},\dots y\_{j})=\softmax(\mathbf{V}\hat{\mathbf{h}}\_{j}+\mathbf{b})$ |  |

The encoder/decoder LSTMs have $2$ layers and $500$ hidden units (i.e. $l=500$).

Additional training details include: batch size of $128$; training for
$30$ epochs with a learning rate of $1.0$, which starts decaying by half
after the first epoch at which performance does not improve on validation;
dropout with probability $0.3$;
parameter initialization over a uniform distribution $U[-0.1,0.1]$; gradient normalization at $1$.
We generate target translations with beam search (beam size $=5$), and evaluate with multi-bleu.perl from Moses.99
9
https://github.com/moses-smt/mosesdecoder/blob/master/scripts/generic/multi-bleu.perl

### A.4 Question Answering

Our baseline model (MemN2N) is implemented following the same architecture as described in [Sukhbaatar et al. (2015)](#bib.bib48). In particular,
let $x=[x\_{1},\dots,x\_{n}]$ represent the sequence of $n$ facts with the associated embeddings $[\mathbf{x}\_{1},\dots,\mathbf{x}\_{n}]$
and let $\mathbf{q}$ be the embedding of the query $q$. The
embeddings are obtained by simply adding the word embeddings in each sentence or query.
The full model with $K$ hops is as follows:

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle p(z\_{k}=i\,|\,x,q)=\softmax((\mathbf{x}\_{i}^{k})^{\top}\mathbf{q}^{k})$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\mathbf{c}^{k}=\sum\_{i=1}^{n}p(z\_{k}=i\,|\,x,q)\mathbf{o}\_{i}^{k}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\mathbf{q}^{k+1}=\mathbf{q}^{k}+\mathbf{c}^{k}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle p(y\,|\,x,q)=\softmax(\mathbf{W}(\mathbf{q}^{K}+\mathbf{c}^{K}))$ |  |

where $p(y\,|\,x,q)$ is the distribution over the answer vocabulary. At each layer, $\{\mathbf{x}\_{i}^{k}\}$ and $\{\mathbf{o}\_{i}^{k}\}$
are computed using embedding matrices $\mathbf{X}^{k}$ and $\mathbf{O}^{k}$. We use the *adjacent weight tying scheme* from the paper
so that $\mathbf{X}^{k+1}=\mathbf{O}^{k},\mathbf{W}^{T}=\mathbf{O}^{K}$. $\mathbf{X}^{1}$ is also used to compute the query embedding at the first hop.
For $k=1$ we have $\mathbf{x}\_{i}^{k}=\mathbf{x}\_{i},\mathbf{q}^{k}=\mathbf{q},\mathbf{c}^{k}=\mathbf{0}$.

For both the Unary and the Binary CRF models, the same input fact and query representations are computed (i.e. same embedding matrices
with weight tying scheme). For the unary model, the potentials are parameterized as

|  |  |  |
| --- | --- | --- |
|  | $\theta\_{k}(i)=(\mathbf{x}\_{i}^{k})^{\top}\mathbf{q}^{k}$ |  |

and for the binary model we compute pairwise potentials as

|  |  |  |
| --- | --- | --- |
|  | $\theta\_{k,k+1}(i,j)=(\mathbf{x}\_{i}^{k})^{\top}\mathbf{q}^{k}+(\mathbf{x}\_{i}^{k})^{\top}\mathbf{x}\_{j}^{k+1}+(\mathbf{x}\_{j}^{k+1})^{\top}\mathbf{q}^{k+1}$ |  |

The $\mathbf{q}^{k}$’s are updated simply with a linear mapping, i.e.

|  |  |  |
| --- | --- | --- |
|  | $\mathbf{q}^{k+1}=\mathbf{Q}\mathbf{q}^{k}$ |  |

In the case of the Binary CRF, to discourage the model from selecting the same fact again we additionally set $\theta\_{k,k+1}(i,i)=-\infty$ for all $i\in\{1,\dots,n\}$.
Given these potentials, we compute the marginals $p(z\_{k}=i,z\_{k+1}=j\,|\,x,q)$ using the forward-backward algorithm, which is then used to compute the context vector:

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | $\displaystyle\mathbf{c}=\sum\_{z\_{1},\ldots,z\_{K}}p(z\_{1},\ldots,z\_{K}\,|\,x,q)f(x,z)$ |  | $\displaystyle f(x,z)=\sum\_{k=1}^{K}f\_{k}(x,z\_{k})$ |  | $\displaystyle f\_{k}(x,z\_{k})=\mathbf{o}\_{z\_{k}}^{k}$ |  |

Note that if $f(x,z)$ factors over the components of $z$ (as is the case above) then computing $\mathbf{c}$ only requires evaluating the marginals
$p(z\_{k}\,|\,x,q)$.

Finally, given the context vector the prediction is made in a similar fashion to MemN2N:

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle p(y\,|\,x,q)=\softmax(\mathbf{W}(\mathbf{q}^{K}+\mathbf{c}))$ |  |

Other training setup is similar to [Sukhbaatar et al. (2015)](#bib.bib48): we use stochastic gradient descent with
learning rate $0.01$, which is divided by $2$ every $25$ epochs until $100$ epochs are reached. Capacity of
the memory is limited to $25$ sentences. The embedding vectors are of size $20$ and gradients are renormalized
if the norm exceeds $40$. All models implement *position encoding*, *temporal encoding*, and *linear start* from
the original paper. For linear start, the $\softmax(\cdot)$ function in the attention layer
is removed at the beginning and re-inserted after $20$ epochs for MemN2N, while for the CRF models we apply a $\log(\softmax(\cdot))$
layer on the $\mathbf{q}^{k}$ after $20$ epochs. Each model is trained separately for each task.

### A.5 Natural Language Inference

Our baseline model/setup is essentially the same as that of [Parikh et al. (2016)](#bib.bib40). Let $[x\_{1},\dots,x\_{n}],[y\_{1},\dots,y\_{m}]$
be the premise/hypothesis, with the corresponding
input representations $[\mathbf{x}\_{1},\dots,\mathbf{x}\_{n}],[\mathbf{y}\_{1},\dots,\mathbf{y}\_{m}]$.
The input representations are obtained by a linear transformation of the $300$-dimensional pretrained GloVe embeddings ([Pennington et al., 2014](#bib.bib42))
after normalizing the GloVe embeddings to have unit norm.1010
10
We use
the GloVe embeddings pretrained over the $840$ billion word Common Crawl, publicly available at http://nlp.stanford.edu/projects/glove/
The pretrained embeddings remain fixed but the linear layer (which is also $300$-dimensional) is trained. Words not in the pretrained vocabulary
are hashed to one of $100$ Gaussian embeddings with mean $0$ and standard deviation $1$.

We concatenate each input representation with a convex combination of the other sentence’s input representations
(essentially performing inter-sentence attention),
where the weights are determined through a dot product followed by a softmax,

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | $\displaystyle e\_{ij}=f(\mathbf{x}\_{i})^{\top}f(\mathbf{y}\_{j})$ |  | $\displaystyle\bar{\mathbf{x}}\_{i}=\left[\mathbf{x}\_{i};\sum\_{j=1}^{m}\frac{\exp e\_{ij}}{\sum\_{k=1}^{m}\exp e\_{ik}}\mathbf{y}\_{j}\right]$ |  | $\displaystyle\bar{\mathbf{y}}\_{j}=\left[\mathbf{y}\_{j};\sum\_{i=1}^{n}\frac{\exp e\_{ij}}{\sum\_{k=1}^{n}\exp e\_{kj}}\mathbf{x}\_{i}\right]$ |  |

Here $f(\cdot)$ is an MLP. The new representations are fed through another MLP $g(\cdot)$, summed,
combined with the final MLP $h(\cdot)$ and fed through a softmax layer to obtain a distribution
over the labels $l$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\bar{\mathbf{x}}$ | $\displaystyle=\sum\_{i=1}^{n}g(\bar{\mathbf{x}}\_{i})\hskip 56.9055pt\bar{\mathbf{y}}=\sum\_{j=1}^{m}g(\bar{\mathbf{y}}\_{j})$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle p(l\,|\,x\_{1},$ | $\displaystyle\dots,x\_{n},y\_{1},\dots,y\_{m})=\softmax(\mathbf{V}h([\bar{\mathbf{x}};\bar{\mathbf{y}}])+\mathbf{b})$ |  |

All the MLPs have $2$-layers, $300$ $\relu$ units, and dropout probability of $0.2$. For structured/simple models,
we first employ the bidirectional parsing LSTM (see [A.1](#A1.SS1 "A.1 Syntactic Attention ‣ Appendix A Model Details ‣ Structured Attention Networks")) to obtain the scores $\theta\_{ij}$. In the structured case
each word representation is simply concatenated with its soft-parent

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\hat{\mathbf{x}}\_{i}=\left[\mathbf{x}\_{i};\sum\_{k=1}^{n}p(z\_{ki}=1\,|\,x)\mathbf{x}\_{k}\right]$ |  |

and $\hat{\mathbf{x}}\_{i}$ (and analogously $\hat{\mathbf{y}}\_{j}$) is used as the input to the above model. In the simple case (which
closely corresponds to the *intra-sentence* attention model of [Parikh et al. (2016)](#bib.bib40)), we have

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\hat{\mathbf{x}}\_{i}=\left[\mathbf{x}\_{i};\sum\_{k=1}^{n}\frac{\exp\theta\_{ki}}{\sum\_{l=1}^{n}\exp\theta\_{li}}\mathbf{x}\_{k}\right]$ |  |

The word embeddings for the parsing LSTMs are also initialized with GloVe, and the parsing layer is shared between the two sentences.
The forward/backward LSTMs for the parsing layer are $100$-dimensional.

Additional training details include: batch size of $32$; training for $100$ epochs with Adagrad ([Duchi et al., 2011](#bib.bib16)) where the global
learning rate is $0.05$ and sum of gradient squared is initialized to $0.1$;
parameter intialization over a Gaussian distribution with mean $0$ and standard deviation $0.01$;
gradient normalization at $5$. In the pretrained scenario, pretraining is done with Adam ([Kingma & Ba, 2015](#bib.bib26)) with
learning rate equal to $0.01$, and $\beta\_{1}=0.9$, $\beta\_{2}=0.999$.

## Appendix B Forward/Backward through the Inside-Outside Algorithm

Figure [6](#A2.F6 "Figure 6 ‣ Appendix B Forward/Backward through the Inside-Outside Algorithm ‣ Structured Attention Networks") shows the procedure for obtaining the parsing marginals from
the input potentials. This corresponds to running the inside-outside version of Eisner’s algorithm ([Eisner, 1996](#bib.bib18)).
The intermediate data structures used during the dynamic programming algorithm
are the (log) inside tables $\alpha$, and the (log) outside tables $\beta$. Both $\alpha,\beta$
are of size $n\times n\times 2\times 2$, where $n$ is the sentence length.
First two dimensions encode the start/end index
of the span (i.e. subtree). The third dimension encodes whether the root of the subtree is
the left ($L$) or right ($R$) index of the span. The fourth dimension indicates if the span is complete ($1$)
or incomplete ($0$). We can calculate the marginal distribution of each word’s parent (for all words) in $O(n^{3})$ using
this algorithm.

Backward pass through the inside-outside algorithm is slightly more involved, but still takes $O(n^{3})$ time.
Figure [7](#A2.F7 "Figure 7 ‣ Appendix B Forward/Backward through the Inside-Outside Algorithm ‣ Structured Attention Networks") illustrates the backward procedure, which receives the gradient of the loss
$\mathcal{L}$ with respect to the marginals, $\nabla^{\mathcal{L}}\_{p}$, and computes the gradient of the loss with respect
to the potentials $\nabla^{\mathcal{L}}\_{\theta}$. The computations must be performed in the signed log-space semifield
to handle log of negative values. See section [3.3](#S3.SS3 "3.3 End-to-End Training ‣ 3 Structured Attention ‣ Structured Attention Networks") and
Table [1](#S3.T1 "Table 1 ‣ 3.3 End-to-End Training ‣ 3 Structured Attention ‣ Structured Attention Networks") for more details.

```
procedure InsideOutside(θ\theta)

            
            α,β←−∞\alpha,\beta\leftarrow-\infty ⊳\triangleright Initialize log of inside (α\alpha), outside (β\beta) tables

            
            for i=1,…,ni=1,\dots,n do

            
             α⁡[i,i,L,1]←0\alpha[i,i,L,1]\leftarrow 0

            
             α⁡[i,i,R,1]←0\alpha[i,i,R,1]\leftarrow 0
  

            
            β⁡[1,n,R,1]←0\beta[1,n,R,1]\leftarrow 0

            
            for k=1,…,nk=1,\dots,n do ⊳\triangleright Inside step

            
             for s=1,…,n−ks=1,\dots,n-k do

            
               t←s+kt\leftarrow s+k

            
               α⁡[s,t,R,0]←⨁u∈[s,t−1]α⁡[s,u,R,1]⊗α⁡[u+1,t,L,1]⊗θs​t\alpha[s,t,R,0]\leftarrow\bigoplus_{u\in[s,t-1]}\alpha[s,u,R,1]\otimes\alpha[u+1,t,L,1]\otimes\theta_{st}

            
               α⁡[s,t,L,0]←⨁u∈[s,t−1]α⁡[s,u,R,1]⊗α⁡[u+1,t,L,1]⊗θt​s\alpha[s,t,L,0]\leftarrow\bigoplus_{u\in[s,t-1]}\alpha[s,u,R,1]\otimes\alpha[u+1,t,L,1]\otimes\theta_{ts}

            
               α⁡[s,t,R,1]←⨁u∈[s+1,t]α⁡[s,u,R,0]⊗α⁡[u,t,R,1]\alpha[s,t,R,1]\leftarrow\bigoplus_{u\in[s+1,t]}\alpha[s,u,R,0]\otimes\alpha[u,t,R,1]

            
               α⁡[s,t,L,1]←⨁u∈[s,t−1]α⁡[s,u,L,1]⊗α⁡[u,t,L,0]\alpha[s,t,L,1]\leftarrow\bigoplus_{u\in[s,t-1]}\alpha[s,u,L,1]\otimes\alpha[u,t,L,0] 
     

            
            for k=n,…,1k=n,\dots,1 do ⊳\triangleright Outside step

            
             for s=1,…,n−ks=1,\dots,n-k do

            
               t←s+kt\leftarrow s+k

            
               for u=s+1,…,tu=s+1,\dots,t do

            
                β[s,u,R,0]←⊕β[s,t,R,1]⊗α[u,t,R,1]\beta[s,u,R,0]\leftarrow_{\oplus}\beta[s,t,R,1]\otimes\alpha[u,t,R,1]

            
                β[u,t,R,1]←⊕β[s,t,R,1]⊗α[s,u,R,0]\beta[u,t,R,1]\leftarrow_{\oplus}\beta[s,t,R,1]\otimes\alpha[s,u,R,0] 
     

            
               if s>1s>1 then

            
                for u=s,…,t−1u=s,\dots,t-1 do

            
                  β[s,u,L,1]←⊕β[s,t,L,1]⊗α[u,t,L,0]\beta[s,u,L,1]\leftarrow_{\oplus}\beta[s,t,L,1]\otimes\alpha[u,t,L,0]

            
                  β[u,t,L,0]←⊕β[s,t,L,1]⊗α[s,u,L,1]\beta[u,t,L,0]\leftarrow_{\oplus}\beta[s,t,L,1]\otimes\alpha[s,u,L,1] 
           

            
               for u=s,…,t−1u=s,\dots,t-1 do

            
                β[s,u,R,1]←⊕β[s,t,R,0]⊗α[u+1,t,L,1]⊗θs​t\beta[s,u,R,1]\leftarrow_{\oplus}\beta[s,t,R,0]\otimes\alpha[u+1,t,L,1]\otimes\theta_{st}

            
                β[u+1,t,L,1]←⊕β[s,t,R,0]⊗α[s,u,R,1]⊗θs​t\beta[u+1,t,L,1]\leftarrow_{\oplus}\beta[s,t,R,0]\otimes\alpha[s,u,R,1]\otimes\theta_{st} 
     

            
               if s>1s>1 then

            
                for u=s,…,t−1u=s,\dots,t-1 do

            
                  β[s,u,R,1]←⊕β[s,t,L,0]⊗α[u+1,t,L,1]⊗θt​s\beta[s,u,R,1]\leftarrow_{\oplus}\beta[s,t,L,0]\otimes\alpha[u+1,t,L,1]\otimes\theta_{ts}

            
                  β[u+1,t,L,1]←⊕β[s,t,L,0]⊗α[s,u,R,1]⊗θt​s\beta[u+1,t,L,1]\leftarrow_{\oplus}\beta[s,t,L,0]\otimes\alpha[s,u,R,1]\otimes\theta_{ts} 
                

            
            A←α⁡[1,n,R,1]A\leftarrow\alpha[1,n,R,1] ⊳\triangleright Log partition

            
            for s=1,…,n−1s=1,\dots,n-1 do ⊳\triangleright Compute marginals. Note that p⁡[s,t]=p⁡(zs​t=1|x)p[s,t]=p(z_{st}=1\,|\,x)

            
             for t=s+1,…,nt=s+1,\dots,n do

            
               p[s,t]←exp(α[s,t,R,0]⊗β[s,t,R,0]⊗−A)p[s,t]\leftarrow\exp(\alpha[s,t,R,0]\otimes\beta[s,t,R,0]\otimes-A)

            
               if s>1s>1 then

            
                p[t,s]←exp(α[s,t,L,0]⊗β[s,t,L,0]⊗−A)p[t,s]\leftarrow\exp(\alpha[s,t,L,0]\otimes\beta[s,t,L,0]\otimes-A)
          

            
            return pp
```

Figure 6:  Forward step of the syntatic attention layer to compute the marginals, using the inside-outside algorithm
([Baker, 1979](#bib.bib3)) on the data structures of [Eisner (1996)](#bib.bib18).
We assume the special root symbol is the first element of the sequence, and that the sentence length is $n$.
Calculations are performed in log-space semifield with $\oplus=\logadd$ and $\otimes=+$ for numerical precision.
$a,b\leftarrow c$ means $a\leftarrow c$ and $b\leftarrow c$.
$a\leftarrow\_{\oplus}b$ means $a\leftarrow a\oplus b$.

```
procedure BackpropInsideOutside(θ,p,∇pℒ\theta,p,\nabla_{p}^{\mathcal{L}})

            
            for s,t=1,…,n;s≠ts,t=1,\dots,n;s\neq t do ⊳\triangleright Backpropagation uses the identity ∇θℒ=(p⊙∇pℒ)​∇θlog⁡p\nabla^{\mathcal{L}}_{\theta}=(p\odot\nabla_{p}^{\mathcal{L}})\nabla^{\log p}_{\theta}

            
             δ⁡[s,t]←log⁡p⁡[s,t]⊗log⁡∇pℒ[s,t]\delta[s,t]\leftarrow\log p[s,t]\otimes\log\nabla_{p}^{\mathcal{L}}[s,t] ⊳\triangleright δ=log⁡(p⊙∇pℒ)\delta=\log(p\odot\nabla_{p}^{\mathcal{L}})
  

            
            ∇αℒ,∇βℒ,log⁡∇θℒ←−∞\nabla_{\alpha}^{\mathcal{L}},\nabla_{\beta}^{\mathcal{L}},\log\nabla_{\theta}^{\mathcal{L}}\leftarrow-\infty ⊳\triangleright Initialize inside (∇αℒ\nabla_{\alpha}^{\mathcal{L}}), outside (∇βℒ\nabla_{\beta}^{\mathcal{L}}) gradients, and log of ∇θℒ\nabla^{\mathcal{L}}_{\theta}

            
            for s=1,…,n−1s=1,\dots,n-1 do ⊳\triangleright Backpropagate δ\delta to ∇αℒ\nabla_{\alpha}^{\mathcal{L}} and ∇βℒ\nabla_{\beta}^{\mathcal{L}}

            
             for t=s+1,…,nt=s+1,\dots,n do

            
               ∇αℒ[s,t,R,0],∇βℒ[s,t,R,0]←δ⁡[s,t]\nabla_{\alpha}^{\mathcal{L}}[s,t,R,0],\nabla_{\beta}^{\mathcal{L}}[s,t,R,0]\leftarrow\delta[s,t]

            
               ∇αℒ[1,n,R,1]←⊕−δ[s,t]\nabla_{\alpha}^{\mathcal{L}}[1,n,R,1]\leftarrow_{\oplus}-\delta[s,t]

            
               if s>1s>1 then

            
                ∇αℒ[s,t,L,0],∇βℒ[s,t,L,0]←δ⁡[t,s]\nabla_{\alpha}^{\mathcal{L}}[s,t,L,0],\nabla_{\beta}^{\mathcal{L}}[s,t,L,0]\leftarrow\delta[t,s]

            
                ∇αℒ[1,n,R,1]←⊕−δ[s,t]\nabla_{\alpha}^{\mathcal{L}}[1,n,R,1]\leftarrow_{\oplus}-\delta[s,t]
          

            
            for k=1,…,nk=1,\dots,n do ⊳\triangleright Backpropagate through outside step

            
             for s=1,…,n−ks=1,\dots,n-k do

            
               t←s+kt\leftarrow s+k

            
               ν←∇βℒ[s,t,R,0]⊗β⁡[s,t,R,0]\nu\leftarrow\nabla_{\beta}^{\mathcal{L}}[s,t,R,0]\otimes\beta[s,t,R,0] ⊳\triangleright ν,γ\nu,\gamma are temporary values

            
               for u=t,…,nu=t,\dots,n do

            
                ∇βℒ[s,u,R,1],∇αℒ[t,u,R,1]←⊕ν⊗β[s,u,R,1]⊗α[t,u,R,1]\nabla_{\beta}^{\mathcal{L}}[s,u,R,1],\nabla_{\alpha}^{\mathcal{L}}[t,u,R,1]\leftarrow_{\oplus}\nu\otimes\beta[s,u,R,1]\otimes\alpha[t,u,R,1]
     

            
               if s>1s>1 then

            
                ν←∇βℒ[s,t,L,0]⊗β⁡[s,t,L,0]\nu\leftarrow\nabla_{\beta}^{\mathcal{L}}[s,t,L,0]\otimes\beta[s,t,L,0]

            
                for u=1,…,su=1,\dots,s do

            
                  ∇βℒ[u,t,L,1],∇αℒ[u,s,L,1]←⊕ν⊗β[u,t,L,1]⊗α[u,s,L,1]\nabla_{\beta}^{\mathcal{L}}[u,t,L,1],\nabla_{\alpha}^{\mathcal{L}}[u,s,L,1]\leftarrow_{\oplus}\nu\otimes\beta[u,t,L,1]\otimes\alpha[u,s,L,1]
      

            
                ν←∇βℒ[s,t,L,1]⊗β⁡[s,t,L,1]\nu\leftarrow\nabla_{\beta}^{\mathcal{L}}[s,t,L,1]\otimes\beta[s,t,L,1]

            
                for u=t,…,nu=t,\dots,n do

            
                  ∇βℒ[s,u,L,1],∇αℒ[t,u,L,0]←⊕ν⊗β[s,u,L,1]⊗α[t,u,L,1]\nabla_{\beta}^{\mathcal{L}}[s,u,L,1],\nabla_{\alpha}^{\mathcal{L}}[t,u,L,0]\leftarrow_{\oplus}\nu\otimes\beta[s,u,L,1]\otimes\alpha[t,u,L,1]
      

            
                for u=1,…,s−1u=1,\dots,s-1 do

            
                  γ←β⁡[u,t,R,0]⊗α⁡[u,s−1,R,1]⊗θu​t\gamma\leftarrow\beta[u,t,R,0]\otimes\alpha[u,s-1,R,1]\otimes\theta_{ut}

            
                  ∇βℒ[u,t,R,0],∇αℒ[u,s−1,R,1],log∇θℒ[u,t]←⊕ν⊗γ\nabla_{\beta}^{\mathcal{L}}[u,t,R,0],\nabla_{\alpha}^{\mathcal{L}}[u,s-1,R,1],\log\nabla_{\theta}^{\mathcal{L}}[u,t]\leftarrow_{\oplus}\nu\otimes\gamma

            
                  γ←β⁡[u,t,L,0]⊗α⁡[u,s−1,R,1]⊗θt​u\gamma\leftarrow\beta[u,t,L,0]\otimes\alpha[u,s-1,R,1]\otimes\theta_{tu}

            
                  ∇βℒ[u,t,L,0],∇αℒ[u,s−1,R,1],log∇θℒ[t,u]←⊕ν⊗γ\nabla_{\beta}^{\mathcal{L}}[u,t,L,0],\nabla_{\alpha}^{\mathcal{L}}[u,s-1,R,1],\log\nabla_{\theta}^{\mathcal{L}}[t,u]\leftarrow_{\oplus}\nu\otimes\gamma
           

            
               ν←∇βℒ[s,t,R,1]⊗β⁡[s,t,R,1]\nu\leftarrow\nabla_{\beta}^{\mathcal{L}}[s,t,R,1]\otimes\beta[s,t,R,1]

            
               for u=1,…,su=1,\dots,s do

            
                ∇βℒ[u,t,R,1],∇αℒ[u,s,R,0]←⊕ν⊗β[u,t,R,1]⊗α[u,s,R,0]\nabla_{\beta}^{\mathcal{L}}[u,t,R,1],\nabla_{\alpha}^{\mathcal{L}}[u,s,R,0]\leftarrow_{\oplus}\nu\otimes\beta[u,t,R,1]\otimes\alpha[u,s,R,0]
     

            
               for u=t+1,…,nu=t+1,\dots,n do

            
                γ←β⁡[s,u,R,0]⊗α⁡[t+1,u,L,1]⊗θs​u\gamma\leftarrow\beta[s,u,R,0]\otimes\alpha[t+1,u,L,1]\otimes\theta_{su}

            
                ∇βℒ[s,u,R,0],∇αℒ[t+1,u,L,1],log∇θℒ[s,u]←⊕ν⊗γ\nabla_{\beta}^{\mathcal{L}}[s,u,R,0],\nabla_{\alpha}^{\mathcal{L}}[t+1,u,L,1],\log\nabla_{\theta}^{\mathcal{L}}[s,u]\leftarrow_{\oplus}\nu\otimes\gamma

            
                γ←β⁡[s,u,L,0]⊗α⁡[t+1,u,L,1]⊗θu​s\gamma\leftarrow\beta[s,u,L,0]\otimes\alpha[t+1,u,L,1]\otimes\theta_{us}

            
                ∇βℒ[s,u,L,0],∇αℒ[t+1,u,L,1],log∇θℒ[u,s]←⊕ν⊗γ\nabla_{\beta}^{\mathcal{L}}[s,u,L,0],\nabla_{\alpha}^{\mathcal{L}}[t+1,u,L,1],\log\nabla_{\theta}^{\mathcal{L}}[u,s]\leftarrow_{\oplus}\nu\otimes\gamma
          

            
            for k=n,…,1k=n,\dots,1 do ⊳\triangleright Backpropagate through inside step

            
             for s=1,…,n−ks=1,\dots,n-k do

            
               t←s+kt\leftarrow s+k

            
               ν←∇αℒ[s,t,R,1]⊗α⁡[s,t,R,1]\nu\leftarrow\nabla_{\alpha}^{\mathcal{L}}[s,t,R,1]\otimes\alpha[s,t,R,1]

            
               for u=s+1,…,tu=s+1,\dots,t do

            
                ∇αℒ[u,t,R,0],∇αℒ[u,t,R,1]←⊕ν⊗α[s,u,R,0]⊗α[u,t,R,1]\nabla_{\alpha}^{\mathcal{L}}[u,t,R,0],\nabla_{\alpha}^{\mathcal{L}}[u,t,R,1]\leftarrow_{\oplus}\nu\otimes\alpha[s,u,R,0]\otimes\alpha[u,t,R,1]
     

            
               if s>1s>1 then

            
                ν←∇αℒ[s,t,L,1]⊗α⁡[s,t,L,1]\nu\leftarrow\nabla_{\alpha}^{\mathcal{L}}[s,t,L,1]\otimes\alpha[s,t,L,1]

            
                for u=s,…,t−1u=s,\dots,t-1 do

            
                  ∇αℒ[s,u,L,1],∇αℒ[u,t,L,0]←⊕ν⊗α[s,u,L,1]⊗α[u,t,L,0]\nabla_{\alpha}^{\mathcal{L}}[s,u,L,1],\nabla_{\alpha}^{\mathcal{L}}[u,t,L,0]\leftarrow_{\oplus}\nu\otimes\alpha[s,u,L,1]\otimes\alpha[u,t,L,0]
      

            
                ν←∇αℒ[s,t,L,0]⊗α⁡[s,t,L,0]\nu\leftarrow\nabla_{\alpha}^{\mathcal{L}}[s,t,L,0]\otimes\alpha[s,t,L,0]

            
                for u=s,…,t−1u=s,\dots,t-1 do

            
                  γ←α⁡[s,u,R,1]⊗α⁡[u+1,t,L,1]⊗θt​s\gamma\leftarrow\alpha[s,u,R,1]\otimes\alpha[u+1,t,L,1]\otimes\theta_{ts}

            
                  ∇αℒ[s,u,R,1],∇αℒ[u+1,t,L,1],log∇θℒ[t,s]←⊕ν⊗γ\nabla_{\alpha}^{\mathcal{L}}[s,u,R,1],\nabla_{\alpha}^{\mathcal{L}}[u+1,t,L,1],\log\nabla_{\theta}^{\mathcal{L}}[t,s]\leftarrow_{\oplus}\nu\otimes\gamma
           

            
               ν←∇αℒ[s,t,R,0]⊗α⁡[s,t,R,0]\nu\leftarrow\nabla_{\alpha}^{\mathcal{L}}[s,t,R,0]\otimes\alpha[s,t,R,0]

            
               for u=s,…,t−1u=s,\dots,t-1 do

            
                γ←α⁡[s,u,R,1]⊗α⁡[u+1,t,L,1]⊗θs​t\gamma\leftarrow\alpha[s,u,R,1]\otimes\alpha[u+1,t,L,1]\otimes\theta_{st}

            
                ∇αℒ[s,u,R,1],∇αℒ[u+1,t,L,1],log∇θℒ[s,t]←⊕ν⊗γ\nabla_{\alpha}^{\mathcal{L}}[s,u,R,1],\nabla_{\alpha}^{\mathcal{L}}[u+1,t,L,1],\log\nabla_{\theta}^{\mathcal{L}}[s,t]\leftarrow_{\oplus}\nu\otimes\gamma
          

            
            return signexp⁡log⁡∇θℒ\signexp\log\nabla_{\theta}^{\mathcal{L}}⊳\triangleright Exponentiate log gradient, multiply by sign, and return ∇θℒ\nabla^{\mathcal{L}}_{\theta}
```

Figure 7:  Backpropagation through the inside-outside algorithm to calculate the gradient with respect
to the input potentials. $\nabla^{a}\_{b}$ denotes
the Jacobian of $a$ with respect to $b$ (so $\nabla^{\mathcal{L}}\_{\theta}$ is the gradient with respect to $\theta$).
$a,b\leftarrow\_{\oplus}c$ means $a\leftarrow a\oplus c$ and $b\leftarrow b\oplus c$.
