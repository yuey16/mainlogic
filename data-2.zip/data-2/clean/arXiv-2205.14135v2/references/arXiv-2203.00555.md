<!-- fulltext source=arxiv_html slug=arXiv-2203.00555 fetched=2026-09-16T11:52:38+00:00 -->

# DeepNet: Scaling Transformers to 1,000 Layers

Hongyu Wang    Shuming Ma11footnotemark: 
1
    Li Dong   Shaohan Huang   Dongdong Zhang   Furu Wei
††thanks: Equal contribution. Work was done during Hongyu’s internship at Microsoft Research.††thanks: Corresponding author <[fuwei@microsoft.com](mailto:fuwei@microsoft.com)> .
Affiliation: Microsoft Research
Affiliation: <https://github.com/microsoft/unilm>

###### Abstract

In this paper, we propose a simple yet effective method to stabilize extremely deep Transformers. Specifically, we introduce a new normalization function (DeepNorm) to modify the residual connection in Transformer, accompanying with theoretically derived initialization.
In-depth theoretical analysis shows that model updates can be bounded in a stable way.
The proposed method combines the best of two worlds, i.e., good performance of Post-LN and stable training of Pre-LN, making DeepNorm a preferred alternative.
We successfully scale Transformers up to 1,000 layers (i.e., 2,500 attention and feed-forward network sublayers) without difficulty, which is one order of magnitude deeper than previous deep Transformers. Remarkably, on a multilingual benchmark with 7,482 translation directions, our 200-layer model with 3.2B parameters significantly outperforms the 48-layer state-of-the-art model with 12B parameters by 5 BLEU points, which indicates a promising scaling direction.

Figure 1: Trend of Transformer depths of state-of-the-art NLP models over time.

## 1 Introduction

Recent years have witnessed a trend towards large-scale Transformer ([Vaswani et al., 2017](#bib.bib37)) models. The capacity has substantially increased from millions of parameters ([Devlin et al., 2019](#bib.bib12); [Conneau et al., 2020](#bib.bib11)) to billions ([Radford et al., 2019](#bib.bib31); [Brown et al., 2020](#bib.bib8); [Huang et al., 2019](#bib.bib21); [Raffel et al., 2020](#bib.bib33); [Lepikhin et al., 2021](#bib.bib24); [Rae et al., 2021](#bib.bib32); [Lin et al., 2021](#bib.bib25); [Smith et al., 2022](#bib.bib36)), and even trillions ([Du et al., 2021](#bib.bib14)). Large-scale models yield state-of-the-art performance on a wide range of tasks, and show impressive abilities in few-shot and zero-shot learning. Despite an enormous number of parameters, their depths (as shown in [Figure 1](#S0.F1 "In DeepNet: Scaling Transformers to 1,000 Layers")) are limited by the training instability of Transformers.

[Nguyen and Salazar (2019)](#bib.bib28) find that pre-norm residual connections (Pre-LN) improve the stability of Transformers based on post-norm connections (Post-LN). However, the gradients of Pre-LN at bottom layers tend to be larger than at top layers ([Shleifer et al., 2021](#bib.bib35)), leading to a degradation in performance compared with Post-LN.
In order to alleviate the above issue, there have been efforts on improving the optimization of deep Transformer by means of better initialization ([Zhang et al., 2019a](#bib.bib42); [Zhang et al., 2019b](#bib.bib44); [Huang et al., 2020](#bib.bib20)), or better architecture ([Wang et al., 2019](#bib.bib38); [Liu et al., 2020](#bib.bib26); [Bachlechner et al., 2020](#bib.bib1); [Shleifer et al., 2021](#bib.bib35)).
These approaches can stabilize a Transformer model with up to hundreds of layers. Yet, none of previous methods has been successfully scaled to 1,000 layers.

Our aim is to improve the training stability of Transformers and scale the model depth by orders of magnitude. To this end, we study the cause of unstable optimization, finding the exploding model update is responsible for the instability.
Motivated by the above observation, we introduce a new normalization function (DeepNorm) at residual connections ([He et al., 2016](#bib.bib19)), which has theoretical justification of bounding the model update by a constant.
The proposed method is simple yet effective, with just lines of code change.
The approach improves the stability of Transformers so that we are able to scale model depth to more than 1,000 layers.
Moreover, experimental results show that DeepNorm combines the best of two worlds, i.e., good performance of Post-LN and stable training of Pre-LN.
The proposed method can be a preferred alternative of Transformers, not only for extremely deep (such as >1000 layers) models, but also for existing large models.
Notably, our 200-layer model with 3.2B parameters achieves 5 BLEU improvement on a massively multilingual machine translation benchmark compared to state-of-the-art model ([Fan et al., 2021](#bib.bib16)) with 48 layers and 12B model size.

## 2 TL;DR for Practitioners

```
  def deepnorm(x):
      return LayerNorm(x * <@\textcolor{red}{$\alpha$}@> + f(x))

  def deepnorm_init(w):
      if w is ['ffn', 'v_proj', 'out_proj']:
          nn.init.xavier_normal_(w, gain=<@\textcolor{red}{$\beta$}@>)
      elif w is ['q_proj', 'k_proj']:
          nn.init.xavier_normal_(w, gain=1)
```

| Architectures | Encoder | | Decoder | |
| --- | --- | --- | --- | --- |
| $\alpha$ | $\beta$ | $\alpha$ | $\beta$ |
| Encoder-only | $(2N)^{\frac{1}{4}}$ | $(8N)^{-\frac{1}{4}}$ | - | - |
| (e.g., BERT) |
| Decoder-only | - | - | $(2M)^{\frac{1}{4}}$ | $(8M)^{-\frac{1}{4}}$ |
| (e.g., GPT) |
| Encoder-decoder | $0.81(N^{4}M)^{\frac{1}{16}}$ | $0.87(N^{4}M)^{-\frac{1}{16}}$ | $(3M)^{\frac{1}{4}}$ | $(12M)^{-\frac{1}{4}}$ |
| (e.g., NMT, T5) |
| --- |

Figure 2: (a) Pseudocode for DeepNorm. We take Xavier initialization ([Glorot and Bengio, 2010](#bib.bib17)) as an example, and it can be replaced with other standard initialization. Notice that $\alpha$ is a constant. (b) Parameters of DeepNorm for different architectures ($N$-layer encoder, $M$-layer decoder).

As shown in [Figure 2](#S2.F2 "In 2 TL;DR for Practitioners ‣ DeepNet: Scaling Transformers to 1,000 Layers"), it is simple to implement our method based on Transformers with Post-LN.
Compared to Post-LN, DeepNorm up-scales the residual connection before performing layer normalization. Besides, we down-scale the parameters during initialization.
Notably, we only scale the weights of feed-forward networks, as well as the value projection and the output projection of attention layers.
Moreover, the scales of residual connection and initialization are dependent on the architecture ([Figure 2](#S2.F2 "In 2 TL;DR for Practitioners ‣ DeepNet: Scaling Transformers to 1,000 Layers")). We provide more details in [Section 4.3](#S4.SS3 "4.3 Derivation for DeepNorm and the Initialization ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers").

## 3 Instability of Deep Transformer

We study the causes of the instability for deep Transformers. Our analysis begins with the observation: better initialization methods stabilize the training of Transformer. This has also been verified by previous work ([Zhang et al., 2019a](#bib.bib42); [Huang et al., 2020](#bib.bib20); [Xu et al., 2021](#bib.bib41)). Therefore, we study the training process of Post-LN with or without proper initialization.
With better initialization, we down-scale the weights of $l$-th layer by $k\_{l}=N-l+1,l\in[1,N]$ after performing Xavier initialization. For example, the output projection $W^{l}\_{o}$ of FFN in $l$-th layer is initialized as:

|  |  |  |
| --- | --- | --- |
|  | $W^{l}\_{o}\backsim\mathcal{N}\left(0,\frac{1}{k\_{l}^{2}d^{\prime}}\right),$ |  |

where $d^{\prime}$ is an average of input and output dimensions. We name this model Post-LN-init. Notice that different from the prior work ([Zhang et al., 2019a](#bib.bib42)), we narrow the scale of lower layers instead of the higher layers. We believe that it helps to separate the effect of the gradient scale from the model update. Besides, Post-LN-init has the same architecture as Post-LN, which eliminates the impact from the architecture.

Figure 3: (a) Gradient norm in the top layers of 18L-18L models. (b) Gradient norm in the last layer of the models with depths varying from 6L-6L to 24L-24L. (c) Validation loss curves of 18L-18L models.

(a) Accumulated model update

(b) Input from FFN to LN

(c) Input from attention to LN

(d) Gradient norm in all decoder layers

Figure 4: Visualization of the model update, the average input of LNs, and the gradients for the 18L-18L models at the early stage of training.

We train 18L-18L Post-LN and 18L-18L Post-LN-init on the IWSLT-14 De-En machine translation dataset.
[Figure 3](#S3.F3 "In 3 Instability of Deep Transformer ‣ DeepNet: Scaling Transformers to 1,000 Layers") visualizes their gradients and validation loss curves.
As shown in [Figure 3](#S3.F3 "In 3 Instability of Deep Transformer ‣ DeepNet: Scaling Transformers to 1,000 Layers")(c), Post-LN-init converged while Post-LN did not.
Post-LN-init has an even larger gradient norm in the last several layers, although its weights have been scaled down. Furthermore, we visualize the gradient norm of the last decoder layer with varying model depth from 6L-6L to 24L-24L.
[Figure 3](#S3.F3 "In 3 Instability of Deep Transformer ‣ DeepNet: Scaling Transformers to 1,000 Layers") shows that the gradient norm of Post-LN-init in the last layer is still much larger than that of Post-LN, regardless of model depth.
It concludes that the exploding gradients in deep layers should not be the root cause of instability of Post-LN, while the scale of model update tends to account for it.

Then we demonstrate that the instability of Post-LN comes from a chain of several issues, including gradient vanishing as well as too large model updates. As shown in [Figure 4a](#S3.F4.sf1 "In Figure 4 ‣ 3 Instability of Deep Transformer ‣ DeepNet: Scaling Transformers to 1,000 Layers"), we first visualize the norm of model update $||\Delta F||$ at the early stage of training:

|  |  |  |
| --- | --- | --- |
|  | $||\Delta F||=||F(x,\theta\_{i})-F(x,\theta\_{0})||,$ |  |

where $x$ and $\theta\_{i}$ denotes input, and model parameters after $i$-th updates.
Post-LN has an exploding update at the very beginning of training, and then nearly no update shortly. It indicates that the model has been stuck in a spurious local optima. Both warm-up and better initialization help alleviate this issue, enabling the model to update smoothly.
When the update explodes, the inputs to LN become large (see [Figure 4b](#S3.F4.sf2 "In Figure 4 ‣ 3 Instability of Deep Transformer ‣ DeepNet: Scaling Transformers to 1,000 Layers") and [Figure 4c](#S3.F4.sf3 "In Figure 4 ‣ 3 Instability of Deep Transformer ‣ DeepNet: Scaling Transformers to 1,000 Layers")).
According to the theoretical analysis from [Xiong et al. (2020)](#bib.bib40), the magnitude of gradient through LN is inversely proportional to the magnitude of its input:

|  |  |  |
| --- | --- | --- |
|  | $||\cfrac{\partial LN(x)}{\partial x}||=\mathcal{O}(\cfrac{\sqrt{d}}{||x||}).$ |  |

[Figure 4b](#S3.F4.sf2 "In Figure 4 ‣ 3 Instability of Deep Transformer ‣ DeepNet: Scaling Transformers to 1,000 Layers") and [Figure 4c](#S3.F4.sf3 "In Figure 4 ‣ 3 Instability of Deep Transformer ‣ DeepNet: Scaling Transformers to 1,000 Layers") show that $||x||$ is significantly larger than $\sqrt{d}$ $(d=512)$ without warm-up or proper initialization. This explains the gradient vanishing problem occurred in the training of Post-LN (see [Figure 4d](#S3.F4.sf4 "In Figure 4 ‣ 3 Instability of Deep Transformer ‣ DeepNet: Scaling Transformers to 1,000 Layers")).

Above all, the instability starts from the large model update at the beginning of training. It renders the model trapped in a bad local optima, which in turn increases the magnitude of inputs to each LN.
As training continues, the gradient through LN becomes increasingly small, thus resulting in severe gradient vanishing.
The vanishing gradients make it difficult to escape from the local optima, and further destabilize the optimization.
On the contrary, Post-LN-init has relatively small updates, and the inputs to LN are stable. This relieves suffering from gradient vanishing, making optimization more stable.

## 4 DeepNet: Extremely Deep Transformers

In this section, we introduce our extremely deep Transformers named DeepNet.
It can stabilize the optimization by mitigating the exploding model update problem.
We first provide the estimation of the expected magnitude of DeepNet’s model update.
Then we provide the theoretical analysis to show that its updates can be bounded by a constant with our proposed DeepNorm.

### 4.1 Architecture

DeepNet is based on the Transformer architecture. Compared to the vanilla Transformer, it uses our new DeepNorm, instead of Post-LN, for each sub-layer. The formulation of DeepNorm can be written as:

|  |  |  |
| --- | --- | --- |
|  | $x\_{l+1}=LN(\alpha x\_{l}+G\_{l}(x\_{l},\theta\_{l})),$ |  |

where $\alpha$ is a constant, and $G\_{l}(x\_{l},\theta\_{l})$ is the function of the $l$-th Transformer sub-layer (i.e., attention or feed-forward network) with parameters $\theta\_{l}$.
Besides, DeepNet scales the weights $\theta\_{l}$ inside residual branches by $\beta$.
Notably, both $\alpha$ and $\beta$ are constants that only depend on the architecture, and we provide the derivation in [Section 4.3](#S4.SS3 "4.3 Derivation for DeepNorm and the Initialization ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers").

### 4.2 Expected Magnitude of Model Update

Attention is an important part of Transformer. Without loss of generality, we study the 1-head case. Let $Q,K,V\in\mathbf{R}^{n\times d}$ denote the query, key, value, respectively. $W^{Q},W^{K},W^{V}\in\mathbf{R}^{d\times d\_{k}}$ are the input projection matrices, and $W^{O}\in\mathbf{R}^{d\_{k}\times d}$ is the output projection matrix. Then, the attention module can be formulated as:

|  |  |  |
| --- | --- | --- |
|  | $Attn(Q,K,V)=softmax(\cfrac{QW^{Q}(KW^{K})^{T}}{\sqrt{d\_{k}}})VW^{V}W^{O}$ |  |

We study the magnitude of the attention module. Lemma [4.1](#S4.Thmtheorem1 "Lemma 4.1. ‣ 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers") proves that $W^{Q}$ and $W^{K}$ do not change the bound of attention output’s magnitude.

###### Lemma 4.1.

Given $\mathbf{X}=(\mathbf{x\_{1}},\mathbf{x\_{2}},...\mathbf{x\_{n}})^{T}\in\mathbf{R}^{n\times d}$, where $var(\mathbf{x\_{i}})=1$, $mean(\mathbf{x\_{i}})=0$ and $q\_{i}\in\mathbf{R}$ for all $i\in[1,n]$, it satisfies that

|  |  |  |
| --- | --- | --- |
|  | $softmax(q\_{1},q\_{2},...,q\_{n})\mathbf{X}\overset{\Theta}{=}\mathbf{x\_{i}},$ |  |

where $\overset{\Theta}{=}$ stands for equal bound of magnitude.

In other words, the magnitude of attention output only depends on the value and output projection: $Attn(Q,K,V)\overset{\Theta}{=}VW^{V}W^{O}$. In this work, we only consider the magnitude of model update, so it is sufficiently instructive to study the case where the hidden dimension equals to $1$. For simplicity, we reduce the matrices $W^{V},W^{O}$ to the scalars $v,w$, which means $Attn(Q,K,V)\overset{\Theta}{=}vwV$. Similarly, we have $FFN(X)\overset{\Theta}{=}vwX$, where $v,w$ denotes the parameters of the feed-forward network.

We define the model update as $||\Delta F||=||F(x,\theta^{\*})-F(x,\theta)||$. Based on the analysis above, we have the following theorem to characterize $||\Delta F||$’s magnitude of an $N$-layer DeepNet with $N$ attentions and FFNs.

###### Theorem 4.2.

Given an $N$-layer DeepNet $F(x,\mathbf{\theta})$ ($\theta=\{\theta\_{1},\theta\_{2},...,\theta\_{2N}\}$), where $\theta\_{2l-1}$ and ${\theta\_{2l}}$ denote the parameters of self-attention and FFN in $l$-th layer, and each sub-layer is normalized with DeepNorm: $x\_{l+1}=LN(\alpha x\_{l}+G\_{l}(x\_{l},\theta\_{l}))$, $||\Delta F||$ satisfies:

|  |  |  |
| --- | --- | --- |
|  | $||\Delta F||\leq\sum\_{i=1}^{2N}\cfrac{\sqrt{v\_{i}^{2}+w\_{i}^{2}}}{\alpha}||\theta\_{i}^{\*}-\theta\_{i}||$ |  |

Vanilla Post-LN can be regarded as a special case of DeepNet, where $\alpha=1$ and $v\_{l}=w\_{l}=1$ at Xavier initialization ([Glorot and Bengio, 2010](#bib.bib17)). Based on [Theorem 4.2](#S4.Thmtheorem2 "Theorem 4.2. ‣ 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers"), we have $||\Delta F||=\mathcal{O}(\sum\_{i=1}^{2N}||\theta\_{i}^{\*}-\theta\_{i}||)$ for vanilla Post-LN. It shows that the model tends to accumulate the update of each sub-layer, which leads to exploding magnitude of model’s update and destabilizes the optimization at the early stage. This explains our findings in [Section 3](#S3 "3 Instability of Deep Transformer ‣ DeepNet: Scaling Transformers to 1,000 Layers").

Besides, [Theorem 4.2](#S4.Thmtheorem2 "Theorem 4.2. ‣ 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers") also explains why warm-ups and smaller initialization can stabilize the training of Post-LN. Warm-ups can reduce the magnitude of the model update by decreasing $||\theta\_{i}^{\*}-\theta\_{i}||$, while smaller initialization lowers $\sqrt{v\_{i}^{2}+w\_{i}^{2}}$.

Furthermore, we study the magnitude of DeepNet with an $N$-layer encoder and an $M$-layer decoder. Let $F\_{ed}(x,y,\theta\_{e},\theta\_{d})$ denotes the model, where $x,y$ is the input of encoder and decoder. $\theta\_{e}$ follows the same definition as $\theta$ in [Theorem 4.2](#S4.Thmtheorem2 "Theorem 4.2. ‣ 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers"). $\theta\_{d}=\{\theta\_{d1},\theta\_{d2},...,\theta\_{d,3M}\}$ stands for the parameters of self-attentions, cross-attentions, and FFNs. We use {$\alpha\_{e}$, $G\_{el}$} and {$\alpha\_{d}$, $G\_{dl}$} to distinguish the notations between the encoder and the decoder. The following theorem shows the expected magnitude of the encoder-decoder’s model update $||\Delta F\_{ed}||=||F\_{ed}(x,y,\theta\_{e}^{\*},\theta\_{d}^{\*})-F\_{ed}(x,y,\theta\_{e},\theta\_{d})||$.

###### Theorem 4.3.

Given an encoder-decoder DeepNet $F\_{ed}(x,y,\theta\_{e},\theta\_{d})$ with N encoder layers and M decoder layers, where each encoder sub-layer is normalized as $x\_{l+1}=LN(\alpha\_{e}x\_{l}+G\_{el}(x\_{l},\theta\_{el}))$, and the decoder sub-layer is normalized as $x\_{l+1}=LN(\alpha\_{d}x\_{l}+G\_{dl}(x\_{l},\theta\_{dl}))$, $||\Delta F\_{ed}||$ satisfies:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle||\Delta F\_{ed}||$ | $\displaystyle\leq\sum\_{j=1}^{M}\cfrac{v\_{d,3j-1}w\_{d,3j-1}}{\alpha\_{d}}\sum\_{i=1}^{2N}\cfrac{\sqrt{v\_{ei}^{2}+w\_{ei}^{2}}}{\alpha\_{e}}||\theta\_{ei}^{\*}-\theta\_{ei}||$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\quad+\sum\_{j=1}^{3M}\cfrac{\sqrt{v\_{dj}^{2}+w\_{dj}^{2}}}{\alpha\_{d}}||\theta\_{dj}^{\*}-\theta\_{dj}||$ |  | (1) |

The vanilla encoder-decoder model satisfies that all of {$\alpha\_{e}$, $\alpha\_{d}$, $v\_{ei}$, $w\_{ei}$, $v\_{di}$, $w\_{di}$} equal to $1$, so we have $||\Delta F\_{ed}||=\mathcal{O}(M\sum\_{i=1}^{2N}||\theta\_{ei}^{\*}-\theta\_{ei}||+\sum\_{j=1}^{3M}||\theta\_{dj}^{\*}-\theta\_{dj}||)$. It indicates the similar accumulative effect which leads to fast growth of the magnitude regarding the model depth (see [Figure 5](#S4.F5 "In 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers")). Furthermore, the cross-attention propagates the magnitude from the encoder to the decoder, which explains why the decoder is more unstable than the encoder ([Liu et al., 2020](#bib.bib26)).

Figure 5: Model updates of vanilla Post-LN and DeepNet at the early stage of training. The visualization is conducted on 64-128-2 tiny Transformers with depth varying from 6L-6L to 100L-100L. It shows that DeepNet has much smaller and more stable updates than Post-LN.

### 4.3 Derivation for DeepNorm and the Initialization

We show that the expected model updates for DeepNet can be bounded by a constant with proper parameters $\alpha$ and $\beta$.
Our analysis is based on SGD update, and we empirically verify it works well for Adam optimizer ([Kingma and Ba, 2015](#bib.bib23)).
We provide the analysis on the encoder-decoder architecture, which can be naturally extended to encoder-only and decoder-only models in the same way.
Analogous to [Zhang et al. (2019b)](#bib.bib44), we set our goal for the model update as follows:

GOAL: $F\_{ed}(x,y,\theta\_{e},\theta\_{d})$ is updated by $\Theta(\eta)$ per SGD step after initialization as $\eta\rightarrow 0$. That is $||\Delta F\_{ed}||=\Theta(\eta)$ where $\Delta F\_{ed}\overset{\Delta}{=}F\_{ed}(x,y,\theta\_{e}-\eta\frac{\partial\mathcal{L}}{\partial\theta\_{e}},\theta\_{d}-\eta\frac{\partial\mathcal{L}}{\partial\theta\_{d}})-F\_{ed}(x,y,\theta\_{e},\theta\_{d})$.

For SGD optimizer, the update of each decoder layer $||\theta\_{di}^{\*}-\theta\_{di}||$ equals to $\eta||\frac{\partial\mathcal{L}}{\partial\theta\_{di}}||$. [Xiong et al. (2020)](#bib.bib40) proved that Post-LN decreases the magnitude of backpropagating error signal, so we have $||\frac{\partial F}{\partial\theta\_{dj}}||\leq||\frac{\partial F}{\partial\theta\_{d,3M}}||$. With $||\frac{\partial F}{\partial\theta\_{d,3M}}||\overset{\Theta}{=}\frac{||\theta\_{d,3M}||}{\alpha\_{d}}$ and the assumption $||\frac{\partial\mathcal{L}}{\partial F}||=\mathcal{O}(1)$, the second term of [1](#S4.Ex8 "In Theorem 4.3. ‣ 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers") can be bounded as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\sum\_{j=1}^{3M}\cfrac{\sqrt{v\_{dj}^{2}+w\_{dj}^{2}}}{\alpha\_{d}}||\theta\_{dj}^{\*}-\theta\_{dj}||$ | $\displaystyle\leq\eta||\cfrac{\partial\mathcal{L}}{\partial F}||\cdot||\cfrac{\partial\mathcal{F}}{\partial\theta\_{d,3M}}||\sum\_{j=1}^{3M}\cfrac{\sqrt{v\_{dj}^{2}+w\_{dj}^{2}}}{\alpha\_{d}}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\overset{\Theta}{=}3\eta M\cfrac{v\_{d}^{2}+w\_{d}^{2}}{\alpha\_{d}^{2}}$ |  | (2) |

There are multiple schemes to bound [Equation 2](#S4.E2 "In 4.3 Derivation for DeepNorm and the Initialization ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers") by $\Theta(\eta)$.
In order to balance the effect of residual connections and the initialization, we set $\alpha\_{d}^{2}=(3M)^{\frac{1}{2}}$, $v\_{d}^{2}+w^{d}\_{2}=(3M)^{\frac{1}{2}}$ and $v\_{d}=w\_{d}=\beta\_{d}$ due to symmetry, that is $\alpha\_{d}=(3M)^{\frac{1}{4}}$, $\beta\_{d}=(12M)^{-\frac{1}{4}}$. Similarly, we use $v\_{e}=w\_{e}=\beta\_{e}=0.87(N^{4}M)^{-\frac{1}{16}},\alpha\_{e}=0.81(N^{4}M)^{\frac{1}{16}}$ to bound the first term in [1](#S4.Ex8 "In Theorem 4.3. ‣ 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers"). Detailed derivation is shown in [Appendix B](#A2 "Appendix B Derivation for Encoder-Decoder Architecture ‣ DeepNet: Scaling Transformers to 1,000 Layers").

In comparison with Post-LN, we visualize the model updates for DeepNet on IWSLT-14 De-En translation dataset at the early training stage.
[Figure 5](#S4.F5 "In 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers") shows that the model update of DeepNet is nearly constant, while the model update of Post-LN is exploding.

In summary, we apply our approach as follows:

Encoder-decoder architecture

1.

Apply standard initialization (e.g., Xavier initialization) for each encoder and decoder layer.
2.

For encoder layers, scale the weights of feed-forward networks as well as the value projection and the output projection of attention layers by $0.87(N^{4}M)^{-\frac{1}{16}}$, and set the weight of residual connections as $0.81(N^{4}M)^{\frac{1}{16}}$.
3.

For decoder layers, scale the weights of feed-forward networks as well as the value projection and the output projection of attention layers by $(12M)^{-\frac{1}{4}}$, and set the weight of residual connections as $(3M)^{\frac{1}{4}}$.

The derivation of encoder-only (such as BERT) and decoder-only (such as GPT) architectures can be conducted in the same way (see [Appendix C](#A3 "Appendix C Derivation for Encoder-only (Decoder-only) Architecture ‣ DeepNet: Scaling Transformers to 1,000 Layers")). We summarize the steps as follows:

Encoder-only (or decoder-only) architecture

1.

Apply standard initialization (e.g., Xavier initialization) for each layer.
2.

For each layer, scale the weights of feed-forward networks as well as the value projection and the output projection of attention layers by $(8N)^{-\frac{1}{4}}$ (or $(8M)^{-\frac{1}{4}}$), and set the weight of residual connections as $(2N)^{\frac{1}{4}}$ (or $(2M)^{\frac{1}{4}}$).

## 5 Neural Machine Translation

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Models | LN | 6L-6L | 18L-18L | 50L-50L | 100L-100L |
| Vanilla Post-LN ([Vaswani et al., 2017](#bib.bib37)) | Post | 28.1 | diverged | | |
| DS-Init ([Zhang et al., 2019a](#bib.bib42)) | Post | 27.9 | diverged | | |
| Admin ([Liu et al., 2020](#bib.bib26)) | Post | 27.9 | 28.8 | diverged | |
| ReZero ([Bachlechner et al., 2020](#bib.bib1)) | No | 26.9 | diverged | | |
| R-Fixup ([Zhang et al., 2019b](#bib.bib44)) | No | 27.5 | 28.4 | 27.7 | diverged |
| T-Fixup ([Huang et al., 2020](#bib.bib20)) | No | 27.5 | 28.4 | 27.9 | diverged |
| Vanilla Pre-LN ([Vaswani et al., 2017](#bib.bib37)) | Pre | 27.0 | 28.1 | 28.0 | 27.4 |
| DLCL ([Wang et al., 2019](#bib.bib38)) | Pre | 27.4 | 28.2 | diverged | 27.5 |
| NormFormer ([Shleifer et al., 2021](#bib.bib35)) | Pre | 27.0 | 28.3 | 27.8 | diverged |
| DeepNet (ours) | Deep | 27.8 | 28.8 | 29.0 | 28.9 |

Table 1: BLEU scores on the WMT-17 En-De test set for different models with varying depth. $A$L-$B$L refers to $A$-layer encoder and $B$-layer decoder.

We verify the effectiveness of DeepNet on the popular machine translation benchmarks, including IWSLT-14 German-English (De-En) dataset and WMT-17 English-German (En-De) dataset. We compare our method with multiple state-of-the-art deep Transformer models, including DLCL ([Wang et al., 2019](#bib.bib38)), NormFormer ([Shleifer et al., 2021](#bib.bib35)), ReZero ([Bachlechner et al., 2020](#bib.bib1)), R-Fixup ([Zhang et al., 2019b](#bib.bib44)), T-Fixup ([Huang et al., 2020](#bib.bib20)), DS-init ([Zhang et al., 2019a](#bib.bib42)), and Admin ([Liu et al., 2020](#bib.bib26)). We reproduce the baselines with their open-source code, and set the hyper-parameters the same for a fair comparison.

We use BLEU as the evaluation metric for all experiments. [Table 1](#S5.T1 "In 5 Neural Machine Translation ‣ DeepNet: Scaling Transformers to 1,000 Layers") reports the results of the baselines and DeepNet on WMT-17 En-De translation dataset. According to their LNs, the baselines are grouped into three categories: Pre-LN, Post-LN, and No-LN. All the compared models are base-size with different depths.

Compared with the models with Post-LN, DeepNet is more stable, and can successfully scale to 100L-100L, reaching the 28.9 BLEU on the test set. In contrast, the baselines with Post-LN lead to unstable optimization when the depth goes to 50L-50L. Besides, DeepNet achieves comparable performance with these baselines when the models are shallow.

In addition, we compare DeepNet with the methods without LN. Both R-Fixup and T-Fixup introduce better initialization methods, which stabilize the training of No-LN Transformer with up to 50-50 layers. Yet, their performance is not as good as those with Post-LN. Besides, half-precision could destabilize the training of ReZero, leading to its divergence with 18-18 layers. This observation is also reported by [Liu et al. (2020)](#bib.bib26). Moreover, deeper models (50L-50L) do not outperform the shallow models (18L-18L). In comparison, DeepNet achieves better translation accuracy than these methods, and scaling to deeper models brings no harm to the performance.

Compared with the Post-LN baselines, the models with Pre-LN are more stable. Both vanilla Pre-LN and DLCL can be scaled to 100L-100L, and 50L-50L NormFormer is also trained successfully. Nevertheless, Pre-LN leads to a 0.5-1.0 BLEU drop compared with the converged Post-LN models. We presume this should be caused by the problem that gradients of Pre-LN at earlier layers tend to be larger than gradients at later layers ([Shleifer et al., 2021](#bib.bib35)). We leave it as the future work. In contrast, DeepNet alleviates the problem by using Post-LN, and outperforms all the Pre-LN baselines.

#### Convergence with varying depth.

We vary the depths of the models from 10L-10L to 100L-100L with an interval of 10 layers.All experiments are conducted with mixed precision training, except ReZero11
1
According to our experiments, ReZero is unstable with half precision, even when the model is shallow.. [Figure 6](#S5.F6 "In Large learning rate, batch size, and hidden dimension. ‣ 5 Neural Machine Translation ‣ DeepNet: Scaling Transformers to 1,000 Layers") shows the results on the IWSLT-14 dataset. We train the models for 8,000 steps because we find most divergence occurs at the beginning of optimization. Overall, DeepNet is stable from shallow to deep. It converges fast, achieving over 30 BLEU in only 8,000 steps while most of the baselines do not. Moreover, the performance keeps improving as the model goes deeper.

#### Large learning rate, batch size, and hidden dimension.

We further scale DeepNet to larger learning rate, batch size, and hidden dimension, respectively. For each experiment, we only change one hyperparameter with the others fixed. [Figure 7](#S5.F7 "In Large learning rate, batch size, and hidden dimension. ‣ 5 Neural Machine Translation ‣ DeepNet: Scaling Transformers to 1,000 Layers") reports the loss curves on the WMT-17 validation set. It shows that DeepNet can be trained without difficulty in all the largest settings. The loss of DeepNet with 1024 hidden size increases after 10K steps because of overfitting. Besides, it indicates that DeepNet can benefit from the larger settings, resulting in faster convergence and lower validation loss.

Figure 6: BLEU scores on the IWSLT-14 De-En test set for different deep models with varing depth from 10L-10L to 100L-100L.

Figure 7: WMT-17 En-De validation loss curves for 18L-18L DeepNet with varing learning rate, batch size and hidden dimension.

## 6 Massively Multilingual Neural Machine Translation

Figure 8: Average BLEU scores for DeepNet with varying depth on the OPUS-100 En-X and X-En test sets.

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| Models | # Layers | # Params | X$\rightarrow$En | En$\rightarrow$X | Avg |
| Baseline ([Zhang et al., 2020](#bib.bib43)) | 12 | 133M | 27.5 | 21.4 | 24.5 |
| 24 | 173M | 29.5 | 22.9 | 26.2 |
| 48 | 254M | 31.4 | 24.0 | 27.7 |
| DeepNet (ours) | 200 | 863M | 33.2 | 29.0 | 31.1 |
| 1000 | 3.8B | 33.9 | 30.2 | 32.1 |

Table 2: Average BLEU for DeepNet and the baseline on the OPUS-100 test sets.

| Models | # Layers | # Params | WMT | OPUS | TED | Flores |
| --- | --- | --- | --- | --- | --- | --- |
| M2M-100 ([Fan et al., 2021](#bib.bib16)) | 48 | 12B | 31.9 | 18.4 | 18.7 | 13.6 |
| DeepNet (ours) | 200 | 3.2B | 33.9 | 23.0 | 20.1 | 18.6 |

Table 3: BLEU scores for DeepNet and M2M-100 on various evaluation sets.

We conduct experiments on the large-scale multilingual machine translation, which is a good testbed for large models. We first use OPUS-100 corpus ([Zhang et al., 2020](#bib.bib43)) to evaluate our model. OPUS-100 is an English-centric multilingual corpus covering 100 languages, which is randomly sampled from the OPUS collection. We scale DeepNet up to 1,000 layers. The model has a 500-layer encoder, a 500-layer decoder, 512 hidden size, 8 attention head, and 2,048 dimensions of feed-forward layers. More details can be found in the Appendix.

[Table 2](#S6.T2 "In 6 Massively Multilingual Neural Machine Translation ‣ DeepNet: Scaling Transformers to 1,000 Layers") summarizes the results of DeepNet and the baselines. It shows that increasing the depth can significantly improve the translation quality of NMT: the baseline of 48 layers achieves a gain of 3.2 points on average over the 12-layer model. DeepNet can successfully scale up the depth to 1,000 layers, outperforming the baseline by an improvement of 4.4 BLEU. It is noted that DeepNet is only trained for 4 epochs, and the performance can be further improved given more computation budgets.

#### Scaling law in terms of depth

We train DeepNet of {12, 20, 100, 200, 1000} layers on the OPUS-100 dataset. [Figure 8](#S6.F8 "In 6 Massively Multilingual Neural Machine Translation ‣ DeepNet: Scaling Transformers to 1,000 Layers") illustrates the scaling curve. Compared with bilingual NMT, multilingual NMT benefits more from scaling the depth of the model because of its hunger in model capacity. We observe logarithmic growth of the BLEU score for multilingual NMT, and the scaling law can be written as:

|  |  |  |
| --- | --- | --- |
|  | $L(d)=A\log(d)+B$ |  |

where $d$ is the depth, and $A,B$ are the constants regarding the other hyper-parameters.

#### More data and language directions.

To explore the limits of DeepNet on multilingual NMT, we then scale up the training data by using CCMatrix ([Schwenk et al., 2021](#bib.bib34)). We also expand the data from CCAligned ([El-Kishky et al., 2020](#bib.bib15)), OPUS ([Zhang et al., 2020](#bib.bib43)), and Tatoeba22
2
<https://tatoeba.org/en/> to cover all languages of Flores101 evaluation sets. The final data consists of 102 languages, 1932 directions, and 12B sentence pairs. With the data, we train DeepNet with a 100-layer encoder, 100-layer decoder, 1,024 hidden dimension, 16 heads, and 4,096 intermediate dimension of feed-forward layers. More details can be found in the Appendix.

We compare DeepNet with the state-of-the-art multilingual NMT model M2M-100 ([Fan et al., 2021](#bib.bib16)). M2M-100 has a 24-layer encoder, a 24-layer decoder, and 4,096 hidden size, resulting in up to 12B parameters. Compared with M2M-100, DeepNet is deep and narrow with only 3.2B parameters. For a fair comparison, we generate the model with beam size 5 and length penalty 1.

Following M2M-100 ([Fan et al., 2021](#bib.bib16)), we evaluate the models on several multilingual translation evaluation datasets, including WMT ([Bojar et al., 2014](#bib.bib5); [Bojar et al., 2017](#bib.bib6); [Bojar et al., 2018](#bib.bib7); [Barrault et al., 2019](#bib.bib4)), OPUS ([Zhang et al., 2020](#bib.bib43)), TED ([Qi et al., 2018](#bib.bib30)), and Flores ([Goyal et al., 2021](#bib.bib18)). The language pairs from the WMT dataset are English-centric. There are 10 languages including English, and most of them are high-resource. For the OPUS dataset, we select the non-English directions from the test set, which has 30 evaluation pairs. The TED evaluation set has 28 languages and 756 directions, and the data is from the spoken language domain. The Flores dataset has all translation pairs between 102 languages. We use a subset covering the languages supported by both M2M-100 and DeepNet, resulting in 87 languages and 7,482 translation directions.

We report the results in [Table 3](#S6.T3 "In 6 Massively Multilingual Neural Machine Translation ‣ DeepNet: Scaling Transformers to 1,000 Layers"). For a fair comparison, we use the same evaluation methods as the baseline. The details can be found in the Appendix. It shows that DeepNet has significantly better performance than M2M-100 on all evaluation datasets, indicating that deepening the model is a very promising direction to improve the quality of NMT models.

## 7 Conclusion and Future Work

We improve the stability of Transformer and successfully scale it to 1,000 layers. This is achieved by our DeepNet with a novel normalization function called DeepNorm. It has theoretical justification to stabilize the optimization with a constant upper bound for model updates. Experimental results verify the effectiveness of our methods across various benchmarks.
We focus on machine translation as a test bed in the current experiments.
In the future, we will extend DeepNet to support more diverse tasks, e.g., language model pre-training ([Dong et al., 2019](#bib.bib13); [Bao et al., 2020](#bib.bib2); [Chi et al., 2021a](#bib.bib9); [Ma et al., 2021](#bib.bib27); [Chi et al., 2021b](#bib.bib10)), protein structure prediction ([Jumper et al., 2021](#bib.bib22)), and BEiT vision pre-training ([Bao et al., 2022](#bib.bib3); [Wang et al., 2021](#bib.bib39)).

#### Acknowledgement

We would like to acknowledge Saksham Singhal for the CCMatrix corpus.

## Appendix A Main Theorem Proof

### A.1 Proof of [Lemma 4.1](#S4.Thmtheorem1 "Lemma 4.1. ‣ 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers")

###### Lemma A.1.

Given $\mathbf{X}=(\mathbf{x\_{1}},\mathbf{x\_{2}},...\mathbf{x\_{n}})^{T}\in\mathbf{R}^{n\times d}$, where $var(\mathbf{x\_{i}})=1$, $mean(\mathbf{x\_{i}})=0$ and $q\_{i}\in\mathbf{R}$ for all $i\in[1,n]$, it satisfies that

|  |  |  |
| --- | --- | --- |
|  | $softmax(q\_{1},q\_{2},...,q\_{n})\mathbf{X}\overset{\Theta}{=}\mathbf{x\_{i}},$ |  |

where $\overset{\Theta}{=}$ stands for equal bound of magnitude.

###### Proof.

The weight $s\_{i}$ of $\mathbf{x\_{i}}$ to output is $s\_{i}=\cfrac{e^{q\_{i}}}{e^{\sum\_{j=1}^{n}q\_{j}}}$, $\sum\_{i=1}^{n}s\_{i}=1$.

|  |  |  |  |
| --- | --- | --- | --- |
|  | $||\text{softmax}(q\_{1},q\_{2},...,q\_{n})\mathbf{X}||=||\sum\_{i=1}^{n}s\_{i}\mathbf{x\_{i}}||\leq\sum\_{i=1}^{n}s\_{i}||\mathbf{x\_{i}}||$ |  | (3) |

With $var(\mathbf{x\_{i}})=1$, $mean(\mathbf{x\_{i}})=0$, for all $i\in[1,n]$, we have $||\mathbf{x\_{i}}||=d$. Therefore, $||\text{softmax}(q\_{1},q\_{2},...,q\_{n})\mathbf{X}||\leq||\mathbf{x\_{i}}||=d$, which is equivalent to softmax$(q\_{1},q\_{2},...,q\_{n})\mathbf{X}\overset{\Theta}{=}\mathbf{x\_{i}}$.
∎

### A.2 Proof of [Theorem 4.2](#S4.Thmtheorem2 "Theorem 4.2. ‣ 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers")

###### Theorem A.2.

Given an $N$-layer DeepNet $F(x,\mathbf{\theta})$ ($\theta=\{\theta\_{1},\theta\_{2},...,\theta\_{2N}\}$), where $\theta\_{2l-1}$ and ${\theta\_{2l}}$ denote the parameters of self-attention and FFN in $l$-th layer, and each sub-layer is normalized with DeepNorm: $x\_{l+1}=LN(\alpha x\_{l}+G\_{l}(x\_{l},\theta\_{l}))$, $||\Delta F||$ satisfies:

|  |  |  |
| --- | --- | --- |
|  | $||\Delta F||\leq\sum\_{i=1}^{2N}\cfrac{\sqrt{v\_{i}^{2}+w\_{i}^{2}}}{\alpha}||\theta\_{i}^{\*}-\theta\_{i}||$ |  |

###### Proof.

Our aim is to study the magnitude of model updates. Following [Zhang et al. [2019b]](#bib.bib44), we make the following assumptions to simplify the derivations:

1. 1.

   Hidden dimension $d$ equals to $1$.
2. 2.

   $var(x+G\_{l}(x))\overset{\Theta}{=}var(x)+var(G\_{l}(x))$
3. 3.

   All relevant weights $v,w$ are positive with magnitude less than 1 and $\alpha,\beta$ for DeepNorm are positive with magnitude greater than 1.

Given Assumption 1, if $G(x)$ is feed-forward network with $\theta=\{v,w\}$, then $G(x)\overset{\Theta}{=}vwx$. According to [Lemma 4.1](#S4.Thmtheorem1 "Lemma 4.1. ‣ 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers"), the query and key projections do not change the bound of the attention output’s magnitude. Therefore, if $G(x)$ is self-attention with $\theta=\{q,k,v,w\}$, then $G(x)\overset{\Theta}{=}vwx$. Especially, if Xavier initialization is used for the projection, then the output can preserve the input variance, which is equivalent to $v=w=1$.
With Assumption 2, we have:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $x\_{l+1}=f\_{l}(x\_{l},\theta\_{l})=\cfrac{\alpha x+G\_{l}(x)}{\sqrt{Var(\alpha x+G\_{l}(x))}}\overset{\Theta}{=}\cfrac{\alpha+v\_{l}w\_{l}}{\sqrt{\alpha^{2}+v\_{l}^{2}w\_{l}^{2}}}x$ |  | (4) |

With [Equation 4](#A1.E4 "In Proof. ‣ A.2 Proof of ‣ Appendix A Main Theorem Proof ‣ DeepNet: Scaling Transformers to 1,000 Layers"), the magnitude of $\frac{\partial f\_{l}}{\partial x}$ and $\frac{\partial f\_{l}}{\partial\theta\_{l}}$ is bounded by:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\cfrac{\partial f\_{l}}{\partial x}$ | $\displaystyle\overset{\Theta}{=}\cfrac{\alpha+v\_{l}w\_{l}}{\sqrt{\alpha^{2}+v\_{l}^{2}w\_{l}^{2}}}$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\cfrac{\partial f\_{l}}{\partial\theta\_{l}}$ | $\displaystyle\overset{\Theta}{=}(\cfrac{\partial f}{\partial v\_{l}},\cfrac{\partial f}{\partial w\_{l}})\overset{\Theta}{=}\cfrac{\alpha x\_{l}(\alpha-v\_{l}w\_{l})}{(\alpha^{2}+v\_{l}^{2}w\_{l}^{2})^{\frac{3}{2}}}\,(w\_{l},v\_{l})$ |  | (5) |

Besides, the model update $||\Delta F||$ satisfies:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $||\Delta F||=||F(x,\theta^{\*})-F(x,\theta)||=||x\_{{2N}+1}^{\*}-x\_{{2N}+1}||=||f(x\_{2N}^{\*},\theta\_{2N}^{\*})-f(x\_{2N},\theta\_{2N})||\\$ |  | (6) |

Using Taylor expansion for [Equation 6](#A1.E6 "In Proof. ‣ A.2 Proof of ‣ Appendix A Main Theorem Proof ‣ DeepNet: Scaling Transformers to 1,000 Layers"), we get:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle||\Delta F||$ | $\displaystyle=||x\_{{2N}+1}^{\*}-x\_{{2N}+1}||$ |  | (7) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\approx||\cfrac{\partial f}{\partial x}(x\_{2N},\theta\_{2N})(x\_{2N}^{\*}-x\_{2N})+\cfrac{\partial f}{\partial\theta}(x\_{2N},\theta\_{2N})(\theta\_{2N}^{\*}-\theta\_{2N})^{T}||$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leq||\cfrac{\partial f}{\partial x}(x\_{2N},\theta\_{2N})||\cdot||x\_{2N}^{\*}-x\_{2N}||+||\cfrac{\partial f}{\partial\theta}(x\_{2N},\theta\_{2N})||\cdot||\theta\_{2N}^{\*}-\theta\_{2N}||$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\cfrac{\alpha+v\_{2N}w\_{2N}}{\sqrt{\alpha^{2}+v\_{2N}^{2}w\_{2N}^{2}}}||x\_{2N}^{\*}-x\_{2N}||+\cfrac{\alpha(\alpha-v\_{2N}w\_{2N})}{(\alpha^{2}+v\_{2N}^{2}w\_{2N}^{2})^{\frac{3}{2}}}\sqrt{v\_{2N}^{2}+w\_{2N}^{2}}||\theta\_{2N}^{\*}-\theta\_{2N}||$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\approx||x\_{2N}^{\*}-x\_{2N}||+\cfrac{\sqrt{v\_{2N}^{2}+w\_{2N}^{2}}}{\alpha}||\theta\_{2N}^{\*}-\theta\_{2N}||$ |  | (8) |

Then, we have:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $||x\_{2N+1}^{\*}-x\_{2N+1}||\leq\sum\_{i=1}^{2N}\cfrac{\sqrt{v\_{i}^{2}+w\_{i}^{2}}}{\alpha}||\theta\_{i}^{\*}-\theta\_{i}||$ |  | (9) |

∎

For vanilla Post-LN with standard initialization, $\alpha=v\_{i}=w\_{i}=1$, so $||\Delta F||=\mathcal{O}(\sum\_{i=1}^{2N}||\theta\_{i}^{\*}-\theta\_{i}||)$.

Proof of [Theorem 4.3](#S4.Thmtheorem3 "Theorem 4.3. ‣ 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers")

###### Theorem A.3.

Given an encoder-decoder DeepNet $F\_{ed}(x,y,\theta\_{e},\theta\_{d})$ with N encoder layers and M decoder layers, where each encoder sub-layer is normalized as $x\_{l+1}=LN(\alpha\_{e}x\_{l}+G\_{el}(x\_{l},\theta\_{el}))$, and the decoder sub-layer is normalized as $x\_{l+1}=LN(\alpha\_{d}x\_{l}+G\_{dl}(x\_{l},\theta\_{dl}))$, $||\Delta F\_{ed}||$ satisfies:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle||\Delta F\_{ed}||$ | $\displaystyle\leq\sum\_{j=1}^{M}\cfrac{v\_{d,3j-1}w\_{d,3j-1}}{\alpha\_{d}}\sum\_{i=1}^{2N}\cfrac{\sqrt{v\_{ei}^{2}+w\_{ei}^{2}}}{\alpha\_{e}}||\theta\_{ei}^{\*}-\theta\_{ei}||$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\quad+\sum\_{j=1}^{3M}\cfrac{\sqrt{v\_{dj}^{2}+w\_{dj}^{2}}}{\alpha\_{d}}||\theta\_{dj}^{\*}-\theta\_{dj}||$ |  | (10) |

###### Proof.

The derivation of self-attention and FFN layers is given in [Section A.2](#A1.SS2 "A.2 Proof of ‣ Appendix A Main Theorem Proof ‣ DeepNet: Scaling Transformers to 1,000 Layers"). For the cross-attention layers, we have:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $y\_{l+1}=f\_{dl}(y\_{l},x\_{e},\theta\_{dl})=\cfrac{\alpha\_{d}y\_{l}+G\_{l}(x\_{e},y\_{l})}{\sqrt{Var(\alpha\_{d}y\_{l}+G\_{dl}(x\_{e},y\_{l}))}}\overset{\Theta}{=}\cfrac{\alpha\_{d}y\_{l}+v\_{l}w\_{l}x\_{e}}{\sqrt{\alpha\_{d}^{2}+v\_{l}^{2}w\_{l}^{2}}}$ |  | (11) |

With [Equation 11](#A1.E11 "In Proof. ‣ A.2 Proof of ‣ Appendix A Main Theorem Proof ‣ DeepNet: Scaling Transformers to 1,000 Layers"), we have the bound of the derivative of $f\_{dl}$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\cfrac{\partial f\_{dl}}{\partial y}$ | $\displaystyle\overset{\Theta}{=}\cfrac{\alpha\_{d}}{\sqrt{\alpha\_{d}^{2}+v\_{l}^{2}w\_{l}^{2}}},\quad\cfrac{\partial f\_{dl}}{\partial x\_{e}}\overset{\Theta}{=}\cfrac{v\_{l}w\_{l}}{\sqrt{\alpha\_{d}^{2}+v\_{l}^{2}w\_{l}^{2}}}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\cfrac{\partial f\_{dl}}{\partial\theta\_{dl}}$ | $\displaystyle\overset{\Theta}{=}(\cfrac{\partial f\_{dl}}{\partial v\_{dl}},\cfrac{\partial f\_{dl}}{\partial w\_{dl}})\overset{\Theta}{=}\cfrac{\alpha\_{d}x\_{e}(\alpha\_{d}-v\_{dl}w\_{dl})}{(\alpha\_{d}^{2}+v\_{dl}^{2}w\_{dl}^{2})^{\frac{3}{2}}}\,(w\_{dl},v\_{dl})$ |  |

By means of Taylor expansion, we estimate the update of $l$-th cross-attention layer $||y\_{l+1}^{\*}-y\_{l+1}||$ as:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle||y\_{l+1}^{\*}-y\_{l+1}||$ | $\displaystyle=||f\_{dl}^{\*}(y\_{l}^{\*},x\_{2N+1}^{\*},\theta\_{dl}^{\*})-f\_{dl}(y\_{l},x\_{2N+1},\theta\_{dl})||$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\approx\cfrac{\alpha\_{d}}{\sqrt{\alpha\_{d}^{2}+v\_{dl}^{2}w\_{dl}^{2}}}||y\_{l}^{\*}-y\_{l}||+\cfrac{v\_{dl}w\_{dl}}{\sqrt{\alpha\_{d}^{2}+v\_{dl}^{2}w\_{dl}^{2}}}||x\_{2N+1}^{\*}-x\_{2N+1}||$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\quad+\cfrac{\alpha\_{d}(\alpha\_{d}-v\_{dl}w\_{dl})}{(\alpha\_{d}^{2}+v\_{dl}^{2}w\_{dl}^{2})^{\frac{3}{2}}}\,\sqrt{v\_{dl}^{2}+w\_{dl}^{2}}||\theta\_{dl}^{\*}-\theta\_{dl}||$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\leq||y\_{l}^{\*}-y\_{l}||+\cfrac{v\_{dl}w\_{dl}}{\alpha\_{d}}||x\_{2N+1}^{\*}-x\_{2N+1}||+\cfrac{\sqrt{v\_{dl}^{2}+w\_{dl}^{2}}}{\alpha\_{d}}||\theta\_{dl}^{\*}-\theta\_{dl}||$ |  | (12) |

According to [Theorem 4.2](#S4.Thmtheorem2 "Theorem 4.2. ‣ 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers"), we have $||x\_{2N+1}^{\*}-x\_{2N+1}||=\mathcal{O}(\sum\_{i=1}^{2N}\frac{\sqrt{v\_{ei}^{2}+w\_{ei}^{2}}}{\alpha\_{e}}||\theta\_{ei}^{\*}-\theta\_{ei}||)$. Therefore, the magnitude of $||\Delta F\_{ed}||$ satisfies:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $||\Delta F\_{ed}||\leq\sum\_{j=1}^{M}\cfrac{v\_{d,3j-1}w\_{d,3j-1}}{\alpha\_{d}}\sum\_{i=1}^{2N}\cfrac{\sqrt{v\_{ei}^{2}+w\_{ei}^{2}}}{\alpha\_{e}}||\theta\_{ei}^{\*}-\theta\_{ei}||+\sum\_{j=1}^{3M}\cfrac{\sqrt{v\_{dj}^{2}+w\_{dj}^{2}}}{\alpha\_{d}}||\theta\_{dj}^{\*}-\theta\_{dj}||$ |  | (13) |

∎

As a special case, the corresponding parameters in [Equation 13](#A1.E13 "In Proof. ‣ A.2 Proof of ‣ Appendix A Main Theorem Proof ‣ DeepNet: Scaling Transformers to 1,000 Layers") for vanilla Post-LN with standard initialization are $1$, so its model update $||\Delta F\_{ed}||=\mathcal{O}(M\sum\_{i=1}^{2N}||\theta\_{ei}^{\*}-\theta\_{ei}||+\sum\_{j=1}^{3M}||\theta\_{dj}^{\*}-\theta\_{dj}||)$.

## Appendix B Derivation for Encoder-Decoder Architecture

Here, we give the derivation of DeepNet for the encoder-decoder architecture with an $N$-layer encoder and an $M$-layer decoder.
As in [Section 4.3](#S4.SS3 "4.3 Derivation for DeepNorm and the Initialization ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers"), we have $v\_{d}=w\_{d}=(12M)^{-\frac{1}{4}}$, $\alpha\_{d}=(3M)^{\frac{1}{4}}$ to bound the second term of [Equation 13](#A1.E13 "In Proof. ‣ A.2 Proof of ‣ Appendix A Main Theorem Proof ‣ DeepNet: Scaling Transformers to 1,000 Layers") to $\Theta(\eta)$. For the first term, we set $v\_{ei}=v\_{e},w\_{ei}=w\_{e}$, so that it goes to:

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\sum\_{j=1}^{M}\cfrac{v\_{d,3j-1}w\_{d,3j-1}}{\alpha\_{d}}\sum\_{i=1}^{2N}\cfrac{\sqrt{v\_{ei}^{2}+w\_{ei}^{2}}}{\alpha\_{e}}||\theta\_{ei}^{\*}-\theta\_{ei}||$ | $\displaystyle=M\cfrac{(12M)^{-\frac{1}{2}}}{(3M)^{\frac{1}{4}}}\sum\_{i=1}^{2N}\cfrac{\sqrt{v\_{ei}^{2}+w\_{ei}^{2}}}{\alpha\_{e}}||\theta\_{ei}^{\*}-\theta\_{ei}||$ |  | (14) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\overset{\Theta}{=}\eta\left(\cfrac{N^{4}M}{27}\right)^{\frac{1}{4}}\cfrac{v\_{e}^{2}+w\_{e}^{2}}{\alpha\_{e}^{2}}$ |  | (15) |

In this work, we use $\alpha\_{e}^{2}=(N^{4}M/27)^{\frac{1}{8}}$, $v\_{e}^{2}+w\_{e}^{2}=(N^{4}M/27)^{-\frac{1}{8}}$ and $v\_{e}=w\_{e}=\beta\_{e}$ that is $\alpha\_{e}=0.81(N^{4}M)^{\frac{1}{16}}$, $\beta\_{e}=0.87(N^{4}M)^{-\frac{1}{16}}$ to satisfy the condition.

## Appendix C Derivation for Encoder-only (Decoder-only) Architecture

For an $N$-layer DeepNet, starting from [Theorem 4.2](#S4.Thmtheorem2 "Theorem 4.2. ‣ 4.2 Expected Magnitude of Model Update ‣ 4 DeepNet: Extremely Deep Transformers ‣ DeepNet: Scaling Transformers to 1,000 Layers") we have,

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle||x\_{2N+1}^{\*}-x\_{2N+1}||\leq\sum\_{i=1}^{2N}\cfrac{\sqrt{v\_{i}^{2}+w\_{i}^{2}}}{\alpha}||\theta\_{i}^{\*}-\theta\_{i}||$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\leq\eta\sum\_{i=1}^{2N}\cfrac{\sqrt{v\_{i}^{2}+w\_{i}^{2}}}{\alpha}||\cfrac{\partial\mathcal{L}}{\partial F}||\cdot||\cfrac{\partial F}{\partial\theta\_{i}}||$ |  | (16) |

By assumption $||\frac{\partial\mathcal{L}}{\partial F}||=\mathcal{O}(1)$, and $||\frac{\partial F}{\partial\theta\_{i}}||\leq||\frac{\partial F}{\partial\theta\_{2N}}||\overset{\Theta}{=}\frac{||\theta\_{2N}||}{\alpha}$, we achieve:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\sum\_{i=1}^{2N}\cfrac{\sqrt{v\_{i}^{2}+w\_{i}^{2}}}{\alpha}||\cfrac{\partial\mathcal{L}}{\partial F}||\cdot||\cfrac{\partial F}{\partial\theta\_{i}}||\leq\mathcal{O}(\cfrac{\sqrt{v\_{2N}^{2}+w\_{2N}^{2}}}{\alpha}\sum\_{i=1}^{2N}\cfrac{\sqrt{v\_{i}^{2}+w\_{i}^{2}}}{\alpha})=\mathcal{O}(1)$ |  | (17) |

Due to symmetry, we set $v\_{i}=v,w\_{j}=w$, so it goes to $2N\frac{v^{2}+w^{2}}{\alpha^{2}}=1$. In this work, we use $v=w=(8N)^{-\frac{1}{4}}$ and $\alpha=(2N)^{\frac{1}{4}}$ to satisfy the condition.

## Appendix D Experimental Details

### D.1 Hyperparameters for IWSLT-14 De-En

|  |  |
| --- | --- |
| Hyperparameters | Value |
| Learning rate | 5e-4 |
| Learning rate scheduler | inverse sqrt |
| Warm-up updates | 4000 |
| Warm-up init learning rate | 1e-7 |
| Max tokens | 4000 |
| Adam $\epsilon$ | 1e-8 |
| Adam $\beta$ | (0.9, 0.98) |
| Label smoothing | 0.1 |
| Training updates | 8K |
| Gradient clipping | 0.0 |
| Dropout | 0.4 |
| Weight decay | 0.0001 |
| Hidden size | 512 |
| FFN inner hidden size | 2048 |
| Attention heads | 8 |

Table 4: Hyperparameters for the machine translation experiments on the IWSLT-14 De-En dataset.

### D.2 Hyperparameters for WMT-17 En-De

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
| Hyperparameters | No-LN | Pre-LN | Post-LN | DeepNorm |
| Learning rate | 5e-4 | 1.5e-3 | 1.5e-3 | 1.5e-3 |
| Learning rate scheduler | inverse sqrt | | | |
| Warm-up updates | 4000 | | | |
| Warm-up init learning rate | 1e-7 | | | |
| Max tokens | 128 $\times$ 4096 | | | |
| Adam $\epsilon$ | 1e-8 | | | |
| Adam $\beta$ | (0.9, 0.98) | | | |
| Label smoothing | 0.1 | | | |
| Training updates | 100K | | | |
| Gradient clipping | 0.0 | | | |
| Dropout | 0.4 | | | |
| Weight decay | 0.0001 | | | |
| Hidden size | 512 | | | |
| FFN inner hidden size | 2048 | | | |
| Attention heads | 8 | | | |

Table 5: Hyperparameters for the base-setting experiments on the WMT-17 En-De dataset.

|  |  |  |  |
| --- | --- | --- | --- |
| Hyperparameters | Base size | Medium size | Large size |
| Hidden size | 512 | 768 | 1,024 |
| FFN inner hidden size | 2048 | 3072 | 4096 |
| Attention heads | 8 | 12 | 16 |
| Layers | 18-18 | | |
| Learning rate | 5e-4 | | |
| Learning rate scheduler | inverse sqrt | | |
| Warm-up updates | 4000 | | |
| Warm-up init learning rate | 1e-7 | | |
| Max tokens | 128 $\times$ 4096 | | |
| Adam $\epsilon$ | 1e-6 | | |
| Adam $\beta$ | (0.9, 0.98) | | |
| Label smoothing | 0.1 | | |
| Training updates | 30K | | |
| Gradient clipping | 1.0 | | |
| Dropout | 0.4 | | |
| Weight decay | 0.0 | | |

Table 6: Hyperparameters for the large-setting experiments on the WMT-17 En-De dataset.

### D.3 Hyperparameters for OPUS-100

|  |  |
| --- | --- |
| Hyperparameters | Value |
| Learning rate | 5e-4 |
| Learning rate scheduler | inverse sqrt |
| Warm-up updates | 4000 |
| Warm-up init learning rate | 1e-7 |
| Max tokens | 128 $\times$ 4096 |
| Adam $\epsilon$ | 1e-8 |
| Adam $\beta$ | (0.9, 0.98) |
| Label smoothing | 0.1 |
| Training epochs | 4 |
| Gradient clipping | 0.0 |
| Dropout | 0.1 |
| Weight decay | 0.0 |
| Hidden size | 512 |
| FFN inner hidden size | 2048 |
| Attention heads | 8 |

Table 7: Hyperparameters for the machine translation experiments on the OPUS-100 dataset.

### D.4 Hyperparameters for 102-Language Machine Translation

|  |  |
| --- | --- |
| Hyperparameters | Value |
| Learning rate | 5e-4 |
| Learning rate scheduler | inverse sqrt |
| Warm-up updates | 6000 |
| Warm-up init learning rate | 1e-7 |
| Max tokens | 256 $\times$ 4096 |
| Adam $\epsilon$ | 1e-6 |
| Adam $\beta$ | (0.9, 0.98) |
| Label smoothing | 0.1 |
| Training updates | 260K |
| Gradient clipping | 1.0 |
| Dropout | 0.1 |
| Weight decay | 0.0 |
| Hidden size | 1024 |
| FFN inner hidden size | 4096 |
| Attention heads | 16 |
| Layers | 100-100 |

Table 8: Hyperparameters for the machine translation experiments on the 102-language dataset.

### D.5 Evaluation Details

For IWSLT-14 and WMT-17, we use the in-built BLEU scripts of Fairseq to report the scores.
Besides, we report the case-sensitive detokenized BLEU using sacreBLEU [[Post, 2018](#bib.bib29)] for the results of OPUS-100.33
3
BLEU+case.mixed+lang.{src}-{tgt}+numrefs.1+smooth.exp+tok.13a+version.1.4.14

For WMT, OPUS, and TED, we use the same test sets and evaluation scripts as in M2M [[Fan et al., 2021](#bib.bib16)], and the results of M2M are directly from the paper [[Fan et al., 2021](#bib.bib16)]. For the Flores-101 evaluation set, we report the spBLEU44
4
<https://github.com/facebookresearch/flores> of M2M-12B with the public checkpoint and script.55
5
<https://github.com/pytorch/fairseq/tree/main/examples/m2m_100>

## Appendix E Experimental Results in [Section 6](#S6 "6 Massively Multilingual Neural Machine Translation ‣ DeepNet: Scaling Transformers to 1,000 Layers")

Figure 9: Evaluation results of 12B M2M-100 on a subset of FLORES-101 devtest set. The $i$-th row is the source language, while $j$-th column is the target language. There are 87 languages and 7,482 directions.

Figure 10: Evaluation results of 3.2B DeepNet on a subset of FLORES-101 devtest set. The $i$-th row is the source language, while $j$-th column is the target language. There are 87 languages and 7,482 directions.
