<!-- fulltext source=arxiv_html slug=arXiv-1912.05671 fetched=2026-09-16T11:52:11+00:00 -->

# Linear Mode Connectivity and the Lottery Ticket Hypothesis

Jonathan Frankle
Affiliation: MIT CSAIL
Correspondence to: [jfrankle@mit.edu](mailto:jfrankle@mit.edu)
  
Gintare Karolina Dziugaite
Affiliation: Element AI
  
Daniel M. Roy
Affiliation: University of Toronto
Affiliation: Vector Institute
  
Michael Carbin
Affiliation: MIT CSAIL

###### Abstract

We study whether a neural network optimizes to the same, linearly connected minimum under different samples of SGD noise (e.g., random data order and augmentation). We find that standard vision models become *stable to SGD noise* in this way early in training. From then on, the outcome of optimization is determined to a linearly connected region.
We use this technique to study *iterative magnitude pruning* (IMP), the procedure used by work on the lottery ticket hypothesis to identify subnetworks that could have trained in isolation to full accuracy. We find that these subnetworks only reach full accuracy when they are stable to SGD noise, which either occurs at initialization for small-scale settings (MNIST) or early in training for large-scale settings (ResNet-50 and Inception-v3 on ImageNet).

## 1 Introduction

When training a neural network with mini-batch stochastic gradient descent (SGD), training examples are presented to the network in a random order within each epoch.
In many cases, each example also undergoes random data augmentation.
This randomness can be seen as *noise* that varies from training run to training run and alters the network’s trajectory through the optimization landscape, even when the initialization and hyperparameters are fixed.
In this paper, we investigate how this SGD noise affects the outcome of optimizing neural networks and the role this effect plays in sparse, *lottery ticket* networks ([Frankle & Carbin, 2019](#bib.bib4)).

$W\_{0}$$W\_{T}^{1}$$W\_{T}^{2}$Instability

$W\_{0}$$W\_{k}$$W\_{T}^{1}$$W\_{T}^{2}$Instability

Figure 1: A diagram of instability analysis from step 0 (left) and step $k$ (right) when comparing networks using linear interpolation.

Instability analysis.
To study these questions, we propose *instability analysis*.
The goal of instability analysis is to determine whether the outcome of optimizing a particular neural network is *stable to SGD noise*.
Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") (left) visualizes instability analysis.
First, we create a network $\mathcal{N}$ with random initialization $W\_{0}$.
We then train two copies of $\mathcal{N}$ with different samples of SGD noise (i.e., different random data orders and augmentations).
Finally, we compare the resulting networks to measure the effect of these different samples of SGD noise on the outcome of optimization.
If the networks are sufficiently similar according to a criterion, we determine $\mathcal{N}$ to be stable to SGD noise.
We also study this behavior starting from the state of $\mathcal{N}$ at step $k$ of training (Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") right).
Doing so allows us to determine *when* the outcome of optimization becomes stable to SGD noise.

There are many possible ways in which to compare the networks that result from instability analysis (Appendix [G](#A7 "Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")).
We use the behavior of the optimization landscape along the line between these networks (blue in Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")).
Does error remain flat or even decrease (meaning the networks are in the same, linearly connected minimum), or is there a barrier of increased error?
We define the *linear interpolation instability* of $\mathcal{N}$ to SGD noise as the maximum increase in error along this path (red).
We consider $\mathcal{N}$ stable to SGD noise if error does not increase along this path, i.e., instability $\approx$ 0.
This means $\mathcal{N}$ will find the same, linearly connected minimum regardless of the sample of SGD noise.

By linearly interpolating at the end of training in this fashion, we assess a linear form of *mode connectivity*, a phenomenon where the minima found by two networks are connected by a path of nonincreasing error.
[Freeman & Bruna (2017)](#bib.bib6), [Draxler et al. (2018)](#bib.bib2), and [Garipov et al. (2018)](#bib.bib8) show that the modes of standard vision networks trained from different initializations are connected by nonlinear paths of constant error or loss.
Based on this work, we expect that all networks we examine are connected by such paths.
However, the modes found by [Draxler et al.](#bib.bib2) and [Garipov et al.](#bib.bib8) are not connected by *linear* paths.
The only extant example of linear mode connectivity is by [Nagarajan & Kolter (2019)](#bib.bib23), who train MLPs from the same initialization on disjoint subsets of MNIST and find that the resulting networks are connected by linear paths of constant test error.
In contrast, we explore linear mode connectivity from points throughout training, we do so at larger scales, and we focus on different samples of SGD noise rather than disjoint samples of data.

|  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Network | Variant | Dataset | Params | Train Steps | Batch | Accuracy | Optimizer | Rate | Schedule | Warmup | BatchNorm | Pruned Density | Style |
| LeNet |  | MNIST | 266K | 24K Iters | 60 | 98.3 $\pm$ 0.1% | adam | 12e-4 | constant | 0 | No | 3.5% | Iterative |
| ResNet-20 | Standard |  |  |  |  | 91.7 $\pm$ 0.1% |  | 0.1 | 10x drop at  32K, 48K | 0 | Yes | 16.8% | Iterative |
| ResNet-20 | Low | CIFAR-10 | 274K | 63K Iters | 128 | 88.8 $\pm$ 0.1% | momentum | 0.01 | 0 | 8.6% |
| ResNet-20 | Warmup |  |  |  |  | 89.7 $\pm$ 0.3% |  | 0.03 | 30K | 8.6% |
| VGG-16 | Standard |  |  |  |  | 93.7 $\pm$ 0.1% |  | 0.1 | 10x drop at  32K, 48K | 0 | Yes | 1.5% | Iterative |
| VGG-16 | Low | CIFAR-10 | 14.7M | 63K Iters | 128 | 91.7 $\pm$ 0.1% | momentum | 0.01 | 0 | 5.5% |
| VGG-16 | Warmup |  |  |  |  | 93.4 $\pm$ 0.1% |  | 0.1 | 30K | 1.5% |
| ResNet-50 |  | ImageNet | 25.5M | 90 Eps | 1024 | 76.1 $\pm$ 0.1% | momentum | 0.4 | 10x drop at 30,60,80 | 5 Eps | Yes | 30% | One-Shot |
| Inception-v3 |  | ImageNet | 27.1M | 171 Eps | 1024 | 78.1 $\pm$ 0.1% | momentum | 0.03 | linear decay to 0.005 | 0 | Yes | 30% | One-Shot |

Table 1: Our networks and hyperparameters.
Accuracies are the means and standard deviations across three initializations.
Hyperparameters for ResNet-20 standard are from [He et al. (2016)](#bib.bib13). Hyperparameters for VGG-16 standard are from [Liu et al. (2019)](#bib.bib20).
Hyperparameters for *low*, *warmup*, and LeNet are adapted from [Frankle & Carbin (2019)](#bib.bib4).
Hyperparameters for ImageNet networks are from Google’s reference TPU code ([Google, 2018](#bib.bib9)).
Note: [Frankle & Carbin](#bib.bib4) mistakenly refer to ResNet-20 as “ResNet-18,” which is a separate network.

We perform instability analysis on standard networks for MNIST, CIFAR-10, and ImageNet.
All but the smallest MNIST network are unstable to SGD noise at initialization according to linear interpolation.
However, by a point early in training (3% for ResNet-20 on CIFAR-10 and 20% for ResNet-50 on ImageNet), all networks become stable to SGD noise.
From this point on, the outcome of optimization is determined to a linearly connected minimum.

The lottery ticket hypothesis.
Finally, we show that instability analysis and linear interpolation are valuable scientific tools for understanding other phenomena in deep learning.
Specifically, we study the sparse networks discussed by the recent *lottery ticket hypothesis* ([Frankle & Carbin, 2019](#bib.bib4), LTH;).
The LTH conjectures that, at initialization, neural networks contain sparse subnetworks that can train in isolation to full accuracy.

Empirical evidence for the LTH consists of experiments using a procedure called *iterative magnitude pruning* (IMP).
On small networks for MNIST and CIFAR-10, IMP retroactively finds subnetworks at initialization that can train to the same accuracy as the full network (we call such subnetworks *matching*).
Importantly, IMP finds matching subnetworks at *nontrivial* sparsity levels, i.e., those beyond which subnetworks found by trivial random pruning are matching.
In more challenging settings, however, there is no empirical evidence for the LTH:
IMP subnetworks of VGGs and ResNets on CIFAR-10 and ImageNet are not matching at nontrivial sparsities ([Liu et al., 2019](#bib.bib20); [Gale et al., 2019](#bib.bib7)).

We show that instability analysis distinguishes known cases where IMP succeeds and fails to find matching subnetworks at nontrivial sparsities, providing the first basis for understanding the mixed results in the literature.
Namely, IMP subnetworks are only matching when they are stable to SGD noise according to linear interpolation.
Using this insight, we identify new scenarios where we can find sparse, matching subnetworks at nontrivial sparsities, including in more challenging settings (e.g., ResNet-50 on ImageNet).
In these settings, sparse IMP subnetworks become stable to SGD noise *early* in training rather than at initialization, just as we find with the unpruned networks.
Moreover, these stable IMP subnetworks are also matching.
In other words, early in training (if not at initialization), sparse subnetworks emerge that can complete training in isolation and reach full accuracy.
These findings shed new light on neural network training dynamics, hint at possible mechanisms underlying lottery ticket phenomena, and extend the lottery ticket observations to larger scales.

Contributions. We make the following contributions:

* •

  We introduce *instability analysis* to determine whether the outcome of optimizing a neural network is stable to SGD noise, and we suggest linear mode connectivity for making this determination.
* •

  On a range of image classification benchmarks including standard networks on ImageNet, we observe that networks become stable to SGD noise early in training.
* •

  We use instability analysis to distinguish successes and failures of IMP (the method behind extant lottery ticket results).
  Namely, sparse IMP subnetworks are matching only when they are stable to SGD noise.
* •

  We generalize IMP to find subnetworks early in training rather than at initialization.
  We show that IMP subnetworks become stable and matching when set to their weights from early in training, making it possible to extend the lottery ticket observations to larger scales.

Figure 2: Error when linearly interpolating between networks trained from the same initialization with different SGD noise. Lines are means and standard deviations over three initializations and three data orders (nine samples total). Trained networks are at 0.0 and 1.0.

## 2 Preliminaries and Methodology

Instability analysis.
To perform instability analysis on a network $\mathcal{N}$ with weights $W$, we make two copies of $\mathcal{N}$ and train them with different random samples of SGD noise (i.e., different data orders and augmentations), producing trained weights $W\_{T}^{1}$ and $W\_{T}^{2}$.
We compare these weights with a function, producing a value we call the *instability* of $\mathcal{N}$ to SGD noise.
We then determine whether this value satisfies a criterion indicating that $\mathcal{N}$ is stable to SGD noise.
The weights of $\mathcal{N}$ could be randomly initialized ($W=W\_{0}$ in Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")) or the result of $k$ training steps ($W=W\_{k}$).

Formally, we model SGD by function $\mathcal{A}^{s\rightarrow t}:\mathbb{R}^{D}\times U\to\mathbb{R}^{D}$ that maps weights $W\_{s}\in\mathbb{R}^{D}$ at step $s$ and SGD randomness $u\sim U$ to weights $W\_{t}\in\mathbb{R}^{D}$ at step $t$ by training for $t-s$ steps ($s,t\in\{0,..,T\}$).
Algorithm [1](#alg1 "Algorithm 1 ‣ 2 Preliminaries and Methodology ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") outlines instability analysis with a function $f:\mathbb{R}^{D}\times\mathbb{R}^{D}\rightarrow\mathbb{R}$.

Algorithm 1  Compute instability of $W\_{k}$ with function $f$.

```
1:
Train WkW_{k} to WT1W_{T}^{1} with noise u1∼Uu_{1}\sim U: WT1=𝒜k→T​(Wk,u1)W_{T}^{1}=\mathcal{A}^{k\rightarrow T}(W_{k},u_{1})

2:
Train WkW_{k} to WT2W_{T}^{2} with noise u2∼Uu_{2}\sim U: WT2=𝒜k→T​(Wk,u2)W_{T}^{2}=\mathcal{A}^{k\rightarrow T}(W_{k},u_{2})

3:
Return f⁡(WT1,WT2)f(W_{T}^{1},W_{T}^{2}), i.e., the instability of WkW_{k} to SGD noise.
```

Linear interpolation.
Consider a path $p$ on the optimization landscape between networks $W\_{1}$ and $W\_{2}$.
We define the *error barrier height* of $p$ as the maximum increase in error from that of $W\_{1}$ and $W\_{2}$ along path $p$.
For instability analysis, we use as our function $f$ the error barrier height along the *linear* path between two networks $W\_{1}$ and $W\_{2}$.11
1
See Appendix [G](#A7 "Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") for alternate ways of comparing the networks.

Formally, let $\mathcal{E}(W)$ be the (train or test) error of a network with weights $W$.
Let $\mathcal{E}\_{\alpha}(W\_{1},W\_{2})=\mathcal{E}(\alpha W\_{1}+(1-\alpha)W\_{2})$ for $\alpha\in[0,1]$ be the error of the network created by linearly interpolating between $W\_{1}$ and $W\_{2}$.
Let $\mathcal{E}\_{\mathsf{sup}}(W\_{1},W\_{2})=\sup\_{\alpha}\mathcal{E}\_{\alpha}(W\_{1},W\_{2})$ be the highest error when interpolating in this way.
Finally, let $\bar{\mathcal{E}}(W\_{1},W\_{2})=\mathsf{mean}(\mathcal{E}(W\_{1}),\mathcal{E}(W\_{2}))$.
The error barrier height on the linear path between $W\_{1}$ and $W\_{2}$ (which is our function $f$ for instability analysis) is $\mathcal{E}\_{\mathsf{sup}}(W\_{1},W\_{2})-\bar{\mathcal{E}}(W\_{1},W\_{2})$ (red line in Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")).
When we perform instability analysis on a network $\mathcal{N}$ with this function, we call this quantity the *linear interpolation instability* (shorthand: *instability*) of $\mathcal{N}$ to SGD noise.

Linear mode connectivity.
Two networks $W\_{1}$ and $W\_{2}$ are *mode connected* if there exists a path between them along which the error barrier height $\approx 0$ ([Draxler et al., 2018](#bib.bib2); [Garipov et al., 2018](#bib.bib8)).
They are *linearly mode connected* if this is true along the linear path.
For instability analysis, we consider a network $\mathcal{N}$ stable to SGD noise (shorthand: *stable*) when the networks that result from instability analysis are linearly mode connected; that is, when the linear interpolation instability of $\mathcal{N}\approx 0$.
Otherwise, it is unstable to SGD noise (shorthand: *unstable*).
Empirically, we consider instability $<$ 2% to be stable; this margin accounts for noise and matches increases in error along paths found by [Draxler et al. (2018, Table B.1)](#bib.bib2) and [Garipov et al. (2018, Table 2)](#bib.bib8).
We use 30 evenly-spaced values of $\alpha$, and we average instability from three initializations and three runs per initialization (nine combinations total).

Networks and datasets.
We study image classification networks on MNIST, CIFAR-10, and ImageNet as listed in Table [1](#S1.T1 "Table 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").
All hyperparameters are standard values from reference code or prior work as cited in Table [1](#S1.T1 "Table 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").
The *warmup* and *low* variants of ResNet-20 and VGG-16 are adapted from hyperparameters in [Frankle & Carbin (2019)](#bib.bib4).

## 3 Instability Analysis of Unpruned Networks

In this section, we perform instability analysis on the standard networks in Table [1](#S1.T1 "Table 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") from many points during training.
We find that, although only LeNet is stable to SGD noise at initialization, every network becomes stable early in training, meaning the outcome of optimization from that point forward is determined to a linearly connected minimum.

Figure 3: Linear interpolation instability when starting from step $k$.
Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total).

Figure 4: Linear interpolation instability on the test set when making two copies of the state of the network at step $k$ and either (1) training for the remaining $T-k$ steps (blue) or (2) training for $T$ steps with the learning rate schedule reset to step 0 (orange).

Instability analysis at initialization.
We first perform instability analysis from initialization.
We use Algorithm [1](#alg1 "Algorithm 1 ‣ 2 Preliminaries and Methodology ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") with $W\_{0}$ (visualized in Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") left): train two copies of the same, randomly initialized network with different samples of SGD noise.
Figure [2](#S1.F2 "Figure 2 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") shows the train (purple) and test (red) error when linearly interpolating between the minima found by these copies.
Except for LeNet (MNIST), none of the networks are stable at initialization.
In fact, train and test error rise to the point of random guessing when linearly interpolating.
LeNet’s error rises slightly, but by less than a percentage point.
We conclude that, in general, larger-scale image classification networks are unstable at initialization according to linear interpolation.

Instability analysis during training.
Although larger networks are unstable at initialization, they may become stable at some point afterwards;
for example, in the limit, they will be stable trivially after the last step of training.
To investigate when networks become stable, we perform instability analysis using the state of the network at various training steps.
That is, we train a network for $k$ steps, make two copies, train them to completion with different samples of SGD noise, and linearly interpolate (Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") right).
We do so for many values of $k$, assessing whether there is a point after which the outcome of optimization is determined to a linearly connected minimum regardless of SGD noise.

For each $k$, Figure [3](#S3.F3 "Figure 3 ‣ 3 Instability Analysis of Unpruned Networks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") shows the linear interpolation instability of the network at step $k$, i.e., the maximum error during interpolation (the peaks in Figure [2](#S1.F2 "Figure 2 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")) minus the mean of the errors of the two networks (the endpoints in Figure [2](#S1.F2 "Figure 2 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")).
In all cases, test set instability decreases as $k$ increases, culminating in stable networks.
The steps at which networks become stable are early in training.
For example, they do so at iterations 2000 for ResNet-20 and 1000 VGG-16; in other words, after 3% and 1.5% of training, SGD noise does not affect the final linearly connected minimum.
ResNet-50 and Inception-v3 become stable later: at epoch 18 (20% into training) and 28 (16%), respectively, using the test set.

For LeNet, ResNet-20, and VGG-16, instability is essentially identical when measured in terms of train or test error, and the networks become stable to SGD noise at the same time for both quantities.
For ResNet-50 and Inception-v3, train instability follows the same trend as test instability but is slightly higher at all points, meaning train set stability occurs later for ResNet-50 and does not occur in our range of analysis for Inception-v3.
Going forward, we present all results with respect to test error for simplicity and include corresponding train error data in the appendices.
3

Algorithm 2  IMP rewinding to step $k$ and $N$ iterations.

```
1:
Create a network with randomly initialization W0∈ℝdW_{0}\in\mathbb{R}^{d}.

2:
Initialize pruning mask to m=1dm=1^{d}.

3:
Train W0W_{0} to WkW_{k} with noise u∼Uu\sim U: Wk=𝒜0→k​(W0,u)W_{k}=\mathcal{A}^{0\rightarrow k}(W_{0},u).

4:
for n∈{1,…,N}n\in\{1,\ldots,N\} do

5:
  

Train m⊙Wkm\odot W_{k} to m⊙WTm\odot W_{T} with noise u′∼Uu^{\prime}\sim U:
WT=𝒜k→T​(m⊙Wk,u′)W_{T}=\mathcal{A}^{k\rightarrow T}(m\odot W_{k},u^{\prime}).

6:
  

Prune the lowest magnitude entries of WTW_{T} that remain.
Let m⁡[i]=0m[i]=0 if WT​[i]W_{T}[i] is pruned.

7:
Return Wk,mW_{k},m
```

Disentangling instability from training time.
Varying the step $k$ from which we run instability analysis has two effects.
First, it changes the state of the network from which we train two copies to completion on different SGD noise.
Second, it changes the number of steps for which those copies are trained: when we run instability analysis from step $k$, we train the copies under different SGD noise for $T-k$ steps.
As $k$ increases, the copies have fewer steps during which to potentially find linearly unconnected minima.
It is possible that the gradual decrease in instability as $k$ increases and the eventual emergence of linear mode connectivity is just an artifact of these shorter training times.

To disentangle the role of training time in our experiments, we modify instability analysis to train the copies for $T$ iterations no matter the value of $k$.
When doing so, we reset the learning rate schedule to iteration 0 after making the copies.
In Figure [4](#S3.F4 "Figure 4 ‣ 3 Instability Analysis of Unpruned Networks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we compare instability with and without this modification for ResNet-20 and VGG-16 on CIFAR-10.
Instability is indistinguishable in both cases, indicating that the different numbers of training steps did not play a role in the earlier results.
Going forward, we present all results by training copies for $T-k$ steps as in Algorithm [1](#alg1 "Algorithm 1 ‣ 2 Preliminaries and Methodology ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| Network | Full | IMP | Rand Prune | Rand Reinit | $\Delta$ IMP | Matching? |
| LeNet | 98.3 | 98.2 | 96.7 | 97.5 | 0.1 | Y |
| ResNet-20 | 91.7 | 88.5 | 88.6 | 88.8 | 3.2 | N |
| ResNet-20 Low | 88.8 | 89.0 | 85.7 | 84.7 | -0.2 | Y |
| ResNet-20 Warmup | 89.7 | 89.6 | 85.7 | 85.6 | 0.1 | Y |
| VGG-16 | 93.7 | 90.9 | 89.4 | 91.0 | 2.8 | N |
| VGG-16 Low | 91.7 | 91.6 | 90.1 | 90.2 | 0.1 | Y |
| VGG-16 Warmup | 93.4 | 93.2 | 90.1 | 90.7 | 0.2 | Y |
| ResNet-50 | 76.1 | 73.7 | 73.1 | 73.4 | 2.4 | N |
| Inception-v3 | 78.1 | 75.7 | 75.2 | 75.5 | 2.4 | N |

Table 2: Accuracy of IMP and random subnetworks when rewinding to $k=0$ at the sparsities in Table [1](#S1.T1 "Table 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"). Accuracies are means across three initializations. All standard deviations are $<0.2$.

## 4 Instability Analysis of Lottery Tickets

In this section, we leverage instability analysis and our observations about linear mode connectivity to gain new insights into the behavior of sparse *lottery ticket* networks.

### 4.1 Overview

We have long known that it is possible to *prune* neural networks after training, often removing 90% of weights without reducing accuracy after some additional training ([Reed, 1993](#bib.bib25); [Han et al., 2015](#bib.bib12); [Gale et al., 2019](#bib.bib7), e.g.,).
However, sparse networks are more difficult to train from scratch.
Beyond *trivial* sparsities where many weights remain and random subnetworks can train to full accuracy, sparse networks trained in isolation are generally less accurate than the corresponding dense networks ([Han et al., 2015](#bib.bib12); [Li et al., 2017](#bib.bib18); [Liu et al., 2019](#bib.bib20); [Frankle & Carbin, 2019](#bib.bib4)).

However, there is a known class of sparse networks that remain accurate at nontrivial sparsities.
On small vision tasks, an algorithm called *iterative magnitude pruning* (IMP) retroactively finds sparse subnetworks that were capable of training in isolation from initialization to full accuracy at the sparsities attained by pruning ([Frankle & Carbin, 2019](#bib.bib4)).
The existence of such subnetworks raises the prospect of replacing conventional, dense networks with sparse ones, creating new opportunities to reduce the cost of training.
However, in more challenging settings, IMP subnetworks perform no better than subnetworks chosen randomly, meaning they only train to full accuracy at trivial sparsities ([Liu et al., 2019](#bib.bib20); [Gale et al., 2019](#bib.bib7)).

We find that instability analysis offers new insights into the behavior of IMP subnetworks and a potential explanation for their successes and failures.
Namely, the sparsest IMP subnetworks only train to full accuracy when they are stable to SGD noise.
In other words, when different samples of SGD noise cause an IMP subnetwork to find minima that are not linearly connected, then test accuracy is lower.

IMP Subnetwork is Matching for $k=0$IMP Subnetwork is Not Matching for $k=0$

Figure 5: Test error when linearly interpolating between subnetworks trained from the same initialization with different SGD noise.
Lines are means and standard deviations over three initializations and three data orders (nine in total). Percents are weights remaining.

IMP Subnetwork is Matching for $k=0$IMP Subnetwork is Not Matching for $k=0$

Figure 6: Linear interpolation instability of subnetworks created using the state of the full network at step $k$ and applying a pruning mask.
Lines are means and standard deviations over three initializations and three data orders (nine in total). Percents are weights remaining.

IMP Subnetwork is Matching for $k=0$IMP Subnetwork is Not Matching for $k=0$

Figure 7: Test error of subnetworks created using the state of the full network at step $k$ and applying a pruning mask.
Lines are means and standard deviations over three initializations and three data orders (nine in total). Percents are weights remaining.

### 4.2 Methodology

Iterative magnitude pruning.
Iterative magnitude pruning (IMP) is a procedure to retroactively find a subnetwork of the state of the full network at step $k$ of training.
To do so, IMP trains a network to completion, prunes weights with the lowest magnitudes globally, and *rewinds* the remaining weights back to their values at iteration $k$ (Algorithm [2](#alg2 "Algorithm 2 ‣ 3 Instability Analysis of Unpruned Networks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")).
The result is a subnetwork $(W\_{k},m)$ where $W\_{k}\in\mathbb{R}^{d}$ is the state of the full network at step $k$ and $m\in\{0,1\}^{d}$ is a mask such that $m\odot W\_{k}$ (where $\odot$ is the element-wise product) is a pruned network.
We can run IMP iteratively (pruning 20% of weights ([Frankle & Carbin, 2019](#bib.bib4)), rewinding, and repeating until a target sparsity) or in one shot (pruning to a target sparsity at once).
We one-shot prune ImageNet networks for efficiency and iteratively prune otherwise (Table [1](#S1.T1 "Table 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")).

[Frankle & Carbin (2019)](#bib.bib4) focus on finding sparse subnetworks at initialization; as such, they only use IMP to “reset” unpruned weights to their values at initialization.
One of our contributions is to generalize IMP to *rewind* to any step $k$.
[Frankle & Carbin](#bib.bib4) refer to subnetworks that match the accuracy of the full network as *winning tickets* because they have “won the initialization lottery” with weights that make attaining this accuracy possible.
When we rewind to iteration $k>0$, subnetworks are no longer randomly initialized, so the term *winning ticket* is no longer appropriate.
Instead, we refer to such subnetworks simply as *matching*.

Sparsity levels.
In this section, we focus on the most extreme sparsity levels for which IMP returns a matching subnetwork at any rewinding step $k$.
These levels are in Table [1](#S1.T1 "Table 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), and Appendix [A](#A1 "Appendix A Selecting Extreme Sparsity Levels for IMP ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") explains these choices.
These sparsities provide the best contrast between sparse networks that are matching and (1) the full, overparameterized networks and (2) other classes of sparse networks.
Appendix [D](#A4 "Appendix D Instability Data at All Sparsities ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") includes the analyses from this section for all sparsities for ResNet-20 and VGG-16, which we summarize in Section [4.4](#S4.SS4 "4.4 Results at Other Sparsity Levels ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"); due to the computational costs of these experiments, we only collected data across all sparsities for these networks.

### 4.3 Experiments and Results

IMP Subnetwork is Matching for $k=0$IMP Subnetwork is Not Matching for $k=0$

Figure 8: Train error of subnetworks created using the state of the full network at step $k$ and apply a pruning mask.
Lines are means and standard deviations over three initializations and three data orders (nine in total). Percents are weights remaining.
We did not compute the train set quantities for Inception-v3 due to computational limitations.

Recapping the lottery ticket hypothesis.
We begin by studying sparse subnetworks rewound to initialization ($k=0$).
This is the lottery ticket experiment from [Frankle & Carbin (2019)](#bib.bib4).
As Table [2](#S3.T2 "Table 2 ‣ 3 Instability Analysis of Unpruned Networks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") shows, when rewinding to step 0, IMP subnetworks of LeNet are matching, as are variants of ResNet-20 and VGG-16 with lower learning rates or learning rate warmup (changes proposed by [Frankle & Carbin](#bib.bib4) to make it possible for IMP to find matching subnetworks).
However, IMP subnetworks of standard ResNet-20, standard VGG-16, ResNet-50, and Inception-v3 are not matching.
In fact, they are no more accurate than subnetworks generated by randomly pruning or reinitializing the IMP subnetworks, suggesting that neither the structure nor the initialization uncovered by IMP provides a performance advantage.
For full details on the accuracy of these subnetworks at all levels of sparsity, see Appendix [A](#A1 "Appendix A Selecting Extreme Sparsity Levels for IMP ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").

Instability analysis of subnetworks at initialization.
When we perform instability analysis on these subnetworks, we find that they are only matching when they are stable to SGD noise (Figure [5](#S4.F5 "Figure 5 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")).
The IMP subnetworks of LeNet, ResNet-20 (low, warmup), and VGG-16 (low, warmup) are stable and matching (Figure [5](#S4.F5 "Figure 5 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), left).
In all other cases, IMP subnetworks are neither stable nor matching (Figure [5](#S4.F5 "Figure 5 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), left).
The low and warmup results are notable because [Frankle & Carbin](#bib.bib4) selected these hyperparameters specifically for IMP to find matching subnetworks; that this change also makes the subnetworks stable adds further evidence of a connection between instability and accuracy in IMP subnetworks.

No randomly pruned or reinitialized subnetworks are stable or matching at these sparsities except those of LeNet: LeNet subnetworks are not matching but error only rises slightly when interpolating.
For all other networks, error approaches that of random guessing when interpolating.

Instability analysis of subnetworks during training.
We just saw that IMP subnetworks are matching from initialization only when they are stable.
In Section [3](#S3 "3 Instability Analysis of Unpruned Networks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we found that unpruned networks become stable only after a certain amount of training.
Here, we combine these observations: we study whether IMP subnetworks become stable later in training and, if so, whether improved accuracy follows.

Concretely, we perform IMP where we rewind to iteration $k>0$ after pruning.
Doing so produces a subnetwork ($W\_{k}$, $m$) of the state of the full network at iteration $k$.
We then run instability analysis using this subnetwork.
Another way of looking at this experiment is that it simulates training the full network to iteration $k$, generating a pruning mask, and evaluating the instability of the resulting subnetwork; the underlying mask-generation procedure involves training the network many times in the course of performing IMP.

The blue dots in Figure [6](#S4.F6 "Figure 6 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") show the instability of the IMP subnetworks at many rewinding iterations.
Networks whose IMP subnetworks were stable when rewinding to iteration 0 remain stable at all other rewinding points (Figure [6](#S4.F6 "Figure 6 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), left).
Notably, networks whose IMP subnetworks were *unstable* when rewinding to iteration 0 become stable when rewinding later.
IMP subnetworks of ResNet-20 and VGG-16 become stable at iterations 500 (0.8% into training) and 1000 (1.6%).
Likewise, IMP subnetworks of ResNet-50 and Inception-v3 become stable at epochs 5 (5.5% into training) and 6 (3.5%).
In all cases, the IMP subnetworks become stable sooner than the unpruned networks, substantially so for ResNet-50 (epoch 5 vs. 18) and Inception-v3 (epoch 6 vs. 28).

Figure 9: The median rewinding iteration at which IMP subnetworks and randomly pruned subnetworks of ResNet-20 and VGG-16 become stable and matching.
A subnetwork is stable if instability $<2\%$. A subnetwork is matching if the accuracy drop $<0.2\%$; we only include points where a majority of subnetworks are matching at any rewinding iteration. Each line is the median across three initializations and three data orders (nine samples in total).

The test error of the IMP subnetworks behaves similarly.
The blue line in Figure [7](#S4.F7 "Figure 7 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") plots the error of the IMP subnetworks and the gray line plots the error of the full networks to one standard deviation; subnetworks are matching when the lines cross.
Networks whose IMP subnetworks were matching when rewinding to step 0 (Figure [7](#S4.F7 "Figure 7 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), left) generally remain matching at later iterations (except for ResNet-20 low and VGG-16 low at the latest rewinding points).
Notably, networks whose IMP subnetworks were *not* matching when rewinding to iteration 0 (Figure [7](#S4.F7 "Figure 7 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), right) become matching when rewinding later.
Moreover, these rewinding points closely coincide with those where the subnetworks become stable.
In summary, at these extreme sparsities, IMP subnetworks are matching when they are stable.

Other observations.
Interestingly, the same pattern holds for the train error: for those networks whose IMP subnetworks were not matching at step 0, train error decreases when rewinding later.
For ResNet-20 and VGG-16, rewinding makes it possible for the IMP subnetworks to converge to 0% train error.
These results suggest stable IMP subnetworks also optimize better.

Randomly pruned and reinitialized subnetworks are unstable and non-matching at all rewinding points (with LeNet again an exception).
Although it is beyond the scope of our study, this behavior suggests a potential broader link between subnetwork stability and accuracy: IMP subnetworks are matching and become stable at least as early as the full networks, while other subnetworks are less accurate and unstable for the sparsities and rewinding points we consider.

### 4.4 Results at Other Sparsity Levels

Thus far, we have performed instability analysis at only two sparsities: unpruned networks (Section [3](#S3 "3 Instability Analysis of Unpruned Networks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")) and an extreme sparsity (Section [4.3](#S4.SS3 "4.3 Experiments and Results ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")).
Here, we examine sparsities between these levels and beyond for ResNet-20 and VGG-16.
Figure [9](#S4.F9 "Figure 9 ‣ 4.3 Experiments and Results ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") presents the median iteration at which IMP and randomly pruned subnetworks become stable (instability $<2\%$) and matching (accuracy drop $<0.2\%$, allowing a small margin for noise) across sparsity levels.22
2
In Appendix [D](#A4 "Appendix D Instability Data at All Sparsities ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we present the full instability and error data that we used to produce this summary.

Stability behavior.
As sparsity increases, the iteration at which the IMP subnetworks become stable decreases, plateaus, and eventually increases.
In contrast, the iteration at which randomly pruned subnetworks become stable only increases until the subnetworks are no longer stable at any rewinding iteration.

Matching behavior.
We separate the sparsities into three *ranges* where different sparse networks are matching.

In sparsity range I, the networks are so overparameterized that even randomly pruned subnetworks are matching (red).
These are sparsities we refer to as *trivial*.
This range occurs when more than 80.0% and 16.8% of weights remain for ResNet-20 and VGG-16.

In sparsity range II, the networks are sufficiently sparse that only IMP subnetworks are matching (orange).
This range occurs when 80.0%-13.4% and 16.8%-1.2% of weights remain in ResNet-20 and VGG-16.
For part of this range, IMP subnetworks become matching and stable at approximately the same rewinding iteration; namely, when 51.2%-13.4% and 6.9%-1.5% of weights remain for ResNet-20 and VGG-16.
In Section [4.3](#S4.SS3 "4.3 Experiments and Results ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we observed this behavior for a single, extreme sparsity level for each network.
Based on Figure [9](#S4.F9 "Figure 9 ‣ 4.3 Experiments and Results ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we conclude that there are many sparsities where these rewinding iterations coincide for ResNet-20 and VGG-16.

In sparsity range III, the networks are so sparse that even IMP subnetworks are not matching at any rewinding iteration we consider.
This range occurs when fewer than 13.4% and 1.2% of weights remain for ResNet-20 and VGG-16.
According to Appendix [D](#A4 "Appendix D Instability Data at All Sparsities ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), the error of IMP subnetworks still decreases when they become stable (although not to the point that they are matching), potentially suggesting a broader relationship between instability and accuracy.

## 5 Discussion

Instability analysis.
We introduce instability analysis as a novel way to study the sensitivity of a neural network’s optimization trajectory to SGD noise.
In doing so, we uncover a class of situations in which *linear* mode connectivity emerges, whereas previous examples of mode connectivity (e.g., between networks trained from different initializations) at similar scales required nonlinear paths ([Draxler et al., 2018](#bib.bib2); [Garipov et al., 2018](#bib.bib8)).

Our full network results divide training into two phases: an unstable phase where the network finds linearly unconnected minima due to SGD noise and a stable phase where the linearly connected minimum is determined.
Our finding that stability emerges early in training adds to work suggesting that training comprises a noisy first phase and a less stochastic second phase.
For example, the Hessian eigenspectrum settles into a few large values and a bulk ([Gur-Ari et al., 2018](#bib.bib11)), and
large-batch training at high learning rates benefits from learning rate warmup ([Goyal et al., 2017](#bib.bib10)).

One way to exploit our findings is to explore changing aspects of optimization (e.g., learning rate schedule or optimizer) similar to [Goyal et al. (2017)](#bib.bib10) once the network becomes stable to improve performance; instability analysis can evaluate the consequences of doing so.
We also believe instability analysis provides a scientific tool for topics related to the scale and distribution of SGD noise, e.g.,
the relationship between batch size, learning rate, and generalization ([LeCun et al., 2012](#bib.bib16); [Keskar et al., 2017](#bib.bib15); [Goyal et al., 2017](#bib.bib10); [Smith & Le, 2018](#bib.bib30); [Smith et al., 2018](#bib.bib31)) and the efficacy of alternative learning rate schedules ([Smith, 2017](#bib.bib28); [Smith & Topin, 2018](#bib.bib29); [Li & Arora, 2020](#bib.bib19)).

The lottery ticket hypothesis.
The lottery ticket hypothesis ([Frankle & Carbin, 2019](#bib.bib4)) conjectures that any “randomly initialized, dense neural network contains a subnetwork that—when trained in isolation—matches the accuracy of the original network.”
This work is among several recent papers to propose that merely sparsifying at initialization can produce high performance neural networks ([Mallya et al., 2018](#bib.bib21); [Zhou et al., 2019](#bib.bib35); [Ramanujan et al., 2020](#bib.bib24); [Evci et al., 2020](#bib.bib3)).
[Frankle & Carbin](#bib.bib4) support the lottery ticket hypothesis by using IMP to find matching subnetworks at initialization in small vision networks.
However, follow-up studies show ([Liu et al., 2019](#bib.bib20); [Gale et al., 2019](#bib.bib7)) and we confirm that IMP does not find matching subnetworks at nontrivial sparsities in more challenging settings.
We use instability analysis to distinguish the successes and failures of IMP as identified in previous work.
In doing so, we make a new connection between the lottery ticket hypothesis and the optimization dynamics of neural networks.

Practical impact of rewinding.
By extending IMP with rewinding, we show how to find matching subnetworks in much larger settings than in previous work, albeit from *early* in training rather than initialization.
Our technique has already been adopted for practical purposes.
[Morcos et al. (2019)](#bib.bib22) show that subnetworks found by IMP with rewinding transfer between vision tasks, meaning the effort of finding a subnetworks can be amortized by reusing it many times.
[Renda et al. (2020)](#bib.bib26) show that IMP with rewinding prunes to state-of-the-art sparsities, matching or exceeding the performance of standard techniques that fine-tune at a low learning rate after pruning ([Han et al., 2015](#bib.bib12); [He et al., 2018](#bib.bib14), e.g.,).
Other efforts use rewinding to further study lottery tickets ([Yu et al., 2020](#bib.bib34); [Frankle et al., 2020](#bib.bib5); [Caron et al., 2020](#bib.bib1); [Savarese et al., 2020](#bib.bib27); [Yin et al., 2020](#bib.bib33)).

Pruning.
In larger-scale settings, IMP subnetworks only become stable and matching after the full network has been trained for some number of steps.
Recent proposals attempt to prune networks at initialization ([Lee et al., 2019](#bib.bib17); [Wang et al., 2020](#bib.bib32)), but our results suggest that the best time to do so may be after some training.
Likewise, most pruning methods only begin to sparsify networks late in training or after training ([Han et al., 2015](#bib.bib12); [Gale et al., 2019](#bib.bib7); [He et al., 2018](#bib.bib14)).
The existence of matching subnetworks early in training suggests that there is an unexploited opportunity to prune networks much earlier than current methods.

## 6 Conclusions

We propose instability analysis as a way to shed light on how SGD noise affects the outcome of optimizing neural networks.
We find that standard networks for MNIST, CIFAR-10, and ImageNet become *stable* to SGD noise early in training, after which the outcome of optimization is determined to a linearly connected minimum.

We then apply instability analysis to better understand a key question at the center of the lottery ticket hypothesis: why does iterative magnitude pruning find sparse networks that can train from initialization to full accuracy in smaller-scale settings (e.g., MNIST) but not on more challenging tasks (e.g., ImageNet)?
We find that extremely sparse IMP subnetworks only train to full accuracy when they are stable to SGD noise, which occurs at initialization in some settings but only after some amount of training in others.

Instability analysis and our linear mode connectivity criterion contribute to a growing range of empirical tools for studying and understanding the behavior of neural networks in practice.
In this paper, we show that it has already yielded new insights into neural network training dynamics and lottery ticket phenomena.

## Acknowledgements

We gratefully acknowledge the support of IBM, which provided us with the GPU resources necessary to conduct experiments on CIFAR-10 through the MIT-IBM Watson AI Lab. In particular, we express our gratitude to David Cox and John Cohn.

We gratefully acknowledge the support of Google, which provided us with the TPU resources necessary to conduct experiments on ImageNet through the TensorFlow Research Cloud. In particular, we express our gratitude to Zak Stone.

This work was supported in part by cloud credits from the MIT Quest for Intelligence.

This work was supported in part by the Office of Naval Research (ONR N00014-17-1-2699).

This work was supported in part by DARPA Award #HR001118C0059.

Daniel M. Roy was supported, in part, by an NSERC Discovery Grant and Ontario Early Researcher Award.

This research was carried out in part while Gintare Karolina Dziugaite and Daniel M. Roy participated in the Foundations of Deep Learning program at the Simons Institute for the Theory of Computing.

## Overview and Contents

In this supplementary material, we include data that either (1) we processed to produce the plots in the paper or (2) that we were not able to fit in the main body of the paper. The contents of these appendices are as follows:

Appendix [A](#A1 "Appendix A Selecting Extreme Sparsity Levels for IMP ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"). The process by which we chose the “extreme” sparsity levels used in Section [4](#S4 "4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").

Appendix [B](#A2 "Appendix B The State of the Network at Rewinding ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"). Details about the states of the unpruned networks and IMP subnetworks at the rewinding iterations, including full network accuracy, $L\_{2}$ distance from initialization, $L\_{2}$ distance to the trained weights, and the $L\_{2}$ distance between trained weights under different data orders.

Appendix [C](#A3 "Appendix C Instability Throughout Training ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"). Linear interpolation instability data *throughout* training for ResNet-20 and VGG-16; that is, interpolating between the states at each epoch of networks trained on different dataorders.

Appendix [D](#A4 "Appendix D Instability Data at All Sparsities ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"). Linear interpolation instability and test error across rewinding iterations for ResNet-20 and VGG-16 at all levels of sparsity (not just the extreme sparsity we analyzed in Section [4.3](#S4.SS3 "4.3 Experiments and Results ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")). This data was used to create Figure [9](#S4.F9 "Figure 9 ‣ 4.3 Experiments and Results ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").

Appendix [E](#A5 "Appendix E Full Linear Interpolation Data ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"). The error when linearly interpolating for all networks in all configurations (unpruned and sparse) at all rewinding iterations. This data was used to create the instability plots in Figures [3](#S3.F3 "Figure 3 ‣ 3 Instability Analysis of Unpruned Networks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") and [6](#S4.F6 "Figure 6 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").

Appendix [F](#A6 "Appendix F Train Instability for Sparse Subnetworks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"). The training set instability for the sparse networks corresponding to the test set instability data that we present in Section [4](#S4 "4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") Figure [6](#S4.F6 "Figure 6 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").

Appendix [G](#A7 "Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"). Functions other than linear mode connectivity for comparing the networks that result from our instability analysis experiments: $L\_{2}$ distance, cosine distance, number of identical classifications, and $L\_{2}$ distance of losses.

## Appendix A Selecting Extreme Sparsity Levels for IMP

In this appendix, we describe how we select the extreme sparsity level that we examine in Section [4.3](#S4.SS3 "4.3 Experiments and Results ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") for each IMP subnetwork.
For each network and hyperparameter configuration, our goal is to study the most extreme sparsity level at which matching subnetworks are known to exist early in training.
To do so, we use IMP to generate subnetworks at many different sparsities for many different rewinding iterations.
We then select the most extreme sparsity level at which any IMP under any rewinding iteration produces a matching subnetwork.

In Figure [10](#A7.F10 "Figure 10 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), each plot contains the maximum accuracy found by any rewinding iteration in red.
The black line is the accuracy of the unpruned network to one standard deviation.
For each network, we select the most extreme sparsity for which the red and black lines intersect.
As a basis for comparison, these plots also include the result of performing IMP with $k=0$ (blue line), random pruning (orange line), and random reinitialization of the IMP subnetworks with $k=0$ (green line).

Note that, for computational reasons, ResNet-50 and Inception-v3 are pruned using one-shot pruning, meaning the networks are pruned to the target sparsity all at once.
All other networks are pruned using iterative pruning, meaning the networks are pruned by 20% after each iteration of IMP until they reach the target sparsity.
Pruning 20% per iteration was the practice adopted by [Frankle & Carbin (2019)](#bib.bib4).
This information is specified in the rightmost Table [1](#S1.T1 "Table 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").

## Appendix B The State of the Network at Rewinding

### B.1 Methodology

In the main body of the paper, we perform instability analysis by training to step $k$, making two copies of the network, optionally apply a pruning mask (as in Section [4](#S4 "4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")), and training these two copies to completion under different samples of SGD noise.
We find that, for a sufficiently large value of $k$, the trained networks will find the same, linearly connected minimum.
In this appendix, we address the following question: what is the state of the network at the step $k$ from which this linear connectivity results?
Are the networks so far along in training that they are virtually fully optimized?
Have they traveled the vast majority of the distance from initialization to the eventual minimum?
In this sense, is the iteration at which the network becomes stable “trivial?”
We address these questions in two ways.

Error at rewinding.
In Figure [11](#A7.F11 "Figure 11 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we present the error of the unpruned network at each rewinding iteration we consider in the main body of the paper.
With this data, we investigate how close the network has come to its full accuracy when it becomes stable.

$L\_{2}$ distances.
In Figures [12](#A7.F12 "Figure 12 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") and [13](#A7.F13 "Figure 13 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we measure various $L\_{2}$ distances that capture how close the network is to initialization and to the end of training.
In particular, we measure three distances as shown in the diagram below (which is an annotated version of Figure [1](#S1.F1 "Figure 1 ‣ 1 Introduction ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")).

$W\_{0}$$W\_{k}$$W\_{T}^{1}$$W\_{T}^{2}$

Distance Between Copies Trained on Different Dataorders

Distance from Rewinding to
  
End of Training

Distance
  
from Init to
  
Rewinding

First, we measure the $L\_{2}$ distance in parameter space from initialization to the state of the network at step $k$ (blue circle in the diagram above and in Figures [12](#A7.F12 "Figure 12 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") and [13](#A7.F13 "Figure 13 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")); for the sparse IMP subnetworks, we measure the $L\_{2}$ distance after applying the pruning mask to both initialization and the state of the network at iteration $k$.
This quantity captures the distance that the network has traversed from initialization by step $k$.

Second, we measure the distance from the state of the network at step $k$ to its state at the end of training under one data order (orange x in the diagram above and in Figures [12](#A7.F12 "Figure 12 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") and [13](#A7.F13 "Figure 13 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")).
This quantity captures the distance that the network traverses after step $k$.
If the network is very close to the minimum by the time it becomes stable, then we expect this quantity to be small compared to the $L\_{2}$ distance between initialization and iteration $k$; that would indicate that the network has already traversed a large distance and has a relatively smaller distance to go.

Finally, we measure the distance between the final states of networks trained from step $k$ under different data orders (green triangle in the diagram above and in Figures [12](#A7.F12 "Figure 12 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") and [13](#A7.F13 "Figure 13 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")).
This quantity captures the size of the linearly connected minimum found by the networks.
We are interested in how this distance compares to the distance traveled by the networks and how this quantity changes as the rewinding iteration varies.

### B.2 Results

Error at rewinding.
These results appear in Figure [11](#A7.F11 "Figure 11 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").
Recall that the unpruned networks become stable at a different (typically later) iteration than the IMP subnetworks, so we consider two rewinding points for each network.

Unpruned networks.
ResNet-20 and VGG-16 become stable to SGD noise at iterations 2000 and 1000, at which point test error is about 25% (compared to final error 8.3%) for ResNet-20 and 20% (compared to final error 6.3%) for VGG-16.
Train error is at a similar value to test error at these points; in both cases, train error eventually converges to 0%.
We conclude that, at the iteration at which they become stable to SGD noise, these networks have not fully converged but are much closer to their final errors than to random guessing.

We see similar behavior for the unpruned ResNet-50 and Inception-v3 networks, which become stable to SGD noise at epochs 18 and 28.
At these points, test error is 55% (compared to final error 24%) for ResNet-50 and 33% (compared to final error 22%) for Inception-v3.
Both networks are most of the way to their final performance.

IMP pruned subnetworks.
The IMP pruned subnetworks become stable to SGD noise earlier than the unpruned networks.
ResNet-20 and VGG-16 become stable to SGD noise at iterations 500 and 1000, at which point error is 30% (compared to final error 8.3%) for ResNet-20 and 35% (compared to final error 6.3%) for VGG-16.
These networks have not fully converged but are closer to their final errors than to random guessing.
IMP subnetworks of ResNet-50 and Inception-v3 become stable to SGD noise much earlier than the unpruned networks—at epoch 5 and epoch 6, respectively.
At these points, error is much higher—55% for ResNet-50 and 40% for Inception-v3—leaving these networks substantial room to further train.
We did not evaluate the train accuracy at these checkpoints for the ImageNet networks due to storage and computational limitations.

$L\_{2}$ distances.
These results appear in Figures [12](#A7.F12 "Figure 12 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") and [13](#A7.F13 "Figure 13 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").

Unpruned networks.
ResNet-20 and VGG-16 become stable to SGD noise at iterations 2000 and 1000, at which point they are closer to their initial weights than to their final weights.
This indicates that they still have a substantial distance to travel on the optimization landscape and are still far from their final weights.
This result is particularly remarkable considering our observation in Appendix [C](#A3 "Appendix C Instability Throughout Training ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") that stable networks follow the same, linearly connected trajectory throughout training (according to test error); the $L\_{2}$ distance data suggests that they do so for a substantial distance.

The unpruned ResNet-50 and Inception-v3 networks are closer to their final weights than their initial weights when they become stable to SGD noise.
In fact, it appears that distance from initialization begins to plateau and distance to the final weights only decreases slowly.
This may indicate that the networks will make much slower progress for the remaining 80% of training iterations.

The green triangles in these plots show the distance between the weights of copies of the network trained from a rewinding iteration to completion on different data orders.
In all cases, the distance between these copies is substantial, even after the networks become stable.
As a point of comparison, we use the distance that the networks travel between initialization and the final weights, which is captured by the orange $x$ for rewinding iteration 0.
For ResNet-20, the distance between copies trained on different data orders from iteration 2000 (when it becomes stable) is more than half the distance that the network travels during the entirety of training.
The same is true for VGG-16 from iteration 1000 (when it becomes stable).
For ResNet-50 and Inception-v3, this distance is about a quarter and half (respectively) of the distance the networks travel over the course of training.
These are remarkably large distances considering that any network on this line segment reaches full test accuracy.

IMP pruned subnetworks.
We show the same data for the IMP subnetworks in Figure [13](#A7.F13 "Figure 13 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").
Each $L\_{2}$ distance in this figure is measured after applying the pruning mask to all weights.
When ResNet-20 and VGG-16 become stable to SGD noise (iterations 2000 and 1000, respectively), they are about 2x (ResNet-20) and 3x (VGG-16) closer to their initial weights than their final weights.
ResNet-50 and Inception-v3 are about equal distances from both points for the epochs at which they become stable.

Unique to the IMP subnetworks, we observe here and in Appendix [G](#A7 "Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") that the $L\_{2}$ distance between copies trained on different data orders drops alongside instability, plateauing at a lower value when training from the rewinding iteration at which the subnetworks becomes stable.
Even this lower distance is still a substantial fraction of the overall distance the network travels: 25%, 45%, 27%, and 28% for ResNet-20, VGG-16, ResNet-50, and Inception-v3.

## Appendix C Instability Throughout Training

In Section [3](#S3 "3 Instability Analysis of Unpruned Networks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we find stable networks that arrive at minima that are linearly connected.
In this appendix, we study whether the trajectories they follow are also linearly connected.
In other words, when training two copies of the same network with different noise, are the states of the network at each step $t$ connected by a linear path over which test error does not increase?
In the main body of the paper, we study this quantity only at the end of training (i.e., $t=T$).
Here, we study it for all iterations $t$ *throughout* training.
To study this behavior, we linearly interpolate between the networks at each epoch of training and compute instability.

Figure [14](#A7.F14 "Figure 14 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") plots instability throughout training for ResNet-20 and VGG-16 from different rewinding iterations $k$ for both train and test error for the unpruned networks and the IMP subnetworks.
We begin with the unpruned networks.
For $k=0$ (blue line), instability increases rapidly.
In fact, it follows the same pattern as error: as the train or test error of each network decreases, the maximum possible instability increases (since instability never exceeds random guessing).
With larger values of $k$, instability increases more slowly throughout training.
When $k$ is sufficiently large that the networks are stable at the end of training, they are generally stable at every epoch of training ($k=2000$, pink line).
In other words, after iteration 2000, the networks follow identical optimization trajectories modulo linear interpolation.

The IMP subnetworks of ResNet-20 exhibit the same behavior as the unpruned network: when the network is stable at the end of training, it is stable throughout training, meaning two copies of the same network follow the same optimization trajectory up to linear interpolation.
The IMP subnetworks of VGG-16 exhibit sightly different behavior at rewinding iterations 500 and 1000: instability initially spikes (meaning the networks rapidly become separated by a loss barrier) but decreases gradually thereafter.
For rewinding iteration 1000, it decreases to 0, meaning the networks are stable by the end of training.
For all other rewinding iterations, being stable at the end of training corresponds to being stable throughout training, so it is possible that rewinding iteration 1000 represents a transition point between the unstable rewinding iterations earlier and the stable rewinding iterations later.

## Appendix D Instability Data at All Sparsities

In Figure [6](#S4.F6 "Figure 6 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") in Section [4.3](#S4.SS3 "4.3 Experiments and Results ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we show the effect of rewinding iteration on instability and test error for sparse subnetworks.
We specifically focus on the most extreme level of sparsity for which IMP at any rewinding iteration is matching (as selected in Appendix [A](#A1 "Appendix A Selecting Extreme Sparsity Levels for IMP ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")).
In this appendix, we present the relationship between rewinding iteration and instability/test error for all levels of sparsity for standard ResNet-20 (Figures [15](#A7.F15 "Figure 15 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") and [16](#A7.F16 "Figure 16 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")) and VGG-16 (Figures [17](#A7.F17 "Figure 17 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") and [18](#A7.F18 "Figure 18 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")) on CIFAR-10.
Section [4.4](#S4.SS4 "4.4 Results at Other Sparsity Levels ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") and Figure [9](#S4.F9 "Figure 9 ‣ 4.3 Experiments and Results ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") summarize this data, so we defer analysis of this data to that section.

This data begins with 80% of weights remaining and includes sparsities attained by repeatedly pruning 20% of weights (e.g., 64% of weights remaining, 51% of weights remaining, etc.).
We include these levels in particular because we use IMP to prune 20% of weights per iteration, meaning we have sparse IMP subnetworks for each of these levels.
We include data for every sparsity level displayed in Appendix [A](#A1 "Appendix A Selecting Extreme Sparsity Levels for IMP ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), including those beyond the extreme sparsities we study in Section [4.3](#S4.SS3 "4.3 Experiments and Results ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").

We only collected this data for standard ResNet-20 and VGG-16 on CIFAR-10.
We determined that it was more valuable to spend our limited computational resources on these networks (whose instability and accuracy are sensitive to rewinding at the extreme sparsity level) than for the *low* and *warmup* variants (which are consistently stable and matching at the extreme sparsity level).
We did not have the computational resources to compute this data on the ImageNet networks for all sparsities.

## Appendix E Full Linear Interpolation Data

In Figures [3](#S3.F3 "Figure 3 ‣ 3 Instability Analysis of Unpruned Networks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") and [6](#S4.F6 "Figure 6 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we plot the instability value derived from linearly interpolating between copies of the same network or subnetwork trained on different data orders.
In this appendix, we plot the linear interpolation data from which we derived the instabilities in Figures [3](#S3.F3 "Figure 3 ‣ 3 Instability Analysis of Unpruned Networks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") and [6](#S4.F6 "Figure 6 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").
We plot this data for the unpruned networks (Figure [19](#A7.F19 "Figure 19 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")), IMP subnetworks (Figure [20](#A7.F20 "Figure 20 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")), randomly pruned subnetworks (Figure [21](#A7.F21 "Figure 21 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")), and the randomly reinitialized IMP subnetworks (Figure [22](#A7.F22 "Figure 22 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis")).

## Appendix F Train Instability for Sparse Subnetworks

In Section [4](#S4 "4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we only measure instability and error on the test set.
We make this choice for simplicity after observing in Section [3](#S3 "3 Instability Analysis of Unpruned Networks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") that train and test instability closely align.
In this appendix, we present the data from Section [4](#S4 "4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") on the test set.
Figures [23](#A7.F23 "Figure 23 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") and [24](#A7.F24 "Figure 24 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") examine the instability and error of the same IMP subnetworks as Figure [6](#S4.F6 "Figure 6 ‣ 4.1 Overview ‣ 4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), but it shows both the train and test sets.
We did not compute the train set quantities for Inception-v3 due to computational limitations.

Train set and test set instability are nearly identical, just as we found in Section [3](#S3 "3 Instability Analysis of Unpruned Networks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").
Interestingly, the two coincide more closely for IMP subnetworks of ResNet-50 than they do for the unpruned networks in Section [3](#S3 "3 Instability Analysis of Unpruned Networks ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis").

For networks that are unstable at rewinding iteration 0, train error and test error follow similar trends, starting higher when the subnetworks are unstable and dropping when the subnetworks become stable.
In other words, the unstable IMP subnetworks are not able to fully optimize to 0% train error, while the stable IMP subnetworks are.

## Appendix G Alternate Distance Functions

Instability analysis involves training two copies of the same network on different data orders and comparing the networks that result.
In the main body of the paper, our method of comparison is linear interpolation, which we find to offer valuable new insights into neural network optimization and the lottery ticket hypothesis.
However, one could parameterize instability analysis with a wide range of other functions for comparing pairs of neural networks.
In this appendix, we discuss four alternate methods for which we collected data using the MNIST and CIFAR-10 networks.

$L\_{2}$ Distance.
One simple way to compare neural networks is to measure the $L\_{2}$ distance between the trained weights.
The limitation of this function is that there is not necessarily any relationship between $L\_{2}$ distance and the functional similarity of networks or the structure of the loss landscape.
In other words, there is no clear interpretation of $L\_{2}$ distance.

In Figure [25](#A7.F25 "Figure 25 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we plot the $L\_{2}$ distance function at all rewinding points for the unpruned networks. In Figure [26](#A7.F26 "Figure 26 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we plot the $L\_{2}$ distance function at all rewinding points for all three classes of sparse networks.
We plot this data separately because $L\_{2}$ distance is not necessarily comparable between sparse networks (which have fewer parameters) and dense networks (which have more parameters).

For the unpruned networks, distance decreases linearly as we logarithmically increase the rewinding iteration.
We see no distinct changes in behavior when the networks become stable, and the $L\_{2}$ distance remains far from 0 at this point.

For the IMP subnetworks, $L\_{2}$ distance mirrors the behavior of instability.
In cases where the IMP subnetworks are stable at all rewinding points (ResNet-20 low/warmup, VGG-16 low/warmup, and LeNet), the $L\_{2}$ distance is at a lower level than the $L\_{2}$ distance between the other baselines (random pruning and random reinitialization) and is consistent across rewinding points.
In cases where the IMP subnetworks are unstable at initialization but become stable later (ResNet-20 and VGG-16), the $L\_{2}$ distance begins high (at the same level as the $L\_{2}$ distance for the randomly pruned and randomly reinitialized baselines) and drops when the subnetworks become stable, settling at a lower level.

Although stable IMP subnetworks are closer in $L\_{2}$ distance than unstable IMP subnetworks and the baselines, the $L\_{2}$ distance remains far from zero.
In general, it is difficult to translate the results of this function into higher-level statements about the relationships between the networks.

Cosine distance.
In Figures [27](#A7.F27 "Figure 27 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") (unpruned networks) and [28](#A7.F28 "Figure 28 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") (sparse networks), we plot the cosine distance in a manner similar to $L\_{2}$ distance.
The results are similar to those for $L\_{2}$ distance, and the same interpretation applies.

Classification differences.
This distance function computes the number of examples that are classified differently by two networks.
Unlike linear interpolation and $L\_{2}$/cosine distance, this function looks at the functional behavior of the networks rather than the parameterizations.
This function is particularly valuable because it allows us to compare the dense and sparse networks directly.

In Figures [29](#A7.F29 "Figure 29 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") (test set) and [30](#A7.F30 "Figure 30 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") (train set), we plot this function for the unpruned and sparse networks across rewinding iterations.
The unpruned networks generally classify the same number of examples differently no matter the rewinding iteration, although the number of different classifications decreases gradually for the latest rewinding iterations for ResNet-20 low and warmup.
We see no relationship between this function and instability.

The behavior of the IMP sparse networks better matches instability.
IMP subnetworks that are stable from initialization (ResNet-20 low and warmup, VGG-16 low and warmup, LeNet) consistently have the same distance no matter the rewinding iteration.
This distance is lower than that for the randomly pruned and randomly reinitialized baselines.

IMP subnetworks that are unstable at iteration 0 (ResNet-20 and VGG-16) have the same number of different classifications as the baselines when rewinding to iteration 0.
When the networks become stable, the number of different classifications drops substantially to a lower level.

One challenge with using this distance function is that it is inherently entangled with accuracy.
As the accuracy of the networks improves, the number of different classifications might decrease simply because the networks will classify more examples correctly (and thereby, the same way).
Consider the IMP subnetworks of ResNet-20 on the CIFAR-10 test set (the graph in the upper right of Figure [29](#A7.F29 "Figure 29 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), blue line).
At rewinding iteration 0, the networks have about 11% error on the test set, meaning there are at most 2200 examples they could classify differently.33
3
In the worst case, all examples that one network misclassifies will be classified correctly by the other. Since each network misclassifies 1100 examples, 2200 examples will be classified differently in total.
In Figure [29](#A7.F29 "Figure 29 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we see that the networks are classifying about 1100 examples differently.

When ResNet-20 IMP subnetworks are stable, error decreases to 8.5%, meaning at most 1700 examples can be classified differently.
However, in Figure [27](#A7.F27 "Figure 27 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"), we see that only about 350 examples are being classified differently.
Although this number is lower than the 1100 differences at rewinding iteration 0 in absolute terms, accuracy has improved as well, so we must consider these differences in context.
At rewinding iteration 0, classification differences are 50% of their maximum possible value, while at rewinding iteration 1000, classification differences are at 21% of their maximum possible value.
In summary, as the IMP subnetworks become stable, they behave in a more functionally similar fashion, even considering accuracy improvements.

Loss $L\_{2}$ distance.
This distance function computes the $L\_{2}$ distance between the vector of cross-entropy losses aggregated by computing the loss on each example.
This function again considers only the functional behavior of the networks, but it uses the per-example loss rather than the classification decisions, which may provide more information about the functional behavior of the networks.
We plot this data in Figures [31](#A7.F31 "Figure 31 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") (test set) and [32](#A7.F32 "Figure 32 ‣ Appendix G Alternate Distance Functions ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis") (train set). It largely mirrors the behavior from the classification difference function, and the same interpretations apply.

Figure 10: An illustration of the methodology by which we select the extreme sparsity levels that we study in Section [4](#S4 "4 Instability Analysis of Lottery Tickets ‣ Linear Mode Connectivity and the Lottery Ticket Hypothesis"). The red line is the maximum accuracy achieved by any IMP subnetwork under any rewinding iteration. The black line is the accuracy of the full network. We use the most extreme sparsity level for which the red and black lines overlap. Each line is the mean and standard deviation across three runs with different initializations.

Figure 11: The error of the full networks at the rewinding iteration specified on the x-axis.
For clarity, this is the error of the network at that specific iteration of training, before any copies are made or further training occurs.
Each line is the mean and standard deviation across three initializations.

Figure 12: Various $L\_{2}$ distances for the full networks at the rewinding iteration specified on the x-axis.
Each line is the mean and standard deviation across three initializations.

Figure 13: Various $L\_{2}$ distances for the IMP subnetworks at the rewinding iteration specified on the x-axis.
Each line is the mean and standard deviation across three initializations. Each $L\_{2}$ distance is computed after applying the pruning mask to the states of the networks in question.

Figure 14: Instability throughout training for ResNet-20 and VGG-16 using both the unpruned networks and the IMP-pruned networks as computed on both the test set and train set. Each line involves training to iteration $k$ and then training two copies on different data orders after.
Each point is the instability when interpolating between the states of the networks at the training iteration on the x-axis.

Figure 15: The instability of subnetworks of ResNet-20 created using the state of the full network at iteration $k$ and trained on different data orders from there. Each line is the mean and standard deviation across three initializations and three data orders (nine samples total). Percents are percents of weights remaining.

Figure 16: The test error of subnetworks of ResNet-20 created using the state of the full network at iteration $k$ and trained on different data orders from there. Each line is the mean and standard deviation across three initializations. Gray lines are the accuracies of the full networks to one standard deviation. Percents are percents of weights remaining.

Figure 17: The instability of subnetworks of VGG-16 created using the state of the full network at iteration $k$ and trained on different data orders from there. Each line is the mean and standard deviation across three initializations and three data orders (nine samples total) Percents are percents of weights remaining.

Figure 18: The test error of subnetworks of VGG-16 created using the state of the full network at iteration $k$ and trained on different data orders from there. Each line is the mean and standard deviation across three initializations. Gray lines are the accuracies of the full networks to one standard deviation. Percents are percents of weights remaining.

Figure 19: The error when linearly interpolating between the minima found by randomly initializing a network, training to iteration $k$, and training two copies from there to completion using different data orders. Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total). The errors of the trained networks are at interpolation = 0.0 and 1.0.

Figure 20: The error when linearly interpolating between the minima found by randomly initializing a network, training to iteration $k$, pruning according to IMP, and training two copies from there to completion using different data orders. Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total). The errors of the trained networks are at interpolation = 0.0 and 1.0. We did not interpolate using the training set for the ImageNet networks due to computational limitations.

Figure 21: The error when linearly interpolating between the minima found by randomly initializing a network, training to iteration $k$, pruning randomly in the same layerwise proportions as IMP, and training two copies from there to completion using different data orders. Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total). The errors of the trained networks are at interpolation = 0.0 and 1.0. We did not interpolate using the training set for the ImageNet networks due to computational limitations.

Figure 22: The error when linearly interpolating between the minima found by randomly initializing a network, training to iteration $k$, pruning according to IMP, randomly reinitializing, and training two copies from there to completion using different data orders. Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total). The errors of the trained networks are at interpolation = 0.0 and 1.0. We did not interpolate using the training set for the ImageNet networks due to computational limitations.

Figure 23: The train and test set instability of subnetworks that are created by using the state of the full network at iteration $k$, applying the pruning mask found by performing IMP with rewinding to iteration $k$, and training on different data orders from there.
Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total). Percents are percents of weights remaining. We did not compute the train set quantities for Inception-v3 due to computational limitations.

Figure 24: The train and test set error of subnetworks that are created by using the state of the full network at iteration $k$, applying the pruning mask found by performing IMP with rewinding to iteration $k$, and training on different data orders from there.
Each line is the mean and standard deviation across three initializations. Percents are percents of weights remaining. We did not compute the train set quantities for Inception-v3 due to computational limitations.

Figure 25: The $L\_{2}$ distance between networks that are created by trained to iteration $k$, making two copies, and training on different data orders from there.
Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total). Percents are percents of weights remaining. We did not compute the train set quantities for the ImageNet networks due to computational limitations.

Figure 26: The $L\_{2}$ distance between subnetworks that are created by using the state of the full network at iteration $k$, applying a pruning mask, and training on different data orders from there.
Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total). Percents are percents of weights remaining. We did not compute the train set quantities for the ImageNet networks due to computational limitations.

Figure 27: The cosine distance between networks that are created by trained to iteration $k$, making two copies, and training on different data orders from there.
Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total). Percents are percents of weights remaining. We did not compute the train set quantities for the ImageNet networks due to computational limitations.

Figure 28: The cosine distance between subnetworks that are created by using the state of the full network at iteration $k$, applying a pruning mask, and training on different data orders from there.
Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total). Percents are percents of weights remaining. We did not compute the train set quantities for the ImageNet networks due to computational limitations.

Figure 29: The number of different test set classifications between networks that are created by training the full network to iteration $k$, optionally applying a pruning mask, and training on different data orders from there.
Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total). Percents are percents of weights remaining.

Figure 30: The number of different train set classifications between networks that are created by training the full network to iteration $k$, optionally applying a pruning mask, and training on different data orders from there.
Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total). Percents are percents of weights remaining.

Figure 31: The $L\_{2}$ distance between the per-example losses on the test set for networks that are created by training the full network to iteration $k$, optionally applying a pruning mask, and training on different data orders from there.
Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total). Percents are percents of weights remaining. We did not compute the train set quantities for the ImageNet networks due to computational limitations.

Figure 32: The $L\_{2}$ distance between the per-example losses on the train set for networks that are created by training the full network to iteration $k$, optionally applying a pruning mask, and training on different data orders from there.
Each line is the mean and standard deviation across three initializations and three data orders (nine samples in total). Percents are percents of weights remaining. We did not compute the train set quantities for the ImageNet networks due to computational limitations.
