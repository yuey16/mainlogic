<!-- fulltext source=arxiv_html slug=arXiv-2005.07683 fetched=2026-09-16T11:52:37+00:00 -->

# Movement Pruning: Adaptive Sparsity by Fine-Tuning

Victor Sanh
Affiliation: Hugging Face
  
Thomas Wolf
Affiliation: Hugging Face
  
Alexander M. Rush
Affiliation: Hugging Face
Affiliation: Cornell University{victor,thomas}@huggingface.co ; arush@cornell.edu

###### Abstract

Magnitude pruning is a widely used strategy for reducing model size in pure supervised learning; however, it is less effective in the transfer learning regime that has become standard for state-of-the-art natural language processing applications. We propose the use of movement pruning, a simple, deterministic first-order weight pruning method that is more adaptive to pretrained model fine-tuning. We give mathematical foundations to the method and compare it to existing zeroth- and first-order pruning methods. Experiments show that when pruning large pretrained language models, movement pruning shows significant improvements in high-sparsity regimes. When combined with distillation, the approach achieves minimal accuracy loss with down to only 3% of the model parameters.

## 1 Introduction

Large-scale transfer learning has become ubiquitous in deep learning and achieves state-of-the-art performance in applications in natural language processing and related fields. In this setup, a large model pretrained on a massive generic dataset is then fine-tuned on a smaller annotated dataset to perform a specific end-task. Model accuracy has been shown to scale with the pretrained model and dataset size ([Raffel et al., 2019](#bib.bib1)). However, significant resources are required to ship and deploy these large models, and training the models have high environmental costs ([Strubell et al., 2019](#bib.bib2)).

Sparsity induction is a widely used approach to reduce the memory footprint of neural networks at only a small cost of accuracy. Pruning methods, which remove weights based on their importance, are a particularly simple and effective method for compressing models. Smaller models are easier to sent on edge devices such as mobile phones but are also significantly less energy greedy: the majority of the energy consumption comes from fetching the model parameters from the long term storage of the mobile device to its volatile memory ([Han et al., 2016a](#bib.bib3); [Horowitz, 2014](#bib.bib4)).

Magnitude pruning ([Han et al., 2015](#bib.bib5); [Han et al., 2016b](#bib.bib6)), which preserves weights with high absolute values, is the most widely used method for weight pruning. It has been applied to a large variety of architectures in computer vision ([Guo et al., 2016](#bib.bib7)), in language processing ([Gale et al., 2019](#bib.bib8)), and more recently has been leveraged as a core component in the lottery ticket hypothesis ([Frankle et al., 2020](#bib.bib9)).

While magnitude pruning is highly effective for standard supervised learning, it is inherently less useful in the transfer learning regime. In supervised learning, weight values are primarily determined by the end-task training data. In transfer learning, weight values are mostly predetermined by the original model and are only fine-tuned on the end task. This prevents these methods from learning to prune based on the fine-tuning step, or “fine-pruning.”

In this work, we argue that to effectively reduce the size of models for transfer learning, one should instead use movement pruning, i.e., pruning approaches that consider the changes in weights during fine-tuning. Movement pruning differs from magnitude pruning in that both weights with low and high values can be pruned if they shrink during training. This strategy moves the selection criteria from the 0th to the 1st-order and facilitates greater pruning based on the fine-tuning objective. To test this approach, we introduce a particularly simple, deterministic version of movement pruning utilizing the straight-through estimator ([Bengio et al., 2013](#bib.bib10)).

We apply movement pruning to pretrained language representations (BERT) ([Devlin et al., 2019](#bib.bib11); [Vaswani et al., 2017](#bib.bib12)) on a diverse set of fine-tuning tasks. In highly sparse regimes (less than 15% of remaining weights), we observe significant improvements over magnitude pruning and other 1st-order methods such as $L\_{0}$ regularization ([Louizos et al., 2017](#bib.bib13)). Our models reach 95% of the original BERT performance with only 5% of the encoder’s weight on natural language inference (MNLI) ([Williams et al., 2018](#bib.bib14)) and question answering (SQuAD v1.1) ([Rajpurkar et al., 2016](#bib.bib15)). Analysis of the differences between magnitude pruning and movement pruning shows that the two methods lead to radically different pruned models with movement pruning showing greater ability to adapt to the end-task.

## 2 Related Work

In addition to magnitude pruning, there are many other approaches for generic model weight pruning. Most similar to our approach are methods for using parallel score matrices to augment the weight matrices ([Mallya and Lazebnik, 2018](#bib.bib16); [Ramanujan et al., 2020](#bib.bib17)), which have been applied for convolutional networks. Differing from our methods, these methods keep the weights of the model fixed (either from a randomly initialized network or a pre-trained network) and the scores are updated to find a good sparse subnetwork.

Many previous works have also explored using higher-order information to select prunable weights. [LeCun et al. (1989)](#bib.bib18) and [Hassibi et al. (1993)](#bib.bib19) leverage the Hessian of the loss to select weights for deletion. Our method does not require the (possibly costly) computation of second-order derivatives since the importance scores are obtained simply as the by-product of the standard fine-tuning. ([Theis et al., 2018](#bib.bib20); [Ding et al., 2019](#bib.bib21); [Lee et al., 2019](#bib.bib22)) use the absolute value or the square value of the gradient. In contrast, we found it useful to preserve the direction of movement in our algorithm.

Compressing pretrained language models for transfer learning
is also a popular area of study. Other approaches include knowledge distillation ([Sanh et al., 2019](#bib.bib23); [Tang et al., 2019](#bib.bib24)) and structured pruning ([Fan et al., 2020a](#bib.bib25); [Sajjad et al., 2020](#bib.bib26); [Michel et al., 2019](#bib.bib27); [Wang et al., 2019](#bib.bib28)). Our core method does not require an external teacher model and targets individual weight. We also show that having a teacher can further improve our approach. Recent work also builds upon iterative magnitude pruning with rewinding ([Yu et al., 2020](#bib.bib29)), weight redistribution ([Dettmers and Zettlemoyer, 2019](#bib.bib30)) models from scratch. This differs from our approach which we frame in the context of transfer learning (focusing on the fine-tuning stage).
Finally, another popular compression approach is quantization. Quantization has been applied to a variety of modern large architectures ([Fan et al., 2020b](#bib.bib31); [Zafrir et al., 2019](#bib.bib32); [Gong et al., 2014](#bib.bib33)) providing high memory compression rates at the cost of no or little performance.
As shown in previous works ([Li et al., 2020](#bib.bib34); [Han et al., 2016b](#bib.bib6)) quantization and pruning are complimentary and can be combined to further improve the performance/size ratio.

## 3 Background: Score-Based Pruning

We first establish shared notation for discussing different neural network pruning strategies. Let $\mathbf{W}\in\mathbb{R}^{n\times n}$ refer to a generic weight matrix in the model (we consider square matrices, but they could be of any shape). To determine which weights are pruned, we introduce a parallel matrix of associated importance scores $\mathbf{S}\in\mathbb{R}^{n\times n}$. Given importance scores, each pruning strategy computes a mask $\mathbf{M}\in\{0,1\}^{n\times n}$. Inference for an input $\mathbf{x}$ becomes $\mathbf{a}=(\mathbf{W}\odot\mathbf{M})\mathbf{x}$, where $\odot$ is the Hadamard product.
A common strategy is to keep the top-$v$ percent of weights by importance. We define Topv as a function which selects the $v\%$ highest values in $\mathbf{S}$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\text{Top}\_{v}(\mathbf{S})\_{i,j}=\begin{cases}1,&S\_{i,j}\text{ in top }v\%\\ 0,&\text{o.w.}\end{cases}$ |  | (1) |

Magnitude-based weight pruning determines the mask based on the absolute value of each weight as a measure of importance.
Formally, we have importance scores $\mathbf{S}=\big(|W\_{i,j}|\big)\_{1\leq i,j\leq n}$, and masks $\mathbf{M}=\text{Top}\_{v}(\mathbf{S})$ (Eq ([1](#S3.E1 "In 3 Background: Score-Based Pruning ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning"))). There are several extensions to this base setup. [Han et al. (2015)](#bib.bib5) use iterative magnitude pruning: the model is first trained until convergence and weights with the lowest magnitudes are removed afterward. The sparsified model is then re-trained with the removed weights fixed to 0. This loop is repeated until the desired sparsity level is reached.

In this study, we focus on automated gradual pruning ([Zhu and Gupta, 2018](#bib.bib35)). It supplements magnitude pruning by allowing masked weights to be updated such that they are not fixed for the entire duration of the training. Automated gradual pruning enables the model to recover from previous masking choices ([Guo et al., 2016](#bib.bib7)). In addition, one can gradually increases the sparsity level $v$ during training using a cubic sparsity scheduler: $v^{(t)}=v\_{f}+(v\_{i}-v\_{f})\left(1-\frac{t-t\_{i}}{N\Delta t}\right)^{3}$.
The sparsity level at time step $t$, $v^{(t)}$ is increased from an initial value $v\_{i}$ (usually 0) to a final value $v\_{f}$ in $n$ pruning steps after $t\_{i}$ steps of warm-up. The model is thus pruned and trained jointly.

## 4 Movement Pruning

Magnitude pruning can be seen as utilizing zeroth-order information (absolute value) of the running model. In this work,
we focus on movement pruning methods where importance is derived from first-order information. Intuitively,
instead of selecting weights that are far from zero, we retain connections that are moving away from zero during the training process. We consider two versions of movement pruning: hard and soft.

For (hard) movement pruning, masks are computed using the Topv function: $\mathbf{M}=\text{Top}\_{v}(\mathbf{S})$. Unlike magnitude pruning, during training, we learn both the weights $\mathbf{W}$ and their importance scores $\mathbf{S}$. During the forward pass, we compute for all $i$, $a\_{i}=\sum\_{k=1}^{n}W\_{i,k}M\_{i,k}x\_{k}$.

Since the gradient of Topv is 0 everywhere it is defined, we follow [Ramanujan et al. (2020)](#bib.bib17); [Mallya and Lazebnik (2018)](#bib.bib16) and approximate its value with the straight-through estimator ([Bengio et al., 2013](#bib.bib10)). In the backward pass, Topv is ignored and the gradient goes "straight-through" to $\mathbf{S}$. The approximation of gradient of the loss $\cal L$ with respect to $S\_{i,j}$ is given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{\partial{\cal L}}{\partial{S}\_{i,j}}=\frac{\partial{\cal L}}{\partial{a}\_{i}}\frac{\partial{a}\_{i}}{\partial{S}\_{i,j}}=\frac{\partial{\cal L}}{\partial{a}\_{i}}{W}\_{i,j}{x}\_{j}$ |  | (2) |

This implies that the scores of weights are updated, even if these weights are masked in the forward pass.
We prove in Appendix [A.1](#A1.SS1 "A.1 Guarantees on the decrease of the training loss ‣ Appendix A Appendices ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning") that movement pruning as an optimization problem will converge.

We also consider a relaxed (soft) version of movement pruning based on the binary mask function described by [Mallya and Lazebnik (2018)](#bib.bib16). Here we replace hyperparameter $v$ with a fixed global threshold value $\tau$ that controls the binary mask. The mask is calculated as $\mathbf{M}=(\mathbf{S}>\tau)$. In order to control the sparsity level, we add a regularization term $R(\mathbf{S})=\lambda\_{\text{mvp}}\sum\_{i,j}\sigma(S\_{i,j})$ which encourages the importance scores to decrease over time11
1
We also experimented with $\sum\_{i,j}|S\_{i,j}|$ but it turned out to be harder to tune while giving similar results.. The coefficient $\lambda\_{\text{mvp}}$ controls the penalty intensity and thus the sparsity level.

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | Magnitude pruning | $L\_{0}$ regularization | Movement pruning | Soft movement pruning |
| Pruning Decision | 0th order | 1st order | 1st order | 1st order |
| Masking Function | Topv | Continuous Hard-Concrete | Topv | Thresholding |
| Pruning Structure | Local or Global | Global | Local or Global | Global |
| Learning Objective | $\mathcal{L}$ | $\mathcal{L}+\lambda\_{l0}\mathbb{E}(L\_{0})$ | $\mathcal{L}$ | $\mathcal{L}+\lambda\_{\text{mvp}}R(\mathbf{S})$ |
| Gradient Form |  | Gumbel-Softmax | Straight-Through | Straight-Through |
| Scores $\mathbf{S}$ | $|W\_{i,j}|$ | $-\sum\_{t}(\frac{\partial{\cal L}}{\partial{W}\_{i,j}})^{(t)}{W}^{(t)}\_{i,j}f(\overline{S}\_{i,j}^{(t)})$ | $-\sum\_{t}(\frac{\partial{\cal L}}{\partial{W}\_{i,j}})^{(t)}{W}^{(t)}\_{i,j}$ | $-\sum\_{t}(\frac{\partial{\cal L}}{\partial{W}\_{i,j}})^{(t)}{W}^{(t)}\_{i,j}$ |

Table 1: Summary of the pruning methods considered in this work and their specificities. The expression of $f$ of $L\_{0}$ regularization is detailed in Eq ([4](#S4.E4 "In 𝐋_𝟎 Regularization ‣ 4 Movement Pruning ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning")).

#### Method Interpretation

In movement pruning, the gradient of $\cal{L}$ with respect to $W\_{i,j}$ is given by the standard gradient derivation: $\frac{\partial{\cal L}}{\partial W\_{i,j}}=\frac{\partial{\cal L}}{\partial a\_{i}}M\_{i,j}x\_{j}$. By combining it to Eq ([2](#S4.E2 "In 4 Movement Pruning ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning")), we have $\frac{\partial{\cal L}}{\partial S\_{i,j}}=\frac{\partial{\cal L}}{\partial W\_{i,j}}W\_{i,j}$ (we omit the binary mask term $M\_{i,j}$ for simplicity). From the gradient update in Eq ([2](#S4.E2 "In 4 Movement Pruning ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning")), $S\_{i,j}$ is increasing when $\frac{\partial{\cal L}}{\partial S\_{i,j}}<0$, which happens in two cases:

* •

  (a) $\frac{\partial{\cal L}}{\partial W\_{i,j}}<0$ and $W\_{i,j}>0$
* •

  (b) $\frac{\partial{\cal L}}{\partial W\_{i,j}}>0$ and $W\_{i,j}<0$

It means that during training $W\_{i,j}$ is increasing while being positive or is decreasing while being negative. It is equivalent to saying that $S\_{i,j}$ is increasing when $W\_{i,j}$ is moving away from 0. Inversely, $S\_{i,j}$ is decreasing when $\frac{\partial{\cal L}}{\partial S\_{i,j}}>0$ which means that $W\_{i,j}$ is shrinking towards 0.

(a) Magnitude pruning

(b) Movement pruning

Figure 1: During fine-tuning (on MNLI), the weights stay close to their pre-trained values which limits the adaptivity of magnitude pruning. We plot the identity line in black. Pruned weights are plotted in grey. Magnitude pruning selects weights that are far from 0 while movement pruning selects weights that are moving away from 0.

While magnitude pruning selects the most important weights as the ones which maximize their distance to 0 ($|W\_{i,j}|$), movement pruning selects the weights which are moving the most away from 0 ($S\_{i,j}$). For this reason, magnitude pruning can be seen as a 0th order method, whereas movement pruning is based on a 1st order signal. In fact, $\mathbf{S}$ can be seen as an accumulator of movement: from equation ([2](#S4.E2 "In 4 Movement Pruning ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning")), after $T$ gradient updates, we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $S\_{i,j}^{(T)}=-\alpha\_{S}\sum\_{t<T}(\frac{\partial{\cal L}}{\partial W\_{i,j}})^{(t)}W^{(t)}\_{i,j}$ |  | (3) |

Figure [1](#S4.F1 "Figure 1 ‣ Method Interpretation ‣ 4 Movement Pruning ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning") shows this difference empirically by comparing weight values during fine-tuning against their pre-trained value. As observed by [Gordon et al. (2020)](#bib.bib36), fine-tuned weights stay close in absolute value to their initial pre-trained values. For magnitude pruning, this stability around the pre-trained values implies that we know with high confidence before even fine-tuning which weights will be pruned as the weights with the smallest absolute value at pre-training will likely stay small and be pruned. In contrast, in movement pruning, the pre-trained weights do not have such an awareness of the pruning decision since the selection is made during fine-tuning (moving away from 0), and both low and high values can be pruned. We posit that this is critical for the success of the approach as it is able to prune based on the task-specific data, not only the pre-trained value.

#### $\mathbf{L\_{0}}$ Regularization

Finally we note that movement pruning (and its soft variant) yield a similar update as $L\_{0}$ regularization based pruning, another movement based pruning approach ([Louizos et al., 2017](#bib.bib13)). Instead of straight-through, $L\_{0}$ uses the hard-concrete distribution, where the mask $\mathbf{M}$ is sampled for all $i,j$ with hyperparameters $b>0$, $l<0$, and $r>1$:

|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle u$ | $\displaystyle\sim\mathcal{U}(0,1)$ | $\displaystyle\overline{{S}}\_{i,j}$ | $\displaystyle=\sigma\big((\log(u)-\log(1-u)+{S}\_{i,j})/b\big)$ |  |
|  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | $\displaystyle{Z}\_{i,j}$ | $\displaystyle=(r-l)\overline{{S}}\_{i,j}+l$ | $\displaystyle{M}\_{i,j}$ | $\displaystyle=\min(1,\operatorname{ReLU}({Z}\_{i,j}))$ |  |

The expected $L\_{0}$ norm has a closed form involving the parameters of the hard-concrete:
$\mathbb{E}(L\_{0})=\sum\_{i,j}\sigma\big(\log S\_{i,j}-b\log(-l/r)\big)$.
Thus, the weights and scores of the model can be optimized in an end-to-end fashion to minimize the sum of the training loss $\cal L$ and the expected $L\_{0}$ penalty. A coefficient $\lambda\_{l0}$ controls the $L\_{0}$ penalty and indirectly the sparsity level. Gradients take a similar form:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{\partial{\cal L}}{\partial{S}\_{i,j}}=\frac{\partial{\cal L}}{\partial a\_{i}}{W}\_{i,j}x\_{j}f(\overline{S}\_{i,j})\text{ where }f(\overline{S}\_{i,j})=\frac{r-l}{b}\bar{S}\_{i,j}(1-\bar{S}\_{i,j})\mathbf{1}\_{\{0\leq{Z}\_{i,j}\leq 1\}}$ |  | (4) |

At test time, a non-stochastic estimation of the mask is used:
$\mathbf{\hat{M}}=\min\Big(1,\operatorname{ReLU}\big((r-l)\sigma(\mathbf{S})+l\big)\Big)$
and weights multiplied by 0 can simply be discarded.

Table [1](#S4.T1 "Table 1 ‣ 4 Movement Pruning ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning") highlights the characteristics of each pruning method.
The main differences are in the masking functions, pruning structure, and the final gradient form.

## 5 Experimental Setup

Transfer learning for NLP uses large pre-trained language models that are fine-tuned on target tasks ([Ruder et al., 2019](#bib.bib37); [Devlin et al., 2019](#bib.bib11); [Radford et al., 2019](#bib.bib38); [Liu et al., 2019](#bib.bib39)).
We experiment with task-specific pruning of BERT-base-uncased, a pre-trained model that contains roughly 84M parameters. We freeze the embedding modules and fine-tune the transformer layers and the task-specific head. All reported sparsity percentages are relative to BERT-base and correspond exactly to model size even comparing to baselines.

We perform experiments on three monolingual (English) tasks, which are common benchmarks for the recent progress in transfer learning for NLP: question answering (SQuAD v1.1) ([Rajpurkar et al., 2016](#bib.bib15)), natural language inference (MNLI) ([Williams et al., 2018](#bib.bib14)), and sentence similarity (QQP) ([Iyer et al., 2017](#bib.bib40)). The datasets respectively contain 8K, 393K, and 364K training examples. SQuAD is formulated as a span extraction task, MNLI and QQP are paired sentence classification tasks.

For a given task, we fine-tune the pre-trained model for the same number of updates (between 6 and 10 epochs) across pruning methods22
2
Preliminary experiments showed that increasing the number of pruning steps tended to improve the end performance. We follow [Zhu and Gupta (2018)](#bib.bib35) and use a cubic sparsity scheduling for Magnitude Pruning (MaP), Movement Pruning (MvP), and Soft Movement Pruning (SMvP). Adding a few steps of cool-down at the end of pruning empirically improves the performance especially in high sparsity regimes. The schedule for $v$ is:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{cases}v\_{i}&0\leq t<t\_{i}\\ v\_{f}+(v\_{i}-v\_{f})(1-\frac{t-t\_{i}-t\_{f}}{N\Delta t})^{3}&t\_{i}\leq t<T-t\_{f}\\ v\_{f}&\text{o.w.}\end{cases}$ |  | (5) |

where $t\_{f}$ is the number of cool-down steps.

We compare our results against several state-of-the-art pruning baselines: Reweighted Proximal Pruning (RPP) ([Guo et al., 2019](#bib.bib41)) combines re-weighted $L\_{1}$ minimization and Proximal Projection ([Parikh and Boyd, 2014](#bib.bib42)) to perform unstructured pruning. LayerDrop ([Fan et al., 2020a](#bib.bib25)) leverages structured dropout to prune models at test time. For RPP and LayerDrop, we report results from authors. We also compare our method against the mini-BERT models, a collection of smaller BERT models with varying hyper-parameters ([Turc et al., 2019](#bib.bib43)).

Finally, [Gordon et al. (2020)](#bib.bib36); [Li et al. (2020)](#bib.bib34) apply unstructured magnitude pruning as a post-hoc operation whereas we use automated gradual pruning ([Zhu and Gupta, 2018](#bib.bib35)) which improves on these methods by enabling masked weights to be updated. Moreover, [McCarley (2019)](#bib.bib44) compares multiple methods to compute structured masking ($L\_{0}$ regularization and head importance as described in ([Michel et al., 2019](#bib.bib27))) and found that structured $L\_{0}$ regularization performs best. We did not find any implementation for this work, so for fair comparison, we presented a strong unstructured $L\_{0}$ regularization baseline.

## 6 Results

Figure [2](#S6.F2 "Figure 2 ‣ 6 Results ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning") displays the results for the main pruning methods at different levels of pruning on each dataset. First, we observe the consistency of the comparison between magnitude and movement pruning: at low sparsity (more than 70% of remaining weights), magnitude pruning outperforms all methods with little or no loss with respect to the dense model whereas the performance of movement pruning methods quickly decreases even for low sparsity levels. However, magnitude pruning performs poorly with high sparsity, and the performance drops extremely quickly. In contrast, first-order methods show strong performances with less than 15% of remaining weights.

Figure 2: Comparisons between different pruning methods in high sparsity regimes. Soft movement pruning consistently outperforms other methods in high sparsity regimes. We plot the performance of the standard fine-tuned BERT along with 95% of its performance. Sparsity percentages are relative to BERT-base and correspond exactly to model size.

Table [2](#S6.T2 "Table 2 ‣ 6 Results ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning") shows the specific model scores for different methods at high sparsity levels. Magnitude pruning on SQuAD achieves 54.5 F1 with 3% of the weights compared to 73.3 F1 with $L\_{0}$ regularization, 76.3 F1 for movement pruning, and 79.9 F1 with soft movement pruning. These experiments indicate that in high sparsity regimes, importance scores derived from the movement accumulated during fine-tuning induce significantly better pruned models compared to absolute values.

Next, we compare the difference in performance between first-order methods. We see that straight-through based hard movement pruning (MvP) is comparable with $L\_{0}$ regularization (with a significant gap in favor of movement pruning on QQP). Soft movement pruning (SMvP) consistently outperforms hard movement pruning and $L\_{0}$ regularization by a strong margin and yields the strongest performance among all pruning methods in high sparsity regimes. These comparisons support the fact that even if movement pruning (and its relaxed version soft movement pruning) is simpler than $L\_{0}$ regularization, it yet yields stronger performances for the same compute budget.

Finally, movement pruning and soft movement pruning compare favorably to the other baselines, except for QQP where RPP is on par with soft movement pruning. Movement pruning also outperforms the fine-tuned mini-BERT models.
This is coherent with ([Li et al., 2020](#bib.bib34)): it is both more efficient and more effective to train a large model and compress it afterward than training a smaller model from scratch. We do note though that current hardware does not support optimized inference for sparse models: from an inference speed perspective, it might often desirable to use a small dense model such as mini-BERT over a sparse alternative of the same size.

Table 2: 
Performance at high sparsity levels. (Soft) movement pruning outperforms current state-of-the art pruning methods at different high sparsity levels. 3% corresponds to 2.6 millions (M) non-zero parameters in the encoder and 10% to 8.5M.

|  | BERT base fine-tuned | Remaining Weights (%) | MaP | $L\_{0}$ Regu | MvP | soft MvP |
| --- | --- | --- | --- | --- | --- | --- |
| SQuAD - Dev EM/F1 | 80.4/88.1 | 10% | 67.7/78.5 | 69.9/80.0 | 71.9/81.7 | 71.3/81.5 |
| 3% | 40.1/54.5 | 61.2/73.3 | 65.2/76.3 | 69.5/79.9 |
| MNLI - Dev acc/MM acc | 84.5/84.9 | 10% | 77.8/79.0 | 77.9/78.5 | 79.3/79.5 | 80.7/81.1 |
| 3% | 68.9/69.8 | 75.1/75.4 | 76.1/76.7 | 79.0/79.6 |
| QQP - Dev acc/F1 | 91.4/88.4 | 10% | 78.8/75.1 | 87.5/81.9 | 89.1/85.5 | 90.5/87.1 |
| 3% | 72.1/58.4 | 86.5/81.0 | 85.6/81.0 | 89.3/85.6 |

#### Distillation further boosts performance

Figure 3: Comparisons between different pruning methods augmented with distillation. Distillation improves the performance across all pruning methods and sparsity levels.

Table 3: Distillation-augmented performances for selected high sparsity levels. All pruning methods benefit from distillation signal further enhancing the ratio Performance VS Model Size.

|  | BERT base fine-tuned | Remaining Weights (%) | MaP | $L\_{0}$ Regu | MvP | soft MvP |
| --- | --- | --- | --- | --- | --- | --- |
| SQuAD - Dev EM/F1 | 80.4/88.1 | 10% | 70.2/80.1 | 72.4/81.9 | 75.6/84.3 | 76.6/84.9 |
| 3% | 45.5/59.6 | 64.3/75.8 | 67.5/78.0 | 72.7/82.3 |
| MNLI - Dev acc/MM acc | 84.5/84.9 | 10% | 78.3/79.3 | 78.7/79.7 | 80.1/80.4 | 81.2/81.8 |
| 3% | 69.4/70.6 | 76.0/76.2 | 76.5/77.4 | 79.5/80.1 |
| QQP - Dev acc/F1 | 91.4/88.4 | 10% | 79.8/65.0 | 88.1/82.8 | 89.7/86.2 | 90.2/86.8 |
| 3% | 72.4/57.8 | 87.0/81.9 | 86.1/81.5 | 89.1/85.5 |

Following previous work, we can further leverage knowledge distillation ([Bucila et al., 2006](#bib.bib45); [Hinton et al., 2014](#bib.bib46)) to boost performance for free in the pruned domain ([Jiao et al., 2019](#bib.bib47); [Sanh et al., 2019](#bib.bib23)) using our baseline fine-tuned BERT-base model as teacher. The training objective is a convex combination of the training loss and a knowledge distillation loss on the output distributions. Figure [3](#S6.F3 "Figure 3 ‣ Distillation further boosts performance ‣ 6 Results ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning") shows the results on SQuAD, MNLI, and QQP for the three pruning methods boosted with distillation. Overall, we observe that the relative comparisons of the pruning methods remain unchanged while the performances are strictly increased. Table [3](#S6.T3 "Table 3 ‣ Distillation further boosts performance ‣ 6 Results ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning") shows for instance that on SQuAD, movement pruning at 10% goes from 81.7 F1 to 84.3 F1. When combined with distillation, soft movement pruning yields the strongest performances across all pruning methods and studied datasets: it reaches 95% of BERT-base with only a fraction of the weights in the encoder ($\sim$5% on SQuAD and MNLI).

## 7 Analysis

#### Movement pruning is adaptive

(a) Distribution of remaining weights

(b) Scores and weights learned by movement pruning

Figure 4: Magnitude pruning and movement pruning leads to pruned models with radically different weight distribution.

Figure 5: Comparison of local and global selections of weights on SQuAD at different sparsity levels. For magnitude and movement pruning, local and global Topv performs similarly at all levels of sparsity.

Figure 6: Remaining weights per layer in the Transformer. Global magnitude pruning tends to prune uniformly layers. Global 1st order methods allocate the weight to the lower layers while heavily pruning the highest layers.

Figure [4a](#S7.F4.sf1 "In Figure 4 ‣ Movement pruning is adaptive ‣ 7 Analysis ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning") compares the distribution of the remaining weights for the same matrix of a model pruned at the same sparsity using magnitude and movement pruning. We observe that by definition, magnitude pruning removes all the weights that are close to zero, ending up with two clusters. In contrast, movement pruning leads to a smoother distribution, which covers the whole interval except for values close to 0.

Figure [4b](#S7.F4.sf2 "In Figure 4 ‣ Movement pruning is adaptive ‣ 7 Analysis ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning") displays each individual weight against its associated importance score in movement pruning. We plot pruned weights in grey. We observe that movement pruning induces no simple relationship between the scores and the weights. Both weights with high absolute value or low absolute value can be considered important.
However, high scores are systematically associated with non-zero weights (and thus the “v-shape”).
This is coherent with the interpretation we gave to the scores (section [4](#S4.SS0.SSS0.Px1 "Method Interpretation ‣ 4 Movement Pruning ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning")): a high score $\mathbf{S}$ indicates that during fine-tuning, the associated weight moved away from 0 and is thus non-null.

#### Local and global masks perform similarly

We study the influence of the locality of the pruning decision. While local Topv selects the $v$% most important weights matrix by matrix, global Topv uncovers non-uniform sparsity patterns in the network by selecting the $v$% most important weights in the whole network. Previous work has shown that a non-uniform sparsity across layers is crucial to the performance in high sparsity regimes ([He et al., 2018](#bib.bib48)). In particular, [Mallya and Lazebnik (2018)](#bib.bib16) found that the sparsity tends to increase with the depth of the network layer.

Figure [6](#S7.F6 "Figure 6 ‣ Movement pruning is adaptive ‣ 7 Analysis ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning") compares the performance of local selection (matrix by matrix) against global selection (all the matrices) for magnitude pruning and movement pruning. Despite being able to find a global sparsity structure, we found that global did not significantly outperform local, except in high sparsity regimes (2.3 F1 points of difference with 3% of remaining weights for movement pruning). Even though the distillation signal boosts the performance of pruned models, the end performance difference between local and global selections remains marginal.

Figure [6](#S7.F6 "Figure 6 ‣ Movement pruning is adaptive ‣ 7 Analysis ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning") shows the remaining weights percentage obtained per layer when the model is pruned until 10% with global pruning methods. Global weight pruning is able to allocate sparsity non-uniformly through the network, and it has been shown to be crucial for the performance in high sparsity regimes ([He et al., 2018](#bib.bib48)). We notice that except for global magnitude pruning, all the global pruning methods tend to allocate a significant part of the weights to the lowest layers while heavily pruning in the highest layers. Global magnitude pruning tends to prune similarly to local magnitude pruning, i.e., uniformly across layers.

## 8 Conclusion

We consider the case of pruning of pretrained models for task-specific fine-tuning and compare zeroth- and first-order pruning methods. We show that a simple method for weight pruning based on straight-through gradients is effective for this task and that it adapts using a first-order importance score. We apply this movement pruning to a transformer-based architecture and empirically show that our method consistently yields strong improvements over existing methods in high-sparsity regimes. The analysis demonstrates how this approach adapts to the fine-tuning regime in a way that magnitude pruning cannot. In future work, it would also be interesting to leverage group-sparsity inducing penalties ([Bach et al., 2011](#bib.bib49)) to remove entire columns or filters. In this setup, we would associate a score to a group of weights (a column or a row for instance). In the transformer architecture, it would give a systematic way to perform feature selection and remove entire columns of the embedding matrix.

## 9 Broader Impact

This work is part of a broader line of research on reducing the memory size of state-of-the-art models in Natural Language Processing (and more generally in Artificial Intelligence). This line of research has potential positive impact in society from a privacy and security perspective: being able to store and run state-of-the-art NLP capabilities on devices (such as smartphones) would erase the need to send API calls (with potentially private data) to a remote server. It is particularly important since there is a rising concern about the potential negative uses of centralized personal data. Moreover, this is complementary to hardware manufacturers’ efforts to build chips that will considerably speedup inference for sparse networks while reducing the energy consumption of such networks.

From an accessibility standpoint, this line of research has the potential to give access to extremely large models ([Raffel et al., 2019](#bib.bib1); [Brown et al., 2020](#bib.bib50)) to the broader community, and not only big labs with large clusters. Extremely compressed models with comparable performance enable smaller teams or individual researchers to experiment with large models on a single GPU. For instance, it would enable the broader community to engage in analyzing a model’s biases such as gender bias ([Lu et al., 2018](#bib.bib51); [Vig et al., 2020](#bib.bib52)), or a model’s lack of robustness to adversarial attacks ([Wallace et al., 2019](#bib.bib53)). More in-depth studies are necessary in these areas to fully understand the risks associated to a model and create robust ways to mitigate them before massively deploying these capabilities.

## Acknowledgments and Disclosure of Funding

This work is conducted as part the authors’ employment at Hugging Face.

## Appendix A Appendices

### A.1 Guarantees on the decrease of the training loss

As the scores are updated, the relative order of the importances is likely shuffled, and some connections will be replaced by more important ones. Under certain conditions, we are able to formally prove that as these replacements happen, the training loss is guaranteed to decrease. Our proof is adapted from [[Ramanujan et al., 2020](#bib.bib17)] to consider the case of fine-tuable $\mathbf{W}$.

We suppose that (a) the training loss $\cal L$ is smooth and admits a first-order Taylor development everywhere it is defined and (b) the learning rate of $\mathbf{W}$ ($\alpha\_{\mathbf{W}}>0$) is small. We define the TopK function as the analog of the Topv function, where $k$ is an integer instead of a proportion. We first consider the case where $k=1$ in the TopK masking, meaning that only one connection is remaining (and the other weights are deactivated/masked). Let’s denote $W\_{i,j}$ this sole remaining connection at step $t$. Following Eq ([1](#S3.E1 "In 3 Background: Score-Based Pruning ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning")), it means that $\forall 1\leq u,v\leq n,S^{(t)}\_{u,v}\leq S^{(t)}\_{i,j}$.

We suppose that at step $t+1$, connections are swapped and the only remaining connection at step $t+1$ is $(k,l)$. We have:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{cases}\text{At $t$},&\forall 1\leq u,v\leq n,S^{(t)}\_{u,v}\leq S^{(t)}\_{i,j}\\ \text{At $t+1$},&\forall 1\leq u,v\leq n,S^{(t+1)}\_{u,v}\leq S^{(t+1)}\_{k,l}\end{cases}$ |  | (6) |

Eq ([6](#A1.E6 "In A.1 Guarantees on the decrease of the training loss ‣ Appendix A Appendices ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning")) gives the following inequality: $S^{(t+1)}\_{k,l}-S^{(t)}\_{k,l}\geq S^{(t+1)}\_{i,j}-S^{(t)}\_{i,j}$. After re-injecting the gradient update in Eq ([2](#S4.E2 "In 4 Movement Pruning ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning")), we have:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $-\alpha\_{\mathbf{S}}\frac{\partial{\cal L}}{\partial a\_{k}}W^{(t)}\_{k,l}x\_{l}\geq-\alpha\_{\mathbf{S}}\frac{\partial{\cal L}}{\partial a\_{i}}W^{(t)}\_{i,j}x\_{j}$ |  | (7) |

Moreover, the conditions in Eq ([6](#A1.E6 "In A.1 Guarantees on the decrease of the training loss ‣ Appendix A Appendices ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning")) lead to the following inferences: $a^{(t)}\_{i}=W^{(t)}\_{i,j}x\_{j}$ and $a^{(t+1)}\_{k}=W^{(t+1)}\_{k,l}x\_{l}$.

Since $\alpha\_{\mathbf{W}}$ is small, $||(a^{(t+1)}\_{i},a^{(t+1)}\_{k})-(a^{(t)}\_{i},a^{(t)}\_{k})||\_{2}$ is also small. Because the training loss $\cal L$ is smooth, we can write the 1st order Taylor development of $\cal{L}$ in point $(a^{(t)}\_{i},a^{(t)}\_{k})$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{split}&\mathcal{L}(a^{(t+1)}\_{i},a^{(t+1)}\_{k})-\mathcal{L}(a^{(t)}\_{i},a^{(t)}\_{k})\\ &\approx\frac{\partial{\cal L}}{\partial a\_{k}}(a^{(t+1)}\_{k}-a^{(t)}\_{k})+\frac{\partial{\cal L}}{\partial a\_{i}}(a^{(t+1)}\_{i}-a^{(t)}\_{i})\\ &=\frac{\partial{\cal L}}{\partial a\_{k}}W^{(t+1)}\_{k,l}x\_{l}-\frac{\partial{\cal L}}{\partial a\_{i}}W^{(t)}\_{i,j}x\_{j}\\ &=\frac{\partial{\cal L}}{\partial a\_{k}}W^{(t+1)}\_{k,l}x\_{l}+(-\frac{\partial{\cal L}}{\partial a\_{k}}W^{(t)}\_{k,l}x\_{l}+\frac{\partial{\cal L}}{\partial a\_{k}}W^{(t)}\_{k,l}x\_{l})-\frac{\partial{\cal L}}{\partial a\_{i}}W^{(t)}\_{i,j}x\_{j}\\ &=\frac{\partial{\cal L}}{\partial a\_{k}}(W^{(t+1)}\_{k,l}x\_{l}-W^{(t)}\_{k,l}x\_{l})+(\frac{\partial{\cal L}}{\partial a\_{k}}W^{(t)}\_{k,l}x\_{l}-\frac{\partial{\cal L}}{\partial a\_{i}}W^{(t)}\_{i,j}x\_{j})\\ &=\frac{\partial{\cal L}}{\partial a\_{k}}x\_{l}(-\alpha\_{\mathbf{W}}\frac{\partial{\cal L}}{\partial a\_{k}}x\_{l}m(S^{(t)})\_{k,l})+(\frac{\partial{\cal L}}{\partial a\_{k}}W^{(t)}\_{k,l}x\_{l}-\frac{\partial{\cal L}}{\partial a\_{i}}W^{(t)}\_{i,j}x\_{j})\end{split}$ |  | (8) |

The first term is null because of inequalities ([6](#A1.E6 "In A.1 Guarantees on the decrease of the training loss ‣ Appendix A Appendices ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning")) and the second term is negative because of inequality ([7](#A1.E7 "In A.1 Guarantees on the decrease of the training loss ‣ Appendix A Appendices ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning")). Thus $\mathcal{L}(a^{(t+1)}\_{i},a^{(t+1)}\_{k})\leq\mathcal{L}(a^{(t)}\_{i},a^{(t)}\_{k})$: when connection $(k,l)$ becomes more important than $(i,j)$, the connections are swapped and the training loss decreases between step $t$ and $t+1$.

Similarly, we can generalize the proof to a set $\mathcal{E}=\{\big((a\_{i},b\_{i}),(c\_{i},d\_{i})\big);i\leq N\}$ of $N$ swapping connections.

We note that this proof is not specific to the TopK masking function. In fact, we can extend the proof using the Threshold masking function $\mathbf{M}:=(\mathbf{S}>=\tau)$ [[Mallya and Lazebnik, 2018](#bib.bib16)]. Inequalities ([6](#A1.E6 "In A.1 Guarantees on the decrease of the training loss ‣ Appendix A Appendices ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning")) are still valid and the proof stays unchanged.

Last, we note these guarantees do not hold if we consider the absolute value of the scores $|S\_{i,j}|$ (as it is done in [Ding et al. [2019]](#bib.bib21) for instance). We prove it by contradiction. If it was the case, it would also be true one specific case: the negative threshold masking function ($\mathbf{M}:=(\mathbf{S}<\tau)$ where $\tau<0$).

We suppose that at step $t+1$, the only remaining connection $(i,j)$ is replaced by $(k,l)$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\begin{cases}\text{At $t$},&\forall 1\leq u,v\leq n,S^{(t)}\_{i,j}\leq\tau\leq S^{(t)}\_{u,v}\\ \text{At $t+1$},&\forall 1\leq u,v\leq n,S^{(t+1)}\_{k,l}\leq\tau\leq S^{(t+1)}\_{u,v}\end{cases}$ |  | (9) |

The inequality on the gradient update becomes: $-\alpha\_{\mathbf{S}}\frac{\partial{\cal L}}{\partial a\_{k}}W^{(t)}\_{k,l}x\_{l}<-\alpha\_{\mathbf{S}}\frac{\partial{\cal L}}{\partial a\_{i}}W\_{i,j}x\_{j}$ and following the same development as in Eq ([8](#A1.E8 "In A.1 Guarantees on the decrease of the training loss ‣ Appendix A Appendices ‣ Movement Pruning: Adaptive Sparsity by Fine-Tuning")), we have $\mathcal{L}(a^{(t+1)}\_{i},a^{(t+1)}\_{k})-\mathcal{L}(a^{(t)}\_{i},a^{(t)}\_{k})\geq 0$: the loss increases. We proved by contradiction that the guarantees on the decrease of the loss do not hold if we consider the absolute value of the score as a proxy for importance.

### A.2 Code and Hyperparameters

Our code to reproduce our results along with the commands to launch the scripts are available33
3
[huggingface.co/mvp](https://huggingface.co/mvp) through the Hugging Face Transformers library [[Wolf et al., 2019](#bib.bib54)]. We also detail all the hyperparameters used in our experiments.

All of the presented experiments run on a single 16GB V100.

### A.3 Inference speed

Early experiments show that even though models fine-pruned with movement pruning are extremely sparse and can be stored efficiently, they do not benefit from significant improvement in terms of inference speed when using the standard PyTorch inference. In fact, in our implementation, sparse matrices are simply matrices with lots of 0 inside which does not induce significant inference speedup without specific hardware optimizations. Recently, hardware manufacturers have announced chips specifically designed for sparse networks44
4
<https://devblogs.nvidia.com/nvidia-ampere-architecture-in-depth/>.
