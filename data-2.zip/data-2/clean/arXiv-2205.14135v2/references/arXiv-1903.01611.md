<!-- fulltext source=arxiv_html slug=arXiv-1903.01611 fetched=2026-09-16T11:52:11+00:00 -->

# Stabilizing the Lottery Ticket HypothesisThanks: This article has been subsumed by *Linear Mode Connectivity and the Lottery Ticket Hypothesis* ([Frankle et al., 2020](#bib.bib5)). Please read/cite that article instead.

Jonathan Frankle
Affiliation: MIT CSAIL
  
Karolina Dziugaite
Affiliation: University of Cambridge
Affiliation: Element AI
  
Daniel M. Roy
Affiliation: University of Toronto
Affiliation: Vector Institute
  
Michael Carbin
Affiliation: MIT CSAIL

###### Abstract

Pruning is a well-established technique for removing unnecessary structure from neural networks after training to improve the performance of inference.
Several recent results have explored the possibility of pruning at initialization time to provide similar benefits during training.
In particular, the *lottery ticket hypothesis* conjectures that typical neural networks contain small subnetworks that can train to similar accuracy in a commensurate number of steps.
The evidence for this claim is that a procedure based on iterative magnitude pruning (IMP) reliably finds such subnetworks retroactively on small vision tasks.
However, IMP fails on deeper networks, and proposed methods to prune before training or train pruned networks encounter similar scaling limitations.

In this paper, we argue that these efforts have struggled on deeper networks because they have focused on pruning precisely at initialization.
We modify IMP to search for subnetworks that could have been obtained by pruning *early* in training (0.1% to 7% through) rather than at iteration 0.
With this change, it finds small subnetworks of deeper networks (e.g., 80% sparsity on Resnet-50) that can complete the training process to match the accuracy of the original network on more challenging tasks (e.g., ImageNet).
In situations where IMP fails at iteration 0, the accuracy benefits of delaying pruning accrue rapidly over the earliest iterations of training.
To explain these behaviors, we study subnetwork *stability*, finding that—as accuracy improves in this fashion—IMP subnetworks train to parameters closer to those of the full network and do so with improved consistency in the face of gradient noise.
These results offer new insights into the opportunity to prune large-scale networks early in training and the behaviors underlying the lottery ticket hypothesis.

## 1 Introduction

For decades, *pruning* ([LeCun
et al., 1990](#bib.bib13); [Han
et al., 2015](#bib.bib8)) unnecessary structure from neural networks has been a popular way to improve the storage and computational costs of inference, which can often be reduced by an order of magnitude without harm to accuracy.
Pruning is typically a post-processing step after training;
until recently, it was believed that the pruned architectures could not themselves be trained from the start ([Han
et al., 2015](#bib.bib8); [Li
et al., 2016](#bib.bib15)).
New results challenge this wisdom, raising the prospect of reducing the cost of training by pruning beforehand.
[Liu
et al. (2019)](#bib.bib16) demonstrate that, at moderate levels of sparsity, pruning produces networks that can be reinitialized and trained to equal accuracy;
[Lee
et al. (2019)](#bib.bib14) propose an efficient method for finding such reinitializable subnetworks before training (SNIP).

[Frankle and
Carbin (2019)](#bib.bib4) characterize the opportunity for pruning at initialization.
For shallow vision networks, they observe that—at levels of sparsity that are more extreme than [Liu
et al. (2019)](#bib.bib16) and [Lee
et al. (2019)](#bib.bib14)—pruned networks can successfully train from scratch so long as each unpruned connection is *reset* back to its initial value from before training.11
1
Appendix [A](#A1 "Appendix A Comparison to “Rethinking the Value of Pruning” and “SNIP” ‣ Stabilizing the Lottery Ticket Hypothesis") compares [Liu
et al. (2019)](#bib.bib16), [Lee
et al. (2019)](#bib.bib14), and [Frankle and
Carbin (2019)](#bib.bib4).
This procedure, which we term *iterative magnitude pruning*
(IMP; Algorithm [1](#alg1 "Algorithm 1 ‣ 1 Introduction ‣ Stabilizing the Lottery Ticket Hypothesis") with $k=0$), produces a subnetwork of the original, untrained network; when it matches the accuracy of the original network, it is called a *winning ticket*.
Based on these results, [Frankle and
Carbin](#bib.bib4) propose the *lottery ticket hypothesis*: dense neural networks contain sparse subnetworks capable of training to commensurate accuracy at similar speed.

Algorithm 1  Iterative Magnitude Pruning (IMP) with rewinding to iteration $k$.

```
1:
Randomly initialize a neural network f⁡(x,m⊙W0)f(x;m\odot W_{0}) with initial trivial pruning mask m=1|W0|m=1^{|W_{0}|}.

2:
Train the network for kk iterations, producing network f⁡(x,m⊙Wk)f(x;m\odot W_{k}).

3:
Train the network for T−kT-k further iterations, producing network f⁡(x,m⊙Wt)f(x;m\odot W_{t}). 

4:
Prune the remaining entries with the lowest magnitudes from WTW_{T}. That is, let m⁡[i]=0m[i]=0 if WT​[i]W_{T}[i] is pruned.

5:
If satisfied, the resulting network is f⁡(x,m⊙WT)f(x;m\odot W_{T}).

6:
Otherwise, reset WW to WkW_{k} and repeat steps 3-5 iteratively, gradually removing more of the network.
```

Despite the enormous potential of pruning before training, none of this work scales beyond small vision benchmarks.
[Lee
et al.](#bib.bib14) provides results only for Tiny ImageNet, a restricted version of ImageNet with 200 classes.
[Liu
et al.](#bib.bib16) examine Resnet-50 on ImageNet, but accuracy declines when only 30% of parameters are pruned.
[Liu
et al.](#bib.bib16), [Gale
et al. (2019)](#bib.bib6), and [Frankle and
Carbin](#bib.bib4) themselves show that IMP fails on deeper networks.
To find winning tickets on deeper networks for CIFAR10, [Frankle and
Carbin](#bib.bib4) make bespoke changes to each network’s learning schedule.
In this paper, we argue that such efforts to train pruned networks or prune before training have struggled on deeper networks because they have focused on doing so precisely at initialization.

In comparison, other techniques gradually prune networks throughout training to competitive levels of sparsity without compromising accuracy ([Zhu and Gupta, 2017](#bib.bib28); [Gale
et al., 2019](#bib.bib6); [Lym et al., 2019](#bib.bib19); [Narang
et al., 2017](#bib.bib24); [Louizos
et al., 2018](#bib.bib17); [Narang
et al., 2017](#bib.bib24)).
However, these approaches must maintain much of the network for a large portion of training or do not scale beyond toy benchmarks.

Rewinding.
In this paper, we demonstrate that there exist subnetworks of deeper networks (i.e., Resnet-50, Squeezenet, Inception-v3) at early points in training (0.1% to 7% through) that are 50% to 99% smaller and that can complete the training process to match the original network’s accuracy.
We show this by modifying IMP to *rewind* pruned subnetwork weights to their former values at iteration $k$ rather than *resetting* them to iteration 0.
For networks where IMP cannot find a winning ticket, the accuracy benefits of this delay in pruning accrue rapidly over the earliest iterations of training.
For example, IMP finds 80% sparse subnetworks of Resnet-50 at epoch 6 (out of 90) with no loss in accuracy on ImageNet.
To the best of our knowledge, our work is the first to show that it is possible to prune (1) so early in training (2) to such extreme levels of sparsity (3) on such large-scale tasks.

Stability.
To explain why IMP fails when resetting to iteration 0 and improves rapidly when rewinding later, we introduce subnetwork *stability*: the distance between two trained copies of the same subnetwork subjected to different noise.
In particular, we focus on the noise introduced by pruning (comparing the trained weights of the full network and subnetwork) and data order (comparing the weights of two subnetworks trained with different data orders).
In cases where IMP fails to find a winning ticket when resetting to iteration 0, both forms of stability improve rapidly as pruning is delayed during the early part of training, mirroring the rise in accuracy.
Stability to pruning captures the extent to which the subnetwork arrived at the same destination as the original network in the optimization landscape.
We hypothesize that improved stability to pruning means that a subnetwork comes closer to the original optimum and thereby accuracy; improvements in stability to data order mean the subnetwork can do so consistently in spite of the noise intrinsic to SGD.

Finally, we revise the lottery ticket hypothesis to consider rewinding in accordance with these results:

###### The Lottery Ticket Hypothesis with Rewinding.

Consider a dense, randomly-initialized neural network $f(x;W\_{0})$ that trains to accuracy $a^{\*}$ in $T^{\*}$ iterations.
Let $W\_{t}$ be the weights at iteration $t$ of training.
There exist an iteration $k\ll T^{\*}$ and fixed pruning mask $m\in\{0,1\}^{|W\_{0}|}$ (where $||m||\_{1}\ll|W\_{0}|$) such that subnetwork $m\odot W\_{k}$ trains to accuracy $a\geq a^{\*}$ in $T\leq T^{\*}-k$ iterations.

Based on this new understanding of the lottery ticket hypothesis provided by our rewinding and stability experiments, we conclude that there are unexploited opportunities to prune large-scale networks early in training while maintaining the accuracy of the eventual trained networks.

## 2 Stability at Initialization

On deeper networks for CIFAR10, Iterative Magnitude Pruning (IMP; Algorithm [1](#alg1 "Algorithm 1 ‣ 1 Introduction ‣ Stabilizing the Lottery Ticket Hypothesis") at $k=0$) fails to yield winning tickets.
The solid blue line in Figure [1](#S2.F1 "Figure 1 ‣ 2 Stability at Initialization ‣ Stabilizing the Lottery Ticket Hypothesis") shows that IMP on VGG-19 (left) and Resnet-18 (right) produces no winning tickets;
the original initialization is inconsequential, and the networks can be reinitialized (dashed blue) without altering accuracy.
[Frankle and
Carbin](#bib.bib4) manage to find winning tickets in these networks by altering the learning schedule, lowering the learning rate (green) or adding warmup (orange).
However, they offer no principled justification for these choices, which are brittle and often alter the behavior of the unpruned networks.

To understand why IMP succeeds or fails to find winning tickets, we examine their *stability*.
We measure two forms of stability: 1) *stability to pruning:* the distance between the weights of a subnetwork trained in isolation and the weights of the same subnetwork when trained within the larger network and 2) *stability to data order:* the distance between the weights of two copies of a subnetwork trained with different data orders.
Stability to pruning captures a subnetwork’s ability to train in isolation and still reach the same destination as the larger network.
Stability to data order captures a subnetwork’s intrinsic ability to consistently reach the same destination despite the gradient noise of SGD.
In this section, we demonstrate that, when IMP returns a subnetwork that qualifies as a winning ticket, it is dramatically more stable by both measures than a randomly-pruned network of the same size.

Formal definitions. A *subnetwork* is a tuple $(W,m)$ of weights $W:\mathbb{R}^{D}$ and a fixed pruning mask $m:\{0,1\}^{D}$.
Notation $m\odot W$ denotes an element-wise product of a mask with weights.
A stochastic training *algorithm* $\mathcal{A}^{t}:\mathbb{R}^{D}\times U\to\mathbb{R}^{D}$ maps initial weights $W$ and data order randomness $u\sim U$ to weights $W\_{t}$ at iteration $t\in\{1,..,T\}$.
The distance $d$ between trained weights $W\_{t}$ and $W^{\prime}\_{t}$ is the $L\_{2}$ distance between the masked, trained parameters: $||m\odot W\_{t}-m\odot W^{\prime}\_{t}||\_{2}$. Throughout the paper, Appendix [B](#A2 "Appendix B Angle Measurements (Stability) ‣ Stabilizing the Lottery Ticket Hypothesis"), follows the same analysis for the angle between the masked, trained parameters.

The stability to pruning of a subnetwork $(W\_{t},m)$ with respect to a noise distribution $U$ under a distance $d(\cdot,\cdot)$ is the expected distance between masked weights at the end of training: $d(\mathcal{A}^{T-t}(W\_{t},u),\mathcal{A}^{T-t}(m\odot W\_{t},u))$ for $u\sim U$.

The stability to data order of a subnetwork $(W\_{t},m)$ with respect to a noise distribution $U$ under a distance $d(\cdot,\cdot)$ is the expected distance between masked weights at the end of training: $d(\mathcal{A}^{T-t}(m\odot W\_{t},u),\mathcal{A}^{T-t}(m\odot W\_{t},u^{\prime}))$ for $u,u^{\prime}\sim U$.

Figure 1: On deeper networks for CIFAR10, IMP fails to
find winning tickets unless the learning rate schedule is altered.

|  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Network | Dataset | Params | Iters | Batch | Accuracy | Rate | Schedule | Warmup | Winning? |
| Lenet | MNIST | 266K | 50K | 60 | 98.0 $\pm$ 0.2% | adam 12e-4 | constant | 0 | Y |
| Resnet-18 (standard) |  |  |  |  | 90.5 $\pm$ 0.0% | mom. 0.1 | 10x drop at  56K, 84K | 0 | N |
| Resnet-18 (low) | CIFAR10 | 274K | 30K | 128 | 89.1 $\pm$ 0.1% | mom. 0.01 | 0 | Y |
| Resnet-18 (warmup) |  |  |  |  | 89.6 $\pm$ 0.1% | mom. 0.03 | 20K | Y |
| VGG-19 (standard) |  |  |  |  | 91.5 $\pm$ 0.2% | mom. 0.1 | 10x drop at  20K, 25K | 0 | N |
| VGG-19 (low) | CIFAR10 | 20.0M | 112K | 64 | 92.0 $\pm$ 0.1% | mom. 0.01 | 0 | N |
| VGG-19 (warmup) |  |  |  |  | 92.3 $\pm$ 0.1% | mom. 0.1 | 10K | Y |

Figure 2: Networks for MNIST and CIFAR10. Accuracies averaged across three trials.

|  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Network | Sparsity | Data Order Stability (Distance) | | | Pruning Stability (Distance) | | | Accuracy | |
|  |  | IMP | Random | Comp | IMP | Random | Comp | IMP | Random |
| Lenet | 10.7% | 20.7 $\pm$ 0.6 | 58.6 $\pm$ 4.0 | 2.8x | 48.1 $\pm$ 0.6 | 75.7 $\pm$ 0.5 | 1.6x | 98.3 $\pm$ 0.1 | 97.5 $\pm$ 0.3 |
| Resnet-18 (standard) |  | 66.4 $\pm$ 0.7 | 66.7 $\pm$ 1.1 | 1.0x | 54.4 $\pm$ 0.2 | 53.4 $\pm$ 0.4 | 1.0x | 87.7 $\pm$ 0.4 | 87.7 $\pm$ 0.5 |
| Resnet-18 (low) | 16.7% | 07.1 $\pm$ 1.2 | 28.9 $\pm$ 3.2 | 4.1x | 19.8 $\pm$ 1.4 | 26.6 $\pm$ 0.1 | 1.3x | 89.1 $\pm$ 0.4 | 86.1 $\pm$ 0.6 |
| Resnet-18 (warmup) |  | 09.5 $\pm$ 0.1 | 37.4 $\pm$ 1.9 | 3.9x | 24.8 $\pm$ 0.9 | 34.6 $\pm$ 0.2 | 1.4x | 90.3 $\pm$ 0.4 | 86.8 $\pm$ 0.5 |
| VGG-19 (standard) |  | 285 $\pm$ 3 | 245 $\pm$ 34 | 0.8x | 216 $\pm$ 1 | 212 $\pm$ 1 | 1.0x | 90.0 $\pm$ 0.3 | 90.2 $\pm$ 0.5 |
| VGG-19 (low) | 2.2% | 36.8 $\pm$ 2.6 | 90.3 $\pm$ 0.7 | 2.5x | 44.0 $\pm$ 0.3 | 66.1 $\pm$ 0.4 | 1.5x | 91.0 $\pm$ 0.3 | 88.0 $\pm$ 0.3 |
| VGG-19 (warmup) |  | 97 $\pm$ 0.6 | 267 $\pm$ 2 | 2.7x | 138 $\pm$ 1 | 201 $\pm$ 1 | 1.5x | 92.4 $\pm$ 0.2 | 90.3 $\pm$ 0.3 |

Figure 3: The average data order stability of subnetworks obtained by IMP and by randomly pruning. Errors are the minimum or maximum across 18 samples.

Methodology.
We measure both forms of stability for Lenet for MNIST and Resnet-18 and VGG-19 for CIFAR10 as studied by [Frankle and
Carbin](#bib.bib4) and described in Figure [2](#S2.F2 "Figure 2 ‣ 2 Stability at Initialization ‣ Stabilizing the Lottery Ticket Hypothesis"). We do so for networks produced by IMP as well as randomly-pruned networks in which we generate a random mask $m$ of a given size with the same layer-wise proportions.
These networks are trained for a fixed number of epochs.
During each epoch, all training examples are randomly shuffled, randomly augmented, and separated into minibatches without replacement; network parameters are updated based on each minibatch in sequence until the training data is exhausted, after which the next epoch begins.

Results.
Figure [3](#S2.F3 "Figure 3 ‣ 2 Stability at Initialization ‣ Stabilizing the Lottery Ticket Hypothesis") displays the stability for IMP subnetworks at a representative level of sparsity.
IMP finds winning tickets for Lenet, but cannot do so for Resnet-18 or VGG-19 without warmup.
Whenever it does so, the winning ticket is far more stable than a randomly-sampled subnetwork.
For example, Lenet winning tickets are 2.8x (data order) and 1.6x (pruning) closer in $L\_{2}$ distance than random subnetworks.
Conversely, IMP cannot find a winning ticket within VGG-19 (standard) and Resnet-18 (standard), and the subnetworks it returns are no more stable than random subnetworks.

Discussion.
These results suggest a connection between winning tickets and stability. Winning tickets are far more stable than random subnetworks.
Likewise, when IMP subnetworks are no more accurate than random subnetworks, they are correspondingly no more stable.
Interestingly, [Frankle and
Carbin](#bib.bib4)’s techniques that enable IMP to find winning tickets also benefit stability.

## 3 Stability with Rewinding

Figure 4: The effect of the rewinding iteration (x-axis) on data order (top row) and pruning (middle row) stability and accuracy (bottom row) for networks in Figure [2](#S2.F2 "Figure 2 ‣ 2 Stability at Initialization ‣ Stabilizing the Lottery Ticket Hypothesis"). Error bars are the minimum and maximum across 18 (data order) and three samples (stability and accuracy). These results were obtained by training more than 6500 networks on K80s and V100s.

In cases where the IMP fails to find a winning ticket, reducing the learning rate early in training via warmup makes it possible for the procedure to succeed, simultaneously improving the stability of the resulting subnetwork.
The efficacy of warmup suggests that a high learning rate is not necessarily detrimental later in training—only in the initial iterations.
One hypothesis to explain these results is that—for the less overparameterized regime of training a subnetwork—optimization is particularly sensitive to noise in the early phase of training.
This sensitivity can be mitigated by reducing the learning rate early on, minimizing the consequences of any individual misstep.

Under this hypothesis, we would expect these subnetworks to become more stable later in training, when they better tolerate a high learning rate.
We explore this possibility by modifying IMP (Algorithm [1](#alg1 "Algorithm 1 ‣ 1 Introduction ‣ Stabilizing the Lottery Ticket Hypothesis") with $k\neq 0$).
After finding a subnetwork, *rewind* each connection back to its weight from an earlier iteration $k$ rather than *resetting* it back to its initial value as [Frankle and
Carbin](#bib.bib4) do.

Results.
The upper two plots for each network in Figure [4](#S3.F4 "Figure 4 ‣ 3 Stability with Rewinding ‣ Stabilizing the Lottery Ticket Hypothesis") show the stability (measured in distance) of the IMP subnetwork (blue) and a random subnetwork (orange) across rewinding iterations.
Across all networks, rewinding later causes gradual improvements in stability, supporting our hypothesis.

For Resnet-18 (standard) and VGG-19 (standard), in which no winning tickets can be found, IMP subnetworks are no more stable than randomly-pruned subnetworks when reset to iteration 0.
However, as the rewinding iteration increases, the IMP subnetwork’s stability dramatically improves when compared to its stability at iteration 0.
Up to our point of analysis, this improvement is larger than that for random subnetworks.
For IMP subnetworks, this change takes place rapidly—within the first 100 iterations (0.14 epochs) for VGG-19 and 500 iterations (1.4 epochs) for Resnet-18.

In cases where IMP finds a winning ticket, IMP subnetworks are already more stable than random subnetworks when resetting to iteration 0 (as noted in Section [2](#S2 "2 Stability at Initialization ‣ Stabilizing the Lottery Ticket Hypothesis")).
This stability gap remains in place across all rewinding iterations that we consider, although it gradually shrinks toward the end of our range of analysis as the random subnetworks become somewhat more stable;
by this point, the networks have already made substantial training progress or—in the case of Lenet—converged.

Discussion.
Section [2](#S2 "2 Stability at Initialization ‣ Stabilizing the Lottery Ticket Hypothesis") shows that, when IMP identifies a winning ticket, it is more stable than a random subnetwork.
Here, we find that IMP subnetworks generally achieve such a stability gap across all network configurations;
however, in many cases, this occurs a small way into training.

## 4 Accuracy with Rewinding

Section [2](#S2 "2 Stability at Initialization ‣ Stabilizing the Lottery Ticket Hypothesis") observes that winning tickets found by IMP exhibit both improved accuracy and stability over random subnetworks.
The previous section finds that the stability of IMP subnetworks improves as a function of rewinding iteration, especially rapidly so for networks where winning tickets are not found.
The bottom plots in Figure [4](#S3.F4 "Figure 4 ‣ 3 Stability with Rewinding ‣ Stabilizing the Lottery Ticket Hypothesis") show that accuracy improves in a similar manner.
Although resetting to iteration 0 does not produce winning tickets for Resnet-18 and VGG-19, rewinding slightly later (iteration 500 for Resnet-18 and 100 for VGG-19) leads to IMP subnetworks that exceed the accuracy of the original network.
At later rewinding iterations, the rate of stability improvements subsides for these subnetworks, corresponding to slowed or no improvement in accuracy.

Improved stability also results in improved accuracy for random subnetworks.
However, the accuracy of the random subnetworks remains lower in all of our experiments.
We believe that the significant stability gap explains this difference:
we hypothesize that the stability of IMP subnetworks over their random counterparts results in better accuracy.

For the latest rewinding iterations that we consider, IMP subnetwork accuracy declines in many cases.
According to our methodology, we train a subnetwork rewound to iteration $k$ for $T^{\*}-k$ iterations, where $T^{\*}$ is the iterations for which the original network was trained.
At later rewind points, we believe that this does not permit enough training time for the subnetwork to recover from pruning.

Figure 5: IMP subnetworks rewound to an iteration early in training outperform the original networks, while resetting to iteration 0 does not.

Discussion.
Figure [5](#S4.F5 "Figure 5 ‣ 4 Accuracy with Rewinding ‣ Stabilizing the Lottery Ticket Hypothesis") plots the accuracy of Resnet-18 and VGG-19 across all levels of sparsity, comparing the IMP subnetworks reset to iteration 0 with those rewound to iteration 100 (VGG-19) and iteration 500 (Resnet-18)—the iterations at which stability and accuracy improvements saturate.
At all levels of sparsity, rewinding makes it possible to find trainable subnetworks early in training without any modifications to network hyperparameters (unlike the warmup or reduced learning rates required in Figure [1](#S2.F1 "Figure 1 ‣ 2 Stability at Initialization ‣ Stabilizing the Lottery Ticket Hypothesis")).

These findings reveal a new opportunity to improve the performance of training.
The aspiration behind the lottery ticket hypothesis is to find small, trainable subnetworks before any training has occurred.
Insofar as IMP reflects the extent of our knowledge about the existence of equally-capable subnetworks early in training,
our findings suggest that—for deeper networks—the best opportunity to prune is a small number of iterations into training rather than at initialization.
Doing so would exploit the rapid improvements in subnetwork stability and accuracy, resulting in subnetworks that can match the performance of the original network at far greater levels of sparsity.

## 5 Rewinding on Deep Networks for ImageNet

|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| Network | Params | Eps. | Batch | Top-1 Accuracy | Learning Schedule | Sparsity |
| Resnet-50 | 25.5M | 90 | 1024 | 76.1 $\pm$ 0.1% | rate 0.4; warmup 5 eps.; 10x drop at 30, 60, 80; momentum | 70% |
| Inception-v3 | 27.1M | 171 | 1024 | 78.1 $\pm$ 0.1% | rate 0.03 linearly decayed to 0.005; momentum | 70% |
| Squeezenet | 1.25M | 150 | 1024 | 54.8 $\pm$ 0.6 % | rate 0.66 exponentially decayed to 6.6e-5; rmsprop | 50% |

Figure 6: Networks for experiments on ImageNet with TPUs. Accuracies averaged across five trials.

Rewinding made it possible to find sparse, trainable subnetworks of deeper networks for CIFAR10 without the need to alter the underlying network’s hyperparameters.
In this section, we demonstrate that this strategy serves the same purpose for deeper networks for ImageNet ([Russakovsky
et al., 2015](#bib.bib25)).
Although IMP with $k=0$ does not produce winning tickets, rewinding 4.4%, 3.5%, and 6.6% into training yields subnetworks that are 70%, 70%, and 50% smaller than the Resnet-50 ([He
et al., 2016](#bib.bib9)), Inception-v3 ([Szegedy et al., 2016](#bib.bib27)), and Squeezenet ([Iandola et al., 2016](#bib.bib12)) architectures, respectively, that can complete training without any drop in accuracy.
We trained more than 600 networks using standard implementations for TPUs ([Google, 2018](#bib.bib7)) as described in Figure [6](#S5.F6 "Figure 6 ‣ 5 Rewinding on Deep Networks for ImageNet ‣ Stabilizing the Lottery Ticket Hypothesis").

Figure 7: The effect of the rewinding epoch (x-axis) on data order stability and accuracy.

Figure [7](#S5.F7 "Figure 7 ‣ 5 Rewinding on Deep Networks for ImageNet ‣ Stabilizing the Lottery Ticket Hypothesis") shows the effect of the rewinding iteration on the stability and accuracy at the levels of sparsity from Figure [6](#S5.F6 "Figure 6 ‣ 5 Rewinding on Deep Networks for ImageNet ‣ Stabilizing the Lottery Ticket Hypothesis").
In general, the trends from Section [4](#S4 "4 Accuracy with Rewinding ‣ Stabilizing the Lottery Ticket Hypothesis") remain in effect.
When resetting weights to initialization, IMP subnetworks perform no better than random subnetworks in terms of both stability and accuracy.
As the rewinding iteration increases, a gap in stability emerges.
Accuracy improves alongside stability, reaching the accuracy of the original network at epoch 4 (out of 90) for Resnet-50, 6 (out of 171) for Inception-v3, and 10 (out of 150) for Squeezenet.
In the case of Squeezenet, rewinding too early makes it impossible for the subnetworks to learn at all.

Figure [8](#S5.F8 "Figure 8 ‣ 5 Rewinding on Deep Networks for ImageNet ‣ Stabilizing the Lottery Ticket Hypothesis") illustrates the effect of performing IMP with rewinding across all levels of sparsity.
The blue line shows the result of *one-shot pruning* (pruning all at once after training) at a rewinding iteration just after the aforementioned thresholds.
Resnet-50, Squeezenet, and Inception match the accuracy of the original network when 70%, 50%, and 70% of weights are pruned.
At lower levels of sparsity, these subnetworks slightly outperform the original network.
The weights obtained by rewinding are essential: when randomly reinitialized (dashed blue line) or reset to iteration 0 (orange line), subnetworks lose accuracy when pruned by any amount.

The bottom right plot explores the effect of iterative pruning (training, pruning 20% of weights at a time, rewinding, and repeating) on Resnet-50.
Rewinding to epoch 6 (the green line) makes it possible to find subnetworks that train to match the original accuracy when just 20% of weights remain.
Randomly reinitializing (dashed green line) or resetting to iteration 0 (red line) perform equally poorly, only losing accuracy as they are pruned.

Discussion.
On these deeper networks for a more challenging task, IMP finds no evidence in support of [Frankle and
Carbin](#bib.bib4)’s hypothesis that equally-capable subnetworks exist at initialization.
However, rewinding to within a few epochs of the start of training makes it possible to find subnetworks with these properties.
Stability continues to offer insight into the value of rewinding: as IMP subnetworks become more stable and a stability gap emerges, they reach higher accuracy.
The central conceit of the lottery ticket hypothesis—that we can prune early in training—continues to apply in this setting;
however, the most productive moment at which to do so is later than strictly at initialization.

Figure 8: Rewinding to iterations early in training produces subnetworks that outperform the original networks, even when resetting to iteration 0 does not.

## 6 Limitations

Like [Frankle and
Carbin](#bib.bib4)’s work, we focus only on image classification.
While we extend their work to include ImageNet, the revised IMP must still train a network one or more times to identify a subnetwork;
we do not propose an efficient way to find these subnetworks at the rewinding iteration.
Our core pruning technique is still
unstructured, magnitude pruning (among many other pruning
techniques, e.g., [Hu
et al. (2016)](#bib.bib11); [Srinivas and Babu (2015)](#bib.bib26); [Dong
et al. (2017)](#bib.bib3); [Li
et al. (2016)](#bib.bib15); [Luo et al. (2017)](#bib.bib18); [He et al. (2017)](#bib.bib10)).
Unstructured pruning does not necessarily yield networks
that execute more quickly with commodity hardware or libraries; we aim to convey insight on neural
network behavior rather than suggest immediate opportunities to improve performance.

## 7 Discussion

Stability.
Stability to pruning measures a subnetwork’s ability to train in isolation to final weights that are close to the values they would have reached had they been trained as part of the original network.
If we consider the trained weights of the original network to be an ideal destination for optimization, then this metric captures a subnetwork’s ability to approach this point with fewer parameters.
We conjecture that, by arriving at a similar destination, these subnetworks also reach similar accuracy, potentially explaining why
increased stability to pruning corresponds to increased accuracy.
[Frankle and
Carbin](#bib.bib4)’s winning tickets are substantially more stable to pruning than random subnetworks, shedding light on a possible mechanism behind the lottery ticket hypothesis.
As a follow-up, one might explore whether subnetworks that are more stable to pruning are also more likely to reach the same basin of attraction as the original network ([Nagarajan and
Kolter, 2019](#bib.bib23)).

We find a similar relationship between stability to data order and accuracy.
Stability to data order measures a subnetwork’s ability to reach similar final weights in spite of training with different mini-batch sequences—the gradient noise intrinsic to SGD.
This metric is valuable because it provides a way to measure subnetwork stability without reference to the original network.
We believe that stability to pruning and data order work hand-in-hand: subnetworks that are robust to data order are better able to reach destinations consistent with the original network in the face of SGD noise.

Pruning early.
We aim to characterize the opportunity to prune early in training.
Doing so could make it possible to reduce the cost of training networks by substantially reducing parameter-counts for most or all of training.
This is an active area of research in its own right, including pruning before training ([Lee
et al., 2019](#bib.bib14)), pruning throughout training ([Zhu and Gupta, 2017](#bib.bib28); [Gale
et al., 2019](#bib.bib6); [Lym et al., 2019](#bib.bib19); [Molchanov
et al., 2017](#bib.bib21); [Louizos
et al., 2018](#bib.bib17); [Narang
et al., 2017](#bib.bib24)), and maintaining a sparse network with dynamic structure ([Bellec
et al., 2018](#bib.bib2); [Mostafa and Wang, 2018](#bib.bib22); [Mocanu et al., 2018](#bib.bib20)).
However, to the best of our knowledge, our work is the first to show that it is possible to prune (1) so early in training (2) to such extreme levels of sparsity (3) on such large-scale tasks.

Specifically, we find that, for many networks, there is an iteration early in training after which pruning can result in subnetworks with far higher accuracy than when pruning at initialization.
Our results with IMP expand the range of known opportunities to prune early in training that—if exploited—could reduce the cost of training.
With better techniques, we expect this range could be expanded even further because our results are restricted by IMP’s limitations. Namely,
it is possible that there are equally-capable subnetworks present at initialization, but IMP is unable to find them.

Stability offers a new perspective for developing new early pruning methods.
One could exploit stability information for pruning, or develop new techniques to maintain stability under pruning.
Under our hypothesized connection between stability and accuracy, such methods could make it possible to find accurate subnetworks early in training.

## 8 Conclusion

The lottery ticket hypothesis hints at future techniques that
identify small, trainable subnetworks capable of matching the accuracy of the larger networks we typically train.
To date, this and other related research have focused on
compressing neural networks before training.
In this work, we
find that other moments early in the training process may present better opportunities for this class of techniques.
In doing so, we shed new light on the lottery ticket hypothesis and its manifestation in deeper networks through the lens of stability.

## Appendix A Comparison to “Rethinking the Value of Pruning” and “SNIP”

In this appendix, we compare the performance of subnetworks found by “The Lottery Ticket Hypothesis” ([Frankle and
Carbin, 2019](#bib.bib4)), “Rethinking the Value of Pruning” ([Liu
et al., 2019](#bib.bib16)), and “SNIP” ([Lee
et al., 2019](#bib.bib14)).
All three papers have different perspectives on the prospect of pruning early in training.

[Frankle and
Carbin](#bib.bib4) argue that sparse, trainable networks exist at initialization time within the networks that we typically train.
They find these networks using IMP ([1](#alg1 "Algorithm 1 ‣ 1 Introduction ‣ Stabilizing the Lottery Ticket Hypothesis") with $k=0$) to find these subnetworks: they train the original network, prune it, and reset each surviving connection’s weight back to its initial value from before training.
They argue that the original initializations are essential for achieving this performance and that randomly reinitializing substantially degrades performance.

[Liu
et al.](#bib.bib16) argue that the sparse networks that result from pruning can be trained from the start and that the original initializations do not matter.
Instead, they find that the networks that result from pruning can be trained with a random initialization to the same performance as the original network.

[Lee
et al.](#bib.bib14) propose a method for pruning early in training called SNIP.
SNIP considers the *sensitivity* of the loss to each weight (based on one mini-batch of data) and removes those weights to which the loss is least sensitive.
Sensitivity is measured by multiplying each weight $w$ by a virtual
parameter $c=1$ and computing $\frac{\partial L}{\partial c}$.
The authors find that SNIP can prune neural networks before they have been trained, and that these networks can be randomly reinitialized without harm to the eventual accuracy.

There are three points of contention between the papers:

1. 1.

   Is the original initialization important? [Frankle and
   Carbin](#bib.bib4) argue that it is essential, but [Liu
   et al.](#bib.bib16) and [Lee
   et al.](#bib.bib14) discard it without any impact on their results.
2. 2.

   At what level of sparsity are the authors measuring? For example, [Liu
   et al.](#bib.bib16) and [Lee
   et al.](#bib.bib14) consider VGG-19 when pruned by up to 95%, while [Frankle and
   Carbin](#bib.bib4) prune by upwards of 99.5%.
3. 3.

   How efficient is the pruning method? [Frankle and
   Carbin](#bib.bib4) must train the same network a dozen or more times, while [Liu
   et al.](#bib.bib16) must train the network once and [Lee
   et al.](#bib.bib14) need to only look at a single mini-batch of data.

Figure 9: The accuracy achieved by VGG19 (left) and Resnet-18 (right) on CIFAR10
when pruned to the specified size using iterative pruning and SNIP. Networks are trained with warmup and
the learning rate hyperparameters used by [Frankle and
Carbin](#bib.bib4).

Figure [9](#A1.F9 "Figure 9 ‣ Appendix A Comparison to “Rethinking the Value of Pruning” and “SNIP” ‣ Stabilizing the Lottery Ticket Hypothesis") compares these three methods on VGG-19 (warmup) and Resnet-18 (warmup) from Figure [2](#S2.F2 "Figure 2 ‣ 2 Stability at Initialization ‣ Stabilizing the Lottery Ticket Hypothesis").
These particular hyperparameters were chosen because IMP does not find winning tickets without warmup, which would render this comparison less informative.
The plots include the accuracy of randomly reinitialized winning tickets (orange), winning tickets with the original initialization (blue), and subnetworks found by SNIP (green).
The results for VGG19 (left) support the findings of [Liu
et al.](#bib.bib16)
that pruned, randomly reinitialized networks
can match the accuracy of the original network: VGG19 can do so when pruned by up to 80%.
However, beyond this point, the accuracy of the randomly
reinitialized networks declines steadily. In contrast, winning tickets with the original initialization match
the accuracy of the original network when pruned by up to 99%. For Resnet-18 (right), which has 75x
fewer parameters, the randomly reinitialized networks lose accuracy much sooner.

SNIP results in a promising improvement over random reinitialization on VGG19, however there is still a performance
gap between SNIP and the winning tickets—an opportunity to further improve the performance of pruning before training.

We return to our original three questions:
Up to a certain level of sparsity, the original initialization is not important. Subnetworks that are randomly reinitialized can still train to full accuracy. Beyond this point, however, the original initialization is necessary in order to maintain high accuracy. [Liu
et al.](#bib.bib16) and [Lee
et al.](#bib.bib14) operate in this first regime, where initialization is less important; [Frankle and
Carbin](#bib.bib4) operate in the second regime.
However, finding networks that learn effectively at these extreme levels of sparsity is very expensive: [Frankle and
Carbin](#bib.bib4) must train the same network many times in order to do so.
[Lee
et al.](#bib.bib14) offer a promising direction for efficiently finding such subnetworks, taking a step toward realizing the opportunity described by [Frankle and
Carbin](#bib.bib4) and this paper.

## Appendix B Angle Measurements (Stability)

|  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Network | Sparsity | Data Order Stability (Angle) | | | Pruning Stability (Angle) | | | Accuracy | |
|  |  | IMP | Random | Comp | IMP | Random | Comp | IMP | Random |
| Lenet | 10.7% | 22.7 $\pm$ 0.5$\degree$ | 49.2 $\pm$ 3.0$\degree$ | 2.2x | 53.1 $\pm$ 0.8$\degree$ | 83.6 $\pm$ 1.1$\degree$ | 1.6x | 98.3 $\pm$ 0.1 | 97.5 $\pm$ 0.3 |
| Resnet-18 (standard) |  | 87.7 $\pm$ 1.2$\degree$ | 88.0 $\pm$ 1.4$\degree$ | 1.0x | 87.7 $\pm$ 1.2 $\degree$ | 88.0 $\pm$ 1.4$\degree$ | 1.0x | 87.7 $\pm$ 0.4 | 87.7 $\pm$ 0.5 |
| Resnet-18 (low) | 16.7% | 16.1 $\pm$ 2.7$\degree$ | 75.8 $\pm$ 1.2$\degree$ | 4.7x | 50.4 $\pm$ 4.8$\degree$ | 77.1 $\pm$ 0.4$\degree$ | 1.5x | 89.1 $\pm$ 0.4 | 86.1 $\pm$ 0.6 |
| Resnet-18 (warmup) |  | 17.0 $\pm$ 0.2$\degree$ | 69.0 $\pm$ 3.8$\degree$ | 4.7x | 49.9 $\pm$ 2.3$\degree$ | 79.0 $\pm$ 0.5$\degree$ | 1.6x | 90.3 $\pm$ 0.4 | 86.8 $\pm$ 0.5 |
| VGG-19 (standard) |  | 88.5 $\pm$ 0.4$\degree$ | 88.3 $\pm$ 0.5$\degree$ | 1.0x | 87.8 $\pm$ 0.2$\degree$ | 88.1 $\pm$ 0.2$\degree$ | 1.0x | 90.0 $\pm$ 0.3 | 90.2 $\pm$ 0.5 |
| VGG-19 (low) | 2.2% | 39.9 $\pm$ 2.1$\degree$ | 84.9 $\pm$ 0.6$\degree$ | 2.1x | 54.0 $\pm$ 0.4$\degree$ | 79.0 $\pm$ 0.2$\degree$ | 1.5x | 91.0 $\pm$ 0.3 | 88.0 $\pm$ 0.3 |
| VGG-19 (warmup) |  | 39.9 $\pm$ 2.1$\degree$ | 84.6 $\pm$ 0.4$\degree$ | 2.1x | 71.7 $\pm$ 0.3$\degree$ | 84.8 $\pm$ 0.2$\degree$ | 1.2x | 92.4 $\pm$ 0.2 | 90.3 $\pm$ 0.3 |

Figure 10: The average stability (as measured in angle) of subnetworks obtained by IMP and by randomly pruning. Errors are the minimum or maximum across 18 samples (data order) and 3 samples (pruning and accuracy).

Figure 11: The effect of the rewinding iteration (x-axis) on angle data order stability (top), angle pruning stability (middle), and accuracy (bottom) for each network in Figure [2](#S2.F2 "Figure 2 ‣ 2 Stability at Initialization ‣ Stabilizing the Lottery Ticket Hypothesis"). This figure accompanies Figure [4](#S3.F4 "Figure 4 ‣ 3 Stability with Rewinding ‣ Stabilizing the Lottery Ticket Hypothesis").

Figure 12: The effect of the rewinding epoch (x-axis) on data order stability (top), pruning stability (middle), and accuracy (bottom) for each network in Figure [6](#S5.F6 "Figure 6 ‣ 5 Rewinding on Deep Networks for ImageNet ‣ Stabilizing the Lottery Ticket Hypothesis").

This appendix accompanies Figures [3](#S2.F3 "Figure 3 ‣ 2 Stability at Initialization ‣ Stabilizing the Lottery Ticket Hypothesis") and [4](#S3.F4 "Figure 4 ‣ 3 Stability with Rewinding ‣ Stabilizing the Lottery Ticket Hypothesis"), which measure the stability of the networks in Figure [2](#S2.F2 "Figure 2 ‣ 2 Stability at Initialization ‣ Stabilizing the Lottery Ticket Hypothesis").
The aforementioned figures measure stability only in terms of distance.
This appendix includes the accompanying measurements of angle.
Figure [10](#A2.F10 "Figure 10 ‣ Appendix B Angle Measurements (Stability) ‣ Stabilizing the Lottery Ticket Hypothesis") includes angle data when resetting at iteration 0 to accompany Figure [3](#S2.F3 "Figure 3 ‣ 2 Stability at Initialization ‣ Stabilizing the Lottery Ticket Hypothesis").
Figure [11](#A2.F11 "Figure 11 ‣ Appendix B Angle Measurements (Stability) ‣ Stabilizing the Lottery Ticket Hypothesis") includes the angle measurements of stability to data order (top) and pruning (middle) when networks are rewound to various iterations; it accompanies Figure [4](#S3.F4 "Figure 4 ‣ 3 Stability with Rewinding ‣ Stabilizing the Lottery Ticket Hypothesis").
Figure [12](#A2.F12 "Figure 12 ‣ Appendix B Angle Measurements (Stability) ‣ Stabilizing the Lottery Ticket Hypothesis") includes angle measurements for the ImageNet networks from Section [5](#S5 "5 Rewinding on Deep Networks for ImageNet ‣ Stabilizing the Lottery Ticket Hypothesis") to accompany Figure [7](#S5.F7 "Figure 7 ‣ 5 Rewinding on Deep Networks for ImageNet ‣ Stabilizing the Lottery Ticket Hypothesis").
