<!-- fulltext source=arxiv_html slug=arXiv-2011.04006 fetched=2026-09-16T11:52:37+00:00 -->

# Long Range Arena: A Benchmark for Efficient Transformers

Yi Tay
††thanks: First two authors contributed equally.
Affiliation: Google Research
Email: [yitay@google.com](mailto:yitay@google.com)
  
Mostafa Dehghani
Email: [dehghani@google.com](mailto:dehghani@google.com)
  
Samira Abnar
Affiliation: Google Research
  
Yikang Shen
Affiliation: Google Research
  
Dara Bahri
Affiliation: Google Research
  
Philip Pham
Affiliation: Google Research
  
Jinfeng Rao
Affiliation: Google Research
  
Liu Yang
Affiliation: Google Research
  
Sebastian Ruder
Affiliation: Google DeepMind
  
Donald Metzler
Affiliation: Google Research

###### Abstract

Transformers do not scale very well to long sequence lengths largely because of quadratic self-attention complexity. In the recent months, a wide spectrum of efficient, fast Transformers have been proposed to tackle this problem, more often than not claiming superior or comparable model quality to vanilla Transformer models. To this date, there is no well-established consensus on how to evaluate this class of models. Moreover, inconsistent benchmarking on a wide spectrum of tasks and datasets makes it difficult to assess relative model quality amongst many models. This paper proposes a systematic and unified benchmark, *Long-Range Arena* , specifically focused on evaluating model quality under long-context scenarios. Our benchmark is a suite of tasks consisting of sequences ranging from $1K$ to $16K$ tokens, encompassing a wide range of data types and modalities such as text, natural, synthetic images, and mathematical expressions requiring similarity, structural, and visual-spatial reasoning. We systematically evaluate ten well-established long-range Transformer models (Reformers, Linformers, Linear Transformers, Sinkhorn Transformers, Performers, Synthesizers, Sparse Transformers, and Longformers) on our newly proposed benchmark suite. Long-Range Arena paves the way towards better understanding this class of efficient Transformer models, facilitates more research in this direction, and presents new challenging tasks to tackle. Our benchmark code will be released at <https://github.com/google-research/long-range-arena>.

|  |
| --- |
|  |

## 1 Introduction

Transformers ([Vaswani et al., 2017](#bib.bib45)) are ubiquitously state-of-the-art across many modalities, from language ([Devlin et al., 2018](#bib.bib9); [Raffel et al., 2019](#bib.bib36); [Child et al., 2019](#bib.bib4)) to images ([Tan & Bansal, 2019](#bib.bib41); [Lu et al., 2019](#bib.bib28)) to protein sequences ([Rives et al., 2019](#bib.bib37)). A common weakness of Transformers is their quadratic memory complexity within the self-attention mechanism that restricts their potential application to domains requiring longer sequence lengths. To date, a dizzying number of efficient Transformer models (‘xformers’) have been proposed to tackle this problem ([Liu et al., 2018](#bib.bib27); [Kitaev et al., 2020](#bib.bib21); [Wang et al., 2020](#bib.bib46); [Tay et al., 2020b](#bib.bib43); [Katharopoulos et al., 2020](#bib.bib18)). Many of these models demonstrate comparable performance to the vanilla Transformer model while successfully reducing the memory complexity of the self-attention mechanism. An overview of this research area can be found in ([Tay et al., 2020c](#bib.bib44)).

Comparing the evaluation and experimental setup of many of these papers, we can make the following observations. Firstly, there is no unifying consensus on what makes an acceptable test bed for benchmarking efficient Transformers. There is also a large diversity in the types of tasks adopted—every single model is evaluated on a different set of tasks and datasets, which makes comparison of different models as well as an assessment of their relative strengths and weaknesses difficult. Secondly, the benchmarks used for evaluation are often arbitrarily chosen, without much consideration to whether the task is suitable for evaluating long-range modeling. Thirdly, many papers tend to conflate the effectiveness of the inductive bias with the benefits of pretraining ([Ainslie et al., 2020](#bib.bib2); [Zaheer et al., 2020](#bib.bib51); [Wang et al., 2020](#bib.bib46)), which tends to obfuscate the true value of the architecture. Pretraining itself is a computationally expensive endeavour and de-coupling inductive bias research from pretraining would make xformer research more accessible.

In this paper, we propose a new benchmark, Long-Range Arena (LRA), for the purpose of benchmarking sequence models under the long-context scenario. We design a benchmark suite comprised of both synthetic probing tasks and real-world tasks and provide relative comparisons for ten recently proposed efficient Transformer models including Sparse Transformers ([Child et al., 2019](#bib.bib4)), Reformer ([Kitaev et al., 2020](#bib.bib21)), Linformer ([Wang et al., 2020](#bib.bib46)), Longformer ([Beltagy et al., 2020](#bib.bib3)), Sinkhorn Transformers ([Tay et al., 2020b](#bib.bib43)), Performers ([Choromanski et al., 2020b](#bib.bib6)), Synthesizers ([Tay et al., 2020a](#bib.bib42)), Linear Transformers ([Katharopoulos et al., 2020](#bib.bib18)), and BigBird ([Zaheer et al., 2020](#bib.bib51)). This is the most comprehensive and extensives side-by-side evaluation of this class of models.

While the focus of this benchmark is the ability of these architectures to reason in long-context scenarios, we are also fundamentally interested in understanding the capabilities and properties of these xformer architectures when exposed to different types of data and conditions. Hence, our benchmark is purposefully designed to be capability probing, i.e, we select datasets and tasks with certain innate structure. For example, can these architectures model long sequences that are intrinsically hierarchical or that contain some form of spatial structure? In general, we are especially interested in the relative performance of these xformer models across diverse circumstances. We hope that understanding these better will inspire research on more efficient architectures in the future. While the focus of this paper is on efficient Transformer models, our benchmark is also model agnostic and can also serve as a benchmark for long-range sequence modeling.

Aside from comparing the quality of these models, we also conduct extensive efficiency and memory usage analysis of these models. We believe such a side-by-side performance benchmark will be valuable to the community, providing deeper insight on the practical efficiency of these methods. Overall, we propose a unified framework for enabling easy side-by-side comparisons of efficient Transformer models and broadly speaking, long-range sequence models in general. Our framework, which we open source, is written in JAX/FLAX11
1
<https://github.com/google/flax>.

## 2 Long-Range Arena (LRA)

This section introduces the Long-Range Arena (LRA) benchmark (pronounced el-ra). We implement our benchmark (which includes the task, evaluators, and models) in Python 3 and Jax/Flax and open-source our code22
2
<https://github.com/google-research/long-range-arena>—making it easy to extend and to build on top of our work.

### 2.1 Desiderata

For creating the Long-Range Arena benchmark, we established a set of desiderata:

1. 1.

   Generality: All efficient Transformers models should be applicable to our tasks. For instance, given that not all xformer models are able to perform autoregressive decoding ([Wang et al., 2020](#bib.bib46)), we include tasks that only require encoding.
2. 2.

   Simplicity: The tasks should have a simple setup. All factors that make comparisons difficult should be removed. This encourages simple models instead of cumbersome pipelined approaches. For instance, we avoid including any particular data augmentation and consider pretraining to be out of scope of this benchmark.
3. 3.

   Challenging: The tasks should be difficult enough for current models to ensure there is room for improvement to encourage future research in this direction.
4. 4.

   Long inputs: The input sequence lengths should be reasonably long since assessing how different models capture long-range dependencies is a core focus of LRA.
5. 5.

   Probing diverse aspects: The set of tasks should assess different capabilities of models like their ability to model relations and hierarchical/spatial structures, generalization capability, etc.
6. 6.

   Non-resource intensive and accessible: The benchmarks should be deliberately designed to be lightweight so as to be accessible to researchers without industry-grade computing resources.

### 2.2 Tasks

This section describes the tasks in the LRA benchmark. Note that these tasks are specifically designed for the purpose of assessing different aspects of efficient Transformer models. Further details about each task can be found in the appendix.

#### 2.2.1 Long ListOps

In this task, we are interested in the capability of modeling hierarchically structured data in a long-context scenario. This benchmark task is a longer variation of the standard ListOps task proposed in ([Nangia & Bowman, 2018](#bib.bib30)), which was designed to investigate the parsing ability of neural models.

The dataset is comprised of sequences with a hierarchical structure and operators max, mean, median and sum\_mod that are enclosed by delimiters (brackets). An example (much shorter) sequence is as follows:

INPUT: [MAX 4 3 [MIN 2 3 ] 1 0 [MEDIAN 1 5 8 9, 2]]
      OUTPUT: 5

In our task we use a version of ListOps of sequence lengths of up to $2K$ to test the ability to reason hierarchically while handling long contexts. Naturally, in the above example the model needs to access all tokens and model the logical structure of the inputs in order to make a prediction. The task is a ten-way classification task and is considerably challenging.

#### 2.2.2 Byte-level Text Classification

This task using real-world data represents a common use case of efficient Transformers, which are often needed to process long documents. Text classification in particular is associated with many real-world applications such as spam, fraud, and bot detection and commercial document classification, among others ([Howard & Ruder, 2018](#bib.bib15)).

This task also benchmarks the ability of the models to deal with compositionality as it is required to compose characters into words into higher-level phrases. Compared to ListOps, boundaries are less well defined and need to be learned from the data, which is a challenging problem in its own right ([Kawakami et al., 2019](#bib.bib19)).

We consider the byte/character-level setup of this task in order to simulate a longer input sequence, which also makes the task considerably more challenging.33
3
On the IMDb word-level task, models without pre-training achieve accuracies in the high 80s while the same models score in the mid 60s on the character-level task ([Tay et al., 2020b](#bib.bib43)). Note that this setup differs significantly from character-level language modeling (char LM). In char LM, it would suffice to read nearby context to determine the next character, e.g., a model is very likely to predict ‘e’ after having seen the prefix ‘appl’. For byte-level text classification, the model needs to reason with compositional, unsegmented data in order to solve a meaningful real-world task. We use the IMDb reviews ([Maas et al., 2011](#bib.bib29)) dataset, which is a commonly used dataset to benchmark document classification. We use a fixed max length of $4K$ for this task, which is truncated or padded when necessary. This is a binary classification task with accuracy as the metric.

#### 2.2.3 Byte-level Document Retrieval

We further evaluate a model’s ability to encode and store compressed representations that are useful for matching and retrieval. Learning the similarity score between two vectors is a common problem in machine learning and is useful for a wide array of applications ([Guo et al., 2016](#bib.bib10)).

Hence, this task is mainly about modeling a similarity score between two documents in a ‘two tower setup’ in which compressed representations are concatenated and passed into a linear classifier. Note that we deliberately prevent models from using cross attention. This task thus serves as a test of how well models are able to compress long sequences into representations suitable for similarity-based matching.

We use the ACL Anthology Network ([Radev et al., 2013](#bib.bib33), AAN;) dataset, which identifies if two papers have a citation link, a common setup used in long-form document matching ([Jiang et al., 2019](#bib.bib16); [Yang et al., 2020](#bib.bib49)).

Similar to the text classification setup, we use a byte/character level setup, which challenges the model to compose and aggregate information over longer contexts. We use a sequence length of $4K$ for each document, which makes the total text length $8K$ for this task. This is a binary classification task with accuracy as the metric.

#### 2.2.4 Image Classification on sequences of pixels

This task is an image classification task, where the inputs are sequences of pixels. In other words, an $N\times N$ image is flattened to a sequence of length $N^{2}$ pixels.

Similar to how the previous tasks require capturing the hierarchical structure in the data, this task requires the model to learn the 2D spatial relations between input pixels, while presented as a 1D sequence of symbols.

We focus on assessing Transformer models that are designed to process a sequence of discrete symbols, so we do not allow extra modules such as a CNN stem that embeds pixel-level inputs. To simplify the setup, we map the input images to a single gray-scale channel where each pixel is represented with an 8-bit pixel intensity (vocabulary size of 256). In LRA, we use the CIFAR-10 dataset ([Krizhevsky, 2009](#bib.bib23)) for the image classification task.

#### 2.2.5 Pathfinder (Long-Range Spatial Dependency)

(a) A positive example.

(b) A negative example.

Figure 1: Samples of the Pathfinder task.

The Pathfinder challenge ([Linsley et al., 2018](#bib.bib26); [Kim\* et al., 2020](#bib.bib20)) was first introduced for learning long-range spatial dependencies. It is a synthetic visual task motivated by cognitive psychology ([Houtkamp & Roelfsema, 2010](#bib.bib14)).

The task requires a model to make a binary decision whether two points represented as circles are connected by a path consisting of dashes. We show a positive example of two connected points and a negative example of two unconnected points in Figure [1](#S2.F1 "Figure 1 ‣ 2.2.5 Pathfinder (Long-Range Spatial Dependency) ‣ 2.2 Tasks ‣ 2 Long-Range Arena (LRA) ‣ Long Range Arena: A Benchmark for Efficient Transformers"). The dataset also contains distractor paths, which makes this setup challenging. We model this task by treating images as sequences of pixels. In this task, images are of dimensions ($32\times 32)$, which make up a sequence length of $1024$.

#### 2.2.6 Pathfinder-X (Long-Range Spatial Dependencies with Extreme Lengths)

Finally, we consider an extreme version of Pathfinder (Pathfinder-X) where examples consist of $16K$ pixels (i.e., images of $128\times 128$).

The key goal here is to observe if a model would fail to solve the $16K$ extreme version even if it can successfully learn the standard version of $1024$ tokens. This is an interesting litmus test to see if the same algorithmic challenges bear a different extent of difficulty when sequence lengths are much longer. We include this in our benchmark as Path-X.

### 2.3 Required Attention Span of LRA tasks

One of the main goals of the LRA benchmark is assessing the ability of different efficient Transformer models to capture long-range dependencies. The tasks and setups are designed with this goal in mind. In order to have a quantitative estimate of the spatial extent needed to be considered by an attention mechanism to encode the inputs, we define *required attention span*.

Given a trained attention-based model and a sequence of tokens as inputs, the required attention span of an attention module is computed as the mean distance between the query token and the attended tokens, scaled by attention weights. Here, we compute the mean *required attention span* over all attention modules in our best vanilla Transformer model for each task, averaged over 1K random samples from the validation set.

Figure 2: Required attention span on different tasks.

Figure [2](#S2.F2 "Figure 2 ‣ 2.3 Required Attention Span of LRA tasks ‣ 2 Long-Range Arena (LRA) ‣ Long Range Arena: A Benchmark for Efficient Transformers") summarizes the required attention span for each task in LRA.
For all the tasks in LRA the required attention span is rather high. This shows, a Transformer model needs to go beyond combining only local information, while in many other tasks and datasets, attention mechanism mostly need to combine information from neighboring positions.

Given the purpose of LRA, we found *required attention span* serves as a good proxy for how difficult a task is for Transformer-based models.44
4
Note that this metric mainly provides an indication of the required attention span for a task and the relative differences between tasks based on a reasonably strong model; a better model might only need to attend to shorter ranges ([Daniluk et al., 2017](#bib.bib8); [Rae & Razavi, 2020](#bib.bib35)).

| Model | ListOps | Text | Retrieval | Image | Pathfinder | Path-X | Avg |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Transformer | 36.37 | 64.27 | 57.46 | 42.44 | 71.40 | FAIL | 54.39 |
| Local Attention | 15.82 | 52.98 | 53.39 | 41.46 | 66.63 | FAIL | 46.06 |
| Sparse Trans. | 17.07 | 63.58 | 59.59 | 44.24 | 71.71 | FAIL | 51.24 |
| Longformer | 35.63 | 62.85 | 56.89 | 42.22 | 69.71 | FAIL | 53.46 |
| Linformer | 35.70 | 53.94 | 52.27 | 38.56 | 76.34 | FAIL | 51.36 |
| Reformer | 37.27 | 56.10 | 53.40 | 38.07 | 68.50 | FAIL | 50.67 |
| Sinkhorn Trans. | 33.67 | 61.20 | 53.83 | 41.23 | 67.45 | FAIL | 51.39 |
| Synthesizer | 36.99 | 61.68 | 54.67 | 41.61 | 69.45 | FAIL | 52.88 |
| BigBird | 36.05 | 64.02 | 59.29 | 40.83 | 74.87 | FAIL | 55.01 |
| Linear Trans. | 16.13 | 65.90 | 53.09 | 42.34 | 75.30 | FAIL | 50.55 |
| Performer | 18.01 | 65.40 | 53.82 | 42.77 | 77.05 | FAIL | 51.41 |
| Task Avg (Std) | 29 (9.7) | 61 (4.6) | 55 (2.6) | 41 (1.8) | 72 (3.7) | FAIL | 52 (2.4) |

Table 1: Experimental results on Long-Range Arena benchmark. Best model is in boldface and second best is underlined. All models do not learn anything on Path-X task, contrary to the Pathfinder task and this is denoted by FAIL. This shows that increasing the sequence length can cause seriously difficulties for model training. We leave Path-X on this benchmark for future challengers but do not include it on the Average score as it has no impact on relative performance.

## 3 Experimental Results

### 3.1 Models

This section describes the models we evaluate on our LRA benchmark. We base our evaluation on ten recently proposed efficient Transformer models. Aside from the standard vanilla Transformer ([Vaswani et al., 2017](#bib.bib45)) and a simple local attention baseline, we compare Sparse Transformers ([Child et al., 2019](#bib.bib4)), Longformers ([Beltagy et al., 2020](#bib.bib3)), Linformers ([Wang et al., 2020](#bib.bib46)), Reformers ([Kitaev et al., 2020](#bib.bib21)), Sinkhorn Transformers ([Tay et al., 2020b](#bib.bib43)), Synthesizers ([Tay et al., 2020a](#bib.bib42)), BigBird ([Zaheer et al., 2020](#bib.bib51)), Linear Transformers ([Katharopoulos et al., 2020](#bib.bib18)), and Performers ([Choromanski et al., 2020a](#bib.bib5)).

We believe these ten models to represent a diverse cross-section of recent efficient Transformer models.

### 3.2 Philosophy behind the benchmark

We note that it is non-trivial and almost impossible to conduct a perfectly fair evaluation of all models. The large search space motivates us to follow a set of fixed hyperparameters (number of layers, heads, embedding dimensions, etc.) for all models. The best performance and relative order of the models may change if we aggressively tune hyperparameters for all models. Hence, the results provided in this paper are not meant to be a final authoritative document on which xformer is the best. Instead, we provide a starting point for future research and strive to be as fair as possible. In order to do so, we plan to release the code with all the hyperparameters and implementation details. Additionally, we intend for our paper to be a living document and encourage researchers (authors and the broader community) to contribute and continue updating this paper (with rules and limitations described in the appendix). We also implemented all models to the best of our abilities. We often consulted with the original developers of the included models.

### 3.3 Quantitative Results

Based on our results, we observe that (1) all proposed tasks in LRA are considerably challenging and (2) there are meaningful differences in model performance across different xformer models.

##### Results on ListOps

The ListOps task (10-way classification) has proven to be reasonably difficult with the best models obtaining only $37\%$. The considerable gap to random chance shows that models are indeed learning the task. We notice that the inductive bias of the xformer model plays a substantial role on this task in which approximately half the xformer models are able to get $>30\%$ performance while the remainder of the models only get slightly above random chance. This may imply that certain efficiency-inspired inductive biases may be better at handling hierarchical data than others. For instance, the results from our experiments seem to suggest that kernel-based models (e.g., Performer, Linear Transformers) are possibly not as effective on hierarchically structured data.

##### Results on Text Classification

Byte-level classification is shown to be difficult and challenging especially when no pretraining or contextual embeddings are used. The best model only obtains $65.90$ accuracy. The Linear Transformer performs well on this task, along with the Performer model. Contrary to the ListOps task, it seems like fast kernel-based models do well on this task.

##### Results on Retrieval

The scores of different models on this task are also rather low (average of $55\%$), indicating the difficulty of the task. The vanilla Transformer model only achieves $57.46\%$ accuracy with some xformer variants scoring very close to random chance. The best performing model is the Sparse Transformer and the second best is BigBird. We find that models that follow fixed sparse patterns to do well on this task. Models that are based on low-rank factorization and kernels perform relatively worse.

##### Results on Image Classification

On the image classification task, most models perform quite similarly (low variance amongst model performance). The best model on this task is the Sparse Transformer, followed by the Performer. Linformer and Reformers do not do well on this task. On a related note, we also observed most of models struggle generalizing to the test even though they manage to overfit the training set. While we extensively tried different regularization techniques on every single model, there is a rather large gap between their performance on train and test set (More details in Appendix).

##### Results on Pathfinder / Path-X

Results show that all models achieve reasonable performance on the Pathfinder task. The average performance is $72$ and the best model Performer obtains $77.05\%$ accuracy. The Local Attention model performs the worse out of all models.

All models failed to solve the Path-X task, achieving at best $50\%$. We find this intriguing because this is essentially an identical task to the standard Pathfinder, albeit with much longer sequence lengths. Hence, we observe that the extreme length of the task can significantly obstruct a model from leaning anything meaningful. We leave Path-X in our benchmark suite, hoping to spur future progress in modeling sequences at extreme lengths.

### 3.4 Efficiency Benchmarks

In this section, we report efficiency metrics of our runs. For simplicity, we use the byte-level text classification benchmark and report run times and memory consumption of the sequence lengths $\{1K,2K,3K,4K\}$. We use a batch size of $32$ for all runs and conduct experiments on 4x4 TPU V3 Chips. We emphasize that this is again largely conditioned on hardware and implementation details (more details can be found in the appendix).

|  | Steps per second | | | | Peak Memory Usage (GB) | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Model | 1K | 2K | 3K | 4K | 1K | 2K | 3K | 4K |
| Transformer | 8.1 | 4.9 | 2.3 | 1.4 | 0.85 | 2.65 | 5.51 | 9.48 |
| Local Attention | 9.2 ($1.1$x) | 8.4 ($1.7$x) | 7.4 ($3.2$x) | 7.4 ($5.3$x) | 0.42 | 0.76 | 1.06 | 1.37 |
| Linformer | 9.3 ($1.2$x) | 9.1 ($1.9$x) | 8.5 ($3.7$x) | 7.7 ($5.5$x) | 0.37 | 0.55 | 0.99 | 0.99 |
| Reformer | 4.4 ($0.5$x) | 2.2 ($0.4$x) | 1.5 ($0.7$x) | 1.1 ($0.8$x) | 0.48 | 0.99 | 1.53 | 2.28 |
| Sinkhorn Trans | 9.1 ($1.1$x) | 7.9 ($1.6$x) | 6.6 ($2.9$x) | 5.3 ($3.8$x) | 0.47 | 0.83 | 1.13 | 1.48 |
| Synthesizer | 8.7 ($1.1$x) | 5.7 ($1.2$x) | 6.6 ($2.9$x) | 1.9 ($1.4$x) | 0.65 | 1.98 | 4.09 | 6.99 |
| BigBird | 7.4 ($0.9$x) | 3.9 ($0.8$x) | 2.7 ($1.2$x) | 1.5 ($1.1$x) | 0.77 | 1.49 | 2.18 | 2.88 |
| Linear Trans. | 9.1 ($1.1$x) | 9.3 ($1.9$x) | 8.6 ($3.7$x) | 7.8 ($5.6$x) | 0.37 | 0.57 | 0.80 | 1.03 |
| Performer | 9.5 ($1.2$x) | 9.4 ($1.9$x) | 8.7 ($3.8$x) | 8.0 ($5.7$x) | 0.37 | 0.59 | 0.82 | 1.06 |

Table 2: Benchmark results of all Xformer models with a consistent batch size of $32$ across all models. We report relative speed increase/decrease in comparison with the vanilla Transformer in brackets besides the steps per second. Memory usage refers to per device memory usage across each TPU device. Benchmarks are run on 4x4 TPU V3 Chips.

##### Results on Speed

Table [2](#S3.T2 "Table 2 ‣ 3.4 Efficiency Benchmarks ‣ 3 Experimental Results ‣ Long Range Arena: A Benchmark for Efficient Transformers") reports our efficiency benchmarks on the xformer models. We note that low-rank and kernel-based models are generally the fastest. The overall fastest model is the Performer model ([Choromanski et al., 2020a](#bib.bib5)), which is 5.7$\times$ faster than Transformers on the $4k$ sequence length. Linformer ([Wang et al., 2020](#bib.bib46)) and Linear Transformers ([Katharopoulos et al., 2020](#bib.bib18)) come in a close second and are almost as fast as Performers (at 5.5 to 5.6$\times$ faster). Based on our implementation, the slowest model is the Reformer model ([Kitaev et al., 2020](#bib.bib21)) that is about $80\%$ the speed of vanilla Transformer at $4K$ sequence lengths and half the speed at $1K$ sequence length.

##### Results on Memory Consumption

The model with the smallest memory footprint in our benchmarks is the Linformer model, coming in at 0.99GB per TPU device as compared to 9.48GB per TPU device for the vanilla Transformers at $N=4K$. That is about a $10$x reduction in memory footprint. Similar to speed, Performers and Linear Transformers are also relatively compact and are almost as compact as Linformers. Other models (Local Attention, Reformers, BigBird, Synthesizers) are still less memory hungry compared to vanilla Transformers but are relatively less efficient (memory consumption wise) compared to Linformers, Performers, and Linear Transformers. We also notice that the memory consumption of models such as Linformer and Performer scales very well, with the memory usgae at $3K$ and $4K$ being approximately equal.

### 3.5 Overall Results: No One-size-fits-all

Based on our analysis, the best qualitative performance in terms of LRA score, i.e. integrated across all five tasks, is the BigBird model. While BigBird does not do extremely well on any individual task compared to other models, it has consistently good performance across all tasks. Performers and Linear Transformers have strong performance on some tasks but their average is lowered by the ListOps task.
Figure [3](#S3.F3 "Figure 3 ‣ 3.5 Overall Results: No One-size-fits-all ‣ 3 Experimental Results ‣ Long Range Arena: A Benchmark for Efficient Transformers") shows the trade-off between qualitative performance, model speed, and memory footprint.
While BigBird performs well, its speed is almost similar to the vanilla Transformer. On the other hand, a model like Local Attention is fast at the cost of lower quantitative performance.
Among these models, the kernel-based variants, i.e., Performer, Linformer, and linear Transformer seem to be able to make a better trade-off in terms of speed and performance, while having reasonable memory usage.

Figure 3: Performance ($y$ axis), speed ($x$ axis), and memory footprint (size of the circles) of different models.

## 4 Related Work

### 4.1 Efficient Transformers

The pervasiveness of Transformer models, along with its well-known trait of being memory intensive, has spurred on a large number of innovations on this front. Early work in this area has typically considered a fixed pattern (local window) approach ([Liu et al., 2018](#bib.bib27); [Parmar et al., 2018](#bib.bib32)). More advanced models have been proposed recently, including combined patterns ([Child et al., 2019](#bib.bib4); [Ho et al., 2019](#bib.bib12); [Beltagy et al., 2020](#bib.bib3); [Zaheer et al., 2020](#bib.bib51)), learned patterns ([Kitaev et al., 2020](#bib.bib21); [Roy et al., 2020](#bib.bib38)), and recent models based on kernels ([Katharopoulos et al., 2020](#bib.bib18); [Choromanski et al., 2020a](#bib.bib5)) or low-rank approximations ([Wang et al., 2020](#bib.bib46)). For the sake of brevity, we refer interested readers to ([Tay et al., 2020c](#bib.bib44)) for a detailed survey of this line of research.

### 4.2 Existing Benchmarks

##### Generative Modeling / Language Modeling

This generative modeling task requires predicting the next character, word, or pixel and is a staple in xformer evaluations ([Roy et al., 2020](#bib.bib38); [Kitaev et al., 2020](#bib.bib21)). However, it has been debated how much long-range signal such tasks actually encode ([Rae & Razavi, 2020](#bib.bib35)).

LSTM language models augmented with attention have been shown to rarely attend beyond seven preceding words of context ([Daniluk et al., 2017](#bib.bib8)) and samples from LSTM language models are known to quickly devolve into generic text. On the other hand, recent models such as the Transformer-XL ([Dai et al., 2019](#bib.bib7)) have been observed to be sensitive to a context of around 900 tokens and samples from large-scale models ([Radford et al., 2019](#bib.bib34)) maintain a consistent theme over much longer sequences. Even such recent models, however, can be improved by limiting the range of attention ([Rae & Razavi, 2020](#bib.bib35)). In sum, while standard language modelling datasets contain *some* long-range signal, which is required to perform long-range coreference resolution, reasoning with events, discourse understanding, etc. ([Ruder et al., 2019](#bib.bib39)) it seems to be overshadowed by the much stronger signal of short-term word co-occurrences and is thus difficult to evaluate.55
5
Datasets such as LAMBADA ([Paperno et al., 2016](#bib.bib31)) more explicitly test for context understanding but are still restricted to comparatively short contexts of five sentences on average.

##### Question Answering

Another commonly used evaluation task is question answering ([Zaheer et al., 2020](#bib.bib51), QA;). Open-domain QA in particular typically requires the model to answer questions based on long contexts such as entire Wikipedia documents ([Joshi et al., 2017](#bib.bib17); [Kwiatkowski et al., 2019](#bib.bib24)) or even books ([Kočiský et al., 2018](#bib.bib22)). Other datasets are explicitly designed to require multiple ‘hops’ of reasoning ([Welbl et al., 2018](#bib.bib47); [Yang et al., 2018](#bib.bib50)). Successful approaches are often highly engineered, computationally expensive systems that require pre-training and a separate retrieval model ([Lee et al., 2019](#bib.bib25); [Guu et al., 2020](#bib.bib11)).

##### Natural Language Understanding / GLUE tasks

Evaluation on natural language understanding (NLU) tasks is also common ([Wang et al., 2020](#bib.bib46)). Examples in most of these datasets such as MultiNLI ([Williams et al., 2018](#bib.bib48)) and SST ([Socher et al., 2013](#bib.bib40)) consist of single sentences and less than $100$ tokens on average.

## 5 Conclusion

We proposed Long Range Arena (LRA), a new benchmark for evaluating progress on efficient Transformer research. Our new benchmark is challenging and probes at model capabilities in dealing with diverse data types and structures such as text, mathematics, and visual data. Our benchmark comprises of tasks ranging from $1K$ to $16K$ tokens. For the first time, we conduct an extensive side-by-side comparison of ten recently proposed efficient Transformer models. The experimental results show that these tasks are very challenging even for long-range Transformer models. The overall results show that there is no one-size-fits-all solution and trade-offs have to be made in terms of model quality and speed/memory. We plan to open source our code and benchmarks to facilitate future benchmarking, research and model development.

## 6 Acknowledgements

We would like to thank the following colleagues: Krzysztof Choromanski, Richard Song, Tamas Sarlos for recommendations on Performer setups. David Dohan and Manzil Zaheer for help on the BigBird implementation. Anselm Levskaya for some useful reference code for Reformers. Orhan Firat for helpful pointers. Jiaxi Tang, Jai Gupta, Zhen Qin, Che Zheng, Zhe Zhao, Da-Cheng Juan, Thomas Unterthiner, Marc Najork, Aurko Roy, Kevin Murphy, Ashish Vaswani, Niki Parmar, Mohammad Taghi Saffar, Noah Fiedel and Peter J Liu, for general feedback and discussions. We would also like to thank Drew Linsley, who provided us with help and information for setting up the path-finder benchmark.

## Appendix A Appendix

### A.1 LRA tasks

This section describes the details and hyperparameters of each task. We also plan to release the configuration files along with the implementation of the models and benchmarks, that can be used to reproduce the results reported in the paper.

#### A.1.1 ListOps

Following the generation steps in ([Nangia & Bowman, 2018](#bib.bib30)), we generate our own long version of this task. We use a sequence length of $2k$ for this task. All our xformer models have an embedding dimension of $512$, $8$ heads, $6$ layers and a feed-forward dimensions of $2048$. We train all models for $5K$ steps. The [CLS] token is used and mapped into a 10 class Softmax layer for classification.

#### A.1.2 Byte-level Document Classification

We use the IMDb reviews dataset ([Maas et al., 2011](#bib.bib29)) and a sequence length of $\{1K,2K,3K,4K\}$ tokens for all models. We pick the best results across these four sequence lengths. We use a [cls] token for prediction. All the [cls] tokens from xformer encoders are passed into a two layered MLP with ReLU activations. The MLP emits a $2$-class logits for binary classification. We optimize the softmax cross entropy loss function. All xformer models are parameterized by the same number of layers, heads and hidden dimensions, namely $8$ heads, $512$ hidden dimensions and $d=2048$ for positional FFN layers. We use $6$ layers for all xformers. The learning rate is $0.05$ with weight decay of $0.1$. We use Adam with warmup. All models are trained for $20K$ steps and a batch size of $32$.

#### A.1.3 Byte-level Document Matching

We use the ACL anthology network for a related article matching task. We use a sequence length of $4K$ per document ($8K$ tokens in total for two sequences). The two encoders share parameters. Similar to document classification, we use the [cls] token from xformer encoders. Let $X\_{1}$ be the [cls] token embedding from document 1 and $X\_{2}$ be the [cls] token embedding from document 2, the final score is computed via:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle Y=\text{MLP}([X\_{1},X\_{2},X\_{1}\*X\_{2},X\_{1}-X\_{2}])$ |  | (1) |

where MLP(.) is a two layered MLP with relu activation functions. In lieu of the much longer sequence length, we use a batch size of $32$, embedding dimension of $128$, $4$ heads, a FFN dimension of $512$ and $4$ layers. Model is trained with Adam for $5K$ steps with a learning rate of $0.5$.

### A.2 Image Classification

We use the gray-scaled (single channel) CIFAR10 as the image classification dataset, with 10 classes. The resolution of input images is $32\times 32$ and after flattening the input images, we feed our xformer encoders with a sequence of $1024$ pixels. Similar to our other classification tasks, there is a classifier head on top of the xformer encoder, consisting of a two-layer MLP with ReLU activation. Softmax cross-entropy has been used for optimizing the parameters of the models. We trained our models for $200$ epochs and have done extensive sweeps over different hyper-parameters and found the following values leading to the best average performance across all xformers: $3$ layers, $4$ heads, $128$ as the hidden dimensions of FFN blocks, $64$ as the query/key/value hidden dimensions, and finally the learning rate of $0.01$.

#### A.2.1 Generalization Gap

For the image classification benchmark, in Section [3](#S3 "3 Experimental Results ‣ Long Range Arena: A Benchmark for Efficient Transformers"), we mentioned that most of the models struggle generalizing to the test set. Table [3](#A1.T3 "Table 3 ‣ A.2.1 Generalization Gap ‣ A.2 Image Classification ‣ Appendix A Appendix ‣ Long Range Arena: A Benchmark for Efficient Transformers") presents the train and test accuracy for different models and for almost all these models, the gap between the two scores is considerably high.

| Model | test accuracy | train accuracy |  |
| --- | --- | --- | --- |
| Transformer | 42.44 | 69.45 |  |
| Local Attention | 41.46 | 63.19 |  |
| Sparse Trans. | 44.24 | 66.74 |  |
| Longformer | 42.22 | 71.65 |  |
| Linformer | 38.56 | 97.23 |  |
| Reformer | 38.07 | 68.45 |  |
| Sinkhorn Trans. | 41.23 | 69.21 |  |
| Synthesizer | 41.61 | 97.31 |  |
| BigBird | 40.83 | 71.49 |  |
| Linear Trans. | 42.34 | 65.61 |  |
| Performer | 42.77 | 73.90 |  |

Table 3: Test and train accuracy of different models on Image Classification task.

While this task can be simple to solve for convectional models (e.g., accuracy of wide-resnet on gray-scale CIFAR10 with no data augmentation is $89.21$) it is rather difficult for Transformer-based models with this setup.
Naturally, one can find ways to improve the performance with a different setup. For instance, in our setup, models are not informed about the oridinality of pixel intensities and consume them as independent symbols. We observed that learning embedding that reflects this property is rather hard for most of these models (Figure ). If we simply replace the embedding layer with a CNN stem, we see imitate boost in the performance (e.g. replacing the embedding layer of a vanilla Transformer with a convectional stem, with $3\times 3$ kernel, we get accuracy of $75.32$).

Another modification that can lead to better performance is to incorporate spatial representation that are translation invariant in Transformer models (e.g., adding 2D relative positional embedding to a vanilla transformer, we get accuracy of $61.72$). However, adding these sorts of changes make the setup digress from the original point of this task in our benchmark.

#### A.2.2 Visualizations of leaned embedding by a vanilla Transformer

Figure [4](#A1.F4 "Figure 4 ‣ A.2.2 Visualizations of leaned embedding by a vanilla Transformer ‣ A.2 Image Classification ‣ Appendix A Appendix ‣ Long Range Arena: A Benchmark for Efficient Transformers") presents visualizations for the pixel intensity and positional embedding that a vanilla transformer model learns for the image classification task, on the gray-scaled CIFAR10 detest.

Figure 4: 
Left: The cosine similarity between the embedding learned for each pixel intensity.
Right: Each tile shows the cosine similarity between the position embedding of the pixel with the indicated row and column and the position embeddings of all other pixels.

On the left, we can see the pairwise similarity of learned embeddings for pixel intensities. Although there is a higher similarity for close pixel values, the patterns from these learned embeddings do not perfectly reflect the ordinality of the pixel intensities.
On the right, we can see the pairwise similarity of positional embeddings for different input positions. We can see that the lower the distance between two pixels is, the more similar are their learned positional embeddings. However, the spatial closeness in $y$ axis is more preserved in the learned embedding than the distances in the $x$ axis.

### A.3 Pathfinder

Pathfinder task probes the ability of models to detect long range spatial dependencies between input features. To solve the task, a model requires to identify the target contour and trace it from one end to the other. Although Pathfinder is visually a simple task, it has been show that the clutter and variations in path shape makes the task difficult for CNN models ([Linsley et al., 2018](#bib.bib26); [Kim\* et al., 2020](#bib.bib20)).

The Pathfinder task is a binary classification task and the resolution of input images is $32\times 32$. Similar to image classification task, we feed our xformer encoders with a sequence of $1024$ pixels after flattening the input images. The classifier head on top of the xformer encoder is also a two-layer MLP with ReLU activation and we use Softmax cross-entropy loss for the optimization. We trained our models for $200$ epochs. The hyper-parameters used for the xformer model are as follow: $4$ layers, $8$ heads, $128$ as the hidden dimensions of FFN blocks, $128$ as the query/key/value hidden dimensions, and the learning rate of $0.01$.

#### A.3.1 Visualization of the Attention Maps from a Vanilla Transformer

Given that transformers have many units with global receptive field, they have better potential for solving the task, compared to models with local receptive fields. Figure [5](#A1.F5 "Figure 5 ‣ A.3.1 Visualization of the Attention Maps from a Vanilla Transformer ‣ A.3 Pathfinder ‣ Appendix A Appendix ‣ Long Range Arena: A Benchmark for Efficient Transformers") shows the attention distributions for a set of examples given on token (CLS token) as the query. We can see that the attention module collects information from different positions in input to be able to trace the target path.

Figure 5: Attention map for different examples from the Pathfinder task. Each map presents the attention distribution, given the CLS token at the final layer as the query, averaged across all heads in a vanilla Transformer model. Note that for visualization, we use attention-rollout ([Abnar & Zuidema, 2020](#bib.bib1)) for more precise input attribution.

We have also included a Pathfinder-X in LRA, which is similar to Pathfinder, but inputs are in higher resolutions, i.e. longer input sequences. On Pathfinder-X, we have tried two setups for training our models, first training models from scratch, second evaluating models that are trained on Pathfinder. In both cases, we found out none of the models are able to deal with/generalize to 16K input length.

## Appendix B Models and Implementation

This section describes the details of our implementation. The code is primarily written in JAX and FLAX. In this section, we note specific details about certain implementations of models. We plan to release hyperparameters in a form of readme or script later.

### B.1 A Brief Overview of Model Implementations

While most of the fine-grained details is planned to be available in the released code, we provide a brief overview of some settings of the xformer models being evaluated. For local attention, we do not use overlapping blocks. For local attention within Sinkhorn Transformer blocks, we do not overlap windows either. For Linformers, the projections are shared between key and values but not across multiple layers. For Performer models, our implementation uses FAVOR+, the more recent version in the paper [Choromanski et al. (2020b)](#bib.bib6).

### B.2 Special Cases of our Implementation

This section describes several special cases in our implementation details. The diverse suite of Transformers come with a plethora of hardware constraints and implementation details. To succeed, a Transformer model needs to also ‘win’ the hardware lottery ([Hooker, 2020](#bib.bib13)), i.e., having readily supported ops, kernels or accelerator support to take advantage of its technical design. This section discusses some of the trade-offs and edge cases that make comparison of several models challenging. In the end, we argue that simplicity is a virtue and not requiring any special support is a positive thing for an efficient Transformer model.

##### On CUDA kernels

CUDA kernels are cumbersome and are specific to GPU hardware, making it difficult to implement or use on TPU pods. Generally, these are considered to be undesirable and inconvenient in practical applications. Hence, Sparse Transformer and Longformer are implemented with equivalent implementations to emulate for performance. This is by applying an equivalent mask. For this reason, we do not benchmark Sparse Transformer and Longformer for speed.

##### Reformer’s Implementation

Having optimized ops to support many of Reformer’s functionality is crucial. Hence, Reformer is implemented slightly differently from other Transformer models. Instead of computing tensors with batch size dimensions $B$ and head dimensions $H$, (i.e., $B\times H\times N\times d$), we compute the attention function for tensors of $N\times d$ dimensions. After which, we parallelize this function via vmap over the batch and head dimensions.

## Appendix C Recommendations for Fair Comparison

We welcome re-evaluation of our models on any task. However, we consider some hyperparameters to be immutable to ensure fair comparison with all models. In the case of proposing new models, the LRA table in the paper can be copied as it is as long as (1) the model size remains unchanged, (2) no pretraining is conducted, (3) no alterations to the fundamental setups (e.g., changing char level to word level or adding spatial information to the image task). We will provide more details at <https://github.com/google-research/long-range-arena>.
