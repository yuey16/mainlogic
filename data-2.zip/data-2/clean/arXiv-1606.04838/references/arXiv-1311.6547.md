<!-- fulltext source=arxiv_html slug=arXiv-1311.6547 fetched=2026-09-18T06:33:38+00:00 -->

# Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis

Katya Scheinberg
††thanks:  katyas@lehigh.edu. Department of Industrial and Systems Engineering, Lehigh University,
Harold S. Mohler Laboratory, 200 West Packer Avenue, Bethlehem, PA 18015-1582, USA. The work of this author is partially supported by NSF Grants DMS 10-16571, DMS 13-19356,
AFOSR Grant FA9550-11-1-0239, and DARPA grant FA 9550-12-1-0406 negotiated by AFOSR.
  
Xiaocheng Tang
††thanks:  xct@lehigh.edu, Department of Industrial and Systems Engineering, Lehigh University,
Harold S. Mohler Laboratory, 200 West Packer Avenue, Bethlehem, PA 18015-1582, USA. The work of this author is partially supported by DARPA grant FA 9550-12-1-0406 negotiated by AFOSR

August 24, 2026

Recently several methods were proposed for sparse optimization which make careful use of second-order information [[11](#bib.bib11), [34](#bib.bib34), [20](#bib.bib20), [4](#bib.bib4)] to improve local convergence rates. These methods construct a composite quadratic approximation using Hessian information, optimize this approximation using a first-order method, such as coordinate descent and employ a line search to ensure sufficient descent.
Here we propose a general framework, which includes slightly modified versions of existing algorithms and also a new algorithm, which uses limited memory BFGS Hessian approximations, and provide a novel global convergence rate analysis, which covers methods that solve subproblems via coordinate descent.

## 1 Introduction

In this paper, we are interested in the following popular convex optimization problem:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\min\_{x\in\mathbb{R}^{n}}F(x)\equiv f(x)+g(x),$ |  | (1.1) |

where $f,g:\mathbb{R}^{n}\rightarrow\mathbb{R}$ are both convex
functions such that $\nabla f(x)$ is assumed to be Lipschitz continuous with Lipschitz constant $L(f)$, i.e.,

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\|\nabla f(x)-\nabla f(y)\|\_{2}\leq L(f)\|x-y\|\_{2},\quad\forall x,y\in\mathbb{R}^{n},$ |  |

and $g(x)$ is convex and has some structure that can be exploited. In particular, in much of the research on first order methods for problem ([1.1](#S1.E1 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) $g(x)$ is considered to be such that the following problem has a closed form solution
for any $z\in\mathbb{R}^{n}$:

|  |  |  |
| --- | --- | --- |
|  | $\min\_{x\in\mathbb{R}^{n}}\left\{g(x)+\frac{1}{2}\|x-z\|^{2}\right\}.$ |  |

Here our general requirement on $g(x)$ is slightly different - we assume that the following problem is
computationally inexpensive to solve approximately, relative to minimizing $F(x)$
for any $z\in\mathbb{R}^{n}$ and some class of positive definite matrices $H$:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\min\_{x\in\mathbb{R}^{n}}\left\{g(x)+\frac{1}{2}\|x-z\|\_{H}^{2}\right\}.$ |  | (1.2) |

Here $\|y\|^{2}\_{H}$ denotes $y^{\top}Hy$. Clearly, the computational cost of approximately solving ([1.2](#S1.E2 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) depends on the choice of matrix $H$ and the solution approach.

We are particularly interested in the case of sparse optimization, where $g(x)=\lambda\|x\|\_{1}$.
While the theory we present here applies to the general form ([1.1](#S1.E1 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")), the efficient method for solving ([1.2](#S1.E2 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) that we consider in this paper is designed with $g(x)=\lambda\|x\|\_{1}$ example in mind. In this case problem ([1.2](#S1.E2 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) takes a form of an unconstrained Lasso problem [[29](#bib.bib29)].
We consider matrices $H$ which are a sum of a diagonal matrix and a low-rank matrix and we apply randomized coordinate descent to solve ([1.2](#S1.E2 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) approximately. An extension to the group sparsity term $g(x)=\lambda\sum\|x\_{i}\|\_{2}$ [[21](#bib.bib21)], is rather straightforward.

Problems of the form ([1.1](#S1.E1 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) with $g(x)=\lambda\|x\|\_{1}$ have been the focus of much research lately in the fields of signal processing and machine learning. This form encompasses a variety of machine learning models,
in which feature selection is desirable, such as sparse logistic regression [[33](#bib.bib33), [34](#bib.bib34), [27](#bib.bib27)], sparse inverse covariance selection [[11](#bib.bib11), [20](#bib.bib20), [24](#bib.bib24)] and unconstrained Lasso [[29](#bib.bib29)], etc. These settings often present common difficulties to optimization algorithms due to their large scale. During the past decade most optimization effort aimed at these problems focused on development of efficient first-order methods, such as accelerated proximal gradient methods [[16](#bib.bib16), [2](#bib.bib2), [31](#bib.bib31)], block coordinate descent methods [[34](#bib.bib34), [10](#bib.bib10), [9](#bib.bib9), [24](#bib.bib24)] and alternating directions methods [[23](#bib.bib23)]. These methods enjoy low per-iteration complexity, but typically have slow local convergence rates. Their performance is often hampered by small step sizes. This, of course, has been known about first-oder methods for a long time, however, due to the very large size of these problems, second-order methods are often not a practical alternative.
In particular, constructing and storing a Hessian matrix, let alone inverting it, is prohibitively expensive for values of $n$ larger than $10000$, which often makes the use of the Hessian in large-scale problems prohibitive, regardless of the benefits of fast local convergence rate.

Nevertheless, recently several new methods were proposed for sparse optimization which make careful use of second-order information [[11](#bib.bib11), [34](#bib.bib34), [20](#bib.bib20), [4](#bib.bib4)].
These new methods are designed to exploit the special structure of the Hessian of specific functions to improve efficiency of solving ([1.2](#S1.E2 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")). Several successful methods employ coordinate descent to approximately solve ([1.2](#S1.E2 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")). While other approaches to solve Lasso subproblem were considered in
[[4](#bib.bib4)], none generally outperform coordinate descent, which is well suited when special structure of the Hessian approximation, $H$,
can be exploited and when low accuracy of the subproblem solutions is sufficient.
In particular, [[34](#bib.bib34)] proposes a specialized GLMNET [[10](#bib.bib10)] implementation for sparse logistic regression, where coordinate descent method is applied to the unconstrained Lasso subproblem constructed using the Hessian of $f(x)$. The special structure of the Hessian is used to reduce the complexity cost of each coordinate step so that it is linear in the number of training instances, and a two-level shrinking scheme proposed to focus the minimization on smaller subproblems. Similar ideas are used in [[11](#bib.bib11)] in a specialized algorithm called QUIC for sparse inverse covariance selection, where the Hessian of $f(x)$ also has a favorable structure for solving Lasso subproblems.
Another specialized method for graphical Markov random fields was recently proposed in [[32](#bib.bib32)]. This method also exploits special Hessian structure to improve coordinate descent efficiency.

There are other common features shared by the methods described above. These methods are often referred to as proximal Newton-type methods.
The overall algorithmic framework can be described as follows:

* •

  At each iteration $k$ the smooth function $f(x)$ is approximated near the current iterate $x^{k}$ by a convex quadratic function $q^{k}(x)$.
* •

  A working subset of coordinates (elements) of $x$ is selected for subproblem optimization.
* •

  Then $l(k)$ passes of coordinate descent are applied to optimize (approximately)
  the function $q^{k}(x)+g(x)$ over the working set, which results in a trial point. Here $l(k)$ is some linear function of $k$.
* •

  The trial point is accepted as the new iterate if it satisfies some sufficient decrease condition (to be specified).
* •

  Otherwise, a line search is applied to compute a new trial point.

In this paper we do not  include the theoretical analysis of various working set selection strategies. Some of these have been analyzed in the prior literature (e.g., see [[14](#bib.bib14)]). Combining such existing analysis with the rate of convergence results in this paper is a subject of a future study.

This paper contains the following three main results.

1. 1.

   We discuss theoretical properties of the above framework in terms of global convergence rates.
   In particular, we show that if we replace the line search by a prox-parameter update mechanism, we can derive sublinear global convergence results for the above methods under mild assumptions on Hessian approximation matrices, which can include diagonal, quasi-Newton and limited memory quasi-Newton approximations. We also provide the convergence rate for the case of inexact subproblem optimization.
   It turns out that standard global convergence analysis of proximal gradient methods (see [[2](#bib.bib2), [26](#bib.bib26)]) does not extend in a natural way to proximal
   quasi-Newton frameworks, hence we use a different technique derived for smooth optimization in [[16](#bib.bib16), [18](#bib.bib18), [7](#bib.bib7)], in a novel way, to obtain the global complexity result.
2. 2.

   The heuristic of applying $l(k)$ passes of coordinate descent to the subproblem is very useful in practice, but has not yet been theoretically justified, due to the lack of known complexity estimates. Here we use probabilistic complexity bounds of randomized coordinate descent to show that this heuristic is indeed well justified theoretically.
   In particular, it guarantees the sufficiently rapid decrease of the expectation of the error in the subproblems and hence allows for sublinear global convergence rate to hold for the entire algorithm (again, in expectation). This gives us the first complete global convergence rate result for the algorithmic schemes for practical (inexact) proximal Newton-type methods. Moreover, using the new analysis from [[17](#bib.bib17), [18](#bib.bib18), [7](#bib.bib7)] we are able to provide lower overall complexity
   bound than the one that follows from [[26](#bib.bib26)]
3. 3.

   Finally, we propose an efficient general purpose algorithm that uses the same theoretical framework, but which does not rely on the special structure of the Hessian, and yet in our tests compares favorably with the state-of-the-art, specialized methods such as QUIC and GLMNET. We replace the exact Hessian computation by the limited memory BFGS Hessian approximations [[19](#bib.bib19)] (LBFGS) and exploit their special structure within a coordinate descent approach to solve the subproblems.

Let us elaborate a bit further on the new approaches and results developed in this paper and discuss related prior work.

In [[5](#bib.bib5)] Byrd et al. propose that the methods in the framework described above should be referred to as sequential quadratic approximation (SQA) instead of proximal Newton methods. They reason that there is no proximal operator or proximal term involved in this framework. This is indeed the case, if a line search is used to ensure sufficient decrease. Here we propose to consider a prox term as a part of the quadratic approximation.
Instead of a line search procedure, we update the prox term of our quadratic model, which allows us to extend global convergence bounds of proximal gradient methods to the case of proximal (quasi-)Newton methods. The criteria for accepting a new iteration is based on sufficient decrease condition (much like in trust region methods, and unlike that in proximal gradient methods).
We show that our mechanism of updating the prox parameter, based on sufficient decrease condition, leads to an improvement in performance and robustness of the algorithm compared to the line search approach as well as enabling us to develop global convergence rates.

Convergence results for the proximal Newton method have been shown
in [[13](#bib.bib13)] and more recently in [[5](#bib.bib5)] (with the same sufficient decrease condition as ours, but applied within a line search). These papers also demonstrate super linear local convergence rate of the proximal Newton and a proximal quasi-Newton method.
Thus it is confirmed in [[5](#bib.bib5), [13](#bib.bib13)] that using second order information is as beneficial for problems of the form ([1.1](#S1.E1 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"))
as it is for the smooth optimization problems. These results apply to our framework when exact Hessian (or a quasi-Newton approximation) of $f(x)$ is used to construct $q(x)$ (and if the matrices have bounded eigenvalues). However, theory in [[5](#bib.bib5), [13](#bib.bib13)]
does not provide global convergence rates for these methods, and just as in the case on smooth optimization,
the super linear local convergence rates, generally, do not apply in the case of LBFGS Hessian approximations.

The convergence rate that we show is sub linear, which is generally the best that can be expected from a proximal (quasi-)Newton method
with no assumptions on the accuracy of the Hessian approximations. Practical benefits of using
LBFGS Hessian approximations is well known for smooth optimization [[19](#bib.bib19)] and have been exploited in many large scale applications.
In this paper we demonstrate this benefit in the composite optimization setting ([1.1](#S1.E1 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")). Some prior work showing benefit of limiter memory quasi-Newton method in proximal setting include [[3](#bib.bib3), [12](#bib.bib12)].
We also emphasize in our theoretical analysis the potential gain over proximal gradient methods in terms of constants occurring in the convergence rate.

To prove the sub linear rate we borrow a technique from [[17](#bib.bib17), [18](#bib.bib18), [7](#bib.bib7)]. The technique used in
[[2](#bib.bib2)] and [[26](#bib.bib26)] for the proof of convergence rates of the (inexact) proximal gradient method do not seem to extend
to general positive definite Hessian approximation matrix. In a related work [[12](#bib.bib12)] the authors analyze global convergence rates of an accelerated proximal quasi-Newton method, as an extension of FISTA method [[2](#bib.bib2)]. The convergence rate they obtain match that of accelerated proximal gradient methods, hence it is a faster rate
than that of our method presented here. However, they have to impose much stricter conditions on the Hessian approximation matrix, in particular they require that the difference between any two consecutive Hessian approximations (i.e., $H\_{k}-H\_{k+1}$) is positive semidefinite. This is actually in contradiction to FISTA’s requirement that the prox parameter is never increased. Such a condition is very restrictive
as is impractical. In this paper we briefly show how results in [[2](#bib.bib2)] and [[26](#bib.bib26)] can be extended under some
(also possibly strong) assumptions of the Hessian approximations, to give a simple and natural convergence rate analysis.
We then present an alternative analysis, which only requires the Hessian approximations to have bounded eigenvalues.
Investigating accelerated version of our approach without restrictive assumptions on the Hessian approximations and with the use
of randomized coordinate descent is a subject of future research.

Finally, we use the complexity analysis of randomized coordinate descent in [[22](#bib.bib22)] to provide a simple and efficient stopping criterion for the subproblems and thus derive the total complexity of proximal (quasi-)Newton methods based on randomized coordinate descent to solve Lasso subproblems.

The paper is organized as follows: in Section [2](#S2 "2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") we describe the algorithmic framework. Then, in Section [3](#S3 "3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") we
present some of the assumptions and discussions and, in Section [3.1](#S3.SS1 "3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"), convergence rate analysis based on [[2](#bib.bib2)] and [[26](#bib.bib26)].
In Section [4](#S4 "4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") we show the new convergence rate analysis using [[17](#bib.bib17), [18](#bib.bib18), [7](#bib.bib7)] for exact and inexact
version of our framework. We then extend the analysis for the cases where inexact solution to a subproblem is random in Section [5](#S5 "5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")
and in particular to the randomized coordinate descent in Section [5.1](#S5.SS1 "5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").
Brief description of the details of our proposed algorithm are in Section [6](#S6 "6 Optimization Algorithm ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") and computational results validating the theory are presented in Section [7](#S7 "7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").

## 2 Basic algorithmic framework and theoretical analysis

The following function is used throughout the paper as an approximation of the objective function $F(x)$.

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle Q(H,u,v):=f(v)+\langle\nabla f(v),u-v\rangle+\frac{1}{2}\langle u-v,H(u-v)\rangle+g(u).$ |  | (2.1) |

For a fixed point $\bar{x}$, the function $Q(H,x,\bar{x})$ serves as an approximation of $F(x)$ around $\bar{x}$.
Matrix $H$ controls the quality of this approximation. In particular, if $f(x)$ is smooth and $H=\frac{1}{\mu}I$, then $Q(H,x,\bar{x})$ is a sum of the prox-gradient approximation of $f(x)$ at $\bar{x}$ and $g(x)$. This particular form of $H$ plays a key role in the design and analysis of proximal gradient methods (e.g., see [[2](#bib.bib2)])
and alternating direction augmented Lagrangian methods (e.g, see [[23](#bib.bib23)]).
If $H=\nabla^{2}f(\bar{x})$, then $Q(H,x,\bar{x})$
is a second order approximation of $F(x)$ [[13](#bib.bib13), [25](#bib.bib25)].
In this paper we assume that $H$ is a positive definite matrix such that $\sigma I\preceq H\preceq MI$ for some positive constants $M$ and $\sigma$.

Minimizing the function $Q(H,u,v)$ over $u$ reduces to solving problem ([1.2](#S1.E2 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")). We will use the following notation to denote the accurate and approximate solutions of ([1.2](#S1.E2 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")).

|  |  |  |  |
| --- | --- | --- | --- |
|  | $p\_{H}(v):=\arg\min\_{u}Q(H,u,v),$ |  | (2.2) |

and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $p\_{H,\phi}(v){\rm\ is\ a\ vector\ such\ that:\ }\ \begin{array}[]{l}Q(H,p\_{H,\phi}(v),v)\leq Q(H,v,v)=F(v),\ {\rm and}\\ Q(H,p\_{H,\phi}(v),v)\leq Q(H,p\_{H}(v),v)+\phi.\end{array}$ |  | (2.3) |

The method that we consider in this paper computes iterates by (approximately) optimizing $Q(H,u,v)$ with respect to $u$ using some particular $H$ which is chosen at each iteration.
The basic algorithm is described in Algorithms [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") and [2](#algorithm2 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").

Algorithm 1 Proximal Quasi-Newton method

```
Choose 
0<ρ≤10<\rho\leq 1 and x0x^{0};

1
for k=0,1,2,⋯k=0,1,2,\cdots do
   
            2
          Choose 0​<μ¯k,ϕk>​0,Gk⪰00<\bar{\mu}_{k},\phi_{k}>0,G_{k}\succeq 0;
   
            3
          Find Hk=Gk+12​μk​IH_{k}=G_{k}+\frac{1}{2\mu_{k}}I and xk+1:=pHk​(xk)x^{k+1}:=p_{H_{k}}(x^{k})
   
            4
          by applying Prox Parameter Update (μ¯k,Gk,xk,ρ)(\bar{\mu}_{k},G_{k},x^{k},\rho);
```

Algorithm 2 Prox Parameter Update $(\bar{\mu},G,x,\rho)$

```
Select 0<β<10<\beta<1 and set μ=μ¯\mu=\bar{\mu};

1
for i=1,2,⋯i=1,2,\cdots do
   
            2
          Define H=G+12​μ​IH=G+\frac{1}{2\mu}I and compute p​(x):=pH​(x)p(x):=p_{H}(x);
   
            3
          If F⁡(p⁡(x))−F⁡(x)≤ρ⁡(Q⁡(H,p⁡(x),x)−F⁡(x))F(p(x))-F(x)\leq\rho(Q(H,p(x),x)-F(x)), then output HH and p⁡(x)p(x), Exit ;
   
            4
          Else μ=βi​μ¯\mu=\beta^{i}\bar{\mu};
```

Algorithm [2](#algorithm2 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") chooses Hessian approximations of the form $H\_{k}=\frac{1}{\mu\_{k}}I+G\_{k}$. However, it is possible to consider any procedure of choosing positive definite $H\_{k}$ which ensures $MI\succeq H\_{k}\succeq\sigma I$ and
$F(p\_{H\_{k}}(x))-F(x)\leq\rho(Q(H\_{k},p\_{H\_{k}}(x),x)-F(x))$, for a given $0<\rho\leq 1$, - a step acceptance condition which is a relaxation of conditions used in [[2](#bib.bib2)] and [[26](#bib.bib26)].

An inexact version of Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") is obtained by simply replacing $p\_{H\_{k}}$ by $p\_{H\_{k},\phi\_{k}}$ in both Algorithms [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") and [2](#algorithm2 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") for some sequence of $\phi\_{k}$ values.

## 3 Basic results, assumptions and preliminary analysis

ISTA [[2](#bib.bib2)] is a particular case of Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") with $G\_{k}=0$, for all $k$, and $\rho=1$.
In this case, the value of $\mu\_{k}$ is chosen so that the conditions of Lemma [2](#Thmtheorem2 "Lemma 2 ‣ 3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") hold with $\epsilon=0$. In other words, the reduction achieved in the objective function $F(x)$ is at least the amount of reduction achieved in the model
$Q(\mu\_{k},p(x^{k}),x^{k})$. It is well known that as long as $\mu\_{k}\leq 1/L(f)$ (recall that $L(f)$ is the Lipschitz constant of the gradient) then condition ([3.8](#S3.E8 "In 3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"))
holds with $\rho=1$. Relaxing condition ([3.8](#S3.E8 "In 3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) by using $\rho<1$ allows us to accept larger values of $\mu\_{k}$, which in turn implies larger steps taken by the algorithm. This basic idea is the cornerstone of step size selection in most nonlinear optimization algorithms. Instead of insisting on achieving ”full” predicted reduction of the objective function (even when possible), a fraction of this reduction is usually sufficient. In our experiments small values of $\rho$ provided much better performance than values close to $1$.

In the next three sections we present the analysis of convergence rate of Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") under different scenarios. Recall that we assume that $f(x)$ is convex and smooth, in other words $\|\nabla f(x)-\nabla f(y)\|\leq L(f)\|x-y\|$ for all $x$ and $y$ in the domain of interest, while $g(x)$ is simply convex. In Section [5.1](#S5.SS1 "5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") we assume that $g(x)=\lambda\|x\|\_{1}$. Note that we do not assume that $f(x)$ is strongly convex or that it is twice continuously differentiable, because we do not rely on any accurate second order information in our framework. We only assume that the Hessian approximations are positive definite and bounded, but their accuracy can be arbitrary, as long as sufficient decrease condition holds. Hence we only achieve sublinear rate of convergence. To achieve higher local rates of convergence stronger assumptions on $f(x)$ and on the Hessian approximations have to be made, see for instance, [[5](#bib.bib5)] and [[13](#bib.bib13)] for related local convergence analysis.

First we present a helpful lemma which is a simple extension of Lemma 2 in [[26](#bib.bib26)] to the case of general positive definite Hessian estimate. This lemma establishes some simple properties of an $\phi$-optimal solution to the proximal problem ([1.2](#S1.E2 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")). It uses the concept of the $\phi$-subdifferential of a convex function $a$ at $x$,
$\partial\_{\phi}a(x)$, which is defined as the set of vectors $y$ such that $a(x)-y^{T}x\leq a(t)-y^{T}t+\phi$ for all $t$.

###### Lemma 1

Given $\phi>0$, a p.d. matrix $H$ and $v\in\mathbb{R}^{n}$, let $p\_{\phi}(v)$ denote the $\phi$-optimal solution to the proximal problem ([1.2](#S1.E2 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) in the sense that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle g(p\_{\phi}(v))+\frac{1}{2}\|p\_{\phi}(v)-z\|\_{H}^{2}\leq\phi+\min\_{x\in\mathbb{R}^{n}}\left\{g(x)+\frac{1}{2}\|x-z\|\_{H}^{2}\right\},$ |  | (3.1) |

where $z=v-H^{-1}\nabla f(v)$. Then there exists $\eta$ such that $\frac{1}{2}\|\eta\|^{2}\_{H^{-1}}\leq\phi$ and

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle H(v-p\_{\phi}(v))-\eta\in\partial\_{\phi}g(p\_{\phi}(v)).$ |  | (3.2) |

Proof. ([3.1](#S3.E1 "In Lemma 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) indicates that $p\_{\phi}(v)$ is an $\phi$-minimizer of the convex function $a(x):=\frac{1}{2}\|x-z\|\_{H}^{2}+g(x)$. If we let $a\_{1}(x)=\frac{1}{2}\|x-z\|\_{H}^{2}$ and $a\_{2}(x)=g(x)$, then this is equivalent to

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle 0\subset\partial\_{\phi}a(p\_{\phi}(v))\subset\partial\_{\phi}a\_{1}(p\_{\phi}(v))+\partial\_{\phi}a\_{2}(p\_{\phi}(v)).$ |  | (3.3) |

Hence,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\partial\_{\phi}a\_{1}(p\_{\phi}(v))$ | $\displaystyle=\left\{y\in\mathbb{R}^{n}~|~\frac{1}{2}\|y+H(z-p\_{\phi}(v))\|^{2}\_{H^{-1}}\leq\phi\right\}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\left\{y\in\mathbb{R}^{n},~y=\eta-H(z-p\_{\phi}(v))~|~\frac{1}{2}\|\eta\|^{2}\_{H^{-1}}\leq\phi\right\}.$ |  |

From ([3.3](#S3.E3 "In 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle H(z-p\_{\phi}(v))-\eta\in\partial\_{\phi}g(p\_{\phi}(v))\mbox{ with }\frac{1}{2}\|\eta\|^{2}\_{H^{-1}}\leq\phi.$ |  | (3.4) |

Then ([3.2](#S3.E2 "In Lemma 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) follows using $z=v-H^{-1}\nabla f(v)$.

We will find the following bound useful on the norm of $\eta$ which follows from the above lemma.

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\|\eta\_{i}\|\leq\sqrt{2\lambda\_{max}(H)\phi\_{i}},$ |  | (3.5) |

where $\lambda\_{max}$ is the largest eigenvalue of $H$ or its upper bound.

Below are the assumptions made in our analysis.

###### Assumptions 1

(i) 
The set of optimal solutions of ([1.1](#S1.E1 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")), $X^{\*}$, is nonempty and $x^{\*}$ is any element of that set.

(ii) 
The effective domain of $F$ is defined as $\dom(F):=\{x\in\mathbb{R}^{n}:F(x)<\infty\}$, and the level set of $F$ at point $x\in\dom(F)$ is defined by

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle{\cal X}\_{F}(x):=\{y\in\dom(F):F(y)\leq F(x)\}.$ |  |

Without loss of generality, we restrict our discussions below to the level set ${\cal X}\_{0}:={\cal X}\_{F}(x^{0})$ given by some $x^{0}\in\dom(F)$, e.g., the initial iterate of the Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").

(iii) 
$g$ is convex and Lipschitz continuous with constant $L\_{g}$ for all $x,y\in{\cal X}\_{0}$:

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle g(x)-g(y)\leq L\_{g}\|x-y\|,$ |  |

(iv) 
There exists positive constants $M$ and $\sigma$ such that for all $k\geq 0$, at the $k$-th iteration of Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"):

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\sigma I\preceq\sigma\_{k}I\preceq H\_{k}\preceq M\_{k}I\preceq MI$ |  | (3.6) |

(v) 
There exists a positive constant $D\_{{\cal X}\_{0}}$ such that for all iterates $\{x^{k}\}$ of Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"):

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\sup\_{x^{\*}\in X^{\*}}~\|x^{k}-x^{\*}\|\leq D\_{{\cal X}\_{0}}$ |  |

In the analysis of the proximal gradient methods Assumption [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") is removed by directly establishing a uniform bound on $\|x^{k}-x^{\*}\|$ (rf. [[28](#bib.bib28), [26](#bib.bib26)]). In the next section we show an outline of a proximal-gradient type analysis where this assumption is imposed for simplicity of the presentation. It is possible [[28](#bib.bib28)] to establish a similar, but more complex bound without this assumption.
The proximal gradient approach in the next subsection, however, requires another, stronger, assumption on $H\_{k}$. In the alternative analysis that follows
we impose Assumption [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") but relax the assumption on $H\_{k}$ matrices.
Note that all iterates $\{x^{k}\}$ fall into the level set ${\cal X}\_{0}$, due to the sufficient decrease condition ([3.8](#S3.E8 "In 3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) that demands a monotonic decrease on the objective values. Assumption [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") thus follows straightforwardly if the level set is bounded, which often holds in real-world problems or can be easily imposed.

### 3.1 Analysis via proximal gradient approach

In this section we extend the analysis in [[2](#bib.bib2)] and [[26](#bib.bib26)] to our framework under additional assumptions on the Hessian approximations $H\_{k}$.
The following lemma, is a generalization of Lemma 2.3 in [[2](#bib.bib2)] and of a similar lemma in [[26](#bib.bib26)].
This lemma serves to provide a bound on the change in the objective function $F(x)$.

###### Lemma 2

Given $\epsilon$, $\phi$ and $H$ such that

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle F(p\_{\phi}(v))$ | $\displaystyle\leq Q(H,p\_{\phi}(v),v)+\epsilon$ |  | (3.7) |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle Q(H,p\_{\phi}(v),v)$ | $\displaystyle\leq\min\_{x\in\mathbb{R}^{n}}Q(H,x,v)+\phi,$ |  |

where $p\_{\phi}(v)$ is the $\phi$-approximate minimizer of $Q(H,x,v)$, then for any $\eta$ such that $\frac{1}{2}\|\eta\|^{2}\_{H^{-1}}\leq\phi$
and for any $u\in\mathbb{R}^{n}$,

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle 2(F(u)-F(p\_{\phi}(v)))\geq\|p\_{\phi}(v)-u\|\_{H}^{2}-\|v-u\|\_{H}^{2}-2\epsilon-2\phi-2\langle\eta,u-p\_{\phi}(v)\rangle.$ |  |

Proof. The proof is an easy extension of that in [[2](#bib.bib2)].

Note that if $\phi=0$, that is the subproblems are solved accurately, then we have $2(F(u)-F(p(v)))\geq\|p(v)-u\|\_{H}^{2}-\|v-u\|\_{H}^{2}-2\epsilon$.

If the sufficient decrease condition

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle(F(x^{k+1})-F(x^{k}))\leq\rho(Q(H\_{k},x^{k+1},x^{k})-F(x^{k}))$ |  | (3.8) |

is satisfied, then

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle F(x^{k+1})$ | $\displaystyle\leq Q(H\_{k},x^{k+1},x^{k})-(1-\rho)\left(Q(H\_{k},x^{k+1},x^{k})-F(x^{k})\right)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leq Q(H\_{k},x^{k+1},x^{k})-\frac{1-\rho}{\rho}(F(x^{k+1})-F(x^{k}))$ |  |

and Lemma [2](#Thmtheorem2 "Lemma 2 ‣ 3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") holds at each iteration $k$ of Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") with $\epsilon\_{k}=-\frac{1-\rho}{\rho}(F(x^{k+1})-F(x^{k}))$.

We now establish the sub linear convergence rate of Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") under the following additional assumption.

###### Assumption 2

Let $\{x^{k}\}$ be the sequence of iterates generated by Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"), then there exists a constant $M\_{H}$ such that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\sum\_{i=0}^{k-1}(\|x^{i+1}-x^{\*}\|^{2}\_{\frac{H\_{i+1}}{M\_{i+1}}}-\|x^{i+1}-x^{\*}\|^{2}\_{\frac{H\_{i}}{M\_{i}}})\leq M\_{H},\quad\forall k,$ |  | (3.9) |

where $M\_{i}$ is the upper bound on the largest eigenvalue of $H\_{i}$ as defined in Assumption [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").

The assumption above is not verifiable, hence it does not appear to be very useful. However, it is easy to see that a condition
$\frac{H\_{i+1}}{M\_{i+1}}\preceq\frac{H\_{i}}{M\_{i}}$, for all $i$, easily implies ([3.9](#S3.E9 "In Assumption 2 ‣ 3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) with $M\_{H}=0$. This condition, in turn,
is trivially satisfied if $H\_{i+1}$
is a multiple of $H\_{i}$ for all $i$, as it is in the case of ISTA algorithm. It is also clear that Assumption [2](#Thmassumptions2 "Assumption 2 ‣ 3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") is a lot weaker than
the condition that $H\_{i+1}$ is a multiple of $H\_{i}$ for all $i$. For example, it also hold if $H\_{i+1}$ is a multiple of $H\_{i}$ for all $i$ except for a finite number of iterations. It also holds if $H\_{i+1}$ converges to $H\_{i}$ (or to its multiple) sufficiently rapidly. It is also weaker than the assumption
in [[12](#bib.bib12)] that $H\_{i+1}\preceq{H\_{i}}$. Exploring different conditions on the Hessian approximations that ensure Assumption [2](#Thmassumptions2 "Assumption 2 ‣ 3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") is a subject of a separate study. Below we show how under this condition sub linear convergence rate is established.

###### Theorem 3

Suppose that Assumptions [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") and [2](#Thmassumptions2 "Assumption 2 ‣ 3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") hold.
Assume that all iterates $\{x^{k}\}$ of inexact Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") are generated with some $\phi\_{k}\geq 0$ (cf. ([2.3](#S2.E3 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"))), then

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle F(x^{k})-F(x^{\*})\leq\frac{1}{k\_{m}}\left(\frac{1}{2}\|x^{0}-x^{\*}\|\_{H\_{0}/M\_{0}}^{2}+M\_{H}+\frac{(1-\rho)(F(x^{0})-F(x^{\*}))}{\rho\sigma}+\sum\_{i=0}^{k-1}\frac{\phi\_{i}}{M\_{i}}+D\_{{\cal X}\_{0}}\sum\_{i=0}^{k-1}\sqrt{\frac{2\phi\_{i}}{M\_{i}}}\right),$ |  | (3.10) |

where $k\_{m}=\sum\_{i=0}^{k-1}M\_{i}^{-1}$.

Proof. Let us apply Lemma [2](#Thmtheorem2 "Lemma 2 ‣ 3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"), sequentially, with $u=x^{\*}$, $p\_{\phi}(v)=x^{i}$ and subproblem minimization residual $\phi\_{i}$ for $i=0,\ldots,k-1$. Adding up resulting inequalities, we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\sum\_{i=0}^{k-1}\frac{F(x^{i+1})-F(x^{\*})}{M\_{i}}\leq\frac{1}{2}\sum\_{i=0}^{k-1}\left(\|x^{i}-x^{\*}\|\_{H\_{i}/M\_{i}}^{2}-\|x^{i+1}-x^{\*}\|\_{H\_{i}/M\_{i}}^{2}\right)+\sum\_{i=0}^{k-1}(\frac{\phi\_{i}}{M\_{i}}+\frac{\epsilon\_{i}}{M\_{i}}+\frac{\langle\eta\_{i},x^{\*}-x^{i+1}\rangle}{M\_{i}})$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle=\frac{1}{2}\left(\|x^{0}-x^{\*}\|\_{\frac{H\_{0}}{M\_{0}}}^{2}+\sum\_{i=0}^{k-1}(\|x^{i+1}-x^{\*}\|^{2}\_{H\_{i+1}/M\_{i+1}}-\|x^{i+1}-x^{\*}\|^{2}\_{H\_{i}/M\_{i}})-\|x^{k}-x^{\*}\|\_{H\_{k}/M\_{k}}^{2}\right)$ |  | (3.11) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle+\sum\_{i=0}^{k-1}\frac{\epsilon\_{i}}{M\_{i}}+\sum\_{i=0}^{k-1}\frac{\phi\_{i}}{M\_{i}}+\sum\_{i=0}^{k-1}\frac{\langle\eta\_{i},x^{\*}-x^{i+1}\rangle}{M\_{i}}.$ |  |

From Assumptions [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") and [2](#Thmassumptions2 "Assumption 2 ‣ 3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") we have

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\sum\_{i=0}^{k-1}\frac{F(x^{i+1})-F(x^{\*})}{M\_{i}}\leq\frac{1}{2}\|x^{0}-x^{\*}\|\_{H\_{0}/M\_{0}}^{2}+M\_{H}+\sum\_{i=0}^{k-1}\frac{\epsilon\_{i}}{M\_{i}}+\sum\_{i=0}^{k-1}\frac{\phi\_{i}}{M\_{i}}+D\_{{\cal X}\_{0}}\sum\_{i=0}^{k-1}\frac{\|\eta\_{i}\|}{M\_{i}}.$ |  |

From ([3.5](#S3.E5 "In 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) and definition of $M\_{i}$ we know that $\|\eta\_{i}\|\leq\sqrt{2M\_{i}\phi\_{i}}$.
Using the already established bound $\sum\_{i=0}^{k-1}\epsilon\_{i}\leq\frac{(1-\rho)(F(x^{0})-F(x^{\*}))}{\rho}$ we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\sum\_{i=0}^{k-1}\frac{F(x^{i+1})-F(x^{\*})}{M\_{i}}\leq\frac{1}{2}\|x^{0}-x^{\*}\|\_{H\_{0}/M\_{0}}^{2}+M\_{H}+\frac{(1-\rho)(F(x^{0})-F(x^{\*}))}{\rho\sigma}+\sum\_{i=0}^{k-1}\frac{\phi\_{i}}{M\_{i}}+D\_{{\cal X}\_{0}}\sum\_{i=0}^{k-1}\sqrt{\frac{2\phi\_{i}}{M\_{i}}}.$ |  |

Hence,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle F(x^{k})-F(x^{\*})$ | $\displaystyle\leq\frac{1}{k\_{m}}\sum\_{i=0}^{k-1}\frac{F(x^{i+1})-F(x^{\*})}{M\_{i}}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leq\frac{1}{k\_{m}}\left(\frac{1}{2}\|x^{0}-x^{\*}\|\_{H\_{0}/M\_{0}}^{2}+M\_{H}+\frac{(1-\rho)(F(x^{0})-F(x^{\*}))}{\rho\sigma}+\sum\_{i=0}^{k-1}\frac{\phi\_{i}}{M\_{i}}+D\_{{\cal X}\_{0}}\sum\_{i=0}^{k-1}\sqrt{\frac{2\phi\_{i}}{M\_{i}}}\right).$ |  |

Let us consider the term $\frac{1}{k\_{m}}=\frac{1}{\sum\_{i=0}^{k-1}M\_{i}^{-1}}$. From earlier discussions, we can see that
$\frac{1}{k\_{m}}\leq\frac{M}{k}$. Moreover, if $H\_{k}$ are diagonal matrices, then $M=L(f)$ and, hence $\frac{1}{k\_{m}}\leq\frac{L(f)}{k}$,
which established a bound similar to that of proximal gradient methods. The role of $M\_{i}$ is to show that if most of these values are much smaller than the global Lipschitz constant $L(f)$, then the constant involved in the sub linear rate can be much smaller than that of the proximal gradient methods.
This is well known effect of using partial second order information and it is observed in our computational results.

We conclude that under Assumption [2](#Thmassumptions2 "Assumption 2 ‣ 3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") converges at the rate of $O(1/k)$ if
$\sum\_{i=0}^{k-1}\sqrt{\frac{2\phi\_{i}}{M\_{i}}}$ is bounded for all $k$. This result in similar to those obtained in [[26](#bib.bib26)].
In [[28](#bib.bib28)] it is shown how randomized block coordinate descent and other methods can be utilized to optimize subproblems
$\min\_{u}Q(H\_{i},u,x^{i})$
so that $\sqrt{\frac{2\phi\_{i}}{M\_{i}}}$ decays sufficiently fast to guarantee such a bound (possibly in expectation).

In this paper, however, we focus on a different derivation of the sub linear convergence rate, which results in a different bound on $\phi\_{k}$
and different, more complex, dependence on the constants, but, on the other hand, does not require Assumption [2](#Thmassumptions2 "Assumption 2 ‣ 3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")
and results in a weaker assumption on $\phi\_{i}$.

## 4 Analysis of sub linear convergence

In our analysis below we will use another known technique for establishing sub linear convergence of gradient descent type methods
on smooth convex functions [[7](#bib.bib7)]. However, due to the non smooth nature of our function the analysis requires significant extensions,
especially in the inexact case. Moreover, it does not apply to the line-search algorithm, we will rely on the fact that a proximal quasi-Newton method is used in that each new iteration $x^{k+1}$ is an approximate minimizer of the function $Q(H\_{k},u,x^{k})$. Our analysis, hence, also applies to proximal gradient methods.

First we prove the following simple result.

###### Lemma 4

Consider $F(\cdot)$ defined in ([1.1](#S1.E1 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")). Let Assumptions [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") hold. Then for any three points $u,v,w\in\dom(F)$, we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle F(u)-F(w)\leq\|\nabla f(u)+\gamma\_{g,\phi}^{v}\|\|u-w\|+2L\_{g}\|u-v\|+2\phi.$ |  | (4.1) |

where $\gamma\_{g,\phi}^{v}\in\partial\_{\phi}g(v)$ is any $\phi$-subgradient of $g(\cdot)$ at point $v$.

Proof. From convexity of $f$ and $g$ and the definition of $\phi$-subgradient, it follows that for any points $u,w$ and $v$,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle f(u)-f(w)$ | $\displaystyle\leq\langle\nabla f(u),u-w\rangle,$ |  | (4.2) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle g(v)-g(w)$ | $\displaystyle\leq\langle\gamma\_{g,\phi}^{v},v-w\rangle+\phi$ |  | (4.3) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle g(2v-u)-g(v)$ | $\displaystyle\geq\langle\gamma\_{g,\phi}^{v},v-u\rangle-\phi.$ |  | (4.4) |

Hence,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle F(u)-F(w)$ | $\displaystyle=f(u)-f(w)+g(u)-g(w)$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=f(u)-f(w)+g(u)-g(v)+g(v)-g(w)$ |  |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\leq\langle\nabla f(u),u-w\rangle+\langle\gamma\_{g,\phi}^{v},v-w\rangle+g(u)-g(v)+\phi$ |  | (4.5) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\langle\nabla f(u),u-w\rangle+\langle\gamma\_{g,\phi}^{v},u-w\rangle+\langle\gamma\_{g,\phi}^{v},v-u\rangle+g(u)-g(v)+\phi$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leq\|\nabla f(u)+\gamma\_{g,\phi}^{v}\|\|u-w\|+g(2v-u)-g(v)+g(u)-g(v)+2\phi.$ |  |

Here we applied ([4.2](#S4.E2 "In 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")), ([4.3](#S4.E3 "In 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"))
and ([4.4](#S4.E4 "In 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) to get
([4.5](#S4.E5 "In 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")).
Using
Assumption [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") to bound the term $g(2v-u)-g(v)+g(u)-g(v)$
we can easily derive ([4.1](#S4.E1 "In Lemma 4 ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")).

### 4.1 The exact case

We now consider the exact version of Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"), i.e., $\phi\_{k}=0$ for all $k$.
We have the following lemma.

###### Lemma 5

Let $x^{k+1}:=\arg\min\_{u\in\mathbb{R}^{n}}Q(H\_{k},u,x\_{k})$, then

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle Q(H\_{k},x^{k},x^{k})-Q(H\_{k},x^{k+1},x^{k})\geq\frac{\sigma\_{k}}{2}\|x^{k+1}-x^{k}\|^{2}.$ |  | (4.6) |

Moreover, there exists a vector $\gamma\_{g}^{k+1}\in\partial g(x^{k+1})$ such that the following bounds hold:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\frac{1}{M\_{k}}\|\nabla f(x^{k})+\gamma\_{g}^{k+1}\|\leq\|x^{k+1}-x^{k}\|\leq\frac{1}{\sigma\_{k}}\|\nabla f(x^{k})+\gamma\_{g}^{k+1}\|.$ |  | (4.7) |

Proof. The proof is a special case of Lemma [7](#Thmtheorem7 "Lemma 7 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"), proved below.

###### Theorem 6

Let Assumptions [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") hold for all $k$.
Then the iterates $\{x^{k}\}$ generated by Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") satisfy

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle F(x^{k})-F^{\*}\leq\frac{2M^{2}(D\_{{\cal X}\_{0}}M+2L\_{g})^{2}}{\rho\sigma^{3}}\frac{1}{k}.$ |  | (4.8) |

Proof. We will denote $F(x^{k})-F^{\*}$ by $\Delta F\_{k}$. Our goal is to bound $\Delta F\_{k}$ from above in terms of $1/k$ which
we will achieve by deriving a lower bound on $\frac{1}{\Delta F\_{k}}$ in terms of $k$.

Let us first show that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $F(x^{k})-F(x^{k+1})=\Delta F\_{k}-\Delta F\_{k+1}\geq c\_{k}\Delta F\_{k}^{2},$ |  | (4.9) |

for some constant $c\_{k}$, which depends on iteration $k$, but will be lower bounded by a uniform constant.

First we will show that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta F\_{k}\leq(D\_{{\cal X}\_{0}}+\frac{2L\_{g}}{\sigma\_{k}})\|\nabla f(x^{k})+\gamma\_{g}^{k+1}\|.$ |  | (4.10) |

This follows simply from ([4.1](#S4.E1 "In Lemma 4 ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) with $u=x^{k},w=x^{\*},v=x^{k+1}$ and $\phi=0$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta F\_{k}=F(x^{k})-F(x^{\*})\leq\|\nabla f(x^{k})+\gamma\_{g}^{k+1}\|\|x^{k}-x^{\*}\|+2L\_{g}\|x^{k}-x^{k+1}\|.$ |  | (4.11) |

Substituting the bounds on $\|x^{k+1}-x^{k}\|$ (cf. ([4.7](#S4.E7 "In Lemma 5 ‣ 4.1 The exact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"))) and $\|x^{k}-x^{\*}\|$ (cf. Assumptions [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"))
in ([4.11](#S4.E11 "In 4.1 The exact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) we get
the desired bound ([4.10](#S4.E10 "In 4.1 The exact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")).

Now we will show that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $F(x^{k})-F(x^{k+1})\geq\frac{\rho\sigma\_{k}}{2M\_{k}^{2}}\|\nabla f(x^{k})+\gamma\_{g}^{k+1}\|^{2}.$ |  | (4.12) |

Indeed $F(x^{k})-F(x^{k+1})\geq\rho(Q(H\_{k},x^{k},x^{k})-Q(H\_{k},x^{k+1},x^{k}))$. And a bound on the reduction in $Q$ can be established by combining ([4.6](#S4.E6 "In Lemma 5 ‣ 4.1 The exact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) and ([4.7](#S4.E7 "In Lemma 5 ‣ 4.1 The exact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")),

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle Q(H\_{k},x^{k},x^{k})-Q(H\_{k},x^{k+1},x^{k})\geq\frac{\sigma\_{k}}{2M\_{k}^{2}}\|\nabla f(x^{k})+\gamma\_{g}^{k+1}\|^{2},$ |  |

Hence, the bound ([4.12](#S4.E12 "In 4.1 The exact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) holds.

Finally, combining the lower bound on $F(x^{k+1})-F(x^{k})$ together with the upper bound on $\Delta F\_{k}^{2}$ we can conclude that

|  |  |  |
| --- | --- | --- |
|  | $F(x^{k+1})-F(x^{k})=\Delta F\_{k+1}-\Delta F\_{k}\geq\frac{\rho\sigma\_{k}}{2M\_{k}^{2}(D\_{{\cal X}\_{0}}+\frac{2L\_{g}}{\sigma\_{k}})^{2}}\Delta F\_{k}^{2},$ |  |

which establishes ([4.28](#S4.E28 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) with $c\_{k}=\frac{\rho\sigma\_{k}^{3}}{2M\_{k}^{2}(D\_{{\cal X}\_{0}}\sigma\_{k}+2L\_{g})^{2}}$.

Dividing both sides of the inequality above by $\Delta F\_{k+1}\Delta F\_{k}$ we have

|  |  |  |
| --- | --- | --- |
|  | $\frac{1}{\Delta F\_{k}}-\frac{1}{\Delta F\_{k+1}}\geq c\_{k}\frac{\Delta F\_{k}}{\Delta F\_{k+1}}\geq c\_{k}.$ |  |

Summing the above expression for $i=0,\ldots,k-1$ we have

|  |  |  |
| --- | --- | --- |
|  | $\frac{1}{\Delta F\_{k}}\geq\sum\_{i=0}^{k-1}c\_{i}+\frac{1}{\Delta F\_{0}}\geq\sum\_{i=0}^{k-1}c\_{i},$ |  |

which finally implies

|  |  |  |
| --- | --- | --- |
|  | $\Delta F\_{k}=F(x^{k})-F^{\*}\leq\frac{1}{\sum\_{i=0}^{k=1}c\_{i}}\leq\frac{2M^{2}(D\_{{\cal X}\_{0}}M+2L\_{g})^{2}}{\rho\sigma^{3}}\frac{1}{k}.$ |  |

Let us note that if $H\_{k}=L(f)I$ for all $k$, as in standard proximal gradient methods, where $L(f)$ is the Lipschitz constant of $\nabla f(x)$, then
the bound becomes

|  |  |  |
| --- | --- | --- |
|  | $F(x^{k})-F^{\*}\leq\frac{2(D\_{{\cal X}\_{0}}L(f)+2L\_{g})^{2}}{\rho L(f)}\frac{1}{k}\approx\frac{2D\_{{\cal X}\_{0}}^{2}L(f)}{k},$ |  |

if $L\_{g}\ll D\_{{\cal X}\_{0}}L(f)$. This bound is similar to $\frac{2\|x^{0}-x^{\*}\|^{2}L(f)}{k}$ established for proximal gradient methods, assuming that $D\_{{\cal X}\_{0}}$ is comparable to
$\|x^{0}-x^{\*}\|$.

### 4.2 The inexact case

We now analyze Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") in the case when the computation of $p\_{H}(v)$ is performed inexactly.
In other words, we consider the version of Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") (and [2](#algorithm2 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) where we compute
$x^{k+1}:=p\_{H\_{k},\phi\_{k}}(x^{k})$ and $\phi\_{k}$ can be positive for any $k$. The analysis is similar to that of the exact case, with a few additional terms that need to be bounded. We begin by extending Lemma [5](#Thmtheorem5 "Lemma 5 ‣ 4.1 The exact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").

###### Lemma 7

Let $x^{k+1}\in\dom(F)$ be such that the inequality $Q(H\_{k},x^{k+1},x^{k})-\min\_{y\in\mathbb{R}^{n}}Q(H\_{k},y,x^{k})\leq\phi\_{k}$ holds
for some $\phi\_{k}\geq 0$. Then

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle Q(H\_{k},x^{k},x^{k})-Q(H\_{k},x^{k+1},x^{k})\geq\frac{\sigma\_{k}}{2}\|x^{k+1}-x^{k}\|^{2}-\sqrt{2M\_{k}\phi\_{k}}\|x^{k+1}-x^{k}\|-\phi\_{k}.$ |  | (4.13) |

Moreover there exists a vector $\gamma\_{g,\phi}^{k+1}\in\partial g\_{\phi\_{k}}(x^{k+1})$ such that the following bounds hold:

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\frac{1}{M\_{k}}\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|-\frac{\sqrt{2M\_{k}\phi\_{k}}}{M\_{k}}\leq\|x^{k+1}-x^{k}\|\leq\frac{1}{\sigma\_{k}}\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|+\frac{\sqrt{2M\_{k}\phi\_{k}}}{\sigma\_{k}}.$ |  | (4.14) |

Proof. Recall Lemma [1](#Thmtheorem1 "Lemma 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"), from ([3.2](#S3.E2 "In Lemma 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")), there
exists a vector, which we will refer to as $\gamma\_{g,\phi}^{k+1}$, such that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\gamma\_{g,\phi}^{k+1}=H\_{k}(x^{k}-x^{k+1})-\nabla f(x^{k})-\eta\_{k}\in\partial\_{\phi}g(x^{k+1}),$ |  | (4.15) |

with $\frac{1}{2}\|\eta\_{k}\|^{2}\_{H\_{k}^{-1}}\leq\phi\_{k}$, which, in turn, implies $\|\eta\_{k}\|\leq\sqrt{2M\_{k}\phi\_{k}}$.
The following inequality follows from the definition of $\phi$-subdifferential,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle g(x^{k})-g(x^{k+1})\geq\langle\gamma\_{g,\phi}^{k+1},x^{k}-x^{k+1}\rangle-\phi\_{k}.$ |  | (4.16) |

From ([4.15](#S4.E15 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"))

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle H\_{k}(x^{k+1}-x^{k})+\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}+\eta\_{k}=0,$ |  | (4.17) |

hence we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\|x^{k+1}-x^{k}\|$ | $\displaystyle\leq\frac{1}{\sigma\_{k}}\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|+\frac{1}{\sigma\_{k}}\|\eta\_{k}\|\leq\frac{1}{\sigma\_{k}}\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|+\frac{\sqrt{2M\_{k}\phi\_{k}}}{\sigma\_{k}},$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\|x^{k+1}-x^{k}\|$ | $\displaystyle\geq\frac{1}{M\_{k}}\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|-\frac{1}{M\_{k}}\|\eta\_{k}\|\geq\frac{1}{M\_{k}}\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|-\frac{\sqrt{2M\_{k}\phi\_{k}}}{M\_{k}}.$ |  |

Using ([4.16](#S4.E16 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) and ([4.17](#S4.E17 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")), we derive ([4.13](#S4.E13 "In Lemma 7 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) as follows,

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle Q(H\_{k},x^{k},x^{k})-Q(H\_{k},x^{k+1},x^{k})$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=g(x^{k})-g(x^{k+1})-\nabla f(x^{k})^{T}(x^{k+1}-x^{k})-\frac{1}{2}\|x^{k+1}-x^{k}\|^{2}\_{H\_{k}}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\geq\langle\gamma\_{g,\phi}^{k+1},x^{k}-x^{k+1}\rangle-\phi\_{k}+\|x^{k+1}-x^{k}\|\_{H\_{K}}^{2}+\langle\gamma\_{g,\phi}^{k+1},x^{k+1}-x^{k}\rangle+\langle\eta\_{k},x^{k+1}-x^{k}\rangle-\frac{1}{2}\|x^{k+1}-x^{k}\|^{2}\_{H\_{k}}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle=\frac{1}{2}\|x^{k+1}-x^{k}\|^{2}\_{H\_{k}}+\langle\eta\_{k},x^{k+1}-x^{k}\rangle-\phi\_{k}\geq\frac{\sigma\_{k}}{2}\|x^{k+1}-x^{k}\|^{2}-\|\eta\_{k}\|\|x^{k+1}-x^{k}\|-\phi\_{k}$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\geq\frac{\sigma\_{k}}{2}\|x^{k+1}-x^{k}\|^{2}-\sqrt{2M\_{k}\phi\_{k}}\|x^{k+1}-x^{k}\|-\phi\_{k}.$ |  |

Unlike the exact case, the inquality
$\frac{1}{\Delta F\_{k+1}}-\frac{1}{\Delta F\_{k}}\geq c\_{k}$ can no longer be guaranteed to hold on each iteration.
The convergence rate is obtained by observing that when this desired inequality fails another inequality always holds, which bounds
$\Delta F\_{k}$ in terms of $\phi\_{k}$. Specifically, we have the following theorem.

###### Lemma 8

Consider $k$th iteration of the inexact Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") with $0\leq\phi\_{k}\leq 1$. Let $\Delta F\_{k}:=F(x^{k})-F(x^{\*})$. Then there exists large enough positive constant $\theta>0$, such that one of the following two cases must hold,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\Delta F\_{k}\leq b\_{k}\sqrt{\phi\_{k}},$ |  | (4.18) |
|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | $\displaystyle\frac{1}{\Delta F\_{k+1}}-\frac{1}{\Delta F\_{k}}\geq c\_{k}.$ |  | (4.19) |

where $b\_{k}$ and $c\_{k}$ are given below,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle b\_{k}=\theta D\_{{\cal X}\_{0}}\sqrt{2M\_{k}}+\frac{2(1+\theta)L\_{g}}{\sigma\_{k}}\sqrt{2M\_{k}}+2,~c\_{k}=\frac{\rho(\sigma\_{k}^{3}(\theta-1)^{2}-2\sigma\_{k}M\_{k}^{2}(1+\theta)-\sigma\_{k}^{3}M\_{k})}{(\sqrt{2}D\_{{\cal X}\_{0}}\theta\sigma\_{k}M\_{k}+2\sqrt{2}L\_{g}(1+\theta)M\_{k}+\sigma\_{k}\sqrt{M\_{k}})^{2}}.$ |  | (4.20) |

Proof. First, applying ([4.1](#S4.E1 "In Lemma 4 ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) with $u=x^{k},w=x^{\*}$ and $v=x^{k+1}$ we obtain,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta F\_{k}=F(x^{k})-F(x^{\*})\leq\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|\|x^{k}-x^{\*}\|+2L\_{g}\|x^{k}-x^{k+1}\|+2\phi\_{k}.$ |  | (4.21) |

We will consider two cases that are possible at each iteration $k$ for some fixed constant $\theta>1$ which we will specify later.

* •

  Case 1

  |  |  |  |  |
  | --- | --- | --- | --- |
  |  | $\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|<\theta\sqrt{2M\_{k}\phi\_{k}}.$ |  | (4.22) |
* •

  Case 2

  |  |  |  |  |
  | --- | --- | --- | --- |
  |  | $\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|\geq\theta\sqrt{2M\_{k}\phi\_{k}}.$ |  | (4.23) |

Let us assume that Case 1 holds, then from ([4.14](#S4.E14 "In Lemma 7 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) and ([4.22](#S4.E22 "In 1st item ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) it simply
follows that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\|x^{k+1}-x^{k}\|\leq\frac{(1+\theta)\sqrt{2M\_{k}\phi\_{k}}}{\sigma\_{k}}.$ |  | (4.24) |

Using ([4.22](#S4.E22 "In 1st item ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")), ([4.21](#S4.E21 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")), the bound on $\|x^{k+1}-x^{k}\|$ from ([4.24](#S4.E24 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) together with the bound on $\|x^{k}-x^{\*}\|$ from Assumptions [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") we get

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle\Delta F\_{k}$ | $\displaystyle\leq D\_{{\cal X}\_{0}}\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|+\frac{2(1+\theta)L\_{g}\sqrt{2M\_{k}\phi\_{k}}}{\sigma\_{k}}+2\phi\_{k}$ |  | (4.25) |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\leq(\theta D\_{{\cal X}\_{0}}+\frac{2(1+\theta)L\_{g}}{\sigma\_{k}})\sqrt{2M\_{k}\phi\_{k}}+2\phi\_{k}\leq(\theta D\_{{\cal X}\_{0}}\sqrt{2M\_{k}}+\frac{2(1+\theta)L\_{g}}{\sigma\_{k}}\sqrt{2M\_{k}}+2)\sqrt{\phi\_{k}},$ |  |

which ensures ([4.18](#S4.E18 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")).

We now consider Case 2, where ([4.23](#S4.E23 "In 2nd item ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) along with ([4.14](#S4.E14 "In Lemma 7 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) from Lemma [7](#Thmtheorem7 "Lemma 7 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") imply

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\frac{\theta-1}{\theta M\_{k}}\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|\leq\|x^{k+1}-x^{k}\|\leq\frac{1+\theta}{\theta\sigma\_{k}}\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|.$ |  | (4.26) |

Substituting into ([4.21](#S4.E21 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) the upper bound on $\|x^{k+1}-x^{k}\|$ from ([4.26](#S4.E26 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) and the bound on $\|x^{k}-x^{\*}\|$ from Assumptions [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") we now get

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\Delta F\_{k}\leq(D\_{{\cal X}\_{0}}+\frac{2L\_{g}(1+\theta)}{\theta\sigma\_{k}})\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|+2\phi\_{k}.$ |  |

From $\phi\_{k}\leq 1$ it follows that $\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|\geq\theta\sqrt{2M\_{k}\phi\_{k}}\geq\theta\sqrt{2M\_{k}}\phi\_{k}$. Hence we obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta F\_{k}\leq(D\_{{\cal X}\_{0}}+\frac{2L\_{g}(1+\theta)}{\theta\sigma\_{k}}+\frac{2}{\theta\sqrt{2M\_{k}}})\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|.$ |  | (4.27) |

We will show that in this case, as in the exact case, we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\Delta F\_{k}-\Delta F\_{k+1}=F(x^{k})-F(x^{k+1})\geq c\_{k}\Delta F\_{k}^{2}$ |  | (4.28) |

for some constant $c\_{k}$ (different from that in the exact case).
Towards that goal we will establish a lower bound on $F(x^{k})-F(x^{k+1})$ in terms of $\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|^{2}$ as before.
We still have $F(x^{k})-F(x^{k+1})\geq\rho(Q(H\_{k},x^{k},x^{k})-Q(H\_{k},x^{k+1},x^{k}))$.
We now use the bounds ([4.13](#S4.E13 "In Lemma 7 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) from Lemma [7](#Thmtheorem7 "Lemma 7 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"), ([4.23](#S4.E23 "In 2nd item ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) and ([4.26](#S4.E26 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) and obtain

|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle Q(H\_{k},x^{k},x^{k})-Q(H\_{k},x^{k+1},x^{k})$ |  |
|  |  |  |  |
| --- | --- | --- | --- |
|  |  | $\displaystyle\geq\frac{\sigma\_{k}}{2}(\frac{\theta-1}{\theta M\_{k}})^{2}\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|^{2}-\frac{1+\theta}{\theta^{2}\sigma\_{k}}\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|^{2}-\frac{1}{2\theta^{2}M\_{k}}\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|^{2}$ |  |

By selecting a sufficiently large $\theta$ we can ensure that

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle F(x^{k})-F(x^{k+1})\geq\rho t\_{k}\|\nabla f(x^{k})+\gamma\_{g,\phi}^{k+1}\|^{2},$ |  | (4.29) |

for $t\_{k}=\frac{\sigma\_{k}}{2}(\frac{\theta-1}{\theta M\_{k}})^{2}-\frac{1+\theta}{\theta^{2}\sigma\_{k}}-\frac{1}{2\theta^{2}M\_{k}}>0$.
Finally, combining the lower bound ([4.29](#S4.E29 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) on $F(x^{k+1})-F(x^{k})$ together with the upper bound ([4.27](#S4.E27 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"))
on $\Delta F\_{k}^{2}$ we can conclude that ([4.28](#S4.E28 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) holds with

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle c\_{k}=\frac{\rho t\_{k}}{(D\_{{\cal X}\_{0}}+\frac{2L\_{g}(1+\theta)}{\theta\sigma\_{k}}+\frac{2}{\theta\sqrt{2M\_{k}}})^{2}}=\frac{\rho(\sigma\_{k}^{3}(\theta-1)^{2}-2\sigma\_{k}M\_{k}^{2}(1+\theta)-\sigma\_{k}^{3}M\_{k})}{(\sqrt{2}D\_{{\cal X}\_{0}}\theta\sigma\_{k}M\_{k}+2\sqrt{2}L\_{g}(1+\theta)M\_{k}+2\sigma\_{k}\sqrt{M\_{k}})^{2}}.$ |  |

Finally, ([4.19](#S4.E19 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) follows from ([4.28](#S4.E28 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) divided by $\Delta F\_{k}\Delta F\_{k+1}$ and using the fact that $\frac{\Delta F\_{k}}{\Delta F\_{k+1}}\geq 1$.

###### Remark 9

Let us discuss the result of the above lemma. The lemma applies for any value of $\theta$ for which
$t\_{k}$, and hence, $c\_{k}$ is positive for all $k$. It is easy to see that large values of $\theta$
imply large values of $c\_{k}$. On the other hand, large $\theta$ is likely to cause Case 1 to hold (i.e., ([4.18](#S4.E18 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")))
instead of Case 2 (i.e., ([4.19](#S4.E19 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"))) on any given iteration, with $b\_{k}$ also growing with the size of $\theta$.
As we will show below the overall rate of convergence of the algorithm is derived using the two bounds - ([4.18](#S4.E18 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")), where
the rate is controlled by the rate of $\phi\_{k}\to 0$ and ([4.19](#S4.E19 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")), which is similar to the bound in the exact case.
The overall bound, thus, will depend on the upper bound on $b\_{k}$’s and the inverse of
the lower bound on $c\_{k}$’s. If, again, we assume that $\sigma\_{k}=M\_{k}=L(f)$ for all $k$, then $\theta=O(\sqrt{L(f)})$ is sufficient to ensure that $c\_{k}>0$
and this results in $b\_{k}\leq O(D\_{{\cal X}\_{0}}L(f))$ and $1/c\_{k}\geq O(D\_{{\cal X}\_{0}}^{2}L(f))$, thus again, we obtain a bound which is comparable to that of proximal gradient methods, although with more complex constants.

We now derive the overall convergence rate, under the assumption that $\phi\_{k}$ decays sufficiently fast.

###### Theorem 10

Suppose that Assumption [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") holds.
Assume that all iterates $\{x^{k}\}$ of inexact Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") are generated with some $\phi\_{k}\geq 0$ that satisfy

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\phi\_{k}\leq\frac{a^{2}}{k^{2}},\mbox{ with }0<a\leq 1.$ |  | (4.30) |

Let $\theta$ be chosen as specified in Lemma [8](#Thmtheorem8 "Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"). Then for any $k$

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle F(x^{k})-F(x^{\*})\leq\frac{\max\{ba,\frac{1}{c}\}}{k-1}$ |  | (4.31) |

with $b,c$ given as follows,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle b=\theta D\_{{\cal X}\_{0}}\sqrt{2M}+\frac{2(1+\theta)L\_{g}}{\sigma}\sqrt{2M}+2,~c=\frac{\rho\left(\frac{\sigma^{2}}{M^{2}}(1-\theta^{-1})^{2}-(2\theta^{-1}+3\theta^{-2})\right)}{2(D\_{{\cal X}\_{0}}+\frac{2L\_{g}(1+\theta^{-1})}{\sqrt{\sigma}}+\frac{2}{\sqrt{2}}\theta^{-1})^{2}}.$ |  | (4.32) |

Proof. Consider all iterations before a particular iteration $k$. From Lemma [8](#Thmtheorem8 "Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"), it follows that either
([4.18](#S4.E18 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) or ([4.19](#S4.E19 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) must hold for each prior iteration.
Let $k\_{1}<k$ denote the index of the last iteration before $k$, for which ([4.18](#S4.E18 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) holds. If no such $k\_{1}$ exists, then ([4.19](#S4.E19 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) holds for all $k$ and without loss of generality we can consider $k\_{1}=0$. From ([4.18](#S4.E18 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) and from the fact that the function value never increases

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta F\_{k\_{1}+1}=F(x^{k\_{1}+1})-F(x^{\*})\leq F(x^{k\_{1}})-F(x^{\*})=\Delta F\_{k\_{1}}\leq b\_{k\_{1}}\sqrt{\phi\_{k\_{1}}k\_{1}}\leq\frac{ab\_{k\_{1}}}{k\_{1}}$ |  | (4.33) |

which is the same as

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\frac{1}{\Delta F\_{k\_{1}+1}}\geq\frac{k\_{1}}{ab\_{k\_{1}}}.$ |  | (4.34) |

For each iteration from $k\_{1}+1$ to $k-1$, ([4.19](#S4.E19 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) gives

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\frac{1}{\Delta F\_{k\_{1}+i+1}}-\frac{1}{\Delta F\_{k\_{1}+i}}\geq c\_{i},~\forall i=1,...,k-k\_{1}-1$ |  |

Summing up the above inequalities and using ([4.34](#S4.E34 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) we obtain the following bound on
$\Delta F\_{k}$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\frac{1}{\Delta F\_{k}}\geq\sum\_{i=1}^{k-k\_{1}-1}c\_{i}+\frac{1}{\Delta F\_{k\_{1}+1}}\geq\sum\_{i=1}^{k-k\_{1}-1}c\_{i}+\frac{k\_{1}}{ab\_{k\_{1}}}.$ |  | (4.35) |

To derive a simple uniform bound on $\Delta F\_{k}$ we will use $b$ and $c$ - uniform upper and lower bounds, respectively, for $b\_{k}$ and $c\_{k}$ given in ([4.20](#S4.E20 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")), i.e., $b\_{k}\leq b$, $c\_{k}\geq c,\forall k\geq k\_{0}$.
From Assumptions [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") we can derive the expressions for $c$ as follows,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle c\_{k}$ | $\displaystyle=\frac{\rho\left(\frac{\sigma\_{k}}{2}(\frac{\theta-1}{\theta M\_{k}})^{2}-\frac{1+\theta}{\theta^{2}\sigma\_{k}}-\frac{1}{2\theta^{2}M\_{k}}\right)}{(D\_{{\cal X}\_{0}}+\frac{2L\_{g}(1+\theta)}{\theta\sigma\_{k}}+\frac{2}{\theta\sqrt{2M\_{k}}})^{2}}\geq\frac{\rho\left(\frac{\sigma}{2}(\frac{\theta-1}{\theta M})^{2}-\frac{1+\theta}{\theta^{2}\sigma}-\frac{1}{2\theta^{2}\sigma}\right)}{(D\_{{\cal X}\_{0}}+\frac{2L\_{g}(1+\theta)}{\theta\sigma}+\frac{2}{\theta\sqrt{2\sigma}})^{2}}\geq\frac{\rho\left(\frac{\sigma^{2}}{2M^{2}}(\frac{\theta-1}{\theta})^{2}-\frac{1+\theta}{\theta^{2}}-\frac{1}{2\theta^{2}}\right)}{(D\_{{\cal X}\_{0}}+\frac{2L\_{g}(1+\theta)}{\theta\sqrt{\sigma}}+\frac{2}{\theta\sqrt{2}})^{2}}$ |  |

Bound $b$ can be obtained in a similar fashion.

Substituting bounds $b$ and $c$ in ([5.5](#S5.E5 "In 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) we get

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\frac{1}{\Delta F\_{k}}\geq(k-k\_{1}-1)c+\frac{k\_{1}}{ab}\geq\min\{c,\frac{1}{ab}\}(k-1),$ |  |

which is the same as ([5.2](#S5.E2 "In Theorem 15 ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")).

###### Remark 11

It follows that the inexact version of Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") has sublinear convergence rate if
$\phi\_{i}\leq a^{2}/i^{2}$ for some $a<1$ and all iterations $i=0,\ldots,k$.
In contrast, the bounds in [[26](#bib.bib26)] and in Section [3.1](#S3.SS1 "3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")
require that $\sum\_{i=0}^{\infty}\sqrt{\phi\_{i}}$ is bounded.
This bound on the overall sequence is clearly
stronger than $\phi\_{i}\leq a^{2}/i^{2}$, since $\sum\_{i=0}^{\infty}\frac{a}{i}=\infty$.
On the other hand, it does not impose any particular requirement on any given iteration, except that
each $\phi\_{i}$ is finite, which our bound on $\phi\_{i}$ is assumed to hold at each iteration, so far.

### 4.3 Complexity in terms of subproblem solver iterations

Let us discuss conditions on the sequence of $\phi\_{i}$ established above and how they can be ensured.
Firstly, let us note that condition $a<1$ in Theorem [10](#Thmtheorem10 "Theorem 10 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") can easily be removed.
We introduced it for the sake of brevity, to ensure that $\phi\_{i}\leq 1$ on each iteration. Clearly, an arbitrarily large $a$ can be used and in that case
$\phi\_{i}\leq 1$ for all $i\geq 1/a$. Moreover, the condition $\phi\_{i}\leq 1$ is only needed to replace $\phi\_{i}$ with $\sqrt{\phi\_{i}}$ in
Lemma [8](#Thmtheorem8 "Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") in inequality ([4.25](#S4.E25 "In 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")). Instead we can use bound ([4.23](#S4.E23 "In 2nd item ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) and
upper bounds on $\nabla f(x^{i})$ and $\gamma^{i+1}\_{g,\phi}$ to replace $\phi\_{k}$ with a constant multiple of $\sqrt{\phi\_{i}}$.
In conclusion, it is sufficient to solve the subproblem on the $i$-th iteration to accuracy $O(1/i^{2})$.

The question now is: what method and what stopping criterion should be used for subproblem optimization, so that sufficient accuracy is achieved
and no excessive computations are performed, in other word, how can we guarantee the bound on $\phi\_{i}$,
while maintaining efficiency of the subproblem optimization?
It is possible to consider terminating
the optimization of the $i$-th subproblem once the duality gap is smaller than the required bound on $\phi\_{i}$.
However, checking duality gap can be computationally very expensive.
Alternatively one can use an algorithm with a known convergence rate.
This way it can be determined apriori how many iterations of such an algorithm should be applied to the $i$-th subproblem to achieve the desired accuracy. In particular, we note that the objective functions in our subproblems are all $\sigma$-strongly convex, so a simple proximal gradient method, or some of its accelerated versions, will enjoy linear convergence rates when applied to these subproblems. Hence, after $i$ iterations of optimizing
$Q\_{i}$, such a method will achieve accuracy $\phi\_{i}$ that decays geometrically, i.e., $\phi\_{i}=C\delta^{i}$, for some constants $C>0$ and $0<\delta<1$, hence
$\sum\_{i=0}^{\infty}\sqrt{\phi\_{i}}$ is bounded. Note that the same property holds for any linearly convergent method, such as the proximal gradient or a semi-smooth Newton method.
Also, it is easy to see that $\phi\_{i}\leq a^{2}/i^{2}$ holds for some $a>0$ for all $i$.
One can also can use FISTA [[2](#bib.bib2)] to optimize $Q\_{i}$ which will ensure
$\phi\_{i}\leq a^{2}/i^{2}$ for some $a>0$ but will not guarantee $\sum\_{i=0}^{\infty}\sqrt{\phi\_{i}}$.
The advantage of using FISTA and its resulting rate is that ist does not depend on the strong convexity constant,
hence the subproblem complexity does
not depend on $\sigma$ - the lower bound on the smallest eigenvalues of the Hessian approximations.
In conclusion, we have the following overall bounds.

###### Theorem 12

Suppose that Assumptions [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") hold and that at the $k$-th iteration of inexact Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")
function $Q(H\_{k},u,x^{k})$ is approximately minimized, to obtain $x^{k+1}$ by applying $l(k)=\alpha k+\beta$ steps of any algorithm which guarantees that
$Q(H\_{k},x^{k+1},x^{k})\leq Q(H\_{k},x^{k},x^{k})$ and whose convergence
rate ensures the error bound $\phi\_{k}\leq a^{2}/(\alpha k+\beta)^{2}$ for some $a>0$. Then accuracy $F(x^{k})-F(x^{\*})\leq\epsilon$ is achieved after at most

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle K=\beta({\frac{\max\{ba,\frac{1}{c}\}}{\epsilon}}+1)+\frac{\alpha}{2}({\frac{\max\{ba,\frac{1}{c}\}}{\epsilon}})({\frac{\max\{ba,\frac{1}{c}\}}{\epsilon}}+1)$ |  | (4.36) |

inner iterations (of the chosen algorithm),
with $b,c$ given in Theorem [10](#Thmtheorem10 "Theorem 10 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").

Proof. A proof follows trivially from Theorem [10](#Thmtheorem10 "Theorem 10 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").

###### Theorem 13

Suppose that Assumptions [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") hold and that at the $k$-th iteration of inexact Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")
function $Q(H\_{k},u,x^{k})$ is approximately minimized, to obtain $x^{k+1}$ by applying $l(k)$ steps of an algorithm, which guarantees that
$Q(H\_{k},x^{k+1},x^{k})\leq Q(H\_{k},x^{k},x^{k})$ and whose convergence
rate ensures the error bound $\phi\_{k}\leq\delta^{l(k)}M\_{Q}$, for some constants $0<\delta<1$ and $M\_{Q}>0$.
Then, by setting $l\_{k}=2log\_{\frac{1}{\delta}}(k)$, accuracy $F(x^{k})-F(x^{\*})\leq\epsilon$ is achieved after at most

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle K=\sum\_{k=0}^{t}2\log\_{\frac{1}{\delta}}(k)\leq 2t\log\_{\frac{1}{\delta}}(t)$ |  | (4.37) |

inner iterations (of the chosen algorithm), with $t=\lceil\frac{\max\{ba,\frac{1}{c}\}}{\epsilon}+1\rceil$
and $b,c$ given in Theorem [10](#Thmtheorem10 "Theorem 10 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").

Proof. A proof follows trivially from Theorem [10](#Thmtheorem10 "Theorem 10 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").

###### Remark 14

The total complexity in terms of the inner iterations should not be viewed as a summary of the whole complexity of Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").
A key step of the algorithm is the computation of $F(x^{k})$ and $\nabla f(x^{k})$ at each iteration. In big data applications this is often the
most extensive step, hence the main complexity is defined by the number of function and gradient computations.
Due to backtracking via proximal parameter update to satisfy sufficient decrease condition,
the number of function and gradient computation may be larger than the number of iterations of
Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"), however,
it does not exceed this number by more than a logarithmic factor. In practice, only several initial iterations contain backtracking steps, hence
Theorem [10](#Thmtheorem10 "Theorem 10 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") provides the bound on the complexity in terms of function and gradient computations.

In the next section we extend our convergence rate results to the case of solving subproblems via randomized coordinate descent, where
$\phi$ is random and hence does not satisfy required bounds on each iteration.

## 5 Analysis of the inexact case under random subproblem accuracy

As we pointed out in the introduction, the most efficient practical approach to subproblem optimization, in the case when $g(x)=\lambda\|x\|\_{1}$, seems to be the coordinate descent method. One iteration of a coordinate descent step can be a lot less expensive
than that of a proximal gradient or a Newton method. In particular, if matrix $H$ is constructed via the
LBFGS approach, then one step of a coordinate decent
method takes a constant number
of operations, $m$ (the memory size of LBFGS, which is typically 10-20).
On the other hand, one step of proximal gradient takes $O(mn)$ operations and Newton method takes $O(nm^{2})$.

Unfortunately, cyclic (Gauss-Seidel) coordinate descent, does not have deterministic complexity bounds, hence it is not possible to know when the work on a particular subproblem can be terminated to guarantee the desired level of accuracy. However, a randomized coordinate descent has probabilistic complexity bounds, which can be used to demonstrate the linear rate of convergence in expectation.

We have the following probabilistic extension of Theorem [10](#Thmtheorem10 "Theorem 10 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").

###### Theorem 15

Suppose that Assumption [1](#Thmassumptions1 "Assumptions 1 ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") holds.
Assume that for all $k$ iterates $\{x^{k}\}$ of inexact Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") are generated with some $\phi\_{k}\geq 0$ that satisfy

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle P\{\phi\_{k}\leq\frac{a^{2}}{k^{2}}\}\geq 1-p,\mbox{ for\ some\ }0<a\leq 1\mbox{ and }0\leq p<1,$ |  | (5.1) |

conditioned on the past.
Let $\theta$, $b$ and $c$ be as specified in Theorem [10](#Thmtheorem10 "Theorem 10 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"). Then for any $k$

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle E(F(x^{k})-F(x^{\*}))\leq\frac{\max\{ba,\frac{1}{c}\}(2-p)}{(1-p)(k-1)}.$ |  | (5.2) |

Proof. As in the proof of Theorem [10](#Thmtheorem10 "Theorem 10 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") consider all iterations before a particular iteration $k$. From Lemma [8](#Thmtheorem8 "Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"), it follows that either ([4.18](#S4.E18 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) or ([4.19](#S4.E19 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) must hold for each prior iteration.
Let $k\_{1}<k$ denote the index of the last iteration before $k$, for which ([4.18](#S4.E18 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) holds. Let $k\_{2}$ denote the index of the second to last such iteration and so on, hence $k\_{i}$ is the index of the last iteration such that there are exactly $i$ iterations between $k\_{i}$ and
$k-1$ for which ([4.18](#S4.E18 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) holds. Without loss of generality we can assume that $k\_{i}$ exists for each $i$, because if it does not - we can set $k\_{i}=0$ and obtain a better bound.
Let us now assume for a given $i$ that $\phi\_{k\_{i}}\leq\frac{a^{2}}{{k\_{i}}^{2}}$ holds, but that $\phi\_{k\_{j}}>\frac{a^{2}}{{k\_{j}}^{2}}$ for all $j=1,\ldots,i-1$ (if $i=1$ we have the case analyzed in the proof of Theorem [10](#Thmtheorem10 "Theorem 10 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")). The analysis in the proof of Theorem [10](#Thmtheorem10 "Theorem 10 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") extends
easily to the case $i>1$ by observing that

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\frac{1}{\Delta F\_{l+1}}-\frac{1}{\Delta F\_{l}}\geq c\_{l}$ |  |

holds for any $k\_{i}+1\leq l\leq k-1$, $l\neq k\_{j},\,j=1\ldots,i-1$, that is all the iterations for which or ([4.18](#S4.E18 "In Lemma 8 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) does not hold.
We also have

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle\frac{1}{\Delta F\_{l+1}}-\frac{1}{\Delta F\_{l}}\geq 0,$ |  |

for $k\_{i}+1\leq l\leq k-1$, $l=k\_{j},\,j=1\ldots,i-1$, simply from the fact that function values never increase.
Summing up the above inequalities and using the fact that $\phi\_{k\_{i}}\leq\frac{a^{2}}{{k\_{i}}^{2}}$ we obtain
$\Delta F\_{k}$,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\frac{1}{\Delta F\_{k}}\geq\sum\_{l=1}^{k-k\_{i}-i}c\_{l}+\frac{k\_{l}}{ab\_{k\_{l}}}\geq(k-k\_{i}-i)c+\frac{k\_{i}}{ab},$ |  | (5.3) |

and finally, we have

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\Delta F\_{k}\leq\frac{\max\{ba,\frac{1}{c}\}}{k-i}.$ |  | (5.4) |

Now, recall that $P\{\phi\_{k\_{i}}\leq\frac{a^{2}}{{k\_{i}}^{2}}\}\geq 1-p$, for any iteration $i$, independently of the other iteration.
This means that the probability that
$\{\phi\_{k\_{i}}\leq\frac{a^{2}}{{k\_{i}}^{2}}\}$ and $\{\phi\_{k\_{j}}>\frac{a^{2}}{{k\_{j}}^{2}}\}$ for all $j=1\ldots,i-1$ is $(1-p)p^{i}$.
This implies

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle E(\Delta F\_{k})\leq\sum\_{i=1}^{k-1}\frac{\max\{ba,\frac{1}{c}\}}{k-i}(1-p)p^{i-1}\leq\frac{\max\{ba,\frac{1}{c}\}(1-p)}{k-1}\sum\_{i=1}^{k-1}(p^{i-1}+\frac{i-1}{k-i}p^{i-1}).$ |  | (5.5) |

To bound the term $\sum\_{i=1}^{k-1}(p^{i-1}+\frac{i-1}{k-i}p^{i-1})$ observe that $\frac{i-1}{k-i}p^{i-1}\leq(i-1)p^{i-1}$ and hence

|  |  |  |
| --- | --- | --- |
|  | $\sum\_{i=1}^{k-1}(p^{i-1}+\frac{i-1}{k-i}p^{i-1})\leq\frac{1}{(1-p)}+\frac{1}{(1-p)^{2}}\leq\frac{2-p}{(1-p)^{2}},$ |  |

which gives us the final bound on the expected error.

We note that the (2-p) factor is the result of an overestimate of the weighted geometric series and a tighter bound should be possible to obtain.

Below we show that randomized coordinate descent can guarantee sufficient accuracy for subproblem solutions and hence maintain the sub linear convergence rate (in expectation) of Algorithm [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"). Moreover, we show in Section [7](#S7 "7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"), that the randomized coordinate descent is as efficient in practice as the cyclic one.

### 5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent

In randomized coordinate descent the model function $Q(\cdot)$ is iteratively minimized over one randomly chosen coordinate, while the others remain fixed.
The method is presented in Algorithm [3](#algorithm3 "In 5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") and is applied for $l$ steps, with $l$ being an input parameter.

Algorithm 3 Randomized Coordinate Descent for optimizing Model Function $Q(H,v,x)$ over $v$: RCD $(Q(H,v,x),x,l)$

```
Set p⁡(x)←xp(x)\leftarrow x;

1
for i=1,2,⋯,li=1,2,\cdots,l do
   
              2
            Choose j∈{1,2,…,n}j\in\{1,2,...,n\} with probability 1n\frac{1}{n};
   
              3
z∗=arg⁡min𝑧​Q​(H,p⁡(x)+z​ej,x)z^{*}=\arg\underset{z}{\min}~Q(H,p(x)+ze_{j},x);
   
              4
p⁡(x)←p⁡(x)+z∗​ejp(x)\leftarrow p(x)+z^{*}e_{j};

5
            Return p⁡(x)p(x).
```

Here we will show how properties of coordinate descent can be used together with the analysis in Section [4](#S4 "4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"). Combination of
coordinate descent with the waker analysis presented in Section [3.1](#S3.SS1 "3.1 Analysis via proximal gradient approach ‣ 3 Basic results, assumptions and preliminary analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") can be found in [[28](#bib.bib28)].

Our analysis is based on Richtarik and Takac’s results on iteration complexity of randomized coordinate descent [[22](#bib.bib22)]. In particular, we make use of Theorem 7 in [[22](#bib.bib22)], which we restate below without proof, while adapting it to our context.

###### Lemma 16

Let $v$ be the initial point and $Q^{\*}:=\min\_{u\in\mathbb{R}^{n}}Q(H,u,v)$. If $v\_{l}$ is the random point generated by applying $l$ randomized coordinate descent steps to a strongly convex function $Q$, then for some constant
we have

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle P\{Q(H,v\_{l},v)-Q^{\*}\geq\phi\}\leq p,$ |  |

as long as

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle i\geq n(1+\mu(H))\log(\frac{Q(H,v,v)-Q^{\*}}{\phi p}),$ |  |

where $\mu(H)$ is a constant that measures conditioning of $H$ along the coordinate directions and in the worst case is at most $M/\sigma$ - the condition
number of $H$.

Let us now state the version of Algorithms [1](#algorithm1 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") and [2](#algorithm2 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") which is close to what implement in practice and
discuss in the following sections and for which the complexity bound can be applied.

Algorithm 4 Proximal Quasi-Newton method using randomized coordinate descent

```
Choose 
0<ρ≤10<\rho\leq 1, a,b>0a,b>0 and x0x^{0};

1
for k=0,1,2,⋯k=0,1,2,\cdots do
   
              2
            Choose 0​<μ¯k,θk>​0,Gk⪰00<\bar{\mu}_{k},\theta_{k}>0,G_{k}\succeq 0.;
   
              3
            Find Hk=Gk+12​μk​IH_{k}=G_{k}+\frac{1}{2\mu_{k}}I and xk+1:=pHk,ϕk​(xk)x^{k+1}:=p_{H_{k},\phi_{k}}(x^{k})
   
              4
            by applying Prox Parameter Update with RCD (μ¯k,Gk,xk,ρ,a,b)(\bar{\mu}_{k},G_{k},x^{k},\rho,a,b).;
```

Algorithm 5 Prox Parameter Update with RCD $(\bar{\mu},G,x,\rho,a,b)$

```
Select 0<β<10<\beta<1 and set μ=μ¯\mu=\bar{\mu};

1
for i=1,2,⋯i=1,2,\cdots do
   
              2
            Define H=G+12​μ​IH=G+\frac{1}{2\mu}I, and compute p​(x):=pH,ϕ​(x)p(x):=p_{H,\phi}(x)
   
              3
            by applying RCD  (Q⁡(H,v,x),x,⌈a​k+b⌉)(Q(H,v,x),x,\lceil ak+b\rceil);
   
              4
            If F⁡(p⁡(x))−F⁡(x)≤ρ⁡(Q⁡(H,p⁡(x),x)−F⁡(x))F(p(x))-F(x)\leq\rho(Q(H,p(x),x)-F(x)), then output HH and p⁡(x)p(x), Exit ;
   
              5
            Else μ=βi​μ¯\mu=\beta^{i}\bar{\mu};
```

The conclusion of Lemma [16](#Thmtheorem16 "Lemma 16 ‣ 5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") in application to Algorithms [3](#algorithm3 "In 5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")-[5](#algorithm5 "In 5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")
is that when applying $l(k)$ steps of randomized coordinate descent
approximately to optimize $Q(H\_{k},u,x^{k})$, $\phi\_{k}\leq M\_{Q}\delta^{l(k)}$, with probability $p$, where
$M\_{Q}$ is an upper bound on $\frac{Q(H\_{k},x^{k},x^{k})-Q(H\_{k},p\_{H}(x^{k}),x^{k})}{p}$ and $\delta=e^{-\frac{1}{n(1+\mu(H\_{k}))}}$.
This, together with Theorem [15](#Thmtheorem15 "Theorem 15 ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") implies that to solve subproblem on iteration $k$ it is sufficient to set
$l(k)=O(n(1+\mu(H))\log(kp/M\_{Q}))$ and the resulting convergence rate will then obey
Theorems [10](#Thmtheorem10 "Theorem 10 ‣ 4.2 The inexact case ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") and [13](#Thmtheorem13 "Theorem 13 ‣ 4.3 Complexity in terms of subproblem solver iterations ‣ 4 Analysis of sub linear convergence ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").
However, it is necessary to know constants $M\_{Q}$
and $\mu(H)$ to be able to construct efficient expression $l(k)$.
In practice, a successful strategy
is to select a slow growing linear function of $k$, $l(k)=ak+b$. This certainly guarantees convergence rate of the outer iteration as in Theorem [15](#Thmtheorem15 "Theorem 15 ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"). In terms of overall rate this gives inferior complexity, however, we believe that the real difference in
terms of the workload appears only in the limit, while in most cases the algorithm successfully terminated before our practical formula $l(k)=ak+b$, described in the next section, significantly exceeds, the theoretical bound $O(n(1+\mu(H))log(kp/M\_{Q}))$ with appropriate constants. Moreover, as noted earlier, the number of function
and gradient evaluations may be the dominant complexity in the big data cases,
hence it may be worthwhile to increase workload of coordinate descent in order to reduce the constants in the bound in
Theorem [15](#Thmtheorem15 "Theorem 15 ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis").

Finally, we note that when using ISTA method for the subproblem, instead of randomized coordinate descent,
the number of inner iteration does not need to depend on the dimension $n$. However,
it depends on $\sigma\_{k}/M\_{k}$ and the cost per iteration is roughly $n$ times bigger than that of coordinate descent (with LBFGS matrices).
Hence the overall complexity of using coordinate descent is better than that of ISTA if $\mu(H\_{k})\ll\sigma\_{k}/M\_{k}$.
This indeed happens often in practical problems, as is discussed in [[22](#bib.bib22)] and other works on coordinate descent.

## 6 Optimization Algorithm

In this section we briefly describe the specifics of the general purpose algorithm that we propose within the framework of Algorithms
[4](#algorithm4 "In 5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"), [5](#algorithm5 "In 5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") and [3](#algorithm3 "In 5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") and that takes advantage of approximate second order information while maintaining low complexity of subproblem optimization steps.
The algorithm is designed to solve problems of the form ([1.1](#S1.E1 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) with $g(x)=\lambda\|x\|\_{1}$, but it does not use any special structure of the smooth part of the objective, $f(x)$.

At iteration $k$ a step $d\_{k}$ is obtained, approximately, as follows

|  |  |  |
| --- | --- | --- |
|  | $d\_{k}=\arg\min\_{d}\{\nabla f(x^{k})^{T}d+d^{T}H\_{k}d+\lambda\|x^{k}+d\|\_{1};\ \mbox{s.t.}~d\_{i}=0,\forall i\in{\cal A}\_{k}\},$ |  |

with $H\_{k}=G\_{k}+\frac{1}{2\mu\_{k}}I$ - a positive definite matrix and ${\cal A}\_{k}$ - a set of coordinates fixed at the current iteration.

The positive definite matrix $G\_{k}$ is computed by a limited memory BFGS approach. In particular,
we use a specific form of Hessian estimate, (see e.g. [[6](#bib.bib6), [19](#bib.bib19)]),

|  |  |  |  |
| --- | --- | --- | --- |
|  | $G\_{k}=\gamma\_{k}I-QRQ^{T}=\gamma\_{k}I-Q\hat{Q}\quad\mbox{with }\hat{Q}=RQ^{T},$ |  | (6.1) |

where $Q$, $\gamma\_{k}$ and $R$ are defined below,

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle Q=\begin{bmatrix}\gamma\_{k}S\_{k}&T\_{k}\end{bmatrix},~R=\begin{bmatrix}\gamma\_{k}S\_{k}^{T}S\_{k}&M\_{k}\\ M\_{k}^{T}&-D\_{k}\end{bmatrix}^{-1},~\gamma\_{k}=\frac{t^{T}\_{k-1}t\_{k-1}}{t^{T}\_{k-1}s\_{k-1}}..$ |  | (6.2) |

Note that there is low-rank structure present in $G\_{k}$, the matrix given by $Q\hat{Q}$, which we can exploit, but $G\_{k}$ itself by definition is always positive definite.
Let $m$ be a small integer which defines the number of latest
BFGS updates that are ”remembered” at any given iteration (we used $10-20$).
Then $S\_{k}$ and $T\_{k}$ are the $p\times m$ matrices with columns defined by vector pairs $\{s\_{i},t\_{i}\}\_{i=k-m}^{k-1}$ that satisfy $s\_{i}^{T}t\_{i}>0,s\_{i}=x^{i+1}-x\_{i}$ and $t\_{i}=\nabla f(x^{i+1})-\nabla f(x^{i})$,
$M\_{k}$ and $D\_{k}$ are the $k\times k$ matrices

|  |  |  |
| --- | --- | --- |
|  | $(M\_{k})\_{i,j}=\begin{cases}s\_{i-1}^{T}t\_{j-1}\quad&\mbox{if }i>j\\ 0\quad&\mbox{otherwise,}\end{cases}\quad D\_{k}=\diag[s^{T}\_{k-m}t\_{k-m},...,s\_{k-1}^{T}t\_{k-1}].$ |  |

The particular choice of $\gamma\_{k}$ is meant to promote well-scaled quasi-Newton steps, so that less time is spent on line search or updating of prox parameter $\mu\_{k}$ [[19](#bib.bib19)]. In fact instead of updating and maintaining $\mu\_{k}$, exactly as described in Algorithm [2](#algorithm2 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") we simply
double $\gamma\_{k}$ in ([6.1](#S6.E1 "In 6 Optimization Algorithm ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) at each backtracking step. This can be viewed as choosing $\mu\_{k}=\infty$ for the first step of backtracking, and $\mu\_{k}=1/(2^{i-1}-1)\gamma\_{k}$ for the $i$-th backtracking step, when $i>1$. As long as $G\_{K}$ in ([6.1](#S6.E1 "In 6 Optimization Algorithm ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")), is positive definite, with smallest eigenvalue bounded by $\sigma>0$, our theory applies to this particular backtracking procedure.

### 6.1 Greedy Active-set Selection $\mathcal{A}\_{k}({\cal I}\_{k})$

An active-set selection strategy maintains a sequence of sets of indices ${\cal A}\_{k}$ that iteratively estimates the optimal active set ${\cal A}^{\*}$ which contains indices of zero entries in the optimal solution $x^{\*}$ of ([1.1](#S1.E1 "In 1 Introduction ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")). We introduce this strategy as a heuristic aiming to improve the efficiency of the implementation and to make it comparable with state-of-the-art methods, which also use active set strategies. A theoretical analysis of the effects of these strategies is a subject of future study.
The complement set of ${\cal A}\_{k}$ is ${\cal I}\_{k}=\{i\in{\cal P}~|~i\notin{\cal A}\_{k}\}$.
Let $(\partial F(x^{k}))\_{i}$ be the $i$-th component of a subgradient of $F(x)$ at $x^{k}$. We define two sets,

|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  | $\displaystyle{\cal I}^{(1)}\_{k}$ | $\displaystyle=\{i\in{\cal P}~|~(\partial F(x^{k}))\_{i}\neq 0\},\ {\cal I}^{(2)}\_{k}=\{i\in{\cal P}~|~(x^{k})\_{i}\neq 0\}.$ |  | (6.3) |

As is done in [[34](#bib.bib34)] and [[11](#bib.bib11)] we select ${\cal I}\_{k}$ to include the entire set ${\cal I}^{(2)}\_{k}$ and the entire set ${\cal I}^{(1)}\_{k}$. We also tested a strategy which includes only a small subset of indices from ${\cal I}^{(1)}\_{k}$ for which the corresponding elements $|(\partial F(x^{k}))\_{i}|$ are the largest. This strategy resulted in a smaller size of subproblems ([6](#S6.Ex1 "6 Optimization Algorithm ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) at the early stages of the algorithm, but did not appear to improve the overall performance of the algorithm.

### 6.2 Solving the inner problem via coordinate descent

We apply coordinate descent method to the piecewise quadratic subproblem ([6](#S6.Ex1 "6 Optimization Algorithm ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) to obtain the direction $d\_{k}$ and exploit the special structure of $H\_{k}$.
Suppose $j$-th coordinate in $d$ is updated, hence $d^{\prime}=d+ze\_{j}$ ($e\_{j}$ is the $j$-th vector of the identity). Then $z$ is obtained by solving the following one-dimensional problem

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\min\_{z}$ | $\displaystyle(H\_{k})\_{jj}z^{2}+((\nabla f(x^{k}))\_{j}+(2H\_{k}d)\_{j})z+\lambda|(x^{k})\_{j}+d\_{j}+z|,$ |  |

which has a simple closed-form solution [[8](#bib.bib8), [11](#bib.bib11)].

The most costly step of an iteration of the coordinate descent method is computing or maintaining vector $H\_{k}d$. Naively, or in the case of general $H\_{k}$, this step takes $O(n)$ flops, since the vector needs to be updated at the end of each iteration, when one of the coordinates of vector $d$ changes. The special form of $G\_{k}$ in $H\_{k}=G\_{k}+\frac{1}{\mu}I=\gamma\_{k}I-Q\hat{Q}$ gives us an opportunity to accelerate this step, reducing the complexity from problem-dependent $O(n)$ to $O(m)$ with $m$ chosen as a small constant. In particular we only store the diagonal elements of $G\_{k}$, $(G\_{k})\_{ii}=\gamma\_{k}-q\_{i}^{T}\hat{q}\_{i}$, where $q\_{i}$ is the $i$th row of the matrix $Q$ and $\hat{q}\_{i}$ is the $i$th column vector of the matrix $\hat{Q}$. We compute $(G\_{k}d)\_{i}$, whenever it is needed, by
maintaining a $2m$ dimensional vector $v:=\hat{Q}d$,
which takes $O(2m)$ flops, and using $(G\_{k}d)\_{i}=\gamma\_{k}d\_{i}-q\_{i}^{T}v$.
After each coordinate step $v$ is updated by $v\leftarrow v+z\_{i}\hat{q}\_{i}$, which costs $O(m)$. We also need to use extra memory for caching $\hat{Q}$ and $\hat{d}$ which takes $O(2mp+2m)$ space. With the other $O(2p+2mn)$ space for storing the diagonal of $G\_{k}$, $Q$ and $d$, altogether we need $O(4mp+2n+2m)$ space, which is essentially $O(4mn)$ when $n\gg m$.

## 7 Computational experiments

The aim of this section is to provide validation for our general purpose algorithm, but not to conduct extensive comparison of various inexact proximal Newton approaches.
In particular, we aim to demonstrate a) that using the exact Hessian is not necessary in these methods, b) that backtracking using prox parameter, based on sufficient decrease condition, which our theory uses, does in fact work well in practice and c) that randomized coordinate descent is at least as effective as the cyclic one, which is standardly used by other methods.

LHAC, for Low rank Hessian Approximation in Active-set Coordinate descent, is a C/C++ package that implements Algorithms [3](#algorithm3 "In 5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")-[4](#algorithm4 "In 5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") for solving general $\ell\_{1}$ regularization problems. We conduct experiments on two of the most well-known $\ell\_{1}$ regularized models – Sparse Inverse Covariance Selection (SICS) and Sparse Logistic Regression (SLR). The following two specialized C/C++ solvers are included in our comparisons:

* •

  QUIC: the quadratic inverse covariance algorithm for solving SICS described in [[11](#bib.bib11)].
* •

  LIBLINEAR: an improved version of GLMNET for solving SLR described in [[10](#bib.bib10), [34](#bib.bib34)].

Note that both of these packages have been shown to be the state-of-the-art solvers in their respective categories (see e.g. [[34](#bib.bib34), [33](#bib.bib33), [11](#bib.bib11), [20](#bib.bib20)]).

Both QUIC and LIBLINEAR adopt line search to ensure function reduction. We have implemented line search in LHAC as well to see how it compares to the updating of prox parameter proposed in Algorithm [2](#algorithm2 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"). In all the experiments presented below use the following notation.

* •

  LHAC: Algorithm [4](#algorithm4 "In 5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") with backtracking on prox parameter.
* •

  LHAC-L: Algorithm [4](#algorithm4 "In 5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") with Armijo line search procedure described below in ([7.4](#S7.E4 "In 7.1 Experimental Settings ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")).

### 7.1 Experimental Settings

For all of the experiments we choose the initial point $x\_{0}=\mathbf{0}$, and we report running time results in seconds, plotted against log-scale relative objective function decrease given by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\log(\frac{F(x)-F^{\*}}{F^{\*}}),$ |  | (7.1) |

where $F^{\*}$ is the optimal function value. Since $F^{\*}$ is not available, we compute an approximation by setting a small optimality tolerance, specifically $10^{-7}$, in QUIC and LIBLINEAR. All the experiments are executed through the MATLAB mex interface.
We also modify the source code of LIBLINEAR in both its optimization routine and mex gateway function to obtain the records of function values and the running time. We note that we simply store, in a double array, and pass the function values which the algorithm already computes, so this adds little to nothing to LIBLINEAR’s computational costs. We also adds a function call of *clock()* at every iteration to all the tested algorithms, except QUIC, which includes a “trace” mode that returns automatically the track of function values and running time, by calling *clock()* iteratively. For both QUIC and LIBLINEAR we downloaded the latest versions of the publicly available source code from their official websites, compiled and built the software on the machine on which all experiments were executed, and which uses 2.4GHz quad-core Intel Core i7 processor, 16G RAM and Mac OS.

The optimal objective values $F^{\*}$ obtained approximately by QUIC and LIBLINEAR are later plugged in LHAC and LHAC-L to terminate the algorithm when the following condition is satisfied

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\frac{F(x)-F^{\*}}{F^{\*}}\leq 10^{-8}.$ |  | (7.2) |

In LHAC we chose $\bar{\mu}=1,\beta=1/2$ and $\rho=0.01$ for sufficient decrease (see Algorithm [5](#algorithm5 "In 5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")), and for LBFGS we use $m=10$.

When solving the subproblems, we terminate the RCD procedure whenever the number of coordinate steps exceeds

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle(1+\lfloor\frac{k}{m}\rfloor)|{\cal I}\_{k}|,$ |  | (7.3) |

where $|{\cal I}\_{k}|$ denotes the number of coordinates in the current working set. Condition ([7.3](#S7.E3 "In 7.1 Experimental Settings ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) indicates that we expect to update each coordinate in ${\cal I}\_{k}$ only once when $k<m$, and that when $k>m$ we increase the number of expected passes through ${\cal I}\_{l}$ by 1 every $m$ iterations, i.e., after LBFGS receives a full update. The idea is not only to avoid spending too much time on the subproblem especially at the beginning of the algorithm when the Hessian approximations computed by LBFGS are often fairly coarse, but also to solve the subproblem more accurately as the iterate moves closer to the optimality. Note that in practice when $|{\cal I}\_{k}|$ is large, the value of ([7.3](#S7.E3 "In 7.1 Experimental Settings ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) almost always dominates $k$, hence it can be lower bounded by $l(k)=ak+b$ with some reasonably large values of $a$ and $b$, which, as we analyzed in Section [5.1](#S5.SS1 "5.1 Analysis of Subproblem Optimization via Randomized Coordinate Descent ‣ 5 Analysis of the inexact case under random subproblem accuracy ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"), guarantees the sub linear convergence rate. We also find that ([7.3](#S7.E3 "In 7.1 Experimental Settings ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")) works quite well in practice in preventing from “over-solving” the subproblems, particularly for LBFGS type algorithms. In Figures [2](#S7.F2 "Figure 2 ‣ 7.2 Sparse Inverse Covariance Selection ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") we plot the data with respect to the number of RCD iterations. In particular Figures [2(a)](#S7.F2.sf1 "In Figure 2 ‣ 7.2 Sparse Inverse Covariance Selection ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") and [2(c)](#S7.F2.sf3 "In Figure 2 ‣ 7.2 Sparse Inverse Covariance Selection ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") show the number of RCD steps taken at the $k$-th iteration, as a function of $k$. Figures [2(b)](#S7.F2.sf2 "In Figure 2 ‣ 7.2 Sparse Inverse Covariance Selection ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") and [2(d)](#S7.F2.sf4 "In Figure 2 ‣ 7.2 Sparse Inverse Covariance Selection ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") show convergence of the objective function to its optimal value as a function of the total number of RCD steps taken so far (both values are plotted in logarithmic scale). Note that RCD steps are not the only component of the CPU time of the algorithms, since gradient computation has to be performed at least once per iteration.

In LHAC-L, a line search procedure is employed, as is done in QUIC and LIBLINEAR, for the convergence to follow from the framework by [[30](#bib.bib30)]. In particular, the Armijo rule chooses the step size $\alpha\_{k}$ to be the largest element from $\{\beta^{0},\beta^{1},\beta^{2},...\}$ satisfying

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle F(x\_{k}+\alpha\_{k}d\_{k})\leq F(x\_{k})+\alpha\_{k}\sigma\Delta\_{k},$ |  | (7.4) |

where $0<\beta<1,0<\sigma<1$, and $\Delta\_{k}:=\nabla f\_{k}^{T}d\_{k}+\lambda\|x\_{k}+d\_{k}\|\_{1}-\lambda\|x\_{k}\|\_{1}$. In all the experiments we chose $\beta=0.5,\sigma=0.001$ for LHAC-L.

### 7.2 Sparse Inverse Covariance Selection

(a) $S:1255\times 1255$

(b)  $S:1869\times 1869$

(c)  $S:692\times 692$

(d)  $S:834\times 834$

Figure 1:  Convergence plots on SICS (the y-axes on log scale).

(a) The number of coordinate descent steps on subproblems w.r.t. outer iteration.

(b)  Both axes are in log scale. Change of objective w.r.t. the number of coordinate descent steps.

(c) The number of coordinate descent steps on subproblems w.r.t. outer iteration.

(d)  Both axes are in log scale. Change of objective w.r.t. the number of coordinate descent steps.

Figure 2:  RCD step count of LHAC on different SLR and SICS data sets.

The sparse inverse covariance selection problem is defined by

|  |  |  |  |
| --- | --- | --- | --- |
|  | $\displaystyle\min\_{X\succ 0}\quad F(X)=-\log\det X+\tr(SX)+\lambda||X||\_{1},$ |  | (7.5) |

where the input $S\in\mathbb{R}^{p\times p}$ is the sample covariance matrix and the optimization is over a symmetric matrix $X\in\mathbb{R}^{p\times p}$ that is required to be positive definite.

For SICS we report results on four real world data sets, denoted as *ER\_692*, *Arabidopsis*, *Leukemia* and *hereditarybc*, which are preprocessed from breast cancer data and gene expression networks. We refer to [[15](#bib.bib15)] for detailed information about those data sets.

We set the regularization parameter $\lambda=0.5$ for all experiments as suggested in [[15](#bib.bib15)].
The plots presented in Figure [1](#S7.F1 "Figure 1 ‣ 7.2 Sparse Inverse Covariance Selection ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") show that LHAC and LHAC-L is almost twice as fast as QUIC, in the two largest data sets Leukemia and hereditarybc (see Figure [1(c)](#S7.F1.sf3 "In Figure 1 ‣ 7.2 Sparse Inverse Covariance Selection ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") and [1(d)](#S7.F1.sf4 "In Figure 1 ‣ 7.2 Sparse Inverse Covariance Selection ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis")). In the other two smaller data sets the results are less clear-cut, but all of the methods solve the problems very fast and the performance of LHAC is comparable to that of QUIC. The performances of LHAC and LHAC-L are fairly similar in all experiments. Again we should note that with the sufficient decrease condition proposed in Algorithm [2](#algorithm2 "In 2 Basic algorithmic framework and theoretical analysis ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis") we are able to establish the global convergence rate, which has not been shown in the case of Armijo line search.

### 7.3 Sparse Logistic Regression

(a)  a9a ($123,32561$)

(b)  slices ($385,53500$)

(c)  gisette ($5000,6000$)

(d) epsilon ($2000,1e^{5}$)

Figure 3:  Convergence plots on SLR. The y-axes is on log scale. Two numbers in parenthesis are features $p$ and sample size $N$.

The objective function of sparse logistic regression is given by

|  |  |  |
| --- | --- | --- |
|  | $\displaystyle F(w)=\lambda\|w\|\_{1}+\frac{1}{N}\sum\_{n=1}^{N}\log(1+\exp(-y\_{n}\cdot w^{T}x\_{n})),$ |  |

where $L(w)=\frac{1}{N}\sum\_{n=1}^{N}\log(1+\exp(-y\_{n}\cdot w^{T}x\_{n}))$ is the
average logistic loss function and $\{(x\_{n},y\_{n})\}^{N}\_{n=1}\in(\mathbb{R}^{p}\times\{-1,1\})$ is the training set. The number of instances in the training set and the number of features are denoted by $N$ and $p$ respectively. Note that the evaluation of $F$ requires $O(pN)$ flops and to compute the Hessian requires $O(Np^{2})$ flops. Hence, we chose such training sets for our experiment with $N$ and $p$ large enough to test the scalability of the algorithms and yet small enough to be completed on a workstation.

We report results of SLR on four data sets downloaded from UCI Machine Learning repository [[1](#bib.bib1)], whose statistics are summarized in Table [1](#S7.T1 "Table 1 ‣ 7.3 Sparse Logistic Regression ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"). In particular, the first data set is the well-known UCI Adult benchmark set *a9a* used for income classification, determining whether a person makes over $50K/yr or not, based on census data; the second one we use in the experiments is called *epsilon*, an artificial data set for PASCAL large scale learning challenge in 2008;
the third one, *slices*, contains features extracted from CT images and is often used for predicting the relative location of CT slices on the human body; and finally we consider *gisette*, a handwritten digit recognition problem from NIPS 2003 feature selection challenge, with the feature set of size 5000 constructed in order to discriminate between two confusable handwritten digits: the four and the nine.

| Data set | #features $p$ | #instances $N$ | #non-zeros | Description |
| --- | --- | --- | --- | --- |
| a9a | $123$ | $32561$ | $451592$ | ‘census Income’ dataset. |
| epsilon | $2000$ | $100000$ | $200000000$ | PASCAL challenge 2008. |
| gisette | $5000$ | $6000$ | $29729997$ | handwritten digit recognition. |
| slices | $385$ | $53500$ | $20597500$ | CT slices location prediction. |

Table 1:  Data statistics in sparse logistic regression experiments.

The results are shown in Figure [3](#S7.F3 "Figure 3 ‣ 7.3 Sparse Logistic Regression ‣ 7 Computational experiments ‣ Practical Inexact Proximal Quasi-Newton Method with Global Complexity Analysis"). In most cases LHAC and LHAC-L outperform LIBLINEAR.
On data set *slice*, LIBLINEAR experiences difficulty in convergence which results in LHAC being faster by an order of magnitude.
On the largest data set *epsilon*, LHAC and LHAC-L is faster than LIBLINEAR by about one third and reaches the same precision. Finally we note that the memory usage of LIBLINEAR is more than doubled compared to that of LHAC and LHAC-L, as we observed in all the experiments and is particularly notable on the largest data set *epsilon*.

## 8 Conclusion

In this paper we presented analysis of global convergence rate of inexact proximal quasi-Newton framework, and showed that randomized coordinate descent, among other subproblem methods, can be used effectively to find inexact quasi-Newton directions, which guarantee sub linear convergence rate of the algorithm, in expectation. This is the first global convergence rate result for an algorithm that uses coordinate descent to inexactly optimize subproblems at each iteration. Moreover, we improve upon results for inexact proximal gradient method in [[26](#bib.bib26)] in that our requirements on the error in subproblem solution are
weaker and the resulting bound on the total number of inner solver iterations is smaller.

Our framework does not rely on or exploit the accuracy of second order information, and hence we do not obtain fast local convergence rates. We also do not assume strong convexity of our objective function, hence a sublinear conference rate is the best global rate we can hope to obtain. In [[12](#bib.bib12)] an accelerated scheme related to our framework is studied and an optimal sublinear convergence rate is shown, but the assumptions on the Hessian approximations are a lot stronger in [[12](#bib.bib12)] than in our paper, hence the accelerated method is not as widely applicable. The framework studied by us in this paper covers several existing efficient algorithms for large scale sparse optimization. However, to provide convergence rates we had to depart from some standard techniques, such as line-search, replacing it instead by a prox-parameter updating mechanism with a trust-region-like sufficient decrease condition for acceptance of iterates. We also use randomized coordinate descent instead of a cyclic one. We demonstrated that this modified framework is, nevertheless, very effective in practice and is competitive with state-of-the-art specialized methods.
