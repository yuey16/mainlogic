<!-- fulltext source=jmlr slug=doi-10.5555_1577069.1755842 fetched=2026-09-18T06:29:46+00:00 -->

Journal of Machine Learning Research 10 (2009) 1737-1754 

Submitted 1/09; Revised 4/09; Published 7/09 

# **SGD-QN: Careful Quasi-Newton Stochastic Gradient Descent** 

### **Antoine Bordes**<sup>∗</sup> 

ANTOINE.BORDES@LIP6.FR 

_LIP6, Université Pierre et Marie Curie 104, Avenue du Président Kennedy 75016 Paris, France_ 

### **Léon Bottou** 

LEONB@NEC-LABS.COM 

_NEC Laboratories America, Inc. 4 Independence Way Princeton, NJ 08540, USA_ 

### **Patrick Gallinari** 

PATRICK.GALLINARI@LIP6.FR 

_LIP6, Université Pierre et Marie Curie 104, Avenue du Président Kennedy 75016 Paris, France_ 

**Editors:** Soeren Sonnenburg, Vojtech Franc, Elad Yom-Tov and Michele Sebag 

## **Abstract** 

The SGD-QN algorithm is a stochastic gradient descent algorithm that makes careful use of secondorder information and splits the parameter update into independently scheduled components. Thanks to this design, SGD-QN iterates nearly as fast as a first-order stochastic gradient descent but requires less iterations to achieve the same accuracy. This algorithm won the “Wild Track” of the first PASCAL Large Scale Learning Challenge (Sonnenburg et al., 2008). **Keywords:** support vector machine, stochastic gradient descent 

## **1. Introduction** 

The last decades have seen a massive increase of data quantities. In various domains such as biology, networking, or information retrieval, fast classification methods able to scale on millions of training instances are needed. Real-world applications demand learning algorithms with low time and memory requirements. The first PASCAL Large Scale Learning Challenge (Sonnenburg et al., 2008) was designed to identify which machine learning techniques best address these new concerns. A generic evaluation framework and various data sets have been provided. Evaluations were carried out on the basis of various performance curves such as training time versus test error, data set size versus test error, and data set size versus training time.<sup>1</sup> 

Our entry in this competition, named SGD-QN , is a carefully designed _Stochastic Gradient Descent_ (SGD) for _linear Support Vector Machines_ (SVM). 

Nonlinear models could in fact reach much better generalization performance on most of the proposed data sets. Unfortunately, even in the Wild Track case, the evaluation criteria for the competition reward good scaling properties and short training durations more than they punish suboptimal test errors. Nearly all the competitors chose to implement linear models in order to avoid the 

> ∗. Also at NEC Laboratories America, Inc. 

> 1. This material and its documentation can be found at `http://largescale.first.fraunhofer.de/` . 

⃝c 2009 Antoine Bordes, Léon Bottou and Patrick Gallinari. 

BORDES, BOTTOU AND GALLINARI 

additional penalty implied by nonlinearities. Although SGD-QN can work on nonlinear models,<sup>2</sup> we only report its performance in the context of linear SVMs. 

Stochastic algorithms are known for their poor optimization performance. However, in the large scale setup, when the bottleneck is the computing time rather than the number of training examples, Bottou and Bousquet (2008) have shown that stochastic algorithms often yield the best generalization performances in spite of being worst optimizers. SGD algorithms were therefore a natural choice for the “Wild Track” of the competition which focuses on the relation between training time and test performance. 

SGD algorithms have been the object of a number of recent works. Bottou (2007) and ShalevShwartz et al. (2007) demonstrate that the plain Stochastic Gradient Descent yields particularly effective algorithms when the input patterns are very sparse, taking less than _O_ ( _d_ ) space and time per iteration to optimize a system with _d_ parameters. It can greatly outperform sophisticated batch methods on large data sets but suffers from slow convergence rates especially on ill-conditioned problems. Various remedies have been proposed: _Stochastic Meta-Descent_ (Schraudolph, 1999) heuristically determines a learning rate for each coefficient of the parameter vector. Although it can solve some ill-conditioning issues, it does not help much for linear SVMs. _Natural Gradient Descent_ (Amari et al., 2000) replaces the learning rate by the inverse of the Riemannian metric tensor. This quasi-Newton stochastic method is statistically efficient but is penalized in practice by the cost of storing and manipulating the metric tensor. _Online BFGS_ (oBFGS) and _Online Limited storage BFGS_ (oLBFGS) (Schraudolph et al., 2007) are stochastic adaptations of the Broyden-FletcherGoldfarb-Shanno (BFGS) optimization algorithm. The limited storage version of this algorithm is a quasi-Newton stochastic method whose cost by iteration is a small multiple of the cost of a standard SGD iteration. Unfortunately this penalty is often bigger than the gains associated with the quasiNewton update. _Online Dual Solvers_ for SVMs (Bordes et al., 2005; Hsieh et al., 2008) have also shown good performance on large scale data sets. These solvers can be applied to both linear and nonlinear SVMs. In the linear case, these dual algorithms are surprising close to SGD but do not require fiddling with learning rates. Although this is often viewed as an advantage, we feel that this aspect restricts the improvement opportunities. 

The contributions of this paper are twofold: 

1. We conduct an analysis of different factors, ranging from algorithmic refinements to implementation details, which can affect the learning speed of SGD algorithms. 

2. We present a novel algorithm, denoted SGD-QN , that carefully exploits these speedup opportunities. We empirically validate its properties by benchmarking it against state-of-the-art SGD solvers and by summarizing its results at the PASCAL Large Scale Learning Challenge (Sonnenburg et al., 2008). 

The paper is organized as follows: Section 2 analyses the potential gains of quasi-Newton techniques for SGD algorithms. Sections 3 and 4 discuss the sparsity and implementation issues. Finally Section 5 presents the SGD-QN algorithm, and Section 6 reports experimental results. 

> 2. Stochastic gradient works well in models with nonlinear parametrization. For SVMs with nonlinear kernels, we would prefer dual methods, (e.g., Bordes et al., 2005), which can exploit the sparsity of the kernel expansion. 

1738 

SGD-QN 

## **2. Analysis** 

This section describes our notations and summarizes theoretical results that are relevant to the design of a fast variant of stochastic gradient algorithms. 

### **2.1 SGD for Linear SVMs** 

Consider a binary classification problem with examples _z_ = ( **x** , _y_ ) ∈ R<sup>_d_</sup> × {−1, +1}. The linear SVM classifier is obtained by minimizing the primal cost function 



where the hyper-parameter λ > 0 controls the strength of the regularization term. Although typical SVMs use mildly non regular convex loss functions, we assume in this paper that the loss ℓ( _s_ ) is convex and twice differentiable with continuous derivatives (ℓ ∈ _C_<sup>2</sup> [R]). This could be simply achieved by smoothing the traditional loss functions in the vicinity of their non regular points. 

Each iteration of the SGD algorithm consists of drawing a random training example ( **x** _t_ , _yt_ ) and computing a new value of the parameter **w** _t_ as 



where the _rescaling matrix_ **B** is positive definite. Since the SVM theory provides simple bounds on the norm of the optimal parameter vector (Shalev-Shwartz et al., 2007), the positive constant _t_ 0 is heuristically chosen to ensure that the first few updates do not produce a parameter with an implausibly large norm. 

- The traditional first-order SGD algorithm, with decreasing learning rate, is obtained by setting **B** = λ<sup>−1</sup> **I** in the generic update (2) : 



- The second-order SGD algorithm is obtained by setting **B** to the inverse of the Hessian Matrix **H** = [ _Pn_<sup>′′(</sup><sup>**w**</sup> _n_<sup>∗)] computed at the optimum</sup><sup>**w**∗</sup> _n_<sup>of the primal cost</sup><sup>_Pn_(</sup><sup>**w**) :</sup> 



Randomly picking examples could lead to expensive random accesses to the slow memory. In practice, one simply performs sequential passes over the randomly shuffled training set. 

### **2.2 What Matters Are the Constant Factors** 

Bottou and Bousquet (2008) characterize the asymptotic learning properties of stochastic gradient algorithms in the _large scale regime_ , that is, when the bottleneck is the computing time rather than the number of training examples. 

The first three columns of Table 2.2 report the time for a single iteration, the number of iterations needed to reach a predefined accuracy ρ , and their product, the time needed to reach accuracy ρ . 

1739 

BORDES, BOTTOU AND GALLINARI 

|**Stochastic Gradient**|**Cost of one**|**Iterations**|**Time to reach**|**Time to reach**|
|---|---|---|---|---|
|**Algorithm**|**iteration**|**to reach**ρ|**accuracy**ρ|_E_ ≤_c_(_E_app+ε)|
|1<sup>_st_ </sup>Order SGD|_O_(_d_)|νκ<sup>2</sup><br>ρ <sup>+o</sup><br>�<br>1<br>ρ<br>�|_O_<br>�<br>_d_νκ<sup>2</sup><br>ρ<br>�|_O_<br>�<br>_d_νκ<sup>2</sup><br>ε<br>�|
|2<sup>_nd_ </sup>Order SGD|_O_<br>�<br>_d_<sup>2�</sup>|ν<br>ρ <sup>+o</sup><br>�<br>1<br>ρ<br>�|_O_<br>�<br>_d_<sup>2</sup>ν<br>ρ<br>�|_O_<br>�<br>_d_<sup>2 </sup>ν<br>ε<br>�|



- Table 1: Asymptotic results for stochastic gradient algorithms, reproduced from Bottou and Bousquet (2008). Compare the second last column (time to optimize) with the last column (time to reach the excess test error ε ). _Legend_ : _n_ number of examples; _d_ parameter dimension; _c_ positive constant that appears in the generalization bounds; κ condition number of the Hessian matrix **H** ; ν = **tr** � **GH**<sup>−1�</sup> with **G** the Fisher matrix (see Theorem 1 for more details). The implicit proportionality coefficients in notations _O_ () and o() are of course independent of these quantities. 

The excess test error _E_ measures how much the test error is worse than the best possible error for this problem. Bottou and Bousquet (2008) decompose the test error as the sum of three terms _E_ = _E_ app + _E_ est + _E_ opt. The _approximation error E_ app measures how closely the chosen family of functions can approximate the optimal solution, the _estimation error E_ est measures the effect of minimizing the empirical risk instead of the expected risk, the _optimization error E_ opt measures the impact of the approximate optimization on the generalization performance. 

The fourth column of Table 2.2 gives the time necessary to reduce the excess test error _E_ below a target that depends on ε > 0. This is the important metric because the test error is the measure that matters in machine learning. 

Both the first-order and the second-order SGD require a time inversely proportional to ε to reach the target test error. Only the constants differ. The second-order algorithm is insensitive to the condition number κ of the Hessian matrix but suffers from a penalty proportional to the dimension _d_ of the parameter vector. Therefore, algorithmic changes that exploit the second-order information in SGD algorithms are unlikely to yield superlinear speedups. We can at best improve the constant factors. 

This property is not limited to SGD algorithms. To reach an excess error ε , the most favorable generalization bounds suggest that one needs a number of examples proportional to 1/ ε . Therefore, the time complexity of any algorithm that processes a non vanishing fraction of these examples cannot scale better than 1/ ε . In fact, Bottou and Bousquet (2008) obtain slightly worse scaling laws for typical non-stochastic gradient algorithms. 

### **2.3 Limited Storage Approximations of Second-Order SGD** 

Since the second-order SGD algorithm is penalized by the high cost of performing the update (2) using a full rescaling matrix **B** = **H**<sup>−1</sup> , it is tempting to consider matrices that admit a sparse representation and yet approximate the inverse Hessian well enough to reduce the negative impact of the condition number κ . 

The following theorem describes how the convergence speed of the generic SGD algorithm (2) is related to the spectrum of matrix **HB** . 

1740 

SGD-QN 

**Theorem 1** _Let_ E σ _denote the expectation with respect to the random selection of the examples_ ( **x** _t_ , _yt_ ) _drawn independently from the training set at each iteration. Let_ **w**<sup>∗</sup> _n_<sup>= argmin</sup> **w**<sup>_Pn_(</sup><sup>**w**)</sup><sup>_be an_</sup> _optimum of the primal cost. Define the Hessian matrix_ **H** = ∂<sup>2</sup> _Pn_ ( **w** _n_<sup>∗)/∂</sup><sup>**w**2</sup><sup>_and the Fisher matrix_</sup> **G** = **G** _t_ = E σ � **g** _t_<sup>′(</sup><sup>**w**</sup> _n_<sup>∗)</sup><sup>**g**</sup> _t_<sup>′(</sup><sup>**w**∗</sup> _n_<sup>)⊤�</sup> _. If the eigenvalues of_ **HB** _are in range_ λ max ≥ λ min > 1/2 _, and if the SGD algorithm_ (2) _converges to_ **w**<sup>∗</sup> _n_<sup>_, the following inequality holds:_</sup> 



The proof of the theorem is provided in the appendix. Note that the theorem assumes that the generic SGD algorithm converges. Convergence in the first-order case holds under very mild assumptions (e.g., Bottou, 1998). Convergence in the generic SGD case holds because it reduces to the first-order case with a the change of variable **w** → **B**<sup>−</sup> 2<sup><u>1</u></sup> **w** . Convergence also holds under slightly stronger assumptions when the rescaling matrix **B** changes over time (e.g., Driancourt, 1994). The following two corollaries recover the maximal number of iterations listed in Table 2.2 with ν = **tr** � **GH**<sup>−1�</sup> and κ = λ<sup>−1</sup> ∥ **H** ∥. Corollary 2 gives a very precise equality for the second-order case because the lower bound and the upper bound of the theorem take identical values. Corollary 3 gives a much less refined bound in the first-order case. **Corollary 2** _Assume_ **B** = **H**<sup>−1</sup> _as in the second-order SGD algorithm_ (4) _. Under the assumptions of Theorem 1, we have_ 



**Corollary 3** _Assume_ **B** = λ<sup>−1</sup> **I** _as in the first-order SGD algorithm_ (3) _. Under the assumptions of Theorem 1, we have_ 



An often rediscovered property of second order SGD provides an useful point of reference: 

### **Theorem 4 (Fabian, 1973; Murata and Amari, 1999; Bottou and LeCun, 2005)** 

_Let_ **w**<sup>∗</sup> = argmin<sup><u>λ</u></sup> 2<sup>∥</sup><sup>**w**∥2 +E</sup><sup>**x**,</sup><sup>_y_[ℓ(</sup><sup>_y_</sup><sup>**w**⊤</sup><sup>**x**)]</sup><sup>_. Given a sample of n independent examples_(</sup><sup>**x**</sup><sup>_i_,</sup><sup>_yi_)</sup><sup>_, define_</sup> **w**<sup>∗</sup> _n_<sup>= argmin</sup> **w**<sup>_Pn_(</sup><sup>**w**)</sup><sup>_and compute_</sup><sup>**w**</sup><sup>_nby applying the second-order SGD update_(4)</sup><sup>_to each of the_</sup> _n examples. If they converge, both n_ E � ∥ **w** _n_ − **w**<sup>∗</sup> ∥<sup>2�</sup> _and n_ E � ∥ **w**<sup>∗</sup> _n_<sup>−</sup><sup>**w**∗∥2�</sup> _converge to a same positive constant K when n increases._ 

This result means that, asymptotically and on average, the parameter **w** _n_ obtained after one pass of second-order SGD is as close to the infinite training set solution **w**<sup>∗</sup> as the true optimum of the primal **w**<sup>∗</sup> _n_<sup>.Therefore,whenthetrainingsetislargeenough,wecanexpectthatasinglepassof</sup> second-order SGD ( _n_ iterations of (4)) optimizes the primal accurately enough to replicate the test error of the actual SVM solution. 

When we replace the full second-order rescaling matrix **B** = **H**<sup>−1</sup> by a more computationally acceptable approximation, Theorem 1 indicates that we lose a constant factor _k_ on the required number of iterations to reach that accuracy. In other words, we can expect to replicate the SVM test error after _k_ passes over the randomly reshuffled training set. 

On the other hand, a well chosen approximation of the rescaling matrix can save a large constant factor on the computation of the generic SGD update (2). The best training times are therefore obtained by carefully trading the quality of the approximation for sparse representations. 

1741 

BORDES, BOTTOU AND GALLINARI 

||**Frequency**|**Los**|**s**|
|---|---|---|---|
|Special example:|_n_<br>skip|λskip<br>2<br>|∥**w**∥<sup>2</sup>|
|Examples 1 to_n_:|1|ℓ(_yi_**w**|<sup>⊤</sup>**x**_i_)|



- Table 2: The regularization term in the primal cost can be viewed as an additional training example with an arbitrarily chosen frequency and a specific loss function. 

### **2.4 More Speedup Opportunities** 

We have argued that carefully designed quasi-Newton techniques can save a constant factor on the training times. There are of course many other ways to save constant factors: 

- _Exploiting the sparsity of the patterns_ (see Section 3) can save a constant factor in the cost of each first-order iteration. The benefits are more limited in the second-order case, because the inverse Hessian matrix is usually not sparse. 

- _Implementation details_ (see Section 4) such as compiler technology or parallelization on a predetermined number of processors can also reduce the learning time by constant factors. 

Such opportunities are often dismissed as engineering tricks. However they should be considered on an equal footing with quasi-Newton techniques. Constant factors matter regardless of their origin. The following two sections provide a detailed discussion of sparsity and implementation. 

## **3. Scheduling Stochastic Updates to Exploit Sparsity** 

First-order SGD iterations can be made substantially faster when the patterns **x** _t_ are sparse. The first-order SGD update has the form 



where α _t_ and β _t_ are scalar coefficients. Subtracting β _t_ **x** _t_ from the parameter vector involves solely the nonzero coefficients of the pattern **x** _t_ . On the other hand, subtracting α _t_ **w** _t_ involves all _d_ coefficients. A naive implementation of (5) would therefore spend most of the time processing this first term. Shalev-Shwartz et al. (2007) circumvent this problem by representing the parameter **w** _t_ as the product _st_ **v** _t_ of a scalar and a vector. The update (5) can then be computed as _st_ +1 = (1 − α _t_ ) _st_ and **v** _t_ +1 = **v** _t_ − β **x** _t_ / _st_ +1 in time proportional to the number of nonzero coefficients in **x** _t_ . 

Although this simple approach works well for the first order SGD algorithm, it does not extend nicely to quasi-Newton SGD algorithms. A more general method consists of treating the regularization term in the primal cost (1) as an additional training example occurring with an arbitrarily chosen frequency with a specific loss function. 

Consider examples with the frequencies and losses listed in Table 2 and write the average loss: 



SGD-QN 

|SGD|SVMSGD2|
|---|---|
|**Require:** λ,**w**0,_t_0,_T_<br>|**Require:** λ,**w**0,_t_0,_T_, `skip`<br>|
|1: _t_=0|1: _t_=0, `count`=`skip`|
|2: **while**_t_≤_T_ **do**<br><br><br>|2: **while**_t_≤_T_ **do**<br><br><br>|
|3:<br>**w**_t_+1=**w**_t_−<br>1<br>λ(_t_+_t_0)<sup>(λ</sup><sup>**w**</sup><sup>_t_ +ℓ′(</sup><sup>_yt_</sup><sup>**w**⊤</sup><sup>_t_</sup><sup>**x**</sup><sup>_t_)</sup><sup>_yt_</sup><sup>**x**</sup><sup>_t_)</sup><br>|3:<br>**w**_t_+1=**w**_t_−<br>1<br>λ(_t_+_t_0)<sup>ℓ′(</sup><sup>_yt_</sup><sup>**w**⊤</sup><sup>_t_</sup><sup>**x**</sup><sup>_t_)</sup><sup>_yt_</sup><sup>**x**</sup><sup>_t_</sup><br><br>|
|4:|4:<br>`count` = `count`−1|
|5:|5:<br>**if**`count`≤0**then**<br>|
|6:|6:<br>**w**_t_+1=**w**_t_+1−<sup>skip</sup><br>_t_+_t_0 <sup>**w**</sup><sup>_t_+1</sup>|
|7:|7:<br>`count`=`skip`<br>|
|8:|8:<br>**end if**|
|9:<br>_t_=_t_+1|9:<br>_t_=_t_+1|
|10: **end while**|10: **end while**|
|11: **return w**_T_|11: **return w**_T_|



Figure 1: Detailed pseudo-codes of the SGD and SVMSGD2 algorithms. 

Minimizing this loss is of course equivalent to minimizing the primal cost (1) with its regularization term. Applying the SGD algorithm to the examples defined in Table 2 separates the regularization updates, which involve the special example, from the pattern updates, which involve the real examples. The parameter skip regulates the relative frequencies of these updates. The SVMSGD2 algorithm (Bottou, 2007) measures the average pattern sparsity and picks a frequency that ensures that the amortized cost of the regularization update is proportional to the number of nonzero coefficients. Figure 1 compares the pseudo-codes of the naive first-order SGD and of the first-order SVMSGD2 . Both algorithms handle the real examples at each iteration (line 3) but SVMSGD2 only performs a regularization update every skip iterations (line 6). 

Assume _s_ is the average proportion of nonzero coefficients in the patterns **x** _i_ and set skip to _c_ / _s_ where _c_ is a predefined constant (we use _c_ = 16 in our experiments). Each pattern update (line 3) requires _sd_ operations. Each regularization update (line 6) requires _d_ operations but occurs _s_ / _c_ times less often. The average cost per iteration is therefore proportional to _O_ ( _sd_ ) instead of _O_ ( _d_ ). 

## **4. Implementation** 

In the optimization literature, a superior algorithm implemented with a slow scripting language usually beats careful implementations of inferior algorithms. This is because the superior algorithm minimizes the training error with a higher order convergence. 

This is no longer true in the case of large scale machine learning because we care about the test error instead of the training error. As explained above, algorithm improvements do not improve the order of the test error convergence. They can simply improve constant factors and therefore _compete evenly with implementation improvements_ . Time spent refining the implementation is time well spent. 

- There are lots of methods for representing sparse vectors with sharply different computing requirement for sequential and random access. Our C++ implementation always uses a full 

1743 

BORDES, BOTTOU AND GALLINARI 

||**Full**|**Sparse**|
|---|---|---|
|Random access to a single coefficient:|Θ(1)|Θ(_s_)|
|In-place addition into a full vector of dimension_d_<sup>′</sup>:|Θ(_d_)|Θ(_s_)|
|In-place addition into a sparse vector with_s_<sup>′ </sup>nonzeros:|Θ(_d_+_s_<sup>′</sup>)|Θ(_s_+_s_<sup>′</sup>)|



Table 3: Costs of various operations on a vector of dimension _d_ with _s_ nonzero coefficients. 

vector for representing the parameter **w** , but handles the patterns **x** using either a full vector representation or a sparse representation as an ordered list of index/value pairs. 

Each calculation can be achieved directly on the sparse representation or after a conversion to the full representation (see Table 3). Inappropriate choices have outrageous costs. For example, on a dense data set with 500 attributes, using sparse vectors increases the training time by 50%; on the sparse RCV1 data set (see Table 4), using a sparse vector to represent the parameter **w** increases the training time by more than 900%. 

- Modern processors often sport specialized instructions to handle vectors and multiple cores. Linear algebra libraries, such as `BLAS` , may or may not use them in ways that suit our purposes. Compilation flags have nontrivial impacts on the learning times. 

Such implementation improvements are often (but not always) orthogonal to the algorithmic improvements described above. The main issue consists of deciding how much development resources are allocated to implementation and to algorithm design. This trade-off depends on the available competencies. 

## **5. SGD-QN: A Careful Diagonal Quasi-Newton SGD** 

As explained in Section 2, designing an efficient quasi-Newton SGD algorithm involves a careful trade-off between the sparsity of the scaling matrix representation **B** and the quality of its approximation of the inverse Hessian **H**<sup>−1</sup> . The two obvious choices are diagonal approximations (Becker and Le Cun, 1989) and low rank approximations (Schraudolph et al., 2007). 

### **5.1 Diagonal Rescaling Matrices** 

Among numerous practical suggestions for running SGD algorithm in multilayer neural networks, Le Cun et al. (1998) emphatically recommend to rescale each input space feature in order to improve the condition number κ of the Hessian matrix. In the case of a linear model, such preconditioning is similar to using a constant diagonal scaling matrix. 

Rescaling the input space defines transformed patterns **X** _t_ such that [ **X** _t_ ] _i_ = _bi_ [ **x** _t_ ] _i_ where the notation [ **v** ] _i_ represents the _i_ -th coefficient of vector **v** . This transformation does not change the classification if the parameter vectors are modified as [ **W** _t_ ] _i_ = [ **w** _t_ ] _i_ / _bi_ . The first-order SGD update on these modified variable is then 



1744 

SGD-QN 

Multiplying by _bi_ shows how the original parameter vector **w** _t_ is affected: 



We observe that rescaling the input is equivalent to multiplying the gradient by a fixed diagonal matrix **B** whose elements are the squares of the coefficients _bi_ . 

Ideally we would like to make the product **BH** spectrally close the identity matrix. Unfortunately we do not know the value of the Hessian matrix **H** at the optimum **w**<sup>∗</sup> _n_<sup>.Instead we could consider</sup> the current value of the Hessian **Hw** _t_ = _P_<sup>′′</sup> ( **w** _t_ ) and compute the diagonal rescaling matrix **B** that makes **BHw** _t_ closest to the identity. This computation could be very costly because it involves the full Hessian matrix. Becker and Le Cun (1989) approximate the optimal diagonal rescaling matrix by inverting the diagonal coefficients of the Hessian. The method relies on the analytical derivation of these diagonal coefficients for multilayer neural networks. This derivation does not extend to arbitrary models. It certainly does not work in the case of traditional SVMs because the hinge loss has zero curvature almost everywhere. 

### **5.2 Low Rank Rescaling Matrices** 

The popular LBFGS optimization algorithm (Nocedal, 1980) maintains a low rank approximation of the inverse Hessian by storing the _k_ most recent rank-one BFGS updates instead of the full inverse Hessian matrix. When the successive full gradients _Pn_<sup>′(</sup><sup>**w**</sup><sup>_t_−1)and</sup><sup>_P_′</sup> _n_<sup>(</sup><sup>**w**</sup><sup>_t_)areavailable,</sup> standard rank one updates can be used to directly estimate the inverse Hessian matrix **H**<sup>−1</sup> . Using this method with stochastic gradient is tricky because the full gradients _Pn_<sup>′(</sup><sup>**w**</sup><sup>_t_−1)and</sup><sup>_P_′</sup> _n_<sup>(</sup><sup>**w**</sup><sup>_t_)are</sup> not readily available. Instead we only have access to the stochastic estimates **g** _t_ −1( **w** _t_ −1) and **g** _t_ ( **w** _t_ ) which are too noisy to compute good rescaling matrices. 

The oLBFGS algorithm (Schraudolph et al., 2007) compares instead the derivatives **g** _t_ −1( **w** _t_ −1) and **g** _t_ −1( **w** _t_ ) for the same example ( **x** _t_ −1, _yt_ −1). This reduces the noise to an acceptable level at the expense of the computation of the additional gradient vector **g** _t_ −1( **w** _t_ ). 

Compared to the first-order SGD, each iteration of the oLBFGS algorithm computes the additional quantity **g** _t_ −1( **w** _t_ ) and updates the list of _k_ rank one updates. The most expensive part however remains the multiplication of the gradient **g** _t_ ( **w** _t_ ) by the low-rank estimate of the inverse Hessian. With _k_ = 10, each iteration of our oLBFGS implementation runs empirically 11 times slower than a first-order SGD iteration. 

### **5.3 SGD-QN** 

The SGD-QN algorithm estimates a _diagonal rescaling matrix_ using a technique inspired by oLBFGS . For any pair of parameters **w** _t_ −1 and **w** _t_ , a Taylor series of the gradient of the primal cost _P_ provides the secant equation: 





Since we are designing a stochastic algorithm, we do not have access to the full gradient _Pn_<sup>′.Fol-</sup> lowing oLBFGS , we replace them by the local gradients **g** _t_ −1( **w** _t_ ) and **g** _t_ −1( **w** _t_ −1) and obtain 



1745 

BORDES, BOTTOU AND GALLINARI 

Since we chose to use a diagonal rescaling matrix **B** , we can write the term-by-term equality 



where the notation [ **v** ] _i_ still represents the _i_ -th coefficient of vector **v** . This leads to computing **B** _ii_ as the average of the ratio [ **w** _t_ − **w** _t_ −1] _i_ /[ **g** _t_ −1( **w** _t_ ) − **g** _t_ −1( **w** _t_ −1)] _i_ . An online estimation is easily achieved during the course of learning by performing a leaky average of these ratios, 



and where the integer _r_ is incremented whenever we update the matrix **B** . 

The weights of the scaling matrix **B** are initialized to λ<sup>−1</sup> because this corresponds to the exact setup of first-order SGD. Since the curvature of the primal cost (1) is always larger than λ , the ratio [ **g** _t_ −1( **w** _t_ ) − **g** _t_ −1( **w** _t_ −1)] _i_ /[ **w** _t_ − **w** _t_ −1] _i_ is always larger than λ . Therefore the coefficients **B** _ii_ never exceed their initial value λ<sup>−1</sup> . Basically these scaling factors slow down the convergence along some axes. The speedup does not occur because we follow the trajectory faster, but because we follow a better trajectory. 

Performing the weight update (2) with a diagonal rescaling matrix **B** consists in performing term-by-term operations with a time complexity that is marginally greater than the complexity of the first-order SGD (3) update. The computation of the additional gradient vector **g** _t_ −1( **w** _t_ ) and the reestimation of all the coefficients **B** _ii_ essentially triples the computing time of a first-order SGD iteration with non-sparse inputs (3), and is considerably slower than a first-order SGD iteration with sparse inputs implemented as discussed in Section 3. 

Fortunately this higher computational cost per iteration can be nearly avoided by scheduling the reestimation of the rescaling matrix with the same frequency as the regularization updates. Section 5.1 has shown that a diagonal rescaling matrix does little more than rescaling the input variables. Since a fixed diagonal rescaling matrix already works quite well, there is little need to update its coefficients very often. 

Figure 2 compares the SVMSGD2 and SGD-QN algorithms. Whenever SVMSGD2 performs a regularization update, we set the flag `updateB` to schedule a reestimation of the rescaling coefficients during the next iteration. This is appropriate because both operations have comparable computing times. Therefore the rescaling matrix reestimation schedule can be regulated with the same `skip` parameter as the regularization updates. In practice, we observe that each SGD-QN iteration demands less than twice the time of a first-order SGD iteration. 

Because SGD-QN reestimates the rescaling matrix after a pattern update, special care must be taken when the ratio [ **w** _t_ − **w** _t_ −1] _i_ /[ **g** _t_ −1( **w** _t_ ) − **g** _t_ −1( **w** _t_ −1)] _i_ has the form 0/0 because the corresponding input coefficient [ **x** _t_ −1] _i_ is zero. Since the secant Equation (6) is valid for any two values of the parameter vector, one can compute the ratios with parameter vectors **w** _t_ −1 and **w** _t_ + ε and derive the correct value by continuity when ε → 0. When [ **x** _t_ −1] _i_ = 0, we can write 



1746 

SGD-QN 

SVMSGD2 SGD-QN 

**Require:** λ , **w** 0, _t_ 0, _T_ , `skip` **Require:** λ , **w** 0, _t_ 0, _T_ , `skip` 1: _t_ = 0, `count` = `skip` 1: _t_ = 0, `count` = `skip` , 2: 2: **B** = λ<sup>−1</sup> **I** ; `updateB` = `false` ; _r_ = 2 3: **while** _t_ ≤ _T_ **do** 3: **while** _t_ ≤ _T_ **do** 4: **w** _t_ +1 = **w** _t_ − λ ( _t_ +1 _t_ 0)<sup>ℓ′(</sup><sup>_yt_</sup><sup>**w**⊤</sup><sup>_t_</sup><sup>**x**</sup><sup>_t_)</sup><sup>_yt_</sup><sup>**x**</sup><sup>_t_</sup> 4: **w** _t_ +1 = **w** _t_ − ( _t_ + _t_ 0)<sup>−1</sup> ℓ<sup>′</sup> ( _yt_ **w**<sup>⊤</sup> _t_ **x** _t_ ) _yt_ **Bx** _t_ 5: 5: **if** `updateB` = `true` **then** 6: 6: **p** _t_ = **g** _t_ ( **w** _t_ +1) − **g** _t_ ( **w** _t_ ) 7: 7: ∀ _i_ , **B** _ii_ = **B** _ii_ +<sup><u>2</u></sup> _r_ �[ **w** _t_ +1 − **w** _t_ ] _i_ [ **p** _t_ ]<sup>−</sup> _i_<sup>1</sup> − **B** _ii_ � 8: 8: ∀ _i_ , **B** _ii_ = max( **B** _ii_ , 10<sup>−2</sup> λ<sup>−1</sup> ) 9: 9: _r_ = _r_ + 1; `updateB` = `false` 10: 10: **end if** 11: `count` = `count` −1 11: `count` = `count` −1 12: **if** `count` ≤ 0 **then** 12: **if** `count` ≤ 0 **then** 13: **w** _t_ +1 = **w** _t_ +1− `skip` ( _t_ + _t_ 0)<sup>−1</sup> **w** _t_ +1 13: **w** _t_ +1 = **w** _t_ +1− `skip` ( _t_ + _t_ 0)<sup>−1</sup> λ **Bw** _t_ +1 14: `count` = `skip` 14: `count` = `skip` ; `updateB` = `true` 15: **end if** 15: **end if** 16: _t_ = _t_ + 1 16: _t_ = _t_ + 1 17: **end while** 17: **end while** 18: **return w** _T_ 18: **return w** _T_ 

Figure 2: Detailed pseudo-codes of the SVMSGD2 and SGD-QN algorithms. 

|Data Set|Train. Ex.|Test. Ex.|Features|_s_|λ|_t_0|_skip_|
|---|---|---|---|---|---|---|---|
|ALPHA|100,000|50,000|500|1|10<sup>−5</sup>|10<sup>6</sup>|16|
|DELTA|100,000|50,000|500|1|10<sup>−4</sup>|10<sup>4</sup>|16|
|RCV1|781,265|23,149|47,152|0.0016|10<sup>−4</sup>|10<sup>5</sup>|9,965|



Table 4: Data sets and parameters used for experiments. 

## **6. Experiments** 

We demonstrate the good scaling properties of SGD-QN in two ways: we present a detailed comparison with other stochastic gradient methods, and we summarize the results obtained on the PASCAL Large Scale Challenge. 

Table 4 describes the three binary classification tasks we used for comparative experiments. The Alpha and Delta tasks were defined for the PASCAL Large Scale Challenge (Sonnenburg et al., 2008). We train with the first 100,000 examples and test with the last 50,000 examples of the official training sets because the official testing sets are not available. Alpha and Delta are dense data sets with relatively severe conditioning problems. The third task is the classification of RCV1 documents belonging to class CCAT (Lewis et al., 2004). This task has become a standard benchmark for linear SVMs on sparse data. Despite its larger size, the RCV1 task is much easier than the Alpha and Delta tasks. All methods discussed in this paper perform well on RCV1. 

1747 

BORDES, BOTTOU AND GALLINARI 

||ALPHA|RCV1|
|---|---|---|
|SGD|0.13|36.8|
|SVMSGD2|0.10|0.20|
|SGD-QN|0.21|0.37|



Table 5: Time (sec.) for performing one pass over the training set. 

The experiments reported in Section 6.4 use the hinge loss ℓ( _s_ ) = max(0, 1 − _s_ ). All other experiments use the squared hinge loss ℓ( _s_ ) = 2<sup><u>1</u>(max(0,1−</sup><sup>_s_))2.In practice, there is no need to make</sup> the losses twice differentiable by smoothing their behavior near _s_ = 0. Unlike most batch optimizer, stochastic algorithms do not not aim directly for nondifferentiable points, but randomly hop around them. The stochastic noise implicitly smoothes the loss. 

The SGD , SVMSGD2 , oLBFGS , and SGD-QN algorithms were implemented using the same C++ code base.<sup>3</sup> All experiments are carried out in single precision. We did not experience numerical accuracy issues, probably because of the influence of the regularization term. Our implementation of oLBFGS maintains a rank 10 rescaling matrix. Setting the oLBFGS gain schedule is rather delicate. We obtained fairly good results by replicating the gain schedule of the VieCRF package.<sup>4</sup> We also propose a comparison with the online dual linear SVM solver (Hsieh et al., 2008) implemented in the LibLinear package.<sup>5</sup> We did not reimplement this algorithm because the LibLinear implementation has proved as simple and as efficient as ours. 

The _t_ 0 parameter is determined using an automatic procedure: since the size of the training set does not affect results of Theorem 1, we simply pick a subset containing 10% of the training examples, perform one SGD-QN pass over this subset with several values for _t_ 0, and pick the value for which the primal cost decreases the most. These values are given in Table 4. 

### **6.1 Sparsity Tricks** 

Table 5 illustrates the influence of the scheduling tricks described in Section 3. The table displays the training times of SGD and SVMSGD2 . The only difference between these two algorithms are the scheduling tricks. SVMSGD2 trains 180 times faster than SGD on the sparse data set RCV1. This table also demonstrates that iterations of the quasi-newton SGD-QN are not prohibitively expensive. 

### **6.2 Quasi-Newton** 

Figure 3 shows how the primal cost _Pn_ ( **w** ) of the Alpha data set evolves with the number of passes (left) and the training time (right). Compared to the first-order SVMSGD2 , both the oLBFGS and SGD-QN algorithms dramatically decrease the number of passes required to achieve similar values of the primal. Even if it uses a more precise approximation of the inverse Hessian, oLBFGS does not perform better after a single pass than SGD-QN . Besides, running a single pass of oLBFGS is much slower than running multiple passes of SVMSGD2 or SGD-QN . The benefits of its secondorder approximation are canceled by its greater time requirements per iteration. On the other hand, 

> 3. Implementations and experiment scripts are available in the `libsgdqn` library on `http://www.mloss.org` . 

> 4. This can be found at `http://www.ofai.at/~jeremy.jancsary` . 

> 5. This can be found at `http://www.csie.ntu.edu.tw/~cjlin/liblinear` . 

1748 

SGD-QN 



<!-- Start of picture text -->
0.40 0.40<br>SVMSGD2 SVMSGD2<br>SGD-QN SGD-QN<br>oLBFGS oLBFGS<br>0.38 0.38<br>0.36 0.36<br>0.34 0.34<br>0.32 0.32<br>0.30 0.30<br> 0  2  4  6  8  10  0  0.5  1  1.5  2<br>Number of epochs Training time (sec.)<br><!-- End of picture text -->

Figure 3: Primal costs according to the number of epochs (left) and the training duration (right) on the Alpha data set. 

each SGD-QN iteration is only marginally slower than a SVMSGD2 iteration; the reduction of the number of iterations is sufficient to offset this cost. 

### **6.3 Training Speed** 

Figure 4 displays the test errors achieved on the Alpha, Delta and RCV1 data sets as a function of the number of passes (left) and the training time (right). These results show again that both oLBFGS and SGD-QN require less iterations than SVMSGD2 to achieve the same test error. However, oLBFGS suffers from the relatively high complexity of its update process. The SGD-QN algorithm is competitive with the dual solver LibLinear on the dense data sets Alpha and Delta; it runs significantly faster on the sparse RCV1 data set. 

According to Theorem 4, given a large enough training set, a perfect second-order SGD algorithm would reach the batch test error after a single pass. One pass learning is attractive when we are dealing with high volume streams of examples that cannot be stored and retrieved quickly. Figure 4 (left) shows that oLBFGS is a little bit closer to that ideal than SGD-QN and could become attractive for problems where the example retrieval time is much greater than the computing time. 

### **6.4 PASCAL Large Scale Challenge Results** 

The SGD-QN algorithm has been submitted to the “Wild Track” of the PASCAL Large Scale Challenge. Wild Track contributors were free to do anything leading to more efficient and more accurate methods. Forty two methods have been submitted to this track. Table 6 shows the SGD-QN ranks determined by the organizers of the challenge according to their evaluation criteria. The SGD-QN algorithm always ranks among the top five submissions and ranks first in overall score (tie with another Newton method). 

1749 

BORDES, BOTTOU AND GALLINARI 



<!-- Start of picture text -->
27.0 27.0<br>SVMSGD2 SVMSGD2<br>SGD-QN SGD-QN<br>26.0 oLBFGS 26.0 oLBFGS<br>LibLinear LibLinear<br>25.0 25.0<br>24.0 24.0<br>23.0 23.0<br>22.0 22.0<br>21.0 21.0<br> 0  2  4  6  8  10  0  0.5  1  1.5  2<br>Number of epochs Training time (sec.)<br>ALPHA DATA SET<br>25.0 25.0<br>SVMSGD2 SVMSGD2<br>24.5 SGD-QN 24.5 SGD-QN<br>oLBFGS oLBFGS<br>LibLinear LibLinear<br>24.0 24.0<br>23.5 23.5<br>23.0 23.0<br>22.5 22.5<br>22.0 22.0<br>21.5 21.5<br>21.0 21.0<br> 0  1  2  3  4  5  0  0.2  0.4  0.6  0.8  1<br>Number of epochs Training time (sec.)<br>DELTA DATA SET<br>7.0 7.0<br>SVMSGD2 SVMSGD2<br>SGD-QN SGD-QN<br>6.8 6.8<br>LibLinear LibLinear<br>6.6 6.6<br>6.4 6.4<br>6.2 6.2<br>6.0 6.0<br>5.8 5.8<br>5.6 5.6<br> 0  1  2  3  4  5  0  0.5  1  1.5  2<br>Number of epochs Training time (sec.)<br>RCV1 DATA SET<br><!-- End of picture text -->

Figure 4: Test errors (in %) according to the number of epochs (left) and training duration (right). 

1750 

SGD-QN 

|Data Set|λ|_skip_|Passes|**Rank**|
|---|---|---|---|---|
|Alpha|10<sup>−5</sup>|16|10|**1**<sup>_st_</sup>|
|Beta|10<sup>−4</sup>|16|15|**3**<sup>_rd_</sup>|
|Gamma|10<sup>−3</sup>|16|10|**1**<sup>_st_</sup>|
|Delta|10<sup>−3</sup>|16|10|**1**<sup>_st_</sup>|
|Epsilon|10<sup>−5</sup>|16|10|**5**<sup>_th_</sup>|
|Zeta|10<sup>−5</sup>|16|10|**4**<sup>_th_</sup>|
|OCR|10<sup>−5</sup>|16|10|**2**<sup>_nd_</sup>|
|Face|10<sup>−5</sup>|16|20|**4**<sup>_th_</sup>|
|DNA|10<sup>−3</sup>|64|10|**2**<sup>_nd_</sup>|
|Webspam|10<sup>−5</sup>|71,066|10|**4**<sup>_th_</sup>|



Table 6: Parameters and final ranks obtained by SGD-QN in the “Wild Track” of the first PASCAL Large Scale Learning Challenge. All competing algorithms were run by the organizers. (Note: the competition results were obtained with a preliminary version of SGD-QN . In particular the λ parameters listed above are different from the values used for all experiments in this paper and listed in Table 4.) 

## **7. Conclusion** 

The SGD-QN algorithm strikes a good compromise for large scale application because it has low time and memory requirements per iteration and because it reaches competitive test errors after a small number of iterations. We have shown how this performance is the result of a careful design taking into account the theoretical knowledge about second-order SGD and a precise understanding of its computational requirements. 

Finally, although this contribution presents SGD-QN as a solver for linear SVMs, this algorithm can be easily extended to nonlinear models for which we can analytically compute the gradients. We plan to further investigate the performance of SGD-QN in this context. 

## **Acknowledgments** 

Part of this work was funded by NSF grant CCR-0325463 and by the EU Network of Excellence PASCAL2. Antoine Bordes was also supported by the French DGA. 

## **Appendix A. Proof of Theorem 1** 

Define **v** _t_ = **w** _t_ − **w** _n_<sup>∗and observe that a second-order Taylor expansion of the primal gives</sup> 



Let E _t_ −1 representing the conditional expectation over the choice of the example at iteration _t_ − 1 given all the choices made during the previous iterations. Since we assume that convergence takes 

1751 

BORDES, BOTTOU AND GALLINARI 

place, we have 



where notation **I** ε is a shorthand for **I** + o (1), that is, a matrix that converges to the identity. Expressing **Hv** _t_ **v**<sup>⊤</sup> _t_<sup>using the generic SGD update (2) gives</sup> 



Let λ max ≥ λ min > 1/2 be the extreme eigenvalues of **HB** . Since, for any positive matrix **X** , 

� λ min + o (1) � **tr** ( **X** ) ≤ **tr** ( **HBI** ε **X** ) ≤ � λ max + o (1) � **tr** ( **X** ) 

we can bracket E σ [ **tr** ( **Hv** _t_ **v**<sup>⊤</sup> _t_<sup>)] between the expressions</sup> 

and 



By recursively applying this bracket, we obtain 

_u_ λ max( _t_ + _t_ 0) ≤ E σ [ **tr** ( **Hv** _t_ **v**<sup>⊤</sup> _t_<sup>)]≤</sup><sup>_u_</sup> λ min<sup>(</sup><sup>_t_+</sup><sup>_t_0)</sup> 

where the notation _u_ λ ( _t_ ) represents a sequence of real satisfying the recursive relation 





and 



1752 

SGD-QN 

## **References** 

- S.-I. Amari, H. Park, and K. Fukumizu. Adaptive method of realizing natural gradient learning for multilayer perceptrons. _Neural Computation_ , 12:1409, 2000. 

- S. Becker and Y. Le Cun. Improving the convergence of back-propagation learning with secondorder methods. In _Proc. 1988 Connectionist Models Summer School_ , pages 29–37. Morgan Kaufman, 1989. 

- A. Bordes, S. Ertekin, J. Weston, and L. Bottou. Fast kernel classifiers with online and active learning. _J. Machine Learning Research_ , 6:1579–1619, September 2005. 

- L. Bottou. Online algorithms and stochastic approximations. In David Saad, editor, _Online Learning and Neural Networks_ . Cambridge University Press, Cambridge, UK, 1998. 

- L. Bottou. Stochastic gradient descent on toy problems, 2007. `http://leon.bottou.org/ projects/sgd` . 

- L. Bottou and O. Bousquet. The tradeoffs of large scale learning. In _Adv. in Neural Information Processing Systems_ , volume 20. MIT Press, 2008. 

- L. Bottou and Y. LeCun. On-line learning for very large datasets. _Applied Stochastic Models in Business and Industry_ , 21(2):137–151, 2005. 

- X. Driancourt. _Optimisation par descente de gradient stochastique de systèmes modulaires combinant réseaux de neurones et programmation dynamique_ . PhD thesis, Université Paris XI, Orsay, France, 1994. 

- V. Fabian. Asymptotically efficient stochastic approximation; the RM case. _Annals of Statistics_ , 1 (3):486–495, 1973. 

- C.-J. Hsieh, K.-W. Chang, C.-J. Lin, S. Keerthi, and S. Sundararajan. A dual coordinate descent method for large-scale linear SVM. In _Proc. 25th Intl. Conf. on Machine Learning (ICML’08)_ , pages 408–415. Omnipress, 2008. 

- Y. Le Cun, L. Bottou, G. Orr, and K.-R. Müller. Efficient backprop. In _Neural Networks, Tricks of the Trade_ , Lecture Notes in Computer Science LNCS 1524. Springer Verlag, 1998. 

- D. D. Lewis, Y. Yang, T. G. Rose, and F. Li. RCV1: A new benchmark collection for text categorization research. _J. Machine Learning Research_ , 5:361–397, 2004. 

- N. Murata and S.-I. Amari. Statistical analysis of learning dynamics. _Signal Processing_ , 74(1): 3–28, 1999. 

- J. Nocedal. Updating quasi-Newton matrices with limited storage. _Mathematics of Computation_ , 35:773–782, 1980. 

- N. Schraudolph. Local gain adaptation in stochastic gradient descent. In _In Proc. of the 9th Intl. Conf. on Artificial Neural Networks_ , pages 569–574, 1999. 

1753 

BORDES, BOTTOU AND GALLINARI 

- N. Schraudolph, J. Yu, and S. Günter. A stochastic quasi-Newton method for online convex optimization. In _Proc. 11th Intl. Conf. on Artificial Intelligence and Statistics (AIstats)_ , pages 433– 440. Soc. for Artificial Intelligence and Statistics, 2007. 

- S. Shalev-Shwartz, Y. Singer, and N. Srebro. Pegasos: Primal estimated subgradient solver for SVM. In _Proc. 24th Intl. Conf. on Machine Learning (ICML’07)_ , pages 807–814. ACM, 2007. 

- S. Sonnenburg, V. Franc, E. Yom-Tov, and M. Sebag. Pascal large scale learning challenge. ICML’08 Workshop, 2008. `http://largescale.first.fraunhofer.de` . 

1754
