"""Path A into data/claims.yaml: screen every citing sentence of a paper, keep the usable claims.

One pass per citing paper, over every sentence of its main.tex that carries a \\cite:

  1. CODE CHECKS (no model)  the line is verbatim in main.tex, every cited work has full text, it is
                             not glued to a heading/float/list marker, it cites at most
                             MAX_CITED_WORKS works, it has no existence/vague phrasing, and it is
                             not already in claims.yaml (kept or dropped).
  2. CITATION FUNCTION       the model sees the sentence with [CITATION n] markers, each cited
                             work's title and year, and the citing paper's year - never the cited
                             full text. Only `background` survives: the cited works are offered as
                             EVIDENCE for the whole claim. Method use, comparisons with the citing
                             authors' own results, passing mentions and part-support are dropped;
                             that is a statement about suitability, not about evidence.
  3. DECONTEXTUALISATION     the model sees the TARGET sentence, the sentences before it in its
                             paragraph, and the cited titles/years. Only `standalone` survives:
                             `self` (the citing authors' own work) and `needs_context` do not.

Survivors are appended to data/claims.yaml through claims.append, with a note recording both
verdicts. That file is then read by a person, who marks a bad claim `drop: true` (see the
README, "Human claim review"). Nothing is dropped from claims.yaml by this script.

Every model call is cached in data/.cache/filter/ by (model, prompt, input), so a re-run pays only
for new sentences.

    python data/filter.py                          # dry run over data/papers.txt
    python data/filter.py --paper 2205.14135v2     # one paper
    python data/filter.py --no-model               # the code checks only, no API calls
    python data/filter.py --write                  # append the survivors to data/claims.yaml
"""

from __future__ import annotations

import argparse
import ast
import logging
import re
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "data"))
import claims  # noqa: E402
from latex import (  # noqa: E402
    CITE_RE,
    SENTENCE_SPLIT,
    citing_sentences,
    paragraphs,
    strip_heading,
    strip_non_prose,
    to_plain_text,
)
from model import Model, load_dotenv, normalise  # noqa: E402

log = logging.getLogger("filter")
PAPERS = ROOT / "data" / "papers.txt"
CACHE = ROOT / "data" / ".cache" / "filter"
MODEL = "gpt-5.6-sol"          # a construction model: never benchmarked
PRECEDING = 3                  # sentences of the paragraph shown before the target

FUNCTIONS = ("background", "partial_detail", "method", "comparison", "entity", "partial_claim")
OUTCOMES = ("standalone", "self", "needs_context")

FUNCTION_PROMPT = """You classify the FUNCTION of the citations in a scientific sentence. Each citation's position is marked [CITATION n]. You are also given each cited work's title and year, and the year of the paper the sentence comes from. Answer with exactly one of: background, partial_detail, method, comparison, entity, or partial_claim.

background - the cited works are offered as EVIDENCE for what the sentence claims, and the whole
  claim is something works with those titles and years could themselves state, show or report -
  including a description of a cited work's own method, results or details.
  e.g. "Recurrent networks have been firmly established as state of the art approaches [CITATION 1]"
  e.g. "ResNet [CITATION 1] adds identity shortcuts between stacked layers"
  e.g. "The base BERT model [CITATION 1] has 12 layers and a hidden size of 768"
  NOTE: words like "state of the art", "faster than" or "speed up" appear in background
  sentences describing PRIOR WORK just as often as in result comparisons. Judge the
  rhetorical role, not the vocabulary.

method - the sentence states what THE AUTHORS did, used, followed or built on. It is
  autobiographical; the cited work is the thing adopted, not evidence for a claim.
  e.g. "We use the Adam optimizer [CITATION 1]"
  e.g. "In row (E) we replace our positional encoding with learned embeddings [CITATION 1]"

comparison - the sentence reports how the authors' OWN results compare against the cited
  work or a baseline it defines. The evidence for the comparison lives in the citing paper.
  e.g. "We train BERT-large 15% faster than the record in MLPerf 1.1 [CITATION 1]"

entity - a citation only IDENTIFIES something the sentence names in passing, while what the
  sentence claims is something the cited work does not itself report: the citing authors' own
  findings, or a later development or trend. Compare the years: a work from YEAR cannot report
  anything that happened after YEAR.
  e.g. "In decoders that use beam search [CITATION 1], our cache cuts memory use by 40%"
  e.g. "Convolutional networks have since become ubiquitous in computer vision [CITATION 1]"
       where [CITATION 1] is a 1998 paper
  e.g. "Attention is now used by most large language models [CITATION 1]" where the work is from 2015

The last two are for sentences the cited works back only in PART - another part says something
none of them could support (judging by their titles and years). Use them only when that part is
real content, not a detail the cited works plausibly cover. First find the sentence's MAIN claim:
what it would still assert with every aside, qualifier and explanation removed.

partial_detail - the cited works back the MAIN claim. What they cannot back is secondary: an
  aside or parenthetical, a qualifier, a suggested cause or explanation, a definition or framing
  that sets up the claim, or a generalisation of the cited examples ("many ...", "typically").
  Removing that part leaves a background sentence.
  e.g. "Gradient clipping stabilises recurrent network training [CITATION 1] (though it adds a
       hyperparameter that is hard to tune)"
  e.g. "Several systems route each token to a few experts, such as Switch [CITATION 1]"

partial_claim - the MAIN claim, or a second claim of equal weight, is something none of the cited
  works could support - often a claim about particular systems, the field, or the citing authors'
  own findings - and the citation backs only a supporting clause.
  e.g. "Existing serving systems waste memory because they allocate contiguously, as most
       frameworks require contiguous tensors [CITATION 1]" where [CITATION 1] is a deep learning
       framework paper
  e.g. "Our model underperforms on long inputs, likely because attention cost grows quadratically
       [CITATION 1]"

Ask: could a reader verify the WHOLE claim by reading only works with these titles and years?
If yes it is background.

Reply with JSON only:
{"function": "background|partial_detail|method|comparison|entity|partial_claim"}"""

DECONTEXT_PROMPT = """You prepare sentences from a research paper for a claim-verification benchmark. Each TARGET sentence cites other works, marked [CITATION n]; you get each cited work's title and year, and the source paper's year. A reader will later check the TARGET against the full text of its cited works, and never sees anything else from the source paper. Keep only sentences that stand on their own.

Answer "standalone" only if the target's claim is fully understandable on its own. It is NOT standalone
if it contains any of these:
  * a pronoun, demonstrative or definite phrase pointing at earlier text ("this", "these", "such",
    "they", "their", "the X" where X was introduced earlier, "the two mechanisms"). A target that
    BEGINS with This/These/Those/It/They/Such/Its/Their, or with "The <noun>" naming something the
    target does not itself introduce, is NEVER standalone
  * a symbol, variable or acronym the sentence does not itself define - EXCEPT
      - names and acronyms of the TARGET's own cited works (e.g. "IBC" when an IBC paper is cited),
        which the cited works themselves define
      - standard acronyms any reader in the field knows without being told (e.g. GPU, CPU, RNN, CNN,
        LSTM, MLP, LLM, NLP, RL, SGD, KL); an acronym the source paper itself introduces (e.g. "HBM"
        for its own memory term) still needs context
  * a continuation opening ("where ...", "which ...", "Doing so ...", "Other approaches ...")
  * a scope the surrounding text sets (a task, benchmark or setting) without which it reads as a
    different, broader claim
A leading connective such as "However," on its own does not count.

Answer "self" if the target reports, describes or announces what THIS paper and its authors did, found,
built, measured, defined, chose to call something, or will do next - even when it cites other works,
and even when the sentence is otherwise self-contained. Anything in the first person ("We have found
...", "we denote ...", "Our work ...", "we compare our model to ...") is self, and so is pure
signposting that asserts nothing ("We refer the reader to ... for details", "Before summarizing, we
make a few remarks").
  Two things are NOT self:
    * a statement the source paper attributes to a cited work
    * "we" meaning the research community or the field, in a claim about the state of knowledge
      rather than about this paper ("we do not yet know whether ...", "the best hardware we have now
      has error rates above ...")

Otherwise answer "needs_context".

Reply with JSON only:
{"outcome": "standalone|self|needs_context", "reason": "<short>"}"""


# -- code checks ------------------------------------------------------------------------------

BAD_STRUCTURE = re.compile(r"\[clean\]|%%|\\(?:section|subsection|subsubsection|paragraph|caption|begin|end|item|label)\b")

VAGUE = re.compile(
    r"there (?:is|are|has|have) (?:also )?(?:been )?(?:work|studies|attempts|proposals|research)"
    r"|a (?:variety|number) of (?:approaches|works|methods)"
    r"|various \w+ (?:schemes|approaches|methods) have been"
    r"|has historically been|is a vague|competing proposals"
    r"|as discussed in detail in", re.I)

#  Every cited work has to be rewritten consistently with the contrasting claim. Past six a
#  citation list is a name-drop rather than an assertion, and data/augment.py's token budget is
#  the real constraint above about three.
MAX_CITED_WORKS = 6


def code_check(line: str, r: dict) -> str | None:
    """Why a line cannot be a claim, from the text alone; None if it can."""
    if r["problems"]:
        return "; ".join(r["problems"])
    if BAD_STRUCTURE.search(line) or re.match(r"^\(?\d+[.)]|^[A-Z][A-Za-z0-9-]{0,12}\s+[A-Z]", line):
        return "glued to a heading, float or list marker"
    if len(r["keys"]) > MAX_CITED_WORKS:
        return f"{len(r['keys'])} cited works"
    if VAGUE.search(r["claim"] or ""):
        return "existence / vague phrasing"
    return None


# -- model inputs -----------------------------------------------------------------------------

def paper_year(paper_id: str) -> str:
    """arXiv ids start YYMM: 2205.14135 is 2022."""
    return f"20{paper_id[:2]}" if re.match(r"\d{4}\.", paper_id) else "unknown"


def render(p: dict, tex: str) -> str:
    return to_plain_text(claims.expand_acronyms(tex, p["main"]), p["macros"], p["labels"], p["author_year"])


def marked(p: dict, line: str) -> tuple[str, list[str]]:
    """The sentence as plain text with each citation replaced by [CITATION n], and the keys in n order."""
    keys: list[str] = []

    def mark(m: re.Match) -> str:
        ns = []
        for key in (k.strip() for k in m.group(1).split(",")):
            if key:
                keys.append(key)
                ns.append(str(len(keys)))
        return " [CITATION " + ", ".join(ns) + "]"

    return render(p, CITE_RE.sub(mark, line)), keys


def preceding(p: dict, line: str) -> list[str]:
    """Up to PRECEDING sentences before the target in its own paragraph, as plain text."""
    want = normalise(line)
    for para in paragraphs(strip_non_prose(p["main"])):
        sentences = [s.strip() for s in SENTENCE_SPLIT.split(strip_heading(para)) if s.strip()]
        for i, s in enumerate(sentences):
            if normalise(s) == want:
                return [render(p, x) for x in sentences[max(0, i - PRECEDING):i]]
    return []


def cited_block(p: dict, keys: list[str], paper_id: str) -> str:
    works = [f"[CITATION {n}] {claims.title_of(p, k)}" for n, k in enumerate(keys, 1)]
    return "\n".join([f"Source paper year: {paper_year(paper_id)}", "Cited works:", *works])


def screen(model: Model, paper_id: str, line: str) -> dict:
    """Both model stages for one line. Decontextualisation runs only on `background`."""
    p = claims.paper(paper_id)
    sentence, keys = marked(p, line)
    works = cited_block(p, keys, paper_id)
    out = {"function": None, "outcome": None, "reason": ""}
    reply = model.ask(FUNCTION_PROMPT, f"SENTENCE: {sentence}\n\n{works}",
                      lambda v: v.get("function") in FUNCTIONS)
    if reply is None:
        out["reason"] = "citation-function call failed"
        return out
    out["function"] = reply["function"]
    if out["function"] != "background":
        return out
    before = preceding(p, line)
    user = "\n".join(["PRECEDING SENTENCES:", *(before or ["(none: the target opens its paragraph)"]),
                      "", f"TARGET: {sentence}", "", works])
    reply = model.ask(DECONTEXT_PROMPT, user, lambda v: v.get("outcome") in OUTCOMES)
    if reply is None:
        out["reason"] = "decontextualisation call failed"
        return out
    out["outcome"], out["reason"] = reply["outcome"], str(reply.get("reason", ""))[:200]
    return out


# -- the pass ---------------------------------------------------------------------------------

def candidates(papers: list[str]) -> tuple[list[dict], dict[str, int]]:
    """Every citing line that passes the code checks and is not in claims.yaml yet."""
    have = {(e["paper"], normalise(e.get("line") or "")) for e in claims.load()}
    have_claims = {normalise(claims.resolve(e)["claim"] or "") for e in claims.load()}
    out, counts = [], {}
    for paper_id in papers:
        p = claims.paper(paper_id)
        if p is None:
            log.warning("%s: no data/clean/arXiv-%s - run ./ingest.sh %s", paper_id, paper_id, paper_id)
            continue
        for line in dict.fromkeys(citing_sentences(p["main"])):
            counts["citing sentences"] = counts.get("citing sentences", 0) + 1
            r = claims.resolve({"paper": paper_id, "line": line})
            if (paper_id, normalise(line)) in have or normalise(r["claim"] or "") in have_claims:
                counts["already in claims.yaml"] = counts.get("already in claims.yaml", 0) + 1
                continue
            why = code_check(line, r)
            if why:
                bucket = "no full text" if why.startswith("no full text") else why.split(";")[0]
                counts[bucket] = counts.get(bucket, 0) + 1
                continue
            out.append({"paper": paper_id, "line": line, "claim": r["claim"]})
    return out, counts


def main() -> int:
    ap = argparse.ArgumentParser(description="Screen citing sentences into data/claims.yaml.")
    ap.add_argument("--paper", action="append", help="arXiv id (repeatable; default: data/papers.txt)")
    ap.add_argument("--model", default=MODEL)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--no-model", action="store_true", help="run the code checks only")
    ap.add_argument("--write", action="store_true", help="append the survivors to data/claims.yaml")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)-7s %(name)s: %(message)s")
    for noisy in ("httpx", "openai"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    papers = args.paper or [i.strip() for i in ast.literal_eval(PAPERS.read_text(encoding="utf-8"))]
    todo, counts = candidates(papers)
    print("\nCODE CHECKS")
    for k, v in sorted(counts.items(), key=lambda kv: -kv[1]):
        print(f"  {v:5d}  {k}")
    print(f"  {len(todo):5d}  pass, go to the model")
    if args.no_model:
        for c in todo:
            print(f"  {c['paper']:14} {c['claim'][:110]}")
        return 0

    load_dotenv()
    model = Model(args.model, CACHE, budgets=(4000, 16000))
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        verdicts = list(pool.map(lambda c: screen(model, c["paper"], c["line"]), todo))

    kept, tally = [], {}
    for c, v in zip(todo, verdicts):
        key = v["function"] if v["function"] != "background" else f"background / {v['outcome']}"
        tally[key or v["reason"]] = tally.get(key or v["reason"], 0) + 1
        if v["function"] == "background" and v["outcome"] == "standalone":
            kept.append((c, v))
    print(f"\nMODEL SCREEN ({args.model})")
    for k, n in sorted(tally.items(), key=lambda kv: -kv[1]):
        print(f"  {n:5d}  {k}")
    print(f"\nKEEP {len(kept)}:")
    for c, _ in kept:
        print(f"  {c['paper']:14} {c['claim'][:110]}")

    if args.write:
        for c, v in kept:
            claims.append({"paper": c["paper"], "line": c["line"],
                           "note": f"filter: background, standalone - {v['reason']}"})
        print(f"\nappended {len(kept)} claim(s) to data/claims.yaml; review them there (drop: true)")
    print(f"model calls: {model.calls} | tokens: {model.usage}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
