"""Flatten an arXiv LaTeX source tree into `main.tex`, `refs.bib` and `bibitems.json`.

Input is a file listing arXiv ids, in whatever shape is convenient:

    ['1706.03762v7', '2005.14165']          a Python/JSON list
    1706.03762v7                            one per line
    https://arxiv.org/abs/1706.03762v7      a URL, with or without `arXiv:`

For each id, `data/raw/arXiv-<id>/` is read and `data/clean/arXiv-<id>/` written:

    main.tex       the paper with every \\input/\\include/\\subfile inlined,
                   appendix included, comments stripped
    refs.bib       the bibliography as BibTeX, from the most faithful source:
                   a .bbl, else an inline `thebibliography`, else real .bib files
    bibitems.json  every cite key → its entry text plus whatever title, authors,
                   year, arXiv id and DOI could be read out of it, so downstream
                   code can link each citation to a full text

Usage:
    python data/clean.py papers.txt
    python data/clean.py papers.txt --raw data/raw --out data/clean
"""

from __future__ import annotations

import argparse
import ast
import json
import logging
import re
import sys
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger("clean")

# --- arXiv ids ---------------------------------------------------------------

# New style (1706.03762v7) and the pre-2007 style (hep-th/9901001v2).
NEW_ID = r"\d{4}\.\d{4,5}(?:v\d+)?"
OLD_ID = r"[a-z-]+(?:\.[A-Z]{2})?/\d{7}(?:v\d+)?"
ARXIV_ID_RE = re.compile(rf"(?:{NEW_ID}|{OLD_ID})")

# Where an id can hide in a bibliography entry: `arXiv:1607.06450`,
# `abs/1409.0473`, `arxiv.org/abs/...`, or a bare eprint field.
ARXIV_MENTION_RE = re.compile(
    rf"(?:arxiv\.org/(?:abs|pdf)/|abs/|arxiv[:\s]*|eprint[\s={{]*)({NEW_ID}|{OLD_ID})",
    re.IGNORECASE,
)


def normalise_id(raw: str) -> str | None:
    """Pull a bare arXiv id out of a URL, an `arXiv:` prefix, or a plain id."""
    text = raw.strip().strip("'\",[]() ")
    if not text:
        return None
    text = re.sub(r"\.pdf$", "", text, flags=re.IGNORECASE)
    match = ARXIV_MENTION_RE.search(text) or ARXIV_ID_RE.search(text)
    return match.group(1) if match and match.groups() else (match.group(0) if match else None)


def read_id_list(path: Path) -> list[str]:
    """Read arXiv ids from a list file, tolerating list literals or plain lines."""
    text = path.read_text(encoding="utf-8").strip()
    items: list[str] = []
    if text.startswith("["):
        # A JSON array, or a Python list literal with single quotes.
        try:
            items = list(json.loads(text))
        except json.JSONDecodeError:
            try:
                items = list(ast.literal_eval(text))
            except (ValueError, SyntaxError):
                items = []
    if not items:
        items = [line for line in text.splitlines() if line.strip() and not line.startswith("#")]

    ids: list[str] = []
    for item in items:
        got = normalise_id(str(item))
        if got is None:
            log.warning("skipping unrecognised entry: %r", item)
        elif got not in ids:
            ids.append(got)
    return ids


# --- comment stripping -------------------------------------------------------

VERBATIM_START = re.compile(r"\\begin\{(verbatim|lstlisting|minted|Verbatim)\*?\}")
VERBATIM_END = re.compile(r"\\end\{(verbatim|lstlisting|minted|Verbatim)\*?\}")


def strip_line_comment(line: str) -> str:
    """Drop a trailing `%` comment, respecting `\\%` and `\\\\`."""
    out: list[str] = []
    i = 0
    while i < len(line):
        char = line[i]
        if char == "\\" and i + 1 < len(line):
            out.append(line[i : i + 2])
            i += 2
            continue
        if char == "%":
            break
        out.append(char)
        i += 1
    return "".join(out)


def strip_comments(text: str) -> str:
    """Remove LaTeX comments, leaving verbatim-like environments untouched."""
    lines: list[str] = []
    in_verbatim = False
    for line in text.splitlines():
        if in_verbatim:
            lines.append(line)
            if VERBATIM_END.search(line):
                in_verbatim = False
            continue
        if VERBATIM_START.search(line):
            in_verbatim = True
            lines.append(line)
            continue
        stripped = strip_line_comment(line)
        # A line that was *only* a comment disappears rather than becoming blank.
        if stripped.strip() or not line.strip().startswith("%"):
            lines.append(stripped.rstrip())
    return "\n".join(lines)


# --- finding the main file ---------------------------------------------------

DOCUMENTCLASS_RE = re.compile(r"^\s*\\documentclass", re.MULTILINE)
BEGIN_DOC_RE = re.compile(r"\\begin\{document\}")
# Names that are conventionally the entry point, best first.
PREFERRED_NAMES = ("main", "ms", "paper", "arxiv", "root", "manuscript", "article")


def find_main_tex(root: Path) -> Path | None:
    """The .tex file that actually starts the document.

    arXiv sources name this anything at all — `ms.tex` in the Transformer paper —
    so look for `\\documentclass` + `\\begin{document}` and break ties by name.
    """
    candidates: list[Path] = []
    for path in sorted(root.rglob("*.tex")):
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        # Judge the file with comments removed, so a commented-out
        # \documentclass in a fragment doesn't masquerade as the main file.
        bare = strip_comments(text)
        if DOCUMENTCLASS_RE.search(bare) and BEGIN_DOC_RE.search(bare):
            candidates.append(path)
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]

    def rank(path: Path) -> tuple[int, int, int]:
        stem = path.stem.lower()
        name_rank = next(
            (i for i, n in enumerate(PREFERRED_NAMES) if stem == n),
            len(PREFERRED_NAMES),
        )
        # Shallower beats deeper; bigger beats smaller as a last resort.
        return (name_rank, len(path.relative_to(root).parts), -path.stat().st_size)

    candidates.sort(key=rank)
    log.debug("main file candidates: %s → %s", [c.name for c in candidates], candidates[0].name)
    return candidates[0]


# --- flattening --------------------------------------------------------------

# \input{f} \include{f} \subfile{f} \InputIfFileExists{f}{...}{...}
INPUT_RE = re.compile(r"\\(input|include|subfile|InputIfFileExists)\s*\{([^}]*)\}")
# \import{dir/}{file} and \subimport{dir/}{file}
IMPORT_RE = re.compile(r"\\(sub)?import\s*\{([^}]*)\}\s*\{([^}]*)\}")

DOC_BODY_RE = re.compile(
    r"\\begin\{document\}(.*?)(?:\\end\{document\}|\Z)", re.DOTALL
)


def _resolve(name: str, bases: list[Path]) -> Path | None:
    """Find the file an \\input refers to; LaTeX lets you omit the .tex."""
    name = name.strip()
    if not name:
        return None
    for base in bases:
        for candidate in (base / name, base / f"{name}.tex"):
            if candidate.is_file():
                return candidate
    return None


@dataclass
class FlattenResult:
    text: str
    included: list[Path] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)


def flatten(main: Path, root: Path | None = None, max_depth: int = 12) -> FlattenResult:
    """Inline every \\input/\\include/\\subfile reachable from `main`.

    Comments are stripped first, so a commented-out `\\input` stays out — the
    Transformer paper comments out its appendix inputs and they must not return.
    """
    root = root or main.parent
    result = FlattenResult(text="")
    seen: set[Path] = set()

    def expand(path: Path, depth: int, is_subfile: bool) -> str:
        resolved = path.resolve()
        if depth > max_depth:
            log.warning("max include depth at %s", path.name)
            return f"\n%% [clean] max depth reached: {path.name}\n"
        if resolved in seen:
            log.warning("circular include of %s", path.name)
            return f"\n%% [clean] circular include skipped: {path.name}\n"
        seen.add(resolved)
        result.included.append(path)

        text = strip_comments(path.read_text(encoding="utf-8", errors="replace"))
        if is_subfile:
            # A subfile carries its own preamble; keep only the body.
            body = DOC_BODY_RE.search(text)
            if body:
                text = body.group(1)

        def replace_input(match: re.Match[str]) -> str:
            command, name = match.group(1), match.group(2)
            target = _resolve(name, [path.parent, root])
            if target is None:
                result.missing.append(name)
                log.warning("%s: unresolved \\%s{%s}", path.name, command, name)
                return f"%% [clean] missing \\{command}{{{name}}}"
            nested = expand(target, depth + 1, is_subfile=command == "subfile")
            return f"\n%% [clean] begin {name}\n{nested}\n%% [clean] end {name}\n"

        def replace_import(match: re.Match[str]) -> str:
            directory, name = match.group(2), match.group(3)
            target = _resolve(name, [path.parent / directory, root / directory])
            if target is None:
                result.missing.append(f"{directory}{name}")
                log.warning("%s: unresolved \\import{{%s}}{{%s}}", path.name, directory, name)
                return f"%% [clean] missing \\import{{{directory}}}{{{name}}}"
            nested = expand(target, depth + 1, is_subfile=bool(match.group(1)))
            return f"\n%% [clean] begin {directory}{name}\n{nested}\n%% [clean] end {name}\n"

        text = IMPORT_RE.sub(replace_import, text)
        text = INPUT_RE.sub(replace_input, text)
        seen.discard(resolved)
        return text

    result.text = expand(main, 0, is_subfile=False)
    return result


# --- LaTeX → plain text ------------------------------------------------------

# Accents written as a symbol command (`\"u`, `\'{e}`) map to a Unicode
# combining mark; NFC then fuses `u` + U+0308 into `ü`, so titles compare
# cleanly against arXiv's own (Unicode) metadata downstream.
SYMBOL_ACCENTS = {
    '"': "\u0308", "'": "\u0301", "`": "\u0300", "^": "\u0302",
    "~": "\u0303", "=": "\u0304", ".": "\u0307",
}
# Accents written as a letter command need a delimiter: `\c{c}` or `\c c`.
LETTER_ACCENTS = {
    "u": "\u0306", "v": "\u030c", "H": "\u030b", "c": "\u0327",
    "k": "\u0328", "r": "\u030a", "d": "\u0323", "b": "\u0331",
}
NAMED_CHARS = {
    "ss": "ß", "ae": "æ", "AE": "Æ", "oe": "œ", "OE": "Œ", "o": "ø", "O": "Ø",
    "l": "ł", "L": "Ł", "aa": "å", "AA": "Å", "i": "i", "j": "j",
    "&": "&", "%": "%", "_": "_", "#": "#", "$": "$", "{": "{", "}": "}",
    "textquoteright": "'", "textquoteleft": "'", "ldots": "...", "dots": "...",
}
SYMBOL_ACCENT_RE = re.compile(r"\\([\"'`^~=.])\s*(?:\{([A-Za-z]?)\}|([A-Za-z]))")
LETTER_ACCENT_RE = re.compile(r"\\([uvHckrdb])(?:\s*\{([A-Za-z]?)\}|\s+([A-Za-z]))")
NAMED_CHAR_RE = re.compile(
    r"\\(" + "|".join(re.escape(k) for k in sorted(NAMED_CHARS, key=len, reverse=True))
    + r")(?![A-Za-z])(?:\{\})?"
)
# Commands whose argument is ordinary text: keep the argument, drop the wrapper.
UNWRAP_RE = re.compile(
    r"\\(?:emph|textit|textbf|texttt|textsc|textrm|textsf|textup|textnormal|text"
    r"|mbox|hbox|url|natexlab|mathrm|mathbf|uppercase|lowercase|MakeUppercase"
    r"|MakeLowercase|enquote)\s*\{"
)
HREF_RE = re.compile(r"\\href\s*\{[^}]*\}\s*\{")
# Any command left after the ones above (font switches, \relax, \BIBand…).
COMMAND_RE = re.compile(r"\\[A-Za-z@]+\*?\s*|\\[/\-]")


def _drop_wrapper(text: str, pattern: re.Pattern[str]) -> str:
    """Replace `\\cmd{arg}` with `arg`, honouring nested braces in `arg`."""
    out: list[str] = []
    pos = 0
    while True:
        match = pattern.search(text, pos)
        if match is None:
            out.append(text[pos:])
            return "".join(out)
        out.append(text[pos : match.start()])
        # Find the brace that closes the argument, then splice out both braces.
        depth, i = 1, match.end()
        while i < len(text) and depth:
            depth += {"{": 1, "}": -1}.get(text[i], 0)
            i += 1
        out.append(text[match.end() : i - 1] if depth == 0 else text[match.end() :])
        pos = i


MATH_RE = re.compile(r"\$[^$]*\$")


def detex(text: str) -> str:
    """Best-effort conversion of a LaTeX fragment to plain text.

    `Minh{-}Thang` → `Minh-Thang`, `{\\em NIPS}` → `NIPS`, `G{\\"u}l{\\c{c}}ehre`
    → `Gülçehre`. Unknown commands are dropped rather than kept verbatim: a
    stray `\\relax` in a title would only add noise to fuzzy matching. Inline
    math is left exactly as written, because arXiv's own metadata keeps
    `$\\ell_1$` verbatim and that is what titles get matched against.
    """
    # Protect math spans, convert the prose between them, then put math back.
    spans = MATH_RE.findall(text)
    text = MATH_RE.sub("\x00", text)
    text = _detex_prose(text)
    for span in spans:
        text = text.replace("\x00", span, 1)
    return " ".join(text.split())


def _detex_prose(text: str) -> str:
    text = _drop_wrapper(text, HREF_RE)
    text = _drop_wrapper(text, UNWRAP_RE)
    text = NAMED_CHAR_RE.sub(lambda m: NAMED_CHARS[m.group(1)], text)
    text = SYMBOL_ACCENT_RE.sub(
        lambda m: (m.group(2) or m.group(3) or "") + SYMBOL_ACCENTS[m.group(1)], text
    )
    text = LETTER_ACCENT_RE.sub(
        lambda m: (m.group(2) or m.group(3) or "") + LETTER_ACCENTS[m.group(1)], text
    )
    text = COMMAND_RE.sub("", text)
    text = text.replace("~", " ").replace("``", '"').replace("''", '"')
    text = text.replace("---", "-").replace("--", "-")
    text = text.replace("{", "").replace("}", "")
    return unicodedata.normalize("NFC", text)


# --- bibliography entries ----------------------------------------------------

BIBLIOGRAPHY_RE = re.compile(r"\\bibliography\s*\{([^}]*)\}")
THEBIB_RE = re.compile(
    r"\\begin\{thebibliography\}.*?\\end\{thebibliography\}", re.DOTALL
)
BIBITEM_SPLIT_RE = re.compile(r"\\bibitem(?:\[[^\]]*\])?\s*\{([^}]*)\}")
NEWBLOCK_RE = re.compile(r"\\newblock\b")
DOI_RE = re.compile(r"10\.\d{4,9}/[-._;()/:a-zA-Z0-9]+")
# natbib disambiguates same-author years as `2014b`; the letter is not a year.
YEAR_RE = re.compile(r"\b((?:19|20)\d{2})[a-z]?\b")
# Digit runs that are not years but sit in the year range: page ranges,
# volume(issue), and the pieces of an arXiv id or DOI. Blanked before YEAR_RE.
NOT_A_YEAR_RE = re.compile(r"\d+\s*-{1,3}\s*\d+|\d+\s*\(\d+\)")
# A year tacked onto an author block: `Zheng. 2016.` or `Gao, J. (2011).`
TRAILING_YEAR_RE = re.compile(r"[\s.,(]*\(?(?:19|20)\d{2}[a-z]?\)?\.?\s*$")
# With no venue block BibTeX appends `, 2001` to the title instead. Only a
# comma-led year is stripped: "…Challenge 2012" is genuinely part of a title.
TITLE_YEAR_RE = re.compile(r",\s*(?:19|20)\d{2}[a-z]?\.?\s*$")
# IEEE-style entries quote the title instead of using \newblock.
QUOTED_TITLE_RE = re.compile(r"``(.+?),?''")
# Author-year styles (SAGE, APA-like) put the title in the FIRST block, after the
# parenthesised year: "Argall BD, ... (2009) A survey of robot learning ...".
AUTHOR_YEAR_TITLE_RE = re.compile(r"^(?P<authors>.+?)\s*\((?:19|20)\d{2}[a-z]?\)\s*(?P<title>.+?)\.?\s*$", re.DOTALL)
BIBTEX_ENTRY_RE = re.compile(r"@([A-Za-z]+)\s*([{(])")
BIBTEX_FIELD_RE = re.compile(r"\s*,?\s*([^\s=,{}]+)\s*=\s*")


@dataclass
class BibEntry:
    key: str
    raw: str
    title: str | None = None
    authors: str | None = None
    year: int | None = None
    arxiv_id: str | None = None
    doi: str | None = None


def _find_doi(text: str) -> str | None:
    # `\_` is how a bbl escapes an underscore inside a DOI.
    match = DOI_RE.search(text.replace("\\_", "_"))
    if not match:
        return None
    # A DOI at the end of a sentence drags the full stop along; balance parens
    # so `(doi: 10.1/x)` doesn't keep the `)`.
    doi = match.group(0).rstrip(".,;:")
    while doi.endswith(")") and doi.count("(") < doi.count(")"):
        doi = doi[:-1]
    return doi or None


def _find_year(text: str) -> int | None:
    scratch = ARXIV_ID_RE.sub(" ", text)
    scratch = DOI_RE.sub(" ", scratch)
    scratch = NOT_A_YEAR_RE.sub(" ", scratch)
    years = YEAR_RE.findall(scratch)
    # Bibliography styles put the year last far more often than first, and a
    # year inside a title ("ImageNet 2012") precedes the publication year.
    return int(years[-1]) if years else None


def _find_arxiv(text: str) -> str | None:
    match = ARXIV_MENTION_RE.search(text)
    return match.group(1) if match else None


def _looks_like_title(text: str) -> bool:
    """Reject a `\\newblock` chunk that is plainly a venue, URL or page range."""
    if len(text) < 3:
        return False
    lowered = text.lower()
    if re.match(r"(in|pages?|vol\.?|volume|technical report|phd thesis)\b", lowered):
        return False
    if lowered.startswith(("http", "www.", "arxiv preprint", "corr abs")):
        return False
    return True


def parse_bibitem(key: str, body: str) -> BibEntry | None:
    """Fields from one `\\bibitem` body, as written by a BibTeX style file.

    Almost every .bst writes `Authors. \\newblock Title. \\newblock Venue, Year.`
    so the second block is the title. IEEE-style files skip `\\newblock` and
    quote the title instead. Anything else gets a null title: a wrong title
    matches the wrong paper downstream, a missing one just matches nothing.
    """
    body = body.replace("\\end{thebibliography}", "")
    raw = " ".join(NEWBLOCK_RE.sub(" ", body).split())
    if not raw:
        return None
    entry = BibEntry(key=key.strip(), raw=raw)
    entry.arxiv_id = _find_arxiv(raw)
    entry.doi = _find_doi(raw)
    entry.year = _find_year(raw)

    chunks = [detex(c) for c in NEWBLOCK_RE.split(body)]
    chunks = [c for c in chunks if c]
    quoted = QUOTED_TITLE_RE.findall(raw)
    author_year = AUTHOR_YEAR_TITLE_RE.match(chunks[0]) if chunks else None
    if author_year and _looks_like_title(author_year.group("title").rstrip(".")):
        # Checked first: in these styles the second block is the VENUE, and taking
        # it as the title ("Robotics and autonomous systems 57(5)") matches nothing
        # at best and the wrong paper at worst.
        entry.title = author_year.group("title").rstrip(".")
        entry.authors = author_year.group("authors").rstrip(".,") or None
    elif len(chunks) >= 2:
        title = TITLE_YEAR_RE.sub("", chunks[1]).rstrip(".")
        if _looks_like_title(title):
            entry.title = title
            entry.authors = TRAILING_YEAR_RE.sub("", chunks[0]).rstrip(".") or None
    elif len(quoted) == 1:
        entry.title = detex(quoted[0]).rstrip(".")
    return entry


def parse_bibitems(thebib: str) -> list[BibEntry]:
    """Every `\\bibitem` in a `thebibliography` block, in order."""
    parts = BIBITEM_SPLIT_RE.split(thebib)
    entries: list[BibEntry] = []
    # split() gives [preamble, key1, body1, key2, body2, ...]
    for key, body in zip(parts[1::2], parts[2::2]):
        entry = parse_bibitem(key, body)
        if entry is not None:
            entries.append(entry)
    return entries


def _read_braced(text: str, start: int, open_ch: str = "{", close_ch: str = "}") -> int:
    """Index just past the group that opens at `text[start]`, or len(text)."""
    depth, i = 0, start
    while i < len(text):
        if text[i] == "\\":
            i += 2
            continue
        if text[i] == open_ch:
            depth += 1
        elif text[i] == close_ch:
            depth -= 1
            if depth == 0:
                return i + 1
        i += 1
    return len(text)


def _read_bibtex_value(text: str, pos: int) -> tuple[str, int, bool]:
    """One field value: `{…}`, `"…"`, or a bare word, joined by `#`.

    The flag says whether the value is a bare `@string` macro name (or a
    number). Macros are not expanded, so a caller must not mistake `nips` for
    a title.
    """
    pieces: list[str] = []
    macro = False
    while True:
        if pos < len(text) and text[pos] == "{":
            end = _read_braced(text, pos)
            pieces.append(text[pos + 1 : end - 1])
        elif pos < len(text) and text[pos] == '"':
            end = pos + 1
            while end < len(text) and text[end] != '"':
                end = _read_braced(text, end) if text[end] == "{" else end + 1
            pieces.append(text[pos + 1 : end])
            end += 1
        else:
            match = re.compile(r"[^\s,#}]*").match(text, pos)
            pieces.append(match.group(0) if match else "")
            end = match.end() if match else pos
            macro = True
        joiner = re.compile(r"\s*#\s*").match(text, end)
        if joiner is None:
            return "".join(pieces), end, macro
        pos = joiner.end()


def parse_bibtex(text: str) -> list[BibEntry]:
    """Entries from BibTeX source, keeping the fields `bibitems.json` needs.

    Hand-rolled because the dependency set is fixed and the format is small:
    `@type{key, name = {value}, …}` with nested braces. `@string` macros are
    not expanded — a title written as a macro is rare and comes out null.
    """
    entries: list[BibEntry] = []
    pos = 0
    while True:
        match = BIBTEX_ENTRY_RE.search(text, pos)
        if match is None:
            return entries
        close = "}" if match.group(2) == "{" else ")"
        end = _read_braced(text, match.end() - 1, match.group(2), close)
        pos = end
        kind = match.group(1).lower()
        if kind in ("comment", "preamble", "string"):
            continue
        body = text[match.end() : end - 1]
        key, _, rest = body.partition(",")
        key = key.strip()
        if not key:
            continue

        fields: dict[str, str] = {}
        macros: set[str] = set()
        cursor = 0
        while True:
            head = BIBTEX_FIELD_RE.match(rest, cursor)
            if head is None:
                break
            value, cursor, macro = _read_bibtex_value(rest, head.end())
            name = head.group(1).lower()
            fields[name] = value.strip()
            if macro and not value.strip().isdigit():
                macros.add(name)

        raw = " ".join(text[match.start() : end].split())
        entry = BibEntry(key=key, raw=raw)
        # A title given as a macro (`title = nips`) would read as the macro's
        # name; null is the honest answer since @string is not expanded.
        title = "" if "title" in macros else detex(fields.get("title", "")).rstrip(".")
        entry.title = title if _looks_like_title(title) else None
        authors = "" if "author" in macros else detex(fields.get("author", ""))
        entry.authors = authors or None
        year = YEAR_RE.search(fields.get("year", "") or fields.get("date", ""))
        entry.year = int(year.group(1)) if year else None
        entry.doi = _find_doi(fields.get("doi", "")) or _find_doi(raw)
        entry.arxiv_id = _find_arxiv(raw)
        entries.append(entry)


# --- bibliography ------------------------------------------------------------

def _bibtex_escape(text: str) -> str:
    return text.replace("{", "(").replace("}", ")").strip()


def synthesise_bib(entries: list[BibEntry]) -> str:
    """Turn parsed `\\bibitem`s into BibTeX-ish `@misc` entries.

    Plenty of arXiv papers ship no .bib at all — the bibliography is baked into
    the .tex as `\\bibitem`s, or shipped as the .bbl that BibTeX wrote. Those
    still name the works cited (and usually their arXiv ids), which is exactly
    what `ref.py` needs, so keep them in a form that parses rather than
    throwing them away.
    """
    out: list[str] = []
    for entry in entries:
        fields = [f"  note = {{{_bibtex_escape(entry.raw)}}}"]
        if entry.arxiv_id:
            fields.append(f"  eprint = {{{entry.arxiv_id}}}")
            fields.append("  archiveprefix = {arXiv}")
        out.append("@misc{" + entry.key + ",\n" + ",\n".join(fields) + "\n}")
    return "\n\n".join(out)


@dataclass
class Bibliography:
    source: str  # "bbl" | "thebibliography" | "bib"
    bibtex: str  # what refs.bib will contain
    entries: list[BibEntry]
    description: str  # one line for the log


def _dedupe(entries: list[BibEntry]) -> list[BibEntry]:
    seen: dict[str, BibEntry] = {}
    for entry in entries:
        if entry.key in seen:
            log.warning("duplicate bibliography key %r; keeping the first", entry.key)
            continue
        seen[entry.key] = entry
    return list(seen.values())


def _find_bbl_files(root: Path, main: Path | None) -> list[Path]:
    """The .bbl(s) to trust: the main file's own, else every one in the tree."""
    if main is not None and main.with_suffix(".bbl").is_file():
        return [main.with_suffix(".bbl")]
    return sorted(root.rglob("*.bbl"))


def _find_bib_files(root: Path, flattened: str) -> list[Path]:
    names = []
    for match in BIBLIOGRAPHY_RE.finditer(flattened):
        names.extend(n.strip() for n in match.group(1).split(",") if n.strip())

    found: list[Path] = []
    for name in names:
        target = _resolve(name if name.endswith(".bib") else f"{name}.bib", [root]) or next(
            iter(sorted(root.rglob(f"{Path(name).name}.bib"))), None
        )
        if target is not None and target not in found:
            found.append(target)
    # No \bibliography, or it pointed at files the tarball doesn't ship.
    return found or sorted(root.rglob("*.bib"))


def _fill_from_bib(entries: list[BibEntry], bibs: list[Path]) -> int:
    """Take title/authors/DOI/arXiv id from a shipped .bib for the same cite key.

    The .bbl is the authority on which works are cited, but its fields are
    recovered heuristically from formatted text; the .bib has them as structured
    fields. The .bib title wins even when the .bbl produced one, because a
    heuristic title can be a venue ("Robotics and autonomous systems 57(5)").
    """
    if not bibs:
        return 0
    by_key = {}
    for path in bibs:
        for e in parse_bibtex(path.read_text(encoding="utf-8", errors="replace")):
            by_key.setdefault(e.key, e)
    filled = 0
    for entry in entries:
        source = by_key.get(entry.key)
        if source is None:
            continue
        for name in ("title", "authors", "doi", "arxiv_id", "year"):
            value = getattr(source, name)
            if value and value != getattr(entry, name) and (name == "title" or not getattr(entry, name)):
                setattr(entry, name, value)
                filled += 1
    return filled


def collect_bib(root: Path, flattened: str, main: Path | None = None) -> Bibliography | None:
    """The paper's references, from the most faithful source available.

    A .bbl is BibTeX's own output — exactly the entries the compiled paper
    cites — so it beats an inline `thebibliography` (usually a pasted .bbl,
    possibly hand-edited) which beats the .bib (often full of entries that were
    never cited). A .bbl that holds no `\\bibitem` (biblatex writes a different
    format) is skipped rather than reported as an empty bibliography.
    """
    bbls = _find_bbl_files(root, main)
    if bbls:
        entries = _dedupe(
            [e for path in bbls for e in parse_bibitems(path.read_text(encoding="utf-8", errors="replace"))]
        )
        if entries:
            names = ", ".join(p.name for p in bbls)
            filled = _fill_from_bib(entries, _find_bib_files(root, flattened))
            if filled:
                names += f" (+{filled} field(s) from .bib)"
            return Bibliography(
                source="bbl",
                bibtex=f"% synthesised from {names}\n" + synthesise_bib(entries),
                entries=entries,
                description=f"{len(entries)} \\bibitem(s) from {names}",
            )
        log.warning("%s: no \\bibitem in %s; ignoring", root.name, ", ".join(p.name for p in bbls))

    thebib = THEBIB_RE.search(flattened)
    if thebib:
        entries = _dedupe(parse_bibitems(thebib.group(0)))
        if entries:
            return Bibliography(
                source="thebibliography",
                bibtex="% synthesised from an inline thebibliography block\n" + synthesise_bib(entries),
                entries=entries,
                description=f"{len(entries)} inline \\bibitem(s)",
            )

    bibs = _find_bib_files(root, flattened)
    if bibs:
        chunks = [p.read_text(encoding="utf-8", errors="replace") for p in bibs]
        entries = _dedupe([e for chunk in chunks for e in parse_bibtex(chunk)])
        names = ", ".join(p.name for p in bibs)
        return Bibliography(
            source="bib",
            bibtex=f"% merged from: {names}\n" + "\n\n".join(chunks),
            entries=entries,
            description=f"{len(entries)} entries from {len(bibs)} .bib file(s)",
        )

    return None


# --- driving one paper -------------------------------------------------------

@dataclass
class CleanResult:
    arxiv_id: str
    out_dir: Path
    main_tex: Path
    bib: Path | None
    included: int
    missing: list[str]
    bib_source: str
    bibitems: Path | None = None
    bib_entries: int = 0


def write_bibitems(path: Path, arxiv_id: str, bib: Bibliography) -> None:
    """Write `bibitems.json`; the schema is a contract with downstream code."""
    payload = {
        "paper": arxiv_id,
        "source": bib.source,
        "count": len(bib.entries),
        "entries": {
            e.key: {
                "raw": e.raw,
                "title": e.title,
                "authors": e.authors,
                "year": e.year,
                "arxiv_id": e.arxiv_id,
                "doi": e.doi,
            }
            for e in bib.entries
        },
    }
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def clean_source(src: Path, out_dir: Path, arxiv_id: str = "") -> CleanResult:
    """Flatten one unpacked arXiv source tree into `out_dir`."""
    main = find_main_tex(src)
    if main is None:
        raise FileNotFoundError(f"no .tex with \\documentclass and \\begin{{document}} under {src}")

    flat = flatten(main, root=src)
    bib = collect_bib(src, flat.text, main)

    out_dir.mkdir(parents=True, exist_ok=True)
    main_out = out_dir / "main.tex"
    banner = (
        f"%% flattened by data/clean.py from {main.name}\n"
        f"%% source: {src.name}\n"
        f"%% inlined {len(flat.included)} file(s)\n"
    )
    main_out.write_text(banner + flat.text.strip() + "\n", encoding="utf-8")

    bib_out: Path | None = None
    items_out: Path | None = None
    if bib is not None:
        bib_out = out_dir / "refs.bib"
        bib_out.write_text(bib.bibtex.strip() + "\n", encoding="utf-8")
        items_out = out_dir / "bibitems.json"
        write_bibitems(items_out, arxiv_id or src.name, bib)

    return CleanResult(
        arxiv_id=arxiv_id or src.name,
        out_dir=out_dir,
        main_tex=main_out,
        bib=bib_out,
        included=len(flat.included),
        missing=flat.missing,
        bib_source=bib.description if bib else "no bibliography found",
        bibitems=items_out,
        bib_entries=len(bib.entries) if bib else 0,
    )


def raw_dir_for(raw_root: Path, arxiv_id: str) -> Path | None:
    """Locate the unpacked source for an id, tolerating naming variations."""
    for name in (f"arXiv-{arxiv_id}", arxiv_id, f"arxiv-{arxiv_id}"):
        candidate = raw_root / name
        if candidate.is_dir():
            return candidate
    # Fall back to any directory whose name contains the id (e.g. a version drift).
    base = arxiv_id.split("v")[0]
    matches = [d for d in raw_root.iterdir() if d.is_dir() and base in d.name]
    return matches[0] if len(matches) == 1 else None


class _Fetcher:
    """Downloads main-paper sources from arXiv, on demand.

    `ref.py` already knows how to pull and unpack an e-print (tarball, bare
    gzip, or a PDF-only response), so reuse it rather than growing a second
    copy. The import is deferred because `ref` imports *this* module at the
    top level, and a module-level import here would make that circular.
    """

    def __init__(self, raw_root: Path, delay_s: float = 3.0) -> None:
        self.raw_root = raw_root
        self.delay_s = delay_s
        self._client = None
        self._fetched = 0

    def fetch(self, arxiv_id: str) -> Path:
        import time

        import httpx

        from ref import USER_AGENT, download_source

        if self._client is None:
            self._client = httpx.Client(headers={"User-Agent": USER_AGENT}, timeout=60.0)
        # arXiv asks for a few seconds between requests; only pause once we've
        # actually hit the network, so a single-paper run starts immediately.
        if self._fetched and self.delay_s > 0:
            time.sleep(self.delay_s)
        log.info("%s: downloading source from arXiv", arxiv_id)
        src = download_source(self._client, arxiv_id, self.raw_root)
        self._fetched += 1
        return src


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Flatten arXiv LaTeX sources into main.tex + refs.bib + bibitems.json per paper.",
    )
    parser.add_argument("ids", type=Path, help="file listing arXiv ids (list literal or one per line)")
    parser.add_argument("--raw", type=Path, default=Path("data/raw"), help="unpacked sources")
    parser.add_argument("--out", type=Path, default=Path("data/clean"), help="destination")
    parser.add_argument(
        "--no-fetch",
        dest="fetch",
        action="store_false",
        help="fail instead of downloading sources that aren't already unpacked",
    )
    parser.add_argument(
        "--delay",
        type=float,
        default=3.0,
        help="seconds between arXiv downloads (default: 3, arXiv's requested rate)",
    )
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)-7s %(name)s: %(message)s",
    )

    ids = read_id_list(args.ids)
    if not ids:
        log.error("no arXiv ids found in %s", args.ids)
        return 1
    log.info("cleaning %d paper(s)", len(ids))

    failures = 0
    fetcher = _Fetcher(args.raw, args.delay) if args.fetch else None
    for arxiv_id in ids:
        src = raw_dir_for(args.raw, arxiv_id)
        if src is None and fetcher is not None:
            # The whole pipeline starts here, so a missing source is the normal
            # case for a newly added id — fetch it rather than sending the user
            # off to ref.py, which only ever downloaded *references*.
            try:
                src = fetcher.fetch(arxiv_id)
            except Exception as exc:
                log.error("%s: could not download source: %s", arxiv_id, exc)
                failures += 1
                continue
        if src is None:
            log.error(
                "%s: no source under %s and --no-fetch was given; "
                "drop the unpacked source in %s/arXiv-%s or drop --no-fetch",
                arxiv_id,
                args.raw,
                args.raw,
                arxiv_id,
            )
            failures += 1
            continue
        try:
            res = clean_source(src, args.out / f"arXiv-{arxiv_id}", arxiv_id)
        except Exception as exc:
            log.error("%s: %s: %s", arxiv_id, type(exc).__name__, exc)
            failures += 1
            continue
        log.info(
            "%s → %s (%d files inlined, bib: %s%s)",
            arxiv_id,
            res.out_dir,
            res.included,
            res.bib_source,
            f", {len(res.missing)} missing input(s)" if res.missing else "",
        )
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
