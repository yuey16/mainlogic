"""Assemble the released dataset from the built cores and the triage in data/claims.yaml.

`data/built/<claim id>.json` holds one record per claim, written by data/augment.py (eight early
cores were built by directed edits and carry `method: directed-edit`; they are exported the same way).
Triage happens in data/claims.yaml itself: `drop: true` removes a claim, and `keep: true` admits a
core whose leftover check did not pass after a person has read it (the reason is in its `note`).
Small fixes a person makes to a core are applied to its built record directly (`hand_fixes`).

    data/final/mainlogic.jsonl = every VERIFIED core of a claim in data/claims.yaml without drop
                               + every unverified core whose claim has keep: true
                               + the P= control for the cores above
    and every row flagged with the human audit of its core (verified | failed | unaudited)

Usage:
    python data/export.py
"""

from __future__ import annotations

import collections
import json
import logging
import sys
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent))
from claims import claim_id, load  # noqa: E402
from human_audit import AUDIT_DIR, core_status, load_records  # noqa: E402

log = logging.getLogger("export")
ROOT = Path(__file__).resolve().parents[1]
BUILT = ROOT / "data" / "built"
PRESERVED = ROOT / "data" / "preserved"
FINAL = ROOT / "data" / "final" / "mainlogic.jsonl"
CELLS = ["P+C+", "P+C-", "P-C+", "P-C-", "P0C+", "P0C-"]
#  The released schema, in this order, on every row.
FIELDS = ["id", "anchor_id", "cell", "paper", "cite_keys", "premise_keys", "no_premise", "premise",
          "conclusion", "relation", "route", "ref_statements", "human_audit"]


def export() -> dict:
    """Verified cores + unverified cores kept after triage, then the P= control."""
    rows = []
    counts = collections.Counter()
    # only claims that are in data/claims.yaml right now: a dropped entry, or one whose line or
    # negation changed (a new id), leaves its old built record behind but not in the dataset
    active = {claim_id(e): e for e in load() if not e.get("drop")}
    for path in sorted(BUILT.glob("*.json")):
        record = json.loads(path.read_text(encoding="utf-8"))
        if record["id"] not in active:
            counts["superseded"] += 1
            continue
        counts[record["status"]] += 1
        if not record.get("cells"):
            continue
        if record["status"] != "verified" and not active[record["id"]].get("keep"):
            continue
        cells = {c["cell"]: c for c in record["cells"]}
        for name in CELLS:
            rows.append(cells[name])
        counts["exported"] += 1
    #  The P= control, when data/preserve.py has built it. Only for anchors that made it into the
    #  dataset above: a control without the cells it controls for is not worth shipping.
    shipped = {r["anchor_id"] for r in rows}
    for path in sorted(PRESERVED.glob("*.json")):
        record = json.loads(path.read_text(encoding="utf-8"))
        if record["id"] not in shipped:
            counts["preserved_orphan"] += 1
            continue
        rows.extend(record["cells"])
        counts["preserved"] += 1
    #  One schema for every row. Dropped: `context` (every claim is standalone, so it was always
    #  empty), `pair_id` and `claim_id` (always equal to `anchor_id`), `variant` (always equal to
    #  `cell`), `operator` (construction method), `audit` (an old per-core decision field;
    #  triage now lives in data/claims.yaml) and `verified` (the automatic leftover check, which
    #  only ever varied on P- rows and is recorded per core as `status` in data/built/).
    #  Added: the human audit's verdict on the row's core - a flag, never a filter
    #  (data/human_audit.py, `core_status`).
    human = core_status(load_records(AUDIT_DIR))
    for i, row in enumerate(rows):
        for key in ("context", "pair_id", "claim_id", "variant", "operator", "audit", "verified"):
            row.pop(key, None)
        row["ref_statements"] = [{k: v for k, v in s.items() if k != "verified"}   # always true
                                 for s in row["ref_statements"]]
        row = {("human_audit" if k == "human_reviewed" else k): v for k, v in row.items()}
        row["human_audit"] = human.get(row["anchor_id"], "unaudited")
        assert set(row) == set(FIELDS), (row["id"], sorted(set(row) ^ set(FIELDS)))
        rows[i] = {k: row[k] for k in FIELDS}
    counts["human_audit"] = dict(collections.Counter(r["human_audit"] for r in rows))
    FINAL.parent.mkdir(parents=True, exist_ok=True)
    FINAL.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows), encoding="utf-8")
    counts["cores_in_final"] = len({r["anchor_id"] for r in rows})
    return dict(counts)


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)-7s %(name)s: %(message)s")
    log.info("export: %s", export())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
